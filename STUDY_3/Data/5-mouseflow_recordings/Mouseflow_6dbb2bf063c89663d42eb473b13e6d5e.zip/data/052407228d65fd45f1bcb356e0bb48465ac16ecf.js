var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052407228d65fd45f1bcb356e0bb48465ac16ecf"] = {
  "startTime": "2018-05-24T19:20:07.6663265Z",
  "websitePageUrl": "/16",
  "visitTime": 80679,
  "engagementTime": 67594,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "6dbb2bf063c89663d42eb473b13e6d5e",
    "created": "2018-05-24T19:20:07.5172126+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=HZWEH",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5144862af82974bd771d28ef42bc7697",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6dbb2bf063c89663d42eb473b13e6d5e/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 493,
      "y": 692
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 41356,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1277,
      "e": 1277,
      "ty": 6,
      "x": 459,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 456,
      "y": 594
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 452,
      "y": 582
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 39894,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1612,
      "e": 1612,
      "ty": 3,
      "x": 452,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1614,
      "e": 1614,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1707,
      "e": 1707,
      "ty": 4,
      "x": 39894,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1708,
      "e": 1708,
      "ty": 5,
      "x": 452,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4202,
      "e": 4202,
      "ty": 2,
      "x": 463,
      "y": 557
    },
    {
      "t": 4245,
      "e": 4245,
      "ty": 7,
      "x": 469,
      "y": 513,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 41805,
      "y": 42751,
      "ta": "#.strategy > p"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 471,
      "y": 431
    },
    {
      "t": 4402,
      "e": 4402,
      "ty": 2,
      "x": 468,
      "y": 373
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 2,
      "x": 467,
      "y": 357
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 41581,
      "y": 19333,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10005,
      "e": 9502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10812,
      "e": 9502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10916,
      "e": 9606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 10916,
      "e": 9606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11002,
      "e": 9692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "C"
    },
    {
      "t": 11051,
      "e": 9741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "C"
    },
    {
      "t": 11140,
      "e": 9830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11140,
      "e": 9830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11234,
      "e": 9924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Co"
    },
    {
      "t": 11258,
      "e": 9948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 11259,
      "e": 9949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11339,
      "e": 10029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11339,
      "e": 10029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11371,
      "e": 10061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11371,
      "e": 10061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11379,
      "e": 10069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compa"
    },
    {
      "t": 11459,
      "e": 10149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11459,
      "e": 10149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 11460,
      "e": 10150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11483,
      "e": 10173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 11540,
      "e": 10230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11540,
      "e": 10230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11586,
      "e": 10276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11602,
      "e": 10292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11603,
      "e": 10293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11626,
      "e": 10316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11674,
      "e": 10364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13852,
      "e": 12542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13852,
      "e": 12542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13954,
      "e": 12644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13955,
      "e": 12645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14019,
      "e": 12709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 14027,
      "e": 12717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14027,
      "e": 12717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14043,
      "e": 12733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14163,
      "e": 12853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14164,
      "e": 12854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14182,
      "e": 12872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14250,
      "e": 12940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14275,
      "e": 12965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 14275,
      "e": 12965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14347,
      "e": 13037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14347,
      "e": 13037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14355,
      "e": 13045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||va"
    },
    {
      "t": 14460,
      "e": 13150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14483,
      "e": 13173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14484,
      "e": 13174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14522,
      "e": 13212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14522,
      "e": 13212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14603,
      "e": 13293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14603,
      "e": 13293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14610,
      "e": 13300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rio"
    },
    {
      "t": 14666,
      "e": 13356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14668,
      "e": 13358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14675,
      "e": 13365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 14707,
      "e": 13397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14747,
      "e": 13437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14748,
      "e": 13438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14771,
      "e": 13461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14834,
      "e": 13524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14843,
      "e": 13533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14843,
      "e": 13533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14915,
      "e": 13605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15036,
      "e": 13726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15037,
      "e": 13727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15155,
      "e": 13845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15179,
      "e": 13869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15179,
      "e": 13869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15235,
      "e": 13925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15235,
      "e": 13925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15251,
      "e": 13941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 15371,
      "e": 14061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15395,
      "e": 14085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15396,
      "e": 14086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15523,
      "e": 14213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 15652,
      "e": 14342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15652,
      "e": 14342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15762,
      "e": 14452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15787,
      "e": 14477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15787,
      "e": 14477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15859,
      "e": 14549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15883,
      "e": 14573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15884,
      "e": 14574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15955,
      "e": 14645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15956,
      "e": 14646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15970,
      "e": 14660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 16010,
      "e": 14700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16075,
      "e": 14765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16075,
      "e": 14765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16131,
      "e": 14821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16132,
      "e": 14822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16195,
      "e": 14885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 16203,
      "e": 14893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16204,
      "e": 14894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16283,
      "e": 14973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16299,
      "e": 14989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16300,
      "e": 14990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16323,
      "e": 15013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16363,
      "e": 15053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16379,
      "e": 15069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16379,
      "e": 15069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16443,
      "e": 15133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16443,
      "e": 15133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16483,
      "e": 15173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 16491,
      "e": 15181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16491,
      "e": 15181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16515,
      "e": 15205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16563,
      "e": 15253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16564,
      "e": 15254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16603,
      "e": 15293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16618,
      "e": 15308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16619,
      "e": 15309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16658,
      "e": 15348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16723,
      "e": 15413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16803,
      "e": 15493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16804,
      "e": 15494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16891,
      "e": 15581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16971,
      "e": 15661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16971,
      "e": 15661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17060,
      "e": 15750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17251,
      "e": 15941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 17253,
      "e": 15943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17323,
      "e": 16013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17323,
      "e": 16013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17363,
      "e": 16053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 17427,
      "e": 16117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17451,
      "e": 16141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17452,
      "e": 16142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17547,
      "e": 16237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17635,
      "e": 16325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 17636,
      "e": 16326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17731,
      "e": 16421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17731,
      "e": 16421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17738,
      "e": 16428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'s"
    },
    {
      "t": 17835,
      "e": 16525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17900,
      "e": 16525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17902,
      "e": 16527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17946,
      "e": 16571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18067,
      "e": 16692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 18067,
      "e": 16692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18115,
      "e": 16740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18115,
      "e": 16740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18156,
      "e": 16781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||br"
    },
    {
      "t": 18164,
      "e": 16789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18165,
      "e": 16790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18218,
      "e": 16843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18218,
      "e": 16843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18250,
      "e": 16875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ea"
    },
    {
      "t": 18275,
      "e": 16900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 18275,
      "e": 16900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18290,
      "e": 16915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 18347,
      "e": 16972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18379,
      "e": 17004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18379,
      "e": 17004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18394,
      "e": 17019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18499,
      "e": 17124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18500,
      "e": 17125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18547,
      "e": 17172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18571,
      "e": 17196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18594,
      "e": 17219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18594,
      "e": 17219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18650,
      "e": 17275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 18651,
      "e": 17276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18675,
      "e": 17300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ov"
    },
    {
      "t": 18731,
      "e": 17356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18804,
      "e": 17429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18804,
      "e": 17429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18875,
      "e": 17500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18875,
      "e": 17500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18899,
      "e": 17524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 18971,
      "e": 17596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18971,
      "e": 17596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18987,
      "e": 17612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 19035,
      "e": 17660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19091,
      "e": 17716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19092,
      "e": 17717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19206,
      "e": 17831,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compare the various start times to see who's breaks overla"
    },
    {
      "t": 19211,
      "e": 17836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19211,
      "e": 17836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19211,
      "e": 17836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19331,
      "e": 17956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19692,
      "e": 18317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19695,
      "e": 18320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19747,
      "e": 18372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19747,
      "e": 18372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19763,
      "e": 18388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 19843,
      "e": 18468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19859,
      "e": 18484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19859,
      "e": 18484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19874,
      "e": 18499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19875,
      "e": 18500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19930,
      "e": 18555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 19979,
      "e": 18604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19980,
      "e": 18605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19986,
      "e": 18611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20066,
      "e": 18691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20083,
      "e": 18708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 20083,
      "e": 18708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20186,
      "e": 18811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 20203,
      "e": 18828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20204,
      "e": 18829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20306,
      "e": 18931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20307,
      "e": 18932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20307,
      "e": 18932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20411,
      "e": 19036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20539,
      "e": 19164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20539,
      "e": 19164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20619,
      "e": 19244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20795,
      "e": 19420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20796,
      "e": 19421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20907,
      "e": 19532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20939,
      "e": 19564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20939,
      "e": 19564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21019,
      "e": 19644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21035,
      "e": 19660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21036,
      "e": 19661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21122,
      "e": 19747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21122,
      "e": 19747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21147,
      "e": 19772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 21267,
      "e": 19892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21411,
      "e": 20036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21412,
      "e": 20037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21522,
      "e": 20147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21522,
      "e": 20147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21538,
      "e": 20163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 21683,
      "e": 20308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21810,
      "e": 20435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21811,
      "e": 20436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21883,
      "e": 20508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22007,
      "e": 20632,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compare the various start times to see who's breaks overlap and who starts "
    },
    {
      "t": 22027,
      "e": 20652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22027,
      "e": 20652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22100,
      "e": 20725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22100,
      "e": 20725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22123,
      "e": 20748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wo"
    },
    {
      "t": 22162,
      "e": 20787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22162,
      "e": 20787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22187,
      "e": 20812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22259,
      "e": 20884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 22259,
      "e": 20884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22299,
      "e": 20924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 22339,
      "e": 20964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22340,
      "e": 20965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22354,
      "e": 20979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22386,
      "e": 21011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22386,
      "e": 21011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22403,
      "e": 21028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22483,
      "e": 21108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22514,
      "e": 21139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22514,
      "e": 21139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22562,
      "e": 21187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22563,
      "e": 21188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22603,
      "e": 21188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 22658,
      "e": 21243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22659,
      "e": 21244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22667,
      "e": 21252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22747,
      "e": 21332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22779,
      "e": 21364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22779,
      "e": 21364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22850,
      "e": 21435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22851,
      "e": 21436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22891,
      "e": 21476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 22963,
      "e": 21548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22964,
      "e": 21549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22987,
      "e": 21572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23075,
      "e": 21660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23091,
      "e": 21676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23092,
      "e": 21677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23170,
      "e": 21755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23219,
      "e": 21804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23219,
      "e": 21804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23315,
      "e": 21900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23316,
      "e": 21901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23331,
      "e": 21916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 23444,
      "e": 22029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23467,
      "e": 22052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23470,
      "e": 22055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23546,
      "e": 22131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23555,
      "e": 22140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 23555,
      "e": 22140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23611,
      "e": 22196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23611,
      "e": 22196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23666,
      "e": 22251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 23668,
      "e": 22253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23715,
      "e": 22300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23715,
      "e": 22300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23803,
      "e": 22388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23804,
      "e": 22389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23819,
      "e": 22404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ni"
    },
    {
      "t": 23843,
      "e": 22428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23843,
      "e": 22428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23883,
      "e": 22468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23939,
      "e": 22524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23955,
      "e": 22540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23955,
      "e": 22540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24018,
      "e": 22603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24019,
      "e": 22604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24042,
      "e": 22627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 24083,
      "e": 22668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24206,
      "e": 22791,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compare the various start times to see who's breaks overlap and who starts work and who is finishe"
    },
    {
      "t": 24267,
      "e": 22852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24268,
      "e": 22853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24406,
      "e": 22991,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compare the various start times to see who's breaks overlap and who starts work and who is finished"
    },
    {
      "t": 24419,
      "e": 23004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24612,
      "e": 23197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24612,
      "e": 23197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24722,
      "e": 23307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24762,
      "e": 23347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 24763,
      "e": 23348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24899,
      "e": 23484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 24907,
      "e": 23492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24907,
      "e": 23492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25051,
      "e": 23636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 25347,
      "e": 23932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25348,
      "e": 23933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25394,
      "e": 23979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25410,
      "e": 23995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 25410,
      "e": 23995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25474,
      "e": 24059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25474,
      "e": 24059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25499,
      "e": 24084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 25546,
      "e": 24131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25587,
      "e": 24172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25587,
      "e": 24172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25667,
      "e": 24252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25675,
      "e": 24260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25676,
      "e": 24261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25754,
      "e": 24339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25770,
      "e": 24355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25771,
      "e": 24356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25858,
      "e": 24443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25859,
      "e": 24444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25939,
      "e": 24524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 25947,
      "e": 24532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25971,
      "e": 24556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25972,
      "e": 24557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26075,
      "e": 24660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26378,
      "e": 24963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26379,
      "e": 24964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26435,
      "e": 25020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26436,
      "e": 25021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26450,
      "e": 25035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| d"
    },
    {
      "t": 26507,
      "e": 25092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26507,
      "e": 25092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26603,
      "e": 25188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26603,
      "e": 25188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 26603,
      "e": 25188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26651,
      "e": 25236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 26675,
      "e": 25260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26826,
      "e": 25411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 26827,
      "e": 25412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26906,
      "e": 25491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 28705,
      "e": 27290,
      "ty": 2,
      "x": 467,
      "y": 361
    },
    {
      "t": 28754,
      "e": 27339,
      "ty": 41,
      "x": 41918,
      "y": 22269,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 28804,
      "e": 27389,
      "ty": 2,
      "x": 456,
      "y": 459
    },
    {
      "t": 28853,
      "e": 27438,
      "ty": 6,
      "x": 437,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28904,
      "e": 27489,
      "ty": 2,
      "x": 429,
      "y": 572
    },
    {
      "t": 29004,
      "e": 27589,
      "ty": 7,
      "x": 426,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29006,
      "e": 27591,
      "ty": 2,
      "x": 426,
      "y": 609
    },
    {
      "t": 29007,
      "e": 27591,
      "ty": 41,
      "x": 36972,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 29102,
      "e": 27686,
      "ty": 6,
      "x": 431,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 29104,
      "e": 27688,
      "ty": 2,
      "x": 431,
      "y": 655
    },
    {
      "t": 29204,
      "e": 27788,
      "ty": 2,
      "x": 431,
      "y": 664
    },
    {
      "t": 29254,
      "e": 27838,
      "ty": 41,
      "x": 50465,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 29304,
      "e": 27888,
      "ty": 2,
      "x": 432,
      "y": 664
    },
    {
      "t": 29504,
      "e": 28088,
      "ty": 41,
      "x": 51011,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 29754,
      "e": 28338,
      "ty": 41,
      "x": 51557,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 29804,
      "e": 28388,
      "ty": 2,
      "x": 433,
      "y": 665
    },
    {
      "t": 29960,
      "e": 28544,
      "ty": 3,
      "x": 433,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 29961,
      "e": 28545,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Compare the various start times to see who's breaks overlap and who starts work and who is finished up for the day."
    },
    {
      "t": 29963,
      "e": 28547,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29964,
      "e": 28548,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30022,
      "e": 28606,
      "ty": 4,
      "x": 51557,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 30032,
      "e": 28616,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30033,
      "e": 28617,
      "ty": 5,
      "x": 433,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 30042,
      "e": 28626,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 31039,
      "e": 29623,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 31604,
      "e": 30188,
      "ty": 2,
      "x": 523,
      "y": 640
    },
    {
      "t": 31704,
      "e": 30288,
      "ty": 2,
      "x": 744,
      "y": 627
    },
    {
      "t": 31754,
      "e": 30338,
      "ty": 41,
      "x": 26344,
      "y": 33570,
      "ta": "html > body"
    },
    {
      "t": 31804,
      "e": 30388,
      "ty": 2,
      "x": 804,
      "y": 601
    },
    {
      "t": 31855,
      "e": 30439,
      "ty": 6,
      "x": 839,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31904,
      "e": 30488,
      "ty": 2,
      "x": 839,
      "y": 573
    },
    {
      "t": 32004,
      "e": 30588,
      "ty": 2,
      "x": 847,
      "y": 570
    },
    {
      "t": 32005,
      "e": 30589,
      "ty": 41,
      "x": 8435,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32104,
      "e": 30688,
      "ty": 2,
      "x": 853,
      "y": 566
    },
    {
      "t": 32192,
      "e": 30776,
      "ty": 3,
      "x": 853,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32193,
      "e": 30777,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32204,
      "e": 30788,
      "ty": 2,
      "x": 853,
      "y": 565
    },
    {
      "t": 32254,
      "e": 30838,
      "ty": 41,
      "x": 9949,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32263,
      "e": 30847,
      "ty": 4,
      "x": 9949,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32263,
      "e": 30847,
      "ty": 5,
      "x": 854,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32304,
      "e": 30888,
      "ty": 2,
      "x": 854,
      "y": 565
    },
    {
      "t": 32563,
      "e": 31147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 32563,
      "e": 31147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32635,
      "e": 31219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 32704,
      "e": 31288,
      "ty": 2,
      "x": 856,
      "y": 566
    },
    {
      "t": 32715,
      "e": 31299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 32715,
      "e": 31299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32742,
      "e": 31326,
      "ty": 7,
      "x": 859,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32754,
      "e": 31338,
      "ty": 41,
      "x": 11030,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 32795,
      "e": 31379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 32804,
      "e": 31388,
      "ty": 2,
      "x": 869,
      "y": 606
    },
    {
      "t": 32838,
      "e": 31422,
      "ty": 6,
      "x": 884,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32904,
      "e": 31488,
      "ty": 2,
      "x": 889,
      "y": 661
    },
    {
      "t": 32976,
      "e": 31560,
      "ty": 7,
      "x": 890,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33004,
      "e": 31588,
      "ty": 2,
      "x": 891,
      "y": 670
    },
    {
      "t": 33004,
      "e": 31588,
      "ty": 41,
      "x": 17951,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 33104,
      "e": 31688,
      "ty": 2,
      "x": 893,
      "y": 674
    },
    {
      "t": 33157,
      "e": 31741,
      "ty": 6,
      "x": 897,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33204,
      "e": 31788,
      "ty": 2,
      "x": 900,
      "y": 662
    },
    {
      "t": 33254,
      "e": 31838,
      "ty": 41,
      "x": 19898,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33376,
      "e": 31960,
      "ty": 3,
      "x": 900,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33377,
      "e": 31961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 33377,
      "e": 31961,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33378,
      "e": 31962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33439,
      "e": 32023,
      "ty": 4,
      "x": 19898,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33439,
      "e": 32023,
      "ty": 5,
      "x": 900,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34131,
      "e": 32715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 34259,
      "e": 32843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 34260,
      "e": 32844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34332,
      "e": 32916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 34332,
      "e": 32916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34378,
      "e": 32962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 34435,
      "e": 33019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 34547,
      "e": 33131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 34548,
      "e": 33132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34707,
      "e": 33291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 34746,
      "e": 33330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 35391,
      "e": 33975,
      "ty": 7,
      "x": 913,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35404,
      "e": 33988,
      "ty": 2,
      "x": 913,
      "y": 669
    },
    {
      "t": 35408,
      "e": 33992,
      "ty": 6,
      "x": 921,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35504,
      "e": 34088,
      "ty": 2,
      "x": 925,
      "y": 680
    },
    {
      "t": 35504,
      "e": 34088,
      "ty": 41,
      "x": 14986,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35604,
      "e": 34188,
      "ty": 2,
      "x": 941,
      "y": 703
    },
    {
      "t": 35754,
      "e": 34338,
      "ty": 41,
      "x": 23748,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35805,
      "e": 34389,
      "ty": 2,
      "x": 945,
      "y": 700
    },
    {
      "t": 36005,
      "e": 34589,
      "ty": 41,
      "x": 25294,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36071,
      "e": 34655,
      "ty": 3,
      "x": 945,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36073,
      "e": 34657,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 36073,
      "e": 34657,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36074,
      "e": 34658,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36159,
      "e": 34743,
      "ty": 4,
      "x": 25294,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36161,
      "e": 34745,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36162,
      "e": 34746,
      "ty": 5,
      "x": 945,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36163,
      "e": 34747,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 37179,
      "e": 35763,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 38105,
      "e": 36689,
      "ty": 2,
      "x": 912,
      "y": 564
    },
    {
      "t": 38204,
      "e": 36788,
      "ty": 2,
      "x": 884,
      "y": 435
    },
    {
      "t": 38254,
      "e": 36838,
      "ty": 41,
      "x": 14851,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 38304,
      "e": 36888,
      "ty": 2,
      "x": 884,
      "y": 385
    },
    {
      "t": 38404,
      "e": 36988,
      "ty": 2,
      "x": 851,
      "y": 282
    },
    {
      "t": 38505,
      "e": 37089,
      "ty": 2,
      "x": 848,
      "y": 264
    },
    {
      "t": 38506,
      "e": 37090,
      "ty": 41,
      "x": 20242,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 38605,
      "e": 37189,
      "ty": 2,
      "x": 848,
      "y": 253
    },
    {
      "t": 38705,
      "e": 37289,
      "ty": 2,
      "x": 843,
      "y": 245
    },
    {
      "t": 38755,
      "e": 37339,
      "ty": 41,
      "x": 15213,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 38804,
      "e": 37388,
      "ty": 2,
      "x": 840,
      "y": 239
    },
    {
      "t": 38912,
      "e": 37496,
      "ty": 6,
      "x": 839,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 38927,
      "e": 37511,
      "ty": 7,
      "x": 839,
      "y": 250,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 38961,
      "e": 37545,
      "ty": 6,
      "x": 836,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 38977,
      "e": 37561,
      "ty": 7,
      "x": 835,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 38994,
      "e": 37578,
      "ty": 6,
      "x": 834,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 39005,
      "e": 37589,
      "ty": 2,
      "x": 834,
      "y": 288
    },
    {
      "t": 39005,
      "e": 37589,
      "ty": 41,
      "x": 38202,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 39044,
      "e": 37628,
      "ty": 7,
      "x": 831,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 39095,
      "e": 37679,
      "ty": 6,
      "x": 831,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39104,
      "e": 37688,
      "ty": 2,
      "x": 831,
      "y": 323
    },
    {
      "t": 39205,
      "e": 37789,
      "ty": 2,
      "x": 831,
      "y": 327
    },
    {
      "t": 39255,
      "e": 37839,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39404,
      "e": 37988,
      "ty": 2,
      "x": 831,
      "y": 326
    },
    {
      "t": 39505,
      "e": 38089,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39551,
      "e": 38135,
      "ty": 3,
      "x": 831,
      "y": 326,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39552,
      "e": 38136,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39630,
      "e": 38214,
      "ty": 4,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39631,
      "e": 38215,
      "ty": 5,
      "x": 831,
      "y": 326,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39631,
      "e": 38215,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 41456,
      "e": 40040,
      "ty": 7,
      "x": 831,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 41504,
      "e": 40088,
      "ty": 2,
      "x": 832,
      "y": 350
    },
    {
      "t": 41505,
      "e": 40089,
      "ty": 41,
      "x": 2510,
      "y": 14123,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 41604,
      "e": 40188,
      "ty": 2,
      "x": 828,
      "y": 386
    },
    {
      "t": 41704,
      "e": 40288,
      "ty": 2,
      "x": 822,
      "y": 421
    },
    {
      "t": 41754,
      "e": 40338,
      "ty": 41,
      "x": 27928,
      "y": 23710,
      "ta": "html > body"
    },
    {
      "t": 41804,
      "e": 40388,
      "ty": 2,
      "x": 818,
      "y": 443
    },
    {
      "t": 41904,
      "e": 40488,
      "ty": 2,
      "x": 818,
      "y": 456
    },
    {
      "t": 42005,
      "e": 40589,
      "ty": 2,
      "x": 819,
      "y": 469
    },
    {
      "t": 42005,
      "e": 40589,
      "ty": 41,
      "x": 27928,
      "y": 25538,
      "ta": "html > body"
    },
    {
      "t": 42105,
      "e": 40689,
      "ty": 2,
      "x": 824,
      "y": 478
    },
    {
      "t": 42255,
      "e": 40839,
      "ty": 41,
      "x": 2725,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 42404,
      "e": 40988,
      "ty": 2,
      "x": 830,
      "y": 478
    },
    {
      "t": 42431,
      "e": 41015,
      "ty": 6,
      "x": 834,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42504,
      "e": 41088,
      "ty": 2,
      "x": 835,
      "y": 474
    },
    {
      "t": 42505,
      "e": 41089,
      "ty": 41,
      "x": 43243,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42704,
      "e": 41288,
      "ty": 2,
      "x": 836,
      "y": 476
    },
    {
      "t": 42714,
      "e": 41298,
      "ty": 7,
      "x": 836,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42755,
      "e": 41339,
      "ty": 41,
      "x": 14352,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 42805,
      "e": 41389,
      "ty": 2,
      "x": 835,
      "y": 480
    },
    {
      "t": 42904,
      "e": 41488,
      "ty": 2,
      "x": 837,
      "y": 489
    },
    {
      "t": 43008,
      "e": 41491,
      "ty": 41,
      "x": 13982,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 43184,
      "e": 41667,
      "ty": 6,
      "x": 837,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 43204,
      "e": 41687,
      "ty": 2,
      "x": 837,
      "y": 496
    },
    {
      "t": 43255,
      "e": 41738,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 43305,
      "e": 41788,
      "ty": 2,
      "x": 836,
      "y": 497
    },
    {
      "t": 43505,
      "e": 41988,
      "ty": 2,
      "x": 828,
      "y": 497
    },
    {
      "t": 43505,
      "e": 41988,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 43605,
      "e": 42088,
      "ty": 2,
      "x": 827,
      "y": 497
    },
    {
      "t": 43755,
      "e": 42238,
      "ty": 41,
      "x": 2914,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 44605,
      "e": 43088,
      "ty": 2,
      "x": 828,
      "y": 497
    },
    {
      "t": 44705,
      "e": 43188,
      "ty": 2,
      "x": 833,
      "y": 499
    },
    {
      "t": 44755,
      "e": 43238,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45528,
      "e": 44011,
      "ty": 3,
      "x": 833,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45530,
      "e": 44013,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 45531,
      "e": 44014,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45630,
      "e": 44113,
      "ty": 4,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45630,
      "e": 44113,
      "ty": 5,
      "x": 833,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45630,
      "e": 44113,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 45871,
      "e": 44354,
      "ty": 7,
      "x": 833,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45905,
      "e": 44388,
      "ty": 2,
      "x": 824,
      "y": 521
    },
    {
      "t": 46005,
      "e": 44488,
      "ty": 41,
      "x": 27928,
      "y": 28861,
      "ta": "html > body"
    },
    {
      "t": 46005,
      "e": 44488,
      "ty": 2,
      "x": 819,
      "y": 529
    },
    {
      "t": 46105,
      "e": 44588,
      "ty": 2,
      "x": 805,
      "y": 549
    },
    {
      "t": 46204,
      "e": 44687,
      "ty": 2,
      "x": 786,
      "y": 573
    },
    {
      "t": 46255,
      "e": 44738,
      "ty": 41,
      "x": 26758,
      "y": 31410,
      "ta": "html > body"
    },
    {
      "t": 46305,
      "e": 44788,
      "ty": 2,
      "x": 785,
      "y": 575
    },
    {
      "t": 48205,
      "e": 46688,
      "ty": 2,
      "x": 784,
      "y": 575
    },
    {
      "t": 48256,
      "e": 46739,
      "ty": 41,
      "x": 26723,
      "y": 31576,
      "ta": "html > body"
    },
    {
      "t": 48304,
      "e": 46787,
      "ty": 2,
      "x": 783,
      "y": 584
    },
    {
      "t": 48405,
      "e": 46888,
      "ty": 2,
      "x": 783,
      "y": 585
    },
    {
      "t": 48505,
      "e": 46988,
      "ty": 2,
      "x": 783,
      "y": 599
    },
    {
      "t": 48506,
      "e": 46989,
      "ty": 41,
      "x": 26689,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 48605,
      "e": 47088,
      "ty": 2,
      "x": 783,
      "y": 609
    },
    {
      "t": 48705,
      "e": 47188,
      "ty": 2,
      "x": 781,
      "y": 614
    },
    {
      "t": 48755,
      "e": 47238,
      "ty": 41,
      "x": 26620,
      "y": 33792,
      "ta": "html > body"
    },
    {
      "t": 48805,
      "e": 47288,
      "ty": 2,
      "x": 781,
      "y": 625
    },
    {
      "t": 48905,
      "e": 47388,
      "ty": 2,
      "x": 781,
      "y": 644
    },
    {
      "t": 49004,
      "e": 47487,
      "ty": 2,
      "x": 786,
      "y": 670
    },
    {
      "t": 49005,
      "e": 47488,
      "ty": 41,
      "x": 26792,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 49105,
      "e": 47588,
      "ty": 2,
      "x": 789,
      "y": 678
    },
    {
      "t": 49204,
      "e": 47687,
      "ty": 2,
      "x": 795,
      "y": 686
    },
    {
      "t": 49255,
      "e": 47738,
      "ty": 41,
      "x": 27171,
      "y": 37780,
      "ta": "html > body"
    },
    {
      "t": 49305,
      "e": 47788,
      "ty": 2,
      "x": 799,
      "y": 692
    },
    {
      "t": 49405,
      "e": 47888,
      "ty": 2,
      "x": 800,
      "y": 693
    },
    {
      "t": 49505,
      "e": 47988,
      "ty": 41,
      "x": 27274,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 49705,
      "e": 48188,
      "ty": 2,
      "x": 824,
      "y": 696
    },
    {
      "t": 49754,
      "e": 48237,
      "ty": 41,
      "x": 649,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 49887,
      "e": 48370,
      "ty": 6,
      "x": 828,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49905,
      "e": 48388,
      "ty": 2,
      "x": 832,
      "y": 700
    },
    {
      "t": 50005,
      "e": 48488,
      "ty": 2,
      "x": 833,
      "y": 701
    },
    {
      "t": 50005,
      "e": 48488,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50006,
      "e": 48489,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50352,
      "e": 48835,
      "ty": 3,
      "x": 833,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50352,
      "e": 48835,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50353,
      "e": 48836,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50447,
      "e": 48930,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50447,
      "e": 48930,
      "ty": 5,
      "x": 833,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50450,
      "e": 48933,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 53072,
      "e": 51555,
      "ty": 7,
      "x": 835,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 53104,
      "e": 51587,
      "ty": 2,
      "x": 835,
      "y": 716
    },
    {
      "t": 53204,
      "e": 51687,
      "ty": 2,
      "x": 836,
      "y": 719
    },
    {
      "t": 53254,
      "e": 51737,
      "ty": 41,
      "x": 3459,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 53404,
      "e": 51887,
      "ty": 2,
      "x": 836,
      "y": 721
    },
    {
      "t": 53504,
      "e": 51987,
      "ty": 2,
      "x": 836,
      "y": 722
    },
    {
      "t": 53505,
      "e": 51988,
      "ty": 41,
      "x": 3658,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 53704,
      "e": 52187,
      "ty": 2,
      "x": 835,
      "y": 723
    },
    {
      "t": 53706,
      "e": 52189,
      "ty": 6,
      "x": 835,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 53755,
      "e": 52238,
      "ty": 41,
      "x": 38202,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 53804,
      "e": 52287,
      "ty": 2,
      "x": 833,
      "y": 725
    },
    {
      "t": 53904,
      "e": 52387,
      "ty": 2,
      "x": 830,
      "y": 727
    },
    {
      "t": 54004,
      "e": 52487,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54136,
      "e": 52619,
      "ty": 3,
      "x": 830,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54137,
      "e": 52620,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 54137,
      "e": 52620,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54222,
      "e": 52705,
      "ty": 4,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54224,
      "e": 52707,
      "ty": 5,
      "x": 830,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54224,
      "e": 52707,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 57176,
      "e": 55659,
      "ty": 7,
      "x": 821,
      "y": 775,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57204,
      "e": 55687,
      "ty": 2,
      "x": 817,
      "y": 804
    },
    {
      "t": 57254,
      "e": 55737,
      "ty": 41,
      "x": 27653,
      "y": 46422,
      "ta": "html > body"
    },
    {
      "t": 57304,
      "e": 55787,
      "ty": 2,
      "x": 808,
      "y": 857
    },
    {
      "t": 57404,
      "e": 55887,
      "ty": 2,
      "x": 805,
      "y": 871
    },
    {
      "t": 57505,
      "e": 55988,
      "ty": 2,
      "x": 809,
      "y": 897
    },
    {
      "t": 57505,
      "e": 55988,
      "ty": 41,
      "x": 27584,
      "y": 49248,
      "ta": "html > body"
    },
    {
      "t": 57604,
      "e": 56087,
      "ty": 2,
      "x": 819,
      "y": 929
    },
    {
      "t": 57704,
      "e": 56187,
      "ty": 2,
      "x": 824,
      "y": 939
    },
    {
      "t": 57754,
      "e": 56237,
      "ty": 41,
      "x": 849,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 57804,
      "e": 56287,
      "ty": 2,
      "x": 826,
      "y": 951
    },
    {
      "t": 57943,
      "e": 56426,
      "ty": 6,
      "x": 828,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58004,
      "e": 56487,
      "ty": 2,
      "x": 828,
      "y": 961
    },
    {
      "t": 58005,
      "e": 56488,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58104,
      "e": 56587,
      "ty": 3,
      "x": 829,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58105,
      "e": 56588,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 58105,
      "e": 56588,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58108,
      "e": 56591,
      "ty": 2,
      "x": 829,
      "y": 962
    },
    {
      "t": 58215,
      "e": 56698,
      "ty": 4,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58215,
      "e": 56698,
      "ty": 5,
      "x": 829,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58215,
      "e": 56698,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 58254,
      "e": 56737,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58327,
      "e": 56810,
      "ty": 7,
      "x": 832,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58361,
      "e": 56844,
      "ty": 6,
      "x": 838,
      "y": 988,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 58404,
      "e": 56887,
      "ty": 2,
      "x": 839,
      "y": 994
    },
    {
      "t": 58414,
      "e": 56897,
      "ty": 7,
      "x": 840,
      "y": 995,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 58494,
      "e": 56977,
      "ty": 6,
      "x": 843,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58504,
      "e": 56987,
      "ty": 2,
      "x": 843,
      "y": 1008
    },
    {
      "t": 58504,
      "e": 56987,
      "ty": 41,
      "x": 6998,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58604,
      "e": 57087,
      "ty": 2,
      "x": 845,
      "y": 1011
    },
    {
      "t": 58704,
      "e": 57187,
      "ty": 2,
      "x": 846,
      "y": 1015
    },
    {
      "t": 58755,
      "e": 57238,
      "ty": 41,
      "x": 8544,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58823,
      "e": 57306,
      "ty": 3,
      "x": 846,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58826,
      "e": 57309,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58826,
      "e": 57309,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58911,
      "e": 57394,
      "ty": 4,
      "x": 8544,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58911,
      "e": 57394,
      "ty": 5,
      "x": 846,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58913,
      "e": 57396,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58914,
      "e": 57397,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58915,
      "e": 57398,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 60004,
      "e": 58487,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60269,
      "e": 58755,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 61005,
      "e": 59491,
      "ty": 2,
      "x": 875,
      "y": 1075
    },
    {
      "t": 61005,
      "e": 59491,
      "ty": 41,
      "x": 29857,
      "y": 59108,
      "ta": "> div.masterdiv"
    },
    {
      "t": 61205,
      "e": 59691,
      "ty": 2,
      "x": 895,
      "y": 1087
    },
    {
      "t": 61247,
      "e": 59733,
      "ty": 6,
      "x": 917,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 61254,
      "e": 59740,
      "ty": 41,
      "x": 4095,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 61304,
      "e": 59790,
      "ty": 2,
      "x": 920,
      "y": 1086
    },
    {
      "t": 61405,
      "e": 59891,
      "ty": 2,
      "x": 928,
      "y": 1087
    },
    {
      "t": 61505,
      "e": 59991,
      "ty": 2,
      "x": 944,
      "y": 1088
    },
    {
      "t": 61505,
      "e": 59991,
      "ty": 41,
      "x": 18841,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 70009,
      "e": 64991,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 78076,
      "e": 64991,
      "ty": 3,
      "x": 944,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 78076,
      "e": 64991,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78194,
      "e": 65109,
      "ty": 4,
      "x": 18841,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 78194,
      "e": 65109,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78194,
      "e": 65109,
      "ty": 5,
      "x": 944,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 78195,
      "e": 65110,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 79236,
      "e": 66151,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 80679,
      "e": 67594,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 208075, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 208083, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3326, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 212747, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7252, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 221002, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14773, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 236867, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12930, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 250800, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 27718, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 279909, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-08 AM-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:994,y:1093,t:1527188730013};\\\", \\\"{x:1000,y:1083,t:1527188730025};\\\", \\\"{x:1008,y:1076,t:1527188730034};\\\", \\\"{x:1018,y:1067,t:1527188730049};\\\", \\\"{x:1027,y:1061,t:1527188730067};\\\", \\\"{x:1029,y:1059,t:1527188730084};\\\", \\\"{x:1031,y:1057,t:1527188730139};\\\", \\\"{x:1033,y:1056,t:1527188730149};\\\", \\\"{x:1038,y:1050,t:1527188730167};\\\", \\\"{x:1041,y:1047,t:1527188730183};\\\", \\\"{x:1042,y:1044,t:1527188730200};\\\", \\\"{x:1044,y:1042,t:1527188730216};\\\", \\\"{x:1045,y:1039,t:1527188730234};\\\", \\\"{x:1046,y:1037,t:1527188730397};\\\", \\\"{x:1047,y:1035,t:1527188730428};\\\", \\\"{x:1048,y:1034,t:1527188730452};\\\", \\\"{x:1048,y:1032,t:1527188730476};\\\", \\\"{x:1049,y:1032,t:1527188730485};\\\", \\\"{x:1051,y:1029,t:1527188730501};\\\", \\\"{x:1054,y:1024,t:1527188730518};\\\", \\\"{x:1058,y:1021,t:1527188730534};\\\", \\\"{x:1060,y:1018,t:1527188730552};\\\", \\\"{x:1062,y:1016,t:1527188730567};\\\", \\\"{x:1063,y:1014,t:1527188730584};\\\", \\\"{x:1063,y:1012,t:1527188730604};\\\", \\\"{x:1064,y:1012,t:1527188730618};\\\", \\\"{x:1069,y:1007,t:1527188730635};\\\", \\\"{x:1072,y:1002,t:1527188730651};\\\", \\\"{x:1078,y:995,t:1527188730667};\\\", \\\"{x:1081,y:991,t:1527188730686};\\\", \\\"{x:1081,y:990,t:1527188730701};\\\", \\\"{x:1083,y:987,t:1527188730779};\\\", \\\"{x:1084,y:987,t:1527188730787};\\\", \\\"{x:1085,y:985,t:1527188730801};\\\", \\\"{x:1085,y:983,t:1527188730818};\\\", \\\"{x:1086,y:983,t:1527188730834};\\\", \\\"{x:1087,y:982,t:1527188730850};\\\", \\\"{x:1092,y:982,t:1527188730867};\\\", \\\"{x:1096,y:982,t:1527188730884};\\\", \\\"{x:1099,y:982,t:1527188730901};\\\", \\\"{x:1101,y:982,t:1527188730933};\\\", \\\"{x:1102,y:982,t:1527188730957};\\\", \\\"{x:1101,y:981,t:1527188731324};\\\", \\\"{x:1101,y:980,t:1527188731335};\\\", \\\"{x:1095,y:979,t:1527188731351};\\\", \\\"{x:1093,y:978,t:1527188731369};\\\", \\\"{x:1089,y:976,t:1527188731385};\\\", \\\"{x:1091,y:976,t:1527188735237};\\\", \\\"{x:1109,y:975,t:1527188735256};\\\", \\\"{x:1119,y:975,t:1527188735271};\\\", \\\"{x:1125,y:973,t:1527188735288};\\\", \\\"{x:1126,y:973,t:1527188735305};\\\", \\\"{x:1130,y:973,t:1527188735363};\\\", \\\"{x:1132,y:973,t:1527188735370};\\\", \\\"{x:1138,y:973,t:1527188735386};\\\", \\\"{x:1141,y:973,t:1527188735403};\\\", \\\"{x:1142,y:973,t:1527188735421};\\\", \\\"{x:1144,y:973,t:1527188735443};\\\", \\\"{x:1146,y:972,t:1527188735466};\\\", \\\"{x:1149,y:970,t:1527188735475};\\\", \\\"{x:1152,y:968,t:1527188735487};\\\", \\\"{x:1158,y:967,t:1527188735504};\\\", \\\"{x:1163,y:965,t:1527188735520};\\\", \\\"{x:1175,y:965,t:1527188735537};\\\", \\\"{x:1183,y:963,t:1527188735553};\\\", \\\"{x:1190,y:963,t:1527188735571};\\\", \\\"{x:1194,y:961,t:1527188735588};\\\", \\\"{x:1203,y:961,t:1527188735604};\\\", \\\"{x:1214,y:961,t:1527188735621};\\\", \\\"{x:1217,y:961,t:1527188735637};\\\", \\\"{x:1227,y:961,t:1527188735654};\\\", \\\"{x:1238,y:961,t:1527188735671};\\\", \\\"{x:1242,y:961,t:1527188735687};\\\", \\\"{x:1247,y:961,t:1527188735704};\\\", \\\"{x:1249,y:961,t:1527188735722};\\\", \\\"{x:1253,y:961,t:1527188735738};\\\", \\\"{x:1257,y:961,t:1527188735754};\\\", \\\"{x:1260,y:961,t:1527188735771};\\\", \\\"{x:1262,y:961,t:1527188735787};\\\", \\\"{x:1266,y:961,t:1527188735804};\\\", \\\"{x:1273,y:964,t:1527188735821};\\\", \\\"{x:1280,y:965,t:1527188735838};\\\", \\\"{x:1287,y:965,t:1527188735854};\\\", \\\"{x:1289,y:965,t:1527188735871};\\\", \\\"{x:1290,y:965,t:1527188735924};\\\", \\\"{x:1291,y:966,t:1527188735938};\\\", \\\"{x:1292,y:967,t:1527188735955};\\\", \\\"{x:1293,y:967,t:1527188735980};\\\", \\\"{x:1292,y:967,t:1527188736092};\\\", \\\"{x:1290,y:966,t:1527188736104};\\\", \\\"{x:1287,y:965,t:1527188736122};\\\", \\\"{x:1286,y:965,t:1527188736139};\\\", \\\"{x:1284,y:963,t:1527188744588};\\\", \\\"{x:1284,y:962,t:1527188745324};\\\", \\\"{x:1281,y:958,t:1527188745532};\\\", \\\"{x:1271,y:954,t:1527188745545};\\\", \\\"{x:1246,y:943,t:1527188745562};\\\", \\\"{x:1206,y:929,t:1527188745579};\\\", \\\"{x:1185,y:900,t:1527188745595};\\\", \\\"{x:1090,y:834,t:1527188745612};\\\", \\\"{x:1052,y:800,t:1527188745629};\\\", \\\"{x:1015,y:775,t:1527188745645};\\\", \\\"{x:1002,y:757,t:1527188745661};\\\", \\\"{x:984,y:739,t:1527188745678};\\\", \\\"{x:965,y:721,t:1527188745695};\\\", \\\"{x:949,y:707,t:1527188745711};\\\", \\\"{x:930,y:691,t:1527188745728};\\\", \\\"{x:907,y:676,t:1527188745745};\\\", \\\"{x:876,y:668,t:1527188745761};\\\", \\\"{x:844,y:655,t:1527188745778};\\\", \\\"{x:779,y:642,t:1527188745794};\\\", \\\"{x:739,y:635,t:1527188745810};\\\", \\\"{x:696,y:628,t:1527188745828};\\\", \\\"{x:653,y:621,t:1527188745845};\\\", \\\"{x:620,y:614,t:1527188745863};\\\", \\\"{x:584,y:614,t:1527188745880};\\\", \\\"{x:544,y:606,t:1527188745897};\\\", \\\"{x:494,y:600,t:1527188745914};\\\", \\\"{x:457,y:595,t:1527188745930};\\\", \\\"{x:427,y:592,t:1527188745946};\\\", \\\"{x:386,y:582,t:1527188745963};\\\", \\\"{x:364,y:578,t:1527188745980};\\\", \\\"{x:339,y:575,t:1527188745997};\\\", \\\"{x:320,y:571,t:1527188746014};\\\", \\\"{x:301,y:567,t:1527188746030};\\\", \\\"{x:295,y:565,t:1527188746047};\\\", \\\"{x:294,y:565,t:1527188746063};\\\", \\\"{x:292,y:563,t:1527188746091};\\\", \\\"{x:288,y:561,t:1527188746099};\\\", \\\"{x:279,y:557,t:1527188746114};\\\", \\\"{x:248,y:555,t:1527188746132};\\\", \\\"{x:205,y:545,t:1527188746146};\\\", \\\"{x:190,y:545,t:1527188746163};\\\", \\\"{x:189,y:545,t:1527188746180};\\\", \\\"{x:188,y:544,t:1527188746203};\\\", \\\"{x:188,y:542,t:1527188746213};\\\", \\\"{x:192,y:538,t:1527188746230};\\\", \\\"{x:210,y:528,t:1527188746247};\\\", \\\"{x:214,y:524,t:1527188746264};\\\", \\\"{x:219,y:524,t:1527188746280};\\\", \\\"{x:226,y:524,t:1527188746297};\\\", \\\"{x:228,y:526,t:1527188746314};\\\", \\\"{x:235,y:529,t:1527188746330};\\\", \\\"{x:255,y:538,t:1527188746347};\\\", \\\"{x:268,y:542,t:1527188746363};\\\", \\\"{x:287,y:545,t:1527188746380};\\\", \\\"{x:307,y:549,t:1527188746398};\\\", \\\"{x:320,y:549,t:1527188746414};\\\", \\\"{x:323,y:549,t:1527188746431};\\\", \\\"{x:324,y:549,t:1527188746447};\\\", \\\"{x:327,y:549,t:1527188746500};\\\", \\\"{x:331,y:547,t:1527188746515};\\\", \\\"{x:334,y:540,t:1527188746532};\\\", \\\"{x:348,y:529,t:1527188746548};\\\", \\\"{x:355,y:524,t:1527188746565};\\\", \\\"{x:356,y:523,t:1527188746580};\\\", \\\"{x:356,y:521,t:1527188746659};\\\", \\\"{x:357,y:518,t:1527188746667};\\\", \\\"{x:358,y:514,t:1527188746681};\\\", \\\"{x:362,y:509,t:1527188746697};\\\", \\\"{x:362,y:507,t:1527188746714};\\\", \\\"{x:363,y:506,t:1527188746731};\\\", \\\"{x:364,y:506,t:1527188746779};\\\", \\\"{x:365,y:506,t:1527188746794};\\\", \\\"{x:366,y:506,t:1527188746827};\\\", \\\"{x:368,y:506,t:1527188746835};\\\", \\\"{x:368,y:507,t:1527188746867};\\\", \\\"{x:369,y:507,t:1527188746881};\\\", \\\"{x:370,y:508,t:1527188746899};\\\", \\\"{x:371,y:510,t:1527188746914};\\\", \\\"{x:371,y:511,t:1527188746930};\\\", \\\"{x:374,y:515,t:1527188746947};\\\", \\\"{x:376,y:516,t:1527188746964};\\\", \\\"{x:377,y:517,t:1527188747027};\\\", \\\"{x:379,y:519,t:1527188747043};\\\", \\\"{x:379,y:520,t:1527188747051};\\\", \\\"{x:380,y:520,t:1527188747065};\\\", \\\"{x:381,y:521,t:1527188747081};\\\", \\\"{x:384,y:527,t:1527188747467};\\\", \\\"{x:392,y:544,t:1527188747483};\\\", \\\"{x:410,y:569,t:1527188747498};\\\", \\\"{x:424,y:592,t:1527188747515};\\\", \\\"{x:432,y:608,t:1527188747531};\\\", \\\"{x:437,y:616,t:1527188747548};\\\", \\\"{x:439,y:627,t:1527188747565};\\\", \\\"{x:444,y:638,t:1527188747581};\\\", \\\"{x:448,y:648,t:1527188747598};\\\", \\\"{x:455,y:660,t:1527188747616};\\\", \\\"{x:461,y:672,t:1527188747631};\\\", \\\"{x:467,y:681,t:1527188747648};\\\", \\\"{x:467,y:682,t:1527188747664};\\\", \\\"{x:470,y:686,t:1527188747681};\\\", \\\"{x:473,y:690,t:1527188747698};\\\", \\\"{x:477,y:695,t:1527188747714};\\\", \\\"{x:483,y:703,t:1527188747732};\\\", \\\"{x:486,y:706,t:1527188747748};\\\", \\\"{x:487,y:707,t:1527188747771};\\\", \\\"{x:487,y:708,t:1527188747844};\\\", \\\"{x:489,y:710,t:1527188747900};\\\", \\\"{x:490,y:714,t:1527188747916};\\\", \\\"{x:492,y:715,t:1527188747932};\\\", \\\"{x:493,y:716,t:1527188753556};\\\", \\\"{x:493,y:720,t:1527188753570};\\\", \\\"{x:496,y:722,t:1527188753587};\\\" ] }, { \\\"rt\\\": 51745, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 332932, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -E -D -D -B -B -5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:723,t:1527188763124};\\\", \\\"{x:506,y:724,t:1527188763131};\\\", \\\"{x:544,y:712,t:1527188763145};\\\", \\\"{x:645,y:675,t:1527188763164};\\\", \\\"{x:783,y:640,t:1527188763179};\\\", \\\"{x:821,y:627,t:1527188763195};\\\", \\\"{x:845,y:613,t:1527188763211};\\\", \\\"{x:886,y:588,t:1527188763227};\\\", \\\"{x:978,y:572,t:1527188763244};\\\", \\\"{x:1079,y:548,t:1527188763260};\\\", \\\"{x:1177,y:519,t:1527188763277};\\\", \\\"{x:1275,y:497,t:1527188763293};\\\", \\\"{x:1361,y:474,t:1527188763311};\\\", \\\"{x:1434,y:449,t:1527188763328};\\\", \\\"{x:1453,y:436,t:1527188763343};\\\", \\\"{x:1481,y:428,t:1527188763361};\\\", \\\"{x:1499,y:426,t:1527188763377};\\\", \\\"{x:1501,y:425,t:1527188763394};\\\", \\\"{x:1502,y:425,t:1527188763418};\\\", \\\"{x:1509,y:425,t:1527188763428};\\\", \\\"{x:1536,y:436,t:1527188763444};\\\", \\\"{x:1557,y:445,t:1527188763461};\\\", \\\"{x:1580,y:450,t:1527188763478};\\\", \\\"{x:1591,y:450,t:1527188763494};\\\", \\\"{x:1595,y:450,t:1527188763511};\\\", \\\"{x:1596,y:450,t:1527188763603};\\\", \\\"{x:1597,y:450,t:1527188763611};\\\", \\\"{x:1599,y:450,t:1527188763628};\\\", \\\"{x:1602,y:449,t:1527188763645};\\\", \\\"{x:1603,y:447,t:1527188763661};\\\", \\\"{x:1605,y:444,t:1527188763677};\\\", \\\"{x:1607,y:441,t:1527188763694};\\\", \\\"{x:1607,y:440,t:1527188763710};\\\", \\\"{x:1607,y:438,t:1527188763738};\\\", \\\"{x:1608,y:436,t:1527188763746};\\\", \\\"{x:1609,y:436,t:1527188763786};\\\", \\\"{x:1611,y:435,t:1527188763826};\\\", \\\"{x:1611,y:434,t:1527188763843};\\\", \\\"{x:1612,y:432,t:1527188763867};\\\", \\\"{x:1613,y:429,t:1527188765291};\\\", \\\"{x:1613,y:431,t:1527188766067};\\\", \\\"{x:1613,y:437,t:1527188766082};\\\", \\\"{x:1613,y:440,t:1527188766096};\\\", \\\"{x:1613,y:441,t:1527188766113};\\\", \\\"{x:1614,y:442,t:1527188766130};\\\", \\\"{x:1615,y:445,t:1527188766155};\\\", \\\"{x:1615,y:447,t:1527188766179};\\\", \\\"{x:1615,y:451,t:1527188766197};\\\", \\\"{x:1616,y:452,t:1527188766214};\\\", \\\"{x:1616,y:454,t:1527188766230};\\\", \\\"{x:1616,y:455,t:1527188766252};\\\", \\\"{x:1616,y:457,t:1527188766267};\\\", \\\"{x:1616,y:458,t:1527188766281};\\\", \\\"{x:1616,y:462,t:1527188766298};\\\", \\\"{x:1616,y:469,t:1527188766313};\\\", \\\"{x:1616,y:479,t:1527188766330};\\\", \\\"{x:1615,y:486,t:1527188766347};\\\", \\\"{x:1615,y:493,t:1527188766364};\\\", \\\"{x:1614,y:497,t:1527188766381};\\\", \\\"{x:1612,y:504,t:1527188766398};\\\", \\\"{x:1611,y:512,t:1527188766414};\\\", \\\"{x:1610,y:519,t:1527188766431};\\\", \\\"{x:1610,y:525,t:1527188766447};\\\", \\\"{x:1610,y:529,t:1527188766463};\\\", \\\"{x:1606,y:534,t:1527188766481};\\\", \\\"{x:1606,y:538,t:1527188766498};\\\", \\\"{x:1606,y:541,t:1527188766514};\\\", \\\"{x:1606,y:543,t:1527188766531};\\\", \\\"{x:1606,y:544,t:1527188766547};\\\", \\\"{x:1606,y:545,t:1527188766564};\\\", \\\"{x:1606,y:547,t:1527188766588};\\\", \\\"{x:1606,y:549,t:1527188766603};\\\", \\\"{x:1606,y:550,t:1527188766627};\\\", \\\"{x:1606,y:552,t:1527188766651};\\\", \\\"{x:1606,y:553,t:1527188766756};\\\", \\\"{x:1607,y:556,t:1527188766765};\\\", \\\"{x:1608,y:559,t:1527188766781};\\\", \\\"{x:1609,y:562,t:1527188766798};\\\", \\\"{x:1613,y:567,t:1527188766814};\\\", \\\"{x:1614,y:572,t:1527188766832};\\\", \\\"{x:1618,y:578,t:1527188766847};\\\", \\\"{x:1620,y:583,t:1527188766864};\\\", \\\"{x:1620,y:585,t:1527188766880};\\\", \\\"{x:1621,y:586,t:1527188766897};\\\", \\\"{x:1621,y:588,t:1527188766914};\\\", \\\"{x:1622,y:588,t:1527188766930};\\\", \\\"{x:1624,y:590,t:1527188766979};\\\", \\\"{x:1625,y:591,t:1527188766987};\\\", \\\"{x:1625,y:593,t:1527188766997};\\\", \\\"{x:1625,y:598,t:1527188767014};\\\", \\\"{x:1626,y:603,t:1527188767030};\\\", \\\"{x:1627,y:605,t:1527188767047};\\\", \\\"{x:1628,y:608,t:1527188767116};\\\", \\\"{x:1628,y:613,t:1527188767131};\\\", \\\"{x:1628,y:621,t:1527188767147};\\\", \\\"{x:1628,y:629,t:1527188767164};\\\", \\\"{x:1626,y:635,t:1527188767182};\\\", \\\"{x:1626,y:636,t:1527188767203};\\\", \\\"{x:1626,y:637,t:1527188767243};\\\", \\\"{x:1625,y:639,t:1527188767260};\\\", \\\"{x:1625,y:642,t:1527188767267};\\\", \\\"{x:1625,y:644,t:1527188767283};\\\", \\\"{x:1625,y:646,t:1527188767298};\\\", \\\"{x:1624,y:648,t:1527188767315};\\\", \\\"{x:1623,y:652,t:1527188767331};\\\", \\\"{x:1623,y:653,t:1527188767348};\\\", \\\"{x:1623,y:654,t:1527188767388};\\\", \\\"{x:1623,y:655,t:1527188767404};\\\", \\\"{x:1623,y:656,t:1527188767415};\\\", \\\"{x:1623,y:659,t:1527188767432};\\\", \\\"{x:1623,y:663,t:1527188767448};\\\", \\\"{x:1623,y:666,t:1527188767465};\\\", \\\"{x:1623,y:667,t:1527188767492};\\\", \\\"{x:1623,y:668,t:1527188767515};\\\", \\\"{x:1623,y:669,t:1527188767532};\\\", \\\"{x:1623,y:670,t:1527188767549};\\\", \\\"{x:1623,y:671,t:1527188767564};\\\", \\\"{x:1623,y:673,t:1527188767582};\\\", \\\"{x:1623,y:675,t:1527188767599};\\\", \\\"{x:1623,y:678,t:1527188767615};\\\", \\\"{x:1623,y:679,t:1527188767635};\\\", \\\"{x:1623,y:680,t:1527188767649};\\\", \\\"{x:1624,y:682,t:1527188767665};\\\", \\\"{x:1625,y:687,t:1527188767682};\\\", \\\"{x:1625,y:690,t:1527188767698};\\\", \\\"{x:1625,y:694,t:1527188767715};\\\", \\\"{x:1625,y:696,t:1527188767732};\\\", \\\"{x:1625,y:697,t:1527188767749};\\\", \\\"{x:1625,y:698,t:1527188767764};\\\", \\\"{x:1625,y:700,t:1527188767781};\\\", \\\"{x:1625,y:701,t:1527188767798};\\\", \\\"{x:1624,y:705,t:1527188767815};\\\", \\\"{x:1623,y:708,t:1527188767832};\\\", \\\"{x:1623,y:711,t:1527188767849};\\\", \\\"{x:1622,y:714,t:1527188767864};\\\", \\\"{x:1621,y:719,t:1527188767881};\\\", \\\"{x:1620,y:723,t:1527188767899};\\\", \\\"{x:1619,y:727,t:1527188767916};\\\", \\\"{x:1618,y:728,t:1527188767931};\\\", \\\"{x:1618,y:729,t:1527188767949};\\\", \\\"{x:1615,y:732,t:1527188767966};\\\", \\\"{x:1614,y:735,t:1527188767982};\\\", \\\"{x:1612,y:739,t:1527188767999};\\\", \\\"{x:1612,y:742,t:1527188768016};\\\", \\\"{x:1610,y:743,t:1527188768031};\\\", \\\"{x:1610,y:744,t:1527188768049};\\\", \\\"{x:1609,y:746,t:1527188768065};\\\", \\\"{x:1609,y:748,t:1527188768092};\\\", \\\"{x:1609,y:750,t:1527188768099};\\\", \\\"{x:1609,y:753,t:1527188768115};\\\", \\\"{x:1609,y:758,t:1527188768132};\\\", \\\"{x:1609,y:762,t:1527188768148};\\\", \\\"{x:1609,y:764,t:1527188768165};\\\", \\\"{x:1609,y:765,t:1527188768182};\\\", \\\"{x:1609,y:768,t:1527188768199};\\\", \\\"{x:1609,y:772,t:1527188768215};\\\", \\\"{x:1609,y:774,t:1527188768232};\\\", \\\"{x:1609,y:776,t:1527188768249};\\\", \\\"{x:1609,y:778,t:1527188768266};\\\", \\\"{x:1610,y:779,t:1527188768291};\\\", \\\"{x:1611,y:782,t:1527188768307};\\\", \\\"{x:1612,y:782,t:1527188768316};\\\", \\\"{x:1612,y:785,t:1527188768331};\\\", \\\"{x:1615,y:791,t:1527188768348};\\\", \\\"{x:1615,y:793,t:1527188768366};\\\", \\\"{x:1615,y:795,t:1527188768383};\\\", \\\"{x:1616,y:796,t:1527188768411};\\\", \\\"{x:1616,y:798,t:1527188768435};\\\", \\\"{x:1616,y:799,t:1527188768448};\\\", \\\"{x:1618,y:803,t:1527188768465};\\\", \\\"{x:1619,y:809,t:1527188768482};\\\", \\\"{x:1620,y:811,t:1527188768498};\\\", \\\"{x:1620,y:814,t:1527188768515};\\\", \\\"{x:1622,y:816,t:1527188768532};\\\", \\\"{x:1622,y:819,t:1527188768548};\\\", \\\"{x:1622,y:821,t:1527188768565};\\\", \\\"{x:1622,y:823,t:1527188768583};\\\", \\\"{x:1622,y:826,t:1527188768598};\\\", \\\"{x:1622,y:830,t:1527188768615};\\\", \\\"{x:1621,y:840,t:1527188768633};\\\", \\\"{x:1618,y:848,t:1527188768649};\\\", \\\"{x:1617,y:855,t:1527188768665};\\\", \\\"{x:1617,y:858,t:1527188768683};\\\", \\\"{x:1617,y:859,t:1527188768699};\\\", \\\"{x:1616,y:860,t:1527188768715};\\\", \\\"{x:1615,y:862,t:1527188768732};\\\", \\\"{x:1615,y:863,t:1527188768762};\\\", \\\"{x:1614,y:865,t:1527188768770};\\\", \\\"{x:1614,y:867,t:1527188768803};\\\", \\\"{x:1614,y:869,t:1527188768818};\\\", \\\"{x:1613,y:869,t:1527188768832};\\\", \\\"{x:1613,y:871,t:1527188768850};\\\", \\\"{x:1613,y:873,t:1527188768865};\\\", \\\"{x:1613,y:874,t:1527188768882};\\\", \\\"{x:1613,y:877,t:1527188768898};\\\", \\\"{x:1613,y:881,t:1527188768915};\\\", \\\"{x:1613,y:884,t:1527188768933};\\\", \\\"{x:1613,y:888,t:1527188768950};\\\", \\\"{x:1611,y:893,t:1527188768965};\\\", \\\"{x:1610,y:897,t:1527188768982};\\\", \\\"{x:1610,y:901,t:1527188769000};\\\", \\\"{x:1610,y:907,t:1527188769015};\\\", \\\"{x:1610,y:910,t:1527188769033};\\\", \\\"{x:1610,y:913,t:1527188769050};\\\", \\\"{x:1610,y:916,t:1527188769065};\\\", \\\"{x:1611,y:918,t:1527188769082};\\\", \\\"{x:1615,y:923,t:1527188769098};\\\", \\\"{x:1617,y:929,t:1527188769116};\\\", \\\"{x:1619,y:933,t:1527188769132};\\\", \\\"{x:1621,y:937,t:1527188769149};\\\", \\\"{x:1623,y:941,t:1527188769165};\\\", \\\"{x:1625,y:942,t:1527188769183};\\\", \\\"{x:1627,y:945,t:1527188769200};\\\", \\\"{x:1628,y:945,t:1527188769215};\\\", \\\"{x:1629,y:946,t:1527188769232};\\\", \\\"{x:1630,y:947,t:1527188769259};\\\", \\\"{x:1630,y:948,t:1527188769284};\\\", \\\"{x:1630,y:949,t:1527188769307};\\\", \\\"{x:1630,y:950,t:1527188769316};\\\", \\\"{x:1630,y:951,t:1527188769403};\\\", \\\"{x:1630,y:953,t:1527188769427};\\\", \\\"{x:1629,y:953,t:1527188769443};\\\", \\\"{x:1628,y:954,t:1527188769459};\\\", \\\"{x:1627,y:954,t:1527188769476};\\\", \\\"{x:1627,y:956,t:1527188769508};\\\", \\\"{x:1627,y:957,t:1527188769564};\\\", \\\"{x:1626,y:958,t:1527188769571};\\\", \\\"{x:1625,y:960,t:1527188769583};\\\", \\\"{x:1624,y:961,t:1527188769600};\\\", \\\"{x:1623,y:961,t:1527188769619};\\\", \\\"{x:1621,y:961,t:1527188769676};\\\", \\\"{x:1620,y:962,t:1527188770779};\\\", \\\"{x:1619,y:963,t:1527188771092};\\\", \\\"{x:1616,y:962,t:1527188771107};\\\", \\\"{x:1614,y:958,t:1527188771118};\\\", \\\"{x:1606,y:947,t:1527188771135};\\\", \\\"{x:1599,y:921,t:1527188771151};\\\", \\\"{x:1598,y:862,t:1527188771168};\\\", \\\"{x:1594,y:775,t:1527188771185};\\\", \\\"{x:1588,y:685,t:1527188771201};\\\", \\\"{x:1585,y:595,t:1527188771218};\\\", \\\"{x:1583,y:508,t:1527188771235};\\\", \\\"{x:1583,y:482,t:1527188771251};\\\", \\\"{x:1589,y:464,t:1527188771267};\\\", \\\"{x:1591,y:445,t:1527188771284};\\\", \\\"{x:1592,y:428,t:1527188771300};\\\", \\\"{x:1592,y:414,t:1527188771318};\\\", \\\"{x:1594,y:404,t:1527188771335};\\\", \\\"{x:1594,y:401,t:1527188771351};\\\", \\\"{x:1594,y:397,t:1527188771368};\\\", \\\"{x:1594,y:402,t:1527188771452};\\\", \\\"{x:1597,y:411,t:1527188771467};\\\", \\\"{x:1606,y:436,t:1527188771485};\\\", \\\"{x:1606,y:456,t:1527188771502};\\\", \\\"{x:1606,y:467,t:1527188771518};\\\", \\\"{x:1607,y:472,t:1527188771535};\\\", \\\"{x:1608,y:471,t:1527188771588};\\\", \\\"{x:1608,y:465,t:1527188771601};\\\", \\\"{x:1608,y:462,t:1527188771618};\\\", \\\"{x:1608,y:457,t:1527188771635};\\\", \\\"{x:1608,y:450,t:1527188771651};\\\", \\\"{x:1609,y:448,t:1527188771668};\\\", \\\"{x:1609,y:446,t:1527188771685};\\\", \\\"{x:1610,y:446,t:1527188771715};\\\", \\\"{x:1613,y:442,t:1527188771723};\\\", \\\"{x:1614,y:441,t:1527188771740};\\\", \\\"{x:1614,y:440,t:1527188771755};\\\", \\\"{x:1614,y:439,t:1527188771891};\\\", \\\"{x:1614,y:437,t:1527188771901};\\\", \\\"{x:1614,y:436,t:1527188771919};\\\", \\\"{x:1614,y:434,t:1527188772036};\\\", \\\"{x:1614,y:432,t:1527188772068};\\\", \\\"{x:1614,y:431,t:1527188772085};\\\", \\\"{x:1614,y:430,t:1527188772202};\\\", \\\"{x:1614,y:435,t:1527188773676};\\\", \\\"{x:1613,y:435,t:1527188773685};\\\", \\\"{x:1613,y:437,t:1527188773697};\\\", \\\"{x:1613,y:438,t:1527188773712};\\\", \\\"{x:1614,y:438,t:1527188774117};\\\", \\\"{x:1615,y:438,t:1527188774129};\\\", \\\"{x:1615,y:437,t:1527188774145};\\\", \\\"{x:1616,y:437,t:1527188774188};\\\", \\\"{x:1616,y:436,t:1527188774292};\\\", \\\"{x:1616,y:435,t:1527188774300};\\\", \\\"{x:1616,y:434,t:1527188774328};\\\", \\\"{x:1618,y:450,t:1527188777589};\\\", \\\"{x:1636,y:495,t:1527188777598};\\\", \\\"{x:1667,y:582,t:1527188777615};\\\", \\\"{x:1678,y:636,t:1527188777631};\\\", \\\"{x:1685,y:668,t:1527188777649};\\\", \\\"{x:1694,y:690,t:1527188777665};\\\", \\\"{x:1698,y:710,t:1527188777682};\\\", \\\"{x:1701,y:723,t:1527188777698};\\\", \\\"{x:1702,y:739,t:1527188777715};\\\", \\\"{x:1703,y:751,t:1527188777732};\\\", \\\"{x:1703,y:755,t:1527188777749};\\\", \\\"{x:1706,y:760,t:1527188777765};\\\", \\\"{x:1706,y:768,t:1527188777782};\\\", \\\"{x:1710,y:777,t:1527188777799};\\\", \\\"{x:1711,y:795,t:1527188777815};\\\", \\\"{x:1711,y:814,t:1527188777832};\\\", \\\"{x:1707,y:842,t:1527188777849};\\\", \\\"{x:1702,y:881,t:1527188777864};\\\", \\\"{x:1696,y:907,t:1527188777882};\\\", \\\"{x:1696,y:917,t:1527188777899};\\\", \\\"{x:1696,y:924,t:1527188777915};\\\", \\\"{x:1696,y:929,t:1527188777932};\\\", \\\"{x:1697,y:929,t:1527188777948};\\\", \\\"{x:1698,y:931,t:1527188777965};\\\", \\\"{x:1700,y:933,t:1527188777982};\\\", \\\"{x:1700,y:934,t:1527188777999};\\\", \\\"{x:1700,y:937,t:1527188778020};\\\", \\\"{x:1699,y:942,t:1527188778036};\\\", \\\"{x:1698,y:945,t:1527188778051};\\\", \\\"{x:1698,y:946,t:1527188778065};\\\", \\\"{x:1696,y:951,t:1527188778082};\\\", \\\"{x:1696,y:952,t:1527188778100};\\\", \\\"{x:1696,y:954,t:1527188778140};\\\", \\\"{x:1695,y:954,t:1527188778149};\\\", \\\"{x:1695,y:955,t:1527188778166};\\\", \\\"{x:1694,y:956,t:1527188778182};\\\", \\\"{x:1692,y:957,t:1527188778198};\\\", \\\"{x:1691,y:957,t:1527188778372};\\\", \\\"{x:1689,y:957,t:1527188778565};\\\", \\\"{x:1687,y:957,t:1527188778572};\\\", \\\"{x:1685,y:956,t:1527188778583};\\\", \\\"{x:1685,y:952,t:1527188778599};\\\", \\\"{x:1685,y:949,t:1527188778616};\\\", \\\"{x:1685,y:948,t:1527188778633};\\\", \\\"{x:1685,y:946,t:1527188778648};\\\", \\\"{x:1684,y:946,t:1527188778683};\\\", \\\"{x:1683,y:945,t:1527188778844};\\\", \\\"{x:1683,y:942,t:1527188778852};\\\", \\\"{x:1683,y:935,t:1527188778865};\\\", \\\"{x:1684,y:927,t:1527188778883};\\\", \\\"{x:1685,y:920,t:1527188778899};\\\", \\\"{x:1687,y:915,t:1527188778915};\\\", \\\"{x:1687,y:913,t:1527188778932};\\\", \\\"{x:1687,y:912,t:1527188778949};\\\", \\\"{x:1688,y:909,t:1527188779011};\\\", \\\"{x:1688,y:907,t:1527188779028};\\\", \\\"{x:1688,y:906,t:1527188779035};\\\", \\\"{x:1689,y:904,t:1527188779049};\\\", \\\"{x:1690,y:900,t:1527188779066};\\\", \\\"{x:1691,y:896,t:1527188779083};\\\", \\\"{x:1691,y:893,t:1527188779099};\\\", \\\"{x:1691,y:890,t:1527188779115};\\\", \\\"{x:1691,y:886,t:1527188779133};\\\", \\\"{x:1691,y:883,t:1527188779150};\\\", \\\"{x:1691,y:878,t:1527188779166};\\\", \\\"{x:1691,y:876,t:1527188779182};\\\", \\\"{x:1690,y:874,t:1527188779199};\\\", \\\"{x:1690,y:873,t:1527188779277};\\\", \\\"{x:1688,y:870,t:1527188779308};\\\", \\\"{x:1687,y:869,t:1527188779316};\\\", \\\"{x:1687,y:864,t:1527188779334};\\\", \\\"{x:1684,y:855,t:1527188779350};\\\", \\\"{x:1682,y:846,t:1527188779367};\\\", \\\"{x:1681,y:841,t:1527188779383};\\\", \\\"{x:1681,y:839,t:1527188779400};\\\", \\\"{x:1681,y:835,t:1527188779417};\\\", \\\"{x:1681,y:832,t:1527188779433};\\\", \\\"{x:1681,y:827,t:1527188779450};\\\", \\\"{x:1679,y:819,t:1527188779467};\\\", \\\"{x:1679,y:810,t:1527188779483};\\\", \\\"{x:1677,y:799,t:1527188779499};\\\", \\\"{x:1676,y:793,t:1527188779517};\\\", \\\"{x:1674,y:787,t:1527188779533};\\\", \\\"{x:1674,y:785,t:1527188779550};\\\", \\\"{x:1674,y:784,t:1527188779566};\\\", \\\"{x:1674,y:781,t:1527188779583};\\\", \\\"{x:1674,y:780,t:1527188779600};\\\", \\\"{x:1674,y:777,t:1527188779617};\\\", \\\"{x:1674,y:771,t:1527188779633};\\\", \\\"{x:1674,y:765,t:1527188779650};\\\", \\\"{x:1674,y:762,t:1527188779667};\\\", \\\"{x:1674,y:759,t:1527188779683};\\\", \\\"{x:1674,y:757,t:1527188779700};\\\", \\\"{x:1674,y:755,t:1527188779717};\\\", \\\"{x:1675,y:751,t:1527188779733};\\\", \\\"{x:1675,y:745,t:1527188779750};\\\", \\\"{x:1676,y:740,t:1527188779767};\\\", \\\"{x:1678,y:736,t:1527188779783};\\\", \\\"{x:1679,y:729,t:1527188779800};\\\", \\\"{x:1679,y:727,t:1527188779820};\\\", \\\"{x:1679,y:725,t:1527188779834};\\\", \\\"{x:1679,y:722,t:1527188779851};\\\", \\\"{x:1679,y:718,t:1527188779868};\\\", \\\"{x:1679,y:707,t:1527188779884};\\\", \\\"{x:1679,y:699,t:1527188779900};\\\", \\\"{x:1679,y:697,t:1527188779917};\\\", \\\"{x:1679,y:692,t:1527188779934};\\\", \\\"{x:1679,y:687,t:1527188779951};\\\", \\\"{x:1679,y:675,t:1527188779967};\\\", \\\"{x:1679,y:668,t:1527188779985};\\\", \\\"{x:1679,y:663,t:1527188780001};\\\", \\\"{x:1679,y:658,t:1527188780018};\\\", \\\"{x:1679,y:657,t:1527188780034};\\\", \\\"{x:1679,y:656,t:1527188780051};\\\", \\\"{x:1679,y:655,t:1527188780084};\\\", \\\"{x:1679,y:653,t:1527188780100};\\\", \\\"{x:1679,y:652,t:1527188780117};\\\", \\\"{x:1679,y:648,t:1527188780134};\\\", \\\"{x:1679,y:645,t:1527188780151};\\\", \\\"{x:1679,y:643,t:1527188780167};\\\", \\\"{x:1679,y:640,t:1527188780184};\\\", \\\"{x:1679,y:637,t:1527188780200};\\\", \\\"{x:1679,y:632,t:1527188780217};\\\", \\\"{x:1679,y:630,t:1527188780234};\\\", \\\"{x:1679,y:660,t:1527188780557};\\\", \\\"{x:1676,y:708,t:1527188780567};\\\", \\\"{x:1657,y:801,t:1527188780585};\\\", \\\"{x:1636,y:829,t:1527188780601};\\\", \\\"{x:1633,y:847,t:1527188780613};\\\", \\\"{x:1631,y:861,t:1527188780635};\\\", \\\"{x:1631,y:866,t:1527188780651};\\\", \\\"{x:1630,y:868,t:1527188780667};\\\", \\\"{x:1630,y:871,t:1527188780684};\\\", \\\"{x:1630,y:874,t:1527188780701};\\\", \\\"{x:1630,y:876,t:1527188780708};\\\", \\\"{x:1630,y:879,t:1527188780718};\\\", \\\"{x:1630,y:883,t:1527188780735};\\\", \\\"{x:1630,y:887,t:1527188780751};\\\", \\\"{x:1629,y:890,t:1527188780769};\\\", \\\"{x:1629,y:892,t:1527188780784};\\\", \\\"{x:1628,y:896,t:1527188780801};\\\", \\\"{x:1628,y:900,t:1527188780818};\\\", \\\"{x:1627,y:905,t:1527188780834};\\\", \\\"{x:1622,y:921,t:1527188780853};\\\", \\\"{x:1621,y:929,t:1527188780868};\\\", \\\"{x:1620,y:933,t:1527188780884};\\\", \\\"{x:1620,y:934,t:1527188780948};\\\", \\\"{x:1620,y:937,t:1527188780956};\\\", \\\"{x:1620,y:942,t:1527188780968};\\\", \\\"{x:1620,y:948,t:1527188780984};\\\", \\\"{x:1617,y:955,t:1527188781001};\\\", \\\"{x:1616,y:960,t:1527188781018};\\\", \\\"{x:1616,y:964,t:1527188781034};\\\", \\\"{x:1616,y:965,t:1527188781051};\\\", \\\"{x:1615,y:966,t:1527188781149};\\\", \\\"{x:1614,y:966,t:1527188781252};\\\", \\\"{x:1614,y:965,t:1527188781308};\\\", \\\"{x:1614,y:962,t:1527188781318};\\\", \\\"{x:1614,y:947,t:1527188781335};\\\", \\\"{x:1614,y:929,t:1527188781351};\\\", \\\"{x:1615,y:914,t:1527188781367};\\\", \\\"{x:1616,y:902,t:1527188781385};\\\", \\\"{x:1617,y:896,t:1527188781401};\\\", \\\"{x:1617,y:894,t:1527188781418};\\\", \\\"{x:1617,y:892,t:1527188781435};\\\", \\\"{x:1618,y:891,t:1527188781451};\\\", \\\"{x:1619,y:888,t:1527188781467};\\\", \\\"{x:1619,y:886,t:1527188781485};\\\", \\\"{x:1619,y:880,t:1527188781500};\\\", \\\"{x:1619,y:876,t:1527188781518};\\\", \\\"{x:1619,y:872,t:1527188781535};\\\", \\\"{x:1619,y:868,t:1527188781550};\\\", \\\"{x:1619,y:865,t:1527188781568};\\\", \\\"{x:1619,y:859,t:1527188781584};\\\", \\\"{x:1619,y:856,t:1527188781601};\\\", \\\"{x:1619,y:852,t:1527188781618};\\\", \\\"{x:1619,y:847,t:1527188781635};\\\", \\\"{x:1619,y:839,t:1527188781652};\\\", \\\"{x:1619,y:832,t:1527188781669};\\\", \\\"{x:1619,y:825,t:1527188781685};\\\", \\\"{x:1619,y:821,t:1527188781702};\\\", \\\"{x:1619,y:817,t:1527188781718};\\\", \\\"{x:1619,y:814,t:1527188781735};\\\", \\\"{x:1618,y:811,t:1527188781752};\\\", \\\"{x:1618,y:808,t:1527188781768};\\\", \\\"{x:1617,y:806,t:1527188781785};\\\", \\\"{x:1615,y:801,t:1527188781802};\\\", \\\"{x:1614,y:798,t:1527188781818};\\\", \\\"{x:1614,y:793,t:1527188781835};\\\", \\\"{x:1611,y:786,t:1527188781851};\\\", \\\"{x:1609,y:779,t:1527188781868};\\\", \\\"{x:1607,y:776,t:1527188781885};\\\", \\\"{x:1603,y:773,t:1527188781902};\\\", \\\"{x:1603,y:770,t:1527188781917};\\\", \\\"{x:1602,y:764,t:1527188781935};\\\", \\\"{x:1602,y:758,t:1527188781952};\\\", \\\"{x:1598,y:752,t:1527188781968};\\\", \\\"{x:1598,y:749,t:1527188781985};\\\", \\\"{x:1597,y:745,t:1527188782002};\\\", \\\"{x:1597,y:740,t:1527188782018};\\\", \\\"{x:1595,y:735,t:1527188782035};\\\", \\\"{x:1594,y:726,t:1527188782052};\\\", \\\"{x:1593,y:719,t:1527188782069};\\\", \\\"{x:1593,y:716,t:1527188782085};\\\", \\\"{x:1593,y:711,t:1527188782102};\\\", \\\"{x:1593,y:708,t:1527188782119};\\\", \\\"{x:1593,y:704,t:1527188782135};\\\", \\\"{x:1593,y:700,t:1527188782152};\\\", \\\"{x:1593,y:698,t:1527188782169};\\\", \\\"{x:1593,y:696,t:1527188782185};\\\", \\\"{x:1593,y:695,t:1527188782203};\\\", \\\"{x:1596,y:685,t:1527188782219};\\\", \\\"{x:1596,y:683,t:1527188782235};\\\", \\\"{x:1596,y:679,t:1527188782252};\\\", \\\"{x:1601,y:674,t:1527188782269};\\\", \\\"{x:1601,y:671,t:1527188782285};\\\", \\\"{x:1602,y:670,t:1527188782302};\\\", \\\"{x:1602,y:668,t:1527188782319};\\\", \\\"{x:1603,y:663,t:1527188782335};\\\", \\\"{x:1603,y:662,t:1527188782352};\\\", \\\"{x:1604,y:658,t:1527188782368};\\\", \\\"{x:1604,y:654,t:1527188782385};\\\", \\\"{x:1605,y:650,t:1527188782402};\\\", \\\"{x:1606,y:645,t:1527188782419};\\\", \\\"{x:1607,y:641,t:1527188782435};\\\", \\\"{x:1608,y:634,t:1527188782452};\\\", \\\"{x:1609,y:630,t:1527188782469};\\\", \\\"{x:1609,y:627,t:1527188782485};\\\", \\\"{x:1609,y:625,t:1527188782503};\\\", \\\"{x:1609,y:623,t:1527188782519};\\\", \\\"{x:1611,y:620,t:1527188782536};\\\", \\\"{x:1611,y:615,t:1527188782552};\\\", \\\"{x:1613,y:608,t:1527188782569};\\\", \\\"{x:1616,y:602,t:1527188782586};\\\", \\\"{x:1617,y:598,t:1527188782602};\\\", \\\"{x:1617,y:597,t:1527188782619};\\\", \\\"{x:1617,y:595,t:1527188782636};\\\", \\\"{x:1619,y:593,t:1527188782652};\\\", \\\"{x:1619,y:592,t:1527188782669};\\\", \\\"{x:1610,y:592,t:1527188782996};\\\", \\\"{x:1586,y:596,t:1527188783004};\\\", \\\"{x:1554,y:601,t:1527188783020};\\\", \\\"{x:1409,y:631,t:1527188783037};\\\", \\\"{x:1320,y:634,t:1527188783054};\\\", \\\"{x:1247,y:634,t:1527188783070};\\\", \\\"{x:1215,y:636,t:1527188783087};\\\", \\\"{x:1195,y:637,t:1527188783105};\\\", \\\"{x:1178,y:642,t:1527188783119};\\\", \\\"{x:1174,y:642,t:1527188783136};\\\", \\\"{x:1159,y:647,t:1527188783154};\\\", \\\"{x:1135,y:654,t:1527188783169};\\\", \\\"{x:1113,y:662,t:1527188783187};\\\", \\\"{x:1089,y:668,t:1527188783203};\\\", \\\"{x:1060,y:670,t:1527188783219};\\\", \\\"{x:1021,y:671,t:1527188783236};\\\", \\\"{x:979,y:671,t:1527188783253};\\\", \\\"{x:950,y:671,t:1527188783269};\\\", \\\"{x:927,y:662,t:1527188783287};\\\", \\\"{x:898,y:653,t:1527188783303};\\\", \\\"{x:883,y:645,t:1527188783319};\\\", \\\"{x:863,y:644,t:1527188783336};\\\", \\\"{x:834,y:644,t:1527188783353};\\\", \\\"{x:811,y:644,t:1527188783369};\\\", \\\"{x:793,y:644,t:1527188783386};\\\", \\\"{x:774,y:644,t:1527188783403};\\\", \\\"{x:746,y:644,t:1527188783419};\\\", \\\"{x:718,y:647,t:1527188783436};\\\", \\\"{x:690,y:647,t:1527188783453};\\\", \\\"{x:650,y:644,t:1527188783470};\\\", \\\"{x:609,y:636,t:1527188783487};\\\", \\\"{x:576,y:627,t:1527188783504};\\\", \\\"{x:552,y:619,t:1527188783520};\\\", \\\"{x:524,y:611,t:1527188783537};\\\", \\\"{x:501,y:603,t:1527188783554};\\\", \\\"{x:471,y:594,t:1527188783570};\\\", \\\"{x:449,y:585,t:1527188783587};\\\", \\\"{x:428,y:571,t:1527188783604};\\\", \\\"{x:415,y:564,t:1527188783620};\\\", \\\"{x:395,y:557,t:1527188783637};\\\", \\\"{x:377,y:549,t:1527188783654};\\\", \\\"{x:375,y:548,t:1527188783670};\\\", \\\"{x:374,y:548,t:1527188783687};\\\", \\\"{x:374,y:547,t:1527188783835};\\\", \\\"{x:376,y:547,t:1527188783843};\\\", \\\"{x:378,y:545,t:1527188783854};\\\", \\\"{x:384,y:541,t:1527188783871};\\\", \\\"{x:385,y:540,t:1527188783886};\\\", \\\"{x:386,y:538,t:1527188783904};\\\", \\\"{x:378,y:540,t:1527188784028};\\\", \\\"{x:368,y:544,t:1527188784037};\\\", \\\"{x:340,y:549,t:1527188784053};\\\", \\\"{x:311,y:549,t:1527188784070};\\\", \\\"{x:291,y:549,t:1527188784086};\\\", \\\"{x:287,y:549,t:1527188784102};\\\", \\\"{x:284,y:549,t:1527188784120};\\\", \\\"{x:283,y:550,t:1527188784137};\\\", \\\"{x:276,y:553,t:1527188784153};\\\", \\\"{x:262,y:557,t:1527188784171};\\\", \\\"{x:255,y:562,t:1527188784187};\\\", \\\"{x:251,y:563,t:1527188784204};\\\", \\\"{x:249,y:563,t:1527188784221};\\\", \\\"{x:248,y:564,t:1527188785509};\\\", \\\"{x:247,y:564,t:1527188785524};\\\", \\\"{x:245,y:565,t:1527188785538};\\\", \\\"{x:245,y:566,t:1527188785555};\\\", \\\"{x:244,y:568,t:1527188785788};\\\", \\\"{x:244,y:576,t:1527188785807};\\\", \\\"{x:244,y:586,t:1527188785822};\\\", \\\"{x:244,y:594,t:1527188785839};\\\", \\\"{x:244,y:600,t:1527188785855};\\\", \\\"{x:246,y:610,t:1527188785872};\\\", \\\"{x:252,y:625,t:1527188785890};\\\", \\\"{x:256,y:644,t:1527188785905};\\\", \\\"{x:264,y:667,t:1527188785922};\\\", \\\"{x:271,y:697,t:1527188785939};\\\", \\\"{x:287,y:733,t:1527188785955};\\\", \\\"{x:294,y:753,t:1527188785972};\\\", \\\"{x:301,y:768,t:1527188785989};\\\", \\\"{x:306,y:781,t:1527188786005};\\\", \\\"{x:309,y:789,t:1527188786022};\\\", \\\"{x:311,y:794,t:1527188786039};\\\", \\\"{x:312,y:797,t:1527188786055};\\\", \\\"{x:313,y:798,t:1527188786107};\\\", \\\"{x:314,y:798,t:1527188788404};\\\", \\\"{x:314,y:791,t:1527188788412};\\\", \\\"{x:314,y:787,t:1527188788424};\\\", \\\"{x:316,y:773,t:1527188788442};\\\", \\\"{x:319,y:756,t:1527188788458};\\\", \\\"{x:322,y:741,t:1527188788474};\\\", \\\"{x:331,y:712,t:1527188788492};\\\", \\\"{x:337,y:691,t:1527188788508};\\\", \\\"{x:347,y:670,t:1527188788524};\\\", \\\"{x:358,y:644,t:1527188788548};\\\", \\\"{x:370,y:619,t:1527188788559};\\\", \\\"{x:383,y:597,t:1527188788574};\\\", \\\"{x:404,y:572,t:1527188788590};\\\", \\\"{x:427,y:553,t:1527188788606};\\\", \\\"{x:454,y:531,t:1527188788625};\\\", \\\"{x:488,y:513,t:1527188788641};\\\", \\\"{x:502,y:510,t:1527188788658};\\\", \\\"{x:509,y:508,t:1527188788674};\\\", \\\"{x:512,y:508,t:1527188788691};\\\", \\\"{x:519,y:512,t:1527188788707};\\\", \\\"{x:527,y:521,t:1527188788724};\\\", \\\"{x:539,y:529,t:1527188788741};\\\", \\\"{x:547,y:541,t:1527188788758};\\\", \\\"{x:556,y:553,t:1527188788775};\\\", \\\"{x:562,y:567,t:1527188788791};\\\", \\\"{x:567,y:577,t:1527188788808};\\\", \\\"{x:572,y:591,t:1527188788825};\\\", \\\"{x:574,y:597,t:1527188788841};\\\", \\\"{x:575,y:598,t:1527188788858};\\\", \\\"{x:576,y:599,t:1527188788908};\\\", \\\"{x:578,y:599,t:1527188788916};\\\", \\\"{x:584,y:599,t:1527188788925};\\\", \\\"{x:598,y:598,t:1527188788941};\\\", \\\"{x:621,y:597,t:1527188788958};\\\", \\\"{x:647,y:594,t:1527188788976};\\\", \\\"{x:662,y:593,t:1527188788991};\\\", \\\"{x:674,y:589,t:1527188789008};\\\", \\\"{x:682,y:584,t:1527188789025};\\\", \\\"{x:690,y:579,t:1527188789042};\\\", \\\"{x:697,y:574,t:1527188789059};\\\", \\\"{x:715,y:568,t:1527188789075};\\\", \\\"{x:728,y:565,t:1527188789092};\\\", \\\"{x:737,y:564,t:1527188789108};\\\", \\\"{x:749,y:562,t:1527188789125};\\\", \\\"{x:756,y:560,t:1527188789141};\\\", \\\"{x:766,y:555,t:1527188789158};\\\", \\\"{x:775,y:554,t:1527188789175};\\\", \\\"{x:779,y:552,t:1527188789191};\\\", \\\"{x:780,y:552,t:1527188789268};\\\", \\\"{x:782,y:552,t:1527188789275};\\\", \\\"{x:788,y:550,t:1527188789292};\\\", \\\"{x:798,y:548,t:1527188789308};\\\", \\\"{x:804,y:548,t:1527188789325};\\\", \\\"{x:807,y:548,t:1527188789342};\\\", \\\"{x:811,y:549,t:1527188789358};\\\", \\\"{x:815,y:552,t:1527188789376};\\\", \\\"{x:819,y:553,t:1527188789393};\\\", \\\"{x:822,y:553,t:1527188789410};\\\", \\\"{x:823,y:553,t:1527188789427};\\\", \\\"{x:824,y:553,t:1527188789460};\\\", \\\"{x:825,y:555,t:1527188789475};\\\", \\\"{x:827,y:556,t:1527188789493};\\\", \\\"{x:828,y:556,t:1527188789509};\\\", \\\"{x:826,y:558,t:1527188789899};\\\", \\\"{x:820,y:564,t:1527188789909};\\\", \\\"{x:805,y:574,t:1527188789925};\\\", \\\"{x:790,y:586,t:1527188789943};\\\", \\\"{x:770,y:594,t:1527188789959};\\\", \\\"{x:747,y:604,t:1527188789975};\\\", \\\"{x:727,y:609,t:1527188789993};\\\", \\\"{x:701,y:617,t:1527188790010};\\\", \\\"{x:666,y:629,t:1527188790026};\\\", \\\"{x:638,y:635,t:1527188790043};\\\", \\\"{x:625,y:642,t:1527188790059};\\\", \\\"{x:621,y:645,t:1527188790076};\\\", \\\"{x:612,y:651,t:1527188790093};\\\", \\\"{x:602,y:660,t:1527188790109};\\\", \\\"{x:594,y:671,t:1527188790125};\\\", \\\"{x:583,y:678,t:1527188790142};\\\", \\\"{x:578,y:680,t:1527188790158};\\\", \\\"{x:575,y:682,t:1527188790176};\\\", \\\"{x:574,y:683,t:1527188790193};\\\", \\\"{x:570,y:685,t:1527188790208};\\\", \\\"{x:568,y:687,t:1527188790226};\\\", \\\"{x:566,y:687,t:1527188790243};\\\", \\\"{x:565,y:689,t:1527188790260};\\\", \\\"{x:564,y:690,t:1527188790276};\\\", \\\"{x:561,y:692,t:1527188790292};\\\", \\\"{x:556,y:696,t:1527188790309};\\\", \\\"{x:554,y:697,t:1527188790326};\\\", \\\"{x:552,y:697,t:1527188790342};\\\", \\\"{x:549,y:698,t:1527188790364};\\\", \\\"{x:548,y:699,t:1527188790375};\\\", \\\"{x:542,y:705,t:1527188790392};\\\", \\\"{x:536,y:711,t:1527188790408};\\\", \\\"{x:532,y:716,t:1527188790426};\\\", \\\"{x:530,y:718,t:1527188790442};\\\", \\\"{x:529,y:718,t:1527188790668};\\\", \\\"{x:528,y:719,t:1527188790677};\\\", \\\"{x:528,y:720,t:1527188790724};\\\", \\\"{x:528,y:721,t:1527188790780};\\\", \\\"{x:527,y:720,t:1527188799531};\\\", \\\"{x:527,y:716,t:1527188799538};\\\", \\\"{x:527,y:711,t:1527188799551};\\\", \\\"{x:527,y:701,t:1527188799568};\\\", \\\"{x:527,y:692,t:1527188799584};\\\", \\\"{x:527,y:681,t:1527188799602};\\\", \\\"{x:527,y:665,t:1527188799619};\\\", \\\"{x:531,y:649,t:1527188799633};\\\", \\\"{x:540,y:630,t:1527188799650};\\\", \\\"{x:545,y:617,t:1527188799667};\\\", \\\"{x:551,y:602,t:1527188799684};\\\", \\\"{x:553,y:595,t:1527188799701};\\\", \\\"{x:554,y:585,t:1527188799716};\\\", \\\"{x:557,y:575,t:1527188799733};\\\", \\\"{x:558,y:566,t:1527188799751};\\\", \\\"{x:560,y:557,t:1527188799766};\\\", \\\"{x:560,y:553,t:1527188799783};\\\", \\\"{x:557,y:549,t:1527188799800};\\\", \\\"{x:551,y:548,t:1527188799816};\\\", \\\"{x:539,y:544,t:1527188799834};\\\", \\\"{x:520,y:543,t:1527188799851};\\\", \\\"{x:493,y:539,t:1527188799866};\\\", \\\"{x:454,y:534,t:1527188799884};\\\", \\\"{x:440,y:530,t:1527188799900};\\\", \\\"{x:437,y:530,t:1527188799916};\\\", \\\"{x:434,y:530,t:1527188799963};\\\", \\\"{x:431,y:530,t:1527188799971};\\\", \\\"{x:427,y:530,t:1527188799984};\\\", \\\"{x:408,y:531,t:1527188800000};\\\", \\\"{x:396,y:531,t:1527188800017};\\\", \\\"{x:376,y:531,t:1527188800034};\\\", \\\"{x:366,y:531,t:1527188800051};\\\", \\\"{x:362,y:532,t:1527188800067};\\\", \\\"{x:360,y:533,t:1527188800084};\\\", \\\"{x:352,y:536,t:1527188800100};\\\", \\\"{x:342,y:539,t:1527188800118};\\\", \\\"{x:330,y:543,t:1527188800134};\\\", \\\"{x:318,y:545,t:1527188800151};\\\", \\\"{x:305,y:545,t:1527188800168};\\\", \\\"{x:301,y:545,t:1527188800183};\\\", \\\"{x:293,y:548,t:1527188800201};\\\", \\\"{x:281,y:552,t:1527188800217};\\\", \\\"{x:260,y:564,t:1527188800234};\\\", \\\"{x:242,y:576,t:1527188800251};\\\", \\\"{x:234,y:583,t:1527188800267};\\\", \\\"{x:233,y:583,t:1527188800284};\\\", \\\"{x:233,y:585,t:1527188800301};\\\", \\\"{x:233,y:591,t:1527188800317};\\\", \\\"{x:236,y:601,t:1527188800334};\\\", \\\"{x:240,y:614,t:1527188800351};\\\", \\\"{x:243,y:620,t:1527188800368};\\\", \\\"{x:248,y:629,t:1527188800385};\\\", \\\"{x:253,y:636,t:1527188800400};\\\", \\\"{x:262,y:643,t:1527188800418};\\\", \\\"{x:269,y:643,t:1527188800435};\\\", \\\"{x:290,y:647,t:1527188800452};\\\", \\\"{x:308,y:647,t:1527188800467};\\\", \\\"{x:328,y:647,t:1527188800484};\\\", \\\"{x:340,y:647,t:1527188800501};\\\", \\\"{x:344,y:643,t:1527188800517};\\\", \\\"{x:346,y:643,t:1527188800535};\\\", \\\"{x:346,y:642,t:1527188800551};\\\", \\\"{x:341,y:638,t:1527188800568};\\\", \\\"{x:329,y:630,t:1527188800584};\\\", \\\"{x:295,y:618,t:1527188800601};\\\", \\\"{x:265,y:614,t:1527188800618};\\\", \\\"{x:251,y:609,t:1527188800635};\\\", \\\"{x:241,y:604,t:1527188800651};\\\", \\\"{x:234,y:602,t:1527188800668};\\\", \\\"{x:232,y:602,t:1527188800684};\\\", \\\"{x:224,y:603,t:1527188800700};\\\", \\\"{x:210,y:604,t:1527188800718};\\\", \\\"{x:202,y:606,t:1527188800735};\\\", \\\"{x:200,y:606,t:1527188800819};\\\", \\\"{x:199,y:606,t:1527188800834};\\\", \\\"{x:176,y:606,t:1527188800850};\\\", \\\"{x:165,y:607,t:1527188800867};\\\", \\\"{x:164,y:607,t:1527188800884};\\\", \\\"{x:166,y:608,t:1527188800902};\\\", \\\"{x:169,y:610,t:1527188800917};\\\", \\\"{x:170,y:611,t:1527188800947};\\\", \\\"{x:170,y:613,t:1527188800955};\\\", \\\"{x:170,y:614,t:1527188800968};\\\", \\\"{x:165,y:623,t:1527188800985};\\\", \\\"{x:157,y:633,t:1527188801001};\\\", \\\"{x:153,y:638,t:1527188801017};\\\", \\\"{x:151,y:640,t:1527188801035};\\\", \\\"{x:151,y:641,t:1527188801052};\\\", \\\"{x:159,y:644,t:1527188801340};\\\", \\\"{x:195,y:647,t:1527188801352};\\\", \\\"{x:274,y:652,t:1527188801369};\\\", \\\"{x:376,y:666,t:1527188801385};\\\", \\\"{x:454,y:675,t:1527188801402};\\\", \\\"{x:481,y:681,t:1527188801419};\\\", \\\"{x:491,y:685,t:1527188801434};\\\", \\\"{x:493,y:685,t:1527188801452};\\\", \\\"{x:496,y:687,t:1527188801469};\\\", \\\"{x:502,y:689,t:1527188801484};\\\", \\\"{x:516,y:695,t:1527188801502};\\\", \\\"{x:532,y:703,t:1527188801519};\\\", \\\"{x:537,y:705,t:1527188801534};\\\", \\\"{x:538,y:706,t:1527188801595};\\\", \\\"{x:538,y:711,t:1527188801603};\\\", \\\"{x:541,y:717,t:1527188801619};\\\", \\\"{x:543,y:727,t:1527188801634};\\\", \\\"{x:545,y:732,t:1527188801651};\\\", \\\"{x:542,y:732,t:1527188801731};\\\", \\\"{x:540,y:729,t:1527188801739};\\\", \\\"{x:539,y:726,t:1527188801755};\\\", \\\"{x:536,y:723,t:1527188801768};\\\", \\\"{x:535,y:722,t:1527188801786};\\\", \\\"{x:535,y:720,t:1527188801802};\\\", \\\"{x:535,y:714,t:1527188801818};\\\", \\\"{x:539,y:708,t:1527188801835};\\\", \\\"{x:553,y:699,t:1527188801851};\\\", \\\"{x:595,y:684,t:1527188801868};\\\", \\\"{x:676,y:656,t:1527188801886};\\\", \\\"{x:724,y:632,t:1527188801902};\\\", \\\"{x:765,y:616,t:1527188801919};\\\", \\\"{x:785,y:605,t:1527188801936};\\\", \\\"{x:793,y:601,t:1527188801951};\\\", \\\"{x:794,y:600,t:1527188801969};\\\", \\\"{x:795,y:599,t:1527188801986};\\\", \\\"{x:798,y:596,t:1527188802001};\\\", \\\"{x:800,y:594,t:1527188802018};\\\", \\\"{x:801,y:594,t:1527188802043};\\\", \\\"{x:801,y:592,t:1527188802051};\\\", \\\"{x:807,y:582,t:1527188802069};\\\", \\\"{x:813,y:577,t:1527188802086};\\\", \\\"{x:817,y:574,t:1527188802102};\\\", \\\"{x:818,y:573,t:1527188802119};\\\", \\\"{x:822,y:569,t:1527188802171};\\\", \\\"{x:826,y:564,t:1527188802185};\\\", \\\"{x:834,y:555,t:1527188802202};\\\", \\\"{x:846,y:547,t:1527188802219};\\\", \\\"{x:848,y:546,t:1527188802236};\\\", \\\"{x:849,y:547,t:1527188802972};\\\", \\\"{x:849,y:553,t:1527188802986};\\\", \\\"{x:846,y:560,t:1527188803003};\\\", \\\"{x:845,y:560,t:1527188803019};\\\", \\\"{x:846,y:559,t:1527188803108};\\\", \\\"{x:848,y:558,t:1527188803119};\\\", \\\"{x:849,y:555,t:1527188803136};\\\", \\\"{x:849,y:553,t:1527188803153};\\\", \\\"{x:848,y:555,t:1527188803427};\\\", \\\"{x:847,y:556,t:1527188803437};\\\", \\\"{x:845,y:561,t:1527188803454};\\\", \\\"{x:842,y:566,t:1527188803470};\\\", \\\"{x:839,y:571,t:1527188803487};\\\", \\\"{x:838,y:572,t:1527188803503};\\\", \\\"{x:837,y:573,t:1527188803520};\\\", \\\"{x:836,y:575,t:1527188803548};\\\", \\\"{x:836,y:577,t:1527188803563};\\\", \\\"{x:833,y:579,t:1527188803571};\\\", \\\"{x:831,y:585,t:1527188803587};\\\", \\\"{x:826,y:592,t:1527188803603};\\\", \\\"{x:819,y:604,t:1527188803620};\\\", \\\"{x:807,y:622,t:1527188803637};\\\", \\\"{x:800,y:638,t:1527188803653};\\\", \\\"{x:792,y:658,t:1527188803670};\\\", \\\"{x:791,y:667,t:1527188803686};\\\", \\\"{x:791,y:670,t:1527188803704};\\\", \\\"{x:788,y:673,t:1527188803720};\\\", \\\"{x:787,y:678,t:1527188803736};\\\", \\\"{x:785,y:686,t:1527188803754};\\\", \\\"{x:784,y:697,t:1527188803770};\\\", \\\"{x:780,y:724,t:1527188803787};\\\", \\\"{x:774,y:741,t:1527188803803};\\\", \\\"{x:774,y:743,t:1527188803820};\\\", \\\"{x:774,y:744,t:1527188803837};\\\", \\\"{x:771,y:749,t:1527188804804};\\\", \\\"{x:765,y:754,t:1527188804811};\\\", \\\"{x:759,y:759,t:1527188804821};\\\", \\\"{x:749,y:767,t:1527188804837};\\\", \\\"{x:748,y:769,t:1527188804855};\\\", \\\"{x:740,y:777,t:1527188804871};\\\", \\\"{x:728,y:782,t:1527188804888};\\\", \\\"{x:709,y:788,t:1527188804905};\\\", \\\"{x:687,y:792,t:1527188804920};\\\", \\\"{x:670,y:797,t:1527188804937};\\\", \\\"{x:646,y:798,t:1527188804955};\\\", \\\"{x:639,y:798,t:1527188804970};\\\", \\\"{x:633,y:798,t:1527188804988};\\\", \\\"{x:624,y:798,t:1527188805005};\\\", \\\"{x:613,y:797,t:1527188805020};\\\", \\\"{x:589,y:790,t:1527188805038};\\\", \\\"{x:564,y:782,t:1527188805054};\\\", \\\"{x:543,y:772,t:1527188805070};\\\", \\\"{x:541,y:770,t:1527188805088};\\\", \\\"{x:540,y:767,t:1527188805123};\\\", \\\"{x:540,y:763,t:1527188805138};\\\", \\\"{x:540,y:757,t:1527188805155};\\\", \\\"{x:540,y:754,t:1527188805171};\\\", \\\"{x:539,y:752,t:1527188805188};\\\", \\\"{x:539,y:751,t:1527188805204};\\\", \\\"{x:538,y:750,t:1527188805221};\\\", \\\"{x:536,y:745,t:1527188805238};\\\", \\\"{x:535,y:739,t:1527188805255};\\\", \\\"{x:532,y:734,t:1527188805273};\\\", \\\"{x:531,y:731,t:1527188805288};\\\", \\\"{x:530,y:730,t:1527188805305};\\\", \\\"{x:530,y:729,t:1527188805338};\\\", \\\"{x:528,y:724,t:1527188805355};\\\", \\\"{x:528,y:720,t:1527188805371};\\\", \\\"{x:528,y:716,t:1527188805388};\\\" ] }, { \\\"rt\\\": 19562, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 353732, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:725,t:1527188808690};\\\", \\\"{x:530,y:742,t:1527188808709};\\\", \\\"{x:530,y:756,t:1527188808725};\\\", \\\"{x:530,y:762,t:1527188808741};\\\", \\\"{x:530,y:770,t:1527188808757};\\\", \\\"{x:530,y:776,t:1527188808774};\\\", \\\"{x:531,y:781,t:1527188808791};\\\", \\\"{x:531,y:783,t:1527188808808};\\\", \\\"{x:531,y:784,t:1527188808824};\\\", \\\"{x:531,y:785,t:1527188808841};\\\", \\\"{x:531,y:786,t:1527188808857};\\\", \\\"{x:535,y:787,t:1527188813548};\\\", \\\"{x:570,y:790,t:1527188813559};\\\", \\\"{x:695,y:806,t:1527188813576};\\\", \\\"{x:795,y:820,t:1527188813593};\\\", \\\"{x:869,y:829,t:1527188813610};\\\", \\\"{x:907,y:835,t:1527188813626};\\\", \\\"{x:938,y:841,t:1527188813643};\\\", \\\"{x:951,y:841,t:1527188813659};\\\", \\\"{x:963,y:839,t:1527188813676};\\\", \\\"{x:976,y:838,t:1527188813694};\\\", \\\"{x:1000,y:837,t:1527188813709};\\\", \\\"{x:1026,y:831,t:1527188813726};\\\", \\\"{x:1049,y:831,t:1527188813743};\\\", \\\"{x:1082,y:831,t:1527188813759};\\\", \\\"{x:1107,y:829,t:1527188813776};\\\", \\\"{x:1121,y:827,t:1527188813794};\\\", \\\"{x:1137,y:822,t:1527188813809};\\\", \\\"{x:1144,y:821,t:1527188813826};\\\", \\\"{x:1154,y:818,t:1527188813843};\\\", \\\"{x:1168,y:818,t:1527188813859};\\\", \\\"{x:1181,y:818,t:1527188813877};\\\", \\\"{x:1200,y:823,t:1527188813893};\\\", \\\"{x:1208,y:830,t:1527188813910};\\\", \\\"{x:1226,y:834,t:1527188813926};\\\", \\\"{x:1240,y:835,t:1527188813943};\\\", \\\"{x:1243,y:836,t:1527188813960};\\\", \\\"{x:1243,y:837,t:1527188813976};\\\", \\\"{x:1240,y:840,t:1527188814083};\\\", \\\"{x:1235,y:843,t:1527188814093};\\\", \\\"{x:1224,y:846,t:1527188814110};\\\", \\\"{x:1213,y:848,t:1527188814126};\\\", \\\"{x:1207,y:849,t:1527188814143};\\\", \\\"{x:1205,y:849,t:1527188814160};\\\", \\\"{x:1204,y:849,t:1527188814179};\\\", \\\"{x:1203,y:848,t:1527188814195};\\\", \\\"{x:1201,y:847,t:1527188814210};\\\", \\\"{x:1200,y:844,t:1527188814226};\\\", \\\"{x:1200,y:843,t:1527188814325};\\\", \\\"{x:1200,y:841,t:1527188814339};\\\", \\\"{x:1200,y:840,t:1527188814371};\\\", \\\"{x:1200,y:839,t:1527188814395};\\\", \\\"{x:1200,y:838,t:1527188814540};\\\", \\\"{x:1200,y:837,t:1527188814547};\\\", \\\"{x:1201,y:837,t:1527188814560};\\\", \\\"{x:1203,y:835,t:1527188814577};\\\", \\\"{x:1205,y:835,t:1527188814594};\\\", \\\"{x:1205,y:834,t:1527188814701};\\\", \\\"{x:1206,y:833,t:1527188814711};\\\", \\\"{x:1207,y:833,t:1527188814732};\\\", \\\"{x:1208,y:833,t:1527188814744};\\\", \\\"{x:1209,y:833,t:1527188814760};\\\", \\\"{x:1210,y:832,t:1527188814779};\\\", \\\"{x:1211,y:832,t:1527188814843};\\\", \\\"{x:1212,y:832,t:1527188814860};\\\", \\\"{x:1214,y:830,t:1527188814877};\\\", \\\"{x:1215,y:830,t:1527188814893};\\\", \\\"{x:1220,y:828,t:1527188818355};\\\", \\\"{x:1222,y:827,t:1527188818363};\\\", \\\"{x:1223,y:827,t:1527188818378};\\\", \\\"{x:1230,y:825,t:1527188818395};\\\", \\\"{x:1234,y:825,t:1527188818411};\\\", \\\"{x:1237,y:825,t:1527188818428};\\\", \\\"{x:1249,y:825,t:1527188818445};\\\", \\\"{x:1259,y:825,t:1527188818461};\\\", \\\"{x:1267,y:825,t:1527188818479};\\\", \\\"{x:1275,y:824,t:1527188818496};\\\", \\\"{x:1284,y:824,t:1527188818512};\\\", \\\"{x:1288,y:824,t:1527188818528};\\\", \\\"{x:1289,y:823,t:1527188818545};\\\", \\\"{x:1290,y:823,t:1527188818587};\\\", \\\"{x:1291,y:823,t:1527188818603};\\\", \\\"{x:1294,y:823,t:1527188818611};\\\", \\\"{x:1302,y:823,t:1527188818629};\\\", \\\"{x:1312,y:823,t:1527188818645};\\\", \\\"{x:1315,y:823,t:1527188818661};\\\", \\\"{x:1319,y:823,t:1527188818678};\\\", \\\"{x:1321,y:823,t:1527188818699};\\\", \\\"{x:1322,y:823,t:1527188818711};\\\", \\\"{x:1325,y:823,t:1527188818729};\\\", \\\"{x:1330,y:824,t:1527188818745};\\\", \\\"{x:1337,y:826,t:1527188818761};\\\", \\\"{x:1339,y:827,t:1527188818779};\\\", \\\"{x:1346,y:829,t:1527188818795};\\\", \\\"{x:1351,y:830,t:1527188818812};\\\", \\\"{x:1353,y:832,t:1527188818828};\\\", \\\"{x:1355,y:832,t:1527188818846};\\\", \\\"{x:1356,y:832,t:1527188818867};\\\", \\\"{x:1356,y:831,t:1527188819002};\\\", \\\"{x:1355,y:831,t:1527188819123};\\\", \\\"{x:1354,y:831,t:1527188819227};\\\", \\\"{x:1353,y:831,t:1527188819243};\\\", \\\"{x:1352,y:831,t:1527188819251};\\\", \\\"{x:1351,y:831,t:1527188819262};\\\", \\\"{x:1350,y:831,t:1527188819279};\\\", \\\"{x:1346,y:831,t:1527188823771};\\\", \\\"{x:1329,y:821,t:1527188823780};\\\", \\\"{x:1304,y:809,t:1527188823798};\\\", \\\"{x:1290,y:802,t:1527188823814};\\\", \\\"{x:1284,y:797,t:1527188823831};\\\", \\\"{x:1271,y:793,t:1527188823847};\\\", \\\"{x:1255,y:787,t:1527188823864};\\\", \\\"{x:1230,y:778,t:1527188823881};\\\", \\\"{x:1186,y:768,t:1527188823897};\\\", \\\"{x:1141,y:761,t:1527188823914};\\\", \\\"{x:1104,y:749,t:1527188823930};\\\", \\\"{x:1089,y:744,t:1527188823947};\\\", \\\"{x:1077,y:739,t:1527188823963};\\\", \\\"{x:1067,y:734,t:1527188823980};\\\", \\\"{x:1046,y:723,t:1527188823998};\\\", \\\"{x:1020,y:712,t:1527188824014};\\\", \\\"{x:998,y:701,t:1527188824031};\\\", \\\"{x:981,y:694,t:1527188824048};\\\", \\\"{x:966,y:688,t:1527188824064};\\\", \\\"{x:953,y:683,t:1527188824081};\\\", \\\"{x:930,y:677,t:1527188824097};\\\", \\\"{x:899,y:672,t:1527188824115};\\\", \\\"{x:888,y:669,t:1527188824131};\\\", \\\"{x:880,y:668,t:1527188824148};\\\", \\\"{x:879,y:668,t:1527188824165};\\\", \\\"{x:877,y:668,t:1527188824187};\\\", \\\"{x:876,y:668,t:1527188824197};\\\", \\\"{x:861,y:667,t:1527188824214};\\\", \\\"{x:838,y:667,t:1527188824230};\\\", \\\"{x:807,y:667,t:1527188824247};\\\", \\\"{x:774,y:665,t:1527188824265};\\\", \\\"{x:746,y:663,t:1527188824280};\\\", \\\"{x:725,y:663,t:1527188824297};\\\", \\\"{x:694,y:663,t:1527188824315};\\\", \\\"{x:671,y:663,t:1527188824331};\\\", \\\"{x:648,y:663,t:1527188824347};\\\", \\\"{x:628,y:663,t:1527188824364};\\\", \\\"{x:612,y:663,t:1527188824380};\\\", \\\"{x:598,y:663,t:1527188824397};\\\", \\\"{x:580,y:661,t:1527188824415};\\\", \\\"{x:556,y:658,t:1527188824430};\\\", \\\"{x:510,y:658,t:1527188824448};\\\", \\\"{x:429,y:658,t:1527188824464};\\\", \\\"{x:388,y:658,t:1527188824480};\\\", \\\"{x:372,y:657,t:1527188824497};\\\", \\\"{x:365,y:657,t:1527188824514};\\\", \\\"{x:358,y:657,t:1527188824530};\\\", \\\"{x:344,y:658,t:1527188824548};\\\", \\\"{x:327,y:659,t:1527188824565};\\\", \\\"{x:311,y:659,t:1527188824580};\\\", \\\"{x:291,y:659,t:1527188824598};\\\", \\\"{x:279,y:659,t:1527188824614};\\\", \\\"{x:274,y:659,t:1527188824630};\\\", \\\"{x:273,y:659,t:1527188824648};\\\", \\\"{x:270,y:659,t:1527188824699};\\\", \\\"{x:268,y:657,t:1527188824714};\\\", \\\"{x:265,y:654,t:1527188824730};\\\", \\\"{x:258,y:649,t:1527188824748};\\\", \\\"{x:249,y:635,t:1527188824764};\\\", \\\"{x:234,y:619,t:1527188824781};\\\", \\\"{x:208,y:601,t:1527188824805};\\\", \\\"{x:186,y:596,t:1527188824821};\\\", \\\"{x:169,y:593,t:1527188824838};\\\", \\\"{x:165,y:592,t:1527188824854};\\\", \\\"{x:165,y:597,t:1527188824938};\\\", \\\"{x:165,y:607,t:1527188824954};\\\", \\\"{x:170,y:612,t:1527188824970};\\\", \\\"{x:178,y:619,t:1527188824988};\\\", \\\"{x:189,y:623,t:1527188825005};\\\", \\\"{x:198,y:624,t:1527188825021};\\\", \\\"{x:203,y:624,t:1527188825037};\\\", \\\"{x:206,y:624,t:1527188825054};\\\", \\\"{x:208,y:623,t:1527188825083};\\\", \\\"{x:210,y:617,t:1527188825091};\\\", \\\"{x:212,y:610,t:1527188825105};\\\", \\\"{x:219,y:599,t:1527188825121};\\\", \\\"{x:229,y:588,t:1527188825137};\\\", \\\"{x:258,y:571,t:1527188825155};\\\", \\\"{x:275,y:564,t:1527188825171};\\\", \\\"{x:294,y:560,t:1527188825188};\\\", \\\"{x:303,y:560,t:1527188825205};\\\", \\\"{x:307,y:560,t:1527188825222};\\\", \\\"{x:310,y:560,t:1527188825237};\\\", \\\"{x:313,y:561,t:1527188825254};\\\", \\\"{x:320,y:563,t:1527188825271};\\\", \\\"{x:327,y:565,t:1527188825287};\\\", \\\"{x:329,y:565,t:1527188825304};\\\", \\\"{x:333,y:567,t:1527188825322};\\\", \\\"{x:336,y:570,t:1527188825337};\\\", \\\"{x:341,y:576,t:1527188825355};\\\", \\\"{x:342,y:577,t:1527188825372};\\\", \\\"{x:343,y:578,t:1527188825427};\\\", \\\"{x:344,y:578,t:1527188825443};\\\", \\\"{x:345,y:579,t:1527188825455};\\\", \\\"{x:352,y:579,t:1527188825472};\\\", \\\"{x:367,y:579,t:1527188825488};\\\", \\\"{x:379,y:579,t:1527188825505};\\\", \\\"{x:392,y:579,t:1527188825522};\\\", \\\"{x:399,y:578,t:1527188825539};\\\", \\\"{x:401,y:579,t:1527188825594};\\\", \\\"{x:401,y:585,t:1527188825606};\\\", \\\"{x:401,y:593,t:1527188825622};\\\", \\\"{x:402,y:597,t:1527188825639};\\\", \\\"{x:402,y:598,t:1527188825658};\\\", \\\"{x:402,y:599,t:1527188825671};\\\", \\\"{x:402,y:600,t:1527188825714};\\\", \\\"{x:403,y:602,t:1527188825722};\\\", \\\"{x:404,y:602,t:1527188825763};\\\", \\\"{x:405,y:603,t:1527188825772};\\\", \\\"{x:411,y:603,t:1527188825788};\\\", \\\"{x:428,y:603,t:1527188825805};\\\", \\\"{x:451,y:602,t:1527188825822};\\\", \\\"{x:480,y:602,t:1527188825838};\\\", \\\"{x:496,y:603,t:1527188825855};\\\", \\\"{x:510,y:606,t:1527188825872};\\\", \\\"{x:520,y:606,t:1527188825888};\\\", \\\"{x:523,y:606,t:1527188825904};\\\", \\\"{x:524,y:606,t:1527188825922};\\\", \\\"{x:525,y:606,t:1527188825938};\\\", \\\"{x:530,y:602,t:1527188825956};\\\", \\\"{x:534,y:595,t:1527188825971};\\\", \\\"{x:540,y:583,t:1527188825988};\\\", \\\"{x:541,y:577,t:1527188826006};\\\", \\\"{x:541,y:574,t:1527188826022};\\\", \\\"{x:539,y:571,t:1527188826038};\\\", \\\"{x:526,y:564,t:1527188826055};\\\", \\\"{x:497,y:556,t:1527188826072};\\\", \\\"{x:393,y:549,t:1527188826089};\\\", \\\"{x:269,y:536,t:1527188826106};\\\", \\\"{x:154,y:528,t:1527188826121};\\\", \\\"{x:77,y:522,t:1527188826139};\\\", \\\"{x:74,y:521,t:1527188826155};\\\", \\\"{x:74,y:522,t:1527188826354};\\\", \\\"{x:78,y:526,t:1527188826362};\\\", \\\"{x:86,y:531,t:1527188826372};\\\", \\\"{x:94,y:540,t:1527188826389};\\\", \\\"{x:110,y:551,t:1527188826406};\\\", \\\"{x:117,y:556,t:1527188826421};\\\", \\\"{x:123,y:559,t:1527188826439};\\\", \\\"{x:125,y:561,t:1527188826456};\\\", \\\"{x:125,y:564,t:1527188826471};\\\", \\\"{x:127,y:567,t:1527188826488};\\\", \\\"{x:127,y:568,t:1527188826505};\\\", \\\"{x:128,y:568,t:1527188826555};\\\", \\\"{x:130,y:568,t:1527188826562};\\\", \\\"{x:133,y:568,t:1527188826571};\\\", \\\"{x:143,y:562,t:1527188826589};\\\", \\\"{x:148,y:557,t:1527188826606};\\\", \\\"{x:149,y:556,t:1527188826651};\\\", \\\"{x:150,y:556,t:1527188826667};\\\", \\\"{x:152,y:556,t:1527188826682};\\\", \\\"{x:153,y:556,t:1527188826691};\\\", \\\"{x:154,y:556,t:1527188826707};\\\", \\\"{x:155,y:556,t:1527188826722};\\\", \\\"{x:158,y:556,t:1527188826738};\\\", \\\"{x:158,y:557,t:1527188826756};\\\", \\\"{x:158,y:557,t:1527188826821};\\\", \\\"{x:159,y:558,t:1527188827018};\\\", \\\"{x:167,y:565,t:1527188827026};\\\", \\\"{x:181,y:577,t:1527188827040};\\\", \\\"{x:209,y:596,t:1527188827056};\\\", \\\"{x:258,y:626,t:1527188827073};\\\", \\\"{x:307,y:651,t:1527188827090};\\\", \\\"{x:333,y:667,t:1527188827106};\\\", \\\"{x:350,y:674,t:1527188827122};\\\", \\\"{x:357,y:676,t:1527188827140};\\\", \\\"{x:368,y:680,t:1527188827157};\\\", \\\"{x:385,y:686,t:1527188827173};\\\", \\\"{x:413,y:697,t:1527188827190};\\\", \\\"{x:432,y:705,t:1527188827207};\\\", \\\"{x:441,y:710,t:1527188827223};\\\", \\\"{x:445,y:711,t:1527188827240};\\\", \\\"{x:447,y:711,t:1527188827257};\\\", \\\"{x:450,y:712,t:1527188827282};\\\", \\\"{x:454,y:715,t:1527188827291};\\\", \\\"{x:459,y:718,t:1527188827306};\\\", \\\"{x:466,y:723,t:1527188827323};\\\", \\\"{x:469,y:725,t:1527188827339};\\\", \\\"{x:469,y:726,t:1527188827356};\\\", \\\"{x:470,y:727,t:1527188827395};\\\", \\\"{x:472,y:728,t:1527188827406};\\\", \\\"{x:476,y:728,t:1527188827422};\\\", \\\"{x:477,y:728,t:1527188827443};\\\" ] }, { \\\"rt\\\": 94532, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 449490, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-K -K -K -F -A -12 PM-Z -Z -H -01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:728,t:1527188829771};\\\", \\\"{x:491,y:737,t:1527188829783};\\\", \\\"{x:515,y:759,t:1527188829792};\\\", \\\"{x:553,y:789,t:1527188829808};\\\", \\\"{x:591,y:817,t:1527188829824};\\\", \\\"{x:618,y:837,t:1527188829841};\\\", \\\"{x:651,y:864,t:1527188829858};\\\", \\\"{x:664,y:875,t:1527188829874};\\\", \\\"{x:675,y:882,t:1527188829890};\\\", \\\"{x:686,y:891,t:1527188829908};\\\", \\\"{x:696,y:896,t:1527188829924};\\\", \\\"{x:704,y:903,t:1527188829940};\\\", \\\"{x:706,y:905,t:1527188829958};\\\", \\\"{x:707,y:906,t:1527188829973};\\\", \\\"{x:708,y:906,t:1527188830010};\\\", \\\"{x:709,y:906,t:1527188830024};\\\", \\\"{x:710,y:907,t:1527188830041};\\\", \\\"{x:711,y:908,t:1527188830058};\\\", \\\"{x:718,y:910,t:1527188833431};\\\", \\\"{x:751,y:921,t:1527188833444};\\\", \\\"{x:868,y:980,t:1527188833461};\\\", \\\"{x:1013,y:1030,t:1527188833478};\\\", \\\"{x:1144,y:1060,t:1527188833494};\\\", \\\"{x:1259,y:1091,t:1527188833511};\\\", \\\"{x:1284,y:1097,t:1527188833529};\\\", \\\"{x:1308,y:1097,t:1527188833544};\\\", \\\"{x:1310,y:1094,t:1527188833561};\\\", \\\"{x:1322,y:1089,t:1527188833578};\\\", \\\"{x:1335,y:1084,t:1527188833594};\\\", \\\"{x:1359,y:1073,t:1527188833611};\\\", \\\"{x:1384,y:1065,t:1527188833629};\\\", \\\"{x:1412,y:1060,t:1527188833644};\\\", \\\"{x:1433,y:1057,t:1527188833661};\\\", \\\"{x:1441,y:1054,t:1527188833679};\\\", \\\"{x:1446,y:1054,t:1527188833694};\\\", \\\"{x:1447,y:1054,t:1527188833711};\\\", \\\"{x:1449,y:1053,t:1527188833734};\\\", \\\"{x:1453,y:1049,t:1527188833745};\\\", \\\"{x:1466,y:1038,t:1527188833761};\\\", \\\"{x:1477,y:1028,t:1527188833778};\\\", \\\"{x:1498,y:1017,t:1527188833794};\\\", \\\"{x:1519,y:1008,t:1527188833811};\\\", \\\"{x:1540,y:1003,t:1527188833827};\\\", \\\"{x:1553,y:1000,t:1527188833844};\\\", \\\"{x:1560,y:997,t:1527188833861};\\\", \\\"{x:1569,y:994,t:1527188833878};\\\", \\\"{x:1578,y:991,t:1527188833894};\\\", \\\"{x:1591,y:988,t:1527188833910};\\\", \\\"{x:1593,y:986,t:1527188833928};\\\", \\\"{x:1595,y:985,t:1527188833950};\\\", \\\"{x:1597,y:983,t:1527188833961};\\\", \\\"{x:1608,y:976,t:1527188833978};\\\", \\\"{x:1620,y:966,t:1527188833995};\\\", \\\"{x:1625,y:962,t:1527188834011};\\\", \\\"{x:1626,y:961,t:1527188834027};\\\", \\\"{x:1626,y:958,t:1527188834455};\\\", \\\"{x:1628,y:954,t:1527188834462};\\\", \\\"{x:1628,y:952,t:1527188834477};\\\", \\\"{x:1629,y:950,t:1527188834494};\\\", \\\"{x:1629,y:949,t:1527188834511};\\\", \\\"{x:1629,y:948,t:1527188834559};\\\", \\\"{x:1626,y:948,t:1527188834566};\\\", \\\"{x:1621,y:948,t:1527188834578};\\\", \\\"{x:1616,y:947,t:1527188834594};\\\", \\\"{x:1613,y:946,t:1527188834611};\\\", \\\"{x:1609,y:943,t:1527188834627};\\\", \\\"{x:1609,y:938,t:1527188834644};\\\", \\\"{x:1606,y:934,t:1527188834662};\\\", \\\"{x:1606,y:931,t:1527188834677};\\\", \\\"{x:1606,y:929,t:1527188834695};\\\", \\\"{x:1604,y:923,t:1527188834711};\\\", \\\"{x:1603,y:920,t:1527188834727};\\\", \\\"{x:1602,y:914,t:1527188834745};\\\", \\\"{x:1602,y:909,t:1527188834761};\\\", \\\"{x:1602,y:908,t:1527188834777};\\\", \\\"{x:1601,y:905,t:1527188834795};\\\", \\\"{x:1599,y:904,t:1527188834811};\\\", \\\"{x:1598,y:899,t:1527188834828};\\\", \\\"{x:1598,y:889,t:1527188834844};\\\", \\\"{x:1598,y:885,t:1527188834862};\\\", \\\"{x:1596,y:882,t:1527188834877};\\\", \\\"{x:1595,y:881,t:1527188834895};\\\", \\\"{x:1595,y:877,t:1527188834911};\\\", \\\"{x:1600,y:869,t:1527188834927};\\\", \\\"{x:1600,y:865,t:1527188834944};\\\", \\\"{x:1605,y:856,t:1527188834961};\\\", \\\"{x:1606,y:852,t:1527188834977};\\\", \\\"{x:1609,y:846,t:1527188834994};\\\", \\\"{x:1613,y:835,t:1527188835011};\\\", \\\"{x:1615,y:827,t:1527188835027};\\\", \\\"{x:1621,y:821,t:1527188835044};\\\", \\\"{x:1622,y:818,t:1527188835061};\\\", \\\"{x:1624,y:814,t:1527188835077};\\\", \\\"{x:1626,y:810,t:1527188835094};\\\", \\\"{x:1627,y:808,t:1527188835112};\\\", \\\"{x:1627,y:806,t:1527188835128};\\\", \\\"{x:1627,y:803,t:1527188835144};\\\", \\\"{x:1627,y:801,t:1527188835162};\\\", \\\"{x:1627,y:799,t:1527188835177};\\\", \\\"{x:1627,y:796,t:1527188835194};\\\", \\\"{x:1626,y:790,t:1527188835211};\\\", \\\"{x:1625,y:786,t:1527188835228};\\\", \\\"{x:1622,y:779,t:1527188835244};\\\", \\\"{x:1620,y:773,t:1527188835261};\\\", \\\"{x:1617,y:766,t:1527188835278};\\\", \\\"{x:1616,y:760,t:1527188835295};\\\", \\\"{x:1612,y:750,t:1527188835310};\\\", \\\"{x:1609,y:741,t:1527188835327};\\\", \\\"{x:1608,y:733,t:1527188835345};\\\", \\\"{x:1608,y:730,t:1527188835361};\\\", \\\"{x:1608,y:723,t:1527188835377};\\\", \\\"{x:1608,y:717,t:1527188835394};\\\", \\\"{x:1608,y:709,t:1527188835411};\\\", \\\"{x:1608,y:703,t:1527188835428};\\\", \\\"{x:1609,y:697,t:1527188835445};\\\", \\\"{x:1610,y:694,t:1527188835460};\\\", \\\"{x:1610,y:692,t:1527188835477};\\\", \\\"{x:1610,y:691,t:1527188835495};\\\", \\\"{x:1610,y:690,t:1527188835510};\\\", \\\"{x:1610,y:687,t:1527188835527};\\\", \\\"{x:1611,y:684,t:1527188835544};\\\", \\\"{x:1612,y:684,t:1527188835562};\\\", \\\"{x:1612,y:682,t:1527188835578};\\\", \\\"{x:1612,y:681,t:1527188835594};\\\", \\\"{x:1612,y:680,t:1527188835623};\\\", \\\"{x:1612,y:678,t:1527188835631};\\\", \\\"{x:1613,y:677,t:1527188835644};\\\", \\\"{x:1613,y:676,t:1527188835660};\\\", \\\"{x:1614,y:674,t:1527188835678};\\\", \\\"{x:1614,y:672,t:1527188835703};\\\", \\\"{x:1614,y:671,t:1527188835775};\\\", \\\"{x:1614,y:669,t:1527188835782};\\\", \\\"{x:1614,y:668,t:1527188835798};\\\", \\\"{x:1614,y:667,t:1527188835815};\\\", \\\"{x:1614,y:666,t:1527188835827};\\\", \\\"{x:1614,y:664,t:1527188835844};\\\", \\\"{x:1614,y:662,t:1527188835860};\\\", \\\"{x:1614,y:661,t:1527188835877};\\\", \\\"{x:1614,y:658,t:1527188835895};\\\", \\\"{x:1614,y:656,t:1527188835911};\\\", \\\"{x:1614,y:655,t:1527188835927};\\\", \\\"{x:1614,y:652,t:1527188835944};\\\", \\\"{x:1614,y:651,t:1527188835961};\\\", \\\"{x:1613,y:646,t:1527188835977};\\\", \\\"{x:1613,y:644,t:1527188835994};\\\", \\\"{x:1613,y:643,t:1527188836010};\\\", \\\"{x:1613,y:637,t:1527188836027};\\\", \\\"{x:1613,y:629,t:1527188836044};\\\", \\\"{x:1613,y:626,t:1527188836061};\\\", \\\"{x:1613,y:622,t:1527188836077};\\\", \\\"{x:1613,y:619,t:1527188836094};\\\", \\\"{x:1613,y:618,t:1527188836111};\\\", \\\"{x:1613,y:617,t:1527188836151};\\\", \\\"{x:1613,y:613,t:1527188836167};\\\", \\\"{x:1613,y:612,t:1527188836191};\\\", \\\"{x:1613,y:611,t:1527188836199};\\\", \\\"{x:1613,y:610,t:1527188836210};\\\", \\\"{x:1613,y:608,t:1527188836228};\\\", \\\"{x:1613,y:603,t:1527188836245};\\\", \\\"{x:1613,y:599,t:1527188836261};\\\", \\\"{x:1613,y:597,t:1527188836277};\\\", \\\"{x:1613,y:593,t:1527188836295};\\\", \\\"{x:1613,y:588,t:1527188836310};\\\", \\\"{x:1613,y:581,t:1527188836327};\\\", \\\"{x:1613,y:579,t:1527188836345};\\\", \\\"{x:1613,y:578,t:1527188836360};\\\", \\\"{x:1613,y:576,t:1527188836415};\\\", \\\"{x:1613,y:575,t:1527188836428};\\\", \\\"{x:1612,y:572,t:1527188836445};\\\", \\\"{x:1611,y:571,t:1527188836460};\\\", \\\"{x:1611,y:570,t:1527188836551};\\\", \\\"{x:1610,y:569,t:1527188836663};\\\", \\\"{x:1605,y:572,t:1527188840455};\\\", \\\"{x:1595,y:591,t:1527188840462};\\\", \\\"{x:1586,y:605,t:1527188840476};\\\", \\\"{x:1572,y:632,t:1527188840493};\\\", \\\"{x:1560,y:642,t:1527188840509};\\\", \\\"{x:1554,y:652,t:1527188840526};\\\", \\\"{x:1552,y:654,t:1527188840607};\\\", \\\"{x:1548,y:659,t:1527188840614};\\\", \\\"{x:1544,y:664,t:1527188840627};\\\", \\\"{x:1535,y:669,t:1527188840644};\\\", \\\"{x:1534,y:670,t:1527188840660};\\\", \\\"{x:1532,y:670,t:1527188840751};\\\", \\\"{x:1531,y:670,t:1527188840760};\\\", \\\"{x:1529,y:669,t:1527188840848};\\\", \\\"{x:1528,y:666,t:1527188840860};\\\", \\\"{x:1526,y:662,t:1527188840877};\\\", \\\"{x:1524,y:660,t:1527188840894};\\\", \\\"{x:1522,y:658,t:1527188840910};\\\", \\\"{x:1520,y:654,t:1527188840927};\\\", \\\"{x:1520,y:648,t:1527188840943};\\\", \\\"{x:1520,y:644,t:1527188840961};\\\", \\\"{x:1520,y:639,t:1527188840977};\\\", \\\"{x:1518,y:635,t:1527188840994};\\\", \\\"{x:1517,y:633,t:1527188841010};\\\", \\\"{x:1517,y:632,t:1527188841367};\\\", \\\"{x:1516,y:630,t:1527188841376};\\\", \\\"{x:1516,y:629,t:1527188841394};\\\", \\\"{x:1515,y:628,t:1527188841415};\\\", \\\"{x:1513,y:628,t:1527188843703};\\\", \\\"{x:1505,y:628,t:1527188843711};\\\", \\\"{x:1498,y:625,t:1527188843725};\\\", \\\"{x:1495,y:624,t:1527188843742};\\\", \\\"{x:1498,y:624,t:1527188844071};\\\", \\\"{x:1499,y:624,t:1527188844079};\\\", \\\"{x:1502,y:624,t:1527188844092};\\\", \\\"{x:1503,y:625,t:1527188844135};\\\", \\\"{x:1497,y:629,t:1527188844143};\\\", \\\"{x:1430,y:640,t:1527188844160};\\\", \\\"{x:1270,y:640,t:1527188844176};\\\", \\\"{x:1033,y:640,t:1527188844192};\\\", \\\"{x:805,y:627,t:1527188844210};\\\", \\\"{x:627,y:613,t:1527188844225};\\\", \\\"{x:526,y:596,t:1527188844243};\\\", \\\"{x:516,y:595,t:1527188844260};\\\", \\\"{x:515,y:595,t:1527188844319};\\\", \\\"{x:510,y:595,t:1527188844327};\\\", \\\"{x:504,y:595,t:1527188844342};\\\", \\\"{x:491,y:594,t:1527188844359};\\\", \\\"{x:447,y:594,t:1527188844374};\\\", \\\"{x:415,y:594,t:1527188844391};\\\", \\\"{x:395,y:594,t:1527188844407};\\\", \\\"{x:393,y:593,t:1527188844425};\\\", \\\"{x:393,y:591,t:1527188844535};\\\", \\\"{x:395,y:582,t:1527188844543};\\\", \\\"{x:396,y:576,t:1527188844558};\\\", \\\"{x:406,y:557,t:1527188844575};\\\", \\\"{x:415,y:550,t:1527188844592};\\\", \\\"{x:417,y:547,t:1527188844607};\\\", \\\"{x:418,y:547,t:1527188844625};\\\", \\\"{x:419,y:548,t:1527188844735};\\\", \\\"{x:419,y:549,t:1527188844743};\\\", \\\"{x:418,y:552,t:1527188844758};\\\", \\\"{x:413,y:559,t:1527188844775};\\\", \\\"{x:411,y:573,t:1527188844792};\\\", \\\"{x:408,y:587,t:1527188844809};\\\", \\\"{x:404,y:599,t:1527188844825};\\\", \\\"{x:403,y:604,t:1527188844841};\\\", \\\"{x:403,y:606,t:1527188844858};\\\", \\\"{x:402,y:606,t:1527188844879};\\\", \\\"{x:401,y:609,t:1527188844942};\\\", \\\"{x:400,y:609,t:1527188844959};\\\", \\\"{x:394,y:611,t:1527188844974};\\\", \\\"{x:392,y:613,t:1527188844992};\\\", \\\"{x:392,y:611,t:1527188845183};\\\", \\\"{x:394,y:607,t:1527188845193};\\\", \\\"{x:394,y:605,t:1527188845208};\\\", \\\"{x:395,y:603,t:1527188845226};\\\", \\\"{x:396,y:602,t:1527188845615};\\\", \\\"{x:401,y:600,t:1527188845626};\\\", \\\"{x:417,y:597,t:1527188845643};\\\", \\\"{x:448,y:592,t:1527188845659};\\\", \\\"{x:488,y:591,t:1527188845675};\\\", \\\"{x:578,y:587,t:1527188845694};\\\", \\\"{x:682,y:577,t:1527188845709};\\\", \\\"{x:788,y:577,t:1527188845725};\\\", \\\"{x:926,y:577,t:1527188845742};\\\", \\\"{x:1018,y:577,t:1527188845759};\\\", \\\"{x:1063,y:577,t:1527188845775};\\\", \\\"{x:1091,y:577,t:1527188845792};\\\", \\\"{x:1112,y:575,t:1527188845809};\\\", \\\"{x:1126,y:575,t:1527188845826};\\\", \\\"{x:1140,y:575,t:1527188845843};\\\", \\\"{x:1158,y:574,t:1527188845858};\\\", \\\"{x:1186,y:574,t:1527188845876};\\\", \\\"{x:1211,y:574,t:1527188845893};\\\", \\\"{x:1230,y:575,t:1527188845908};\\\", \\\"{x:1252,y:575,t:1527188845926};\\\", \\\"{x:1264,y:579,t:1527188845943};\\\", \\\"{x:1265,y:579,t:1527188845966};\\\", \\\"{x:1265,y:580,t:1527188845976};\\\", \\\"{x:1274,y:584,t:1527188845993};\\\", \\\"{x:1286,y:589,t:1527188846008};\\\", \\\"{x:1305,y:595,t:1527188846025};\\\", \\\"{x:1335,y:605,t:1527188846042};\\\", \\\"{x:1395,y:617,t:1527188846060};\\\", \\\"{x:1450,y:629,t:1527188846076};\\\", \\\"{x:1475,y:639,t:1527188846093};\\\", \\\"{x:1479,y:640,t:1527188846110};\\\", \\\"{x:1480,y:640,t:1527188846127};\\\", \\\"{x:1482,y:640,t:1527188846167};\\\", \\\"{x:1483,y:640,t:1527188846176};\\\", \\\"{x:1485,y:640,t:1527188846192};\\\", \\\"{x:1497,y:641,t:1527188846210};\\\", \\\"{x:1501,y:641,t:1527188846225};\\\", \\\"{x:1502,y:641,t:1527188846243};\\\", \\\"{x:1504,y:641,t:1527188846263};\\\", \\\"{x:1505,y:641,t:1527188846275};\\\", \\\"{x:1509,y:641,t:1527188846293};\\\", \\\"{x:1521,y:641,t:1527188846310};\\\", \\\"{x:1531,y:640,t:1527188846325};\\\", \\\"{x:1540,y:638,t:1527188846342};\\\", \\\"{x:1541,y:637,t:1527188846399};\\\", \\\"{x:1541,y:635,t:1527188846409};\\\", \\\"{x:1540,y:635,t:1527188846439};\\\", \\\"{x:1539,y:635,t:1527188846487};\\\", \\\"{x:1539,y:634,t:1527188846494};\\\", \\\"{x:1537,y:633,t:1527188846510};\\\", \\\"{x:1531,y:629,t:1527188846526};\\\", \\\"{x:1526,y:629,t:1527188846542};\\\", \\\"{x:1524,y:627,t:1527188846670};\\\", \\\"{x:1523,y:627,t:1527188846678};\\\", \\\"{x:1521,y:626,t:1527188846693};\\\", \\\"{x:1518,y:625,t:1527188846710};\\\", \\\"{x:1517,y:625,t:1527188846725};\\\", \\\"{x:1514,y:624,t:1527188846743};\\\", \\\"{x:1502,y:628,t:1527188850151};\\\", \\\"{x:1479,y:636,t:1527188850162};\\\", \\\"{x:1371,y:648,t:1527188850179};\\\", \\\"{x:1248,y:658,t:1527188850195};\\\", \\\"{x:1141,y:664,t:1527188850212};\\\", \\\"{x:1069,y:666,t:1527188850229};\\\", \\\"{x:1042,y:667,t:1527188850245};\\\", \\\"{x:1022,y:670,t:1527188850262};\\\", \\\"{x:999,y:675,t:1527188850279};\\\", \\\"{x:972,y:675,t:1527188850295};\\\", \\\"{x:933,y:675,t:1527188850312};\\\", \\\"{x:852,y:675,t:1527188850329};\\\", \\\"{x:810,y:672,t:1527188850344};\\\", \\\"{x:789,y:667,t:1527188850362};\\\", \\\"{x:780,y:665,t:1527188850379};\\\", \\\"{x:773,y:662,t:1527188850395};\\\", \\\"{x:763,y:659,t:1527188850412};\\\", \\\"{x:746,y:658,t:1527188850429};\\\", \\\"{x:734,y:653,t:1527188850444};\\\", \\\"{x:707,y:647,t:1527188850462};\\\", \\\"{x:657,y:638,t:1527188850479};\\\", \\\"{x:588,y:635,t:1527188850495};\\\", \\\"{x:513,y:635,t:1527188850510};\\\", \\\"{x:473,y:635,t:1527188850528};\\\", \\\"{x:463,y:634,t:1527188850544};\\\", \\\"{x:459,y:634,t:1527188850614};\\\", \\\"{x:452,y:634,t:1527188850630};\\\", \\\"{x:400,y:631,t:1527188850646};\\\", \\\"{x:384,y:626,t:1527188850663};\\\", \\\"{x:378,y:625,t:1527188850680};\\\", \\\"{x:378,y:618,t:1527188850807};\\\", \\\"{x:378,y:614,t:1527188850814};\\\", \\\"{x:373,y:609,t:1527188850830};\\\", \\\"{x:371,y:596,t:1527188850846};\\\", \\\"{x:372,y:590,t:1527188850863};\\\", \\\"{x:373,y:586,t:1527188850880};\\\", \\\"{x:376,y:583,t:1527188850896};\\\", \\\"{x:378,y:582,t:1527188850990};\\\", \\\"{x:378,y:581,t:1527188850999};\\\", \\\"{x:379,y:581,t:1527188851406};\\\", \\\"{x:387,y:581,t:1527188851414};\\\", \\\"{x:397,y:586,t:1527188851430};\\\", \\\"{x:420,y:601,t:1527188851447};\\\", \\\"{x:428,y:606,t:1527188851464};\\\", \\\"{x:432,y:608,t:1527188851480};\\\", \\\"{x:432,y:609,t:1527188851518};\\\", \\\"{x:434,y:609,t:1527188851534};\\\", \\\"{x:437,y:611,t:1527188851547};\\\", \\\"{x:456,y:620,t:1527188851564};\\\", \\\"{x:476,y:632,t:1527188851581};\\\", \\\"{x:507,y:640,t:1527188851598};\\\", \\\"{x:557,y:655,t:1527188851614};\\\", \\\"{x:606,y:661,t:1527188851630};\\\", \\\"{x:618,y:664,t:1527188851647};\\\", \\\"{x:619,y:665,t:1527188851664};\\\", \\\"{x:616,y:663,t:1527188851758};\\\", \\\"{x:608,y:658,t:1527188851767};\\\", \\\"{x:598,y:653,t:1527188851781};\\\", \\\"{x:566,y:643,t:1527188851797};\\\", \\\"{x:513,y:635,t:1527188851814};\\\", \\\"{x:446,y:635,t:1527188851830};\\\", \\\"{x:346,y:627,t:1527188851847};\\\", \\\"{x:316,y:623,t:1527188851864};\\\", \\\"{x:310,y:620,t:1527188851880};\\\", \\\"{x:309,y:620,t:1527188851896};\\\", \\\"{x:308,y:620,t:1527188851990};\\\", \\\"{x:308,y:617,t:1527188851999};\\\", \\\"{x:315,y:613,t:1527188852014};\\\", \\\"{x:328,y:608,t:1527188852032};\\\", \\\"{x:339,y:607,t:1527188852048};\\\", \\\"{x:348,y:607,t:1527188852063};\\\", \\\"{x:356,y:607,t:1527188852081};\\\", \\\"{x:361,y:607,t:1527188852098};\\\", \\\"{x:366,y:606,t:1527188852113};\\\", \\\"{x:372,y:606,t:1527188852131};\\\", \\\"{x:382,y:604,t:1527188852148};\\\", \\\"{x:386,y:604,t:1527188852164};\\\", \\\"{x:387,y:602,t:1527188852606};\\\", \\\"{x:387,y:600,t:1527188852615};\\\", \\\"{x:387,y:599,t:1527188852726};\\\", \\\"{x:387,y:597,t:1527188852735};\\\", \\\"{x:390,y:595,t:1527188852748};\\\", \\\"{x:405,y:597,t:1527188852765};\\\", \\\"{x:445,y:605,t:1527188852781};\\\", \\\"{x:521,y:633,t:1527188852798};\\\", \\\"{x:616,y:672,t:1527188852814};\\\", \\\"{x:639,y:688,t:1527188852831};\\\", \\\"{x:659,y:703,t:1527188852848};\\\", \\\"{x:673,y:717,t:1527188852865};\\\", \\\"{x:689,y:732,t:1527188852882};\\\", \\\"{x:711,y:745,t:1527188852897};\\\", \\\"{x:743,y:765,t:1527188852914};\\\", \\\"{x:769,y:784,t:1527188852932};\\\", \\\"{x:801,y:808,t:1527188852948};\\\", \\\"{x:823,y:824,t:1527188852964};\\\", \\\"{x:839,y:839,t:1527188852981};\\\", \\\"{x:849,y:844,t:1527188852997};\\\", \\\"{x:849,y:845,t:1527188853015};\\\", \\\"{x:850,y:845,t:1527188855206};\\\", \\\"{x:861,y:845,t:1527188855217};\\\", \\\"{x:900,y:833,t:1527188855233};\\\", \\\"{x:945,y:821,t:1527188855250};\\\", \\\"{x:979,y:817,t:1527188855267};\\\", \\\"{x:1024,y:803,t:1527188855283};\\\", \\\"{x:1087,y:789,t:1527188855300};\\\", \\\"{x:1124,y:761,t:1527188855317};\\\", \\\"{x:1153,y:740,t:1527188855333};\\\", \\\"{x:1173,y:722,t:1527188855350};\\\", \\\"{x:1174,y:720,t:1527188855367};\\\", \\\"{x:1175,y:719,t:1527188855383};\\\", \\\"{x:1175,y:717,t:1527188855400};\\\", \\\"{x:1177,y:715,t:1527188855417};\\\", \\\"{x:1181,y:710,t:1527188855434};\\\", \\\"{x:1196,y:697,t:1527188855450};\\\", \\\"{x:1219,y:684,t:1527188855467};\\\", \\\"{x:1250,y:678,t:1527188855484};\\\", \\\"{x:1278,y:673,t:1527188855500};\\\", \\\"{x:1316,y:671,t:1527188855516};\\\", \\\"{x:1385,y:675,t:1527188855534};\\\", \\\"{x:1458,y:677,t:1527188855550};\\\", \\\"{x:1501,y:677,t:1527188855567};\\\", \\\"{x:1527,y:676,t:1527188855584};\\\", \\\"{x:1552,y:680,t:1527188855600};\\\", \\\"{x:1572,y:681,t:1527188855617};\\\", \\\"{x:1578,y:682,t:1527188855634};\\\", \\\"{x:1579,y:682,t:1527188855991};\\\", \\\"{x:1581,y:681,t:1527188856002};\\\", \\\"{x:1575,y:680,t:1527188856079};\\\", \\\"{x:1564,y:680,t:1527188856086};\\\", \\\"{x:1550,y:679,t:1527188856101};\\\", \\\"{x:1525,y:677,t:1527188856117};\\\", \\\"{x:1510,y:677,t:1527188856135};\\\", \\\"{x:1505,y:676,t:1527188856151};\\\", \\\"{x:1505,y:675,t:1527188856174};\\\", \\\"{x:1505,y:677,t:1527188856319};\\\", \\\"{x:1505,y:684,t:1527188856334};\\\", \\\"{x:1508,y:698,t:1527188856351};\\\", \\\"{x:1509,y:703,t:1527188856368};\\\", \\\"{x:1509,y:706,t:1527188856384};\\\", \\\"{x:1510,y:707,t:1527188856401};\\\", \\\"{x:1510,y:709,t:1527188856418};\\\", \\\"{x:1510,y:713,t:1527188856434};\\\", \\\"{x:1510,y:717,t:1527188856451};\\\", \\\"{x:1509,y:726,t:1527188856468};\\\", \\\"{x:1509,y:734,t:1527188856484};\\\", \\\"{x:1509,y:741,t:1527188856501};\\\", \\\"{x:1509,y:744,t:1527188856518};\\\", \\\"{x:1509,y:745,t:1527188856558};\\\", \\\"{x:1509,y:748,t:1527188856568};\\\", \\\"{x:1509,y:750,t:1527188856584};\\\", \\\"{x:1509,y:752,t:1527188856601};\\\", \\\"{x:1510,y:754,t:1527188856619};\\\", \\\"{x:1510,y:755,t:1527188856635};\\\", \\\"{x:1511,y:757,t:1527188856651};\\\", \\\"{x:1511,y:759,t:1527188856679};\\\", \\\"{x:1511,y:761,t:1527188856686};\\\", \\\"{x:1511,y:762,t:1527188856701};\\\", \\\"{x:1511,y:770,t:1527188856718};\\\", \\\"{x:1511,y:777,t:1527188856735};\\\", \\\"{x:1510,y:781,t:1527188856751};\\\", \\\"{x:1510,y:785,t:1527188856768};\\\", \\\"{x:1511,y:791,t:1527188856785};\\\", \\\"{x:1511,y:796,t:1527188856801};\\\", \\\"{x:1512,y:803,t:1527188856818};\\\", \\\"{x:1515,y:808,t:1527188856835};\\\", \\\"{x:1515,y:814,t:1527188856851};\\\", \\\"{x:1515,y:817,t:1527188856868};\\\", \\\"{x:1515,y:819,t:1527188856885};\\\", \\\"{x:1515,y:821,t:1527188856901};\\\", \\\"{x:1515,y:825,t:1527188856918};\\\", \\\"{x:1515,y:833,t:1527188856935};\\\", \\\"{x:1515,y:836,t:1527188856951};\\\", \\\"{x:1515,y:838,t:1527188856968};\\\", \\\"{x:1515,y:840,t:1527188856985};\\\", \\\"{x:1514,y:843,t:1527188857002};\\\", \\\"{x:1514,y:846,t:1527188857018};\\\", \\\"{x:1514,y:849,t:1527188857035};\\\", \\\"{x:1514,y:854,t:1527188857051};\\\", \\\"{x:1513,y:860,t:1527188857068};\\\", \\\"{x:1513,y:864,t:1527188857085};\\\", \\\"{x:1513,y:868,t:1527188857101};\\\", \\\"{x:1513,y:876,t:1527188857118};\\\", \\\"{x:1511,y:882,t:1527188857136};\\\", \\\"{x:1511,y:884,t:1527188857152};\\\", \\\"{x:1511,y:888,t:1527188857168};\\\", \\\"{x:1511,y:891,t:1527188857185};\\\", \\\"{x:1512,y:892,t:1527188857202};\\\", \\\"{x:1513,y:893,t:1527188857218};\\\", \\\"{x:1514,y:895,t:1527188857235};\\\", \\\"{x:1514,y:896,t:1527188857252};\\\", \\\"{x:1514,y:901,t:1527188857268};\\\", \\\"{x:1515,y:904,t:1527188857285};\\\", \\\"{x:1516,y:908,t:1527188857302};\\\", \\\"{x:1517,y:909,t:1527188857326};\\\", \\\"{x:1517,y:910,t:1527188857335};\\\", \\\"{x:1518,y:911,t:1527188857352};\\\", \\\"{x:1518,y:914,t:1527188857368};\\\", \\\"{x:1518,y:917,t:1527188857385};\\\", \\\"{x:1518,y:919,t:1527188857402};\\\", \\\"{x:1518,y:922,t:1527188857418};\\\", \\\"{x:1518,y:924,t:1527188857435};\\\", \\\"{x:1518,y:926,t:1527188857452};\\\", \\\"{x:1518,y:928,t:1527188857468};\\\", \\\"{x:1518,y:930,t:1527188857485};\\\", \\\"{x:1518,y:933,t:1527188857502};\\\", \\\"{x:1517,y:936,t:1527188857518};\\\", \\\"{x:1517,y:938,t:1527188857535};\\\", \\\"{x:1516,y:941,t:1527188857552};\\\", \\\"{x:1516,y:942,t:1527188857568};\\\", \\\"{x:1516,y:944,t:1527188857590};\\\", \\\"{x:1516,y:945,t:1527188857614};\\\", \\\"{x:1516,y:947,t:1527188857630};\\\", \\\"{x:1516,y:948,t:1527188857638};\\\", \\\"{x:1516,y:950,t:1527188857653};\\\", \\\"{x:1516,y:952,t:1527188857669};\\\", \\\"{x:1516,y:953,t:1527188857694};\\\", \\\"{x:1516,y:954,t:1527188857790};\\\", \\\"{x:1515,y:955,t:1527188857802};\\\", \\\"{x:1515,y:956,t:1527188857822};\\\", \\\"{x:1515,y:957,t:1527188857838};\\\", \\\"{x:1515,y:958,t:1527188857854};\\\", \\\"{x:1515,y:959,t:1527188857902};\\\", \\\"{x:1515,y:961,t:1527188857942};\\\", \\\"{x:1514,y:961,t:1527188865127};\\\", \\\"{x:1511,y:961,t:1527188865239};\\\", \\\"{x:1508,y:959,t:1527188865246};\\\", \\\"{x:1506,y:956,t:1527188865259};\\\", \\\"{x:1505,y:955,t:1527188865275};\\\", \\\"{x:1504,y:953,t:1527188865291};\\\", \\\"{x:1503,y:951,t:1527188865309};\\\", \\\"{x:1501,y:950,t:1527188865325};\\\", \\\"{x:1501,y:949,t:1527188865351};\\\", \\\"{x:1500,y:947,t:1527188865391};\\\", \\\"{x:1499,y:945,t:1527188865398};\\\", \\\"{x:1499,y:943,t:1527188865409};\\\", \\\"{x:1496,y:940,t:1527188865424};\\\", \\\"{x:1492,y:933,t:1527188865442};\\\", \\\"{x:1491,y:931,t:1527188865459};\\\", \\\"{x:1490,y:928,t:1527188865475};\\\", \\\"{x:1488,y:925,t:1527188865492};\\\", \\\"{x:1486,y:923,t:1527188865509};\\\", \\\"{x:1484,y:921,t:1527188865525};\\\", \\\"{x:1483,y:917,t:1527188865541};\\\", \\\"{x:1482,y:910,t:1527188865558};\\\", \\\"{x:1481,y:909,t:1527188865575};\\\", \\\"{x:1481,y:907,t:1527188865592};\\\", \\\"{x:1481,y:904,t:1527188865609};\\\", \\\"{x:1481,y:900,t:1527188865626};\\\", \\\"{x:1482,y:896,t:1527188865642};\\\", \\\"{x:1482,y:892,t:1527188865659};\\\", \\\"{x:1482,y:887,t:1527188865675};\\\", \\\"{x:1482,y:883,t:1527188865692};\\\", \\\"{x:1483,y:882,t:1527188865708};\\\", \\\"{x:1483,y:881,t:1527188865725};\\\", \\\"{x:1483,y:880,t:1527188865766};\\\", \\\"{x:1483,y:879,t:1527188865782};\\\", \\\"{x:1483,y:878,t:1527188865791};\\\", \\\"{x:1483,y:877,t:1527188865910};\\\", \\\"{x:1483,y:876,t:1527188865925};\\\", \\\"{x:1484,y:874,t:1527188865941};\\\", \\\"{x:1485,y:872,t:1527188865958};\\\", \\\"{x:1485,y:869,t:1527188865975};\\\", \\\"{x:1486,y:866,t:1527188865993};\\\", \\\"{x:1486,y:864,t:1527188866009};\\\", \\\"{x:1486,y:863,t:1527188866025};\\\", \\\"{x:1486,y:862,t:1527188866071};\\\", \\\"{x:1486,y:860,t:1527188866078};\\\", \\\"{x:1486,y:858,t:1527188866093};\\\", \\\"{x:1488,y:854,t:1527188866109};\\\", \\\"{x:1487,y:852,t:1527188866415};\\\", \\\"{x:1487,y:851,t:1527188866425};\\\", \\\"{x:1486,y:851,t:1527188866454};\\\", \\\"{x:1485,y:850,t:1527188866486};\\\", \\\"{x:1484,y:850,t:1527188866502};\\\", \\\"{x:1484,y:848,t:1527188866534};\\\", \\\"{x:1468,y:839,t:1527188868974};\\\", \\\"{x:1445,y:817,t:1527188868982};\\\", \\\"{x:1406,y:790,t:1527188868994};\\\", \\\"{x:1302,y:751,t:1527188869010};\\\", \\\"{x:1171,y:730,t:1527188869027};\\\", \\\"{x:1060,y:714,t:1527188869045};\\\", \\\"{x:958,y:700,t:1527188869061};\\\", \\\"{x:922,y:691,t:1527188869078};\\\", \\\"{x:905,y:676,t:1527188869094};\\\", \\\"{x:892,y:670,t:1527188869111};\\\", \\\"{x:878,y:664,t:1527188869128};\\\", \\\"{x:850,y:652,t:1527188869144};\\\", \\\"{x:787,y:638,t:1527188869162};\\\", \\\"{x:702,y:619,t:1527188869177};\\\", \\\"{x:600,y:593,t:1527188869195};\\\", \\\"{x:515,y:570,t:1527188869212};\\\", \\\"{x:481,y:554,t:1527188869228};\\\", \\\"{x:477,y:552,t:1527188869238};\\\", \\\"{x:476,y:552,t:1527188869254};\\\", \\\"{x:472,y:553,t:1527188869374};\\\", \\\"{x:472,y:556,t:1527188869388};\\\", \\\"{x:471,y:561,t:1527188869405};\\\", \\\"{x:471,y:562,t:1527188869431};\\\", \\\"{x:478,y:564,t:1527188869438};\\\", \\\"{x:490,y:565,t:1527188869455};\\\", \\\"{x:508,y:567,t:1527188869471};\\\", \\\"{x:528,y:570,t:1527188869488};\\\", \\\"{x:562,y:575,t:1527188869513};\\\", \\\"{x:588,y:577,t:1527188869529};\\\", \\\"{x:606,y:577,t:1527188869546};\\\", \\\"{x:613,y:577,t:1527188869561};\\\", \\\"{x:615,y:578,t:1527188869578};\\\", \\\"{x:617,y:579,t:1527188869614};\\\", \\\"{x:620,y:582,t:1527188869628};\\\", \\\"{x:622,y:587,t:1527188869646};\\\", \\\"{x:623,y:591,t:1527188869662};\\\", \\\"{x:623,y:592,t:1527188869679};\\\", \\\"{x:623,y:595,t:1527188869695};\\\", \\\"{x:623,y:596,t:1527188869726};\\\", \\\"{x:623,y:597,t:1527188869742};\\\", \\\"{x:622,y:597,t:1527188869750};\\\", \\\"{x:620,y:597,t:1527188869761};\\\", \\\"{x:619,y:597,t:1527188869779};\\\", \\\"{x:616,y:597,t:1527188869795};\\\", \\\"{x:615,y:597,t:1527188869822};\\\", \\\"{x:629,y:589,t:1527188870150};\\\", \\\"{x:656,y:576,t:1527188870163};\\\", \\\"{x:752,y:555,t:1527188870180};\\\", \\\"{x:845,y:535,t:1527188870196};\\\", \\\"{x:943,y:528,t:1527188870212};\\\", \\\"{x:1045,y:520,t:1527188870229};\\\", \\\"{x:1134,y:518,t:1527188870246};\\\", \\\"{x:1269,y:512,t:1527188870263};\\\", \\\"{x:1344,y:512,t:1527188870279};\\\", \\\"{x:1410,y:512,t:1527188870295};\\\", \\\"{x:1437,y:512,t:1527188870313};\\\", \\\"{x:1461,y:512,t:1527188870330};\\\", \\\"{x:1469,y:512,t:1527188870346};\\\", \\\"{x:1479,y:513,t:1527188870362};\\\", \\\"{x:1480,y:514,t:1527188870390};\\\", \\\"{x:1482,y:514,t:1527188870398};\\\", \\\"{x:1483,y:520,t:1527188870413};\\\", \\\"{x:1493,y:533,t:1527188870430};\\\", \\\"{x:1507,y:549,t:1527188870446};\\\", \\\"{x:1513,y:554,t:1527188870462};\\\", \\\"{x:1514,y:555,t:1527188870480};\\\", \\\"{x:1514,y:556,t:1527188870501};\\\", \\\"{x:1509,y:560,t:1527188870513};\\\", \\\"{x:1498,y:568,t:1527188870530};\\\", \\\"{x:1462,y:574,t:1527188870546};\\\", \\\"{x:1403,y:574,t:1527188870564};\\\", \\\"{x:1381,y:576,t:1527188870579};\\\", \\\"{x:1377,y:576,t:1527188870597};\\\", \\\"{x:1378,y:576,t:1527188870710};\\\", \\\"{x:1382,y:575,t:1527188870718};\\\", \\\"{x:1385,y:575,t:1527188870730};\\\", \\\"{x:1390,y:575,t:1527188870746};\\\", \\\"{x:1396,y:575,t:1527188870763};\\\", \\\"{x:1400,y:575,t:1527188870781};\\\", \\\"{x:1401,y:575,t:1527188870796};\\\", \\\"{x:1402,y:574,t:1527188870878};\\\", \\\"{x:1402,y:573,t:1527188870886};\\\", \\\"{x:1403,y:573,t:1527188870897};\\\", \\\"{x:1404,y:572,t:1527188871030};\\\", \\\"{x:1406,y:572,t:1527188871038};\\\", \\\"{x:1407,y:573,t:1527188871048};\\\", \\\"{x:1410,y:573,t:1527188871064};\\\", \\\"{x:1413,y:575,t:1527188871081};\\\", \\\"{x:1414,y:576,t:1527188871098};\\\", \\\"{x:1406,y:570,t:1527188876398};\\\", \\\"{x:1393,y:556,t:1527188876409};\\\", \\\"{x:1379,y:544,t:1527188876426};\\\", \\\"{x:1367,y:535,t:1527188876443};\\\", \\\"{x:1365,y:534,t:1527188876459};\\\", \\\"{x:1365,y:533,t:1527188876478};\\\", \\\"{x:1364,y:533,t:1527188876502};\\\", \\\"{x:1362,y:533,t:1527188876510};\\\", \\\"{x:1358,y:531,t:1527188876526};\\\", \\\"{x:1351,y:529,t:1527188876543};\\\", \\\"{x:1347,y:527,t:1527188876560};\\\", \\\"{x:1346,y:527,t:1527188876582};\\\", \\\"{x:1343,y:526,t:1527188876655};\\\", \\\"{x:1342,y:524,t:1527188876662};\\\", \\\"{x:1340,y:524,t:1527188876677};\\\", \\\"{x:1334,y:521,t:1527188876693};\\\", \\\"{x:1329,y:518,t:1527188876710};\\\", \\\"{x:1327,y:516,t:1527188876727};\\\", \\\"{x:1323,y:514,t:1527188876743};\\\", \\\"{x:1322,y:513,t:1527188876760};\\\", \\\"{x:1321,y:512,t:1527188876782};\\\", \\\"{x:1320,y:512,t:1527188876794};\\\", \\\"{x:1318,y:510,t:1527188876822};\\\", \\\"{x:1318,y:511,t:1527188880358};\\\", \\\"{x:1318,y:518,t:1527188880368};\\\", \\\"{x:1317,y:524,t:1527188880385};\\\", \\\"{x:1317,y:531,t:1527188880401};\\\", \\\"{x:1317,y:536,t:1527188880418};\\\", \\\"{x:1317,y:540,t:1527188880435};\\\", \\\"{x:1318,y:545,t:1527188880451};\\\", \\\"{x:1319,y:549,t:1527188880469};\\\", \\\"{x:1319,y:553,t:1527188880485};\\\", \\\"{x:1319,y:559,t:1527188880501};\\\", \\\"{x:1320,y:565,t:1527188880518};\\\", \\\"{x:1321,y:568,t:1527188880535};\\\", \\\"{x:1321,y:571,t:1527188880553};\\\", \\\"{x:1322,y:572,t:1527188880568};\\\", \\\"{x:1323,y:575,t:1527188880585};\\\", \\\"{x:1323,y:579,t:1527188880602};\\\", \\\"{x:1327,y:585,t:1527188880618};\\\", \\\"{x:1330,y:588,t:1527188880635};\\\", \\\"{x:1330,y:594,t:1527188880652};\\\", \\\"{x:1330,y:598,t:1527188880668};\\\", \\\"{x:1330,y:603,t:1527188880685};\\\", \\\"{x:1330,y:611,t:1527188880702};\\\", \\\"{x:1330,y:614,t:1527188880719};\\\", \\\"{x:1330,y:619,t:1527188880735};\\\", \\\"{x:1330,y:625,t:1527188880753};\\\", \\\"{x:1330,y:632,t:1527188880769};\\\", \\\"{x:1330,y:640,t:1527188880785};\\\", \\\"{x:1328,y:649,t:1527188880802};\\\", \\\"{x:1325,y:657,t:1527188880819};\\\", \\\"{x:1324,y:662,t:1527188880836};\\\", \\\"{x:1324,y:665,t:1527188880852};\\\", \\\"{x:1321,y:668,t:1527188880869};\\\", \\\"{x:1321,y:673,t:1527188880886};\\\", \\\"{x:1320,y:674,t:1527188880902};\\\", \\\"{x:1320,y:675,t:1527188880919};\\\", \\\"{x:1317,y:680,t:1527188880936};\\\", \\\"{x:1317,y:683,t:1527188880952};\\\", \\\"{x:1317,y:687,t:1527188880969};\\\", \\\"{x:1317,y:690,t:1527188880986};\\\", \\\"{x:1316,y:691,t:1527188881003};\\\", \\\"{x:1316,y:692,t:1527188881019};\\\", \\\"{x:1316,y:693,t:1527188881036};\\\", \\\"{x:1316,y:694,t:1527188881054};\\\", \\\"{x:1315,y:695,t:1527188881069};\\\", \\\"{x:1314,y:702,t:1527188881086};\\\", \\\"{x:1314,y:703,t:1527188881103};\\\", \\\"{x:1314,y:705,t:1527188881119};\\\", \\\"{x:1314,y:707,t:1527188881136};\\\", \\\"{x:1313,y:710,t:1527188881153};\\\", \\\"{x:1313,y:714,t:1527188881170};\\\", \\\"{x:1312,y:720,t:1527188881186};\\\", \\\"{x:1311,y:727,t:1527188881203};\\\", \\\"{x:1311,y:734,t:1527188881220};\\\", \\\"{x:1311,y:738,t:1527188881236};\\\", \\\"{x:1311,y:742,t:1527188881253};\\\", \\\"{x:1311,y:746,t:1527188881270};\\\", \\\"{x:1310,y:748,t:1527188881286};\\\", \\\"{x:1309,y:751,t:1527188881303};\\\", \\\"{x:1309,y:753,t:1527188881320};\\\", \\\"{x:1309,y:758,t:1527188881337};\\\", \\\"{x:1309,y:759,t:1527188881353};\\\", \\\"{x:1309,y:761,t:1527188881370};\\\", \\\"{x:1309,y:763,t:1527188881387};\\\", \\\"{x:1309,y:764,t:1527188881403};\\\", \\\"{x:1309,y:765,t:1527188881420};\\\", \\\"{x:1310,y:767,t:1527188881437};\\\", \\\"{x:1310,y:768,t:1527188881453};\\\", \\\"{x:1310,y:771,t:1527188881470};\\\", \\\"{x:1310,y:773,t:1527188881487};\\\", \\\"{x:1311,y:776,t:1527188881504};\\\", \\\"{x:1311,y:781,t:1527188881520};\\\", \\\"{x:1312,y:785,t:1527188881537};\\\", \\\"{x:1313,y:788,t:1527188881554};\\\", \\\"{x:1313,y:791,t:1527188881570};\\\", \\\"{x:1313,y:795,t:1527188881587};\\\", \\\"{x:1315,y:804,t:1527188881604};\\\", \\\"{x:1315,y:809,t:1527188881621};\\\", \\\"{x:1316,y:816,t:1527188881637};\\\", \\\"{x:1319,y:825,t:1527188881654};\\\", \\\"{x:1320,y:833,t:1527188881671};\\\", \\\"{x:1323,y:839,t:1527188881687};\\\", \\\"{x:1323,y:845,t:1527188881704};\\\", \\\"{x:1323,y:851,t:1527188881721};\\\", \\\"{x:1323,y:854,t:1527188881737};\\\", \\\"{x:1323,y:856,t:1527188881754};\\\", \\\"{x:1323,y:859,t:1527188881771};\\\", \\\"{x:1323,y:860,t:1527188881790};\\\", \\\"{x:1324,y:861,t:1527188881804};\\\", \\\"{x:1324,y:862,t:1527188881821};\\\", \\\"{x:1324,y:864,t:1527188881838};\\\", \\\"{x:1325,y:866,t:1527188881854};\\\", \\\"{x:1325,y:868,t:1527188881871};\\\", \\\"{x:1325,y:870,t:1527188881888};\\\", \\\"{x:1325,y:873,t:1527188881904};\\\", \\\"{x:1325,y:876,t:1527188881921};\\\", \\\"{x:1325,y:880,t:1527188881938};\\\", \\\"{x:1325,y:883,t:1527188881955};\\\", \\\"{x:1325,y:885,t:1527188881971};\\\", \\\"{x:1326,y:889,t:1527188881988};\\\", \\\"{x:1326,y:892,t:1527188882005};\\\", \\\"{x:1326,y:895,t:1527188882021};\\\", \\\"{x:1326,y:899,t:1527188882037};\\\", \\\"{x:1326,y:903,t:1527188882055};\\\", \\\"{x:1326,y:907,t:1527188882071};\\\", \\\"{x:1326,y:910,t:1527188882088};\\\", \\\"{x:1326,y:912,t:1527188882105};\\\", \\\"{x:1326,y:914,t:1527188882122};\\\", \\\"{x:1326,y:915,t:1527188882138};\\\", \\\"{x:1326,y:917,t:1527188882156};\\\", \\\"{x:1326,y:919,t:1527188882173};\\\", \\\"{x:1326,y:920,t:1527188882190};\\\", \\\"{x:1325,y:922,t:1527188882206};\\\", \\\"{x:1325,y:924,t:1527188882222};\\\", \\\"{x:1324,y:925,t:1527188882238};\\\", \\\"{x:1323,y:927,t:1527188882255};\\\", \\\"{x:1323,y:928,t:1527188882272};\\\", \\\"{x:1322,y:931,t:1527188882289};\\\", \\\"{x:1321,y:934,t:1527188882305};\\\", \\\"{x:1321,y:935,t:1527188882322};\\\", \\\"{x:1321,y:938,t:1527188882340};\\\", \\\"{x:1321,y:940,t:1527188882355};\\\", \\\"{x:1321,y:941,t:1527188882438};\\\", \\\"{x:1321,y:943,t:1527188882486};\\\", \\\"{x:1321,y:944,t:1527188882494};\\\", \\\"{x:1322,y:944,t:1527188882510};\\\", \\\"{x:1323,y:945,t:1527188882526};\\\", \\\"{x:1323,y:946,t:1527188882541};\\\", \\\"{x:1324,y:948,t:1527188882558};\\\", \\\"{x:1324,y:949,t:1527188882574};\\\", \\\"{x:1325,y:950,t:1527188882589};\\\", \\\"{x:1325,y:953,t:1527188882607};\\\", \\\"{x:1325,y:954,t:1527188882623};\\\", \\\"{x:1326,y:957,t:1527188882646};\\\", \\\"{x:1326,y:958,t:1527188882677};\\\", \\\"{x:1326,y:959,t:1527188882694};\\\", \\\"{x:1326,y:960,t:1527188882710};\\\", \\\"{x:1326,y:961,t:1527188882758};\\\", \\\"{x:1326,y:962,t:1527188882902};\\\", \\\"{x:1325,y:963,t:1527188882910};\\\", \\\"{x:1324,y:963,t:1527188882942};\\\", \\\"{x:1323,y:963,t:1527188883118};\\\", \\\"{x:1322,y:963,t:1527188883223};\\\", \\\"{x:1321,y:963,t:1527188883230};\\\", \\\"{x:1320,y:963,t:1527188883246};\\\", \\\"{x:1319,y:963,t:1527188883278};\\\", \\\"{x:1318,y:964,t:1527188883390};\\\", \\\"{x:1317,y:964,t:1527188884118};\\\", \\\"{x:1317,y:959,t:1527188885294};\\\", \\\"{x:1319,y:952,t:1527188885302};\\\", \\\"{x:1321,y:945,t:1527188885312};\\\", \\\"{x:1327,y:929,t:1527188885329};\\\", \\\"{x:1333,y:909,t:1527188885345};\\\", \\\"{x:1341,y:888,t:1527188885363};\\\", \\\"{x:1356,y:863,t:1527188885379};\\\", \\\"{x:1363,y:847,t:1527188885395};\\\", \\\"{x:1370,y:830,t:1527188885412};\\\", \\\"{x:1375,y:816,t:1527188885429};\\\", \\\"{x:1379,y:798,t:1527188885445};\\\", \\\"{x:1382,y:760,t:1527188885463};\\\", \\\"{x:1385,y:739,t:1527188885479};\\\", \\\"{x:1386,y:720,t:1527188885495};\\\", \\\"{x:1389,y:704,t:1527188885512};\\\", \\\"{x:1390,y:692,t:1527188885529};\\\", \\\"{x:1390,y:671,t:1527188885547};\\\", \\\"{x:1390,y:655,t:1527188885562};\\\", \\\"{x:1388,y:640,t:1527188885579};\\\", \\\"{x:1386,y:625,t:1527188885596};\\\", \\\"{x:1380,y:608,t:1527188885613};\\\", \\\"{x:1380,y:594,t:1527188885630};\\\", \\\"{x:1379,y:573,t:1527188885646};\\\", \\\"{x:1378,y:564,t:1527188885663};\\\", \\\"{x:1376,y:551,t:1527188885679};\\\", \\\"{x:1374,y:538,t:1527188885697};\\\", \\\"{x:1372,y:524,t:1527188885714};\\\", \\\"{x:1369,y:511,t:1527188885730};\\\", \\\"{x:1369,y:502,t:1527188885746};\\\", \\\"{x:1369,y:496,t:1527188885764};\\\", \\\"{x:1369,y:488,t:1527188885779};\\\", \\\"{x:1370,y:475,t:1527188885796};\\\", \\\"{x:1376,y:462,t:1527188885814};\\\", \\\"{x:1380,y:452,t:1527188885829};\\\", \\\"{x:1389,y:444,t:1527188885846};\\\", \\\"{x:1392,y:439,t:1527188885863};\\\", \\\"{x:1393,y:438,t:1527188885880};\\\", \\\"{x:1394,y:438,t:1527188885934};\\\", \\\"{x:1397,y:438,t:1527188885958};\\\", \\\"{x:1398,y:438,t:1527188885966};\\\", \\\"{x:1399,y:438,t:1527188885998};\\\", \\\"{x:1401,y:438,t:1527188886046};\\\", \\\"{x:1402,y:439,t:1527188886054};\\\", \\\"{x:1403,y:439,t:1527188886064};\\\", \\\"{x:1405,y:441,t:1527188886081};\\\", \\\"{x:1406,y:442,t:1527188886098};\\\", \\\"{x:1407,y:442,t:1527188887142};\\\", \\\"{x:1408,y:442,t:1527188887150};\\\", \\\"{x:1410,y:441,t:1527188887182};\\\", \\\"{x:1411,y:441,t:1527188887302};\\\", \\\"{x:1411,y:446,t:1527188889902};\\\", \\\"{x:1410,y:453,t:1527188889910};\\\", \\\"{x:1409,y:462,t:1527188889922};\\\", \\\"{x:1404,y:474,t:1527188889938};\\\", \\\"{x:1401,y:487,t:1527188889956};\\\", \\\"{x:1400,y:498,t:1527188889972};\\\", \\\"{x:1395,y:510,t:1527188889989};\\\", \\\"{x:1389,y:527,t:1527188890006};\\\", \\\"{x:1370,y:563,t:1527188890022};\\\", \\\"{x:1359,y:584,t:1527188890039};\\\", \\\"{x:1347,y:605,t:1527188890056};\\\", \\\"{x:1341,y:627,t:1527188890073};\\\", \\\"{x:1329,y:654,t:1527188890090};\\\", \\\"{x:1322,y:674,t:1527188890106};\\\", \\\"{x:1318,y:692,t:1527188890123};\\\", \\\"{x:1315,y:709,t:1527188890140};\\\", \\\"{x:1303,y:728,t:1527188890156};\\\", \\\"{x:1293,y:748,t:1527188890173};\\\", \\\"{x:1284,y:777,t:1527188890190};\\\", \\\"{x:1272,y:807,t:1527188890206};\\\", \\\"{x:1262,y:838,t:1527188890222};\\\", \\\"{x:1258,y:849,t:1527188890240};\\\", \\\"{x:1256,y:857,t:1527188890257};\\\", \\\"{x:1256,y:859,t:1527188890273};\\\", \\\"{x:1255,y:860,t:1527188890290};\\\", \\\"{x:1254,y:860,t:1527188890406};\\\", \\\"{x:1249,y:860,t:1527188890424};\\\", \\\"{x:1247,y:859,t:1527188890440};\\\", \\\"{x:1244,y:859,t:1527188890574};\\\", \\\"{x:1241,y:858,t:1527188890590};\\\", \\\"{x:1239,y:858,t:1527188890606};\\\", \\\"{x:1235,y:857,t:1527188890624};\\\", \\\"{x:1229,y:855,t:1527188890641};\\\", \\\"{x:1226,y:854,t:1527188890657};\\\", \\\"{x:1224,y:852,t:1527188890674};\\\", \\\"{x:1224,y:851,t:1527188890750};\\\", \\\"{x:1222,y:851,t:1527188890774};\\\", \\\"{x:1219,y:850,t:1527188890791};\\\", \\\"{x:1217,y:850,t:1527188890807};\\\", \\\"{x:1213,y:848,t:1527188890824};\\\", \\\"{x:1212,y:848,t:1527188890841};\\\", \\\"{x:1211,y:848,t:1527188890858};\\\", \\\"{x:1212,y:848,t:1527188890926};\\\", \\\"{x:1215,y:848,t:1527188890940};\\\", \\\"{x:1217,y:848,t:1527188890957};\\\", \\\"{x:1222,y:848,t:1527188890975};\\\", \\\"{x:1231,y:848,t:1527188890990};\\\", \\\"{x:1239,y:843,t:1527188891007};\\\", \\\"{x:1254,y:838,t:1527188891025};\\\", \\\"{x:1271,y:833,t:1527188891042};\\\", \\\"{x:1279,y:831,t:1527188891058};\\\", \\\"{x:1281,y:830,t:1527188891074};\\\", \\\"{x:1282,y:830,t:1527188891092};\\\", \\\"{x:1285,y:830,t:1527188891108};\\\", \\\"{x:1286,y:830,t:1527188891125};\\\", \\\"{x:1287,y:830,t:1527188891142};\\\", \\\"{x:1288,y:830,t:1527188891182};\\\", \\\"{x:1289,y:830,t:1527188891215};\\\", \\\"{x:1291,y:830,t:1527188891225};\\\", \\\"{x:1292,y:830,t:1527188891254};\\\", \\\"{x:1293,y:831,t:1527188891270};\\\", \\\"{x:1293,y:832,t:1527188891310};\\\", \\\"{x:1293,y:834,t:1527188891358};\\\", \\\"{x:1293,y:835,t:1527188891376};\\\", \\\"{x:1292,y:838,t:1527188891391};\\\", \\\"{x:1290,y:840,t:1527188891408};\\\", \\\"{x:1289,y:841,t:1527188891426};\\\", \\\"{x:1288,y:842,t:1527188891442};\\\", \\\"{x:1288,y:843,t:1527188891458};\\\", \\\"{x:1285,y:845,t:1527188891494};\\\", \\\"{x:1284,y:845,t:1527188891534};\\\", \\\"{x:1283,y:845,t:1527188891542};\\\", \\\"{x:1282,y:845,t:1527188891559};\\\", \\\"{x:1281,y:845,t:1527188891790};\\\", \\\"{x:1281,y:844,t:1527188892455};\\\", \\\"{x:1281,y:843,t:1527188892461};\\\", \\\"{x:1280,y:843,t:1527188892478};\\\", \\\"{x:1279,y:842,t:1527188892494};\\\", \\\"{x:1279,y:840,t:1527188892511};\\\", \\\"{x:1282,y:839,t:1527188894209};\\\", \\\"{x:1284,y:840,t:1527188894219};\\\", \\\"{x:1289,y:846,t:1527188894235};\\\", \\\"{x:1291,y:851,t:1527188894251};\\\", \\\"{x:1292,y:855,t:1527188894268};\\\", \\\"{x:1294,y:860,t:1527188894286};\\\", \\\"{x:1295,y:861,t:1527188894313};\\\", \\\"{x:1296,y:862,t:1527188894321};\\\", \\\"{x:1297,y:864,t:1527188894335};\\\", \\\"{x:1299,y:867,t:1527188894352};\\\", \\\"{x:1301,y:874,t:1527188894368};\\\", \\\"{x:1306,y:882,t:1527188894385};\\\", \\\"{x:1307,y:883,t:1527188894402};\\\", \\\"{x:1310,y:885,t:1527188894418};\\\", \\\"{x:1313,y:886,t:1527188894435};\\\", \\\"{x:1314,y:887,t:1527188894452};\\\", \\\"{x:1319,y:891,t:1527188894469};\\\", \\\"{x:1329,y:899,t:1527188894486};\\\", \\\"{x:1335,y:904,t:1527188894503};\\\", \\\"{x:1340,y:909,t:1527188894520};\\\", \\\"{x:1344,y:912,t:1527188894536};\\\", \\\"{x:1346,y:913,t:1527188894552};\\\", \\\"{x:1348,y:913,t:1527188894569};\\\", \\\"{x:1348,y:914,t:1527188894626};\\\", \\\"{x:1349,y:914,t:1527188894641};\\\", \\\"{x:1350,y:914,t:1527188894657};\\\", \\\"{x:1350,y:912,t:1527188894778};\\\", \\\"{x:1350,y:911,t:1527188894793};\\\", \\\"{x:1349,y:909,t:1527188894803};\\\", \\\"{x:1349,y:908,t:1527188894850};\\\", \\\"{x:1348,y:908,t:1527188894930};\\\", \\\"{x:1348,y:907,t:1527188894954};\\\", \\\"{x:1347,y:907,t:1527188894970};\\\", \\\"{x:1346,y:908,t:1527188898162};\\\", \\\"{x:1346,y:912,t:1527188898176};\\\", \\\"{x:1345,y:920,t:1527188898193};\\\", \\\"{x:1344,y:927,t:1527188898210};\\\", \\\"{x:1343,y:930,t:1527188898227};\\\", \\\"{x:1343,y:934,t:1527188898244};\\\", \\\"{x:1343,y:936,t:1527188898260};\\\", \\\"{x:1343,y:938,t:1527188898278};\\\", \\\"{x:1343,y:941,t:1527188898294};\\\", \\\"{x:1343,y:944,t:1527188898310};\\\", \\\"{x:1343,y:949,t:1527188898328};\\\", \\\"{x:1343,y:952,t:1527188898343};\\\", \\\"{x:1342,y:955,t:1527188898360};\\\", \\\"{x:1342,y:960,t:1527188898377};\\\", \\\"{x:1342,y:962,t:1527188898393};\\\", \\\"{x:1343,y:969,t:1527188898411};\\\", \\\"{x:1343,y:975,t:1527188898427};\\\", \\\"{x:1344,y:978,t:1527188898445};\\\", \\\"{x:1344,y:977,t:1527188898538};\\\", \\\"{x:1344,y:975,t:1527188898546};\\\", \\\"{x:1344,y:971,t:1527188898561};\\\", \\\"{x:1344,y:967,t:1527188898578};\\\", \\\"{x:1344,y:963,t:1527188898595};\\\", \\\"{x:1346,y:960,t:1527188898612};\\\", \\\"{x:1347,y:953,t:1527188898627};\\\", \\\"{x:1348,y:951,t:1527188898644};\\\", \\\"{x:1350,y:945,t:1527188898662};\\\", \\\"{x:1353,y:936,t:1527188898677};\\\", \\\"{x:1356,y:929,t:1527188898694};\\\", \\\"{x:1358,y:926,t:1527188898711};\\\", \\\"{x:1360,y:920,t:1527188898728};\\\", \\\"{x:1360,y:919,t:1527188898744};\\\", \\\"{x:1360,y:917,t:1527188898761};\\\", \\\"{x:1360,y:916,t:1527188898881};\\\", \\\"{x:1359,y:914,t:1527188898897};\\\", \\\"{x:1358,y:914,t:1527188898922};\\\", \\\"{x:1357,y:914,t:1527188898946};\\\", \\\"{x:1356,y:914,t:1527188898985};\\\", \\\"{x:1355,y:913,t:1527188899002};\\\", \\\"{x:1354,y:913,t:1527188899012};\\\", \\\"{x:1352,y:911,t:1527188899029};\\\", \\\"{x:1351,y:909,t:1527188899046};\\\", \\\"{x:1351,y:908,t:1527188899065};\\\", \\\"{x:1350,y:908,t:1527188899106};\\\", \\\"{x:1350,y:906,t:1527188899121};\\\", \\\"{x:1350,y:905,t:1527188899161};\\\", \\\"{x:1350,y:904,t:1527188899234};\\\", \\\"{x:1350,y:903,t:1527188899546};\\\", \\\"{x:1350,y:902,t:1527188899570};\\\", \\\"{x:1349,y:901,t:1527188902114};\\\", \\\"{x:1347,y:893,t:1527188904825};\\\", \\\"{x:1345,y:886,t:1527188904842};\\\", \\\"{x:1343,y:876,t:1527188904858};\\\", \\\"{x:1342,y:861,t:1527188904875};\\\", \\\"{x:1340,y:843,t:1527188904892};\\\", \\\"{x:1339,y:824,t:1527188904907};\\\", \\\"{x:1339,y:809,t:1527188904925};\\\", \\\"{x:1339,y:782,t:1527188904942};\\\", \\\"{x:1342,y:754,t:1527188904958};\\\", \\\"{x:1348,y:728,t:1527188904974};\\\", \\\"{x:1356,y:711,t:1527188904992};\\\", \\\"{x:1358,y:695,t:1527188905009};\\\", \\\"{x:1361,y:688,t:1527188905025};\\\", \\\"{x:1364,y:667,t:1527188905041};\\\", \\\"{x:1372,y:637,t:1527188905059};\\\", \\\"{x:1374,y:630,t:1527188905075};\\\", \\\"{x:1377,y:616,t:1527188905092};\\\", \\\"{x:1379,y:609,t:1527188905109};\\\", \\\"{x:1381,y:605,t:1527188905126};\\\", \\\"{x:1382,y:603,t:1527188905141};\\\", \\\"{x:1382,y:602,t:1527188905169};\\\", \\\"{x:1383,y:599,t:1527188905178};\\\", \\\"{x:1387,y:595,t:1527188905192};\\\", \\\"{x:1392,y:588,t:1527188905209};\\\", \\\"{x:1404,y:576,t:1527188905225};\\\", \\\"{x:1406,y:571,t:1527188905242};\\\", \\\"{x:1407,y:571,t:1527188905259};\\\", \\\"{x:1408,y:570,t:1527188905305};\\\", \\\"{x:1411,y:566,t:1527188905314};\\\", \\\"{x:1414,y:564,t:1527188905343};\\\", \\\"{x:1416,y:562,t:1527188905359};\\\", \\\"{x:1417,y:562,t:1527188905385};\\\", \\\"{x:1419,y:563,t:1527188905393};\\\", \\\"{x:1421,y:569,t:1527188905410};\\\", \\\"{x:1424,y:583,t:1527188905426};\\\", \\\"{x:1424,y:586,t:1527188905442};\\\", \\\"{x:1425,y:587,t:1527188905460};\\\", \\\"{x:1426,y:595,t:1527188906978};\\\", \\\"{x:1426,y:616,t:1527188906985};\\\", \\\"{x:1428,y:627,t:1527188906996};\\\", \\\"{x:1429,y:640,t:1527188907013};\\\", \\\"{x:1429,y:651,t:1527188907030};\\\", \\\"{x:1427,y:664,t:1527188907046};\\\", \\\"{x:1426,y:671,t:1527188907063};\\\", \\\"{x:1424,y:676,t:1527188907080};\\\", \\\"{x:1422,y:682,t:1527188907096};\\\", \\\"{x:1420,y:689,t:1527188907113};\\\", \\\"{x:1419,y:701,t:1527188907129};\\\", \\\"{x:1418,y:712,t:1527188907147};\\\", \\\"{x:1418,y:722,t:1527188907162};\\\", \\\"{x:1415,y:728,t:1527188907180};\\\", \\\"{x:1415,y:731,t:1527188907197};\\\", \\\"{x:1415,y:734,t:1527188907213};\\\", \\\"{x:1415,y:738,t:1527188907230};\\\", \\\"{x:1415,y:745,t:1527188907247};\\\", \\\"{x:1415,y:750,t:1527188907263};\\\", \\\"{x:1415,y:756,t:1527188907279};\\\", \\\"{x:1415,y:758,t:1527188907297};\\\", \\\"{x:1415,y:763,t:1527188907314};\\\", \\\"{x:1415,y:764,t:1527188907330};\\\", \\\"{x:1415,y:766,t:1527188907347};\\\", \\\"{x:1415,y:769,t:1527188907364};\\\", \\\"{x:1415,y:770,t:1527188907380};\\\", \\\"{x:1415,y:772,t:1527188907397};\\\", \\\"{x:1415,y:773,t:1527188907414};\\\", \\\"{x:1415,y:774,t:1527188907431};\\\", \\\"{x:1415,y:776,t:1527188907447};\\\", \\\"{x:1415,y:779,t:1527188907464};\\\", \\\"{x:1415,y:784,t:1527188907481};\\\", \\\"{x:1415,y:786,t:1527188907497};\\\", \\\"{x:1413,y:796,t:1527188907514};\\\", \\\"{x:1413,y:799,t:1527188907531};\\\", \\\"{x:1410,y:805,t:1527188907547};\\\", \\\"{x:1410,y:806,t:1527188907564};\\\", \\\"{x:1410,y:809,t:1527188907581};\\\", \\\"{x:1410,y:811,t:1527188907597};\\\", \\\"{x:1410,y:817,t:1527188907614};\\\", \\\"{x:1408,y:822,t:1527188907631};\\\", \\\"{x:1405,y:830,t:1527188907648};\\\", \\\"{x:1405,y:837,t:1527188907664};\\\", \\\"{x:1405,y:845,t:1527188907681};\\\", \\\"{x:1405,y:859,t:1527188907697};\\\", \\\"{x:1405,y:866,t:1527188907713};\\\", \\\"{x:1405,y:868,t:1527188907731};\\\", \\\"{x:1405,y:871,t:1527188907748};\\\", \\\"{x:1405,y:875,t:1527188907764};\\\", \\\"{x:1406,y:878,t:1527188907781};\\\", \\\"{x:1407,y:881,t:1527188907798};\\\", \\\"{x:1408,y:885,t:1527188907815};\\\", \\\"{x:1410,y:888,t:1527188907830};\\\", \\\"{x:1410,y:891,t:1527188907848};\\\", \\\"{x:1411,y:894,t:1527188907864};\\\", \\\"{x:1411,y:895,t:1527188907880};\\\", \\\"{x:1412,y:898,t:1527188907898};\\\", \\\"{x:1413,y:899,t:1527188907915};\\\", \\\"{x:1414,y:901,t:1527188907931};\\\", \\\"{x:1414,y:902,t:1527188907948};\\\", \\\"{x:1414,y:905,t:1527188907965};\\\", \\\"{x:1415,y:907,t:1527188907982};\\\", \\\"{x:1415,y:911,t:1527188907998};\\\", \\\"{x:1415,y:914,t:1527188908015};\\\", \\\"{x:1416,y:918,t:1527188908032};\\\", \\\"{x:1417,y:920,t:1527188908048};\\\", \\\"{x:1417,y:925,t:1527188908065};\\\", \\\"{x:1419,y:931,t:1527188908082};\\\", \\\"{x:1420,y:934,t:1527188908099};\\\", \\\"{x:1421,y:936,t:1527188908115};\\\", \\\"{x:1421,y:939,t:1527188908132};\\\", \\\"{x:1421,y:942,t:1527188908149};\\\", \\\"{x:1422,y:944,t:1527188908165};\\\", \\\"{x:1424,y:947,t:1527188908182};\\\", \\\"{x:1425,y:948,t:1527188908198};\\\", \\\"{x:1425,y:949,t:1527188908215};\\\", \\\"{x:1425,y:950,t:1527188908232};\\\", \\\"{x:1425,y:952,t:1527188908249};\\\", \\\"{x:1426,y:953,t:1527188908289};\\\", \\\"{x:1427,y:953,t:1527188908298};\\\", \\\"{x:1427,y:954,t:1527188908338};\\\", \\\"{x:1427,y:956,t:1527188908349};\\\", \\\"{x:1427,y:958,t:1527188908366};\\\", \\\"{x:1426,y:960,t:1527188908382};\\\", \\\"{x:1426,y:961,t:1527188908398};\\\", \\\"{x:1424,y:962,t:1527188908415};\\\", \\\"{x:1424,y:963,t:1527188908433};\\\", \\\"{x:1421,y:966,t:1527188908449};\\\", \\\"{x:1418,y:968,t:1527188908466};\\\", \\\"{x:1402,y:969,t:1527188908483};\\\", \\\"{x:1394,y:969,t:1527188908499};\\\", \\\"{x:1369,y:956,t:1527188908516};\\\", \\\"{x:1298,y:961,t:1527188908533};\\\", \\\"{x:1269,y:958,t:1527188908550};\\\", \\\"{x:1220,y:939,t:1527188908566};\\\", \\\"{x:1174,y:920,t:1527188908583};\\\", \\\"{x:1105,y:902,t:1527188908600};\\\", \\\"{x:990,y:880,t:1527188908615};\\\", \\\"{x:903,y:860,t:1527188908633};\\\", \\\"{x:802,y:840,t:1527188908649};\\\", \\\"{x:785,y:835,t:1527188908665};\\\", \\\"{x:768,y:830,t:1527188908683};\\\", \\\"{x:750,y:825,t:1527188908700};\\\", \\\"{x:738,y:824,t:1527188908717};\\\", \\\"{x:722,y:821,t:1527188908733};\\\", \\\"{x:705,y:816,t:1527188908750};\\\", \\\"{x:686,y:815,t:1527188908767};\\\", \\\"{x:657,y:810,t:1527188908783};\\\", \\\"{x:598,y:800,t:1527188908800};\\\", \\\"{x:548,y:787,t:1527188908817};\\\", \\\"{x:528,y:784,t:1527188908833};\\\", \\\"{x:527,y:782,t:1527188908850};\\\", \\\"{x:526,y:782,t:1527188908867};\\\", \\\"{x:522,y:777,t:1527188908884};\\\", \\\"{x:515,y:771,t:1527188908900};\\\", \\\"{x:493,y:763,t:1527188908917};\\\", \\\"{x:470,y:755,t:1527188908934};\\\", \\\"{x:454,y:749,t:1527188908950};\\\", \\\"{x:451,y:746,t:1527188908967};\\\", \\\"{x:450,y:745,t:1527188908984};\\\", \\\"{x:450,y:743,t:1527188909066};\\\", \\\"{x:450,y:740,t:1527188909073};\\\", \\\"{x:451,y:737,t:1527188909084};\\\", \\\"{x:463,y:730,t:1527188909101};\\\", \\\"{x:470,y:727,t:1527188909117};\\\", \\\"{x:472,y:725,t:1527188909134};\\\", \\\"{x:475,y:725,t:1527188909158};\\\", \\\"{x:475,y:724,t:1527188909202};\\\", \\\"{x:479,y:722,t:1527188909209};\\\", \\\"{x:481,y:719,t:1527188909225};\\\", \\\"{x:484,y:716,t:1527188909241};\\\", \\\"{x:486,y:716,t:1527188909258};\\\", \\\"{x:488,y:716,t:1527188915170};\\\", \\\"{x:506,y:706,t:1527188915177};\\\", \\\"{x:551,y:692,t:1527188915191};\\\", \\\"{x:677,y:667,t:1527188915207};\\\", \\\"{x:836,y:643,t:1527188915231};\\\", \\\"{x:918,y:637,t:1527188915248};\\\", \\\"{x:972,y:629,t:1527188915264};\\\", \\\"{x:1001,y:626,t:1527188915281};\\\", \\\"{x:1014,y:617,t:1527188915298};\\\", \\\"{x:1027,y:609,t:1527188915314};\\\", \\\"{x:1055,y:599,t:1527188915332};\\\", \\\"{x:1072,y:583,t:1527188915349};\\\", \\\"{x:1084,y:575,t:1527188915364};\\\", \\\"{x:1102,y:567,t:1527188915381};\\\", \\\"{x:1115,y:566,t:1527188915398};\\\", \\\"{x:1116,y:566,t:1527188915414};\\\", \\\"{x:1117,y:566,t:1527188915457};\\\", \\\"{x:1121,y:567,t:1527188915465};\\\", \\\"{x:1131,y:586,t:1527188915481};\\\", \\\"{x:1145,y:600,t:1527188915498};\\\", \\\"{x:1153,y:606,t:1527188915515};\\\", \\\"{x:1164,y:615,t:1527188915531};\\\", \\\"{x:1182,y:622,t:1527188915549};\\\", \\\"{x:1201,y:630,t:1527188915565};\\\", \\\"{x:1223,y:636,t:1527188915581};\\\", \\\"{x:1231,y:637,t:1527188915598};\\\", \\\"{x:1233,y:638,t:1527188915614};\\\", \\\"{x:1237,y:640,t:1527188915631};\\\", \\\"{x:1239,y:640,t:1527188915648};\\\", \\\"{x:1245,y:640,t:1527188915664};\\\", \\\"{x:1256,y:641,t:1527188915681};\\\", \\\"{x:1264,y:642,t:1527188915698};\\\", \\\"{x:1268,y:644,t:1527188915715};\\\", \\\"{x:1275,y:644,t:1527188915732};\\\", \\\"{x:1285,y:644,t:1527188915748};\\\", \\\"{x:1307,y:646,t:1527188915764};\\\", \\\"{x:1319,y:646,t:1527188915781};\\\", \\\"{x:1321,y:646,t:1527188915798};\\\", \\\"{x:1323,y:646,t:1527188915815};\\\", \\\"{x:1322,y:646,t:1527188915994};\\\", \\\"{x:1321,y:646,t:1527188916001};\\\", \\\"{x:1319,y:646,t:1527188916017};\\\", \\\"{x:1317,y:646,t:1527188916031};\\\", \\\"{x:1315,y:646,t:1527188916049};\\\", \\\"{x:1311,y:645,t:1527188916064};\\\", \\\"{x:1305,y:640,t:1527188916081};\\\", \\\"{x:1302,y:638,t:1527188916098};\\\", \\\"{x:1300,y:637,t:1527188916114};\\\", \\\"{x:1299,y:637,t:1527188916241};\\\", \\\"{x:1299,y:642,t:1527188916249};\\\", \\\"{x:1299,y:644,t:1527188916264};\\\", \\\"{x:1298,y:651,t:1527188916281};\\\", \\\"{x:1300,y:661,t:1527188916298};\\\", \\\"{x:1301,y:669,t:1527188916314};\\\", \\\"{x:1302,y:672,t:1527188916332};\\\", \\\"{x:1303,y:676,t:1527188916348};\\\", \\\"{x:1304,y:680,t:1527188916365};\\\", \\\"{x:1305,y:686,t:1527188916382};\\\", \\\"{x:1307,y:693,t:1527188916399};\\\", \\\"{x:1308,y:701,t:1527188916414};\\\", \\\"{x:1310,y:706,t:1527188916432};\\\", \\\"{x:1311,y:710,t:1527188916448};\\\", \\\"{x:1311,y:713,t:1527188916464};\\\", \\\"{x:1312,y:720,t:1527188916481};\\\", \\\"{x:1312,y:724,t:1527188916498};\\\", \\\"{x:1312,y:728,t:1527188916514};\\\", \\\"{x:1312,y:733,t:1527188916531};\\\", \\\"{x:1312,y:738,t:1527188916548};\\\", \\\"{x:1313,y:744,t:1527188916564};\\\", \\\"{x:1313,y:749,t:1527188916581};\\\", \\\"{x:1315,y:759,t:1527188916598};\\\", \\\"{x:1316,y:765,t:1527188916615};\\\", \\\"{x:1316,y:769,t:1527188916631};\\\", \\\"{x:1316,y:773,t:1527188916648};\\\", \\\"{x:1316,y:774,t:1527188916665};\\\", \\\"{x:1316,y:775,t:1527188916689};\\\", \\\"{x:1316,y:776,t:1527188916713};\\\", \\\"{x:1317,y:777,t:1527188916721};\\\", \\\"{x:1318,y:778,t:1527188916737};\\\", \\\"{x:1318,y:781,t:1527188916748};\\\", \\\"{x:1320,y:784,t:1527188916765};\\\", \\\"{x:1320,y:785,t:1527188916793};\\\", \\\"{x:1320,y:786,t:1527188916809};\\\", \\\"{x:1320,y:787,t:1527188916817};\\\", \\\"{x:1320,y:788,t:1527188916831};\\\", \\\"{x:1320,y:790,t:1527188916849};\\\", \\\"{x:1320,y:794,t:1527188916864};\\\", \\\"{x:1317,y:805,t:1527188916881};\\\", \\\"{x:1314,y:810,t:1527188916898};\\\", \\\"{x:1314,y:817,t:1527188916914};\\\", \\\"{x:1311,y:825,t:1527188916931};\\\", \\\"{x:1309,y:831,t:1527188916948};\\\", \\\"{x:1309,y:838,t:1527188916964};\\\", \\\"{x:1308,y:844,t:1527188916981};\\\", \\\"{x:1307,y:850,t:1527188916998};\\\", \\\"{x:1305,y:853,t:1527188917014};\\\", \\\"{x:1305,y:854,t:1527188917031};\\\", \\\"{x:1304,y:858,t:1527188917048};\\\", \\\"{x:1304,y:861,t:1527188917064};\\\", \\\"{x:1303,y:866,t:1527188917081};\\\", \\\"{x:1303,y:869,t:1527188917098};\\\", \\\"{x:1303,y:871,t:1527188917114};\\\", \\\"{x:1303,y:874,t:1527188917131};\\\", \\\"{x:1303,y:878,t:1527188917148};\\\", \\\"{x:1302,y:884,t:1527188917164};\\\", \\\"{x:1302,y:889,t:1527188917181};\\\", \\\"{x:1302,y:891,t:1527188917199};\\\", \\\"{x:1302,y:895,t:1527188917215};\\\", \\\"{x:1302,y:899,t:1527188917231};\\\", \\\"{x:1302,y:904,t:1527188917249};\\\", \\\"{x:1303,y:906,t:1527188917265};\\\", \\\"{x:1303,y:911,t:1527188917281};\\\", \\\"{x:1304,y:914,t:1527188917298};\\\", \\\"{x:1305,y:916,t:1527188917314};\\\", \\\"{x:1306,y:919,t:1527188917331};\\\", \\\"{x:1306,y:923,t:1527188917348};\\\", \\\"{x:1307,y:924,t:1527188917364};\\\", \\\"{x:1307,y:926,t:1527188917382};\\\", \\\"{x:1307,y:927,t:1527188917401};\\\", \\\"{x:1307,y:929,t:1527188917415};\\\", \\\"{x:1307,y:931,t:1527188917432};\\\", \\\"{x:1307,y:933,t:1527188917447};\\\", \\\"{x:1309,y:936,t:1527188917465};\\\", \\\"{x:1310,y:937,t:1527188917481};\\\", \\\"{x:1310,y:938,t:1527188917513};\\\", \\\"{x:1310,y:939,t:1527188917521};\\\", \\\"{x:1311,y:940,t:1527188917532};\\\", \\\"{x:1311,y:941,t:1527188917547};\\\", \\\"{x:1312,y:943,t:1527188917564};\\\", \\\"{x:1313,y:946,t:1527188917582};\\\", \\\"{x:1313,y:948,t:1527188917597};\\\", \\\"{x:1313,y:950,t:1527188917614};\\\", \\\"{x:1314,y:952,t:1527188917632};\\\", \\\"{x:1315,y:953,t:1527188917647};\\\", \\\"{x:1316,y:953,t:1527188917664};\\\", \\\"{x:1313,y:954,t:1527188917737};\\\", \\\"{x:1298,y:945,t:1527188917747};\\\", \\\"{x:1272,y:927,t:1527188917764};\\\", \\\"{x:1251,y:914,t:1527188917782};\\\", \\\"{x:1202,y:904,t:1527188917797};\\\", \\\"{x:1140,y:891,t:1527188917814};\\\", \\\"{x:1098,y:884,t:1527188917831};\\\", \\\"{x:1071,y:876,t:1527188917848};\\\", \\\"{x:1041,y:870,t:1527188917864};\\\", \\\"{x:1008,y:856,t:1527188917881};\\\", \\\"{x:980,y:847,t:1527188917897};\\\", \\\"{x:962,y:837,t:1527188917914};\\\", \\\"{x:939,y:828,t:1527188917932};\\\", \\\"{x:911,y:819,t:1527188917947};\\\", \\\"{x:883,y:812,t:1527188917964};\\\", \\\"{x:828,y:800,t:1527188917981};\\\", \\\"{x:790,y:797,t:1527188917997};\\\", \\\"{x:767,y:789,t:1527188918015};\\\", \\\"{x:760,y:786,t:1527188918031};\\\", \\\"{x:760,y:784,t:1527188918097};\\\", \\\"{x:754,y:783,t:1527188918114};\\\", \\\"{x:744,y:780,t:1527188918131};\\\", \\\"{x:735,y:778,t:1527188918147};\\\", \\\"{x:722,y:774,t:1527188918164};\\\", \\\"{x:707,y:770,t:1527188918181};\\\", \\\"{x:696,y:766,t:1527188918197};\\\", \\\"{x:690,y:761,t:1527188918214};\\\", \\\"{x:688,y:759,t:1527188918231};\\\", \\\"{x:687,y:758,t:1527188918248};\\\", \\\"{x:682,y:757,t:1527188918264};\\\", \\\"{x:649,y:749,t:1527188918281};\\\", \\\"{x:633,y:748,t:1527188918297};\\\", \\\"{x:627,y:747,t:1527188918315};\\\", \\\"{x:627,y:746,t:1527188918331};\\\", \\\"{x:632,y:746,t:1527188918393};\\\", \\\"{x:656,y:750,t:1527188918401};\\\", \\\"{x:696,y:755,t:1527188918415};\\\", \\\"{x:788,y:768,t:1527188918431};\\\", \\\"{x:865,y:789,t:1527188918448};\\\", \\\"{x:967,y:801,t:1527188918464};\\\", \\\"{x:1092,y:810,t:1527188918481};\\\", \\\"{x:1116,y:813,t:1527188918498};\\\", \\\"{x:1130,y:813,t:1527188918514};\\\", \\\"{x:1150,y:813,t:1527188918532};\\\", \\\"{x:1162,y:813,t:1527188918548};\\\", \\\"{x:1165,y:813,t:1527188918564};\\\", \\\"{x:1186,y:812,t:1527188918581};\\\", \\\"{x:1208,y:811,t:1527188918597};\\\", \\\"{x:1232,y:811,t:1527188918614};\\\", \\\"{x:1245,y:811,t:1527188918631};\\\", \\\"{x:1251,y:813,t:1527188918648};\\\", \\\"{x:1252,y:813,t:1527188918705};\\\", \\\"{x:1252,y:814,t:1527188918714};\\\", \\\"{x:1252,y:816,t:1527188918732};\\\", \\\"{x:1252,y:820,t:1527188918748};\\\", \\\"{x:1252,y:822,t:1527188918765};\\\", \\\"{x:1253,y:826,t:1527188918781};\\\", \\\"{x:1254,y:829,t:1527188918797};\\\", \\\"{x:1256,y:832,t:1527188918814};\\\", \\\"{x:1256,y:836,t:1527188918831};\\\", \\\"{x:1257,y:840,t:1527188918847};\\\", \\\"{x:1262,y:843,t:1527188918864};\\\", \\\"{x:1266,y:846,t:1527188918881};\\\", \\\"{x:1271,y:848,t:1527188918897};\\\", \\\"{x:1274,y:848,t:1527188918914};\\\", \\\"{x:1277,y:848,t:1527188918931};\\\", \\\"{x:1279,y:848,t:1527188919089};\\\", \\\"{x:1280,y:848,t:1527188919104};\\\", \\\"{x:1281,y:848,t:1527188919114};\\\", \\\"{x:1282,y:845,t:1527188919131};\\\", \\\"{x:1282,y:843,t:1527188919148};\\\", \\\"{x:1282,y:842,t:1527188919164};\\\", \\\"{x:1283,y:842,t:1527188919181};\\\", \\\"{x:1284,y:841,t:1527188919198};\\\", \\\"{x:1284,y:840,t:1527188919257};\\\", \\\"{x:1284,y:839,t:1527188919282};\\\", \\\"{x:1288,y:839,t:1527188920473};\\\", \\\"{x:1295,y:846,t:1527188920481};\\\", \\\"{x:1303,y:852,t:1527188920497};\\\", \\\"{x:1309,y:856,t:1527188920514};\\\", \\\"{x:1311,y:858,t:1527188920530};\\\", \\\"{x:1312,y:858,t:1527188920593};\\\", \\\"{x:1312,y:860,t:1527188920634};\\\", \\\"{x:1314,y:862,t:1527188920648};\\\", \\\"{x:1316,y:866,t:1527188920664};\\\", \\\"{x:1319,y:868,t:1527188920680};\\\", \\\"{x:1320,y:869,t:1527188920697};\\\", \\\"{x:1324,y:875,t:1527188920714};\\\", \\\"{x:1329,y:882,t:1527188920731};\\\", \\\"{x:1330,y:887,t:1527188920747};\\\", \\\"{x:1333,y:890,t:1527188920764};\\\", \\\"{x:1333,y:891,t:1527188920809};\\\", \\\"{x:1330,y:891,t:1527188920841};\\\", \\\"{x:1322,y:880,t:1527188920849};\\\", \\\"{x:1313,y:873,t:1527188920865};\\\", \\\"{x:1293,y:862,t:1527188920880};\\\", \\\"{x:1279,y:856,t:1527188920897};\\\", \\\"{x:1278,y:855,t:1527188920915};\\\", \\\"{x:1277,y:854,t:1527188920937};\\\", \\\"{x:1277,y:853,t:1527188920953};\\\", \\\"{x:1277,y:851,t:1527188920964};\\\", \\\"{x:1274,y:848,t:1527188920981};\\\", \\\"{x:1271,y:844,t:1527188920998};\\\", \\\"{x:1268,y:840,t:1527188921015};\\\", \\\"{x:1266,y:840,t:1527188921031};\\\", \\\"{x:1266,y:839,t:1527188921129};\\\", \\\"{x:1267,y:839,t:1527188921138};\\\", \\\"{x:1269,y:839,t:1527188921147};\\\", \\\"{x:1273,y:840,t:1527188921165};\\\", \\\"{x:1279,y:843,t:1527188921180};\\\", \\\"{x:1283,y:844,t:1527188921197};\\\", \\\"{x:1285,y:845,t:1527188921214};\\\", \\\"{x:1286,y:845,t:1527188921257};\\\", \\\"{x:1287,y:845,t:1527188921265};\\\", \\\"{x:1288,y:845,t:1527188921280};\\\", \\\"{x:1292,y:846,t:1527188921298};\\\", \\\"{x:1283,y:846,t:1527188922289};\\\", \\\"{x:1269,y:846,t:1527188922297};\\\", \\\"{x:1231,y:847,t:1527188922313};\\\", \\\"{x:1200,y:852,t:1527188922330};\\\", \\\"{x:1169,y:856,t:1527188922347};\\\", \\\"{x:1152,y:855,t:1527188922364};\\\", \\\"{x:1138,y:855,t:1527188922381};\\\", \\\"{x:1114,y:855,t:1527188922397};\\\", \\\"{x:1093,y:851,t:1527188922414};\\\", \\\"{x:1034,y:842,t:1527188922430};\\\", \\\"{x:967,y:824,t:1527188922448};\\\", \\\"{x:942,y:818,t:1527188922464};\\\", \\\"{x:934,y:815,t:1527188922480};\\\", \\\"{x:931,y:814,t:1527188922497};\\\", \\\"{x:930,y:812,t:1527188922513};\\\", \\\"{x:917,y:804,t:1527188922530};\\\", \\\"{x:880,y:792,t:1527188922547};\\\", \\\"{x:855,y:784,t:1527188922563};\\\", \\\"{x:828,y:776,t:1527188922580};\\\", \\\"{x:814,y:770,t:1527188922597};\\\", \\\"{x:779,y:763,t:1527188922614};\\\", \\\"{x:756,y:757,t:1527188922631};\\\", \\\"{x:745,y:755,t:1527188922648};\\\", \\\"{x:738,y:754,t:1527188922664};\\\", \\\"{x:736,y:754,t:1527188922680};\\\", \\\"{x:730,y:754,t:1527188922697};\\\", \\\"{x:715,y:754,t:1527188922714};\\\", \\\"{x:691,y:754,t:1527188922730};\\\", \\\"{x:669,y:754,t:1527188922748};\\\", \\\"{x:655,y:754,t:1527188922763};\\\", \\\"{x:648,y:754,t:1527188922780};\\\", \\\"{x:643,y:754,t:1527188922798};\\\", \\\"{x:636,y:754,t:1527188922813};\\\", \\\"{x:617,y:752,t:1527188922831};\\\", \\\"{x:596,y:749,t:1527188922848};\\\", \\\"{x:577,y:744,t:1527188922863};\\\", \\\"{x:568,y:742,t:1527188922880};\\\", \\\"{x:556,y:740,t:1527188922897};\\\", \\\"{x:556,y:739,t:1527188922913};\\\", \\\"{x:555,y:739,t:1527188922945};\\\", \\\"{x:551,y:739,t:1527188922953};\\\", \\\"{x:548,y:738,t:1527188922964};\\\", \\\"{x:537,y:735,t:1527188922981};\\\", \\\"{x:524,y:733,t:1527188922997};\\\", \\\"{x:516,y:731,t:1527188923009};\\\", \\\"{x:515,y:731,t:1527188923026};\\\", \\\"{x:514,y:730,t:1527188923114};\\\", \\\"{x:514,y:728,t:1527188923129};\\\", \\\"{x:513,y:728,t:1527188923153};\\\" ] }, { \\\"rt\\\": 197695, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 648716, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -C -10 AM-12 PM-A -11 AM-12 PM-O -C -11 AM-12 PM-12 PM-01 PM-03 PM-F -01 PM-02 PM-03 PM-03 PM-02 PM-12 PM-Z -03 PM-F -12 PM-01 PM-02 PM-03 PM-04 PM-U -02 PM-03 PM-03 PM-04 PM-04 PM-04 PM-1\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:726,t:1527188925825};\\\", \\\"{x:514,y:732,t:1527188925833};\\\", \\\"{x:519,y:736,t:1527188925848};\\\", \\\"{x:524,y:743,t:1527188925865};\\\", \\\"{x:530,y:757,t:1527188925881};\\\", \\\"{x:535,y:764,t:1527188925898};\\\", \\\"{x:537,y:768,t:1527188925911};\\\", \\\"{x:545,y:778,t:1527188925929};\\\", \\\"{x:552,y:789,t:1527188925946};\\\", \\\"{x:554,y:793,t:1527188925962};\\\", \\\"{x:554,y:794,t:1527188925978};\\\", \\\"{x:555,y:796,t:1527188926041};\\\", \\\"{x:555,y:799,t:1527188926049};\\\", \\\"{x:556,y:803,t:1527188926061};\\\", \\\"{x:557,y:808,t:1527188926078};\\\", \\\"{x:558,y:813,t:1527188926095};\\\", \\\"{x:558,y:816,t:1527188926112};\\\", \\\"{x:558,y:820,t:1527188926129};\\\", \\\"{x:558,y:821,t:1527188926145};\\\", \\\"{x:558,y:822,t:1527188926193};\\\", \\\"{x:557,y:822,t:1527188926201};\\\", \\\"{x:555,y:822,t:1527188926706};\\\", \\\"{x:550,y:819,t:1527188926713};\\\", \\\"{x:549,y:818,t:1527188926729};\\\", \\\"{x:546,y:815,t:1527188926745};\\\", \\\"{x:543,y:813,t:1527188935473};\\\", \\\"{x:529,y:796,t:1527188935484};\\\", \\\"{x:501,y:765,t:1527188935501};\\\", \\\"{x:474,y:736,t:1527188935518};\\\", \\\"{x:438,y:707,t:1527188935535};\\\", \\\"{x:421,y:690,t:1527188935553};\\\", \\\"{x:419,y:679,t:1527188935570};\\\", \\\"{x:416,y:668,t:1527188935587};\\\", \\\"{x:414,y:651,t:1527188935604};\\\", \\\"{x:410,y:623,t:1527188935621};\\\", \\\"{x:409,y:586,t:1527188935638};\\\", \\\"{x:409,y:568,t:1527188935653};\\\", \\\"{x:410,y:544,t:1527188935670};\\\", \\\"{x:425,y:518,t:1527188935687};\\\", \\\"{x:446,y:495,t:1527188935704};\\\", \\\"{x:458,y:482,t:1527188935720};\\\", \\\"{x:478,y:468,t:1527188935736};\\\", \\\"{x:486,y:466,t:1527188935752};\\\", \\\"{x:492,y:464,t:1527188935769};\\\", \\\"{x:507,y:464,t:1527188935787};\\\", \\\"{x:520,y:472,t:1527188935804};\\\", \\\"{x:540,y:486,t:1527188935819};\\\", \\\"{x:553,y:499,t:1527188935837};\\\", \\\"{x:566,y:508,t:1527188935854};\\\", \\\"{x:583,y:514,t:1527188935870};\\\", \\\"{x:599,y:517,t:1527188935887};\\\", \\\"{x:602,y:517,t:1527188935904};\\\", \\\"{x:607,y:517,t:1527188935920};\\\", \\\"{x:612,y:517,t:1527188935936};\\\", \\\"{x:613,y:517,t:1527188935954};\\\", \\\"{x:615,y:517,t:1527188936009};\\\", \\\"{x:619,y:517,t:1527188936033};\\\", \\\"{x:620,y:517,t:1527188936041};\\\", \\\"{x:626,y:515,t:1527188936054};\\\", \\\"{x:635,y:515,t:1527188936070};\\\", \\\"{x:639,y:515,t:1527188936087};\\\", \\\"{x:651,y:515,t:1527188936104};\\\", \\\"{x:658,y:517,t:1527188936120};\\\", \\\"{x:665,y:521,t:1527188936137};\\\", \\\"{x:666,y:521,t:1527188936154};\\\", \\\"{x:667,y:521,t:1527188936184};\\\", \\\"{x:671,y:523,t:1527188936297};\\\", \\\"{x:676,y:528,t:1527188936304};\\\", \\\"{x:680,y:534,t:1527188936320};\\\", \\\"{x:697,y:552,t:1527188936337};\\\", \\\"{x:706,y:563,t:1527188936355};\\\", \\\"{x:716,y:587,t:1527188936371};\\\", \\\"{x:724,y:609,t:1527188936387};\\\", \\\"{x:730,y:626,t:1527188936404};\\\", \\\"{x:730,y:643,t:1527188936421};\\\", \\\"{x:731,y:650,t:1527188936437};\\\", \\\"{x:736,y:665,t:1527188936454};\\\", \\\"{x:742,y:665,t:1527188936471};\\\", \\\"{x:742,y:667,t:1527188936505};\\\", \\\"{x:742,y:668,t:1527188936561};\\\", \\\"{x:742,y:669,t:1527188936657};\\\", \\\"{x:749,y:662,t:1527188940489};\\\", \\\"{x:784,y:641,t:1527188940496};\\\", \\\"{x:841,y:616,t:1527188940506};\\\", \\\"{x:936,y:580,t:1527188940524};\\\", \\\"{x:1004,y:557,t:1527188940542};\\\", \\\"{x:1084,y:538,t:1527188940557};\\\", \\\"{x:1115,y:525,t:1527188940574};\\\", \\\"{x:1142,y:520,t:1527188940591};\\\", \\\"{x:1160,y:514,t:1527188940607};\\\", \\\"{x:1161,y:513,t:1527188940624};\\\", \\\"{x:1163,y:511,t:1527188940664};\\\", \\\"{x:1164,y:511,t:1527188940674};\\\", \\\"{x:1170,y:512,t:1527188940691};\\\", \\\"{x:1170,y:514,t:1527188940707};\\\", \\\"{x:1171,y:514,t:1527188940724};\\\", \\\"{x:1172,y:515,t:1527188940741};\\\", \\\"{x:1173,y:516,t:1527188940817};\\\", \\\"{x:1177,y:516,t:1527188940824};\\\", \\\"{x:1186,y:516,t:1527188940841};\\\", \\\"{x:1217,y:516,t:1527188940858};\\\", \\\"{x:1265,y:516,t:1527188940874};\\\", \\\"{x:1298,y:518,t:1527188940891};\\\", \\\"{x:1316,y:518,t:1527188940908};\\\", \\\"{x:1321,y:517,t:1527188940924};\\\", \\\"{x:1321,y:516,t:1527188941033};\\\", \\\"{x:1324,y:514,t:1527188941041};\\\", \\\"{x:1327,y:513,t:1527188941058};\\\", \\\"{x:1328,y:511,t:1527188941075};\\\", \\\"{x:1325,y:509,t:1527188941185};\\\", \\\"{x:1323,y:508,t:1527188941193};\\\", \\\"{x:1321,y:507,t:1527188941209};\\\", \\\"{x:1320,y:507,t:1527188941226};\\\", \\\"{x:1319,y:507,t:1527188941282};\\\", \\\"{x:1317,y:506,t:1527188941292};\\\", \\\"{x:1313,y:505,t:1527188941308};\\\", \\\"{x:1310,y:505,t:1527188941326};\\\", \\\"{x:1310,y:504,t:1527188941342};\\\", \\\"{x:1309,y:507,t:1527188941434};\\\", \\\"{x:1309,y:508,t:1527188941443};\\\", \\\"{x:1308,y:516,t:1527188941459};\\\", \\\"{x:1308,y:518,t:1527188941476};\\\", \\\"{x:1308,y:525,t:1527188941493};\\\", \\\"{x:1310,y:530,t:1527188941509};\\\", \\\"{x:1311,y:533,t:1527188941525};\\\", \\\"{x:1312,y:534,t:1527188941543};\\\", \\\"{x:1312,y:536,t:1527188941558};\\\", \\\"{x:1312,y:541,t:1527188941575};\\\", \\\"{x:1312,y:548,t:1527188941592};\\\", \\\"{x:1312,y:553,t:1527188941608};\\\", \\\"{x:1312,y:558,t:1527188941625};\\\", \\\"{x:1312,y:563,t:1527188941642};\\\", \\\"{x:1312,y:567,t:1527188941659};\\\", \\\"{x:1312,y:573,t:1527188941676};\\\", \\\"{x:1312,y:577,t:1527188941693};\\\", \\\"{x:1312,y:582,t:1527188941710};\\\", \\\"{x:1309,y:589,t:1527188941725};\\\", \\\"{x:1309,y:593,t:1527188941743};\\\", \\\"{x:1309,y:598,t:1527188941759};\\\", \\\"{x:1309,y:601,t:1527188941775};\\\", \\\"{x:1308,y:605,t:1527188941792};\\\", \\\"{x:1306,y:610,t:1527188941809};\\\", \\\"{x:1306,y:614,t:1527188941826};\\\", \\\"{x:1306,y:618,t:1527188941843};\\\", \\\"{x:1306,y:621,t:1527188941859};\\\", \\\"{x:1305,y:622,t:1527188941875};\\\", \\\"{x:1305,y:625,t:1527188941892};\\\", \\\"{x:1305,y:629,t:1527188941910};\\\", \\\"{x:1305,y:632,t:1527188941925};\\\", \\\"{x:1305,y:636,t:1527188941943};\\\", \\\"{x:1305,y:638,t:1527188941959};\\\", \\\"{x:1306,y:645,t:1527188941976};\\\", \\\"{x:1308,y:647,t:1527188941993};\\\", \\\"{x:1310,y:651,t:1527188942009};\\\", \\\"{x:1310,y:652,t:1527188942027};\\\", \\\"{x:1310,y:656,t:1527188942042};\\\", \\\"{x:1313,y:662,t:1527188942059};\\\", \\\"{x:1314,y:665,t:1527188942076};\\\", \\\"{x:1314,y:672,t:1527188942092};\\\", \\\"{x:1316,y:677,t:1527188942109};\\\", \\\"{x:1317,y:681,t:1527188942127};\\\", \\\"{x:1317,y:685,t:1527188942142};\\\", \\\"{x:1317,y:688,t:1527188942159};\\\", \\\"{x:1318,y:692,t:1527188942177};\\\", \\\"{x:1318,y:695,t:1527188942193};\\\", \\\"{x:1319,y:697,t:1527188942209};\\\", \\\"{x:1319,y:698,t:1527188942226};\\\", \\\"{x:1319,y:700,t:1527188942243};\\\", \\\"{x:1320,y:701,t:1527188942260};\\\", \\\"{x:1320,y:703,t:1527188942276};\\\", \\\"{x:1320,y:707,t:1527188942293};\\\", \\\"{x:1320,y:711,t:1527188942310};\\\", \\\"{x:1322,y:716,t:1527188942327};\\\", \\\"{x:1324,y:723,t:1527188942343};\\\", \\\"{x:1324,y:729,t:1527188942359};\\\", \\\"{x:1325,y:734,t:1527188942376};\\\", \\\"{x:1326,y:742,t:1527188942393};\\\", \\\"{x:1326,y:747,t:1527188942410};\\\", \\\"{x:1328,y:752,t:1527188942426};\\\", \\\"{x:1328,y:755,t:1527188942444};\\\", \\\"{x:1328,y:761,t:1527188942459};\\\", \\\"{x:1329,y:764,t:1527188942477};\\\", \\\"{x:1329,y:765,t:1527188942494};\\\", \\\"{x:1329,y:767,t:1527188942509};\\\", \\\"{x:1329,y:768,t:1527188942526};\\\", \\\"{x:1329,y:770,t:1527188942543};\\\", \\\"{x:1329,y:771,t:1527188942559};\\\", \\\"{x:1329,y:774,t:1527188942577};\\\", \\\"{x:1328,y:778,t:1527188942593};\\\", \\\"{x:1324,y:785,t:1527188942611};\\\", \\\"{x:1320,y:793,t:1527188942626};\\\", \\\"{x:1319,y:798,t:1527188942643};\\\", \\\"{x:1319,y:801,t:1527188942660};\\\", \\\"{x:1318,y:802,t:1527188942676};\\\", \\\"{x:1318,y:803,t:1527188942729};\\\", \\\"{x:1318,y:804,t:1527188942753};\\\", \\\"{x:1318,y:805,t:1527188942793};\\\", \\\"{x:1318,y:806,t:1527188942810};\\\", \\\"{x:1318,y:807,t:1527188942827};\\\", \\\"{x:1318,y:808,t:1527188942843};\\\", \\\"{x:1318,y:809,t:1527188942860};\\\", \\\"{x:1318,y:813,t:1527188942877};\\\", \\\"{x:1318,y:816,t:1527188942893};\\\", \\\"{x:1318,y:819,t:1527188942911};\\\", \\\"{x:1318,y:821,t:1527188942926};\\\", \\\"{x:1318,y:825,t:1527188942944};\\\", \\\"{x:1316,y:829,t:1527188942960};\\\", \\\"{x:1316,y:832,t:1527188942977};\\\", \\\"{x:1316,y:838,t:1527188942993};\\\", \\\"{x:1316,y:839,t:1527188943011};\\\", \\\"{x:1316,y:842,t:1527188943028};\\\", \\\"{x:1316,y:845,t:1527188943044};\\\", \\\"{x:1316,y:847,t:1527188943061};\\\", \\\"{x:1316,y:850,t:1527188943077};\\\", \\\"{x:1316,y:852,t:1527188943093};\\\", \\\"{x:1316,y:856,t:1527188943111};\\\", \\\"{x:1316,y:859,t:1527188943128};\\\", \\\"{x:1319,y:862,t:1527188943144};\\\", \\\"{x:1319,y:865,t:1527188943161};\\\", \\\"{x:1319,y:867,t:1527188943178};\\\", \\\"{x:1321,y:871,t:1527188943193};\\\", \\\"{x:1321,y:874,t:1527188943210};\\\", \\\"{x:1321,y:877,t:1527188943228};\\\", \\\"{x:1321,y:881,t:1527188943243};\\\", \\\"{x:1321,y:882,t:1527188943260};\\\", \\\"{x:1321,y:886,t:1527188943277};\\\", \\\"{x:1321,y:888,t:1527188943294};\\\", \\\"{x:1321,y:889,t:1527188943311};\\\", \\\"{x:1322,y:892,t:1527188943327};\\\", \\\"{x:1322,y:894,t:1527188943344};\\\", \\\"{x:1322,y:898,t:1527188943360};\\\", \\\"{x:1322,y:902,t:1527188943377};\\\", \\\"{x:1322,y:905,t:1527188943394};\\\", \\\"{x:1322,y:908,t:1527188943410};\\\", \\\"{x:1320,y:910,t:1527188943428};\\\", \\\"{x:1319,y:911,t:1527188943444};\\\", \\\"{x:1319,y:914,t:1527188943460};\\\", \\\"{x:1318,y:918,t:1527188943477};\\\", \\\"{x:1318,y:920,t:1527188943494};\\\", \\\"{x:1317,y:924,t:1527188943510};\\\", \\\"{x:1317,y:926,t:1527188943528};\\\", \\\"{x:1316,y:929,t:1527188943544};\\\", \\\"{x:1316,y:931,t:1527188943560};\\\", \\\"{x:1315,y:933,t:1527188943578};\\\", \\\"{x:1315,y:935,t:1527188943594};\\\", \\\"{x:1315,y:936,t:1527188943612};\\\", \\\"{x:1315,y:938,t:1527188943633};\\\", \\\"{x:1315,y:939,t:1527188943673};\\\", \\\"{x:1315,y:941,t:1527188943697};\\\", \\\"{x:1313,y:942,t:1527188943712};\\\", \\\"{x:1313,y:944,t:1527188943727};\\\", \\\"{x:1311,y:947,t:1527188943745};\\\", \\\"{x:1310,y:949,t:1527188943761};\\\", \\\"{x:1310,y:951,t:1527188943777};\\\", \\\"{x:1310,y:954,t:1527188943817};\\\", \\\"{x:1310,y:955,t:1527188943827};\\\", \\\"{x:1310,y:956,t:1527188943845};\\\", \\\"{x:1310,y:958,t:1527188943864};\\\", \\\"{x:1310,y:960,t:1527188943880};\\\", \\\"{x:1310,y:961,t:1527188943894};\\\", \\\"{x:1309,y:964,t:1527188943911};\\\", \\\"{x:1309,y:965,t:1527188944489};\\\", \\\"{x:1313,y:954,t:1527188944953};\\\", \\\"{x:1317,y:945,t:1527188944963};\\\", \\\"{x:1320,y:927,t:1527188944979};\\\", \\\"{x:1320,y:902,t:1527188944996};\\\", \\\"{x:1320,y:879,t:1527188945013};\\\", \\\"{x:1318,y:862,t:1527188945030};\\\", \\\"{x:1314,y:847,t:1527188945046};\\\", \\\"{x:1311,y:838,t:1527188945062};\\\", \\\"{x:1309,y:827,t:1527188945079};\\\", \\\"{x:1308,y:816,t:1527188945095};\\\", \\\"{x:1305,y:804,t:1527188945113};\\\", \\\"{x:1303,y:786,t:1527188945129};\\\", \\\"{x:1300,y:770,t:1527188945147};\\\", \\\"{x:1300,y:759,t:1527188945162};\\\", \\\"{x:1299,y:753,t:1527188945180};\\\", \\\"{x:1299,y:743,t:1527188945197};\\\", \\\"{x:1299,y:735,t:1527188945213};\\\", \\\"{x:1297,y:725,t:1527188945229};\\\", \\\"{x:1297,y:716,t:1527188945246};\\\", \\\"{x:1296,y:704,t:1527188945262};\\\", \\\"{x:1296,y:698,t:1527188945279};\\\", \\\"{x:1296,y:690,t:1527188945296};\\\", \\\"{x:1293,y:685,t:1527188945313};\\\", \\\"{x:1293,y:684,t:1527188945329};\\\", \\\"{x:1291,y:677,t:1527188945346};\\\", \\\"{x:1291,y:676,t:1527188945362};\\\", \\\"{x:1291,y:673,t:1527188945380};\\\", \\\"{x:1291,y:669,t:1527188945397};\\\", \\\"{x:1291,y:662,t:1527188945413};\\\", \\\"{x:1291,y:654,t:1527188945430};\\\", \\\"{x:1291,y:646,t:1527188945446};\\\", \\\"{x:1291,y:638,t:1527188945463};\\\", \\\"{x:1291,y:629,t:1527188945480};\\\", \\\"{x:1291,y:621,t:1527188945497};\\\", \\\"{x:1294,y:606,t:1527188945513};\\\", \\\"{x:1294,y:598,t:1527188945529};\\\", \\\"{x:1294,y:592,t:1527188945547};\\\", \\\"{x:1294,y:587,t:1527188945563};\\\", \\\"{x:1295,y:583,t:1527188945580};\\\", \\\"{x:1296,y:575,t:1527188945596};\\\", \\\"{x:1297,y:569,t:1527188945613};\\\", \\\"{x:1299,y:558,t:1527188945629};\\\", \\\"{x:1301,y:546,t:1527188945646};\\\", \\\"{x:1305,y:536,t:1527188945663};\\\", \\\"{x:1306,y:528,t:1527188945680};\\\", \\\"{x:1310,y:515,t:1527188945697};\\\", \\\"{x:1312,y:503,t:1527188945714};\\\", \\\"{x:1313,y:499,t:1527188945730};\\\", \\\"{x:1313,y:497,t:1527188945746};\\\", \\\"{x:1314,y:496,t:1527188945764};\\\", \\\"{x:1314,y:495,t:1527189028783};\\\", \\\"{x:1315,y:495,t:1527189029471};\\\", \\\"{x:1316,y:495,t:1527189029486};\\\", \\\"{x:1317,y:495,t:1527189029511};\\\", \\\"{x:1316,y:495,t:1527189030518};\\\", \\\"{x:1315,y:495,t:1527189030583};\\\", \\\"{x:1314,y:495,t:1527189030623};\\\", \\\"{x:1313,y:495,t:1527189030631};\\\", \\\"{x:1312,y:495,t:1527189030687};\\\", \\\"{x:1311,y:495,t:1527189030718};\\\", \\\"{x:1310,y:495,t:1527189030730};\\\", \\\"{x:1312,y:496,t:1527189030966};\\\", \\\"{x:1312,y:497,t:1527189030980};\\\", \\\"{x:1313,y:498,t:1527189031038};\\\", \\\"{x:1313,y:502,t:1527189038071};\\\", \\\"{x:1311,y:511,t:1527189038080};\\\", \\\"{x:1308,y:518,t:1527189038088};\\\", \\\"{x:1299,y:539,t:1527189038105};\\\", \\\"{x:1295,y:556,t:1527189038121};\\\", \\\"{x:1290,y:572,t:1527189038139};\\\", \\\"{x:1288,y:585,t:1527189038156};\\\", \\\"{x:1287,y:596,t:1527189038171};\\\", \\\"{x:1284,y:608,t:1527189038189};\\\", \\\"{x:1283,y:619,t:1527189038206};\\\", \\\"{x:1280,y:641,t:1527189038221};\\\", \\\"{x:1275,y:668,t:1527189038239};\\\", \\\"{x:1271,y:687,t:1527189038255};\\\", \\\"{x:1268,y:700,t:1527189038272};\\\", \\\"{x:1266,y:714,t:1527189038289};\\\", \\\"{x:1264,y:727,t:1527189038305};\\\", \\\"{x:1263,y:736,t:1527189038321};\\\", \\\"{x:1259,y:749,t:1527189038338};\\\", \\\"{x:1256,y:768,t:1527189038356};\\\", \\\"{x:1248,y:782,t:1527189038371};\\\", \\\"{x:1247,y:790,t:1527189038389};\\\", \\\"{x:1245,y:794,t:1527189038405};\\\", \\\"{x:1245,y:796,t:1527189038422};\\\", \\\"{x:1244,y:797,t:1527189038455};\\\", \\\"{x:1241,y:801,t:1527189038494};\\\", \\\"{x:1240,y:802,t:1527189038505};\\\", \\\"{x:1234,y:808,t:1527189038523};\\\", \\\"{x:1231,y:809,t:1527189038539};\\\", \\\"{x:1230,y:811,t:1527189038556};\\\", \\\"{x:1229,y:812,t:1527189038572};\\\", \\\"{x:1228,y:814,t:1527189038599};\\\", \\\"{x:1227,y:814,t:1527189038606};\\\", \\\"{x:1224,y:817,t:1527189038623};\\\", \\\"{x:1222,y:821,t:1527189038639};\\\", \\\"{x:1220,y:823,t:1527189038656};\\\", \\\"{x:1220,y:825,t:1527189038808};\\\", \\\"{x:1219,y:826,t:1527189039063};\\\", \\\"{x:1219,y:827,t:1527189039073};\\\", \\\"{x:1218,y:827,t:1527189039111};\\\", \\\"{x:1217,y:827,t:1527189039126};\\\", \\\"{x:1216,y:827,t:1527189039151};\\\", \\\"{x:1215,y:828,t:1527189044486};\\\", \\\"{x:1215,y:830,t:1527189044503};\\\", \\\"{x:1215,y:841,t:1527189044512};\\\", \\\"{x:1218,y:862,t:1527189044529};\\\", \\\"{x:1221,y:872,t:1527189044546};\\\", \\\"{x:1222,y:880,t:1527189044562};\\\", \\\"{x:1223,y:886,t:1527189044578};\\\", \\\"{x:1224,y:892,t:1527189044595};\\\", \\\"{x:1224,y:895,t:1527189044611};\\\", \\\"{x:1224,y:896,t:1527189044628};\\\", \\\"{x:1224,y:901,t:1527189044645};\\\", \\\"{x:1225,y:906,t:1527189044661};\\\", \\\"{x:1227,y:914,t:1527189044679};\\\", \\\"{x:1228,y:917,t:1527189044695};\\\", \\\"{x:1228,y:920,t:1527189044713};\\\", \\\"{x:1227,y:924,t:1527189044729};\\\", \\\"{x:1225,y:927,t:1527189044746};\\\", \\\"{x:1221,y:934,t:1527189044763};\\\", \\\"{x:1219,y:942,t:1527189044778};\\\", \\\"{x:1216,y:947,t:1527189044796};\\\", \\\"{x:1215,y:952,t:1527189044813};\\\", \\\"{x:1214,y:955,t:1527189044828};\\\", \\\"{x:1213,y:958,t:1527189044846};\\\", \\\"{x:1209,y:971,t:1527189044862};\\\", \\\"{x:1207,y:977,t:1527189044879};\\\", \\\"{x:1207,y:981,t:1527189044896};\\\", \\\"{x:1205,y:984,t:1527189044912};\\\", \\\"{x:1206,y:984,t:1527189045014};\\\", \\\"{x:1207,y:984,t:1527189045028};\\\", \\\"{x:1211,y:984,t:1527189045046};\\\", \\\"{x:1219,y:984,t:1527189045063};\\\", \\\"{x:1221,y:983,t:1527189045095};\\\", \\\"{x:1224,y:982,t:1527189045103};\\\", \\\"{x:1227,y:981,t:1527189045112};\\\", \\\"{x:1231,y:979,t:1527189045130};\\\", \\\"{x:1242,y:975,t:1527189045146};\\\", \\\"{x:1251,y:973,t:1527189045163};\\\", \\\"{x:1257,y:971,t:1527189045179};\\\", \\\"{x:1259,y:970,t:1527189045195};\\\", \\\"{x:1260,y:970,t:1527189045215};\\\", \\\"{x:1261,y:969,t:1527189045551};\\\", \\\"{x:1261,y:968,t:1527189045562};\\\", \\\"{x:1263,y:968,t:1527189045799};\\\", \\\"{x:1264,y:968,t:1527189045814};\\\", \\\"{x:1271,y:968,t:1527189045830};\\\", \\\"{x:1286,y:968,t:1527189045847};\\\", \\\"{x:1292,y:968,t:1527189045864};\\\", \\\"{x:1294,y:968,t:1527189045880};\\\", \\\"{x:1295,y:968,t:1527189046184};\\\", \\\"{x:1296,y:968,t:1527189046200};\\\", \\\"{x:1298,y:968,t:1527189046215};\\\", \\\"{x:1307,y:968,t:1527189046232};\\\", \\\"{x:1309,y:968,t:1527189046247};\\\", \\\"{x:1310,y:968,t:1527189046271};\\\", \\\"{x:1311,y:968,t:1527189046281};\\\", \\\"{x:1312,y:968,t:1527189046368};\\\", \\\"{x:1313,y:968,t:1527189046407};\\\", \\\"{x:1316,y:968,t:1527189046423};\\\", \\\"{x:1320,y:968,t:1527189046431};\\\", \\\"{x:1332,y:968,t:1527189046448};\\\", \\\"{x:1345,y:969,t:1527189046465};\\\", \\\"{x:1353,y:969,t:1527189046481};\\\", \\\"{x:1354,y:969,t:1527189046502};\\\", \\\"{x:1353,y:969,t:1527189051502};\\\", \\\"{x:1351,y:968,t:1527189051567};\\\", \\\"{x:1349,y:968,t:1527189052351};\\\", \\\"{x:1346,y:967,t:1527189052359};\\\", \\\"{x:1339,y:958,t:1527189052371};\\\", \\\"{x:1333,y:951,t:1527189052387};\\\", \\\"{x:1323,y:941,t:1527189052404};\\\", \\\"{x:1315,y:932,t:1527189052421};\\\", \\\"{x:1308,y:924,t:1527189052437};\\\", \\\"{x:1302,y:911,t:1527189052454};\\\", \\\"{x:1295,y:901,t:1527189052470};\\\", \\\"{x:1289,y:894,t:1527189052487};\\\", \\\"{x:1279,y:886,t:1527189052504};\\\", \\\"{x:1272,y:881,t:1527189052521};\\\", \\\"{x:1269,y:878,t:1527189052537};\\\", \\\"{x:1269,y:876,t:1527189052554};\\\", \\\"{x:1266,y:869,t:1527189052571};\\\", \\\"{x:1265,y:866,t:1527189052587};\\\", \\\"{x:1265,y:862,t:1527189052604};\\\", \\\"{x:1265,y:854,t:1527189052621};\\\", \\\"{x:1265,y:847,t:1527189052637};\\\", \\\"{x:1265,y:843,t:1527189052654};\\\", \\\"{x:1265,y:839,t:1527189052671};\\\", \\\"{x:1265,y:838,t:1527189052727};\\\", \\\"{x:1265,y:837,t:1527189052742};\\\", \\\"{x:1265,y:836,t:1527189052758};\\\", \\\"{x:1265,y:835,t:1527189052774};\\\", \\\"{x:1265,y:834,t:1527189052822};\\\", \\\"{x:1266,y:834,t:1527189052855};\\\", \\\"{x:1267,y:834,t:1527189052878};\\\", \\\"{x:1269,y:834,t:1527189052903};\\\", \\\"{x:1270,y:834,t:1527189052911};\\\", \\\"{x:1271,y:834,t:1527189052926};\\\", \\\"{x:1272,y:834,t:1527189052939};\\\", \\\"{x:1276,y:833,t:1527189052955};\\\", \\\"{x:1277,y:833,t:1527189052983};\\\", \\\"{x:1278,y:833,t:1527189053005};\\\", \\\"{x:1280,y:831,t:1527189053927};\\\", \\\"{x:1281,y:829,t:1527189053943};\\\", \\\"{x:1281,y:827,t:1527189053998};\\\", \\\"{x:1282,y:827,t:1527189055038};\\\", \\\"{x:1284,y:829,t:1527189055046};\\\", \\\"{x:1284,y:833,t:1527189055057};\\\", \\\"{x:1284,y:837,t:1527189055074};\\\", \\\"{x:1284,y:844,t:1527189055090};\\\", \\\"{x:1284,y:847,t:1527189055107};\\\", \\\"{x:1284,y:852,t:1527189055123};\\\", \\\"{x:1284,y:855,t:1527189055140};\\\", \\\"{x:1284,y:859,t:1527189055158};\\\", \\\"{x:1284,y:861,t:1527189055173};\\\", \\\"{x:1286,y:863,t:1527189055191};\\\", \\\"{x:1286,y:865,t:1527189055207};\\\", \\\"{x:1286,y:866,t:1527189055238};\\\", \\\"{x:1286,y:868,t:1527189055246};\\\", \\\"{x:1286,y:870,t:1527189055270};\\\", \\\"{x:1286,y:871,t:1527189055279};\\\", \\\"{x:1286,y:872,t:1527189055294};\\\", \\\"{x:1286,y:873,t:1527189055307};\\\", \\\"{x:1286,y:874,t:1527189055324};\\\", \\\"{x:1286,y:877,t:1527189055340};\\\", \\\"{x:1285,y:881,t:1527189055357};\\\", \\\"{x:1281,y:890,t:1527189055375};\\\", \\\"{x:1277,y:898,t:1527189055390};\\\", \\\"{x:1276,y:904,t:1527189055407};\\\", \\\"{x:1273,y:910,t:1527189055424};\\\", \\\"{x:1270,y:919,t:1527189055440};\\\", \\\"{x:1269,y:924,t:1527189055458};\\\", \\\"{x:1267,y:927,t:1527189055474};\\\", \\\"{x:1267,y:931,t:1527189055491};\\\", \\\"{x:1266,y:935,t:1527189055507};\\\", \\\"{x:1266,y:937,t:1527189055524};\\\", \\\"{x:1266,y:939,t:1527189055541};\\\", \\\"{x:1266,y:941,t:1527189055558};\\\", \\\"{x:1266,y:942,t:1527189055574};\\\", \\\"{x:1266,y:943,t:1527189055591};\\\", \\\"{x:1266,y:944,t:1527189055608};\\\", \\\"{x:1266,y:946,t:1527189055625};\\\", \\\"{x:1266,y:949,t:1527189055641};\\\", \\\"{x:1271,y:954,t:1527189055657};\\\", \\\"{x:1276,y:961,t:1527189055675};\\\", \\\"{x:1279,y:963,t:1527189055691};\\\", \\\"{x:1280,y:966,t:1527189055707};\\\", \\\"{x:1281,y:967,t:1527189055724};\\\", \\\"{x:1282,y:967,t:1527189055782};\\\", \\\"{x:1283,y:967,t:1527189055806};\\\", \\\"{x:1284,y:968,t:1527189055814};\\\", \\\"{x:1285,y:968,t:1527189055830};\\\", \\\"{x:1288,y:970,t:1527189055841};\\\", \\\"{x:1302,y:972,t:1527189055858};\\\", \\\"{x:1318,y:975,t:1527189055874};\\\", \\\"{x:1329,y:975,t:1527189055891};\\\", \\\"{x:1341,y:979,t:1527189055908};\\\", \\\"{x:1344,y:979,t:1527189055924};\\\", \\\"{x:1346,y:979,t:1527189055941};\\\", \\\"{x:1348,y:979,t:1527189055958};\\\", \\\"{x:1349,y:979,t:1527189055990};\\\", \\\"{x:1350,y:979,t:1527189056014};\\\", \\\"{x:1352,y:979,t:1527189056024};\\\", \\\"{x:1355,y:978,t:1527189056042};\\\", \\\"{x:1356,y:978,t:1527189056058};\\\", \\\"{x:1359,y:978,t:1527189056075};\\\", \\\"{x:1360,y:977,t:1527189056091};\\\", \\\"{x:1362,y:977,t:1527189056108};\\\", \\\"{x:1364,y:976,t:1527189056135};\\\", \\\"{x:1365,y:976,t:1527189056159};\\\", \\\"{x:1369,y:975,t:1527189056175};\\\", \\\"{x:1371,y:975,t:1527189056191};\\\", \\\"{x:1376,y:973,t:1527189056208};\\\", \\\"{x:1377,y:972,t:1527189056226};\\\", \\\"{x:1379,y:972,t:1527189056294};\\\", \\\"{x:1379,y:971,t:1527189056310};\\\", \\\"{x:1380,y:971,t:1527189056326};\\\", \\\"{x:1382,y:971,t:1527189056358};\\\", \\\"{x:1382,y:970,t:1527189056375};\\\", \\\"{x:1383,y:968,t:1527189056398};\\\", \\\"{x:1384,y:968,t:1527189056430};\\\", \\\"{x:1383,y:967,t:1527189057279};\\\", \\\"{x:1383,y:965,t:1527189057294};\\\", \\\"{x:1383,y:963,t:1527189057309};\\\", \\\"{x:1382,y:959,t:1527189057326};\\\", \\\"{x:1382,y:958,t:1527189057342};\\\", \\\"{x:1381,y:957,t:1527189057951};\\\", \\\"{x:1381,y:956,t:1527189058934};\\\", \\\"{x:1381,y:955,t:1527189058945};\\\", \\\"{x:1383,y:955,t:1527189059022};\\\", \\\"{x:1385,y:956,t:1527189059030};\\\", \\\"{x:1388,y:957,t:1527189059044};\\\", \\\"{x:1390,y:957,t:1527189059062};\\\", \\\"{x:1392,y:958,t:1527189059078};\\\", \\\"{x:1393,y:958,t:1527189059094};\\\", \\\"{x:1393,y:959,t:1527189059118};\\\", \\\"{x:1395,y:959,t:1527189059128};\\\", \\\"{x:1396,y:959,t:1527189059144};\\\", \\\"{x:1399,y:960,t:1527189059190};\\\", \\\"{x:1400,y:960,t:1527189059199};\\\", \\\"{x:1400,y:961,t:1527189059212};\\\", \\\"{x:1401,y:962,t:1527189059228};\\\", \\\"{x:1402,y:963,t:1527189059334};\\\", \\\"{x:1403,y:963,t:1527189059346};\\\", \\\"{x:1406,y:963,t:1527189059362};\\\", \\\"{x:1408,y:965,t:1527189059390};\\\", \\\"{x:1410,y:965,t:1527189059478};\\\", \\\"{x:1412,y:965,t:1527189059496};\\\", \\\"{x:1413,y:965,t:1527189059590};\\\", \\\"{x:1413,y:964,t:1527189059743};\\\", \\\"{x:1413,y:962,t:1527189059766};\\\", \\\"{x:1412,y:962,t:1527189059790};\\\", \\\"{x:1411,y:962,t:1527189059798};\\\", \\\"{x:1410,y:962,t:1527189059812};\\\", \\\"{x:1409,y:962,t:1527189059828};\\\", \\\"{x:1409,y:961,t:1527189059845};\\\", \\\"{x:1410,y:961,t:1527189060504};\\\", \\\"{x:1411,y:961,t:1527189060679};\\\", \\\"{x:1412,y:962,t:1527189060686};\\\", \\\"{x:1413,y:962,t:1527189060831};\\\", \\\"{x:1413,y:960,t:1527189064904};\\\", \\\"{x:1411,y:958,t:1527189064919};\\\", \\\"{x:1408,y:957,t:1527189064935};\\\", \\\"{x:1405,y:951,t:1527189065072};\\\", \\\"{x:1403,y:945,t:1527189065085};\\\", \\\"{x:1399,y:936,t:1527189065102};\\\", \\\"{x:1392,y:929,t:1527189065119};\\\", \\\"{x:1381,y:905,t:1527189065135};\\\", \\\"{x:1376,y:886,t:1527189065153};\\\", \\\"{x:1373,y:871,t:1527189065169};\\\", \\\"{x:1369,y:852,t:1527189065185};\\\", \\\"{x:1369,y:833,t:1527189065202};\\\", \\\"{x:1369,y:818,t:1527189065219};\\\", \\\"{x:1369,y:806,t:1527189065235};\\\", \\\"{x:1365,y:785,t:1527189065252};\\\", \\\"{x:1362,y:768,t:1527189065269};\\\", \\\"{x:1359,y:750,t:1527189065285};\\\", \\\"{x:1355,y:728,t:1527189065303};\\\", \\\"{x:1351,y:707,t:1527189065319};\\\", \\\"{x:1349,y:694,t:1527189065336};\\\", \\\"{x:1347,y:676,t:1527189065353};\\\", \\\"{x:1341,y:658,t:1527189065369};\\\", \\\"{x:1338,y:638,t:1527189065385};\\\", \\\"{x:1340,y:613,t:1527189065402};\\\", \\\"{x:1341,y:606,t:1527189065419};\\\", \\\"{x:1341,y:604,t:1527189065436};\\\", \\\"{x:1341,y:603,t:1527189065452};\\\", \\\"{x:1340,y:605,t:1527189065648};\\\", \\\"{x:1339,y:612,t:1527189065656};\\\", \\\"{x:1336,y:619,t:1527189065669};\\\", \\\"{x:1336,y:626,t:1527189065687};\\\", \\\"{x:1334,y:627,t:1527189065703};\\\", \\\"{x:1332,y:632,t:1527189065719};\\\", \\\"{x:1331,y:634,t:1527189065743};\\\", \\\"{x:1330,y:635,t:1527189065753};\\\", \\\"{x:1330,y:636,t:1527189065770};\\\", \\\"{x:1328,y:638,t:1527189065787};\\\", \\\"{x:1326,y:638,t:1527189065887};\\\", \\\"{x:1324,y:638,t:1527189065903};\\\", \\\"{x:1322,y:638,t:1527189065919};\\\", \\\"{x:1320,y:638,t:1527189065936};\\\", \\\"{x:1319,y:638,t:1527189065954};\\\", \\\"{x:1318,y:638,t:1527189065969};\\\", \\\"{x:1317,y:637,t:1527189065987};\\\", \\\"{x:1317,y:636,t:1527189066003};\\\", \\\"{x:1317,y:635,t:1527189066031};\\\", \\\"{x:1316,y:634,t:1527189066053};\\\", \\\"{x:1315,y:632,t:1527189066069};\\\", \\\"{x:1315,y:631,t:1527189066087};\\\", \\\"{x:1315,y:630,t:1527189067040};\\\", \\\"{x:1315,y:629,t:1527189067151};\\\", \\\"{x:1314,y:631,t:1527189070935};\\\", \\\"{x:1309,y:641,t:1527189070943};\\\", \\\"{x:1305,y:647,t:1527189070959};\\\", \\\"{x:1304,y:651,t:1527189070975};\\\", \\\"{x:1303,y:654,t:1527189070992};\\\", \\\"{x:1303,y:656,t:1527189071008};\\\", \\\"{x:1303,y:657,t:1527189071025};\\\", \\\"{x:1300,y:664,t:1527189071042};\\\", \\\"{x:1295,y:674,t:1527189071058};\\\", \\\"{x:1290,y:683,t:1527189071075};\\\", \\\"{x:1285,y:691,t:1527189071091};\\\", \\\"{x:1279,y:701,t:1527189071108};\\\", \\\"{x:1270,y:713,t:1527189071126};\\\", \\\"{x:1264,y:722,t:1527189071141};\\\", \\\"{x:1255,y:736,t:1527189071158};\\\", \\\"{x:1245,y:753,t:1527189071175};\\\", \\\"{x:1241,y:759,t:1527189071192};\\\", \\\"{x:1237,y:765,t:1527189071209};\\\", \\\"{x:1234,y:769,t:1527189071226};\\\", \\\"{x:1232,y:774,t:1527189071242};\\\", \\\"{x:1225,y:781,t:1527189071258};\\\", \\\"{x:1224,y:784,t:1527189071276};\\\", \\\"{x:1221,y:790,t:1527189071292};\\\", \\\"{x:1217,y:794,t:1527189071308};\\\", \\\"{x:1214,y:800,t:1527189071326};\\\", \\\"{x:1213,y:804,t:1527189071343};\\\", \\\"{x:1211,y:809,t:1527189071359};\\\", \\\"{x:1207,y:816,t:1527189071376};\\\", \\\"{x:1206,y:817,t:1527189071393};\\\", \\\"{x:1204,y:821,t:1527189071409};\\\", \\\"{x:1202,y:824,t:1527189071426};\\\", \\\"{x:1202,y:826,t:1527189071455};\\\", \\\"{x:1202,y:827,t:1527189071504};\\\", \\\"{x:1202,y:829,t:1527189071567};\\\", \\\"{x:1202,y:830,t:1527189071616};\\\", \\\"{x:1202,y:832,t:1527189071696};\\\", \\\"{x:1202,y:833,t:1527189071984};\\\", \\\"{x:1203,y:833,t:1527189072023};\\\", \\\"{x:1205,y:834,t:1527189072279};\\\", \\\"{x:1205,y:835,t:1527189072295};\\\", \\\"{x:1206,y:838,t:1527189072310};\\\", \\\"{x:1209,y:844,t:1527189072327};\\\", \\\"{x:1209,y:847,t:1527189072343};\\\", \\\"{x:1209,y:850,t:1527189072359};\\\", \\\"{x:1209,y:852,t:1527189072376};\\\", \\\"{x:1209,y:853,t:1527189072393};\\\", \\\"{x:1209,y:856,t:1527189072410};\\\", \\\"{x:1209,y:864,t:1527189072426};\\\", \\\"{x:1209,y:869,t:1527189072438};\\\", \\\"{x:1209,y:869,t:1527189072451};\\\", \\\"{x:1208,y:879,t:1527189072994};\\\", \\\"{x:1209,y:879,t:1527189073010};\\\", \\\"{x:1209,y:879,t:1527189073088};\\\", \\\"{x:1211,y:879,t:1527189073143};\\\", \\\"{x:1213,y:876,t:1527189073161};\\\", \\\"{x:1214,y:875,t:1527189073178};\\\", \\\"{x:1214,y:873,t:1527189073194};\\\", \\\"{x:1214,y:871,t:1527189073210};\\\", \\\"{x:1214,y:869,t:1527189073228};\\\", \\\"{x:1215,y:867,t:1527189073247};\\\", \\\"{x:1216,y:866,t:1527189073260};\\\", \\\"{x:1216,y:864,t:1527189073278};\\\", \\\"{x:1217,y:860,t:1527189073295};\\\", \\\"{x:1217,y:859,t:1527189073335};\\\", \\\"{x:1217,y:858,t:1527189073359};\\\", \\\"{x:1217,y:857,t:1527189073375};\\\", \\\"{x:1217,y:856,t:1527189073399};\\\", \\\"{x:1217,y:855,t:1527189073411};\\\", \\\"{x:1217,y:852,t:1527189073428};\\\", \\\"{x:1217,y:849,t:1527189073445};\\\", \\\"{x:1217,y:847,t:1527189073461};\\\", \\\"{x:1218,y:846,t:1527189073478};\\\", \\\"{x:1219,y:844,t:1527189073527};\\\", \\\"{x:1219,y:843,t:1527189073545};\\\", \\\"{x:1221,y:840,t:1527189073562};\\\", \\\"{x:1221,y:839,t:1527189073610};\\\", \\\"{x:1222,y:838,t:1527189073618};\\\", \\\"{x:1222,y:837,t:1527189073954};\\\", \\\"{x:1222,y:835,t:1527189073970};\\\", \\\"{x:1222,y:832,t:1527189073982};\\\", \\\"{x:1222,y:830,t:1527189073998};\\\", \\\"{x:1220,y:825,t:1527189074014};\\\", \\\"{x:1218,y:823,t:1527189074031};\\\", \\\"{x:1218,y:822,t:1527189074434};\\\", \\\"{x:1218,y:823,t:1527189074834};\\\", \\\"{x:1218,y:825,t:1527189074850};\\\", \\\"{x:1215,y:833,t:1527189074866};\\\", \\\"{x:1215,y:837,t:1527189074882};\\\", \\\"{x:1215,y:839,t:1527189074899};\\\", \\\"{x:1215,y:842,t:1527189074916};\\\", \\\"{x:1215,y:845,t:1527189074933};\\\", \\\"{x:1215,y:850,t:1527189074949};\\\", \\\"{x:1215,y:854,t:1527189074965};\\\", \\\"{x:1215,y:858,t:1527189074982};\\\", \\\"{x:1215,y:861,t:1527189074999};\\\", \\\"{x:1215,y:863,t:1527189075016};\\\", \\\"{x:1216,y:866,t:1527189075032};\\\", \\\"{x:1217,y:869,t:1527189075048};\\\", \\\"{x:1217,y:872,t:1527189075066};\\\", \\\"{x:1219,y:875,t:1527189075082};\\\", \\\"{x:1222,y:880,t:1527189075099};\\\", \\\"{x:1222,y:884,t:1527189075115};\\\", \\\"{x:1222,y:888,t:1527189075132};\\\", \\\"{x:1222,y:892,t:1527189075150};\\\", \\\"{x:1222,y:895,t:1527189075165};\\\", \\\"{x:1221,y:899,t:1527189075183};\\\", \\\"{x:1221,y:901,t:1527189075200};\\\", \\\"{x:1221,y:906,t:1527189075216};\\\", \\\"{x:1219,y:909,t:1527189075233};\\\", \\\"{x:1215,y:916,t:1527189075250};\\\", \\\"{x:1214,y:920,t:1527189075265};\\\", \\\"{x:1214,y:925,t:1527189075283};\\\", \\\"{x:1214,y:931,t:1527189075299};\\\", \\\"{x:1214,y:936,t:1527189075316};\\\", \\\"{x:1214,y:938,t:1527189075333};\\\", \\\"{x:1214,y:939,t:1527189075418};\\\", \\\"{x:1214,y:942,t:1527189075433};\\\", \\\"{x:1215,y:944,t:1527189075450};\\\", \\\"{x:1216,y:945,t:1527189075466};\\\", \\\"{x:1217,y:946,t:1527189075523};\\\", \\\"{x:1218,y:948,t:1527189075538};\\\", \\\"{x:1219,y:949,t:1527189075554};\\\", \\\"{x:1219,y:950,t:1527189075566};\\\", \\\"{x:1220,y:950,t:1527189075583};\\\", \\\"{x:1221,y:951,t:1527189075600};\\\", \\\"{x:1222,y:952,t:1527189075617};\\\", \\\"{x:1223,y:953,t:1527189075633};\\\", \\\"{x:1224,y:954,t:1527189075650};\\\", \\\"{x:1225,y:955,t:1527189075666};\\\", \\\"{x:1226,y:956,t:1527189075683};\\\", \\\"{x:1227,y:961,t:1527189075700};\\\", \\\"{x:1228,y:963,t:1527189075717};\\\", \\\"{x:1228,y:964,t:1527189075738};\\\", \\\"{x:1228,y:965,t:1527189075858};\\\", \\\"{x:1230,y:966,t:1527189075874};\\\", \\\"{x:1232,y:967,t:1527189075884};\\\", \\\"{x:1238,y:967,t:1527189075900};\\\", \\\"{x:1241,y:969,t:1527189075917};\\\", \\\"{x:1242,y:970,t:1527189075934};\\\", \\\"{x:1244,y:971,t:1527189075950};\\\", \\\"{x:1245,y:971,t:1527189075978};\\\", \\\"{x:1248,y:971,t:1527189075986};\\\", \\\"{x:1251,y:971,t:1527189076002};\\\", \\\"{x:1255,y:971,t:1527189076017};\\\", \\\"{x:1267,y:975,t:1527189076034};\\\", \\\"{x:1269,y:976,t:1527189076050};\\\", \\\"{x:1275,y:976,t:1527189076066};\\\", \\\"{x:1276,y:976,t:1527189076098};\\\", \\\"{x:1276,y:975,t:1527189076146};\\\", \\\"{x:1276,y:974,t:1527189076154};\\\", \\\"{x:1276,y:973,t:1527189076186};\\\", \\\"{x:1277,y:972,t:1527189076378};\\\", \\\"{x:1277,y:971,t:1527189076538};\\\", \\\"{x:1279,y:969,t:1527189076642};\\\", \\\"{x:1280,y:967,t:1527189076747};\\\", \\\"{x:1283,y:964,t:1527189076754};\\\", \\\"{x:1284,y:963,t:1527189076770};\\\", \\\"{x:1285,y:962,t:1527189076786};\\\", \\\"{x:1285,y:961,t:1527189077354};\\\", \\\"{x:1286,y:961,t:1527189077378};\\\", \\\"{x:1287,y:961,t:1527189077419};\\\", \\\"{x:1288,y:961,t:1527189077435};\\\", \\\"{x:1289,y:961,t:1527189077452};\\\", \\\"{x:1293,y:961,t:1527189077469};\\\", \\\"{x:1295,y:963,t:1527189077485};\\\", \\\"{x:1296,y:964,t:1527189077502};\\\", \\\"{x:1297,y:964,t:1527189077519};\\\", \\\"{x:1299,y:966,t:1527189077535};\\\", \\\"{x:1300,y:967,t:1527189077552};\\\", \\\"{x:1302,y:971,t:1527189077569};\\\", \\\"{x:1307,y:974,t:1527189077585};\\\", \\\"{x:1317,y:980,t:1527189077601};\\\", \\\"{x:1320,y:982,t:1527189077618};\\\", \\\"{x:1324,y:984,t:1527189077635};\\\", \\\"{x:1327,y:985,t:1527189077651};\\\", \\\"{x:1328,y:985,t:1527189077668};\\\", \\\"{x:1329,y:985,t:1527189077685};\\\", \\\"{x:1330,y:985,t:1527189077706};\\\", \\\"{x:1331,y:984,t:1527189077719};\\\", \\\"{x:1334,y:981,t:1527189077735};\\\", \\\"{x:1338,y:978,t:1527189077751};\\\", \\\"{x:1341,y:977,t:1527189077768};\\\", \\\"{x:1345,y:973,t:1527189077786};\\\", \\\"{x:1345,y:972,t:1527189077802};\\\", \\\"{x:1347,y:967,t:1527189077819};\\\", \\\"{x:1349,y:963,t:1527189077835};\\\", \\\"{x:1353,y:959,t:1527189077852};\\\", \\\"{x:1358,y:955,t:1527189077868};\\\", \\\"{x:1359,y:953,t:1527189077886};\\\", \\\"{x:1360,y:953,t:1527189077902};\\\", \\\"{x:1362,y:951,t:1527189077923};\\\", \\\"{x:1361,y:952,t:1527189078194};\\\", \\\"{x:1359,y:955,t:1527189078202};\\\", \\\"{x:1358,y:955,t:1527189078218};\\\", \\\"{x:1358,y:956,t:1527189078658};\\\", \\\"{x:1358,y:958,t:1527189078670};\\\", \\\"{x:1354,y:967,t:1527189078686};\\\", \\\"{x:1351,y:972,t:1527189078703};\\\", \\\"{x:1350,y:974,t:1527189078720};\\\", \\\"{x:1349,y:971,t:1527189078842};\\\", \\\"{x:1349,y:969,t:1527189078857};\\\", \\\"{x:1348,y:969,t:1527189078881};\\\", \\\"{x:1350,y:968,t:1527189079002};\\\", \\\"{x:1365,y:968,t:1527189079019};\\\", \\\"{x:1392,y:972,t:1527189079037};\\\", \\\"{x:1416,y:981,t:1527189079054};\\\", \\\"{x:1435,y:991,t:1527189079071};\\\", \\\"{x:1453,y:993,t:1527189079086};\\\", \\\"{x:1465,y:997,t:1527189079103};\\\", \\\"{x:1466,y:997,t:1527189079118};\\\", \\\"{x:1468,y:997,t:1527189079168};\\\", \\\"{x:1473,y:996,t:1527189079177};\\\", \\\"{x:1477,y:996,t:1527189079193};\\\", \\\"{x:1480,y:996,t:1527189079203};\\\", \\\"{x:1482,y:995,t:1527189079220};\\\", \\\"{x:1484,y:994,t:1527189079236};\\\", \\\"{x:1485,y:993,t:1527189079257};\\\", \\\"{x:1485,y:992,t:1527189079270};\\\", \\\"{x:1487,y:990,t:1527189079287};\\\", \\\"{x:1495,y:987,t:1527189079303};\\\", \\\"{x:1500,y:987,t:1527189079320};\\\", \\\"{x:1506,y:985,t:1527189079337};\\\", \\\"{x:1511,y:984,t:1527189079354};\\\", \\\"{x:1513,y:983,t:1527189079370};\\\", \\\"{x:1515,y:981,t:1527189079387};\\\", \\\"{x:1518,y:980,t:1527189079404};\\\", \\\"{x:1527,y:976,t:1527189079421};\\\", \\\"{x:1533,y:976,t:1527189079437};\\\", \\\"{x:1537,y:976,t:1527189079453};\\\", \\\"{x:1542,y:976,t:1527189079470};\\\", \\\"{x:1547,y:976,t:1527189079487};\\\", \\\"{x:1550,y:976,t:1527189079504};\\\", \\\"{x:1553,y:977,t:1527189079521};\\\", \\\"{x:1558,y:978,t:1527189079537};\\\", \\\"{x:1574,y:980,t:1527189079554};\\\", \\\"{x:1578,y:980,t:1527189079570};\\\", \\\"{x:1580,y:981,t:1527189079588};\\\", \\\"{x:1582,y:981,t:1527189079714};\\\", \\\"{x:1583,y:981,t:1527189079722};\\\", \\\"{x:1585,y:981,t:1527189079738};\\\", \\\"{x:1587,y:981,t:1527189079754};\\\", \\\"{x:1587,y:980,t:1527189079794};\\\", \\\"{x:1587,y:979,t:1527189079833};\\\", \\\"{x:1587,y:978,t:1527189079842};\\\", \\\"{x:1587,y:975,t:1527189079855};\\\", \\\"{x:1587,y:974,t:1527189079870};\\\", \\\"{x:1587,y:972,t:1527189079888};\\\", \\\"{x:1586,y:970,t:1527189079905};\\\", \\\"{x:1584,y:968,t:1527189079922};\\\", \\\"{x:1583,y:967,t:1527189079946};\\\", \\\"{x:1582,y:967,t:1527189079962};\\\", \\\"{x:1580,y:967,t:1527189080011};\\\", \\\"{x:1580,y:966,t:1527189080021};\\\", \\\"{x:1576,y:964,t:1527189081787};\\\", \\\"{x:1568,y:955,t:1527189081794};\\\", \\\"{x:1560,y:947,t:1527189081807};\\\", \\\"{x:1531,y:929,t:1527189081822};\\\", \\\"{x:1503,y:908,t:1527189081839};\\\", \\\"{x:1479,y:890,t:1527189081856};\\\", \\\"{x:1452,y:874,t:1527189081872};\\\", \\\"{x:1439,y:866,t:1527189081889};\\\", \\\"{x:1437,y:860,t:1527189081906};\\\", \\\"{x:1431,y:851,t:1527189081923};\\\", \\\"{x:1427,y:845,t:1527189081939};\\\", \\\"{x:1416,y:831,t:1527189081957};\\\", \\\"{x:1398,y:818,t:1527189081973};\\\", \\\"{x:1383,y:807,t:1527189081990};\\\", \\\"{x:1369,y:793,t:1527189082007};\\\", \\\"{x:1363,y:787,t:1527189082023};\\\", \\\"{x:1361,y:783,t:1527189082039};\\\", \\\"{x:1360,y:780,t:1527189082056};\\\", \\\"{x:1358,y:777,t:1527189082073};\\\", \\\"{x:1358,y:776,t:1527189082090};\\\", \\\"{x:1358,y:774,t:1527189082107};\\\", \\\"{x:1357,y:772,t:1527189082124};\\\", \\\"{x:1357,y:771,t:1527189082140};\\\", \\\"{x:1358,y:770,t:1527189082242};\\\", \\\"{x:1359,y:770,t:1527189082258};\\\", \\\"{x:1362,y:768,t:1527189082274};\\\", \\\"{x:1363,y:768,t:1527189082290};\\\", \\\"{x:1365,y:768,t:1527189082307};\\\", \\\"{x:1368,y:769,t:1527189082324};\\\", \\\"{x:1370,y:770,t:1527189082340};\\\", \\\"{x:1371,y:771,t:1527189082357};\\\", \\\"{x:1373,y:772,t:1527189082418};\\\", \\\"{x:1374,y:772,t:1527189082658};\\\", \\\"{x:1375,y:771,t:1527189082674};\\\", \\\"{x:1376,y:771,t:1527189082795};\\\", \\\"{x:1377,y:768,t:1527189082810};\\\", \\\"{x:1380,y:766,t:1527189082826};\\\", \\\"{x:1381,y:764,t:1527189082858};\\\", \\\"{x:1382,y:767,t:1527189083122};\\\", \\\"{x:1382,y:770,t:1527189083131};\\\", \\\"{x:1383,y:776,t:1527189083141};\\\", \\\"{x:1384,y:782,t:1527189083158};\\\", \\\"{x:1385,y:791,t:1527189083175};\\\", \\\"{x:1385,y:799,t:1527189083191};\\\", \\\"{x:1385,y:806,t:1527189083208};\\\", \\\"{x:1388,y:813,t:1527189083225};\\\", \\\"{x:1389,y:820,t:1527189083242};\\\", \\\"{x:1391,y:824,t:1527189083258};\\\", \\\"{x:1392,y:827,t:1527189083276};\\\", \\\"{x:1392,y:832,t:1527189083291};\\\", \\\"{x:1392,y:833,t:1527189083308};\\\", \\\"{x:1392,y:837,t:1527189083325};\\\", \\\"{x:1392,y:840,t:1527189083342};\\\", \\\"{x:1391,y:844,t:1527189083358};\\\", \\\"{x:1390,y:851,t:1527189083375};\\\", \\\"{x:1389,y:855,t:1527189083392};\\\", \\\"{x:1387,y:860,t:1527189083408};\\\", \\\"{x:1386,y:866,t:1527189083425};\\\", \\\"{x:1386,y:872,t:1527189083442};\\\", \\\"{x:1385,y:878,t:1527189083458};\\\", \\\"{x:1383,y:885,t:1527189083475};\\\", \\\"{x:1382,y:890,t:1527189083492};\\\", \\\"{x:1379,y:896,t:1527189083508};\\\", \\\"{x:1379,y:902,t:1527189083525};\\\", \\\"{x:1378,y:906,t:1527189083543};\\\", \\\"{x:1378,y:909,t:1527189083558};\\\", \\\"{x:1378,y:911,t:1527189083575};\\\", \\\"{x:1378,y:912,t:1527189083592};\\\", \\\"{x:1378,y:915,t:1527189083608};\\\", \\\"{x:1379,y:918,t:1527189083625};\\\", \\\"{x:1382,y:925,t:1527189083642};\\\", \\\"{x:1384,y:930,t:1527189083660};\\\", \\\"{x:1385,y:935,t:1527189083675};\\\", \\\"{x:1386,y:940,t:1527189083693};\\\", \\\"{x:1386,y:941,t:1527189083709};\\\", \\\"{x:1387,y:942,t:1527189083725};\\\", \\\"{x:1387,y:943,t:1527189083754};\\\", \\\"{x:1388,y:943,t:1527189083762};\\\", \\\"{x:1389,y:943,t:1527189083786};\\\", \\\"{x:1389,y:944,t:1527189083794};\\\", \\\"{x:1390,y:944,t:1527189083808};\\\", \\\"{x:1390,y:945,t:1527189083825};\\\", \\\"{x:1390,y:946,t:1527189083841};\\\", \\\"{x:1390,y:947,t:1527189083881};\\\", \\\"{x:1390,y:948,t:1527189083905};\\\", \\\"{x:1390,y:950,t:1527189083929};\\\", \\\"{x:1390,y:951,t:1527189083961};\\\", \\\"{x:1390,y:953,t:1527189084067};\\\", \\\"{x:1390,y:954,t:1527189084081};\\\", \\\"{x:1390,y:957,t:1527189084092};\\\", \\\"{x:1390,y:964,t:1527189084109};\\\", \\\"{x:1390,y:968,t:1527189084126};\\\", \\\"{x:1390,y:973,t:1527189084142};\\\", \\\"{x:1390,y:974,t:1527189084159};\\\", \\\"{x:1390,y:975,t:1527189084176};\\\", \\\"{x:1389,y:976,t:1527189084274};\\\", \\\"{x:1387,y:976,t:1527189084282};\\\", \\\"{x:1386,y:976,t:1527189084293};\\\", \\\"{x:1385,y:973,t:1527189084309};\\\", \\\"{x:1384,y:972,t:1527189084326};\\\", \\\"{x:1383,y:969,t:1527189084343};\\\", \\\"{x:1382,y:969,t:1527189084450};\\\", \\\"{x:1381,y:968,t:1527189084459};\\\", \\\"{x:1381,y:966,t:1527189084476};\\\", \\\"{x:1381,y:965,t:1527189084506};\\\", \\\"{x:1381,y:964,t:1527189085258};\\\", \\\"{x:1382,y:964,t:1527189085282};\\\", \\\"{x:1383,y:964,t:1527189085395};\\\", \\\"{x:1385,y:964,t:1527189085418};\\\", \\\"{x:1386,y:964,t:1527189085434};\\\", \\\"{x:1388,y:965,t:1527189085458};\\\", \\\"{x:1389,y:965,t:1527189085465};\\\", \\\"{x:1390,y:966,t:1527189085481};\\\", \\\"{x:1391,y:966,t:1527189085506};\\\", \\\"{x:1392,y:968,t:1527189085522};\\\", \\\"{x:1393,y:968,t:1527189085537};\\\", \\\"{x:1393,y:969,t:1527189085545};\\\", \\\"{x:1394,y:969,t:1527189085561};\\\", \\\"{x:1396,y:969,t:1527189085586};\\\", \\\"{x:1397,y:969,t:1527189085601};\\\", \\\"{x:1398,y:970,t:1527189085611};\\\", \\\"{x:1398,y:971,t:1527189085627};\\\", \\\"{x:1401,y:972,t:1527189085644};\\\", \\\"{x:1402,y:972,t:1527189085661};\\\", \\\"{x:1405,y:972,t:1527189085677};\\\", \\\"{x:1413,y:973,t:1527189085694};\\\", \\\"{x:1426,y:976,t:1527189085711};\\\", \\\"{x:1432,y:979,t:1527189085727};\\\", \\\"{x:1438,y:979,t:1527189085745};\\\", \\\"{x:1441,y:979,t:1527189085761};\\\", \\\"{x:1442,y:979,t:1527189085777};\\\", \\\"{x:1443,y:979,t:1527189085945};\\\", \\\"{x:1445,y:979,t:1527189085960};\\\", \\\"{x:1446,y:978,t:1527189085978};\\\", \\\"{x:1447,y:977,t:1527189086002};\\\", \\\"{x:1449,y:976,t:1527189086033};\\\", \\\"{x:1449,y:975,t:1527189086226};\\\", \\\"{x:1449,y:974,t:1527189086258};\\\", \\\"{x:1450,y:974,t:1527189086273};\\\", \\\"{x:1450,y:973,t:1527189086289};\\\", \\\"{x:1450,y:972,t:1527189086306};\\\", \\\"{x:1451,y:972,t:1527189086363};\\\", \\\"{x:1454,y:972,t:1527189086378};\\\", \\\"{x:1455,y:972,t:1527189086395};\\\", \\\"{x:1458,y:972,t:1527189086411};\\\", \\\"{x:1463,y:974,t:1527189086428};\\\", \\\"{x:1469,y:978,t:1527189086445};\\\", \\\"{x:1472,y:982,t:1527189086461};\\\", \\\"{x:1475,y:985,t:1527189086479};\\\", \\\"{x:1478,y:987,t:1527189086495};\\\", \\\"{x:1479,y:987,t:1527189086522};\\\", \\\"{x:1480,y:987,t:1527189086530};\\\", \\\"{x:1481,y:987,t:1527189086545};\\\", \\\"{x:1486,y:987,t:1527189086562};\\\", \\\"{x:1494,y:987,t:1527189086578};\\\", \\\"{x:1506,y:987,t:1527189086595};\\\", \\\"{x:1513,y:987,t:1527189086612};\\\", \\\"{x:1518,y:987,t:1527189086628};\\\", \\\"{x:1521,y:987,t:1527189086645};\\\", \\\"{x:1522,y:987,t:1527189086662};\\\", \\\"{x:1523,y:985,t:1527189086678};\\\", \\\"{x:1523,y:984,t:1527189086698};\\\", \\\"{x:1523,y:982,t:1527189086712};\\\", \\\"{x:1524,y:979,t:1527189086728};\\\", \\\"{x:1524,y:978,t:1527189086746};\\\", \\\"{x:1525,y:977,t:1527189086762};\\\", \\\"{x:1525,y:976,t:1527189086779};\\\", \\\"{x:1525,y:974,t:1527189086795};\\\", \\\"{x:1525,y:973,t:1527189086812};\\\", \\\"{x:1525,y:971,t:1527189086829};\\\", \\\"{x:1525,y:969,t:1527189086845};\\\", \\\"{x:1524,y:966,t:1527189086862};\\\", \\\"{x:1525,y:966,t:1527189087034};\\\", \\\"{x:1525,y:969,t:1527189087045};\\\", \\\"{x:1525,y:970,t:1527189087066};\\\", \\\"{x:1525,y:972,t:1527189087079};\\\", \\\"{x:1525,y:973,t:1527189087096};\\\", \\\"{x:1527,y:974,t:1527189087113};\\\", \\\"{x:1529,y:976,t:1527189087130};\\\", \\\"{x:1535,y:979,t:1527189087146};\\\", \\\"{x:1539,y:981,t:1527189087162};\\\", \\\"{x:1542,y:983,t:1527189087179};\\\", \\\"{x:1545,y:984,t:1527189087196};\\\", \\\"{x:1546,y:984,t:1527189087212};\\\", \\\"{x:1548,y:985,t:1527189087230};\\\", \\\"{x:1549,y:985,t:1527189087250};\\\", \\\"{x:1552,y:985,t:1527189087263};\\\", \\\"{x:1555,y:985,t:1527189087279};\\\", \\\"{x:1559,y:986,t:1527189087296};\\\", \\\"{x:1563,y:986,t:1527189087313};\\\", \\\"{x:1565,y:986,t:1527189087330};\\\", \\\"{x:1566,y:986,t:1527189087362};\\\", \\\"{x:1567,y:986,t:1527189087386};\\\", \\\"{x:1568,y:986,t:1527189087396};\\\", \\\"{x:1569,y:986,t:1527189087417};\\\", \\\"{x:1571,y:986,t:1527189087433};\\\", \\\"{x:1572,y:985,t:1527189087466};\\\", \\\"{x:1573,y:984,t:1527189087506};\\\", \\\"{x:1574,y:983,t:1527189087513};\\\", \\\"{x:1575,y:982,t:1527189087529};\\\", \\\"{x:1576,y:981,t:1527189087545};\\\", \\\"{x:1577,y:980,t:1527189087563};\\\", \\\"{x:1578,y:980,t:1527189087585};\\\", \\\"{x:1579,y:980,t:1527189087596};\\\", \\\"{x:1580,y:979,t:1527189087650};\\\", \\\"{x:1580,y:978,t:1527189087664};\\\", \\\"{x:1581,y:978,t:1527189087679};\\\", \\\"{x:1582,y:976,t:1527189087705};\\\", \\\"{x:1583,y:974,t:1527189087817};\\\", \\\"{x:1584,y:973,t:1527189087829};\\\", \\\"{x:1584,y:972,t:1527189087865};\\\", \\\"{x:1584,y:971,t:1527189087905};\\\", \\\"{x:1584,y:970,t:1527189087929};\\\", \\\"{x:1584,y:969,t:1527189087946};\\\", \\\"{x:1584,y:968,t:1527189087963};\\\", \\\"{x:1584,y:967,t:1527189087994};\\\", \\\"{x:1584,y:966,t:1527189088002};\\\", \\\"{x:1584,y:965,t:1527189088014};\\\", \\\"{x:1582,y:964,t:1527189088571};\\\", \\\"{x:1581,y:962,t:1527189088581};\\\", \\\"{x:1578,y:962,t:1527189090714};\\\", \\\"{x:1575,y:962,t:1527189090722};\\\", \\\"{x:1569,y:966,t:1527189090734};\\\", \\\"{x:1554,y:971,t:1527189090749};\\\", \\\"{x:1542,y:980,t:1527189090766};\\\", \\\"{x:1531,y:987,t:1527189090784};\\\", \\\"{x:1529,y:988,t:1527189090800};\\\", \\\"{x:1528,y:988,t:1527189090890};\\\", \\\"{x:1525,y:988,t:1527189090899};\\\", \\\"{x:1512,y:988,t:1527189090916};\\\", \\\"{x:1502,y:990,t:1527189090933};\\\", \\\"{x:1495,y:991,t:1527189090950};\\\", \\\"{x:1491,y:991,t:1527189090966};\\\", \\\"{x:1489,y:991,t:1527189091074};\\\", \\\"{x:1488,y:990,t:1527189091084};\\\", \\\"{x:1487,y:990,t:1527189091101};\\\", \\\"{x:1486,y:989,t:1527189091186};\\\", \\\"{x:1486,y:988,t:1527189091218};\\\", \\\"{x:1486,y:987,t:1527189091233};\\\", \\\"{x:1486,y:985,t:1527189091258};\\\", \\\"{x:1486,y:984,t:1527189091282};\\\", \\\"{x:1487,y:981,t:1527189091300};\\\", \\\"{x:1487,y:978,t:1527189091318};\\\", \\\"{x:1489,y:977,t:1527189091333};\\\", \\\"{x:1490,y:975,t:1527189091351};\\\", \\\"{x:1490,y:974,t:1527189091474};\\\", \\\"{x:1490,y:972,t:1527189091483};\\\", \\\"{x:1490,y:971,t:1527189091578};\\\", \\\"{x:1490,y:969,t:1527189091658};\\\", \\\"{x:1489,y:968,t:1527189091715};\\\", \\\"{x:1488,y:968,t:1527189091994};\\\", \\\"{x:1487,y:968,t:1527189092066};\\\", \\\"{x:1485,y:968,t:1527189092085};\\\", \\\"{x:1484,y:967,t:1527189092102};\\\", \\\"{x:1483,y:967,t:1527189092117};\\\", \\\"{x:1472,y:967,t:1527189093786};\\\", \\\"{x:1453,y:967,t:1527189093803};\\\", \\\"{x:1406,y:967,t:1527189093819};\\\", \\\"{x:1387,y:970,t:1527189093836};\\\", \\\"{x:1384,y:970,t:1527189093852};\\\", \\\"{x:1382,y:970,t:1527189093913};\\\", \\\"{x:1380,y:970,t:1527189093921};\\\", \\\"{x:1376,y:970,t:1527189093936};\\\", \\\"{x:1352,y:971,t:1527189093953};\\\", \\\"{x:1343,y:971,t:1527189093969};\\\", \\\"{x:1341,y:971,t:1527189093986};\\\", \\\"{x:1341,y:970,t:1527189094130};\\\", \\\"{x:1341,y:968,t:1527189094138};\\\", \\\"{x:1341,y:967,t:1527189094218};\\\", \\\"{x:1343,y:967,t:1527189094233};\\\", \\\"{x:1344,y:967,t:1527189094250};\\\", \\\"{x:1346,y:967,t:1527189094273};\\\", \\\"{x:1347,y:967,t:1527189094286};\\\", \\\"{x:1350,y:967,t:1527189094304};\\\", \\\"{x:1354,y:967,t:1527189094320};\\\", \\\"{x:1358,y:967,t:1527189094336};\\\", \\\"{x:1366,y:967,t:1527189094354};\\\", \\\"{x:1369,y:967,t:1527189094370};\\\", \\\"{x:1370,y:967,t:1527189094387};\\\", \\\"{x:1371,y:966,t:1527189094424};\\\", \\\"{x:1372,y:966,t:1527189094513};\\\", \\\"{x:1372,y:965,t:1527189094536};\\\", \\\"{x:1371,y:964,t:1527189094609};\\\", \\\"{x:1370,y:964,t:1527189094633};\\\", \\\"{x:1369,y:964,t:1527189094641};\\\", \\\"{x:1368,y:964,t:1527189094658};\\\", \\\"{x:1367,y:963,t:1527189094673};\\\", \\\"{x:1365,y:963,t:1527189094689};\\\", \\\"{x:1365,y:962,t:1527189094730};\\\", \\\"{x:1365,y:961,t:1527189094738};\\\", \\\"{x:1362,y:958,t:1527189095458};\\\", \\\"{x:1360,y:950,t:1527189095472};\\\", \\\"{x:1357,y:937,t:1527189095489};\\\", \\\"{x:1355,y:923,t:1527189095505};\\\", \\\"{x:1352,y:917,t:1527189095521};\\\", \\\"{x:1352,y:915,t:1527189095538};\\\", \\\"{x:1352,y:913,t:1527189095562};\\\", \\\"{x:1352,y:912,t:1527189095610};\\\", \\\"{x:1352,y:910,t:1527189095634};\\\", \\\"{x:1352,y:908,t:1527189095641};\\\", \\\"{x:1352,y:906,t:1527189095730};\\\", \\\"{x:1352,y:905,t:1527189095754};\\\", \\\"{x:1352,y:904,t:1527189095762};\\\", \\\"{x:1352,y:903,t:1527189095771};\\\", \\\"{x:1352,y:902,t:1527189095794};\\\", \\\"{x:1351,y:901,t:1527189095867};\\\", \\\"{x:1351,y:900,t:1527189096162};\\\", \\\"{x:1352,y:900,t:1527189096178};\\\", \\\"{x:1355,y:900,t:1527189096189};\\\", \\\"{x:1360,y:900,t:1527189096206};\\\", \\\"{x:1367,y:901,t:1527189096223};\\\", \\\"{x:1371,y:903,t:1527189096239};\\\", \\\"{x:1376,y:905,t:1527189096255};\\\", \\\"{x:1382,y:905,t:1527189096273};\\\", \\\"{x:1383,y:905,t:1527189096314};\\\", \\\"{x:1386,y:904,t:1527189096322};\\\", \\\"{x:1391,y:903,t:1527189096339};\\\", \\\"{x:1399,y:903,t:1527189096356};\\\", \\\"{x:1407,y:903,t:1527189096373};\\\", \\\"{x:1411,y:902,t:1527189096390};\\\", \\\"{x:1414,y:902,t:1527189096406};\\\", \\\"{x:1415,y:902,t:1527189096426};\\\", \\\"{x:1417,y:902,t:1527189096440};\\\", \\\"{x:1420,y:900,t:1527189096456};\\\", \\\"{x:1427,y:900,t:1527189096473};\\\", \\\"{x:1438,y:900,t:1527189096489};\\\", \\\"{x:1443,y:899,t:1527189096505};\\\", \\\"{x:1447,y:898,t:1527189096523};\\\", \\\"{x:1448,y:898,t:1527189096540};\\\", \\\"{x:1452,y:897,t:1527189096556};\\\", \\\"{x:1455,y:897,t:1527189096573};\\\", \\\"{x:1460,y:897,t:1527189096589};\\\", \\\"{x:1462,y:897,t:1527189096607};\\\", \\\"{x:1466,y:896,t:1527189096623};\\\", \\\"{x:1470,y:895,t:1527189096640};\\\", \\\"{x:1472,y:895,t:1527189096656};\\\", \\\"{x:1474,y:895,t:1527189096673};\\\", \\\"{x:1476,y:895,t:1527189096690};\\\", \\\"{x:1479,y:895,t:1527189096706};\\\", \\\"{x:1480,y:895,t:1527189096723};\\\", \\\"{x:1484,y:895,t:1527189096740};\\\", \\\"{x:1489,y:896,t:1527189096757};\\\", \\\"{x:1490,y:896,t:1527189096773};\\\", \\\"{x:1491,y:896,t:1527189096791};\\\", \\\"{x:1492,y:896,t:1527189096806};\\\", \\\"{x:1494,y:897,t:1527189096823};\\\", \\\"{x:1496,y:898,t:1527189096840};\\\", \\\"{x:1497,y:899,t:1527189096857};\\\", \\\"{x:1498,y:899,t:1527189096946};\\\", \\\"{x:1499,y:899,t:1527189096957};\\\", \\\"{x:1494,y:901,t:1527189097082};\\\", \\\"{x:1491,y:903,t:1527189097090};\\\", \\\"{x:1486,y:904,t:1527189097107};\\\", \\\"{x:1482,y:905,t:1527189097124};\\\", \\\"{x:1474,y:905,t:1527189097140};\\\", \\\"{x:1470,y:906,t:1527189097156};\\\", \\\"{x:1467,y:907,t:1527189097174};\\\", \\\"{x:1465,y:907,t:1527189097234};\\\", \\\"{x:1464,y:907,t:1527189097242};\\\", \\\"{x:1459,y:907,t:1527189097256};\\\", \\\"{x:1450,y:908,t:1527189097273};\\\", \\\"{x:1447,y:908,t:1527189097290};\\\", \\\"{x:1444,y:909,t:1527189097402};\\\", \\\"{x:1443,y:910,t:1527189097410};\\\", \\\"{x:1442,y:910,t:1527189097426};\\\", \\\"{x:1442,y:911,t:1527189098634};\\\", \\\"{x:1443,y:912,t:1527189098649};\\\", \\\"{x:1444,y:913,t:1527189098666};\\\", \\\"{x:1445,y:915,t:1527189098675};\\\", \\\"{x:1448,y:921,t:1527189098692};\\\", \\\"{x:1449,y:922,t:1527189098709};\\\", \\\"{x:1450,y:924,t:1527189098724};\\\", \\\"{x:1452,y:926,t:1527189098742};\\\", \\\"{x:1453,y:928,t:1527189098758};\\\", \\\"{x:1456,y:932,t:1527189098775};\\\", \\\"{x:1458,y:937,t:1527189098792};\\\", \\\"{x:1466,y:941,t:1527189098809};\\\", \\\"{x:1475,y:948,t:1527189098825};\\\", \\\"{x:1487,y:954,t:1527189098842};\\\", \\\"{x:1491,y:956,t:1527189098859};\\\", \\\"{x:1495,y:959,t:1527189098876};\\\", \\\"{x:1498,y:961,t:1527189098892};\\\", \\\"{x:1499,y:962,t:1527189098909};\\\", \\\"{x:1504,y:966,t:1527189098926};\\\", \\\"{x:1517,y:970,t:1527189098942};\\\", \\\"{x:1522,y:973,t:1527189098959};\\\", \\\"{x:1527,y:975,t:1527189098975};\\\", \\\"{x:1531,y:975,t:1527189098991};\\\", \\\"{x:1532,y:975,t:1527189099009};\\\", \\\"{x:1533,y:975,t:1527189099026};\\\", \\\"{x:1535,y:974,t:1527189099090};\\\", \\\"{x:1536,y:973,t:1527189099097};\\\", \\\"{x:1539,y:971,t:1527189099109};\\\", \\\"{x:1542,y:969,t:1527189099126};\\\", \\\"{x:1546,y:965,t:1527189099143};\\\", \\\"{x:1548,y:963,t:1527189099159};\\\", \\\"{x:1550,y:962,t:1527189099219};\\\", \\\"{x:1553,y:962,t:1527189099250};\\\", \\\"{x:1554,y:960,t:1527189099266};\\\", \\\"{x:1555,y:959,t:1527189099281};\\\", \\\"{x:1556,y:959,t:1527189099298};\\\", \\\"{x:1557,y:959,t:1527189099314};\\\", \\\"{x:1557,y:957,t:1527189099326};\\\", \\\"{x:1561,y:956,t:1527189099343};\\\", \\\"{x:1563,y:954,t:1527189099359};\\\", \\\"{x:1567,y:954,t:1527189099376};\\\", \\\"{x:1568,y:953,t:1527189099393};\\\", \\\"{x:1569,y:953,t:1527189099409};\\\", \\\"{x:1570,y:953,t:1527189099458};\\\", \\\"{x:1571,y:953,t:1527189099554};\\\", \\\"{x:1572,y:954,t:1527189099570};\\\", \\\"{x:1573,y:954,t:1527189099577};\\\", \\\"{x:1574,y:956,t:1527189099682};\\\", \\\"{x:1576,y:956,t:1527189099714};\\\", \\\"{x:1577,y:957,t:1527189099738};\\\", \\\"{x:1579,y:958,t:1527189099769};\\\", \\\"{x:1580,y:960,t:1527189099786};\\\", \\\"{x:1582,y:961,t:1527189099802};\\\", \\\"{x:1579,y:961,t:1527189103074};\\\", \\\"{x:1574,y:958,t:1527189103081};\\\", \\\"{x:1568,y:954,t:1527189103097};\\\", \\\"{x:1556,y:949,t:1527189103113};\\\", \\\"{x:1534,y:937,t:1527189103130};\\\", \\\"{x:1511,y:921,t:1527189103147};\\\", \\\"{x:1488,y:902,t:1527189103163};\\\", \\\"{x:1458,y:873,t:1527189103180};\\\", \\\"{x:1417,y:843,t:1527189103197};\\\", \\\"{x:1356,y:799,t:1527189103213};\\\", \\\"{x:1302,y:773,t:1527189103229};\\\", \\\"{x:1270,y:758,t:1527189103247};\\\", \\\"{x:1264,y:753,t:1527189103262};\\\", \\\"{x:1263,y:752,t:1527189103280};\\\", \\\"{x:1263,y:750,t:1527189103330};\\\", \\\"{x:1263,y:748,t:1527189103346};\\\", \\\"{x:1264,y:746,t:1527189103364};\\\", \\\"{x:1267,y:746,t:1527189103380};\\\", \\\"{x:1284,y:746,t:1527189103397};\\\", \\\"{x:1296,y:752,t:1527189103414};\\\", \\\"{x:1315,y:764,t:1527189103430};\\\", \\\"{x:1332,y:776,t:1527189103447};\\\", \\\"{x:1343,y:785,t:1527189103464};\\\", \\\"{x:1354,y:792,t:1527189103480};\\\", \\\"{x:1362,y:797,t:1527189103497};\\\", \\\"{x:1363,y:795,t:1527189103602};\\\", \\\"{x:1365,y:790,t:1527189103614};\\\", \\\"{x:1367,y:785,t:1527189103631};\\\", \\\"{x:1370,y:778,t:1527189103647};\\\", \\\"{x:1372,y:777,t:1527189103664};\\\", \\\"{x:1373,y:775,t:1527189103681};\\\", \\\"{x:1374,y:775,t:1527189104090};\\\", \\\"{x:1375,y:774,t:1527189104098};\\\", \\\"{x:1375,y:773,t:1527189104114};\\\", \\\"{x:1375,y:772,t:1527189104131};\\\", \\\"{x:1376,y:772,t:1527189104170};\\\", \\\"{x:1376,y:770,t:1527189104186};\\\", \\\"{x:1378,y:769,t:1527189104198};\\\", \\\"{x:1379,y:768,t:1527189104218};\\\", \\\"{x:1380,y:768,t:1527189104231};\\\", \\\"{x:1381,y:766,t:1527189104248};\\\", \\\"{x:1381,y:765,t:1527189104370};\\\", \\\"{x:1382,y:763,t:1527189104381};\\\", \\\"{x:1382,y:762,t:1527189104397};\\\", \\\"{x:1384,y:763,t:1527189105337};\\\", \\\"{x:1384,y:766,t:1527189105349};\\\", \\\"{x:1385,y:775,t:1527189105367};\\\", \\\"{x:1385,y:789,t:1527189105382};\\\", \\\"{x:1385,y:799,t:1527189105399};\\\", \\\"{x:1385,y:806,t:1527189105416};\\\", \\\"{x:1385,y:810,t:1527189105432};\\\", \\\"{x:1387,y:813,t:1527189105449};\\\", \\\"{x:1390,y:822,t:1527189105466};\\\", \\\"{x:1391,y:824,t:1527189105483};\\\", \\\"{x:1392,y:828,t:1527189105499};\\\", \\\"{x:1395,y:834,t:1527189105516};\\\", \\\"{x:1396,y:838,t:1527189105533};\\\", \\\"{x:1397,y:839,t:1527189105550};\\\", \\\"{x:1399,y:845,t:1527189105566};\\\", \\\"{x:1400,y:849,t:1527189105583};\\\", \\\"{x:1401,y:856,t:1527189105599};\\\", \\\"{x:1402,y:866,t:1527189105616};\\\", \\\"{x:1404,y:875,t:1527189105633};\\\", \\\"{x:1404,y:881,t:1527189105649};\\\", \\\"{x:1404,y:892,t:1527189105666};\\\", \\\"{x:1404,y:898,t:1527189105683};\\\", \\\"{x:1404,y:904,t:1527189105699};\\\", \\\"{x:1404,y:909,t:1527189105716};\\\", \\\"{x:1404,y:917,t:1527189105733};\\\", \\\"{x:1404,y:920,t:1527189105749};\\\", \\\"{x:1405,y:925,t:1527189105766};\\\", \\\"{x:1406,y:927,t:1527189105783};\\\", \\\"{x:1406,y:929,t:1527189105801};\\\", \\\"{x:1406,y:931,t:1527189105816};\\\", \\\"{x:1406,y:936,t:1527189105833};\\\", \\\"{x:1402,y:942,t:1527189105849};\\\", \\\"{x:1400,y:945,t:1527189105866};\\\", \\\"{x:1400,y:946,t:1527189105914};\\\", \\\"{x:1400,y:948,t:1527189105945};\\\", \\\"{x:1398,y:950,t:1527189105953};\\\", \\\"{x:1397,y:952,t:1527189105966};\\\", \\\"{x:1393,y:955,t:1527189105983};\\\", \\\"{x:1392,y:958,t:1527189106000};\\\", \\\"{x:1388,y:960,t:1527189106016};\\\", \\\"{x:1388,y:961,t:1527189106082};\\\", \\\"{x:1387,y:964,t:1527189106186};\\\", \\\"{x:1386,y:965,t:1527189106202};\\\", \\\"{x:1384,y:965,t:1527189106266};\\\", \\\"{x:1376,y:967,t:1527189106283};\\\", \\\"{x:1370,y:969,t:1527189106300};\\\", \\\"{x:1369,y:970,t:1527189106317};\\\", \\\"{x:1366,y:970,t:1527189106334};\\\", \\\"{x:1365,y:970,t:1527189106350};\\\", \\\"{x:1364,y:970,t:1527189106377};\\\", \\\"{x:1367,y:970,t:1527189106458};\\\", \\\"{x:1369,y:970,t:1527189106467};\\\", \\\"{x:1370,y:970,t:1527189106484};\\\", \\\"{x:1372,y:970,t:1527189106501};\\\", \\\"{x:1373,y:970,t:1527189106626};\\\", \\\"{x:1374,y:970,t:1527189106738};\\\", \\\"{x:1376,y:970,t:1527189106898};\\\", \\\"{x:1377,y:973,t:1527189106905};\\\", \\\"{x:1379,y:974,t:1527189106917};\\\", \\\"{x:1381,y:976,t:1527189106934};\\\", \\\"{x:1386,y:981,t:1527189106951};\\\", \\\"{x:1390,y:985,t:1527189106967};\\\", \\\"{x:1396,y:986,t:1527189106985};\\\", \\\"{x:1399,y:987,t:1527189107001};\\\", \\\"{x:1405,y:989,t:1527189107017};\\\", \\\"{x:1406,y:990,t:1527189107034};\\\", \\\"{x:1408,y:990,t:1527189107051};\\\", \\\"{x:1413,y:990,t:1527189107068};\\\", \\\"{x:1418,y:990,t:1527189107084};\\\", \\\"{x:1426,y:986,t:1527189107101};\\\", \\\"{x:1429,y:985,t:1527189107118};\\\", \\\"{x:1431,y:985,t:1527189107170};\\\", \\\"{x:1433,y:984,t:1527189107186};\\\", \\\"{x:1435,y:983,t:1527189107210};\\\", \\\"{x:1435,y:982,t:1527189107290};\\\", \\\"{x:1436,y:981,t:1527189107302};\\\", \\\"{x:1439,y:979,t:1527189107318};\\\", \\\"{x:1442,y:979,t:1527189107334};\\\", \\\"{x:1444,y:979,t:1527189107351};\\\", \\\"{x:1444,y:978,t:1527189107434};\\\", \\\"{x:1447,y:978,t:1527189107452};\\\", \\\"{x:1448,y:977,t:1527189107474};\\\", \\\"{x:1448,y:976,t:1527189107865};\\\", \\\"{x:1449,y:975,t:1527189108234};\\\", \\\"{x:1449,y:974,t:1527189108954};\\\", \\\"{x:1449,y:973,t:1527189108971};\\\", \\\"{x:1450,y:970,t:1527189108986};\\\", \\\"{x:1451,y:969,t:1527189109003};\\\", \\\"{x:1452,y:967,t:1527189109042};\\\", \\\"{x:1453,y:966,t:1527189109426};\\\", \\\"{x:1456,y:966,t:1527189109481};\\\", \\\"{x:1458,y:967,t:1527189109490};\\\", \\\"{x:1464,y:971,t:1527189109504};\\\", \\\"{x:1470,y:973,t:1527189109520};\\\", \\\"{x:1474,y:975,t:1527189109537};\\\", \\\"{x:1475,y:975,t:1527189109553};\\\", \\\"{x:1475,y:976,t:1527189109618};\\\", \\\"{x:1476,y:976,t:1527189109658};\\\", \\\"{x:1477,y:977,t:1527189109682};\\\", \\\"{x:1478,y:978,t:1527189109689};\\\", \\\"{x:1479,y:978,t:1527189109818};\\\", \\\"{x:1481,y:979,t:1527189109826};\\\", \\\"{x:1485,y:979,t:1527189109837};\\\", \\\"{x:1492,y:979,t:1527189109854};\\\", \\\"{x:1495,y:979,t:1527189109871};\\\", \\\"{x:1496,y:979,t:1527189109887};\\\", \\\"{x:1498,y:979,t:1527189109970};\\\", \\\"{x:1501,y:979,t:1527189109987};\\\", \\\"{x:1504,y:978,t:1527189110005};\\\", \\\"{x:1506,y:977,t:1527189110022};\\\", \\\"{x:1506,y:976,t:1527189110041};\\\", \\\"{x:1506,y:975,t:1527189110090};\\\", \\\"{x:1507,y:974,t:1527189110104};\\\", \\\"{x:1509,y:972,t:1527189110121};\\\", \\\"{x:1512,y:969,t:1527189110137};\\\", \\\"{x:1513,y:968,t:1527189110170};\\\", \\\"{x:1514,y:970,t:1527189110562};\\\", \\\"{x:1515,y:971,t:1527189110571};\\\", \\\"{x:1519,y:976,t:1527189110588};\\\", \\\"{x:1524,y:980,t:1527189110605};\\\", \\\"{x:1526,y:982,t:1527189110622};\\\", \\\"{x:1527,y:982,t:1527189110638};\\\", \\\"{x:1528,y:983,t:1527189110655};\\\", \\\"{x:1531,y:986,t:1527189110674};\\\", \\\"{x:1533,y:986,t:1527189110689};\\\", \\\"{x:1536,y:987,t:1527189110705};\\\", \\\"{x:1542,y:989,t:1527189110721};\\\", \\\"{x:1546,y:989,t:1527189110739};\\\", \\\"{x:1553,y:990,t:1527189110755};\\\", \\\"{x:1556,y:991,t:1527189110771};\\\", \\\"{x:1557,y:991,t:1527189110788};\\\", \\\"{x:1562,y:992,t:1527189110806};\\\", \\\"{x:1564,y:992,t:1527189110822};\\\", \\\"{x:1567,y:992,t:1527189110838};\\\", \\\"{x:1571,y:992,t:1527189110856};\\\", \\\"{x:1574,y:991,t:1527189110872};\\\", \\\"{x:1578,y:991,t:1527189110888};\\\", \\\"{x:1586,y:988,t:1527189110905};\\\", \\\"{x:1587,y:988,t:1527189110978};\\\", \\\"{x:1588,y:987,t:1527189110988};\\\", \\\"{x:1590,y:985,t:1527189111005};\\\", \\\"{x:1594,y:983,t:1527189111023};\\\", \\\"{x:1596,y:981,t:1527189111039};\\\", \\\"{x:1596,y:980,t:1527189111055};\\\", \\\"{x:1596,y:979,t:1527189111072};\\\", \\\"{x:1596,y:976,t:1527189111089};\\\", \\\"{x:1596,y:975,t:1527189111105};\\\", \\\"{x:1596,y:972,t:1527189111122};\\\", \\\"{x:1596,y:970,t:1527189111140};\\\", \\\"{x:1595,y:967,t:1527189111156};\\\", \\\"{x:1595,y:965,t:1527189111172};\\\", \\\"{x:1593,y:962,t:1527189111189};\\\", \\\"{x:1593,y:960,t:1527189111206};\\\", \\\"{x:1592,y:959,t:1527189111222};\\\", \\\"{x:1591,y:959,t:1527189111282};\\\", \\\"{x:1590,y:959,t:1527189111410};\\\", \\\"{x:1589,y:959,t:1527189111433};\\\", \\\"{x:1587,y:959,t:1527189111562};\\\", \\\"{x:1586,y:960,t:1527189111573};\\\", \\\"{x:1585,y:961,t:1527189111589};\\\", \\\"{x:1585,y:962,t:1527189111609};\\\", \\\"{x:1581,y:959,t:1527189114938};\\\", \\\"{x:1576,y:953,t:1527189114945};\\\", \\\"{x:1569,y:945,t:1527189114960};\\\", \\\"{x:1551,y:928,t:1527189114977};\\\", \\\"{x:1530,y:916,t:1527189114994};\\\", \\\"{x:1526,y:914,t:1527189115010};\\\", \\\"{x:1524,y:911,t:1527189115049};\\\", \\\"{x:1523,y:911,t:1527189115059};\\\", \\\"{x:1515,y:904,t:1527189115076};\\\", \\\"{x:1507,y:897,t:1527189115094};\\\", \\\"{x:1498,y:890,t:1527189115110};\\\", \\\"{x:1495,y:888,t:1527189115127};\\\", \\\"{x:1493,y:886,t:1527189115144};\\\", \\\"{x:1493,y:884,t:1527189115160};\\\", \\\"{x:1491,y:877,t:1527189115177};\\\", \\\"{x:1487,y:864,t:1527189115193};\\\", \\\"{x:1482,y:857,t:1527189115209};\\\", \\\"{x:1481,y:851,t:1527189115226};\\\", \\\"{x:1480,y:848,t:1527189115243};\\\", \\\"{x:1479,y:847,t:1527189115260};\\\", \\\"{x:1478,y:843,t:1527189115281};\\\", \\\"{x:1478,y:841,t:1527189115306};\\\", \\\"{x:1477,y:840,t:1527189115313};\\\", \\\"{x:1476,y:839,t:1527189115327};\\\", \\\"{x:1476,y:838,t:1527189115344};\\\", \\\"{x:1476,y:837,t:1527189115360};\\\", \\\"{x:1475,y:835,t:1527189115376};\\\", \\\"{x:1475,y:834,t:1527189115394};\\\", \\\"{x:1475,y:833,t:1527189115410};\\\", \\\"{x:1475,y:832,t:1527189115426};\\\", \\\"{x:1475,y:831,t:1527189115570};\\\", \\\"{x:1476,y:829,t:1527189115578};\\\", \\\"{x:1476,y:828,t:1527189116122};\\\", \\\"{x:1477,y:829,t:1527189116465};\\\", \\\"{x:1477,y:833,t:1527189116477};\\\", \\\"{x:1477,y:844,t:1527189116496};\\\", \\\"{x:1477,y:855,t:1527189116512};\\\", \\\"{x:1477,y:868,t:1527189116529};\\\", \\\"{x:1477,y:874,t:1527189116544};\\\", \\\"{x:1476,y:878,t:1527189116561};\\\", \\\"{x:1475,y:884,t:1527189116577};\\\", \\\"{x:1475,y:890,t:1527189116595};\\\", \\\"{x:1475,y:893,t:1527189116611};\\\", \\\"{x:1475,y:900,t:1527189116629};\\\", \\\"{x:1476,y:908,t:1527189116645};\\\", \\\"{x:1477,y:917,t:1527189116662};\\\", \\\"{x:1478,y:923,t:1527189116679};\\\", \\\"{x:1478,y:926,t:1527189116694};\\\", \\\"{x:1478,y:929,t:1527189116712};\\\", \\\"{x:1478,y:931,t:1527189116729};\\\", \\\"{x:1478,y:936,t:1527189116745};\\\", \\\"{x:1478,y:944,t:1527189116762};\\\", \\\"{x:1481,y:948,t:1527189116778};\\\", \\\"{x:1481,y:949,t:1527189116794};\\\", \\\"{x:1482,y:954,t:1527189116811};\\\", \\\"{x:1482,y:956,t:1527189116829};\\\", \\\"{x:1482,y:958,t:1527189116845};\\\", \\\"{x:1482,y:959,t:1527189116938};\\\", \\\"{x:1482,y:962,t:1527189116946};\\\", \\\"{x:1482,y:966,t:1527189117154};\\\", \\\"{x:1484,y:967,t:1527189117162};\\\", \\\"{x:1490,y:973,t:1527189117178};\\\", \\\"{x:1497,y:978,t:1527189117195};\\\", \\\"{x:1500,y:979,t:1527189117212};\\\", \\\"{x:1503,y:979,t:1527189117229};\\\", \\\"{x:1503,y:980,t:1527189117245};\\\", \\\"{x:1506,y:980,t:1527189117305};\\\", \\\"{x:1508,y:980,t:1527189117314};\\\", \\\"{x:1511,y:980,t:1527189117329};\\\", \\\"{x:1524,y:983,t:1527189117345};\\\", \\\"{x:1531,y:984,t:1527189117363};\\\", \\\"{x:1536,y:986,t:1527189117379};\\\", \\\"{x:1540,y:987,t:1527189117395};\\\", \\\"{x:1542,y:987,t:1527189117482};\\\", \\\"{x:1543,y:987,t:1527189117495};\\\", \\\"{x:1547,y:987,t:1527189117513};\\\", \\\"{x:1548,y:987,t:1527189117529};\\\", \\\"{x:1549,y:987,t:1527189117546};\\\", \\\"{x:1550,y:987,t:1527189117706};\\\", \\\"{x:1552,y:986,t:1527189117713};\\\", \\\"{x:1555,y:983,t:1527189117729};\\\", \\\"{x:1558,y:982,t:1527189117746};\\\", \\\"{x:1559,y:981,t:1527189117763};\\\", \\\"{x:1560,y:981,t:1527189117780};\\\", \\\"{x:1561,y:980,t:1527189117796};\\\", \\\"{x:1562,y:980,t:1527189117905};\\\", \\\"{x:1562,y:979,t:1527189117945};\\\", \\\"{x:1563,y:978,t:1527189118017};\\\", \\\"{x:1563,y:977,t:1527189118030};\\\", \\\"{x:1563,y:976,t:1527189118047};\\\", \\\"{x:1566,y:974,t:1527189118062};\\\", \\\"{x:1567,y:973,t:1527189118079};\\\", \\\"{x:1568,y:972,t:1527189118097};\\\", \\\"{x:1570,y:972,t:1527189118146};\\\", \\\"{x:1571,y:971,t:1527189118164};\\\", \\\"{x:1573,y:970,t:1527189118179};\\\", \\\"{x:1573,y:969,t:1527189118218};\\\", \\\"{x:1575,y:967,t:1527189118281};\\\", \\\"{x:1577,y:967,t:1527189118369};\\\", \\\"{x:1577,y:966,t:1527189118402};\\\", \\\"{x:1578,y:966,t:1527189118414};\\\", \\\"{x:1578,y:965,t:1527189118430};\\\", \\\"{x:1579,y:965,t:1527189118449};\\\", \\\"{x:1580,y:965,t:1527189118463};\\\", \\\"{x:1581,y:965,t:1527189118481};\\\", \\\"{x:1582,y:965,t:1527189118496};\\\", \\\"{x:1585,y:965,t:1527189118514};\\\", \\\"{x:1587,y:968,t:1527189118531};\\\", \\\"{x:1590,y:972,t:1527189118547};\\\", \\\"{x:1593,y:976,t:1527189118564};\\\", \\\"{x:1593,y:978,t:1527189118581};\\\", \\\"{x:1594,y:979,t:1527189118597};\\\", \\\"{x:1595,y:980,t:1527189118614};\\\", \\\"{x:1596,y:981,t:1527189118641};\\\", \\\"{x:1597,y:982,t:1527189118706};\\\", \\\"{x:1598,y:983,t:1527189118713};\\\", \\\"{x:1600,y:985,t:1527189118731};\\\", \\\"{x:1605,y:986,t:1527189118748};\\\", \\\"{x:1607,y:987,t:1527189118763};\\\", \\\"{x:1608,y:987,t:1527189118780};\\\", \\\"{x:1609,y:987,t:1527189118841};\\\", \\\"{x:1612,y:988,t:1527189118849};\\\", \\\"{x:1613,y:988,t:1527189118873};\\\", \\\"{x:1614,y:988,t:1527189118890};\\\", \\\"{x:1616,y:988,t:1527189118898};\\\", \\\"{x:1618,y:988,t:1527189118913};\\\", \\\"{x:1619,y:988,t:1527189118938};\\\", \\\"{x:1622,y:988,t:1527189118961};\\\", \\\"{x:1623,y:988,t:1527189118978};\\\", \\\"{x:1624,y:988,t:1527189118986};\\\", \\\"{x:1626,y:987,t:1527189118997};\\\", \\\"{x:1628,y:986,t:1527189119014};\\\", \\\"{x:1630,y:982,t:1527189119030};\\\", \\\"{x:1634,y:979,t:1527189119048};\\\", \\\"{x:1636,y:977,t:1527189119065};\\\", \\\"{x:1637,y:974,t:1527189119080};\\\", \\\"{x:1639,y:973,t:1527189119098};\\\", \\\"{x:1639,y:972,t:1527189119114};\\\", \\\"{x:1627,y:970,t:1527189120762};\\\", \\\"{x:1584,y:964,t:1527189120770};\\\", \\\"{x:1520,y:964,t:1527189120783};\\\", \\\"{x:1406,y:948,t:1527189120800};\\\", \\\"{x:1276,y:929,t:1527189120815};\\\", \\\"{x:1192,y:918,t:1527189120833};\\\", \\\"{x:1147,y:911,t:1527189120850};\\\", \\\"{x:1139,y:908,t:1527189120866};\\\", \\\"{x:1130,y:907,t:1527189120883};\\\", \\\"{x:1116,y:902,t:1527189120900};\\\", \\\"{x:1080,y:899,t:1527189120916};\\\", \\\"{x:1013,y:887,t:1527189120933};\\\", \\\"{x:945,y:884,t:1527189120949};\\\", \\\"{x:913,y:882,t:1527189120966};\\\", \\\"{x:894,y:882,t:1527189120982};\\\", \\\"{x:881,y:882,t:1527189121000};\\\", \\\"{x:852,y:880,t:1527189121016};\\\", \\\"{x:803,y:877,t:1527189121033};\\\", \\\"{x:728,y:856,t:1527189121049};\\\", \\\"{x:706,y:849,t:1527189121067};\\\", \\\"{x:684,y:846,t:1527189121083};\\\", \\\"{x:674,y:845,t:1527189121099};\\\", \\\"{x:670,y:843,t:1527189121117};\\\", \\\"{x:666,y:841,t:1527189121133};\\\", \\\"{x:664,y:840,t:1527189121149};\\\", \\\"{x:662,y:834,t:1527189121167};\\\", \\\"{x:660,y:827,t:1527189121183};\\\", \\\"{x:658,y:810,t:1527189121199};\\\", \\\"{x:653,y:798,t:1527189121217};\\\", \\\"{x:650,y:786,t:1527189121232};\\\", \\\"{x:646,y:775,t:1527189121249};\\\", \\\"{x:645,y:769,t:1527189121266};\\\", \\\"{x:645,y:763,t:1527189121284};\\\", \\\"{x:642,y:750,t:1527189121300};\\\", \\\"{x:642,y:738,t:1527189121317};\\\", \\\"{x:642,y:729,t:1527189121333};\\\", \\\"{x:642,y:721,t:1527189121349};\\\", \\\"{x:642,y:717,t:1527189121366};\\\", \\\"{x:642,y:714,t:1527189121384};\\\", \\\"{x:641,y:712,t:1527189121399};\\\", \\\"{x:640,y:706,t:1527189121416};\\\", \\\"{x:637,y:693,t:1527189121434};\\\", \\\"{x:637,y:682,t:1527189121450};\\\", \\\"{x:637,y:675,t:1527189121467};\\\", \\\"{x:637,y:670,t:1527189121483};\\\", \\\"{x:637,y:668,t:1527189121500};\\\", \\\"{x:635,y:664,t:1527189121518};\\\", \\\"{x:629,y:657,t:1527189121535};\\\", \\\"{x:621,y:648,t:1527189121550};\\\", \\\"{x:614,y:638,t:1527189121567};\\\", \\\"{x:610,y:633,t:1527189121585};\\\", \\\"{x:607,y:628,t:1527189121600};\\\", \\\"{x:607,y:624,t:1527189121618};\\\", \\\"{x:605,y:621,t:1527189121634};\\\", \\\"{x:604,y:620,t:1527189121657};\\\", \\\"{x:603,y:619,t:1527189121667};\\\", \\\"{x:602,y:617,t:1527189121684};\\\", \\\"{x:600,y:616,t:1527189121701};\\\", \\\"{x:599,y:615,t:1527189121717};\\\", \\\"{x:599,y:614,t:1527189121896};\\\", \\\"{x:599,y:615,t:1527189121961};\\\", \\\"{x:596,y:620,t:1527189121969};\\\", \\\"{x:591,y:625,t:1527189121984};\\\", \\\"{x:576,y:637,t:1527189122001};\\\", \\\"{x:575,y:638,t:1527189122017};\\\", \\\"{x:573,y:639,t:1527189122034};\\\", \\\"{x:572,y:640,t:1527189122064};\\\", \\\"{x:570,y:642,t:1527189122089};\\\", \\\"{x:569,y:643,t:1527189122102};\\\", \\\"{x:564,y:646,t:1527189122117};\\\", \\\"{x:558,y:651,t:1527189122135};\\\", \\\"{x:554,y:655,t:1527189122152};\\\", \\\"{x:548,y:660,t:1527189122167};\\\", \\\"{x:538,y:669,t:1527189122186};\\\", \\\"{x:522,y:687,t:1527189122201};\\\", \\\"{x:513,y:700,t:1527189122218};\\\", \\\"{x:506,y:716,t:1527189122235};\\\", \\\"{x:502,y:722,t:1527189122251};\\\", \\\"{x:500,y:724,t:1527189122268};\\\", \\\"{x:500,y:726,t:1527189122283};\\\", \\\"{x:500,y:729,t:1527189122301};\\\", \\\"{x:500,y:733,t:1527189122318};\\\", \\\"{x:500,y:737,t:1527189122334};\\\", \\\"{x:500,y:738,t:1527189122351};\\\", \\\"{x:500,y:739,t:1527189122377};\\\", \\\"{x:500,y:741,t:1527189122385};\\\", \\\"{x:500,y:743,t:1527189122417};\\\" ] }, { \\\"rt\\\": 15589, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 665837, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:748,t:1527189124808};\\\", \\\"{x:510,y:760,t:1527189124821};\\\", \\\"{x:512,y:769,t:1527189124836};\\\", \\\"{x:515,y:780,t:1527189124853};\\\", \\\"{x:520,y:788,t:1527189124869};\\\", \\\"{x:522,y:796,t:1527189124886};\\\", \\\"{x:525,y:799,t:1527189124903};\\\", \\\"{x:527,y:803,t:1527189124920};\\\", \\\"{x:528,y:804,t:1527189124936};\\\", \\\"{x:532,y:811,t:1527189124952};\\\", \\\"{x:537,y:821,t:1527189124971};\\\", \\\"{x:544,y:830,t:1527189124987};\\\", \\\"{x:558,y:838,t:1527189125003};\\\", \\\"{x:568,y:850,t:1527189125020};\\\", \\\"{x:576,y:856,t:1527189125036};\\\", \\\"{x:580,y:860,t:1527189125053};\\\", \\\"{x:590,y:864,t:1527189125071};\\\", \\\"{x:597,y:867,t:1527189125087};\\\", \\\"{x:607,y:873,t:1527189125103};\\\", \\\"{x:625,y:880,t:1527189125121};\\\", \\\"{x:631,y:880,t:1527189125137};\\\", \\\"{x:639,y:884,t:1527189125154};\\\", \\\"{x:644,y:885,t:1527189125171};\\\", \\\"{x:646,y:885,t:1527189125187};\\\", \\\"{x:647,y:886,t:1527189125203};\\\", \\\"{x:647,y:887,t:1527189125392};\\\", \\\"{x:646,y:883,t:1527189132410};\\\", \\\"{x:640,y:873,t:1527189132425};\\\", \\\"{x:636,y:862,t:1527189132442};\\\", \\\"{x:630,y:837,t:1527189132458};\\\", \\\"{x:627,y:801,t:1527189132475};\\\", \\\"{x:609,y:760,t:1527189132492};\\\", \\\"{x:589,y:729,t:1527189132508};\\\", \\\"{x:576,y:707,t:1527189132525};\\\", \\\"{x:569,y:690,t:1527189132542};\\\", \\\"{x:566,y:682,t:1527189132558};\\\", \\\"{x:566,y:679,t:1527189132575};\\\", \\\"{x:566,y:675,t:1527189132592};\\\", \\\"{x:567,y:670,t:1527189132608};\\\", \\\"{x:568,y:659,t:1527189132625};\\\", \\\"{x:571,y:652,t:1527189132642};\\\", \\\"{x:571,y:643,t:1527189132658};\\\", \\\"{x:573,y:630,t:1527189132677};\\\", \\\"{x:578,y:617,t:1527189132692};\\\", \\\"{x:586,y:606,t:1527189132708};\\\", \\\"{x:595,y:596,t:1527189132727};\\\", \\\"{x:603,y:586,t:1527189132744};\\\", \\\"{x:609,y:578,t:1527189132759};\\\", \\\"{x:619,y:567,t:1527189132776};\\\", \\\"{x:625,y:565,t:1527189132793};\\\", \\\"{x:635,y:558,t:1527189132810};\\\", \\\"{x:662,y:543,t:1527189132844};\\\", \\\"{x:681,y:538,t:1527189132859};\\\", \\\"{x:697,y:536,t:1527189132876};\\\", \\\"{x:713,y:533,t:1527189132893};\\\", \\\"{x:720,y:531,t:1527189132910};\\\", \\\"{x:733,y:528,t:1527189132927};\\\", \\\"{x:745,y:526,t:1527189132943};\\\", \\\"{x:753,y:524,t:1527189132960};\\\", \\\"{x:761,y:523,t:1527189132976};\\\", \\\"{x:762,y:523,t:1527189132993};\\\", \\\"{x:763,y:523,t:1527189133009};\\\", \\\"{x:764,y:524,t:1527189133027};\\\", \\\"{x:766,y:527,t:1527189133044};\\\", \\\"{x:767,y:528,t:1527189133060};\\\", \\\"{x:776,y:533,t:1527189133077};\\\", \\\"{x:784,y:536,t:1527189133094};\\\", \\\"{x:793,y:541,t:1527189133110};\\\", \\\"{x:811,y:545,t:1527189133126};\\\", \\\"{x:829,y:551,t:1527189133144};\\\", \\\"{x:852,y:560,t:1527189133160};\\\", \\\"{x:868,y:567,t:1527189133178};\\\", \\\"{x:868,y:565,t:1527189133290};\\\", \\\"{x:869,y:563,t:1527189133311};\\\", \\\"{x:870,y:561,t:1527189133327};\\\", \\\"{x:870,y:560,t:1527189133343};\\\", \\\"{x:869,y:558,t:1527189133361};\\\", \\\"{x:867,y:557,t:1527189133376};\\\", \\\"{x:866,y:553,t:1527189133394};\\\", \\\"{x:863,y:552,t:1527189133410};\\\", \\\"{x:861,y:550,t:1527189133427};\\\", \\\"{x:856,y:549,t:1527189133445};\\\", \\\"{x:850,y:545,t:1527189133462};\\\", \\\"{x:847,y:545,t:1527189133477};\\\", \\\"{x:847,y:544,t:1527189133552};\\\", \\\"{x:846,y:544,t:1527189133576};\\\", \\\"{x:842,y:544,t:1527189133813};\\\", \\\"{x:811,y:544,t:1527189133821};\\\", \\\"{x:750,y:544,t:1527189133831};\\\", \\\"{x:611,y:545,t:1527189133848};\\\", \\\"{x:486,y:541,t:1527189133865};\\\", \\\"{x:375,y:541,t:1527189133883};\\\", \\\"{x:297,y:540,t:1527189133899};\\\", \\\"{x:275,y:542,t:1527189133915};\\\", \\\"{x:246,y:548,t:1527189133932};\\\", \\\"{x:207,y:553,t:1527189133948};\\\", \\\"{x:183,y:553,t:1527189133965};\\\", \\\"{x:168,y:553,t:1527189133982};\\\", \\\"{x:166,y:553,t:1527189133999};\\\", \\\"{x:166,y:554,t:1527189134125};\\\", \\\"{x:166,y:558,t:1527189134134};\\\", \\\"{x:167,y:577,t:1527189134148};\\\", \\\"{x:168,y:594,t:1527189134165};\\\", \\\"{x:170,y:597,t:1527189134182};\\\", \\\"{x:171,y:600,t:1527189134199};\\\", \\\"{x:172,y:602,t:1527189134215};\\\", \\\"{x:173,y:606,t:1527189134277};\\\", \\\"{x:174,y:610,t:1527189134284};\\\", \\\"{x:174,y:615,t:1527189134298};\\\", \\\"{x:174,y:621,t:1527189134315};\\\", \\\"{x:173,y:625,t:1527189134332};\\\", \\\"{x:172,y:629,t:1527189134348};\\\", \\\"{x:172,y:632,t:1527189134367};\\\", \\\"{x:172,y:636,t:1527189134382};\\\", \\\"{x:175,y:644,t:1527189134399};\\\", \\\"{x:179,y:652,t:1527189134416};\\\", \\\"{x:183,y:657,t:1527189134431};\\\", \\\"{x:185,y:658,t:1527189134449};\\\", \\\"{x:186,y:658,t:1527189134466};\\\", \\\"{x:188,y:660,t:1527189134493};\\\", \\\"{x:191,y:660,t:1527189134501};\\\", \\\"{x:193,y:660,t:1527189134518};\\\", \\\"{x:200,y:661,t:1527189134531};\\\", \\\"{x:237,y:665,t:1527189134548};\\\", \\\"{x:261,y:666,t:1527189134565};\\\", \\\"{x:278,y:666,t:1527189134582};\\\", \\\"{x:295,y:665,t:1527189134598};\\\", \\\"{x:296,y:664,t:1527189134615};\\\", \\\"{x:298,y:664,t:1527189134660};\\\", \\\"{x:299,y:664,t:1527189134668};\\\", \\\"{x:303,y:661,t:1527189134682};\\\", \\\"{x:314,y:658,t:1527189134699};\\\", \\\"{x:324,y:657,t:1527189134715};\\\", \\\"{x:339,y:655,t:1527189134732};\\\", \\\"{x:349,y:655,t:1527189134749};\\\", \\\"{x:358,y:655,t:1527189134766};\\\", \\\"{x:368,y:655,t:1527189134782};\\\", \\\"{x:384,y:655,t:1527189134800};\\\", \\\"{x:397,y:650,t:1527189134816};\\\", \\\"{x:406,y:649,t:1527189134832};\\\", \\\"{x:416,y:647,t:1527189134848};\\\", \\\"{x:430,y:647,t:1527189134866};\\\", \\\"{x:440,y:647,t:1527189134882};\\\", \\\"{x:459,y:644,t:1527189134898};\\\", \\\"{x:464,y:644,t:1527189134916};\\\", \\\"{x:478,y:640,t:1527189134932};\\\", \\\"{x:479,y:640,t:1527189135013};\\\", \\\"{x:482,y:637,t:1527189135022};\\\", \\\"{x:485,y:636,t:1527189135033};\\\", \\\"{x:501,y:630,t:1527189135049};\\\", \\\"{x:512,y:626,t:1527189135066};\\\", \\\"{x:523,y:621,t:1527189135083};\\\", \\\"{x:528,y:618,t:1527189135099};\\\", \\\"{x:531,y:616,t:1527189135115};\\\", \\\"{x:533,y:614,t:1527189135133};\\\", \\\"{x:539,y:610,t:1527189135148};\\\", \\\"{x:546,y:607,t:1527189135166};\\\", \\\"{x:567,y:598,t:1527189135184};\\\", \\\"{x:587,y:588,t:1527189135200};\\\", \\\"{x:594,y:583,t:1527189135216};\\\", \\\"{x:599,y:580,t:1527189135233};\\\", \\\"{x:600,y:580,t:1527189135250};\\\", \\\"{x:604,y:577,t:1527189135266};\\\", \\\"{x:606,y:574,t:1527189135283};\\\", \\\"{x:613,y:569,t:1527189135300};\\\", \\\"{x:639,y:563,t:1527189135316};\\\", \\\"{x:671,y:558,t:1527189135333};\\\", \\\"{x:687,y:556,t:1527189135350};\\\", \\\"{x:696,y:554,t:1527189135367};\\\", \\\"{x:700,y:554,t:1527189135383};\\\", \\\"{x:701,y:553,t:1527189135400};\\\", \\\"{x:702,y:553,t:1527189135437};\\\", \\\"{x:704,y:552,t:1527189135453};\\\", \\\"{x:704,y:551,t:1527189135466};\\\", \\\"{x:705,y:550,t:1527189135483};\\\", \\\"{x:698,y:550,t:1527189135798};\\\", \\\"{x:692,y:550,t:1527189135805};\\\", \\\"{x:688,y:550,t:1527189135815};\\\", \\\"{x:666,y:550,t:1527189135833};\\\", \\\"{x:648,y:549,t:1527189135850};\\\", \\\"{x:636,y:548,t:1527189135867};\\\", \\\"{x:624,y:544,t:1527189135883};\\\", \\\"{x:612,y:540,t:1527189135900};\\\", \\\"{x:606,y:538,t:1527189135916};\\\", \\\"{x:587,y:530,t:1527189135934};\\\", \\\"{x:577,y:528,t:1527189135950};\\\", \\\"{x:575,y:526,t:1527189135966};\\\", \\\"{x:574,y:524,t:1527189136024};\\\", \\\"{x:575,y:520,t:1527189136032};\\\", \\\"{x:577,y:514,t:1527189136051};\\\", \\\"{x:579,y:511,t:1527189136066};\\\", \\\"{x:584,y:506,t:1527189136083};\\\", \\\"{x:588,y:502,t:1527189136100};\\\", \\\"{x:590,y:500,t:1527189136116};\\\", \\\"{x:592,y:499,t:1527189136197};\\\", \\\"{x:592,y:498,t:1527189136229};\\\", \\\"{x:593,y:497,t:1527189136245};\\\", \\\"{x:596,y:496,t:1527189136261};\\\", \\\"{x:596,y:495,t:1527189136269};\\\", \\\"{x:597,y:495,t:1527189136284};\\\", \\\"{x:599,y:495,t:1527189136300};\\\", \\\"{x:606,y:495,t:1527189136317};\\\", \\\"{x:610,y:498,t:1527189136334};\\\", \\\"{x:612,y:500,t:1527189136350};\\\", \\\"{x:612,y:502,t:1527189136525};\\\", \\\"{x:611,y:506,t:1527189136534};\\\", \\\"{x:603,y:526,t:1527189136550};\\\", \\\"{x:595,y:550,t:1527189136567};\\\", \\\"{x:586,y:568,t:1527189136585};\\\", \\\"{x:575,y:590,t:1527189136601};\\\", \\\"{x:567,y:606,t:1527189136618};\\\", \\\"{x:565,y:615,t:1527189136633};\\\", \\\"{x:559,y:637,t:1527189136652};\\\", \\\"{x:553,y:656,t:1527189136667};\\\", \\\"{x:544,y:672,t:1527189136684};\\\", \\\"{x:533,y:694,t:1527189136700};\\\", \\\"{x:527,y:703,t:1527189136717};\\\", \\\"{x:523,y:711,t:1527189136734};\\\", \\\"{x:521,y:712,t:1527189136750};\\\", \\\"{x:520,y:714,t:1527189136767};\\\", \\\"{x:519,y:714,t:1527189136894};\\\", \\\"{x:519,y:718,t:1527189136981};\\\", \\\"{x:519,y:719,t:1527189136990};\\\", \\\"{x:519,y:723,t:1527189137002};\\\", \\\"{x:521,y:730,t:1527189137017};\\\", \\\"{x:521,y:732,t:1527189137034};\\\", \\\"{x:521,y:733,t:1527189137053};\\\", \\\"{x:521,y:734,t:1527189137150};\\\", \\\"{x:521,y:735,t:1527189137157};\\\", \\\"{x:521,y:736,t:1527189137181};\\\" ] }, { \\\"rt\\\": 48449, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 715543, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:737,t:1527189141782};\\\", \\\"{x:538,y:757,t:1527189141808};\\\", \\\"{x:557,y:775,t:1527189141821};\\\", \\\"{x:571,y:784,t:1527189141838};\\\", \\\"{x:575,y:791,t:1527189141855};\\\", \\\"{x:583,y:795,t:1527189141871};\\\", \\\"{x:585,y:798,t:1527189141888};\\\", \\\"{x:587,y:799,t:1527189141905};\\\", \\\"{x:593,y:801,t:1527189141921};\\\", \\\"{x:600,y:806,t:1527189141938};\\\", \\\"{x:606,y:808,t:1527189141955};\\\", \\\"{x:614,y:810,t:1527189141971};\\\", \\\"{x:626,y:814,t:1527189141988};\\\", \\\"{x:637,y:818,t:1527189142005};\\\", \\\"{x:653,y:826,t:1527189142021};\\\", \\\"{x:665,y:828,t:1527189142038};\\\", \\\"{x:673,y:832,t:1527189142055};\\\", \\\"{x:678,y:833,t:1527189142072};\\\", \\\"{x:678,y:834,t:1527189142088};\\\", \\\"{x:676,y:834,t:1527189142277};\\\", \\\"{x:673,y:836,t:1527189148804};\\\", \\\"{x:672,y:836,t:1527189148812};\\\", \\\"{x:670,y:837,t:1527189148826};\\\", \\\"{x:670,y:836,t:1527189148988};\\\", \\\"{x:670,y:835,t:1527189149012};\\\", \\\"{x:666,y:835,t:1527189153582};\\\", \\\"{x:665,y:836,t:1527189153597};\\\", \\\"{x:663,y:836,t:1527189153614};\\\", \\\"{x:662,y:838,t:1527189153630};\\\", \\\"{x:662,y:839,t:1527189154589};\\\", \\\"{x:663,y:839,t:1527189155981};\\\", \\\"{x:667,y:839,t:1527189168493};\\\", \\\"{x:673,y:836,t:1527189168508};\\\", \\\"{x:790,y:813,t:1527189168525};\\\", \\\"{x:865,y:804,t:1527189168542};\\\", \\\"{x:919,y:801,t:1527189168559};\\\", \\\"{x:942,y:799,t:1527189168574};\\\", \\\"{x:958,y:799,t:1527189168591};\\\", \\\"{x:973,y:798,t:1527189168608};\\\", \\\"{x:999,y:798,t:1527189168625};\\\", \\\"{x:1047,y:805,t:1527189168641};\\\", \\\"{x:1101,y:808,t:1527189168659};\\\", \\\"{x:1152,y:818,t:1527189168675};\\\", \\\"{x:1185,y:818,t:1527189168692};\\\", \\\"{x:1228,y:820,t:1527189168709};\\\", \\\"{x:1240,y:821,t:1527189168725};\\\", \\\"{x:1246,y:823,t:1527189168742};\\\", \\\"{x:1252,y:824,t:1527189168759};\\\", \\\"{x:1259,y:824,t:1527189168775};\\\", \\\"{x:1270,y:826,t:1527189168792};\\\", \\\"{x:1284,y:827,t:1527189168809};\\\", \\\"{x:1305,y:827,t:1527189168825};\\\", \\\"{x:1328,y:831,t:1527189168842};\\\", \\\"{x:1349,y:835,t:1527189168859};\\\", \\\"{x:1369,y:835,t:1527189168875};\\\", \\\"{x:1376,y:836,t:1527189168892};\\\", \\\"{x:1379,y:836,t:1527189168909};\\\", \\\"{x:1382,y:841,t:1527189169278};\\\", \\\"{x:1383,y:849,t:1527189169293};\\\", \\\"{x:1387,y:867,t:1527189169309};\\\", \\\"{x:1387,y:877,t:1527189169326};\\\", \\\"{x:1387,y:887,t:1527189169342};\\\", \\\"{x:1387,y:894,t:1527189169359};\\\", \\\"{x:1386,y:898,t:1527189169379};\\\", \\\"{x:1384,y:906,t:1527189169392};\\\", \\\"{x:1381,y:913,t:1527189169408};\\\", \\\"{x:1378,y:920,t:1527189169426};\\\", \\\"{x:1377,y:927,t:1527189169442};\\\", \\\"{x:1375,y:933,t:1527189169458};\\\", \\\"{x:1371,y:940,t:1527189169475};\\\", \\\"{x:1371,y:941,t:1527189169492};\\\", \\\"{x:1369,y:947,t:1527189169508};\\\", \\\"{x:1368,y:950,t:1527189169525};\\\", \\\"{x:1367,y:953,t:1527189169542};\\\", \\\"{x:1366,y:954,t:1527189169558};\\\", \\\"{x:1366,y:956,t:1527189169575};\\\", \\\"{x:1366,y:957,t:1527189169596};\\\", \\\"{x:1366,y:958,t:1527189169629};\\\", \\\"{x:1366,y:960,t:1527189169644};\\\", \\\"{x:1367,y:962,t:1527189169685};\\\", \\\"{x:1367,y:963,t:1527189169709};\\\", \\\"{x:1367,y:964,t:1527189169726};\\\", \\\"{x:1368,y:965,t:1527189169743};\\\", \\\"{x:1368,y:967,t:1527189169759};\\\", \\\"{x:1369,y:968,t:1527189169776};\\\", \\\"{x:1370,y:969,t:1527189169797};\\\", \\\"{x:1370,y:958,t:1527189175517};\\\", \\\"{x:1370,y:951,t:1527189175530};\\\", \\\"{x:1370,y:937,t:1527189175547};\\\", \\\"{x:1370,y:922,t:1527189175564};\\\", \\\"{x:1369,y:916,t:1527189175580};\\\", \\\"{x:1368,y:908,t:1527189175597};\\\", \\\"{x:1366,y:903,t:1527189175613};\\\", \\\"{x:1366,y:899,t:1527189175631};\\\", \\\"{x:1366,y:893,t:1527189175647};\\\", \\\"{x:1366,y:881,t:1527189175664};\\\", \\\"{x:1366,y:869,t:1527189175681};\\\", \\\"{x:1365,y:855,t:1527189175697};\\\", \\\"{x:1362,y:847,t:1527189175713};\\\", \\\"{x:1361,y:842,t:1527189175730};\\\", \\\"{x:1360,y:838,t:1527189175747};\\\", \\\"{x:1357,y:835,t:1527189175764};\\\", \\\"{x:1356,y:828,t:1527189175780};\\\", \\\"{x:1353,y:810,t:1527189175797};\\\", \\\"{x:1352,y:799,t:1527189175815};\\\", \\\"{x:1348,y:785,t:1527189175830};\\\", \\\"{x:1347,y:769,t:1527189175848};\\\", \\\"{x:1347,y:752,t:1527189175865};\\\", \\\"{x:1346,y:742,t:1527189175881};\\\", \\\"{x:1346,y:735,t:1527189175897};\\\", \\\"{x:1349,y:726,t:1527189175915};\\\", \\\"{x:1350,y:720,t:1527189175930};\\\", \\\"{x:1353,y:715,t:1527189175947};\\\", \\\"{x:1356,y:709,t:1527189175964};\\\", \\\"{x:1358,y:708,t:1527189175981};\\\", \\\"{x:1358,y:707,t:1527189175998};\\\", \\\"{x:1358,y:706,t:1527189176053};\\\", \\\"{x:1358,y:705,t:1527189176064};\\\", \\\"{x:1357,y:705,t:1527189176141};\\\", \\\"{x:1355,y:714,t:1527189176149};\\\", \\\"{x:1348,y:727,t:1527189176165};\\\", \\\"{x:1335,y:752,t:1527189176181};\\\", \\\"{x:1326,y:769,t:1527189176197};\\\", \\\"{x:1323,y:779,t:1527189176215};\\\", \\\"{x:1319,y:783,t:1527189176231};\\\", \\\"{x:1318,y:783,t:1527189176261};\\\", \\\"{x:1316,y:783,t:1527189176269};\\\", \\\"{x:1312,y:783,t:1527189176282};\\\", \\\"{x:1279,y:774,t:1527189176297};\\\", \\\"{x:1195,y:748,t:1527189176314};\\\", \\\"{x:1056,y:704,t:1527189176331};\\\", \\\"{x:896,y:662,t:1527189176348};\\\", \\\"{x:724,y:633,t:1527189176364};\\\", \\\"{x:543,y:604,t:1527189176382};\\\", \\\"{x:469,y:599,t:1527189176397};\\\", \\\"{x:448,y:595,t:1527189176413};\\\", \\\"{x:427,y:592,t:1527189176434};\\\", \\\"{x:414,y:590,t:1527189176450};\\\", \\\"{x:401,y:587,t:1527189176467};\\\", \\\"{x:388,y:582,t:1527189176484};\\\", \\\"{x:359,y:576,t:1527189176500};\\\", \\\"{x:338,y:569,t:1527189176517};\\\", \\\"{x:302,y:564,t:1527189176534};\\\", \\\"{x:282,y:561,t:1527189176550};\\\", \\\"{x:270,y:558,t:1527189176566};\\\", \\\"{x:266,y:556,t:1527189176583};\\\", \\\"{x:263,y:555,t:1527189176601};\\\", \\\"{x:263,y:553,t:1527189176616};\\\", \\\"{x:257,y:550,t:1527189176634};\\\", \\\"{x:245,y:547,t:1527189176651};\\\", \\\"{x:230,y:547,t:1527189176666};\\\", \\\"{x:217,y:550,t:1527189176683};\\\", \\\"{x:211,y:554,t:1527189176700};\\\", \\\"{x:209,y:557,t:1527189176717};\\\", \\\"{x:204,y:560,t:1527189176734};\\\", \\\"{x:198,y:566,t:1527189176752};\\\", \\\"{x:187,y:577,t:1527189176767};\\\", \\\"{x:181,y:583,t:1527189176783};\\\", \\\"{x:172,y:591,t:1527189176801};\\\", \\\"{x:171,y:594,t:1527189176818};\\\", \\\"{x:170,y:597,t:1527189176900};\\\", \\\"{x:170,y:603,t:1527189176919};\\\", \\\"{x:169,y:607,t:1527189176935};\\\", \\\"{x:169,y:608,t:1527189176951};\\\", \\\"{x:169,y:609,t:1527189177157};\\\", \\\"{x:170,y:609,t:1527189177169};\\\", \\\"{x:181,y:609,t:1527189177184};\\\", \\\"{x:188,y:605,t:1527189177201};\\\", \\\"{x:193,y:603,t:1527189177219};\\\", \\\"{x:196,y:598,t:1527189177235};\\\", \\\"{x:201,y:597,t:1527189177251};\\\", \\\"{x:206,y:589,t:1527189177267};\\\", \\\"{x:218,y:579,t:1527189177284};\\\", \\\"{x:233,y:568,t:1527189177300};\\\", \\\"{x:244,y:561,t:1527189177318};\\\", \\\"{x:251,y:557,t:1527189177334};\\\", \\\"{x:257,y:552,t:1527189177352};\\\", \\\"{x:269,y:546,t:1527189177368};\\\", \\\"{x:280,y:539,t:1527189177387};\\\", \\\"{x:290,y:534,t:1527189177400};\\\", \\\"{x:298,y:528,t:1527189177417};\\\", \\\"{x:299,y:528,t:1527189177435};\\\", \\\"{x:300,y:527,t:1527189177450};\\\", \\\"{x:305,y:527,t:1527189177468};\\\", \\\"{x:316,y:525,t:1527189177484};\\\", \\\"{x:332,y:522,t:1527189177502};\\\", \\\"{x:346,y:518,t:1527189177518};\\\", \\\"{x:372,y:517,t:1527189177535};\\\", \\\"{x:404,y:517,t:1527189177551};\\\", \\\"{x:443,y:520,t:1527189177569};\\\", \\\"{x:471,y:521,t:1527189177585};\\\", \\\"{x:492,y:522,t:1527189177600};\\\", \\\"{x:514,y:525,t:1527189177619};\\\", \\\"{x:529,y:526,t:1527189177635};\\\", \\\"{x:547,y:528,t:1527189177651};\\\", \\\"{x:555,y:530,t:1527189177668};\\\", \\\"{x:556,y:530,t:1527189177685};\\\", \\\"{x:558,y:530,t:1527189177716};\\\", \\\"{x:564,y:530,t:1527189177724};\\\", \\\"{x:572,y:530,t:1527189177735};\\\", \\\"{x:580,y:529,t:1527189177752};\\\", \\\"{x:586,y:529,t:1527189177768};\\\", \\\"{x:589,y:529,t:1527189177785};\\\", \\\"{x:591,y:529,t:1527189177829};\\\", \\\"{x:592,y:529,t:1527189177837};\\\", \\\"{x:604,y:529,t:1527189177853};\\\", \\\"{x:609,y:529,t:1527189177868};\\\", \\\"{x:624,y:528,t:1527189177885};\\\", \\\"{x:625,y:528,t:1527189177902};\\\", \\\"{x:626,y:528,t:1527189177918};\\\", \\\"{x:627,y:528,t:1527189177956};\\\", \\\"{x:628,y:528,t:1527189177968};\\\", \\\"{x:637,y:528,t:1527189177985};\\\", \\\"{x:657,y:524,t:1527189178003};\\\", \\\"{x:683,y:523,t:1527189178018};\\\", \\\"{x:723,y:523,t:1527189178034};\\\", \\\"{x:762,y:523,t:1527189178052};\\\", \\\"{x:787,y:523,t:1527189178068};\\\", \\\"{x:799,y:523,t:1527189178085};\\\", \\\"{x:802,y:523,t:1527189178101};\\\", \\\"{x:804,y:523,t:1527189178118};\\\", \\\"{x:805,y:522,t:1527189178213};\\\", \\\"{x:806,y:521,t:1527189178220};\\\", \\\"{x:806,y:520,t:1527189178244};\\\", \\\"{x:808,y:518,t:1527189178277};\\\", \\\"{x:809,y:518,t:1527189178284};\\\", \\\"{x:811,y:517,t:1527189178303};\\\", \\\"{x:813,y:515,t:1527189178319};\\\", \\\"{x:815,y:512,t:1527189178335};\\\", \\\"{x:816,y:511,t:1527189178352};\\\", \\\"{x:818,y:510,t:1527189178369};\\\", \\\"{x:819,y:508,t:1527189178384};\\\", \\\"{x:822,y:505,t:1527189178402};\\\", \\\"{x:827,y:500,t:1527189178419};\\\", \\\"{x:831,y:499,t:1527189178435};\\\", \\\"{x:835,y:497,t:1527189178452};\\\", \\\"{x:836,y:497,t:1527189178468};\\\", \\\"{x:840,y:496,t:1527189178485};\\\", \\\"{x:844,y:494,t:1527189178502};\\\", \\\"{x:845,y:493,t:1527189178540};\\\", \\\"{x:839,y:494,t:1527189178901};\\\", \\\"{x:832,y:499,t:1527189178908};\\\", \\\"{x:811,y:505,t:1527189178920};\\\", \\\"{x:775,y:516,t:1527189178936};\\\", \\\"{x:718,y:527,t:1527189178952};\\\", \\\"{x:689,y:530,t:1527189178968};\\\", \\\"{x:674,y:532,t:1527189178986};\\\", \\\"{x:670,y:533,t:1527189179003};\\\", \\\"{x:664,y:537,t:1527189179019};\\\", \\\"{x:651,y:542,t:1527189179036};\\\", \\\"{x:638,y:547,t:1527189179053};\\\", \\\"{x:625,y:550,t:1527189179069};\\\", \\\"{x:618,y:551,t:1527189179086};\\\", \\\"{x:614,y:552,t:1527189179103};\\\", \\\"{x:613,y:553,t:1527189179119};\\\", \\\"{x:612,y:553,t:1527189179148};\\\", \\\"{x:610,y:556,t:1527189179156};\\\", \\\"{x:604,y:559,t:1527189179168};\\\", \\\"{x:591,y:562,t:1527189179186};\\\", \\\"{x:572,y:569,t:1527189179204};\\\", \\\"{x:557,y:570,t:1527189179218};\\\", \\\"{x:543,y:570,t:1527189179236};\\\", \\\"{x:539,y:570,t:1527189179253};\\\", \\\"{x:535,y:571,t:1527189179269};\\\", \\\"{x:521,y:574,t:1527189179286};\\\", \\\"{x:514,y:575,t:1527189179303};\\\", \\\"{x:508,y:575,t:1527189179319};\\\", \\\"{x:508,y:576,t:1527189179701};\\\", \\\"{x:495,y:582,t:1527189179710};\\\", \\\"{x:481,y:590,t:1527189179721};\\\", \\\"{x:457,y:597,t:1527189179737};\\\", \\\"{x:429,y:599,t:1527189179753};\\\", \\\"{x:385,y:602,t:1527189179770};\\\", \\\"{x:346,y:602,t:1527189179786};\\\", \\\"{x:318,y:602,t:1527189179803};\\\", \\\"{x:292,y:600,t:1527189179820};\\\", \\\"{x:273,y:600,t:1527189179836};\\\", \\\"{x:255,y:597,t:1527189179853};\\\", \\\"{x:247,y:596,t:1527189179870};\\\", \\\"{x:246,y:594,t:1527189179957};\\\", \\\"{x:243,y:593,t:1527189179971};\\\", \\\"{x:231,y:588,t:1527189179987};\\\", \\\"{x:219,y:582,t:1527189180003};\\\", \\\"{x:207,y:572,t:1527189180020};\\\", \\\"{x:201,y:563,t:1527189180037};\\\", \\\"{x:192,y:550,t:1527189180053};\\\", \\\"{x:185,y:544,t:1527189180070};\\\", \\\"{x:172,y:537,t:1527189180086};\\\", \\\"{x:159,y:534,t:1527189180103};\\\", \\\"{x:145,y:533,t:1527189180120};\\\", \\\"{x:140,y:532,t:1527189180137};\\\", \\\"{x:139,y:532,t:1527189180153};\\\", \\\"{x:140,y:530,t:1527189180365};\\\", \\\"{x:141,y:530,t:1527189180405};\\\", \\\"{x:142,y:531,t:1527189180420};\\\", \\\"{x:143,y:531,t:1527189180452};\\\", \\\"{x:145,y:531,t:1527189180469};\\\", \\\"{x:147,y:533,t:1527189180476};\\\", \\\"{x:148,y:533,t:1527189180503};\\\", \\\"{x:148,y:533,t:1527189180556};\\\", \\\"{x:149,y:533,t:1527189180605};\\\", \\\"{x:152,y:533,t:1527189180620};\\\", \\\"{x:167,y:549,t:1527189180637};\\\", \\\"{x:203,y:573,t:1527189180654};\\\", \\\"{x:243,y:602,t:1527189180671};\\\", \\\"{x:287,y:629,t:1527189180688};\\\", \\\"{x:331,y:649,t:1527189180705};\\\", \\\"{x:361,y:657,t:1527189180721};\\\", \\\"{x:381,y:669,t:1527189180737};\\\", \\\"{x:401,y:680,t:1527189180754};\\\", \\\"{x:417,y:689,t:1527189180771};\\\", \\\"{x:438,y:700,t:1527189180787};\\\", \\\"{x:461,y:713,t:1527189180804};\\\", \\\"{x:466,y:716,t:1527189180820};\\\", \\\"{x:459,y:716,t:1527189180893};\\\", \\\"{x:451,y:714,t:1527189180904};\\\", \\\"{x:445,y:710,t:1527189180922};\\\", \\\"{x:441,y:709,t:1527189180938};\\\", \\\"{x:440,y:707,t:1527189181004};\\\", \\\"{x:429,y:686,t:1527189181020};\\\", \\\"{x:404,y:660,t:1527189181038};\\\", \\\"{x:374,y:632,t:1527189181054};\\\", \\\"{x:313,y:593,t:1527189181071};\\\", \\\"{x:285,y:579,t:1527189181088};\\\", \\\"{x:278,y:572,t:1527189181104};\\\", \\\"{x:277,y:572,t:1527189181131};\\\", \\\"{x:272,y:570,t:1527189181156};\\\", \\\"{x:259,y:568,t:1527189181171};\\\", \\\"{x:236,y:561,t:1527189181187};\\\", \\\"{x:202,y:555,t:1527189181204};\\\", \\\"{x:192,y:550,t:1527189181221};\\\", \\\"{x:191,y:548,t:1527189181341};\\\", \\\"{x:191,y:547,t:1527189181372};\\\", \\\"{x:192,y:542,t:1527189181387};\\\", \\\"{x:196,y:536,t:1527189181404};\\\", \\\"{x:196,y:535,t:1527189181492};\\\", \\\"{x:189,y:535,t:1527189181505};\\\", \\\"{x:173,y:534,t:1527189181521};\\\", \\\"{x:166,y:534,t:1527189181538};\\\", \\\"{x:164,y:533,t:1527189181554};\\\", \\\"{x:164,y:534,t:1527189181884};\\\", \\\"{x:178,y:544,t:1527189181892};\\\", \\\"{x:197,y:556,t:1527189181905};\\\", \\\"{x:234,y:574,t:1527189181921};\\\", \\\"{x:265,y:598,t:1527189181939};\\\", \\\"{x:311,y:621,t:1527189181955};\\\", \\\"{x:355,y:650,t:1527189181972};\\\", \\\"{x:373,y:666,t:1527189181987};\\\", \\\"{x:384,y:677,t:1527189182005};\\\", \\\"{x:397,y:689,t:1527189182022};\\\", \\\"{x:406,y:704,t:1527189182038};\\\", \\\"{x:419,y:720,t:1527189182055};\\\", \\\"{x:434,y:737,t:1527189182072};\\\", \\\"{x:453,y:758,t:1527189182088};\\\", \\\"{x:466,y:773,t:1527189182105};\\\", \\\"{x:469,y:778,t:1527189182122};\\\", \\\"{x:469,y:779,t:1527189182137};\\\", \\\"{x:472,y:783,t:1527189182155};\\\", \\\"{x:474,y:785,t:1527189182171};\\\", \\\"{x:476,y:786,t:1527189182189};\\\", \\\"{x:476,y:779,t:1527189182237};\\\", \\\"{x:476,y:770,t:1527189182245};\\\", \\\"{x:476,y:760,t:1527189182256};\\\", \\\"{x:476,y:752,t:1527189182276};\\\", \\\"{x:476,y:745,t:1527189182288};\\\", \\\"{x:476,y:744,t:1527189182308};\\\", \\\"{x:476,y:743,t:1527189182380};\\\", \\\"{x:476,y:741,t:1527189182387};\\\", \\\"{x:476,y:740,t:1527189182405};\\\" ] }, { \\\"rt\\\": 65272, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 782083, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -M -02 PM-E -11 AM-12 PM-02 PM-01 PM-02 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:754,t:1527189191340};\\\", \\\"{x:492,y:776,t:1527189191359};\\\", \\\"{x:495,y:785,t:1527189191365};\\\", \\\"{x:495,y:790,t:1527189191379};\\\", \\\"{x:499,y:808,t:1527189191396};\\\", \\\"{x:504,y:831,t:1527189191412};\\\", \\\"{x:507,y:837,t:1527189191429};\\\", \\\"{x:508,y:840,t:1527189191446};\\\", \\\"{x:508,y:843,t:1527189191463};\\\", \\\"{x:509,y:844,t:1527189191480};\\\", \\\"{x:509,y:845,t:1527189191496};\\\", \\\"{x:509,y:846,t:1527189193437};\\\", \\\"{x:507,y:846,t:1527189193448};\\\", \\\"{x:506,y:846,t:1527189193465};\\\", \\\"{x:506,y:845,t:1527189196640};\\\", \\\"{x:522,y:834,t:1527189196653};\\\", \\\"{x:617,y:803,t:1527189196669};\\\", \\\"{x:850,y:775,t:1527189196687};\\\", \\\"{x:1031,y:759,t:1527189196703};\\\", \\\"{x:1208,y:739,t:1527189196720};\\\", \\\"{x:1350,y:728,t:1527189196737};\\\", \\\"{x:1489,y:707,t:1527189196754};\\\", \\\"{x:1589,y:693,t:1527189196770};\\\", \\\"{x:1665,y:678,t:1527189196787};\\\", \\\"{x:1691,y:668,t:1527189196804};\\\", \\\"{x:1707,y:660,t:1527189196820};\\\", \\\"{x:1722,y:650,t:1527189196837};\\\", \\\"{x:1746,y:638,t:1527189196854};\\\", \\\"{x:1786,y:627,t:1527189196870};\\\", \\\"{x:1821,y:619,t:1527189196887};\\\", \\\"{x:1828,y:616,t:1527189196904};\\\", \\\"{x:1829,y:615,t:1527189196920};\\\", \\\"{x:1829,y:613,t:1527189196943};\\\", \\\"{x:1829,y:612,t:1527189196954};\\\", \\\"{x:1829,y:611,t:1527189196969};\\\", \\\"{x:1830,y:609,t:1527189196987};\\\", \\\"{x:1829,y:609,t:1527189197024};\\\", \\\"{x:1824,y:609,t:1527189197036};\\\", \\\"{x:1811,y:623,t:1527189197054};\\\", \\\"{x:1777,y:650,t:1527189197070};\\\", \\\"{x:1733,y:670,t:1527189197086};\\\", \\\"{x:1672,y:716,t:1527189197103};\\\", \\\"{x:1656,y:728,t:1527189197120};\\\", \\\"{x:1647,y:729,t:1527189197137};\\\", \\\"{x:1633,y:725,t:1527189197154};\\\", \\\"{x:1610,y:710,t:1527189197171};\\\", \\\"{x:1589,y:691,t:1527189197187};\\\", \\\"{x:1568,y:669,t:1527189197204};\\\", \\\"{x:1557,y:662,t:1527189197221};\\\", \\\"{x:1550,y:658,t:1527189197237};\\\", \\\"{x:1543,y:653,t:1527189197254};\\\", \\\"{x:1522,y:645,t:1527189197271};\\\", \\\"{x:1505,y:638,t:1527189197288};\\\", \\\"{x:1486,y:626,t:1527189197303};\\\", \\\"{x:1467,y:612,t:1527189197321};\\\", \\\"{x:1442,y:601,t:1527189197337};\\\", \\\"{x:1424,y:594,t:1527189197354};\\\", \\\"{x:1409,y:587,t:1527189197371};\\\", \\\"{x:1399,y:584,t:1527189197387};\\\", \\\"{x:1398,y:583,t:1527189197404};\\\", \\\"{x:1396,y:581,t:1527189197421};\\\", \\\"{x:1392,y:577,t:1527189197437};\\\", \\\"{x:1368,y:572,t:1527189197454};\\\", \\\"{x:1335,y:563,t:1527189197471};\\\", \\\"{x:1303,y:553,t:1527189197487};\\\", \\\"{x:1296,y:549,t:1527189197504};\\\", \\\"{x:1299,y:549,t:1527189197656};\\\", \\\"{x:1328,y:549,t:1527189197671};\\\", \\\"{x:1370,y:549,t:1527189197687};\\\", \\\"{x:1434,y:549,t:1527189197704};\\\", \\\"{x:1492,y:549,t:1527189197721};\\\", \\\"{x:1535,y:549,t:1527189197738};\\\", \\\"{x:1561,y:550,t:1527189197754};\\\", \\\"{x:1580,y:556,t:1527189197771};\\\", \\\"{x:1584,y:557,t:1527189197788};\\\", \\\"{x:1590,y:560,t:1527189197804};\\\", \\\"{x:1590,y:561,t:1527189197821};\\\", \\\"{x:1590,y:566,t:1527189197887};\\\", \\\"{x:1593,y:587,t:1527189197904};\\\", \\\"{x:1598,y:605,t:1527189197921};\\\", \\\"{x:1605,y:621,t:1527189197938};\\\", \\\"{x:1613,y:641,t:1527189197954};\\\", \\\"{x:1622,y:657,t:1527189197971};\\\", \\\"{x:1628,y:680,t:1527189197988};\\\", \\\"{x:1634,y:700,t:1527189198004};\\\", \\\"{x:1636,y:718,t:1527189198021};\\\", \\\"{x:1638,y:730,t:1527189198038};\\\", \\\"{x:1638,y:743,t:1527189198055};\\\", \\\"{x:1633,y:757,t:1527189198072};\\\", \\\"{x:1630,y:765,t:1527189198088};\\\", \\\"{x:1624,y:773,t:1527189198105};\\\", \\\"{x:1620,y:778,t:1527189198121};\\\", \\\"{x:1611,y:786,t:1527189198138};\\\", \\\"{x:1601,y:792,t:1527189198155};\\\", \\\"{x:1592,y:799,t:1527189198171};\\\", \\\"{x:1586,y:803,t:1527189198188};\\\", \\\"{x:1582,y:806,t:1527189198205};\\\", \\\"{x:1580,y:808,t:1527189198221};\\\", \\\"{x:1578,y:811,t:1527189198238};\\\", \\\"{x:1572,y:818,t:1527189198255};\\\", \\\"{x:1566,y:822,t:1527189198271};\\\", \\\"{x:1559,y:827,t:1527189198288};\\\", \\\"{x:1551,y:831,t:1527189198305};\\\", \\\"{x:1547,y:834,t:1527189198321};\\\", \\\"{x:1543,y:835,t:1527189198338};\\\", \\\"{x:1535,y:839,t:1527189198355};\\\", \\\"{x:1524,y:843,t:1527189198371};\\\", \\\"{x:1516,y:846,t:1527189198388};\\\", \\\"{x:1502,y:855,t:1527189198405};\\\", \\\"{x:1491,y:858,t:1527189198421};\\\", \\\"{x:1486,y:860,t:1527189198438};\\\", \\\"{x:1479,y:862,t:1527189198456};\\\", \\\"{x:1473,y:865,t:1527189198471};\\\", \\\"{x:1468,y:866,t:1527189198488};\\\", \\\"{x:1463,y:866,t:1527189198505};\\\", \\\"{x:1454,y:867,t:1527189198523};\\\", \\\"{x:1447,y:868,t:1527189198538};\\\", \\\"{x:1441,y:870,t:1527189198555};\\\", \\\"{x:1438,y:871,t:1527189198572};\\\", \\\"{x:1436,y:872,t:1527189198588};\\\", \\\"{x:1430,y:872,t:1527189198605};\\\", \\\"{x:1423,y:872,t:1527189198622};\\\", \\\"{x:1414,y:872,t:1527189198638};\\\", \\\"{x:1397,y:872,t:1527189198656};\\\", \\\"{x:1386,y:872,t:1527189198671};\\\", \\\"{x:1375,y:872,t:1527189198688};\\\", \\\"{x:1371,y:872,t:1527189198705};\\\", \\\"{x:1370,y:872,t:1527189198727};\\\", \\\"{x:1368,y:872,t:1527189198751};\\\", \\\"{x:1364,y:872,t:1527189198760};\\\", \\\"{x:1358,y:872,t:1527189198772};\\\", \\\"{x:1344,y:868,t:1527189198788};\\\", \\\"{x:1330,y:865,t:1527189198805};\\\", \\\"{x:1318,y:863,t:1527189198822};\\\", \\\"{x:1313,y:863,t:1527189198838};\\\", \\\"{x:1311,y:863,t:1527189198944};\\\", \\\"{x:1310,y:862,t:1527189198959};\\\", \\\"{x:1310,y:861,t:1527189198972};\\\", \\\"{x:1308,y:861,t:1527189198989};\\\", \\\"{x:1306,y:860,t:1527189199005};\\\", \\\"{x:1301,y:858,t:1527189199022};\\\", \\\"{x:1297,y:856,t:1527189199039};\\\", \\\"{x:1294,y:854,t:1527189199056};\\\", \\\"{x:1292,y:853,t:1527189199072};\\\", \\\"{x:1291,y:853,t:1527189199096};\\\", \\\"{x:1289,y:852,t:1527189199127};\\\", \\\"{x:1289,y:851,t:1527189199143};\\\", \\\"{x:1288,y:851,t:1527189199155};\\\", \\\"{x:1286,y:849,t:1527189199172};\\\", \\\"{x:1286,y:848,t:1527189199191};\\\", \\\"{x:1285,y:848,t:1527189199280};\\\", \\\"{x:1284,y:847,t:1527189199289};\\\", \\\"{x:1283,y:845,t:1527189199305};\\\", \\\"{x:1282,y:844,t:1527189199327};\\\", \\\"{x:1281,y:844,t:1527189199339};\\\", \\\"{x:1281,y:842,t:1527189199368};\\\", \\\"{x:1280,y:840,t:1527189199391};\\\", \\\"{x:1279,y:838,t:1527189199406};\\\", \\\"{x:1279,y:836,t:1527189199438};\\\", \\\"{x:1278,y:835,t:1527189199478};\\\", \\\"{x:1277,y:834,t:1527189199518};\\\", \\\"{x:1276,y:832,t:1527189199527};\\\", \\\"{x:1275,y:831,t:1527189199543};\\\", \\\"{x:1275,y:830,t:1527189199556};\\\", \\\"{x:1274,y:830,t:1527189199571};\\\", \\\"{x:1273,y:829,t:1527189199589};\\\", \\\"{x:1272,y:828,t:1527189199605};\\\", \\\"{x:1272,y:827,t:1527189199622};\\\", \\\"{x:1271,y:826,t:1527189199639};\\\", \\\"{x:1270,y:826,t:1527189199655};\\\", \\\"{x:1270,y:825,t:1527189199728};\\\", \\\"{x:1269,y:824,t:1527189199740};\\\", \\\"{x:1268,y:822,t:1527189199756};\\\", \\\"{x:1268,y:820,t:1527189199772};\\\", \\\"{x:1267,y:819,t:1527189199789};\\\", \\\"{x:1266,y:818,t:1527189199806};\\\", \\\"{x:1266,y:817,t:1527189199855};\\\", \\\"{x:1266,y:815,t:1527189199873};\\\", \\\"{x:1265,y:814,t:1527189199889};\\\", \\\"{x:1265,y:813,t:1527189199944};\\\", \\\"{x:1265,y:812,t:1527189201968};\\\", \\\"{x:1265,y:809,t:1527189201976};\\\", \\\"{x:1266,y:802,t:1527189201992};\\\", \\\"{x:1269,y:796,t:1527189202007};\\\", \\\"{x:1279,y:777,t:1527189202024};\\\", \\\"{x:1299,y:751,t:1527189202041};\\\", \\\"{x:1303,y:742,t:1527189202059};\\\", \\\"{x:1311,y:724,t:1527189202075};\\\", \\\"{x:1316,y:715,t:1527189202092};\\\", \\\"{x:1322,y:709,t:1527189202108};\\\", \\\"{x:1325,y:706,t:1527189202124};\\\", \\\"{x:1328,y:702,t:1527189202142};\\\", \\\"{x:1330,y:701,t:1527189202159};\\\", \\\"{x:1332,y:699,t:1527189202174};\\\", \\\"{x:1334,y:696,t:1527189202192};\\\", \\\"{x:1334,y:695,t:1527189202576};\\\", \\\"{x:1337,y:695,t:1527189202615};\\\", \\\"{x:1341,y:698,t:1527189202625};\\\", \\\"{x:1347,y:705,t:1527189202641};\\\", \\\"{x:1351,y:715,t:1527189202658};\\\", \\\"{x:1352,y:724,t:1527189202675};\\\", \\\"{x:1355,y:736,t:1527189202692};\\\", \\\"{x:1356,y:745,t:1527189202709};\\\", \\\"{x:1359,y:750,t:1527189202725};\\\", \\\"{x:1360,y:757,t:1527189202741};\\\", \\\"{x:1360,y:762,t:1527189202758};\\\", \\\"{x:1360,y:775,t:1527189202775};\\\", \\\"{x:1360,y:781,t:1527189202791};\\\", \\\"{x:1360,y:783,t:1527189202808};\\\", \\\"{x:1360,y:784,t:1527189202950};\\\", \\\"{x:1359,y:784,t:1527189203527};\\\", \\\"{x:1358,y:784,t:1527189203608};\\\", \\\"{x:1356,y:784,t:1527189204328};\\\", \\\"{x:1356,y:781,t:1527189204343};\\\", \\\"{x:1356,y:778,t:1527189204359};\\\", \\\"{x:1353,y:774,t:1527189204377};\\\", \\\"{x:1353,y:773,t:1527189204393};\\\", \\\"{x:1353,y:772,t:1527189204432};\\\", \\\"{x:1349,y:775,t:1527189215679};\\\", \\\"{x:1346,y:783,t:1527189215687};\\\", \\\"{x:1344,y:787,t:1527189215701};\\\", \\\"{x:1344,y:788,t:1527189215719};\\\", \\\"{x:1343,y:791,t:1527189215760};\\\", \\\"{x:1343,y:792,t:1527189215783};\\\", \\\"{x:1343,y:794,t:1527189215791};\\\", \\\"{x:1343,y:796,t:1527189215802};\\\", \\\"{x:1343,y:798,t:1527189215819};\\\", \\\"{x:1340,y:801,t:1527189215836};\\\", \\\"{x:1340,y:803,t:1527189215851};\\\", \\\"{x:1336,y:807,t:1527189215869};\\\", \\\"{x:1333,y:812,t:1527189215886};\\\", \\\"{x:1329,y:816,t:1527189215902};\\\", \\\"{x:1320,y:823,t:1527189215919};\\\", \\\"{x:1314,y:827,t:1527189215935};\\\", \\\"{x:1310,y:831,t:1527189215952};\\\", \\\"{x:1300,y:837,t:1527189215969};\\\", \\\"{x:1294,y:841,t:1527189215985};\\\", \\\"{x:1293,y:844,t:1527189216002};\\\", \\\"{x:1291,y:844,t:1527189216019};\\\", \\\"{x:1290,y:845,t:1527189216035};\\\", \\\"{x:1289,y:845,t:1527189216052};\\\", \\\"{x:1288,y:847,t:1527189216069};\\\", \\\"{x:1287,y:847,t:1527189216086};\\\", \\\"{x:1287,y:848,t:1527189216102};\\\", \\\"{x:1287,y:850,t:1527189216119};\\\", \\\"{x:1287,y:851,t:1527189216143};\\\", \\\"{x:1287,y:852,t:1527189216167};\\\", \\\"{x:1287,y:853,t:1527189216176};\\\", \\\"{x:1286,y:854,t:1527189216615};\\\", \\\"{x:1289,y:855,t:1527189217343};\\\", \\\"{x:1308,y:854,t:1527189217353};\\\", \\\"{x:1367,y:843,t:1527189217370};\\\", \\\"{x:1401,y:843,t:1527189217387};\\\", \\\"{x:1439,y:843,t:1527189217403};\\\", \\\"{x:1462,y:843,t:1527189217420};\\\", \\\"{x:1466,y:845,t:1527189217437};\\\", \\\"{x:1463,y:843,t:1527189232863};\\\", \\\"{x:1460,y:836,t:1527189232870};\\\", \\\"{x:1457,y:830,t:1527189232882};\\\", \\\"{x:1454,y:822,t:1527189232898};\\\", \\\"{x:1451,y:810,t:1527189232915};\\\", \\\"{x:1446,y:803,t:1527189232932};\\\", \\\"{x:1442,y:792,t:1527189232949};\\\", \\\"{x:1438,y:782,t:1527189232965};\\\", \\\"{x:1432,y:768,t:1527189232982};\\\", \\\"{x:1427,y:757,t:1527189232998};\\\", \\\"{x:1422,y:746,t:1527189233015};\\\", \\\"{x:1415,y:736,t:1527189233032};\\\", \\\"{x:1411,y:723,t:1527189233049};\\\", \\\"{x:1407,y:706,t:1527189233065};\\\", \\\"{x:1401,y:689,t:1527189233082};\\\", \\\"{x:1395,y:680,t:1527189233099};\\\", \\\"{x:1392,y:671,t:1527189233115};\\\", \\\"{x:1389,y:665,t:1527189233132};\\\", \\\"{x:1386,y:660,t:1527189233149};\\\", \\\"{x:1384,y:657,t:1527189233165};\\\", \\\"{x:1376,y:650,t:1527189233182};\\\", \\\"{x:1369,y:642,t:1527189233199};\\\", \\\"{x:1365,y:637,t:1527189233216};\\\", \\\"{x:1363,y:633,t:1527189233232};\\\", \\\"{x:1362,y:632,t:1527189233249};\\\", \\\"{x:1361,y:630,t:1527189233265};\\\", \\\"{x:1357,y:627,t:1527189233282};\\\", \\\"{x:1353,y:623,t:1527189233299};\\\", \\\"{x:1347,y:619,t:1527189233316};\\\", \\\"{x:1342,y:617,t:1527189233332};\\\", \\\"{x:1340,y:615,t:1527189233350};\\\", \\\"{x:1334,y:611,t:1527189233367};\\\", \\\"{x:1333,y:609,t:1527189233383};\\\", \\\"{x:1331,y:608,t:1527189233399};\\\", \\\"{x:1328,y:605,t:1527189233416};\\\", \\\"{x:1324,y:602,t:1527189233433};\\\", \\\"{x:1321,y:602,t:1527189233450};\\\", \\\"{x:1318,y:600,t:1527189233466};\\\", \\\"{x:1315,y:597,t:1527189233482};\\\", \\\"{x:1310,y:597,t:1527189233499};\\\", \\\"{x:1309,y:595,t:1527189233517};\\\", \\\"{x:1306,y:595,t:1527189233533};\\\", \\\"{x:1303,y:593,t:1527189233550};\\\", \\\"{x:1298,y:589,t:1527189233567};\\\", \\\"{x:1296,y:587,t:1527189233583};\\\", \\\"{x:1293,y:584,t:1527189233599};\\\", \\\"{x:1292,y:583,t:1527189233616};\\\", \\\"{x:1290,y:581,t:1527189233633};\\\", \\\"{x:1288,y:579,t:1527189233650};\\\", \\\"{x:1286,y:577,t:1527189233667};\\\", \\\"{x:1285,y:576,t:1527189233683};\\\", \\\"{x:1283,y:575,t:1527189233699};\\\", \\\"{x:1282,y:575,t:1527189233717};\\\", \\\"{x:1281,y:574,t:1527189233735};\\\", \\\"{x:1281,y:573,t:1527189233967};\\\", \\\"{x:1281,y:570,t:1527189233983};\\\", \\\"{x:1282,y:566,t:1527189234003};\\\", \\\"{x:1285,y:561,t:1527189234016};\\\", \\\"{x:1286,y:556,t:1527189234033};\\\", \\\"{x:1287,y:555,t:1527189234049};\\\", \\\"{x:1287,y:554,t:1527189234520};\\\", \\\"{x:1283,y:555,t:1527189234534};\\\", \\\"{x:1280,y:557,t:1527189234550};\\\", \\\"{x:1278,y:560,t:1527189234567};\\\", \\\"{x:1278,y:572,t:1527189240936};\\\", \\\"{x:1278,y:597,t:1527189240943};\\\", \\\"{x:1282,y:618,t:1527189240956};\\\", \\\"{x:1295,y:637,t:1527189240972};\\\", \\\"{x:1299,y:668,t:1527189240988};\\\", \\\"{x:1309,y:689,t:1527189241005};\\\", \\\"{x:1321,y:719,t:1527189241022};\\\", \\\"{x:1331,y:752,t:1527189241039};\\\", \\\"{x:1337,y:767,t:1527189241056};\\\", \\\"{x:1341,y:785,t:1527189241072};\\\", \\\"{x:1346,y:797,t:1527189241089};\\\", \\\"{x:1354,y:817,t:1527189241106};\\\", \\\"{x:1358,y:840,t:1527189241122};\\\", \\\"{x:1366,y:862,t:1527189241139};\\\", \\\"{x:1374,y:880,t:1527189241156};\\\", \\\"{x:1384,y:892,t:1527189241172};\\\", \\\"{x:1393,y:897,t:1527189241190};\\\", \\\"{x:1401,y:902,t:1527189241206};\\\", \\\"{x:1406,y:907,t:1527189241222};\\\", \\\"{x:1417,y:913,t:1527189241239};\\\", \\\"{x:1437,y:923,t:1527189241256};\\\", \\\"{x:1456,y:932,t:1527189241272};\\\", \\\"{x:1474,y:940,t:1527189241289};\\\", \\\"{x:1484,y:945,t:1527189241306};\\\", \\\"{x:1491,y:951,t:1527189241323};\\\", \\\"{x:1496,y:954,t:1527189241339};\\\", \\\"{x:1497,y:955,t:1527189241356};\\\", \\\"{x:1497,y:957,t:1527189241408};\\\", \\\"{x:1496,y:963,t:1527189241425};\\\", \\\"{x:1494,y:967,t:1527189241439};\\\", \\\"{x:1494,y:968,t:1527189241455};\\\", \\\"{x:1493,y:969,t:1527189241478};\\\", \\\"{x:1492,y:970,t:1527189241542};\\\", \\\"{x:1491,y:970,t:1527189241555};\\\", \\\"{x:1490,y:970,t:1527189241572};\\\", \\\"{x:1491,y:968,t:1527189241688};\\\", \\\"{x:1498,y:967,t:1527189241695};\\\", \\\"{x:1507,y:966,t:1527189241706};\\\", \\\"{x:1520,y:964,t:1527189241722};\\\", \\\"{x:1535,y:964,t:1527189241739};\\\", \\\"{x:1545,y:964,t:1527189241755};\\\", \\\"{x:1546,y:964,t:1527189241773};\\\", \\\"{x:1549,y:963,t:1527189241823};\\\", \\\"{x:1552,y:962,t:1527189241840};\\\", \\\"{x:1557,y:962,t:1527189241856};\\\", \\\"{x:1566,y:960,t:1527189241873};\\\", \\\"{x:1572,y:959,t:1527189241889};\\\", \\\"{x:1578,y:959,t:1527189241906};\\\", \\\"{x:1582,y:958,t:1527189241922};\\\", \\\"{x:1586,y:958,t:1527189241940};\\\", \\\"{x:1588,y:958,t:1527189241956};\\\", \\\"{x:1589,y:958,t:1527189241973};\\\", \\\"{x:1590,y:958,t:1527189241990};\\\", \\\"{x:1593,y:958,t:1527189242006};\\\", \\\"{x:1595,y:958,t:1527189242023};\\\", \\\"{x:1599,y:958,t:1527189242047};\\\", \\\"{x:1600,y:959,t:1527189242056};\\\", \\\"{x:1611,y:962,t:1527189242073};\\\", \\\"{x:1613,y:963,t:1527189242091};\\\", \\\"{x:1619,y:964,t:1527189242106};\\\", \\\"{x:1623,y:965,t:1527189242123};\\\", \\\"{x:1610,y:952,t:1527189244807};\\\", \\\"{x:1603,y:942,t:1527189244815};\\\", \\\"{x:1594,y:932,t:1527189244825};\\\", \\\"{x:1576,y:918,t:1527189244842};\\\", \\\"{x:1552,y:896,t:1527189244859};\\\", \\\"{x:1526,y:880,t:1527189244875};\\\", \\\"{x:1508,y:867,t:1527189244892};\\\", \\\"{x:1486,y:852,t:1527189244909};\\\", \\\"{x:1464,y:835,t:1527189244925};\\\", \\\"{x:1449,y:822,t:1527189244942};\\\", \\\"{x:1434,y:800,t:1527189244959};\\\", \\\"{x:1419,y:783,t:1527189244975};\\\", \\\"{x:1407,y:766,t:1527189244992};\\\", \\\"{x:1396,y:751,t:1527189245009};\\\", \\\"{x:1389,y:736,t:1527189245026};\\\", \\\"{x:1382,y:724,t:1527189245042};\\\", \\\"{x:1379,y:712,t:1527189245059};\\\", \\\"{x:1370,y:692,t:1527189245075};\\\", \\\"{x:1361,y:666,t:1527189245092};\\\", \\\"{x:1343,y:634,t:1527189245109};\\\", \\\"{x:1320,y:607,t:1527189245125};\\\", \\\"{x:1303,y:586,t:1527189245142};\\\", \\\"{x:1286,y:568,t:1527189245159};\\\", \\\"{x:1283,y:566,t:1527189245176};\\\", \\\"{x:1283,y:564,t:1527189245192};\\\", \\\"{x:1283,y:563,t:1527189245209};\\\", \\\"{x:1283,y:562,t:1527189245225};\\\", \\\"{x:1284,y:562,t:1527189245279};\\\", \\\"{x:1292,y:562,t:1527189245294};\\\", \\\"{x:1294,y:565,t:1527189245309};\\\", \\\"{x:1296,y:567,t:1527189245326};\\\", \\\"{x:1297,y:567,t:1527189245342};\\\", \\\"{x:1297,y:571,t:1527189245959};\\\", \\\"{x:1297,y:597,t:1527189245977};\\\", \\\"{x:1293,y:625,t:1527189245993};\\\", \\\"{x:1292,y:652,t:1527189246009};\\\", \\\"{x:1292,y:679,t:1527189246026};\\\", \\\"{x:1292,y:702,t:1527189246043};\\\", \\\"{x:1295,y:723,t:1527189246060};\\\", \\\"{x:1296,y:738,t:1527189246076};\\\", \\\"{x:1296,y:749,t:1527189246093};\\\", \\\"{x:1299,y:762,t:1527189246109};\\\", \\\"{x:1302,y:774,t:1527189246126};\\\", \\\"{x:1304,y:796,t:1527189246143};\\\", \\\"{x:1306,y:806,t:1527189246160};\\\", \\\"{x:1307,y:814,t:1527189246177};\\\", \\\"{x:1307,y:823,t:1527189246193};\\\", \\\"{x:1307,y:836,t:1527189246210};\\\", \\\"{x:1307,y:853,t:1527189246227};\\\", \\\"{x:1307,y:878,t:1527189246243};\\\", \\\"{x:1306,y:892,t:1527189246260};\\\", \\\"{x:1306,y:901,t:1527189246276};\\\", \\\"{x:1306,y:905,t:1527189246293};\\\", \\\"{x:1306,y:909,t:1527189246310};\\\", \\\"{x:1305,y:912,t:1527189246326};\\\", \\\"{x:1302,y:919,t:1527189246343};\\\", \\\"{x:1302,y:922,t:1527189246360};\\\", \\\"{x:1300,y:926,t:1527189246376};\\\", \\\"{x:1300,y:928,t:1527189246394};\\\", \\\"{x:1300,y:929,t:1527189246410};\\\", \\\"{x:1299,y:932,t:1527189246426};\\\", \\\"{x:1298,y:932,t:1527189246443};\\\", \\\"{x:1298,y:934,t:1527189246471};\\\", \\\"{x:1297,y:935,t:1527189246480};\\\", \\\"{x:1297,y:936,t:1527189246493};\\\", \\\"{x:1296,y:940,t:1527189246510};\\\", \\\"{x:1293,y:950,t:1527189246526};\\\", \\\"{x:1290,y:963,t:1527189246543};\\\", \\\"{x:1290,y:969,t:1527189246561};\\\", \\\"{x:1290,y:971,t:1527189246576};\\\", \\\"{x:1289,y:976,t:1527189246593};\\\", \\\"{x:1289,y:977,t:1527189246631};\\\", \\\"{x:1289,y:978,t:1527189246670};\\\", \\\"{x:1292,y:976,t:1527189246678};\\\", \\\"{x:1293,y:975,t:1527189246693};\\\", \\\"{x:1294,y:975,t:1527189246710};\\\", \\\"{x:1294,y:974,t:1527189246727};\\\", \\\"{x:1296,y:974,t:1527189246742};\\\", \\\"{x:1297,y:974,t:1527189246761};\\\", \\\"{x:1299,y:974,t:1527189246777};\\\", \\\"{x:1302,y:974,t:1527189246912};\\\", \\\"{x:1305,y:976,t:1527189246926};\\\", \\\"{x:1308,y:977,t:1527189246943};\\\", \\\"{x:1311,y:979,t:1527189246960};\\\", \\\"{x:1313,y:980,t:1527189246977};\\\", \\\"{x:1314,y:981,t:1527189246993};\\\", \\\"{x:1327,y:981,t:1527189247010};\\\", \\\"{x:1334,y:981,t:1527189247028};\\\", \\\"{x:1338,y:981,t:1527189247043};\\\", \\\"{x:1339,y:979,t:1527189247060};\\\", \\\"{x:1340,y:976,t:1527189247078};\\\", \\\"{x:1342,y:975,t:1527189247094};\\\", \\\"{x:1342,y:974,t:1527189247191};\\\", \\\"{x:1344,y:976,t:1527189247198};\\\", \\\"{x:1348,y:984,t:1527189247210};\\\", \\\"{x:1353,y:992,t:1527189247227};\\\", \\\"{x:1361,y:1003,t:1527189247244};\\\", \\\"{x:1372,y:1011,t:1527189247260};\\\", \\\"{x:1389,y:1015,t:1527189247277};\\\", \\\"{x:1417,y:1018,t:1527189247294};\\\", \\\"{x:1440,y:1018,t:1527189247310};\\\", \\\"{x:1466,y:1018,t:1527189247327};\\\", \\\"{x:1474,y:1017,t:1527189247344};\\\", \\\"{x:1476,y:1016,t:1527189247361};\\\", \\\"{x:1477,y:1014,t:1527189247415};\\\", \\\"{x:1477,y:1012,t:1527189247427};\\\", \\\"{x:1475,y:1001,t:1527189247444};\\\", \\\"{x:1469,y:989,t:1527189247460};\\\", \\\"{x:1463,y:977,t:1527189247479};\\\", \\\"{x:1461,y:976,t:1527189247495};\\\", \\\"{x:1459,y:972,t:1527189247511};\\\", \\\"{x:1457,y:971,t:1527189247527};\\\", \\\"{x:1454,y:970,t:1527189247544};\\\", \\\"{x:1452,y:970,t:1527189247561};\\\", \\\"{x:1444,y:967,t:1527189247577};\\\", \\\"{x:1435,y:964,t:1527189247594};\\\", \\\"{x:1427,y:960,t:1527189247612};\\\", \\\"{x:1420,y:955,t:1527189247627};\\\", \\\"{x:1416,y:954,t:1527189247645};\\\", \\\"{x:1416,y:953,t:1527189247662};\\\", \\\"{x:1416,y:959,t:1527189247760};\\\", \\\"{x:1418,y:961,t:1527189247768};\\\", \\\"{x:1418,y:963,t:1527189247777};\\\", \\\"{x:1423,y:969,t:1527189247795};\\\", \\\"{x:1428,y:976,t:1527189247811};\\\", \\\"{x:1431,y:980,t:1527189247827};\\\", \\\"{x:1436,y:982,t:1527189247844};\\\", \\\"{x:1443,y:984,t:1527189247861};\\\", \\\"{x:1449,y:984,t:1527189247877};\\\", \\\"{x:1451,y:984,t:1527189247894};\\\", \\\"{x:1462,y:985,t:1527189247911};\\\", \\\"{x:1469,y:985,t:1527189247927};\\\", \\\"{x:1474,y:986,t:1527189247944};\\\", \\\"{x:1477,y:986,t:1527189247961};\\\", \\\"{x:1480,y:985,t:1527189247978};\\\", \\\"{x:1482,y:983,t:1527189247994};\\\", \\\"{x:1482,y:981,t:1527189248011};\\\", \\\"{x:1484,y:978,t:1527189248028};\\\", \\\"{x:1485,y:974,t:1527189248044};\\\", \\\"{x:1488,y:972,t:1527189248061};\\\", \\\"{x:1488,y:970,t:1527189248079};\\\", \\\"{x:1488,y:967,t:1527189248167};\\\", \\\"{x:1488,y:964,t:1527189248178};\\\", \\\"{x:1488,y:963,t:1527189248194};\\\", \\\"{x:1489,y:962,t:1527189248215};\\\", \\\"{x:1491,y:961,t:1527189248263};\\\", \\\"{x:1496,y:961,t:1527189248279};\\\", \\\"{x:1497,y:961,t:1527189248295};\\\", \\\"{x:1502,y:966,t:1527189248311};\\\", \\\"{x:1503,y:970,t:1527189248328};\\\", \\\"{x:1506,y:974,t:1527189248344};\\\", \\\"{x:1509,y:980,t:1527189248361};\\\", \\\"{x:1511,y:981,t:1527189248378};\\\", \\\"{x:1515,y:984,t:1527189248395};\\\", \\\"{x:1518,y:987,t:1527189248411};\\\", \\\"{x:1519,y:987,t:1527189248428};\\\", \\\"{x:1520,y:987,t:1527189248511};\\\", \\\"{x:1525,y:987,t:1527189248528};\\\", \\\"{x:1533,y:986,t:1527189248545};\\\", \\\"{x:1541,y:982,t:1527189248562};\\\", \\\"{x:1548,y:982,t:1527189248578};\\\", \\\"{x:1552,y:981,t:1527189248596};\\\", \\\"{x:1554,y:980,t:1527189248611};\\\", \\\"{x:1554,y:979,t:1527189248628};\\\", \\\"{x:1556,y:978,t:1527189248645};\\\", \\\"{x:1559,y:974,t:1527189248661};\\\", \\\"{x:1566,y:967,t:1527189248679};\\\", \\\"{x:1568,y:964,t:1527189248695};\\\", \\\"{x:1568,y:963,t:1527189248711};\\\", \\\"{x:1569,y:962,t:1527189248768};\\\", \\\"{x:1571,y:962,t:1527189248823};\\\", \\\"{x:1573,y:965,t:1527189248831};\\\", \\\"{x:1575,y:967,t:1527189248846};\\\", \\\"{x:1579,y:973,t:1527189248862};\\\", \\\"{x:1580,y:977,t:1527189248878};\\\", \\\"{x:1581,y:978,t:1527189248895};\\\", \\\"{x:1584,y:981,t:1527189248912};\\\", \\\"{x:1586,y:982,t:1527189248928};\\\", \\\"{x:1587,y:983,t:1527189248950};\\\", \\\"{x:1589,y:984,t:1527189248962};\\\", \\\"{x:1591,y:984,t:1527189248979};\\\", \\\"{x:1592,y:984,t:1527189248996};\\\", \\\"{x:1593,y:984,t:1527189249012};\\\", \\\"{x:1596,y:984,t:1527189249029};\\\", \\\"{x:1600,y:984,t:1527189249046};\\\", \\\"{x:1610,y:984,t:1527189249062};\\\", \\\"{x:1623,y:986,t:1527189249079};\\\", \\\"{x:1629,y:987,t:1527189249095};\\\", \\\"{x:1638,y:987,t:1527189249112};\\\", \\\"{x:1642,y:987,t:1527189249129};\\\", \\\"{x:1645,y:987,t:1527189249145};\\\", \\\"{x:1646,y:987,t:1527189249162};\\\", \\\"{x:1648,y:986,t:1527189249199};\\\", \\\"{x:1648,y:983,t:1527189249212};\\\", \\\"{x:1648,y:982,t:1527189249231};\\\", \\\"{x:1650,y:980,t:1527189249245};\\\", \\\"{x:1650,y:979,t:1527189249263};\\\", \\\"{x:1650,y:981,t:1527189249383};\\\", \\\"{x:1652,y:984,t:1527189249395};\\\", \\\"{x:1656,y:987,t:1527189249412};\\\", \\\"{x:1661,y:996,t:1527189249429};\\\", \\\"{x:1664,y:1000,t:1527189249445};\\\", \\\"{x:1665,y:1001,t:1527189249462};\\\", \\\"{x:1669,y:1001,t:1527189249478};\\\", \\\"{x:1671,y:1001,t:1527189249503};\\\", \\\"{x:1675,y:1000,t:1527189249512};\\\", \\\"{x:1683,y:997,t:1527189249529};\\\", \\\"{x:1691,y:996,t:1527189249545};\\\", \\\"{x:1693,y:995,t:1527189249562};\\\", \\\"{x:1696,y:994,t:1527189249580};\\\", \\\"{x:1697,y:994,t:1527189249595};\\\", \\\"{x:1698,y:994,t:1527189249622};\\\", \\\"{x:1700,y:992,t:1527189249631};\\\", \\\"{x:1703,y:989,t:1527189249654};\\\", \\\"{x:1706,y:987,t:1527189249662};\\\", \\\"{x:1710,y:985,t:1527189249678};\\\", \\\"{x:1712,y:980,t:1527189249696};\\\", \\\"{x:1716,y:979,t:1527189249712};\\\", \\\"{x:1722,y:974,t:1527189249729};\\\", \\\"{x:1724,y:971,t:1527189249791};\\\", \\\"{x:1729,y:965,t:1527189249798};\\\", \\\"{x:1730,y:963,t:1527189249812};\\\", \\\"{x:1731,y:961,t:1527189249829};\\\", \\\"{x:1727,y:961,t:1527189249911};\\\", \\\"{x:1710,y:961,t:1527189249929};\\\", \\\"{x:1678,y:961,t:1527189249947};\\\", \\\"{x:1636,y:961,t:1527189249963};\\\", \\\"{x:1583,y:945,t:1527189249979};\\\", \\\"{x:1558,y:934,t:1527189249996};\\\", \\\"{x:1543,y:924,t:1527189250012};\\\", \\\"{x:1533,y:918,t:1527189250029};\\\", \\\"{x:1517,y:887,t:1527189250047};\\\", \\\"{x:1498,y:864,t:1527189250062};\\\", \\\"{x:1462,y:842,t:1527189250080};\\\", \\\"{x:1377,y:820,t:1527189250096};\\\", \\\"{x:1283,y:780,t:1527189250112};\\\", \\\"{x:1185,y:754,t:1527189250129};\\\", \\\"{x:1010,y:723,t:1527189250147};\\\", \\\"{x:824,y:689,t:1527189250164};\\\", \\\"{x:655,y:660,t:1527189250179};\\\", \\\"{x:516,y:641,t:1527189250196};\\\", \\\"{x:427,y:623,t:1527189250215};\\\", \\\"{x:384,y:611,t:1527189250229};\\\", \\\"{x:365,y:604,t:1527189250245};\\\", \\\"{x:364,y:603,t:1527189250264};\\\", \\\"{x:360,y:600,t:1527189250334};\\\", \\\"{x:357,y:595,t:1527189250347};\\\", \\\"{x:333,y:575,t:1527189250364};\\\", \\\"{x:307,y:558,t:1527189250381};\\\", \\\"{x:278,y:541,t:1527189250399};\\\", \\\"{x:262,y:536,t:1527189250414};\\\", \\\"{x:260,y:535,t:1527189250431};\\\", \\\"{x:260,y:534,t:1527189250477};\\\", \\\"{x:262,y:531,t:1527189250486};\\\", \\\"{x:267,y:522,t:1527189250498};\\\", \\\"{x:283,y:514,t:1527189250514};\\\", \\\"{x:334,y:496,t:1527189250530};\\\", \\\"{x:384,y:490,t:1527189250548};\\\", \\\"{x:432,y:490,t:1527189250565};\\\", \\\"{x:454,y:492,t:1527189250581};\\\", \\\"{x:478,y:507,t:1527189250598};\\\", \\\"{x:490,y:516,t:1527189250614};\\\", \\\"{x:500,y:519,t:1527189250631};\\\", \\\"{x:512,y:523,t:1527189250648};\\\", \\\"{x:515,y:524,t:1527189250665};\\\", \\\"{x:518,y:525,t:1527189250682};\\\", \\\"{x:521,y:528,t:1527189250710};\\\", \\\"{x:523,y:531,t:1527189250718};\\\", \\\"{x:527,y:535,t:1527189250731};\\\", \\\"{x:530,y:540,t:1527189250748};\\\", \\\"{x:532,y:540,t:1527189250765};\\\", \\\"{x:540,y:540,t:1527189250780};\\\", \\\"{x:554,y:537,t:1527189250798};\\\", \\\"{x:557,y:534,t:1527189250814};\\\", \\\"{x:562,y:531,t:1527189250831};\\\", \\\"{x:565,y:527,t:1527189250848};\\\", \\\"{x:566,y:526,t:1527189250865};\\\", \\\"{x:569,y:524,t:1527189250882};\\\", \\\"{x:570,y:523,t:1527189250898};\\\", \\\"{x:571,y:523,t:1527189250915};\\\", \\\"{x:573,y:522,t:1527189250930};\\\", \\\"{x:575,y:520,t:1527189250947};\\\", \\\"{x:578,y:517,t:1527189250965};\\\", \\\"{x:581,y:516,t:1527189250981};\\\", \\\"{x:584,y:514,t:1527189250997};\\\", \\\"{x:589,y:512,t:1527189251015};\\\", \\\"{x:599,y:508,t:1527189251032};\\\", \\\"{x:612,y:502,t:1527189251048};\\\", \\\"{x:627,y:497,t:1527189251065};\\\", \\\"{x:631,y:495,t:1527189251082};\\\", \\\"{x:630,y:495,t:1527189251318};\\\", \\\"{x:627,y:495,t:1527189251331};\\\", \\\"{x:625,y:496,t:1527189251349};\\\", \\\"{x:622,y:496,t:1527189251365};\\\", \\\"{x:622,y:497,t:1527189251398};\\\", \\\"{x:617,y:500,t:1527189251415};\\\", \\\"{x:607,y:503,t:1527189251432};\\\", \\\"{x:603,y:505,t:1527189251449};\\\", \\\"{x:600,y:506,t:1527189251466};\\\", \\\"{x:600,y:507,t:1527189251551};\\\", \\\"{x:595,y:512,t:1527189251566};\\\", \\\"{x:581,y:533,t:1527189251582};\\\", \\\"{x:562,y:562,t:1527189251599};\\\", \\\"{x:542,y:593,t:1527189251615};\\\", \\\"{x:535,y:618,t:1527189251632};\\\", \\\"{x:531,y:636,t:1527189251649};\\\", \\\"{x:530,y:650,t:1527189251665};\\\", \\\"{x:530,y:656,t:1527189251681};\\\", \\\"{x:531,y:661,t:1527189251699};\\\", \\\"{x:531,y:664,t:1527189251715};\\\", \\\"{x:531,y:667,t:1527189251731};\\\", \\\"{x:532,y:670,t:1527189251749};\\\", \\\"{x:532,y:676,t:1527189251764};\\\", \\\"{x:533,y:685,t:1527189251781};\\\", \\\"{x:533,y:691,t:1527189251799};\\\", \\\"{x:533,y:696,t:1527189251814};\\\", \\\"{x:533,y:700,t:1527189251832};\\\", \\\"{x:535,y:706,t:1527189251849};\\\", \\\"{x:535,y:719,t:1527189251866};\\\", \\\"{x:534,y:730,t:1527189251883};\\\", \\\"{x:532,y:738,t:1527189251899};\\\", \\\"{x:532,y:742,t:1527189251916};\\\", \\\"{x:530,y:746,t:1527189251932};\\\", \\\"{x:529,y:746,t:1527189251991};\\\", \\\"{x:529,y:745,t:1527189251999};\\\", \\\"{x:529,y:742,t:1527189252151};\\\", \\\"{x:529,y:740,t:1527189252166};\\\", \\\"{x:529,y:739,t:1527189252183};\\\", \\\"{x:529,y:736,t:1527189252199};\\\", \\\"{x:529,y:735,t:1527189252216};\\\", \\\"{x:531,y:732,t:1527189254986};\\\", \\\"{x:534,y:730,t:1527189254994};\\\", \\\"{x:535,y:730,t:1527189255004};\\\", \\\"{x:543,y:725,t:1527189255022};\\\", \\\"{x:546,y:725,t:1527189255038};\\\", \\\"{x:549,y:725,t:1527189255055};\\\", \\\"{x:551,y:725,t:1527189255072};\\\", \\\"{x:556,y:725,t:1527189255087};\\\", \\\"{x:563,y:725,t:1527189255105};\\\", \\\"{x:577,y:725,t:1527189255123};\\\", \\\"{x:586,y:725,t:1527189255138};\\\", \\\"{x:593,y:725,t:1527189255154};\\\", \\\"{x:595,y:725,t:1527189255171};\\\", \\\"{x:592,y:727,t:1527189255418};\\\", \\\"{x:582,y:728,t:1527189255426};\\\", \\\"{x:562,y:731,t:1527189255439};\\\", \\\"{x:542,y:734,t:1527189255454};\\\", \\\"{x:518,y:738,t:1527189255471};\\\", \\\"{x:511,y:739,t:1527189255489};\\\", \\\"{x:510,y:739,t:1527189255506};\\\", \\\"{x:506,y:739,t:1527189255562};\\\", \\\"{x:499,y:739,t:1527189255572};\\\", \\\"{x:489,y:739,t:1527189255589};\\\", \\\"{x:485,y:740,t:1527189255606};\\\", \\\"{x:485,y:738,t:1527189255795};\\\", \\\"{x:486,y:738,t:1527189255888};\\\", \\\"{x:488,y:738,t:1527189255912};\\\", \\\"{x:488,y:738,t:1527189255964};\\\" ] }, { \\\"rt\\\": 36462, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 820140, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:744,t:1527189258122};\\\", \\\"{x:490,y:752,t:1527189258129};\\\", \\\"{x:491,y:763,t:1527189258143};\\\", \\\"{x:491,y:782,t:1527189258158};\\\", \\\"{x:492,y:798,t:1527189258174};\\\", \\\"{x:496,y:815,t:1527189258190};\\\", \\\"{x:501,y:830,t:1527189258207};\\\", \\\"{x:505,y:837,t:1527189258224};\\\", \\\"{x:506,y:842,t:1527189258241};\\\", \\\"{x:506,y:844,t:1527189264211};\\\", \\\"{x:506,y:849,t:1527189264219};\\\", \\\"{x:511,y:859,t:1527189264236};\\\", \\\"{x:511,y:860,t:1527189264252};\\\", \\\"{x:513,y:861,t:1527189264906};\\\", \\\"{x:513,y:862,t:1527189264937};\\\", \\\"{x:517,y:862,t:1527189264977};\\\", \\\"{x:522,y:862,t:1527189264987};\\\", \\\"{x:530,y:857,t:1527189265003};\\\", \\\"{x:559,y:855,t:1527189265020};\\\", \\\"{x:589,y:855,t:1527189265037};\\\", \\\"{x:617,y:855,t:1527189265054};\\\", \\\"{x:649,y:855,t:1527189265070};\\\", \\\"{x:672,y:855,t:1527189265087};\\\", \\\"{x:683,y:855,t:1527189265104};\\\", \\\"{x:694,y:855,t:1527189265120};\\\", \\\"{x:697,y:855,t:1527189265137};\\\", \\\"{x:694,y:855,t:1527189267938};\\\", \\\"{x:684,y:859,t:1527189267946};\\\", \\\"{x:675,y:864,t:1527189267959};\\\", \\\"{x:662,y:869,t:1527189267975};\\\", \\\"{x:660,y:870,t:1527189267992};\\\", \\\"{x:659,y:870,t:1527189268451};\\\", \\\"{x:658,y:870,t:1527189268466};\\\", \\\"{x:659,y:870,t:1527189268546};\\\", \\\"{x:665,y:870,t:1527189268560};\\\", \\\"{x:684,y:870,t:1527189268576};\\\", \\\"{x:694,y:870,t:1527189268593};\\\", \\\"{x:697,y:871,t:1527189269161};\\\", \\\"{x:705,y:886,t:1527189269177};\\\", \\\"{x:708,y:889,t:1527189269194};\\\", \\\"{x:715,y:891,t:1527189269211};\\\", \\\"{x:720,y:891,t:1527189269228};\\\", \\\"{x:727,y:891,t:1527189269244};\\\", \\\"{x:730,y:888,t:1527189269261};\\\", \\\"{x:736,y:886,t:1527189269278};\\\", \\\"{x:738,y:885,t:1527189269294};\\\", \\\"{x:742,y:883,t:1527189269311};\\\", \\\"{x:745,y:881,t:1527189269328};\\\", \\\"{x:749,y:879,t:1527189269346};\\\", \\\"{x:755,y:877,t:1527189269361};\\\", \\\"{x:757,y:876,t:1527189269379};\\\", \\\"{x:759,y:875,t:1527189269395};\\\", \\\"{x:760,y:875,t:1527189269481};\\\", \\\"{x:759,y:875,t:1527189271258};\\\", \\\"{x:754,y:875,t:1527189271266};\\\", \\\"{x:753,y:875,t:1527189271281};\\\", \\\"{x:756,y:875,t:1527189271386};\\\", \\\"{x:759,y:873,t:1527189271399};\\\", \\\"{x:783,y:866,t:1527189271416};\\\", \\\"{x:822,y:860,t:1527189271433};\\\", \\\"{x:855,y:852,t:1527189271448};\\\", \\\"{x:886,y:847,t:1527189271465};\\\", \\\"{x:896,y:842,t:1527189271482};\\\", \\\"{x:900,y:838,t:1527189271498};\\\", \\\"{x:902,y:837,t:1527189271515};\\\", \\\"{x:903,y:837,t:1527189271546};\\\", \\\"{x:905,y:837,t:1527189271578};\\\", \\\"{x:908,y:837,t:1527189271585};\\\", \\\"{x:916,y:834,t:1527189271598};\\\", \\\"{x:936,y:829,t:1527189271616};\\\", \\\"{x:954,y:827,t:1527189271632};\\\", \\\"{x:979,y:820,t:1527189271650};\\\", \\\"{x:996,y:817,t:1527189271666};\\\", \\\"{x:1002,y:817,t:1527189271682};\\\", \\\"{x:1007,y:813,t:1527189271700};\\\", \\\"{x:1010,y:813,t:1527189271715};\\\", \\\"{x:1014,y:811,t:1527189271732};\\\", \\\"{x:1017,y:811,t:1527189271749};\\\", \\\"{x:1024,y:810,t:1527189271765};\\\", \\\"{x:1033,y:809,t:1527189271783};\\\", \\\"{x:1040,y:809,t:1527189271800};\\\", \\\"{x:1047,y:809,t:1527189271817};\\\", \\\"{x:1056,y:809,t:1527189271832};\\\", \\\"{x:1078,y:811,t:1527189271849};\\\", \\\"{x:1098,y:811,t:1527189271866};\\\", \\\"{x:1114,y:815,t:1527189271882};\\\", \\\"{x:1131,y:817,t:1527189271899};\\\", \\\"{x:1145,y:821,t:1527189271917};\\\", \\\"{x:1154,y:823,t:1527189271933};\\\", \\\"{x:1160,y:826,t:1527189271950};\\\", \\\"{x:1165,y:827,t:1527189271967};\\\", \\\"{x:1167,y:829,t:1527189271982};\\\", \\\"{x:1174,y:829,t:1527189271999};\\\", \\\"{x:1176,y:829,t:1527189272017};\\\", \\\"{x:1177,y:830,t:1527189272034};\\\", \\\"{x:1178,y:830,t:1527189272242};\\\", \\\"{x:1181,y:832,t:1527189272251};\\\", \\\"{x:1183,y:832,t:1527189272267};\\\", \\\"{x:1191,y:833,t:1527189272284};\\\", \\\"{x:1198,y:833,t:1527189272301};\\\", \\\"{x:1201,y:833,t:1527189272317};\\\", \\\"{x:1203,y:833,t:1527189272333};\\\", \\\"{x:1204,y:833,t:1527189272466};\\\", \\\"{x:1206,y:833,t:1527189272474};\\\", \\\"{x:1207,y:833,t:1527189272490};\\\", \\\"{x:1209,y:832,t:1527189272503};\\\", \\\"{x:1214,y:831,t:1527189272517};\\\", \\\"{x:1219,y:831,t:1527189272534};\\\", \\\"{x:1220,y:830,t:1527189272550};\\\", \\\"{x:1220,y:829,t:1527189272850};\\\", \\\"{x:1218,y:829,t:1527189272857};\\\", \\\"{x:1217,y:829,t:1527189272868};\\\", \\\"{x:1215,y:828,t:1527189272884};\\\", \\\"{x:1215,y:827,t:1527189284290};\\\", \\\"{x:1208,y:819,t:1527189284306};\\\", \\\"{x:1173,y:784,t:1527189284322};\\\", \\\"{x:1134,y:758,t:1527189284339};\\\", \\\"{x:1108,y:742,t:1527189284355};\\\", \\\"{x:1085,y:728,t:1527189284374};\\\", \\\"{x:1073,y:720,t:1527189284389};\\\", \\\"{x:1063,y:715,t:1527189284406};\\\", \\\"{x:1054,y:707,t:1527189284422};\\\", \\\"{x:1047,y:702,t:1527189284439};\\\", \\\"{x:1037,y:694,t:1527189284456};\\\", \\\"{x:1028,y:688,t:1527189284473};\\\", \\\"{x:1017,y:681,t:1527189284489};\\\", \\\"{x:999,y:669,t:1527189284505};\\\", \\\"{x:980,y:663,t:1527189284522};\\\", \\\"{x:961,y:657,t:1527189284539};\\\", \\\"{x:949,y:651,t:1527189284556};\\\", \\\"{x:940,y:647,t:1527189284574};\\\", \\\"{x:928,y:638,t:1527189284589};\\\", \\\"{x:913,y:635,t:1527189284606};\\\", \\\"{x:898,y:631,t:1527189284624};\\\", \\\"{x:880,y:631,t:1527189284639};\\\", \\\"{x:864,y:630,t:1527189284655};\\\", \\\"{x:843,y:627,t:1527189284680};\\\", \\\"{x:820,y:625,t:1527189284696};\\\", \\\"{x:775,y:618,t:1527189284712};\\\", \\\"{x:711,y:606,t:1527189284730};\\\", \\\"{x:666,y:605,t:1527189284745};\\\", \\\"{x:605,y:603,t:1527189284763};\\\", \\\"{x:562,y:603,t:1527189284779};\\\", \\\"{x:551,y:600,t:1527189284796};\\\", \\\"{x:548,y:599,t:1527189284813};\\\", \\\"{x:546,y:599,t:1527189284881};\\\", \\\"{x:528,y:598,t:1527189284897};\\\", \\\"{x:517,y:594,t:1527189284913};\\\", \\\"{x:513,y:590,t:1527189284931};\\\", \\\"{x:510,y:589,t:1527189284946};\\\", \\\"{x:509,y:587,t:1527189284962};\\\", \\\"{x:508,y:587,t:1527189284980};\\\", \\\"{x:501,y:585,t:1527189284995};\\\", \\\"{x:494,y:583,t:1527189285013};\\\", \\\"{x:482,y:582,t:1527189285030};\\\", \\\"{x:475,y:578,t:1527189285046};\\\", \\\"{x:461,y:573,t:1527189285063};\\\", \\\"{x:442,y:569,t:1527189285079};\\\", \\\"{x:424,y:562,t:1527189285097};\\\", \\\"{x:422,y:561,t:1527189285112};\\\", \\\"{x:419,y:558,t:1527189285130};\\\", \\\"{x:415,y:554,t:1527189285148};\\\", \\\"{x:414,y:549,t:1527189285163};\\\", \\\"{x:413,y:547,t:1527189285180};\\\", \\\"{x:413,y:541,t:1527189285196};\\\", \\\"{x:413,y:534,t:1527189285212};\\\", \\\"{x:413,y:530,t:1527189285230};\\\", \\\"{x:410,y:529,t:1527189285289};\\\", \\\"{x:401,y:529,t:1527189285296};\\\", \\\"{x:371,y:533,t:1527189285314};\\\", \\\"{x:318,y:541,t:1527189285330};\\\", \\\"{x:262,y:541,t:1527189285348};\\\", \\\"{x:239,y:539,t:1527189285364};\\\", \\\"{x:235,y:537,t:1527189285379};\\\", \\\"{x:233,y:537,t:1527189285513};\\\", \\\"{x:228,y:532,t:1527189285530};\\\", \\\"{x:223,y:524,t:1527189285547};\\\", \\\"{x:214,y:510,t:1527189285565};\\\", \\\"{x:195,y:488,t:1527189285580};\\\", \\\"{x:180,y:477,t:1527189285597};\\\", \\\"{x:164,y:469,t:1527189285613};\\\", \\\"{x:157,y:466,t:1527189285630};\\\", \\\"{x:156,y:466,t:1527189285646};\\\", \\\"{x:151,y:469,t:1527189285729};\\\", \\\"{x:142,y:484,t:1527189285747};\\\", \\\"{x:138,y:494,t:1527189285766};\\\", \\\"{x:138,y:495,t:1527189285781};\\\", \\\"{x:138,y:496,t:1527189285796};\\\", \\\"{x:141,y:498,t:1527189285813};\\\", \\\"{x:142,y:498,t:1527189285831};\\\", \\\"{x:143,y:498,t:1527189285865};\\\", \\\"{x:147,y:498,t:1527189285881};\\\", \\\"{x:150,y:499,t:1527189285896};\\\", \\\"{x:154,y:499,t:1527189285914};\\\", \\\"{x:158,y:502,t:1527189285930};\\\", \\\"{x:159,y:502,t:1527189285947};\\\", \\\"{x:160,y:504,t:1527189285977};\\\", \\\"{x:163,y:506,t:1527189286225};\\\", \\\"{x:172,y:512,t:1527189286233};\\\", \\\"{x:195,y:525,t:1527189286248};\\\", \\\"{x:239,y:551,t:1527189286264};\\\", \\\"{x:302,y:597,t:1527189286281};\\\", \\\"{x:331,y:628,t:1527189286299};\\\", \\\"{x:355,y:647,t:1527189286315};\\\", \\\"{x:365,y:654,t:1527189286331};\\\", \\\"{x:372,y:660,t:1527189286347};\\\", \\\"{x:382,y:665,t:1527189286364};\\\", \\\"{x:392,y:674,t:1527189286381};\\\", \\\"{x:404,y:685,t:1527189286397};\\\", \\\"{x:413,y:693,t:1527189286414};\\\", \\\"{x:415,y:697,t:1527189286430};\\\", \\\"{x:416,y:698,t:1527189286446};\\\", \\\"{x:417,y:700,t:1527189286497};\\\", \\\"{x:427,y:705,t:1527189286513};\\\", \\\"{x:432,y:707,t:1527189286530};\\\", \\\"{x:434,y:707,t:1527189286548};\\\", \\\"{x:435,y:708,t:1527189286564};\\\", \\\"{x:437,y:708,t:1527189286618};\\\", \\\"{x:441,y:709,t:1527189286633};\\\", \\\"{x:445,y:710,t:1527189286648};\\\", \\\"{x:456,y:713,t:1527189286663};\\\", \\\"{x:466,y:716,t:1527189286680};\\\", \\\"{x:484,y:725,t:1527189286698};\\\", \\\"{x:486,y:725,t:1527189286713};\\\", \\\"{x:488,y:725,t:1527189286731};\\\", \\\"{x:490,y:726,t:1527189286801};\\\", \\\"{x:490,y:727,t:1527189286814};\\\", \\\"{x:492,y:728,t:1527189286831};\\\" ] }, { \\\"rt\\\": 88352, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 909825, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -F -F -F -12 PM-12 PM-01 PM-01 PM-02 PM-02 PM-03 PM-04 PM-2-01 PM-05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:730,t:1527189296066};\\\", \\\"{x:496,y:731,t:1527189296081};\\\", \\\"{x:502,y:732,t:1527189298153};\\\", \\\"{x:510,y:734,t:1527189298161};\\\", \\\"{x:516,y:734,t:1527189298175};\\\", \\\"{x:530,y:734,t:1527189298190};\\\", \\\"{x:539,y:734,t:1527189298207};\\\", \\\"{x:559,y:735,t:1527189298225};\\\", \\\"{x:579,y:738,t:1527189298242};\\\", \\\"{x:615,y:748,t:1527189298257};\\\", \\\"{x:662,y:756,t:1527189298274};\\\", \\\"{x:685,y:763,t:1527189298288};\\\", \\\"{x:728,y:775,t:1527189298305};\\\", \\\"{x:743,y:777,t:1527189298322};\\\", \\\"{x:745,y:777,t:1527189298338};\\\", \\\"{x:745,y:778,t:1527189304944};\\\", \\\"{x:727,y:759,t:1527189304956};\\\", \\\"{x:690,y:718,t:1527189304973};\\\", \\\"{x:682,y:708,t:1527189304990};\\\", \\\"{x:674,y:699,t:1527189305007};\\\", \\\"{x:663,y:676,t:1527189305024};\\\", \\\"{x:643,y:646,t:1527189305040};\\\", \\\"{x:632,y:632,t:1527189305056};\\\", \\\"{x:627,y:622,t:1527189305074};\\\", \\\"{x:627,y:621,t:1527189305097};\\\", \\\"{x:627,y:620,t:1527189306144};\\\", \\\"{x:626,y:620,t:1527189306322};\\\", \\\"{x:626,y:619,t:1527189306330};\\\", \\\"{x:624,y:618,t:1527189306441};\\\", \\\"{x:622,y:618,t:1527189306457};\\\", \\\"{x:621,y:617,t:1527189306465};\\\", \\\"{x:620,y:615,t:1527189306481};\\\", \\\"{x:620,y:614,t:1527189306497};\\\", \\\"{x:618,y:614,t:1527189306522};\\\", \\\"{x:617,y:614,t:1527189306665};\\\", \\\"{x:613,y:614,t:1527189306681};\\\", \\\"{x:612,y:614,t:1527189306697};\\\", \\\"{x:610,y:614,t:1527189306714};\\\", \\\"{x:608,y:614,t:1527189306731};\\\", \\\"{x:606,y:614,t:1527189306747};\\\", \\\"{x:605,y:615,t:1527189306764};\\\", \\\"{x:603,y:616,t:1527189306781};\\\", \\\"{x:601,y:617,t:1527189306798};\\\", \\\"{x:599,y:617,t:1527189306814};\\\", \\\"{x:598,y:617,t:1527189306832};\\\", \\\"{x:597,y:618,t:1527189306848};\\\", \\\"{x:595,y:618,t:1527189306888};\\\", \\\"{x:593,y:619,t:1527189306912};\\\", \\\"{x:593,y:621,t:1527189307353};\\\", \\\"{x:595,y:629,t:1527189307365};\\\", \\\"{x:621,y:651,t:1527189307383};\\\", \\\"{x:645,y:672,t:1527189307397};\\\", \\\"{x:733,y:710,t:1527189307414};\\\", \\\"{x:813,y:744,t:1527189307432};\\\", \\\"{x:877,y:774,t:1527189307447};\\\", \\\"{x:930,y:794,t:1527189307464};\\\", \\\"{x:946,y:799,t:1527189307482};\\\", \\\"{x:949,y:800,t:1527189307497};\\\", \\\"{x:949,y:801,t:1527189307514};\\\", \\\"{x:952,y:801,t:1527189307531};\\\", \\\"{x:954,y:801,t:1527189307547};\\\", \\\"{x:956,y:801,t:1527189307564};\\\", \\\"{x:956,y:797,t:1527189307581};\\\", \\\"{x:956,y:796,t:1527189309450};\\\", \\\"{x:958,y:794,t:1527189311298};\\\", \\\"{x:963,y:790,t:1527189311305};\\\", \\\"{x:968,y:786,t:1527189311318};\\\", \\\"{x:978,y:777,t:1527189311335};\\\", \\\"{x:990,y:773,t:1527189311351};\\\", \\\"{x:996,y:769,t:1527189311369};\\\", \\\"{x:1003,y:768,t:1527189311385};\\\", \\\"{x:1012,y:764,t:1527189311402};\\\", \\\"{x:1024,y:760,t:1527189311419};\\\", \\\"{x:1049,y:753,t:1527189311435};\\\", \\\"{x:1069,y:748,t:1527189311452};\\\", \\\"{x:1095,y:741,t:1527189311469};\\\", \\\"{x:1119,y:736,t:1527189311485};\\\", \\\"{x:1139,y:735,t:1527189311501};\\\", \\\"{x:1156,y:735,t:1527189311519};\\\", \\\"{x:1170,y:734,t:1527189311535};\\\", \\\"{x:1178,y:732,t:1527189311553};\\\", \\\"{x:1186,y:731,t:1527189311568};\\\", \\\"{x:1204,y:727,t:1527189311585};\\\", \\\"{x:1218,y:726,t:1527189311601};\\\", \\\"{x:1238,y:726,t:1527189311618};\\\", \\\"{x:1260,y:726,t:1527189311635};\\\", \\\"{x:1276,y:726,t:1527189311652};\\\", \\\"{x:1294,y:726,t:1527189311668};\\\", \\\"{x:1299,y:726,t:1527189311685};\\\", \\\"{x:1301,y:726,t:1527189311703};\\\", \\\"{x:1302,y:725,t:1527189311738};\\\", \\\"{x:1303,y:725,t:1527189311752};\\\", \\\"{x:1307,y:723,t:1527189311769};\\\", \\\"{x:1308,y:722,t:1527189311793};\\\", \\\"{x:1313,y:720,t:1527189311810};\\\", \\\"{x:1315,y:718,t:1527189311819};\\\", \\\"{x:1320,y:711,t:1527189311836};\\\", \\\"{x:1324,y:709,t:1527189311852};\\\", \\\"{x:1326,y:707,t:1527189311869};\\\", \\\"{x:1327,y:707,t:1527189311885};\\\", \\\"{x:1327,y:706,t:1527189311913};\\\", \\\"{x:1329,y:704,t:1527189311930};\\\", \\\"{x:1330,y:704,t:1527189311937};\\\", \\\"{x:1333,y:704,t:1527189311952};\\\", \\\"{x:1338,y:702,t:1527189311969};\\\", \\\"{x:1340,y:701,t:1527189311986};\\\", \\\"{x:1341,y:701,t:1527189312002};\\\", \\\"{x:1342,y:700,t:1527189312019};\\\", \\\"{x:1343,y:699,t:1527189312060};\\\", \\\"{x:1344,y:699,t:1527189312085};\\\", \\\"{x:1345,y:697,t:1527189312102};\\\", \\\"{x:1345,y:701,t:1527189312762};\\\", \\\"{x:1346,y:702,t:1527189312769};\\\", \\\"{x:1348,y:706,t:1527189312787};\\\", \\\"{x:1348,y:710,t:1527189312802};\\\", \\\"{x:1348,y:711,t:1527189312819};\\\", \\\"{x:1348,y:712,t:1527189312836};\\\", \\\"{x:1348,y:715,t:1527189312857};\\\", \\\"{x:1348,y:716,t:1527189312869};\\\", \\\"{x:1348,y:720,t:1527189312887};\\\", \\\"{x:1347,y:725,t:1527189312903};\\\", \\\"{x:1347,y:729,t:1527189312919};\\\", \\\"{x:1347,y:730,t:1527189312945};\\\", \\\"{x:1346,y:730,t:1527189312986};\\\", \\\"{x:1345,y:733,t:1527189313004};\\\", \\\"{x:1344,y:736,t:1527189313020};\\\", \\\"{x:1343,y:739,t:1527189313036};\\\", \\\"{x:1343,y:740,t:1527189313053};\\\", \\\"{x:1342,y:742,t:1527189313070};\\\", \\\"{x:1342,y:744,t:1527189313087};\\\", \\\"{x:1342,y:746,t:1527189313104};\\\", \\\"{x:1341,y:747,t:1527189313119};\\\", \\\"{x:1341,y:750,t:1527189313137};\\\", \\\"{x:1341,y:752,t:1527189313154};\\\", \\\"{x:1341,y:753,t:1527189313178};\\\", \\\"{x:1340,y:753,t:1527189313186};\\\", \\\"{x:1340,y:754,t:1527189313258};\\\", \\\"{x:1339,y:756,t:1527189313282};\\\", \\\"{x:1340,y:753,t:1527189314197};\\\", \\\"{x:1341,y:750,t:1527189314207};\\\", \\\"{x:1342,y:748,t:1527189314223};\\\", \\\"{x:1343,y:745,t:1527189314241};\\\", \\\"{x:1343,y:744,t:1527189314257};\\\", \\\"{x:1345,y:743,t:1527189314275};\\\", \\\"{x:1345,y:742,t:1527189314291};\\\", \\\"{x:1345,y:741,t:1527189314308};\\\", \\\"{x:1345,y:738,t:1527189314324};\\\", \\\"{x:1347,y:730,t:1527189314341};\\\", \\\"{x:1347,y:726,t:1527189314358};\\\", \\\"{x:1347,y:724,t:1527189314374};\\\", \\\"{x:1347,y:721,t:1527189314391};\\\", \\\"{x:1347,y:720,t:1527189314420};\\\", \\\"{x:1347,y:719,t:1527189314428};\\\", \\\"{x:1347,y:717,t:1527189314441};\\\", \\\"{x:1348,y:714,t:1527189314458};\\\", \\\"{x:1348,y:712,t:1527189314474};\\\", \\\"{x:1349,y:710,t:1527189314491};\\\", \\\"{x:1349,y:708,t:1527189314507};\\\", \\\"{x:1349,y:707,t:1527189314597};\\\", \\\"{x:1349,y:704,t:1527189314608};\\\", \\\"{x:1350,y:702,t:1527189314625};\\\", \\\"{x:1350,y:700,t:1527189314710};\\\", \\\"{x:1350,y:698,t:1527189314724};\\\", \\\"{x:1350,y:695,t:1527189314741};\\\", \\\"{x:1350,y:694,t:1527189314765};\\\", \\\"{x:1350,y:693,t:1527189314868};\\\", \\\"{x:1350,y:691,t:1527189314877};\\\", \\\"{x:1349,y:690,t:1527189314891};\\\", \\\"{x:1349,y:689,t:1527189314932};\\\", \\\"{x:1348,y:689,t:1527189317860};\\\", \\\"{x:1347,y:699,t:1527189317877};\\\", \\\"{x:1345,y:709,t:1527189317894};\\\", \\\"{x:1344,y:714,t:1527189317910};\\\", \\\"{x:1344,y:717,t:1527189317927};\\\", \\\"{x:1344,y:720,t:1527189317989};\\\", \\\"{x:1344,y:721,t:1527189317996};\\\", \\\"{x:1344,y:723,t:1527189318010};\\\", \\\"{x:1343,y:726,t:1527189318026};\\\", \\\"{x:1342,y:731,t:1527189318043};\\\", \\\"{x:1342,y:732,t:1527189318093};\\\", \\\"{x:1342,y:734,t:1527189318111};\\\", \\\"{x:1342,y:735,t:1527189318127};\\\", \\\"{x:1342,y:739,t:1527189318144};\\\", \\\"{x:1342,y:741,t:1527189318161};\\\", \\\"{x:1342,y:745,t:1527189318177};\\\", \\\"{x:1342,y:749,t:1527189318194};\\\", \\\"{x:1342,y:755,t:1527189318211};\\\", \\\"{x:1342,y:767,t:1527189318227};\\\", \\\"{x:1341,y:785,t:1527189318244};\\\", \\\"{x:1341,y:811,t:1527189318260};\\\", \\\"{x:1341,y:823,t:1527189318277};\\\", \\\"{x:1340,y:833,t:1527189318294};\\\", \\\"{x:1339,y:839,t:1527189318311};\\\", \\\"{x:1336,y:852,t:1527189318327};\\\", \\\"{x:1334,y:866,t:1527189318344};\\\", \\\"{x:1332,y:881,t:1527189318362};\\\", \\\"{x:1331,y:896,t:1527189318377};\\\", \\\"{x:1331,y:914,t:1527189318394};\\\", \\\"{x:1336,y:927,t:1527189318411};\\\", \\\"{x:1338,y:941,t:1527189318427};\\\", \\\"{x:1342,y:957,t:1527189318444};\\\", \\\"{x:1343,y:981,t:1527189318461};\\\", \\\"{x:1344,y:995,t:1527189318478};\\\", \\\"{x:1347,y:1004,t:1527189318494};\\\", \\\"{x:1347,y:1008,t:1527189318511};\\\", \\\"{x:1347,y:1009,t:1527189318527};\\\", \\\"{x:1347,y:1005,t:1527189318685};\\\", \\\"{x:1347,y:1003,t:1527189318694};\\\", \\\"{x:1347,y:999,t:1527189318710};\\\", \\\"{x:1347,y:993,t:1527189318728};\\\", \\\"{x:1346,y:989,t:1527189318743};\\\", \\\"{x:1346,y:987,t:1527189318761};\\\", \\\"{x:1346,y:986,t:1527189318788};\\\", \\\"{x:1347,y:983,t:1527189318861};\\\", \\\"{x:1348,y:982,t:1527189318884};\\\", \\\"{x:1349,y:982,t:1527189318989};\\\", \\\"{x:1352,y:985,t:1527189318997};\\\", \\\"{x:1356,y:987,t:1527189319011};\\\", \\\"{x:1363,y:991,t:1527189319028};\\\", \\\"{x:1364,y:991,t:1527189319044};\\\", \\\"{x:1365,y:992,t:1527189319068};\\\", \\\"{x:1368,y:992,t:1527189319083};\\\", \\\"{x:1370,y:991,t:1527189319094};\\\", \\\"{x:1373,y:991,t:1527189319111};\\\", \\\"{x:1374,y:989,t:1527189319127};\\\", \\\"{x:1377,y:990,t:1527189319144};\\\", \\\"{x:1382,y:992,t:1527189319160};\\\", \\\"{x:1387,y:994,t:1527189319178};\\\", \\\"{x:1396,y:994,t:1527189319195};\\\", \\\"{x:1403,y:994,t:1527189319211};\\\", \\\"{x:1404,y:993,t:1527189319228};\\\", \\\"{x:1405,y:993,t:1527189319244};\\\", \\\"{x:1409,y:991,t:1527189319284};\\\", \\\"{x:1411,y:989,t:1527189319316};\\\", \\\"{x:1413,y:989,t:1527189319328};\\\", \\\"{x:1416,y:986,t:1527189319345};\\\", \\\"{x:1419,y:985,t:1527189319361};\\\", \\\"{x:1420,y:984,t:1527189319378};\\\", \\\"{x:1422,y:982,t:1527189319395};\\\", \\\"{x:1422,y:978,t:1527189319508};\\\", \\\"{x:1422,y:974,t:1527189319516};\\\", \\\"{x:1422,y:971,t:1527189319527};\\\", \\\"{x:1422,y:968,t:1527189319545};\\\", \\\"{x:1422,y:964,t:1527189319562};\\\", \\\"{x:1422,y:963,t:1527189319578};\\\", \\\"{x:1422,y:962,t:1527189319595};\\\", \\\"{x:1421,y:961,t:1527189319612};\\\", \\\"{x:1419,y:956,t:1527189319628};\\\", \\\"{x:1419,y:952,t:1527189319645};\\\", \\\"{x:1417,y:949,t:1527189319661};\\\", \\\"{x:1417,y:946,t:1527189319678};\\\", \\\"{x:1416,y:946,t:1527189319757};\\\", \\\"{x:1416,y:950,t:1527189319765};\\\", \\\"{x:1416,y:952,t:1527189319778};\\\", \\\"{x:1420,y:959,t:1527189319795};\\\", \\\"{x:1434,y:970,t:1527189319812};\\\", \\\"{x:1449,y:979,t:1527189319829};\\\", \\\"{x:1454,y:982,t:1527189319845};\\\", \\\"{x:1458,y:984,t:1527189319862};\\\", \\\"{x:1458,y:985,t:1527189319878};\\\", \\\"{x:1460,y:985,t:1527189319895};\\\", \\\"{x:1465,y:985,t:1527189319912};\\\", \\\"{x:1467,y:985,t:1527189319928};\\\", \\\"{x:1472,y:984,t:1527189319945};\\\", \\\"{x:1475,y:984,t:1527189319962};\\\", \\\"{x:1478,y:984,t:1527189319979};\\\", \\\"{x:1479,y:984,t:1527189319995};\\\", \\\"{x:1480,y:984,t:1527189320165};\\\", \\\"{x:1483,y:982,t:1527189320179};\\\", \\\"{x:1486,y:974,t:1527189320195};\\\", \\\"{x:1490,y:970,t:1527189320212};\\\", \\\"{x:1490,y:968,t:1527189320229};\\\", \\\"{x:1495,y:974,t:1527189320349};\\\", \\\"{x:1499,y:980,t:1527189320362};\\\", \\\"{x:1509,y:989,t:1527189320379};\\\", \\\"{x:1528,y:1000,t:1527189320396};\\\", \\\"{x:1536,y:1002,t:1527189320412};\\\", \\\"{x:1543,y:1004,t:1527189320429};\\\", \\\"{x:1550,y:1004,t:1527189320446};\\\", \\\"{x:1556,y:1002,t:1527189320462};\\\", \\\"{x:1558,y:1002,t:1527189320500};\\\", \\\"{x:1559,y:1002,t:1527189320533};\\\", \\\"{x:1561,y:1002,t:1527189320638};\\\", \\\"{x:1563,y:1000,t:1527189320677};\\\", \\\"{x:1565,y:997,t:1527189320684};\\\", \\\"{x:1566,y:996,t:1527189320696};\\\", \\\"{x:1567,y:993,t:1527189320712};\\\", \\\"{x:1568,y:990,t:1527189320729};\\\", \\\"{x:1570,y:988,t:1527189320746};\\\", \\\"{x:1570,y:987,t:1527189320788};\\\", \\\"{x:1570,y:986,t:1527189320820};\\\", \\\"{x:1570,y:983,t:1527189320829};\\\", \\\"{x:1570,y:979,t:1527189320846};\\\", \\\"{x:1568,y:976,t:1527189320864};\\\", \\\"{x:1568,y:975,t:1527189320879};\\\", \\\"{x:1568,y:972,t:1527189320896};\\\", \\\"{x:1568,y:969,t:1527189320913};\\\", \\\"{x:1568,y:967,t:1527189320929};\\\", \\\"{x:1568,y:963,t:1527189320947};\\\", \\\"{x:1568,y:962,t:1527189320963};\\\", \\\"{x:1567,y:960,t:1527189320979};\\\", \\\"{x:1567,y:959,t:1527189321092};\\\", \\\"{x:1570,y:961,t:1527189321100};\\\", \\\"{x:1571,y:963,t:1527189321114};\\\", \\\"{x:1575,y:966,t:1527189321130};\\\", \\\"{x:1581,y:968,t:1527189321146};\\\", \\\"{x:1590,y:972,t:1527189321164};\\\", \\\"{x:1595,y:974,t:1527189321180};\\\", \\\"{x:1597,y:975,t:1527189321196};\\\", \\\"{x:1598,y:975,t:1527189321213};\\\", \\\"{x:1600,y:975,t:1527189321229};\\\", \\\"{x:1601,y:975,t:1527189321246};\\\", \\\"{x:1604,y:975,t:1527189321263};\\\", \\\"{x:1606,y:974,t:1527189321280};\\\", \\\"{x:1608,y:974,t:1527189321296};\\\", \\\"{x:1611,y:971,t:1527189321313};\\\", \\\"{x:1613,y:970,t:1527189321330};\\\", \\\"{x:1616,y:968,t:1527189321346};\\\", \\\"{x:1618,y:966,t:1527189321363};\\\", \\\"{x:1620,y:965,t:1527189321381};\\\", \\\"{x:1620,y:964,t:1527189321725};\\\", \\\"{x:1620,y:963,t:1527189321740};\\\", \\\"{x:1618,y:963,t:1527189324205};\\\", \\\"{x:1615,y:960,t:1527189324216};\\\", \\\"{x:1613,y:957,t:1527189324233};\\\", \\\"{x:1611,y:957,t:1527189324249};\\\", \\\"{x:1609,y:956,t:1527189343197};\\\", \\\"{x:1550,y:921,t:1527189343214};\\\", \\\"{x:1521,y:905,t:1527189343230};\\\", \\\"{x:1487,y:893,t:1527189343247};\\\", \\\"{x:1408,y:874,t:1527189343264};\\\", \\\"{x:1332,y:862,t:1527189343280};\\\", \\\"{x:1254,y:849,t:1527189343298};\\\", \\\"{x:1184,y:829,t:1527189343314};\\\", \\\"{x:1132,y:817,t:1527189343331};\\\", \\\"{x:1101,y:809,t:1527189343347};\\\", \\\"{x:1086,y:801,t:1527189343365};\\\", \\\"{x:1070,y:793,t:1527189343380};\\\", \\\"{x:1034,y:783,t:1527189343397};\\\", \\\"{x:1006,y:774,t:1527189343414};\\\", \\\"{x:930,y:766,t:1527189343431};\\\", \\\"{x:861,y:757,t:1527189343447};\\\", \\\"{x:809,y:754,t:1527189343463};\\\", \\\"{x:740,y:754,t:1527189343481};\\\", \\\"{x:678,y:755,t:1527189343497};\\\", \\\"{x:614,y:755,t:1527189343514};\\\", \\\"{x:590,y:754,t:1527189343531};\\\", \\\"{x:582,y:750,t:1527189343547};\\\", \\\"{x:582,y:749,t:1527189343564};\\\", \\\"{x:582,y:740,t:1527189343580};\\\", \\\"{x:581,y:731,t:1527189343597};\\\", \\\"{x:578,y:722,t:1527189343614};\\\", \\\"{x:574,y:712,t:1527189343631};\\\", \\\"{x:572,y:703,t:1527189343647};\\\", \\\"{x:569,y:691,t:1527189343664};\\\", \\\"{x:569,y:680,t:1527189343682};\\\", \\\"{x:568,y:665,t:1527189343696};\\\", \\\"{x:568,y:651,t:1527189343714};\\\", \\\"{x:568,y:641,t:1527189343731};\\\", \\\"{x:568,y:623,t:1527189343749};\\\", \\\"{x:568,y:615,t:1527189343763};\\\", \\\"{x:568,y:609,t:1527189343780};\\\", \\\"{x:568,y:604,t:1527189343797};\\\", \\\"{x:569,y:600,t:1527189343815};\\\", \\\"{x:570,y:596,t:1527189343831};\\\", \\\"{x:577,y:584,t:1527189343848};\\\", \\\"{x:583,y:574,t:1527189343864};\\\", \\\"{x:589,y:566,t:1527189343882};\\\", \\\"{x:591,y:563,t:1527189343898};\\\", \\\"{x:594,y:563,t:1527189343931};\\\", \\\"{x:598,y:566,t:1527189343949};\\\", \\\"{x:601,y:568,t:1527189343965};\\\", \\\"{x:604,y:568,t:1527189343981};\\\", \\\"{x:605,y:569,t:1527189344085};\\\", \\\"{x:605,y:570,t:1527189344099};\\\", \\\"{x:605,y:573,t:1527189344115};\\\", \\\"{x:610,y:582,t:1527189344291};\\\", \\\"{x:625,y:590,t:1527189344299};\\\", \\\"{x:673,y:632,t:1527189344315};\\\", \\\"{x:739,y:691,t:1527189344331};\\\", \\\"{x:779,y:732,t:1527189344348};\\\", \\\"{x:830,y:769,t:1527189344366};\\\", \\\"{x:892,y:790,t:1527189344382};\\\", \\\"{x:936,y:800,t:1527189344398};\\\", \\\"{x:995,y:808,t:1527189344416};\\\", \\\"{x:1052,y:821,t:1527189344433};\\\", \\\"{x:1092,y:827,t:1527189344449};\\\", \\\"{x:1117,y:835,t:1527189344466};\\\", \\\"{x:1129,y:841,t:1527189344483};\\\", \\\"{x:1131,y:842,t:1527189344499};\\\", \\\"{x:1137,y:847,t:1527189344572};\\\", \\\"{x:1150,y:853,t:1527189344583};\\\", \\\"{x:1181,y:872,t:1527189344600};\\\", \\\"{x:1227,y:900,t:1527189344616};\\\", \\\"{x:1256,y:925,t:1527189344633};\\\", \\\"{x:1276,y:941,t:1527189344650};\\\", \\\"{x:1289,y:944,t:1527189344666};\\\", \\\"{x:1295,y:947,t:1527189344683};\\\", \\\"{x:1305,y:949,t:1527189344701};\\\", \\\"{x:1319,y:954,t:1527189344717};\\\", \\\"{x:1341,y:962,t:1527189344733};\\\", \\\"{x:1369,y:970,t:1527189344750};\\\", \\\"{x:1388,y:975,t:1527189344766};\\\", \\\"{x:1407,y:976,t:1527189344783};\\\", \\\"{x:1410,y:977,t:1527189344800};\\\", \\\"{x:1411,y:977,t:1527189344816};\\\", \\\"{x:1413,y:977,t:1527189344833};\\\", \\\"{x:1414,y:976,t:1527189344849};\\\", \\\"{x:1417,y:974,t:1527189344867};\\\", \\\"{x:1421,y:974,t:1527189344883};\\\", \\\"{x:1426,y:970,t:1527189344900};\\\", \\\"{x:1443,y:966,t:1527189344917};\\\", \\\"{x:1460,y:962,t:1527189344934};\\\", \\\"{x:1470,y:955,t:1527189344951};\\\", \\\"{x:1473,y:952,t:1527189344968};\\\", \\\"{x:1473,y:951,t:1527189344983};\\\", \\\"{x:1478,y:951,t:1527189345028};\\\", \\\"{x:1488,y:951,t:1527189345038};\\\", \\\"{x:1492,y:951,t:1527189345050};\\\", \\\"{x:1514,y:950,t:1527189345067};\\\", \\\"{x:1562,y:950,t:1527189345084};\\\", \\\"{x:1623,y:956,t:1527189345100};\\\", \\\"{x:1662,y:968,t:1527189345117};\\\", \\\"{x:1676,y:973,t:1527189345134};\\\", \\\"{x:1676,y:974,t:1527189345151};\\\", \\\"{x:1675,y:974,t:1527189345286};\\\", \\\"{x:1667,y:970,t:1527189345301};\\\", \\\"{x:1646,y:967,t:1527189345318};\\\", \\\"{x:1623,y:963,t:1527189345334};\\\", \\\"{x:1592,y:963,t:1527189345351};\\\", \\\"{x:1576,y:962,t:1527189345368};\\\", \\\"{x:1573,y:962,t:1527189345384};\\\", \\\"{x:1572,y:961,t:1527189345436};\\\", \\\"{x:1572,y:960,t:1527189345450};\\\", \\\"{x:1572,y:957,t:1527189345468};\\\", \\\"{x:1576,y:957,t:1527189345491};\\\", \\\"{x:1581,y:958,t:1527189345500};\\\", \\\"{x:1584,y:961,t:1527189345518};\\\", \\\"{x:1589,y:965,t:1527189345534};\\\", \\\"{x:1599,y:972,t:1527189345551};\\\", \\\"{x:1608,y:974,t:1527189345567};\\\", \\\"{x:1622,y:974,t:1527189345583};\\\", \\\"{x:1631,y:972,t:1527189345601};\\\", \\\"{x:1633,y:971,t:1527189345618};\\\", \\\"{x:1634,y:970,t:1527189345635};\\\", \\\"{x:1634,y:969,t:1527189345700};\\\", \\\"{x:1632,y:968,t:1527189345719};\\\", \\\"{x:1631,y:967,t:1527189345735};\\\", \\\"{x:1628,y:966,t:1527189345752};\\\", \\\"{x:1626,y:964,t:1527189345768};\\\", \\\"{x:1624,y:962,t:1527189345786};\\\", \\\"{x:1622,y:962,t:1527189345801};\\\", \\\"{x:1620,y:962,t:1527189345818};\\\", \\\"{x:1619,y:962,t:1527189345838};\\\", \\\"{x:1618,y:962,t:1527189345852};\\\", \\\"{x:1613,y:962,t:1527189345868};\\\", \\\"{x:1608,y:962,t:1527189345885};\\\", \\\"{x:1606,y:962,t:1527189345902};\\\", \\\"{x:1609,y:962,t:1527189346404};\\\", \\\"{x:1611,y:962,t:1527189346419};\\\", \\\"{x:1613,y:962,t:1527189346437};\\\", \\\"{x:1596,y:953,t:1527189383047};\\\", \\\"{x:1523,y:917,t:1527189383054};\\\", \\\"{x:1421,y:894,t:1527189383067};\\\", \\\"{x:1199,y:850,t:1527189383085};\\\", \\\"{x:1028,y:803,t:1527189383101};\\\", \\\"{x:901,y:771,t:1527189383117};\\\", \\\"{x:797,y:755,t:1527189383134};\\\", \\\"{x:780,y:752,t:1527189383151};\\\", \\\"{x:779,y:752,t:1527189383167};\\\", \\\"{x:777,y:752,t:1527189383247};\\\", \\\"{x:772,y:754,t:1527189383255};\\\", \\\"{x:747,y:764,t:1527189383267};\\\", \\\"{x:664,y:774,t:1527189383285};\\\", \\\"{x:600,y:774,t:1527189383302};\\\", \\\"{x:577,y:773,t:1527189383318};\\\", \\\"{x:573,y:772,t:1527189383335};\\\", \\\"{x:573,y:771,t:1527189383375};\\\", \\\"{x:566,y:769,t:1527189383385};\\\", \\\"{x:542,y:768,t:1527189383403};\\\", \\\"{x:517,y:768,t:1527189383419};\\\", \\\"{x:482,y:765,t:1527189383435};\\\", \\\"{x:466,y:754,t:1527189383453};\\\", \\\"{x:457,y:747,t:1527189383468};\\\", \\\"{x:455,y:743,t:1527189383484};\\\", \\\"{x:454,y:741,t:1527189383500};\\\" ] }, { \\\"rt\\\": 9806, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 921193, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:454,y:748,t:1527189386215};\\\", \\\"{x:454,y:755,t:1527189386224};\\\", \\\"{x:455,y:763,t:1527189386236};\\\", \\\"{x:458,y:777,t:1527189386252};\\\", \\\"{x:461,y:787,t:1527189386269};\\\", \\\"{x:465,y:798,t:1527189386286};\\\", \\\"{x:469,y:810,t:1527189386302};\\\", \\\"{x:470,y:812,t:1527189386319};\\\", \\\"{x:470,y:814,t:1527189386336};\\\", \\\"{x:471,y:815,t:1527189386353};\\\", \\\"{x:471,y:816,t:1527189387646};\\\", \\\"{x:473,y:817,t:1527189387991};\\\", \\\"{x:475,y:817,t:1527189388005};\\\", \\\"{x:477,y:817,t:1527189388020};\\\", \\\"{x:488,y:816,t:1527189388037};\\\", \\\"{x:509,y:816,t:1527189388054};\\\", \\\"{x:540,y:816,t:1527189388070};\\\", \\\"{x:643,y:816,t:1527189388088};\\\", \\\"{x:741,y:821,t:1527189388104};\\\", \\\"{x:843,y:829,t:1527189388120};\\\", \\\"{x:904,y:835,t:1527189388137};\\\", \\\"{x:942,y:838,t:1527189388154};\\\", \\\"{x:967,y:842,t:1527189388170};\\\", \\\"{x:980,y:845,t:1527189388187};\\\", \\\"{x:985,y:846,t:1527189388205};\\\", \\\"{x:991,y:847,t:1527189388221};\\\", \\\"{x:999,y:849,t:1527189388238};\\\", \\\"{x:1009,y:851,t:1527189388254};\\\", \\\"{x:1023,y:855,t:1527189388270};\\\", \\\"{x:1045,y:860,t:1527189388287};\\\", \\\"{x:1069,y:866,t:1527189388304};\\\", \\\"{x:1083,y:868,t:1527189388320};\\\", \\\"{x:1091,y:871,t:1527189388338};\\\", \\\"{x:1096,y:873,t:1527189388354};\\\", \\\"{x:1101,y:876,t:1527189388371};\\\", \\\"{x:1112,y:885,t:1527189388387};\\\", \\\"{x:1120,y:891,t:1527189388405};\\\", \\\"{x:1135,y:900,t:1527189388420};\\\", \\\"{x:1154,y:913,t:1527189388438};\\\", \\\"{x:1173,y:927,t:1527189388454};\\\", \\\"{x:1201,y:937,t:1527189388471};\\\", \\\"{x:1209,y:938,t:1527189388488};\\\", \\\"{x:1219,y:939,t:1527189388505};\\\", \\\"{x:1227,y:940,t:1527189388522};\\\", \\\"{x:1239,y:942,t:1527189388537};\\\", \\\"{x:1261,y:946,t:1527189388554};\\\", \\\"{x:1276,y:951,t:1527189388572};\\\", \\\"{x:1294,y:953,t:1527189388587};\\\", \\\"{x:1308,y:953,t:1527189388605};\\\", \\\"{x:1310,y:953,t:1527189388622};\\\", \\\"{x:1311,y:953,t:1527189388637};\\\", \\\"{x:1312,y:953,t:1527189388655};\\\", \\\"{x:1314,y:953,t:1527189388671};\\\", \\\"{x:1330,y:959,t:1527189388687};\\\", \\\"{x:1345,y:965,t:1527189388704};\\\", \\\"{x:1358,y:969,t:1527189388721};\\\", \\\"{x:1361,y:969,t:1527189388738};\\\", \\\"{x:1362,y:969,t:1527189388783};\\\", \\\"{x:1362,y:967,t:1527189388849};\\\", \\\"{x:1361,y:966,t:1527189388863};\\\", \\\"{x:1358,y:965,t:1527189388871};\\\", \\\"{x:1351,y:961,t:1527189388887};\\\", \\\"{x:1349,y:960,t:1527189388905};\\\", \\\"{x:1349,y:959,t:1527189388927};\\\", \\\"{x:1337,y:951,t:1527189390047};\\\", \\\"{x:1307,y:909,t:1527189390055};\\\", \\\"{x:1262,y:879,t:1527189390071};\\\", \\\"{x:1212,y:858,t:1527189390088};\\\", \\\"{x:1144,y:829,t:1527189390105};\\\", \\\"{x:1058,y:806,t:1527189390122};\\\", \\\"{x:1017,y:792,t:1527189390138};\\\", \\\"{x:999,y:787,t:1527189390154};\\\", \\\"{x:987,y:774,t:1527189390172};\\\", \\\"{x:975,y:755,t:1527189390189};\\\", \\\"{x:963,y:737,t:1527189390204};\\\", \\\"{x:941,y:714,t:1527189390221};\\\", \\\"{x:922,y:697,t:1527189390238};\\\", \\\"{x:895,y:675,t:1527189390255};\\\", \\\"{x:878,y:663,t:1527189390272};\\\", \\\"{x:854,y:647,t:1527189390289};\\\", \\\"{x:804,y:624,t:1527189390306};\\\", \\\"{x:768,y:611,t:1527189390320};\\\", \\\"{x:745,y:604,t:1527189390337};\\\", \\\"{x:736,y:599,t:1527189390358};\\\", \\\"{x:730,y:595,t:1527189390374};\\\", \\\"{x:721,y:592,t:1527189390390};\\\", \\\"{x:701,y:587,t:1527189390407};\\\", \\\"{x:675,y:583,t:1527189390423};\\\", \\\"{x:649,y:575,t:1527189390440};\\\", \\\"{x:618,y:572,t:1527189390457};\\\", \\\"{x:591,y:568,t:1527189390474};\\\", \\\"{x:568,y:563,t:1527189390490};\\\", \\\"{x:547,y:562,t:1527189390507};\\\", \\\"{x:527,y:562,t:1527189390524};\\\", \\\"{x:501,y:562,t:1527189390540};\\\", \\\"{x:474,y:562,t:1527189390557};\\\", \\\"{x:456,y:557,t:1527189390573};\\\", \\\"{x:440,y:553,t:1527189390591};\\\", \\\"{x:414,y:551,t:1527189390607};\\\", \\\"{x:398,y:550,t:1527189390624};\\\", \\\"{x:382,y:548,t:1527189390640};\\\", \\\"{x:365,y:547,t:1527189390658};\\\", \\\"{x:349,y:545,t:1527189390674};\\\", \\\"{x:334,y:545,t:1527189390690};\\\", \\\"{x:313,y:545,t:1527189390707};\\\", \\\"{x:289,y:545,t:1527189390724};\\\", \\\"{x:275,y:545,t:1527189390740};\\\", \\\"{x:258,y:545,t:1527189390758};\\\", \\\"{x:252,y:545,t:1527189390774};\\\", \\\"{x:245,y:548,t:1527189390789};\\\", \\\"{x:234,y:552,t:1527189390807};\\\", \\\"{x:223,y:555,t:1527189390823};\\\", \\\"{x:217,y:556,t:1527189390841};\\\", \\\"{x:214,y:556,t:1527189390857};\\\", \\\"{x:213,y:556,t:1527189390894};\\\", \\\"{x:209,y:556,t:1527189390926};\\\", \\\"{x:201,y:556,t:1527189390940};\\\", \\\"{x:180,y:556,t:1527189390957};\\\", \\\"{x:161,y:554,t:1527189390975};\\\", \\\"{x:159,y:554,t:1527189390990};\\\", \\\"{x:158,y:552,t:1527189391031};\\\", \\\"{x:158,y:551,t:1527189391048};\\\", \\\"{x:158,y:550,t:1527189391057};\\\", \\\"{x:158,y:549,t:1527189391074};\\\", \\\"{x:158,y:548,t:1527189391134};\\\", \\\"{x:158,y:545,t:1527189391150};\\\", \\\"{x:158,y:542,t:1527189391158};\\\", \\\"{x:158,y:534,t:1527189391174};\\\", \\\"{x:158,y:529,t:1527189391191};\\\", \\\"{x:158,y:527,t:1527189391215};\\\", \\\"{x:158,y:528,t:1527189391360};\\\", \\\"{x:155,y:530,t:1527189391374};\\\", \\\"{x:154,y:531,t:1527189391406};\\\", \\\"{x:153,y:531,t:1527189391438};\\\", \\\"{x:152,y:533,t:1527189391446};\\\", \\\"{x:153,y:533,t:1527189391870};\\\", \\\"{x:171,y:534,t:1527189391878};\\\", \\\"{x:183,y:536,t:1527189391891};\\\", \\\"{x:213,y:540,t:1527189391908};\\\", \\\"{x:269,y:546,t:1527189391925};\\\", \\\"{x:307,y:555,t:1527189391942};\\\", \\\"{x:337,y:555,t:1527189391958};\\\", \\\"{x:355,y:555,t:1527189391974};\\\", \\\"{x:365,y:555,t:1527189391991};\\\", \\\"{x:377,y:555,t:1527189392008};\\\", \\\"{x:403,y:555,t:1527189392025};\\\", \\\"{x:424,y:555,t:1527189392041};\\\", \\\"{x:463,y:552,t:1527189392058};\\\", \\\"{x:512,y:550,t:1527189392076};\\\", \\\"{x:561,y:546,t:1527189392091};\\\", \\\"{x:581,y:545,t:1527189392108};\\\", \\\"{x:591,y:544,t:1527189392124};\\\", \\\"{x:596,y:544,t:1527189392141};\\\", \\\"{x:602,y:544,t:1527189392159};\\\", \\\"{x:605,y:541,t:1527189392174};\\\", \\\"{x:608,y:541,t:1527189392191};\\\", \\\"{x:620,y:540,t:1527189392208};\\\", \\\"{x:635,y:540,t:1527189392226};\\\", \\\"{x:670,y:537,t:1527189392243};\\\", \\\"{x:704,y:536,t:1527189392258};\\\", \\\"{x:724,y:533,t:1527189392275};\\\", \\\"{x:734,y:533,t:1527189392292};\\\", \\\"{x:735,y:533,t:1527189392308};\\\", \\\"{x:736,y:533,t:1527189392383};\\\", \\\"{x:737,y:533,t:1527189392398};\\\", \\\"{x:740,y:531,t:1527189392407};\\\", \\\"{x:742,y:530,t:1527189392425};\\\", \\\"{x:747,y:528,t:1527189392442};\\\", \\\"{x:750,y:527,t:1527189392458};\\\", \\\"{x:752,y:525,t:1527189392475};\\\", \\\"{x:754,y:523,t:1527189392493};\\\", \\\"{x:759,y:521,t:1527189392508};\\\", \\\"{x:764,y:520,t:1527189392525};\\\", \\\"{x:773,y:519,t:1527189392543};\\\", \\\"{x:776,y:519,t:1527189392558};\\\", \\\"{x:777,y:518,t:1527189392575};\\\", \\\"{x:778,y:517,t:1527189392594};\\\", \\\"{x:779,y:517,t:1527189392614};\\\", \\\"{x:784,y:515,t:1527189392625};\\\", \\\"{x:801,y:512,t:1527189392642};\\\", \\\"{x:812,y:507,t:1527189392658};\\\", \\\"{x:821,y:506,t:1527189392675};\\\", \\\"{x:825,y:505,t:1527189392692};\\\", \\\"{x:819,y:509,t:1527189392999};\\\", \\\"{x:798,y:522,t:1527189393009};\\\", \\\"{x:729,y:565,t:1527189393026};\\\", \\\"{x:653,y:603,t:1527189393043};\\\", \\\"{x:581,y:634,t:1527189393060};\\\", \\\"{x:549,y:648,t:1527189393076};\\\", \\\"{x:535,y:657,t:1527189393092};\\\", \\\"{x:532,y:658,t:1527189393109};\\\", \\\"{x:525,y:664,t:1527189393126};\\\", \\\"{x:521,y:667,t:1527189393142};\\\", \\\"{x:515,y:670,t:1527189393159};\\\", \\\"{x:514,y:671,t:1527189393177};\\\", \\\"{x:513,y:671,t:1527189393239};\\\", \\\"{x:512,y:674,t:1527189393246};\\\", \\\"{x:511,y:679,t:1527189393260};\\\", \\\"{x:510,y:689,t:1527189393277};\\\", \\\"{x:507,y:697,t:1527189393292};\\\", \\\"{x:507,y:702,t:1527189393310};\\\", \\\"{x:507,y:707,t:1527189393327};\\\", \\\"{x:508,y:708,t:1527189393343};\\\", \\\"{x:510,y:711,t:1527189393360};\\\", \\\"{x:514,y:717,t:1527189393376};\\\", \\\"{x:515,y:723,t:1527189393393};\\\", \\\"{x:518,y:728,t:1527189393410};\\\", \\\"{x:520,y:732,t:1527189393426};\\\", \\\"{x:520,y:733,t:1527189393443};\\\", \\\"{x:521,y:734,t:1527189393459};\\\", \\\"{x:529,y:729,t:1527189393551};\\\", \\\"{x:540,y:724,t:1527189393560};\\\", \\\"{x:626,y:695,t:1527189393577};\\\", \\\"{x:701,y:659,t:1527189393593};\\\", \\\"{x:754,y:627,t:1527189393609};\\\", \\\"{x:798,y:595,t:1527189393626};\\\", \\\"{x:808,y:585,t:1527189393643};\\\", \\\"{x:810,y:579,t:1527189393658};\\\", \\\"{x:810,y:576,t:1527189393676};\\\", \\\"{x:809,y:570,t:1527189393693};\\\", \\\"{x:808,y:568,t:1527189393709};\\\", \\\"{x:804,y:560,t:1527189393727};\\\", \\\"{x:803,y:558,t:1527189393782};\\\", \\\"{x:803,y:556,t:1527189393793};\\\", \\\"{x:801,y:554,t:1527189393810};\\\", \\\"{x:800,y:552,t:1527189393838};\\\", \\\"{x:799,y:548,t:1527189393854};\\\", \\\"{x:799,y:547,t:1527189393862};\\\", \\\"{x:799,y:544,t:1527189393876};\\\", \\\"{x:802,y:540,t:1527189393893};\\\", \\\"{x:806,y:535,t:1527189393909};\\\", \\\"{x:811,y:528,t:1527189393926};\\\", \\\"{x:815,y:525,t:1527189393943};\\\", \\\"{x:817,y:522,t:1527189393960};\\\", \\\"{x:820,y:520,t:1527189393975};\\\", \\\"{x:825,y:514,t:1527189393994};\\\", \\\"{x:830,y:509,t:1527189394010};\\\", \\\"{x:833,y:506,t:1527189394025};\\\", \\\"{x:825,y:512,t:1527189394302};\\\", \\\"{x:814,y:528,t:1527189394310};\\\", \\\"{x:790,y:553,t:1527189394327};\\\", \\\"{x:766,y:575,t:1527189394344};\\\", \\\"{x:745,y:595,t:1527189394360};\\\", \\\"{x:735,y:602,t:1527189394378};\\\", \\\"{x:729,y:606,t:1527189394393};\\\", \\\"{x:728,y:607,t:1527189394410};\\\", \\\"{x:722,y:610,t:1527189394427};\\\", \\\"{x:710,y:620,t:1527189394442};\\\", \\\"{x:690,y:631,t:1527189394460};\\\", \\\"{x:672,y:639,t:1527189394478};\\\", \\\"{x:665,y:642,t:1527189394493};\\\", \\\"{x:662,y:646,t:1527189394542};\\\", \\\"{x:658,y:647,t:1527189394560};\\\", \\\"{x:656,y:649,t:1527189394577};\\\", \\\"{x:651,y:650,t:1527189394594};\\\", \\\"{x:642,y:653,t:1527189394611};\\\", \\\"{x:639,y:654,t:1527189394628};\\\", \\\"{x:635,y:656,t:1527189394644};\\\", \\\"{x:629,y:661,t:1527189394661};\\\", \\\"{x:618,y:673,t:1527189394678};\\\", \\\"{x:608,y:682,t:1527189394694};\\\", \\\"{x:593,y:693,t:1527189394711};\\\", \\\"{x:575,y:704,t:1527189394727};\\\", \\\"{x:567,y:709,t:1527189394744};\\\", \\\"{x:562,y:712,t:1527189394761};\\\", \\\"{x:557,y:715,t:1527189394778};\\\", \\\"{x:553,y:719,t:1527189394794};\\\", \\\"{x:549,y:723,t:1527189394811};\\\", \\\"{x:545,y:726,t:1527189394827};\\\", \\\"{x:538,y:729,t:1527189394844};\\\", \\\"{x:528,y:738,t:1527189394860};\\\", \\\"{x:519,y:743,t:1527189394877};\\\", \\\"{x:514,y:745,t:1527189394894};\\\", \\\"{x:515,y:745,t:1527189394977};\\\", \\\"{x:519,y:745,t:1527189394994};\\\", \\\"{x:520,y:745,t:1527189395010};\\\", \\\"{x:520,y:745,t:1527189395071};\\\" ] }, { \\\"rt\\\": 8171, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 930580, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:745,t:1527189397006};\\\", \\\"{x:522,y:745,t:1527189397014};\\\", \\\"{x:529,y:745,t:1527189397029};\\\", \\\"{x:538,y:745,t:1527189397046};\\\", \\\"{x:538,y:746,t:1527189397063};\\\", \\\"{x:539,y:746,t:1527189397094};\\\", \\\"{x:540,y:746,t:1527189397118};\\\", \\\"{x:541,y:746,t:1527189397142};\\\", \\\"{x:544,y:746,t:1527189397150};\\\", \\\"{x:546,y:745,t:1527189397166};\\\", \\\"{x:547,y:744,t:1527189397180};\\\", \\\"{x:553,y:741,t:1527189397197};\\\", \\\"{x:561,y:739,t:1527189397214};\\\", \\\"{x:570,y:737,t:1527189397231};\\\", \\\"{x:582,y:734,t:1527189397247};\\\", \\\"{x:591,y:732,t:1527189397262};\\\", \\\"{x:606,y:731,t:1527189397279};\\\", \\\"{x:615,y:728,t:1527189397296};\\\", \\\"{x:622,y:727,t:1527189397312};\\\", \\\"{x:623,y:727,t:1527189397330};\\\", \\\"{x:624,y:727,t:1527189397415};\\\", \\\"{x:628,y:727,t:1527189397430};\\\", \\\"{x:636,y:727,t:1527189397447};\\\", \\\"{x:640,y:727,t:1527189397462};\\\", \\\"{x:645,y:727,t:1527189397479};\\\", \\\"{x:647,y:727,t:1527189397496};\\\", \\\"{x:650,y:727,t:1527189397513};\\\", \\\"{x:656,y:727,t:1527189397530};\\\", \\\"{x:659,y:727,t:1527189397547};\\\", \\\"{x:660,y:727,t:1527189397563};\\\", \\\"{x:661,y:727,t:1527189397580};\\\", \\\"{x:665,y:727,t:1527189398919};\\\", \\\"{x:687,y:731,t:1527189398930};\\\", \\\"{x:807,y:754,t:1527189398948};\\\", \\\"{x:920,y:768,t:1527189398964};\\\", \\\"{x:1031,y:783,t:1527189398982};\\\", \\\"{x:1116,y:790,t:1527189398998};\\\", \\\"{x:1148,y:789,t:1527189399015};\\\", \\\"{x:1160,y:785,t:1527189399031};\\\", \\\"{x:1163,y:781,t:1527189399048};\\\", \\\"{x:1171,y:777,t:1527189399065};\\\", \\\"{x:1179,y:771,t:1527189399081};\\\", \\\"{x:1194,y:759,t:1527189399098};\\\", \\\"{x:1216,y:745,t:1527189399115};\\\", \\\"{x:1249,y:738,t:1527189399131};\\\", \\\"{x:1282,y:735,t:1527189399148};\\\", \\\"{x:1314,y:731,t:1527189399165};\\\", \\\"{x:1335,y:730,t:1527189399181};\\\", \\\"{x:1340,y:730,t:1527189399198};\\\", \\\"{x:1341,y:730,t:1527189399231};\\\", \\\"{x:1345,y:731,t:1527189399248};\\\", \\\"{x:1350,y:732,t:1527189399265};\\\", \\\"{x:1352,y:734,t:1527189399281};\\\", \\\"{x:1353,y:735,t:1527189399298};\\\", \\\"{x:1353,y:737,t:1527189399335};\\\", \\\"{x:1352,y:739,t:1527189399348};\\\", \\\"{x:1349,y:742,t:1527189399365};\\\", \\\"{x:1346,y:743,t:1527189399382};\\\", \\\"{x:1344,y:748,t:1527189399397};\\\", \\\"{x:1342,y:750,t:1527189399414};\\\", \\\"{x:1342,y:751,t:1527189399446};\\\", \\\"{x:1341,y:753,t:1527189399478};\\\", \\\"{x:1341,y:756,t:1527189399486};\\\", \\\"{x:1339,y:757,t:1527189399498};\\\", \\\"{x:1338,y:762,t:1527189399515};\\\", \\\"{x:1338,y:764,t:1527189399531};\\\", \\\"{x:1339,y:764,t:1527189399775};\\\", \\\"{x:1340,y:764,t:1527189401103};\\\", \\\"{x:1342,y:764,t:1527189401117};\\\", \\\"{x:1350,y:764,t:1527189401132};\\\", \\\"{x:1352,y:764,t:1527189401149};\\\", \\\"{x:1351,y:764,t:1527189401303};\\\", \\\"{x:1349,y:764,t:1527189401316};\\\", \\\"{x:1348,y:764,t:1527189401333};\\\", \\\"{x:1346,y:764,t:1527189401349};\\\", \\\"{x:1344,y:763,t:1527189401367};\\\", \\\"{x:1338,y:762,t:1527189402393};\\\", \\\"{x:1304,y:755,t:1527189402401};\\\", \\\"{x:1186,y:728,t:1527189402417};\\\", \\\"{x:1040,y:693,t:1527189402434};\\\", \\\"{x:860,y:636,t:1527189402451};\\\", \\\"{x:709,y:601,t:1527189402468};\\\", \\\"{x:548,y:568,t:1527189402485};\\\", \\\"{x:402,y:541,t:1527189402517};\\\", \\\"{x:385,y:539,t:1527189402534};\\\", \\\"{x:373,y:536,t:1527189402550};\\\", \\\"{x:363,y:534,t:1527189402567};\\\", \\\"{x:350,y:531,t:1527189402584};\\\", \\\"{x:327,y:529,t:1527189402600};\\\", \\\"{x:304,y:527,t:1527189402617};\\\", \\\"{x:291,y:526,t:1527189402634};\\\", \\\"{x:284,y:525,t:1527189402651};\\\", \\\"{x:282,y:525,t:1527189402667};\\\", \\\"{x:281,y:526,t:1527189402684};\\\", \\\"{x:268,y:533,t:1527189402701};\\\", \\\"{x:252,y:542,t:1527189402717};\\\", \\\"{x:239,y:548,t:1527189402734};\\\", \\\"{x:233,y:549,t:1527189402751};\\\", \\\"{x:231,y:550,t:1527189402766};\\\", \\\"{x:222,y:550,t:1527189402847};\\\", \\\"{x:212,y:550,t:1527189402854};\\\", \\\"{x:206,y:550,t:1527189402867};\\\", \\\"{x:200,y:550,t:1527189402883};\\\", \\\"{x:199,y:550,t:1527189402901};\\\", \\\"{x:197,y:550,t:1527189402951};\\\", \\\"{x:193,y:549,t:1527189402967};\\\", \\\"{x:188,y:548,t:1527189402985};\\\", \\\"{x:186,y:547,t:1527189403000};\\\", \\\"{x:185,y:547,t:1527189403045};\\\", \\\"{x:184,y:546,t:1527189403070};\\\", \\\"{x:182,y:545,t:1527189403084};\\\", \\\"{x:179,y:543,t:1527189403100};\\\", \\\"{x:169,y:541,t:1527189403118};\\\", \\\"{x:165,y:540,t:1527189403135};\\\", \\\"{x:164,y:539,t:1527189403151};\\\", \\\"{x:167,y:541,t:1527189403510};\\\", \\\"{x:177,y:549,t:1527189403518};\\\", \\\"{x:195,y:561,t:1527189403534};\\\", \\\"{x:215,y:574,t:1527189403552};\\\", \\\"{x:227,y:586,t:1527189403567};\\\", \\\"{x:244,y:596,t:1527189403585};\\\", \\\"{x:257,y:601,t:1527189403601};\\\", \\\"{x:270,y:610,t:1527189403617};\\\", \\\"{x:282,y:621,t:1527189403636};\\\", \\\"{x:297,y:633,t:1527189403651};\\\", \\\"{x:316,y:644,t:1527189403668};\\\", \\\"{x:323,y:652,t:1527189403684};\\\", \\\"{x:337,y:660,t:1527189403701};\\\", \\\"{x:346,y:664,t:1527189403717};\\\", \\\"{x:363,y:672,t:1527189403734};\\\", \\\"{x:366,y:673,t:1527189403752};\\\", \\\"{x:369,y:676,t:1527189403768};\\\", \\\"{x:379,y:681,t:1527189403784};\\\", \\\"{x:389,y:687,t:1527189403802};\\\", \\\"{x:396,y:693,t:1527189403818};\\\", \\\"{x:401,y:696,t:1527189403835};\\\", \\\"{x:402,y:696,t:1527189403851};\\\", \\\"{x:403,y:696,t:1527189403869};\\\", \\\"{x:407,y:697,t:1527189403885};\\\", \\\"{x:412,y:699,t:1527189403902};\\\", \\\"{x:433,y:709,t:1527189403919};\\\", \\\"{x:444,y:713,t:1527189403934};\\\", \\\"{x:450,y:713,t:1527189403952};\\\", \\\"{x:451,y:714,t:1527189403968};\\\", \\\"{x:453,y:714,t:1527189404031};\\\", \\\"{x:454,y:714,t:1527189404039};\\\", \\\"{x:456,y:714,t:1527189404055};\\\", \\\"{x:456,y:715,t:1527189404068};\\\", \\\"{x:458,y:716,t:1527189404086};\\\", \\\"{x:458,y:717,t:1527189404102};\\\", \\\"{x:458,y:719,t:1527189404119};\\\", \\\"{x:458,y:722,t:1527189404185};\\\", \\\"{x:462,y:726,t:1527189404201};\\\", \\\"{x:462,y:732,t:1527189404218};\\\", \\\"{x:465,y:734,t:1527189404235};\\\" ] }, { \\\"rt\\\": 61122, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 993000, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -H -Z -04 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:465,y:736,t:1527189406551};\\\", \\\"{x:483,y:753,t:1527189406558};\\\", \\\"{x:512,y:767,t:1527189406571};\\\", \\\"{x:602,y:798,t:1527189406586};\\\", \\\"{x:690,y:837,t:1527189406604};\\\", \\\"{x:750,y:857,t:1527189406620};\\\", \\\"{x:794,y:875,t:1527189406636};\\\", \\\"{x:812,y:882,t:1527189406653};\\\", \\\"{x:818,y:883,t:1527189406669};\\\", \\\"{x:821,y:883,t:1527189406710};\\\", \\\"{x:824,y:883,t:1527189406720};\\\", \\\"{x:834,y:885,t:1527189406736};\\\", \\\"{x:844,y:889,t:1527189406753};\\\", \\\"{x:852,y:891,t:1527189406771};\\\", \\\"{x:854,y:891,t:1527189406787};\\\", \\\"{x:855,y:891,t:1527189409927};\\\", \\\"{x:856,y:892,t:1527189410375};\\\", \\\"{x:858,y:894,t:1527189410390};\\\", \\\"{x:862,y:894,t:1527189410422};\\\", \\\"{x:884,y:889,t:1527189410440};\\\", \\\"{x:912,y:877,t:1527189410456};\\\", \\\"{x:944,y:866,t:1527189410473};\\\", \\\"{x:960,y:857,t:1527189410490};\\\", \\\"{x:981,y:852,t:1527189410507};\\\", \\\"{x:998,y:847,t:1527189410523};\\\", \\\"{x:1039,y:841,t:1527189410540};\\\", \\\"{x:1072,y:835,t:1527189410557};\\\", \\\"{x:1094,y:833,t:1527189410574};\\\", \\\"{x:1130,y:826,t:1527189410590};\\\", \\\"{x:1169,y:818,t:1527189410607};\\\", \\\"{x:1182,y:813,t:1527189410623};\\\", \\\"{x:1189,y:811,t:1527189410640};\\\", \\\"{x:1191,y:808,t:1527189410657};\\\", \\\"{x:1194,y:807,t:1527189410674};\\\", \\\"{x:1196,y:806,t:1527189410690};\\\", \\\"{x:1198,y:806,t:1527189410708};\\\", \\\"{x:1201,y:804,t:1527189410724};\\\", \\\"{x:1213,y:806,t:1527189410741};\\\", \\\"{x:1222,y:810,t:1527189410758};\\\", \\\"{x:1230,y:811,t:1527189410774};\\\", \\\"{x:1235,y:811,t:1527189410790};\\\", \\\"{x:1236,y:813,t:1527189410983};\\\", \\\"{x:1236,y:816,t:1527189410991};\\\", \\\"{x:1234,y:821,t:1527189411007};\\\", \\\"{x:1232,y:826,t:1527189411023};\\\", \\\"{x:1230,y:829,t:1527189411041};\\\", \\\"{x:1230,y:831,t:1527189411057};\\\", \\\"{x:1227,y:833,t:1527189411075};\\\", \\\"{x:1225,y:836,t:1527189411091};\\\", \\\"{x:1220,y:839,t:1527189411107};\\\", \\\"{x:1219,y:840,t:1527189411127};\\\", \\\"{x:1224,y:840,t:1527189411375};\\\", \\\"{x:1246,y:843,t:1527189411391};\\\", \\\"{x:1268,y:843,t:1527189411407};\\\", \\\"{x:1290,y:844,t:1527189411425};\\\", \\\"{x:1307,y:845,t:1527189411441};\\\", \\\"{x:1314,y:845,t:1527189411457};\\\", \\\"{x:1316,y:846,t:1527189411476};\\\", \\\"{x:1317,y:847,t:1527189411607};\\\", \\\"{x:1318,y:847,t:1527189411631};\\\", \\\"{x:1319,y:847,t:1527189411642};\\\", \\\"{x:1333,y:851,t:1527189411658};\\\", \\\"{x:1346,y:855,t:1527189411675};\\\", \\\"{x:1362,y:860,t:1527189411692};\\\", \\\"{x:1377,y:865,t:1527189411707};\\\", \\\"{x:1386,y:868,t:1527189411724};\\\", \\\"{x:1389,y:870,t:1527189411742};\\\", \\\"{x:1391,y:872,t:1527189411871};\\\", \\\"{x:1393,y:873,t:1527189411879};\\\", \\\"{x:1393,y:874,t:1527189411892};\\\", \\\"{x:1394,y:875,t:1527189411907};\\\", \\\"{x:1394,y:876,t:1527189412119};\\\", \\\"{x:1398,y:875,t:1527189412127};\\\", \\\"{x:1405,y:875,t:1527189412142};\\\", \\\"{x:1423,y:874,t:1527189412158};\\\", \\\"{x:1457,y:870,t:1527189412175};\\\", \\\"{x:1482,y:868,t:1527189412191};\\\", \\\"{x:1499,y:864,t:1527189412208};\\\", \\\"{x:1506,y:863,t:1527189412225};\\\", \\\"{x:1510,y:862,t:1527189412242};\\\", \\\"{x:1514,y:858,t:1527189412259};\\\", \\\"{x:1522,y:854,t:1527189412275};\\\", \\\"{x:1527,y:848,t:1527189412292};\\\", \\\"{x:1542,y:842,t:1527189412309};\\\", \\\"{x:1554,y:838,t:1527189412325};\\\", \\\"{x:1564,y:835,t:1527189412342};\\\", \\\"{x:1588,y:831,t:1527189412358};\\\", \\\"{x:1603,y:830,t:1527189412375};\\\", \\\"{x:1613,y:827,t:1527189412392};\\\", \\\"{x:1621,y:825,t:1527189412409};\\\", \\\"{x:1625,y:824,t:1527189412424};\\\", \\\"{x:1626,y:823,t:1527189412442};\\\", \\\"{x:1629,y:821,t:1527189412459};\\\", \\\"{x:1630,y:821,t:1527189412475};\\\", \\\"{x:1631,y:820,t:1527189412492};\\\", \\\"{x:1634,y:816,t:1527189412509};\\\", \\\"{x:1636,y:808,t:1527189412525};\\\", \\\"{x:1636,y:799,t:1527189412541};\\\", \\\"{x:1636,y:788,t:1527189412559};\\\", \\\"{x:1635,y:777,t:1527189412575};\\\", \\\"{x:1633,y:766,t:1527189412591};\\\", \\\"{x:1628,y:755,t:1527189412609};\\\", \\\"{x:1627,y:749,t:1527189412626};\\\", \\\"{x:1625,y:740,t:1527189412642};\\\", \\\"{x:1620,y:724,t:1527189412659};\\\", \\\"{x:1618,y:717,t:1527189412675};\\\", \\\"{x:1618,y:715,t:1527189412692};\\\", \\\"{x:1618,y:709,t:1527189412709};\\\", \\\"{x:1616,y:698,t:1527189412728};\\\", \\\"{x:1612,y:680,t:1527189412742};\\\", \\\"{x:1606,y:661,t:1527189412758};\\\", \\\"{x:1603,y:658,t:1527189412775};\\\", \\\"{x:1602,y:653,t:1527189412791};\\\", \\\"{x:1597,y:647,t:1527189412808};\\\", \\\"{x:1591,y:638,t:1527189412825};\\\", \\\"{x:1579,y:623,t:1527189412841};\\\", \\\"{x:1574,y:614,t:1527189412858};\\\", \\\"{x:1569,y:607,t:1527189412875};\\\", \\\"{x:1568,y:607,t:1527189412891};\\\", \\\"{x:1567,y:606,t:1527189412908};\\\", \\\"{x:1564,y:603,t:1527189412925};\\\", \\\"{x:1563,y:593,t:1527189412941};\\\", \\\"{x:1549,y:559,t:1527189412959};\\\", \\\"{x:1542,y:544,t:1527189412975};\\\", \\\"{x:1537,y:534,t:1527189412993};\\\", \\\"{x:1533,y:526,t:1527189413009};\\\", \\\"{x:1531,y:521,t:1527189413025};\\\", \\\"{x:1530,y:518,t:1527189413043};\\\", \\\"{x:1530,y:517,t:1527189413058};\\\", \\\"{x:1529,y:516,t:1527189413075};\\\", \\\"{x:1526,y:513,t:1527189413097};\\\", \\\"{x:1524,y:512,t:1527189413108};\\\", \\\"{x:1516,y:506,t:1527189413125};\\\", \\\"{x:1496,y:492,t:1527189413142};\\\", \\\"{x:1481,y:485,t:1527189413158};\\\", \\\"{x:1470,y:480,t:1527189413175};\\\", \\\"{x:1461,y:475,t:1527189413192};\\\", \\\"{x:1453,y:472,t:1527189413208};\\\", \\\"{x:1447,y:472,t:1527189413225};\\\", \\\"{x:1441,y:471,t:1527189413242};\\\", \\\"{x:1430,y:471,t:1527189413258};\\\", \\\"{x:1415,y:471,t:1527189413275};\\\", \\\"{x:1389,y:476,t:1527189413292};\\\", \\\"{x:1354,y:494,t:1527189413308};\\\", \\\"{x:1345,y:499,t:1527189413325};\\\", \\\"{x:1341,y:502,t:1527189413342};\\\", \\\"{x:1341,y:507,t:1527189413391};\\\", \\\"{x:1341,y:512,t:1527189413399};\\\", \\\"{x:1341,y:516,t:1527189413409};\\\", \\\"{x:1340,y:523,t:1527189413426};\\\", \\\"{x:1338,y:529,t:1527189413442};\\\", \\\"{x:1338,y:531,t:1527189413460};\\\", \\\"{x:1338,y:532,t:1527189413475};\\\", \\\"{x:1338,y:535,t:1527189413493};\\\", \\\"{x:1338,y:540,t:1527189413509};\\\", \\\"{x:1338,y:548,t:1527189413526};\\\", \\\"{x:1344,y:565,t:1527189413543};\\\", \\\"{x:1347,y:574,t:1527189413559};\\\", \\\"{x:1347,y:576,t:1527189413575};\\\", \\\"{x:1348,y:576,t:1527189413639};\\\", \\\"{x:1351,y:578,t:1527189413646};\\\", \\\"{x:1356,y:583,t:1527189413659};\\\", \\\"{x:1369,y:590,t:1527189413676};\\\", \\\"{x:1384,y:596,t:1527189413693};\\\", \\\"{x:1401,y:600,t:1527189413710};\\\", \\\"{x:1419,y:601,t:1527189413726};\\\", \\\"{x:1436,y:601,t:1527189413743};\\\", \\\"{x:1441,y:601,t:1527189413759};\\\", \\\"{x:1443,y:601,t:1527189413783};\\\", \\\"{x:1444,y:601,t:1527189413815};\\\", \\\"{x:1446,y:601,t:1527189413825};\\\", \\\"{x:1450,y:601,t:1527189413843};\\\", \\\"{x:1466,y:607,t:1527189413860};\\\", \\\"{x:1486,y:611,t:1527189413877};\\\", \\\"{x:1504,y:618,t:1527189413892};\\\", \\\"{x:1527,y:628,t:1527189413909};\\\", \\\"{x:1552,y:644,t:1527189413926};\\\", \\\"{x:1565,y:651,t:1527189413942};\\\", \\\"{x:1569,y:654,t:1527189413959};\\\", \\\"{x:1570,y:656,t:1527189413976};\\\", \\\"{x:1572,y:657,t:1527189414014};\\\", \\\"{x:1572,y:659,t:1527189414026};\\\", \\\"{x:1573,y:668,t:1527189414042};\\\", \\\"{x:1578,y:681,t:1527189414059};\\\", \\\"{x:1578,y:686,t:1527189414077};\\\", \\\"{x:1579,y:687,t:1527189414092};\\\", \\\"{x:1579,y:689,t:1527189414110};\\\", \\\"{x:1583,y:693,t:1527189414126};\\\", \\\"{x:1590,y:703,t:1527189414143};\\\", \\\"{x:1601,y:715,t:1527189414159};\\\", \\\"{x:1614,y:721,t:1527189414177};\\\", \\\"{x:1621,y:724,t:1527189414193};\\\", \\\"{x:1622,y:725,t:1527189414210};\\\", \\\"{x:1623,y:725,t:1527189414311};\\\", \\\"{x:1623,y:714,t:1527189414327};\\\", \\\"{x:1623,y:708,t:1527189414343};\\\", \\\"{x:1623,y:706,t:1527189414360};\\\", \\\"{x:1623,y:705,t:1527189414377};\\\", \\\"{x:1623,y:704,t:1527189414423};\\\", \\\"{x:1623,y:703,t:1527189414471};\\\", \\\"{x:1623,y:702,t:1527189414479};\\\", \\\"{x:1621,y:701,t:1527189414534};\\\", \\\"{x:1620,y:700,t:1527189414550};\\\", \\\"{x:1620,y:699,t:1527189414566};\\\", \\\"{x:1619,y:698,t:1527189414582};\\\", \\\"{x:1618,y:698,t:1527189414593};\\\", \\\"{x:1617,y:698,t:1527189414622};\\\", \\\"{x:1615,y:698,t:1527189414638};\\\", \\\"{x:1613,y:698,t:1527189414663};\\\", \\\"{x:1611,y:697,t:1527189414677};\\\", \\\"{x:1610,y:697,t:1527189414694};\\\", \\\"{x:1609,y:696,t:1527189414709};\\\", \\\"{x:1608,y:695,t:1527189414936};\\\", \\\"{x:1608,y:698,t:1527189415223};\\\", \\\"{x:1608,y:699,t:1527189415231};\\\", \\\"{x:1608,y:703,t:1527189415243};\\\", \\\"{x:1608,y:708,t:1527189415261};\\\", \\\"{x:1607,y:710,t:1527189415276};\\\", \\\"{x:1606,y:714,t:1527189415294};\\\", \\\"{x:1606,y:725,t:1527189415311};\\\", \\\"{x:1605,y:733,t:1527189415327};\\\", \\\"{x:1604,y:739,t:1527189415343};\\\", \\\"{x:1603,y:744,t:1527189415360};\\\", \\\"{x:1603,y:748,t:1527189415377};\\\", \\\"{x:1603,y:750,t:1527189415394};\\\", \\\"{x:1603,y:756,t:1527189415410};\\\", \\\"{x:1604,y:760,t:1527189415428};\\\", \\\"{x:1604,y:767,t:1527189415443};\\\", \\\"{x:1604,y:779,t:1527189415461};\\\", \\\"{x:1604,y:784,t:1527189415478};\\\", \\\"{x:1606,y:789,t:1527189415494};\\\", \\\"{x:1611,y:802,t:1527189415509};\\\", \\\"{x:1612,y:805,t:1527189415527};\\\", \\\"{x:1615,y:811,t:1527189415543};\\\", \\\"{x:1616,y:817,t:1527189415560};\\\", \\\"{x:1616,y:821,t:1527189415577};\\\", \\\"{x:1617,y:825,t:1527189415593};\\\", \\\"{x:1618,y:833,t:1527189415610};\\\", \\\"{x:1619,y:842,t:1527189415627};\\\", \\\"{x:1619,y:847,t:1527189415643};\\\", \\\"{x:1619,y:853,t:1527189415660};\\\", \\\"{x:1619,y:856,t:1527189415677};\\\", \\\"{x:1619,y:857,t:1527189415693};\\\", \\\"{x:1618,y:863,t:1527189415710};\\\", \\\"{x:1618,y:867,t:1527189415727};\\\", \\\"{x:1617,y:872,t:1527189415743};\\\", \\\"{x:1616,y:876,t:1527189415761};\\\", \\\"{x:1615,y:882,t:1527189415777};\\\", \\\"{x:1614,y:889,t:1527189415793};\\\", \\\"{x:1614,y:894,t:1527189415810};\\\", \\\"{x:1614,y:902,t:1527189415827};\\\", \\\"{x:1614,y:908,t:1527189415844};\\\", \\\"{x:1614,y:915,t:1527189415861};\\\", \\\"{x:1614,y:922,t:1527189415878};\\\", \\\"{x:1615,y:930,t:1527189415894};\\\", \\\"{x:1617,y:934,t:1527189415911};\\\", \\\"{x:1618,y:936,t:1527189415927};\\\", \\\"{x:1623,y:944,t:1527189415944};\\\", \\\"{x:1627,y:953,t:1527189415961};\\\", \\\"{x:1630,y:956,t:1527189415978};\\\", \\\"{x:1628,y:959,t:1527189416080};\\\", \\\"{x:1627,y:959,t:1527189416095};\\\", \\\"{x:1624,y:960,t:1527189416110};\\\", \\\"{x:1622,y:961,t:1527189416128};\\\", \\\"{x:1621,y:962,t:1527189416167};\\\", \\\"{x:1620,y:963,t:1527189416183};\\\", \\\"{x:1619,y:963,t:1527189416195};\\\", \\\"{x:1618,y:965,t:1527189416224};\\\", \\\"{x:1618,y:967,t:1527189416230};\\\", \\\"{x:1617,y:967,t:1527189416245};\\\", \\\"{x:1617,y:968,t:1527189416260};\\\", \\\"{x:1616,y:969,t:1527189416326};\\\", \\\"{x:1611,y:969,t:1527189416334};\\\", \\\"{x:1610,y:968,t:1527189416344};\\\", \\\"{x:1609,y:968,t:1527189416361};\\\", \\\"{x:1608,y:967,t:1527189416487};\\\", \\\"{x:1608,y:966,t:1527189416495};\\\", \\\"{x:1608,y:965,t:1527189416512};\\\", \\\"{x:1609,y:964,t:1527189417088};\\\", \\\"{x:1609,y:963,t:1527189417095};\\\", \\\"{x:1611,y:961,t:1527189417112};\\\", \\\"{x:1613,y:959,t:1527189417129};\\\", \\\"{x:1614,y:959,t:1527189417183};\\\", \\\"{x:1615,y:958,t:1527189417206};\\\", \\\"{x:1616,y:958,t:1527189417214};\\\", \\\"{x:1617,y:957,t:1527189417255};\\\", \\\"{x:1617,y:956,t:1527189417919};\\\", \\\"{x:1616,y:956,t:1527189418150};\\\", \\\"{x:1615,y:956,t:1527189418162};\\\", \\\"{x:1614,y:957,t:1527189418179};\\\", \\\"{x:1612,y:957,t:1527189418195};\\\", \\\"{x:1610,y:957,t:1527189418335};\\\", \\\"{x:1608,y:958,t:1527189418346};\\\", \\\"{x:1607,y:959,t:1527189418363};\\\", \\\"{x:1608,y:959,t:1527189418663};\\\", \\\"{x:1610,y:959,t:1527189418680};\\\", \\\"{x:1611,y:960,t:1527189418697};\\\", \\\"{x:1611,y:961,t:1527189418713};\\\", \\\"{x:1613,y:961,t:1527189419119};\\\", \\\"{x:1597,y:961,t:1527189422072};\\\", \\\"{x:1522,y:969,t:1527189422082};\\\", \\\"{x:1397,y:969,t:1527189422100};\\\", \\\"{x:1260,y:962,t:1527189422116};\\\", \\\"{x:1110,y:938,t:1527189422132};\\\", \\\"{x:1000,y:911,t:1527189422149};\\\", \\\"{x:951,y:902,t:1527189422166};\\\", \\\"{x:941,y:897,t:1527189422182};\\\", \\\"{x:941,y:895,t:1527189422230};\\\", \\\"{x:938,y:890,t:1527189422239};\\\", \\\"{x:929,y:885,t:1527189422248};\\\", \\\"{x:910,y:879,t:1527189422266};\\\", \\\"{x:894,y:874,t:1527189422282};\\\", \\\"{x:871,y:868,t:1527189422299};\\\", \\\"{x:822,y:867,t:1527189422316};\\\", \\\"{x:741,y:867,t:1527189422331};\\\", \\\"{x:684,y:868,t:1527189422349};\\\", \\\"{x:639,y:863,t:1527189422366};\\\", \\\"{x:616,y:854,t:1527189422381};\\\", \\\"{x:609,y:848,t:1527189422398};\\\", \\\"{x:604,y:840,t:1527189422415};\\\", \\\"{x:596,y:827,t:1527189422431};\\\", \\\"{x:584,y:809,t:1527189422449};\\\", \\\"{x:573,y:784,t:1527189422465};\\\", \\\"{x:556,y:748,t:1527189422482};\\\", \\\"{x:523,y:700,t:1527189422499};\\\", \\\"{x:495,y:656,t:1527189422516};\\\", \\\"{x:470,y:612,t:1527189422533};\\\", \\\"{x:458,y:579,t:1527189422550};\\\", \\\"{x:454,y:561,t:1527189422567};\\\", \\\"{x:453,y:547,t:1527189422583};\\\", \\\"{x:454,y:532,t:1527189422600};\\\", \\\"{x:462,y:518,t:1527189422616};\\\", \\\"{x:468,y:498,t:1527189422634};\\\", \\\"{x:478,y:484,t:1527189422651};\\\", \\\"{x:493,y:476,t:1527189422666};\\\", \\\"{x:497,y:476,t:1527189422683};\\\", \\\"{x:506,y:484,t:1527189422700};\\\", \\\"{x:522,y:510,t:1527189422717};\\\", \\\"{x:547,y:542,t:1527189422734};\\\", \\\"{x:597,y:607,t:1527189422751};\\\", \\\"{x:611,y:633,t:1527189422768};\\\", \\\"{x:612,y:642,t:1527189422783};\\\", \\\"{x:612,y:643,t:1527189422800};\\\", \\\"{x:612,y:644,t:1527189422886};\\\", \\\"{x:612,y:643,t:1527189422900};\\\", \\\"{x:612,y:642,t:1527189422918};\\\", \\\"{x:612,y:640,t:1527189422966};\\\", \\\"{x:614,y:636,t:1527189422984};\\\", \\\"{x:617,y:630,t:1527189423003};\\\", \\\"{x:617,y:624,t:1527189423018};\\\", \\\"{x:616,y:618,t:1527189423033};\\\", \\\"{x:612,y:611,t:1527189423050};\\\", \\\"{x:606,y:600,t:1527189423068};\\\", \\\"{x:604,y:594,t:1527189423083};\\\", \\\"{x:603,y:589,t:1527189423102};\\\", \\\"{x:603,y:583,t:1527189423117};\\\", \\\"{x:603,y:579,t:1527189423134};\\\", \\\"{x:604,y:579,t:1527189423150};\\\", \\\"{x:610,y:587,t:1527189423397};\\\", \\\"{x:621,y:599,t:1527189423406};\\\", \\\"{x:641,y:616,t:1527189423418};\\\", \\\"{x:694,y:655,t:1527189423435};\\\", \\\"{x:773,y:697,t:1527189423450};\\\", \\\"{x:860,y:728,t:1527189423467};\\\", \\\"{x:940,y:765,t:1527189423484};\\\", \\\"{x:1005,y:799,t:1527189423500};\\\", \\\"{x:1053,y:818,t:1527189423518};\\\", \\\"{x:1098,y:847,t:1527189423534};\\\", \\\"{x:1130,y:864,t:1527189423551};\\\", \\\"{x:1157,y:873,t:1527189423567};\\\", \\\"{x:1185,y:881,t:1527189423584};\\\", \\\"{x:1210,y:889,t:1527189423601};\\\", \\\"{x:1232,y:892,t:1527189423618};\\\", \\\"{x:1252,y:895,t:1527189423634};\\\", \\\"{x:1271,y:900,t:1527189423651};\\\", \\\"{x:1314,y:907,t:1527189423667};\\\", \\\"{x:1355,y:919,t:1527189423685};\\\", \\\"{x:1384,y:928,t:1527189423701};\\\", \\\"{x:1400,y:929,t:1527189423718};\\\", \\\"{x:1427,y:930,t:1527189423735};\\\", \\\"{x:1449,y:930,t:1527189423751};\\\", \\\"{x:1471,y:930,t:1527189423768};\\\", \\\"{x:1498,y:930,t:1527189423785};\\\", \\\"{x:1518,y:935,t:1527189423801};\\\", \\\"{x:1525,y:936,t:1527189423818};\\\", \\\"{x:1527,y:937,t:1527189423835};\\\", \\\"{x:1528,y:937,t:1527189423887};\\\", \\\"{x:1531,y:937,t:1527189423903};\\\", \\\"{x:1535,y:937,t:1527189423919};\\\", \\\"{x:1544,y:938,t:1527189423935};\\\", \\\"{x:1552,y:939,t:1527189423952};\\\", \\\"{x:1567,y:944,t:1527189423968};\\\", \\\"{x:1584,y:949,t:1527189423985};\\\", \\\"{x:1593,y:954,t:1527189424002};\\\", \\\"{x:1601,y:955,t:1527189424018};\\\", \\\"{x:1604,y:957,t:1527189424035};\\\", \\\"{x:1609,y:958,t:1527189424052};\\\", \\\"{x:1617,y:962,t:1527189424069};\\\", \\\"{x:1624,y:962,t:1527189424085};\\\", \\\"{x:1627,y:964,t:1527189424102};\\\", \\\"{x:1626,y:963,t:1527189424191};\\\", \\\"{x:1625,y:963,t:1527189424202};\\\", \\\"{x:1623,y:963,t:1527189424218};\\\", \\\"{x:1622,y:962,t:1527189424415};\\\", \\\"{x:1621,y:961,t:1527189424438};\\\", \\\"{x:1620,y:961,t:1527189424479};\\\", \\\"{x:1619,y:961,t:1527189424486};\\\", \\\"{x:1617,y:961,t:1527189424590};\\\", \\\"{x:1615,y:961,t:1527189424601};\\\", \\\"{x:1613,y:961,t:1527189424622};\\\", \\\"{x:1612,y:961,t:1527189424646};\\\", \\\"{x:1571,y:976,t:1527189464754};\\\", \\\"{x:1469,y:1011,t:1527189464761};\\\", \\\"{x:1383,y:1036,t:1527189464776};\\\", \\\"{x:1218,y:1076,t:1527189464793};\\\", \\\"{x:1068,y:1104,t:1527189464808};\\\", \\\"{x:882,y:1123,t:1527189464826};\\\", \\\"{x:830,y:1123,t:1527189464842};\\\", \\\"{x:819,y:1121,t:1527189464858};\\\", \\\"{x:818,y:1118,t:1527189464930};\\\", \\\"{x:801,y:1109,t:1527189464942};\\\", \\\"{x:760,y:1093,t:1527189464959};\\\", \\\"{x:735,y:1085,t:1527189464975};\\\", \\\"{x:716,y:1080,t:1527189464992};\\\", \\\"{x:706,y:1078,t:1527189465009};\\\", \\\"{x:705,y:1077,t:1527189465025};\\\", \\\"{x:702,y:1059,t:1527189465041};\\\", \\\"{x:702,y:1032,t:1527189465059};\\\", \\\"{x:696,y:998,t:1527189465075};\\\", \\\"{x:681,y:955,t:1527189465092};\\\", \\\"{x:649,y:906,t:1527189465109};\\\", \\\"{x:633,y:886,t:1527189465125};\\\", \\\"{x:630,y:882,t:1527189465142};\\\", \\\"{x:630,y:880,t:1527189465159};\\\", \\\"{x:630,y:874,t:1527189465175};\\\", \\\"{x:629,y:865,t:1527189465192};\\\", \\\"{x:626,y:850,t:1527189465209};\\\", \\\"{x:624,y:846,t:1527189465225};\\\", \\\"{x:623,y:845,t:1527189465274};\\\", \\\"{x:615,y:844,t:1527189465305};\\\", \\\"{x:595,y:830,t:1527189465313};\\\", \\\"{x:574,y:809,t:1527189465325};\\\", \\\"{x:544,y:788,t:1527189465342};\\\", \\\"{x:535,y:778,t:1527189465359};\\\", \\\"{x:534,y:774,t:1527189465375};\\\", \\\"{x:534,y:771,t:1527189465392};\\\", \\\"{x:534,y:758,t:1527189465409};\\\", \\\"{x:532,y:744,t:1527189465426};\\\", \\\"{x:531,y:740,t:1527189465441};\\\", \\\"{x:530,y:735,t:1527189465458};\\\", \\\"{x:530,y:728,t:1527189465472};\\\", \\\"{x:530,y:727,t:1527189465488};\\\", \\\"{x:529,y:726,t:1527189465505};\\\", \\\"{x:529,y:725,t:1527189465522};\\\", \\\"{x:529,y:724,t:1527189465585};\\\", \\\"{x:529,y:722,t:1527189465593};\\\", \\\"{x:528,y:721,t:1527189465606};\\\", \\\"{x:527,y:721,t:1527189465721};\\\", \\\"{x:525,y:722,t:1527189465729};\\\", \\\"{x:524,y:724,t:1527189465740};\\\", \\\"{x:521,y:728,t:1527189465756};\\\", \\\"{x:521,y:731,t:1527189465773};\\\", \\\"{x:520,y:733,t:1527189465789};\\\" ] }, { \\\"rt\\\": 52638, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 1047159, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-11 AM-12 PM-03 PM-12 PM-01 PM-02 PM-02 PM-03 PM-G -01 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:739,t:1527189472818};\\\", \\\"{x:527,y:769,t:1527189472832};\\\", \\\"{x:554,y:817,t:1527189472849};\\\", \\\"{x:557,y:819,t:1527189472861};\\\", \\\"{x:559,y:822,t:1527189472877};\\\", \\\"{x:561,y:822,t:1527189472893};\\\", \\\"{x:561,y:824,t:1527189472945};\\\", \\\"{x:565,y:829,t:1527189472960};\\\", \\\"{x:583,y:840,t:1527189472976};\\\", \\\"{x:616,y:849,t:1527189472994};\\\", \\\"{x:638,y:853,t:1527189473011};\\\", \\\"{x:667,y:855,t:1527189473027};\\\", \\\"{x:702,y:857,t:1527189473044};\\\", \\\"{x:756,y:859,t:1527189473061};\\\", \\\"{x:798,y:859,t:1527189473078};\\\", \\\"{x:828,y:861,t:1527189473094};\\\", \\\"{x:852,y:870,t:1527189473111};\\\", \\\"{x:863,y:874,t:1527189473127};\\\", \\\"{x:875,y:879,t:1527189473144};\\\", \\\"{x:897,y:881,t:1527189473161};\\\", \\\"{x:914,y:884,t:1527189473179};\\\", \\\"{x:936,y:885,t:1527189473195};\\\", \\\"{x:959,y:886,t:1527189473211};\\\", \\\"{x:981,y:888,t:1527189473229};\\\", \\\"{x:1021,y:893,t:1527189473244};\\\", \\\"{x:1062,y:897,t:1527189473261};\\\", \\\"{x:1087,y:904,t:1527189473279};\\\", \\\"{x:1112,y:906,t:1527189473295};\\\", \\\"{x:1127,y:906,t:1527189473312};\\\", \\\"{x:1133,y:904,t:1527189473329};\\\", \\\"{x:1135,y:904,t:1527189473505};\\\", \\\"{x:1140,y:906,t:1527189473513};\\\", \\\"{x:1142,y:910,t:1527189473528};\\\", \\\"{x:1146,y:915,t:1527189473544};\\\", \\\"{x:1159,y:923,t:1527189473561};\\\", \\\"{x:1175,y:931,t:1527189473578};\\\", \\\"{x:1195,y:939,t:1527189473594};\\\", \\\"{x:1217,y:948,t:1527189473611};\\\", \\\"{x:1255,y:958,t:1527189473629};\\\", \\\"{x:1298,y:971,t:1527189473645};\\\", \\\"{x:1336,y:980,t:1527189473662};\\\", \\\"{x:1375,y:990,t:1527189473679};\\\", \\\"{x:1398,y:992,t:1527189473695};\\\", \\\"{x:1418,y:995,t:1527189473711};\\\", \\\"{x:1428,y:997,t:1527189473729};\\\", \\\"{x:1441,y:998,t:1527189473745};\\\", \\\"{x:1461,y:1002,t:1527189473761};\\\", \\\"{x:1471,y:1003,t:1527189473779};\\\", \\\"{x:1488,y:1003,t:1527189473795};\\\", \\\"{x:1516,y:1003,t:1527189473811};\\\", \\\"{x:1538,y:1003,t:1527189473828};\\\", \\\"{x:1550,y:1003,t:1527189473845};\\\", \\\"{x:1560,y:1003,t:1527189473861};\\\", \\\"{x:1565,y:1003,t:1527189473878};\\\", \\\"{x:1566,y:1003,t:1527189473961};\\\", \\\"{x:1568,y:1002,t:1527189473985};\\\", \\\"{x:1568,y:999,t:1527189473996};\\\", \\\"{x:1568,y:995,t:1527189474011};\\\", \\\"{x:1568,y:990,t:1527189474028};\\\", \\\"{x:1565,y:984,t:1527189474045};\\\", \\\"{x:1564,y:983,t:1527189474061};\\\", \\\"{x:1563,y:982,t:1527189474078};\\\", \\\"{x:1561,y:981,t:1527189474096};\\\", \\\"{x:1559,y:981,t:1527189474111};\\\", \\\"{x:1557,y:978,t:1527189474128};\\\", \\\"{x:1555,y:975,t:1527189474145};\\\", \\\"{x:1552,y:971,t:1527189474162};\\\", \\\"{x:1552,y:968,t:1527189474179};\\\", \\\"{x:1550,y:967,t:1527189474196};\\\", \\\"{x:1549,y:966,t:1527189474211};\\\", \\\"{x:1547,y:963,t:1527189474229};\\\", \\\"{x:1545,y:961,t:1527189474246};\\\", \\\"{x:1543,y:961,t:1527189474262};\\\", \\\"{x:1541,y:961,t:1527189478202};\\\", \\\"{x:1533,y:964,t:1527189478214};\\\", \\\"{x:1486,y:985,t:1527189478231};\\\", \\\"{x:1457,y:993,t:1527189478247};\\\", \\\"{x:1438,y:996,t:1527189478264};\\\", \\\"{x:1421,y:996,t:1527189478281};\\\", \\\"{x:1408,y:996,t:1527189478298};\\\", \\\"{x:1405,y:996,t:1527189478314};\\\", \\\"{x:1401,y:996,t:1527189478331};\\\", \\\"{x:1397,y:996,t:1527189478348};\\\", \\\"{x:1383,y:995,t:1527189478364};\\\", \\\"{x:1369,y:991,t:1527189478380};\\\", \\\"{x:1358,y:990,t:1527189478398};\\\", \\\"{x:1353,y:990,t:1527189478414};\\\", \\\"{x:1352,y:988,t:1527189478514};\\\", \\\"{x:1356,y:978,t:1527189478531};\\\", \\\"{x:1366,y:968,t:1527189478549};\\\", \\\"{x:1371,y:963,t:1527189478565};\\\", \\\"{x:1373,y:962,t:1527189478581};\\\", \\\"{x:1375,y:962,t:1527189478658};\\\", \\\"{x:1379,y:962,t:1527189478665};\\\", \\\"{x:1383,y:965,t:1527189478680};\\\", \\\"{x:1389,y:969,t:1527189478698};\\\", \\\"{x:1393,y:971,t:1527189478714};\\\", \\\"{x:1395,y:973,t:1527189478731};\\\", \\\"{x:1396,y:973,t:1527189478747};\\\", \\\"{x:1398,y:975,t:1527189478765};\\\", \\\"{x:1403,y:976,t:1527189478780};\\\", \\\"{x:1411,y:978,t:1527189478798};\\\", \\\"{x:1421,y:980,t:1527189478815};\\\", \\\"{x:1434,y:981,t:1527189478831};\\\", \\\"{x:1445,y:982,t:1527189478848};\\\", \\\"{x:1451,y:982,t:1527189478865};\\\", \\\"{x:1452,y:982,t:1527189478897};\\\", \\\"{x:1454,y:982,t:1527189478915};\\\", \\\"{x:1457,y:979,t:1527189478930};\\\", \\\"{x:1464,y:973,t:1527189478948};\\\", \\\"{x:1472,y:966,t:1527189478965};\\\", \\\"{x:1474,y:964,t:1527189478981};\\\", \\\"{x:1474,y:963,t:1527189479194};\\\", \\\"{x:1474,y:962,t:1527189479258};\\\", \\\"{x:1473,y:963,t:1527189479330};\\\", \\\"{x:1473,y:966,t:1527189479338};\\\", \\\"{x:1473,y:967,t:1527189479348};\\\", \\\"{x:1475,y:971,t:1527189479365};\\\", \\\"{x:1478,y:972,t:1527189479382};\\\", \\\"{x:1481,y:974,t:1527189479398};\\\", \\\"{x:1484,y:977,t:1527189479415};\\\", \\\"{x:1488,y:977,t:1527189479431};\\\", \\\"{x:1493,y:977,t:1527189479447};\\\", \\\"{x:1499,y:977,t:1527189479465};\\\", \\\"{x:1509,y:977,t:1527189479481};\\\", \\\"{x:1513,y:979,t:1527189479498};\\\", \\\"{x:1516,y:980,t:1527189479515};\\\", \\\"{x:1521,y:982,t:1527189479531};\\\", \\\"{x:1523,y:982,t:1527189479548};\\\", \\\"{x:1524,y:982,t:1527189479570};\\\", \\\"{x:1525,y:982,t:1527189479582};\\\", \\\"{x:1533,y:981,t:1527189479598};\\\", \\\"{x:1548,y:976,t:1527189479615};\\\", \\\"{x:1552,y:975,t:1527189479631};\\\", \\\"{x:1557,y:971,t:1527189479648};\\\", \\\"{x:1557,y:969,t:1527189479754};\\\", \\\"{x:1557,y:966,t:1527189479766};\\\", \\\"{x:1555,y:964,t:1527189479782};\\\", \\\"{x:1553,y:959,t:1527189479799};\\\", \\\"{x:1552,y:958,t:1527189479815};\\\", \\\"{x:1551,y:957,t:1527189479841};\\\", \\\"{x:1550,y:957,t:1527189480442};\\\", \\\"{x:1549,y:957,t:1527189480634};\\\", \\\"{x:1546,y:958,t:1527189480722};\\\", \\\"{x:1546,y:960,t:1527189480732};\\\", \\\"{x:1544,y:963,t:1527189480749};\\\", \\\"{x:1543,y:965,t:1527189480766};\\\", \\\"{x:1542,y:965,t:1527189481234};\\\", \\\"{x:1521,y:965,t:1527189504093};\\\", \\\"{x:1475,y:944,t:1527189504100};\\\", \\\"{x:1441,y:929,t:1527189504115};\\\", \\\"{x:1425,y:898,t:1527189504132};\\\", \\\"{x:1414,y:866,t:1527189504148};\\\", \\\"{x:1395,y:840,t:1527189504165};\\\", \\\"{x:1354,y:810,t:1527189504183};\\\", \\\"{x:1265,y:781,t:1527189504199};\\\", \\\"{x:1152,y:754,t:1527189504215};\\\", \\\"{x:1025,y:720,t:1527189504233};\\\", \\\"{x:889,y:694,t:1527189504249};\\\", \\\"{x:785,y:660,t:1527189504265};\\\", \\\"{x:727,y:627,t:1527189504284};\\\", \\\"{x:666,y:601,t:1527189504299};\\\", \\\"{x:625,y:577,t:1527189504315};\\\", \\\"{x:554,y:546,t:1527189504341};\\\", \\\"{x:537,y:542,t:1527189504358};\\\", \\\"{x:528,y:541,t:1527189504374};\\\", \\\"{x:513,y:539,t:1527189504390};\\\", \\\"{x:487,y:539,t:1527189504408};\\\", \\\"{x:435,y:539,t:1527189504425};\\\", \\\"{x:343,y:537,t:1527189504441};\\\", \\\"{x:268,y:537,t:1527189504458};\\\", \\\"{x:236,y:536,t:1527189504474};\\\", \\\"{x:225,y:535,t:1527189504490};\\\", \\\"{x:198,y:531,t:1527189504507};\\\", \\\"{x:177,y:533,t:1527189504525};\\\", \\\"{x:140,y:534,t:1527189504542};\\\", \\\"{x:108,y:530,t:1527189504557};\\\", \\\"{x:75,y:520,t:1527189504575};\\\", \\\"{x:57,y:518,t:1527189504591};\\\", \\\"{x:55,y:518,t:1527189504608};\\\", \\\"{x:61,y:518,t:1527189504669};\\\", \\\"{x:66,y:519,t:1527189504676};\\\", \\\"{x:82,y:527,t:1527189504693};\\\", \\\"{x:92,y:531,t:1527189504707};\\\", \\\"{x:99,y:536,t:1527189504725};\\\", \\\"{x:107,y:542,t:1527189504742};\\\", \\\"{x:113,y:546,t:1527189504757};\\\", \\\"{x:118,y:546,t:1527189505156};\\\", \\\"{x:122,y:546,t:1527189505164};\\\", \\\"{x:126,y:546,t:1527189505176};\\\", \\\"{x:130,y:547,t:1527189505192};\\\", \\\"{x:131,y:547,t:1527189505209};\\\", \\\"{x:132,y:547,t:1527189505292};\\\", \\\"{x:134,y:547,t:1527189505340};\\\", \\\"{x:135,y:547,t:1527189505453};\\\", \\\"{x:138,y:547,t:1527189505484};\\\", \\\"{x:139,y:547,t:1527189505492};\\\", \\\"{x:141,y:547,t:1527189505516};\\\", \\\"{x:142,y:547,t:1527189505540};\\\", \\\"{x:144,y:547,t:1527189505572};\\\", \\\"{x:145,y:547,t:1527189505580};\\\", \\\"{x:147,y:547,t:1527189505596};\\\", \\\"{x:148,y:547,t:1527189505781};\\\", \\\"{x:149,y:547,t:1527189505821};\\\", \\\"{x:151,y:547,t:1527189516812};\\\", \\\"{x:169,y:546,t:1527189516820};\\\", \\\"{x:194,y:541,t:1527189516836};\\\", \\\"{x:286,y:523,t:1527189516851};\\\", \\\"{x:345,y:513,t:1527189516868};\\\", \\\"{x:377,y:507,t:1527189516882};\\\", \\\"{x:419,y:503,t:1527189516898};\\\", \\\"{x:481,y:494,t:1527189516918};\\\", \\\"{x:500,y:493,t:1527189516936};\\\", \\\"{x:521,y:493,t:1527189516951};\\\", \\\"{x:539,y:494,t:1527189516968};\\\", \\\"{x:566,y:497,t:1527189516984};\\\", \\\"{x:598,y:497,t:1527189517001};\\\", \\\"{x:630,y:497,t:1527189517019};\\\", \\\"{x:652,y:497,t:1527189517034};\\\", \\\"{x:705,y:494,t:1527189517052};\\\", \\\"{x:784,y:490,t:1527189517069};\\\", \\\"{x:883,y:490,t:1527189517085};\\\", \\\"{x:975,y:490,t:1527189517102};\\\", \\\"{x:1055,y:490,t:1527189517119};\\\", \\\"{x:1125,y:490,t:1527189517136};\\\", \\\"{x:1170,y:496,t:1527189517152};\\\", \\\"{x:1198,y:496,t:1527189517168};\\\", \\\"{x:1221,y:496,t:1527189517186};\\\", \\\"{x:1246,y:487,t:1527189517202};\\\", \\\"{x:1276,y:481,t:1527189517218};\\\", \\\"{x:1312,y:473,t:1527189517235};\\\", \\\"{x:1331,y:473,t:1527189517251};\\\", \\\"{x:1352,y:474,t:1527189517268};\\\", \\\"{x:1359,y:477,t:1527189517285};\\\", \\\"{x:1371,y:486,t:1527189517302};\\\", \\\"{x:1383,y:498,t:1527189517319};\\\", \\\"{x:1390,y:508,t:1527189517336};\\\", \\\"{x:1390,y:510,t:1527189517352};\\\", \\\"{x:1390,y:514,t:1527189517369};\\\", \\\"{x:1390,y:517,t:1527189517386};\\\", \\\"{x:1390,y:521,t:1527189517403};\\\", \\\"{x:1393,y:529,t:1527189517418};\\\", \\\"{x:1400,y:544,t:1527189517436};\\\", \\\"{x:1403,y:548,t:1527189517452};\\\", \\\"{x:1403,y:551,t:1527189517469};\\\", \\\"{x:1406,y:555,t:1527189517486};\\\", \\\"{x:1412,y:564,t:1527189517506};\\\", \\\"{x:1413,y:566,t:1527189517518};\\\", \\\"{x:1414,y:566,t:1527189517535};\\\", \\\"{x:1415,y:569,t:1527189517628};\\\", \\\"{x:1415,y:570,t:1527189517636};\\\", \\\"{x:1415,y:575,t:1527189517653};\\\", \\\"{x:1415,y:580,t:1527189517669};\\\", \\\"{x:1415,y:593,t:1527189517686};\\\", \\\"{x:1415,y:611,t:1527189517703};\\\", \\\"{x:1415,y:628,t:1527189517719};\\\", \\\"{x:1417,y:636,t:1527189517735};\\\", \\\"{x:1419,y:640,t:1527189517753};\\\", \\\"{x:1419,y:644,t:1527189517769};\\\", \\\"{x:1421,y:649,t:1527189517786};\\\", \\\"{x:1423,y:656,t:1527189517803};\\\", \\\"{x:1430,y:672,t:1527189517820};\\\", \\\"{x:1435,y:681,t:1527189517836};\\\", \\\"{x:1440,y:692,t:1527189517853};\\\", \\\"{x:1442,y:701,t:1527189517870};\\\", \\\"{x:1445,y:707,t:1527189517886};\\\", \\\"{x:1446,y:711,t:1527189517903};\\\", \\\"{x:1446,y:718,t:1527189517919};\\\", \\\"{x:1450,y:737,t:1527189517936};\\\", \\\"{x:1453,y:756,t:1527189517953};\\\", \\\"{x:1456,y:770,t:1527189517969};\\\", \\\"{x:1456,y:784,t:1527189517986};\\\", \\\"{x:1456,y:800,t:1527189518002};\\\", \\\"{x:1457,y:821,t:1527189518019};\\\", \\\"{x:1457,y:832,t:1527189518035};\\\", \\\"{x:1457,y:835,t:1527189518052};\\\", \\\"{x:1453,y:846,t:1527189518069};\\\", \\\"{x:1446,y:858,t:1527189518086};\\\", \\\"{x:1443,y:872,t:1527189518102};\\\", \\\"{x:1439,y:883,t:1527189518120};\\\", \\\"{x:1436,y:892,t:1527189518137};\\\", \\\"{x:1433,y:903,t:1527189518152};\\\", \\\"{x:1433,y:913,t:1527189518170};\\\", \\\"{x:1432,y:917,t:1527189518186};\\\", \\\"{x:1431,y:921,t:1527189518202};\\\", \\\"{x:1427,y:935,t:1527189518220};\\\", \\\"{x:1426,y:954,t:1527189518236};\\\", \\\"{x:1426,y:972,t:1527189518253};\\\", \\\"{x:1426,y:985,t:1527189518270};\\\", \\\"{x:1426,y:995,t:1527189518287};\\\", \\\"{x:1426,y:1001,t:1527189518303};\\\", \\\"{x:1427,y:1004,t:1527189518320};\\\", \\\"{x:1427,y:1005,t:1527189518341};\\\", \\\"{x:1428,y:1005,t:1527189518404};\\\", \\\"{x:1438,y:1004,t:1527189518420};\\\", \\\"{x:1449,y:1004,t:1527189518436};\\\", \\\"{x:1464,y:1004,t:1527189518453};\\\", \\\"{x:1485,y:1004,t:1527189518470};\\\", \\\"{x:1504,y:1001,t:1527189518487};\\\", \\\"{x:1517,y:998,t:1527189518504};\\\", \\\"{x:1533,y:994,t:1527189518519};\\\", \\\"{x:1547,y:989,t:1527189518537};\\\", \\\"{x:1554,y:989,t:1527189518554};\\\", \\\"{x:1556,y:988,t:1527189518572};\\\", \\\"{x:1557,y:988,t:1527189518587};\\\", \\\"{x:1558,y:987,t:1527189518603};\\\", \\\"{x:1570,y:985,t:1527189518620};\\\", \\\"{x:1586,y:979,t:1527189518637};\\\", \\\"{x:1603,y:976,t:1527189518654};\\\", \\\"{x:1628,y:971,t:1527189518670};\\\", \\\"{x:1643,y:963,t:1527189518687};\\\", \\\"{x:1663,y:959,t:1527189518704};\\\", \\\"{x:1681,y:955,t:1527189518721};\\\", \\\"{x:1717,y:951,t:1527189518737};\\\", \\\"{x:1755,y:946,t:1527189518754};\\\", \\\"{x:1773,y:946,t:1527189518770};\\\", \\\"{x:1784,y:946,t:1527189518787};\\\", \\\"{x:1793,y:943,t:1527189518804};\\\", \\\"{x:1806,y:942,t:1527189518820};\\\", \\\"{x:1824,y:936,t:1527189518836};\\\", \\\"{x:1852,y:936,t:1527189518854};\\\", \\\"{x:1886,y:929,t:1527189518870};\\\", \\\"{x:1911,y:921,t:1527189518887};\\\", \\\"{x:1919,y:919,t:1527189518903};\\\", \\\"{x:1915,y:913,t:1527189519093};\\\", \\\"{x:1903,y:905,t:1527189519104};\\\", \\\"{x:1872,y:889,t:1527189519122};\\\", \\\"{x:1803,y:851,t:1527189519137};\\\", \\\"{x:1721,y:817,t:1527189519154};\\\", \\\"{x:1665,y:794,t:1527189519171};\\\", \\\"{x:1642,y:781,t:1527189519187};\\\", \\\"{x:1614,y:764,t:1527189519204};\\\", \\\"{x:1590,y:744,t:1527189519221};\\\", \\\"{x:1550,y:714,t:1527189519237};\\\", \\\"{x:1527,y:693,t:1527189519254};\\\", \\\"{x:1511,y:678,t:1527189519271};\\\", \\\"{x:1493,y:657,t:1527189519287};\\\", \\\"{x:1460,y:636,t:1527189519304};\\\", \\\"{x:1414,y:600,t:1527189519321};\\\", \\\"{x:1385,y:571,t:1527189519337};\\\", \\\"{x:1379,y:561,t:1527189519353};\\\", \\\"{x:1374,y:549,t:1527189519371};\\\", \\\"{x:1369,y:536,t:1527189519387};\\\", \\\"{x:1361,y:508,t:1527189519404};\\\", \\\"{x:1357,y:496,t:1527189519421};\\\", \\\"{x:1354,y:489,t:1527189519437};\\\", \\\"{x:1353,y:487,t:1527189519453};\\\", \\\"{x:1350,y:487,t:1527189519508};\\\", \\\"{x:1350,y:508,t:1527189519521};\\\", \\\"{x:1357,y:584,t:1527189519538};\\\", \\\"{x:1363,y:680,t:1527189519554};\\\", \\\"{x:1363,y:747,t:1527189519571};\\\", \\\"{x:1352,y:796,t:1527189519589};\\\", \\\"{x:1340,y:806,t:1527189519604};\\\", \\\"{x:1322,y:823,t:1527189519621};\\\", \\\"{x:1264,y:849,t:1527189519638};\\\", \\\"{x:1198,y:873,t:1527189519654};\\\", \\\"{x:1117,y:898,t:1527189519671};\\\", \\\"{x:1035,y:918,t:1527189519688};\\\", \\\"{x:1004,y:921,t:1527189519704};\\\", \\\"{x:988,y:921,t:1527189519721};\\\", \\\"{x:974,y:918,t:1527189519738};\\\", \\\"{x:972,y:917,t:1527189519754};\\\", \\\"{x:970,y:917,t:1527189519771};\\\", \\\"{x:954,y:911,t:1527189519788};\\\", \\\"{x:922,y:901,t:1527189519804};\\\", \\\"{x:845,y:881,t:1527189519821};\\\", \\\"{x:763,y:864,t:1527189519838};\\\", \\\"{x:690,y:852,t:1527189519854};\\\", \\\"{x:655,y:841,t:1527189519871};\\\", \\\"{x:639,y:836,t:1527189519887};\\\", \\\"{x:626,y:828,t:1527189519904};\\\", \\\"{x:623,y:825,t:1527189519920};\\\", \\\"{x:622,y:824,t:1527189519937};\\\", \\\"{x:627,y:821,t:1527189519987};\\\", \\\"{x:645,y:802,t:1527189520004};\\\", \\\"{x:679,y:780,t:1527189520021};\\\", \\\"{x:763,y:749,t:1527189520037};\\\", \\\"{x:833,y:732,t:1527189520054};\\\", \\\"{x:908,y:721,t:1527189520070};\\\", \\\"{x:961,y:714,t:1527189520087};\\\", \\\"{x:978,y:710,t:1527189520104};\\\", \\\"{x:990,y:707,t:1527189520121};\\\", \\\"{x:992,y:705,t:1527189520148};\\\", \\\"{x:993,y:705,t:1527189520156};\\\", \\\"{x:996,y:701,t:1527189520171};\\\", \\\"{x:1007,y:683,t:1527189520188};\\\", \\\"{x:1018,y:671,t:1527189520205};\\\", \\\"{x:1034,y:657,t:1527189520221};\\\", \\\"{x:1048,y:639,t:1527189520238};\\\", \\\"{x:1058,y:631,t:1527189520255};\\\", \\\"{x:1066,y:622,t:1527189520271};\\\", \\\"{x:1074,y:614,t:1527189520288};\\\", \\\"{x:1089,y:599,t:1527189520305};\\\", \\\"{x:1095,y:593,t:1527189520322};\\\", \\\"{x:1096,y:592,t:1527189520338};\\\", \\\"{x:1095,y:592,t:1527189520356};\\\", \\\"{x:1066,y:611,t:1527189520372};\\\", \\\"{x:921,y:662,t:1527189520388};\\\", \\\"{x:712,y:710,t:1527189520405};\\\", \\\"{x:528,y:754,t:1527189520423};\\\", \\\"{x:380,y:784,t:1527189520438};\\\", \\\"{x:296,y:790,t:1527189520455};\\\", \\\"{x:278,y:790,t:1527189520471};\\\", \\\"{x:278,y:785,t:1527189520499};\\\", \\\"{x:285,y:779,t:1527189520507};\\\", \\\"{x:288,y:773,t:1527189520522};\\\", \\\"{x:293,y:761,t:1527189520537};\\\", \\\"{x:297,y:748,t:1527189520554};\\\", \\\"{x:294,y:729,t:1527189520571};\\\", \\\"{x:292,y:724,t:1527189520587};\\\", \\\"{x:291,y:724,t:1527189520605};\\\", \\\"{x:287,y:725,t:1527189520621};\\\", \\\"{x:285,y:726,t:1527189520638};\\\", \\\"{x:284,y:731,t:1527189520655};\\\", \\\"{x:288,y:733,t:1527189520672};\\\", \\\"{x:294,y:733,t:1527189520688};\\\", \\\"{x:310,y:733,t:1527189520705};\\\", \\\"{x:328,y:733,t:1527189520721};\\\", \\\"{x:342,y:734,t:1527189520739};\\\", \\\"{x:373,y:735,t:1527189520755};\\\", \\\"{x:419,y:744,t:1527189520772};\\\", \\\"{x:437,y:744,t:1527189520788};\\\", \\\"{x:445,y:742,t:1527189520806};\\\", \\\"{x:446,y:742,t:1527189520821};\\\", \\\"{x:449,y:739,t:1527189520839};\\\", \\\"{x:453,y:736,t:1527189520854};\\\", \\\"{x:455,y:735,t:1527189520871};\\\", \\\"{x:457,y:735,t:1527189520955};\\\", \\\"{x:457,y:735,t:1527189521039};\\\" ] }, { \\\"rt\\\": 84432, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1132830, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-01 PM-02 PM-02 PM-02 PM-03 PM-F -F -12 PM-12 PM-12 PM-01 PM-02 PM-02 PM-03 PM-03 PM-04 PM-03 PM-11 AM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:458,y:735,t:1527189523380};\\\", \\\"{x:481,y:756,t:1527189533052};\\\", \\\"{x:520,y:785,t:1527189533067};\\\", \\\"{x:574,y:835,t:1527189533082};\\\", \\\"{x:627,y:915,t:1527189533099};\\\", \\\"{x:651,y:947,t:1527189533110};\\\", \\\"{x:693,y:1008,t:1527189533127};\\\", \\\"{x:713,y:1034,t:1527189533144};\\\", \\\"{x:723,y:1046,t:1527189533161};\\\", \\\"{x:725,y:1049,t:1527189533177};\\\", \\\"{x:727,y:1053,t:1527189533194};\\\", \\\"{x:733,y:1067,t:1527189533211};\\\", \\\"{x:742,y:1084,t:1527189533227};\\\", \\\"{x:753,y:1100,t:1527189533244};\\\", \\\"{x:768,y:1124,t:1527189533260};\\\", \\\"{x:797,y:1159,t:1527189533277};\\\", \\\"{x:823,y:1191,t:1527189533294};\\\", \\\"{x:852,y:1199,t:1527189533311};\\\", \\\"{x:871,y:1199,t:1527189533331};\\\", \\\"{x:874,y:1199,t:1527189533348};\\\", \\\"{x:875,y:1199,t:1527189533420};\\\", \\\"{x:876,y:1197,t:1527189533433};\\\", \\\"{x:879,y:1195,t:1527189533448};\\\", \\\"{x:879,y:1193,t:1527189533468};\\\", \\\"{x:880,y:1193,t:1527189533636};\\\", \\\"{x:941,y:1193,t:1527189534589};\\\", \\\"{x:950,y:1184,t:1527189539717};\\\", \\\"{x:964,y:1169,t:1527189539724};\\\", \\\"{x:973,y:1160,t:1527189539737};\\\", \\\"{x:995,y:1146,t:1527189539755};\\\", \\\"{x:1004,y:1138,t:1527189539771};\\\", \\\"{x:1020,y:1132,t:1527189539788};\\\", \\\"{x:1022,y:1130,t:1527189539804};\\\", \\\"{x:1026,y:1127,t:1527189539893};\\\", \\\"{x:1033,y:1121,t:1527189539905};\\\", \\\"{x:1044,y:1113,t:1527189539921};\\\", \\\"{x:1054,y:1106,t:1527189539937};\\\", \\\"{x:1057,y:1103,t:1527189539955};\\\", \\\"{x:1059,y:1101,t:1527189539972};\\\", \\\"{x:1065,y:1097,t:1527189539987};\\\", \\\"{x:1074,y:1090,t:1527189540005};\\\", \\\"{x:1084,y:1080,t:1527189540022};\\\", \\\"{x:1098,y:1069,t:1527189540037};\\\", \\\"{x:1103,y:1065,t:1527189540055};\\\", \\\"{x:1106,y:1061,t:1527189540071};\\\", \\\"{x:1107,y:1061,t:1527189540087};\\\", \\\"{x:1113,y:1056,t:1527189540105};\\\", \\\"{x:1128,y:1048,t:1527189540122};\\\", \\\"{x:1139,y:1039,t:1527189540138};\\\", \\\"{x:1149,y:1036,t:1527189540155};\\\", \\\"{x:1167,y:1028,t:1527189540171};\\\", \\\"{x:1169,y:1026,t:1527189540187};\\\", \\\"{x:1172,y:1025,t:1527189540205};\\\", \\\"{x:1172,y:1024,t:1527189540251};\\\", \\\"{x:1173,y:1023,t:1527189540261};\\\", \\\"{x:1177,y:1021,t:1527189540272};\\\", \\\"{x:1184,y:1018,t:1527189540287};\\\", \\\"{x:1192,y:1015,t:1527189540304};\\\", \\\"{x:1196,y:1013,t:1527189540321};\\\", \\\"{x:1201,y:1011,t:1527189540338};\\\", \\\"{x:1204,y:1009,t:1527189540354};\\\", \\\"{x:1205,y:1008,t:1527189540371};\\\", \\\"{x:1206,y:1008,t:1527189540395};\\\", \\\"{x:1207,y:1007,t:1527189540404};\\\", \\\"{x:1211,y:1004,t:1527189540421};\\\", \\\"{x:1215,y:1004,t:1527189540439};\\\", \\\"{x:1222,y:1001,t:1527189540455};\\\", \\\"{x:1227,y:999,t:1527189540472};\\\", \\\"{x:1231,y:996,t:1527189540489};\\\", \\\"{x:1237,y:995,t:1527189540505};\\\", \\\"{x:1248,y:991,t:1527189540522};\\\", \\\"{x:1257,y:988,t:1527189540539};\\\", \\\"{x:1268,y:987,t:1527189540555};\\\", \\\"{x:1283,y:979,t:1527189540572};\\\", \\\"{x:1290,y:977,t:1527189540588};\\\", \\\"{x:1297,y:975,t:1527189540605};\\\", \\\"{x:1302,y:974,t:1527189540623};\\\", \\\"{x:1304,y:973,t:1527189540639};\\\", \\\"{x:1305,y:973,t:1527189540676};\\\", \\\"{x:1313,y:971,t:1527189540688};\\\", \\\"{x:1327,y:970,t:1527189540705};\\\", \\\"{x:1340,y:968,t:1527189540722};\\\", \\\"{x:1353,y:966,t:1527189540739};\\\", \\\"{x:1360,y:965,t:1527189540755};\\\", \\\"{x:1365,y:964,t:1527189540772};\\\", \\\"{x:1369,y:964,t:1527189540789};\\\", \\\"{x:1370,y:964,t:1527189540806};\\\", \\\"{x:1373,y:964,t:1527189540822};\\\", \\\"{x:1374,y:964,t:1527189540839};\\\", \\\"{x:1377,y:964,t:1527189540856};\\\", \\\"{x:1381,y:964,t:1527189540872};\\\", \\\"{x:1383,y:964,t:1527189540889};\\\", \\\"{x:1392,y:964,t:1527189540905};\\\", \\\"{x:1405,y:964,t:1527189540922};\\\", \\\"{x:1415,y:964,t:1527189540939};\\\", \\\"{x:1422,y:964,t:1527189540956};\\\", \\\"{x:1428,y:964,t:1527189540972};\\\", \\\"{x:1431,y:964,t:1527189540989};\\\", \\\"{x:1435,y:964,t:1527189541006};\\\", \\\"{x:1440,y:963,t:1527189541021};\\\", \\\"{x:1445,y:963,t:1527189541039};\\\", \\\"{x:1452,y:963,t:1527189541055};\\\", \\\"{x:1458,y:963,t:1527189541072};\\\", \\\"{x:1466,y:962,t:1527189541089};\\\", \\\"{x:1470,y:961,t:1527189541106};\\\", \\\"{x:1472,y:961,t:1527189541124};\\\", \\\"{x:1473,y:961,t:1527189541493};\\\", \\\"{x:1476,y:961,t:1527189541505};\\\", \\\"{x:1477,y:961,t:1527189541523};\\\", \\\"{x:1479,y:961,t:1527189541539};\\\", \\\"{x:1480,y:961,t:1527189541556};\\\", \\\"{x:1481,y:961,t:1527189559889};\\\", \\\"{x:1460,y:954,t:1527189559895};\\\", \\\"{x:1423,y:939,t:1527189559908};\\\", \\\"{x:1369,y:910,t:1527189559925};\\\", \\\"{x:1335,y:888,t:1527189559942};\\\", \\\"{x:1297,y:866,t:1527189559958};\\\", \\\"{x:1271,y:851,t:1527189559975};\\\", \\\"{x:1268,y:851,t:1527189559993};\\\", \\\"{x:1267,y:850,t:1527189560072};\\\", \\\"{x:1267,y:849,t:1527189560079};\\\", \\\"{x:1267,y:846,t:1527189560092};\\\", \\\"{x:1267,y:844,t:1527189560109};\\\", \\\"{x:1269,y:840,t:1527189560125};\\\", \\\"{x:1279,y:835,t:1527189560142};\\\", \\\"{x:1291,y:830,t:1527189560160};\\\", \\\"{x:1294,y:827,t:1527189560175};\\\", \\\"{x:1296,y:825,t:1527189560192};\\\", \\\"{x:1296,y:821,t:1527189560210};\\\", \\\"{x:1296,y:818,t:1527189560225};\\\", \\\"{x:1296,y:810,t:1527189560242};\\\", \\\"{x:1302,y:794,t:1527189560259};\\\", \\\"{x:1306,y:790,t:1527189560276};\\\", \\\"{x:1309,y:788,t:1527189560292};\\\", \\\"{x:1312,y:787,t:1527189560309};\\\", \\\"{x:1312,y:786,t:1527189560360};\\\", \\\"{x:1322,y:796,t:1527189560375};\\\", \\\"{x:1329,y:802,t:1527189560393};\\\", \\\"{x:1336,y:817,t:1527189560410};\\\", \\\"{x:1347,y:828,t:1527189560425};\\\", \\\"{x:1350,y:835,t:1527189560442};\\\", \\\"{x:1351,y:838,t:1527189560459};\\\", \\\"{x:1350,y:847,t:1527189560476};\\\", \\\"{x:1347,y:864,t:1527189560492};\\\", \\\"{x:1345,y:890,t:1527189560509};\\\", \\\"{x:1346,y:913,t:1527189560527};\\\", \\\"{x:1354,y:928,t:1527189560542};\\\", \\\"{x:1357,y:933,t:1527189560559};\\\", \\\"{x:1357,y:934,t:1527189560632};\\\", \\\"{x:1357,y:940,t:1527189560643};\\\", \\\"{x:1359,y:952,t:1527189560659};\\\", \\\"{x:1360,y:961,t:1527189560676};\\\", \\\"{x:1360,y:964,t:1527189560692};\\\", \\\"{x:1359,y:961,t:1527189560768};\\\", \\\"{x:1359,y:960,t:1527189560783};\\\", \\\"{x:1359,y:958,t:1527189560792};\\\", \\\"{x:1357,y:956,t:1527189560810};\\\", \\\"{x:1356,y:956,t:1527189560826};\\\", \\\"{x:1355,y:956,t:1527189560999};\\\", \\\"{x:1355,y:957,t:1527189561015};\\\", \\\"{x:1355,y:958,t:1527189561047};\\\", \\\"{x:1353,y:959,t:1527189561059};\\\", \\\"{x:1353,y:960,t:1527189561077};\\\", \\\"{x:1353,y:961,t:1527189561111};\\\", \\\"{x:1353,y:963,t:1527189561126};\\\", \\\"{x:1354,y:968,t:1527189561143};\\\", \\\"{x:1354,y:972,t:1527189561160};\\\", \\\"{x:1357,y:976,t:1527189561176};\\\", \\\"{x:1359,y:982,t:1527189561193};\\\", \\\"{x:1367,y:990,t:1527189561209};\\\", \\\"{x:1379,y:998,t:1527189561226};\\\", \\\"{x:1385,y:1003,t:1527189561243};\\\", \\\"{x:1386,y:1003,t:1527189561279};\\\", \\\"{x:1389,y:1003,t:1527189561293};\\\", \\\"{x:1396,y:1002,t:1527189561310};\\\", \\\"{x:1406,y:997,t:1527189561326};\\\", \\\"{x:1415,y:993,t:1527189561343};\\\", \\\"{x:1416,y:992,t:1527189561432};\\\", \\\"{x:1417,y:989,t:1527189561443};\\\", \\\"{x:1420,y:980,t:1527189561460};\\\", \\\"{x:1423,y:973,t:1527189561477};\\\", \\\"{x:1424,y:970,t:1527189561493};\\\", \\\"{x:1424,y:969,t:1527189561510};\\\", \\\"{x:1424,y:967,t:1527189561608};\\\", \\\"{x:1424,y:965,t:1527189561615};\\\", \\\"{x:1424,y:963,t:1527189561627};\\\", \\\"{x:1425,y:962,t:1527189561647};\\\", \\\"{x:1426,y:962,t:1527189561711};\\\", \\\"{x:1433,y:965,t:1527189561727};\\\", \\\"{x:1436,y:968,t:1527189561743};\\\", \\\"{x:1438,y:970,t:1527189561760};\\\", \\\"{x:1439,y:971,t:1527189561778};\\\", \\\"{x:1440,y:971,t:1527189561815};\\\", \\\"{x:1445,y:973,t:1527189561827};\\\", \\\"{x:1457,y:978,t:1527189561843};\\\", \\\"{x:1463,y:980,t:1527189561860};\\\", \\\"{x:1468,y:982,t:1527189561877};\\\", \\\"{x:1473,y:983,t:1527189561893};\\\", \\\"{x:1475,y:984,t:1527189561910};\\\", \\\"{x:1480,y:986,t:1527189561928};\\\", \\\"{x:1483,y:986,t:1527189561943};\\\", \\\"{x:1486,y:986,t:1527189561960};\\\", \\\"{x:1487,y:986,t:1527189561977};\\\", \\\"{x:1489,y:985,t:1527189561993};\\\", \\\"{x:1490,y:985,t:1527189562010};\\\", \\\"{x:1490,y:984,t:1527189562080};\\\", \\\"{x:1491,y:982,t:1527189562093};\\\", \\\"{x:1491,y:979,t:1527189562110};\\\", \\\"{x:1491,y:975,t:1527189562127};\\\", \\\"{x:1491,y:973,t:1527189562144};\\\", \\\"{x:1491,y:970,t:1527189562160};\\\", \\\"{x:1491,y:969,t:1527189562183};\\\", \\\"{x:1491,y:968,t:1527189562195};\\\", \\\"{x:1491,y:967,t:1527189562215};\\\", \\\"{x:1490,y:966,t:1527189562227};\\\", \\\"{x:1490,y:967,t:1527189562520};\\\", \\\"{x:1490,y:969,t:1527189562536};\\\", \\\"{x:1491,y:969,t:1527189562544};\\\", \\\"{x:1494,y:970,t:1527189562561};\\\", \\\"{x:1495,y:972,t:1527189562577};\\\", \\\"{x:1495,y:973,t:1527189562594};\\\", \\\"{x:1497,y:973,t:1527189562611};\\\", \\\"{x:1498,y:974,t:1527189562631};\\\", \\\"{x:1500,y:976,t:1527189562644};\\\", \\\"{x:1504,y:979,t:1527189562663};\\\", \\\"{x:1505,y:979,t:1527189562678};\\\", \\\"{x:1510,y:984,t:1527189562695};\\\", \\\"{x:1521,y:986,t:1527189562711};\\\", \\\"{x:1527,y:987,t:1527189562727};\\\", \\\"{x:1529,y:988,t:1527189562744};\\\", \\\"{x:1533,y:988,t:1527189562761};\\\", \\\"{x:1539,y:989,t:1527189562777};\\\", \\\"{x:1543,y:991,t:1527189562794};\\\", \\\"{x:1547,y:991,t:1527189562811};\\\", \\\"{x:1549,y:991,t:1527189562827};\\\", \\\"{x:1550,y:991,t:1527189562844};\\\", \\\"{x:1552,y:991,t:1527189562887};\\\", \\\"{x:1553,y:991,t:1527189562895};\\\", \\\"{x:1555,y:989,t:1527189562911};\\\", \\\"{x:1557,y:986,t:1527189562928};\\\", \\\"{x:1558,y:982,t:1527189562945};\\\", \\\"{x:1559,y:980,t:1527189562961};\\\", \\\"{x:1559,y:979,t:1527189562978};\\\", \\\"{x:1560,y:978,t:1527189562994};\\\", \\\"{x:1560,y:974,t:1527189563023};\\\", \\\"{x:1560,y:973,t:1527189563047};\\\", \\\"{x:1560,y:972,t:1527189563064};\\\", \\\"{x:1561,y:971,t:1527189563078};\\\", \\\"{x:1561,y:970,t:1527189563158};\\\", \\\"{x:1561,y:969,t:1527189563166};\\\", \\\"{x:1561,y:968,t:1527189563178};\\\", \\\"{x:1560,y:967,t:1527189563198};\\\", \\\"{x:1559,y:967,t:1527189563214};\\\", \\\"{x:1558,y:965,t:1527189563228};\\\", \\\"{x:1556,y:965,t:1527189563244};\\\", \\\"{x:1555,y:964,t:1527189563262};\\\", \\\"{x:1555,y:962,t:1527189571999};\\\", \\\"{x:1555,y:952,t:1527189572007};\\\", \\\"{x:1555,y:949,t:1527189572019};\\\", \\\"{x:1555,y:948,t:1527189572036};\\\", \\\"{x:1554,y:947,t:1527189572143};\\\", \\\"{x:1553,y:947,t:1527189572152};\\\", \\\"{x:1546,y:949,t:1527189573767};\\\", \\\"{x:1534,y:951,t:1527189573775};\\\", \\\"{x:1527,y:956,t:1527189573787};\\\", \\\"{x:1507,y:956,t:1527189573804};\\\", \\\"{x:1488,y:953,t:1527189573821};\\\", \\\"{x:1471,y:948,t:1527189573837};\\\", \\\"{x:1459,y:947,t:1527189573854};\\\", \\\"{x:1455,y:947,t:1527189573871};\\\", \\\"{x:1454,y:946,t:1527189574062};\\\", \\\"{x:1453,y:941,t:1527189574070};\\\", \\\"{x:1442,y:927,t:1527189574087};\\\", \\\"{x:1429,y:910,t:1527189574103};\\\", \\\"{x:1412,y:889,t:1527189574120};\\\", \\\"{x:1399,y:867,t:1527189574138};\\\", \\\"{x:1387,y:845,t:1527189574154};\\\", \\\"{x:1366,y:826,t:1527189574171};\\\", \\\"{x:1345,y:808,t:1527189574187};\\\", \\\"{x:1323,y:794,t:1527189574203};\\\", \\\"{x:1306,y:777,t:1527189574221};\\\", \\\"{x:1297,y:764,t:1527189574238};\\\", \\\"{x:1287,y:749,t:1527189574253};\\\", \\\"{x:1283,y:741,t:1527189574271};\\\", \\\"{x:1283,y:740,t:1527189574287};\\\", \\\"{x:1284,y:735,t:1527189574303};\\\", \\\"{x:1286,y:732,t:1527189574321};\\\", \\\"{x:1296,y:721,t:1527189574337};\\\", \\\"{x:1305,y:705,t:1527189574354};\\\", \\\"{x:1325,y:691,t:1527189574371};\\\", \\\"{x:1346,y:679,t:1527189574388};\\\", \\\"{x:1372,y:670,t:1527189574405};\\\", \\\"{x:1380,y:670,t:1527189574421};\\\", \\\"{x:1383,y:670,t:1527189574438};\\\", \\\"{x:1389,y:674,t:1527189574455};\\\", \\\"{x:1391,y:676,t:1527189574471};\\\", \\\"{x:1392,y:677,t:1527189574488};\\\", \\\"{x:1392,y:679,t:1527189574575};\\\", \\\"{x:1390,y:681,t:1527189574588};\\\", \\\"{x:1375,y:692,t:1527189574605};\\\", \\\"{x:1358,y:702,t:1527189574621};\\\", \\\"{x:1343,y:712,t:1527189574638};\\\", \\\"{x:1332,y:718,t:1527189574655};\\\", \\\"{x:1331,y:719,t:1527189574671};\\\", \\\"{x:1330,y:721,t:1527189574719};\\\", \\\"{x:1327,y:728,t:1527189574727};\\\", \\\"{x:1326,y:731,t:1527189574738};\\\", \\\"{x:1319,y:737,t:1527189574755};\\\", \\\"{x:1316,y:739,t:1527189574772};\\\", \\\"{x:1314,y:739,t:1527189574788};\\\", \\\"{x:1314,y:737,t:1527189574855};\\\", \\\"{x:1317,y:734,t:1527189574871};\\\", \\\"{x:1321,y:729,t:1527189574888};\\\", \\\"{x:1326,y:724,t:1527189574904};\\\", \\\"{x:1328,y:721,t:1527189574922};\\\", \\\"{x:1329,y:721,t:1527189574938};\\\", \\\"{x:1332,y:718,t:1527189574954};\\\", \\\"{x:1335,y:716,t:1527189574972};\\\", \\\"{x:1341,y:712,t:1527189574988};\\\", \\\"{x:1347,y:706,t:1527189575005};\\\", \\\"{x:1349,y:703,t:1527189575022};\\\", \\\"{x:1349,y:702,t:1527189575040};\\\", \\\"{x:1349,y:701,t:1527189575319};\\\", \\\"{x:1349,y:700,t:1527189575335};\\\", \\\"{x:1350,y:699,t:1527189575599};\\\", \\\"{x:1351,y:699,t:1527189575615};\\\", \\\"{x:1352,y:699,t:1527189575663};\\\", \\\"{x:1352,y:700,t:1527189575679};\\\", \\\"{x:1352,y:702,t:1527189575690};\\\", \\\"{x:1352,y:706,t:1527189575706};\\\", \\\"{x:1353,y:714,t:1527189575722};\\\", \\\"{x:1354,y:719,t:1527189575739};\\\", \\\"{x:1356,y:725,t:1527189575756};\\\", \\\"{x:1356,y:737,t:1527189575772};\\\", \\\"{x:1356,y:749,t:1527189575789};\\\", \\\"{x:1356,y:759,t:1527189575806};\\\", \\\"{x:1356,y:770,t:1527189575822};\\\", \\\"{x:1358,y:788,t:1527189575839};\\\", \\\"{x:1360,y:793,t:1527189575856};\\\", \\\"{x:1363,y:797,t:1527189575872};\\\", \\\"{x:1363,y:800,t:1527189575889};\\\", \\\"{x:1364,y:802,t:1527189575906};\\\", \\\"{x:1364,y:803,t:1527189575922};\\\", \\\"{x:1364,y:804,t:1527189575939};\\\", \\\"{x:1364,y:809,t:1527189575956};\\\", \\\"{x:1367,y:814,t:1527189575973};\\\", \\\"{x:1367,y:827,t:1527189575989};\\\", \\\"{x:1369,y:837,t:1527189576006};\\\", \\\"{x:1370,y:855,t:1527189576023};\\\", \\\"{x:1370,y:860,t:1527189576039};\\\", \\\"{x:1371,y:865,t:1527189576056};\\\", \\\"{x:1372,y:866,t:1527189576073};\\\", \\\"{x:1372,y:871,t:1527189576088};\\\", \\\"{x:1371,y:875,t:1527189576106};\\\", \\\"{x:1371,y:879,t:1527189576123};\\\", \\\"{x:1368,y:887,t:1527189576139};\\\", \\\"{x:1368,y:889,t:1527189576156};\\\", \\\"{x:1366,y:895,t:1527189576173};\\\", \\\"{x:1364,y:898,t:1527189576189};\\\", \\\"{x:1363,y:901,t:1527189576206};\\\", \\\"{x:1363,y:903,t:1527189576223};\\\", \\\"{x:1362,y:907,t:1527189576239};\\\", \\\"{x:1362,y:911,t:1527189576256};\\\", \\\"{x:1361,y:918,t:1527189576273};\\\", \\\"{x:1360,y:923,t:1527189576289};\\\", \\\"{x:1360,y:925,t:1527189576305};\\\", \\\"{x:1359,y:928,t:1527189576323};\\\", \\\"{x:1359,y:930,t:1527189576339};\\\", \\\"{x:1358,y:933,t:1527189576356};\\\", \\\"{x:1356,y:938,t:1527189576373};\\\", \\\"{x:1355,y:946,t:1527189576389};\\\", \\\"{x:1354,y:958,t:1527189576406};\\\", \\\"{x:1350,y:974,t:1527189576423};\\\", \\\"{x:1349,y:982,t:1527189576439};\\\", \\\"{x:1346,y:986,t:1527189576457};\\\", \\\"{x:1346,y:988,t:1527189576473};\\\", \\\"{x:1345,y:988,t:1527189576591};\\\", \\\"{x:1345,y:986,t:1527189576606};\\\", \\\"{x:1347,y:972,t:1527189576623};\\\", \\\"{x:1349,y:966,t:1527189576640};\\\", \\\"{x:1352,y:960,t:1527189576656};\\\", \\\"{x:1353,y:960,t:1527189576673};\\\", \\\"{x:1353,y:961,t:1527189577112};\\\", \\\"{x:1355,y:964,t:1527189577123};\\\", \\\"{x:1356,y:967,t:1527189577142};\\\", \\\"{x:1357,y:969,t:1527189577157};\\\", \\\"{x:1360,y:972,t:1527189577172};\\\", \\\"{x:1362,y:973,t:1527189577190};\\\", \\\"{x:1364,y:975,t:1527189577206};\\\", \\\"{x:1366,y:977,t:1527189577223};\\\", \\\"{x:1366,y:978,t:1527189577239};\\\", \\\"{x:1367,y:978,t:1527189577257};\\\", \\\"{x:1368,y:978,t:1527189577278};\\\", \\\"{x:1369,y:979,t:1527189577290};\\\", \\\"{x:1371,y:980,t:1527189577306};\\\", \\\"{x:1373,y:981,t:1527189577323};\\\", \\\"{x:1376,y:983,t:1527189577340};\\\", \\\"{x:1378,y:985,t:1527189577357};\\\", \\\"{x:1379,y:985,t:1527189577374};\\\", \\\"{x:1381,y:985,t:1527189577390};\\\", \\\"{x:1384,y:988,t:1527189577407};\\\", \\\"{x:1385,y:988,t:1527189577430};\\\", \\\"{x:1389,y:989,t:1527189577440};\\\", \\\"{x:1396,y:989,t:1527189577457};\\\", \\\"{x:1402,y:989,t:1527189577474};\\\", \\\"{x:1406,y:989,t:1527189577489};\\\", \\\"{x:1413,y:989,t:1527189577507};\\\", \\\"{x:1415,y:988,t:1527189577524};\\\", \\\"{x:1416,y:987,t:1527189577551};\\\", \\\"{x:1416,y:985,t:1527189577559};\\\", \\\"{x:1416,y:983,t:1527189577574};\\\", \\\"{x:1417,y:979,t:1527189577590};\\\", \\\"{x:1422,y:971,t:1527189577607};\\\", \\\"{x:1423,y:968,t:1527189577625};\\\", \\\"{x:1425,y:964,t:1527189577641};\\\", \\\"{x:1426,y:962,t:1527189577658};\\\", \\\"{x:1426,y:961,t:1527189577674};\\\", \\\"{x:1426,y:960,t:1527189577691};\\\", \\\"{x:1426,y:959,t:1527189577719};\\\", \\\"{x:1428,y:959,t:1527189577831};\\\", \\\"{x:1429,y:959,t:1527189577841};\\\", \\\"{x:1430,y:962,t:1527189577857};\\\", \\\"{x:1431,y:963,t:1527189577874};\\\", \\\"{x:1432,y:965,t:1527189577891};\\\", \\\"{x:1436,y:966,t:1527189577907};\\\", \\\"{x:1437,y:969,t:1527189577924};\\\", \\\"{x:1438,y:969,t:1527189577941};\\\", \\\"{x:1439,y:970,t:1527189577957};\\\", \\\"{x:1441,y:970,t:1527189577991};\\\", \\\"{x:1442,y:971,t:1527189578007};\\\", \\\"{x:1444,y:972,t:1527189578024};\\\", \\\"{x:1445,y:972,t:1527189578041};\\\", \\\"{x:1448,y:973,t:1527189578058};\\\", \\\"{x:1450,y:974,t:1527189578073};\\\", \\\"{x:1452,y:974,t:1527189578090};\\\", \\\"{x:1453,y:974,t:1527189578110};\\\", \\\"{x:1454,y:974,t:1527189578134};\\\", \\\"{x:1455,y:974,t:1527189578142};\\\", \\\"{x:1457,y:974,t:1527189578158};\\\", \\\"{x:1459,y:974,t:1527189578173};\\\", \\\"{x:1464,y:974,t:1527189578190};\\\", \\\"{x:1465,y:974,t:1527189578207};\\\", \\\"{x:1466,y:975,t:1527189578287};\\\", \\\"{x:1467,y:975,t:1527189578312};\\\", \\\"{x:1468,y:975,t:1527189578551};\\\", \\\"{x:1470,y:974,t:1527189578559};\\\", \\\"{x:1475,y:970,t:1527189578575};\\\", \\\"{x:1479,y:967,t:1527189578592};\\\", \\\"{x:1484,y:966,t:1527189578608};\\\", \\\"{x:1487,y:964,t:1527189578625};\\\", \\\"{x:1489,y:963,t:1527189578641};\\\", \\\"{x:1491,y:963,t:1527189578671};\\\", \\\"{x:1492,y:963,t:1527189578687};\\\", \\\"{x:1493,y:961,t:1527189578696};\\\", \\\"{x:1494,y:961,t:1527189578711};\\\", \\\"{x:1495,y:960,t:1527189578725};\\\", \\\"{x:1497,y:959,t:1527189578741};\\\", \\\"{x:1497,y:958,t:1527189578758};\\\", \\\"{x:1497,y:959,t:1527189578966};\\\", \\\"{x:1498,y:961,t:1527189578975};\\\", \\\"{x:1498,y:964,t:1527189578993};\\\", \\\"{x:1498,y:966,t:1527189579009};\\\", \\\"{x:1498,y:968,t:1527189579025};\\\", \\\"{x:1498,y:969,t:1527189579042};\\\", \\\"{x:1500,y:970,t:1527189579057};\\\", \\\"{x:1501,y:971,t:1527189579075};\\\", \\\"{x:1503,y:973,t:1527189579104};\\\", \\\"{x:1504,y:974,t:1527189579119};\\\", \\\"{x:1505,y:975,t:1527189579135};\\\", \\\"{x:1506,y:976,t:1527189579142};\\\", \\\"{x:1507,y:976,t:1527189579158};\\\", \\\"{x:1509,y:978,t:1527189579175};\\\", \\\"{x:1510,y:979,t:1527189579192};\\\", \\\"{x:1511,y:981,t:1527189579208};\\\", \\\"{x:1512,y:981,t:1527189579225};\\\", \\\"{x:1513,y:982,t:1527189579242};\\\", \\\"{x:1515,y:983,t:1527189579271};\\\", \\\"{x:1516,y:983,t:1527189579278};\\\", \\\"{x:1516,y:984,t:1527189579292};\\\", \\\"{x:1517,y:984,t:1527189579319};\\\", \\\"{x:1520,y:984,t:1527189579327};\\\", \\\"{x:1522,y:984,t:1527189579343};\\\", \\\"{x:1523,y:984,t:1527189579359};\\\", \\\"{x:1524,y:984,t:1527189579375};\\\", \\\"{x:1525,y:984,t:1527189579392};\\\", \\\"{x:1526,y:984,t:1527189579415};\\\", \\\"{x:1528,y:984,t:1527189579425};\\\", \\\"{x:1529,y:984,t:1527189579442};\\\", \\\"{x:1533,y:982,t:1527189579459};\\\", \\\"{x:1534,y:980,t:1527189579475};\\\", \\\"{x:1535,y:978,t:1527189579492};\\\", \\\"{x:1536,y:977,t:1527189579509};\\\", \\\"{x:1536,y:976,t:1527189579535};\\\", \\\"{x:1536,y:974,t:1527189579543};\\\", \\\"{x:1536,y:971,t:1527189579559};\\\", \\\"{x:1536,y:969,t:1527189579575};\\\", \\\"{x:1536,y:968,t:1527189579599};\\\", \\\"{x:1538,y:967,t:1527189579816};\\\", \\\"{x:1540,y:969,t:1527189579826};\\\", \\\"{x:1544,y:972,t:1527189579842};\\\", \\\"{x:1547,y:976,t:1527189579859};\\\", \\\"{x:1550,y:980,t:1527189579876};\\\", \\\"{x:1551,y:982,t:1527189579892};\\\", \\\"{x:1554,y:984,t:1527189579909};\\\", \\\"{x:1555,y:986,t:1527189579927};\\\", \\\"{x:1559,y:989,t:1527189579942};\\\", \\\"{x:1566,y:993,t:1527189579959};\\\", \\\"{x:1568,y:996,t:1527189579976};\\\", \\\"{x:1570,y:996,t:1527189579992};\\\", \\\"{x:1572,y:997,t:1527189580009};\\\", \\\"{x:1574,y:997,t:1527189580031};\\\", \\\"{x:1575,y:997,t:1527189580047};\\\", \\\"{x:1577,y:997,t:1527189580063};\\\", \\\"{x:1581,y:997,t:1527189580076};\\\", \\\"{x:1586,y:997,t:1527189580093};\\\", \\\"{x:1592,y:997,t:1527189580109};\\\", \\\"{x:1595,y:996,t:1527189580126};\\\", \\\"{x:1599,y:996,t:1527189580143};\\\", \\\"{x:1600,y:996,t:1527189580159};\\\", \\\"{x:1602,y:996,t:1527189580176};\\\", \\\"{x:1604,y:995,t:1527189580207};\\\", \\\"{x:1606,y:994,t:1527189580231};\\\", \\\"{x:1607,y:993,t:1527189580247};\\\", \\\"{x:1608,y:992,t:1527189580259};\\\", \\\"{x:1609,y:991,t:1527189580276};\\\", \\\"{x:1610,y:988,t:1527189580293};\\\", \\\"{x:1611,y:987,t:1527189580309};\\\", \\\"{x:1612,y:985,t:1527189580326};\\\", \\\"{x:1613,y:983,t:1527189580344};\\\", \\\"{x:1614,y:982,t:1527189580359};\\\", \\\"{x:1614,y:981,t:1527189580376};\\\", \\\"{x:1615,y:979,t:1527189580393};\\\", \\\"{x:1616,y:976,t:1527189580409};\\\", \\\"{x:1616,y:974,t:1527189580480};\\\", \\\"{x:1616,y:973,t:1527189580493};\\\", \\\"{x:1616,y:971,t:1527189580510};\\\", \\\"{x:1616,y:970,t:1527189580526};\\\", \\\"{x:1616,y:968,t:1527189580543};\\\", \\\"{x:1615,y:967,t:1527189580560};\\\", \\\"{x:1607,y:967,t:1527189583031};\\\", \\\"{x:1592,y:967,t:1527189583045};\\\", \\\"{x:1560,y:971,t:1527189583064};\\\", \\\"{x:1553,y:971,t:1527189583079};\\\", \\\"{x:1540,y:971,t:1527189583094};\\\", \\\"{x:1539,y:971,t:1527189583112};\\\", \\\"{x:1538,y:970,t:1527189583167};\\\", \\\"{x:1538,y:967,t:1527189583183};\\\", \\\"{x:1536,y:965,t:1527189583196};\\\", \\\"{x:1527,y:960,t:1527189583212};\\\", \\\"{x:1521,y:958,t:1527189583228};\\\", \\\"{x:1519,y:957,t:1527189583244};\\\", \\\"{x:1517,y:957,t:1527189583343};\\\", \\\"{x:1514,y:956,t:1527189583350};\\\", \\\"{x:1507,y:956,t:1527189583362};\\\", \\\"{x:1498,y:956,t:1527189583379};\\\", \\\"{x:1491,y:956,t:1527189583395};\\\", \\\"{x:1488,y:956,t:1527189583412};\\\", \\\"{x:1487,y:956,t:1527189583429};\\\", \\\"{x:1485,y:956,t:1527189583536};\\\", \\\"{x:1484,y:956,t:1527189583551};\\\", \\\"{x:1482,y:956,t:1527189583563};\\\", \\\"{x:1480,y:958,t:1527189583579};\\\", \\\"{x:1479,y:959,t:1527189583595};\\\", \\\"{x:1477,y:959,t:1527189604400};\\\", \\\"{x:1472,y:959,t:1527189604413};\\\", \\\"{x:1460,y:962,t:1527189604431};\\\", \\\"{x:1438,y:967,t:1527189604447};\\\", \\\"{x:1371,y:975,t:1527189604463};\\\", \\\"{x:1267,y:981,t:1527189604481};\\\", \\\"{x:1154,y:981,t:1527189604497};\\\", \\\"{x:1039,y:975,t:1527189604514};\\\", \\\"{x:925,y:959,t:1527189604530};\\\", \\\"{x:847,y:946,t:1527189604546};\\\", \\\"{x:804,y:939,t:1527189604563};\\\", \\\"{x:782,y:934,t:1527189604580};\\\", \\\"{x:755,y:925,t:1527189604597};\\\", \\\"{x:727,y:920,t:1527189604615};\\\", \\\"{x:724,y:919,t:1527189604630};\\\", \\\"{x:719,y:916,t:1527189604647};\\\", \\\"{x:703,y:909,t:1527189604664};\\\", \\\"{x:664,y:901,t:1527189604680};\\\", \\\"{x:567,y:872,t:1527189604696};\\\", \\\"{x:434,y:829,t:1527189604714};\\\", \\\"{x:290,y:765,t:1527189604730};\\\", \\\"{x:170,y:698,t:1527189604747};\\\", \\\"{x:79,y:618,t:1527189604766};\\\", \\\"{x:30,y:541,t:1527189604781};\\\", \\\"{x:8,y:460,t:1527189604797};\\\", \\\"{x:8,y:391,t:1527189604811};\\\", \\\"{x:16,y:309,t:1527189604827};\\\", \\\"{x:51,y:226,t:1527189604843};\\\", \\\"{x:91,y:138,t:1527189604861};\\\", \\\"{x:140,y:58,t:1527189604877};\\\", \\\"{x:156,y:31,t:1527189604894};\\\", \\\"{x:187,y:0,t:1527189604911};\\\", \\\"{x:194,y:0,t:1527189604928};\\\", \\\"{x:200,y:0,t:1527189604943};\\\", \\\"{x:220,y:0,t:1527189604960};\\\", \\\"{x:280,y:0,t:1527189604978};\\\", \\\"{x:371,y:26,t:1527189604994};\\\", \\\"{x:482,y:57,t:1527189605011};\\\", \\\"{x:585,y:92,t:1527189605028};\\\", \\\"{x:689,y:128,t:1527189605045};\\\", \\\"{x:776,y:176,t:1527189605063};\\\", \\\"{x:813,y:205,t:1527189605077};\\\", \\\"{x:843,y:232,t:1527189605094};\\\", \\\"{x:853,y:247,t:1527189605110};\\\", \\\"{x:857,y:258,t:1527189605128};\\\", \\\"{x:858,y:261,t:1527189605145};\\\", \\\"{x:859,y:264,t:1527189605160};\\\", \\\"{x:859,y:267,t:1527189605177};\\\", \\\"{x:859,y:281,t:1527189605194};\\\", \\\"{x:860,y:303,t:1527189605211};\\\", \\\"{x:862,y:326,t:1527189605227};\\\", \\\"{x:867,y:342,t:1527189605244};\\\", \\\"{x:868,y:350,t:1527189605260};\\\", \\\"{x:868,y:360,t:1527189605277};\\\", \\\"{x:865,y:371,t:1527189605294};\\\", \\\"{x:853,y:393,t:1527189605311};\\\", \\\"{x:842,y:416,t:1527189605327};\\\", \\\"{x:822,y:447,t:1527189605345};\\\", \\\"{x:804,y:471,t:1527189605361};\\\", \\\"{x:789,y:486,t:1527189605378};\\\", \\\"{x:767,y:498,t:1527189605394};\\\", \\\"{x:738,y:507,t:1527189605412};\\\", \\\"{x:697,y:523,t:1527189605428};\\\", \\\"{x:667,y:532,t:1527189605444};\\\", \\\"{x:639,y:538,t:1527189605459};\\\", \\\"{x:627,y:538,t:1527189605479};\\\", \\\"{x:626,y:538,t:1527189605525};\\\", \\\"{x:622,y:538,t:1527189605534};\\\", \\\"{x:612,y:538,t:1527189605545};\\\", \\\"{x:594,y:538,t:1527189605561};\\\", \\\"{x:581,y:538,t:1527189605578};\\\", \\\"{x:576,y:537,t:1527189605594};\\\", \\\"{x:576,y:535,t:1527189605614};\\\", \\\"{x:576,y:531,t:1527189605629};\\\", \\\"{x:582,y:525,t:1527189605644};\\\", \\\"{x:595,y:516,t:1527189605662};\\\", \\\"{x:600,y:513,t:1527189605678};\\\", \\\"{x:601,y:513,t:1527189605791};\\\", \\\"{x:602,y:513,t:1527189605799};\\\", \\\"{x:603,y:513,t:1527189605838};\\\", \\\"{x:603,y:516,t:1527189605950};\\\", \\\"{x:601,y:528,t:1527189605962};\\\", \\\"{x:588,y:552,t:1527189605979};\\\", \\\"{x:576,y:588,t:1527189605996};\\\", \\\"{x:564,y:616,t:1527189606012};\\\", \\\"{x:556,y:639,t:1527189606028};\\\", \\\"{x:549,y:669,t:1527189606045};\\\", \\\"{x:548,y:679,t:1527189606061};\\\", \\\"{x:548,y:684,t:1527189606079};\\\", \\\"{x:548,y:687,t:1527189606095};\\\", \\\"{x:547,y:691,t:1527189606112};\\\", \\\"{x:545,y:692,t:1527189606134};\\\", \\\"{x:544,y:693,t:1527189606157};\\\", \\\"{x:541,y:694,t:1527189606182};\\\", \\\"{x:540,y:696,t:1527189606195};\\\", \\\"{x:537,y:702,t:1527189606212};\\\", \\\"{x:530,y:719,t:1527189606229};\\\", \\\"{x:517,y:752,t:1527189606247};\\\", \\\"{x:510,y:776,t:1527189606264};\\\", \\\"{x:504,y:790,t:1527189606279};\\\", \\\"{x:504,y:791,t:1527189606295};\\\", \\\"{x:504,y:789,t:1527189606358};\\\", \\\"{x:504,y:788,t:1527189606366};\\\", \\\"{x:504,y:787,t:1527189606430};\\\", \\\"{x:504,y:784,t:1527189606486};\\\", \\\"{x:505,y:778,t:1527189606496};\\\", \\\"{x:510,y:767,t:1527189606514};\\\", \\\"{x:514,y:765,t:1527189606529};\\\", \\\"{x:515,y:765,t:1527189606546};\\\" ] }, { \\\"rt\\\": 29520, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1163882, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Compare the various start times to see who's breaks overlap and who starts work and who is finished up for the day.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5122, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1170011, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 21735, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1192763, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 17931, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1212043, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"HZWEH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"HZWEH\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 221, dom: 693, initialDom: 799",
  "javascriptErrors": []
}