var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6fbe76fd94d466bdbf7cce077e7bf595",
  "created": "2018-06-04T13:23:54.6279721-07:00",
  "lastActivity": "2018-06-04T13:24:09.7262202-07:00",
  "pageViews": [
    {
      "id": "06045476e2e2111b0c017cc2d31b5ba55ec83233",
      "startTime": "2018-06-04T13:23:54.6279721-07:00",
      "endTime": "2018-06-04T13:24:09.7262202-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 15242,
      "engagementTime": 13600,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15242,
  "engagementTime": 13600,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VVH1B",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "50f797762ec98b3f8024dcfec98a44d3",
  "gdpr": false
}