var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8e73fbc15d24e55360ed30b6de8cca62",
  "created": "2018-05-21T10:16:24.1332621-07:00",
  "lastActivity": "2018-05-21T10:16:34.8387971-07:00",
  "pageViews": [
    {
      "id": "05212430e2c142d562b1d8a567b19a5dd1756ab7",
      "startTime": "2018-05-21T10:16:24.2986844-07:00",
      "endTime": "2018-05-21T10:16:34.8387971-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 10754,
      "engagementTime": 10752,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10754,
  "engagementTime": 10752,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8MVD2",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1a1f3e987c3a07b21c4a48554b159610",
  "gdpr": false
}