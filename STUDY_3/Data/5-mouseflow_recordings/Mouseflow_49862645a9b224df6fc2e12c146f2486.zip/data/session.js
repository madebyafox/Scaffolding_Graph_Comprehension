var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "49862645a9b224df6fc2e12c146f2486",
  "created": "2018-06-01T10:09:46.87546-07:00",
  "lastActivity": "2018-06-01T10:10:43.9618365-07:00",
  "pageViews": [
    {
      "id": "06014784270d88d24a2200c6b18a7d7f19cba35d",
      "startTime": "2018-06-01T10:09:46.8908365-07:00",
      "endTime": "2018-06-01T10:10:43.9618365-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 57071,
      "engagementTime": 43521,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 57071,
  "engagementTime": 43521,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZAOCZ",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "cc70d9ef879b832c0f9510477c6e4d14",
  "gdpr": false
}