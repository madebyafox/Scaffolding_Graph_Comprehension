var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e94640ab550f075e31c8a082bcbf462b",
  "created": "2018-05-25T10:20:10.9525756-07:00",
  "lastActivity": "2018-05-25T10:21:22.0855756-07:00",
  "pageViews": [
    {
      "id": "052511635886740b9bf07bc935c8556aaa5fa377",
      "startTime": "2018-05-25T10:20:10.9525756-07:00",
      "endTime": "2018-05-25T10:21:22.0855756-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 71133,
      "engagementTime": 68724,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 71133,
  "engagementTime": 68724,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=FL092",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "aaf1ce83882fa7975e2a7a6fa5adb14d",
  "gdpr": false
}