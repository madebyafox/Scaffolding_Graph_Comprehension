var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "24448cb106b91f87c675cacc4bb09dbb",
  "created": "2018-05-22T13:15:53.3805888-07:00",
  "lastActivity": "2018-05-22T13:16:16.5898056-07:00",
  "pageViews": [
    {
      "id": "0522535767227575b97a5a72e2e3cdcfd0c46e54",
      "startTime": "2018-05-22T13:15:53.4438056-07:00",
      "endTime": "2018-05-22T13:16:16.5898056-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 23146,
      "engagementTime": 23009,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 23146,
  "engagementTime": 23009,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=67NP2",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ea33c5ceb87cce2eefa5cbdc641b848b",
  "gdpr": false
}