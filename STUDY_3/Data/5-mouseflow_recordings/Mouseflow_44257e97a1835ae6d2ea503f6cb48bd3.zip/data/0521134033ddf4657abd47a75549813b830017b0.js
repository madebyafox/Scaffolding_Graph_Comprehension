var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0521134033ddf4657abd47a75549813b830017b0"] = {
  "startTime": "2018-05-21T20:19:13.3110158Z",
  "websitePageUrl": "/16",
  "visitTime": 74046,
  "engagementTime": 73598,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "44257e97a1835ae6d2ea503f6cb48bd3",
    "created": "2018-05-21T20:19:13.1711219+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=5GELG",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0fd014f728b9ec9cb8b3c3ed1050a6e7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/44257e97a1835ae6d2ea503f6cb48bd3/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 467,
      "y": 739
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 41581,
      "y": 40495,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 452,
      "y": 732
    },
    {
      "t": 1137,
      "e": 1137,
      "ty": 6,
      "x": 384,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 1154,
      "e": 1154,
      "ty": 7,
      "x": 362,
      "y": 626,
      "ta": "#strategyButton"
    },
    {
      "t": 1187,
      "e": 1187,
      "ty": 6,
      "x": 324,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 324,
      "y": 588
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 23595,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 306,
      "y": 561
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 304,
      "y": 557
    },
    {
      "t": 1488,
      "e": 1488,
      "ty": 3,
      "x": 304,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1489,
      "e": 1489,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 23258,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 4,
      "x": 23258,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 5,
      "x": 304,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 303,
      "y": 556
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 303,
      "y": 555
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 23145,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4114,
      "e": 4114,
      "ty": 3,
      "x": 303,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4289,
      "e": 4289,
      "ty": 4,
      "x": 23145,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4289,
      "e": 4289,
      "ty": 5,
      "x": 303,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5185,
      "e": 5185,
      "ty": 3,
      "x": 303,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5352,
      "e": 5352,
      "ty": 4,
      "x": 23145,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5352,
      "e": 5352,
      "ty": 5,
      "x": 303,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 307,
      "y": 553
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 23595,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7044,
      "e": 7044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7508,
      "e": 7508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7509,
      "e": 7509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7605,
      "e": 7605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7612,
      "e": 7612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7989,
      "e": 7989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7989,
      "e": 7989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8068,
      "e": 8068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 8180,
      "e": 8180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8181,
      "e": 8181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8324,
      "e": 8324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 8404,
      "e": 8404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8484,
      "e": 8484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8485,
      "e": 8485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look "
    },
    {
      "t": 8676,
      "e": 8676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8693,
      "e": 8693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8693,
      "e": 8693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8803,
      "e": 8803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look a"
    },
    {
      "t": 8852,
      "e": 8852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8852,
      "e": 8852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8884,
      "e": 8884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 8992,
      "e": 8992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8992,
      "e": 8992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9011,
      "e": 9011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9108,
      "e": 9108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9108,
      "e": 9108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9164,
      "e": 9164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9212,
      "e": 9212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9469,
      "e": 9469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9469,
      "e": 9469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9627,
      "e": 9627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9627,
      "e": 9627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9732,
      "e": 9732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 9813,
      "e": 9813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9813,
      "e": 9813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9884,
      "e": 9884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9980,
      "e": 9980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11572,
      "e": 11572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11572,
      "e": 11572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11677,
      "e": 11677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11677,
      "e": 11677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11749,
      "e": 11749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 11869,
      "e": 11869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11869,
      "e": 11869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11876,
      "e": 11876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 "
    },
    {
      "t": 12036,
      "e": 12036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12468,
      "e": 12468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12532,
      "e": 12532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12"
    },
    {
      "t": 12668,
      "e": 12668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12724,
      "e": 12724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 1"
    },
    {
      "t": 12860,
      "e": 12860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12908,
      "e": 12908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the "
    },
    {
      "t": 13021,
      "e": 13021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13092,
      "e": 13092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the"
    },
    {
      "t": 13196,
      "e": 13196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13260,
      "e": 13260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at th"
    },
    {
      "t": 13380,
      "e": 13380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13428,
      "e": 13428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at t"
    },
    {
      "t": 13564,
      "e": 13564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13628,
      "e": 13628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at "
    },
    {
      "t": 13885,
      "e": 13885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 13885,
      "e": 13885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13996,
      "e": 13996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 14133,
      "e": 14133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14133,
      "e": 14133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14268,
      "e": 14268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 14340,
      "e": 14340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14341,
      "e": 14341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14460,
      "e": 14460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14460,
      "e": 14460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14476,
      "e": 14476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 14588,
      "e": 14588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14589,
      "e": 14589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14669,
      "e": 14669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14725,
      "e": 14725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14948,
      "e": 14948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15027,
      "e": 15027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at wuer"
    },
    {
      "t": 15156,
      "e": 15156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15196,
      "e": 15196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at wue"
    },
    {
      "t": 15316,
      "e": 15316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15356,
      "e": 15356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at wu"
    },
    {
      "t": 15468,
      "e": 15468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15508,
      "e": 15508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at w"
    },
    {
      "t": 15796,
      "e": 15796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 15798,
      "e": 15798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15836,
      "e": 15836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 16412,
      "e": 16412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16491,
      "e": 16491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at w"
    },
    {
      "t": 16603,
      "e": 16603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at w"
    },
    {
      "t": 16709,
      "e": 16709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16709,
      "e": 16709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16789,
      "e": 16789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17844,
      "e": 17844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17844,
      "e": 17844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18003,
      "e": 18003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at whe"
    },
    {
      "t": 18013,
      "e": 18013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18013,
      "e": 18013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18043,
      "e": 18043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 18164,
      "e": 18164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18165,
      "e": 18165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18245,
      "e": 18245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18302,
      "e": 18302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18302,
      "e": 18302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18324,
      "e": 18324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18428,
      "e": 18428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18764,
      "e": 18764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18765,
      "e": 18765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18891,
      "e": 18891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18892,
      "e": 18892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18980,
      "e": 18980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 19054,
      "e": 19054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19057,
      "e": 19057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19099,
      "e": 19099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19196,
      "e": 19196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19244,
      "e": 19244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19245,
      "e": 19245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19387,
      "e": 19387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19500,
      "e": 19500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19501,
      "e": 19501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19602,
      "e": 19602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm"
    },
    {
      "t": 19612,
      "e": 19612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19772,
      "e": 19772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19773,
      "e": 19773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19924,
      "e": 19924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20179,
      "e": 20179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20179,
      "e": 20179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20252,
      "e": 20252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20308,
      "e": 20308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20308,
      "e": 20308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20404,
      "e": 20404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20404,
      "e": 20404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20451,
      "e": 20451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 20524,
      "e": 20524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20525,
      "e": 20525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20548,
      "e": 20548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20627,
      "e": 20627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20628,
      "e": 20628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20676,
      "e": 20676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20717,
      "e": 20717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20780,
      "e": 20780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20781,
      "e": 20781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20867,
      "e": 20867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20869,
      "e": 20869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20915,
      "e": 20915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 21052,
      "e": 21052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21053,
      "e": 21053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21060,
      "e": 21060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21203,
      "e": 21203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and t"
    },
    {
      "t": 21213,
      "e": 21213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21213,
      "e": 21213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21214,
      "e": 21214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21276,
      "e": 21276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21300,
      "e": 21300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21300,
      "e": 21300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21372,
      "e": 21372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21372,
      "e": 21372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21396,
      "e": 21396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 21476,
      "e": 21476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21508,
      "e": 21508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21510,
      "e": 21510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21620,
      "e": 21620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21773,
      "e": 21773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 21774,
      "e": 21774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21892,
      "e": 21892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21892,
      "e": 21892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21924,
      "e": 21924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 22003,
      "e": 22003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22004,
      "e": 22004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22035,
      "e": 22035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22084,
      "e": 22084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22188,
      "e": 22188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22188,
      "e": 22188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22356,
      "e": 22356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22358,
      "e": 22358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22412,
      "e": 22412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 22484,
      "e": 22484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22485,
      "e": 22485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22555,
      "e": 22555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22612,
      "e": 22612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22652,
      "e": 22652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 22652,
      "e": 22652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22802,
      "e": 22802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events l"
    },
    {
      "t": 22828,
      "e": 22828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 22917,
      "e": 22917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22918,
      "e": 22918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23021,
      "e": 23021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23068,
      "e": 23068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23070,
      "e": 23070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23171,
      "e": 23171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23204,
      "e": 23204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23204,
      "e": 23204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23300,
      "e": 23300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23402,
      "e": 23402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events line"
    },
    {
      "t": 23492,
      "e": 23492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23493,
      "e": 23493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23588,
      "e": 23588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23588,
      "e": 23588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23628,
      "e": 23628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 23724,
      "e": 23724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24300,
      "e": 24300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 24301,
      "e": 24301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24428,
      "e": 24428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 24645,
      "e": 24645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24645,
      "e": 24645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24748,
      "e": 24748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 24845,
      "e": 24845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24845,
      "e": 24845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25002,
      "e": 25002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up "
    },
    {
      "t": 25021,
      "e": 25021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25076,
      "e": 25076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25078,
      "e": 25078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25202,
      "e": 25202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up a"
    },
    {
      "t": 25203,
      "e": 25203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25220,
      "e": 25220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25220,
      "e": 25220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25317,
      "e": 25317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25549,
      "e": 25549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25549,
      "e": 25549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25644,
      "e": 25644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25644,
      "e": 25644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25683,
      "e": 25683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 25756,
      "e": 25756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25788,
      "e": 25788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25788,
      "e": 25788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25877,
      "e": 25877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25877,
      "e": 25877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25915,
      "e": 25915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 26044,
      "e": 26044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26044,
      "e": 26044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26124,
      "e": 26124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26197,
      "e": 26197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26237,
      "e": 26198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26239,
      "e": 26200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26332,
      "e": 26293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26500,
      "e": 26461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26501,
      "e": 26462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26644,
      "e": 26605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26644,
      "e": 26605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26692,
      "e": 26653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 26748,
      "e": 26709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26749,
      "e": 26710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26764,
      "e": 26725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26875,
      "e": 26836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26980,
      "e": 26941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26981,
      "e": 26942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27076,
      "e": 27037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27613,
      "e": 27574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 27613,
      "e": 27574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27684,
      "e": 27645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 27801,
      "e": 27762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that ax"
    },
    {
      "t": 27851,
      "e": 27812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27852,
      "e": 27813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27931,
      "e": 27892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28236,
      "e": 28197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28237,
      "e": 28198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28389,
      "e": 28350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28389,
      "e": 28350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28404,
      "e": 28365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 28508,
      "e": 28469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29924,
      "e": 29885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29924,
      "e": 29885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30044,
      "e": 30005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30188,
      "e": 30149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30188,
      "e": 30149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30348,
      "e": 30309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30349,
      "e": 30310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30387,
      "e": 30348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 30587,
      "e": 30548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30604,
      "e": 30565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30604,
      "e": 30565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30748,
      "e": 30709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31644,
      "e": 31605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31645,
      "e": 31606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31802,
      "e": 31763,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that axis start"
    },
    {
      "t": 31804,
      "e": 31765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31893,
      "e": 31854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31893,
      "e": 31854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32003,
      "e": 31964,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that axis start "
    },
    {
      "t": 32068,
      "e": 32029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32076,
      "e": 32037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32077,
      "e": 32038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32201,
      "e": 32162,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that axis start a"
    },
    {
      "t": 32204,
      "e": 32165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32204,
      "e": 32165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32220,
      "e": 32181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 32324,
      "e": 32285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32325,
      "e": 32286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32364,
      "e": 32325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32468,
      "e": 32429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32771,
      "e": 32732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 32772,
      "e": 32733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32924,
      "e": 32885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 32925,
      "e": 32886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32995,
      "e": 32956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 33044,
      "e": 33005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33044,
      "e": 33005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33084,
      "e": 33045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33181,
      "e": 33142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33532,
      "e": 33493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33533,
      "e": 33494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33620,
      "e": 33581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33622,
      "e": 33583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33644,
      "e": 33605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 33733,
      "e": 33694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34400,
      "e": 34361,
      "ty": 2,
      "x": 384,
      "y": 570
    },
    {
      "t": 34500,
      "e": 34461,
      "ty": 2,
      "x": 370,
      "y": 592
    },
    {
      "t": 34501,
      "e": 34462,
      "ty": 41,
      "x": 30677,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34548,
      "e": 34509,
      "ty": 7,
      "x": 359,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34600,
      "e": 34561,
      "ty": 2,
      "x": 478,
      "y": 617
    },
    {
      "t": 34647,
      "e": 34608,
      "ty": 6,
      "x": 559,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34700,
      "e": 34661,
      "ty": 2,
      "x": 564,
      "y": 576
    },
    {
      "t": 34751,
      "e": 34712,
      "ty": 41,
      "x": 53046,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34800,
      "e": 34761,
      "ty": 2,
      "x": 569,
      "y": 533
    },
    {
      "t": 34848,
      "e": 34809,
      "ty": 7,
      "x": 560,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34900,
      "e": 34861,
      "ty": 2,
      "x": 551,
      "y": 521
    },
    {
      "t": 35000,
      "e": 34961,
      "ty": 2,
      "x": 518,
      "y": 520
    },
    {
      "t": 35000,
      "e": 34961,
      "ty": 41,
      "x": 47314,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 35101,
      "e": 35062,
      "ty": 2,
      "x": 505,
      "y": 520
    },
    {
      "t": 35137,
      "e": 35098,
      "ty": 6,
      "x": 506,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35200,
      "e": 35161,
      "ty": 2,
      "x": 517,
      "y": 524
    },
    {
      "t": 35250,
      "e": 35211,
      "ty": 41,
      "x": 47426,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35300,
      "e": 35261,
      "ty": 2,
      "x": 519,
      "y": 525
    },
    {
      "t": 35400,
      "e": 35361,
      "ty": 2,
      "x": 520,
      "y": 527
    },
    {
      "t": 35500,
      "e": 35461,
      "ty": 2,
      "x": 523,
      "y": 530
    },
    {
      "t": 35501,
      "e": 35462,
      "ty": 41,
      "x": 47876,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35505,
      "e": 35466,
      "ty": 3,
      "x": 523,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35591,
      "e": 35552,
      "ty": 4,
      "x": 47876,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35591,
      "e": 35552,
      "ty": 5,
      "x": 523,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36252,
      "e": 36213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 36254,
      "e": 36215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36364,
      "e": 36325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36364,
      "e": 36325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36389,
      "e": 36327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that veaxis start at 12 pm"
    },
    {
      "t": 36523,
      "e": 36461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36524,
      "e": 36462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36572,
      "e": 36510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that veraxis start at 12 pm"
    },
    {
      "t": 36620,
      "e": 36558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36724,
      "e": 36662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36725,
      "e": 36663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36804,
      "e": 36742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertaxis start at 12 pm"
    },
    {
      "t": 36931,
      "e": 36869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36932,
      "e": 36870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37027,
      "e": 36965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertiaxis start at 12 pm"
    },
    {
      "t": 37259,
      "e": 37197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37260,
      "e": 37198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37292,
      "e": 37230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertiiaxis start at 12 pm"
    },
    {
      "t": 37403,
      "e": 37341,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertiiaxis start at 12 pm"
    },
    {
      "t": 37724,
      "e": 37662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37772,
      "e": 37710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertiaxis start at 12 pm"
    },
    {
      "t": 37843,
      "e": 37781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 37844,
      "e": 37782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37924,
      "e": 37862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37925,
      "e": 37863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37956,
      "e": 37894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that verticaaxis start at 12 pm"
    },
    {
      "t": 38036,
      "e": 37974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38045,
      "e": 37983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38046,
      "e": 37984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38107,
      "e": 38045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that verticalaxis start at 12 pm"
    },
    {
      "t": 38228,
      "e": 38166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38228,
      "e": 38166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38293,
      "e": 38167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertical axis start at 12 pm"
    },
    {
      "t": 38404,
      "e": 38278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertical axis start at 12 pm"
    },
    {
      "t": 39100,
      "e": 38974,
      "ty": 2,
      "x": 530,
      "y": 534
    },
    {
      "t": 39134,
      "e": 39008,
      "ty": 7,
      "x": 768,
      "y": 632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39201,
      "e": 39075,
      "ty": 2,
      "x": 1356,
      "y": 917
    },
    {
      "t": 39300,
      "e": 39174,
      "ty": 2,
      "x": 1889,
      "y": 1199
    },
    {
      "t": 39401,
      "e": 39275,
      "ty": 2,
      "x": 1501,
      "y": 1199
    },
    {
      "t": 39501,
      "e": 39375,
      "ty": 2,
      "x": 1077,
      "y": 1199
    },
    {
      "t": 39700,
      "e": 39574,
      "ty": 2,
      "x": 1074,
      "y": 1199
    },
    {
      "t": 39751,
      "e": 39625,
      "ty": 41,
      "x": 32027,
      "y": 64981,
      "ta": "> div.stimulus"
    },
    {
      "t": 39800,
      "e": 39674,
      "ty": 2,
      "x": 695,
      "y": 1117
    },
    {
      "t": 39900,
      "e": 39774,
      "ty": 2,
      "x": 572,
      "y": 1039
    },
    {
      "t": 40001,
      "e": 39875,
      "ty": 2,
      "x": 510,
      "y": 997
    },
    {
      "t": 40001,
      "e": 39875,
      "ty": 41,
      "x": 46414,
      "y": 54787,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40100,
      "e": 39974,
      "ty": 2,
      "x": 505,
      "y": 971
    },
    {
      "t": 40200,
      "e": 40074,
      "ty": 2,
      "x": 508,
      "y": 904
    },
    {
      "t": 40250,
      "e": 40124,
      "ty": 41,
      "x": 45965,
      "y": 49580,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40300,
      "e": 40174,
      "ty": 2,
      "x": 506,
      "y": 903
    },
    {
      "t": 40500,
      "e": 40374,
      "ty": 2,
      "x": 484,
      "y": 878
    },
    {
      "t": 40500,
      "e": 40374,
      "ty": 41,
      "x": 43492,
      "y": 48195,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40600,
      "e": 40474,
      "ty": 2,
      "x": 371,
      "y": 753
    },
    {
      "t": 40700,
      "e": 40574,
      "ty": 2,
      "x": 368,
      "y": 747
    },
    {
      "t": 40752,
      "e": 40626,
      "ty": 41,
      "x": 30452,
      "y": 40938,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40800,
      "e": 40674,
      "ty": 2,
      "x": 456,
      "y": 738
    },
    {
      "t": 40900,
      "e": 40774,
      "ty": 2,
      "x": 1405,
      "y": 836
    },
    {
      "t": 41001,
      "e": 40875,
      "ty": 2,
      "x": 1705,
      "y": 867
    },
    {
      "t": 41001,
      "e": 40875,
      "ty": 41,
      "x": 64760,
      "y": 52213,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41100,
      "e": 40974,
      "ty": 2,
      "x": 1594,
      "y": 913
    },
    {
      "t": 41201,
      "e": 41075,
      "ty": 2,
      "x": 1176,
      "y": 975
    },
    {
      "t": 41251,
      "e": 41125,
      "ty": 41,
      "x": 43850,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 41301,
      "e": 41175,
      "ty": 2,
      "x": 1153,
      "y": 984
    },
    {
      "t": 41400,
      "e": 41274,
      "ty": 2,
      "x": 1152,
      "y": 984
    },
    {
      "t": 41500,
      "e": 41374,
      "ty": 2,
      "x": 1144,
      "y": 947
    },
    {
      "t": 41501,
      "e": 41375,
      "ty": 41,
      "x": 25228,
      "y": 57942,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41601,
      "e": 41475,
      "ty": 2,
      "x": 1144,
      "y": 928
    },
    {
      "t": 41701,
      "e": 41575,
      "ty": 2,
      "x": 1145,
      "y": 888
    },
    {
      "t": 41751,
      "e": 41625,
      "ty": 41,
      "x": 25510,
      "y": 51425,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41800,
      "e": 41674,
      "ty": 2,
      "x": 1153,
      "y": 820
    },
    {
      "t": 41900,
      "e": 41774,
      "ty": 2,
      "x": 1170,
      "y": 722
    },
    {
      "t": 42000,
      "e": 41874,
      "ty": 2,
      "x": 1177,
      "y": 682
    },
    {
      "t": 42001,
      "e": 41875,
      "ty": 41,
      "x": 27553,
      "y": 38962,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 42101,
      "e": 41975,
      "ty": 2,
      "x": 1177,
      "y": 679
    },
    {
      "t": 42201,
      "e": 42075,
      "ty": 2,
      "x": 1165,
      "y": 713
    },
    {
      "t": 42251,
      "e": 42125,
      "ty": 41,
      "x": 26144,
      "y": 43904,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 42301,
      "e": 42175,
      "ty": 2,
      "x": 1143,
      "y": 793
    },
    {
      "t": 42401,
      "e": 42275,
      "ty": 2,
      "x": 905,
      "y": 906
    },
    {
      "t": 42500,
      "e": 42374,
      "ty": 2,
      "x": 440,
      "y": 894
    },
    {
      "t": 42501,
      "e": 42375,
      "ty": 41,
      "x": 38546,
      "y": 49082,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 42601,
      "e": 42475,
      "ty": 2,
      "x": 405,
      "y": 869
    },
    {
      "t": 42701,
      "e": 42575,
      "ty": 2,
      "x": 367,
      "y": 725
    },
    {
      "t": 42751,
      "e": 42625,
      "ty": 41,
      "x": 20786,
      "y": 49325,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 42800,
      "e": 42674,
      "ty": 2,
      "x": 363,
      "y": 697
    },
    {
      "t": 42901,
      "e": 42775,
      "ty": 2,
      "x": 363,
      "y": 694
    },
    {
      "t": 42989,
      "e": 42863,
      "ty": 6,
      "x": 367,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 43000,
      "e": 42874,
      "ty": 2,
      "x": 367,
      "y": 686
    },
    {
      "t": 43000,
      "e": 42874,
      "ty": 41,
      "x": 15513,
      "y": 60264,
      "ta": "#strategyButton"
    },
    {
      "t": 43101,
      "e": 42975,
      "ty": 2,
      "x": 381,
      "y": 665
    },
    {
      "t": 43201,
      "e": 43075,
      "ty": 2,
      "x": 384,
      "y": 659
    },
    {
      "t": 43251,
      "e": 43125,
      "ty": 41,
      "x": 24797,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 44801,
      "e": 44675,
      "ty": 2,
      "x": 384,
      "y": 658
    },
    {
      "t": 44901,
      "e": 44775,
      "ty": 2,
      "x": 385,
      "y": 661
    },
    {
      "t": 45001,
      "e": 44875,
      "ty": 41,
      "x": 25343,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 45251,
      "e": 45125,
      "ty": 41,
      "x": 25343,
      "y": 21714,
      "ta": "#strategyButton"
    },
    {
      "t": 45301,
      "e": 45175,
      "ty": 2,
      "x": 385,
      "y": 671
    },
    {
      "t": 45401,
      "e": 45275,
      "ty": 2,
      "x": 385,
      "y": 672
    },
    {
      "t": 45501,
      "e": 45375,
      "ty": 41,
      "x": 25343,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 45953,
      "e": 45827,
      "ty": 3,
      "x": 385,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 45955,
      "e": 45829,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at where 12 pm is and the events lined up along that vertical axis start at 12 pm"
    },
    {
      "t": 45955,
      "e": 45829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45957,
      "e": 45831,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46056,
      "e": 45930,
      "ty": 4,
      "x": 25343,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 46068,
      "e": 45942,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46069,
      "e": 45943,
      "ty": 5,
      "x": 385,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 46079,
      "e": 45953,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 47068,
      "e": 46942,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 47691,
      "e": 47565,
      "ty": 2,
      "x": 761,
      "y": 625
    },
    {
      "t": 47742,
      "e": 47616,
      "ty": 41,
      "x": 48015,
      "y": 30426,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 47792,
      "e": 47666,
      "ty": 2,
      "x": 1300,
      "y": 556
    },
    {
      "t": 47892,
      "e": 47766,
      "ty": 2,
      "x": 1392,
      "y": 514
    },
    {
      "t": 47992,
      "e": 47866,
      "ty": 2,
      "x": 1243,
      "y": 483
    },
    {
      "t": 47992,
      "e": 47866,
      "ty": 41,
      "x": 42530,
      "y": 26313,
      "ta": "html > body"
    },
    {
      "t": 48092,
      "e": 47966,
      "ty": 2,
      "x": 1072,
      "y": 483
    },
    {
      "t": 48191,
      "e": 48065,
      "ty": 2,
      "x": 1068,
      "y": 521
    },
    {
      "t": 48241,
      "e": 48115,
      "ty": 41,
      "x": 55369,
      "y": 34529,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48291,
      "e": 48165,
      "ty": 2,
      "x": 1060,
      "y": 551
    },
    {
      "t": 48392,
      "e": 48266,
      "ty": 2,
      "x": 1060,
      "y": 552
    },
    {
      "t": 48439,
      "e": 48313,
      "ty": 3,
      "x": 1060,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48492,
      "e": 48366,
      "ty": 41,
      "x": 54504,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48551,
      "e": 48425,
      "ty": 4,
      "x": 54504,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48552,
      "e": 48426,
      "ty": 5,
      "x": 1060,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48665,
      "e": 48428,
      "ty": 6,
      "x": 1058,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48692,
      "e": 48455,
      "ty": 2,
      "x": 1056,
      "y": 556
    },
    {
      "t": 48741,
      "e": 48504,
      "ty": 41,
      "x": 53639,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48791,
      "e": 48554,
      "ty": 2,
      "x": 1055,
      "y": 558
    },
    {
      "t": 48879,
      "e": 48642,
      "ty": 3,
      "x": 1055,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48880,
      "e": 48643,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48951,
      "e": 48714,
      "ty": 4,
      "x": 53422,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48951,
      "e": 48714,
      "ty": 5,
      "x": 1055,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48991,
      "e": 48754,
      "ty": 41,
      "x": 53422,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49563,
      "e": 49326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 49563,
      "e": 49326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49666,
      "e": 49429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 49796,
      "e": 49559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 49796,
      "e": 49559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49874,
      "e": 49637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 49992,
      "e": 49755,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 50436,
      "e": 50199,
      "ty": 7,
      "x": 1055,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50491,
      "e": 50254,
      "ty": 2,
      "x": 1047,
      "y": 619
    },
    {
      "t": 50491,
      "e": 50254,
      "ty": 41,
      "x": 51692,
      "y": 42129,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 50535,
      "e": 50298,
      "ty": 6,
      "x": 1037,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50591,
      "e": 50354,
      "ty": 2,
      "x": 1032,
      "y": 657
    },
    {
      "t": 50691,
      "e": 50454,
      "ty": 2,
      "x": 1032,
      "y": 658
    },
    {
      "t": 50742,
      "e": 50505,
      "ty": 41,
      "x": 48448,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50790,
      "e": 50553,
      "ty": 3,
      "x": 1032,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50791,
      "e": 50554,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 50791,
      "e": 50554,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50791,
      "e": 50554,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50878,
      "e": 50641,
      "ty": 4,
      "x": 48448,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50878,
      "e": 50641,
      "ty": 5,
      "x": 1032,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51555,
      "e": 51318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 52035,
      "e": 51798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 52035,
      "e": 51798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52114,
      "e": 51877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 52146,
      "e": 51909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 52298,
      "e": 52061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 52298,
      "e": 52061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52426,
      "e": 52189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 52427,
      "e": 52190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52434,
      "e": 52197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 52491,
      "e": 52254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 52592,
      "e": 52355,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 52643,
      "e": 52406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 52644,
      "e": 52407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52762,
      "e": 52525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 52762,
      "e": 52525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52810,
      "e": 52573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phili"
    },
    {
      "t": 52875,
      "e": 52638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 52979,
      "e": 52742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 52980,
      "e": 52743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53066,
      "e": 52829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 53147,
      "e": 52910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 53147,
      "e": 52910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53291,
      "e": 53054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 53292,
      "e": 53055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53307,
      "e": 53070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||pi"
    },
    {
      "t": 53387,
      "e": 53150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 53388,
      "e": 53151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53434,
      "e": 53197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 53522,
      "e": 53285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 53587,
      "e": 53350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 53587,
      "e": 53350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53706,
      "e": 53469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 53707,
      "e": 53470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53770,
      "e": 53533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 53835,
      "e": 53598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 53923,
      "e": 53686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 53923,
      "e": 53686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53971,
      "e": 53734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 54807,
      "e": 54570,
      "ty": 7,
      "x": 1024,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54824,
      "e": 54587,
      "ty": 6,
      "x": 1017,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54891,
      "e": 54654,
      "ty": 2,
      "x": 1004,
      "y": 690
    },
    {
      "t": 54992,
      "e": 54755,
      "ty": 2,
      "x": 996,
      "y": 697
    },
    {
      "t": 54992,
      "e": 54755,
      "ty": 41,
      "x": 51579,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55056,
      "e": 54819,
      "ty": 3,
      "x": 996,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55057,
      "e": 54820,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philippines\n"
    },
    {
      "t": 55058,
      "e": 54821,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55058,
      "e": 54821,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55135,
      "e": 54898,
      "ty": 4,
      "x": 51579,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55135,
      "e": 54898,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55135,
      "e": 54898,
      "ty": 5,
      "x": 996,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55136,
      "e": 54899,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 55492,
      "e": 55255,
      "ty": 2,
      "x": 975,
      "y": 679
    },
    {
      "t": 55492,
      "e": 55255,
      "ty": 41,
      "x": 33301,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 55591,
      "e": 55354,
      "ty": 2,
      "x": 958,
      "y": 650
    },
    {
      "t": 55692,
      "e": 55455,
      "ty": 2,
      "x": 937,
      "y": 626
    },
    {
      "t": 55741,
      "e": 55504,
      "ty": 41,
      "x": 30993,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 55792,
      "e": 55555,
      "ty": 2,
      "x": 869,
      "y": 561
    },
    {
      "t": 55992,
      "e": 55755,
      "ty": 41,
      "x": 29650,
      "y": 30634,
      "ta": "html > body"
    },
    {
      "t": 56152,
      "e": 55915,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 56291,
      "e": 56054,
      "ty": 2,
      "x": 865,
      "y": 562
    },
    {
      "t": 56391,
      "e": 56154,
      "ty": 2,
      "x": 406,
      "y": 566
    },
    {
      "t": 56492,
      "e": 56255,
      "ty": 2,
      "x": 117,
      "y": 546
    },
    {
      "t": 56492,
      "e": 56255,
      "ty": 41,
      "x": 3753,
      "y": 29803,
      "ta": "html > body"
    },
    {
      "t": 56991,
      "e": 56754,
      "ty": 2,
      "x": 79,
      "y": 532
    },
    {
      "t": 56992,
      "e": 56755,
      "ty": 41,
      "x": 2445,
      "y": 29028,
      "ta": "html > body"
    },
    {
      "t": 57091,
      "e": 56854,
      "ty": 2,
      "x": 8,
      "y": 121
    },
    {
      "t": 57192,
      "e": 56955,
      "ty": 2,
      "x": 11,
      "y": 0
    },
    {
      "t": 57242,
      "e": 57005,
      "ty": 41,
      "x": 4201,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 57291,
      "e": 57054,
      "ty": 2,
      "x": 479,
      "y": 0
    },
    {
      "t": 57391,
      "e": 57154,
      "ty": 2,
      "x": 904,
      "y": 87
    },
    {
      "t": 57491,
      "e": 57254,
      "ty": 2,
      "x": 901,
      "y": 152
    },
    {
      "t": 57492,
      "e": 57255,
      "ty": 41,
      "x": 30752,
      "y": 7977,
      "ta": "html > body"
    },
    {
      "t": 57591,
      "e": 57354,
      "ty": 2,
      "x": 845,
      "y": 197
    },
    {
      "t": 57691,
      "e": 57454,
      "ty": 2,
      "x": 809,
      "y": 219
    },
    {
      "t": 57741,
      "e": 57504,
      "ty": 41,
      "x": 27584,
      "y": 12298,
      "ta": "html > body"
    },
    {
      "t": 57791,
      "e": 57554,
      "ty": 2,
      "x": 812,
      "y": 245
    },
    {
      "t": 57891,
      "e": 57654,
      "ty": 2,
      "x": 818,
      "y": 258
    },
    {
      "t": 57991,
      "e": 57754,
      "ty": 2,
      "x": 822,
      "y": 283
    },
    {
      "t": 57991,
      "e": 57754,
      "ty": 41,
      "x": 137,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 58091,
      "e": 57854,
      "ty": 2,
      "x": 825,
      "y": 306
    },
    {
      "t": 58192,
      "e": 57955,
      "ty": 2,
      "x": 825,
      "y": 313
    },
    {
      "t": 58242,
      "e": 58005,
      "ty": 41,
      "x": 3552,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 58291,
      "e": 58054,
      "ty": 2,
      "x": 825,
      "y": 315
    },
    {
      "t": 58392,
      "e": 58155,
      "ty": 2,
      "x": 825,
      "y": 316
    },
    {
      "t": 58490,
      "e": 58157,
      "ty": 6,
      "x": 826,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58493,
      "e": 58160,
      "ty": 2,
      "x": 826,
      "y": 319
    },
    {
      "t": 58493,
      "e": 58160,
      "ty": 41,
      "x": 0,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58591,
      "e": 58258,
      "ty": 2,
      "x": 828,
      "y": 319
    },
    {
      "t": 58691,
      "e": 58358,
      "ty": 2,
      "x": 831,
      "y": 320
    },
    {
      "t": 58741,
      "e": 58408,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58767,
      "e": 58434,
      "ty": 3,
      "x": 831,
      "y": 320,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58769,
      "e": 58436,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58863,
      "e": 58530,
      "ty": 4,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58864,
      "e": 58531,
      "ty": 5,
      "x": 831,
      "y": 320,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58865,
      "e": 58532,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 59691,
      "e": 59358,
      "ty": 2,
      "x": 832,
      "y": 320
    },
    {
      "t": 59742,
      "e": 59409,
      "ty": 41,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 59791,
      "e": 59458,
      "ty": 2,
      "x": 829,
      "y": 322
    },
    {
      "t": 59843,
      "e": 59510,
      "ty": 7,
      "x": 825,
      "y": 325,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 59892,
      "e": 59559,
      "ty": 2,
      "x": 821,
      "y": 327
    },
    {
      "t": 59992,
      "e": 59659,
      "ty": 2,
      "x": 810,
      "y": 332
    },
    {
      "t": 59992,
      "e": 59659,
      "ty": 41,
      "x": 27619,
      "y": 17948,
      "ta": "html > body"
    },
    {
      "t": 60092,
      "e": 59759,
      "ty": 2,
      "x": 778,
      "y": 355
    },
    {
      "t": 60191,
      "e": 59858,
      "ty": 2,
      "x": 753,
      "y": 381
    },
    {
      "t": 60242,
      "e": 59909,
      "ty": 41,
      "x": 25380,
      "y": 21660,
      "ta": "html > body"
    },
    {
      "t": 60292,
      "e": 59959,
      "ty": 2,
      "x": 742,
      "y": 412
    },
    {
      "t": 60391,
      "e": 60058,
      "ty": 2,
      "x": 744,
      "y": 428
    },
    {
      "t": 60491,
      "e": 60158,
      "ty": 2,
      "x": 783,
      "y": 442
    },
    {
      "t": 60491,
      "e": 60158,
      "ty": 41,
      "x": 26689,
      "y": 24042,
      "ta": "html > body"
    },
    {
      "t": 60591,
      "e": 60258,
      "ty": 2,
      "x": 825,
      "y": 454
    },
    {
      "t": 60691,
      "e": 60358,
      "ty": 2,
      "x": 827,
      "y": 454
    },
    {
      "t": 60742,
      "e": 60409,
      "ty": 41,
      "x": 2035,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 60792,
      "e": 60459,
      "ty": 2,
      "x": 830,
      "y": 454
    },
    {
      "t": 60892,
      "e": 60559,
      "ty": 2,
      "x": 832,
      "y": 452
    },
    {
      "t": 60968,
      "e": 60635,
      "ty": 6,
      "x": 832,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60991,
      "e": 60658,
      "ty": 2,
      "x": 833,
      "y": 447
    },
    {
      "t": 60992,
      "e": 60659,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61092,
      "e": 60759,
      "ty": 2,
      "x": 834,
      "y": 442
    },
    {
      "t": 61144,
      "e": 60811,
      "ty": 3,
      "x": 834,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61145,
      "e": 60812,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61145,
      "e": 60812,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61231,
      "e": 60898,
      "ty": 4,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61231,
      "e": 60898,
      "ty": 5,
      "x": 834,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61231,
      "e": 60898,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 61241,
      "e": 60908,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61967,
      "e": 61634,
      "ty": 7,
      "x": 828,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61992,
      "e": 61659,
      "ty": 2,
      "x": 826,
      "y": 453
    },
    {
      "t": 61992,
      "e": 61659,
      "ty": 41,
      "x": 1086,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 62092,
      "e": 61759,
      "ty": 2,
      "x": 789,
      "y": 521
    },
    {
      "t": 62192,
      "e": 61859,
      "ty": 2,
      "x": 765,
      "y": 583
    },
    {
      "t": 62242,
      "e": 61909,
      "ty": 41,
      "x": 25656,
      "y": 33736,
      "ta": "html > body"
    },
    {
      "t": 62292,
      "e": 61959,
      "ty": 2,
      "x": 747,
      "y": 644
    },
    {
      "t": 62392,
      "e": 62059,
      "ty": 2,
      "x": 731,
      "y": 682
    },
    {
      "t": 62491,
      "e": 62158,
      "ty": 2,
      "x": 716,
      "y": 722
    },
    {
      "t": 62491,
      "e": 62158,
      "ty": 41,
      "x": 24381,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 62592,
      "e": 62259,
      "ty": 2,
      "x": 711,
      "y": 755
    },
    {
      "t": 62692,
      "e": 62359,
      "ty": 2,
      "x": 735,
      "y": 788
    },
    {
      "t": 62742,
      "e": 62409,
      "ty": 41,
      "x": 25346,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 62792,
      "e": 62459,
      "ty": 2,
      "x": 753,
      "y": 792
    },
    {
      "t": 62891,
      "e": 62558,
      "ty": 2,
      "x": 770,
      "y": 797
    },
    {
      "t": 62992,
      "e": 62659,
      "ty": 2,
      "x": 776,
      "y": 798
    },
    {
      "t": 62992,
      "e": 62659,
      "ty": 41,
      "x": 26448,
      "y": 43763,
      "ta": "html > body"
    },
    {
      "t": 63091,
      "e": 62758,
      "ty": 2,
      "x": 781,
      "y": 795
    },
    {
      "t": 63192,
      "e": 62859,
      "ty": 2,
      "x": 786,
      "y": 792
    },
    {
      "t": 63242,
      "e": 62909,
      "ty": 41,
      "x": 26826,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 63292,
      "e": 62959,
      "ty": 2,
      "x": 786,
      "y": 772
    },
    {
      "t": 63392,
      "e": 63059,
      "ty": 2,
      "x": 786,
      "y": 759
    },
    {
      "t": 63491,
      "e": 63158,
      "ty": 2,
      "x": 788,
      "y": 754
    },
    {
      "t": 63491,
      "e": 63158,
      "ty": 41,
      "x": 26861,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 63592,
      "e": 63259,
      "ty": 2,
      "x": 791,
      "y": 748
    },
    {
      "t": 63692,
      "e": 63359,
      "ty": 2,
      "x": 795,
      "y": 743
    },
    {
      "t": 63742,
      "e": 63409,
      "ty": 41,
      "x": 27171,
      "y": 40550,
      "ta": "html > body"
    },
    {
      "t": 63791,
      "e": 63458,
      "ty": 2,
      "x": 801,
      "y": 738
    },
    {
      "t": 63892,
      "e": 63559,
      "ty": 2,
      "x": 804,
      "y": 733
    },
    {
      "t": 63992,
      "e": 63659,
      "ty": 2,
      "x": 805,
      "y": 727
    },
    {
      "t": 63992,
      "e": 63659,
      "ty": 41,
      "x": 27446,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 64092,
      "e": 63759,
      "ty": 2,
      "x": 799,
      "y": 721
    },
    {
      "t": 64242,
      "e": 63909,
      "ty": 41,
      "x": 27240,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 64492,
      "e": 64159,
      "ty": 2,
      "x": 800,
      "y": 721
    },
    {
      "t": 64492,
      "e": 64159,
      "ty": 41,
      "x": 27274,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 65348,
      "e": 65015,
      "ty": 6,
      "x": 828,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65381,
      "e": 65048,
      "ty": 7,
      "x": 840,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65392,
      "e": 65059,
      "ty": 2,
      "x": 840,
      "y": 730
    },
    {
      "t": 65491,
      "e": 65158,
      "ty": 2,
      "x": 841,
      "y": 731
    },
    {
      "t": 65491,
      "e": 65158,
      "ty": 41,
      "x": 4913,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65791,
      "e": 65458,
      "ty": 6,
      "x": 838,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65792,
      "e": 65459,
      "ty": 2,
      "x": 838,
      "y": 731
    },
    {
      "t": 65891,
      "e": 65558,
      "ty": 2,
      "x": 836,
      "y": 732
    },
    {
      "t": 65959,
      "e": 65626,
      "ty": 3,
      "x": 836,
      "y": 732,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65961,
      "e": 65628,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65962,
      "e": 65629,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65992,
      "e": 65659,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66062,
      "e": 65729,
      "ty": 4,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66063,
      "e": 65730,
      "ty": 5,
      "x": 836,
      "y": 732,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66063,
      "e": 65730,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 66392,
      "e": 66059,
      "ty": 2,
      "x": 834,
      "y": 735
    },
    {
      "t": 66399,
      "e": 66066,
      "ty": 7,
      "x": 834,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66416,
      "e": 66067,
      "ty": 6,
      "x": 834,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 66432,
      "e": 66083,
      "ty": 7,
      "x": 832,
      "y": 769,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 66448,
      "e": 66099,
      "ty": 6,
      "x": 828,
      "y": 786,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66465,
      "e": 66116,
      "ty": 7,
      "x": 824,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66491,
      "e": 66142,
      "ty": 2,
      "x": 822,
      "y": 818
    },
    {
      "t": 66492,
      "e": 66143,
      "ty": 41,
      "x": 341,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66592,
      "e": 66243,
      "ty": 2,
      "x": 816,
      "y": 901
    },
    {
      "t": 66691,
      "e": 66342,
      "ty": 2,
      "x": 819,
      "y": 922
    },
    {
      "t": 66742,
      "e": 66393,
      "ty": 41,
      "x": 27928,
      "y": 50743,
      "ta": "html > body"
    },
    {
      "t": 66792,
      "e": 66443,
      "ty": 2,
      "x": 819,
      "y": 928
    },
    {
      "t": 66892,
      "e": 66543,
      "ty": 2,
      "x": 829,
      "y": 945
    },
    {
      "t": 66992,
      "e": 66643,
      "ty": 2,
      "x": 843,
      "y": 955
    },
    {
      "t": 66992,
      "e": 66643,
      "ty": 41,
      "x": 17454,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 67091,
      "e": 66742,
      "ty": 2,
      "x": 845,
      "y": 958
    },
    {
      "t": 67192,
      "e": 66843,
      "ty": 2,
      "x": 845,
      "y": 959
    },
    {
      "t": 67242,
      "e": 66893,
      "ty": 41,
      "x": 17454,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 67291,
      "e": 66942,
      "ty": 2,
      "x": 840,
      "y": 960
    },
    {
      "t": 67310,
      "e": 66961,
      "ty": 6,
      "x": 839,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67391,
      "e": 67042,
      "ty": 2,
      "x": 838,
      "y": 960
    },
    {
      "t": 67454,
      "e": 67105,
      "ty": 3,
      "x": 838,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67455,
      "e": 67106,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 67455,
      "e": 67106,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67491,
      "e": 67142,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67558,
      "e": 67209,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67559,
      "e": 67210,
      "ty": 5,
      "x": 838,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67559,
      "e": 67210,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 67691,
      "e": 67342,
      "ty": 2,
      "x": 837,
      "y": 961
    },
    {
      "t": 67733,
      "e": 67384,
      "ty": 7,
      "x": 845,
      "y": 975,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67742,
      "e": 67393,
      "ty": 41,
      "x": 5595,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 67782,
      "e": 67433,
      "ty": 6,
      "x": 885,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67791,
      "e": 67442,
      "ty": 2,
      "x": 885,
      "y": 1013
    },
    {
      "t": 67816,
      "e": 67467,
      "ty": 7,
      "x": 909,
      "y": 1039,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67892,
      "e": 67543,
      "ty": 2,
      "x": 924,
      "y": 1060
    },
    {
      "t": 67992,
      "e": 67643,
      "ty": 41,
      "x": 31544,
      "y": 58277,
      "ta": "html > body"
    },
    {
      "t": 68092,
      "e": 67743,
      "ty": 2,
      "x": 918,
      "y": 1053
    },
    {
      "t": 68184,
      "e": 67835,
      "ty": 6,
      "x": 911,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68192,
      "e": 67843,
      "ty": 2,
      "x": 911,
      "y": 1036
    },
    {
      "t": 68242,
      "e": 67893,
      "ty": 41,
      "x": 40498,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68292,
      "e": 67943,
      "ty": 2,
      "x": 906,
      "y": 1029
    },
    {
      "t": 68383,
      "e": 68034,
      "ty": 3,
      "x": 906,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68385,
      "e": 68036,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68385,
      "e": 68036,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68392,
      "e": 68043,
      "ty": 2,
      "x": 906,
      "y": 1026
    },
    {
      "t": 68471,
      "e": 68122,
      "ty": 4,
      "x": 39467,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68471,
      "e": 68122,
      "ty": 5,
      "x": 906,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68473,
      "e": 68124,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68473,
      "e": 68124,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68475,
      "e": 68126,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68492,
      "e": 68143,
      "ty": 41,
      "x": 30925,
      "y": 56394,
      "ta": "html > body"
    },
    {
      "t": 68892,
      "e": 68543,
      "ty": 2,
      "x": 905,
      "y": 1026
    },
    {
      "t": 68991,
      "e": 68642,
      "ty": 2,
      "x": 901,
      "y": 1018
    },
    {
      "t": 68992,
      "e": 68643,
      "ty": 41,
      "x": 30752,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 69092,
      "e": 68743,
      "ty": 2,
      "x": 882,
      "y": 983
    },
    {
      "t": 69192,
      "e": 68843,
      "ty": 2,
      "x": 864,
      "y": 949
    },
    {
      "t": 69242,
      "e": 68893,
      "ty": 41,
      "x": 29099,
      "y": 51242,
      "ta": "html > body"
    },
    {
      "t": 69292,
      "e": 68943,
      "ty": 2,
      "x": 841,
      "y": 911
    },
    {
      "t": 69392,
      "e": 69043,
      "ty": 2,
      "x": 819,
      "y": 865
    },
    {
      "t": 69492,
      "e": 69143,
      "ty": 2,
      "x": 818,
      "y": 857
    },
    {
      "t": 69492,
      "e": 69143,
      "ty": 41,
      "x": 27894,
      "y": 47032,
      "ta": "html > body"
    },
    {
      "t": 69810,
      "e": 69461,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 70192,
      "e": 69843,
      "ty": 2,
      "x": 816,
      "y": 857
    },
    {
      "t": 70242,
      "e": 69893,
      "ty": 41,
      "x": 25560,
      "y": 64968,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 70292,
      "e": 69943,
      "ty": 2,
      "x": 813,
      "y": 853
    },
    {
      "t": 70392,
      "e": 70043,
      "ty": 2,
      "x": 824,
      "y": 887
    },
    {
      "t": 70491,
      "e": 70043,
      "ty": 2,
      "x": 841,
      "y": 920
    },
    {
      "t": 70493,
      "e": 70045,
      "ty": 41,
      "x": 26937,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70592,
      "e": 70144,
      "ty": 2,
      "x": 879,
      "y": 990
    },
    {
      "t": 70686,
      "e": 70238,
      "ty": 6,
      "x": 973,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 70691,
      "e": 70243,
      "ty": 2,
      "x": 973,
      "y": 1076
    },
    {
      "t": 70742,
      "e": 70294,
      "ty": 41,
      "x": 53247,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 70791,
      "e": 70343,
      "ty": 2,
      "x": 1020,
      "y": 1086
    },
    {
      "t": 70892,
      "e": 70444,
      "ty": 2,
      "x": 1021,
      "y": 1086
    },
    {
      "t": 70992,
      "e": 70544,
      "ty": 2,
      "x": 1020,
      "y": 1087
    },
    {
      "t": 70992,
      "e": 70544,
      "ty": 41,
      "x": 60346,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 71092,
      "e": 70644,
      "ty": 2,
      "x": 1018,
      "y": 1087
    },
    {
      "t": 71144,
      "e": 70696,
      "ty": 3,
      "x": 1018,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 71145,
      "e": 70697,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 71240,
      "e": 70792,
      "ty": 4,
      "x": 59254,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 71241,
      "e": 70793,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 71242,
      "e": 70794,
      "ty": 5,
      "x": 1018,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 71242,
      "e": 70794,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 71246,
      "e": 70798,
      "ty": 41,
      "x": 34782,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 71791,
      "e": 71343,
      "ty": 2,
      "x": 1017,
      "y": 1087
    },
    {
      "t": 71891,
      "e": 71443,
      "ty": 2,
      "x": 1011,
      "y": 1079
    },
    {
      "t": 71991,
      "e": 71543,
      "ty": 2,
      "x": 1007,
      "y": 1075
    },
    {
      "t": 71991,
      "e": 71543,
      "ty": 41,
      "x": 34403,
      "y": 59108,
      "ta": "html > body"
    },
    {
      "t": 72091,
      "e": 71643,
      "ty": 2,
      "x": 1004,
      "y": 1072
    },
    {
      "t": 72191,
      "e": 71743,
      "ty": 2,
      "x": 1000,
      "y": 1067
    },
    {
      "t": 72241,
      "e": 71793,
      "ty": 41,
      "x": 34093,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 72286,
      "e": 71838,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 73296,
      "e": 72848,
      "ty": 2,
      "x": 219,
      "y": 0
    },
    {
      "t": 73296,
      "e": 72848,
      "ty": 41,
      "x": 7541,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 73491,
      "e": 73043,
      "ty": 2,
      "x": 254,
      "y": 44
    },
    {
      "t": 73491,
      "e": 73043,
      "ty": 41,
      "x": 8471,
      "y": 1994,
      "ta": "html > body"
    },
    {
      "t": 73591,
      "e": 73143,
      "ty": 2,
      "x": 343,
      "y": 115
    },
    {
      "t": 73691,
      "e": 73243,
      "ty": 2,
      "x": 435,
      "y": 147
    },
    {
      "t": 73741,
      "e": 73293,
      "ty": 41,
      "x": 4298,
      "y": 32686,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 73791,
      "e": 73343,
      "ty": 2,
      "x": 494,
      "y": 165
    },
    {
      "t": 73891,
      "e": 73443,
      "ty": 2,
      "x": 495,
      "y": 165
    },
    {
      "t": 73991,
      "e": 73543,
      "ty": 2,
      "x": 526,
      "y": 243
    },
    {
      "t": 73991,
      "e": 73543,
      "ty": 41,
      "x": 7136,
      "y": 32702,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 74046,
      "e": 73598,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 105962, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 105966, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 6804, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 114104, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7007, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Delta\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 122114, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 19547, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 142747, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14184, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 157934, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 18187, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 177488, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1314,y:0,t:1526933319971};\\\", \\\"{x:1109,y:0,t:1526933319991};\\\", \\\"{x:8,y:4,t:1526933320188};\\\", \\\"{x:8,y:6,t:1526933320362};\\\", \\\"{x:8,y:10,t:1526933320370};\\\", \\\"{x:10,y:13,t:1526933320385};\\\", \\\"{x:16,y:21,t:1526933320402};\\\", \\\"{x:17,y:23,t:1526933320418};\\\", \\\"{x:18,y:25,t:1526933320435};\\\", \\\"{x:18,y:27,t:1526933320453};\\\", \\\"{x:19,y:30,t:1526933320468};\\\", \\\"{x:22,y:32,t:1526933320486};\\\", \\\"{x:25,y:35,t:1526933320502};\\\", \\\"{x:28,y:39,t:1526933320519};\\\", \\\"{x:29,y:41,t:1526933320536};\\\", \\\"{x:30,y:41,t:1526933320554};\\\", \\\"{x:30,y:43,t:1526933320570};\\\", \\\"{x:32,y:45,t:1526933320586};\\\", \\\"{x:38,y:53,t:1526933320603};\\\", \\\"{x:43,y:59,t:1526933320619};\\\", \\\"{x:45,y:62,t:1526933320636};\\\", \\\"{x:45,y:63,t:1526933320652};\\\", \\\"{x:47,y:65,t:1526933320669};\\\", \\\"{x:48,y:66,t:1526933320686};\\\", \\\"{x:53,y:71,t:1526933320703};\\\", \\\"{x:57,y:78,t:1526933320719};\\\", \\\"{x:66,y:89,t:1526933320736};\\\", \\\"{x:73,y:100,t:1526933320753};\\\", \\\"{x:81,y:110,t:1526933320770};\\\", \\\"{x:92,y:125,t:1526933320786};\\\", \\\"{x:116,y:158,t:1526933320803};\\\", \\\"{x:142,y:189,t:1526933320819};\\\", \\\"{x:152,y:204,t:1526933320835};\\\", \\\"{x:163,y:218,t:1526933320852};\\\", \\\"{x:178,y:236,t:1526933320869};\\\", \\\"{x:199,y:255,t:1526933320885};\\\", \\\"{x:217,y:270,t:1526933320903};\\\", \\\"{x:231,y:283,t:1526933320919};\\\", \\\"{x:243,y:297,t:1526933320936};\\\", \\\"{x:258,y:311,t:1526933320952};\\\", \\\"{x:272,y:322,t:1526933320969};\\\", \\\"{x:286,y:331,t:1526933320985};\\\", \\\"{x:310,y:350,t:1526933321003};\\\", \\\"{x:321,y:359,t:1526933321019};\\\", \\\"{x:331,y:368,t:1526933321036};\\\", \\\"{x:345,y:376,t:1526933321052};\\\", \\\"{x:357,y:386,t:1526933321069};\\\", \\\"{x:370,y:394,t:1526933321085};\\\", \\\"{x:383,y:403,t:1526933321102};\\\", \\\"{x:396,y:414,t:1526933321120};\\\", \\\"{x:411,y:426,t:1526933321135};\\\", \\\"{x:424,y:437,t:1526933321153};\\\", \\\"{x:437,y:448,t:1526933321169};\\\", \\\"{x:451,y:459,t:1526933321187};\\\", \\\"{x:456,y:465,t:1526933321203};\\\", \\\"{x:461,y:469,t:1526933321219};\\\", \\\"{x:465,y:477,t:1526933321237};\\\", \\\"{x:470,y:484,t:1526933321252};\\\", \\\"{x:474,y:490,t:1526933321270};\\\", \\\"{x:478,y:496,t:1526933321286};\\\", \\\"{x:480,y:497,t:1526933321303};\\\", \\\"{x:481,y:497,t:1526933323132};\\\", \\\"{x:482,y:497,t:1526933323155};\\\", \\\"{x:483,y:497,t:1526933323171};\\\", \\\"{x:486,y:497,t:1526933323188};\\\", \\\"{x:488,y:497,t:1526933323211};\\\", \\\"{x:489,y:497,t:1526933323221};\\\", \\\"{x:490,y:497,t:1526933323282};\\\", \\\"{x:491,y:497,t:1526933323298};\\\", \\\"{x:493,y:497,t:1526933323314};\\\", \\\"{x:495,y:497,t:1526933323330};\\\", \\\"{x:497,y:498,t:1526933323354};\\\", \\\"{x:499,y:499,t:1526933323371};\\\", \\\"{x:500,y:500,t:1526933323388};\\\", \\\"{x:501,y:500,t:1526933323405};\\\", \\\"{x:503,y:500,t:1526933323421};\\\", \\\"{x:504,y:500,t:1526933323442};\\\", \\\"{x:505,y:500,t:1526933323454};\\\", \\\"{x:506,y:501,t:1526933323470};\\\", \\\"{x:508,y:501,t:1526933323490};\\\", \\\"{x:509,y:501,t:1526933323504};\\\", \\\"{x:510,y:502,t:1526933323521};\\\", \\\"{x:512,y:503,t:1526933323538};\\\", \\\"{x:515,y:503,t:1526933323555};\\\", \\\"{x:518,y:504,t:1526933323571};\\\", \\\"{x:523,y:505,t:1526933323587};\\\", \\\"{x:527,y:507,t:1526933323606};\\\", \\\"{x:530,y:507,t:1526933323622};\\\", \\\"{x:533,y:507,t:1526933323638};\\\", \\\"{x:535,y:507,t:1526933323654};\\\", \\\"{x:537,y:509,t:1526933323672};\\\", \\\"{x:538,y:509,t:1526933323690};\\\", \\\"{x:539,y:509,t:1526933323705};\\\", \\\"{x:542,y:509,t:1526933323721};\\\", \\\"{x:547,y:510,t:1526933323738};\\\", \\\"{x:550,y:510,t:1526933323754};\\\", \\\"{x:552,y:511,t:1526933323771};\\\", \\\"{x:556,y:512,t:1526933323788};\\\", \\\"{x:561,y:513,t:1526933323806};\\\", \\\"{x:563,y:513,t:1526933323821};\\\", \\\"{x:566,y:513,t:1526933323839};\\\", \\\"{x:570,y:514,t:1526933323856};\\\", \\\"{x:574,y:514,t:1526933323871};\\\", \\\"{x:576,y:514,t:1526933323889};\\\", \\\"{x:577,y:514,t:1526933323904};\\\", \\\"{x:579,y:514,t:1526933323922};\\\", \\\"{x:581,y:516,t:1526933323939};\\\", \\\"{x:583,y:516,t:1526933323963};\\\", \\\"{x:584,y:516,t:1526933323979};\\\", \\\"{x:585,y:516,t:1526933323988};\\\", \\\"{x:587,y:516,t:1526933324006};\\\", \\\"{x:590,y:516,t:1526933324022};\\\", \\\"{x:593,y:516,t:1526933324039};\\\", \\\"{x:596,y:517,t:1526933324056};\\\", \\\"{x:598,y:517,t:1526933324071};\\\", \\\"{x:600,y:517,t:1526933324088};\\\", \\\"{x:604,y:517,t:1526933324107};\\\", \\\"{x:608,y:518,t:1526933324122};\\\", \\\"{x:616,y:519,t:1526933324138};\\\", \\\"{x:621,y:520,t:1526933324156};\\\", \\\"{x:626,y:521,t:1526933324172};\\\", \\\"{x:630,y:521,t:1526933324189};\\\", \\\"{x:632,y:521,t:1526933324210};\\\", \\\"{x:633,y:521,t:1526933324234};\\\", \\\"{x:635,y:521,t:1526933324267};\\\", \\\"{x:635,y:522,t:1526933324307};\\\", \\\"{x:636,y:522,t:1526933324403};\\\", \\\"{x:636,y:524,t:1526933325028};\\\", \\\"{x:636,y:525,t:1526933325051};\\\", \\\"{x:637,y:526,t:1526933325059};\\\", \\\"{x:639,y:529,t:1526933325073};\\\", \\\"{x:640,y:532,t:1526933325090};\\\", \\\"{x:643,y:535,t:1526933325106};\\\", \\\"{x:648,y:543,t:1526933325125};\\\", \\\"{x:651,y:546,t:1526933325140};\\\", \\\"{x:656,y:551,t:1526933325156};\\\", \\\"{x:662,y:557,t:1526933325173};\\\", \\\"{x:668,y:561,t:1526933325190};\\\", \\\"{x:673,y:566,t:1526933325206};\\\", \\\"{x:679,y:571,t:1526933325222};\\\", \\\"{x:690,y:582,t:1526933325240};\\\", \\\"{x:703,y:591,t:1526933325256};\\\", \\\"{x:721,y:602,t:1526933325273};\\\", \\\"{x:739,y:614,t:1526933325290};\\\", \\\"{x:754,y:628,t:1526933325305};\\\", \\\"{x:779,y:644,t:1526933325322};\\\", \\\"{x:797,y:656,t:1526933325340};\\\", \\\"{x:811,y:667,t:1526933325355};\\\", \\\"{x:826,y:677,t:1526933325372};\\\", \\\"{x:849,y:688,t:1526933325390};\\\", \\\"{x:867,y:697,t:1526933325407};\\\", \\\"{x:889,y:711,t:1526933325422};\\\", \\\"{x:911,y:722,t:1526933325440};\\\", \\\"{x:935,y:734,t:1526933325456};\\\", \\\"{x:957,y:743,t:1526933325473};\\\", \\\"{x:978,y:754,t:1526933325490};\\\", \\\"{x:1006,y:769,t:1526933325506};\\\", \\\"{x:1019,y:780,t:1526933325523};\\\", \\\"{x:1032,y:787,t:1526933325540};\\\", \\\"{x:1034,y:790,t:1526933325556};\\\", \\\"{x:1047,y:797,t:1526933325573};\\\", \\\"{x:1056,y:802,t:1526933325590};\\\", \\\"{x:1061,y:807,t:1526933325606};\\\", \\\"{x:1072,y:816,t:1526933325623};\\\", \\\"{x:1080,y:820,t:1526933325640};\\\", \\\"{x:1085,y:824,t:1526933325657};\\\", \\\"{x:1091,y:829,t:1526933325672};\\\", \\\"{x:1098,y:833,t:1526933325690};\\\", \\\"{x:1109,y:843,t:1526933325706};\\\", \\\"{x:1119,y:855,t:1526933325723};\\\", \\\"{x:1127,y:863,t:1526933325740};\\\", \\\"{x:1138,y:874,t:1526933325757};\\\", \\\"{x:1149,y:883,t:1526933325773};\\\", \\\"{x:1163,y:894,t:1526933325790};\\\", \\\"{x:1175,y:903,t:1526933325807};\\\", \\\"{x:1186,y:909,t:1526933325824};\\\", \\\"{x:1198,y:915,t:1526933325841};\\\", \\\"{x:1212,y:923,t:1526933325857};\\\", \\\"{x:1223,y:931,t:1526933325873};\\\", \\\"{x:1236,y:939,t:1526933325891};\\\", \\\"{x:1253,y:944,t:1526933325907};\\\", \\\"{x:1263,y:949,t:1526933325923};\\\", \\\"{x:1277,y:955,t:1526933325941};\\\", \\\"{x:1288,y:960,t:1526933325957};\\\", \\\"{x:1299,y:964,t:1526933325974};\\\", \\\"{x:1307,y:966,t:1526933325991};\\\", \\\"{x:1320,y:967,t:1526933326007};\\\", \\\"{x:1325,y:968,t:1526933326023};\\\", \\\"{x:1334,y:971,t:1526933326040};\\\", \\\"{x:1342,y:972,t:1526933326057};\\\", \\\"{x:1345,y:974,t:1526933326073};\\\", \\\"{x:1346,y:975,t:1526933326090};\\\", \\\"{x:1347,y:975,t:1526933326107};\\\", \\\"{x:1344,y:975,t:1526933326244};\\\", \\\"{x:1342,y:975,t:1526933326257};\\\", \\\"{x:1337,y:975,t:1526933326274};\\\", \\\"{x:1329,y:975,t:1526933326291};\\\", \\\"{x:1318,y:975,t:1526933326308};\\\", \\\"{x:1315,y:975,t:1526933326323};\\\", \\\"{x:1310,y:975,t:1526933326341};\\\", \\\"{x:1308,y:974,t:1526933326357};\\\", \\\"{x:1302,y:973,t:1526933326374};\\\", \\\"{x:1299,y:973,t:1526933326391};\\\", \\\"{x:1293,y:971,t:1526933326407};\\\", \\\"{x:1287,y:971,t:1526933326423};\\\", \\\"{x:1284,y:970,t:1526933326441};\\\", \\\"{x:1281,y:970,t:1526933326457};\\\", \\\"{x:1280,y:970,t:1526933326473};\\\", \\\"{x:1279,y:969,t:1526933326979};\\\", \\\"{x:1280,y:967,t:1526933327060};\\\", \\\"{x:1281,y:965,t:1526933327084};\\\", \\\"{x:1281,y:964,t:1526933327099};\\\", \\\"{x:1282,y:960,t:1526933327107};\\\", \\\"{x:1282,y:957,t:1526933327124};\\\", \\\"{x:1282,y:955,t:1526933327141};\\\", \\\"{x:1282,y:954,t:1526933327158};\\\", \\\"{x:1284,y:951,t:1526933327174};\\\", \\\"{x:1284,y:947,t:1526933327191};\\\", \\\"{x:1284,y:944,t:1526933327208};\\\", \\\"{x:1285,y:941,t:1526933327224};\\\", \\\"{x:1286,y:938,t:1526933327240};\\\", \\\"{x:1286,y:937,t:1526933327257};\\\", \\\"{x:1287,y:932,t:1526933327273};\\\", \\\"{x:1287,y:930,t:1526933327290};\\\", \\\"{x:1287,y:927,t:1526933327307};\\\", \\\"{x:1288,y:923,t:1526933327324};\\\", \\\"{x:1289,y:920,t:1526933327340};\\\", \\\"{x:1289,y:917,t:1526933327357};\\\", \\\"{x:1289,y:914,t:1526933327374};\\\", \\\"{x:1291,y:910,t:1526933327390};\\\", \\\"{x:1292,y:907,t:1526933327408};\\\", \\\"{x:1292,y:906,t:1526933327423};\\\", \\\"{x:1293,y:903,t:1526933327441};\\\", \\\"{x:1294,y:903,t:1526933327457};\\\", \\\"{x:1295,y:902,t:1526933327473};\\\", \\\"{x:1295,y:900,t:1526933327499};\\\", \\\"{x:1295,y:898,t:1526933327516};\\\", \\\"{x:1295,y:897,t:1526933327539};\\\", \\\"{x:1296,y:896,t:1526933327579};\\\", \\\"{x:1296,y:895,t:1526933327627};\\\", \\\"{x:1296,y:894,t:1526933327643};\\\", \\\"{x:1297,y:893,t:1526933327657};\\\", \\\"{x:1298,y:892,t:1526933327676};\\\", \\\"{x:1298,y:891,t:1526933327723};\\\", \\\"{x:1298,y:889,t:1526933327787};\\\", \\\"{x:1298,y:888,t:1526933327803};\\\", \\\"{x:1298,y:887,t:1526933327827};\\\", \\\"{x:1298,y:885,t:1526933327843};\\\", \\\"{x:1298,y:884,t:1526933327899};\\\", \\\"{x:1299,y:883,t:1526933327923};\\\", \\\"{x:1300,y:881,t:1526933328034};\\\", \\\"{x:1301,y:879,t:1526933328083};\\\", \\\"{x:1301,y:878,t:1526933328115};\\\", \\\"{x:1301,y:877,t:1526933328179};\\\", \\\"{x:1302,y:877,t:1526933328195};\\\", \\\"{x:1302,y:876,t:1526933328211};\\\", \\\"{x:1302,y:875,t:1526933328668};\\\", \\\"{x:1302,y:874,t:1526933328691};\\\", \\\"{x:1304,y:873,t:1526933328707};\\\", \\\"{x:1304,y:872,t:1526933328739};\\\", \\\"{x:1304,y:871,t:1526933328755};\\\", \\\"{x:1304,y:869,t:1526933328771};\\\", \\\"{x:1305,y:868,t:1526933328787};\\\", \\\"{x:1305,y:867,t:1526933328803};\\\", \\\"{x:1305,y:866,t:1526933328844};\\\", \\\"{x:1305,y:865,t:1526933328858};\\\", \\\"{x:1306,y:864,t:1526933328874};\\\", \\\"{x:1307,y:863,t:1526933328891};\\\", \\\"{x:1307,y:862,t:1526933328907};\\\", \\\"{x:1307,y:860,t:1526933328925};\\\", \\\"{x:1307,y:857,t:1526933328940};\\\", \\\"{x:1308,y:856,t:1526933328958};\\\", \\\"{x:1308,y:853,t:1526933328979};\\\", \\\"{x:1308,y:852,t:1526933328991};\\\", \\\"{x:1308,y:850,t:1526933329007};\\\", \\\"{x:1308,y:848,t:1526933329138};\\\", \\\"{x:1306,y:847,t:1526933329146};\\\", \\\"{x:1304,y:846,t:1526933329170};\\\", \\\"{x:1302,y:845,t:1526933329178};\\\", \\\"{x:1302,y:844,t:1526933329194};\\\", \\\"{x:1301,y:843,t:1526933329207};\\\", \\\"{x:1300,y:843,t:1526933329224};\\\", \\\"{x:1299,y:842,t:1526933329240};\\\", \\\"{x:1297,y:842,t:1526933329524};\\\", \\\"{x:1296,y:842,t:1526933329572};\\\", \\\"{x:1295,y:842,t:1526933329636};\\\", \\\"{x:1294,y:842,t:1526933329715};\\\", \\\"{x:1293,y:842,t:1526933329923};\\\", \\\"{x:1293,y:843,t:1526933330082};\\\", \\\"{x:1292,y:844,t:1526933330348};\\\", \\\"{x:1291,y:844,t:1526933330357};\\\", \\\"{x:1289,y:842,t:1526933330375};\\\", \\\"{x:1284,y:841,t:1526933330392};\\\", \\\"{x:1282,y:840,t:1526933330407};\\\", \\\"{x:1281,y:839,t:1526933330425};\\\", \\\"{x:1281,y:838,t:1526933331299};\\\", \\\"{x:1276,y:836,t:1526933331690};\\\", \\\"{x:1255,y:830,t:1526933331707};\\\", \\\"{x:1217,y:821,t:1526933331724};\\\", \\\"{x:1139,y:811,t:1526933331741};\\\", \\\"{x:1052,y:796,t:1526933331757};\\\", \\\"{x:956,y:774,t:1526933331774};\\\", \\\"{x:858,y:752,t:1526933331791};\\\", \\\"{x:752,y:718,t:1526933331808};\\\", \\\"{x:648,y:698,t:1526933331824};\\\", \\\"{x:548,y:668,t:1526933331841};\\\", \\\"{x:468,y:645,t:1526933331858};\\\", \\\"{x:378,y:625,t:1526933331874};\\\", \\\"{x:339,y:616,t:1526933331891};\\\", \\\"{x:311,y:609,t:1526933331910};\\\", \\\"{x:300,y:602,t:1526933331927};\\\", \\\"{x:284,y:599,t:1526933331945};\\\", \\\"{x:271,y:595,t:1526933331963};\\\", \\\"{x:270,y:595,t:1526933331977};\\\", \\\"{x:259,y:592,t:1526933331995};\\\", \\\"{x:254,y:590,t:1526933332012};\\\", \\\"{x:248,y:588,t:1526933332028};\\\", \\\"{x:246,y:587,t:1526933332045};\\\", \\\"{x:244,y:585,t:1526933332062};\\\", \\\"{x:240,y:582,t:1526933332078};\\\", \\\"{x:239,y:582,t:1526933332095};\\\", \\\"{x:240,y:582,t:1526933332747};\\\", \\\"{x:243,y:582,t:1526933332771};\\\", \\\"{x:244,y:582,t:1526933332779};\\\", \\\"{x:251,y:582,t:1526933332796};\\\", \\\"{x:256,y:582,t:1526933332812};\\\", \\\"{x:263,y:585,t:1526933332830};\\\", \\\"{x:271,y:585,t:1526933332847};\\\", \\\"{x:277,y:585,t:1526933332864};\\\", \\\"{x:284,y:586,t:1526933332879};\\\", \\\"{x:289,y:587,t:1526933332896};\\\", \\\"{x:294,y:587,t:1526933332913};\\\", \\\"{x:299,y:589,t:1526933332929};\\\", \\\"{x:308,y:589,t:1526933332946};\\\", \\\"{x:310,y:590,t:1526933332963};\\\", \\\"{x:314,y:591,t:1526933332979};\\\", \\\"{x:316,y:591,t:1526933332996};\\\", \\\"{x:320,y:592,t:1526933333013};\\\", \\\"{x:322,y:592,t:1526933333029};\\\", \\\"{x:324,y:592,t:1526933333046};\\\", \\\"{x:327,y:592,t:1526933333063};\\\", \\\"{x:331,y:592,t:1526933333079};\\\", \\\"{x:335,y:592,t:1526933333096};\\\", \\\"{x:338,y:592,t:1526933333113};\\\", \\\"{x:343,y:592,t:1526933333129};\\\", \\\"{x:352,y:592,t:1526933333147};\\\", \\\"{x:356,y:592,t:1526933333163};\\\", \\\"{x:360,y:592,t:1526933333179};\\\", \\\"{x:362,y:592,t:1526933333197};\\\", \\\"{x:364,y:592,t:1526933333213};\\\", \\\"{x:367,y:592,t:1526933333230};\\\", \\\"{x:369,y:592,t:1526933333247};\\\", \\\"{x:370,y:592,t:1526933333266};\\\", \\\"{x:373,y:592,t:1526933333315};\\\", \\\"{x:373,y:591,t:1526933333331};\\\", \\\"{x:373,y:590,t:1526933333347};\\\", \\\"{x:374,y:590,t:1526933333364};\\\", \\\"{x:374,y:584,t:1526933333381};\\\", \\\"{x:374,y:582,t:1526933333395};\\\", \\\"{x:378,y:577,t:1526933333414};\\\", \\\"{x:379,y:571,t:1526933333430};\\\", \\\"{x:381,y:567,t:1526933333446};\\\", \\\"{x:384,y:561,t:1526933333463};\\\", \\\"{x:385,y:559,t:1526933333480};\\\", \\\"{x:386,y:556,t:1526933333496};\\\", \\\"{x:387,y:555,t:1526933333513};\\\", \\\"{x:387,y:550,t:1526933333530};\\\", \\\"{x:389,y:548,t:1526933333547};\\\", \\\"{x:390,y:546,t:1526933333563};\\\", \\\"{x:391,y:544,t:1526933333580};\\\", \\\"{x:392,y:541,t:1526933333596};\\\", \\\"{x:394,y:537,t:1526933333613};\\\", \\\"{x:395,y:536,t:1526933333630};\\\", \\\"{x:395,y:534,t:1526933333646};\\\", \\\"{x:395,y:533,t:1526933333691};\\\", \\\"{x:395,y:532,t:1526933333746};\\\", \\\"{x:395,y:531,t:1526933333763};\\\", \\\"{x:395,y:530,t:1526933333781};\\\", \\\"{x:395,y:529,t:1526933333842};\\\", \\\"{x:395,y:528,t:1526933333906};\\\", \\\"{x:395,y:527,t:1526933334739};\\\", \\\"{x:394,y:529,t:1526933334748};\\\", \\\"{x:397,y:542,t:1526933334766};\\\", \\\"{x:399,y:559,t:1526933334782};\\\", \\\"{x:407,y:579,t:1526933334799};\\\", \\\"{x:414,y:597,t:1526933334814};\\\", \\\"{x:423,y:612,t:1526933334831};\\\", \\\"{x:434,y:626,t:1526933334848};\\\", \\\"{x:440,y:638,t:1526933334864};\\\", \\\"{x:450,y:648,t:1526933334881};\\\", \\\"{x:461,y:657,t:1526933334898};\\\", \\\"{x:466,y:663,t:1526933334913};\\\", \\\"{x:473,y:667,t:1526933334931};\\\", \\\"{x:479,y:671,t:1526933334948};\\\", \\\"{x:487,y:675,t:1526933334964};\\\", \\\"{x:492,y:677,t:1526933334981};\\\", \\\"{x:499,y:680,t:1526933334998};\\\", \\\"{x:502,y:682,t:1526933335014};\\\", \\\"{x:505,y:683,t:1526933335031};\\\", \\\"{x:506,y:684,t:1526933335049};\\\", \\\"{x:507,y:685,t:1526933335064};\\\", \\\"{x:509,y:686,t:1526933335081};\\\", \\\"{x:510,y:687,t:1526933335106};\\\", \\\"{x:511,y:688,t:1526933335123};\\\", \\\"{x:511,y:689,t:1526933335138};\\\", \\\"{x:511,y:691,t:1526933335149};\\\", \\\"{x:512,y:691,t:1526933335165};\\\", \\\"{x:513,y:693,t:1526933335182};\\\", \\\"{x:513,y:694,t:1526933335199};\\\", \\\"{x:514,y:695,t:1526933335214};\\\", \\\"{x:515,y:698,t:1526933335231};\\\", \\\"{x:516,y:700,t:1526933335249};\\\", \\\"{x:517,y:702,t:1526933335268};\\\", \\\"{x:518,y:702,t:1526933335362};\\\", \\\"{x:518,y:703,t:1526933335579};\\\", \\\"{x:518,y:704,t:1526933335603};\\\", \\\"{x:518,y:705,t:1526933335619};\\\", \\\"{x:518,y:706,t:1526933335632};\\\", \\\"{x:518,y:708,t:1526933335907};\\\", \\\"{x:518,y:709,t:1526933335931};\\\", \\\"{x:518,y:710,t:1526933335955};\\\", \\\"{x:518,y:711,t:1526933336251};\\\", \\\"{x:518,y:712,t:1526933336266};\\\", \\\"{x:518,y:713,t:1526933336299};\\\", \\\"{x:518,y:714,t:1526933336339};\\\" ] }, { \\\"rt\\\": 25525, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 204248, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -U -03 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:714,t:1526933339442};\\\", \\\"{x:524,y:713,t:1526933339451};\\\", \\\"{x:533,y:703,t:1526933339467};\\\", \\\"{x:542,y:692,t:1526933339485};\\\", \\\"{x:549,y:681,t:1526933339501};\\\", \\\"{x:557,y:670,t:1526933339518};\\\", \\\"{x:564,y:660,t:1526933339535};\\\", \\\"{x:570,y:650,t:1526933339551};\\\", \\\"{x:573,y:646,t:1526933339568};\\\", \\\"{x:574,y:645,t:1526933339586};\\\", \\\"{x:575,y:644,t:1526933339674};\\\", \\\"{x:576,y:643,t:1526933339698};\\\", \\\"{x:576,y:642,t:1526933339730};\\\", \\\"{x:576,y:641,t:1526933339746};\\\", \\\"{x:577,y:641,t:1526933339762};\\\", \\\"{x:577,y:637,t:1526933339903};\\\", \\\"{x:576,y:635,t:1526933339930};\\\", \\\"{x:575,y:635,t:1526933339937};\\\", \\\"{x:573,y:635,t:1526933339954};\\\", \\\"{x:573,y:634,t:1526933339968};\\\", \\\"{x:570,y:632,t:1526933339985};\\\", \\\"{x:568,y:631,t:1526933340001};\\\", \\\"{x:562,y:629,t:1526933340018};\\\", \\\"{x:560,y:628,t:1526933340036};\\\", \\\"{x:555,y:626,t:1526933340051};\\\", \\\"{x:550,y:625,t:1526933340068};\\\", \\\"{x:544,y:622,t:1526933340085};\\\", \\\"{x:534,y:620,t:1526933340101};\\\", \\\"{x:528,y:618,t:1526933340118};\\\", \\\"{x:527,y:617,t:1526933340135};\\\", \\\"{x:525,y:616,t:1526933340153};\\\", \\\"{x:525,y:615,t:1526933340887};\\\", \\\"{x:525,y:614,t:1526933341087};\\\", \\\"{x:525,y:612,t:1526933341336};\\\", \\\"{x:525,y:611,t:1526933342062};\\\", \\\"{x:527,y:611,t:1526933342073};\\\", \\\"{x:541,y:611,t:1526933342089};\\\", \\\"{x:559,y:612,t:1526933342107};\\\", \\\"{x:593,y:623,t:1526933342124};\\\", \\\"{x:647,y:634,t:1526933342139};\\\", \\\"{x:709,y:653,t:1526933342157};\\\", \\\"{x:800,y:685,t:1526933342174};\\\", \\\"{x:880,y:703,t:1526933342191};\\\", \\\"{x:941,y:720,t:1526933342207};\\\", \\\"{x:989,y:736,t:1526933342224};\\\", \\\"{x:1018,y:747,t:1526933342241};\\\", \\\"{x:1039,y:754,t:1526933342257};\\\", \\\"{x:1058,y:761,t:1526933342274};\\\", \\\"{x:1075,y:766,t:1526933342291};\\\", \\\"{x:1085,y:771,t:1526933342307};\\\", \\\"{x:1094,y:772,t:1526933342324};\\\", \\\"{x:1102,y:774,t:1526933342342};\\\", \\\"{x:1111,y:775,t:1526933342357};\\\", \\\"{x:1127,y:780,t:1526933342374};\\\", \\\"{x:1135,y:782,t:1526933342391};\\\", \\\"{x:1144,y:784,t:1526933342407};\\\", \\\"{x:1152,y:787,t:1526933342424};\\\", \\\"{x:1158,y:789,t:1526933342441};\\\", \\\"{x:1164,y:791,t:1526933342456};\\\", \\\"{x:1166,y:792,t:1526933342475};\\\", \\\"{x:1172,y:792,t:1526933342491};\\\", \\\"{x:1175,y:793,t:1526933342507};\\\", \\\"{x:1182,y:796,t:1526933342524};\\\", \\\"{x:1187,y:799,t:1526933342541};\\\", \\\"{x:1194,y:801,t:1526933342558};\\\", \\\"{x:1205,y:804,t:1526933342574};\\\", \\\"{x:1212,y:806,t:1526933342592};\\\", \\\"{x:1218,y:807,t:1526933342608};\\\", \\\"{x:1224,y:810,t:1526933342625};\\\", \\\"{x:1232,y:812,t:1526933342641};\\\", \\\"{x:1242,y:816,t:1526933342657};\\\", \\\"{x:1248,y:818,t:1526933342674};\\\", \\\"{x:1253,y:818,t:1526933342691};\\\", \\\"{x:1256,y:820,t:1526933342708};\\\", \\\"{x:1259,y:821,t:1526933342724};\\\", \\\"{x:1260,y:821,t:1526933342741};\\\", \\\"{x:1266,y:822,t:1526933342757};\\\", \\\"{x:1268,y:822,t:1526933342774};\\\", \\\"{x:1270,y:824,t:1526933342791};\\\", \\\"{x:1273,y:824,t:1526933342808};\\\", \\\"{x:1277,y:825,t:1526933342824};\\\", \\\"{x:1286,y:827,t:1526933342843};\\\", \\\"{x:1293,y:828,t:1526933342859};\\\", \\\"{x:1303,y:829,t:1526933342874};\\\", \\\"{x:1316,y:831,t:1526933342891};\\\", \\\"{x:1325,y:833,t:1526933342908};\\\", \\\"{x:1339,y:836,t:1526933342924};\\\", \\\"{x:1345,y:837,t:1526933342941};\\\", \\\"{x:1363,y:839,t:1526933342958};\\\", \\\"{x:1373,y:839,t:1526933342974};\\\", \\\"{x:1385,y:839,t:1526933342991};\\\", \\\"{x:1386,y:839,t:1526933343014};\\\", \\\"{x:1389,y:839,t:1526933343025};\\\", \\\"{x:1397,y:839,t:1526933343041};\\\", \\\"{x:1406,y:839,t:1526933343058};\\\", \\\"{x:1423,y:839,t:1526933343074};\\\", \\\"{x:1429,y:839,t:1526933343091};\\\", \\\"{x:1435,y:837,t:1526933343108};\\\", \\\"{x:1444,y:837,t:1526933343125};\\\", \\\"{x:1453,y:836,t:1526933343141};\\\", \\\"{x:1465,y:835,t:1526933343158};\\\", \\\"{x:1474,y:835,t:1526933343175};\\\", \\\"{x:1483,y:833,t:1526933343191};\\\", \\\"{x:1491,y:833,t:1526933343209};\\\", \\\"{x:1504,y:832,t:1526933343225};\\\", \\\"{x:1515,y:832,t:1526933343241};\\\", \\\"{x:1524,y:832,t:1526933343258};\\\", \\\"{x:1536,y:832,t:1526933343275};\\\", \\\"{x:1547,y:832,t:1526933343291};\\\", \\\"{x:1564,y:832,t:1526933343308};\\\", \\\"{x:1578,y:831,t:1526933343325};\\\", \\\"{x:1593,y:831,t:1526933343341};\\\", \\\"{x:1623,y:831,t:1526933343358};\\\", \\\"{x:1638,y:831,t:1526933343375};\\\", \\\"{x:1653,y:831,t:1526933343391};\\\", \\\"{x:1659,y:830,t:1526933343408};\\\", \\\"{x:1665,y:830,t:1526933343425};\\\", \\\"{x:1668,y:829,t:1526933343442};\\\", \\\"{x:1670,y:828,t:1526933343458};\\\", \\\"{x:1671,y:828,t:1526933343485};\\\", \\\"{x:1672,y:827,t:1526933343501};\\\", \\\"{x:1673,y:827,t:1526933343525};\\\", \\\"{x:1674,y:827,t:1526933343541};\\\", \\\"{x:1675,y:826,t:1526933343557};\\\", \\\"{x:1675,y:825,t:1526933343597};\\\", \\\"{x:1675,y:823,t:1526933343629};\\\", \\\"{x:1675,y:822,t:1526933343642};\\\", \\\"{x:1674,y:821,t:1526933343658};\\\", \\\"{x:1671,y:819,t:1526933343675};\\\", \\\"{x:1667,y:816,t:1526933343692};\\\", \\\"{x:1659,y:808,t:1526933343708};\\\", \\\"{x:1648,y:799,t:1526933343725};\\\", \\\"{x:1638,y:791,t:1526933343742};\\\", \\\"{x:1628,y:784,t:1526933343758};\\\", \\\"{x:1620,y:776,t:1526933343775};\\\", \\\"{x:1613,y:762,t:1526933343792};\\\", \\\"{x:1604,y:749,t:1526933343808};\\\", \\\"{x:1596,y:740,t:1526933343825};\\\", \\\"{x:1591,y:735,t:1526933343842};\\\", \\\"{x:1586,y:728,t:1526933343858};\\\", \\\"{x:1582,y:723,t:1526933343875};\\\", \\\"{x:1579,y:716,t:1526933343892};\\\", \\\"{x:1576,y:709,t:1526933343908};\\\", \\\"{x:1572,y:703,t:1526933343925};\\\", \\\"{x:1566,y:694,t:1526933343942};\\\", \\\"{x:1562,y:689,t:1526933343958};\\\", \\\"{x:1556,y:682,t:1526933343975};\\\", \\\"{x:1552,y:676,t:1526933343993};\\\", \\\"{x:1548,y:668,t:1526933344008};\\\", \\\"{x:1544,y:659,t:1526933344025};\\\", \\\"{x:1538,y:654,t:1526933344042};\\\", \\\"{x:1529,y:647,t:1526933344058};\\\", \\\"{x:1524,y:643,t:1526933344075};\\\", \\\"{x:1519,y:641,t:1526933344093};\\\", \\\"{x:1512,y:636,t:1526933344110};\\\", \\\"{x:1497,y:632,t:1526933344126};\\\", \\\"{x:1457,y:609,t:1526933344142};\\\", \\\"{x:1433,y:596,t:1526933344160};\\\", \\\"{x:1418,y:583,t:1526933344176};\\\", \\\"{x:1408,y:576,t:1526933344193};\\\", \\\"{x:1401,y:571,t:1526933344210};\\\", \\\"{x:1387,y:563,t:1526933344225};\\\", \\\"{x:1368,y:549,t:1526933344243};\\\", \\\"{x:1349,y:534,t:1526933344259};\\\", \\\"{x:1327,y:518,t:1526933344276};\\\", \\\"{x:1313,y:506,t:1526933344293};\\\", \\\"{x:1301,y:494,t:1526933344309};\\\", \\\"{x:1292,y:485,t:1526933344326};\\\", \\\"{x:1278,y:474,t:1526933344342};\\\", \\\"{x:1269,y:465,t:1526933344360};\\\", \\\"{x:1265,y:454,t:1526933344375};\\\", \\\"{x:1265,y:432,t:1526933344392};\\\", \\\"{x:1265,y:400,t:1526933344409};\\\", \\\"{x:1272,y:356,t:1526933344426};\\\", \\\"{x:1293,y:291,t:1526933344442};\\\", \\\"{x:1311,y:238,t:1526933344459};\\\", \\\"{x:1327,y:215,t:1526933344476};\\\", \\\"{x:1340,y:193,t:1526933344492};\\\", \\\"{x:1360,y:176,t:1526933344509};\\\", \\\"{x:1381,y:160,t:1526933344525};\\\", \\\"{x:1388,y:154,t:1526933344542};\\\", \\\"{x:1393,y:152,t:1526933344559};\\\", \\\"{x:1397,y:152,t:1526933344576};\\\", \\\"{x:1400,y:152,t:1526933344630};\\\", \\\"{x:1402,y:153,t:1526933344642};\\\", \\\"{x:1410,y:161,t:1526933344659};\\\", \\\"{x:1417,y:178,t:1526933344676};\\\", \\\"{x:1430,y:211,t:1526933344691};\\\", \\\"{x:1437,y:245,t:1526933344709};\\\", \\\"{x:1443,y:297,t:1526933344726};\\\", \\\"{x:1443,y:324,t:1526933344742};\\\", \\\"{x:1443,y:357,t:1526933344759};\\\", \\\"{x:1442,y:384,t:1526933344776};\\\", \\\"{x:1440,y:409,t:1526933344792};\\\", \\\"{x:1434,y:428,t:1526933344809};\\\", \\\"{x:1426,y:443,t:1526933344826};\\\", \\\"{x:1417,y:458,t:1526933344842};\\\", \\\"{x:1413,y:465,t:1526933344860};\\\", \\\"{x:1408,y:473,t:1526933344876};\\\", \\\"{x:1403,y:478,t:1526933344892};\\\", \\\"{x:1397,y:486,t:1526933344909};\\\", \\\"{x:1391,y:494,t:1526933344926};\\\", \\\"{x:1386,y:499,t:1526933344943};\\\", \\\"{x:1380,y:508,t:1526933344960};\\\", \\\"{x:1374,y:515,t:1526933344976};\\\", \\\"{x:1370,y:522,t:1526933344994};\\\", \\\"{x:1364,y:531,t:1526933345010};\\\", \\\"{x:1356,y:541,t:1526933345027};\\\", \\\"{x:1352,y:546,t:1526933345043};\\\", \\\"{x:1347,y:555,t:1526933345059};\\\", \\\"{x:1343,y:563,t:1526933345077};\\\", \\\"{x:1339,y:572,t:1526933345094};\\\", \\\"{x:1335,y:581,t:1526933345110};\\\", \\\"{x:1329,y:595,t:1526933345126};\\\", \\\"{x:1328,y:602,t:1526933345144};\\\", \\\"{x:1325,y:610,t:1526933345160};\\\", \\\"{x:1323,y:622,t:1526933345177};\\\", \\\"{x:1323,y:634,t:1526933345193};\\\", \\\"{x:1319,y:647,t:1526933345209};\\\", \\\"{x:1318,y:651,t:1526933345227};\\\", \\\"{x:1316,y:662,t:1526933345243};\\\", \\\"{x:1315,y:676,t:1526933345259};\\\", \\\"{x:1311,y:687,t:1526933345276};\\\", \\\"{x:1311,y:699,t:1526933345293};\\\", \\\"{x:1311,y:721,t:1526933345310};\\\", \\\"{x:1311,y:732,t:1526933345326};\\\", \\\"{x:1310,y:748,t:1526933345343};\\\", \\\"{x:1309,y:762,t:1526933345360};\\\", \\\"{x:1309,y:770,t:1526933345376};\\\", \\\"{x:1307,y:780,t:1526933345393};\\\", \\\"{x:1304,y:789,t:1526933345410};\\\", \\\"{x:1302,y:796,t:1526933345426};\\\", \\\"{x:1300,y:805,t:1526933345443};\\\", \\\"{x:1295,y:814,t:1526933345460};\\\", \\\"{x:1288,y:827,t:1526933345477};\\\", \\\"{x:1283,y:838,t:1526933345493};\\\", \\\"{x:1278,y:846,t:1526933345509};\\\", \\\"{x:1276,y:849,t:1526933345526};\\\", \\\"{x:1274,y:851,t:1526933345543};\\\", \\\"{x:1273,y:852,t:1526933345560};\\\", \\\"{x:1272,y:852,t:1526933345577};\\\", \\\"{x:1268,y:856,t:1526933345593};\\\", \\\"{x:1267,y:858,t:1526933345611};\\\", \\\"{x:1264,y:859,t:1526933345627};\\\", \\\"{x:1264,y:860,t:1526933345643};\\\", \\\"{x:1264,y:861,t:1526933345662};\\\", \\\"{x:1263,y:862,t:1526933345686};\\\", \\\"{x:1262,y:862,t:1526933345694};\\\", \\\"{x:1261,y:862,t:1526933345727};\\\", \\\"{x:1258,y:864,t:1526933345743};\\\", \\\"{x:1255,y:864,t:1526933345761};\\\", \\\"{x:1253,y:864,t:1526933345776};\\\", \\\"{x:1251,y:864,t:1526933345798};\\\", \\\"{x:1248,y:864,t:1526933345811};\\\", \\\"{x:1245,y:864,t:1526933345828};\\\", \\\"{x:1241,y:864,t:1526933345843};\\\", \\\"{x:1239,y:864,t:1526933345861};\\\", \\\"{x:1238,y:864,t:1526933345877};\\\", \\\"{x:1235,y:864,t:1526933345894};\\\", \\\"{x:1233,y:864,t:1526933345910};\\\", \\\"{x:1231,y:863,t:1526933345928};\\\", \\\"{x:1229,y:863,t:1526933345967};\\\", \\\"{x:1228,y:863,t:1526933345999};\\\", \\\"{x:1226,y:862,t:1526933346015};\\\", \\\"{x:1225,y:862,t:1526933346029};\\\", \\\"{x:1224,y:862,t:1526933346043};\\\", \\\"{x:1223,y:860,t:1526933346060};\\\", \\\"{x:1222,y:860,t:1526933346078};\\\", \\\"{x:1225,y:861,t:1526933346271};\\\", \\\"{x:1228,y:862,t:1526933346278};\\\", \\\"{x:1234,y:864,t:1526933346295};\\\", \\\"{x:1244,y:867,t:1526933346311};\\\", \\\"{x:1256,y:869,t:1526933346328};\\\", \\\"{x:1266,y:870,t:1526933346345};\\\", \\\"{x:1273,y:872,t:1526933346361};\\\", \\\"{x:1280,y:874,t:1526933346377};\\\", \\\"{x:1286,y:876,t:1526933346395};\\\", \\\"{x:1289,y:876,t:1526933346411};\\\", \\\"{x:1295,y:876,t:1526933346428};\\\", \\\"{x:1297,y:876,t:1526933346445};\\\", \\\"{x:1301,y:876,t:1526933346461};\\\", \\\"{x:1304,y:876,t:1526933346478};\\\", \\\"{x:1305,y:876,t:1526933346495};\\\", \\\"{x:1309,y:876,t:1526933346511};\\\", \\\"{x:1310,y:875,t:1526933346535};\\\", \\\"{x:1311,y:875,t:1526933346655};\\\", \\\"{x:1312,y:875,t:1526933346735};\\\", \\\"{x:1312,y:874,t:1526933346829};\\\", \\\"{x:1312,y:873,t:1526933346845};\\\", \\\"{x:1312,y:872,t:1526933346869};\\\", \\\"{x:1312,y:871,t:1526933346918};\\\", \\\"{x:1313,y:870,t:1526933346958};\\\", \\\"{x:1313,y:866,t:1526933347639};\\\", \\\"{x:1315,y:863,t:1526933347646};\\\", \\\"{x:1317,y:860,t:1526933347662};\\\", \\\"{x:1327,y:844,t:1526933347678};\\\", \\\"{x:1338,y:821,t:1526933347696};\\\", \\\"{x:1352,y:801,t:1526933347712};\\\", \\\"{x:1372,y:776,t:1526933347728};\\\", \\\"{x:1386,y:742,t:1526933347746};\\\", \\\"{x:1422,y:692,t:1526933347762};\\\", \\\"{x:1456,y:634,t:1526933347779};\\\", \\\"{x:1485,y:589,t:1526933347796};\\\", \\\"{x:1505,y:556,t:1526933347812};\\\", \\\"{x:1522,y:523,t:1526933347829};\\\", \\\"{x:1535,y:490,t:1526933347846};\\\", \\\"{x:1543,y:468,t:1526933347862};\\\", \\\"{x:1551,y:442,t:1526933347879};\\\", \\\"{x:1557,y:428,t:1526933347896};\\\", \\\"{x:1559,y:412,t:1526933347912};\\\", \\\"{x:1560,y:401,t:1526933347929};\\\", \\\"{x:1561,y:392,t:1526933347946};\\\", \\\"{x:1564,y:383,t:1526933347961};\\\", \\\"{x:1566,y:376,t:1526933347978};\\\", \\\"{x:1569,y:368,t:1526933347995};\\\", \\\"{x:1571,y:364,t:1526933348012};\\\", \\\"{x:1572,y:364,t:1526933348045};\\\", \\\"{x:1574,y:364,t:1526933348061};\\\", \\\"{x:1575,y:366,t:1526933348079};\\\", \\\"{x:1576,y:368,t:1526933348095};\\\", \\\"{x:1578,y:373,t:1526933348113};\\\", \\\"{x:1579,y:378,t:1526933348128};\\\", \\\"{x:1580,y:381,t:1526933348145};\\\", \\\"{x:1582,y:386,t:1526933348163};\\\", \\\"{x:1583,y:390,t:1526933348179};\\\", \\\"{x:1583,y:393,t:1526933348196};\\\", \\\"{x:1583,y:396,t:1526933348212};\\\", \\\"{x:1583,y:398,t:1526933348229};\\\", \\\"{x:1583,y:399,t:1526933348245};\\\", \\\"{x:1583,y:406,t:1526933348262};\\\", \\\"{x:1580,y:412,t:1526933348278};\\\", \\\"{x:1572,y:419,t:1526933348295};\\\", \\\"{x:1557,y:424,t:1526933348312};\\\", \\\"{x:1534,y:431,t:1526933348328};\\\", \\\"{x:1512,y:434,t:1526933348345};\\\", \\\"{x:1490,y:434,t:1526933348362};\\\", \\\"{x:1452,y:434,t:1526933348378};\\\", \\\"{x:1393,y:434,t:1526933348396};\\\", \\\"{x:1303,y:433,t:1526933348412};\\\", \\\"{x:1208,y:430,t:1526933348429};\\\", \\\"{x:1126,y:424,t:1526933348445};\\\", \\\"{x:1073,y:422,t:1526933348462};\\\", \\\"{x:1045,y:417,t:1526933348480};\\\", \\\"{x:1021,y:413,t:1526933348495};\\\", \\\"{x:1007,y:412,t:1526933348512};\\\", \\\"{x:986,y:412,t:1526933348529};\\\", \\\"{x:968,y:412,t:1526933348545};\\\", \\\"{x:949,y:412,t:1526933348562};\\\", \\\"{x:930,y:412,t:1526933348579};\\\", \\\"{x:913,y:412,t:1526933348595};\\\", \\\"{x:898,y:412,t:1526933348612};\\\", \\\"{x:879,y:413,t:1526933348629};\\\", \\\"{x:856,y:413,t:1526933348645};\\\", \\\"{x:824,y:413,t:1526933348662};\\\", \\\"{x:803,y:413,t:1526933348679};\\\", \\\"{x:778,y:413,t:1526933348696};\\\", \\\"{x:751,y:413,t:1526933348712};\\\", \\\"{x:733,y:413,t:1526933348729};\\\", \\\"{x:713,y:413,t:1526933348746};\\\", \\\"{x:700,y:413,t:1526933348762};\\\", \\\"{x:695,y:413,t:1526933348779};\\\", \\\"{x:681,y:414,t:1526933348795};\\\", \\\"{x:659,y:420,t:1526933348813};\\\", \\\"{x:643,y:425,t:1526933348830};\\\", \\\"{x:627,y:433,t:1526933348847};\\\", \\\"{x:612,y:441,t:1526933348862};\\\", \\\"{x:597,y:448,t:1526933348880};\\\", \\\"{x:582,y:456,t:1526933348896};\\\", \\\"{x:575,y:465,t:1526933348913};\\\", \\\"{x:564,y:471,t:1526933348929};\\\", \\\"{x:551,y:480,t:1526933348947};\\\", \\\"{x:544,y:486,t:1526933348963};\\\", \\\"{x:540,y:489,t:1526933348980};\\\", \\\"{x:536,y:493,t:1526933348997};\\\", \\\"{x:528,y:498,t:1526933349012};\\\", \\\"{x:518,y:506,t:1526933349031};\\\", \\\"{x:500,y:520,t:1526933349046};\\\", \\\"{x:490,y:524,t:1526933349063};\\\", \\\"{x:482,y:529,t:1526933349079};\\\", \\\"{x:480,y:531,t:1526933349091};\\\", \\\"{x:477,y:534,t:1526933349108};\\\", \\\"{x:470,y:539,t:1526933349126};\\\", \\\"{x:462,y:548,t:1526933349143};\\\", \\\"{x:459,y:549,t:1526933349162};\\\", \\\"{x:454,y:552,t:1526933349179};\\\", \\\"{x:453,y:552,t:1526933349196};\\\", \\\"{x:452,y:553,t:1526933349212};\\\", \\\"{x:450,y:554,t:1526933349229};\\\", \\\"{x:448,y:557,t:1526933349246};\\\", \\\"{x:448,y:558,t:1526933349262};\\\", \\\"{x:448,y:559,t:1526933349807};\\\", \\\"{x:448,y:560,t:1526933349814};\\\", \\\"{x:448,y:561,t:1526933349828};\\\", \\\"{x:448,y:562,t:1526933349869};\\\", \\\"{x:448,y:563,t:1526933349878};\\\", \\\"{x:448,y:564,t:1526933349917};\\\", \\\"{x:448,y:565,t:1526933349949};\\\", \\\"{x:448,y:566,t:1526933349973};\\\", \\\"{x:448,y:567,t:1526933349982};\\\", \\\"{x:448,y:568,t:1526933350062};\\\", \\\"{x:448,y:569,t:1526933350086};\\\", \\\"{x:448,y:570,t:1526933350110};\\\", \\\"{x:448,y:571,t:1526933350133};\\\", \\\"{x:448,y:572,t:1526933350149};\\\", \\\"{x:448,y:573,t:1526933350160};\\\", \\\"{x:448,y:574,t:1526933350206};\\\", \\\"{x:448,y:575,t:1526933350238};\\\", \\\"{x:446,y:577,t:1526933350286};\\\", \\\"{x:446,y:579,t:1526933350334};\\\", \\\"{x:446,y:580,t:1526933350374};\\\", \\\"{x:446,y:582,t:1526933350446};\\\", \\\"{x:446,y:583,t:1526933350478};\\\", \\\"{x:446,y:584,t:1526933350494};\\\", \\\"{x:447,y:586,t:1526933350517};\\\", \\\"{x:447,y:588,t:1526933350549};\\\", \\\"{x:447,y:589,t:1526933350566};\\\", \\\"{x:447,y:592,t:1526933350580};\\\", \\\"{x:454,y:597,t:1526933350597};\\\", \\\"{x:461,y:602,t:1526933350614};\\\", \\\"{x:467,y:607,t:1526933350630};\\\", \\\"{x:481,y:613,t:1526933350648};\\\", \\\"{x:496,y:621,t:1526933350665};\\\", \\\"{x:518,y:634,t:1526933350682};\\\", \\\"{x:533,y:645,t:1526933350697};\\\", \\\"{x:572,y:661,t:1526933350715};\\\", \\\"{x:597,y:675,t:1526933350732};\\\", \\\"{x:650,y:687,t:1526933350747};\\\", \\\"{x:694,y:696,t:1526933350764};\\\", \\\"{x:789,y:709,t:1526933350781};\\\", \\\"{x:933,y:734,t:1526933350798};\\\", \\\"{x:1022,y:748,t:1526933350815};\\\", \\\"{x:1105,y:770,t:1526933350832};\\\", \\\"{x:1198,y:790,t:1526933350848};\\\", \\\"{x:1275,y:808,t:1526933350865};\\\", \\\"{x:1342,y:818,t:1526933350882};\\\", \\\"{x:1403,y:833,t:1526933350898};\\\", \\\"{x:1441,y:842,t:1526933350915};\\\", \\\"{x:1459,y:852,t:1526933350931};\\\", \\\"{x:1491,y:859,t:1526933350948};\\\", \\\"{x:1507,y:863,t:1526933350964};\\\", \\\"{x:1530,y:866,t:1526933350981};\\\", \\\"{x:1544,y:869,t:1526933350998};\\\", \\\"{x:1557,y:874,t:1526933351014};\\\", \\\"{x:1577,y:880,t:1526933351031};\\\", \\\"{x:1591,y:882,t:1526933351047};\\\", \\\"{x:1598,y:884,t:1526933351065};\\\", \\\"{x:1601,y:885,t:1526933351081};\\\", \\\"{x:1602,y:887,t:1526933351110};\\\", \\\"{x:1604,y:888,t:1526933351118};\\\", \\\"{x:1605,y:889,t:1526933351131};\\\", \\\"{x:1608,y:891,t:1526933351149};\\\", \\\"{x:1608,y:893,t:1526933351166};\\\", \\\"{x:1609,y:893,t:1526933351182};\\\", \\\"{x:1609,y:894,t:1526933351222};\\\", \\\"{x:1610,y:895,t:1526933351232};\\\", \\\"{x:1610,y:898,t:1526933351249};\\\", \\\"{x:1611,y:901,t:1526933351264};\\\", \\\"{x:1611,y:907,t:1526933351281};\\\", \\\"{x:1611,y:910,t:1526933351299};\\\", \\\"{x:1611,y:914,t:1526933351314};\\\", \\\"{x:1606,y:924,t:1526933351331};\\\", \\\"{x:1599,y:935,t:1526933351348};\\\", \\\"{x:1593,y:946,t:1526933351365};\\\", \\\"{x:1576,y:967,t:1526933351381};\\\", \\\"{x:1564,y:979,t:1526933351398};\\\", \\\"{x:1553,y:989,t:1526933351415};\\\", \\\"{x:1542,y:997,t:1526933351432};\\\", \\\"{x:1536,y:1005,t:1526933351449};\\\", \\\"{x:1529,y:1012,t:1526933351464};\\\", \\\"{x:1522,y:1016,t:1526933351481};\\\", \\\"{x:1515,y:1019,t:1526933351499};\\\", \\\"{x:1507,y:1025,t:1526933351515};\\\", \\\"{x:1505,y:1026,t:1526933351532};\\\", \\\"{x:1503,y:1028,t:1526933351549};\\\", \\\"{x:1500,y:1030,t:1526933351565};\\\", \\\"{x:1497,y:1031,t:1526933351581};\\\", \\\"{x:1496,y:1033,t:1526933351598};\\\", \\\"{x:1495,y:1033,t:1526933351614};\\\", \\\"{x:1495,y:1034,t:1526933351631};\\\", \\\"{x:1498,y:1035,t:1526933351710};\\\", \\\"{x:1501,y:1035,t:1526933351718};\\\", \\\"{x:1504,y:1035,t:1526933351734};\\\", \\\"{x:1509,y:1035,t:1526933351748};\\\", \\\"{x:1522,y:1035,t:1526933351767};\\\", \\\"{x:1526,y:1035,t:1526933351782};\\\", \\\"{x:1533,y:1035,t:1526933351798};\\\", \\\"{x:1540,y:1035,t:1526933351816};\\\", \\\"{x:1546,y:1035,t:1526933351832};\\\", \\\"{x:1551,y:1035,t:1526933351849};\\\", \\\"{x:1557,y:1035,t:1526933351866};\\\", \\\"{x:1561,y:1035,t:1526933351882};\\\", \\\"{x:1568,y:1033,t:1526933351899};\\\", \\\"{x:1570,y:1033,t:1526933351916};\\\", \\\"{x:1578,y:1031,t:1526933351932};\\\", \\\"{x:1582,y:1031,t:1526933351949};\\\", \\\"{x:1589,y:1028,t:1526933351967};\\\", \\\"{x:1590,y:1028,t:1526933351983};\\\", \\\"{x:1594,y:1027,t:1526933351999};\\\", \\\"{x:1596,y:1024,t:1526933352017};\\\", \\\"{x:1601,y:1022,t:1526933352033};\\\", \\\"{x:1613,y:1015,t:1526933352049};\\\", \\\"{x:1619,y:1012,t:1526933352065};\\\", \\\"{x:1631,y:1005,t:1526933352083};\\\", \\\"{x:1638,y:999,t:1526933352098};\\\", \\\"{x:1639,y:998,t:1526933352115};\\\", \\\"{x:1640,y:998,t:1526933352132};\\\", \\\"{x:1641,y:997,t:1526933352149};\\\", \\\"{x:1642,y:996,t:1526933352165};\\\", \\\"{x:1643,y:995,t:1526933352182};\\\", \\\"{x:1645,y:991,t:1526933352198};\\\", \\\"{x:1647,y:987,t:1526933352215};\\\", \\\"{x:1648,y:985,t:1526933352233};\\\", \\\"{x:1649,y:984,t:1526933352248};\\\", \\\"{x:1650,y:983,t:1526933352266};\\\", \\\"{x:1652,y:981,t:1526933352283};\\\", \\\"{x:1653,y:979,t:1526933352298};\\\", \\\"{x:1656,y:974,t:1526933352315};\\\", \\\"{x:1658,y:971,t:1526933352333};\\\", \\\"{x:1658,y:968,t:1526933352349};\\\", \\\"{x:1661,y:964,t:1526933352366};\\\", \\\"{x:1662,y:964,t:1526933352383};\\\", \\\"{x:1664,y:963,t:1526933352400};\\\", \\\"{x:1661,y:963,t:1526933352599};\\\", \\\"{x:1648,y:967,t:1526933352616};\\\", \\\"{x:1634,y:975,t:1526933352633};\\\", \\\"{x:1618,y:985,t:1526933352650};\\\", \\\"{x:1603,y:991,t:1526933352665};\\\", \\\"{x:1595,y:995,t:1526933352683};\\\", \\\"{x:1593,y:996,t:1526933352699};\\\", \\\"{x:1593,y:995,t:1526933352814};\\\", \\\"{x:1596,y:990,t:1526933352822};\\\", \\\"{x:1600,y:981,t:1526933352833};\\\", \\\"{x:1613,y:950,t:1526933352850};\\\", \\\"{x:1633,y:905,t:1526933352866};\\\", \\\"{x:1650,y:857,t:1526933352882};\\\", \\\"{x:1663,y:814,t:1526933352899};\\\", \\\"{x:1667,y:788,t:1526933352916};\\\", \\\"{x:1672,y:763,t:1526933352933};\\\", \\\"{x:1675,y:725,t:1526933352950};\\\", \\\"{x:1677,y:699,t:1526933352966};\\\", \\\"{x:1677,y:677,t:1526933352982};\\\", \\\"{x:1677,y:652,t:1526933352999};\\\", \\\"{x:1672,y:628,t:1526933353017};\\\", \\\"{x:1668,y:613,t:1526933353032};\\\", \\\"{x:1664,y:600,t:1526933353050};\\\", \\\"{x:1662,y:586,t:1526933353066};\\\", \\\"{x:1659,y:572,t:1526933353083};\\\", \\\"{x:1654,y:560,t:1526933353100};\\\", \\\"{x:1647,y:546,t:1526933353117};\\\", \\\"{x:1641,y:535,t:1526933353133};\\\", \\\"{x:1636,y:517,t:1526933353150};\\\", \\\"{x:1632,y:505,t:1526933353167};\\\", \\\"{x:1629,y:499,t:1526933353183};\\\", \\\"{x:1628,y:490,t:1526933353200};\\\", \\\"{x:1625,y:477,t:1526933353217};\\\", \\\"{x:1624,y:472,t:1526933353234};\\\", \\\"{x:1622,y:462,t:1526933353250};\\\", \\\"{x:1620,y:457,t:1526933353267};\\\", \\\"{x:1619,y:455,t:1526933353283};\\\", \\\"{x:1619,y:452,t:1526933353300};\\\", \\\"{x:1619,y:449,t:1526933353317};\\\", \\\"{x:1619,y:447,t:1526933353333};\\\", \\\"{x:1619,y:443,t:1526933353350};\\\", \\\"{x:1619,y:441,t:1526933353367};\\\", \\\"{x:1619,y:438,t:1526933353384};\\\", \\\"{x:1620,y:436,t:1526933353401};\\\", \\\"{x:1620,y:435,t:1526933353422};\\\", \\\"{x:1621,y:434,t:1526933353439};\\\", \\\"{x:1622,y:434,t:1526933353470};\\\", \\\"{x:1622,y:435,t:1526933353910};\\\", \\\"{x:1622,y:439,t:1526933353919};\\\", \\\"{x:1622,y:441,t:1526933353934};\\\", \\\"{x:1622,y:445,t:1526933353951};\\\", \\\"{x:1622,y:449,t:1526933353968};\\\", \\\"{x:1622,y:453,t:1526933353984};\\\", \\\"{x:1624,y:455,t:1526933354001};\\\", \\\"{x:1624,y:461,t:1526933354018};\\\", \\\"{x:1624,y:466,t:1526933354034};\\\", \\\"{x:1624,y:470,t:1526933354051};\\\", \\\"{x:1624,y:474,t:1526933354068};\\\", \\\"{x:1624,y:477,t:1526933354085};\\\", \\\"{x:1624,y:482,t:1526933354101};\\\", \\\"{x:1624,y:491,t:1526933354118};\\\", \\\"{x:1626,y:496,t:1526933354135};\\\", \\\"{x:1626,y:500,t:1526933354151};\\\", \\\"{x:1626,y:505,t:1526933354168};\\\", \\\"{x:1626,y:510,t:1526933354184};\\\", \\\"{x:1626,y:515,t:1526933354201};\\\", \\\"{x:1626,y:522,t:1526933354218};\\\", \\\"{x:1626,y:528,t:1526933354234};\\\", \\\"{x:1626,y:535,t:1526933354250};\\\", \\\"{x:1626,y:542,t:1526933354267};\\\", \\\"{x:1626,y:546,t:1526933354283};\\\", \\\"{x:1627,y:549,t:1526933354301};\\\", \\\"{x:1627,y:557,t:1526933354318};\\\", \\\"{x:1628,y:561,t:1526933354333};\\\", \\\"{x:1628,y:565,t:1526933354350};\\\", \\\"{x:1628,y:568,t:1526933354368};\\\", \\\"{x:1630,y:574,t:1526933354383};\\\", \\\"{x:1630,y:579,t:1526933354401};\\\", \\\"{x:1629,y:582,t:1526933354417};\\\", \\\"{x:1628,y:585,t:1526933354434};\\\", \\\"{x:1628,y:587,t:1526933354450};\\\", \\\"{x:1628,y:593,t:1526933354468};\\\", \\\"{x:1628,y:600,t:1526933354484};\\\", \\\"{x:1628,y:605,t:1526933354500};\\\", \\\"{x:1628,y:615,t:1526933354517};\\\", \\\"{x:1628,y:621,t:1526933354534};\\\", \\\"{x:1628,y:623,t:1526933354550};\\\", \\\"{x:1628,y:625,t:1526933354568};\\\", \\\"{x:1628,y:627,t:1526933354584};\\\", \\\"{x:1628,y:630,t:1526933354601};\\\", \\\"{x:1628,y:632,t:1526933354618};\\\", \\\"{x:1628,y:637,t:1526933354635};\\\", \\\"{x:1628,y:639,t:1526933354651};\\\", \\\"{x:1628,y:641,t:1526933354667};\\\", \\\"{x:1628,y:643,t:1526933354684};\\\", \\\"{x:1627,y:645,t:1526933354700};\\\", \\\"{x:1626,y:647,t:1526933354734};\\\", \\\"{x:1625,y:649,t:1526933354751};\\\", \\\"{x:1618,y:655,t:1526933354768};\\\", \\\"{x:1600,y:666,t:1526933354785};\\\", \\\"{x:1548,y:686,t:1526933354802};\\\", \\\"{x:1446,y:714,t:1526933354818};\\\", \\\"{x:1302,y:755,t:1526933354835};\\\", \\\"{x:1159,y:788,t:1526933354852};\\\", \\\"{x:980,y:808,t:1526933354868};\\\", \\\"{x:800,y:815,t:1526933354885};\\\", \\\"{x:553,y:809,t:1526933354902};\\\", \\\"{x:444,y:805,t:1526933354918};\\\", \\\"{x:357,y:790,t:1526933354934};\\\", \\\"{x:342,y:788,t:1526933354952};\\\", \\\"{x:337,y:787,t:1526933354968};\\\", \\\"{x:337,y:785,t:1526933354985};\\\", \\\"{x:336,y:785,t:1526933355047};\\\", \\\"{x:336,y:783,t:1526933355054};\\\", \\\"{x:336,y:780,t:1526933355068};\\\", \\\"{x:337,y:776,t:1526933355085};\\\", \\\"{x:338,y:763,t:1526933355102};\\\", \\\"{x:338,y:746,t:1526933355119};\\\", \\\"{x:338,y:729,t:1526933355135};\\\", \\\"{x:342,y:716,t:1526933355152};\\\", \\\"{x:344,y:707,t:1526933355168};\\\", \\\"{x:346,y:704,t:1526933355185};\\\", \\\"{x:346,y:699,t:1526933355202};\\\", \\\"{x:346,y:695,t:1526933355219};\\\", \\\"{x:346,y:688,t:1526933355235};\\\", \\\"{x:346,y:686,t:1526933355252};\\\", \\\"{x:346,y:681,t:1526933355268};\\\", \\\"{x:347,y:676,t:1526933355285};\\\", \\\"{x:349,y:662,t:1526933355302};\\\", \\\"{x:350,y:660,t:1526933355319};\\\", \\\"{x:352,y:656,t:1526933355335};\\\", \\\"{x:352,y:652,t:1526933355352};\\\", \\\"{x:352,y:650,t:1526933355370};\\\", \\\"{x:352,y:647,t:1526933355385};\\\", \\\"{x:349,y:644,t:1526933355402};\\\", \\\"{x:345,y:640,t:1526933355418};\\\", \\\"{x:339,y:636,t:1526933355435};\\\", \\\"{x:327,y:632,t:1526933355452};\\\", \\\"{x:308,y:628,t:1526933355468};\\\", \\\"{x:287,y:621,t:1526933355485};\\\", \\\"{x:254,y:610,t:1526933355502};\\\", \\\"{x:232,y:602,t:1526933355519};\\\", \\\"{x:217,y:596,t:1526933355534};\\\", \\\"{x:207,y:591,t:1526933355551};\\\", \\\"{x:201,y:587,t:1526933355568};\\\", \\\"{x:197,y:585,t:1526933355584};\\\", \\\"{x:196,y:584,t:1526933355602};\\\", \\\"{x:195,y:583,t:1526933355638};\\\", \\\"{x:193,y:583,t:1526933355661};\\\", \\\"{x:192,y:583,t:1526933355693};\\\", \\\"{x:189,y:583,t:1526933355702};\\\", \\\"{x:185,y:585,t:1526933355719};\\\", \\\"{x:179,y:592,t:1526933355735};\\\", \\\"{x:176,y:594,t:1526933355752};\\\", \\\"{x:176,y:595,t:1526933355806};\\\", \\\"{x:176,y:596,t:1526933355819};\\\", \\\"{x:175,y:597,t:1526933355903};\\\", \\\"{x:175,y:599,t:1526933356126};\\\", \\\"{x:175,y:601,t:1526933356135};\\\", \\\"{x:176,y:603,t:1526933356151};\\\", \\\"{x:176,y:606,t:1526933356174};\\\", \\\"{x:176,y:607,t:1526933356191};\\\", \\\"{x:176,y:609,t:1526933356202};\\\", \\\"{x:175,y:613,t:1526933356219};\\\", \\\"{x:171,y:617,t:1526933356235};\\\", \\\"{x:169,y:621,t:1526933356253};\\\", \\\"{x:165,y:626,t:1526933356269};\\\", \\\"{x:164,y:634,t:1526933356285};\\\", \\\"{x:162,y:638,t:1526933356303};\\\", \\\"{x:161,y:640,t:1526933356357};\\\", \\\"{x:160,y:641,t:1526933356373};\\\", \\\"{x:161,y:643,t:1526933357303};\\\", \\\"{x:163,y:643,t:1526933357320};\\\", \\\"{x:167,y:643,t:1526933357337};\\\", \\\"{x:174,y:647,t:1526933357354};\\\", \\\"{x:184,y:653,t:1526933357370};\\\", \\\"{x:196,y:656,t:1526933357387};\\\", \\\"{x:233,y:667,t:1526933357403};\\\", \\\"{x:271,y:681,t:1526933357419};\\\", \\\"{x:306,y:694,t:1526933357437};\\\", \\\"{x:342,y:706,t:1526933357453};\\\", \\\"{x:355,y:713,t:1526933357470};\\\", \\\"{x:374,y:716,t:1526933357487};\\\", \\\"{x:391,y:718,t:1526933357503};\\\", \\\"{x:401,y:719,t:1526933357520};\\\", \\\"{x:402,y:719,t:1526933357606};\\\", \\\"{x:405,y:719,t:1526933357620};\\\", \\\"{x:411,y:719,t:1526933357637};\\\", \\\"{x:419,y:719,t:1526933357653};\\\", \\\"{x:421,y:718,t:1526933357671};\\\", \\\"{x:424,y:718,t:1526933357687};\\\", \\\"{x:427,y:718,t:1526933357704};\\\", \\\"{x:432,y:718,t:1526933357721};\\\", \\\"{x:441,y:718,t:1526933357737};\\\", \\\"{x:448,y:719,t:1526933357755};\\\", \\\"{x:453,y:720,t:1526933357771};\\\", \\\"{x:455,y:720,t:1526933357787};\\\", \\\"{x:457,y:720,t:1526933357804};\\\", \\\"{x:458,y:721,t:1526933357821};\\\", \\\"{x:459,y:721,t:1526933357885};\\\", \\\"{x:460,y:721,t:1526933357901};\\\", \\\"{x:461,y:721,t:1526933357982};\\\", \\\"{x:463,y:721,t:1526933357989};\\\", \\\"{x:464,y:721,t:1526933358046};\\\", \\\"{x:466,y:721,t:1526933358061};\\\", \\\"{x:467,y:721,t:1526933358077};\\\", \\\"{x:468,y:722,t:1526933358087};\\\", \\\"{x:470,y:722,t:1526933358104};\\\", \\\"{x:472,y:722,t:1526933358121};\\\", \\\"{x:473,y:722,t:1526933358137};\\\", \\\"{x:476,y:722,t:1526933358154};\\\", \\\"{x:478,y:722,t:1526933358171};\\\", \\\"{x:481,y:722,t:1526933358187};\\\", \\\"{x:483,y:722,t:1526933358204};\\\", \\\"{x:485,y:722,t:1526933358221};\\\", \\\"{x:487,y:722,t:1526933358237};\\\", \\\"{x:488,y:722,t:1526933358270};\\\", \\\"{x:491,y:723,t:1526933358285};\\\", \\\"{x:492,y:723,t:1526933358301};\\\", \\\"{x:493,y:723,t:1526933358325};\\\", \\\"{x:495,y:724,t:1526933358365};\\\", \\\"{x:497,y:724,t:1526933358398};\\\", \\\"{x:498,y:724,t:1526933358510};\\\" ] }, { \\\"rt\\\": 20181, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 225640, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 0.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:724,t:1526933369183};\\\", \\\"{x:505,y:724,t:1526933369197};\\\", \\\"{x:506,y:723,t:1526933369214};\\\", \\\"{x:518,y:723,t:1526933369230};\\\", \\\"{x:532,y:727,t:1526933369247};\\\", \\\"{x:540,y:729,t:1526933369264};\\\", \\\"{x:548,y:730,t:1526933369280};\\\", \\\"{x:552,y:731,t:1526933369297};\\\", \\\"{x:556,y:731,t:1526933369314};\\\", \\\"{x:560,y:732,t:1526933369330};\\\", \\\"{x:562,y:732,t:1526933369348};\\\", \\\"{x:565,y:733,t:1526933369364};\\\", \\\"{x:568,y:733,t:1526933369381};\\\", \\\"{x:572,y:733,t:1526933369397};\\\", \\\"{x:575,y:735,t:1526933369413};\\\", \\\"{x:580,y:736,t:1526933369429};\\\", \\\"{x:586,y:736,t:1526933369446};\\\", \\\"{x:594,y:737,t:1526933369462};\\\", \\\"{x:600,y:739,t:1526933369479};\\\", \\\"{x:607,y:739,t:1526933369496};\\\", \\\"{x:612,y:740,t:1526933369512};\\\", \\\"{x:619,y:740,t:1526933369529};\\\", \\\"{x:624,y:741,t:1526933369546};\\\", \\\"{x:635,y:743,t:1526933369563};\\\", \\\"{x:645,y:744,t:1526933369579};\\\", \\\"{x:654,y:745,t:1526933369596};\\\", \\\"{x:668,y:748,t:1526933369613};\\\", \\\"{x:680,y:749,t:1526933369630};\\\", \\\"{x:693,y:750,t:1526933369646};\\\", \\\"{x:714,y:753,t:1526933369664};\\\", \\\"{x:736,y:756,t:1526933369679};\\\", \\\"{x:754,y:758,t:1526933369696};\\\", \\\"{x:773,y:762,t:1526933369714};\\\", \\\"{x:795,y:762,t:1526933369730};\\\", \\\"{x:806,y:762,t:1526933369746};\\\", \\\"{x:828,y:766,t:1526933369763};\\\", \\\"{x:842,y:767,t:1526933369780};\\\", \\\"{x:862,y:769,t:1526933369796};\\\", \\\"{x:883,y:771,t:1526933369813};\\\", \\\"{x:894,y:774,t:1526933369830};\\\", \\\"{x:908,y:774,t:1526933369846};\\\", \\\"{x:915,y:775,t:1526933369863};\\\", \\\"{x:922,y:775,t:1526933369880};\\\", \\\"{x:937,y:775,t:1526933369897};\\\", \\\"{x:949,y:775,t:1526933369914};\\\", \\\"{x:959,y:775,t:1526933369929};\\\", \\\"{x:973,y:777,t:1526933369946};\\\", \\\"{x:992,y:781,t:1526933369964};\\\", \\\"{x:1016,y:783,t:1526933369980};\\\", \\\"{x:1038,y:785,t:1526933369997};\\\", \\\"{x:1056,y:788,t:1526933370014};\\\", \\\"{x:1068,y:793,t:1526933370030};\\\", \\\"{x:1084,y:796,t:1526933370046};\\\", \\\"{x:1092,y:796,t:1526933370063};\\\", \\\"{x:1104,y:796,t:1526933370079};\\\", \\\"{x:1112,y:796,t:1526933370096};\\\", \\\"{x:1119,y:797,t:1526933370114};\\\", \\\"{x:1130,y:800,t:1526933370130};\\\", \\\"{x:1145,y:800,t:1526933370146};\\\", \\\"{x:1158,y:801,t:1526933370163};\\\", \\\"{x:1165,y:801,t:1526933370180};\\\", \\\"{x:1175,y:802,t:1526933370196};\\\", \\\"{x:1192,y:805,t:1526933370213};\\\", \\\"{x:1202,y:806,t:1526933370230};\\\", \\\"{x:1210,y:806,t:1526933370246};\\\", \\\"{x:1217,y:806,t:1526933370263};\\\", \\\"{x:1219,y:806,t:1526933370280};\\\", \\\"{x:1225,y:807,t:1526933370296};\\\", \\\"{x:1230,y:807,t:1526933370314};\\\", \\\"{x:1236,y:807,t:1526933370330};\\\", \\\"{x:1244,y:807,t:1526933370346};\\\", \\\"{x:1249,y:807,t:1526933370363};\\\", \\\"{x:1254,y:808,t:1526933370380};\\\", \\\"{x:1257,y:808,t:1526933370397};\\\", \\\"{x:1260,y:809,t:1526933370413};\\\", \\\"{x:1260,y:810,t:1526933370430};\\\", \\\"{x:1260,y:812,t:1526933370487};\\\", \\\"{x:1260,y:817,t:1526933370497};\\\", \\\"{x:1259,y:821,t:1526933370514};\\\", \\\"{x:1256,y:826,t:1526933370531};\\\", \\\"{x:1255,y:827,t:1526933370547};\\\", \\\"{x:1253,y:830,t:1526933370564};\\\", \\\"{x:1251,y:832,t:1526933370580};\\\", \\\"{x:1245,y:835,t:1526933370597};\\\", \\\"{x:1242,y:835,t:1526933370613};\\\", \\\"{x:1238,y:836,t:1526933370630};\\\", \\\"{x:1233,y:838,t:1526933370647};\\\", \\\"{x:1231,y:838,t:1526933370663};\\\", \\\"{x:1230,y:838,t:1526933370680};\\\", \\\"{x:1228,y:838,t:1526933370697};\\\", \\\"{x:1225,y:838,t:1526933370714};\\\", \\\"{x:1220,y:837,t:1526933370730};\\\", \\\"{x:1217,y:837,t:1526933370747};\\\", \\\"{x:1215,y:837,t:1526933370763};\\\", \\\"{x:1214,y:837,t:1526933370780};\\\", \\\"{x:1214,y:836,t:1526933371038};\\\", \\\"{x:1214,y:835,t:1526933371078};\\\", \\\"{x:1215,y:834,t:1526933371097};\\\", \\\"{x:1215,y:833,t:1526933371133};\\\", \\\"{x:1215,y:832,t:1526933374734};\\\", \\\"{x:1215,y:830,t:1526933374749};\\\", \\\"{x:1215,y:829,t:1526933374766};\\\", \\\"{x:1215,y:828,t:1526933374789};\\\", \\\"{x:1214,y:828,t:1526933375303};\\\", \\\"{x:1214,y:829,t:1526933375757};\\\", \\\"{x:1214,y:830,t:1526933375781};\\\", \\\"{x:1214,y:831,t:1526933375797};\\\", \\\"{x:1215,y:832,t:1526933375805};\\\", \\\"{x:1216,y:832,t:1526933375816};\\\", \\\"{x:1217,y:833,t:1526933375838};\\\", \\\"{x:1217,y:834,t:1526933375861};\\\", \\\"{x:1217,y:835,t:1526933375869};\\\", \\\"{x:1218,y:836,t:1526933375894};\\\", \\\"{x:1219,y:837,t:1526933375909};\\\", \\\"{x:1219,y:838,t:1526933375933};\\\", \\\"{x:1219,y:839,t:1526933375973};\\\", \\\"{x:1219,y:841,t:1526933375989};\\\", \\\"{x:1219,y:840,t:1526933378149};\\\", \\\"{x:1218,y:838,t:1526933378165};\\\", \\\"{x:1217,y:836,t:1526933378189};\\\", \\\"{x:1216,y:835,t:1526933378205};\\\", \\\"{x:1216,y:834,t:1526933378235};\\\", \\\"{x:1213,y:831,t:1526933378251};\\\", \\\"{x:1212,y:831,t:1526933378268};\\\", \\\"{x:1211,y:828,t:1526933378285};\\\", \\\"{x:1209,y:827,t:1526933378301};\\\", \\\"{x:1208,y:826,t:1526933378320};\\\", \\\"{x:1208,y:824,t:1526933378336};\\\", \\\"{x:1207,y:824,t:1526933378352};\\\", \\\"{x:1207,y:823,t:1526933378373};\\\", \\\"{x:1207,y:822,t:1526933378430};\\\", \\\"{x:1207,y:821,t:1526933378471};\\\", \\\"{x:1209,y:821,t:1526933378767};\\\", \\\"{x:1210,y:821,t:1526933378871};\\\", \\\"{x:1211,y:822,t:1526933378926};\\\", \\\"{x:1211,y:823,t:1526933378950};\\\", \\\"{x:1212,y:824,t:1526933378974};\\\", \\\"{x:1213,y:825,t:1526933378999};\\\", \\\"{x:1214,y:825,t:1526933379019};\\\", \\\"{x:1216,y:825,t:1526933379036};\\\", \\\"{x:1218,y:825,t:1526933379053};\\\", \\\"{x:1219,y:825,t:1526933379071};\\\", \\\"{x:1220,y:825,t:1526933379086};\\\", \\\"{x:1221,y:826,t:1526933379103};\\\", \\\"{x:1223,y:827,t:1526933379121};\\\", \\\"{x:1225,y:829,t:1526933379142};\\\", \\\"{x:1226,y:830,t:1526933379156};\\\", \\\"{x:1228,y:830,t:1526933379170};\\\", \\\"{x:1230,y:830,t:1526933379186};\\\", \\\"{x:1232,y:830,t:1526933379214};\\\", \\\"{x:1235,y:830,t:1526933379254};\\\", \\\"{x:1237,y:830,t:1526933379269};\\\", \\\"{x:1240,y:832,t:1526933379286};\\\", \\\"{x:1243,y:832,t:1526933379303};\\\", \\\"{x:1244,y:833,t:1526933379320};\\\", \\\"{x:1246,y:833,t:1526933379337};\\\", \\\"{x:1248,y:833,t:1526933379355};\\\", \\\"{x:1249,y:833,t:1526933379371};\\\", \\\"{x:1250,y:833,t:1526933379390};\\\", \\\"{x:1251,y:833,t:1526933379414};\\\", \\\"{x:1252,y:833,t:1526933379422};\\\", \\\"{x:1255,y:833,t:1526933379436};\\\", \\\"{x:1259,y:833,t:1526933379453};\\\", \\\"{x:1263,y:833,t:1526933379470};\\\", \\\"{x:1265,y:833,t:1526933379486};\\\", \\\"{x:1266,y:833,t:1526933379503};\\\", \\\"{x:1269,y:833,t:1526933379520};\\\", \\\"{x:1271,y:833,t:1526933379599};\\\", \\\"{x:1272,y:833,t:1526933379606};\\\", \\\"{x:1273,y:833,t:1526933379630};\\\", \\\"{x:1274,y:833,t:1526933379638};\\\", \\\"{x:1275,y:833,t:1526933379653};\\\", \\\"{x:1276,y:833,t:1526933379678};\\\", \\\"{x:1277,y:833,t:1526933379687};\\\", \\\"{x:1278,y:833,t:1526933379734};\\\", \\\"{x:1279,y:833,t:1526933379782};\\\", \\\"{x:1280,y:833,t:1526933379790};\\\", \\\"{x:1281,y:834,t:1526933381174};\\\", \\\"{x:1281,y:835,t:1526933381214};\\\", \\\"{x:1281,y:836,t:1526933381231};\\\", \\\"{x:1281,y:837,t:1526933381262};\\\", \\\"{x:1280,y:838,t:1526933381278};\\\", \\\"{x:1277,y:838,t:1526933381288};\\\", \\\"{x:1267,y:839,t:1526933381305};\\\", \\\"{x:1255,y:839,t:1526933381321};\\\", \\\"{x:1235,y:839,t:1526933381338};\\\", \\\"{x:1217,y:839,t:1526933381355};\\\", \\\"{x:1196,y:837,t:1526933381371};\\\", \\\"{x:1171,y:831,t:1526933381388};\\\", \\\"{x:1136,y:826,t:1526933381404};\\\", \\\"{x:1087,y:817,t:1526933381421};\\\", \\\"{x:1042,y:810,t:1526933381438};\\\", \\\"{x:997,y:803,t:1526933381454};\\\", \\\"{x:937,y:790,t:1526933381471};\\\", \\\"{x:881,y:775,t:1526933381488};\\\", \\\"{x:824,y:764,t:1526933381504};\\\", \\\"{x:771,y:746,t:1526933381522};\\\", \\\"{x:707,y:715,t:1526933381538};\\\", \\\"{x:633,y:686,t:1526933381555};\\\", \\\"{x:586,y:667,t:1526933381571};\\\", \\\"{x:561,y:651,t:1526933381588};\\\", \\\"{x:551,y:645,t:1526933381605};\\\", \\\"{x:546,y:640,t:1526933381621};\\\", \\\"{x:544,y:635,t:1526933381638};\\\", \\\"{x:543,y:631,t:1526933381685};\\\", \\\"{x:542,y:629,t:1526933381693};\\\", \\\"{x:539,y:625,t:1526933381707};\\\", \\\"{x:535,y:619,t:1526933381723};\\\", \\\"{x:520,y:608,t:1526933381740};\\\", \\\"{x:501,y:599,t:1526933381757};\\\", \\\"{x:488,y:590,t:1526933381773};\\\", \\\"{x:462,y:580,t:1526933381790};\\\", \\\"{x:449,y:576,t:1526933381807};\\\", \\\"{x:434,y:569,t:1526933381824};\\\", \\\"{x:426,y:561,t:1526933381840};\\\", \\\"{x:420,y:557,t:1526933381856};\\\", \\\"{x:418,y:554,t:1526933381873};\\\", \\\"{x:414,y:551,t:1526933381890};\\\", \\\"{x:412,y:550,t:1526933382127};\\\", \\\"{x:409,y:550,t:1526933382140};\\\", \\\"{x:404,y:546,t:1526933382158};\\\", \\\"{x:386,y:538,t:1526933382174};\\\", \\\"{x:368,y:530,t:1526933382190};\\\", \\\"{x:356,y:524,t:1526933382207};\\\", \\\"{x:353,y:522,t:1526933382224};\\\", \\\"{x:352,y:521,t:1526933382241};\\\", \\\"{x:353,y:520,t:1526933382502};\\\", \\\"{x:356,y:520,t:1526933382510};\\\", \\\"{x:357,y:520,t:1526933382524};\\\", \\\"{x:362,y:519,t:1526933382541};\\\", \\\"{x:368,y:519,t:1526933382557};\\\", \\\"{x:369,y:519,t:1526933382573};\\\", \\\"{x:369,y:520,t:1526933385206};\\\", \\\"{x:369,y:528,t:1526933385214};\\\", \\\"{x:369,y:540,t:1526933385228};\\\", \\\"{x:369,y:565,t:1526933385244};\\\", \\\"{x:376,y:593,t:1526933385261};\\\", \\\"{x:387,y:613,t:1526933385277};\\\", \\\"{x:402,y:641,t:1526933385294};\\\", \\\"{x:413,y:657,t:1526933385310};\\\", \\\"{x:425,y:680,t:1526933385326};\\\", \\\"{x:440,y:705,t:1526933385343};\\\", \\\"{x:460,y:729,t:1526933385360};\\\", \\\"{x:477,y:758,t:1526933385376};\\\", \\\"{x:492,y:781,t:1526933385393};\\\", \\\"{x:502,y:797,t:1526933385409};\\\", \\\"{x:510,y:812,t:1526933385425};\\\", \\\"{x:516,y:824,t:1526933385443};\\\", \\\"{x:520,y:830,t:1526933385460};\\\", \\\"{x:522,y:834,t:1526933385476};\\\", \\\"{x:525,y:837,t:1526933385493};\\\", \\\"{x:525,y:839,t:1526933385510};\\\", \\\"{x:525,y:840,t:1526933385581};\\\", \\\"{x:525,y:841,t:1526933385613};\\\", \\\"{x:525,y:842,t:1526933385662};\\\", \\\"{x:522,y:840,t:1526933385675};\\\", \\\"{x:513,y:818,t:1526933385693};\\\", \\\"{x:506,y:800,t:1526933385708};\\\", \\\"{x:503,y:791,t:1526933385726};\\\", \\\"{x:502,y:788,t:1526933385742};\\\", \\\"{x:501,y:786,t:1526933385760};\\\", \\\"{x:500,y:781,t:1526933385775};\\\", \\\"{x:500,y:773,t:1526933385792};\\\", \\\"{x:498,y:762,t:1526933385809};\\\", \\\"{x:498,y:755,t:1526933385826};\\\", \\\"{x:498,y:752,t:1526933385842};\\\", \\\"{x:498,y:748,t:1526933385859};\\\", \\\"{x:498,y:745,t:1526933385876};\\\", \\\"{x:497,y:742,t:1526933385892};\\\", \\\"{x:497,y:737,t:1526933385908};\\\", \\\"{x:497,y:735,t:1526933385927};\\\", \\\"{x:497,y:734,t:1526933385943};\\\", \\\"{x:497,y:733,t:1526933385959};\\\", \\\"{x:497,y:732,t:1526933385976};\\\", \\\"{x:497,y:731,t:1526933386125};\\\", \\\"{x:496,y:729,t:1526933387142};\\\", \\\"{x:493,y:721,t:1526933387149};\\\", \\\"{x:487,y:713,t:1526933387162};\\\", \\\"{x:480,y:698,t:1526933387179};\\\", \\\"{x:472,y:687,t:1526933387195};\\\", \\\"{x:468,y:679,t:1526933387211};\\\", \\\"{x:467,y:674,t:1526933387228};\\\", \\\"{x:467,y:662,t:1526933387245};\\\", \\\"{x:467,y:650,t:1526933387262};\\\", \\\"{x:466,y:640,t:1526933387278};\\\", \\\"{x:466,y:635,t:1526933387295};\\\", \\\"{x:464,y:631,t:1526933387311};\\\", \\\"{x:464,y:630,t:1526933387349};\\\", \\\"{x:464,y:629,t:1526933387364};\\\", \\\"{x:464,y:627,t:1526933387380};\\\", \\\"{x:464,y:625,t:1526933387395};\\\", \\\"{x:464,y:623,t:1526933387413};\\\", \\\"{x:464,y:622,t:1526933387429};\\\", \\\"{x:462,y:619,t:1526933387445};\\\", \\\"{x:459,y:615,t:1526933387461};\\\", \\\"{x:456,y:613,t:1526933387477};\\\" ] }, { \\\"rt\\\": 18374, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 245295, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:425,y:592,t:1526933387596};\\\", \\\"{x:424,y:592,t:1526933387612};\\\", \\\"{x:423,y:592,t:1526933387661};\\\", \\\"{x:420,y:592,t:1526933387677};\\\", \\\"{x:420,y:591,t:1526933387694};\\\", \\\"{x:417,y:588,t:1526933387715};\\\", \\\"{x:416,y:584,t:1526933387728};\\\", \\\"{x:412,y:580,t:1526933387745};\\\", \\\"{x:408,y:571,t:1526933387762};\\\", \\\"{x:407,y:567,t:1526933387778};\\\", \\\"{x:404,y:565,t:1526933387795};\\\", \\\"{x:404,y:564,t:1526933387812};\\\", \\\"{x:403,y:564,t:1526933387828};\\\", \\\"{x:398,y:555,t:1526933388005};\\\", \\\"{x:393,y:546,t:1526933388014};\\\", \\\"{x:393,y:544,t:1526933388028};\\\", \\\"{x:390,y:541,t:1526933388046};\\\", \\\"{x:389,y:540,t:1526933388061};\\\", \\\"{x:389,y:539,t:1526933388125};\\\", \\\"{x:388,y:539,t:1526933388141};\\\", \\\"{x:388,y:537,t:1526933388190};\\\", \\\"{x:387,y:537,t:1526933388204};\\\", \\\"{x:386,y:536,t:1526933388254};\\\", \\\"{x:386,y:535,t:1526933388478};\\\", \\\"{x:386,y:534,t:1526933388486};\\\", \\\"{x:386,y:532,t:1526933388519};\\\", \\\"{x:387,y:531,t:1526933388533};\\\", \\\"{x:390,y:531,t:1526933388548};\\\", \\\"{x:393,y:531,t:1526933388562};\\\", \\\"{x:394,y:530,t:1526933388579};\\\", \\\"{x:401,y:530,t:1526933388595};\\\", \\\"{x:406,y:530,t:1526933388612};\\\", \\\"{x:418,y:531,t:1526933388629};\\\", \\\"{x:431,y:535,t:1526933388645};\\\", \\\"{x:447,y:539,t:1526933388662};\\\", \\\"{x:467,y:544,t:1526933388680};\\\", \\\"{x:476,y:547,t:1526933388695};\\\", \\\"{x:487,y:548,t:1526933388712};\\\", \\\"{x:495,y:548,t:1526933388729};\\\", \\\"{x:501,y:550,t:1526933388747};\\\", \\\"{x:505,y:552,t:1526933388762};\\\", \\\"{x:508,y:552,t:1526933388781};\\\", \\\"{x:510,y:552,t:1526933388796};\\\", \\\"{x:520,y:556,t:1526933388813};\\\", \\\"{x:536,y:562,t:1526933388829};\\\", \\\"{x:559,y:570,t:1526933388846};\\\", \\\"{x:588,y:577,t:1526933388863};\\\", \\\"{x:622,y:586,t:1526933388881};\\\", \\\"{x:662,y:593,t:1526933388897};\\\", \\\"{x:729,y:614,t:1526933388912};\\\", \\\"{x:830,y:636,t:1526933388928};\\\", \\\"{x:951,y:668,t:1526933388946};\\\", \\\"{x:1069,y:692,t:1526933388963};\\\", \\\"{x:1184,y:717,t:1526933388979};\\\", \\\"{x:1279,y:730,t:1526933388996};\\\", \\\"{x:1366,y:752,t:1526933389012};\\\", \\\"{x:1519,y:796,t:1526933389029};\\\", \\\"{x:1631,y:820,t:1526933389046};\\\", \\\"{x:1706,y:840,t:1526933389063};\\\", \\\"{x:1736,y:846,t:1526933389080};\\\", \\\"{x:1745,y:851,t:1526933389096};\\\", \\\"{x:1752,y:853,t:1526933389113};\\\", \\\"{x:1759,y:856,t:1526933389129};\\\", \\\"{x:1760,y:856,t:1526933389147};\\\", \\\"{x:1760,y:857,t:1526933389239};\\\", \\\"{x:1760,y:859,t:1526933389270};\\\", \\\"{x:1759,y:860,t:1526933389279};\\\", \\\"{x:1758,y:861,t:1526933389296};\\\", \\\"{x:1754,y:861,t:1526933389314};\\\", \\\"{x:1752,y:864,t:1526933389329};\\\", \\\"{x:1751,y:865,t:1526933389347};\\\", \\\"{x:1750,y:865,t:1526933389363};\\\", \\\"{x:1749,y:865,t:1526933389974};\\\", \\\"{x:1745,y:865,t:1526933389981};\\\", \\\"{x:1737,y:865,t:1526933389997};\\\", \\\"{x:1732,y:865,t:1526933390014};\\\", \\\"{x:1723,y:865,t:1526933390030};\\\", \\\"{x:1717,y:865,t:1526933390047};\\\", \\\"{x:1715,y:865,t:1526933390063};\\\", \\\"{x:1713,y:865,t:1526933390080};\\\", \\\"{x:1711,y:865,t:1526933390097};\\\", \\\"{x:1708,y:865,t:1526933390113};\\\", \\\"{x:1705,y:865,t:1526933390130};\\\", \\\"{x:1701,y:865,t:1526933390147};\\\", \\\"{x:1694,y:865,t:1526933390163};\\\", \\\"{x:1689,y:864,t:1526933390180};\\\", \\\"{x:1681,y:863,t:1526933390197};\\\", \\\"{x:1676,y:861,t:1526933390214};\\\", \\\"{x:1673,y:860,t:1526933390231};\\\", \\\"{x:1670,y:860,t:1526933390248};\\\", \\\"{x:1669,y:859,t:1526933390264};\\\", \\\"{x:1667,y:859,t:1526933390280};\\\", \\\"{x:1665,y:859,t:1526933390302};\\\", \\\"{x:1663,y:858,t:1526933390314};\\\", \\\"{x:1660,y:858,t:1526933390341};\\\", \\\"{x:1657,y:858,t:1526933390357};\\\", \\\"{x:1656,y:858,t:1526933390365};\\\", \\\"{x:1655,y:858,t:1526933390380};\\\", \\\"{x:1645,y:858,t:1526933390397};\\\", \\\"{x:1640,y:858,t:1526933390414};\\\", \\\"{x:1637,y:858,t:1526933390430};\\\", \\\"{x:1635,y:858,t:1526933390447};\\\", \\\"{x:1634,y:858,t:1526933390464};\\\", \\\"{x:1632,y:858,t:1526933390485};\\\", \\\"{x:1631,y:858,t:1526933390509};\\\", \\\"{x:1630,y:858,t:1526933390517};\\\", \\\"{x:1627,y:858,t:1526933390530};\\\", \\\"{x:1624,y:858,t:1526933390547};\\\", \\\"{x:1620,y:860,t:1526933390565};\\\", \\\"{x:1617,y:861,t:1526933390580};\\\", \\\"{x:1612,y:865,t:1526933390597};\\\", \\\"{x:1606,y:873,t:1526933390615};\\\", \\\"{x:1595,y:887,t:1526933390631};\\\", \\\"{x:1586,y:893,t:1526933390647};\\\", \\\"{x:1577,y:901,t:1526933390664};\\\", \\\"{x:1569,y:907,t:1526933390681};\\\", \\\"{x:1566,y:910,t:1526933390697};\\\", \\\"{x:1562,y:915,t:1526933390714};\\\", \\\"{x:1560,y:917,t:1526933390731};\\\", \\\"{x:1557,y:920,t:1526933390747};\\\", \\\"{x:1555,y:925,t:1526933390764};\\\", \\\"{x:1554,y:928,t:1526933390782};\\\", \\\"{x:1552,y:929,t:1526933390797};\\\", \\\"{x:1552,y:932,t:1526933390830};\\\", \\\"{x:1552,y:933,t:1526933390878};\\\", \\\"{x:1552,y:934,t:1526933390885};\\\", \\\"{x:1551,y:935,t:1526933390909};\\\", \\\"{x:1550,y:936,t:1526933390941};\\\", \\\"{x:1550,y:937,t:1526933390957};\\\", \\\"{x:1550,y:938,t:1526933390965};\\\", \\\"{x:1549,y:938,t:1526933390981};\\\", \\\"{x:1549,y:939,t:1526933391014};\\\", \\\"{x:1549,y:941,t:1526933391032};\\\", \\\"{x:1550,y:937,t:1526933391278};\\\", \\\"{x:1553,y:934,t:1526933391286};\\\", \\\"{x:1554,y:929,t:1526933391298};\\\", \\\"{x:1562,y:918,t:1526933391314};\\\", \\\"{x:1564,y:912,t:1526933391332};\\\", \\\"{x:1566,y:904,t:1526933391349};\\\", \\\"{x:1568,y:898,t:1526933391365};\\\", \\\"{x:1568,y:885,t:1526933391382};\\\", \\\"{x:1567,y:876,t:1526933391398};\\\", \\\"{x:1566,y:873,t:1526933391414};\\\", \\\"{x:1564,y:869,t:1526933391431};\\\", \\\"{x:1564,y:864,t:1526933391477};\\\", \\\"{x:1564,y:855,t:1526933391485};\\\", \\\"{x:1564,y:845,t:1526933391498};\\\", \\\"{x:1564,y:829,t:1526933391515};\\\", \\\"{x:1564,y:810,t:1526933391531};\\\", \\\"{x:1564,y:786,t:1526933391549};\\\", \\\"{x:1564,y:764,t:1526933391565};\\\", \\\"{x:1564,y:748,t:1526933391581};\\\", \\\"{x:1561,y:733,t:1526933391598};\\\", \\\"{x:1557,y:721,t:1526933391616};\\\", \\\"{x:1557,y:714,t:1526933391632};\\\", \\\"{x:1556,y:707,t:1526933391648};\\\", \\\"{x:1556,y:697,t:1526933391665};\\\", \\\"{x:1556,y:679,t:1526933391682};\\\", \\\"{x:1556,y:664,t:1526933391698};\\\", \\\"{x:1553,y:658,t:1526933391715};\\\", \\\"{x:1553,y:656,t:1526933391731};\\\", \\\"{x:1553,y:655,t:1526933391748};\\\", \\\"{x:1553,y:649,t:1526933391765};\\\", \\\"{x:1553,y:634,t:1526933391781};\\\", \\\"{x:1553,y:610,t:1526933391798};\\\", \\\"{x:1553,y:589,t:1526933391815};\\\", \\\"{x:1553,y:574,t:1526933391832};\\\", \\\"{x:1554,y:560,t:1526933391849};\\\", \\\"{x:1556,y:546,t:1526933391865};\\\", \\\"{x:1561,y:528,t:1526933391882};\\\", \\\"{x:1565,y:511,t:1526933391898};\\\", \\\"{x:1565,y:497,t:1526933391915};\\\", \\\"{x:1566,y:489,t:1526933391932};\\\", \\\"{x:1566,y:484,t:1526933391948};\\\", \\\"{x:1561,y:472,t:1526933391965};\\\", \\\"{x:1550,y:461,t:1526933391982};\\\", \\\"{x:1530,y:454,t:1526933391998};\\\", \\\"{x:1515,y:443,t:1526933392015};\\\", \\\"{x:1491,y:435,t:1526933392032};\\\", \\\"{x:1452,y:428,t:1526933392049};\\\", \\\"{x:1409,y:420,t:1526933392065};\\\", \\\"{x:1383,y:414,t:1526933392083};\\\", \\\"{x:1353,y:412,t:1526933392099};\\\", \\\"{x:1345,y:410,t:1526933392115};\\\", \\\"{x:1342,y:409,t:1526933392132};\\\", \\\"{x:1341,y:409,t:1526933392148};\\\", \\\"{x:1341,y:410,t:1526933392310};\\\", \\\"{x:1341,y:411,t:1526933392326};\\\", \\\"{x:1341,y:412,t:1526933392334};\\\", \\\"{x:1341,y:415,t:1526933392734};\\\", \\\"{x:1352,y:438,t:1526933392749};\\\", \\\"{x:1364,y:463,t:1526933392766};\\\", \\\"{x:1367,y:489,t:1526933392782};\\\", \\\"{x:1371,y:502,t:1526933392799};\\\", \\\"{x:1372,y:514,t:1526933392817};\\\", \\\"{x:1372,y:526,t:1526933392832};\\\", \\\"{x:1372,y:538,t:1526933392849};\\\", \\\"{x:1374,y:551,t:1526933392866};\\\", \\\"{x:1377,y:568,t:1526933392883};\\\", \\\"{x:1380,y:590,t:1526933392900};\\\", \\\"{x:1385,y:608,t:1526933392916};\\\", \\\"{x:1390,y:627,t:1526933392933};\\\", \\\"{x:1404,y:659,t:1526933392949};\\\", \\\"{x:1416,y:685,t:1526933392966};\\\", \\\"{x:1435,y:717,t:1526933392982};\\\", \\\"{x:1450,y:743,t:1526933392999};\\\", \\\"{x:1465,y:775,t:1526933393017};\\\", \\\"{x:1478,y:798,t:1526933393032};\\\", \\\"{x:1499,y:829,t:1526933393049};\\\", \\\"{x:1539,y:874,t:1526933393066};\\\", \\\"{x:1569,y:912,t:1526933393082};\\\", \\\"{x:1589,y:932,t:1526933393100};\\\", \\\"{x:1609,y:948,t:1526933393116};\\\", \\\"{x:1630,y:966,t:1526933393133};\\\", \\\"{x:1641,y:973,t:1526933393149};\\\", \\\"{x:1646,y:975,t:1526933393167};\\\", \\\"{x:1648,y:976,t:1526933393183};\\\", \\\"{x:1649,y:976,t:1526933393200};\\\", \\\"{x:1648,y:979,t:1526933393382};\\\", \\\"{x:1643,y:980,t:1526933393390};\\\", \\\"{x:1640,y:981,t:1526933393399};\\\", \\\"{x:1634,y:984,t:1526933393417};\\\", \\\"{x:1631,y:985,t:1526933393434};\\\", \\\"{x:1629,y:985,t:1526933393509};\\\", \\\"{x:1628,y:984,t:1526933393550};\\\", \\\"{x:1628,y:983,t:1526933393567};\\\", \\\"{x:1628,y:981,t:1526933393583};\\\", \\\"{x:1628,y:979,t:1526933393600};\\\", \\\"{x:1628,y:978,t:1526933393616};\\\", \\\"{x:1628,y:976,t:1526933393653};\\\", \\\"{x:1627,y:974,t:1526933393669};\\\", \\\"{x:1627,y:973,t:1526933393710};\\\", \\\"{x:1627,y:972,t:1526933393718};\\\", \\\"{x:1627,y:971,t:1526933393733};\\\", \\\"{x:1625,y:971,t:1526933393750};\\\", \\\"{x:1625,y:970,t:1526933393766};\\\", \\\"{x:1624,y:970,t:1526933393798};\\\", \\\"{x:1624,y:969,t:1526933393806};\\\", \\\"{x:1624,y:968,t:1526933393831};\\\", \\\"{x:1624,y:967,t:1526933393838};\\\", \\\"{x:1624,y:966,t:1526933393854};\\\", \\\"{x:1624,y:965,t:1526933393866};\\\", \\\"{x:1624,y:962,t:1526933393884};\\\", \\\"{x:1624,y:959,t:1526933393901};\\\", \\\"{x:1623,y:954,t:1526933393917};\\\", \\\"{x:1621,y:949,t:1526933393933};\\\", \\\"{x:1621,y:943,t:1526933393951};\\\", \\\"{x:1621,y:938,t:1526933393968};\\\", \\\"{x:1621,y:934,t:1526933393984};\\\", \\\"{x:1620,y:925,t:1526933394001};\\\", \\\"{x:1620,y:916,t:1526933394018};\\\", \\\"{x:1618,y:914,t:1526933394033};\\\", \\\"{x:1617,y:913,t:1526933394051};\\\", \\\"{x:1617,y:910,t:1526933394067};\\\", \\\"{x:1616,y:905,t:1526933394084};\\\", \\\"{x:1615,y:899,t:1526933394101};\\\", \\\"{x:1615,y:885,t:1526933394118};\\\", \\\"{x:1615,y:876,t:1526933394133};\\\", \\\"{x:1615,y:872,t:1526933394151};\\\", \\\"{x:1615,y:865,t:1526933394168};\\\", \\\"{x:1615,y:861,t:1526933394184};\\\", \\\"{x:1615,y:856,t:1526933394201};\\\", \\\"{x:1615,y:851,t:1526933394218};\\\", \\\"{x:1615,y:844,t:1526933394234};\\\", \\\"{x:1615,y:837,t:1526933394251};\\\", \\\"{x:1615,y:827,t:1526933394267};\\\", \\\"{x:1615,y:822,t:1526933394284};\\\", \\\"{x:1615,y:820,t:1526933394301};\\\", \\\"{x:1616,y:816,t:1526933394317};\\\", \\\"{x:1616,y:815,t:1526933394334};\\\", \\\"{x:1616,y:811,t:1526933394350};\\\", \\\"{x:1616,y:809,t:1526933394367};\\\", \\\"{x:1616,y:805,t:1526933394385};\\\", \\\"{x:1617,y:802,t:1526933394401};\\\", \\\"{x:1617,y:800,t:1526933394417};\\\", \\\"{x:1617,y:799,t:1526933394434};\\\", \\\"{x:1617,y:798,t:1526933394450};\\\", \\\"{x:1618,y:797,t:1526933394467};\\\", \\\"{x:1618,y:796,t:1526933394494};\\\", \\\"{x:1618,y:795,t:1526933394501};\\\", \\\"{x:1618,y:794,t:1526933394526};\\\", \\\"{x:1618,y:793,t:1526933394557};\\\", \\\"{x:1619,y:793,t:1526933394702};\\\", \\\"{x:1619,y:796,t:1526933394718};\\\", \\\"{x:1619,y:801,t:1526933394735};\\\", \\\"{x:1619,y:805,t:1526933394752};\\\", \\\"{x:1619,y:809,t:1526933394767};\\\", \\\"{x:1619,y:813,t:1526933394784};\\\", \\\"{x:1619,y:817,t:1526933394802};\\\", \\\"{x:1619,y:824,t:1526933394817};\\\", \\\"{x:1619,y:827,t:1526933394834};\\\", \\\"{x:1619,y:831,t:1526933394851};\\\", \\\"{x:1619,y:834,t:1526933394867};\\\", \\\"{x:1619,y:838,t:1526933394885};\\\", \\\"{x:1619,y:841,t:1526933394901};\\\", \\\"{x:1619,y:844,t:1526933394917};\\\", \\\"{x:1619,y:847,t:1526933394934};\\\", \\\"{x:1619,y:850,t:1526933394951};\\\", \\\"{x:1619,y:852,t:1526933394968};\\\", \\\"{x:1619,y:854,t:1526933395022};\\\", \\\"{x:1619,y:856,t:1526933395034};\\\", \\\"{x:1619,y:863,t:1526933395051};\\\", \\\"{x:1617,y:872,t:1526933395068};\\\", \\\"{x:1617,y:879,t:1526933395084};\\\", \\\"{x:1615,y:891,t:1526933395102};\\\", \\\"{x:1613,y:897,t:1526933395117};\\\", \\\"{x:1612,y:901,t:1526933395135};\\\", \\\"{x:1611,y:909,t:1526933395152};\\\", \\\"{x:1611,y:916,t:1526933395168};\\\", \\\"{x:1607,y:921,t:1526933395184};\\\", \\\"{x:1605,y:925,t:1526933395202};\\\", \\\"{x:1603,y:929,t:1526933395218};\\\", \\\"{x:1603,y:933,t:1526933395235};\\\", \\\"{x:1603,y:934,t:1526933395252};\\\", \\\"{x:1603,y:936,t:1526933395269};\\\", \\\"{x:1603,y:937,t:1526933395285};\\\", \\\"{x:1603,y:938,t:1526933395310};\\\", \\\"{x:1603,y:940,t:1526933395318};\\\", \\\"{x:1603,y:941,t:1526933395335};\\\", \\\"{x:1604,y:942,t:1526933395365};\\\", \\\"{x:1605,y:944,t:1526933395382};\\\", \\\"{x:1606,y:944,t:1526933395454};\\\", \\\"{x:1607,y:944,t:1526933395468};\\\", \\\"{x:1608,y:944,t:1526933395527};\\\", \\\"{x:1608,y:942,t:1526933395535};\\\", \\\"{x:1609,y:938,t:1526933395552};\\\", \\\"{x:1609,y:934,t:1526933395568};\\\", \\\"{x:1609,y:929,t:1526933395586};\\\", \\\"{x:1609,y:922,t:1526933395602};\\\", \\\"{x:1609,y:916,t:1526933395618};\\\", \\\"{x:1606,y:910,t:1526933395635};\\\", \\\"{x:1606,y:904,t:1526933395652};\\\", \\\"{x:1603,y:899,t:1526933395668};\\\", \\\"{x:1602,y:891,t:1526933395685};\\\", \\\"{x:1602,y:887,t:1526933395701};\\\", \\\"{x:1602,y:883,t:1526933395718};\\\", \\\"{x:1602,y:881,t:1526933395735};\\\", \\\"{x:1601,y:878,t:1526933395751};\\\", \\\"{x:1601,y:874,t:1526933395768};\\\", \\\"{x:1601,y:870,t:1526933395786};\\\", \\\"{x:1601,y:865,t:1526933395801};\\\", \\\"{x:1601,y:857,t:1526933395819};\\\", \\\"{x:1601,y:855,t:1526933395835};\\\", \\\"{x:1601,y:851,t:1526933395852};\\\", \\\"{x:1599,y:848,t:1526933395869};\\\", \\\"{x:1599,y:845,t:1526933395885};\\\", \\\"{x:1598,y:845,t:1526933395901};\\\", \\\"{x:1598,y:843,t:1526933395925};\\\", \\\"{x:1598,y:841,t:1526933395936};\\\", \\\"{x:1598,y:838,t:1526933395953};\\\", \\\"{x:1598,y:836,t:1526933395969};\\\", \\\"{x:1599,y:834,t:1526933395986};\\\", \\\"{x:1599,y:833,t:1526933396003};\\\", \\\"{x:1599,y:832,t:1526933396019};\\\", \\\"{x:1599,y:831,t:1526933396036};\\\", \\\"{x:1599,y:830,t:1526933396095};\\\", \\\"{x:1602,y:830,t:1526933396182};\\\", \\\"{x:1603,y:830,t:1526933396206};\\\", \\\"{x:1605,y:830,t:1526933396237};\\\", \\\"{x:1607,y:830,t:1526933396269};\\\", \\\"{x:1607,y:829,t:1526933396406};\\\", \\\"{x:1607,y:828,t:1526933396418};\\\", \\\"{x:1607,y:827,t:1526933396436};\\\", \\\"{x:1607,y:825,t:1526933396453};\\\", \\\"{x:1607,y:822,t:1526933396470};\\\", \\\"{x:1607,y:818,t:1526933396486};\\\", \\\"{x:1607,y:813,t:1526933396503};\\\", \\\"{x:1607,y:809,t:1526933396520};\\\", \\\"{x:1608,y:803,t:1526933396536};\\\", \\\"{x:1610,y:798,t:1526933396553};\\\", \\\"{x:1611,y:791,t:1526933396569};\\\", \\\"{x:1614,y:784,t:1526933396585};\\\", \\\"{x:1615,y:778,t:1526933396602};\\\", \\\"{x:1615,y:774,t:1526933396619};\\\", \\\"{x:1616,y:768,t:1526933396635};\\\", \\\"{x:1616,y:763,t:1526933396653};\\\", \\\"{x:1618,y:757,t:1526933396668};\\\", \\\"{x:1619,y:751,t:1526933396685};\\\", \\\"{x:1619,y:744,t:1526933396702};\\\", \\\"{x:1620,y:740,t:1526933396719};\\\", \\\"{x:1622,y:736,t:1526933396735};\\\", \\\"{x:1622,y:734,t:1526933396753};\\\", \\\"{x:1622,y:733,t:1526933396770};\\\", \\\"{x:1622,y:730,t:1526933396785};\\\", \\\"{x:1622,y:729,t:1526933396802};\\\", \\\"{x:1622,y:728,t:1526933396820};\\\", \\\"{x:1622,y:726,t:1526933397287};\\\", \\\"{x:1622,y:722,t:1526933397304};\\\", \\\"{x:1622,y:717,t:1526933397320};\\\", \\\"{x:1622,y:713,t:1526933397337};\\\", \\\"{x:1617,y:703,t:1526933397354};\\\", \\\"{x:1616,y:698,t:1526933397369};\\\", \\\"{x:1613,y:692,t:1526933397386};\\\", \\\"{x:1610,y:688,t:1526933397403};\\\", \\\"{x:1609,y:684,t:1526933397419};\\\", \\\"{x:1608,y:680,t:1526933397436};\\\", \\\"{x:1606,y:675,t:1526933397453};\\\", \\\"{x:1606,y:674,t:1526933397469};\\\", \\\"{x:1604,y:673,t:1526933397486};\\\", \\\"{x:1603,y:671,t:1526933397504};\\\", \\\"{x:1602,y:669,t:1526933397519};\\\", \\\"{x:1602,y:667,t:1526933397537};\\\", \\\"{x:1602,y:666,t:1526933397557};\\\", \\\"{x:1602,y:664,t:1526933397573};\\\", \\\"{x:1602,y:663,t:1526933397587};\\\", \\\"{x:1601,y:661,t:1526933397603};\\\", \\\"{x:1601,y:659,t:1526933397621};\\\", \\\"{x:1601,y:658,t:1526933397637};\\\", \\\"{x:1601,y:653,t:1526933397653};\\\", \\\"{x:1601,y:650,t:1526933397670};\\\", \\\"{x:1601,y:646,t:1526933397687};\\\", \\\"{x:1602,y:643,t:1526933397704};\\\", \\\"{x:1603,y:640,t:1526933397721};\\\", \\\"{x:1606,y:634,t:1526933397736};\\\", \\\"{x:1606,y:631,t:1526933397753};\\\", \\\"{x:1611,y:626,t:1526933397771};\\\", \\\"{x:1613,y:623,t:1526933397787};\\\", \\\"{x:1615,y:619,t:1526933397804};\\\", \\\"{x:1616,y:617,t:1526933397821};\\\", \\\"{x:1620,y:608,t:1526933397836};\\\", \\\"{x:1627,y:597,t:1526933397854};\\\", \\\"{x:1630,y:592,t:1526933397871};\\\", \\\"{x:1633,y:588,t:1526933397887};\\\", \\\"{x:1636,y:581,t:1526933397904};\\\", \\\"{x:1639,y:573,t:1526933397921};\\\", \\\"{x:1641,y:568,t:1526933397937};\\\", \\\"{x:1642,y:564,t:1526933397954};\\\", \\\"{x:1643,y:562,t:1526933397970};\\\", \\\"{x:1645,y:559,t:1526933397986};\\\", \\\"{x:1645,y:556,t:1526933398003};\\\", \\\"{x:1646,y:552,t:1526933398021};\\\", \\\"{x:1647,y:550,t:1526933398037};\\\", \\\"{x:1648,y:548,t:1526933398053};\\\", \\\"{x:1648,y:546,t:1526933398071};\\\", \\\"{x:1648,y:544,t:1526933398087};\\\", \\\"{x:1648,y:543,t:1526933398103};\\\", \\\"{x:1648,y:542,t:1526933398120};\\\", \\\"{x:1648,y:541,t:1526933398138};\\\", \\\"{x:1649,y:540,t:1526933398154};\\\", \\\"{x:1649,y:539,t:1526933398173};\\\", \\\"{x:1649,y:538,t:1526933398187};\\\", \\\"{x:1649,y:536,t:1526933398206};\\\", \\\"{x:1649,y:535,t:1526933398222};\\\", \\\"{x:1650,y:534,t:1526933398237};\\\", \\\"{x:1650,y:533,t:1526933398278};\\\", \\\"{x:1650,y:532,t:1526933398288};\\\", \\\"{x:1651,y:531,t:1526933398310};\\\", \\\"{x:1651,y:530,t:1526933398321};\\\", \\\"{x:1651,y:527,t:1526933398338};\\\", \\\"{x:1651,y:523,t:1526933398354};\\\", \\\"{x:1651,y:519,t:1526933398371};\\\", \\\"{x:1651,y:515,t:1526933398388};\\\", \\\"{x:1647,y:508,t:1526933398404};\\\", \\\"{x:1642,y:503,t:1526933398421};\\\", \\\"{x:1604,y:475,t:1526933398438};\\\", \\\"{x:1539,y:454,t:1526933398455};\\\", \\\"{x:1470,y:432,t:1526933398471};\\\", \\\"{x:1355,y:412,t:1526933398488};\\\", \\\"{x:1206,y:390,t:1526933398505};\\\", \\\"{x:1026,y:363,t:1526933398521};\\\", \\\"{x:859,y:352,t:1526933398539};\\\", \\\"{x:710,y:340,t:1526933398554};\\\", \\\"{x:580,y:335,t:1526933398570};\\\", \\\"{x:496,y:336,t:1526933398587};\\\", \\\"{x:445,y:336,t:1526933398604};\\\", \\\"{x:423,y:338,t:1526933398620};\\\", \\\"{x:414,y:342,t:1526933398637};\\\", \\\"{x:413,y:344,t:1526933398654};\\\", \\\"{x:412,y:345,t:1526933398670};\\\", \\\"{x:410,y:346,t:1526933398688};\\\", \\\"{x:404,y:350,t:1526933398704};\\\", \\\"{x:398,y:357,t:1526933398721};\\\", \\\"{x:397,y:360,t:1526933398737};\\\", \\\"{x:393,y:367,t:1526933398755};\\\", \\\"{x:390,y:377,t:1526933398771};\\\", \\\"{x:389,y:388,t:1526933398788};\\\", \\\"{x:387,y:405,t:1526933398804};\\\", \\\"{x:385,y:429,t:1526933398821};\\\", \\\"{x:385,y:444,t:1526933398838};\\\", \\\"{x:385,y:460,t:1526933398854};\\\", \\\"{x:385,y:471,t:1526933398871};\\\", \\\"{x:385,y:481,t:1526933398888};\\\", \\\"{x:386,y:491,t:1526933398904};\\\", \\\"{x:387,y:497,t:1526933398921};\\\", \\\"{x:387,y:499,t:1526933398938};\\\", \\\"{x:388,y:505,t:1526933398955};\\\", \\\"{x:390,y:512,t:1526933398972};\\\", \\\"{x:391,y:520,t:1526933398988};\\\", \\\"{x:392,y:526,t:1526933399004};\\\", \\\"{x:392,y:531,t:1526933399020};\\\", \\\"{x:394,y:538,t:1526933399037};\\\", \\\"{x:395,y:544,t:1526933399053};\\\", \\\"{x:396,y:555,t:1526933399071};\\\", \\\"{x:401,y:565,t:1526933399088};\\\", \\\"{x:403,y:568,t:1526933399105};\\\", \\\"{x:405,y:574,t:1526933399120};\\\", \\\"{x:405,y:576,t:1526933399138};\\\", \\\"{x:406,y:578,t:1526933399155};\\\", \\\"{x:406,y:580,t:1526933399171};\\\", \\\"{x:407,y:583,t:1526933399188};\\\", \\\"{x:407,y:587,t:1526933399204};\\\", \\\"{x:407,y:589,t:1526933399221};\\\", \\\"{x:407,y:590,t:1526933399244};\\\", \\\"{x:407,y:591,t:1526933399261};\\\", \\\"{x:407,y:593,t:1526933399272};\\\", \\\"{x:407,y:594,t:1526933399288};\\\", \\\"{x:407,y:596,t:1526933399305};\\\", \\\"{x:404,y:599,t:1526933399321};\\\", \\\"{x:390,y:602,t:1526933399337};\\\", \\\"{x:377,y:604,t:1526933399355};\\\", \\\"{x:354,y:604,t:1526933399372};\\\", \\\"{x:338,y:604,t:1526933399388};\\\", \\\"{x:312,y:604,t:1526933399405};\\\", \\\"{x:290,y:604,t:1526933399421};\\\", \\\"{x:281,y:606,t:1526933399437};\\\", \\\"{x:272,y:607,t:1526933399455};\\\", \\\"{x:268,y:607,t:1526933399471};\\\", \\\"{x:266,y:607,t:1526933399487};\\\", \\\"{x:265,y:607,t:1526933399517};\\\", \\\"{x:264,y:607,t:1526933399525};\\\", \\\"{x:263,y:607,t:1526933399537};\\\", \\\"{x:258,y:607,t:1526933399554};\\\", \\\"{x:255,y:608,t:1526933399572};\\\", \\\"{x:250,y:611,t:1526933399587};\\\", \\\"{x:242,y:612,t:1526933399605};\\\", \\\"{x:228,y:618,t:1526933399621};\\\", \\\"{x:207,y:625,t:1526933399639};\\\", \\\"{x:190,y:629,t:1526933399655};\\\", \\\"{x:169,y:635,t:1526933399672};\\\", \\\"{x:148,y:636,t:1526933399689};\\\", \\\"{x:137,y:636,t:1526933399705};\\\", \\\"{x:130,y:637,t:1526933399721};\\\", \\\"{x:131,y:636,t:1526933399966};\\\", \\\"{x:133,y:636,t:1526933399973};\\\", \\\"{x:135,y:636,t:1526933399989};\\\", \\\"{x:141,y:636,t:1526933400004};\\\", \\\"{x:146,y:636,t:1526933400022};\\\", \\\"{x:148,y:637,t:1526933400038};\\\", \\\"{x:151,y:637,t:1526933400055};\\\", \\\"{x:154,y:637,t:1526933400071};\\\", \\\"{x:155,y:637,t:1526933400089};\\\", \\\"{x:157,y:637,t:1526933400105};\\\", \\\"{x:159,y:637,t:1526933400125};\\\", \\\"{x:160,y:637,t:1526933400140};\\\", \\\"{x:161,y:637,t:1526933400156};\\\", \\\"{x:162,y:637,t:1526933400172};\\\", \\\"{x:163,y:637,t:1526933403607};\\\", \\\"{x:176,y:637,t:1526933403615};\\\", \\\"{x:197,y:637,t:1526933403630};\\\", \\\"{x:283,y:643,t:1526933403647};\\\", \\\"{x:311,y:648,t:1526933403662};\\\", \\\"{x:340,y:653,t:1526933403680};\\\", \\\"{x:361,y:654,t:1526933403696};\\\", \\\"{x:377,y:654,t:1526933403713};\\\", \\\"{x:391,y:654,t:1526933403730};\\\", \\\"{x:395,y:654,t:1526933403746};\\\", \\\"{x:396,y:654,t:1526933403799};\\\", \\\"{x:398,y:654,t:1526933403815};\\\", \\\"{x:398,y:653,t:1526933403831};\\\", \\\"{x:399,y:652,t:1526933403846};\\\", \\\"{x:400,y:651,t:1526933403863};\\\", \\\"{x:405,y:647,t:1526933403881};\\\", \\\"{x:410,y:646,t:1526933403897};\\\", \\\"{x:423,y:642,t:1526933403913};\\\", \\\"{x:439,y:640,t:1526933403930};\\\", \\\"{x:457,y:635,t:1526933403945};\\\", \\\"{x:472,y:631,t:1526933403963};\\\", \\\"{x:488,y:625,t:1526933403979};\\\", \\\"{x:502,y:620,t:1526933403996};\\\", \\\"{x:520,y:614,t:1526933404013};\\\", \\\"{x:558,y:606,t:1526933404030};\\\", \\\"{x:574,y:602,t:1526933404046};\\\", \\\"{x:590,y:598,t:1526933404063};\\\", \\\"{x:604,y:596,t:1526933404080};\\\", \\\"{x:610,y:594,t:1526933404096};\\\", \\\"{x:615,y:592,t:1526933404113};\\\", \\\"{x:617,y:590,t:1526933404130};\\\", \\\"{x:621,y:589,t:1526933404147};\\\", \\\"{x:625,y:586,t:1526933404163};\\\", \\\"{x:631,y:584,t:1526933404181};\\\", \\\"{x:648,y:578,t:1526933404198};\\\", \\\"{x:672,y:577,t:1526933404213};\\\", \\\"{x:702,y:577,t:1526933404230};\\\", \\\"{x:719,y:577,t:1526933404246};\\\", \\\"{x:741,y:577,t:1526933404263};\\\", \\\"{x:763,y:577,t:1526933404280};\\\", \\\"{x:792,y:577,t:1526933404297};\\\", \\\"{x:807,y:577,t:1526933404313};\\\", \\\"{x:818,y:577,t:1526933404330};\\\", \\\"{x:821,y:577,t:1526933404348};\\\", \\\"{x:823,y:577,t:1526933404416};\\\", \\\"{x:825,y:576,t:1526933404431};\\\", \\\"{x:827,y:574,t:1526933404451};\\\", \\\"{x:828,y:569,t:1526933404463};\\\", \\\"{x:829,y:569,t:1526933404480};\\\", \\\"{x:829,y:568,t:1526933404510};\\\", \\\"{x:830,y:567,t:1526933404542};\\\", \\\"{x:828,y:571,t:1526933404647};\\\", \\\"{x:827,y:574,t:1526933404663};\\\", \\\"{x:827,y:578,t:1526933404681};\\\", \\\"{x:827,y:580,t:1526933404697};\\\", \\\"{x:827,y:582,t:1526933404715};\\\", \\\"{x:828,y:583,t:1526933404730};\\\", \\\"{x:829,y:583,t:1526933404747};\\\", \\\"{x:831,y:585,t:1526933404764};\\\", \\\"{x:833,y:587,t:1526933404780};\\\", \\\"{x:834,y:588,t:1526933404797};\\\", \\\"{x:836,y:590,t:1526933404814};\\\", \\\"{x:838,y:592,t:1526933404830};\\\", \\\"{x:839,y:592,t:1526933404846};\\\", \\\"{x:839,y:593,t:1526933404871};\\\", \\\"{x:839,y:595,t:1526933405374};\\\", \\\"{x:837,y:600,t:1526933405382};\\\", \\\"{x:835,y:603,t:1526933405397};\\\", \\\"{x:816,y:621,t:1526933405415};\\\", \\\"{x:803,y:631,t:1526933405431};\\\", \\\"{x:785,y:641,t:1526933405447};\\\", \\\"{x:766,y:652,t:1526933405464};\\\", \\\"{x:749,y:659,t:1526933405481};\\\", \\\"{x:722,y:666,t:1526933405497};\\\", \\\"{x:687,y:676,t:1526933405515};\\\", \\\"{x:660,y:684,t:1526933405531};\\\", \\\"{x:644,y:691,t:1526933405548};\\\", \\\"{x:626,y:694,t:1526933405564};\\\", \\\"{x:613,y:699,t:1526933405581};\\\", \\\"{x:594,y:702,t:1526933405598};\\\", \\\"{x:588,y:705,t:1526933405614};\\\", \\\"{x:585,y:707,t:1526933405631};\\\", \\\"{x:578,y:708,t:1526933405648};\\\", \\\"{x:568,y:712,t:1526933405664};\\\", \\\"{x:557,y:715,t:1526933405681};\\\", \\\"{x:548,y:718,t:1526933405698};\\\", \\\"{x:543,y:718,t:1526933405714};\\\", \\\"{x:542,y:718,t:1526933405731};\\\", \\\"{x:541,y:718,t:1526933405748};\\\" ] }, { \\\"rt\\\": 57540, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 304055, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-I -I -7-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:717,t:1526933408256};\\\", \\\"{x:540,y:714,t:1526933408270};\\\", \\\"{x:540,y:712,t:1526933408283};\\\", \\\"{x:539,y:710,t:1526933408300};\\\", \\\"{x:538,y:708,t:1526933408316};\\\", \\\"{x:538,y:706,t:1526933408333};\\\", \\\"{x:538,y:705,t:1526933408919};\\\", \\\"{x:538,y:703,t:1526933408933};\\\", \\\"{x:539,y:701,t:1526933408950};\\\", \\\"{x:539,y:699,t:1526933408967};\\\", \\\"{x:539,y:698,t:1526933408983};\\\", \\\"{x:539,y:697,t:1526933409001};\\\", \\\"{x:544,y:695,t:1526933410767};\\\", \\\"{x:551,y:694,t:1526933410783};\\\", \\\"{x:562,y:691,t:1526933410791};\\\", \\\"{x:570,y:691,t:1526933410804};\\\", \\\"{x:588,y:690,t:1526933410818};\\\", \\\"{x:620,y:689,t:1526933410835};\\\", \\\"{x:651,y:691,t:1526933410853};\\\", \\\"{x:705,y:694,t:1526933410868};\\\", \\\"{x:768,y:699,t:1526933410885};\\\", \\\"{x:846,y:703,t:1526933410902};\\\", \\\"{x:901,y:708,t:1526933410918};\\\", \\\"{x:960,y:710,t:1526933410935};\\\", \\\"{x:1040,y:710,t:1526933410953};\\\", \\\"{x:1094,y:710,t:1526933410969};\\\", \\\"{x:1128,y:708,t:1526933410986};\\\", \\\"{x:1150,y:707,t:1526933411003};\\\", \\\"{x:1168,y:706,t:1526933411019};\\\", \\\"{x:1182,y:703,t:1526933411036};\\\", \\\"{x:1191,y:702,t:1526933411054};\\\", \\\"{x:1204,y:701,t:1526933411069};\\\", \\\"{x:1213,y:699,t:1526933411086};\\\", \\\"{x:1236,y:696,t:1526933411103};\\\", \\\"{x:1242,y:694,t:1526933411119};\\\", \\\"{x:1259,y:692,t:1526933411136};\\\", \\\"{x:1275,y:689,t:1526933411153};\\\", \\\"{x:1286,y:686,t:1526933411170};\\\", \\\"{x:1300,y:683,t:1526933411186};\\\", \\\"{x:1319,y:677,t:1526933411204};\\\", \\\"{x:1338,y:667,t:1526933411219};\\\", \\\"{x:1358,y:659,t:1526933411236};\\\", \\\"{x:1386,y:642,t:1526933411252};\\\", \\\"{x:1415,y:630,t:1526933411271};\\\", \\\"{x:1450,y:608,t:1526933411286};\\\", \\\"{x:1500,y:571,t:1526933411302};\\\", \\\"{x:1520,y:553,t:1526933411319};\\\", \\\"{x:1535,y:536,t:1526933411336};\\\", \\\"{x:1549,y:517,t:1526933411353};\\\", \\\"{x:1560,y:506,t:1526933411370};\\\", \\\"{x:1570,y:489,t:1526933411386};\\\", \\\"{x:1576,y:478,t:1526933411405};\\\", \\\"{x:1577,y:474,t:1526933411420};\\\", \\\"{x:1580,y:472,t:1526933411435};\\\", \\\"{x:1580,y:470,t:1526933411453};\\\", \\\"{x:1580,y:469,t:1526933411470};\\\", \\\"{x:1579,y:468,t:1526933411527};\\\", \\\"{x:1576,y:468,t:1526933411536};\\\", \\\"{x:1568,y:471,t:1526933411553};\\\", \\\"{x:1560,y:474,t:1526933411570};\\\", \\\"{x:1551,y:476,t:1526933411586};\\\", \\\"{x:1538,y:478,t:1526933411605};\\\", \\\"{x:1525,y:482,t:1526933411620};\\\", \\\"{x:1504,y:490,t:1526933411636};\\\", \\\"{x:1484,y:495,t:1526933411653};\\\", \\\"{x:1464,y:501,t:1526933411670};\\\", \\\"{x:1453,y:508,t:1526933411687};\\\", \\\"{x:1442,y:512,t:1526933411703};\\\", \\\"{x:1435,y:515,t:1526933411720};\\\", \\\"{x:1431,y:516,t:1526933411737};\\\", \\\"{x:1429,y:517,t:1526933411753};\\\", \\\"{x:1415,y:519,t:1526933411770};\\\", \\\"{x:1400,y:522,t:1526933411787};\\\", \\\"{x:1391,y:522,t:1526933411804};\\\", \\\"{x:1387,y:522,t:1526933411820};\\\", \\\"{x:1383,y:522,t:1526933411837};\\\", \\\"{x:1378,y:522,t:1526933411853};\\\", \\\"{x:1375,y:522,t:1526933411870};\\\", \\\"{x:1373,y:522,t:1526933411887};\\\", \\\"{x:1370,y:521,t:1526933411903};\\\", \\\"{x:1366,y:519,t:1526933411920};\\\", \\\"{x:1360,y:516,t:1526933411937};\\\", \\\"{x:1351,y:511,t:1526933411953};\\\", \\\"{x:1342,y:508,t:1526933411970};\\\", \\\"{x:1335,y:505,t:1526933411987};\\\", \\\"{x:1330,y:502,t:1526933412003};\\\", \\\"{x:1325,y:500,t:1526933412020};\\\", \\\"{x:1322,y:499,t:1526933412037};\\\", \\\"{x:1322,y:498,t:1526933412053};\\\", \\\"{x:1319,y:497,t:1526933412072};\\\", \\\"{x:1317,y:497,t:1526933412215};\\\", \\\"{x:1315,y:497,t:1526933412263};\\\", \\\"{x:1314,y:497,t:1526933412295};\\\", \\\"{x:1313,y:497,t:1526933412335};\\\", \\\"{x:1310,y:499,t:1526933412455};\\\", \\\"{x:1312,y:499,t:1526933418632};\\\", \\\"{x:1313,y:499,t:1526933418642};\\\", \\\"{x:1315,y:499,t:1526933418659};\\\", \\\"{x:1316,y:499,t:1526933418686};\\\", \\\"{x:1318,y:499,t:1526933424895};\\\", \\\"{x:1319,y:499,t:1526933424910};\\\", \\\"{x:1320,y:499,t:1526933424976};\\\", \\\"{x:1321,y:499,t:1526933425007};\\\", \\\"{x:1321,y:498,t:1526933425022};\\\", \\\"{x:1322,y:498,t:1526933425127};\\\", \\\"{x:1323,y:498,t:1526933425135};\\\", \\\"{x:1324,y:498,t:1526933425199};\\\", \\\"{x:1325,y:498,t:1526933425214};\\\", \\\"{x:1328,y:497,t:1526933425231};\\\", \\\"{x:1331,y:497,t:1526933425248};\\\", \\\"{x:1332,y:496,t:1526933425264};\\\", \\\"{x:1333,y:496,t:1526933425383};\\\", \\\"{x:1334,y:496,t:1526933425431};\\\", \\\"{x:1336,y:495,t:1526933425448};\\\", \\\"{x:1337,y:495,t:1526933425465};\\\", \\\"{x:1339,y:495,t:1526933425481};\\\", \\\"{x:1340,y:495,t:1526933425497};\\\", \\\"{x:1341,y:495,t:1526933425606};\\\", \\\"{x:1342,y:495,t:1526933425622};\\\", \\\"{x:1343,y:495,t:1526933425629};\\\", \\\"{x:1344,y:495,t:1526933425647};\\\", \\\"{x:1347,y:495,t:1526933425664};\\\", \\\"{x:1348,y:495,t:1526933425680};\\\", \\\"{x:1350,y:495,t:1526933425697};\\\", \\\"{x:1352,y:495,t:1526933425814};\\\", \\\"{x:1353,y:495,t:1526933425832};\\\", \\\"{x:1356,y:495,t:1526933425847};\\\", \\\"{x:1357,y:495,t:1526933425865};\\\", \\\"{x:1359,y:495,t:1526933425882};\\\", \\\"{x:1360,y:495,t:1526933425898};\\\", \\\"{x:1361,y:495,t:1526933425914};\\\", \\\"{x:1362,y:495,t:1526933425932};\\\", \\\"{x:1363,y:495,t:1526933426200};\\\", \\\"{x:1365,y:495,t:1526933426214};\\\", \\\"{x:1368,y:495,t:1526933426231};\\\", \\\"{x:1373,y:495,t:1526933426249};\\\", \\\"{x:1375,y:495,t:1526933426265};\\\", \\\"{x:1376,y:495,t:1526933426282};\\\", \\\"{x:1378,y:495,t:1526933426298};\\\", \\\"{x:1379,y:495,t:1526933426327};\\\", \\\"{x:1381,y:495,t:1526933426975};\\\", \\\"{x:1382,y:495,t:1526933426983};\\\", \\\"{x:1383,y:496,t:1526933426999};\\\", \\\"{x:1387,y:497,t:1526933427016};\\\", \\\"{x:1389,y:499,t:1526933427031};\\\", \\\"{x:1391,y:500,t:1526933427048};\\\", \\\"{x:1392,y:500,t:1526933427246};\\\", \\\"{x:1394,y:500,t:1526933427463};\\\", \\\"{x:1393,y:501,t:1526933428159};\\\", \\\"{x:1392,y:502,t:1526933428183};\\\", \\\"{x:1391,y:503,t:1526933428215};\\\", \\\"{x:1389,y:503,t:1526933428239};\\\", \\\"{x:1388,y:503,t:1526933428263};\\\", \\\"{x:1387,y:505,t:1526933428279};\\\", \\\"{x:1386,y:505,t:1526933428287};\\\", \\\"{x:1385,y:505,t:1526933428300};\\\", \\\"{x:1381,y:507,t:1526933428317};\\\", \\\"{x:1381,y:509,t:1526933428333};\\\", \\\"{x:1374,y:510,t:1526933428350};\\\", \\\"{x:1367,y:514,t:1526933428366};\\\", \\\"{x:1362,y:514,t:1526933428383};\\\", \\\"{x:1350,y:514,t:1526933428400};\\\", \\\"{x:1338,y:514,t:1526933428416};\\\", \\\"{x:1330,y:514,t:1526933428433};\\\", \\\"{x:1328,y:514,t:1526933428450};\\\", \\\"{x:1327,y:514,t:1526933428559};\\\", \\\"{x:1327,y:512,t:1526933428607};\\\", \\\"{x:1327,y:511,t:1526933428617};\\\", \\\"{x:1327,y:510,t:1526933428634};\\\", \\\"{x:1327,y:509,t:1526933428855};\\\", \\\"{x:1327,y:507,t:1526933428895};\\\", \\\"{x:1327,y:506,t:1526933429007};\\\", \\\"{x:1330,y:506,t:1526933429016};\\\", \\\"{x:1335,y:506,t:1526933429033};\\\", \\\"{x:1339,y:506,t:1526933429051};\\\", \\\"{x:1342,y:506,t:1526933429066};\\\", \\\"{x:1345,y:505,t:1526933429084};\\\", \\\"{x:1347,y:505,t:1526933429101};\\\", \\\"{x:1348,y:505,t:1526933429117};\\\", \\\"{x:1349,y:505,t:1526933429135};\\\", \\\"{x:1352,y:504,t:1526933429152};\\\", \\\"{x:1354,y:503,t:1526933429167};\\\", \\\"{x:1356,y:503,t:1526933429184};\\\", \\\"{x:1357,y:503,t:1526933429201};\\\", \\\"{x:1358,y:503,t:1526933429217};\\\", \\\"{x:1360,y:502,t:1526933429239};\\\", \\\"{x:1362,y:501,t:1526933429254};\\\", \\\"{x:1365,y:498,t:1526933429267};\\\", \\\"{x:1366,y:498,t:1526933429284};\\\", \\\"{x:1369,y:496,t:1526933429301};\\\", \\\"{x:1373,y:496,t:1526933429316};\\\", \\\"{x:1375,y:496,t:1526933429334};\\\", \\\"{x:1376,y:495,t:1526933429408};\\\", \\\"{x:1377,y:494,t:1526933429417};\\\", \\\"{x:1380,y:493,t:1526933429434};\\\", \\\"{x:1382,y:492,t:1526933429454};\\\", \\\"{x:1383,y:492,t:1526933429647};\\\", \\\"{x:1386,y:492,t:1526933429655};\\\", \\\"{x:1389,y:492,t:1526933429668};\\\", \\\"{x:1404,y:493,t:1526933429684};\\\", \\\"{x:1419,y:496,t:1526933429701};\\\", \\\"{x:1429,y:496,t:1526933429718};\\\", \\\"{x:1438,y:498,t:1526933429734};\\\", \\\"{x:1441,y:498,t:1526933429751};\\\", \\\"{x:1442,y:498,t:1526933429775};\\\", \\\"{x:1443,y:498,t:1526933429790};\\\", \\\"{x:1444,y:498,t:1526933429863};\\\", \\\"{x:1445,y:498,t:1526933429879};\\\", \\\"{x:1448,y:498,t:1526933430127};\\\", \\\"{x:1455,y:498,t:1526933430135};\\\", \\\"{x:1471,y:498,t:1526933430151};\\\", \\\"{x:1483,y:498,t:1526933430168};\\\", \\\"{x:1495,y:498,t:1526933430185};\\\", \\\"{x:1498,y:498,t:1526933430201};\\\", \\\"{x:1499,y:498,t:1526933430222};\\\", \\\"{x:1501,y:498,t:1526933430255};\\\", \\\"{x:1503,y:498,t:1526933430268};\\\", \\\"{x:1510,y:498,t:1526933430284};\\\", \\\"{x:1519,y:498,t:1526933430302};\\\", \\\"{x:1524,y:498,t:1526933430319};\\\", \\\"{x:1525,y:498,t:1526933430335};\\\", \\\"{x:1524,y:498,t:1526933430551};\\\", \\\"{x:1523,y:499,t:1526933430591};\\\", \\\"{x:1522,y:500,t:1526933430621};\\\", \\\"{x:1529,y:500,t:1526933430783};\\\", \\\"{x:1539,y:500,t:1526933430791};\\\", \\\"{x:1550,y:500,t:1526933430802};\\\", \\\"{x:1575,y:501,t:1526933430819};\\\", \\\"{x:1599,y:503,t:1526933430835};\\\", \\\"{x:1610,y:505,t:1526933430852};\\\", \\\"{x:1613,y:505,t:1526933430869};\\\", \\\"{x:1613,y:506,t:1526933430911};\\\", \\\"{x:1613,y:507,t:1526933430926};\\\", \\\"{x:1613,y:508,t:1526933430975};\\\", \\\"{x:1609,y:508,t:1526933430991};\\\", \\\"{x:1608,y:508,t:1526933431002};\\\", \\\"{x:1600,y:508,t:1526933431018};\\\", \\\"{x:1591,y:508,t:1526933431035};\\\", \\\"{x:1588,y:508,t:1526933431051};\\\", \\\"{x:1587,y:508,t:1526933431069};\\\", \\\"{x:1586,y:508,t:1526933431326};\\\", \\\"{x:1587,y:508,t:1526933431335};\\\", \\\"{x:1589,y:507,t:1526933431351};\\\", \\\"{x:1592,y:505,t:1526933431368};\\\", \\\"{x:1596,y:504,t:1526933431385};\\\", \\\"{x:1602,y:503,t:1526933431401};\\\", \\\"{x:1604,y:503,t:1526933431418};\\\", \\\"{x:1609,y:502,t:1526933431435};\\\", \\\"{x:1615,y:502,t:1526933431451};\\\", \\\"{x:1623,y:500,t:1526933431468};\\\", \\\"{x:1631,y:499,t:1526933431485};\\\", \\\"{x:1641,y:498,t:1526933431501};\\\", \\\"{x:1645,y:496,t:1526933431518};\\\", \\\"{x:1646,y:496,t:1526933431541};\\\", \\\"{x:1649,y:496,t:1526933431574};\\\", \\\"{x:1651,y:496,t:1526933431586};\\\", \\\"{x:1653,y:496,t:1526933431603};\\\", \\\"{x:1654,y:496,t:1526933431619};\\\", \\\"{x:1655,y:496,t:1526933431636};\\\", \\\"{x:1655,y:498,t:1526933431751};\\\", \\\"{x:1654,y:499,t:1526933431927};\\\", \\\"{x:1648,y:499,t:1526933431936};\\\", \\\"{x:1617,y:499,t:1526933431952};\\\", \\\"{x:1575,y:499,t:1526933431969};\\\", \\\"{x:1527,y:499,t:1526933431986};\\\", \\\"{x:1477,y:499,t:1526933432003};\\\", \\\"{x:1420,y:498,t:1526933432020};\\\", \\\"{x:1386,y:498,t:1526933432036};\\\", \\\"{x:1357,y:497,t:1526933432053};\\\", \\\"{x:1335,y:496,t:1526933432070};\\\", \\\"{x:1319,y:493,t:1526933432087};\\\", \\\"{x:1292,y:493,t:1526933432104};\\\", \\\"{x:1288,y:493,t:1526933432120};\\\", \\\"{x:1286,y:493,t:1526933432136};\\\", \\\"{x:1288,y:494,t:1526933432320};\\\", \\\"{x:1298,y:495,t:1526933432336};\\\", \\\"{x:1302,y:495,t:1526933432353};\\\", \\\"{x:1302,y:496,t:1526933432479};\\\", \\\"{x:1303,y:496,t:1526933432583};\\\", \\\"{x:1304,y:496,t:1526933432615};\\\", \\\"{x:1305,y:496,t:1526933432663};\\\", \\\"{x:1306,y:496,t:1526933433062};\\\", \\\"{x:1307,y:496,t:1526933433102};\\\", \\\"{x:1308,y:496,t:1526933433127};\\\", \\\"{x:1311,y:496,t:1526933433137};\\\", \\\"{x:1311,y:497,t:1526933433169};\\\", \\\"{x:1312,y:497,t:1526933433187};\\\", \\\"{x:1314,y:497,t:1526933433455};\\\", \\\"{x:1317,y:498,t:1526933435431};\\\", \\\"{x:1319,y:500,t:1526933435439};\\\", \\\"{x:1326,y:503,t:1526933435456};\\\", \\\"{x:1334,y:505,t:1526933435472};\\\", \\\"{x:1340,y:507,t:1526933435489};\\\", \\\"{x:1343,y:508,t:1526933435506};\\\", \\\"{x:1344,y:509,t:1526933435522};\\\", \\\"{x:1345,y:509,t:1526933435606};\\\", \\\"{x:1346,y:509,t:1526933435630};\\\", \\\"{x:1347,y:511,t:1526933435638};\\\", \\\"{x:1349,y:511,t:1526933435726};\\\", \\\"{x:1350,y:510,t:1526933435742};\\\", \\\"{x:1351,y:510,t:1526933435755};\\\", \\\"{x:1351,y:509,t:1526933435771};\\\", \\\"{x:1352,y:507,t:1526933435789};\\\", \\\"{x:1354,y:506,t:1526933435806};\\\", \\\"{x:1354,y:504,t:1526933435821};\\\", \\\"{x:1355,y:503,t:1526933435839};\\\", \\\"{x:1356,y:501,t:1526933435856};\\\", \\\"{x:1357,y:500,t:1526933435871};\\\", \\\"{x:1357,y:499,t:1526933435889};\\\", \\\"{x:1357,y:498,t:1526933435906};\\\", \\\"{x:1358,y:497,t:1526933435922};\\\", \\\"{x:1359,y:496,t:1526933435966};\\\", \\\"{x:1358,y:496,t:1526933436415};\\\", \\\"{x:1360,y:496,t:1526933438319};\\\", \\\"{x:1363,y:496,t:1526933438327};\\\", \\\"{x:1366,y:496,t:1526933438342};\\\", \\\"{x:1372,y:496,t:1526933438358};\\\", \\\"{x:1379,y:497,t:1526933438374};\\\", \\\"{x:1382,y:498,t:1526933438391};\\\", \\\"{x:1385,y:498,t:1526933438536};\\\", \\\"{x:1386,y:498,t:1526933438543};\\\", \\\"{x:1388,y:498,t:1526933438558};\\\", \\\"{x:1389,y:498,t:1526933438575};\\\", \\\"{x:1391,y:498,t:1526933438591};\\\", \\\"{x:1393,y:498,t:1526933438608};\\\", \\\"{x:1396,y:498,t:1526933438630};\\\", \\\"{x:1398,y:498,t:1526933438641};\\\", \\\"{x:1401,y:498,t:1526933438659};\\\", \\\"{x:1403,y:498,t:1526933438675};\\\", \\\"{x:1404,y:497,t:1526933438743};\\\", \\\"{x:1405,y:497,t:1526933438791};\\\", \\\"{x:1407,y:497,t:1526933438823};\\\", \\\"{x:1409,y:496,t:1526933438831};\\\", \\\"{x:1409,y:495,t:1526933438847};\\\", \\\"{x:1411,y:495,t:1526933438858};\\\", \\\"{x:1413,y:495,t:1526933439239};\\\", \\\"{x:1414,y:495,t:1526933439246};\\\", \\\"{x:1418,y:495,t:1526933439258};\\\", \\\"{x:1426,y:495,t:1526933439276};\\\", \\\"{x:1435,y:495,t:1526933439292};\\\", \\\"{x:1445,y:495,t:1526933439308};\\\", \\\"{x:1448,y:496,t:1526933439325};\\\", \\\"{x:1450,y:497,t:1526933439391};\\\", \\\"{x:1451,y:497,t:1526933439408};\\\", \\\"{x:1454,y:497,t:1526933439425};\\\", \\\"{x:1456,y:497,t:1526933439443};\\\", \\\"{x:1459,y:497,t:1526933439458};\\\", \\\"{x:1464,y:497,t:1526933439475};\\\", \\\"{x:1467,y:498,t:1526933439492};\\\", \\\"{x:1469,y:499,t:1526933439509};\\\", \\\"{x:1470,y:499,t:1526933439525};\\\", \\\"{x:1471,y:499,t:1526933439542};\\\", \\\"{x:1472,y:499,t:1526933439583};\\\", \\\"{x:1473,y:499,t:1526933439592};\\\", \\\"{x:1479,y:499,t:1526933439609};\\\", \\\"{x:1480,y:499,t:1526933439625};\\\", \\\"{x:1483,y:499,t:1526933439642};\\\", \\\"{x:1485,y:499,t:1526933439659};\\\", \\\"{x:1486,y:499,t:1526933439676};\\\", \\\"{x:1487,y:499,t:1526933439692};\\\", \\\"{x:1488,y:499,t:1526933440191};\\\", \\\"{x:1493,y:499,t:1526933440210};\\\", \\\"{x:1505,y:499,t:1526933440227};\\\", \\\"{x:1515,y:499,t:1526933440243};\\\", \\\"{x:1522,y:499,t:1526933440260};\\\", \\\"{x:1527,y:499,t:1526933440277};\\\", \\\"{x:1529,y:499,t:1526933440292};\\\", \\\"{x:1530,y:499,t:1526933440359};\\\", \\\"{x:1531,y:499,t:1526933440376};\\\", \\\"{x:1533,y:499,t:1526933440423};\\\", \\\"{x:1534,y:499,t:1526933440438};\\\", \\\"{x:1537,y:499,t:1526933440447};\\\", \\\"{x:1540,y:499,t:1526933440459};\\\", \\\"{x:1545,y:499,t:1526933440476};\\\", \\\"{x:1548,y:499,t:1526933440493};\\\", \\\"{x:1550,y:499,t:1526933440509};\\\", \\\"{x:1551,y:499,t:1526933440526};\\\", \\\"{x:1552,y:499,t:1526933441175};\\\", \\\"{x:1554,y:499,t:1526933441182};\\\", \\\"{x:1555,y:499,t:1526933441193};\\\", \\\"{x:1559,y:499,t:1526933441211};\\\", \\\"{x:1564,y:500,t:1526933441226};\\\", \\\"{x:1566,y:500,t:1526933441243};\\\", \\\"{x:1569,y:500,t:1526933441260};\\\", \\\"{x:1573,y:500,t:1526933441277};\\\", \\\"{x:1576,y:501,t:1526933441293};\\\", \\\"{x:1581,y:502,t:1526933441311};\\\", \\\"{x:1585,y:502,t:1526933441327};\\\", \\\"{x:1587,y:502,t:1526933441343};\\\", \\\"{x:1593,y:502,t:1526933441360};\\\", \\\"{x:1598,y:502,t:1526933441377};\\\", \\\"{x:1603,y:502,t:1526933441393};\\\", \\\"{x:1606,y:502,t:1526933441411};\\\", \\\"{x:1608,y:502,t:1526933441427};\\\", \\\"{x:1610,y:502,t:1526933441443};\\\", \\\"{x:1611,y:502,t:1526933441460};\\\", \\\"{x:1612,y:501,t:1526933441478};\\\", \\\"{x:1613,y:501,t:1526933441493};\\\", \\\"{x:1615,y:500,t:1526933441511};\\\", \\\"{x:1614,y:500,t:1526933441695};\\\", \\\"{x:1612,y:500,t:1526933441727};\\\", \\\"{x:1610,y:501,t:1526933441745};\\\", \\\"{x:1604,y:505,t:1526933441760};\\\", \\\"{x:1601,y:507,t:1526933441777};\\\", \\\"{x:1597,y:508,t:1526933441795};\\\", \\\"{x:1592,y:511,t:1526933441810};\\\", \\\"{x:1588,y:511,t:1526933441827};\\\", \\\"{x:1576,y:512,t:1526933441845};\\\", \\\"{x:1558,y:512,t:1526933441860};\\\", \\\"{x:1527,y:514,t:1526933441877};\\\", \\\"{x:1444,y:514,t:1526933441894};\\\", \\\"{x:1387,y:513,t:1526933441910};\\\", \\\"{x:1293,y:513,t:1526933441927};\\\", \\\"{x:1185,y:513,t:1526933441944};\\\", \\\"{x:1052,y:498,t:1526933441960};\\\", \\\"{x:909,y:483,t:1526933441977};\\\", \\\"{x:799,y:476,t:1526933441994};\\\", \\\"{x:680,y:472,t:1526933442010};\\\", \\\"{x:656,y:472,t:1526933442026};\\\", \\\"{x:589,y:471,t:1526933442044};\\\", \\\"{x:545,y:476,t:1526933442059};\\\", \\\"{x:538,y:476,t:1526933442077};\\\", \\\"{x:531,y:478,t:1526933442093};\\\", \\\"{x:530,y:479,t:1526933442110};\\\", \\\"{x:529,y:481,t:1526933442127};\\\", \\\"{x:526,y:481,t:1526933442144};\\\", \\\"{x:525,y:481,t:1526933442160};\\\", \\\"{x:523,y:484,t:1526933442177};\\\", \\\"{x:523,y:485,t:1526933442279};\\\", \\\"{x:523,y:486,t:1526933442302};\\\", \\\"{x:523,y:487,t:1526933442326};\\\", \\\"{x:523,y:489,t:1526933442351};\\\", \\\"{x:524,y:489,t:1526933442382};\\\", \\\"{x:525,y:491,t:1526933442414};\\\", \\\"{x:525,y:493,t:1526933442430};\\\", \\\"{x:525,y:494,t:1526933442444};\\\", \\\"{x:525,y:495,t:1526933442462};\\\", \\\"{x:525,y:496,t:1526933442477};\\\", \\\"{x:532,y:497,t:1526933442494};\\\", \\\"{x:537,y:497,t:1526933442511};\\\", \\\"{x:540,y:497,t:1526933442527};\\\", \\\"{x:539,y:498,t:1526933443734};\\\", \\\"{x:536,y:502,t:1526933443746};\\\", \\\"{x:527,y:509,t:1526933443762};\\\", \\\"{x:520,y:519,t:1526933443779};\\\", \\\"{x:514,y:528,t:1526933443797};\\\", \\\"{x:507,y:537,t:1526933443812};\\\", \\\"{x:502,y:544,t:1526933443828};\\\", \\\"{x:499,y:552,t:1526933443845};\\\", \\\"{x:496,y:560,t:1526933443863};\\\", \\\"{x:495,y:564,t:1526933443879};\\\", \\\"{x:493,y:570,t:1526933443895};\\\", \\\"{x:488,y:578,t:1526933443913};\\\", \\\"{x:486,y:581,t:1526933443930};\\\", \\\"{x:486,y:586,t:1526933443946};\\\", \\\"{x:486,y:587,t:1526933443963};\\\", \\\"{x:485,y:589,t:1526933443982};\\\", \\\"{x:487,y:589,t:1526933456167};\\\", \\\"{x:500,y:589,t:1526933456184};\\\", \\\"{x:516,y:589,t:1526933456201};\\\", \\\"{x:524,y:589,t:1526933456218};\\\", \\\"{x:532,y:589,t:1526933456234};\\\", \\\"{x:546,y:591,t:1526933456251};\\\", \\\"{x:563,y:595,t:1526933456267};\\\", \\\"{x:585,y:596,t:1526933456285};\\\", \\\"{x:606,y:597,t:1526933456301};\\\", \\\"{x:634,y:600,t:1526933456318};\\\", \\\"{x:652,y:600,t:1526933456340};\\\", \\\"{x:678,y:600,t:1526933456356};\\\", \\\"{x:750,y:600,t:1526933456374};\\\", \\\"{x:761,y:600,t:1526933456389};\\\", \\\"{x:786,y:600,t:1526933456406};\\\", \\\"{x:800,y:596,t:1526933456423};\\\", \\\"{x:814,y:590,t:1526933456440};\\\", \\\"{x:820,y:588,t:1526933456457};\\\", \\\"{x:826,y:585,t:1526933456474};\\\", \\\"{x:830,y:580,t:1526933456490};\\\", \\\"{x:832,y:577,t:1526933456506};\\\", \\\"{x:832,y:575,t:1526933456525};\\\", \\\"{x:832,y:574,t:1526933456540};\\\", \\\"{x:836,y:571,t:1526933456556};\\\", \\\"{x:839,y:565,t:1526933456573};\\\", \\\"{x:839,y:564,t:1526933456591};\\\", \\\"{x:839,y:562,t:1526933456607};\\\", \\\"{x:839,y:559,t:1526933456624};\\\", \\\"{x:838,y:557,t:1526933456641};\\\", \\\"{x:836,y:556,t:1526933456656};\\\", \\\"{x:836,y:555,t:1526933456678};\\\", \\\"{x:836,y:554,t:1526933456690};\\\", \\\"{x:835,y:554,t:1526933456717};\\\", \\\"{x:835,y:552,t:1526933456734};\\\", \\\"{x:835,y:551,t:1526933456799};\\\", \\\"{x:835,y:549,t:1526933456880};\\\", \\\"{x:835,y:548,t:1526933456902};\\\", \\\"{x:835,y:546,t:1526933456992};\\\", \\\"{x:835,y:545,t:1526933457013};\\\", \\\"{x:835,y:544,t:1526933457037};\\\", \\\"{x:835,y:543,t:1526933457077};\\\", \\\"{x:835,y:542,t:1526933457110};\\\", \\\"{x:835,y:541,t:1526933463861};\\\", \\\"{x:831,y:544,t:1526933463868};\\\", \\\"{x:826,y:553,t:1526933463883};\\\", \\\"{x:820,y:564,t:1526933463898};\\\", \\\"{x:810,y:580,t:1526933463915};\\\", \\\"{x:799,y:602,t:1526933463931};\\\", \\\"{x:786,y:622,t:1526933463947};\\\", \\\"{x:771,y:646,t:1526933463965};\\\", \\\"{x:760,y:661,t:1526933463982};\\\", \\\"{x:750,y:673,t:1526933463999};\\\", \\\"{x:733,y:694,t:1526933464015};\\\", \\\"{x:696,y:725,t:1526933464031};\\\", \\\"{x:669,y:752,t:1526933464048};\\\", \\\"{x:628,y:775,t:1526933464065};\\\", \\\"{x:622,y:781,t:1526933464081};\\\", \\\"{x:621,y:782,t:1526933464099};\\\", \\\"{x:618,y:782,t:1526933464114};\\\", \\\"{x:617,y:782,t:1526933464131};\\\", \\\"{x:617,y:783,t:1526933464148};\\\", \\\"{x:617,y:782,t:1526933464229};\\\", \\\"{x:614,y:779,t:1526933464245};\\\", \\\"{x:614,y:776,t:1526933464253};\\\", \\\"{x:614,y:775,t:1526933464266};\\\", \\\"{x:608,y:766,t:1526933464281};\\\", \\\"{x:599,y:758,t:1526933464299};\\\", \\\"{x:583,y:750,t:1526933464316};\\\", \\\"{x:565,y:741,t:1526933464332};\\\", \\\"{x:543,y:734,t:1526933464350};\\\", \\\"{x:533,y:730,t:1526933464366};\\\", \\\"{x:527,y:725,t:1526933464381};\\\", \\\"{x:522,y:723,t:1526933464399};\\\", \\\"{x:520,y:722,t:1526933464415};\\\", \\\"{x:518,y:722,t:1526933464431};\\\", \\\"{x:516,y:722,t:1526933464448};\\\", \\\"{x:510,y:719,t:1526933464465};\\\", \\\"{x:507,y:719,t:1526933464482};\\\", \\\"{x:506,y:719,t:1526933464498};\\\" ] }, { \\\"rt\\\": 12647, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 317933, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:717,t:1526933468165};\\\", \\\"{x:512,y:713,t:1526933468177};\\\", \\\"{x:517,y:713,t:1526933468184};\\\", \\\"{x:526,y:711,t:1526933468201};\\\", \\\"{x:534,y:710,t:1526933468218};\\\", \\\"{x:542,y:710,t:1526933468234};\\\", \\\"{x:549,y:710,t:1526933468252};\\\", \\\"{x:560,y:709,t:1526933468268};\\\", \\\"{x:576,y:705,t:1526933468284};\\\", \\\"{x:601,y:702,t:1526933468301};\\\", \\\"{x:615,y:700,t:1526933468319};\\\", \\\"{x:622,y:700,t:1526933468335};\\\", \\\"{x:633,y:700,t:1526933468352};\\\", \\\"{x:653,y:697,t:1526933468368};\\\", \\\"{x:671,y:694,t:1526933468385};\\\", \\\"{x:699,y:688,t:1526933468402};\\\", \\\"{x:721,y:683,t:1526933468419};\\\", \\\"{x:735,y:681,t:1526933468434};\\\", \\\"{x:739,y:677,t:1526933468452};\\\", \\\"{x:774,y:668,t:1526933468469};\\\", \\\"{x:789,y:660,t:1526933468485};\\\", \\\"{x:797,y:658,t:1526933468502};\\\", \\\"{x:808,y:658,t:1526933468518};\\\", \\\"{x:820,y:654,t:1526933468535};\\\", \\\"{x:834,y:648,t:1526933468552};\\\", \\\"{x:845,y:642,t:1526933468569};\\\", \\\"{x:869,y:634,t:1526933468585};\\\", \\\"{x:898,y:625,t:1526933468603};\\\", \\\"{x:914,y:619,t:1526933468618};\\\", \\\"{x:934,y:612,t:1526933468636};\\\", \\\"{x:955,y:608,t:1526933468652};\\\", \\\"{x:991,y:598,t:1526933468669};\\\", \\\"{x:1028,y:588,t:1526933468686};\\\", \\\"{x:1052,y:580,t:1526933468701};\\\", \\\"{x:1075,y:574,t:1526933468719};\\\", \\\"{x:1101,y:568,t:1526933468736};\\\", \\\"{x:1122,y:561,t:1526933468751};\\\", \\\"{x:1140,y:556,t:1526933468769};\\\", \\\"{x:1159,y:546,t:1526933468786};\\\", \\\"{x:1184,y:536,t:1526933468802};\\\", \\\"{x:1207,y:523,t:1526933468819};\\\", \\\"{x:1223,y:516,t:1526933468836};\\\", \\\"{x:1238,y:511,t:1526933468852};\\\", \\\"{x:1259,y:504,t:1526933468868};\\\", \\\"{x:1273,y:499,t:1526933468886};\\\", \\\"{x:1278,y:499,t:1526933468903};\\\", \\\"{x:1282,y:498,t:1526933468919};\\\", \\\"{x:1283,y:498,t:1526933468935};\\\", \\\"{x:1284,y:498,t:1526933468953};\\\", \\\"{x:1285,y:498,t:1526933468973};\\\", \\\"{x:1287,y:497,t:1526933468986};\\\", \\\"{x:1288,y:497,t:1526933469003};\\\", \\\"{x:1291,y:497,t:1526933469019};\\\", \\\"{x:1294,y:497,t:1526933469036};\\\", \\\"{x:1297,y:499,t:1526933469052};\\\", \\\"{x:1300,y:501,t:1526933469069};\\\", \\\"{x:1301,y:503,t:1526933469086};\\\", \\\"{x:1301,y:506,t:1526933469103};\\\", \\\"{x:1301,y:508,t:1526933469119};\\\", \\\"{x:1301,y:510,t:1526933469136};\\\", \\\"{x:1301,y:512,t:1526933469153};\\\", \\\"{x:1300,y:513,t:1526933469169};\\\", \\\"{x:1296,y:513,t:1526933469373};\\\", \\\"{x:1288,y:513,t:1526933469387};\\\", \\\"{x:1267,y:516,t:1526933469403};\\\", \\\"{x:1247,y:519,t:1526933469420};\\\", \\\"{x:1229,y:521,t:1526933469437};\\\", \\\"{x:1211,y:526,t:1526933469454};\\\", \\\"{x:1197,y:526,t:1526933469471};\\\", \\\"{x:1182,y:530,t:1526933469486};\\\", \\\"{x:1169,y:532,t:1526933469504};\\\", \\\"{x:1161,y:534,t:1526933469520};\\\", \\\"{x:1159,y:534,t:1526933469537};\\\", \\\"{x:1153,y:535,t:1526933469553};\\\", \\\"{x:1150,y:536,t:1526933469571};\\\", \\\"{x:1145,y:536,t:1526933469586};\\\", \\\"{x:1142,y:536,t:1526933469603};\\\", \\\"{x:1134,y:536,t:1526933469621};\\\", \\\"{x:1124,y:538,t:1526933469636};\\\", \\\"{x:1104,y:539,t:1526933469653};\\\", \\\"{x:1091,y:539,t:1526933469670};\\\", \\\"{x:1079,y:539,t:1526933469686};\\\", \\\"{x:1067,y:539,t:1526933469703};\\\", \\\"{x:1057,y:539,t:1526933469721};\\\", \\\"{x:1034,y:533,t:1526933469736};\\\", \\\"{x:1016,y:530,t:1526933469753};\\\", \\\"{x:995,y:524,t:1526933469771};\\\", \\\"{x:974,y:520,t:1526933469787};\\\", \\\"{x:958,y:517,t:1526933469803};\\\", \\\"{x:938,y:515,t:1526933469822};\\\", \\\"{x:918,y:512,t:1526933469836};\\\", \\\"{x:907,y:511,t:1526933469852};\\\", \\\"{x:892,y:510,t:1526933469870};\\\", \\\"{x:872,y:506,t:1526933469887};\\\", \\\"{x:859,y:503,t:1526933469902};\\\", \\\"{x:842,y:499,t:1526933469920};\\\", \\\"{x:824,y:495,t:1526933469937};\\\", \\\"{x:807,y:493,t:1526933469953};\\\", \\\"{x:795,y:491,t:1526933469970};\\\", \\\"{x:779,y:489,t:1526933469986};\\\", \\\"{x:771,y:488,t:1526933470003};\\\", \\\"{x:760,y:485,t:1526933470021};\\\", \\\"{x:752,y:484,t:1526933470036};\\\", \\\"{x:746,y:482,t:1526933470053};\\\", \\\"{x:739,y:481,t:1526933470070};\\\", \\\"{x:732,y:480,t:1526933470087};\\\", \\\"{x:725,y:480,t:1526933470103};\\\", \\\"{x:715,y:480,t:1526933470119};\\\", \\\"{x:707,y:479,t:1526933470137};\\\", \\\"{x:703,y:479,t:1526933470153};\\\", \\\"{x:698,y:478,t:1526933470170};\\\", \\\"{x:695,y:478,t:1526933470187};\\\", \\\"{x:692,y:478,t:1526933470203};\\\", \\\"{x:688,y:478,t:1526933470220};\\\", \\\"{x:673,y:478,t:1526933470236};\\\", \\\"{x:663,y:478,t:1526933470254};\\\", \\\"{x:651,y:478,t:1526933470270};\\\", \\\"{x:644,y:478,t:1526933470287};\\\", \\\"{x:634,y:478,t:1526933470304};\\\", \\\"{x:623,y:479,t:1526933470320};\\\", \\\"{x:614,y:482,t:1526933470337};\\\", \\\"{x:605,y:482,t:1526933470354};\\\", \\\"{x:594,y:484,t:1526933470370};\\\", \\\"{x:581,y:487,t:1526933470389};\\\", \\\"{x:570,y:488,t:1526933470404};\\\", \\\"{x:562,y:488,t:1526933470420};\\\", \\\"{x:558,y:489,t:1526933470437};\\\", \\\"{x:554,y:491,t:1526933470454};\\\", \\\"{x:552,y:491,t:1526933470471};\\\", \\\"{x:547,y:493,t:1526933470487};\\\", \\\"{x:541,y:494,t:1526933470504};\\\", \\\"{x:530,y:496,t:1526933470521};\\\", \\\"{x:516,y:500,t:1526933470537};\\\", \\\"{x:501,y:504,t:1526933470555};\\\", \\\"{x:488,y:506,t:1526933470573};\\\", \\\"{x:478,y:507,t:1526933470587};\\\", \\\"{x:467,y:510,t:1526933470603};\\\", \\\"{x:463,y:511,t:1526933470620};\\\", \\\"{x:462,y:511,t:1526933470637};\\\", \\\"{x:461,y:511,t:1526933470654};\\\", \\\"{x:460,y:513,t:1526933470671};\\\", \\\"{x:459,y:514,t:1526933470700};\\\", \\\"{x:459,y:515,t:1526933470724};\\\", \\\"{x:458,y:515,t:1526933470748};\\\", \\\"{x:457,y:515,t:1526933470756};\\\", \\\"{x:457,y:516,t:1526933470771};\\\", \\\"{x:455,y:517,t:1526933470787};\\\", \\\"{x:454,y:517,t:1526933470803};\\\", \\\"{x:451,y:517,t:1526933470820};\\\", \\\"{x:449,y:518,t:1526933470838};\\\", \\\"{x:448,y:518,t:1526933470853};\\\", \\\"{x:444,y:518,t:1526933470871};\\\", \\\"{x:441,y:519,t:1526933470887};\\\", \\\"{x:439,y:519,t:1526933470904};\\\", \\\"{x:437,y:519,t:1526933470921};\\\", \\\"{x:435,y:519,t:1526933470937};\\\", \\\"{x:431,y:519,t:1526933470954};\\\", \\\"{x:430,y:519,t:1526933470971};\\\", \\\"{x:425,y:519,t:1526933470986};\\\", \\\"{x:421,y:519,t:1526933471004};\\\", \\\"{x:420,y:519,t:1526933471021};\\\", \\\"{x:419,y:518,t:1526933471037};\\\", \\\"{x:418,y:518,t:1526933471054};\\\", \\\"{x:416,y:518,t:1526933471071};\\\", \\\"{x:415,y:518,t:1526933471087};\\\", \\\"{x:414,y:518,t:1526933471104};\\\", \\\"{x:413,y:518,t:1526933471121};\\\", \\\"{x:412,y:518,t:1526933471138};\\\", \\\"{x:411,y:518,t:1526933471154};\\\", \\\"{x:407,y:518,t:1526933471171};\\\", \\\"{x:404,y:518,t:1526933471187};\\\", \\\"{x:399,y:518,t:1526933471204};\\\", \\\"{x:397,y:518,t:1526933471221};\\\", \\\"{x:396,y:518,t:1526933471469};\\\", \\\"{x:396,y:519,t:1526933471484};\\\", \\\"{x:396,y:520,t:1526933471493};\\\", \\\"{x:396,y:522,t:1526933471504};\\\", \\\"{x:395,y:523,t:1526933471521};\\\", \\\"{x:394,y:527,t:1526933471539};\\\", \\\"{x:395,y:533,t:1526933471554};\\\", \\\"{x:397,y:535,t:1526933471571};\\\", \\\"{x:399,y:537,t:1526933471588};\\\", \\\"{x:400,y:541,t:1526933471605};\\\", \\\"{x:402,y:544,t:1526933471621};\\\", \\\"{x:404,y:549,t:1526933471637};\\\", \\\"{x:405,y:553,t:1526933471656};\\\", \\\"{x:409,y:559,t:1526933471671};\\\", \\\"{x:410,y:563,t:1526933471689};\\\", \\\"{x:412,y:566,t:1526933471705};\\\", \\\"{x:413,y:568,t:1526933471721};\\\", \\\"{x:414,y:570,t:1526933471738};\\\", \\\"{x:415,y:572,t:1526933471755};\\\", \\\"{x:416,y:572,t:1526933471771};\\\", \\\"{x:416,y:573,t:1526933471788};\\\", \\\"{x:418,y:574,t:1526933471806};\\\", \\\"{x:419,y:575,t:1526933471822};\\\", \\\"{x:422,y:576,t:1526933471837};\\\", \\\"{x:425,y:577,t:1526933471855};\\\", \\\"{x:429,y:578,t:1526933471872};\\\", \\\"{x:431,y:579,t:1526933471887};\\\", \\\"{x:439,y:582,t:1526933471905};\\\", \\\"{x:450,y:583,t:1526933471922};\\\", \\\"{x:459,y:583,t:1526933471938};\\\", \\\"{x:473,y:585,t:1526933471955};\\\", \\\"{x:495,y:589,t:1526933471971};\\\", \\\"{x:517,y:591,t:1526933471989};\\\", \\\"{x:556,y:593,t:1526933472005};\\\", \\\"{x:582,y:594,t:1526933472023};\\\", \\\"{x:609,y:594,t:1526933472038};\\\", \\\"{x:627,y:590,t:1526933472056};\\\", \\\"{x:640,y:585,t:1526933472072};\\\", \\\"{x:658,y:582,t:1526933472088};\\\", \\\"{x:670,y:579,t:1526933472105};\\\", \\\"{x:676,y:574,t:1526933472122};\\\", \\\"{x:679,y:571,t:1526933472138};\\\", \\\"{x:680,y:570,t:1526933472155};\\\", \\\"{x:681,y:567,t:1526933472172};\\\", \\\"{x:681,y:562,t:1526933472189};\\\", \\\"{x:681,y:554,t:1526933472205};\\\", \\\"{x:677,y:550,t:1526933472221};\\\", \\\"{x:671,y:546,t:1526933472238};\\\", \\\"{x:667,y:543,t:1526933472255};\\\", \\\"{x:663,y:539,t:1526933472272};\\\", \\\"{x:660,y:537,t:1526933472289};\\\", \\\"{x:656,y:533,t:1526933472305};\\\", \\\"{x:652,y:529,t:1526933472322};\\\", \\\"{x:649,y:526,t:1526933472339};\\\", \\\"{x:645,y:523,t:1526933472355};\\\", \\\"{x:643,y:522,t:1526933472372};\\\", \\\"{x:639,y:519,t:1526933472388};\\\", \\\"{x:636,y:518,t:1526933472405};\\\", \\\"{x:636,y:516,t:1526933472423};\\\", \\\"{x:634,y:514,t:1526933472439};\\\", \\\"{x:633,y:513,t:1526933472455};\\\", \\\"{x:631,y:511,t:1526933472472};\\\", \\\"{x:630,y:510,t:1526933472489};\\\", \\\"{x:629,y:509,t:1526933472505};\\\", \\\"{x:628,y:509,t:1526933472522};\\\", \\\"{x:627,y:507,t:1526933472539};\\\", \\\"{x:624,y:505,t:1526933472554};\\\", \\\"{x:616,y:501,t:1526933472572};\\\", \\\"{x:612,y:499,t:1526933472589};\\\", \\\"{x:610,y:499,t:1526933472605};\\\", \\\"{x:609,y:498,t:1526933472622};\\\", \\\"{x:614,y:499,t:1526933473020};\\\", \\\"{x:623,y:502,t:1526933473029};\\\", \\\"{x:628,y:507,t:1526933473039};\\\", \\\"{x:644,y:514,t:1526933473056};\\\", \\\"{x:662,y:520,t:1526933473072};\\\", \\\"{x:676,y:523,t:1526933473089};\\\", \\\"{x:696,y:527,t:1526933473107};\\\", \\\"{x:712,y:532,t:1526933473123};\\\", \\\"{x:724,y:533,t:1526933473139};\\\", \\\"{x:752,y:540,t:1526933473156};\\\", \\\"{x:767,y:542,t:1526933473172};\\\", \\\"{x:774,y:542,t:1526933473189};\\\", \\\"{x:777,y:543,t:1526933473206};\\\", \\\"{x:778,y:543,t:1526933473309};\\\", \\\"{x:780,y:543,t:1526933473349};\\\", \\\"{x:784,y:543,t:1526933473357};\\\", \\\"{x:790,y:543,t:1526933473372};\\\", \\\"{x:802,y:543,t:1526933473389};\\\", \\\"{x:818,y:546,t:1526933473407};\\\", \\\"{x:834,y:548,t:1526933473424};\\\", \\\"{x:848,y:552,t:1526933473440};\\\", \\\"{x:853,y:553,t:1526933473456};\\\", \\\"{x:858,y:555,t:1526933473471};\\\", \\\"{x:861,y:555,t:1526933473488};\\\", \\\"{x:862,y:555,t:1526933473829};\\\", \\\"{x:862,y:553,t:1526933474698};\\\", \\\"{x:862,y:552,t:1526933474706};\\\", \\\"{x:861,y:551,t:1526933474723};\\\", \\\"{x:860,y:551,t:1526933474772};\\\", \\\"{x:858,y:551,t:1526933474796};\\\", \\\"{x:854,y:548,t:1526933474806};\\\", \\\"{x:851,y:548,t:1526933474823};\\\", \\\"{x:845,y:545,t:1526933474840};\\\", \\\"{x:844,y:545,t:1526933474860};\\\", \\\"{x:843,y:545,t:1526933474874};\\\", \\\"{x:842,y:545,t:1526933474892};\\\", \\\"{x:840,y:544,t:1526933474989};\\\", \\\"{x:839,y:544,t:1526933475029};\\\", \\\"{x:838,y:543,t:1526933475125};\\\", \\\"{x:837,y:543,t:1526933475764};\\\", \\\"{x:836,y:543,t:1526933475780};\\\", \\\"{x:834,y:543,t:1526933475821};\\\", \\\"{x:833,y:543,t:1526933475828};\\\", \\\"{x:832,y:543,t:1526933475860};\\\", \\\"{x:830,y:543,t:1526933475876};\\\", \\\"{x:829,y:543,t:1526933475901};\\\", \\\"{x:828,y:543,t:1526933475908};\\\", \\\"{x:828,y:544,t:1526933475925};\\\", \\\"{x:826,y:545,t:1526933475941};\\\", \\\"{x:819,y:546,t:1526933475959};\\\", \\\"{x:808,y:549,t:1526933475975};\\\", \\\"{x:800,y:549,t:1526933475991};\\\", \\\"{x:794,y:552,t:1526933476009};\\\", \\\"{x:775,y:556,t:1526933476025};\\\", \\\"{x:753,y:566,t:1526933476043};\\\", \\\"{x:730,y:577,t:1526933476058};\\\", \\\"{x:706,y:589,t:1526933476076};\\\", \\\"{x:685,y:604,t:1526933476094};\\\", \\\"{x:679,y:606,t:1526933476108};\\\", \\\"{x:672,y:614,t:1526933476125};\\\", \\\"{x:663,y:621,t:1526933476141};\\\", \\\"{x:655,y:627,t:1526933476158};\\\", \\\"{x:648,y:633,t:1526933476176};\\\", \\\"{x:638,y:641,t:1526933476192};\\\", \\\"{x:631,y:646,t:1526933476208};\\\", \\\"{x:630,y:647,t:1526933476225};\\\", \\\"{x:628,y:648,t:1526933476242};\\\", \\\"{x:624,y:653,t:1526933476258};\\\", \\\"{x:618,y:658,t:1526933476275};\\\", \\\"{x:613,y:662,t:1526933476292};\\\", \\\"{x:606,y:666,t:1526933476308};\\\", \\\"{x:599,y:670,t:1526933476325};\\\", \\\"{x:595,y:673,t:1526933476342};\\\", \\\"{x:593,y:673,t:1526933476358};\\\", \\\"{x:590,y:675,t:1526933476375};\\\", \\\"{x:587,y:676,t:1526933476392};\\\", \\\"{x:585,y:676,t:1526933476408};\\\", \\\"{x:583,y:679,t:1526933476425};\\\", \\\"{x:581,y:680,t:1526933476441};\\\", \\\"{x:579,y:680,t:1526933476468};\\\", \\\"{x:578,y:681,t:1526933476475};\\\", \\\"{x:576,y:683,t:1526933476492};\\\", \\\"{x:575,y:684,t:1526933476508};\\\", \\\"{x:571,y:687,t:1526933476525};\\\", \\\"{x:565,y:692,t:1526933476542};\\\", \\\"{x:556,y:696,t:1526933476558};\\\", \\\"{x:551,y:705,t:1526933476575};\\\", \\\"{x:542,y:710,t:1526933476592};\\\", \\\"{x:532,y:719,t:1526933476608};\\\", \\\"{x:524,y:725,t:1526933476626};\\\", \\\"{x:512,y:731,t:1526933476642};\\\", \\\"{x:504,y:735,t:1526933476659};\\\", \\\"{x:498,y:739,t:1526933476675};\\\", \\\"{x:495,y:741,t:1526933476692};\\\", \\\"{x:493,y:741,t:1526933476716};\\\", \\\"{x:493,y:742,t:1526933476725};\\\" ] }, { \\\"rt\\\": 50769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 370027, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -M -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:741,t:1526933483013};\\\", \\\"{x:491,y:740,t:1526933483022};\\\", \\\"{x:491,y:737,t:1526933483043};\\\", \\\"{x:491,y:736,t:1526933483055};\\\", \\\"{x:491,y:734,t:1526933483071};\\\", \\\"{x:491,y:733,t:1526933483088};\\\", \\\"{x:491,y:730,t:1526933483104};\\\", \\\"{x:492,y:724,t:1526933483122};\\\", \\\"{x:495,y:715,t:1526933483138};\\\", \\\"{x:495,y:713,t:1526933483154};\\\", \\\"{x:495,y:710,t:1526933483163};\\\", \\\"{x:496,y:706,t:1526933483181};\\\", \\\"{x:497,y:703,t:1526933483197};\\\", \\\"{x:497,y:696,t:1526933483215};\\\", \\\"{x:498,y:692,t:1526933483231};\\\", \\\"{x:500,y:682,t:1526933483248};\\\", \\\"{x:501,y:679,t:1526933483264};\\\", \\\"{x:503,y:671,t:1526933483282};\\\", \\\"{x:505,y:668,t:1526933483297};\\\", \\\"{x:505,y:666,t:1526933483315};\\\", \\\"{x:506,y:665,t:1526933483332};\\\", \\\"{x:506,y:664,t:1526933483348};\\\", \\\"{x:506,y:663,t:1526933483365};\\\", \\\"{x:506,y:662,t:1526933483389};\\\", \\\"{x:506,y:661,t:1526933483413};\\\", \\\"{x:507,y:660,t:1526933483429};\\\", \\\"{x:507,y:659,t:1526933483436};\\\", \\\"{x:507,y:658,t:1526933483449};\\\", \\\"{x:511,y:646,t:1526933483465};\\\", \\\"{x:513,y:636,t:1526933483481};\\\", \\\"{x:515,y:631,t:1526933483499};\\\", \\\"{x:515,y:626,t:1526933483514};\\\", \\\"{x:517,y:621,t:1526933483531};\\\", \\\"{x:519,y:613,t:1526933483547};\\\", \\\"{x:520,y:608,t:1526933483564};\\\", \\\"{x:522,y:601,t:1526933483581};\\\", \\\"{x:523,y:593,t:1526933483599};\\\", \\\"{x:523,y:590,t:1526933483615};\\\", \\\"{x:524,y:585,t:1526933483631};\\\", \\\"{x:525,y:577,t:1526933483647};\\\", \\\"{x:527,y:572,t:1526933483665};\\\", \\\"{x:527,y:566,t:1526933483682};\\\", \\\"{x:527,y:564,t:1526933483698};\\\", \\\"{x:531,y:556,t:1526933483715};\\\", \\\"{x:531,y:553,t:1526933483732};\\\", \\\"{x:535,y:545,t:1526933483747};\\\", \\\"{x:538,y:542,t:1526933483764};\\\", \\\"{x:539,y:539,t:1526933483781};\\\", \\\"{x:539,y:531,t:1526933483799};\\\", \\\"{x:541,y:520,t:1526933483815};\\\", \\\"{x:541,y:516,t:1526933483832};\\\", \\\"{x:542,y:512,t:1526933483847};\\\", \\\"{x:543,y:509,t:1526933483864};\\\", \\\"{x:543,y:506,t:1526933483881};\\\", \\\"{x:543,y:503,t:1526933483897};\\\", \\\"{x:544,y:499,t:1526933483914};\\\", \\\"{x:544,y:497,t:1526933483931};\\\", \\\"{x:544,y:496,t:1526933483948};\\\", \\\"{x:544,y:494,t:1526933483964};\\\", \\\"{x:544,y:492,t:1526933483981};\\\", \\\"{x:544,y:490,t:1526933483997};\\\", \\\"{x:543,y:489,t:1526933484477};\\\", \\\"{x:541,y:489,t:1526933484485};\\\", \\\"{x:540,y:489,t:1526933484497};\\\", \\\"{x:538,y:489,t:1526933484514};\\\", \\\"{x:535,y:486,t:1526933484532};\\\", \\\"{x:532,y:486,t:1526933484547};\\\", \\\"{x:527,y:486,t:1526933484566};\\\", \\\"{x:522,y:485,t:1526933484583};\\\", \\\"{x:520,y:483,t:1526933484598};\\\", \\\"{x:516,y:482,t:1526933484616};\\\", \\\"{x:513,y:482,t:1526933484632};\\\", \\\"{x:510,y:480,t:1526933484650};\\\", \\\"{x:504,y:479,t:1526933484666};\\\", \\\"{x:498,y:477,t:1526933484683};\\\", \\\"{x:492,y:475,t:1526933484700};\\\", \\\"{x:489,y:474,t:1526933484716};\\\", \\\"{x:486,y:473,t:1526933484733};\\\", \\\"{x:483,y:471,t:1526933484750};\\\", \\\"{x:479,y:470,t:1526933484767};\\\", \\\"{x:474,y:469,t:1526933484784};\\\", \\\"{x:473,y:468,t:1526933484799};\\\", \\\"{x:471,y:468,t:1526933484817};\\\", \\\"{x:470,y:465,t:1526933484833};\\\", \\\"{x:470,y:461,t:1526933484850};\\\", \\\"{x:470,y:451,t:1526933484867};\\\", \\\"{x:470,y:442,t:1526933484883};\\\", \\\"{x:470,y:426,t:1526933484900};\\\", \\\"{x:467,y:394,t:1526933484917};\\\", \\\"{x:465,y:376,t:1526933484933};\\\", \\\"{x:465,y:362,t:1526933484950};\\\", \\\"{x:465,y:353,t:1526933484967};\\\", \\\"{x:465,y:345,t:1526933484983};\\\", \\\"{x:467,y:340,t:1526933485000};\\\", \\\"{x:468,y:332,t:1526933485017};\\\", \\\"{x:471,y:323,t:1526933485034};\\\", \\\"{x:473,y:319,t:1526933485051};\\\", \\\"{x:476,y:315,t:1526933485067};\\\", \\\"{x:478,y:309,t:1526933485084};\\\", \\\"{x:483,y:304,t:1526933485100};\\\", \\\"{x:483,y:303,t:1526933485116};\\\", \\\"{x:485,y:303,t:1526933485134};\\\", \\\"{x:487,y:301,t:1526933485151};\\\", \\\"{x:488,y:300,t:1526933485173};\\\", \\\"{x:490,y:298,t:1526933485204};\\\", \\\"{x:491,y:298,t:1526933485270};\\\", \\\"{x:492,y:297,t:1526933485300};\\\", \\\"{x:493,y:297,t:1526933495117};\\\", \\\"{x:494,y:297,t:1526933495127};\\\", \\\"{x:501,y:295,t:1526933495142};\\\", \\\"{x:516,y:292,t:1526933495159};\\\", \\\"{x:540,y:292,t:1526933495176};\\\", \\\"{x:562,y:292,t:1526933495193};\\\", \\\"{x:581,y:292,t:1526933495209};\\\", \\\"{x:603,y:294,t:1526933495226};\\\", \\\"{x:631,y:301,t:1526933495244};\\\", \\\"{x:663,y:307,t:1526933495260};\\\", \\\"{x:706,y:325,t:1526933495277};\\\", \\\"{x:742,y:332,t:1526933495292};\\\", \\\"{x:790,y:347,t:1526933495309};\\\", \\\"{x:838,y:361,t:1526933495326};\\\", \\\"{x:879,y:371,t:1526933495343};\\\", \\\"{x:905,y:380,t:1526933495361};\\\", \\\"{x:935,y:389,t:1526933495377};\\\", \\\"{x:965,y:396,t:1526933495393};\\\", \\\"{x:979,y:401,t:1526933495410};\\\", \\\"{x:993,y:405,t:1526933495427};\\\", \\\"{x:1002,y:409,t:1526933495444};\\\", \\\"{x:1015,y:412,t:1526933495461};\\\", \\\"{x:1027,y:413,t:1526933495477};\\\", \\\"{x:1034,y:416,t:1526933495493};\\\", \\\"{x:1045,y:418,t:1526933495510};\\\", \\\"{x:1057,y:421,t:1526933495528};\\\", \\\"{x:1066,y:422,t:1526933495544};\\\", \\\"{x:1074,y:423,t:1526933495560};\\\", \\\"{x:1087,y:426,t:1526933495577};\\\", \\\"{x:1100,y:428,t:1526933495593};\\\", \\\"{x:1118,y:431,t:1526933495610};\\\", \\\"{x:1140,y:434,t:1526933495627};\\\", \\\"{x:1168,y:439,t:1526933495644};\\\", \\\"{x:1181,y:440,t:1526933495660};\\\", \\\"{x:1200,y:444,t:1526933495677};\\\", \\\"{x:1217,y:446,t:1526933495694};\\\", \\\"{x:1235,y:447,t:1526933495710};\\\", \\\"{x:1249,y:447,t:1526933495727};\\\", \\\"{x:1261,y:447,t:1526933495744};\\\", \\\"{x:1280,y:447,t:1526933495761};\\\", \\\"{x:1293,y:447,t:1526933495777};\\\", \\\"{x:1302,y:447,t:1526933495794};\\\", \\\"{x:1311,y:447,t:1526933495811};\\\", \\\"{x:1320,y:447,t:1526933495827};\\\", \\\"{x:1324,y:447,t:1526933495844};\\\", \\\"{x:1329,y:447,t:1526933495861};\\\", \\\"{x:1331,y:446,t:1526933495877};\\\", \\\"{x:1333,y:445,t:1526933495908};\\\", \\\"{x:1334,y:444,t:1526933495925};\\\", \\\"{x:1336,y:443,t:1526933495940};\\\", \\\"{x:1339,y:440,t:1526933495948};\\\", \\\"{x:1346,y:435,t:1526933495962};\\\", \\\"{x:1351,y:431,t:1526933495978};\\\", \\\"{x:1357,y:426,t:1526933495994};\\\", \\\"{x:1367,y:412,t:1526933496011};\\\", \\\"{x:1370,y:407,t:1526933496028};\\\", \\\"{x:1372,y:407,t:1526933496044};\\\", \\\"{x:1377,y:402,t:1526933496061};\\\", \\\"{x:1383,y:391,t:1526933496078};\\\", \\\"{x:1388,y:379,t:1526933496096};\\\", \\\"{x:1389,y:371,t:1526933496111};\\\", \\\"{x:1391,y:361,t:1526933496128};\\\", \\\"{x:1395,y:355,t:1526933496145};\\\", \\\"{x:1395,y:349,t:1526933496163};\\\", \\\"{x:1395,y:345,t:1526933496178};\\\", \\\"{x:1396,y:336,t:1526933496196};\\\", \\\"{x:1400,y:326,t:1526933496213};\\\", \\\"{x:1402,y:321,t:1526933496229};\\\", \\\"{x:1402,y:319,t:1526933496246};\\\", \\\"{x:1405,y:312,t:1526933496263};\\\", \\\"{x:1407,y:308,t:1526933496279};\\\", \\\"{x:1409,y:305,t:1526933496296};\\\", \\\"{x:1412,y:302,t:1526933496317};\\\", \\\"{x:1413,y:299,t:1526933496330};\\\", \\\"{x:1415,y:297,t:1526933496345};\\\", \\\"{x:1416,y:296,t:1526933496363};\\\", \\\"{x:1420,y:292,t:1526933496380};\\\", \\\"{x:1421,y:290,t:1526933496395};\\\", \\\"{x:1424,y:286,t:1526933496413};\\\", \\\"{x:1426,y:284,t:1526933496430};\\\", \\\"{x:1426,y:283,t:1526933496446};\\\", \\\"{x:1427,y:282,t:1526933496462};\\\", \\\"{x:1430,y:280,t:1526933496533};\\\", \\\"{x:1430,y:283,t:1526933496677};\\\", \\\"{x:1430,y:289,t:1526933496685};\\\", \\\"{x:1430,y:293,t:1526933496696};\\\", \\\"{x:1430,y:308,t:1526933496713};\\\", \\\"{x:1422,y:330,t:1526933496731};\\\", \\\"{x:1416,y:351,t:1526933496747};\\\", \\\"{x:1410,y:374,t:1526933496764};\\\", \\\"{x:1400,y:407,t:1526933496780};\\\", \\\"{x:1396,y:430,t:1526933496796};\\\", \\\"{x:1390,y:449,t:1526933496814};\\\", \\\"{x:1387,y:467,t:1526933496831};\\\", \\\"{x:1382,y:484,t:1526933496848};\\\", \\\"{x:1376,y:497,t:1526933496863};\\\", \\\"{x:1370,y:509,t:1526933496880};\\\", \\\"{x:1364,y:522,t:1526933496898};\\\", \\\"{x:1360,y:534,t:1526933496913};\\\", \\\"{x:1352,y:549,t:1526933496931};\\\", \\\"{x:1347,y:565,t:1526933496948};\\\", \\\"{x:1336,y:589,t:1526933496965};\\\", \\\"{x:1324,y:612,t:1526933496981};\\\", \\\"{x:1314,y:633,t:1526933496997};\\\", \\\"{x:1307,y:654,t:1526933497014};\\\", \\\"{x:1296,y:672,t:1526933497031};\\\", \\\"{x:1287,y:688,t:1526933497047};\\\", \\\"{x:1279,y:709,t:1526933497065};\\\", \\\"{x:1268,y:732,t:1526933497081};\\\", \\\"{x:1259,y:746,t:1526933497097};\\\", \\\"{x:1247,y:765,t:1526933497115};\\\", \\\"{x:1236,y:785,t:1526933497132};\\\", \\\"{x:1225,y:806,t:1526933497148};\\\", \\\"{x:1214,y:839,t:1526933497165};\\\", \\\"{x:1203,y:863,t:1526933497181};\\\", \\\"{x:1196,y:879,t:1526933497198};\\\", \\\"{x:1188,y:890,t:1526933497215};\\\", \\\"{x:1185,y:900,t:1526933497232};\\\", \\\"{x:1182,y:908,t:1526933497249};\\\", \\\"{x:1180,y:916,t:1526933497265};\\\", \\\"{x:1178,y:922,t:1526933497282};\\\", \\\"{x:1177,y:926,t:1526933497299};\\\", \\\"{x:1176,y:928,t:1526933497315};\\\", \\\"{x:1175,y:929,t:1526933497333};\\\", \\\"{x:1175,y:930,t:1526933497349};\\\", \\\"{x:1175,y:931,t:1526933497373};\\\", \\\"{x:1175,y:932,t:1526933497381};\\\", \\\"{x:1175,y:933,t:1526933497398};\\\", \\\"{x:1175,y:934,t:1526933497416};\\\", \\\"{x:1174,y:935,t:1526933498229};\\\", \\\"{x:1173,y:935,t:1526933498236};\\\", \\\"{x:1168,y:935,t:1526933498252};\\\", \\\"{x:1163,y:935,t:1526933498267};\\\", \\\"{x:1148,y:935,t:1526933498283};\\\", \\\"{x:1130,y:935,t:1526933498300};\\\", \\\"{x:1124,y:934,t:1526933498317};\\\", \\\"{x:1122,y:933,t:1526933498334};\\\", \\\"{x:1121,y:933,t:1526933498350};\\\", \\\"{x:1119,y:933,t:1526933499454};\\\", \\\"{x:1119,y:932,t:1526933499549};\\\", \\\"{x:1120,y:930,t:1526933499557};\\\", \\\"{x:1121,y:929,t:1526933499571};\\\", \\\"{x:1126,y:928,t:1526933499588};\\\", \\\"{x:1132,y:926,t:1526933499604};\\\", \\\"{x:1147,y:925,t:1526933499620};\\\", \\\"{x:1166,y:925,t:1526933499638};\\\", \\\"{x:1192,y:925,t:1526933499655};\\\", \\\"{x:1222,y:925,t:1526933499670};\\\", \\\"{x:1249,y:925,t:1526933499687};\\\", \\\"{x:1277,y:924,t:1526933499704};\\\", \\\"{x:1303,y:924,t:1526933499721};\\\", \\\"{x:1323,y:924,t:1526933499737};\\\", \\\"{x:1339,y:924,t:1526933499754};\\\", \\\"{x:1352,y:924,t:1526933499772};\\\", \\\"{x:1361,y:924,t:1526933499788};\\\", \\\"{x:1368,y:924,t:1526933499804};\\\", \\\"{x:1375,y:922,t:1526933499821};\\\", \\\"{x:1380,y:920,t:1526933499837};\\\", \\\"{x:1381,y:920,t:1526933499854};\\\", \\\"{x:1382,y:919,t:1526933499876};\\\", \\\"{x:1382,y:918,t:1526933499908};\\\", \\\"{x:1381,y:916,t:1526933499924};\\\", \\\"{x:1377,y:915,t:1526933499938};\\\", \\\"{x:1366,y:908,t:1526933499955};\\\", \\\"{x:1350,y:898,t:1526933499972};\\\", \\\"{x:1332,y:891,t:1526933499988};\\\", \\\"{x:1330,y:891,t:1526933500004};\\\", \\\"{x:1330,y:890,t:1526933500028};\\\", \\\"{x:1330,y:889,t:1526933500044};\\\", \\\"{x:1330,y:887,t:1526933500070};\\\", \\\"{x:1331,y:886,t:1526933500077};\\\", \\\"{x:1333,y:886,t:1526933500088};\\\", \\\"{x:1335,y:885,t:1526933500105};\\\", \\\"{x:1339,y:883,t:1526933500122};\\\", \\\"{x:1345,y:883,t:1526933500139};\\\", \\\"{x:1350,y:883,t:1526933500155};\\\", \\\"{x:1356,y:883,t:1526933500172};\\\", \\\"{x:1360,y:883,t:1526933500188};\\\", \\\"{x:1363,y:883,t:1526933500205};\\\", \\\"{x:1366,y:883,t:1526933500222};\\\", \\\"{x:1370,y:883,t:1526933500239};\\\", \\\"{x:1373,y:884,t:1526933500256};\\\", \\\"{x:1375,y:884,t:1526933500273};\\\", \\\"{x:1376,y:884,t:1526933500289};\\\", \\\"{x:1378,y:885,t:1526933500308};\\\", \\\"{x:1379,y:886,t:1526933500349};\\\", \\\"{x:1379,y:887,t:1526933500356};\\\", \\\"{x:1380,y:887,t:1526933500373};\\\", \\\"{x:1382,y:887,t:1526933500420};\\\", \\\"{x:1382,y:888,t:1526933500428};\\\", \\\"{x:1382,y:889,t:1526933500485};\\\", \\\"{x:1382,y:890,t:1526933500493};\\\", \\\"{x:1383,y:890,t:1526933500507};\\\", \\\"{x:1383,y:891,t:1526933500525};\\\", \\\"{x:1384,y:892,t:1526933500543};\\\", \\\"{x:1384,y:893,t:1526933500603};\\\", \\\"{x:1384,y:894,t:1526933500973};\\\", \\\"{x:1384,y:895,t:1526933501061};\\\", \\\"{x:1383,y:895,t:1526933507781};\\\", \\\"{x:1382,y:895,t:1526933507796};\\\", \\\"{x:1382,y:894,t:1526933507808};\\\", \\\"{x:1380,y:893,t:1526933507829};\\\", \\\"{x:1380,y:892,t:1526933507842};\\\", \\\"{x:1380,y:891,t:1526933507859};\\\", \\\"{x:1379,y:889,t:1526933507874};\\\", \\\"{x:1379,y:888,t:1526933507891};\\\", \\\"{x:1379,y:887,t:1526933507908};\\\", \\\"{x:1379,y:885,t:1526933507925};\\\", \\\"{x:1379,y:884,t:1526933507941};\\\", \\\"{x:1377,y:882,t:1526933507958};\\\", \\\"{x:1377,y:880,t:1526933507975};\\\", \\\"{x:1377,y:879,t:1526933508020};\\\", \\\"{x:1377,y:877,t:1526933509564};\\\", \\\"{x:1377,y:876,t:1526933509580};\\\", \\\"{x:1377,y:874,t:1526933509595};\\\", \\\"{x:1377,y:873,t:1526933509619};\\\", \\\"{x:1378,y:871,t:1526933509644};\\\", \\\"{x:1378,y:870,t:1526933509669};\\\", \\\"{x:1378,y:869,t:1526933509684};\\\", \\\"{x:1378,y:868,t:1526933509695};\\\", \\\"{x:1378,y:867,t:1526933509724};\\\", \\\"{x:1378,y:866,t:1526933509740};\\\", \\\"{x:1378,y:865,t:1526933509772};\\\", \\\"{x:1378,y:863,t:1526933510429};\\\", \\\"{x:1378,y:862,t:1526933510436};\\\", \\\"{x:1378,y:861,t:1526933510452};\\\", \\\"{x:1378,y:860,t:1526933510468};\\\", \\\"{x:1378,y:859,t:1526933510480};\\\", \\\"{x:1378,y:858,t:1526933510498};\\\", \\\"{x:1378,y:857,t:1526933510524};\\\", \\\"{x:1377,y:857,t:1526933512517};\\\", \\\"{x:1375,y:857,t:1526933512532};\\\", \\\"{x:1374,y:857,t:1526933512556};\\\", \\\"{x:1371,y:857,t:1526933512571};\\\", \\\"{x:1365,y:857,t:1526933512588};\\\", \\\"{x:1358,y:857,t:1526933512604};\\\", \\\"{x:1351,y:857,t:1526933512621};\\\", \\\"{x:1347,y:857,t:1526933512637};\\\", \\\"{x:1347,y:856,t:1526933512654};\\\", \\\"{x:1346,y:855,t:1526933512670};\\\", \\\"{x:1344,y:854,t:1526933512687};\\\", \\\"{x:1344,y:852,t:1526933512704};\\\", \\\"{x:1342,y:850,t:1526933512720};\\\", \\\"{x:1342,y:849,t:1526933512741};\\\", \\\"{x:1342,y:848,t:1526933512765};\\\", \\\"{x:1341,y:846,t:1526933512773};\\\", \\\"{x:1341,y:845,t:1526933512789};\\\", \\\"{x:1341,y:840,t:1526933512804};\\\", \\\"{x:1341,y:832,t:1526933512821};\\\", \\\"{x:1341,y:822,t:1526933512837};\\\", \\\"{x:1339,y:807,t:1526933512854};\\\", \\\"{x:1336,y:791,t:1526933512872};\\\", \\\"{x:1336,y:787,t:1526933512888};\\\", \\\"{x:1336,y:784,t:1526933512904};\\\", \\\"{x:1336,y:780,t:1526933512921};\\\", \\\"{x:1337,y:776,t:1526933512939};\\\", \\\"{x:1337,y:772,t:1526933512954};\\\", \\\"{x:1338,y:767,t:1526933512971};\\\", \\\"{x:1340,y:757,t:1526933512988};\\\", \\\"{x:1342,y:751,t:1526933513004};\\\", \\\"{x:1342,y:745,t:1526933513021};\\\", \\\"{x:1345,y:741,t:1526933513038};\\\", \\\"{x:1345,y:738,t:1526933513055};\\\", \\\"{x:1345,y:737,t:1526933513071};\\\", \\\"{x:1346,y:734,t:1526933513087};\\\", \\\"{x:1346,y:733,t:1526933513104};\\\", \\\"{x:1346,y:732,t:1526933513121};\\\", \\\"{x:1347,y:730,t:1526933513138};\\\", \\\"{x:1348,y:728,t:1526933513156};\\\", \\\"{x:1349,y:727,t:1526933513197};\\\", \\\"{x:1349,y:726,t:1526933513213};\\\", \\\"{x:1349,y:725,t:1526933513222};\\\", \\\"{x:1349,y:723,t:1526933513238};\\\", \\\"{x:1349,y:722,t:1526933513260};\\\", \\\"{x:1351,y:719,t:1526933513277};\\\", \\\"{x:1351,y:717,t:1526933513289};\\\", \\\"{x:1352,y:714,t:1526933513305};\\\", \\\"{x:1352,y:711,t:1526933513323};\\\", \\\"{x:1353,y:709,t:1526933513339};\\\", \\\"{x:1353,y:707,t:1526933513355};\\\", \\\"{x:1353,y:701,t:1526933513372};\\\", \\\"{x:1353,y:700,t:1526933513388};\\\", \\\"{x:1354,y:698,t:1526933513405};\\\", \\\"{x:1355,y:694,t:1526933513422};\\\", \\\"{x:1356,y:690,t:1526933513439};\\\", \\\"{x:1357,y:683,t:1526933513456};\\\", \\\"{x:1359,y:679,t:1526933513472};\\\", \\\"{x:1359,y:677,t:1526933513490};\\\", \\\"{x:1359,y:676,t:1526933513507};\\\", \\\"{x:1359,y:675,t:1526933513532};\\\", \\\"{x:1358,y:675,t:1526933513686};\\\", \\\"{x:1357,y:675,t:1526933513693};\\\", \\\"{x:1355,y:676,t:1526933513706};\\\", \\\"{x:1353,y:677,t:1526933513724};\\\", \\\"{x:1350,y:679,t:1526933513740};\\\", \\\"{x:1349,y:681,t:1526933513757};\\\", \\\"{x:1349,y:682,t:1526933513780};\\\", \\\"{x:1348,y:683,t:1526933513804};\\\", \\\"{x:1348,y:684,t:1526933513820};\\\", \\\"{x:1348,y:685,t:1526933513843};\\\", \\\"{x:1347,y:686,t:1526933513875};\\\", \\\"{x:1346,y:687,t:1526933513915};\\\", \\\"{x:1345,y:688,t:1526933514132};\\\", \\\"{x:1345,y:690,t:1526933514147};\\\", \\\"{x:1345,y:691,t:1526933514211};\\\", \\\"{x:1345,y:693,t:1526933519388};\\\", \\\"{x:1343,y:694,t:1526933519404};\\\", \\\"{x:1342,y:696,t:1526933519419};\\\", \\\"{x:1342,y:697,t:1526933519443};\\\", \\\"{x:1342,y:698,t:1526933519459};\\\", \\\"{x:1342,y:700,t:1526933519483};\\\", \\\"{x:1342,y:701,t:1526933519491};\\\", \\\"{x:1342,y:703,t:1526933519503};\\\", \\\"{x:1342,y:705,t:1526933519521};\\\", \\\"{x:1343,y:708,t:1526933519536};\\\", \\\"{x:1344,y:710,t:1526933519554};\\\", \\\"{x:1346,y:711,t:1526933519571};\\\", \\\"{x:1346,y:714,t:1526933519588};\\\", \\\"{x:1348,y:716,t:1526933519604};\\\", \\\"{x:1349,y:718,t:1526933519621};\\\", \\\"{x:1349,y:720,t:1526933519638};\\\", \\\"{x:1351,y:723,t:1526933519654};\\\", \\\"{x:1351,y:725,t:1526933519671};\\\", \\\"{x:1351,y:727,t:1526933519688};\\\", \\\"{x:1351,y:730,t:1526933519704};\\\", \\\"{x:1351,y:732,t:1526933519721};\\\", \\\"{x:1352,y:736,t:1526933519738};\\\", \\\"{x:1353,y:738,t:1526933519755};\\\", \\\"{x:1353,y:740,t:1526933519771};\\\", \\\"{x:1353,y:742,t:1526933519788};\\\", \\\"{x:1354,y:745,t:1526933519805};\\\", \\\"{x:1355,y:748,t:1526933519827};\\\", \\\"{x:1355,y:751,t:1526933519844};\\\", \\\"{x:1355,y:752,t:1526933519855};\\\", \\\"{x:1355,y:754,t:1526933519872};\\\", \\\"{x:1355,y:758,t:1526933519888};\\\", \\\"{x:1355,y:761,t:1526933519904};\\\", \\\"{x:1354,y:763,t:1526933519922};\\\", \\\"{x:1352,y:766,t:1526933519938};\\\", \\\"{x:1349,y:772,t:1526933519955};\\\", \\\"{x:1347,y:777,t:1526933519971};\\\", \\\"{x:1340,y:785,t:1526933519988};\\\", \\\"{x:1333,y:791,t:1526933520005};\\\", \\\"{x:1330,y:794,t:1526933520022};\\\", \\\"{x:1330,y:795,t:1526933520039};\\\", \\\"{x:1329,y:796,t:1526933520055};\\\", \\\"{x:1323,y:799,t:1526933520072};\\\", \\\"{x:1315,y:800,t:1526933520088};\\\", \\\"{x:1299,y:803,t:1526933520105};\\\", \\\"{x:1279,y:803,t:1526933520121};\\\", \\\"{x:1264,y:803,t:1526933520058};\\\", \\\"{x:1196,y:799,t:1526933520075};\\\", \\\"{x:1140,y:789,t:1526933520091};\\\", \\\"{x:1069,y:765,t:1526933520108};\\\", \\\"{x:1001,y:739,t:1526933520126};\\\", \\\"{x:916,y:709,t:1526933520141};\\\", \\\"{x:834,y:674,t:1526933520158};\\\", \\\"{x:780,y:647,t:1526933520176};\\\", \\\"{x:742,y:632,t:1526933520192};\\\", \\\"{x:728,y:622,t:1526933520209};\\\", \\\"{x:712,y:615,t:1526933520225};\\\", \\\"{x:700,y:607,t:1526933520247};\\\", \\\"{x:695,y:603,t:1526933520264};\\\", \\\"{x:690,y:602,t:1526933520281};\\\", \\\"{x:684,y:600,t:1526933520298};\\\", \\\"{x:672,y:598,t:1526933520314};\\\", \\\"{x:654,y:594,t:1526933520331};\\\", \\\"{x:650,y:591,t:1526933520348};\\\", \\\"{x:641,y:588,t:1526933520365};\\\", \\\"{x:631,y:582,t:1526933520381};\\\", \\\"{x:624,y:576,t:1526933520398};\\\", \\\"{x:616,y:570,t:1526933520415};\\\", \\\"{x:613,y:566,t:1526933520432};\\\", \\\"{x:609,y:553,t:1526933520447};\\\", \\\"{x:608,y:550,t:1526933520465};\\\", \\\"{x:606,y:545,t:1526933520481};\\\", \\\"{x:605,y:542,t:1526933520497};\\\", \\\"{x:605,y:536,t:1526933520514};\\\", \\\"{x:603,y:527,t:1526933520531};\\\", \\\"{x:602,y:524,t:1526933520548};\\\", \\\"{x:602,y:522,t:1526933520564};\\\", \\\"{x:600,y:519,t:1526933520581};\\\", \\\"{x:596,y:517,t:1526933520598};\\\", \\\"{x:589,y:513,t:1526933520614};\\\", \\\"{x:568,y:506,t:1526933520631};\\\", \\\"{x:533,y:504,t:1526933520647};\\\", \\\"{x:506,y:498,t:1526933520664};\\\", \\\"{x:495,y:494,t:1526933520682};\\\", \\\"{x:490,y:494,t:1526933520697};\\\", \\\"{x:493,y:496,t:1526933520746};\\\", \\\"{x:497,y:497,t:1526933520754};\\\", \\\"{x:504,y:504,t:1526933520765};\\\", \\\"{x:568,y:512,t:1526933520781};\\\", \\\"{x:643,y:523,t:1526933520799};\\\", \\\"{x:740,y:533,t:1526933520814};\\\", \\\"{x:823,y:544,t:1526933520831};\\\", \\\"{x:895,y:553,t:1526933520848};\\\", \\\"{x:933,y:560,t:1526933520865};\\\", \\\"{x:956,y:563,t:1526933520882};\\\", \\\"{x:970,y:565,t:1526933520898};\\\", \\\"{x:971,y:565,t:1526933520979};\\\", \\\"{x:970,y:562,t:1526933520986};\\\", \\\"{x:965,y:562,t:1526933520998};\\\", \\\"{x:949,y:554,t:1526933521016};\\\", \\\"{x:921,y:550,t:1526933521032};\\\", \\\"{x:897,y:544,t:1526933521048};\\\", \\\"{x:877,y:542,t:1526933521064};\\\", \\\"{x:861,y:535,t:1526933521081};\\\", \\\"{x:851,y:531,t:1526933521098};\\\", \\\"{x:845,y:528,t:1526933521114};\\\", \\\"{x:844,y:527,t:1526933521131};\\\", \\\"{x:843,y:527,t:1526933521283};\\\", \\\"{x:843,y:526,t:1526933521298};\\\", \\\"{x:843,y:525,t:1526933521314};\\\", \\\"{x:843,y:523,t:1526933521332};\\\", \\\"{x:841,y:521,t:1526933521348};\\\", \\\"{x:840,y:519,t:1526933521365};\\\", \\\"{x:840,y:518,t:1526933521381};\\\", \\\"{x:839,y:516,t:1526933521399};\\\", \\\"{x:838,y:515,t:1526933521416};\\\", \\\"{x:837,y:514,t:1526933521432};\\\", \\\"{x:836,y:514,t:1526933521467};\\\", \\\"{x:835,y:513,t:1526933521483};\\\", \\\"{x:835,y:512,t:1526933521522};\\\", \\\"{x:835,y:511,t:1526933521547};\\\", \\\"{x:835,y:510,t:1526933521618};\\\", \\\"{x:835,y:510,t:1526933524236};\\\", \\\"{x:834,y:509,t:1526933525803};\\\", \\\"{x:831,y:510,t:1526933525818};\\\", \\\"{x:825,y:513,t:1526933525836};\\\", \\\"{x:819,y:516,t:1526933525852};\\\", \\\"{x:809,y:521,t:1526933525868};\\\", \\\"{x:789,y:526,t:1526933525886};\\\", \\\"{x:769,y:529,t:1526933525902};\\\", \\\"{x:734,y:536,t:1526933525918};\\\", \\\"{x:689,y:536,t:1526933525936};\\\", \\\"{x:607,y:531,t:1526933525953};\\\", \\\"{x:511,y:522,t:1526933525969};\\\", \\\"{x:509,y:522,t:1526933525985};\\\", \\\"{x:501,y:518,t:1526933526003};\\\", \\\"{x:499,y:518,t:1526933526715};\\\", \\\"{x:498,y:518,t:1526933526723};\\\", \\\"{x:497,y:518,t:1526933526738};\\\", \\\"{x:492,y:518,t:1526933527027};\\\", \\\"{x:489,y:518,t:1526933527037};\\\", \\\"{x:481,y:518,t:1526933527054};\\\", \\\"{x:473,y:519,t:1526933527070};\\\", \\\"{x:451,y:521,t:1526933527086};\\\", \\\"{x:412,y:522,t:1526933527103};\\\", \\\"{x:385,y:527,t:1526933527121};\\\", \\\"{x:369,y:532,t:1526933527137};\\\", \\\"{x:361,y:533,t:1526933527153};\\\", \\\"{x:358,y:536,t:1526933527169};\\\", \\\"{x:343,y:541,t:1526933527187};\\\", \\\"{x:333,y:545,t:1526933527203};\\\", \\\"{x:329,y:545,t:1526933527547};\\\", \\\"{x:312,y:541,t:1526933527554};\\\", \\\"{x:310,y:536,t:1526933527569};\\\", \\\"{x:256,y:519,t:1526933527587};\\\", \\\"{x:244,y:515,t:1526933527603};\\\", \\\"{x:231,y:515,t:1526933527621};\\\", \\\"{x:224,y:514,t:1526933527637};\\\", \\\"{x:220,y:515,t:1526933527653};\\\", \\\"{x:215,y:515,t:1526933527670};\\\", \\\"{x:200,y:515,t:1526933527686};\\\", \\\"{x:173,y:515,t:1526933527703};\\\", \\\"{x:136,y:514,t:1526933527721};\\\", \\\"{x:102,y:508,t:1526933527736};\\\", \\\"{x:93,y:505,t:1526933527753};\\\", \\\"{x:81,y:505,t:1526933527770};\\\", \\\"{x:80,y:505,t:1526933527786};\\\", \\\"{x:77,y:505,t:1526933527804};\\\", \\\"{x:76,y:506,t:1526933527820};\\\", \\\"{x:74,y:510,t:1526933527837};\\\", \\\"{x:73,y:513,t:1526933527853};\\\", \\\"{x:72,y:515,t:1526933527870};\\\", \\\"{x:72,y:517,t:1526933527887};\\\", \\\"{x:72,y:519,t:1526933527903};\\\", \\\"{x:72,y:520,t:1526933527921};\\\", \\\"{x:72,y:521,t:1526933527938};\\\", \\\"{x:73,y:523,t:1526933527953};\\\", \\\"{x:77,y:525,t:1526933527971};\\\", \\\"{x:82,y:527,t:1526933527988};\\\", \\\"{x:89,y:530,t:1526933528004};\\\", \\\"{x:100,y:531,t:1526933528020};\\\", \\\"{x:110,y:532,t:1526933528037};\\\", \\\"{x:115,y:535,t:1526933528054};\\\", \\\"{x:117,y:535,t:1526933528071};\\\", \\\"{x:122,y:536,t:1526933528087};\\\", \\\"{x:125,y:538,t:1526933528103};\\\", \\\"{x:127,y:538,t:1526933528121};\\\", \\\"{x:129,y:538,t:1526933528139};\\\", \\\"{x:130,y:538,t:1526933528698};\\\", \\\"{x:134,y:540,t:1526933528706};\\\", \\\"{x:137,y:540,t:1526933528722};\\\", \\\"{x:151,y:541,t:1526933528737};\\\", \\\"{x:171,y:546,t:1526933528754};\\\", \\\"{x:190,y:553,t:1526933528771};\\\", \\\"{x:202,y:558,t:1526933528788};\\\", \\\"{x:226,y:566,t:1526933528805};\\\", \\\"{x:236,y:569,t:1526933528822};\\\", \\\"{x:242,y:570,t:1526933528837};\\\", \\\"{x:236,y:570,t:1526933528930};\\\", \\\"{x:225,y:566,t:1526933528938};\\\", \\\"{x:200,y:559,t:1526933528955};\\\", \\\"{x:153,y:547,t:1526933528972};\\\", \\\"{x:116,y:534,t:1526933528988};\\\", \\\"{x:98,y:531,t:1526933529004};\\\", \\\"{x:87,y:528,t:1526933529021};\\\", \\\"{x:85,y:526,t:1526933529038};\\\", \\\"{x:87,y:526,t:1526933529099};\\\", \\\"{x:90,y:526,t:1526933529106};\\\", \\\"{x:93,y:526,t:1526933529122};\\\", \\\"{x:98,y:529,t:1526933529137};\\\", \\\"{x:105,y:530,t:1526933529155};\\\", \\\"{x:115,y:534,t:1526933529172};\\\", \\\"{x:126,y:538,t:1526933529187};\\\", \\\"{x:135,y:540,t:1526933529205};\\\", \\\"{x:142,y:542,t:1526933529222};\\\", \\\"{x:144,y:543,t:1526933529239};\\\", \\\"{x:145,y:544,t:1526933529254};\\\", \\\"{x:147,y:544,t:1526933529323};\\\", \\\"{x:148,y:544,t:1526933529339};\\\", \\\"{x:149,y:544,t:1526933529363};\\\", \\\"{x:150,y:543,t:1526933529387};\\\", \\\"{x:151,y:543,t:1526933529418};\\\", \\\"{x:165,y:544,t:1526933529931};\\\", \\\"{x:175,y:550,t:1526933529938};\\\", \\\"{x:235,y:584,t:1526933529956};\\\", \\\"{x:300,y:628,t:1526933529972};\\\", \\\"{x:366,y:668,t:1526933529989};\\\", \\\"{x:415,y:697,t:1526933530006};\\\", \\\"{x:450,y:719,t:1526933530022};\\\", \\\"{x:474,y:733,t:1526933530038};\\\", \\\"{x:490,y:744,t:1526933530055};\\\", \\\"{x:500,y:751,t:1526933530072};\\\", \\\"{x:512,y:757,t:1526933530089};\\\", \\\"{x:519,y:762,t:1526933530105};\\\", \\\"{x:533,y:768,t:1526933530122};\\\", \\\"{x:541,y:774,t:1526933530139};\\\", \\\"{x:548,y:776,t:1526933530156};\\\", \\\"{x:549,y:776,t:1526933530195};\\\", \\\"{x:550,y:776,t:1526933530283};\\\", \\\"{x:550,y:774,t:1526933530306};\\\", \\\"{x:550,y:767,t:1526933530323};\\\", \\\"{x:548,y:762,t:1526933530340};\\\", \\\"{x:545,y:758,t:1526933530356};\\\", \\\"{x:543,y:754,t:1526933530373};\\\", \\\"{x:541,y:751,t:1526933530389};\\\", \\\"{x:538,y:747,t:1526933530406};\\\", \\\"{x:537,y:746,t:1526933530422};\\\", \\\"{x:537,y:745,t:1526933530442};\\\", \\\"{x:537,y:744,t:1526933530456};\\\", \\\"{x:536,y:742,t:1526933530472};\\\" ] }, { \\\"rt\\\": 72145, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 443417, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -E -B -B -X -B -B -B -J -B -B -F -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:733,t:1526933532010};\\\", \\\"{x:508,y:713,t:1526933532034};\\\", \\\"{x:499,y:707,t:1526933532040};\\\", \\\"{x:499,y:705,t:1526933532056};\\\", \\\"{x:497,y:702,t:1526933532939};\\\", \\\"{x:498,y:700,t:1526933532946};\\\", \\\"{x:508,y:696,t:1526933532957};\\\", \\\"{x:530,y:687,t:1526933532975};\\\", \\\"{x:624,y:664,t:1526933532991};\\\", \\\"{x:734,y:650,t:1526933533008};\\\", \\\"{x:874,y:618,t:1526933533025};\\\", \\\"{x:1032,y:596,t:1526933533041};\\\", \\\"{x:1199,y:589,t:1526933533058};\\\", \\\"{x:1463,y:603,t:1526933533074};\\\", \\\"{x:1665,y:606,t:1526933533092};\\\", \\\"{x:1858,y:606,t:1526933533108};\\\", \\\"{x:1927,y:593,t:1526933533125};\\\", \\\"{x:1927,y:577,t:1526933533142};\\\", \\\"{x:1927,y:563,t:1526933533158};\\\", \\\"{x:1927,y:547,t:1526933533174};\\\", \\\"{x:1927,y:535,t:1526933533192};\\\", \\\"{x:1927,y:532,t:1526933533208};\\\", \\\"{x:1927,y:531,t:1526933533283};\\\", \\\"{x:1927,y:530,t:1526933533292};\\\", \\\"{x:1927,y:529,t:1526933533308};\\\", \\\"{x:1923,y:523,t:1526933533325};\\\", \\\"{x:1906,y:510,t:1526933533341};\\\", \\\"{x:1873,y:492,t:1526933533357};\\\", \\\"{x:1822,y:469,t:1526933533374};\\\", \\\"{x:1742,y:437,t:1526933533392};\\\", \\\"{x:1682,y:411,t:1526933533408};\\\", \\\"{x:1596,y:386,t:1526933533425};\\\", \\\"{x:1559,y:375,t:1526933533442};\\\", \\\"{x:1527,y:363,t:1526933533458};\\\", \\\"{x:1521,y:360,t:1526933533475};\\\", \\\"{x:1518,y:360,t:1526933533890};\\\", \\\"{x:1517,y:360,t:1526933533922};\\\", \\\"{x:1514,y:361,t:1526933533939};\\\", \\\"{x:1513,y:361,t:1526933533947};\\\", \\\"{x:1511,y:363,t:1526933533958};\\\", \\\"{x:1509,y:368,t:1526933533976};\\\", \\\"{x:1505,y:371,t:1526933533992};\\\", \\\"{x:1505,y:373,t:1526933534008};\\\", \\\"{x:1503,y:373,t:1526933534026};\\\", \\\"{x:1503,y:374,t:1526933534042};\\\", \\\"{x:1500,y:376,t:1526933534058};\\\", \\\"{x:1496,y:379,t:1526933534076};\\\", \\\"{x:1492,y:384,t:1526933534092};\\\", \\\"{x:1490,y:389,t:1526933534109};\\\", \\\"{x:1484,y:396,t:1526933534126};\\\", \\\"{x:1479,y:404,t:1526933534141};\\\", \\\"{x:1470,y:415,t:1526933534158};\\\", \\\"{x:1459,y:426,t:1526933534176};\\\", \\\"{x:1448,y:437,t:1526933534191};\\\", \\\"{x:1441,y:443,t:1526933534209};\\\", \\\"{x:1435,y:451,t:1526933534226};\\\", \\\"{x:1430,y:458,t:1526933534242};\\\", \\\"{x:1424,y:468,t:1526933534259};\\\", \\\"{x:1422,y:472,t:1526933534276};\\\", \\\"{x:1420,y:473,t:1526933534292};\\\", \\\"{x:1419,y:475,t:1526933534314};\\\", \\\"{x:1418,y:475,t:1526933534330};\\\", \\\"{x:1418,y:476,t:1526933534342};\\\", \\\"{x:1418,y:477,t:1526933534370};\\\", \\\"{x:1418,y:478,t:1526933534595};\\\", \\\"{x:1419,y:480,t:1526933534608};\\\", \\\"{x:1420,y:483,t:1526933534626};\\\", \\\"{x:1422,y:486,t:1526933534642};\\\", \\\"{x:1422,y:487,t:1526933534666};\\\", \\\"{x:1422,y:488,t:1526933535130};\\\", \\\"{x:1422,y:490,t:1526933538978};\\\", \\\"{x:1421,y:492,t:1526933538986};\\\", \\\"{x:1418,y:496,t:1526933538996};\\\", \\\"{x:1414,y:503,t:1526933539013};\\\", \\\"{x:1412,y:510,t:1526933539029};\\\", \\\"{x:1407,y:520,t:1526933539046};\\\", \\\"{x:1403,y:534,t:1526933539063};\\\", \\\"{x:1394,y:553,t:1526933539078};\\\", \\\"{x:1385,y:572,t:1526933539096};\\\", \\\"{x:1375,y:592,t:1526933539113};\\\", \\\"{x:1369,y:606,t:1526933539129};\\\", \\\"{x:1364,y:623,t:1526933539146};\\\", \\\"{x:1356,y:644,t:1526933539163};\\\", \\\"{x:1350,y:666,t:1526933539179};\\\", \\\"{x:1344,y:681,t:1526933539196};\\\", \\\"{x:1342,y:697,t:1526933539214};\\\", \\\"{x:1339,y:709,t:1526933539231};\\\", \\\"{x:1335,y:725,t:1526933539246};\\\", \\\"{x:1334,y:735,t:1526933539263};\\\", \\\"{x:1333,y:743,t:1526933539280};\\\", \\\"{x:1332,y:752,t:1526933539296};\\\", \\\"{x:1331,y:761,t:1526933539313};\\\", \\\"{x:1328,y:768,t:1526933539330};\\\", \\\"{x:1326,y:778,t:1526933539346};\\\", \\\"{x:1324,y:787,t:1526933539363};\\\", \\\"{x:1324,y:789,t:1526933539380};\\\", \\\"{x:1324,y:790,t:1526933539396};\\\", \\\"{x:1324,y:789,t:1526933539674};\\\", \\\"{x:1324,y:788,t:1526933539698};\\\", \\\"{x:1324,y:786,t:1526933539713};\\\", \\\"{x:1324,y:785,t:1526933539778};\\\", \\\"{x:1324,y:784,t:1526933539786};\\\", \\\"{x:1324,y:782,t:1526933539797};\\\", \\\"{x:1324,y:780,t:1526933539813};\\\", \\\"{x:1325,y:779,t:1526933539830};\\\", \\\"{x:1326,y:778,t:1526933539847};\\\", \\\"{x:1327,y:777,t:1526933539863};\\\", \\\"{x:1327,y:776,t:1526933539899};\\\", \\\"{x:1328,y:775,t:1526933539913};\\\", \\\"{x:1329,y:774,t:1526933539930};\\\", \\\"{x:1330,y:770,t:1526933539947};\\\", \\\"{x:1331,y:766,t:1526933539963};\\\", \\\"{x:1331,y:760,t:1526933539980};\\\", \\\"{x:1331,y:755,t:1526933539997};\\\", \\\"{x:1331,y:747,t:1526933540013};\\\", \\\"{x:1331,y:736,t:1526933540030};\\\", \\\"{x:1330,y:721,t:1526933540047};\\\", \\\"{x:1330,y:706,t:1526933540063};\\\", \\\"{x:1325,y:681,t:1526933540080};\\\", \\\"{x:1320,y:656,t:1526933540097};\\\", \\\"{x:1315,y:636,t:1526933540114};\\\", \\\"{x:1310,y:626,t:1526933540130};\\\", \\\"{x:1308,y:619,t:1526933540147};\\\", \\\"{x:1308,y:615,t:1526933540164};\\\", \\\"{x:1307,y:612,t:1526933540180};\\\", \\\"{x:1306,y:608,t:1526933540197};\\\", \\\"{x:1305,y:605,t:1526933540214};\\\", \\\"{x:1304,y:602,t:1526933540230};\\\", \\\"{x:1302,y:599,t:1526933540247};\\\", \\\"{x:1300,y:596,t:1526933540264};\\\", \\\"{x:1299,y:595,t:1526933540280};\\\", \\\"{x:1298,y:593,t:1526933540297};\\\", \\\"{x:1296,y:591,t:1526933540314};\\\", \\\"{x:1295,y:590,t:1526933540331};\\\", \\\"{x:1294,y:589,t:1526933540362};\\\", \\\"{x:1293,y:588,t:1526933540370};\\\", \\\"{x:1292,y:588,t:1526933540394};\\\", \\\"{x:1292,y:587,t:1526933540403};\\\", \\\"{x:1291,y:587,t:1526933540414};\\\", \\\"{x:1290,y:587,t:1526933540430};\\\", \\\"{x:1290,y:586,t:1526933540458};\\\", \\\"{x:1289,y:585,t:1526933541011};\\\", \\\"{x:1287,y:584,t:1526933541026};\\\", \\\"{x:1286,y:584,t:1526933541035};\\\", \\\"{x:1285,y:583,t:1526933541048};\\\", \\\"{x:1281,y:583,t:1526933541064};\\\", \\\"{x:1281,y:582,t:1526933541081};\\\", \\\"{x:1280,y:582,t:1526933541098};\\\", \\\"{x:1279,y:582,t:1526933541114};\\\", \\\"{x:1278,y:581,t:1526933541186};\\\", \\\"{x:1277,y:581,t:1526933541203};\\\", \\\"{x:1275,y:581,t:1526933541291};\\\", \\\"{x:1273,y:581,t:1526933541386};\\\", \\\"{x:1272,y:581,t:1526933541475};\\\", \\\"{x:1271,y:581,t:1526933541522};\\\", \\\"{x:1270,y:581,t:1526933541531};\\\", \\\"{x:1270,y:579,t:1526933541915};\\\", \\\"{x:1271,y:576,t:1526933541922};\\\", \\\"{x:1272,y:576,t:1526933541938};\\\", \\\"{x:1272,y:574,t:1526933541948};\\\", \\\"{x:1273,y:574,t:1526933541965};\\\", \\\"{x:1274,y:573,t:1526933541982};\\\", \\\"{x:1275,y:572,t:1526933542002};\\\", \\\"{x:1275,y:571,t:1526933542026};\\\", \\\"{x:1276,y:570,t:1526933542058};\\\", \\\"{x:1277,y:569,t:1526933542066};\\\", \\\"{x:1278,y:569,t:1526933542114};\\\", \\\"{x:1279,y:568,t:1526933542130};\\\", \\\"{x:1280,y:567,t:1526933542154};\\\", \\\"{x:1281,y:566,t:1526933542186};\\\", \\\"{x:1282,y:566,t:1526933542198};\\\", \\\"{x:1283,y:565,t:1526933542226};\\\", \\\"{x:1284,y:564,t:1526933542322};\\\", \\\"{x:1285,y:564,t:1526933554002};\\\", \\\"{x:1283,y:571,t:1526933554010};\\\", \\\"{x:1279,y:582,t:1526933554024};\\\", \\\"{x:1272,y:604,t:1526933554042};\\\", \\\"{x:1266,y:626,t:1526933554057};\\\", \\\"{x:1266,y:664,t:1526933554074};\\\", \\\"{x:1266,y:686,t:1526933554092};\\\", \\\"{x:1266,y:701,t:1526933554107};\\\", \\\"{x:1266,y:712,t:1526933554124};\\\", \\\"{x:1271,y:723,t:1526933554141};\\\", \\\"{x:1278,y:732,t:1526933554158};\\\", \\\"{x:1281,y:738,t:1526933554174};\\\", \\\"{x:1286,y:746,t:1526933554192};\\\", \\\"{x:1290,y:750,t:1526933554209};\\\", \\\"{x:1294,y:753,t:1526933554225};\\\", \\\"{x:1297,y:755,t:1526933554242};\\\", \\\"{x:1302,y:758,t:1526933554258};\\\", \\\"{x:1307,y:760,t:1526933554275};\\\", \\\"{x:1311,y:762,t:1526933554291};\\\", \\\"{x:1326,y:766,t:1526933554308};\\\", \\\"{x:1338,y:768,t:1526933554325};\\\", \\\"{x:1345,y:768,t:1526933554342};\\\", \\\"{x:1348,y:768,t:1526933554359};\\\", \\\"{x:1351,y:768,t:1526933554376};\\\", \\\"{x:1352,y:768,t:1526933554392};\\\", \\\"{x:1354,y:768,t:1526933554467};\\\", \\\"{x:1355,y:768,t:1526933554498};\\\", \\\"{x:1356,y:768,t:1526933554546};\\\", \\\"{x:1356,y:767,t:1526933554818};\\\", \\\"{x:1355,y:767,t:1526933554842};\\\", \\\"{x:1355,y:766,t:1526933554866};\\\", \\\"{x:1354,y:766,t:1526933554907};\\\", \\\"{x:1352,y:766,t:1526933555058};\\\", \\\"{x:1351,y:766,t:1526933555379};\\\", \\\"{x:1350,y:764,t:1526933563706};\\\", \\\"{x:1354,y:763,t:1526933566787};\\\", \\\"{x:1361,y:762,t:1526933566801};\\\", \\\"{x:1376,y:762,t:1526933566818};\\\", \\\"{x:1392,y:762,t:1526933566836};\\\", \\\"{x:1410,y:765,t:1526933566852};\\\", \\\"{x:1430,y:771,t:1526933566869};\\\", \\\"{x:1447,y:777,t:1526933566885};\\\", \\\"{x:1466,y:783,t:1526933566901};\\\", \\\"{x:1481,y:787,t:1526933566918};\\\", \\\"{x:1490,y:792,t:1526933566935};\\\", \\\"{x:1497,y:794,t:1526933566951};\\\", \\\"{x:1503,y:798,t:1526933566969};\\\", \\\"{x:1514,y:807,t:1526933566985};\\\", \\\"{x:1527,y:816,t:1526933567002};\\\", \\\"{x:1530,y:818,t:1526933567018};\\\", \\\"{x:1530,y:819,t:1526933567043};\\\", \\\"{x:1530,y:821,t:1526933567058};\\\", \\\"{x:1530,y:823,t:1526933567074};\\\", \\\"{x:1530,y:824,t:1526933567085};\\\", \\\"{x:1530,y:826,t:1526933567102};\\\", \\\"{x:1528,y:829,t:1526933567118};\\\", \\\"{x:1526,y:831,t:1526933567135};\\\", \\\"{x:1523,y:832,t:1526933567152};\\\", \\\"{x:1517,y:833,t:1526933567168};\\\", \\\"{x:1512,y:835,t:1526933567185};\\\", \\\"{x:1505,y:836,t:1526933567202};\\\", \\\"{x:1501,y:836,t:1526933567219};\\\", \\\"{x:1498,y:836,t:1526933567236};\\\", \\\"{x:1498,y:838,t:1526933567411};\\\", \\\"{x:1497,y:839,t:1526933569811};\\\", \\\"{x:1496,y:839,t:1526933569915};\\\", \\\"{x:1495,y:839,t:1526933569978};\\\", \\\"{x:1494,y:839,t:1526933570058};\\\", \\\"{x:1493,y:839,t:1526933570259};\\\", \\\"{x:1491,y:838,t:1526933570271};\\\", \\\"{x:1488,y:837,t:1526933570287};\\\", \\\"{x:1486,y:835,t:1526933570305};\\\", \\\"{x:1484,y:834,t:1526933570322};\\\", \\\"{x:1481,y:832,t:1526933570338};\\\", \\\"{x:1481,y:831,t:1526933570394};\\\", \\\"{x:1480,y:831,t:1526933570474};\\\", \\\"{x:1479,y:830,t:1526933570487};\\\", \\\"{x:1477,y:829,t:1526933570504};\\\", \\\"{x:1476,y:828,t:1526933570522};\\\", \\\"{x:1474,y:828,t:1526933570546};\\\", \\\"{x:1473,y:828,t:1526933570594};\\\", \\\"{x:1472,y:827,t:1526933570610};\\\", \\\"{x:1471,y:826,t:1526933570635};\\\", \\\"{x:1470,y:826,t:1526933570642};\\\", \\\"{x:1470,y:825,t:1526933570658};\\\", \\\"{x:1468,y:824,t:1526933570683};\\\", \\\"{x:1466,y:824,t:1526933570706};\\\", \\\"{x:1465,y:824,t:1526933570730};\\\", \\\"{x:1464,y:822,t:1526933570739};\\\", \\\"{x:1463,y:822,t:1526933570755};\\\", \\\"{x:1460,y:821,t:1526933570772};\\\", \\\"{x:1457,y:820,t:1526933570789};\\\", \\\"{x:1453,y:818,t:1526933570805};\\\", \\\"{x:1451,y:818,t:1526933570822};\\\", \\\"{x:1446,y:817,t:1526933570839};\\\", \\\"{x:1445,y:816,t:1526933570855};\\\", \\\"{x:1443,y:815,t:1526933570871};\\\", \\\"{x:1443,y:814,t:1526933570889};\\\", \\\"{x:1442,y:814,t:1526933570922};\\\", \\\"{x:1441,y:814,t:1526933570938};\\\", \\\"{x:1440,y:814,t:1526933570963};\\\", \\\"{x:1439,y:814,t:1526933570995};\\\", \\\"{x:1438,y:814,t:1526933571005};\\\", \\\"{x:1437,y:813,t:1526933571021};\\\", \\\"{x:1435,y:812,t:1526933571042};\\\", \\\"{x:1434,y:812,t:1526933571055};\\\", \\\"{x:1431,y:811,t:1526933571071};\\\", \\\"{x:1422,y:808,t:1526933571088};\\\", \\\"{x:1413,y:806,t:1526933571106};\\\", \\\"{x:1400,y:803,t:1526933571122};\\\", \\\"{x:1385,y:797,t:1526933571138};\\\", \\\"{x:1381,y:795,t:1526933571156};\\\", \\\"{x:1377,y:794,t:1526933571171};\\\", \\\"{x:1373,y:793,t:1526933571189};\\\", \\\"{x:1371,y:793,t:1526933571205};\\\", \\\"{x:1368,y:791,t:1526933571222};\\\", \\\"{x:1366,y:791,t:1526933571239};\\\", \\\"{x:1364,y:791,t:1526933571255};\\\", \\\"{x:1363,y:790,t:1526933571272};\\\", \\\"{x:1362,y:790,t:1526933571288};\\\", \\\"{x:1361,y:789,t:1526933571354};\\\", \\\"{x:1361,y:788,t:1526933571362};\\\", \\\"{x:1361,y:787,t:1526933571371};\\\", \\\"{x:1360,y:785,t:1526933571388};\\\", \\\"{x:1359,y:784,t:1526933571406};\\\", \\\"{x:1357,y:780,t:1526933571423};\\\", \\\"{x:1357,y:779,t:1526933571438};\\\", \\\"{x:1357,y:778,t:1526933571455};\\\", \\\"{x:1355,y:777,t:1526933571472};\\\", \\\"{x:1354,y:776,t:1526933571490};\\\", \\\"{x:1354,y:775,t:1526933571506};\\\", \\\"{x:1352,y:775,t:1526933571674};\\\", \\\"{x:1351,y:775,t:1526933571698};\\\", \\\"{x:1350,y:775,t:1526933571714};\\\", \\\"{x:1349,y:775,t:1526933571802};\\\", \\\"{x:1348,y:775,t:1526933571978};\\\", \\\"{x:1346,y:776,t:1526933572146};\\\", \\\"{x:1345,y:776,t:1526933572179};\\\", \\\"{x:1344,y:776,t:1526933572210};\\\", \\\"{x:1343,y:776,t:1526933572962};\\\", \\\"{x:1343,y:777,t:1526933573499};\\\", \\\"{x:1344,y:777,t:1526933573762};\\\", \\\"{x:1345,y:777,t:1526933573819};\\\", \\\"{x:1346,y:777,t:1526933573866};\\\", \\\"{x:1347,y:777,t:1526933573946};\\\", \\\"{x:1348,y:776,t:1526933574034};\\\", \\\"{x:1348,y:775,t:1526933574090};\\\", \\\"{x:1348,y:774,t:1526933574154};\\\", \\\"{x:1348,y:772,t:1526933574170};\\\", \\\"{x:1348,y:771,t:1526933574194};\\\", \\\"{x:1348,y:768,t:1526933574208};\\\", \\\"{x:1346,y:763,t:1526933574225};\\\", \\\"{x:1344,y:757,t:1526933574241};\\\", \\\"{x:1344,y:755,t:1526933574258};\\\", \\\"{x:1343,y:753,t:1526933574275};\\\", \\\"{x:1343,y:752,t:1526933574322};\\\", \\\"{x:1343,y:753,t:1526933574634};\\\", \\\"{x:1343,y:754,t:1526933574674};\\\", \\\"{x:1344,y:755,t:1526933576507};\\\", \\\"{x:1344,y:756,t:1526933576723};\\\", \\\"{x:1344,y:757,t:1526933576803};\\\", \\\"{x:1344,y:758,t:1526933577074};\\\", \\\"{x:1344,y:759,t:1526933577163};\\\", \\\"{x:1344,y:760,t:1526933577194};\\\", \\\"{x:1341,y:761,t:1526933577235};\\\", \\\"{x:1339,y:761,t:1526933577250};\\\", \\\"{x:1338,y:761,t:1526933577260};\\\", \\\"{x:1336,y:761,t:1526933577277};\\\", \\\"{x:1334,y:761,t:1526933577294};\\\", \\\"{x:1332,y:761,t:1526933577310};\\\", \\\"{x:1330,y:761,t:1526933577327};\\\", \\\"{x:1329,y:761,t:1526933577346};\\\", \\\"{x:1328,y:761,t:1526933577370};\\\", \\\"{x:1327,y:761,t:1526933577394};\\\", \\\"{x:1326,y:761,t:1526933577409};\\\", \\\"{x:1325,y:761,t:1526933577427};\\\", \\\"{x:1322,y:761,t:1526933577444};\\\", \\\"{x:1319,y:761,t:1526933577460};\\\", \\\"{x:1315,y:761,t:1526933577477};\\\", \\\"{x:1314,y:761,t:1526933577494};\\\", \\\"{x:1312,y:761,t:1526933577510};\\\", \\\"{x:1309,y:761,t:1526933577530};\\\", \\\"{x:1308,y:761,t:1526933577546};\\\", \\\"{x:1306,y:761,t:1526933577560};\\\", \\\"{x:1298,y:761,t:1526933577577};\\\", \\\"{x:1294,y:759,t:1526933577594};\\\", \\\"{x:1285,y:758,t:1526933577610};\\\", \\\"{x:1279,y:757,t:1526933577627};\\\", \\\"{x:1276,y:757,t:1526933577644};\\\", \\\"{x:1273,y:757,t:1526933577661};\\\", \\\"{x:1270,y:757,t:1526933577676};\\\", \\\"{x:1265,y:758,t:1526933577693};\\\", \\\"{x:1257,y:761,t:1526933577710};\\\", \\\"{x:1251,y:765,t:1526933577727};\\\", \\\"{x:1247,y:769,t:1526933577743};\\\", \\\"{x:1237,y:776,t:1526933577761};\\\", \\\"{x:1228,y:781,t:1526933577778};\\\", \\\"{x:1218,y:794,t:1526933577794};\\\", \\\"{x:1215,y:798,t:1526933577810};\\\", \\\"{x:1211,y:802,t:1526933577826};\\\", \\\"{x:1208,y:806,t:1526933577844};\\\", \\\"{x:1207,y:807,t:1526933577861};\\\", \\\"{x:1206,y:808,t:1526933577914};\\\", \\\"{x:1205,y:809,t:1526933577938};\\\", \\\"{x:1205,y:811,t:1526933577954};\\\", \\\"{x:1204,y:813,t:1526933577979};\\\", \\\"{x:1204,y:814,t:1526933578002};\\\", \\\"{x:1204,y:816,t:1526933578010};\\\", \\\"{x:1205,y:817,t:1526933578027};\\\", \\\"{x:1206,y:818,t:1526933578044};\\\", \\\"{x:1207,y:820,t:1526933578061};\\\", \\\"{x:1208,y:824,t:1526933578077};\\\", \\\"{x:1209,y:828,t:1526933578094};\\\", \\\"{x:1211,y:829,t:1526933578111};\\\", \\\"{x:1211,y:831,t:1526933578128};\\\", \\\"{x:1212,y:831,t:1526933578144};\\\", \\\"{x:1212,y:832,t:1526933578162};\\\", \\\"{x:1212,y:833,t:1526933578186};\\\", \\\"{x:1214,y:833,t:1526933578314};\\\", \\\"{x:1215,y:832,t:1526933578362};\\\", \\\"{x:1216,y:831,t:1526933578426};\\\", \\\"{x:1216,y:830,t:1526933578618};\\\", \\\"{x:1216,y:829,t:1526933578650};\\\", \\\"{x:1216,y:828,t:1526933578722};\\\", \\\"{x:1216,y:827,t:1526933582937};\\\", \\\"{x:1216,y:826,t:1526933582969};\\\", \\\"{x:1216,y:825,t:1526933582984};\\\", \\\"{x:1216,y:824,t:1526933583017};\\\", \\\"{x:1217,y:823,t:1526933583035};\\\", \\\"{x:1217,y:822,t:1526933583242};\\\", \\\"{x:1218,y:821,t:1526933583257};\\\", \\\"{x:1218,y:820,t:1526933583298};\\\", \\\"{x:1218,y:819,t:1526933583321};\\\", \\\"{x:1219,y:819,t:1526933583345};\\\", \\\"{x:1220,y:818,t:1526933583354};\\\", \\\"{x:1220,y:817,t:1526933583401};\\\", \\\"{x:1220,y:816,t:1526933583417};\\\", \\\"{x:1221,y:816,t:1526933583434};\\\", \\\"{x:1221,y:814,t:1526933583451};\\\", \\\"{x:1223,y:813,t:1526933583513};\\\", \\\"{x:1224,y:812,t:1526933583537};\\\", \\\"{x:1224,y:811,t:1526933583551};\\\", \\\"{x:1228,y:808,t:1526933583567};\\\", \\\"{x:1232,y:807,t:1526933583584};\\\", \\\"{x:1239,y:803,t:1526933583601};\\\", \\\"{x:1244,y:800,t:1526933583617};\\\", \\\"{x:1248,y:798,t:1526933583634};\\\", \\\"{x:1252,y:796,t:1526933583651};\\\", \\\"{x:1256,y:796,t:1526933583667};\\\", \\\"{x:1259,y:793,t:1526933583684};\\\", \\\"{x:1264,y:792,t:1526933583702};\\\", \\\"{x:1270,y:788,t:1526933583719};\\\", \\\"{x:1281,y:785,t:1526933583735};\\\", \\\"{x:1293,y:781,t:1526933583752};\\\", \\\"{x:1300,y:776,t:1526933583768};\\\", \\\"{x:1311,y:774,t:1526933583784};\\\", \\\"{x:1323,y:772,t:1526933583802};\\\", \\\"{x:1328,y:771,t:1526933583818};\\\", \\\"{x:1333,y:768,t:1526933583834};\\\", \\\"{x:1336,y:766,t:1526933583852};\\\", \\\"{x:1338,y:766,t:1526933583868};\\\", \\\"{x:1341,y:766,t:1526933583890};\\\", \\\"{x:1342,y:766,t:1526933583905};\\\", \\\"{x:1343,y:766,t:1526933583919};\\\", \\\"{x:1345,y:764,t:1526933583934};\\\", \\\"{x:1346,y:763,t:1526933584121};\\\", \\\"{x:1348,y:762,t:1526933584138};\\\", \\\"{x:1349,y:761,t:1526933584170};\\\", \\\"{x:1349,y:758,t:1526933585841};\\\", \\\"{x:1349,y:746,t:1526933585852};\\\", \\\"{x:1349,y:719,t:1526933585870};\\\", \\\"{x:1347,y:696,t:1526933585887};\\\", \\\"{x:1347,y:674,t:1526933585903};\\\", \\\"{x:1345,y:655,t:1526933585920};\\\", \\\"{x:1345,y:638,t:1526933585937};\\\", \\\"{x:1345,y:622,t:1526933585953};\\\", \\\"{x:1345,y:616,t:1526933585969};\\\", \\\"{x:1345,y:605,t:1526933585987};\\\", \\\"{x:1345,y:592,t:1526933586003};\\\", \\\"{x:1345,y:584,t:1526933586020};\\\", \\\"{x:1345,y:578,t:1526933586036};\\\", \\\"{x:1344,y:573,t:1526933586054};\\\", \\\"{x:1341,y:570,t:1526933586070};\\\", \\\"{x:1338,y:567,t:1526933586087};\\\", \\\"{x:1335,y:564,t:1526933586103};\\\", \\\"{x:1329,y:560,t:1526933586119};\\\", \\\"{x:1326,y:560,t:1526933586137};\\\", \\\"{x:1320,y:560,t:1526933586153};\\\", \\\"{x:1313,y:561,t:1526933586169};\\\", \\\"{x:1308,y:562,t:1526933586186};\\\", \\\"{x:1304,y:563,t:1526933586204};\\\", \\\"{x:1302,y:563,t:1526933586220};\\\", \\\"{x:1298,y:565,t:1526933586237};\\\", \\\"{x:1294,y:566,t:1526933586254};\\\", \\\"{x:1291,y:566,t:1526933586270};\\\", \\\"{x:1290,y:567,t:1526933586286};\\\", \\\"{x:1283,y:567,t:1526933586304};\\\", \\\"{x:1278,y:567,t:1526933586319};\\\", \\\"{x:1271,y:567,t:1526933586337};\\\", \\\"{x:1269,y:567,t:1526933586353};\\\", \\\"{x:1267,y:567,t:1526933586369};\\\", \\\"{x:1264,y:567,t:1526933586386};\\\", \\\"{x:1260,y:565,t:1526933586404};\\\", \\\"{x:1259,y:565,t:1526933586425};\\\", \\\"{x:1259,y:564,t:1526933586617};\\\", \\\"{x:1260,y:564,t:1526933586641};\\\", \\\"{x:1261,y:564,t:1526933586673};\\\", \\\"{x:1264,y:564,t:1526933586689};\\\", \\\"{x:1266,y:562,t:1526933586704};\\\", \\\"{x:1267,y:562,t:1526933586720};\\\", \\\"{x:1268,y:562,t:1526933586737};\\\", \\\"{x:1271,y:562,t:1526933586754};\\\", \\\"{x:1271,y:561,t:1526933586771};\\\", \\\"{x:1273,y:561,t:1526933586787};\\\", \\\"{x:1274,y:561,t:1526933586804};\\\", \\\"{x:1277,y:561,t:1526933586821};\\\", \\\"{x:1279,y:561,t:1526933586853};\\\", \\\"{x:1280,y:561,t:1526933586871};\\\", \\\"{x:1282,y:561,t:1526933587505};\\\", \\\"{x:1283,y:561,t:1526933587521};\\\", \\\"{x:1283,y:562,t:1526933590114};\\\", \\\"{x:1283,y:565,t:1526933590123};\\\", \\\"{x:1283,y:574,t:1526933590140};\\\", \\\"{x:1283,y:580,t:1526933590156};\\\", \\\"{x:1282,y:586,t:1526933590173};\\\", \\\"{x:1281,y:590,t:1526933590189};\\\", \\\"{x:1281,y:593,t:1526933590206};\\\", \\\"{x:1281,y:594,t:1526933590233};\\\", \\\"{x:1281,y:595,t:1526933590241};\\\", \\\"{x:1281,y:596,t:1526933590257};\\\", \\\"{x:1281,y:597,t:1526933590289};\\\", \\\"{x:1281,y:598,t:1526933590314};\\\", \\\"{x:1280,y:600,t:1526933590361};\\\", \\\"{x:1279,y:602,t:1526933590394};\\\", \\\"{x:1279,y:603,t:1526933590425};\\\", \\\"{x:1279,y:604,t:1526933590440};\\\", \\\"{x:1278,y:606,t:1526933590457};\\\", \\\"{x:1278,y:608,t:1526933590473};\\\", \\\"{x:1278,y:609,t:1526933590722};\\\", \\\"{x:1276,y:613,t:1526933590729};\\\", \\\"{x:1276,y:614,t:1526933590740};\\\", \\\"{x:1276,y:616,t:1526933590756};\\\", \\\"{x:1276,y:619,t:1526933590774};\\\", \\\"{x:1276,y:622,t:1526933590790};\\\", \\\"{x:1276,y:625,t:1526933590807};\\\", \\\"{x:1276,y:626,t:1526933590824};\\\", \\\"{x:1276,y:628,t:1526933590841};\\\", \\\"{x:1276,y:629,t:1526933590857};\\\", \\\"{x:1275,y:631,t:1526933590874};\\\", \\\"{x:1275,y:632,t:1526933590891};\\\", \\\"{x:1274,y:635,t:1526933590907};\\\", \\\"{x:1274,y:638,t:1526933590923};\\\", \\\"{x:1274,y:641,t:1526933590940};\\\", \\\"{x:1274,y:645,t:1526933590956};\\\", \\\"{x:1273,y:647,t:1526933590974};\\\", \\\"{x:1273,y:649,t:1526933590991};\\\", \\\"{x:1273,y:654,t:1526933591007};\\\", \\\"{x:1273,y:657,t:1526933591024};\\\", \\\"{x:1273,y:662,t:1526933591040};\\\", \\\"{x:1273,y:669,t:1526933591057};\\\", \\\"{x:1273,y:677,t:1526933591073};\\\", \\\"{x:1273,y:681,t:1526933591091};\\\", \\\"{x:1273,y:685,t:1526933591107};\\\", \\\"{x:1273,y:691,t:1526933591124};\\\", \\\"{x:1272,y:698,t:1526933591141};\\\", \\\"{x:1272,y:709,t:1526933591157};\\\", \\\"{x:1272,y:720,t:1526933591173};\\\", \\\"{x:1272,y:727,t:1526933591191};\\\", \\\"{x:1272,y:734,t:1526933591206};\\\", \\\"{x:1272,y:740,t:1526933591223};\\\", \\\"{x:1272,y:747,t:1526933591241};\\\", \\\"{x:1272,y:755,t:1526933591257};\\\", \\\"{x:1272,y:761,t:1526933591273};\\\", \\\"{x:1272,y:768,t:1526933591291};\\\", \\\"{x:1271,y:778,t:1526933591308};\\\", \\\"{x:1271,y:784,t:1526933591324};\\\", \\\"{x:1271,y:790,t:1526933591341};\\\", \\\"{x:1271,y:799,t:1526933591358};\\\", \\\"{x:1271,y:809,t:1526933591374};\\\", \\\"{x:1271,y:818,t:1526933591391};\\\", \\\"{x:1268,y:828,t:1526933591408};\\\", \\\"{x:1268,y:838,t:1526933591423};\\\", \\\"{x:1268,y:849,t:1526933591440};\\\", \\\"{x:1268,y:866,t:1526933591457};\\\", \\\"{x:1270,y:880,t:1526933591473};\\\", \\\"{x:1272,y:886,t:1526933591490};\\\", \\\"{x:1273,y:888,t:1526933591507};\\\", \\\"{x:1273,y:891,t:1526933591524};\\\", \\\"{x:1273,y:897,t:1526933591541};\\\", \\\"{x:1273,y:899,t:1526933591558};\\\", \\\"{x:1273,y:904,t:1526933591574};\\\", \\\"{x:1273,y:908,t:1526933591591};\\\", \\\"{x:1273,y:911,t:1526933591608};\\\", \\\"{x:1273,y:913,t:1526933591624};\\\", \\\"{x:1273,y:915,t:1526933591640};\\\", \\\"{x:1273,y:917,t:1526933591657};\\\", \\\"{x:1273,y:919,t:1526933591674};\\\", \\\"{x:1274,y:921,t:1526933591690};\\\", \\\"{x:1276,y:924,t:1526933591708};\\\", \\\"{x:1276,y:925,t:1526933591724};\\\", \\\"{x:1276,y:928,t:1526933591741};\\\", \\\"{x:1276,y:929,t:1526933591758};\\\", \\\"{x:1276,y:926,t:1526933591842};\\\", \\\"{x:1276,y:896,t:1526933591858};\\\", \\\"{x:1279,y:864,t:1526933591875};\\\", \\\"{x:1283,y:834,t:1526933591891};\\\", \\\"{x:1287,y:805,t:1526933591908};\\\", \\\"{x:1293,y:778,t:1526933591925};\\\", \\\"{x:1300,y:739,t:1526933591941};\\\", \\\"{x:1302,y:709,t:1526933591958};\\\", \\\"{x:1302,y:692,t:1526933591975};\\\", \\\"{x:1302,y:682,t:1526933591991};\\\", \\\"{x:1303,y:673,t:1526933592007};\\\", \\\"{x:1305,y:667,t:1526933592025};\\\", \\\"{x:1306,y:662,t:1526933592040};\\\", \\\"{x:1306,y:650,t:1526933592058};\\\", \\\"{x:1306,y:636,t:1526933592075};\\\", \\\"{x:1306,y:624,t:1526933592091};\\\", \\\"{x:1304,y:611,t:1526933592108};\\\", \\\"{x:1303,y:605,t:1526933592126};\\\", \\\"{x:1300,y:600,t:1526933592142};\\\", \\\"{x:1299,y:594,t:1526933592158};\\\", \\\"{x:1296,y:584,t:1526933592175};\\\", \\\"{x:1295,y:578,t:1526933592192};\\\", \\\"{x:1295,y:575,t:1526933592208};\\\", \\\"{x:1295,y:574,t:1526933592224};\\\", \\\"{x:1295,y:573,t:1526933592242};\\\", \\\"{x:1288,y:572,t:1526933600529};\\\", \\\"{x:1269,y:572,t:1526933600537};\\\", \\\"{x:1244,y:572,t:1526933600548};\\\", \\\"{x:1163,y:557,t:1526933600565};\\\", \\\"{x:1070,y:540,t:1526933600581};\\\", \\\"{x:984,y:525,t:1526933600598};\\\", \\\"{x:949,y:508,t:1526933600615};\\\", \\\"{x:944,y:506,t:1526933600631};\\\", \\\"{x:943,y:506,t:1526933600657};\\\", \\\"{x:941,y:506,t:1526933600666};\\\", \\\"{x:938,y:506,t:1526933600683};\\\", \\\"{x:933,y:506,t:1526933600699};\\\", \\\"{x:932,y:506,t:1526933600716};\\\", \\\"{x:931,y:506,t:1526933600733};\\\", \\\"{x:928,y:505,t:1526933600750};\\\", \\\"{x:924,y:505,t:1526933600767};\\\", \\\"{x:919,y:503,t:1526933600783};\\\", \\\"{x:916,y:503,t:1526933601585};\\\", \\\"{x:915,y:503,t:1526933601657};\\\", \\\"{x:914,y:503,t:1526933601729};\\\", \\\"{x:913,y:503,t:1526933601736};\\\", \\\"{x:912,y:503,t:1526933601753};\\\", \\\"{x:911,y:504,t:1526933601767};\\\", \\\"{x:909,y:504,t:1526933601784};\\\", \\\"{x:908,y:505,t:1526933601800};\\\", \\\"{x:903,y:505,t:1526933601817};\\\", \\\"{x:897,y:505,t:1526933601834};\\\", \\\"{x:891,y:506,t:1526933601850};\\\", \\\"{x:885,y:507,t:1526933601868};\\\", \\\"{x:871,y:508,t:1526933601884};\\\", \\\"{x:860,y:510,t:1526933601900};\\\", \\\"{x:849,y:510,t:1526933601918};\\\", \\\"{x:845,y:510,t:1526933601934};\\\", \\\"{x:839,y:513,t:1526933601951};\\\", \\\"{x:825,y:522,t:1526933601969};\\\", \\\"{x:817,y:523,t:1526933601984};\\\", \\\"{x:813,y:528,t:1526933602002};\\\", \\\"{x:806,y:531,t:1526933602018};\\\", \\\"{x:803,y:533,t:1526933602034};\\\", \\\"{x:797,y:534,t:1526933602051};\\\", \\\"{x:784,y:535,t:1526933602068};\\\", \\\"{x:773,y:539,t:1526933602084};\\\", \\\"{x:759,y:543,t:1526933602102};\\\", \\\"{x:748,y:550,t:1526933602118};\\\", \\\"{x:745,y:552,t:1526933602135};\\\", \\\"{x:736,y:557,t:1526933602152};\\\", \\\"{x:725,y:560,t:1526933602169};\\\", \\\"{x:712,y:565,t:1526933602185};\\\", \\\"{x:693,y:575,t:1526933602200};\\\", \\\"{x:674,y:584,t:1526933602218};\\\", \\\"{x:657,y:591,t:1526933602234};\\\", \\\"{x:647,y:596,t:1526933602251};\\\", \\\"{x:640,y:599,t:1526933602268};\\\", \\\"{x:632,y:604,t:1526933602285};\\\", \\\"{x:626,y:606,t:1526933602301};\\\", \\\"{x:622,y:608,t:1526933602318};\\\", \\\"{x:622,y:609,t:1526933602335};\\\", \\\"{x:622,y:610,t:1526933602417};\\\", \\\"{x:626,y:609,t:1526933602424};\\\", \\\"{x:634,y:606,t:1526933602435};\\\", \\\"{x:649,y:599,t:1526933602452};\\\", \\\"{x:669,y:586,t:1526933602469};\\\", \\\"{x:681,y:576,t:1526933602486};\\\", \\\"{x:687,y:569,t:1526933602501};\\\", \\\"{x:687,y:564,t:1526933602518};\\\", \\\"{x:687,y:562,t:1526933602535};\\\", \\\"{x:685,y:557,t:1526933602551};\\\", \\\"{x:677,y:547,t:1526933602569};\\\", \\\"{x:658,y:531,t:1526933602586};\\\", \\\"{x:643,y:520,t:1526933602602};\\\", \\\"{x:626,y:511,t:1526933602619};\\\", \\\"{x:618,y:507,t:1526933602635};\\\", \\\"{x:613,y:503,t:1526933602652};\\\", \\\"{x:608,y:498,t:1526933602669};\\\", \\\"{x:606,y:497,t:1526933602685};\\\", \\\"{x:608,y:494,t:1526933602809};\\\", \\\"{x:609,y:494,t:1526933602824};\\\", \\\"{x:609,y:493,t:1526933602836};\\\", \\\"{x:609,y:494,t:1526933603289};\\\", \\\"{x:609,y:503,t:1526933603302};\\\", \\\"{x:604,y:520,t:1526933603319};\\\", \\\"{x:600,y:541,t:1526933603335};\\\", \\\"{x:594,y:559,t:1526933603353};\\\", \\\"{x:589,y:571,t:1526933603369};\\\", \\\"{x:587,y:589,t:1526933603385};\\\", \\\"{x:578,y:609,t:1526933603403};\\\", \\\"{x:574,y:630,t:1526933603419};\\\", \\\"{x:568,y:650,t:1526933603436};\\\", \\\"{x:563,y:665,t:1526933603452};\\\", \\\"{x:558,y:680,t:1526933603469};\\\", \\\"{x:554,y:689,t:1526933603485};\\\", \\\"{x:549,y:697,t:1526933603502};\\\", \\\"{x:547,y:702,t:1526933603519};\\\", \\\"{x:543,y:713,t:1526933603535};\\\", \\\"{x:533,y:726,t:1526933603553};\\\", \\\"{x:530,y:734,t:1526933603569};\\\", \\\"{x:529,y:737,t:1526933603585};\\\", \\\"{x:529,y:735,t:1526933605297};\\\", \\\"{x:526,y:721,t:1526933605305};\\\", \\\"{x:515,y:700,t:1526933605320};\\\", \\\"{x:507,y:682,t:1526933605337};\\\", \\\"{x:502,y:669,t:1526933605353};\\\", \\\"{x:488,y:640,t:1526933605370};\\\", \\\"{x:465,y:604,t:1526933605387};\\\", \\\"{x:447,y:568,t:1526933605403};\\\", \\\"{x:432,y:541,t:1526933605420};\\\" ] }, { \\\"rt\\\": 43769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 488697, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L -J -J -J -I -I -J -J -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:396,y:464,t:1526933605601};\\\", \\\"{x:396,y:463,t:1526933605624};\\\", \\\"{x:396,y:462,t:1526933605665};\\\", \\\"{x:394,y:460,t:1526933605689};\\\", \\\"{x:394,y:459,t:1526933605728};\\\", \\\"{x:393,y:457,t:1526933605794};\\\", \\\"{x:393,y:455,t:1526933605849};\\\", \\\"{x:392,y:454,t:1526933605865};\\\", \\\"{x:392,y:452,t:1526933605881};\\\", \\\"{x:392,y:451,t:1526933605905};\\\", \\\"{x:392,y:449,t:1526933605921};\\\", \\\"{x:392,y:448,t:1526933605937};\\\", \\\"{x:392,y:446,t:1526933605954};\\\", \\\"{x:392,y:445,t:1526933605977};\\\", \\\"{x:392,y:444,t:1526933605987};\\\", \\\"{x:392,y:442,t:1526933606004};\\\", \\\"{x:393,y:437,t:1526933606021};\\\", \\\"{x:394,y:434,t:1526933606037};\\\", \\\"{x:396,y:431,t:1526933606055};\\\", \\\"{x:397,y:429,t:1526933606072};\\\", \\\"{x:397,y:427,t:1526933606087};\\\", \\\"{x:398,y:424,t:1526933606105};\\\", \\\"{x:400,y:422,t:1526933606122};\\\", \\\"{x:401,y:420,t:1526933606139};\\\", \\\"{x:401,y:418,t:1526933606154};\\\", \\\"{x:403,y:417,t:1526933606171};\\\", \\\"{x:404,y:415,t:1526933606188};\\\", \\\"{x:404,y:414,t:1526933606204};\\\", \\\"{x:405,y:413,t:1526933606222};\\\", \\\"{x:406,y:411,t:1526933606238};\\\", \\\"{x:408,y:410,t:1526933606265};\\\", \\\"{x:409,y:409,t:1526933606281};\\\", \\\"{x:410,y:409,t:1526933606289};\\\", \\\"{x:410,y:408,t:1526933606305};\\\", \\\"{x:411,y:408,t:1526933606321};\\\", \\\"{x:411,y:407,t:1526933606338};\\\", \\\"{x:413,y:406,t:1526933606361};\\\", \\\"{x:413,y:405,t:1526933606376};\\\", \\\"{x:414,y:405,t:1526933606388};\\\", \\\"{x:416,y:403,t:1526933606404};\\\", \\\"{x:418,y:402,t:1526933606421};\\\", \\\"{x:419,y:401,t:1526933606438};\\\", \\\"{x:421,y:399,t:1526933606454};\\\", \\\"{x:422,y:398,t:1526933606471};\\\", \\\"{x:426,y:398,t:1526933606488};\\\", \\\"{x:428,y:395,t:1526933606504};\\\", \\\"{x:430,y:394,t:1526933606521};\\\", \\\"{x:432,y:393,t:1526933606538};\\\", \\\"{x:433,y:392,t:1526933606561};\\\", \\\"{x:433,y:390,t:1526933606585};\\\", \\\"{x:434,y:390,t:1526933606593};\\\", \\\"{x:434,y:389,t:1526933606605};\\\", \\\"{x:438,y:387,t:1526933606621};\\\", \\\"{x:439,y:387,t:1526933606638};\\\", \\\"{x:441,y:386,t:1526933606655};\\\", \\\"{x:442,y:385,t:1526933606671};\\\", \\\"{x:444,y:383,t:1526933606688};\\\", \\\"{x:445,y:382,t:1526933606713};\\\", \\\"{x:446,y:381,t:1526933606736};\\\", \\\"{x:447,y:381,t:1526933606745};\\\", \\\"{x:448,y:380,t:1526933606755};\\\", \\\"{x:449,y:379,t:1526933606771};\\\", \\\"{x:450,y:379,t:1526933606788};\\\", \\\"{x:452,y:378,t:1526933606805};\\\", \\\"{x:453,y:377,t:1526933606821};\\\", \\\"{x:454,y:376,t:1526933606838};\\\", \\\"{x:456,y:376,t:1526933606857};\\\", \\\"{x:458,y:374,t:1526933606871};\\\", \\\"{x:460,y:373,t:1526933606905};\\\", \\\"{x:461,y:373,t:1526933606929};\\\", \\\"{x:463,y:372,t:1526933606961};\\\", \\\"{x:464,y:371,t:1526933607025};\\\", \\\"{x:465,y:370,t:1526933607038};\\\", \\\"{x:466,y:370,t:1526933607057};\\\", \\\"{x:467,y:370,t:1526933607138};\\\", \\\"{x:468,y:369,t:1526933607161};\\\", \\\"{x:469,y:369,t:1526933607177};\\\", \\\"{x:470,y:369,t:1526933607193};\\\", \\\"{x:470,y:368,t:1526933607208};\\\", \\\"{x:471,y:367,t:1526933607222};\\\", \\\"{x:472,y:367,t:1526933607265};\\\", \\\"{x:473,y:366,t:1526933607273};\\\", \\\"{x:474,y:365,t:1526933607289};\\\", \\\"{x:474,y:364,t:1526933607305};\\\", \\\"{x:475,y:364,t:1526933607322};\\\", \\\"{x:476,y:363,t:1526933607369};\\\", \\\"{x:479,y:362,t:1526933607393};\\\", \\\"{x:479,y:361,t:1526933607409};\\\", \\\"{x:481,y:361,t:1526933607465};\\\", \\\"{x:482,y:360,t:1526933607521};\\\", \\\"{x:483,y:359,t:1526933607561};\\\", \\\"{x:484,y:359,t:1526933607577};\\\", \\\"{x:484,y:358,t:1526933607588};\\\", \\\"{x:486,y:358,t:1526933607605};\\\", \\\"{x:487,y:357,t:1526933607622};\\\", \\\"{x:488,y:356,t:1526933607639};\\\", \\\"{x:489,y:355,t:1526933607673};\\\", \\\"{x:491,y:355,t:1526933607689};\\\", \\\"{x:493,y:355,t:1526933607706};\\\", \\\"{x:494,y:354,t:1526933607722};\\\", \\\"{x:496,y:352,t:1526933607739};\\\", \\\"{x:498,y:352,t:1526933607755};\\\", \\\"{x:501,y:352,t:1526933607773};\\\", \\\"{x:503,y:351,t:1526933607790};\\\", \\\"{x:505,y:350,t:1526933607805};\\\", \\\"{x:508,y:350,t:1526933607823};\\\", \\\"{x:514,y:349,t:1526933607839};\\\", \\\"{x:528,y:348,t:1526933607855};\\\", \\\"{x:540,y:348,t:1526933607872};\\\", \\\"{x:570,y:348,t:1526933607889};\\\", \\\"{x:587,y:348,t:1526933607906};\\\", \\\"{x:607,y:348,t:1526933607923};\\\", \\\"{x:624,y:348,t:1526933607939};\\\", \\\"{x:651,y:348,t:1526933607957};\\\", \\\"{x:689,y:351,t:1526933607972};\\\", \\\"{x:734,y:357,t:1526933607990};\\\", \\\"{x:774,y:365,t:1526933608006};\\\", \\\"{x:854,y:374,t:1526933608022};\\\", \\\"{x:936,y:391,t:1526933608040};\\\", \\\"{x:1020,y:404,t:1526933608056};\\\", \\\"{x:1121,y:426,t:1526933608072};\\\", \\\"{x:1269,y:455,t:1526933608089};\\\", \\\"{x:1359,y:472,t:1526933608106};\\\", \\\"{x:1443,y:491,t:1526933608123};\\\", \\\"{x:1518,y:509,t:1526933608140};\\\", \\\"{x:1591,y:533,t:1526933608156};\\\", \\\"{x:1648,y:544,t:1526933608172};\\\", \\\"{x:1685,y:557,t:1526933608189};\\\", \\\"{x:1710,y:561,t:1526933608207};\\\", \\\"{x:1722,y:567,t:1526933608222};\\\", \\\"{x:1728,y:568,t:1526933608240};\\\", \\\"{x:1729,y:568,t:1526933608257};\\\", \\\"{x:1729,y:569,t:1526933608465};\\\", \\\"{x:1725,y:570,t:1526933608474};\\\", \\\"{x:1716,y:572,t:1526933608490};\\\", \\\"{x:1707,y:572,t:1526933608506};\\\", \\\"{x:1693,y:575,t:1526933608523};\\\", \\\"{x:1660,y:579,t:1526933608539};\\\", \\\"{x:1634,y:579,t:1526933608557};\\\", \\\"{x:1617,y:579,t:1526933608574};\\\", \\\"{x:1604,y:579,t:1526933608589};\\\", \\\"{x:1593,y:579,t:1526933608606};\\\", \\\"{x:1583,y:577,t:1526933608623};\\\", \\\"{x:1578,y:576,t:1526933608639};\\\", \\\"{x:1575,y:576,t:1526933608656};\\\", \\\"{x:1559,y:574,t:1526933608673};\\\", \\\"{x:1545,y:572,t:1526933608689};\\\", \\\"{x:1535,y:571,t:1526933608707};\\\", \\\"{x:1528,y:570,t:1526933608724};\\\", \\\"{x:1518,y:567,t:1526933608740};\\\", \\\"{x:1511,y:563,t:1526933608757};\\\", \\\"{x:1509,y:562,t:1526933608773};\\\", \\\"{x:1506,y:558,t:1526933608789};\\\", \\\"{x:1504,y:552,t:1526933608807};\\\", \\\"{x:1502,y:537,t:1526933608823};\\\", \\\"{x:1502,y:527,t:1526933608840};\\\", \\\"{x:1502,y:517,t:1526933608857};\\\", \\\"{x:1502,y:492,t:1526933608873};\\\", \\\"{x:1502,y:477,t:1526933608890};\\\", \\\"{x:1506,y:468,t:1526933608906};\\\", \\\"{x:1509,y:459,t:1526933608924};\\\", \\\"{x:1512,y:452,t:1526933608940};\\\", \\\"{x:1515,y:449,t:1526933608957};\\\", \\\"{x:1518,y:447,t:1526933608974};\\\", \\\"{x:1524,y:443,t:1526933608991};\\\", \\\"{x:1527,y:442,t:1526933609007};\\\", \\\"{x:1534,y:438,t:1526933609024};\\\", \\\"{x:1537,y:437,t:1526933609040};\\\", \\\"{x:1543,y:435,t:1526933609056};\\\", \\\"{x:1549,y:433,t:1526933609074};\\\", \\\"{x:1550,y:432,t:1526933609090};\\\", \\\"{x:1550,y:431,t:1526933609145};\\\", \\\"{x:1555,y:434,t:1526933609156};\\\", \\\"{x:1564,y:447,t:1526933609174};\\\", \\\"{x:1573,y:465,t:1526933609190};\\\", \\\"{x:1579,y:479,t:1526933609206};\\\", \\\"{x:1583,y:491,t:1526933609225};\\\", \\\"{x:1584,y:503,t:1526933609241};\\\", \\\"{x:1587,y:529,t:1526933609257};\\\", \\\"{x:1589,y:551,t:1526933609274};\\\", \\\"{x:1589,y:571,t:1526933609291};\\\", \\\"{x:1589,y:589,t:1526933609308};\\\", \\\"{x:1589,y:612,t:1526933609324};\\\", \\\"{x:1586,y:634,t:1526933609341};\\\", \\\"{x:1584,y:648,t:1526933609358};\\\", \\\"{x:1582,y:661,t:1526933609374};\\\", \\\"{x:1579,y:674,t:1526933609391};\\\", \\\"{x:1578,y:682,t:1526933609407};\\\", \\\"{x:1577,y:687,t:1526933609423};\\\", \\\"{x:1575,y:691,t:1526933609441};\\\", \\\"{x:1569,y:700,t:1526933609456};\\\", \\\"{x:1568,y:705,t:1526933609473};\\\", \\\"{x:1566,y:706,t:1526933609491};\\\", \\\"{x:1565,y:707,t:1526933609508};\\\", \\\"{x:1563,y:709,t:1526933609524};\\\", \\\"{x:1555,y:714,t:1526933609541};\\\", \\\"{x:1550,y:717,t:1526933609557};\\\", \\\"{x:1547,y:717,t:1526933609573};\\\", \\\"{x:1543,y:718,t:1526933609590};\\\", \\\"{x:1539,y:718,t:1526933609607};\\\", \\\"{x:1532,y:718,t:1526933609624};\\\", \\\"{x:1525,y:719,t:1526933609641};\\\", \\\"{x:1511,y:719,t:1526933609657};\\\", \\\"{x:1501,y:719,t:1526933609675};\\\", \\\"{x:1487,y:721,t:1526933609690};\\\", \\\"{x:1477,y:721,t:1526933609708};\\\", \\\"{x:1470,y:721,t:1526933609725};\\\", \\\"{x:1454,y:719,t:1526933609740};\\\", \\\"{x:1444,y:717,t:1526933609757};\\\", \\\"{x:1436,y:717,t:1526933609775};\\\", \\\"{x:1423,y:717,t:1526933609790};\\\", \\\"{x:1413,y:715,t:1526933609807};\\\", \\\"{x:1398,y:715,t:1526933609824};\\\", \\\"{x:1383,y:715,t:1526933609841};\\\", \\\"{x:1370,y:715,t:1526933609857};\\\", \\\"{x:1367,y:715,t:1526933609874};\\\", \\\"{x:1363,y:717,t:1526933609913};\\\", \\\"{x:1361,y:718,t:1526933609929};\\\", \\\"{x:1358,y:721,t:1526933609941};\\\", \\\"{x:1352,y:726,t:1526933609958};\\\", \\\"{x:1344,y:731,t:1526933609975};\\\", \\\"{x:1338,y:737,t:1526933609990};\\\", \\\"{x:1331,y:744,t:1526933610007};\\\", \\\"{x:1327,y:751,t:1526933610025};\\\", \\\"{x:1324,y:756,t:1526933610040};\\\", \\\"{x:1319,y:765,t:1526933610058};\\\", \\\"{x:1318,y:771,t:1526933610075};\\\", \\\"{x:1315,y:774,t:1526933610091};\\\", \\\"{x:1314,y:777,t:1526933610107};\\\", \\\"{x:1312,y:782,t:1526933610124};\\\", \\\"{x:1311,y:783,t:1526933610142};\\\", \\\"{x:1308,y:788,t:1526933610157};\\\", \\\"{x:1308,y:792,t:1526933610174};\\\", \\\"{x:1304,y:797,t:1526933610191};\\\", \\\"{x:1301,y:802,t:1526933610207};\\\", \\\"{x:1299,y:804,t:1526933610225};\\\", \\\"{x:1295,y:807,t:1526933610241};\\\", \\\"{x:1294,y:809,t:1526933610258};\\\", \\\"{x:1290,y:811,t:1526933610281};\\\", \\\"{x:1289,y:811,t:1526933610297};\\\", \\\"{x:1286,y:811,t:1526933610308};\\\", \\\"{x:1279,y:811,t:1526933610325};\\\", \\\"{x:1274,y:811,t:1526933610342};\\\", \\\"{x:1270,y:811,t:1526933610357};\\\", \\\"{x:1267,y:811,t:1526933610375};\\\", \\\"{x:1263,y:812,t:1526933610391};\\\", \\\"{x:1261,y:812,t:1526933610408};\\\", \\\"{x:1258,y:813,t:1526933610424};\\\", \\\"{x:1253,y:815,t:1526933610441};\\\", \\\"{x:1250,y:817,t:1526933610458};\\\", \\\"{x:1247,y:820,t:1526933610475};\\\", \\\"{x:1244,y:822,t:1526933610491};\\\", \\\"{x:1241,y:824,t:1526933610507};\\\", \\\"{x:1237,y:827,t:1526933610525};\\\", \\\"{x:1233,y:830,t:1526933610541};\\\", \\\"{x:1232,y:830,t:1526933610557};\\\", \\\"{x:1229,y:831,t:1526933610689};\\\", \\\"{x:1228,y:831,t:1526933610697};\\\", \\\"{x:1226,y:832,t:1526933610708};\\\", \\\"{x:1225,y:832,t:1526933610725};\\\", \\\"{x:1223,y:833,t:1526933610742};\\\", \\\"{x:1220,y:834,t:1526933610758};\\\", \\\"{x:1219,y:834,t:1526933610774};\\\", \\\"{x:1218,y:834,t:1526933610791};\\\", \\\"{x:1216,y:834,t:1526933610897};\\\", \\\"{x:1215,y:835,t:1526933610945};\\\", \\\"{x:1214,y:835,t:1526933610969};\\\", \\\"{x:1213,y:835,t:1526933610977};\\\", \\\"{x:1213,y:836,t:1526933611001};\\\", \\\"{x:1212,y:836,t:1526933611009};\\\", \\\"{x:1212,y:837,t:1526933611026};\\\", \\\"{x:1210,y:837,t:1526933611048};\\\", \\\"{x:1209,y:838,t:1526933611097};\\\", \\\"{x:1211,y:837,t:1526933612945};\\\", \\\"{x:1212,y:837,t:1526933612985};\\\", \\\"{x:1213,y:836,t:1526933613017};\\\", \\\"{x:1214,y:836,t:1526933613065};\\\", \\\"{x:1215,y:836,t:1526933613081};\\\", \\\"{x:1216,y:835,t:1526933613094};\\\", \\\"{x:1218,y:834,t:1526933613127};\\\", \\\"{x:1219,y:833,t:1526933613168};\\\", \\\"{x:1221,y:833,t:1526933613514};\\\", \\\"{x:1222,y:833,t:1526933613526};\\\", \\\"{x:1223,y:833,t:1526933613543};\\\", \\\"{x:1223,y:831,t:1526933613649};\\\", \\\"{x:1222,y:831,t:1526933614130};\\\", \\\"{x:1221,y:832,t:1526933614161};\\\", \\\"{x:1220,y:832,t:1526933614184};\\\", \\\"{x:1219,y:832,t:1526933614195};\\\", \\\"{x:1219,y:833,t:1526933614211};\\\", \\\"{x:1218,y:833,t:1526933614232};\\\", \\\"{x:1217,y:833,t:1526933614249};\\\", \\\"{x:1216,y:834,t:1526933614260};\\\", \\\"{x:1214,y:835,t:1526933614345};\\\", \\\"{x:1213,y:835,t:1526933617033};\\\", \\\"{x:1212,y:834,t:1526933617056};\\\", \\\"{x:1210,y:831,t:1526933617065};\\\", \\\"{x:1209,y:830,t:1526933617081};\\\", \\\"{x:1208,y:828,t:1526933617097};\\\", \\\"{x:1204,y:824,t:1526933617113};\\\", \\\"{x:1201,y:822,t:1526933617130};\\\", \\\"{x:1199,y:820,t:1526933617147};\\\", \\\"{x:1198,y:818,t:1526933617163};\\\", \\\"{x:1196,y:815,t:1526933617180};\\\", \\\"{x:1195,y:813,t:1526933617197};\\\", \\\"{x:1194,y:810,t:1526933617213};\\\", \\\"{x:1193,y:807,t:1526933617230};\\\", \\\"{x:1191,y:802,t:1526933617247};\\\", \\\"{x:1188,y:797,t:1526933617264};\\\", \\\"{x:1187,y:795,t:1526933617280};\\\", \\\"{x:1184,y:790,t:1526933617297};\\\", \\\"{x:1184,y:787,t:1526933617314};\\\", \\\"{x:1183,y:786,t:1526933617330};\\\", \\\"{x:1182,y:783,t:1526933617347};\\\", \\\"{x:1181,y:781,t:1526933617368};\\\", \\\"{x:1181,y:780,t:1526933617433};\\\", \\\"{x:1180,y:779,t:1526933617449};\\\", \\\"{x:1180,y:777,t:1526933617465};\\\", \\\"{x:1180,y:775,t:1526933617480};\\\", \\\"{x:1179,y:773,t:1526933617497};\\\", \\\"{x:1179,y:772,t:1526933619473};\\\", \\\"{x:1180,y:772,t:1526933620802};\\\", \\\"{x:1181,y:772,t:1526933621034};\\\", \\\"{x:1181,y:771,t:1526933621129};\\\", \\\"{x:1182,y:771,t:1526933621136};\\\", \\\"{x:1183,y:771,t:1526933621185};\\\", \\\"{x:1184,y:771,t:1526933621417};\\\", \\\"{x:1184,y:772,t:1526933621473};\\\", \\\"{x:1184,y:773,t:1526933621785};\\\", \\\"{x:1184,y:775,t:1526933621801};\\\", \\\"{x:1184,y:776,t:1526933621825};\\\", \\\"{x:1184,y:778,t:1526933621857};\\\", \\\"{x:1184,y:779,t:1526933621873};\\\", \\\"{x:1184,y:782,t:1526933621889};\\\", \\\"{x:1184,y:786,t:1526933621905};\\\", \\\"{x:1184,y:788,t:1526933621929};\\\", \\\"{x:1183,y:789,t:1526933621945};\\\", \\\"{x:1183,y:790,t:1526933621953};\\\", \\\"{x:1183,y:792,t:1526933621967};\\\", \\\"{x:1183,y:795,t:1526933621984};\\\", \\\"{x:1182,y:801,t:1526933622000};\\\", \\\"{x:1181,y:807,t:1526933622017};\\\", \\\"{x:1180,y:813,t:1526933622034};\\\", \\\"{x:1179,y:820,t:1526933622050};\\\", \\\"{x:1179,y:825,t:1526933622067};\\\", \\\"{x:1177,y:830,t:1526933622084};\\\", \\\"{x:1176,y:832,t:1526933622101};\\\", \\\"{x:1176,y:833,t:1526933622117};\\\", \\\"{x:1176,y:834,t:1526933622161};\\\", \\\"{x:1176,y:835,t:1526933622353};\\\", \\\"{x:1176,y:834,t:1526933622367};\\\", \\\"{x:1178,y:828,t:1526933622384};\\\", \\\"{x:1180,y:820,t:1526933622401};\\\", \\\"{x:1181,y:816,t:1526933622417};\\\", \\\"{x:1182,y:811,t:1526933622434};\\\", \\\"{x:1182,y:810,t:1526933622451};\\\", \\\"{x:1182,y:809,t:1526933622468};\\\", \\\"{x:1183,y:806,t:1526933622484};\\\", \\\"{x:1183,y:804,t:1526933622502};\\\", \\\"{x:1184,y:803,t:1526933622518};\\\", \\\"{x:1184,y:801,t:1526933622534};\\\", \\\"{x:1184,y:798,t:1526933622551};\\\", \\\"{x:1184,y:789,t:1526933622568};\\\", \\\"{x:1184,y:784,t:1526933622584};\\\", \\\"{x:1186,y:777,t:1526933622601};\\\", \\\"{x:1186,y:776,t:1526933622618};\\\", \\\"{x:1186,y:773,t:1526933622635};\\\", \\\"{x:1186,y:772,t:1526933622651};\\\", \\\"{x:1186,y:770,t:1526933622668};\\\", \\\"{x:1185,y:768,t:1526933622684};\\\", \\\"{x:1185,y:767,t:1526933622701};\\\", \\\"{x:1185,y:765,t:1526933622719};\\\", \\\"{x:1185,y:764,t:1526933624761};\\\", \\\"{x:1186,y:763,t:1526933624777};\\\", \\\"{x:1187,y:763,t:1526933624825};\\\", \\\"{x:1189,y:762,t:1526933624969};\\\", \\\"{x:1193,y:761,t:1526933624986};\\\", \\\"{x:1198,y:761,t:1526933625003};\\\", \\\"{x:1203,y:760,t:1526933625019};\\\", \\\"{x:1208,y:760,t:1526933625036};\\\", \\\"{x:1216,y:759,t:1526933625054};\\\", \\\"{x:1219,y:758,t:1526933625069};\\\", \\\"{x:1222,y:758,t:1526933625086};\\\", \\\"{x:1225,y:758,t:1526933625103};\\\", \\\"{x:1227,y:758,t:1526933625120};\\\", \\\"{x:1232,y:758,t:1526933625136};\\\", \\\"{x:1240,y:758,t:1526933625152};\\\", \\\"{x:1242,y:758,t:1526933625170};\\\", \\\"{x:1247,y:758,t:1526933625186};\\\", \\\"{x:1249,y:758,t:1526933625203};\\\", \\\"{x:1251,y:758,t:1526933625220};\\\", \\\"{x:1252,y:758,t:1526933625237};\\\", \\\"{x:1254,y:758,t:1526933625253};\\\", \\\"{x:1255,y:758,t:1526933625270};\\\", \\\"{x:1257,y:758,t:1526933625393};\\\", \\\"{x:1257,y:759,t:1526933625441};\\\", \\\"{x:1257,y:760,t:1526933625454};\\\", \\\"{x:1257,y:761,t:1526933625470};\\\", \\\"{x:1257,y:762,t:1526933625487};\\\", \\\"{x:1256,y:762,t:1526933625537};\\\", \\\"{x:1255,y:762,t:1526933625553};\\\", \\\"{x:1254,y:763,t:1526933625593};\\\", \\\"{x:1253,y:763,t:1526933625608};\\\", \\\"{x:1253,y:764,t:1526933625633};\\\", \\\"{x:1252,y:764,t:1526933625665};\\\", \\\"{x:1251,y:765,t:1526933625681};\\\", \\\"{x:1250,y:765,t:1526933625729};\\\", \\\"{x:1248,y:767,t:1526933626433};\\\", \\\"{x:1245,y:768,t:1526933628314};\\\", \\\"{x:1242,y:768,t:1526933628322};\\\", \\\"{x:1228,y:768,t:1526933628340};\\\", \\\"{x:1220,y:768,t:1526933628356};\\\", \\\"{x:1211,y:768,t:1526933628373};\\\", \\\"{x:1207,y:768,t:1526933628389};\\\", \\\"{x:1203,y:768,t:1526933628406};\\\", \\\"{x:1201,y:768,t:1526933628449};\\\", \\\"{x:1200,y:768,t:1526933628457};\\\", \\\"{x:1196,y:769,t:1526933628473};\\\", \\\"{x:1195,y:769,t:1526933628489};\\\", \\\"{x:1192,y:769,t:1526933628505};\\\", \\\"{x:1190,y:770,t:1526933628522};\\\", \\\"{x:1189,y:771,t:1526933628539};\\\", \\\"{x:1188,y:771,t:1526933628569};\\\", \\\"{x:1187,y:771,t:1526933628577};\\\", \\\"{x:1186,y:771,t:1526933628589};\\\", \\\"{x:1185,y:771,t:1526933628606};\\\", \\\"{x:1183,y:771,t:1526933628622};\\\", \\\"{x:1182,y:771,t:1526933628649};\\\", \\\"{x:1181,y:771,t:1526933628841};\\\", \\\"{x:1180,y:771,t:1526933628881};\\\", \\\"{x:1180,y:770,t:1526933628929};\\\", \\\"{x:1180,y:769,t:1526933629009};\\\", \\\"{x:1181,y:769,t:1526933629022};\\\", \\\"{x:1185,y:769,t:1526933629040};\\\", \\\"{x:1193,y:769,t:1526933629057};\\\", \\\"{x:1196,y:769,t:1526933629072};\\\", \\\"{x:1205,y:769,t:1526933629089};\\\", \\\"{x:1209,y:767,t:1526933629106};\\\", \\\"{x:1213,y:767,t:1526933629124};\\\", \\\"{x:1216,y:767,t:1526933629139};\\\", \\\"{x:1217,y:767,t:1526933629156};\\\", \\\"{x:1218,y:767,t:1526933629174};\\\", \\\"{x:1219,y:767,t:1526933629193};\\\", \\\"{x:1220,y:767,t:1526933629207};\\\", \\\"{x:1221,y:767,t:1526933629224};\\\", \\\"{x:1224,y:767,t:1526933629239};\\\", \\\"{x:1226,y:767,t:1526933629256};\\\", \\\"{x:1229,y:767,t:1526933629273};\\\", \\\"{x:1231,y:767,t:1526933629297};\\\", \\\"{x:1232,y:767,t:1526933629307};\\\", \\\"{x:1233,y:767,t:1526933629323};\\\", \\\"{x:1236,y:766,t:1526933629339};\\\", \\\"{x:1238,y:766,t:1526933629357};\\\", \\\"{x:1242,y:764,t:1526933629373};\\\", \\\"{x:1243,y:764,t:1526933629389};\\\", \\\"{x:1244,y:764,t:1526933629406};\\\", \\\"{x:1245,y:763,t:1526933629449};\\\", \\\"{x:1246,y:763,t:1526933629465};\\\", \\\"{x:1247,y:762,t:1526933630649};\\\", \\\"{x:1249,y:762,t:1526933630753};\\\", \\\"{x:1250,y:762,t:1526933630760};\\\", \\\"{x:1251,y:762,t:1526933630777};\\\", \\\"{x:1252,y:762,t:1526933630790};\\\", \\\"{x:1255,y:762,t:1526933630807};\\\", \\\"{x:1257,y:763,t:1526933630825};\\\", \\\"{x:1259,y:764,t:1526933630841};\\\", \\\"{x:1260,y:765,t:1526933630858};\\\", \\\"{x:1261,y:765,t:1526933630937};\\\", \\\"{x:1263,y:765,t:1526933630952};\\\", \\\"{x:1264,y:765,t:1526933630977};\\\", \\\"{x:1267,y:765,t:1526933630991};\\\", \\\"{x:1268,y:765,t:1526933631007};\\\", \\\"{x:1271,y:765,t:1526933631025};\\\", \\\"{x:1272,y:765,t:1526933631042};\\\", \\\"{x:1273,y:765,t:1526933631073};\\\", \\\"{x:1274,y:765,t:1526933631145};\\\", \\\"{x:1275,y:765,t:1526933631158};\\\", \\\"{x:1276,y:766,t:1526933631175};\\\", \\\"{x:1278,y:766,t:1526933631192};\\\", \\\"{x:1279,y:767,t:1526933631207};\\\", \\\"{x:1281,y:768,t:1526933631225};\\\", \\\"{x:1282,y:768,t:1526933631242};\\\", \\\"{x:1284,y:768,t:1526933631257};\\\", \\\"{x:1285,y:768,t:1526933631275};\\\", \\\"{x:1286,y:768,t:1526933631497};\\\", \\\"{x:1288,y:768,t:1526933631509};\\\", \\\"{x:1293,y:768,t:1526933631525};\\\", \\\"{x:1299,y:768,t:1526933631542};\\\", \\\"{x:1303,y:768,t:1526933631559};\\\", \\\"{x:1305,y:768,t:1526933631574};\\\", \\\"{x:1306,y:768,t:1526933631591};\\\", \\\"{x:1308,y:768,t:1526933631609};\\\", \\\"{x:1309,y:768,t:1526933631640};\\\", \\\"{x:1310,y:768,t:1526933631657};\\\", \\\"{x:1312,y:768,t:1526933631665};\\\", \\\"{x:1313,y:768,t:1526933631681};\\\", \\\"{x:1316,y:768,t:1526933631697};\\\", \\\"{x:1317,y:768,t:1526933631708};\\\", \\\"{x:1319,y:768,t:1526933631725};\\\", \\\"{x:1323,y:768,t:1526933631742};\\\", \\\"{x:1325,y:768,t:1526933631759};\\\", \\\"{x:1326,y:768,t:1526933631775};\\\", \\\"{x:1327,y:768,t:1526933637561};\\\", \\\"{x:1327,y:769,t:1526933637569};\\\", \\\"{x:1327,y:770,t:1526933637579};\\\", \\\"{x:1327,y:772,t:1526933637596};\\\", \\\"{x:1326,y:775,t:1526933637612};\\\", \\\"{x:1325,y:777,t:1526933637630};\\\", \\\"{x:1323,y:779,t:1526933637647};\\\", \\\"{x:1320,y:782,t:1526933637663};\\\", \\\"{x:1318,y:784,t:1526933637679};\\\", \\\"{x:1311,y:789,t:1526933637696};\\\", \\\"{x:1307,y:791,t:1526933637713};\\\", \\\"{x:1307,y:792,t:1526933637730};\\\", \\\"{x:1304,y:792,t:1526933637747};\\\", \\\"{x:1300,y:795,t:1526933637762};\\\", \\\"{x:1296,y:798,t:1526933637780};\\\", \\\"{x:1295,y:798,t:1526933637797};\\\", \\\"{x:1293,y:799,t:1526933637824};\\\", \\\"{x:1291,y:800,t:1526933637832};\\\", \\\"{x:1290,y:800,t:1526933637847};\\\", \\\"{x:1290,y:801,t:1526933637863};\\\", \\\"{x:1286,y:802,t:1526933637880};\\\", \\\"{x:1284,y:803,t:1526933637897};\\\", \\\"{x:1282,y:804,t:1526933637913};\\\", \\\"{x:1280,y:806,t:1526933637929};\\\", \\\"{x:1277,y:808,t:1526933637947};\\\", \\\"{x:1274,y:809,t:1526933637963};\\\", \\\"{x:1268,y:812,t:1526933637980};\\\", \\\"{x:1265,y:813,t:1526933637997};\\\", \\\"{x:1261,y:815,t:1526933638014};\\\", \\\"{x:1257,y:817,t:1526933638030};\\\", \\\"{x:1254,y:818,t:1526933638046};\\\", \\\"{x:1253,y:819,t:1526933638063};\\\", \\\"{x:1251,y:820,t:1526933638177};\\\", \\\"{x:1250,y:820,t:1526933638192};\\\", \\\"{x:1249,y:820,t:1526933638217};\\\", \\\"{x:1247,y:820,t:1526933638232};\\\", \\\"{x:1244,y:820,t:1526933638246};\\\", \\\"{x:1242,y:820,t:1526933638264};\\\", \\\"{x:1241,y:820,t:1526933638279};\\\", \\\"{x:1240,y:820,t:1526933638296};\\\", \\\"{x:1238,y:820,t:1526933638320};\\\", \\\"{x:1235,y:820,t:1526933638337};\\\", \\\"{x:1233,y:820,t:1526933638417};\\\", \\\"{x:1231,y:820,t:1526933638433};\\\", \\\"{x:1230,y:820,t:1526933638446};\\\", \\\"{x:1229,y:820,t:1526933638464};\\\", \\\"{x:1228,y:820,t:1526933638480};\\\", \\\"{x:1227,y:820,t:1526933638497};\\\", \\\"{x:1226,y:820,t:1526933638514};\\\", \\\"{x:1225,y:821,t:1526933638536};\\\", \\\"{x:1224,y:821,t:1526933638577};\\\", \\\"{x:1223,y:823,t:1526933638592};\\\", \\\"{x:1222,y:823,t:1526933638609};\\\", \\\"{x:1221,y:824,t:1526933638657};\\\", \\\"{x:1221,y:825,t:1526933638680};\\\", \\\"{x:1220,y:826,t:1526933638705};\\\", \\\"{x:1220,y:828,t:1526933638714};\\\", \\\"{x:1219,y:830,t:1526933638825};\\\", \\\"{x:1218,y:831,t:1526933639105};\\\", \\\"{x:1217,y:831,t:1526933640001};\\\", \\\"{x:1217,y:832,t:1526933640015};\\\", \\\"{x:1217,y:830,t:1526933643376};\\\", \\\"{x:1217,y:828,t:1526933643387};\\\", \\\"{x:1216,y:818,t:1526933643404};\\\", \\\"{x:1212,y:812,t:1526933643420};\\\", \\\"{x:1211,y:807,t:1526933643438};\\\", \\\"{x:1208,y:801,t:1526933643453};\\\", \\\"{x:1206,y:798,t:1526933643470};\\\", \\\"{x:1206,y:797,t:1526933643488};\\\", \\\"{x:1206,y:794,t:1526933643504};\\\", \\\"{x:1206,y:793,t:1526933643521};\\\", \\\"{x:1205,y:789,t:1526933643537};\\\", \\\"{x:1204,y:786,t:1526933643554};\\\", \\\"{x:1203,y:782,t:1526933643571};\\\", \\\"{x:1202,y:779,t:1526933643587};\\\", \\\"{x:1202,y:776,t:1526933643604};\\\", \\\"{x:1200,y:774,t:1526933643621};\\\", \\\"{x:1200,y:773,t:1526933643638};\\\", \\\"{x:1199,y:771,t:1526933643654};\\\", \\\"{x:1198,y:770,t:1526933643673};\\\", \\\"{x:1197,y:769,t:1526933643688};\\\", \\\"{x:1197,y:768,t:1526933643704};\\\", \\\"{x:1195,y:768,t:1526933643721};\\\", \\\"{x:1195,y:767,t:1526933643738};\\\", \\\"{x:1194,y:766,t:1526933643755};\\\", \\\"{x:1194,y:765,t:1526933643809};\\\", \\\"{x:1194,y:764,t:1526933644128};\\\", \\\"{x:1196,y:764,t:1526933644193};\\\", \\\"{x:1197,y:764,t:1526933644216};\\\", \\\"{x:1199,y:764,t:1526933644232};\\\", \\\"{x:1201,y:764,t:1526933644273};\\\", \\\"{x:1202,y:764,t:1526933644288};\\\", \\\"{x:1203,y:764,t:1526933644304};\\\", \\\"{x:1204,y:764,t:1526933644322};\\\", \\\"{x:1206,y:764,t:1526933644338};\\\", \\\"{x:1208,y:764,t:1526933644354};\\\", \\\"{x:1209,y:764,t:1526933644372};\\\", \\\"{x:1211,y:764,t:1526933644388};\\\", \\\"{x:1216,y:765,t:1526933644405};\\\", \\\"{x:1218,y:765,t:1526933644421};\\\", \\\"{x:1222,y:766,t:1526933644438};\\\", \\\"{x:1227,y:767,t:1526933644455};\\\", \\\"{x:1232,y:768,t:1526933644473};\\\", \\\"{x:1243,y:770,t:1526933644488};\\\", \\\"{x:1249,y:772,t:1526933644505};\\\", \\\"{x:1255,y:773,t:1526933644522};\\\", \\\"{x:1262,y:774,t:1526933644538};\\\", \\\"{x:1266,y:775,t:1526933644554};\\\", \\\"{x:1270,y:775,t:1526933644572};\\\", \\\"{x:1275,y:776,t:1526933644588};\\\", \\\"{x:1282,y:776,t:1526933644604};\\\", \\\"{x:1287,y:778,t:1526933644622};\\\", \\\"{x:1294,y:779,t:1526933644639};\\\", \\\"{x:1297,y:780,t:1526933644655};\\\", \\\"{x:1299,y:780,t:1526933644672};\\\", \\\"{x:1302,y:780,t:1526933644689};\\\", \\\"{x:1303,y:780,t:1526933644721};\\\", \\\"{x:1306,y:780,t:1526933644728};\\\", \\\"{x:1307,y:780,t:1526933644744};\\\", \\\"{x:1310,y:780,t:1526933644755};\\\", \\\"{x:1314,y:782,t:1526933644772};\\\", \\\"{x:1316,y:782,t:1526933644788};\\\", \\\"{x:1318,y:782,t:1526933644805};\\\", \\\"{x:1323,y:782,t:1526933644822};\\\", \\\"{x:1327,y:782,t:1526933644839};\\\", \\\"{x:1333,y:782,t:1526933644855};\\\", \\\"{x:1339,y:782,t:1526933644872};\\\", \\\"{x:1346,y:781,t:1526933644888};\\\", \\\"{x:1348,y:780,t:1526933644906};\\\", \\\"{x:1349,y:779,t:1526933644928};\\\", \\\"{x:1350,y:778,t:1526933645049};\\\", \\\"{x:1350,y:777,t:1526933645297};\\\", \\\"{x:1350,y:776,t:1526933645305};\\\", \\\"{x:1350,y:775,t:1526933645322};\\\", \\\"{x:1350,y:773,t:1526933645339};\\\", \\\"{x:1350,y:772,t:1526933645356};\\\", \\\"{x:1350,y:770,t:1526933645373};\\\", \\\"{x:1350,y:769,t:1526933645389};\\\", \\\"{x:1350,y:768,t:1526933645406};\\\", \\\"{x:1350,y:767,t:1526933645439};\\\", \\\"{x:1350,y:766,t:1526933645456};\\\", \\\"{x:1349,y:764,t:1526933645472};\\\", \\\"{x:1347,y:762,t:1526933645489};\\\", \\\"{x:1335,y:760,t:1526933645506};\\\", \\\"{x:1311,y:755,t:1526933645523};\\\", \\\"{x:1301,y:749,t:1526933645538};\\\", \\\"{x:1290,y:743,t:1526933645556};\\\", \\\"{x:1208,y:735,t:1526933645573};\\\", \\\"{x:1187,y:729,t:1526933645589};\\\", \\\"{x:1110,y:712,t:1526933645606};\\\", \\\"{x:1083,y:698,t:1526933645623};\\\", \\\"{x:1071,y:689,t:1526933645639};\\\", \\\"{x:1050,y:679,t:1526933645656};\\\", \\\"{x:1048,y:673,t:1526933645672};\\\", \\\"{x:1045,y:673,t:1526933646168};\\\", \\\"{x:1040,y:669,t:1526933646176};\\\", \\\"{x:1028,y:661,t:1526933646190};\\\", \\\"{x:998,y:645,t:1526933646206};\\\", \\\"{x:957,y:622,t:1526933646223};\\\", \\\"{x:771,y:563,t:1526933646241};\\\", \\\"{x:585,y:532,t:1526933646256};\\\", \\\"{x:364,y:501,t:1526933646273};\\\", \\\"{x:249,y:473,t:1526933646284};\\\", \\\"{x:8,y:433,t:1526933646301};\\\", \\\"{x:8,y:378,t:1526933646324};\\\", \\\"{x:8,y:329,t:1526933646341};\\\", \\\"{x:8,y:293,t:1526933646357};\\\", \\\"{x:8,y:269,t:1526933646374};\\\", \\\"{x:8,y:253,t:1526933646391};\\\", \\\"{x:8,y:248,t:1526933646408};\\\", \\\"{x:11,y:250,t:1526933646480};\\\", \\\"{x:17,y:255,t:1526933646490};\\\", \\\"{x:28,y:268,t:1526933646508};\\\", \\\"{x:55,y:288,t:1526933646525};\\\", \\\"{x:94,y:312,t:1526933646541};\\\", \\\"{x:128,y:335,t:1526933646558};\\\", \\\"{x:145,y:350,t:1526933646575};\\\", \\\"{x:168,y:371,t:1526933646591};\\\", \\\"{x:178,y:385,t:1526933646607};\\\", \\\"{x:179,y:397,t:1526933646624};\\\", \\\"{x:179,y:408,t:1526933646641};\\\", \\\"{x:177,y:418,t:1526933646657};\\\", \\\"{x:168,y:425,t:1526933646674};\\\", \\\"{x:157,y:433,t:1526933646691};\\\", \\\"{x:141,y:444,t:1526933646708};\\\", \\\"{x:121,y:457,t:1526933646725};\\\", \\\"{x:110,y:468,t:1526933646741};\\\", \\\"{x:103,y:483,t:1526933646758};\\\", \\\"{x:99,y:491,t:1526933646776};\\\", \\\"{x:99,y:495,t:1526933646791};\\\", \\\"{x:99,y:497,t:1526933646806};\\\", \\\"{x:99,y:507,t:1526933646824};\\\", \\\"{x:99,y:518,t:1526933646841};\\\", \\\"{x:99,y:533,t:1526933646857};\\\", \\\"{x:99,y:540,t:1526933646875};\\\", \\\"{x:100,y:541,t:1526933646890};\\\", \\\"{x:100,y:542,t:1526933646908};\\\", \\\"{x:101,y:543,t:1526933647001};\\\", \\\"{x:102,y:543,t:1526933647017};\\\", \\\"{x:106,y:543,t:1526933647025};\\\", \\\"{x:115,y:541,t:1526933647042};\\\", \\\"{x:121,y:537,t:1526933647058};\\\", \\\"{x:126,y:533,t:1526933647075};\\\", \\\"{x:134,y:532,t:1526933647092};\\\", \\\"{x:138,y:530,t:1526933647108};\\\", \\\"{x:140,y:528,t:1526933647125};\\\", \\\"{x:141,y:528,t:1526933647256};\\\", \\\"{x:143,y:526,t:1526933647264};\\\", \\\"{x:144,y:526,t:1526933647275};\\\", \\\"{x:145,y:523,t:1526933647292};\\\", \\\"{x:149,y:519,t:1526933647308};\\\", \\\"{x:150,y:518,t:1526933647325};\\\", \\\"{x:153,y:515,t:1526933647342};\\\", \\\"{x:155,y:514,t:1526933647358};\\\", \\\"{x:157,y:511,t:1526933647375};\\\", \\\"{x:160,y:509,t:1526933647392};\\\", \\\"{x:162,y:506,t:1526933647408};\\\", \\\"{x:165,y:505,t:1526933648225};\\\", \\\"{x:173,y:513,t:1526933648232};\\\", \\\"{x:177,y:522,t:1526933648243};\\\", \\\"{x:191,y:541,t:1526933648259};\\\", \\\"{x:212,y:568,t:1526933648277};\\\", \\\"{x:236,y:596,t:1526933648293};\\\", \\\"{x:266,y:625,t:1526933648309};\\\", \\\"{x:301,y:651,t:1526933648327};\\\", \\\"{x:349,y:684,t:1526933648343};\\\", \\\"{x:388,y:711,t:1526933648359};\\\", \\\"{x:410,y:725,t:1526933648376};\\\", \\\"{x:441,y:750,t:1526933648393};\\\", \\\"{x:472,y:766,t:1526933648409};\\\", \\\"{x:499,y:780,t:1526933648426};\\\", \\\"{x:521,y:792,t:1526933648443};\\\", \\\"{x:542,y:805,t:1526933648459};\\\", \\\"{x:562,y:816,t:1526933648476};\\\", \\\"{x:577,y:823,t:1526933648493};\\\", \\\"{x:591,y:830,t:1526933648509};\\\", \\\"{x:596,y:834,t:1526933648526};\\\", \\\"{x:605,y:841,t:1526933648543};\\\", \\\"{x:609,y:846,t:1526933648559};\\\", \\\"{x:613,y:848,t:1526933648576};\\\", \\\"{x:616,y:849,t:1526933648593};\\\", \\\"{x:616,y:850,t:1526933648688};\\\", \\\"{x:615,y:850,t:1526933648696};\\\", \\\"{x:613,y:850,t:1526933648709};\\\", \\\"{x:603,y:850,t:1526933648726};\\\", \\\"{x:593,y:845,t:1526933648743};\\\", \\\"{x:576,y:838,t:1526933648759};\\\", \\\"{x:563,y:833,t:1526933648776};\\\", \\\"{x:551,y:827,t:1526933648792};\\\", \\\"{x:546,y:824,t:1526933648810};\\\", \\\"{x:544,y:822,t:1526933648826};\\\", \\\"{x:535,y:815,t:1526933648843};\\\", \\\"{x:528,y:810,t:1526933648860};\\\", \\\"{x:513,y:796,t:1526933648876};\\\", \\\"{x:504,y:785,t:1526933648893};\\\", \\\"{x:499,y:780,t:1526933648910};\\\", \\\"{x:494,y:775,t:1526933648926};\\\", \\\"{x:490,y:771,t:1526933648943};\\\", \\\"{x:489,y:769,t:1526933648960};\\\", \\\"{x:487,y:765,t:1526933648976};\\\", \\\"{x:487,y:763,t:1526933648993};\\\", \\\"{x:486,y:761,t:1526933649010};\\\", \\\"{x:486,y:759,t:1526933649026};\\\", \\\"{x:486,y:758,t:1526933649048};\\\", \\\"{x:486,y:756,t:1526933649064};\\\", \\\"{x:486,y:755,t:1526933649080};\\\", \\\"{x:486,y:753,t:1526933649097};\\\", \\\"{x:486,y:751,t:1526933649110};\\\", \\\"{x:488,y:748,t:1526933649126};\\\", \\\"{x:492,y:745,t:1526933649142};\\\", \\\"{x:495,y:745,t:1526933649160};\\\", \\\"{x:495,y:744,t:1526933649176};\\\" ] }, { \\\"rt\\\": 94216, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 584105, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -O -Z -F -E -E -E -X -B -B -B -A -E -B -B -B -11 AM-12 PM-B -O -M -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:743,t:1526933652713};\\\", \\\"{x:499,y:742,t:1526933652737};\\\", \\\"{x:499,y:741,t:1526933652760};\\\", \\\"{x:501,y:741,t:1526933652768};\\\", \\\"{x:505,y:738,t:1526933652782};\\\", \\\"{x:521,y:730,t:1526933652799};\\\", \\\"{x:553,y:718,t:1526933652815};\\\", \\\"{x:579,y:696,t:1526933652833};\\\", \\\"{x:594,y:684,t:1526933652849};\\\", \\\"{x:608,y:674,t:1526933652863};\\\", \\\"{x:661,y:657,t:1526933652880};\\\", \\\"{x:691,y:649,t:1526933652897};\\\", \\\"{x:713,y:643,t:1526933652914};\\\", \\\"{x:757,y:633,t:1526933652930};\\\", \\\"{x:807,y:627,t:1526933652947};\\\", \\\"{x:858,y:620,t:1526933652964};\\\", \\\"{x:888,y:617,t:1526933652980};\\\", \\\"{x:915,y:614,t:1526933652996};\\\", \\\"{x:939,y:612,t:1526933653013};\\\", \\\"{x:960,y:609,t:1526933653031};\\\", \\\"{x:978,y:607,t:1526933653046};\\\", \\\"{x:997,y:607,t:1526933653063};\\\", \\\"{x:1030,y:607,t:1526933653080};\\\", \\\"{x:1057,y:607,t:1526933653096};\\\", \\\"{x:1085,y:607,t:1526933653113};\\\", \\\"{x:1102,y:607,t:1526933653130};\\\", \\\"{x:1114,y:607,t:1526933653146};\\\", \\\"{x:1120,y:608,t:1526933653163};\\\", \\\"{x:1121,y:608,t:1526933654232};\\\", \\\"{x:1126,y:607,t:1526933655408};\\\", \\\"{x:1127,y:607,t:1526933655416};\\\", \\\"{x:1132,y:609,t:1526933655430};\\\", \\\"{x:1157,y:617,t:1526933655447};\\\", \\\"{x:1195,y:634,t:1526933655464};\\\", \\\"{x:1217,y:645,t:1526933655480};\\\", \\\"{x:1243,y:656,t:1526933655497};\\\", \\\"{x:1286,y:666,t:1526933655514};\\\", \\\"{x:1328,y:677,t:1526933655530};\\\", \\\"{x:1371,y:688,t:1526933655547};\\\", \\\"{x:1388,y:699,t:1526933655564};\\\", \\\"{x:1417,y:708,t:1526933655580};\\\", \\\"{x:1442,y:716,t:1526933655597};\\\", \\\"{x:1466,y:724,t:1526933655614};\\\", \\\"{x:1477,y:730,t:1526933655630};\\\", \\\"{x:1484,y:732,t:1526933655648};\\\", \\\"{x:1486,y:733,t:1526933655663};\\\", \\\"{x:1486,y:734,t:1526933655736};\\\", \\\"{x:1482,y:735,t:1526933655748};\\\", \\\"{x:1466,y:738,t:1526933655765};\\\", \\\"{x:1454,y:738,t:1526933655780};\\\", \\\"{x:1433,y:738,t:1526933655797};\\\", \\\"{x:1410,y:737,t:1526933655814};\\\", \\\"{x:1392,y:735,t:1526933655831};\\\", \\\"{x:1383,y:733,t:1526933655847};\\\", \\\"{x:1382,y:732,t:1526933655864};\\\", \\\"{x:1381,y:732,t:1526933656024};\\\", \\\"{x:1379,y:732,t:1526933656032};\\\", \\\"{x:1377,y:732,t:1526933656056};\\\", \\\"{x:1375,y:731,t:1526933656064};\\\", \\\"{x:1374,y:730,t:1526933656081};\\\", \\\"{x:1373,y:730,t:1526933656097};\\\", \\\"{x:1372,y:730,t:1526933656120};\\\", \\\"{x:1372,y:729,t:1526933656130};\\\", \\\"{x:1371,y:729,t:1526933656147};\\\", \\\"{x:1370,y:729,t:1526933656209};\\\", \\\"{x:1369,y:729,t:1526933656233};\\\", \\\"{x:1369,y:727,t:1526933656352};\\\", \\\"{x:1367,y:725,t:1526933656368};\\\", \\\"{x:1367,y:722,t:1526933656380};\\\", \\\"{x:1365,y:721,t:1526933656397};\\\", \\\"{x:1364,y:719,t:1526933656414};\\\", \\\"{x:1364,y:718,t:1526933656430};\\\", \\\"{x:1363,y:717,t:1526933656448};\\\", \\\"{x:1362,y:716,t:1526933656464};\\\", \\\"{x:1362,y:715,t:1526933656480};\\\", \\\"{x:1362,y:714,t:1526933656504};\\\", \\\"{x:1362,y:713,t:1526933656514};\\\", \\\"{x:1362,y:712,t:1526933656536};\\\", \\\"{x:1362,y:711,t:1526933656548};\\\", \\\"{x:1362,y:710,t:1526933656576};\\\", \\\"{x:1362,y:709,t:1526933656600};\\\", \\\"{x:1362,y:707,t:1526933656614};\\\", \\\"{x:1361,y:707,t:1526933656640};\\\", \\\"{x:1361,y:705,t:1526933656672};\\\", \\\"{x:1361,y:704,t:1526933656704};\\\", \\\"{x:1361,y:702,t:1526933656744};\\\", \\\"{x:1360,y:702,t:1526933656752};\\\", \\\"{x:1360,y:701,t:1526933656764};\\\", \\\"{x:1359,y:701,t:1526933656780};\\\", \\\"{x:1358,y:700,t:1526933657112};\\\", \\\"{x:1356,y:698,t:1526933657120};\\\", \\\"{x:1355,y:698,t:1526933657131};\\\", \\\"{x:1354,y:698,t:1526933657176};\\\", \\\"{x:1353,y:698,t:1526933657201};\\\", \\\"{x:1352,y:698,t:1526933657680};\\\", \\\"{x:1351,y:698,t:1526933657688};\\\", \\\"{x:1349,y:698,t:1526933657697};\\\", \\\"{x:1347,y:698,t:1526933657714};\\\", \\\"{x:1344,y:698,t:1526933657731};\\\", \\\"{x:1340,y:697,t:1526933657748};\\\", \\\"{x:1338,y:697,t:1526933657764};\\\", \\\"{x:1336,y:697,t:1526933657781};\\\", \\\"{x:1333,y:697,t:1526933657797};\\\", \\\"{x:1331,y:697,t:1526933657814};\\\", \\\"{x:1327,y:697,t:1526933657831};\\\", \\\"{x:1324,y:696,t:1526933657847};\\\", \\\"{x:1321,y:696,t:1526933657864};\\\", \\\"{x:1323,y:696,t:1526933658105};\\\", \\\"{x:1324,y:696,t:1526933658119};\\\", \\\"{x:1326,y:696,t:1526933658144};\\\", \\\"{x:1327,y:696,t:1526933658248};\\\", \\\"{x:1329,y:696,t:1526933658280};\\\", \\\"{x:1330,y:696,t:1526933658296};\\\", \\\"{x:1331,y:696,t:1526933658344};\\\", \\\"{x:1332,y:695,t:1526933658368};\\\", \\\"{x:1333,y:695,t:1526933658400};\\\", \\\"{x:1335,y:695,t:1526933658440};\\\", \\\"{x:1336,y:695,t:1526933658713};\\\", \\\"{x:1336,y:694,t:1526933658721};\\\", \\\"{x:1338,y:694,t:1526933658736};\\\", \\\"{x:1339,y:692,t:1526933658776};\\\", \\\"{x:1340,y:692,t:1526933658784};\\\", \\\"{x:1341,y:690,t:1526933658840};\\\", \\\"{x:1342,y:690,t:1526933658905};\\\", \\\"{x:1343,y:690,t:1526933658984};\\\", \\\"{x:1344,y:690,t:1526933659032};\\\", \\\"{x:1345,y:690,t:1526933659096};\\\", \\\"{x:1346,y:690,t:1526933659112};\\\", \\\"{x:1346,y:691,t:1526933659153};\\\", \\\"{x:1347,y:692,t:1526933659184};\\\", \\\"{x:1348,y:692,t:1526933659296};\\\", \\\"{x:1349,y:693,t:1526933659320};\\\", \\\"{x:1350,y:693,t:1526933659377};\\\", \\\"{x:1351,y:693,t:1526933659584};\\\", \\\"{x:1352,y:694,t:1526933660961};\\\", \\\"{x:1352,y:695,t:1526933661049};\\\", \\\"{x:1352,y:697,t:1526933661120};\\\", \\\"{x:1352,y:698,t:1526933661577};\\\", \\\"{x:1352,y:700,t:1526933663153};\\\", \\\"{x:1352,y:701,t:1526933663185};\\\", \\\"{x:1352,y:703,t:1526933663288};\\\", \\\"{x:1351,y:703,t:1526933664392};\\\", \\\"{x:1350,y:703,t:1526933664425};\\\", \\\"{x:1349,y:703,t:1526933664465};\\\", \\\"{x:1348,y:703,t:1526933664633};\\\", \\\"{x:1347,y:703,t:1526933667104};\\\", \\\"{x:1353,y:703,t:1526933667216};\\\", \\\"{x:1353,y:701,t:1526933667224};\\\", \\\"{x:1357,y:702,t:1526933669601};\\\", \\\"{x:1374,y:710,t:1526933669618};\\\", \\\"{x:1389,y:721,t:1526933669634};\\\", \\\"{x:1410,y:731,t:1526933669650};\\\", \\\"{x:1434,y:741,t:1526933669667};\\\", \\\"{x:1458,y:750,t:1526933669684};\\\", \\\"{x:1486,y:755,t:1526933669701};\\\", \\\"{x:1500,y:762,t:1526933669718};\\\", \\\"{x:1513,y:765,t:1526933669734};\\\", \\\"{x:1516,y:765,t:1526933669751};\\\", \\\"{x:1521,y:766,t:1526933669768};\\\", \\\"{x:1525,y:767,t:1526933669784};\\\", \\\"{x:1528,y:768,t:1526933669801};\\\", \\\"{x:1532,y:769,t:1526933669817};\\\", \\\"{x:1537,y:771,t:1526933669834};\\\", \\\"{x:1542,y:773,t:1526933669851};\\\", \\\"{x:1545,y:774,t:1526933669868};\\\", \\\"{x:1549,y:776,t:1526933669884};\\\", \\\"{x:1550,y:776,t:1526933669901};\\\", \\\"{x:1554,y:776,t:1526933669918};\\\", \\\"{x:1558,y:776,t:1526933669933};\\\", \\\"{x:1564,y:777,t:1526933669951};\\\", \\\"{x:1574,y:778,t:1526933669968};\\\", \\\"{x:1578,y:778,t:1526933669984};\\\", \\\"{x:1582,y:780,t:1526933670001};\\\", \\\"{x:1585,y:781,t:1526933670018};\\\", \\\"{x:1590,y:784,t:1526933670034};\\\", \\\"{x:1594,y:784,t:1526933670051};\\\", \\\"{x:1595,y:784,t:1526933670067};\\\", \\\"{x:1597,y:784,t:1526933670104};\\\", \\\"{x:1598,y:784,t:1526933670136};\\\", \\\"{x:1600,y:784,t:1526933670152};\\\", \\\"{x:1606,y:785,t:1526933670168};\\\", \\\"{x:1615,y:791,t:1526933670184};\\\", \\\"{x:1624,y:798,t:1526933670201};\\\", \\\"{x:1633,y:811,t:1526933670218};\\\", \\\"{x:1644,y:826,t:1526933670234};\\\", \\\"{x:1653,y:842,t:1526933670251};\\\", \\\"{x:1657,y:856,t:1526933670269};\\\", \\\"{x:1657,y:869,t:1526933670284};\\\", \\\"{x:1657,y:880,t:1526933670301};\\\", \\\"{x:1657,y:895,t:1526933670318};\\\", \\\"{x:1650,y:907,t:1526933670334};\\\", \\\"{x:1646,y:919,t:1526933670351};\\\", \\\"{x:1641,y:934,t:1526933670368};\\\", \\\"{x:1638,y:943,t:1526933670384};\\\", \\\"{x:1635,y:948,t:1526933670401};\\\", \\\"{x:1633,y:953,t:1526933670417};\\\", \\\"{x:1631,y:955,t:1526933670434};\\\", \\\"{x:1630,y:956,t:1526933670451};\\\", \\\"{x:1629,y:958,t:1526933670468};\\\", \\\"{x:1628,y:959,t:1526933670484};\\\", \\\"{x:1628,y:960,t:1526933670501};\\\", \\\"{x:1628,y:962,t:1526933670518};\\\", \\\"{x:1627,y:963,t:1526933670534};\\\", \\\"{x:1626,y:964,t:1526933670616};\\\", \\\"{x:1625,y:963,t:1526933670633};\\\", \\\"{x:1624,y:963,t:1526933670688};\\\", \\\"{x:1623,y:962,t:1526933670701};\\\", \\\"{x:1622,y:959,t:1526933670718};\\\", \\\"{x:1621,y:959,t:1526933670734};\\\", \\\"{x:1620,y:958,t:1526933670751};\\\", \\\"{x:1620,y:957,t:1526933670767};\\\", \\\"{x:1619,y:956,t:1526933670784};\\\", \\\"{x:1619,y:955,t:1526933670848};\\\", \\\"{x:1619,y:954,t:1526933670888};\\\", \\\"{x:1619,y:953,t:1526933670904};\\\", \\\"{x:1619,y:952,t:1526933670936};\\\", \\\"{x:1619,y:951,t:1526933670976};\\\", \\\"{x:1619,y:950,t:1526933671000};\\\", \\\"{x:1618,y:950,t:1526933671015};\\\", \\\"{x:1618,y:949,t:1526933671072};\\\", \\\"{x:1618,y:948,t:1526933671136};\\\", \\\"{x:1617,y:947,t:1526933671184};\\\", \\\"{x:1617,y:946,t:1526933671201};\\\", \\\"{x:1617,y:945,t:1526933671240};\\\", \\\"{x:1616,y:944,t:1526933671251};\\\", \\\"{x:1616,y:943,t:1526933671296};\\\", \\\"{x:1616,y:942,t:1526933671312};\\\", \\\"{x:1615,y:941,t:1526933671328};\\\", \\\"{x:1615,y:940,t:1526933671343};\\\", \\\"{x:1615,y:938,t:1526933671360};\\\", \\\"{x:1614,y:937,t:1526933671368};\\\", \\\"{x:1614,y:935,t:1526933671385};\\\", \\\"{x:1614,y:934,t:1526933671401};\\\", \\\"{x:1613,y:933,t:1526933671424};\\\", \\\"{x:1613,y:932,t:1526933671435};\\\", \\\"{x:1613,y:931,t:1526933671472};\\\", \\\"{x:1613,y:929,t:1526933671496};\\\", \\\"{x:1613,y:928,t:1526933671512};\\\", \\\"{x:1613,y:926,t:1526933671544};\\\", \\\"{x:1613,y:925,t:1526933671551};\\\", \\\"{x:1613,y:922,t:1526933671568};\\\", \\\"{x:1613,y:921,t:1526933671585};\\\", \\\"{x:1613,y:919,t:1526933671601};\\\", \\\"{x:1613,y:918,t:1526933671648};\\\", \\\"{x:1613,y:917,t:1526933671656};\\\", \\\"{x:1613,y:916,t:1526933671679};\\\", \\\"{x:1614,y:910,t:1526933671704};\\\", \\\"{x:1615,y:908,t:1526933671718};\\\", \\\"{x:1615,y:903,t:1526933671735};\\\", \\\"{x:1616,y:903,t:1526933671800};\\\", \\\"{x:1617,y:902,t:1526933671816};\\\", \\\"{x:1617,y:900,t:1526933671823};\\\", \\\"{x:1617,y:898,t:1526933671835};\\\", \\\"{x:1617,y:897,t:1526933671851};\\\", \\\"{x:1617,y:895,t:1526933672000};\\\", \\\"{x:1617,y:894,t:1526933672112};\\\", \\\"{x:1618,y:893,t:1526933672120};\\\", \\\"{x:1618,y:892,t:1526933672136};\\\", \\\"{x:1618,y:891,t:1526933672176};\\\", \\\"{x:1618,y:889,t:1526933672192};\\\", \\\"{x:1618,y:888,t:1526933672208};\\\", \\\"{x:1618,y:886,t:1526933672224};\\\", \\\"{x:1618,y:885,t:1526933672248};\\\", \\\"{x:1618,y:883,t:1526933672280};\\\", \\\"{x:1618,y:881,t:1526933672296};\\\", \\\"{x:1618,y:880,t:1526933672303};\\\", \\\"{x:1618,y:879,t:1526933672320};\\\", \\\"{x:1618,y:877,t:1526933672335};\\\", \\\"{x:1618,y:875,t:1526933672351};\\\", \\\"{x:1618,y:874,t:1526933672368};\\\", \\\"{x:1618,y:873,t:1526933672385};\\\", \\\"{x:1617,y:870,t:1526933672401};\\\", \\\"{x:1617,y:869,t:1526933672418};\\\", \\\"{x:1616,y:865,t:1526933672435};\\\", \\\"{x:1616,y:863,t:1526933672452};\\\", \\\"{x:1616,y:862,t:1526933672468};\\\", \\\"{x:1615,y:859,t:1526933672485};\\\", \\\"{x:1614,y:858,t:1526933672504};\\\", \\\"{x:1614,y:857,t:1526933672518};\\\", \\\"{x:1613,y:854,t:1526933672535};\\\", \\\"{x:1611,y:848,t:1526933672551};\\\", \\\"{x:1604,y:829,t:1526933672568};\\\", \\\"{x:1603,y:826,t:1526933672585};\\\", \\\"{x:1603,y:825,t:1526933672601};\\\", \\\"{x:1603,y:823,t:1526933672618};\\\", \\\"{x:1603,y:822,t:1526933672648};\\\", \\\"{x:1603,y:821,t:1526933672672};\\\", \\\"{x:1603,y:820,t:1526933672688};\\\", \\\"{x:1602,y:820,t:1526933672702};\\\", \\\"{x:1601,y:815,t:1526933672718};\\\", \\\"{x:1600,y:815,t:1526933672735};\\\", \\\"{x:1599,y:811,t:1526933672752};\\\", \\\"{x:1599,y:810,t:1526933672768};\\\", \\\"{x:1599,y:806,t:1526933672785};\\\", \\\"{x:1599,y:803,t:1526933672802};\\\", \\\"{x:1599,y:801,t:1526933672818};\\\", \\\"{x:1599,y:798,t:1526933672835};\\\", \\\"{x:1600,y:793,t:1526933672852};\\\", \\\"{x:1601,y:788,t:1526933672868};\\\", \\\"{x:1605,y:783,t:1526933672885};\\\", \\\"{x:1606,y:776,t:1526933672902};\\\", \\\"{x:1606,y:768,t:1526933672918};\\\", \\\"{x:1607,y:762,t:1526933672935};\\\", \\\"{x:1609,y:752,t:1526933672952};\\\", \\\"{x:1610,y:747,t:1526933672968};\\\", \\\"{x:1610,y:744,t:1526933672985};\\\", \\\"{x:1611,y:741,t:1526933673003};\\\", \\\"{x:1613,y:733,t:1526933673019};\\\", \\\"{x:1615,y:727,t:1526933673035};\\\", \\\"{x:1617,y:721,t:1526933673052};\\\", \\\"{x:1619,y:715,t:1526933673068};\\\", \\\"{x:1619,y:713,t:1526933673085};\\\", \\\"{x:1619,y:711,t:1526933673102};\\\", \\\"{x:1619,y:709,t:1526933673118};\\\", \\\"{x:1619,y:708,t:1526933673552};\\\", \\\"{x:1619,y:706,t:1526933673568};\\\", \\\"{x:1619,y:705,t:1526933673585};\\\", \\\"{x:1619,y:702,t:1526933673602};\\\", \\\"{x:1619,y:701,t:1526933673624};\\\", \\\"{x:1618,y:701,t:1526933673640};\\\", \\\"{x:1616,y:701,t:1526933674704};\\\", \\\"{x:1614,y:701,t:1526933674719};\\\", \\\"{x:1602,y:704,t:1526933674735};\\\", \\\"{x:1573,y:709,t:1526933674751};\\\", \\\"{x:1554,y:715,t:1526933674769};\\\", \\\"{x:1531,y:719,t:1526933674785};\\\", \\\"{x:1509,y:727,t:1526933674803};\\\", \\\"{x:1481,y:735,t:1526933674819};\\\", \\\"{x:1461,y:742,t:1526933674835};\\\", \\\"{x:1447,y:744,t:1526933674852};\\\", \\\"{x:1433,y:746,t:1526933674869};\\\", \\\"{x:1422,y:747,t:1526933674886};\\\", \\\"{x:1418,y:748,t:1526933674903};\\\", \\\"{x:1416,y:748,t:1526933674985};\\\", \\\"{x:1410,y:748,t:1526933675003};\\\", \\\"{x:1404,y:745,t:1526933675020};\\\", \\\"{x:1395,y:741,t:1526933675036};\\\", \\\"{x:1387,y:736,t:1526933675053};\\\", \\\"{x:1381,y:731,t:1526933675070};\\\", \\\"{x:1373,y:725,t:1526933675086};\\\", \\\"{x:1364,y:720,t:1526933675103};\\\", \\\"{x:1359,y:717,t:1526933675120};\\\", \\\"{x:1354,y:714,t:1526933675136};\\\", \\\"{x:1352,y:712,t:1526933675153};\\\", \\\"{x:1350,y:711,t:1526933675177};\\\", \\\"{x:1350,y:709,t:1526933675193};\\\", \\\"{x:1349,y:708,t:1526933675208};\\\", \\\"{x:1346,y:703,t:1526933675220};\\\", \\\"{x:1345,y:700,t:1526933675235};\\\", \\\"{x:1344,y:699,t:1526933675252};\\\", \\\"{x:1342,y:698,t:1526933675280};\\\", \\\"{x:1342,y:697,t:1526933675329};\\\", \\\"{x:1340,y:697,t:1526933675361};\\\", \\\"{x:1339,y:697,t:1526933675377};\\\", \\\"{x:1338,y:697,t:1526933675393};\\\", \\\"{x:1336,y:697,t:1526933675402};\\\", \\\"{x:1335,y:697,t:1526933675433};\\\", \\\"{x:1334,y:697,t:1526933675449};\\\", \\\"{x:1333,y:697,t:1526933675457};\\\", \\\"{x:1333,y:696,t:1526933675736};\\\", \\\"{x:1334,y:696,t:1526933675792};\\\", \\\"{x:1334,y:695,t:1526933675849};\\\", \\\"{x:1335,y:694,t:1526933675897};\\\", \\\"{x:1336,y:694,t:1526933675962};\\\", \\\"{x:1337,y:694,t:1526933675993};\\\", \\\"{x:1337,y:693,t:1526933676003};\\\", \\\"{x:1338,y:693,t:1526933676033};\\\", \\\"{x:1338,y:691,t:1526933676618};\\\", \\\"{x:1338,y:688,t:1526933676633};\\\", \\\"{x:1337,y:688,t:1526933676641};\\\", \\\"{x:1336,y:686,t:1526933676653};\\\", \\\"{x:1335,y:684,t:1526933676670};\\\", \\\"{x:1334,y:682,t:1526933676687};\\\", \\\"{x:1332,y:680,t:1526933676703};\\\", \\\"{x:1329,y:676,t:1526933676720};\\\", \\\"{x:1325,y:672,t:1526933676736};\\\", \\\"{x:1325,y:667,t:1526933676753};\\\", \\\"{x:1319,y:661,t:1526933676769};\\\", \\\"{x:1317,y:655,t:1526933676786};\\\", \\\"{x:1315,y:649,t:1526933676803};\\\", \\\"{x:1311,y:637,t:1526933676819};\\\", \\\"{x:1304,y:619,t:1526933676836};\\\", \\\"{x:1299,y:610,t:1526933676853};\\\", \\\"{x:1293,y:599,t:1526933676869};\\\", \\\"{x:1287,y:591,t:1526933676886};\\\", \\\"{x:1285,y:585,t:1526933676903};\\\", \\\"{x:1284,y:584,t:1526933676920};\\\", \\\"{x:1284,y:583,t:1526933676944};\\\", \\\"{x:1284,y:582,t:1526933677041};\\\", \\\"{x:1283,y:580,t:1526933677057};\\\", \\\"{x:1283,y:577,t:1526933677070};\\\", \\\"{x:1281,y:574,t:1526933677086};\\\", \\\"{x:1280,y:569,t:1526933677103};\\\", \\\"{x:1278,y:565,t:1526933677119};\\\", \\\"{x:1276,y:560,t:1526933677136};\\\", \\\"{x:1275,y:558,t:1526933677153};\\\", \\\"{x:1275,y:557,t:1526933677170};\\\", \\\"{x:1274,y:554,t:1526933677186};\\\", \\\"{x:1272,y:552,t:1526933677202};\\\", \\\"{x:1272,y:551,t:1526933677220};\\\", \\\"{x:1272,y:550,t:1526933677236};\\\", \\\"{x:1272,y:549,t:1526933677360};\\\", \\\"{x:1271,y:549,t:1526933677370};\\\", \\\"{x:1270,y:549,t:1526933677387};\\\", \\\"{x:1268,y:549,t:1526933677408};\\\", \\\"{x:1268,y:550,t:1526933677424};\\\", \\\"{x:1268,y:551,t:1526933677436};\\\", \\\"{x:1268,y:552,t:1526933677454};\\\", \\\"{x:1268,y:553,t:1526933677469};\\\", \\\"{x:1268,y:554,t:1526933677487};\\\", \\\"{x:1268,y:556,t:1526933677504};\\\", \\\"{x:1268,y:558,t:1526933677521};\\\", \\\"{x:1268,y:559,t:1526933677537};\\\", \\\"{x:1268,y:561,t:1526933677553};\\\", \\\"{x:1268,y:562,t:1526933677593};\\\", \\\"{x:1269,y:563,t:1526933677609};\\\", \\\"{x:1269,y:564,t:1526933677641};\\\", \\\"{x:1270,y:565,t:1526933677655};\\\", \\\"{x:1272,y:565,t:1526933677673};\\\", \\\"{x:1272,y:566,t:1526933677689};\\\", \\\"{x:1274,y:567,t:1526933677703};\\\", \\\"{x:1275,y:567,t:1526933677721};\\\", \\\"{x:1276,y:568,t:1526933677737};\\\", \\\"{x:1277,y:568,t:1526933677753};\\\", \\\"{x:1278,y:568,t:1526933677770};\\\", \\\"{x:1279,y:569,t:1526933677786};\\\", \\\"{x:1281,y:569,t:1526933677961};\\\", \\\"{x:1282,y:569,t:1526933678114};\\\", \\\"{x:1282,y:570,t:1526933679418};\\\", \\\"{x:1283,y:570,t:1526933693514};\\\", \\\"{x:1285,y:569,t:1526933693525};\\\", \\\"{x:1286,y:569,t:1526933693544};\\\", \\\"{x:1293,y:566,t:1526933693558};\\\", \\\"{x:1305,y:561,t:1526933693574};\\\", \\\"{x:1308,y:560,t:1526933693590};\\\", \\\"{x:1310,y:559,t:1526933693607};\\\", \\\"{x:1313,y:559,t:1526933693625};\\\", \\\"{x:1316,y:557,t:1526933693641};\\\", \\\"{x:1317,y:557,t:1526933693658};\\\", \\\"{x:1318,y:557,t:1526933693674};\\\", \\\"{x:1319,y:556,t:1526933693690};\\\", \\\"{x:1321,y:555,t:1526933693712};\\\", \\\"{x:1322,y:554,t:1526933693736};\\\", \\\"{x:1323,y:554,t:1526933693744};\\\", \\\"{x:1324,y:554,t:1526933693758};\\\", \\\"{x:1328,y:553,t:1526933693774};\\\", \\\"{x:1331,y:553,t:1526933693790};\\\", \\\"{x:1337,y:553,t:1526933693808};\\\", \\\"{x:1340,y:553,t:1526933693824};\\\", \\\"{x:1342,y:552,t:1526933693840};\\\", \\\"{x:1344,y:552,t:1526933693857};\\\", \\\"{x:1345,y:552,t:1526933693875};\\\", \\\"{x:1349,y:550,t:1526933693890};\\\", \\\"{x:1352,y:550,t:1526933693907};\\\", \\\"{x:1355,y:550,t:1526933693925};\\\", \\\"{x:1360,y:548,t:1526933693940};\\\", \\\"{x:1363,y:548,t:1526933693958};\\\", \\\"{x:1364,y:548,t:1526933693975};\\\", \\\"{x:1370,y:546,t:1526933693990};\\\", \\\"{x:1371,y:546,t:1526933694007};\\\", \\\"{x:1376,y:546,t:1526933694025};\\\", \\\"{x:1381,y:546,t:1526933694041};\\\", \\\"{x:1383,y:546,t:1526933694058};\\\", \\\"{x:1385,y:546,t:1526933694074};\\\", \\\"{x:1388,y:546,t:1526933694090};\\\", \\\"{x:1390,y:546,t:1526933694107};\\\", \\\"{x:1391,y:546,t:1526933694129};\\\", \\\"{x:1393,y:546,t:1526933694152};\\\", \\\"{x:1394,y:547,t:1526933694161};\\\", \\\"{x:1395,y:550,t:1526933694175};\\\", \\\"{x:1397,y:552,t:1526933694191};\\\", \\\"{x:1398,y:554,t:1526933694208};\\\", \\\"{x:1399,y:561,t:1526933694225};\\\", \\\"{x:1399,y:566,t:1526933694241};\\\", \\\"{x:1401,y:573,t:1526933694258};\\\", \\\"{x:1401,y:580,t:1526933694275};\\\", \\\"{x:1401,y:589,t:1526933694290};\\\", \\\"{x:1396,y:603,t:1526933694307};\\\", \\\"{x:1392,y:612,t:1526933694324};\\\", \\\"{x:1386,y:622,t:1526933694341};\\\", \\\"{x:1380,y:634,t:1526933694357};\\\", \\\"{x:1374,y:649,t:1526933694375};\\\", \\\"{x:1365,y:660,t:1526933694391};\\\", \\\"{x:1355,y:670,t:1526933694408};\\\", \\\"{x:1340,y:690,t:1526933694425};\\\", \\\"{x:1331,y:702,t:1526933694441};\\\", \\\"{x:1318,y:715,t:1526933694458};\\\", \\\"{x:1301,y:728,t:1526933694475};\\\", \\\"{x:1292,y:736,t:1526933694491};\\\", \\\"{x:1283,y:743,t:1526933694508};\\\", \\\"{x:1276,y:752,t:1526933694525};\\\", \\\"{x:1267,y:759,t:1526933694541};\\\", \\\"{x:1263,y:765,t:1526933694558};\\\", \\\"{x:1259,y:770,t:1526933694574};\\\", \\\"{x:1255,y:777,t:1526933694592};\\\", \\\"{x:1252,y:782,t:1526933694608};\\\", \\\"{x:1247,y:789,t:1526933694624};\\\", \\\"{x:1245,y:791,t:1526933694641};\\\", \\\"{x:1244,y:793,t:1526933694658};\\\", \\\"{x:1242,y:797,t:1526933694675};\\\", \\\"{x:1242,y:799,t:1526933694691};\\\", \\\"{x:1242,y:803,t:1526933694708};\\\", \\\"{x:1242,y:805,t:1526933694724};\\\", \\\"{x:1242,y:809,t:1526933694742};\\\", \\\"{x:1243,y:812,t:1526933694758};\\\", \\\"{x:1244,y:814,t:1526933694775};\\\", \\\"{x:1245,y:817,t:1526933694792};\\\", \\\"{x:1245,y:820,t:1526933694808};\\\", \\\"{x:1248,y:821,t:1526933694825};\\\", \\\"{x:1250,y:823,t:1526933694842};\\\", \\\"{x:1253,y:824,t:1526933694858};\\\", \\\"{x:1256,y:827,t:1526933694875};\\\", \\\"{x:1261,y:828,t:1526933694892};\\\", \\\"{x:1268,y:831,t:1526933694907};\\\", \\\"{x:1272,y:832,t:1526933694925};\\\", \\\"{x:1276,y:834,t:1526933694942};\\\", \\\"{x:1281,y:834,t:1526933694957};\\\", \\\"{x:1286,y:835,t:1526933694974};\\\", \\\"{x:1291,y:835,t:1526933694992};\\\", \\\"{x:1296,y:835,t:1526933695008};\\\", \\\"{x:1307,y:837,t:1526933695024};\\\", \\\"{x:1312,y:837,t:1526933695041};\\\", \\\"{x:1317,y:838,t:1526933695058};\\\", \\\"{x:1321,y:840,t:1526933695074};\\\", \\\"{x:1328,y:840,t:1526933695092};\\\", \\\"{x:1337,y:842,t:1526933695108};\\\", \\\"{x:1347,y:842,t:1526933695125};\\\", \\\"{x:1361,y:843,t:1526933695142};\\\", \\\"{x:1372,y:843,t:1526933695157};\\\", \\\"{x:1379,y:843,t:1526933695175};\\\", \\\"{x:1382,y:843,t:1526933695192};\\\", \\\"{x:1384,y:843,t:1526933695208};\\\", \\\"{x:1392,y:843,t:1526933695224};\\\", \\\"{x:1400,y:842,t:1526933695242};\\\", \\\"{x:1405,y:842,t:1526933695258};\\\", \\\"{x:1410,y:841,t:1526933695275};\\\", \\\"{x:1419,y:840,t:1526933695292};\\\", \\\"{x:1426,y:839,t:1526933695308};\\\", \\\"{x:1430,y:839,t:1526933695325};\\\", \\\"{x:1432,y:838,t:1526933695341};\\\", \\\"{x:1433,y:838,t:1526933695361};\\\", \\\"{x:1435,y:838,t:1526933695375};\\\", \\\"{x:1437,y:837,t:1526933695392};\\\", \\\"{x:1440,y:837,t:1526933695408};\\\", \\\"{x:1442,y:837,t:1526933695424};\\\", \\\"{x:1446,y:835,t:1526933695442};\\\", \\\"{x:1449,y:835,t:1526933695458};\\\", \\\"{x:1450,y:835,t:1526933695475};\\\", \\\"{x:1452,y:835,t:1526933695492};\\\", \\\"{x:1453,y:835,t:1526933695512};\\\", \\\"{x:1456,y:834,t:1526933695525};\\\", \\\"{x:1458,y:834,t:1526933695541};\\\", \\\"{x:1463,y:833,t:1526933695558};\\\", \\\"{x:1469,y:833,t:1526933695575};\\\", \\\"{x:1471,y:833,t:1526933695592};\\\", \\\"{x:1472,y:833,t:1526933695632};\\\", \\\"{x:1473,y:833,t:1526933695648};\\\", \\\"{x:1475,y:833,t:1526933695664};\\\", \\\"{x:1477,y:833,t:1526933695680};\\\", \\\"{x:1478,y:833,t:1526933695691};\\\", \\\"{x:1480,y:833,t:1526933695808};\\\", \\\"{x:1482,y:831,t:1526933695824};\\\", \\\"{x:1481,y:831,t:1526933696321};\\\", \\\"{x:1476,y:833,t:1526933701405};\\\", \\\"{x:1427,y:847,t:1526933701415};\\\", \\\"{x:1269,y:871,t:1526933701431};\\\", \\\"{x:1094,y:882,t:1526933701447};\\\", \\\"{x:914,y:884,t:1526933701464};\\\", \\\"{x:709,y:853,t:1526933701481};\\\", \\\"{x:525,y:810,t:1526933701497};\\\", \\\"{x:363,y:770,t:1526933701514};\\\", \\\"{x:230,y:729,t:1526933701531};\\\", \\\"{x:202,y:709,t:1526933701547};\\\", \\\"{x:201,y:706,t:1526933701564};\\\", \\\"{x:200,y:705,t:1526933701603};\\\", \\\"{x:200,y:703,t:1526933701614};\\\", \\\"{x:198,y:695,t:1526933701631};\\\", \\\"{x:194,y:690,t:1526933701648};\\\", \\\"{x:192,y:687,t:1526933701665};\\\", \\\"{x:190,y:685,t:1526933701681};\\\", \\\"{x:190,y:681,t:1526933701698};\\\", \\\"{x:190,y:673,t:1526933701714};\\\", \\\"{x:190,y:669,t:1526933701733};\\\", \\\"{x:198,y:661,t:1526933701747};\\\", \\\"{x:211,y:652,t:1526933701764};\\\", \\\"{x:215,y:650,t:1526933701775};\\\", \\\"{x:222,y:645,t:1526933701792};\\\", \\\"{x:231,y:638,t:1526933701809};\\\", \\\"{x:238,y:633,t:1526933701825};\\\", \\\"{x:242,y:632,t:1526933701842};\\\", \\\"{x:248,y:630,t:1526933701859};\\\", \\\"{x:249,y:630,t:1526933701875};\\\", \\\"{x:254,y:627,t:1526933701892};\\\", \\\"{x:261,y:621,t:1526933701909};\\\", \\\"{x:266,y:616,t:1526933701925};\\\", \\\"{x:267,y:615,t:1526933701942};\\\", \\\"{x:268,y:614,t:1526933701959};\\\", \\\"{x:270,y:613,t:1526933701975};\\\", \\\"{x:272,y:613,t:1526933701992};\\\", \\\"{x:273,y:612,t:1526933702010};\\\", \\\"{x:274,y:611,t:1526933702025};\\\", \\\"{x:275,y:611,t:1526933702052};\\\", \\\"{x:273,y:611,t:1526933702100};\\\", \\\"{x:271,y:612,t:1526933702111};\\\", \\\"{x:261,y:616,t:1526933702125};\\\", \\\"{x:247,y:619,t:1526933702142};\\\", \\\"{x:242,y:625,t:1526933702159};\\\", \\\"{x:238,y:628,t:1526933702176};\\\", \\\"{x:236,y:628,t:1526933702192};\\\", \\\"{x:235,y:628,t:1526933702220};\\\", \\\"{x:237,y:628,t:1526933702324};\\\", \\\"{x:245,y:627,t:1526933702332};\\\", \\\"{x:247,y:627,t:1526933702344};\\\", \\\"{x:272,y:623,t:1526933702360};\\\", \\\"{x:313,y:622,t:1526933702377};\\\", \\\"{x:368,y:622,t:1526933702393};\\\", \\\"{x:438,y:622,t:1526933702409};\\\", \\\"{x:505,y:622,t:1526933702427};\\\", \\\"{x:552,y:622,t:1526933702442};\\\", \\\"{x:625,y:622,t:1526933702460};\\\", \\\"{x:698,y:620,t:1526933702476};\\\", \\\"{x:731,y:620,t:1526933702493};\\\", \\\"{x:749,y:617,t:1526933702509};\\\", \\\"{x:768,y:614,t:1526933702526};\\\", \\\"{x:789,y:611,t:1526933702542};\\\", \\\"{x:829,y:608,t:1526933702560};\\\", \\\"{x:866,y:603,t:1526933702577};\\\", \\\"{x:879,y:599,t:1526933702593};\\\", \\\"{x:894,y:596,t:1526933702610};\\\", \\\"{x:900,y:595,t:1526933702626};\\\", \\\"{x:904,y:594,t:1526933702642};\\\", \\\"{x:910,y:590,t:1526933702659};\\\", \\\"{x:916,y:586,t:1526933702676};\\\", \\\"{x:917,y:585,t:1526933702693};\\\", \\\"{x:915,y:585,t:1526933702763};\\\", \\\"{x:908,y:585,t:1526933702776};\\\", \\\"{x:893,y:585,t:1526933702793};\\\", \\\"{x:872,y:585,t:1526933702809};\\\", \\\"{x:848,y:585,t:1526933702827};\\\", \\\"{x:805,y:580,t:1526933702844};\\\", \\\"{x:727,y:560,t:1526933702861};\\\", \\\"{x:698,y:550,t:1526933702878};\\\", \\\"{x:676,y:542,t:1526933702893};\\\", \\\"{x:665,y:534,t:1526933702909};\\\", \\\"{x:654,y:532,t:1526933702926};\\\", \\\"{x:649,y:531,t:1526933702943};\\\", \\\"{x:645,y:531,t:1526933702959};\\\", \\\"{x:642,y:531,t:1526933702976};\\\", \\\"{x:627,y:531,t:1526933702992};\\\", \\\"{x:616,y:532,t:1526933703009};\\\", \\\"{x:610,y:532,t:1526933703025};\\\", \\\"{x:592,y:532,t:1526933703043};\\\", \\\"{x:576,y:534,t:1526933703060};\\\", \\\"{x:571,y:536,t:1526933703076};\\\", \\\"{x:561,y:537,t:1526933703093};\\\", \\\"{x:548,y:540,t:1526933703109};\\\", \\\"{x:540,y:541,t:1526933703126};\\\", \\\"{x:532,y:548,t:1526933703143};\\\", \\\"{x:529,y:551,t:1526933703160};\\\", \\\"{x:529,y:552,t:1526933703179};\\\", \\\"{x:529,y:553,t:1526933703193};\\\", \\\"{x:527,y:555,t:1526933703209};\\\", \\\"{x:527,y:556,t:1526933703227};\\\", \\\"{x:527,y:560,t:1526933703243};\\\", \\\"{x:527,y:564,t:1526933703260};\\\", \\\"{x:527,y:566,t:1526933703277};\\\", \\\"{x:531,y:569,t:1526933703293};\\\", \\\"{x:535,y:571,t:1526933703310};\\\", \\\"{x:541,y:573,t:1526933703326};\\\", \\\"{x:546,y:576,t:1526933703343};\\\", \\\"{x:551,y:578,t:1526933703360};\\\", \\\"{x:558,y:580,t:1526933703376};\\\", \\\"{x:559,y:581,t:1526933703393};\\\", \\\"{x:566,y:581,t:1526933703410};\\\", \\\"{x:569,y:581,t:1526933703426};\\\", \\\"{x:571,y:581,t:1526933703443};\\\", \\\"{x:572,y:581,t:1526933703501};\\\", \\\"{x:574,y:581,t:1526933703511};\\\", \\\"{x:575,y:581,t:1526933703526};\\\", \\\"{x:577,y:581,t:1526933703543};\\\", \\\"{x:579,y:581,t:1526933703561};\\\", \\\"{x:580,y:581,t:1526933703578};\\\", \\\"{x:581,y:581,t:1526933703596};\\\", \\\"{x:582,y:581,t:1526933703610};\\\", \\\"{x:585,y:581,t:1526933703628};\\\", \\\"{x:586,y:581,t:1526933703644};\\\", \\\"{x:591,y:581,t:1526933703660};\\\", \\\"{x:594,y:581,t:1526933703678};\\\", \\\"{x:595,y:581,t:1526933703708};\\\", \\\"{x:597,y:581,t:1526933703796};\\\", \\\"{x:598,y:581,t:1526933703820};\\\", \\\"{x:601,y:581,t:1526933703861};\\\", \\\"{x:601,y:580,t:1526933703884};\\\", \\\"{x:602,y:580,t:1526933704637};\\\", \\\"{x:605,y:589,t:1526933704644};\\\", \\\"{x:611,y:601,t:1526933704664};\\\", \\\"{x:620,y:611,t:1526933704679};\\\", \\\"{x:637,y:626,t:1526933704695};\\\", \\\"{x:657,y:643,t:1526933704712};\\\", \\\"{x:681,y:659,t:1526933704727};\\\", \\\"{x:708,y:674,t:1526933704744};\\\", \\\"{x:749,y:699,t:1526933704761};\\\", \\\"{x:804,y:724,t:1526933704778};\\\", \\\"{x:873,y:755,t:1526933704794};\\\", \\\"{x:1003,y:787,t:1526933704811};\\\", \\\"{x:1091,y:812,t:1526933704828};\\\", \\\"{x:1198,y:833,t:1526933704844};\\\", \\\"{x:1302,y:859,t:1526933704861};\\\", \\\"{x:1396,y:884,t:1526933704878};\\\", \\\"{x:1489,y:901,t:1526933704894};\\\", \\\"{x:1567,y:912,t:1526933704911};\\\", \\\"{x:1612,y:926,t:1526933704928};\\\", \\\"{x:1637,y:931,t:1526933704945};\\\", \\\"{x:1648,y:932,t:1526933704961};\\\", \\\"{x:1649,y:932,t:1526933704978};\\\", \\\"{x:1650,y:932,t:1526933704994};\\\", \\\"{x:1648,y:933,t:1526933705149};\\\", \\\"{x:1642,y:934,t:1526933705162};\\\", \\\"{x:1638,y:937,t:1526933705179};\\\", \\\"{x:1619,y:940,t:1526933705196};\\\", \\\"{x:1610,y:940,t:1526933705212};\\\", \\\"{x:1586,y:940,t:1526933705229};\\\", \\\"{x:1573,y:940,t:1526933705245};\\\", \\\"{x:1550,y:940,t:1526933705261};\\\", \\\"{x:1533,y:941,t:1526933705279};\\\", \\\"{x:1525,y:941,t:1526933705296};\\\", \\\"{x:1519,y:941,t:1526933705312};\\\", \\\"{x:1511,y:938,t:1526933705329};\\\", \\\"{x:1504,y:936,t:1526933705346};\\\", \\\"{x:1500,y:933,t:1526933705362};\\\", \\\"{x:1494,y:930,t:1526933705379};\\\", \\\"{x:1480,y:925,t:1526933705396};\\\", \\\"{x:1476,y:922,t:1526933705411};\\\", \\\"{x:1473,y:921,t:1526933705429};\\\", \\\"{x:1471,y:921,t:1526933705691};\\\", \\\"{x:1470,y:917,t:1526933705700};\\\", \\\"{x:1469,y:916,t:1526933705712};\\\", \\\"{x:1466,y:910,t:1526933705729};\\\", \\\"{x:1465,y:908,t:1526933705745};\\\", \\\"{x:1461,y:905,t:1526933705762};\\\", \\\"{x:1455,y:900,t:1526933705779};\\\", \\\"{x:1448,y:892,t:1526933705795};\\\", \\\"{x:1442,y:886,t:1526933705813};\\\", \\\"{x:1435,y:881,t:1526933705828};\\\", \\\"{x:1421,y:870,t:1526933705845};\\\", \\\"{x:1408,y:856,t:1526933705863};\\\", \\\"{x:1394,y:841,t:1526933705878};\\\", \\\"{x:1383,y:828,t:1526933705895};\\\", \\\"{x:1374,y:819,t:1526933705912};\\\", \\\"{x:1370,y:812,t:1526933705928};\\\", \\\"{x:1366,y:807,t:1526933705946};\\\", \\\"{x:1363,y:804,t:1526933705962};\\\", \\\"{x:1362,y:804,t:1526933705978};\\\", \\\"{x:1362,y:800,t:1526933706117};\\\", \\\"{x:1362,y:794,t:1526933706131};\\\", \\\"{x:1367,y:782,t:1526933706146};\\\", \\\"{x:1371,y:770,t:1526933706163};\\\", \\\"{x:1375,y:747,t:1526933706180};\\\", \\\"{x:1375,y:744,t:1526933706196};\\\", \\\"{x:1381,y:723,t:1526933706213};\\\", \\\"{x:1384,y:713,t:1526933706230};\\\", \\\"{x:1384,y:708,t:1526933706246};\\\", \\\"{x:1384,y:706,t:1526933706263};\\\", \\\"{x:1384,y:704,t:1526933706280};\\\", \\\"{x:1384,y:702,t:1526933706296};\\\", \\\"{x:1384,y:701,t:1526933706313};\\\", \\\"{x:1382,y:701,t:1526933706333};\\\", \\\"{x:1380,y:701,t:1526933706346};\\\", \\\"{x:1377,y:701,t:1526933706363};\\\", \\\"{x:1373,y:702,t:1526933706380};\\\", \\\"{x:1364,y:707,t:1526933706397};\\\", \\\"{x:1358,y:708,t:1526933706413};\\\", \\\"{x:1356,y:711,t:1526933706430};\\\", \\\"{x:1353,y:712,t:1526933706446};\\\", \\\"{x:1352,y:713,t:1526933706463};\\\", \\\"{x:1352,y:714,t:1526933706480};\\\", \\\"{x:1351,y:716,t:1526933706497};\\\", \\\"{x:1349,y:718,t:1526933706512};\\\", \\\"{x:1349,y:720,t:1526933706530};\\\", \\\"{x:1349,y:722,t:1526933706547};\\\", \\\"{x:1349,y:723,t:1526933706563};\\\", \\\"{x:1349,y:726,t:1526933706580};\\\", \\\"{x:1349,y:729,t:1526933706597};\\\", \\\"{x:1349,y:730,t:1526933706613};\\\", \\\"{x:1349,y:734,t:1526933706630};\\\", \\\"{x:1347,y:736,t:1526933706647};\\\", \\\"{x:1347,y:739,t:1526933706663};\\\", \\\"{x:1345,y:744,t:1526933706680};\\\", \\\"{x:1344,y:747,t:1526933706696};\\\", \\\"{x:1343,y:748,t:1526933706713};\\\", \\\"{x:1342,y:750,t:1526933706731};\\\", \\\"{x:1342,y:751,t:1526933706764};\\\", \\\"{x:1340,y:753,t:1526933706788};\\\", \\\"{x:1339,y:756,t:1526933706804};\\\", \\\"{x:1338,y:757,t:1526933706820};\\\", \\\"{x:1338,y:758,t:1526933706861};\\\", \\\"{x:1338,y:760,t:1526933706876};\\\", \\\"{x:1337,y:761,t:1526933706884};\\\", \\\"{x:1337,y:763,t:1526933706917};\\\", \\\"{x:1337,y:764,t:1526933706930};\\\", \\\"{x:1337,y:765,t:1526933707116};\\\", \\\"{x:1340,y:764,t:1526933707524};\\\", \\\"{x:1342,y:763,t:1526933707565};\\\", \\\"{x:1343,y:763,t:1526933707597};\\\", \\\"{x:1344,y:762,t:1526933707644};\\\", \\\"{x:1345,y:762,t:1526933707685};\\\", \\\"{x:1344,y:762,t:1526933713932};\\\", \\\"{x:1344,y:758,t:1526933714406};\\\", \\\"{x:1345,y:752,t:1526933714419};\\\", \\\"{x:1358,y:735,t:1526933714437};\\\", \\\"{x:1362,y:728,t:1526933714453};\\\", \\\"{x:1368,y:714,t:1526933714469};\\\", \\\"{x:1377,y:691,t:1526933714486};\\\", \\\"{x:1392,y:662,t:1526933714503};\\\", \\\"{x:1399,y:647,t:1526933714519};\\\", \\\"{x:1404,y:625,t:1526933714536};\\\", \\\"{x:1410,y:599,t:1526933714553};\\\", \\\"{x:1420,y:573,t:1526933714569};\\\", \\\"{x:1426,y:531,t:1526933714586};\\\", \\\"{x:1434,y:469,t:1526933714603};\\\", \\\"{x:1447,y:415,t:1526933714620};\\\", \\\"{x:1449,y:378,t:1526933714636};\\\", \\\"{x:1447,y:370,t:1526933714653};\\\", \\\"{x:1446,y:367,t:1526933714670};\\\", \\\"{x:1444,y:362,t:1526933714687};\\\", \\\"{x:1444,y:350,t:1526933714703};\\\", \\\"{x:1440,y:336,t:1526933714719};\\\", \\\"{x:1435,y:320,t:1526933714736};\\\", \\\"{x:1431,y:312,t:1526933714753};\\\", \\\"{x:1431,y:311,t:1526933714772};\\\", \\\"{x:1427,y:310,t:1526933714804};\\\", \\\"{x:1416,y:315,t:1526933714820};\\\", \\\"{x:1389,y:333,t:1526933714836};\\\", \\\"{x:1377,y:350,t:1526933714853};\\\", \\\"{x:1373,y:362,t:1526933714871};\\\", \\\"{x:1372,y:379,t:1526933714886};\\\", \\\"{x:1372,y:390,t:1526933714904};\\\", \\\"{x:1372,y:394,t:1526933714921};\\\", \\\"{x:1372,y:397,t:1526933714937};\\\", \\\"{x:1373,y:399,t:1526933714953};\\\", \\\"{x:1374,y:400,t:1526933714970};\\\", \\\"{x:1376,y:403,t:1526933714986};\\\", \\\"{x:1380,y:409,t:1526933715004};\\\", \\\"{x:1385,y:415,t:1526933715020};\\\", \\\"{x:1389,y:419,t:1526933715037};\\\", \\\"{x:1393,y:420,t:1526933715053};\\\", \\\"{x:1399,y:422,t:1526933715070};\\\", \\\"{x:1403,y:423,t:1526933715086};\\\", \\\"{x:1406,y:424,t:1526933715103};\\\", \\\"{x:1411,y:426,t:1526933715121};\\\", \\\"{x:1413,y:426,t:1526933715136};\\\", \\\"{x:1414,y:426,t:1526933715164};\\\", \\\"{x:1415,y:427,t:1526933716325};\\\", \\\"{x:1412,y:437,t:1526933716339};\\\", \\\"{x:1398,y:467,t:1526933716354};\\\", \\\"{x:1376,y:515,t:1526933716371};\\\", \\\"{x:1349,y:554,t:1526933716388};\\\", \\\"{x:1323,y:597,t:1526933716404};\\\", \\\"{x:1309,y:617,t:1526933716421};\\\", \\\"{x:1298,y:632,t:1526933716437};\\\", \\\"{x:1290,y:647,t:1526933716454};\\\", \\\"{x:1285,y:655,t:1526933716471};\\\", \\\"{x:1283,y:664,t:1526933716488};\\\", \\\"{x:1277,y:671,t:1526933716504};\\\", \\\"{x:1273,y:674,t:1526933716521};\\\", \\\"{x:1273,y:673,t:1526933716636};\\\", \\\"{x:1273,y:665,t:1526933716644};\\\", \\\"{x:1273,y:660,t:1526933716655};\\\", \\\"{x:1273,y:652,t:1526933716671};\\\", \\\"{x:1273,y:649,t:1526933716687};\\\", \\\"{x:1275,y:637,t:1526933716704};\\\", \\\"{x:1279,y:625,t:1526933716721};\\\", \\\"{x:1279,y:620,t:1526933716738};\\\", \\\"{x:1279,y:616,t:1526933716754};\\\", \\\"{x:1279,y:609,t:1526933716771};\\\", \\\"{x:1279,y:601,t:1526933716787};\\\", \\\"{x:1279,y:599,t:1526933716804};\\\", \\\"{x:1279,y:598,t:1526933716821};\\\", \\\"{x:1279,y:596,t:1526933716838};\\\", \\\"{x:1279,y:595,t:1526933716854};\\\", \\\"{x:1279,y:593,t:1526933716871};\\\", \\\"{x:1279,y:591,t:1526933716889};\\\", \\\"{x:1279,y:590,t:1526933716904};\\\", \\\"{x:1279,y:586,t:1526933716921};\\\", \\\"{x:1279,y:585,t:1526933716938};\\\", \\\"{x:1279,y:583,t:1526933716954};\\\", \\\"{x:1279,y:580,t:1526933716971};\\\", \\\"{x:1281,y:574,t:1526933716988};\\\", \\\"{x:1282,y:571,t:1526933717004};\\\", \\\"{x:1283,y:570,t:1526933717027};\\\", \\\"{x:1283,y:569,t:1526933717548};\\\", \\\"{x:1283,y:568,t:1526933717573};\\\", \\\"{x:1283,y:567,t:1526933717605};\\\", \\\"{x:1283,y:566,t:1526933717652};\\\", \\\"{x:1284,y:566,t:1526933718315};\\\", \\\"{x:1286,y:566,t:1526933718323};\\\", \\\"{x:1292,y:566,t:1526933718340};\\\", \\\"{x:1301,y:566,t:1526933718355};\\\", \\\"{x:1316,y:566,t:1526933718372};\\\", \\\"{x:1329,y:566,t:1526933718389};\\\", \\\"{x:1339,y:566,t:1526933718406};\\\", \\\"{x:1349,y:566,t:1526933718422};\\\", \\\"{x:1358,y:566,t:1526933718439};\\\", \\\"{x:1365,y:566,t:1526933718456};\\\", \\\"{x:1366,y:567,t:1526933718472};\\\", \\\"{x:1365,y:567,t:1526933718860};\\\", \\\"{x:1362,y:567,t:1526933718874};\\\", \\\"{x:1354,y:567,t:1526933718890};\\\", \\\"{x:1350,y:567,t:1526933718906};\\\", \\\"{x:1349,y:567,t:1526933718924};\\\", \\\"{x:1349,y:566,t:1526933719173};\\\", \\\"{x:1349,y:565,t:1526933719189};\\\", \\\"{x:1350,y:564,t:1526933719221};\\\", \\\"{x:1351,y:563,t:1526933719236};\\\", \\\"{x:1352,y:563,t:1526933719260};\\\", \\\"{x:1354,y:563,t:1526933719273};\\\", \\\"{x:1356,y:563,t:1526933719290};\\\", \\\"{x:1358,y:563,t:1526933719307};\\\", \\\"{x:1361,y:563,t:1526933719323};\\\", \\\"{x:1364,y:562,t:1526933719340};\\\", \\\"{x:1364,y:561,t:1526933719541};\\\", \\\"{x:1366,y:560,t:1526933719556};\\\", \\\"{x:1367,y:560,t:1526933719573};\\\", \\\"{x:1367,y:559,t:1526933719764};\\\", \\\"{x:1367,y:558,t:1526933719836};\\\", \\\"{x:1367,y:557,t:1526933719844};\\\", \\\"{x:1368,y:557,t:1526933719858};\\\", \\\"{x:1371,y:557,t:1526933719874};\\\", \\\"{x:1372,y:557,t:1526933719891};\\\", \\\"{x:1374,y:557,t:1526933720044};\\\", \\\"{x:1376,y:558,t:1526933720057};\\\", \\\"{x:1378,y:559,t:1526933720073};\\\", \\\"{x:1378,y:560,t:1526933720091};\\\", \\\"{x:1378,y:563,t:1526933721717};\\\", \\\"{x:1377,y:568,t:1526933721726};\\\", \\\"{x:1372,y:579,t:1526933721742};\\\", \\\"{x:1361,y:594,t:1526933721759};\\\", \\\"{x:1352,y:605,t:1526933721775};\\\", \\\"{x:1346,y:610,t:1526933721792};\\\", \\\"{x:1337,y:621,t:1526933721808};\\\", \\\"{x:1332,y:627,t:1526933721826};\\\", \\\"{x:1323,y:637,t:1526933721841};\\\", \\\"{x:1312,y:648,t:1526933721859};\\\", \\\"{x:1300,y:660,t:1526933721875};\\\", \\\"{x:1281,y:678,t:1526933721892};\\\", \\\"{x:1268,y:688,t:1526933721909};\\\", \\\"{x:1256,y:695,t:1526933721926};\\\", \\\"{x:1249,y:701,t:1526933721942};\\\", \\\"{x:1243,y:704,t:1526933721959};\\\", \\\"{x:1238,y:708,t:1526933721976};\\\", \\\"{x:1230,y:712,t:1526933721993};\\\", \\\"{x:1221,y:718,t:1526933722009};\\\", \\\"{x:1210,y:725,t:1526933722026};\\\", \\\"{x:1203,y:729,t:1526933722042};\\\", \\\"{x:1201,y:731,t:1526933722059};\\\", \\\"{x:1197,y:733,t:1526933722076};\\\", \\\"{x:1194,y:737,t:1526933722093};\\\", \\\"{x:1193,y:738,t:1526933722108};\\\", \\\"{x:1191,y:740,t:1526933722126};\\\", \\\"{x:1190,y:740,t:1526933722143};\\\", \\\"{x:1190,y:742,t:1526933722164};\\\", \\\"{x:1190,y:743,t:1526933722196};\\\", \\\"{x:1189,y:743,t:1526933722209};\\\", \\\"{x:1188,y:744,t:1526933722226};\\\", \\\"{x:1188,y:745,t:1526933722252};\\\", \\\"{x:1188,y:747,t:1526933722260};\\\", \\\"{x:1188,y:749,t:1526933722276};\\\", \\\"{x:1188,y:751,t:1526933722301};\\\", \\\"{x:1188,y:752,t:1526933722309};\\\", \\\"{x:1188,y:755,t:1526933722325};\\\", \\\"{x:1188,y:759,t:1526933722343};\\\", \\\"{x:1188,y:762,t:1526933722359};\\\", \\\"{x:1188,y:763,t:1526933722376};\\\", \\\"{x:1188,y:765,t:1526933722393};\\\", \\\"{x:1188,y:767,t:1526933722410};\\\", \\\"{x:1189,y:771,t:1526933722426};\\\", \\\"{x:1193,y:775,t:1526933722442};\\\", \\\"{x:1196,y:777,t:1526933722460};\\\", \\\"{x:1199,y:778,t:1526933722475};\\\", \\\"{x:1202,y:779,t:1526933722492};\\\", \\\"{x:1203,y:779,t:1526933722510};\\\", \\\"{x:1207,y:781,t:1526933722526};\\\", \\\"{x:1215,y:786,t:1526933722542};\\\", \\\"{x:1224,y:787,t:1526933722559};\\\", \\\"{x:1230,y:787,t:1526933722575};\\\", \\\"{x:1236,y:787,t:1526933722593};\\\", \\\"{x:1241,y:787,t:1526933722610};\\\", \\\"{x:1247,y:787,t:1526933722626};\\\", \\\"{x:1259,y:787,t:1526933722643};\\\", \\\"{x:1269,y:786,t:1526933722660};\\\", \\\"{x:1285,y:785,t:1526933722676};\\\", \\\"{x:1294,y:783,t:1526933722692};\\\", \\\"{x:1306,y:783,t:1526933722710};\\\", \\\"{x:1317,y:783,t:1526933722726};\\\", \\\"{x:1329,y:783,t:1526933722743};\\\", \\\"{x:1341,y:782,t:1526933722760};\\\", \\\"{x:1347,y:782,t:1526933722776};\\\", \\\"{x:1352,y:782,t:1526933722792};\\\", \\\"{x:1356,y:781,t:1526933722809};\\\", \\\"{x:1359,y:781,t:1526933722826};\\\", \\\"{x:1362,y:781,t:1526933722842};\\\", \\\"{x:1363,y:780,t:1526933722859};\\\", \\\"{x:1364,y:780,t:1526933722955};\\\", \\\"{x:1364,y:778,t:1526933723100};\\\", \\\"{x:1364,y:775,t:1526933723110};\\\", \\\"{x:1363,y:773,t:1526933723127};\\\", \\\"{x:1362,y:771,t:1526933723143};\\\", \\\"{x:1362,y:769,t:1526933723160};\\\", \\\"{x:1362,y:767,t:1526933723176};\\\", \\\"{x:1361,y:767,t:1526933723284};\\\", \\\"{x:1360,y:766,t:1526933723364};\\\", \\\"{x:1359,y:766,t:1526933723484};\\\", \\\"{x:1357,y:766,t:1526933723596};\\\", \\\"{x:1356,y:766,t:1526933723636};\\\", \\\"{x:1354,y:766,t:1526933723725};\\\", \\\"{x:1353,y:766,t:1526933723973};\\\", \\\"{x:1352,y:767,t:1526933724045};\\\", \\\"{x:1351,y:767,t:1526933724092};\\\", \\\"{x:1351,y:768,t:1526933724134};\\\", \\\"{x:1351,y:767,t:1526933724372};\\\", \\\"{x:1351,y:766,t:1526933724924};\\\", \\\"{x:1351,y:765,t:1526933724964};\\\", \\\"{x:1351,y:764,t:1526933725036};\\\", \\\"{x:1351,y:763,t:1526933725157};\\\", \\\"{x:1351,y:762,t:1526933725420};\\\", \\\"{x:1350,y:762,t:1526933725572};\\\", \\\"{x:1349,y:762,t:1526933725707};\\\", \\\"{x:1350,y:762,t:1526933728036};\\\", \\\"{x:1353,y:762,t:1526933728047};\\\", \\\"{x:1357,y:762,t:1526933728065};\\\", \\\"{x:1360,y:762,t:1526933728080};\\\", \\\"{x:1364,y:762,t:1526933728097};\\\", \\\"{x:1367,y:762,t:1526933728114};\\\", \\\"{x:1368,y:762,t:1526933728131};\\\", \\\"{x:1371,y:762,t:1526933728147};\\\", \\\"{x:1372,y:762,t:1526933728163};\\\", \\\"{x:1374,y:762,t:1526933728181};\\\", \\\"{x:1375,y:762,t:1526933728196};\\\", \\\"{x:1377,y:762,t:1526933728219};\\\", \\\"{x:1378,y:762,t:1526933728231};\\\", \\\"{x:1383,y:762,t:1526933728246};\\\", \\\"{x:1389,y:762,t:1526933728263};\\\", \\\"{x:1392,y:762,t:1526933728280};\\\", \\\"{x:1396,y:762,t:1526933728296};\\\", \\\"{x:1399,y:762,t:1526933728313};\\\", \\\"{x:1403,y:762,t:1526933728330};\\\", \\\"{x:1404,y:762,t:1526933728346};\\\", \\\"{x:1409,y:762,t:1526933728364};\\\", \\\"{x:1410,y:762,t:1526933728396};\\\", \\\"{x:1412,y:762,t:1526933728411};\\\", \\\"{x:1415,y:762,t:1526933728420};\\\", \\\"{x:1416,y:762,t:1526933728540};\\\", \\\"{x:1417,y:762,t:1526933729309};\\\", \\\"{x:1419,y:762,t:1526933729316};\\\", \\\"{x:1421,y:762,t:1526933729332};\\\", \\\"{x:1425,y:762,t:1526933729348};\\\", \\\"{x:1427,y:762,t:1526933729365};\\\", \\\"{x:1430,y:762,t:1526933729381};\\\", \\\"{x:1432,y:762,t:1526933729397};\\\", \\\"{x:1433,y:762,t:1526933729415};\\\", \\\"{x:1435,y:762,t:1526933729430};\\\", \\\"{x:1436,y:762,t:1526933729452};\\\", \\\"{x:1438,y:762,t:1526933729468};\\\", \\\"{x:1440,y:762,t:1526933729482};\\\", \\\"{x:1445,y:762,t:1526933729498};\\\", \\\"{x:1447,y:762,t:1526933729515};\\\", \\\"{x:1454,y:763,t:1526933729531};\\\", \\\"{x:1458,y:765,t:1526933729547};\\\", \\\"{x:1459,y:765,t:1526933729564};\\\", \\\"{x:1461,y:765,t:1526933729587};\\\", \\\"{x:1463,y:765,t:1526933729597};\\\", \\\"{x:1467,y:766,t:1526933729614};\\\", \\\"{x:1468,y:766,t:1526933729631};\\\", \\\"{x:1473,y:767,t:1526933729647};\\\", \\\"{x:1476,y:767,t:1526933729665};\\\", \\\"{x:1481,y:768,t:1526933729681};\\\", \\\"{x:1483,y:768,t:1526933729697};\\\", \\\"{x:1484,y:768,t:1526933729724};\\\", \\\"{x:1484,y:767,t:1526933730261};\\\", \\\"{x:1484,y:766,t:1526933730284};\\\", \\\"{x:1484,y:765,t:1526933730349};\\\", \\\"{x:1484,y:764,t:1526933730365};\\\", \\\"{x:1484,y:763,t:1526933730381};\\\", \\\"{x:1484,y:762,t:1526933730403};\\\", \\\"{x:1483,y:760,t:1526933730435};\\\", \\\"{x:1483,y:759,t:1526933730532};\\\", \\\"{x:1482,y:759,t:1526933731364};\\\", \\\"{x:1481,y:759,t:1526933731412};\\\", \\\"{x:1480,y:759,t:1526933731420};\\\", \\\"{x:1479,y:760,t:1526933731452};\\\", \\\"{x:1478,y:760,t:1526933731508};\\\", \\\"{x:1477,y:761,t:1526933731540};\\\", \\\"{x:1477,y:762,t:1526933731628};\\\", \\\"{x:1474,y:764,t:1526933732692};\\\", \\\"{x:1469,y:765,t:1526933732700};\\\", \\\"{x:1452,y:770,t:1526933732717};\\\", \\\"{x:1437,y:775,t:1526933732734};\\\", \\\"{x:1417,y:778,t:1526933732752};\\\", \\\"{x:1416,y:779,t:1526933732770};\\\", \\\"{x:1414,y:779,t:1526933732783};\\\", \\\"{x:1413,y:779,t:1526933732800};\\\", \\\"{x:1405,y:780,t:1526933732817};\\\", \\\"{x:1404,y:780,t:1526933732924};\\\", \\\"{x:1404,y:779,t:1526933732934};\\\", \\\"{x:1404,y:776,t:1526933732950};\\\", \\\"{x:1401,y:773,t:1526933732967};\\\", \\\"{x:1398,y:771,t:1526933732983};\\\", \\\"{x:1393,y:768,t:1526933733000};\\\", \\\"{x:1386,y:767,t:1526933733018};\\\", \\\"{x:1375,y:764,t:1526933733034};\\\", \\\"{x:1363,y:763,t:1526933733051};\\\", \\\"{x:1343,y:762,t:1526933733067};\\\", \\\"{x:1331,y:761,t:1526933733084};\\\", \\\"{x:1316,y:757,t:1526933733101};\\\", \\\"{x:1312,y:756,t:1526933733117};\\\", \\\"{x:1311,y:756,t:1526933733134};\\\", \\\"{x:1312,y:756,t:1526933733258};\\\", \\\"{x:1313,y:758,t:1526933733267};\\\", \\\"{x:1315,y:759,t:1526933733284};\\\", \\\"{x:1318,y:762,t:1526933733300};\\\", \\\"{x:1322,y:763,t:1526933733318};\\\", \\\"{x:1326,y:765,t:1526933733334};\\\", \\\"{x:1328,y:767,t:1526933733350};\\\", \\\"{x:1330,y:767,t:1526933733367};\\\", \\\"{x:1331,y:767,t:1526933733384};\\\", \\\"{x:1332,y:771,t:1526933733435};\\\", \\\"{x:1332,y:776,t:1526933733451};\\\", \\\"{x:1337,y:804,t:1526933733467};\\\", \\\"{x:1334,y:836,t:1526933733484};\\\", \\\"{x:1325,y:863,t:1526933733501};\\\", \\\"{x:1315,y:880,t:1526933733518};\\\", \\\"{x:1306,y:903,t:1526933733535};\\\", \\\"{x:1300,y:923,t:1526933733550};\\\", \\\"{x:1296,y:933,t:1526933733568};\\\", \\\"{x:1296,y:948,t:1526933733584};\\\", \\\"{x:1297,y:972,t:1526933733601};\\\", \\\"{x:1297,y:975,t:1526933733618};\\\", \\\"{x:1304,y:980,t:1526933733635};\\\", \\\"{x:1311,y:990,t:1526933733651};\\\", \\\"{x:1315,y:997,t:1526933733667};\\\", \\\"{x:1315,y:998,t:1526933733684};\\\", \\\"{x:1315,y:999,t:1526933733724};\\\", \\\"{x:1315,y:1000,t:1526933733772};\\\", \\\"{x:1317,y:1000,t:1526933733787};\\\", \\\"{x:1320,y:1000,t:1526933733801};\\\", \\\"{x:1327,y:995,t:1526933733818};\\\", \\\"{x:1332,y:989,t:1526933733835};\\\", \\\"{x:1336,y:980,t:1526933733852};\\\", \\\"{x:1336,y:976,t:1526933733868};\\\", \\\"{x:1336,y:974,t:1526933733886};\\\", \\\"{x:1336,y:973,t:1526933733902};\\\", \\\"{x:1336,y:972,t:1526933733972};\\\", \\\"{x:1337,y:969,t:1526933733995};\\\", \\\"{x:1337,y:967,t:1526933734045};\\\", \\\"{x:1338,y:967,t:1526933734052};\\\", \\\"{x:1338,y:966,t:1526933734068};\\\", \\\"{x:1339,y:966,t:1526933734085};\\\", \\\"{x:1339,y:964,t:1526933734103};\\\", \\\"{x:1340,y:964,t:1526933734117};\\\", \\\"{x:1341,y:963,t:1526933734146};\\\", \\\"{x:1342,y:963,t:1526933734179};\\\", \\\"{x:1343,y:962,t:1526933734429};\\\", \\\"{x:1344,y:961,t:1526933734436};\\\", \\\"{x:1345,y:960,t:1526933734452};\\\", \\\"{x:1348,y:957,t:1526933734469};\\\", \\\"{x:1351,y:951,t:1526933734484};\\\", \\\"{x:1357,y:936,t:1526933734501};\\\", \\\"{x:1358,y:922,t:1526933734518};\\\", \\\"{x:1363,y:901,t:1526933734535};\\\", \\\"{x:1367,y:883,t:1526933734552};\\\", \\\"{x:1371,y:865,t:1526933734569};\\\", \\\"{x:1371,y:848,t:1526933734585};\\\", \\\"{x:1371,y:837,t:1526933734602};\\\", \\\"{x:1371,y:830,t:1526933734619};\\\", \\\"{x:1371,y:822,t:1526933734635};\\\", \\\"{x:1372,y:805,t:1526933734652};\\\", \\\"{x:1372,y:799,t:1526933734669};\\\", \\\"{x:1372,y:795,t:1526933734685};\\\", \\\"{x:1372,y:789,t:1526933734702};\\\", \\\"{x:1370,y:784,t:1526933734720};\\\", \\\"{x:1367,y:780,t:1526933734735};\\\", \\\"{x:1364,y:777,t:1526933734752};\\\", \\\"{x:1361,y:773,t:1526933734769};\\\", \\\"{x:1358,y:768,t:1526933734786};\\\", \\\"{x:1356,y:765,t:1526933734802};\\\", \\\"{x:1355,y:762,t:1526933734819};\\\", \\\"{x:1354,y:761,t:1526933734836};\\\", \\\"{x:1353,y:761,t:1526933735173};\\\", \\\"{x:1351,y:761,t:1526933735755};\\\", \\\"{x:1350,y:761,t:1526933737020};\\\", \\\"{x:1351,y:761,t:1526933737221};\\\", \\\"{x:1357,y:761,t:1526933737238};\\\", \\\"{x:1362,y:761,t:1526933737255};\\\", \\\"{x:1363,y:761,t:1526933737272};\\\", \\\"{x:1366,y:762,t:1526933737287};\\\", \\\"{x:1367,y:762,t:1526933737304};\\\", \\\"{x:1368,y:762,t:1526933737357};\\\", \\\"{x:1369,y:762,t:1526933737371};\\\", \\\"{x:1371,y:762,t:1526933737388};\\\", \\\"{x:1374,y:762,t:1526933737404};\\\", \\\"{x:1377,y:762,t:1526933737421};\\\", \\\"{x:1378,y:762,t:1526933737438};\\\", \\\"{x:1380,y:762,t:1526933737453};\\\", \\\"{x:1381,y:762,t:1526933737470};\\\", \\\"{x:1382,y:762,t:1526933737487};\\\", \\\"{x:1385,y:762,t:1526933737504};\\\", \\\"{x:1388,y:761,t:1526933737520};\\\", \\\"{x:1391,y:761,t:1526933737537};\\\", \\\"{x:1393,y:761,t:1526933737554};\\\", \\\"{x:1395,y:761,t:1526933737571};\\\", \\\"{x:1398,y:761,t:1526933737588};\\\", \\\"{x:1400,y:760,t:1526933737604};\\\", \\\"{x:1401,y:760,t:1526933737621};\\\", \\\"{x:1403,y:760,t:1526933737638};\\\", \\\"{x:1403,y:759,t:1526933737654};\\\", \\\"{x:1404,y:759,t:1526933737683};\\\", \\\"{x:1405,y:759,t:1526933737716};\\\", \\\"{x:1406,y:759,t:1526933737756};\\\", \\\"{x:1407,y:759,t:1526933737771};\\\", \\\"{x:1408,y:759,t:1526933737812};\\\", \\\"{x:1409,y:759,t:1526933737835};\\\", \\\"{x:1411,y:759,t:1526933737885};\\\", \\\"{x:1412,y:759,t:1526933739723};\\\", \\\"{x:1413,y:759,t:1526933739739};\\\", \\\"{x:1414,y:759,t:1526933739756};\\\", \\\"{x:1415,y:759,t:1526933739820};\\\", \\\"{x:1416,y:759,t:1526933739828};\\\", \\\"{x:1417,y:759,t:1526933739852};\\\", \\\"{x:1418,y:759,t:1526933739868};\\\", \\\"{x:1420,y:759,t:1526933739884};\\\", \\\"{x:1421,y:759,t:1526933739899};\\\", \\\"{x:1422,y:758,t:1526933739907};\\\", \\\"{x:1423,y:758,t:1526933739924};\\\", \\\"{x:1424,y:758,t:1526933739964};\\\", \\\"{x:1425,y:758,t:1526933739973};\\\", \\\"{x:1426,y:758,t:1526933739990};\\\", \\\"{x:1428,y:758,t:1526933740006};\\\", \\\"{x:1430,y:758,t:1526933740023};\\\", \\\"{x:1432,y:758,t:1526933740041};\\\", \\\"{x:1434,y:758,t:1526933740060};\\\", \\\"{x:1435,y:758,t:1526933740073};\\\", \\\"{x:1436,y:758,t:1526933740091};\\\", \\\"{x:1437,y:758,t:1526933740106};\\\", \\\"{x:1438,y:758,t:1526933740123};\\\", \\\"{x:1439,y:758,t:1526933740140};\\\", \\\"{x:1440,y:758,t:1526933740157};\\\", \\\"{x:1441,y:758,t:1526933740173};\\\", \\\"{x:1442,y:758,t:1526933740220};\\\", \\\"{x:1444,y:758,t:1526933740228};\\\", \\\"{x:1445,y:758,t:1526933740244};\\\", \\\"{x:1447,y:758,t:1526933740268};\\\", \\\"{x:1448,y:758,t:1526933740284};\\\", \\\"{x:1450,y:758,t:1526933740292};\\\", \\\"{x:1451,y:758,t:1526933740307};\\\", \\\"{x:1452,y:758,t:1526933740323};\\\", \\\"{x:1454,y:758,t:1526933740340};\\\", \\\"{x:1456,y:757,t:1526933740356};\\\", \\\"{x:1457,y:757,t:1526933740373};\\\", \\\"{x:1459,y:757,t:1526933740395};\\\", \\\"{x:1461,y:757,t:1526933740405};\\\", \\\"{x:1463,y:757,t:1526933740422};\\\", \\\"{x:1470,y:757,t:1526933740440};\\\", \\\"{x:1475,y:757,t:1526933740457};\\\", \\\"{x:1482,y:757,t:1526933740472};\\\", \\\"{x:1485,y:757,t:1526933740490};\\\", \\\"{x:1487,y:757,t:1526933740507};\\\", \\\"{x:1488,y:757,t:1526933740579};\\\", \\\"{x:1495,y:759,t:1526933741124};\\\", \\\"{x:1503,y:760,t:1526933741140};\\\", \\\"{x:1518,y:761,t:1526933741158};\\\", \\\"{x:1531,y:762,t:1526933741175};\\\", \\\"{x:1548,y:766,t:1526933741191};\\\", \\\"{x:1557,y:767,t:1526933741208};\\\", \\\"{x:1567,y:770,t:1526933741225};\\\", \\\"{x:1580,y:771,t:1526933741241};\\\", \\\"{x:1593,y:774,t:1526933741256};\\\", \\\"{x:1601,y:774,t:1526933741274};\\\", \\\"{x:1604,y:774,t:1526933741290};\\\", \\\"{x:1606,y:775,t:1526933741306};\\\", \\\"{x:1606,y:777,t:1526933741596};\\\", \\\"{x:1604,y:779,t:1526933741607};\\\", \\\"{x:1603,y:782,t:1526933741625};\\\", \\\"{x:1601,y:785,t:1526933741642};\\\", \\\"{x:1589,y:794,t:1526933741658};\\\", \\\"{x:1584,y:796,t:1526933741674};\\\", \\\"{x:1564,y:805,t:1526933741692};\\\", \\\"{x:1548,y:810,t:1526933741708};\\\", \\\"{x:1531,y:816,t:1526933741725};\\\", \\\"{x:1517,y:824,t:1526933741742};\\\", \\\"{x:1503,y:830,t:1526933741758};\\\", \\\"{x:1493,y:836,t:1526933741775};\\\", \\\"{x:1477,y:846,t:1526933741791};\\\", \\\"{x:1454,y:853,t:1526933741808};\\\", \\\"{x:1441,y:861,t:1526933741824};\\\", \\\"{x:1421,y:864,t:1526933741841};\\\", \\\"{x:1413,y:870,t:1526933741858};\\\", \\\"{x:1399,y:878,t:1526933741875};\\\", \\\"{x:1387,y:884,t:1526933741892};\\\", \\\"{x:1384,y:887,t:1526933741908};\\\", \\\"{x:1383,y:888,t:1526933741924};\\\", \\\"{x:1382,y:889,t:1526933741941};\\\", \\\"{x:1379,y:892,t:1526933741959};\\\", \\\"{x:1377,y:894,t:1526933741974};\\\", \\\"{x:1373,y:900,t:1526933741992};\\\", \\\"{x:1372,y:904,t:1526933742008};\\\", \\\"{x:1372,y:906,t:1526933742025};\\\", \\\"{x:1372,y:908,t:1526933742042};\\\", \\\"{x:1372,y:909,t:1526933742059};\\\", \\\"{x:1372,y:910,t:1526933742074};\\\", \\\"{x:1372,y:914,t:1526933742092};\\\", \\\"{x:1372,y:915,t:1526933742116};\\\", \\\"{x:1372,y:916,t:1526933742156};\\\", \\\"{x:1372,y:917,t:1526933742236};\\\", \\\"{x:1373,y:917,t:1526933742244};\\\", \\\"{x:1374,y:917,t:1526933742259};\\\", \\\"{x:1380,y:915,t:1526933742276};\\\", \\\"{x:1381,y:915,t:1526933742291};\\\", \\\"{x:1383,y:913,t:1526933742309};\\\", \\\"{x:1384,y:912,t:1526933742326};\\\", \\\"{x:1384,y:910,t:1526933742341};\\\", \\\"{x:1385,y:909,t:1526933742358};\\\", \\\"{x:1385,y:907,t:1526933742375};\\\", \\\"{x:1387,y:904,t:1526933742391};\\\", \\\"{x:1387,y:903,t:1526933742407};\\\", \\\"{x:1388,y:902,t:1526933742425};\\\", \\\"{x:1388,y:901,t:1526933742441};\\\", \\\"{x:1388,y:900,t:1526933742483};\\\", \\\"{x:1388,y:899,t:1526933742490};\\\", \\\"{x:1386,y:899,t:1526933742508};\\\", \\\"{x:1384,y:899,t:1526933742524};\\\", \\\"{x:1383,y:899,t:1526933742541};\\\", \\\"{x:1384,y:899,t:1526933742764};\\\", \\\"{x:1387,y:899,t:1526933742775};\\\", \\\"{x:1391,y:899,t:1526933742792};\\\", \\\"{x:1399,y:899,t:1526933742808};\\\", \\\"{x:1407,y:899,t:1526933742825};\\\", \\\"{x:1416,y:899,t:1526933742842};\\\", \\\"{x:1424,y:899,t:1526933742858};\\\", \\\"{x:1439,y:899,t:1526933742875};\\\", \\\"{x:1448,y:899,t:1526933742891};\\\", \\\"{x:1449,y:899,t:1526933742908};\\\", \\\"{x:1450,y:899,t:1526933743012};\\\", \\\"{x:1450,y:898,t:1526933743026};\\\", \\\"{x:1447,y:897,t:1526933743042};\\\", \\\"{x:1443,y:896,t:1526933743059};\\\", \\\"{x:1428,y:895,t:1526933743075};\\\", \\\"{x:1423,y:895,t:1526933743092};\\\", \\\"{x:1420,y:894,t:1526933743108};\\\", \\\"{x:1418,y:894,t:1526933743125};\\\", \\\"{x:1414,y:894,t:1526933743142};\\\", \\\"{x:1409,y:893,t:1526933743160};\\\", \\\"{x:1399,y:891,t:1526933743175};\\\", \\\"{x:1390,y:888,t:1526933743192};\\\", \\\"{x:1374,y:885,t:1526933743209};\\\", \\\"{x:1345,y:881,t:1526933743225};\\\", \\\"{x:1306,y:869,t:1526933743242};\\\", \\\"{x:1201,y:841,t:1526933743260};\\\", \\\"{x:1140,y:824,t:1526933743275};\\\", \\\"{x:1095,y:811,t:1526933743292};\\\", \\\"{x:1055,y:798,t:1526933743310};\\\", \\\"{x:1033,y:791,t:1526933743326};\\\", \\\"{x:1024,y:786,t:1526933743342};\\\", \\\"{x:1023,y:785,t:1526933743359};\\\", \\\"{x:1023,y:784,t:1526933743375};\\\", \\\"{x:1024,y:783,t:1526933743392};\\\", \\\"{x:1025,y:783,t:1526933743409};\\\", \\\"{x:1028,y:781,t:1526933743425};\\\", \\\"{x:1027,y:781,t:1526933743500};\\\", \\\"{x:1023,y:781,t:1526933743510};\\\", \\\"{x:1007,y:781,t:1526933743525};\\\", \\\"{x:980,y:781,t:1526933743543};\\\", \\\"{x:907,y:781,t:1526933743559};\\\", \\\"{x:809,y:781,t:1526933743577};\\\", \\\"{x:711,y:774,t:1526933743592};\\\", \\\"{x:600,y:758,t:1526933743609};\\\", \\\"{x:523,y:740,t:1526933743627};\\\", \\\"{x:451,y:722,t:1526933743642};\\\", \\\"{x:383,y:700,t:1526933743659};\\\", \\\"{x:357,y:687,t:1526933743676};\\\", \\\"{x:351,y:685,t:1526933743693};\\\", \\\"{x:349,y:684,t:1526933743710};\\\", \\\"{x:348,y:683,t:1526933743747};\\\", \\\"{x:346,y:679,t:1526933743760};\\\", \\\"{x:345,y:675,t:1526933743776};\\\", \\\"{x:341,y:668,t:1526933743793};\\\", \\\"{x:338,y:658,t:1526933743810};\\\", \\\"{x:332,y:649,t:1526933743827};\\\", \\\"{x:331,y:648,t:1526933743867};\\\", \\\"{x:331,y:650,t:1526933743877};\\\", \\\"{x:337,y:666,t:1526933743894};\\\", \\\"{x:340,y:681,t:1526933743910};\\\", \\\"{x:350,y:699,t:1526933743927};\\\", \\\"{x:356,y:708,t:1526933743944};\\\", \\\"{x:362,y:715,t:1526933743960};\\\", \\\"{x:362,y:716,t:1526933743977};\\\", \\\"{x:365,y:716,t:1526933743994};\\\", \\\"{x:371,y:715,t:1526933744010};\\\", \\\"{x:382,y:711,t:1526933744027};\\\", \\\"{x:397,y:709,t:1526933744044};\\\", \\\"{x:412,y:709,t:1526933744060};\\\", \\\"{x:423,y:709,t:1526933744077};\\\", \\\"{x:431,y:709,t:1526933744094};\\\", \\\"{x:435,y:709,t:1526933744110};\\\", \\\"{x:442,y:709,t:1526933744127};\\\", \\\"{x:449,y:709,t:1526933744144};\\\", \\\"{x:454,y:709,t:1526933744161};\\\", \\\"{x:457,y:708,t:1526933744177};\\\", \\\"{x:458,y:708,t:1526933744195};\\\", \\\"{x:466,y:711,t:1526933744211};\\\", \\\"{x:481,y:716,t:1526933744227};\\\", \\\"{x:492,y:722,t:1526933744245};\\\", \\\"{x:497,y:724,t:1526933744261};\\\", \\\"{x:499,y:725,t:1526933744277};\\\", \\\"{x:501,y:728,t:1526933744294};\\\", \\\"{x:503,y:731,t:1526933744310};\\\", \\\"{x:507,y:735,t:1526933744327};\\\", \\\"{x:509,y:738,t:1526933744344};\\\" ] }, { \\\"rt\\\": 14782, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 600411, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -12 PM-12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:729,t:1526933746300};\\\", \\\"{x:519,y:724,t:1526933746311};\\\", \\\"{x:523,y:716,t:1526933746329};\\\", \\\"{x:525,y:713,t:1526933746344};\\\", \\\"{x:528,y:709,t:1526933746362};\\\", \\\"{x:533,y:701,t:1526933746387};\\\", \\\"{x:534,y:701,t:1526933746395};\\\", \\\"{x:535,y:699,t:1526933746481};\\\", \\\"{x:536,y:698,t:1526933746495};\\\", \\\"{x:538,y:695,t:1526933746525};\\\", \\\"{x:539,y:694,t:1526933746530};\\\", \\\"{x:540,y:692,t:1526933746546};\\\", \\\"{x:541,y:692,t:1526933746562};\\\", \\\"{x:545,y:688,t:1526933746578};\\\", \\\"{x:550,y:686,t:1526933746596};\\\", \\\"{x:555,y:681,t:1526933746612};\\\", \\\"{x:560,y:678,t:1526933746629};\\\", \\\"{x:561,y:677,t:1526933746646};\\\", \\\"{x:562,y:676,t:1526933746662};\\\", \\\"{x:564,y:675,t:1526933746679};\\\", \\\"{x:567,y:673,t:1526933746699};\\\", \\\"{x:568,y:672,t:1526933746714};\\\", \\\"{x:570,y:671,t:1526933746729};\\\", \\\"{x:573,y:669,t:1526933746746};\\\", \\\"{x:581,y:662,t:1526933746763};\\\", \\\"{x:585,y:656,t:1526933746779};\\\", \\\"{x:589,y:649,t:1526933746796};\\\", \\\"{x:603,y:639,t:1526933746813};\\\", \\\"{x:614,y:633,t:1526933746829};\\\", \\\"{x:626,y:627,t:1526933746847};\\\", \\\"{x:637,y:619,t:1526933746862};\\\", \\\"{x:649,y:613,t:1526933746880};\\\", \\\"{x:667,y:609,t:1526933746896};\\\", \\\"{x:684,y:605,t:1526933746913};\\\", \\\"{x:707,y:601,t:1526933746929};\\\", \\\"{x:733,y:596,t:1526933746947};\\\", \\\"{x:778,y:592,t:1526933746964};\\\", \\\"{x:799,y:592,t:1526933746979};\\\", \\\"{x:815,y:592,t:1526933746996};\\\", \\\"{x:837,y:592,t:1526933747013};\\\", \\\"{x:848,y:592,t:1526933747029};\\\", \\\"{x:856,y:592,t:1526933747046};\\\", \\\"{x:863,y:593,t:1526933747063};\\\", \\\"{x:866,y:593,t:1526933747079};\\\", \\\"{x:867,y:594,t:1526933747100};\\\", \\\"{x:869,y:594,t:1526933747113};\\\", \\\"{x:870,y:595,t:1526933747131};\\\", \\\"{x:871,y:595,t:1526933747146};\\\", \\\"{x:872,y:596,t:1526933747163};\\\", \\\"{x:875,y:596,t:1526933747404};\\\", \\\"{x:876,y:596,t:1526933747415};\\\", \\\"{x:882,y:595,t:1526933747432};\\\", \\\"{x:889,y:594,t:1526933747448};\\\", \\\"{x:899,y:589,t:1526933747465};\\\", \\\"{x:905,y:587,t:1526933747481};\\\", \\\"{x:910,y:587,t:1526933747497};\\\", \\\"{x:919,y:587,t:1526933747513};\\\", \\\"{x:928,y:591,t:1526933747530};\\\", \\\"{x:935,y:597,t:1526933747548};\\\", \\\"{x:939,y:599,t:1526933747563};\\\", \\\"{x:939,y:600,t:1526933747580};\\\", \\\"{x:940,y:600,t:1526933748124};\\\", \\\"{x:941,y:601,t:1526933748286};\\\", \\\"{x:943,y:605,t:1526933750547};\\\", \\\"{x:886,y:628,t:1526933750564};\\\", \\\"{x:825,y:645,t:1526933750582};\\\", \\\"{x:781,y:660,t:1526933750597};\\\", \\\"{x:737,y:669,t:1526933750616};\\\", \\\"{x:708,y:673,t:1526933750632};\\\", \\\"{x:682,y:676,t:1526933750649};\\\", \\\"{x:667,y:676,t:1526933750666};\\\", \\\"{x:656,y:676,t:1526933750683};\\\", \\\"{x:645,y:676,t:1526933750699};\\\", \\\"{x:641,y:676,t:1526933750716};\\\", \\\"{x:637,y:676,t:1526933750732};\\\", \\\"{x:635,y:676,t:1526933750750};\\\", \\\"{x:633,y:676,t:1526933750766};\\\", \\\"{x:631,y:674,t:1526933750795};\\\", \\\"{x:631,y:673,t:1526933750803};\\\", \\\"{x:631,y:671,t:1526933750816};\\\", \\\"{x:631,y:664,t:1526933750833};\\\", \\\"{x:631,y:657,t:1526933750849};\\\", \\\"{x:631,y:647,t:1526933750867};\\\", \\\"{x:631,y:640,t:1526933750882};\\\", \\\"{x:631,y:630,t:1526933750900};\\\", \\\"{x:631,y:623,t:1526933750916};\\\", \\\"{x:631,y:621,t:1526933750932};\\\", \\\"{x:631,y:618,t:1526933750949};\\\", \\\"{x:631,y:614,t:1526933750966};\\\", \\\"{x:630,y:613,t:1526933750982};\\\", \\\"{x:630,y:611,t:1526933750999};\\\", \\\"{x:627,y:608,t:1526933751016};\\\", \\\"{x:626,y:605,t:1526933751032};\\\", \\\"{x:622,y:598,t:1526933751050};\\\", \\\"{x:617,y:592,t:1526933751067};\\\", \\\"{x:615,y:587,t:1526933751083};\\\", \\\"{x:614,y:585,t:1526933751099};\\\", \\\"{x:613,y:580,t:1526933751116};\\\", \\\"{x:610,y:574,t:1526933751133};\\\", \\\"{x:607,y:568,t:1526933751149};\\\", \\\"{x:600,y:554,t:1526933751167};\\\", \\\"{x:588,y:541,t:1526933751183};\\\", \\\"{x:574,y:528,t:1526933751199};\\\", \\\"{x:552,y:509,t:1526933751217};\\\", \\\"{x:546,y:502,t:1526933751233};\\\", \\\"{x:545,y:495,t:1526933751250};\\\", \\\"{x:543,y:489,t:1526933751266};\\\", \\\"{x:547,y:481,t:1526933751284};\\\", \\\"{x:558,y:474,t:1526933751299};\\\", \\\"{x:582,y:466,t:1526933751316};\\\", \\\"{x:606,y:457,t:1526933751333};\\\", \\\"{x:631,y:449,t:1526933751350};\\\", \\\"{x:648,y:444,t:1526933751366};\\\", \\\"{x:664,y:439,t:1526933751384};\\\", \\\"{x:676,y:436,t:1526933751399};\\\", \\\"{x:680,y:434,t:1526933751417};\\\", \\\"{x:685,y:434,t:1526933751434};\\\", \\\"{x:694,y:434,t:1526933751450};\\\", \\\"{x:707,y:435,t:1526933751467};\\\", \\\"{x:722,y:439,t:1526933751484};\\\", \\\"{x:732,y:441,t:1526933751501};\\\", \\\"{x:741,y:446,t:1526933751517};\\\", \\\"{x:750,y:454,t:1526933751534};\\\", \\\"{x:760,y:463,t:1526933751551};\\\", \\\"{x:771,y:473,t:1526933751567};\\\", \\\"{x:782,y:483,t:1526933751584};\\\", \\\"{x:795,y:489,t:1526933751602};\\\", \\\"{x:805,y:494,t:1526933751616};\\\", \\\"{x:806,y:494,t:1526933751634};\\\", \\\"{x:807,y:495,t:1526933751650};\\\", \\\"{x:808,y:495,t:1526933751692};\\\", \\\"{x:810,y:495,t:1526933751723};\\\", \\\"{x:812,y:495,t:1526933751740};\\\", \\\"{x:813,y:495,t:1526933751763};\\\", \\\"{x:813,y:494,t:1526933752154};\\\", \\\"{x:810,y:492,t:1526933752167};\\\", \\\"{x:809,y:492,t:1526933752184};\\\", \\\"{x:812,y:492,t:1526933752564};\\\", \\\"{x:817,y:492,t:1526933752571};\\\", \\\"{x:819,y:492,t:1526933752588};\\\", \\\"{x:821,y:493,t:1526933752907};\\\", \\\"{x:822,y:494,t:1526933752955};\\\", \\\"{x:823,y:494,t:1526933753036};\\\", \\\"{x:824,y:494,t:1526933753051};\\\", \\\"{x:826,y:495,t:1526933753068};\\\", \\\"{x:829,y:495,t:1526933753098};\\\", \\\"{x:829,y:496,t:1526933753107};\\\", \\\"{x:830,y:497,t:1526933753122};\\\", \\\"{x:831,y:497,t:1526933753138};\\\", \\\"{x:832,y:498,t:1526933753154};\\\", \\\"{x:832,y:500,t:1526933753419};\\\", \\\"{x:831,y:500,t:1526933753435};\\\", \\\"{x:830,y:500,t:1526933753451};\\\", \\\"{x:829,y:501,t:1526933753468};\\\", \\\"{x:828,y:501,t:1526933753490};\\\", \\\"{x:824,y:501,t:1526933753869};\\\", \\\"{x:802,y:501,t:1526933753885};\\\", \\\"{x:768,y:501,t:1526933753901};\\\", \\\"{x:691,y:501,t:1526933753919};\\\", \\\"{x:560,y:500,t:1526933753935};\\\", \\\"{x:383,y:493,t:1526933753953};\\\", \\\"{x:214,y:489,t:1526933753969};\\\", \\\"{x:53,y:489,t:1526933753985};\\\", \\\"{x:8,y:480,t:1526933754002};\\\", \\\"{x:8,y:478,t:1526933754018};\\\", \\\"{x:8,y:471,t:1526933754034};\\\", \\\"{x:8,y:469,t:1526933754053};\\\", \\\"{x:8,y:472,t:1526933754115};\\\", \\\"{x:8,y:477,t:1526933754122};\\\", \\\"{x:11,y:486,t:1526933754135};\\\", \\\"{x:20,y:502,t:1526933754153};\\\", \\\"{x:31,y:516,t:1526933754168};\\\", \\\"{x:42,y:523,t:1526933754185};\\\", \\\"{x:53,y:529,t:1526933754203};\\\", \\\"{x:61,y:530,t:1526933754218};\\\", \\\"{x:73,y:535,t:1526933754235};\\\", \\\"{x:84,y:539,t:1526933754251};\\\", \\\"{x:91,y:542,t:1526933754269};\\\", \\\"{x:102,y:546,t:1526933754285};\\\", \\\"{x:106,y:548,t:1526933754302};\\\", \\\"{x:109,y:550,t:1526933754319};\\\", \\\"{x:111,y:551,t:1526933754335};\\\", \\\"{x:111,y:552,t:1526933754351};\\\", \\\"{x:114,y:552,t:1526933754368};\\\", \\\"{x:115,y:552,t:1526933754384};\\\", \\\"{x:118,y:552,t:1526933754401};\\\", \\\"{x:119,y:552,t:1526933754419};\\\", \\\"{x:121,y:552,t:1526933754451};\\\", \\\"{x:125,y:552,t:1526933754469};\\\", \\\"{x:129,y:552,t:1526933754485};\\\", \\\"{x:131,y:551,t:1526933754501};\\\", \\\"{x:132,y:551,t:1526933754518};\\\", \\\"{x:133,y:550,t:1526933754535};\\\", \\\"{x:136,y:549,t:1526933754552};\\\", \\\"{x:138,y:549,t:1526933754569};\\\", \\\"{x:142,y:546,t:1526933754584};\\\", \\\"{x:148,y:544,t:1526933754601};\\\", \\\"{x:150,y:543,t:1526933754618};\\\", \\\"{x:151,y:543,t:1526933754634};\\\", \\\"{x:154,y:541,t:1526933754652};\\\", \\\"{x:155,y:541,t:1526933754669};\\\", \\\"{x:155,y:540,t:1526933754686};\\\", \\\"{x:156,y:540,t:1526933755083};\\\", \\\"{x:157,y:540,t:1526933755091};\\\", \\\"{x:159,y:540,t:1526933755492};\\\", \\\"{x:169,y:542,t:1526933755504};\\\", \\\"{x:198,y:545,t:1526933755521};\\\", \\\"{x:244,y:552,t:1526933755537};\\\", \\\"{x:311,y:562,t:1526933755552};\\\", \\\"{x:422,y:576,t:1526933755569};\\\", \\\"{x:660,y:627,t:1526933755586};\\\", \\\"{x:854,y:659,t:1526933755604};\\\", \\\"{x:1029,y:693,t:1526933755619};\\\", \\\"{x:1206,y:717,t:1526933755636};\\\", \\\"{x:1344,y:730,t:1526933755653};\\\", \\\"{x:1489,y:741,t:1526933755670};\\\", \\\"{x:1619,y:760,t:1526933755687};\\\", \\\"{x:1701,y:768,t:1526933755703};\\\", \\\"{x:1733,y:769,t:1526933755720};\\\", \\\"{x:1743,y:770,t:1526933755736};\\\", \\\"{x:1750,y:770,t:1526933755753};\\\", \\\"{x:1751,y:770,t:1526933755769};\\\", \\\"{x:1747,y:770,t:1526933755907};\\\", \\\"{x:1740,y:770,t:1526933755920};\\\", \\\"{x:1718,y:768,t:1526933755937};\\\", \\\"{x:1695,y:767,t:1526933755953};\\\", \\\"{x:1668,y:767,t:1526933755969};\\\", \\\"{x:1648,y:767,t:1526933755986};\\\", \\\"{x:1564,y:776,t:1526933756003};\\\", \\\"{x:1533,y:777,t:1526933756020};\\\", \\\"{x:1508,y:777,t:1526933756037};\\\", \\\"{x:1489,y:775,t:1526933756054};\\\", \\\"{x:1475,y:775,t:1526933756070};\\\", \\\"{x:1463,y:775,t:1526933756086};\\\", \\\"{x:1456,y:775,t:1526933756104};\\\", \\\"{x:1448,y:775,t:1526933756120};\\\", \\\"{x:1445,y:775,t:1526933756137};\\\", \\\"{x:1442,y:775,t:1526933756153};\\\", \\\"{x:1438,y:775,t:1526933756170};\\\", \\\"{x:1430,y:776,t:1526933756186};\\\", \\\"{x:1417,y:776,t:1526933756203};\\\", \\\"{x:1409,y:776,t:1526933756219};\\\", \\\"{x:1399,y:776,t:1526933756236};\\\", \\\"{x:1386,y:775,t:1526933756254};\\\", \\\"{x:1374,y:773,t:1526933756269};\\\", \\\"{x:1367,y:767,t:1526933756287};\\\", \\\"{x:1348,y:765,t:1526933756305};\\\", \\\"{x:1340,y:763,t:1526933756320};\\\", \\\"{x:1328,y:761,t:1526933756337};\\\", \\\"{x:1324,y:758,t:1526933756353};\\\", \\\"{x:1322,y:758,t:1526933756369};\\\", \\\"{x:1321,y:758,t:1526933756386};\\\", \\\"{x:1322,y:758,t:1526933756532};\\\", \\\"{x:1324,y:758,t:1526933756572};\\\", \\\"{x:1326,y:758,t:1526933756588};\\\", \\\"{x:1327,y:757,t:1526933756604};\\\", \\\"{x:1329,y:756,t:1526933756621};\\\", \\\"{x:1330,y:756,t:1526933756644};\\\", \\\"{x:1331,y:755,t:1526933756660};\\\", \\\"{x:1331,y:758,t:1526933757948};\\\", \\\"{x:1331,y:765,t:1526933757956};\\\", \\\"{x:1331,y:774,t:1526933757971};\\\", \\\"{x:1331,y:792,t:1526933757988};\\\", \\\"{x:1331,y:802,t:1526933758004};\\\", \\\"{x:1331,y:810,t:1526933758020};\\\", \\\"{x:1331,y:819,t:1526933758037};\\\", \\\"{x:1331,y:831,t:1526933758054};\\\", \\\"{x:1336,y:849,t:1526933758069};\\\", \\\"{x:1342,y:872,t:1526933758086};\\\", \\\"{x:1352,y:894,t:1526933758104};\\\", \\\"{x:1357,y:910,t:1526933758120};\\\", \\\"{x:1366,y:926,t:1526933758136};\\\", \\\"{x:1368,y:931,t:1526933758153};\\\", \\\"{x:1371,y:939,t:1526933758169};\\\", \\\"{x:1374,y:947,t:1526933758186};\\\", \\\"{x:1374,y:950,t:1526933758203};\\\", \\\"{x:1374,y:952,t:1526933758219};\\\", \\\"{x:1374,y:954,t:1526933758251};\\\", \\\"{x:1373,y:956,t:1526933758267};\\\", \\\"{x:1371,y:958,t:1526933758275};\\\", \\\"{x:1368,y:961,t:1526933758287};\\\", \\\"{x:1364,y:965,t:1526933758303};\\\", \\\"{x:1356,y:971,t:1526933758319};\\\", \\\"{x:1347,y:976,t:1526933758336};\\\", \\\"{x:1336,y:982,t:1526933758354};\\\", \\\"{x:1330,y:984,t:1526933758369};\\\", \\\"{x:1328,y:985,t:1526933758386};\\\", \\\"{x:1328,y:982,t:1526933758459};\\\", \\\"{x:1328,y:978,t:1526933758470};\\\", \\\"{x:1329,y:965,t:1526933758487};\\\", \\\"{x:1332,y:954,t:1526933758503};\\\", \\\"{x:1335,y:940,t:1526933758520};\\\", \\\"{x:1339,y:929,t:1526933758536};\\\", \\\"{x:1344,y:919,t:1526933758554};\\\", \\\"{x:1346,y:914,t:1526933758570};\\\", \\\"{x:1351,y:904,t:1526933758586};\\\", \\\"{x:1353,y:902,t:1526933758604};\\\", \\\"{x:1354,y:899,t:1526933758620};\\\", \\\"{x:1354,y:897,t:1526933758636};\\\", \\\"{x:1354,y:896,t:1526933758675};\\\", \\\"{x:1354,y:894,t:1526933758687};\\\", \\\"{x:1354,y:890,t:1526933758704};\\\", \\\"{x:1354,y:884,t:1526933758720};\\\", \\\"{x:1354,y:878,t:1526933758737};\\\", \\\"{x:1354,y:871,t:1526933758754};\\\", \\\"{x:1355,y:865,t:1526933758770};\\\", \\\"{x:1355,y:857,t:1526933758787};\\\", \\\"{x:1355,y:845,t:1526933758803};\\\", \\\"{x:1355,y:837,t:1526933758820};\\\", \\\"{x:1355,y:829,t:1526933758837};\\\", \\\"{x:1355,y:824,t:1526933758854};\\\", \\\"{x:1355,y:817,t:1526933758870};\\\", \\\"{x:1355,y:812,t:1526933758887};\\\", \\\"{x:1355,y:808,t:1526933758903};\\\", \\\"{x:1351,y:803,t:1526933758920};\\\", \\\"{x:1350,y:799,t:1526933758937};\\\", \\\"{x:1350,y:794,t:1526933758954};\\\", \\\"{x:1350,y:792,t:1526933758969};\\\", \\\"{x:1350,y:786,t:1526933758987};\\\", \\\"{x:1350,y:781,t:1526933759003};\\\", \\\"{x:1350,y:777,t:1526933759020};\\\", \\\"{x:1349,y:773,t:1526933759037};\\\", \\\"{x:1348,y:771,t:1526933759054};\\\", \\\"{x:1348,y:768,t:1526933759070};\\\", \\\"{x:1348,y:763,t:1526933759086};\\\", \\\"{x:1348,y:757,t:1526933759105};\\\", \\\"{x:1348,y:754,t:1526933759120};\\\", \\\"{x:1348,y:752,t:1526933759137};\\\", \\\"{x:1348,y:749,t:1526933759154};\\\", \\\"{x:1348,y:747,t:1526933759170};\\\", \\\"{x:1348,y:742,t:1526933759188};\\\", \\\"{x:1348,y:740,t:1526933759204};\\\", \\\"{x:1348,y:738,t:1526933759220};\\\", \\\"{x:1348,y:736,t:1526933759237};\\\", \\\"{x:1349,y:735,t:1526933759254};\\\", \\\"{x:1349,y:733,t:1526933759270};\\\", \\\"{x:1349,y:731,t:1526933759287};\\\", \\\"{x:1349,y:729,t:1526933759304};\\\", \\\"{x:1350,y:726,t:1526933759320};\\\", \\\"{x:1351,y:725,t:1526933759337};\\\", \\\"{x:1352,y:722,t:1526933759355};\\\", \\\"{x:1352,y:720,t:1526933759371};\\\", \\\"{x:1352,y:717,t:1526933759388};\\\", \\\"{x:1352,y:714,t:1526933759404};\\\", \\\"{x:1352,y:712,t:1526933759420};\\\", \\\"{x:1352,y:711,t:1526933759437};\\\", \\\"{x:1352,y:707,t:1526933759454};\\\", \\\"{x:1351,y:706,t:1526933759470};\\\", \\\"{x:1351,y:705,t:1526933759487};\\\", \\\"{x:1351,y:704,t:1526933759507};\\\", \\\"{x:1346,y:704,t:1526933759916};\\\", \\\"{x:1334,y:704,t:1526933759924};\\\", \\\"{x:1322,y:704,t:1526933759938};\\\", \\\"{x:1275,y:704,t:1526933759954};\\\", \\\"{x:1129,y:711,t:1526933759972};\\\", \\\"{x:1007,y:730,t:1526933759988};\\\", \\\"{x:896,y:734,t:1526933760004};\\\", \\\"{x:803,y:742,t:1526933760020};\\\", \\\"{x:707,y:761,t:1526933760037};\\\", \\\"{x:661,y:768,t:1526933760054};\\\", \\\"{x:630,y:770,t:1526933760071};\\\", \\\"{x:612,y:772,t:1526933760087};\\\", \\\"{x:607,y:773,t:1526933760104};\\\", \\\"{x:600,y:775,t:1526933760120};\\\", \\\"{x:591,y:781,t:1526933760137};\\\", \\\"{x:589,y:783,t:1526933760154};\\\", \\\"{x:582,y:787,t:1526933760146};\\\", \\\"{x:573,y:787,t:1526933760161};\\\", \\\"{x:565,y:787,t:1526933760178};\\\", \\\"{x:561,y:787,t:1526933760194};\\\", \\\"{x:559,y:787,t:1526933760211};\\\", \\\"{x:558,y:785,t:1526933760241};\\\", \\\"{x:556,y:780,t:1526933760249};\\\", \\\"{x:551,y:769,t:1526933760261};\\\", \\\"{x:540,y:753,t:1526933760280};\\\", \\\"{x:524,y:733,t:1526933760294};\\\", \\\"{x:513,y:720,t:1526933760311};\\\", \\\"{x:509,y:717,t:1526933760330};\\\", \\\"{x:507,y:716,t:1526933760346};\\\", \\\"{x:506,y:713,t:1526933760364};\\\", \\\"{x:505,y:713,t:1526933760382};\\\", \\\"{x:505,y:714,t:1526933760609};\\\", \\\"{x:505,y:715,t:1526933760616};\\\", \\\"{x:505,y:717,t:1526933760632};\\\", \\\"{x:505,y:719,t:1526933760648};\\\", \\\"{x:505,y:721,t:1526933760665};\\\", \\\"{x:505,y:723,t:1526933760682};\\\", \\\"{x:505,y:724,t:1526933760698};\\\", \\\"{x:505,y:725,t:1526933760753};\\\", \\\"{x:505,y:726,t:1526933760764};\\\", \\\"{x:505,y:727,t:1526933760781};\\\", \\\"{x:507,y:729,t:1526933760797};\\\" ] }, { \\\"rt\\\": 8621, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 610232, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:730,t:1526933762569};\\\", \\\"{x:514,y:729,t:1526933762583};\\\", \\\"{x:523,y:724,t:1526933762601};\\\", \\\"{x:528,y:721,t:1526933762617};\\\", \\\"{x:532,y:718,t:1526933762634};\\\", \\\"{x:535,y:716,t:1526933762650};\\\", \\\"{x:536,y:716,t:1526933762667};\\\", \\\"{x:539,y:714,t:1526933762682};\\\", \\\"{x:545,y:713,t:1526933762699};\\\", \\\"{x:548,y:712,t:1526933762716};\\\", \\\"{x:549,y:712,t:1526933762733};\\\", \\\"{x:551,y:712,t:1526933762750};\\\", \\\"{x:553,y:711,t:1526933762767};\\\", \\\"{x:556,y:710,t:1526933762782};\\\", \\\"{x:607,y:708,t:1526933762864};\\\", \\\"{x:609,y:708,t:1526933762868};\\\", \\\"{x:611,y:708,t:1526933762884};\\\", \\\"{x:612,y:708,t:1526933762900};\\\", \\\"{x:613,y:708,t:1526933762921};\\\", \\\"{x:617,y:710,t:1526933762933};\\\", \\\"{x:623,y:711,t:1526933762949};\\\", \\\"{x:632,y:711,t:1526933762967};\\\", \\\"{x:640,y:714,t:1526933762983};\\\", \\\"{x:650,y:716,t:1526933762999};\\\", \\\"{x:659,y:718,t:1526933763016};\\\", \\\"{x:669,y:721,t:1526933763034};\\\", \\\"{x:675,y:724,t:1526933763050};\\\", \\\"{x:683,y:725,t:1526933763066};\\\", \\\"{x:688,y:726,t:1526933763084};\\\", \\\"{x:694,y:728,t:1526933763099};\\\", \\\"{x:702,y:729,t:1526933763117};\\\", \\\"{x:717,y:733,t:1526933763134};\\\", \\\"{x:738,y:739,t:1526933763150};\\\", \\\"{x:756,y:745,t:1526933763166};\\\", \\\"{x:787,y:748,t:1526933763183};\\\", \\\"{x:816,y:754,t:1526933763200};\\\", \\\"{x:863,y:763,t:1526933763217};\\\", \\\"{x:897,y:771,t:1526933763234};\\\", \\\"{x:928,y:781,t:1526933763249};\\\", \\\"{x:988,y:794,t:1526933763266};\\\", \\\"{x:1037,y:803,t:1526933763284};\\\", \\\"{x:1111,y:823,t:1526933763299};\\\", \\\"{x:1197,y:846,t:1526933763317};\\\", \\\"{x:1284,y:863,t:1526933763334};\\\", \\\"{x:1369,y:882,t:1526933763350};\\\", \\\"{x:1440,y:898,t:1526933763366};\\\", \\\"{x:1494,y:907,t:1526933763384};\\\", \\\"{x:1530,y:915,t:1526933763400};\\\", \\\"{x:1577,y:925,t:1526933763416};\\\", \\\"{x:1602,y:932,t:1526933763433};\\\", \\\"{x:1618,y:942,t:1526933763451};\\\", \\\"{x:1632,y:952,t:1526933763467};\\\", \\\"{x:1657,y:957,t:1526933763483};\\\", \\\"{x:1668,y:961,t:1526933763501};\\\", \\\"{x:1669,y:961,t:1526933764778};\\\", \\\"{x:1670,y:960,t:1526933764906};\\\", \\\"{x:1670,y:959,t:1526933764928};\\\", \\\"{x:1670,y:958,t:1526933764945};\\\", \\\"{x:1670,y:954,t:1526933764961};\\\", \\\"{x:1669,y:954,t:1526933764969};\\\", \\\"{x:1663,y:949,t:1526933764985};\\\", \\\"{x:1651,y:942,t:1526933765002};\\\", \\\"{x:1635,y:939,t:1526933765018};\\\", \\\"{x:1618,y:934,t:1526933765035};\\\", \\\"{x:1604,y:930,t:1526933765052};\\\", \\\"{x:1580,y:922,t:1526933765068};\\\", \\\"{x:1563,y:917,t:1526933765085};\\\", \\\"{x:1524,y:913,t:1526933765103};\\\", \\\"{x:1465,y:903,t:1526933765118};\\\", \\\"{x:1411,y:894,t:1526933765136};\\\", \\\"{x:1370,y:884,t:1526933765152};\\\", \\\"{x:1340,y:881,t:1526933765168};\\\", \\\"{x:1293,y:871,t:1526933765185};\\\", \\\"{x:1266,y:865,t:1526933765202};\\\", \\\"{x:1243,y:862,t:1526933765220};\\\", \\\"{x:1223,y:857,t:1526933765235};\\\", \\\"{x:1215,y:854,t:1526933765252};\\\", \\\"{x:1208,y:854,t:1526933765270};\\\", \\\"{x:1199,y:851,t:1526933765286};\\\", \\\"{x:1193,y:847,t:1526933765302};\\\", \\\"{x:1187,y:842,t:1526933765320};\\\", \\\"{x:1186,y:842,t:1526933765728};\\\", \\\"{x:1184,y:842,t:1526933765736};\\\", \\\"{x:1183,y:842,t:1526933765752};\\\", \\\"{x:1182,y:842,t:1526933765817};\\\", \\\"{x:1176,y:840,t:1526933765824};\\\", \\\"{x:1176,y:838,t:1526933765836};\\\", \\\"{x:1171,y:836,t:1526933765852};\\\", \\\"{x:1158,y:834,t:1526933765869};\\\", \\\"{x:1150,y:832,t:1526933765885};\\\", \\\"{x:1142,y:828,t:1526933765902};\\\", \\\"{x:1132,y:822,t:1526933765919};\\\", \\\"{x:1119,y:817,t:1526933765935};\\\", \\\"{x:1103,y:804,t:1526933765951};\\\", \\\"{x:1073,y:786,t:1526933765969};\\\", \\\"{x:1060,y:784,t:1526933765986};\\\", \\\"{x:1044,y:785,t:1526933766001};\\\", \\\"{x:1029,y:776,t:1526933766019};\\\", \\\"{x:1018,y:771,t:1526933766036};\\\", \\\"{x:997,y:764,t:1526933766052};\\\", \\\"{x:975,y:755,t:1526933766069};\\\", \\\"{x:960,y:745,t:1526933766086};\\\", \\\"{x:944,y:742,t:1526933766103};\\\", \\\"{x:935,y:735,t:1526933766119};\\\", \\\"{x:919,y:732,t:1526933766136};\\\", \\\"{x:885,y:722,t:1526933766152};\\\", \\\"{x:865,y:713,t:1526933766169};\\\", \\\"{x:860,y:712,t:1526933766185};\\\", \\\"{x:855,y:707,t:1526933766203};\\\", \\\"{x:854,y:707,t:1526933766219};\\\", \\\"{x:852,y:707,t:1526933766985};\\\", \\\"{x:847,y:706,t:1526933767003};\\\", \\\"{x:845,y:705,t:1526933767020};\\\", \\\"{x:841,y:704,t:1526933767037};\\\", \\\"{x:832,y:703,t:1526933767053};\\\", \\\"{x:826,y:701,t:1526933767071};\\\", \\\"{x:815,y:699,t:1526933767087};\\\", \\\"{x:808,y:696,t:1526933767103};\\\", \\\"{x:794,y:692,t:1526933767120};\\\", \\\"{x:776,y:687,t:1526933767137};\\\", \\\"{x:759,y:682,t:1526933767153};\\\", \\\"{x:737,y:679,t:1526933767170};\\\", \\\"{x:722,y:670,t:1526933767187};\\\", \\\"{x:701,y:668,t:1526933767203};\\\", \\\"{x:670,y:658,t:1526933767220};\\\", \\\"{x:635,y:652,t:1526933767238};\\\", \\\"{x:606,y:643,t:1526933767253};\\\", \\\"{x:581,y:638,t:1526933767270};\\\", \\\"{x:554,y:632,t:1526933767287};\\\", \\\"{x:530,y:627,t:1526933767304};\\\", \\\"{x:510,y:619,t:1526933767320};\\\", \\\"{x:482,y:611,t:1526933767337};\\\", \\\"{x:467,y:607,t:1526933767353};\\\", \\\"{x:446,y:605,t:1526933767370};\\\", \\\"{x:441,y:602,t:1526933767387};\\\", \\\"{x:437,y:602,t:1526933767403};\\\", \\\"{x:435,y:602,t:1526933767420};\\\", \\\"{x:434,y:602,t:1526933767472};\\\", \\\"{x:434,y:601,t:1526933767486};\\\", \\\"{x:432,y:601,t:1526933767504};\\\", \\\"{x:431,y:601,t:1526933767554};\\\", \\\"{x:429,y:601,t:1526933767609};\\\", \\\"{x:429,y:600,t:1526933767675};\\\", \\\"{x:429,y:599,t:1526933767687};\\\", \\\"{x:429,y:598,t:1526933767712};\\\", \\\"{x:430,y:596,t:1526933767736};\\\", \\\"{x:431,y:596,t:1526933767745};\\\", \\\"{x:431,y:595,t:1526933767754};\\\", \\\"{x:435,y:594,t:1526933767771};\\\", \\\"{x:438,y:591,t:1526933767788};\\\", \\\"{x:440,y:588,t:1526933767803};\\\", \\\"{x:442,y:587,t:1526933767821};\\\", \\\"{x:442,y:586,t:1526933767840};\\\", \\\"{x:442,y:584,t:1526933767937};\\\", \\\"{x:442,y:582,t:1526933767954};\\\", \\\"{x:440,y:576,t:1526933767971};\\\", \\\"{x:437,y:574,t:1526933767987};\\\", \\\"{x:434,y:574,t:1526933768152};\\\", \\\"{x:433,y:574,t:1526933768161};\\\", \\\"{x:432,y:574,t:1526933768171};\\\", \\\"{x:428,y:575,t:1526933768188};\\\", \\\"{x:424,y:577,t:1526933768204};\\\", \\\"{x:423,y:578,t:1526933768221};\\\", \\\"{x:420,y:581,t:1526933768238};\\\", \\\"{x:417,y:582,t:1526933768255};\\\", \\\"{x:415,y:583,t:1526933768271};\\\", \\\"{x:415,y:584,t:1526933768288};\\\", \\\"{x:415,y:586,t:1526933768305};\\\", \\\"{x:415,y:587,t:1526933768321};\\\", \\\"{x:417,y:588,t:1526933768338};\\\", \\\"{x:422,y:590,t:1526933768356};\\\", \\\"{x:431,y:591,t:1526933768371};\\\", \\\"{x:455,y:599,t:1526933768388};\\\", \\\"{x:491,y:608,t:1526933768405};\\\", \\\"{x:550,y:616,t:1526933768421};\\\", \\\"{x:592,y:622,t:1526933768437};\\\", \\\"{x:636,y:622,t:1526933768454};\\\", \\\"{x:679,y:622,t:1526933768470};\\\", \\\"{x:701,y:622,t:1526933768487};\\\", \\\"{x:719,y:622,t:1526933768504};\\\", \\\"{x:727,y:618,t:1526933768522};\\\", \\\"{x:731,y:610,t:1526933768538};\\\", \\\"{x:732,y:604,t:1526933768554};\\\", \\\"{x:732,y:599,t:1526933768572};\\\", \\\"{x:734,y:593,t:1526933768588};\\\", \\\"{x:735,y:589,t:1526933768605};\\\", \\\"{x:735,y:585,t:1526933768621};\\\", \\\"{x:735,y:583,t:1526933768638};\\\", \\\"{x:735,y:581,t:1526933768655};\\\", \\\"{x:735,y:580,t:1526933768672};\\\", \\\"{x:736,y:579,t:1526933768696};\\\", \\\"{x:739,y:579,t:1526933768704};\\\", \\\"{x:754,y:579,t:1526933768720};\\\", \\\"{x:776,y:579,t:1526933768737};\\\", \\\"{x:805,y:579,t:1526933768755};\\\", \\\"{x:827,y:578,t:1526933768771};\\\", \\\"{x:851,y:578,t:1526933768788};\\\", \\\"{x:869,y:576,t:1526933768805};\\\", \\\"{x:884,y:576,t:1526933768822};\\\", \\\"{x:890,y:576,t:1526933768838};\\\", \\\"{x:892,y:575,t:1526933768855};\\\", \\\"{x:892,y:574,t:1526933768897};\\\", \\\"{x:892,y:573,t:1526933768913};\\\", \\\"{x:893,y:571,t:1526933768929};\\\", \\\"{x:894,y:570,t:1526933768938};\\\", \\\"{x:894,y:569,t:1526933768955};\\\", \\\"{x:893,y:566,t:1526933768973};\\\", \\\"{x:882,y:561,t:1526933768989};\\\", \\\"{x:864,y:554,t:1526933769005};\\\", \\\"{x:834,y:543,t:1526933769021};\\\", \\\"{x:789,y:536,t:1526933769038};\\\", \\\"{x:692,y:527,t:1526933769055};\\\", \\\"{x:563,y:516,t:1526933769073};\\\", \\\"{x:405,y:512,t:1526933769088};\\\", \\\"{x:151,y:494,t:1526933769106};\\\", \\\"{x:8,y:483,t:1526933769122};\\\", \\\"{x:8,y:484,t:1526933769176};\\\", \\\"{x:8,y:485,t:1526933769225};\\\", \\\"{x:8,y:486,t:1526933769239};\\\", \\\"{x:10,y:490,t:1526933769256};\\\", \\\"{x:14,y:495,t:1526933769272};\\\", \\\"{x:18,y:502,t:1526933769289};\\\", \\\"{x:22,y:506,t:1526933769306};\\\", \\\"{x:26,y:511,t:1526933769323};\\\", \\\"{x:34,y:518,t:1526933769339};\\\", \\\"{x:45,y:525,t:1526933769356};\\\", \\\"{x:56,y:530,t:1526933769375};\\\", \\\"{x:65,y:535,t:1526933769390};\\\", \\\"{x:73,y:539,t:1526933769405};\\\", \\\"{x:81,y:542,t:1526933769421};\\\", \\\"{x:85,y:543,t:1526933769439};\\\", \\\"{x:86,y:543,t:1526933769456};\\\", \\\"{x:87,y:543,t:1526933769480};\\\", \\\"{x:88,y:543,t:1526933769488};\\\", \\\"{x:89,y:543,t:1526933769505};\\\", \\\"{x:92,y:543,t:1526933769522};\\\", \\\"{x:96,y:543,t:1526933769538};\\\", \\\"{x:99,y:543,t:1526933769555};\\\", \\\"{x:106,y:543,t:1526933769572};\\\", \\\"{x:109,y:543,t:1526933769589};\\\", \\\"{x:112,y:543,t:1526933769604};\\\", \\\"{x:117,y:543,t:1526933769622};\\\", \\\"{x:120,y:543,t:1526933769639};\\\", \\\"{x:126,y:543,t:1526933769654};\\\", \\\"{x:130,y:543,t:1526933769672};\\\", \\\"{x:135,y:543,t:1526933769688};\\\", \\\"{x:137,y:543,t:1526933769706};\\\", \\\"{x:140,y:543,t:1526933769722};\\\", \\\"{x:144,y:543,t:1526933769739};\\\", \\\"{x:148,y:543,t:1526933769756};\\\", \\\"{x:149,y:543,t:1526933769773};\\\", \\\"{x:150,y:543,t:1526933769789};\\\", \\\"{x:151,y:543,t:1526933770225};\\\", \\\"{x:153,y:543,t:1526933770239};\\\", \\\"{x:184,y:560,t:1526933770257};\\\", \\\"{x:276,y:607,t:1526933770273};\\\", \\\"{x:377,y:641,t:1526933770290};\\\", \\\"{x:467,y:677,t:1526933770306};\\\", \\\"{x:525,y:702,t:1526933770323};\\\", \\\"{x:579,y:721,t:1526933770339};\\\", \\\"{x:599,y:727,t:1526933770356};\\\", \\\"{x:614,y:732,t:1526933770372};\\\", \\\"{x:620,y:736,t:1526933770389};\\\", \\\"{x:623,y:737,t:1526933770406};\\\", \\\"{x:625,y:738,t:1526933770423};\\\", \\\"{x:627,y:741,t:1526933770439};\\\", \\\"{x:631,y:745,t:1526933770456};\\\", \\\"{x:639,y:750,t:1526933770473};\\\", \\\"{x:642,y:751,t:1526933770490};\\\", \\\"{x:639,y:751,t:1526933770553};\\\", \\\"{x:628,y:749,t:1526933770561};\\\", \\\"{x:608,y:744,t:1526933770573};\\\", \\\"{x:550,y:730,t:1526933770591};\\\", \\\"{x:527,y:725,t:1526933770607};\\\", \\\"{x:516,y:723,t:1526933770623};\\\", \\\"{x:509,y:722,t:1526933770640};\\\", \\\"{x:506,y:721,t:1526933770657};\\\", \\\"{x:505,y:721,t:1526933770696};\\\" ] }, { \\\"rt\\\": 64562, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 676013, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -E -H -Z -F -B -O -F -Z -C -C -E -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:721,t:1526933772157};\\\", \\\"{x:502,y:721,t:1526933773345};\\\", \\\"{x:499,y:719,t:1526933773367};\\\", \\\"{x:495,y:718,t:1526933773377};\\\", \\\"{x:492,y:718,t:1526933773394};\\\", \\\"{x:489,y:718,t:1526933773408};\\\", \\\"{x:485,y:718,t:1526933773424};\\\", \\\"{x:484,y:718,t:1526933773442};\\\", \\\"{x:482,y:718,t:1526933773458};\\\", \\\"{x:480,y:718,t:1526933773475};\\\", \\\"{x:477,y:718,t:1526933773492};\\\", \\\"{x:476,y:718,t:1526933773508};\\\", \\\"{x:475,y:718,t:1526933773525};\\\", \\\"{x:473,y:718,t:1526933773542};\\\", \\\"{x:472,y:718,t:1526933773633};\\\", \\\"{x:474,y:718,t:1526933773849};\\\", \\\"{x:479,y:718,t:1526933773859};\\\", \\\"{x:502,y:719,t:1526933773875};\\\", \\\"{x:561,y:722,t:1526933773893};\\\", \\\"{x:642,y:731,t:1526933773909};\\\", \\\"{x:744,y:743,t:1526933773925};\\\", \\\"{x:845,y:751,t:1526933773942};\\\", \\\"{x:969,y:761,t:1526933773959};\\\", \\\"{x:1123,y:774,t:1526933773977};\\\", \\\"{x:1209,y:783,t:1526933773992};\\\", \\\"{x:1285,y:787,t:1526933774010};\\\", \\\"{x:1317,y:789,t:1526933774026};\\\", \\\"{x:1337,y:790,t:1526933774042};\\\", \\\"{x:1356,y:790,t:1526933774059};\\\", \\\"{x:1376,y:790,t:1526933774076};\\\", \\\"{x:1387,y:790,t:1526933774092};\\\", \\\"{x:1389,y:790,t:1526933774109};\\\", \\\"{x:1389,y:791,t:1526933775321};\\\", \\\"{x:1388,y:792,t:1526933775330};\\\", \\\"{x:1388,y:794,t:1526933775344};\\\", \\\"{x:1384,y:802,t:1526933775361};\\\", \\\"{x:1381,y:806,t:1526933775377};\\\", \\\"{x:1380,y:810,t:1526933775393};\\\", \\\"{x:1379,y:811,t:1526933775411};\\\", \\\"{x:1378,y:813,t:1526933775427};\\\", \\\"{x:1377,y:813,t:1526933775444};\\\", \\\"{x:1377,y:814,t:1526933775473};\\\", \\\"{x:1376,y:815,t:1526933775489};\\\", \\\"{x:1374,y:816,t:1526933775521};\\\", \\\"{x:1373,y:817,t:1526933775546};\\\", \\\"{x:1372,y:818,t:1526933775577};\\\", \\\"{x:1370,y:818,t:1526933775594};\\\", \\\"{x:1368,y:818,t:1526933775611};\\\", \\\"{x:1366,y:818,t:1526933775628};\\\", \\\"{x:1364,y:818,t:1526933775644};\\\", \\\"{x:1362,y:818,t:1526933775661};\\\", \\\"{x:1359,y:818,t:1526933775678};\\\", \\\"{x:1356,y:818,t:1526933775693};\\\", \\\"{x:1353,y:818,t:1526933775711};\\\", \\\"{x:1349,y:818,t:1526933775729};\\\", \\\"{x:1348,y:818,t:1526933775744};\\\", \\\"{x:1350,y:816,t:1526933775841};\\\", \\\"{x:1352,y:816,t:1526933775848};\\\", \\\"{x:1354,y:812,t:1526933775860};\\\", \\\"{x:1362,y:809,t:1526933775877};\\\", \\\"{x:1372,y:805,t:1526933775894};\\\", \\\"{x:1388,y:801,t:1526933775910};\\\", \\\"{x:1403,y:799,t:1526933775928};\\\", \\\"{x:1439,y:795,t:1526933775944};\\\", \\\"{x:1475,y:790,t:1526933775961};\\\", \\\"{x:1515,y:785,t:1526933775977};\\\", \\\"{x:1539,y:784,t:1526933775995};\\\", \\\"{x:1560,y:786,t:1526933776010};\\\", \\\"{x:1588,y:787,t:1526933776027};\\\", \\\"{x:1608,y:787,t:1526933776045};\\\", \\\"{x:1622,y:787,t:1526933776060};\\\", \\\"{x:1633,y:784,t:1526933776077};\\\", \\\"{x:1642,y:782,t:1526933776095};\\\", \\\"{x:1645,y:781,t:1526933776110};\\\", \\\"{x:1646,y:780,t:1526933776128};\\\", \\\"{x:1648,y:777,t:1526933776145};\\\", \\\"{x:1648,y:772,t:1526933776161};\\\", \\\"{x:1649,y:764,t:1526933776178};\\\", \\\"{x:1649,y:754,t:1526933776195};\\\", \\\"{x:1649,y:747,t:1526933776211};\\\", \\\"{x:1649,y:743,t:1526933776228};\\\", \\\"{x:1646,y:739,t:1526933776244};\\\", \\\"{x:1637,y:732,t:1526933776261};\\\", \\\"{x:1624,y:726,t:1526933776277};\\\", \\\"{x:1603,y:712,t:1526933776294};\\\", \\\"{x:1582,y:703,t:1526933776312};\\\", \\\"{x:1566,y:693,t:1526933776327};\\\", \\\"{x:1556,y:685,t:1526933776345};\\\", \\\"{x:1552,y:681,t:1526933776361};\\\", \\\"{x:1548,y:678,t:1526933776377};\\\", \\\"{x:1546,y:674,t:1526933776395};\\\", \\\"{x:1543,y:671,t:1526933776412};\\\", \\\"{x:1540,y:668,t:1526933776428};\\\", \\\"{x:1534,y:664,t:1526933776445};\\\", \\\"{x:1528,y:661,t:1526933776461};\\\", \\\"{x:1522,y:657,t:1526933776477};\\\", \\\"{x:1508,y:649,t:1526933776495};\\\", \\\"{x:1492,y:641,t:1526933776511};\\\", \\\"{x:1471,y:632,t:1526933776528};\\\", \\\"{x:1455,y:624,t:1526933776545};\\\", \\\"{x:1422,y:611,t:1526933776562};\\\", \\\"{x:1412,y:609,t:1526933776578};\\\", \\\"{x:1402,y:604,t:1526933776594};\\\", \\\"{x:1394,y:600,t:1526933776611};\\\", \\\"{x:1382,y:597,t:1526933776628};\\\", \\\"{x:1375,y:595,t:1526933776644};\\\", \\\"{x:1371,y:592,t:1526933776662};\\\", \\\"{x:1370,y:592,t:1526933776678};\\\", \\\"{x:1370,y:582,t:1526933776770};\\\", \\\"{x:1370,y:577,t:1526933776779};\\\", \\\"{x:1382,y:546,t:1526933776795};\\\", \\\"{x:1400,y:511,t:1526933776812};\\\", \\\"{x:1411,y:485,t:1526933776829};\\\", \\\"{x:1425,y:464,t:1526933776844};\\\", \\\"{x:1436,y:448,t:1526933776862};\\\", \\\"{x:1444,y:433,t:1526933776879};\\\", \\\"{x:1449,y:421,t:1526933776895};\\\", \\\"{x:1454,y:413,t:1526933776912};\\\", \\\"{x:1462,y:400,t:1526933776929};\\\", \\\"{x:1466,y:392,t:1526933776945};\\\", \\\"{x:1472,y:386,t:1526933776962};\\\", \\\"{x:1473,y:384,t:1526933776979};\\\", \\\"{x:1475,y:383,t:1526933776995};\\\", \\\"{x:1474,y:383,t:1526933777050};\\\", \\\"{x:1471,y:391,t:1526933777062};\\\", \\\"{x:1471,y:414,t:1526933777079};\\\", \\\"{x:1469,y:440,t:1526933777096};\\\", \\\"{x:1463,y:462,t:1526933777112};\\\", \\\"{x:1453,y:495,t:1526933777129};\\\", \\\"{x:1451,y:510,t:1526933777145};\\\", \\\"{x:1448,y:525,t:1526933777162};\\\", \\\"{x:1448,y:537,t:1526933777179};\\\", \\\"{x:1447,y:544,t:1526933777196};\\\", \\\"{x:1447,y:551,t:1526933777212};\\\", \\\"{x:1446,y:556,t:1526933777229};\\\", \\\"{x:1443,y:566,t:1526933777246};\\\", \\\"{x:1442,y:572,t:1526933777262};\\\", \\\"{x:1442,y:581,t:1526933777279};\\\", \\\"{x:1442,y:585,t:1526933777296};\\\", \\\"{x:1442,y:595,t:1526933777312};\\\", \\\"{x:1442,y:600,t:1526933777329};\\\", \\\"{x:1442,y:614,t:1526933777346};\\\", \\\"{x:1437,y:629,t:1526933777362};\\\", \\\"{x:1437,y:637,t:1526933777379};\\\", \\\"{x:1437,y:642,t:1526933777396};\\\", \\\"{x:1437,y:657,t:1526933777412};\\\", \\\"{x:1436,y:671,t:1526933777428};\\\", \\\"{x:1434,y:682,t:1526933777446};\\\", \\\"{x:1432,y:691,t:1526933777462};\\\", \\\"{x:1424,y:701,t:1526933777479};\\\", \\\"{x:1414,y:709,t:1526933777496};\\\", \\\"{x:1403,y:717,t:1526933777512};\\\", \\\"{x:1395,y:724,t:1526933777529};\\\", \\\"{x:1383,y:735,t:1526933777545};\\\", \\\"{x:1375,y:738,t:1526933777562};\\\", \\\"{x:1363,y:743,t:1526933777578};\\\", \\\"{x:1347,y:747,t:1526933777595};\\\", \\\"{x:1337,y:749,t:1526933777612};\\\", \\\"{x:1328,y:750,t:1526933777628};\\\", \\\"{x:1318,y:751,t:1526933777645};\\\", \\\"{x:1310,y:752,t:1526933777662};\\\", \\\"{x:1307,y:752,t:1526933777678};\\\", \\\"{x:1303,y:752,t:1526933777695};\\\", \\\"{x:1301,y:752,t:1526933777744};\\\", \\\"{x:1298,y:749,t:1526933777752};\\\", \\\"{x:1298,y:745,t:1526933777762};\\\", \\\"{x:1295,y:732,t:1526933777778};\\\", \\\"{x:1290,y:707,t:1526933777795};\\\", \\\"{x:1287,y:677,t:1526933777812};\\\", \\\"{x:1285,y:643,t:1526933777829};\\\", \\\"{x:1285,y:605,t:1526933777845};\\\", \\\"{x:1290,y:565,t:1526933777863};\\\", \\\"{x:1291,y:544,t:1526933777879};\\\", \\\"{x:1295,y:531,t:1526933777895};\\\", \\\"{x:1298,y:523,t:1526933777912};\\\", \\\"{x:1298,y:522,t:1526933777929};\\\", \\\"{x:1298,y:521,t:1526933777945};\\\", \\\"{x:1297,y:521,t:1526933778057};\\\", \\\"{x:1293,y:521,t:1526933778063};\\\", \\\"{x:1287,y:523,t:1526933778079};\\\", \\\"{x:1277,y:530,t:1526933778095};\\\", \\\"{x:1267,y:541,t:1526933778112};\\\", \\\"{x:1266,y:547,t:1526933778129};\\\", \\\"{x:1266,y:552,t:1526933778145};\\\", \\\"{x:1268,y:559,t:1526933778162};\\\", \\\"{x:1281,y:568,t:1526933778179};\\\", \\\"{x:1298,y:575,t:1526933778195};\\\", \\\"{x:1316,y:583,t:1526933778213};\\\", \\\"{x:1333,y:588,t:1526933778229};\\\", \\\"{x:1346,y:590,t:1526933778245};\\\", \\\"{x:1367,y:591,t:1526933778262};\\\", \\\"{x:1391,y:596,t:1526933778279};\\\", \\\"{x:1411,y:599,t:1526933778296};\\\", \\\"{x:1438,y:601,t:1526933778311};\\\", \\\"{x:1455,y:601,t:1526933778329};\\\", \\\"{x:1478,y:601,t:1526933778346};\\\", \\\"{x:1500,y:601,t:1526933778362};\\\", \\\"{x:1524,y:601,t:1526933778379};\\\", \\\"{x:1531,y:602,t:1526933778396};\\\", \\\"{x:1545,y:607,t:1526933778412};\\\", \\\"{x:1551,y:610,t:1526933778429};\\\", \\\"{x:1560,y:617,t:1526933778446};\\\", \\\"{x:1571,y:624,t:1526933778462};\\\", \\\"{x:1580,y:630,t:1526933778479};\\\", \\\"{x:1589,y:635,t:1526933778496};\\\", \\\"{x:1592,y:639,t:1526933778512};\\\", \\\"{x:1597,y:646,t:1526933778529};\\\", \\\"{x:1604,y:657,t:1526933778546};\\\", \\\"{x:1613,y:670,t:1526933778562};\\\", \\\"{x:1620,y:679,t:1526933778579};\\\", \\\"{x:1623,y:683,t:1526933778597};\\\", \\\"{x:1625,y:685,t:1526933778612};\\\", \\\"{x:1627,y:687,t:1526933778629};\\\", \\\"{x:1627,y:688,t:1526933778646};\\\", \\\"{x:1627,y:691,t:1526933778662};\\\", \\\"{x:1627,y:694,t:1526933778680};\\\", \\\"{x:1628,y:697,t:1526933778696};\\\", \\\"{x:1628,y:698,t:1526933778712};\\\", \\\"{x:1629,y:698,t:1526933778776};\\\", \\\"{x:1629,y:700,t:1526933778944};\\\", \\\"{x:1626,y:701,t:1526933778960};\\\", \\\"{x:1625,y:701,t:1526933778968};\\\", \\\"{x:1623,y:702,t:1526933778992};\\\", \\\"{x:1622,y:702,t:1526933779008};\\\", \\\"{x:1621,y:703,t:1526933779016};\\\", \\\"{x:1620,y:703,t:1526933779039};\\\", \\\"{x:1619,y:704,t:1526933779088};\\\", \\\"{x:1618,y:704,t:1526933779096};\\\", \\\"{x:1616,y:704,t:1526933779113};\\\", \\\"{x:1614,y:704,t:1526933779129};\\\", \\\"{x:1613,y:705,t:1526933779146};\\\", \\\"{x:1611,y:705,t:1526933779201};\\\", \\\"{x:1610,y:705,t:1526933779257};\\\", \\\"{x:1609,y:705,t:1526933779272};\\\", \\\"{x:1608,y:705,t:1526933779280};\\\", \\\"{x:1608,y:703,t:1526933779304};\\\", \\\"{x:1608,y:702,t:1526933781241};\\\", \\\"{x:1608,y:701,t:1526933781249};\\\", \\\"{x:1608,y:700,t:1526933781265};\\\", \\\"{x:1610,y:698,t:1526933781282};\\\", \\\"{x:1610,y:697,t:1526933781299};\\\", \\\"{x:1611,y:696,t:1526933781320};\\\", \\\"{x:1612,y:696,t:1526933781722};\\\", \\\"{x:1613,y:696,t:1526933781777};\\\", \\\"{x:1614,y:696,t:1526933781921};\\\", \\\"{x:1615,y:696,t:1526933781932};\\\", \\\"{x:1616,y:696,t:1526933782025};\\\", \\\"{x:1617,y:697,t:1526933782080};\\\", \\\"{x:1618,y:697,t:1526933782153};\\\", \\\"{x:1619,y:697,t:1526933783265};\\\", \\\"{x:1619,y:698,t:1526933783401};\\\", \\\"{x:1619,y:700,t:1526933783417};\\\", \\\"{x:1619,y:704,t:1526933783435};\\\", \\\"{x:1620,y:706,t:1526933783451};\\\", \\\"{x:1620,y:707,t:1526933783467};\\\", \\\"{x:1620,y:710,t:1526933783485};\\\", \\\"{x:1619,y:711,t:1526933783513};\\\", \\\"{x:1619,y:712,t:1526933783521};\\\", \\\"{x:1619,y:713,t:1526933783534};\\\", \\\"{x:1619,y:714,t:1526933783551};\\\", \\\"{x:1619,y:715,t:1526933783567};\\\", \\\"{x:1618,y:716,t:1526933783618};\\\", \\\"{x:1617,y:717,t:1526933784489};\\\", \\\"{x:1617,y:718,t:1526933784501};\\\", \\\"{x:1616,y:720,t:1526933784518};\\\", \\\"{x:1616,y:721,t:1526933784534};\\\", \\\"{x:1615,y:723,t:1526933784551};\\\", \\\"{x:1614,y:724,t:1526933784568};\\\", \\\"{x:1614,y:726,t:1526933784584};\\\", \\\"{x:1613,y:729,t:1526933784602};\\\", \\\"{x:1612,y:732,t:1526933784618};\\\", \\\"{x:1612,y:734,t:1526933784649};\\\", \\\"{x:1611,y:735,t:1526933784657};\\\", \\\"{x:1611,y:736,t:1526933784673};\\\", \\\"{x:1611,y:737,t:1526933784685};\\\", \\\"{x:1610,y:741,t:1526933784701};\\\", \\\"{x:1610,y:742,t:1526933784721};\\\", \\\"{x:1610,y:744,t:1526933784737};\\\", \\\"{x:1610,y:746,t:1526933784751};\\\", \\\"{x:1609,y:748,t:1526933784769};\\\", \\\"{x:1609,y:752,t:1526933784785};\\\", \\\"{x:1609,y:754,t:1526933784801};\\\", \\\"{x:1609,y:755,t:1526933784825};\\\", \\\"{x:1609,y:757,t:1526933784835};\\\", \\\"{x:1609,y:758,t:1526933784851};\\\", \\\"{x:1609,y:760,t:1526933784869};\\\", \\\"{x:1609,y:762,t:1526933784889};\\\", \\\"{x:1609,y:763,t:1526933784901};\\\", \\\"{x:1609,y:764,t:1526933784918};\\\", \\\"{x:1609,y:766,t:1526933784935};\\\", \\\"{x:1609,y:767,t:1526933784951};\\\", \\\"{x:1610,y:768,t:1526933784985};\\\", \\\"{x:1610,y:770,t:1526933785002};\\\", \\\"{x:1610,y:772,t:1526933785033};\\\", \\\"{x:1610,y:773,t:1526933785041};\\\", \\\"{x:1610,y:774,t:1526933785074};\\\", \\\"{x:1610,y:775,t:1526933785085};\\\", \\\"{x:1610,y:776,t:1526933785105};\\\", \\\"{x:1610,y:777,t:1526933785118};\\\", \\\"{x:1610,y:778,t:1526933785135};\\\", \\\"{x:1610,y:779,t:1526933785152};\\\", \\\"{x:1610,y:782,t:1526933785168};\\\", \\\"{x:1609,y:786,t:1526933785185};\\\", \\\"{x:1609,y:787,t:1526933785202};\\\", \\\"{x:1609,y:790,t:1526933785218};\\\", \\\"{x:1609,y:793,t:1526933785235};\\\", \\\"{x:1609,y:794,t:1526933785252};\\\", \\\"{x:1609,y:796,t:1526933785268};\\\", \\\"{x:1609,y:797,t:1526933785285};\\\", \\\"{x:1609,y:800,t:1526933785302};\\\", \\\"{x:1608,y:803,t:1526933785319};\\\", \\\"{x:1608,y:804,t:1526933785335};\\\", \\\"{x:1608,y:806,t:1526933785352};\\\", \\\"{x:1607,y:810,t:1526933785369};\\\", \\\"{x:1607,y:813,t:1526933785386};\\\", \\\"{x:1607,y:816,t:1526933785402};\\\", \\\"{x:1607,y:819,t:1526933785419};\\\", \\\"{x:1607,y:820,t:1526933785435};\\\", \\\"{x:1607,y:822,t:1526933785452};\\\", \\\"{x:1607,y:824,t:1526933785468};\\\", \\\"{x:1607,y:825,t:1526933785485};\\\", \\\"{x:1607,y:826,t:1526933785502};\\\", \\\"{x:1607,y:828,t:1526933785520};\\\", \\\"{x:1607,y:829,t:1526933785535};\\\", \\\"{x:1608,y:829,t:1526933785552};\\\", \\\"{x:1608,y:832,t:1526933785569};\\\", \\\"{x:1609,y:834,t:1526933785585};\\\", \\\"{x:1609,y:835,t:1526933785602};\\\", \\\"{x:1612,y:839,t:1526933785619};\\\", \\\"{x:1613,y:841,t:1526933785635};\\\", \\\"{x:1614,y:842,t:1526933785652};\\\", \\\"{x:1616,y:846,t:1526933785669};\\\", \\\"{x:1617,y:851,t:1526933785685};\\\", \\\"{x:1617,y:853,t:1526933785702};\\\", \\\"{x:1618,y:858,t:1526933785719};\\\", \\\"{x:1618,y:863,t:1526933785735};\\\", \\\"{x:1621,y:871,t:1526933785752};\\\", \\\"{x:1621,y:879,t:1526933785768};\\\", \\\"{x:1621,y:881,t:1526933785785};\\\", \\\"{x:1621,y:888,t:1526933785802};\\\", \\\"{x:1621,y:895,t:1526933785819};\\\", \\\"{x:1621,y:904,t:1526933785835};\\\", \\\"{x:1617,y:919,t:1526933785852};\\\", \\\"{x:1614,y:927,t:1526933785868};\\\", \\\"{x:1613,y:930,t:1526933785884};\\\", \\\"{x:1610,y:936,t:1526933785902};\\\", \\\"{x:1610,y:940,t:1526933785919};\\\", \\\"{x:1609,y:942,t:1526933785935};\\\", \\\"{x:1608,y:943,t:1526933785952};\\\", \\\"{x:1607,y:945,t:1526933785969};\\\", \\\"{x:1607,y:946,t:1526933785986};\\\", \\\"{x:1607,y:948,t:1526933786017};\\\", \\\"{x:1605,y:948,t:1526933786025};\\\", \\\"{x:1605,y:949,t:1526933786041};\\\", \\\"{x:1605,y:951,t:1526933786089};\\\", \\\"{x:1605,y:952,t:1526933786113};\\\", \\\"{x:1605,y:954,t:1526933786121};\\\", \\\"{x:1605,y:955,t:1526933786138};\\\", \\\"{x:1605,y:957,t:1526933786152};\\\", \\\"{x:1605,y:958,t:1526933786170};\\\", \\\"{x:1605,y:954,t:1526933786369};\\\", \\\"{x:1605,y:938,t:1526933786387};\\\", \\\"{x:1605,y:919,t:1526933786403};\\\", \\\"{x:1605,y:903,t:1526933786419};\\\", \\\"{x:1606,y:886,t:1526933786436};\\\", \\\"{x:1608,y:860,t:1526933786453};\\\", \\\"{x:1608,y:834,t:1526933786470};\\\", \\\"{x:1610,y:811,t:1526933786486};\\\", \\\"{x:1611,y:798,t:1526933786504};\\\", \\\"{x:1609,y:787,t:1526933786519};\\\", \\\"{x:1609,y:770,t:1526933786538};\\\", \\\"{x:1609,y:761,t:1526933786553};\\\", \\\"{x:1609,y:754,t:1526933786569};\\\", \\\"{x:1608,y:747,t:1526933786586};\\\", \\\"{x:1607,y:742,t:1526933786603};\\\", \\\"{x:1605,y:730,t:1526933786619};\\\", \\\"{x:1605,y:719,t:1526933786636};\\\", \\\"{x:1605,y:714,t:1526933786654};\\\", \\\"{x:1605,y:711,t:1526933786669};\\\", \\\"{x:1605,y:709,t:1526933786977};\\\", \\\"{x:1605,y:706,t:1526933786986};\\\", \\\"{x:1605,y:702,t:1526933787003};\\\", \\\"{x:1606,y:698,t:1526933787020};\\\", \\\"{x:1606,y:697,t:1526933787037};\\\", \\\"{x:1601,y:697,t:1526933787314};\\\", \\\"{x:1591,y:695,t:1526933787321};\\\", \\\"{x:1573,y:692,t:1526933787338};\\\", \\\"{x:1544,y:692,t:1526933787354};\\\", \\\"{x:1521,y:692,t:1526933787370};\\\", \\\"{x:1498,y:691,t:1526933787387};\\\", \\\"{x:1464,y:689,t:1526933787403};\\\", \\\"{x:1439,y:689,t:1526933787420};\\\", \\\"{x:1427,y:689,t:1526933787438};\\\", \\\"{x:1417,y:689,t:1526933787453};\\\", \\\"{x:1411,y:689,t:1526933787470};\\\", \\\"{x:1409,y:689,t:1526933787487};\\\", \\\"{x:1407,y:689,t:1526933787503};\\\", \\\"{x:1406,y:690,t:1526933787594};\\\", \\\"{x:1404,y:691,t:1526933787603};\\\", \\\"{x:1398,y:694,t:1526933787620};\\\", \\\"{x:1395,y:696,t:1526933787637};\\\", \\\"{x:1387,y:698,t:1526933787653};\\\", \\\"{x:1378,y:699,t:1526933787670};\\\", \\\"{x:1371,y:700,t:1526933787686};\\\", \\\"{x:1370,y:701,t:1526933787704};\\\", \\\"{x:1366,y:701,t:1526933787720};\\\", \\\"{x:1362,y:702,t:1526933787736};\\\", \\\"{x:1361,y:702,t:1526933787754};\\\", \\\"{x:1359,y:702,t:1526933787770};\\\", \\\"{x:1358,y:703,t:1526933787809};\\\", \\\"{x:1357,y:703,t:1526933787820};\\\", \\\"{x:1356,y:703,t:1526933787897};\\\", \\\"{x:1357,y:703,t:1526933788032};\\\", \\\"{x:1359,y:704,t:1526933788040};\\\", \\\"{x:1362,y:704,t:1526933788054};\\\", \\\"{x:1374,y:704,t:1526933788070};\\\", \\\"{x:1383,y:704,t:1526933788086};\\\", \\\"{x:1386,y:704,t:1526933788104};\\\", \\\"{x:1393,y:704,t:1526933788120};\\\", \\\"{x:1394,y:704,t:1526933788144};\\\", \\\"{x:1395,y:703,t:1526933788154};\\\", \\\"{x:1397,y:703,t:1526933788170};\\\", \\\"{x:1399,y:702,t:1526933788201};\\\", \\\"{x:1401,y:701,t:1526933788216};\\\", \\\"{x:1402,y:701,t:1526933788241};\\\", \\\"{x:1403,y:701,t:1526933788254};\\\", \\\"{x:1403,y:700,t:1526933788272};\\\", \\\"{x:1404,y:700,t:1526933788296};\\\", \\\"{x:1404,y:699,t:1526933788304};\\\", \\\"{x:1405,y:698,t:1526933788320};\\\", \\\"{x:1406,y:697,t:1526933788344};\\\", \\\"{x:1407,y:697,t:1526933788354};\\\", \\\"{x:1407,y:696,t:1526933788393};\\\", \\\"{x:1408,y:695,t:1526933788442};\\\", \\\"{x:1409,y:695,t:1526933788522};\\\", \\\"{x:1410,y:694,t:1526933788537};\\\", \\\"{x:1411,y:694,t:1526933788601};\\\", \\\"{x:1409,y:694,t:1526933788994};\\\", \\\"{x:1408,y:694,t:1526933789004};\\\", \\\"{x:1407,y:694,t:1526933789022};\\\", \\\"{x:1405,y:695,t:1526933789039};\\\", \\\"{x:1402,y:695,t:1526933789055};\\\", \\\"{x:1400,y:695,t:1526933789072};\\\", \\\"{x:1394,y:695,t:1526933789088};\\\", \\\"{x:1385,y:695,t:1526933789105};\\\", \\\"{x:1383,y:696,t:1526933789122};\\\", \\\"{x:1380,y:697,t:1526933789139};\\\", \\\"{x:1379,y:697,t:1526933789156};\\\", \\\"{x:1377,y:697,t:1526933789171};\\\", \\\"{x:1375,y:697,t:1526933789188};\\\", \\\"{x:1373,y:697,t:1526933789206};\\\", \\\"{x:1372,y:697,t:1526933789241};\\\", \\\"{x:1371,y:697,t:1526933789256};\\\", \\\"{x:1370,y:697,t:1526933789271};\\\", \\\"{x:1367,y:697,t:1526933789289};\\\", \\\"{x:1364,y:697,t:1526933789305};\\\", \\\"{x:1360,y:697,t:1526933789321};\\\", \\\"{x:1357,y:697,t:1526933789338};\\\", \\\"{x:1356,y:697,t:1526933789355};\\\", \\\"{x:1353,y:698,t:1526933789372};\\\", \\\"{x:1351,y:698,t:1526933789405};\\\", \\\"{x:1350,y:698,t:1526933789441};\\\", \\\"{x:1343,y:698,t:1526933790673};\\\", \\\"{x:1317,y:698,t:1526933790691};\\\", \\\"{x:1228,y:698,t:1526933790706};\\\", \\\"{x:1115,y:698,t:1526933790722};\\\", \\\"{x:964,y:691,t:1526933790739};\\\", \\\"{x:824,y:680,t:1526933790756};\\\", \\\"{x:694,y:659,t:1526933790773};\\\", \\\"{x:563,y:640,t:1526933790789};\\\", \\\"{x:455,y:622,t:1526933790806};\\\", \\\"{x:406,y:614,t:1526933790822};\\\", \\\"{x:366,y:602,t:1526933790840};\\\", \\\"{x:358,y:598,t:1526933790856};\\\", \\\"{x:338,y:590,t:1526933790873};\\\", \\\"{x:336,y:587,t:1526933790890};\\\", \\\"{x:334,y:585,t:1526933790906};\\\", \\\"{x:334,y:584,t:1526933790922};\\\", \\\"{x:334,y:580,t:1526933790940};\\\", \\\"{x:334,y:574,t:1526933790955};\\\", \\\"{x:340,y:564,t:1526933790972};\\\", \\\"{x:352,y:551,t:1526933790990};\\\", \\\"{x:368,y:544,t:1526933791006};\\\", \\\"{x:390,y:536,t:1526933791023};\\\", \\\"{x:413,y:533,t:1526933791040};\\\", \\\"{x:452,y:527,t:1526933791057};\\\", \\\"{x:482,y:524,t:1526933791073};\\\", \\\"{x:518,y:518,t:1526933791089};\\\", \\\"{x:547,y:513,t:1526933791107};\\\", \\\"{x:562,y:513,t:1526933791123};\\\", \\\"{x:579,y:513,t:1526933791139};\\\", \\\"{x:600,y:513,t:1526933791157};\\\", \\\"{x:621,y:512,t:1526933791173};\\\", \\\"{x:642,y:510,t:1526933791191};\\\", \\\"{x:669,y:504,t:1526933791207};\\\", \\\"{x:696,y:499,t:1526933791222};\\\", \\\"{x:720,y:493,t:1526933791239};\\\", \\\"{x:734,y:489,t:1526933791258};\\\", \\\"{x:737,y:488,t:1526933791274};\\\", \\\"{x:739,y:487,t:1526933791353};\\\", \\\"{x:740,y:487,t:1526933791369};\\\", \\\"{x:742,y:487,t:1526933791377};\\\", \\\"{x:748,y:487,t:1526933791390};\\\", \\\"{x:764,y:487,t:1526933791408};\\\", \\\"{x:781,y:487,t:1526933791425};\\\", \\\"{x:803,y:490,t:1526933791441};\\\", \\\"{x:828,y:492,t:1526933791458};\\\", \\\"{x:832,y:492,t:1526933791474};\\\", \\\"{x:832,y:493,t:1526933791490};\\\", \\\"{x:833,y:493,t:1526933791535};\\\", \\\"{x:834,y:493,t:1526933791544};\\\", \\\"{x:835,y:493,t:1526933791560};\\\", \\\"{x:836,y:493,t:1526933791576};\\\", \\\"{x:837,y:494,t:1526933791589};\\\", \\\"{x:838,y:494,t:1526933791624};\\\", \\\"{x:838,y:495,t:1526933797561};\\\", \\\"{x:827,y:504,t:1526933797578};\\\", \\\"{x:805,y:510,t:1526933797596};\\\", \\\"{x:773,y:516,t:1526933797612};\\\", \\\"{x:743,y:521,t:1526933797629};\\\", \\\"{x:716,y:523,t:1526933797645};\\\", \\\"{x:708,y:524,t:1526933797662};\\\", \\\"{x:694,y:527,t:1526933797678};\\\", \\\"{x:683,y:531,t:1526933797695};\\\", \\\"{x:665,y:534,t:1526933797712};\\\", \\\"{x:662,y:536,t:1526933797728};\\\", \\\"{x:649,y:541,t:1526933797745};\\\", \\\"{x:638,y:544,t:1526933797763};\\\", \\\"{x:633,y:544,t:1526933797778};\\\", \\\"{x:621,y:544,t:1526933797795};\\\", \\\"{x:604,y:544,t:1526933797812};\\\", \\\"{x:580,y:543,t:1526933797830};\\\", \\\"{x:542,y:543,t:1526933797845};\\\", \\\"{x:484,y:535,t:1526933797863};\\\", \\\"{x:468,y:523,t:1526933797880};\\\", \\\"{x:459,y:519,t:1526933797895};\\\", \\\"{x:459,y:518,t:1526933797912};\\\", \\\"{x:458,y:515,t:1526933797978};\\\", \\\"{x:445,y:515,t:1526933797995};\\\", \\\"{x:428,y:518,t:1526933798013};\\\", \\\"{x:424,y:518,t:1526933798029};\\\", \\\"{x:423,y:518,t:1526933798049};\\\", \\\"{x:421,y:518,t:1526933798062};\\\", \\\"{x:412,y:520,t:1526933798079};\\\", \\\"{x:396,y:525,t:1526933798096};\\\", \\\"{x:370,y:539,t:1526933798113};\\\", \\\"{x:331,y:547,t:1526933798129};\\\", \\\"{x:291,y:549,t:1526933798145};\\\", \\\"{x:238,y:550,t:1526933798164};\\\", \\\"{x:189,y:555,t:1526933798179};\\\", \\\"{x:166,y:559,t:1526933798196};\\\", \\\"{x:156,y:560,t:1526933798212};\\\", \\\"{x:156,y:559,t:1526933798617};\\\", \\\"{x:156,y:558,t:1526933798629};\\\", \\\"{x:156,y:556,t:1526933798646};\\\", \\\"{x:158,y:553,t:1526933798665};\\\", \\\"{x:159,y:551,t:1526933798679};\\\", \\\"{x:160,y:551,t:1526933798696};\\\", \\\"{x:160,y:549,t:1526933798713};\\\", \\\"{x:161,y:549,t:1526933798752};\\\", \\\"{x:162,y:548,t:1526933798776};\\\", \\\"{x:165,y:547,t:1526933798848};\\\", \\\"{x:169,y:548,t:1526933799240};\\\", \\\"{x:171,y:555,t:1526933799249};\\\", \\\"{x:171,y:558,t:1526933799263};\\\", \\\"{x:191,y:579,t:1526933799281};\\\", \\\"{x:271,y:609,t:1526933799297};\\\", \\\"{x:388,y:646,t:1526933799314};\\\", \\\"{x:554,y:698,t:1526933799330};\\\", \\\"{x:770,y:764,t:1526933799346};\\\", \\\"{x:1007,y:835,t:1526933799363};\\\", \\\"{x:1252,y:897,t:1526933799380};\\\", \\\"{x:1519,y:964,t:1526933799396};\\\", \\\"{x:1746,y:1035,t:1526933799413};\\\", \\\"{x:1927,y:1092,t:1526933799430};\\\", \\\"{x:1927,y:1129,t:1526933799447};\\\", \\\"{x:1927,y:1148,t:1526933799464};\\\", \\\"{x:1927,y:1157,t:1526933799480};\\\", \\\"{x:1927,y:1159,t:1526933799497};\\\", \\\"{x:1927,y:1156,t:1526933799536};\\\", \\\"{x:1927,y:1148,t:1526933799548};\\\", \\\"{x:1927,y:1117,t:1526933799563};\\\", \\\"{x:1927,y:1070,t:1526933799580};\\\", \\\"{x:1923,y:1043,t:1526933799597};\\\", \\\"{x:1918,y:1027,t:1526933799613};\\\", \\\"{x:1906,y:1009,t:1526933799630};\\\", \\\"{x:1877,y:987,t:1526933799647};\\\", \\\"{x:1845,y:964,t:1526933799664};\\\", \\\"{x:1792,y:945,t:1526933799681};\\\", \\\"{x:1766,y:936,t:1526933799697};\\\", \\\"{x:1735,y:925,t:1526933799713};\\\", \\\"{x:1710,y:922,t:1526933799730};\\\", \\\"{x:1689,y:921,t:1526933799748};\\\", \\\"{x:1675,y:919,t:1526933799764};\\\", \\\"{x:1670,y:919,t:1526933799780};\\\", \\\"{x:1658,y:917,t:1526933799798};\\\", \\\"{x:1650,y:914,t:1526933799814};\\\", \\\"{x:1635,y:910,t:1526933799831};\\\", \\\"{x:1614,y:902,t:1526933799847};\\\", \\\"{x:1588,y:896,t:1526933799864};\\\", \\\"{x:1562,y:885,t:1526933799880};\\\", \\\"{x:1543,y:871,t:1526933799897};\\\", \\\"{x:1532,y:863,t:1526933799914};\\\", \\\"{x:1521,y:848,t:1526933799931};\\\", \\\"{x:1497,y:834,t:1526933799948};\\\", \\\"{x:1438,y:805,t:1526933799964};\\\", \\\"{x:1409,y:784,t:1526933799981};\\\", \\\"{x:1385,y:775,t:1526933799997};\\\", \\\"{x:1370,y:768,t:1526933800014};\\\", \\\"{x:1365,y:764,t:1526933800031};\\\", \\\"{x:1363,y:761,t:1526933800047};\\\", \\\"{x:1363,y:760,t:1526933800265};\\\", \\\"{x:1362,y:758,t:1526933800281};\\\", \\\"{x:1357,y:757,t:1526933800298};\\\", \\\"{x:1355,y:757,t:1526933800315};\\\", \\\"{x:1353,y:757,t:1526933800331};\\\", \\\"{x:1351,y:757,t:1526933801602};\\\", \\\"{x:1350,y:757,t:1526933801642};\\\", \\\"{x:1353,y:757,t:1526933802313};\\\", \\\"{x:1364,y:758,t:1526933802321};\\\", \\\"{x:1376,y:761,t:1526933802332};\\\", \\\"{x:1397,y:767,t:1526933802350};\\\", \\\"{x:1411,y:772,t:1526933802366};\\\", \\\"{x:1420,y:776,t:1526933802382};\\\", \\\"{x:1424,y:777,t:1526933802398};\\\", \\\"{x:1424,y:778,t:1526933802489};\\\", \\\"{x:1424,y:777,t:1526933802585};\\\", \\\"{x:1424,y:776,t:1526933802599};\\\", \\\"{x:1423,y:774,t:1526933802616};\\\", \\\"{x:1423,y:773,t:1526933802633};\\\", \\\"{x:1423,y:772,t:1526933802657};\\\", \\\"{x:1423,y:770,t:1526933802697};\\\", \\\"{x:1423,y:769,t:1526933802721};\\\", \\\"{x:1422,y:768,t:1526933802732};\\\", \\\"{x:1422,y:766,t:1526933802749};\\\", \\\"{x:1422,y:765,t:1526933802767};\\\", \\\"{x:1420,y:765,t:1526933802783};\\\", \\\"{x:1419,y:765,t:1526933802799};\\\", \\\"{x:1418,y:763,t:1526933802816};\\\", \\\"{x:1417,y:762,t:1526933802833};\\\", \\\"{x:1413,y:761,t:1526933802848};\\\", \\\"{x:1409,y:759,t:1526933802866};\\\", \\\"{x:1406,y:758,t:1526933802883};\\\", \\\"{x:1405,y:758,t:1526933802899};\\\", \\\"{x:1404,y:758,t:1526933802915};\\\", \\\"{x:1403,y:758,t:1526933802932};\\\", \\\"{x:1404,y:758,t:1526933803377};\\\", \\\"{x:1406,y:758,t:1526933803393};\\\", \\\"{x:1408,y:758,t:1526933803409};\\\", \\\"{x:1409,y:758,t:1526933803441};\\\", \\\"{x:1411,y:758,t:1526933803465};\\\", \\\"{x:1412,y:758,t:1526933803505};\\\", \\\"{x:1413,y:758,t:1526933803623};\\\", \\\"{x:1414,y:758,t:1526933803656};\\\", \\\"{x:1416,y:759,t:1526933803680};\\\", \\\"{x:1419,y:759,t:1526933803696};\\\", \\\"{x:1422,y:760,t:1526933803704};\\\", \\\"{x:1424,y:761,t:1526933803715};\\\", \\\"{x:1430,y:763,t:1526933803732};\\\", \\\"{x:1436,y:766,t:1526933803750};\\\", \\\"{x:1440,y:767,t:1526933803765};\\\", \\\"{x:1443,y:768,t:1526933803782};\\\", \\\"{x:1445,y:769,t:1526933803800};\\\", \\\"{x:1448,y:770,t:1526933803816};\\\", \\\"{x:1451,y:771,t:1526933803832};\\\", \\\"{x:1452,y:771,t:1526933803849};\\\", \\\"{x:1454,y:771,t:1526933803872};\\\", \\\"{x:1455,y:771,t:1526933803904};\\\", \\\"{x:1457,y:771,t:1526933803920};\\\", \\\"{x:1458,y:771,t:1526933803936};\\\", \\\"{x:1459,y:772,t:1526933803949};\\\", \\\"{x:1461,y:772,t:1526933803966};\\\", \\\"{x:1462,y:773,t:1526933803982};\\\", \\\"{x:1463,y:773,t:1526933804033};\\\", \\\"{x:1464,y:773,t:1526933804050};\\\", \\\"{x:1465,y:773,t:1526933804073};\\\", \\\"{x:1466,y:773,t:1526933804083};\\\", \\\"{x:1467,y:773,t:1526933804100};\\\", \\\"{x:1468,y:773,t:1526933804117};\\\", \\\"{x:1469,y:773,t:1526933804133};\\\", \\\"{x:1470,y:773,t:1526933804150};\\\", \\\"{x:1472,y:773,t:1526933804177};\\\", \\\"{x:1473,y:773,t:1526933804193};\\\", \\\"{x:1474,y:773,t:1526933804209};\\\", \\\"{x:1476,y:773,t:1526933804225};\\\", \\\"{x:1477,y:773,t:1526933804233};\\\", \\\"{x:1478,y:773,t:1526933804313};\\\", \\\"{x:1479,y:772,t:1526933804401};\\\", \\\"{x:1480,y:772,t:1526933804441};\\\", \\\"{x:1481,y:771,t:1526933804482};\\\", \\\"{x:1482,y:770,t:1526933804625};\\\", \\\"{x:1483,y:770,t:1526933804673};\\\", \\\"{x:1484,y:769,t:1526933804745};\\\", \\\"{x:1484,y:768,t:1526933804809};\\\", \\\"{x:1485,y:767,t:1526933804858};\\\", \\\"{x:1486,y:767,t:1526933804953};\\\", \\\"{x:1488,y:767,t:1526933805393};\\\", \\\"{x:1489,y:766,t:1526933805425};\\\", \\\"{x:1489,y:765,t:1526933805681};\\\", \\\"{x:1489,y:764,t:1526933805697};\\\", \\\"{x:1491,y:764,t:1526933806410};\\\", \\\"{x:1493,y:764,t:1526933806418};\\\", \\\"{x:1501,y:764,t:1526933806435};\\\", \\\"{x:1513,y:766,t:1526933806452};\\\", \\\"{x:1518,y:767,t:1526933806468};\\\", \\\"{x:1525,y:769,t:1526933806486};\\\", \\\"{x:1527,y:769,t:1526933806501};\\\", \\\"{x:1529,y:769,t:1526933806518};\\\", \\\"{x:1530,y:769,t:1526933806538};\\\", \\\"{x:1531,y:769,t:1526933806553};\\\", \\\"{x:1532,y:769,t:1526933806585};\\\", \\\"{x:1533,y:769,t:1526933806609};\\\", \\\"{x:1534,y:769,t:1526933806649};\\\", \\\"{x:1535,y:769,t:1526933806665};\\\", \\\"{x:1536,y:769,t:1526933806713};\\\", \\\"{x:1536,y:768,t:1526933806729};\\\", \\\"{x:1537,y:768,t:1526933806745};\\\", \\\"{x:1538,y:767,t:1526933806753};\\\", \\\"{x:1538,y:766,t:1526933806824};\\\", \\\"{x:1539,y:766,t:1526933806835};\\\", \\\"{x:1539,y:764,t:1526933806855};\\\", \\\"{x:1540,y:764,t:1526933806872};\\\", \\\"{x:1541,y:763,t:1526933806885};\\\", \\\"{x:1542,y:763,t:1526933806904};\\\", \\\"{x:1543,y:763,t:1526933806928};\\\", \\\"{x:1544,y:762,t:1526933806944};\\\", \\\"{x:1545,y:762,t:1526933806992};\\\", \\\"{x:1546,y:761,t:1526933807009};\\\", \\\"{x:1547,y:761,t:1526933807018};\\\", \\\"{x:1548,y:761,t:1526933807056};\\\", \\\"{x:1550,y:760,t:1526933807068};\\\", \\\"{x:1551,y:760,t:1526933807169};\\\", \\\"{x:1552,y:760,t:1526933807249};\\\", \\\"{x:1553,y:760,t:1526933807281};\\\", \\\"{x:1554,y:760,t:1526933807418};\\\", \\\"{x:1555,y:759,t:1526933807521};\\\", \\\"{x:1552,y:760,t:1526933807721};\\\", \\\"{x:1542,y:762,t:1526933807735};\\\", \\\"{x:1509,y:766,t:1526933807753};\\\", \\\"{x:1448,y:755,t:1526933807769};\\\", \\\"{x:1308,y:722,t:1526933807785};\\\", \\\"{x:1229,y:710,t:1526933807802};\\\", \\\"{x:1159,y:697,t:1526933807817};\\\", \\\"{x:1125,y:687,t:1526933807834};\\\", \\\"{x:1103,y:679,t:1526933807852};\\\", \\\"{x:1094,y:675,t:1526933807867};\\\", \\\"{x:1093,y:675,t:1526933807884};\\\", \\\"{x:1092,y:675,t:1526933807902};\\\", \\\"{x:1093,y:674,t:1526933807937};\\\", \\\"{x:1095,y:673,t:1526933807952};\\\", \\\"{x:1100,y:671,t:1526933807968};\\\", \\\"{x:1104,y:667,t:1526933807985};\\\", \\\"{x:1110,y:666,t:1526933808002};\\\", \\\"{x:1117,y:664,t:1526933808018};\\\", \\\"{x:1132,y:664,t:1526933808035};\\\", \\\"{x:1151,y:666,t:1526933808052};\\\", \\\"{x:1166,y:668,t:1526933808069};\\\", \\\"{x:1185,y:673,t:1526933808085};\\\", \\\"{x:1208,y:673,t:1526933808102};\\\", \\\"{x:1225,y:675,t:1526933808119};\\\", \\\"{x:1235,y:677,t:1526933808135};\\\", \\\"{x:1245,y:680,t:1526933808152};\\\", \\\"{x:1249,y:681,t:1526933808168};\\\", \\\"{x:1254,y:682,t:1526933808185};\\\", \\\"{x:1262,y:685,t:1526933808202};\\\", \\\"{x:1275,y:687,t:1526933808219};\\\", \\\"{x:1285,y:689,t:1526933808235};\\\", \\\"{x:1294,y:689,t:1526933808252};\\\", \\\"{x:1300,y:691,t:1526933808269};\\\", \\\"{x:1307,y:694,t:1526933808285};\\\", \\\"{x:1313,y:696,t:1526933808303};\\\", \\\"{x:1318,y:698,t:1526933808320};\\\", \\\"{x:1320,y:698,t:1526933808335};\\\", \\\"{x:1321,y:698,t:1526933808352};\\\", \\\"{x:1325,y:699,t:1526933808368};\\\", \\\"{x:1329,y:700,t:1526933808385};\\\", \\\"{x:1333,y:700,t:1526933808402};\\\", \\\"{x:1336,y:700,t:1526933808420};\\\", \\\"{x:1337,y:700,t:1526933808441};\\\", \\\"{x:1338,y:700,t:1526933808506};\\\", \\\"{x:1339,y:700,t:1526933808519};\\\", \\\"{x:1340,y:700,t:1526933808673};\\\", \\\"{x:1342,y:700,t:1526933808778};\\\", \\\"{x:1343,y:700,t:1526933808872};\\\", \\\"{x:1344,y:700,t:1526933808886};\\\", \\\"{x:1348,y:700,t:1526933808901};\\\", \\\"{x:1350,y:700,t:1526933808918};\\\", \\\"{x:1355,y:700,t:1526933808936};\\\", \\\"{x:1356,y:700,t:1526933808960};\\\", \\\"{x:1357,y:700,t:1526933808984};\\\", \\\"{x:1358,y:700,t:1526933809000};\\\", \\\"{x:1361,y:700,t:1526933809065};\\\", \\\"{x:1362,y:700,t:1526933809072};\\\", \\\"{x:1363,y:700,t:1526933809086};\\\", \\\"{x:1368,y:700,t:1526933809101};\\\", \\\"{x:1373,y:700,t:1526933809118};\\\", \\\"{x:1379,y:700,t:1526933809136};\\\", \\\"{x:1383,y:700,t:1526933809152};\\\", \\\"{x:1384,y:700,t:1526933809184};\\\", \\\"{x:1386,y:700,t:1526933809192};\\\", \\\"{x:1388,y:700,t:1526933809208};\\\", \\\"{x:1389,y:700,t:1526933809219};\\\", \\\"{x:1392,y:700,t:1526933809236};\\\", \\\"{x:1397,y:700,t:1526933809253};\\\", \\\"{x:1400,y:700,t:1526933809269};\\\", \\\"{x:1404,y:700,t:1526933809286};\\\", \\\"{x:1408,y:700,t:1526933809303};\\\", \\\"{x:1411,y:700,t:1526933809319};\\\", \\\"{x:1414,y:700,t:1526933809337};\\\", \\\"{x:1417,y:700,t:1526933809353};\\\", \\\"{x:1420,y:700,t:1526933809368};\\\", \\\"{x:1424,y:700,t:1526933809386};\\\", \\\"{x:1425,y:700,t:1526933809403};\\\", \\\"{x:1426,y:700,t:1526933809889};\\\", \\\"{x:1428,y:700,t:1526933809905};\\\", \\\"{x:1432,y:699,t:1526933809921};\\\", \\\"{x:1444,y:699,t:1526933809936};\\\", \\\"{x:1452,y:699,t:1526933809953};\\\", \\\"{x:1456,y:699,t:1526933809970};\\\", \\\"{x:1457,y:701,t:1526933809986};\\\", \\\"{x:1458,y:701,t:1526933810097};\\\", \\\"{x:1459,y:701,t:1526933810113};\\\", \\\"{x:1460,y:701,t:1526933810193};\\\", \\\"{x:1462,y:701,t:1526933810225};\\\", \\\"{x:1464,y:701,t:1526933810249};\\\", \\\"{x:1465,y:700,t:1526933810257};\\\", \\\"{x:1466,y:700,t:1526933810271};\\\", \\\"{x:1467,y:700,t:1526933810289};\\\", \\\"{x:1468,y:700,t:1526933810346};\\\", \\\"{x:1469,y:698,t:1526933810377};\\\", \\\"{x:1470,y:698,t:1526933810473};\\\", \\\"{x:1471,y:697,t:1526933810489};\\\", \\\"{x:1472,y:697,t:1526933810504};\\\", \\\"{x:1476,y:697,t:1526933810521};\\\", \\\"{x:1487,y:697,t:1526933810537};\\\", \\\"{x:1493,y:696,t:1526933810554};\\\", \\\"{x:1497,y:696,t:1526933810570};\\\", \\\"{x:1506,y:696,t:1526933810587};\\\", \\\"{x:1518,y:696,t:1526933810603};\\\", \\\"{x:1523,y:696,t:1526933810621};\\\", \\\"{x:1526,y:696,t:1526933810637};\\\", \\\"{x:1530,y:695,t:1526933810654};\\\", \\\"{x:1532,y:694,t:1526933810753};\\\", \\\"{x:1535,y:694,t:1526933810771};\\\", \\\"{x:1537,y:693,t:1526933810788};\\\", \\\"{x:1539,y:693,t:1526933810880};\\\", \\\"{x:1540,y:693,t:1526933810896};\\\", \\\"{x:1542,y:693,t:1526933810911};\\\", \\\"{x:1544,y:693,t:1526933810952};\\\", \\\"{x:1546,y:693,t:1526933810985};\\\", \\\"{x:1547,y:691,t:1526933810992};\\\", \\\"{x:1549,y:691,t:1526933811002};\\\", \\\"{x:1550,y:691,t:1526933811020};\\\", \\\"{x:1554,y:691,t:1526933811037};\\\", \\\"{x:1557,y:691,t:1526933811052};\\\", \\\"{x:1562,y:691,t:1526933811070};\\\", \\\"{x:1571,y:691,t:1526933811087};\\\", \\\"{x:1581,y:691,t:1526933811102};\\\", \\\"{x:1593,y:691,t:1526933811120};\\\", \\\"{x:1608,y:691,t:1526933811137};\\\", \\\"{x:1622,y:691,t:1526933811154};\\\", \\\"{x:1635,y:691,t:1526933811169};\\\", \\\"{x:1647,y:691,t:1526933811187};\\\", \\\"{x:1652,y:691,t:1526933811204};\\\", \\\"{x:1655,y:690,t:1526933811220};\\\", \\\"{x:1653,y:690,t:1526933811426};\\\", \\\"{x:1652,y:690,t:1526933811438};\\\", \\\"{x:1642,y:689,t:1526933811455};\\\", \\\"{x:1626,y:689,t:1526933811471};\\\", \\\"{x:1611,y:689,t:1526933811487};\\\", \\\"{x:1600,y:689,t:1526933811504};\\\", \\\"{x:1595,y:689,t:1526933811520};\\\", \\\"{x:1594,y:689,t:1526933811537};\\\", \\\"{x:1591,y:689,t:1526933811833};\\\", \\\"{x:1590,y:689,t:1526933811848};\\\", \\\"{x:1588,y:690,t:1526933811857};\\\", \\\"{x:1585,y:691,t:1526933811873};\\\", \\\"{x:1584,y:691,t:1526933811897};\\\", \\\"{x:1583,y:692,t:1526933811944};\\\", \\\"{x:1580,y:694,t:1526933811953};\\\", \\\"{x:1579,y:694,t:1526933812288};\\\", \\\"{x:1576,y:694,t:1526933812304};\\\", \\\"{x:1574,y:693,t:1526933812320};\\\", \\\"{x:1572,y:691,t:1526933812337};\\\", \\\"{x:1571,y:691,t:1526933812368};\\\", \\\"{x:1570,y:690,t:1526933812729};\\\", \\\"{x:1572,y:690,t:1526933812841};\\\", \\\"{x:1575,y:690,t:1526933812855};\\\", \\\"{x:1582,y:691,t:1526933812871};\\\", \\\"{x:1585,y:692,t:1526933812889};\\\", \\\"{x:1586,y:692,t:1526933812905};\\\", \\\"{x:1588,y:692,t:1526933813026};\\\", \\\"{x:1589,y:692,t:1526933813073};\\\", \\\"{x:1591,y:692,t:1526933813104};\\\", \\\"{x:1592,y:692,t:1526933813153};\\\", \\\"{x:1593,y:692,t:1526933813177};\\\", \\\"{x:1594,y:692,t:1526933813188};\\\", \\\"{x:1595,y:692,t:1526933813206};\\\", \\\"{x:1598,y:691,t:1526933813221};\\\", \\\"{x:1599,y:691,t:1526933813239};\\\", \\\"{x:1602,y:691,t:1526933813255};\\\", \\\"{x:1605,y:690,t:1526933813271};\\\", \\\"{x:1601,y:689,t:1526933813442};\\\", \\\"{x:1594,y:689,t:1526933813455};\\\", \\\"{x:1570,y:684,t:1526933813471};\\\", \\\"{x:1532,y:679,t:1526933813489};\\\", \\\"{x:1510,y:672,t:1526933813505};\\\", \\\"{x:1488,y:665,t:1526933813521};\\\", \\\"{x:1466,y:653,t:1526933813539};\\\", \\\"{x:1456,y:649,t:1526933813555};\\\", \\\"{x:1450,y:646,t:1526933813571};\\\", \\\"{x:1449,y:645,t:1526933813592};\\\", \\\"{x:1449,y:644,t:1526933813641};\\\", \\\"{x:1449,y:642,t:1526933813665};\\\", \\\"{x:1449,y:641,t:1526933813681};\\\", \\\"{x:1449,y:639,t:1526933813696};\\\", \\\"{x:1449,y:638,t:1526933813753};\\\", \\\"{x:1449,y:636,t:1526933813777};\\\", \\\"{x:1449,y:635,t:1526933813788};\\\", \\\"{x:1449,y:634,t:1526933813822};\\\", \\\"{x:1449,y:632,t:1526933813848};\\\", \\\"{x:1453,y:632,t:1526933813872};\\\", \\\"{x:1454,y:632,t:1526933813914};\\\", \\\"{x:1454,y:631,t:1526933815017};\\\", \\\"{x:1449,y:631,t:1526933815025};\\\", \\\"{x:1440,y:630,t:1526933815040};\\\", \\\"{x:1408,y:622,t:1526933815057};\\\", \\\"{x:1384,y:614,t:1526933815073};\\\", \\\"{x:1366,y:609,t:1526933815090};\\\", \\\"{x:1349,y:604,t:1526933815107};\\\", \\\"{x:1328,y:598,t:1526933815123};\\\", \\\"{x:1315,y:594,t:1526933815139};\\\", \\\"{x:1308,y:592,t:1526933815156};\\\", \\\"{x:1304,y:591,t:1526933815173};\\\", \\\"{x:1302,y:590,t:1526933815190};\\\", \\\"{x:1301,y:590,t:1526933815207};\\\", \\\"{x:1300,y:590,t:1526933815257};\\\", \\\"{x:1299,y:590,t:1526933815273};\\\", \\\"{x:1296,y:586,t:1526933815329};\\\", \\\"{x:1295,y:586,t:1526933815339};\\\", \\\"{x:1293,y:582,t:1526933815357};\\\", \\\"{x:1289,y:578,t:1526933815373};\\\", \\\"{x:1287,y:575,t:1526933815390};\\\", \\\"{x:1286,y:573,t:1526933815406};\\\", \\\"{x:1286,y:572,t:1526933815422};\\\", \\\"{x:1286,y:571,t:1526933815441};\\\", \\\"{x:1286,y:570,t:1526933815457};\\\", \\\"{x:1286,y:569,t:1526933815473};\\\", \\\"{x:1286,y:568,t:1526933815529};\\\", \\\"{x:1285,y:568,t:1526933815585};\\\", \\\"{x:1285,y:567,t:1526933815593};\\\", \\\"{x:1285,y:565,t:1526933815801};\\\", \\\"{x:1288,y:564,t:1526933815816};\\\", \\\"{x:1292,y:564,t:1526933815824};\\\", \\\"{x:1296,y:564,t:1526933815839};\\\", \\\"{x:1303,y:564,t:1526933815856};\\\", \\\"{x:1312,y:564,t:1526933815873};\\\", \\\"{x:1317,y:564,t:1526933815889};\\\", \\\"{x:1321,y:565,t:1526933815906};\\\", \\\"{x:1323,y:566,t:1526933815923};\\\", \\\"{x:1324,y:566,t:1526933815939};\\\", \\\"{x:1326,y:566,t:1526933815956};\\\", \\\"{x:1329,y:566,t:1526933815973};\\\", \\\"{x:1331,y:566,t:1526933815989};\\\", \\\"{x:1332,y:566,t:1526933816032};\\\", \\\"{x:1334,y:566,t:1526933816041};\\\", \\\"{x:1338,y:566,t:1526933816056};\\\", \\\"{x:1343,y:566,t:1526933816073};\\\", \\\"{x:1345,y:566,t:1526933816089};\\\", \\\"{x:1347,y:566,t:1526933816106};\\\", \\\"{x:1347,y:567,t:1526933816473};\\\", \\\"{x:1356,y:567,t:1526933816490};\\\", \\\"{x:1366,y:568,t:1526933816506};\\\", \\\"{x:1373,y:569,t:1526933816523};\\\", \\\"{x:1380,y:571,t:1526933816540};\\\", \\\"{x:1387,y:571,t:1526933816557};\\\", \\\"{x:1392,y:572,t:1526933816574};\\\", \\\"{x:1395,y:573,t:1526933816591};\\\", \\\"{x:1398,y:573,t:1526933816607};\\\", \\\"{x:1399,y:574,t:1526933816624};\\\", \\\"{x:1404,y:575,t:1526933816640};\\\", \\\"{x:1406,y:575,t:1526933816656};\\\", \\\"{x:1407,y:575,t:1526933816745};\\\", \\\"{x:1408,y:575,t:1526933816810};\\\", \\\"{x:1409,y:575,t:1526933816843};\\\", \\\"{x:1410,y:575,t:1526933816864};\\\", \\\"{x:1411,y:575,t:1526933816873};\\\", \\\"{x:1412,y:575,t:1526933816890};\\\", \\\"{x:1413,y:575,t:1526933817105};\\\", \\\"{x:1412,y:574,t:1526933817129};\\\", \\\"{x:1412,y:573,t:1526933817160};\\\", \\\"{x:1412,y:572,t:1526933817201};\\\", \\\"{x:1413,y:571,t:1526933817282};\\\", \\\"{x:1414,y:571,t:1526933817312};\\\", \\\"{x:1415,y:570,t:1526933817329};\\\", \\\"{x:1416,y:570,t:1526933817345};\\\", \\\"{x:1418,y:570,t:1526933817357};\\\", \\\"{x:1424,y:567,t:1526933817374};\\\", \\\"{x:1435,y:567,t:1526933817390};\\\", \\\"{x:1450,y:566,t:1526933817407};\\\", \\\"{x:1463,y:566,t:1526933817423};\\\", \\\"{x:1485,y:564,t:1526933817440};\\\", \\\"{x:1491,y:564,t:1526933817457};\\\", \\\"{x:1495,y:564,t:1526933817474};\\\", \\\"{x:1499,y:564,t:1526933817491};\\\", \\\"{x:1499,y:563,t:1526933817618};\\\", \\\"{x:1495,y:563,t:1526933817625};\\\", \\\"{x:1489,y:563,t:1526933817641};\\\", \\\"{x:1482,y:563,t:1526933817657};\\\", \\\"{x:1476,y:563,t:1526933817674};\\\", \\\"{x:1474,y:563,t:1526933817690};\\\", \\\"{x:1475,y:563,t:1526933817921};\\\", \\\"{x:1480,y:564,t:1526933817930};\\\", \\\"{x:1484,y:564,t:1526933817940};\\\", \\\"{x:1497,y:565,t:1526933817957};\\\", \\\"{x:1508,y:566,t:1526933817974};\\\", \\\"{x:1518,y:567,t:1526933817990};\\\", \\\"{x:1525,y:569,t:1526933818007};\\\", \\\"{x:1526,y:569,t:1526933818056};\\\", \\\"{x:1527,y:570,t:1526933818072};\\\", \\\"{x:1528,y:570,t:1526933818177};\\\", \\\"{x:1530,y:570,t:1526933818233};\\\", \\\"{x:1532,y:570,t:1526933818248};\\\", \\\"{x:1534,y:569,t:1526933818257};\\\", \\\"{x:1535,y:568,t:1526933818275};\\\", \\\"{x:1538,y:568,t:1526933818292};\\\", \\\"{x:1539,y:567,t:1526933818313};\\\", \\\"{x:1540,y:567,t:1526933818325};\\\", \\\"{x:1541,y:567,t:1526933818341};\\\", \\\"{x:1541,y:565,t:1526933818458};\\\", \\\"{x:1542,y:565,t:1526933818538};\\\", \\\"{x:1542,y:564,t:1526933818552};\\\", \\\"{x:1544,y:563,t:1526933818561};\\\", \\\"{x:1544,y:562,t:1526933818592};\\\", \\\"{x:1545,y:562,t:1526933818657};\\\", \\\"{x:1545,y:563,t:1526933818889};\\\", \\\"{x:1544,y:563,t:1526933818904};\\\", \\\"{x:1544,y:562,t:1526933819786};\\\", \\\"{x:1545,y:561,t:1526933819889};\\\", \\\"{x:1545,y:560,t:1526933821718};\\\", \\\"{x:1542,y:560,t:1526933821734};\\\", \\\"{x:1537,y:560,t:1526933821750};\\\", \\\"{x:1535,y:560,t:1526933821766};\\\", \\\"{x:1533,y:560,t:1526933821782};\\\", \\\"{x:1532,y:560,t:1526933821806};\\\", \\\"{x:1531,y:560,t:1526933821816};\\\", \\\"{x:1532,y:560,t:1526933822085};\\\", \\\"{x:1534,y:560,t:1526933822101};\\\", \\\"{x:1534,y:559,t:1526933822116};\\\", \\\"{x:1536,y:559,t:1526933822132};\\\", \\\"{x:1539,y:557,t:1526933822149};\\\", \\\"{x:1542,y:556,t:1526933822166};\\\", \\\"{x:1548,y:555,t:1526933822183};\\\", \\\"{x:1559,y:552,t:1526933822199};\\\", \\\"{x:1568,y:552,t:1526933822217};\\\", \\\"{x:1578,y:551,t:1526933822233};\\\", \\\"{x:1589,y:550,t:1526933822250};\\\", \\\"{x:1595,y:547,t:1526933822266};\\\", \\\"{x:1604,y:546,t:1526933822282};\\\", \\\"{x:1610,y:545,t:1526933822300};\\\", \\\"{x:1615,y:545,t:1526933822316};\\\", \\\"{x:1622,y:543,t:1526933822332};\\\", \\\"{x:1626,y:543,t:1526933822349};\\\", \\\"{x:1629,y:543,t:1526933822367};\\\", \\\"{x:1631,y:542,t:1526933822382};\\\", \\\"{x:1632,y:542,t:1526933822400};\\\", \\\"{x:1632,y:543,t:1526933822511};\\\", \\\"{x:1631,y:545,t:1526933822517};\\\", \\\"{x:1631,y:549,t:1526933822533};\\\", \\\"{x:1627,y:552,t:1526933822549};\\\", \\\"{x:1625,y:555,t:1526933822567};\\\", \\\"{x:1623,y:557,t:1526933822582};\\\", \\\"{x:1622,y:558,t:1526933822599};\\\", \\\"{x:1623,y:558,t:1526933822941};\\\", \\\"{x:1627,y:558,t:1526933822949};\\\", \\\"{x:1641,y:557,t:1526933822967};\\\", \\\"{x:1651,y:556,t:1526933822983};\\\", \\\"{x:1654,y:555,t:1526933823000};\\\", \\\"{x:1657,y:555,t:1526933823016};\\\", \\\"{x:1658,y:554,t:1526933823238};\\\", \\\"{x:1658,y:553,t:1526933823249};\\\", \\\"{x:1659,y:552,t:1526933823266};\\\", \\\"{x:1662,y:552,t:1526933823284};\\\", \\\"{x:1664,y:552,t:1526933823300};\\\", \\\"{x:1666,y:552,t:1526933823316};\\\", \\\"{x:1673,y:553,t:1526933823334};\\\", \\\"{x:1674,y:553,t:1526933823350};\\\", \\\"{x:1675,y:553,t:1526933823366};\\\", \\\"{x:1676,y:553,t:1526933823606};\\\", \\\"{x:1676,y:554,t:1526933823616};\\\", \\\"{x:1676,y:555,t:1526933823634};\\\", \\\"{x:1676,y:556,t:1526933823651};\\\", \\\"{x:1671,y:565,t:1526933824990};\\\", \\\"{x:1660,y:577,t:1526933825001};\\\", \\\"{x:1633,y:614,t:1526933825018};\\\", \\\"{x:1611,y:643,t:1526933825034};\\\", \\\"{x:1587,y:674,t:1526933825050};\\\", \\\"{x:1574,y:692,t:1526933825068};\\\", \\\"{x:1564,y:699,t:1526933825085};\\\", \\\"{x:1557,y:706,t:1526933825100};\\\", \\\"{x:1531,y:734,t:1526933825117};\\\", \\\"{x:1503,y:757,t:1526933825134};\\\", \\\"{x:1467,y:787,t:1526933825150};\\\", \\\"{x:1439,y:809,t:1526933825167};\\\", \\\"{x:1395,y:827,t:1526933825185};\\\", \\\"{x:1370,y:833,t:1526933825201};\\\", \\\"{x:1323,y:839,t:1526933825218};\\\", \\\"{x:1296,y:839,t:1526933825235};\\\", \\\"{x:1268,y:840,t:1526933825250};\\\", \\\"{x:1255,y:840,t:1526933825267};\\\", \\\"{x:1251,y:839,t:1526933825285};\\\", \\\"{x:1248,y:839,t:1526933825302};\\\", \\\"{x:1246,y:837,t:1526933825318};\\\", \\\"{x:1246,y:835,t:1526933825335};\\\", \\\"{x:1247,y:827,t:1526933825351};\\\", \\\"{x:1254,y:816,t:1526933825367};\\\", \\\"{x:1260,y:806,t:1526933825384};\\\", \\\"{x:1265,y:796,t:1526933825401};\\\", \\\"{x:1269,y:788,t:1526933825417};\\\", \\\"{x:1275,y:782,t:1526933825434};\\\", \\\"{x:1280,y:778,t:1526933825452};\\\", \\\"{x:1286,y:774,t:1526933825468};\\\", \\\"{x:1288,y:769,t:1526933825484};\\\", \\\"{x:1293,y:766,t:1526933825500};\\\", \\\"{x:1294,y:765,t:1526933825517};\\\", \\\"{x:1295,y:765,t:1526933825540};\\\", \\\"{x:1296,y:763,t:1526933825551};\\\", \\\"{x:1297,y:761,t:1526933825568};\\\", \\\"{x:1288,y:754,t:1526933825584};\\\", \\\"{x:1264,y:748,t:1526933825602};\\\", \\\"{x:1192,y:728,t:1526933825618};\\\", \\\"{x:1046,y:709,t:1526933825635};\\\", \\\"{x:876,y:673,t:1526933825652};\\\", \\\"{x:667,y:622,t:1526933825668};\\\", \\\"{x:421,y:582,t:1526933825685};\\\", \\\"{x:90,y:500,t:1526933825701};\\\", \\\"{x:8,y:436,t:1526933825725};\\\", \\\"{x:8,y:410,t:1526933825741};\\\", \\\"{x:8,y:390,t:1526933825758};\\\", \\\"{x:8,y:382,t:1526933825775};\\\", \\\"{x:8,y:383,t:1526933826085};\\\", \\\"{x:8,y:382,t:1526933826166};\\\", \\\"{x:8,y:380,t:1526933826176};\\\", \\\"{x:8,y:376,t:1526933826192};\\\", \\\"{x:8,y:358,t:1526933826208};\\\", \\\"{x:8,y:345,t:1526933826225};\\\", \\\"{x:8,y:328,t:1526933826241};\\\", \\\"{x:8,y:320,t:1526933826259};\\\", \\\"{x:8,y:317,t:1526933826275};\\\", \\\"{x:8,y:324,t:1526933826318};\\\", \\\"{x:14,y:333,t:1526933826325};\\\", \\\"{x:32,y:351,t:1526933826343};\\\", \\\"{x:56,y:374,t:1526933826359};\\\", \\\"{x:93,y:408,t:1526933826376};\\\", \\\"{x:117,y:431,t:1526933826393};\\\", \\\"{x:127,y:446,t:1526933826408};\\\", \\\"{x:131,y:453,t:1526933826426};\\\", \\\"{x:133,y:462,t:1526933826442};\\\", \\\"{x:133,y:467,t:1526933826458};\\\", \\\"{x:133,y:474,t:1526933826476};\\\", \\\"{x:133,y:481,t:1526933826492};\\\", \\\"{x:133,y:482,t:1526933826510};\\\", \\\"{x:132,y:485,t:1526933826525};\\\", \\\"{x:132,y:488,t:1526933826544};\\\", \\\"{x:129,y:496,t:1526933826558};\\\", \\\"{x:125,y:514,t:1526933826576};\\\", \\\"{x:125,y:533,t:1526933826592};\\\", \\\"{x:126,y:545,t:1526933826609};\\\", \\\"{x:129,y:552,t:1526933826625};\\\", \\\"{x:130,y:556,t:1526933826642};\\\", \\\"{x:131,y:557,t:1526933826658};\\\", \\\"{x:133,y:560,t:1526933826675};\\\", \\\"{x:134,y:561,t:1526933826709};\\\", \\\"{x:135,y:561,t:1526933826764};\\\", \\\"{x:136,y:561,t:1526933826775};\\\", \\\"{x:142,y:560,t:1526933826793};\\\", \\\"{x:150,y:556,t:1526933826809};\\\", \\\"{x:156,y:553,t:1526933826826};\\\", \\\"{x:163,y:548,t:1526933826842};\\\", \\\"{x:167,y:546,t:1526933826859};\\\", \\\"{x:171,y:543,t:1526933826876};\\\", \\\"{x:172,y:541,t:1526933826893};\\\", \\\"{x:174,y:539,t:1526933826910};\\\", \\\"{x:175,y:538,t:1526933826933};\\\", \\\"{x:175,y:537,t:1526933826949};\\\", \\\"{x:175,y:536,t:1526933827133};\\\", \\\"{x:173,y:536,t:1526933827174};\\\", \\\"{x:172,y:536,t:1526933827181};\\\", \\\"{x:170,y:536,t:1526933827197};\\\", \\\"{x:169,y:537,t:1526933827210};\\\", \\\"{x:168,y:537,t:1526933827246};\\\", \\\"{x:169,y:537,t:1526933827924};\\\", \\\"{x:173,y:540,t:1526933827933};\\\", \\\"{x:179,y:541,t:1526933827943};\\\", \\\"{x:198,y:548,t:1526933827960};\\\", \\\"{x:231,y:555,t:1526933827977};\\\", \\\"{x:282,y:571,t:1526933827994};\\\", \\\"{x:373,y:584,t:1526933828010};\\\", \\\"{x:502,y:607,t:1526933828027};\\\", \\\"{x:643,y:629,t:1526933828044};\\\", \\\"{x:871,y:660,t:1526933828061};\\\", \\\"{x:944,y:666,t:1526933828077};\\\", \\\"{x:1148,y:702,t:1526933828094};\\\", \\\"{x:1290,y:724,t:1526933828110};\\\", \\\"{x:1422,y:740,t:1526933828126};\\\", \\\"{x:1522,y:756,t:1526933828144};\\\", \\\"{x:1568,y:762,t:1526933828160};\\\", \\\"{x:1585,y:762,t:1526933828177};\\\", \\\"{x:1604,y:762,t:1526933828193};\\\", \\\"{x:1610,y:762,t:1526933828210};\\\", \\\"{x:1610,y:761,t:1526933828226};\\\", \\\"{x:1612,y:757,t:1526933828926};\\\", \\\"{x:1614,y:754,t:1526933828934};\\\", \\\"{x:1617,y:749,t:1526933828944};\\\", \\\"{x:1619,y:743,t:1526933828961};\\\", \\\"{x:1620,y:742,t:1526933828978};\\\", \\\"{x:1621,y:741,t:1526933828997};\\\", \\\"{x:1622,y:740,t:1526933829011};\\\", \\\"{x:1623,y:737,t:1526933829028};\\\", \\\"{x:1624,y:734,t:1526933829044};\\\", \\\"{x:1625,y:732,t:1526933829061};\\\", \\\"{x:1625,y:731,t:1526933829078};\\\", \\\"{x:1626,y:729,t:1526933829094};\\\", \\\"{x:1627,y:726,t:1526933829110};\\\", \\\"{x:1628,y:725,t:1526933829128};\\\", \\\"{x:1628,y:723,t:1526933829144};\\\", \\\"{x:1628,y:722,t:1526933829161};\\\", \\\"{x:1630,y:722,t:1526933830166};\\\", \\\"{x:1630,y:721,t:1526933830178};\\\", \\\"{x:1627,y:722,t:1526933830195};\\\", \\\"{x:1623,y:725,t:1526933830212};\\\", \\\"{x:1619,y:727,t:1526933830227};\\\", \\\"{x:1615,y:731,t:1526933830245};\\\", \\\"{x:1605,y:743,t:1526933830261};\\\", \\\"{x:1589,y:763,t:1526933830278};\\\", \\\"{x:1568,y:783,t:1526933830296};\\\", \\\"{x:1546,y:806,t:1526933830312};\\\", \\\"{x:1525,y:820,t:1526933830328};\\\", \\\"{x:1516,y:826,t:1526933830345};\\\", \\\"{x:1509,y:830,t:1526933830362};\\\", \\\"{x:1501,y:835,t:1526933830379};\\\", \\\"{x:1493,y:839,t:1526933830395};\\\", \\\"{x:1486,y:845,t:1526933830412};\\\", \\\"{x:1481,y:848,t:1526933830428};\\\", \\\"{x:1479,y:849,t:1526933830445};\\\", \\\"{x:1479,y:850,t:1526933830470};\\\", \\\"{x:1478,y:850,t:1526933830479};\\\", \\\"{x:1478,y:849,t:1526933830565};\\\", \\\"{x:1478,y:846,t:1526933830579};\\\", \\\"{x:1478,y:841,t:1526933830595};\\\", \\\"{x:1478,y:835,t:1526933830612};\\\", \\\"{x:1479,y:830,t:1526933830629};\\\", \\\"{x:1480,y:830,t:1526933830645};\\\", \\\"{x:1481,y:829,t:1526933830662};\\\", \\\"{x:1481,y:828,t:1526933830718};\\\", \\\"{x:1484,y:827,t:1526933831317};\\\", \\\"{x:1487,y:827,t:1526933831330};\\\", \\\"{x:1497,y:827,t:1526933831345};\\\", \\\"{x:1505,y:827,t:1526933831362};\\\", \\\"{x:1518,y:827,t:1526933831379};\\\", \\\"{x:1533,y:830,t:1526933831396};\\\", \\\"{x:1539,y:831,t:1526933831412};\\\", \\\"{x:1544,y:832,t:1526933831429};\\\", \\\"{x:1546,y:832,t:1526933831445};\\\", \\\"{x:1547,y:832,t:1526933831468};\\\", \\\"{x:1549,y:832,t:1526933831501};\\\", \\\"{x:1550,y:832,t:1526933831534};\\\", \\\"{x:1552,y:831,t:1526933831546};\\\", \\\"{x:1552,y:830,t:1526933831574};\\\", \\\"{x:1551,y:830,t:1526933832149};\\\", \\\"{x:1552,y:829,t:1526933832502};\\\", \\\"{x:1555,y:829,t:1526933832525};\\\", \\\"{x:1557,y:829,t:1526933832542};\\\", \\\"{x:1559,y:829,t:1526933832549};\\\", \\\"{x:1562,y:829,t:1526933832563};\\\", \\\"{x:1569,y:827,t:1526933832581};\\\", \\\"{x:1580,y:826,t:1526933832596};\\\", \\\"{x:1591,y:826,t:1526933832613};\\\", \\\"{x:1601,y:825,t:1526933832629};\\\", \\\"{x:1604,y:825,t:1526933832645};\\\", \\\"{x:1607,y:825,t:1526933832662};\\\", \\\"{x:1610,y:825,t:1526933832679};\\\", \\\"{x:1612,y:825,t:1526933832695};\\\", \\\"{x:1613,y:825,t:1526933832713};\\\", \\\"{x:1615,y:825,t:1526933832748};\\\", \\\"{x:1617,y:825,t:1526933832764};\\\", \\\"{x:1618,y:825,t:1526933832780};\\\", \\\"{x:1620,y:825,t:1526933832796};\\\", \\\"{x:1621,y:824,t:1526933832813};\\\", \\\"{x:1622,y:824,t:1526933833286};\\\", \\\"{x:1623,y:824,t:1526933833390};\\\", \\\"{x:1624,y:825,t:1526933833470};\\\", \\\"{x:1624,y:826,t:1526933833542};\\\", \\\"{x:1624,y:828,t:1526933833598};\\\", \\\"{x:1625,y:828,t:1526933833613};\\\", \\\"{x:1625,y:829,t:1526933833653};\\\", \\\"{x:1625,y:831,t:1526933833693};\\\", \\\"{x:1624,y:833,t:1526933833726};\\\", \\\"{x:1621,y:835,t:1526933833734};\\\", \\\"{x:1613,y:836,t:1526933833747};\\\", \\\"{x:1581,y:836,t:1526933833764};\\\", \\\"{x:1503,y:836,t:1526933833780};\\\", \\\"{x:1334,y:836,t:1526933833797};\\\", \\\"{x:1185,y:822,t:1526933833813};\\\", \\\"{x:1030,y:798,t:1526933833830};\\\", \\\"{x:855,y:767,t:1526933833847};\\\", \\\"{x:702,y:740,t:1526933833864};\\\", \\\"{x:553,y:721,t:1526933833881};\\\", \\\"{x:428,y:700,t:1526933833896};\\\", \\\"{x:364,y:690,t:1526933833914};\\\", \\\"{x:341,y:681,t:1526933833926};\\\", \\\"{x:338,y:680,t:1526933833941};\\\", \\\"{x:338,y:679,t:1526933833981};\\\", \\\"{x:338,y:678,t:1526933834004};\\\", \\\"{x:338,y:677,t:1526933834013};\\\", \\\"{x:338,y:676,t:1526933834028};\\\", \\\"{x:340,y:675,t:1526933834041};\\\", \\\"{x:343,y:673,t:1526933834058};\\\", \\\"{x:351,y:666,t:1526933834076};\\\", \\\"{x:364,y:658,t:1526933834091};\\\", \\\"{x:401,y:648,t:1526933834115};\\\", \\\"{x:433,y:640,t:1526933834132};\\\", \\\"{x:498,y:632,t:1526933834148};\\\", \\\"{x:520,y:629,t:1526933834165};\\\", \\\"{x:537,y:627,t:1526933834182};\\\", \\\"{x:549,y:627,t:1526933834199};\\\", \\\"{x:557,y:625,t:1526933834214};\\\", \\\"{x:560,y:625,t:1526933834231};\\\", \\\"{x:563,y:624,t:1526933834293};\\\", \\\"{x:568,y:623,t:1526933834301};\\\", \\\"{x:574,y:621,t:1526933834315};\\\", \\\"{x:591,y:618,t:1526933834332};\\\", \\\"{x:610,y:614,t:1526933834349};\\\", \\\"{x:628,y:609,t:1526933834365};\\\", \\\"{x:635,y:608,t:1526933834381};\\\", \\\"{x:640,y:605,t:1526933834399};\\\", \\\"{x:645,y:604,t:1526933834415};\\\", \\\"{x:654,y:597,t:1526933834432};\\\", \\\"{x:659,y:594,t:1526933834448};\\\", \\\"{x:663,y:591,t:1526933834467};\\\", \\\"{x:663,y:590,t:1526933834501};\\\", \\\"{x:663,y:589,t:1526933834516};\\\", \\\"{x:663,y:588,t:1526933834532};\\\", \\\"{x:660,y:585,t:1526933834549};\\\", \\\"{x:651,y:579,t:1526933834565};\\\", \\\"{x:637,y:572,t:1526933834582};\\\", \\\"{x:631,y:571,t:1526933834599};\\\", \\\"{x:627,y:570,t:1526933834615};\\\", \\\"{x:624,y:570,t:1526933834633};\\\", \\\"{x:623,y:569,t:1526933834648};\\\", \\\"{x:621,y:568,t:1526933834666};\\\", \\\"{x:619,y:568,t:1526933834683};\\\", \\\"{x:615,y:568,t:1526933834699};\\\", \\\"{x:614,y:568,t:1526933834716};\\\", \\\"{x:612,y:568,t:1526933835710};\\\", \\\"{x:609,y:569,t:1526933835717};\\\", \\\"{x:605,y:577,t:1526933835733};\\\", \\\"{x:602,y:582,t:1526933835750};\\\", \\\"{x:598,y:586,t:1526933835767};\\\", \\\"{x:592,y:593,t:1526933835782};\\\", \\\"{x:588,y:599,t:1526933835800};\\\", \\\"{x:584,y:605,t:1526933835817};\\\", \\\"{x:580,y:609,t:1526933835832};\\\", \\\"{x:570,y:623,t:1526933835850};\\\", \\\"{x:559,y:640,t:1526933835867};\\\", \\\"{x:545,y:663,t:1526933835883};\\\", \\\"{x:536,y:680,t:1526933835899};\\\", \\\"{x:523,y:697,t:1526933835916};\\\", \\\"{x:519,y:705,t:1526933835933};\\\", \\\"{x:514,y:713,t:1526933835950};\\\", \\\"{x:510,y:720,t:1526933835967};\\\", \\\"{x:509,y:726,t:1526933835982};\\\", \\\"{x:505,y:735,t:1526933836000};\\\", \\\"{x:502,y:739,t:1526933836016};\\\", \\\"{x:500,y:745,t:1526933836034};\\\", \\\"{x:497,y:750,t:1526933836049};\\\", \\\"{x:496,y:751,t:1526933836067};\\\", \\\"{x:496,y:752,t:1526933836270};\\\", \\\"{x:497,y:752,t:1526933836284};\\\", \\\"{x:500,y:752,t:1526933836300};\\\", \\\"{x:506,y:750,t:1526933836317};\\\", \\\"{x:509,y:748,t:1526933836335};\\\", \\\"{x:513,y:744,t:1526933836350};\\\", \\\"{x:514,y:739,t:1526933836367};\\\", \\\"{x:518,y:736,t:1526933836384};\\\", \\\"{x:522,y:733,t:1526933836400};\\\", \\\"{x:524,y:731,t:1526933836417};\\\", \\\"{x:525,y:730,t:1526933836434};\\\", \\\"{x:526,y:729,t:1526933836453};\\\", \\\"{x:527,y:728,t:1526933836478};\\\", \\\"{x:527,y:726,t:1526933836493};\\\" ] }, { \\\"rt\\\": 46483, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 724061, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -O -2-05 PM-03 PM-3-I -J -J -M -M -X -O -O -O -G -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:724,t:1526933839652};\\\", \\\"{x:540,y:721,t:1526933839660};\\\", \\\"{x:543,y:719,t:1526933839672};\\\", \\\"{x:562,y:713,t:1526933839688};\\\", \\\"{x:578,y:708,t:1526933839701};\\\", \\\"{x:617,y:699,t:1526933839718};\\\", \\\"{x:646,y:698,t:1526933839733};\\\", \\\"{x:687,y:698,t:1526933839751};\\\", \\\"{x:754,y:698,t:1526933839768};\\\", \\\"{x:810,y:696,t:1526933839784};\\\", \\\"{x:843,y:696,t:1526933839801};\\\", \\\"{x:876,y:698,t:1526933839817};\\\", \\\"{x:912,y:701,t:1526933839834};\\\", \\\"{x:943,y:706,t:1526933839851};\\\", \\\"{x:975,y:707,t:1526933839869};\\\", \\\"{x:987,y:707,t:1526933839884};\\\", \\\"{x:1008,y:707,t:1526933839901};\\\", \\\"{x:1016,y:707,t:1526933839918};\\\", \\\"{x:1025,y:707,t:1526933839935};\\\", \\\"{x:1040,y:707,t:1526933839951};\\\", \\\"{x:1047,y:712,t:1526933839968};\\\", \\\"{x:1061,y:712,t:1526933839984};\\\", \\\"{x:1076,y:712,t:1526933840000};\\\", \\\"{x:1087,y:712,t:1526933840017};\\\", \\\"{x:1102,y:714,t:1526933840034};\\\", \\\"{x:1120,y:716,t:1526933840051};\\\", \\\"{x:1153,y:715,t:1526933840068};\\\", \\\"{x:1189,y:715,t:1526933840084};\\\", \\\"{x:1241,y:717,t:1526933840101};\\\", \\\"{x:1274,y:717,t:1526933840118};\\\", \\\"{x:1302,y:717,t:1526933840133};\\\", \\\"{x:1322,y:717,t:1526933840151};\\\", \\\"{x:1336,y:717,t:1526933840167};\\\", \\\"{x:1349,y:717,t:1526933840184};\\\", \\\"{x:1359,y:715,t:1526933840201};\\\", \\\"{x:1365,y:715,t:1526933840217};\\\", \\\"{x:1372,y:715,t:1526933840234};\\\", \\\"{x:1381,y:715,t:1526933840251};\\\", \\\"{x:1387,y:714,t:1526933840267};\\\", \\\"{x:1388,y:714,t:1526933840284};\\\", \\\"{x:1389,y:714,t:1526933840909};\\\", \\\"{x:1390,y:714,t:1526933840940};\\\", \\\"{x:1393,y:714,t:1526933840950};\\\", \\\"{x:1400,y:719,t:1526933840967};\\\", \\\"{x:1417,y:733,t:1526933840984};\\\", \\\"{x:1440,y:749,t:1526933841000};\\\", \\\"{x:1468,y:773,t:1526933841017};\\\", \\\"{x:1506,y:805,t:1526933841034};\\\", \\\"{x:1533,y:833,t:1526933841050};\\\", \\\"{x:1564,y:859,t:1526933841067};\\\", \\\"{x:1585,y:874,t:1526933841084};\\\", \\\"{x:1599,y:887,t:1526933841100};\\\", \\\"{x:1615,y:906,t:1526933841117};\\\", \\\"{x:1624,y:916,t:1526933841135};\\\", \\\"{x:1629,y:923,t:1526933841151};\\\", \\\"{x:1630,y:925,t:1526933841167};\\\", \\\"{x:1630,y:926,t:1526933841184};\\\", \\\"{x:1630,y:927,t:1526933841221};\\\", \\\"{x:1629,y:931,t:1526933841235};\\\", \\\"{x:1619,y:938,t:1526933841250};\\\", \\\"{x:1612,y:943,t:1526933841267};\\\", \\\"{x:1599,y:949,t:1526933841285};\\\", \\\"{x:1582,y:953,t:1526933841301};\\\", \\\"{x:1562,y:955,t:1526933841317};\\\", \\\"{x:1549,y:957,t:1526933841333};\\\", \\\"{x:1541,y:957,t:1526933841351};\\\", \\\"{x:1532,y:957,t:1526933841368};\\\", \\\"{x:1522,y:957,t:1526933841384};\\\", \\\"{x:1514,y:957,t:1526933841400};\\\", \\\"{x:1511,y:957,t:1526933841417};\\\", \\\"{x:1510,y:957,t:1526933841478};\\\", \\\"{x:1510,y:955,t:1526933841493};\\\", \\\"{x:1510,y:952,t:1526933841509};\\\", \\\"{x:1510,y:949,t:1526933841518};\\\", \\\"{x:1511,y:944,t:1526933841534};\\\", \\\"{x:1513,y:941,t:1526933841550};\\\", \\\"{x:1516,y:936,t:1526933841567};\\\", \\\"{x:1519,y:933,t:1526933841583};\\\", \\\"{x:1521,y:933,t:1526933841613};\\\", \\\"{x:1523,y:932,t:1526933841621};\\\", \\\"{x:1524,y:931,t:1526933841645};\\\", \\\"{x:1526,y:931,t:1526933841653};\\\", \\\"{x:1528,y:931,t:1526933841667};\\\", \\\"{x:1530,y:931,t:1526933841685};\\\", \\\"{x:1532,y:931,t:1526933841701};\\\", \\\"{x:1538,y:931,t:1526933841718};\\\", \\\"{x:1540,y:931,t:1526933841733};\\\", \\\"{x:1541,y:931,t:1526933841781};\\\", \\\"{x:1542,y:931,t:1526933841814};\\\", \\\"{x:1543,y:931,t:1526933841821};\\\", \\\"{x:1545,y:931,t:1526933841966};\\\", \\\"{x:1546,y:931,t:1526933842021};\\\", \\\"{x:1548,y:931,t:1526933842084};\\\", \\\"{x:1549,y:931,t:1526933842100};\\\", \\\"{x:1552,y:934,t:1526933842116};\\\", \\\"{x:1556,y:937,t:1526933842133};\\\", \\\"{x:1554,y:938,t:1526933842326};\\\", \\\"{x:1553,y:939,t:1526933842351};\\\", \\\"{x:1552,y:940,t:1526933842366};\\\", \\\"{x:1550,y:940,t:1526933842383};\\\", \\\"{x:1550,y:941,t:1526933842399};\\\", \\\"{x:1549,y:941,t:1526933842416};\\\", \\\"{x:1547,y:941,t:1526933842433};\\\", \\\"{x:1547,y:942,t:1526933842469};\\\", \\\"{x:1546,y:943,t:1526933842509};\\\", \\\"{x:1546,y:942,t:1526933842646};\\\", \\\"{x:1545,y:941,t:1526933842653};\\\", \\\"{x:1544,y:940,t:1526933842666};\\\", \\\"{x:1544,y:939,t:1526933842751};\\\", \\\"{x:1544,y:938,t:1526933842767};\\\", \\\"{x:1543,y:935,t:1526933842783};\\\", \\\"{x:1543,y:933,t:1526933842800};\\\", \\\"{x:1543,y:930,t:1526933842817};\\\", \\\"{x:1542,y:925,t:1526933842833};\\\", \\\"{x:1542,y:919,t:1526933842850};\\\", \\\"{x:1542,y:913,t:1526933842866};\\\", \\\"{x:1542,y:908,t:1526933842884};\\\", \\\"{x:1542,y:904,t:1526933842899};\\\", \\\"{x:1542,y:900,t:1526933842917};\\\", \\\"{x:1542,y:895,t:1526933842933};\\\", \\\"{x:1542,y:890,t:1526933842950};\\\", \\\"{x:1542,y:886,t:1526933842967};\\\", \\\"{x:1544,y:882,t:1526933842983};\\\", \\\"{x:1544,y:880,t:1526933842999};\\\", \\\"{x:1546,y:876,t:1526933843017};\\\", \\\"{x:1546,y:874,t:1526933843033};\\\", \\\"{x:1547,y:869,t:1526933843050};\\\", \\\"{x:1547,y:868,t:1526933843067};\\\", \\\"{x:1547,y:865,t:1526933843083};\\\", \\\"{x:1548,y:863,t:1526933843100};\\\", \\\"{x:1548,y:861,t:1526933843117};\\\", \\\"{x:1549,y:857,t:1526933843132};\\\", \\\"{x:1550,y:851,t:1526933843149};\\\", \\\"{x:1550,y:850,t:1526933843167};\\\", \\\"{x:1550,y:847,t:1526933843183};\\\", \\\"{x:1550,y:844,t:1526933843200};\\\", \\\"{x:1550,y:843,t:1526933843217};\\\", \\\"{x:1550,y:841,t:1526933843232};\\\", \\\"{x:1550,y:840,t:1526933843249};\\\", \\\"{x:1551,y:837,t:1526933843266};\\\", \\\"{x:1551,y:835,t:1526933843283};\\\", \\\"{x:1551,y:832,t:1526933843300};\\\", \\\"{x:1551,y:831,t:1526933843317};\\\", \\\"{x:1551,y:829,t:1526933843341};\\\", \\\"{x:1551,y:828,t:1526933843357};\\\", \\\"{x:1551,y:826,t:1526933843390};\\\", \\\"{x:1551,y:825,t:1526933843686};\\\", \\\"{x:1550,y:825,t:1526933843766};\\\", \\\"{x:1549,y:825,t:1526933844390};\\\", \\\"{x:1548,y:827,t:1526933844429};\\\", \\\"{x:1547,y:828,t:1526933844558};\\\", \\\"{x:1545,y:828,t:1526933846390};\\\", \\\"{x:1540,y:828,t:1526933846398};\\\", \\\"{x:1510,y:820,t:1526933846415};\\\", \\\"{x:1477,y:809,t:1526933846430};\\\", \\\"{x:1431,y:792,t:1526933846447};\\\", \\\"{x:1398,y:779,t:1526933846465};\\\", \\\"{x:1373,y:771,t:1526933846481};\\\", \\\"{x:1363,y:765,t:1526933846497};\\\", \\\"{x:1360,y:764,t:1526933846514};\\\", \\\"{x:1358,y:764,t:1526933846531};\\\", \\\"{x:1357,y:763,t:1526933846548};\\\", \\\"{x:1356,y:763,t:1526933846853};\\\", \\\"{x:1355,y:763,t:1526933846885};\\\", \\\"{x:1353,y:763,t:1526933846904};\\\", \\\"{x:1352,y:763,t:1526933846913};\\\", \\\"{x:1349,y:763,t:1526933846930};\\\", \\\"{x:1351,y:763,t:1526933847476};\\\", \\\"{x:1354,y:763,t:1526933847484};\\\", \\\"{x:1355,y:763,t:1526933847495};\\\", \\\"{x:1361,y:763,t:1526933847513};\\\", \\\"{x:1366,y:763,t:1526933847530};\\\", \\\"{x:1370,y:763,t:1526933847545};\\\", \\\"{x:1376,y:765,t:1526933847563};\\\", \\\"{x:1378,y:765,t:1526933847580};\\\", \\\"{x:1380,y:765,t:1526933847596};\\\", \\\"{x:1381,y:765,t:1526933847636};\\\", \\\"{x:1383,y:765,t:1526933847660};\\\", \\\"{x:1384,y:765,t:1526933847684};\\\", \\\"{x:1385,y:765,t:1526933847696};\\\", \\\"{x:1387,y:765,t:1526933847713};\\\", \\\"{x:1388,y:765,t:1526933847730};\\\", \\\"{x:1389,y:765,t:1526933847746};\\\", \\\"{x:1391,y:765,t:1526933847764};\\\", \\\"{x:1394,y:764,t:1526933847780};\\\", \\\"{x:1396,y:764,t:1526933847796};\\\", \\\"{x:1397,y:764,t:1526933847813};\\\", \\\"{x:1400,y:762,t:1526933847829};\\\", \\\"{x:1402,y:762,t:1526933847860};\\\", \\\"{x:1403,y:761,t:1526933847868};\\\", \\\"{x:1404,y:761,t:1526933847948};\\\", \\\"{x:1405,y:761,t:1526933847964};\\\", \\\"{x:1406,y:759,t:1526933847980};\\\", \\\"{x:1407,y:759,t:1526933848005};\\\", \\\"{x:1408,y:759,t:1526933848012};\\\", \\\"{x:1409,y:759,t:1526933848030};\\\", \\\"{x:1409,y:758,t:1526933848047};\\\", \\\"{x:1410,y:758,t:1526933848117};\\\", \\\"{x:1412,y:758,t:1526933848130};\\\", \\\"{x:1413,y:758,t:1526933848152};\\\", \\\"{x:1414,y:757,t:1526933848230};\\\", \\\"{x:1416,y:757,t:1526933848478};\\\", \\\"{x:1417,y:758,t:1526933848493};\\\", \\\"{x:1417,y:759,t:1526933848509};\\\", \\\"{x:1418,y:759,t:1526933848525};\\\", \\\"{x:1419,y:759,t:1526933848564};\\\", \\\"{x:1420,y:759,t:1526933848579};\\\", \\\"{x:1422,y:759,t:1526933848597};\\\", \\\"{x:1425,y:759,t:1526933848613};\\\", \\\"{x:1426,y:760,t:1526933848629};\\\", \\\"{x:1428,y:760,t:1526933848647};\\\", \\\"{x:1429,y:760,t:1526933848662};\\\", \\\"{x:1432,y:760,t:1526933848679};\\\", \\\"{x:1435,y:761,t:1526933848696};\\\", \\\"{x:1436,y:761,t:1526933848712};\\\", \\\"{x:1439,y:762,t:1526933848729};\\\", \\\"{x:1442,y:762,t:1526933848746};\\\", \\\"{x:1445,y:762,t:1526933848762};\\\", \\\"{x:1448,y:763,t:1526933848780};\\\", \\\"{x:1451,y:763,t:1526933848796};\\\", \\\"{x:1455,y:763,t:1526933848813};\\\", \\\"{x:1458,y:763,t:1526933848829};\\\", \\\"{x:1461,y:763,t:1526933848845};\\\", \\\"{x:1464,y:763,t:1526933848863};\\\", \\\"{x:1465,y:763,t:1526933848879};\\\", \\\"{x:1466,y:763,t:1526933848925};\\\", \\\"{x:1467,y:763,t:1526933848932};\\\", \\\"{x:1468,y:763,t:1526933848945};\\\", \\\"{x:1469,y:762,t:1526933848964};\\\", \\\"{x:1470,y:762,t:1526933848997};\\\", \\\"{x:1471,y:762,t:1526933849013};\\\", \\\"{x:1472,y:761,t:1526933849038};\\\", \\\"{x:1473,y:761,t:1526933849350};\\\", \\\"{x:1474,y:761,t:1526933849363};\\\", \\\"{x:1477,y:762,t:1526933849379};\\\", \\\"{x:1478,y:762,t:1526933849396};\\\", \\\"{x:1484,y:763,t:1526933849413};\\\", \\\"{x:1489,y:763,t:1526933849429};\\\", \\\"{x:1496,y:763,t:1526933849446};\\\", \\\"{x:1501,y:766,t:1526933849463};\\\", \\\"{x:1504,y:766,t:1526933849479};\\\", \\\"{x:1507,y:766,t:1526933849496};\\\", \\\"{x:1510,y:766,t:1526933849514};\\\", \\\"{x:1511,y:766,t:1526933849528};\\\", \\\"{x:1512,y:766,t:1526933849546};\\\", \\\"{x:1513,y:766,t:1526933849562};\\\", \\\"{x:1514,y:765,t:1526933849580};\\\", \\\"{x:1515,y:765,t:1526933849595};\\\", \\\"{x:1519,y:765,t:1526933849612};\\\", \\\"{x:1524,y:763,t:1526933849628};\\\", \\\"{x:1528,y:763,t:1526933849645};\\\", \\\"{x:1531,y:763,t:1526933849663};\\\", \\\"{x:1534,y:762,t:1526933849678};\\\", \\\"{x:1530,y:762,t:1526933849798};\\\", \\\"{x:1493,y:762,t:1526933849813};\\\", \\\"{x:1409,y:764,t:1526933849829};\\\", \\\"{x:1306,y:766,t:1526933849845};\\\", \\\"{x:1170,y:769,t:1526933849862};\\\", \\\"{x:1032,y:769,t:1526933849879};\\\", \\\"{x:866,y:769,t:1526933849895};\\\", \\\"{x:713,y:768,t:1526933849912};\\\", \\\"{x:599,y:768,t:1526933849928};\\\", \\\"{x:524,y:766,t:1526933849945};\\\", \\\"{x:489,y:765,t:1526933849961};\\\", \\\"{x:468,y:765,t:1526933849979};\\\", \\\"{x:458,y:765,t:1526933849995};\\\", \\\"{x:457,y:764,t:1526933850011};\\\", \\\"{x:452,y:764,t:1526933850029};\\\", \\\"{x:438,y:764,t:1526933850045};\\\", \\\"{x:419,y:764,t:1526933850061};\\\", \\\"{x:396,y:760,t:1526933850078};\\\", \\\"{x:375,y:757,t:1526933850096};\\\", \\\"{x:360,y:749,t:1526933850112};\\\", \\\"{x:354,y:743,t:1526933850128};\\\", \\\"{x:352,y:736,t:1526933850145};\\\", \\\"{x:353,y:725,t:1526933850162};\\\", \\\"{x:362,y:712,t:1526933850179};\\\", \\\"{x:367,y:706,t:1526933850195};\\\", \\\"{x:369,y:703,t:1526933850211};\\\", \\\"{x:374,y:697,t:1526933850228};\\\", \\\"{x:375,y:692,t:1526933850245};\\\", \\\"{x:380,y:687,t:1526933850262};\\\", \\\"{x:388,y:680,t:1526933850278};\\\", \\\"{x:392,y:674,t:1526933850295};\\\", \\\"{x:401,y:668,t:1526933850313};\\\", \\\"{x:411,y:662,t:1526933850328};\\\", \\\"{x:427,y:655,t:1526933850345};\\\", \\\"{x:440,y:649,t:1526933850361};\\\", \\\"{x:449,y:643,t:1526933850378};\\\", \\\"{x:476,y:628,t:1526933850396};\\\", \\\"{x:525,y:616,t:1526933850412};\\\", \\\"{x:606,y:602,t:1526933850428};\\\", \\\"{x:635,y:599,t:1526933850446};\\\", \\\"{x:680,y:599,t:1526933850462};\\\", \\\"{x:751,y:604,t:1526933850479};\\\", \\\"{x:804,y:604,t:1526933850495};\\\", \\\"{x:836,y:604,t:1526933850512};\\\", \\\"{x:854,y:604,t:1526933850528};\\\", \\\"{x:868,y:604,t:1526933850545};\\\", \\\"{x:874,y:604,t:1526933850562};\\\", \\\"{x:876,y:604,t:1526933850578};\\\", \\\"{x:877,y:604,t:1526933850595};\\\", \\\"{x:879,y:604,t:1526933850652};\\\", \\\"{x:879,y:603,t:1526933850669};\\\", \\\"{x:881,y:601,t:1526933850685};\\\", \\\"{x:882,y:600,t:1526933850710};\\\", \\\"{x:882,y:599,t:1526933850732};\\\", \\\"{x:882,y:598,t:1526933850748};\\\", \\\"{x:881,y:597,t:1526933850762};\\\", \\\"{x:874,y:595,t:1526933850778};\\\", \\\"{x:869,y:595,t:1526933850795};\\\", \\\"{x:853,y:592,t:1526933850813};\\\", \\\"{x:840,y:588,t:1526933850830};\\\", \\\"{x:823,y:585,t:1526933850845};\\\", \\\"{x:816,y:584,t:1526933850862};\\\", \\\"{x:814,y:583,t:1526933850878};\\\", \\\"{x:812,y:583,t:1526933850916};\\\", \\\"{x:810,y:583,t:1526933850928};\\\", \\\"{x:804,y:583,t:1526933850945};\\\", \\\"{x:785,y:583,t:1526933850962};\\\", \\\"{x:767,y:583,t:1526933850978};\\\", \\\"{x:738,y:579,t:1526933850995};\\\", \\\"{x:703,y:567,t:1526933851013};\\\", \\\"{x:671,y:561,t:1526933851029};\\\", \\\"{x:657,y:557,t:1526933851045};\\\", \\\"{x:653,y:556,t:1526933851062};\\\", \\\"{x:651,y:555,t:1526933851080};\\\", \\\"{x:649,y:555,t:1526933851141};\\\", \\\"{x:648,y:554,t:1526933851156};\\\", \\\"{x:647,y:554,t:1526933851165};\\\", \\\"{x:647,y:553,t:1526933851180};\\\", \\\"{x:640,y:551,t:1526933851196};\\\", \\\"{x:610,y:548,t:1526933851214};\\\", \\\"{x:589,y:543,t:1526933851230};\\\", \\\"{x:575,y:542,t:1526933851247};\\\", \\\"{x:558,y:537,t:1526933851262};\\\", \\\"{x:534,y:533,t:1526933851280};\\\", \\\"{x:505,y:531,t:1526933851296};\\\", \\\"{x:444,y:524,t:1526933851313};\\\", \\\"{x:362,y:521,t:1526933851329};\\\", \\\"{x:321,y:518,t:1526933851345};\\\", \\\"{x:246,y:518,t:1526933851362};\\\", \\\"{x:197,y:519,t:1526933851380};\\\", \\\"{x:176,y:520,t:1526933851395};\\\", \\\"{x:138,y:527,t:1526933851413};\\\", \\\"{x:121,y:534,t:1526933851430};\\\", \\\"{x:110,y:539,t:1526933851446};\\\", \\\"{x:97,y:547,t:1526933851462};\\\", \\\"{x:95,y:549,t:1526933851480};\\\", \\\"{x:93,y:550,t:1526933851497};\\\", \\\"{x:93,y:553,t:1526933851512};\\\", \\\"{x:94,y:561,t:1526933851531};\\\", \\\"{x:94,y:565,t:1526933851547};\\\", \\\"{x:95,y:571,t:1526933851562};\\\", \\\"{x:97,y:576,t:1526933851579};\\\", \\\"{x:99,y:579,t:1526933851596};\\\", \\\"{x:100,y:580,t:1526933851612};\\\", \\\"{x:101,y:580,t:1526933851636};\\\", \\\"{x:102,y:580,t:1526933851646};\\\", \\\"{x:105,y:578,t:1526933851662};\\\", \\\"{x:107,y:575,t:1526933851679};\\\", \\\"{x:113,y:571,t:1526933851696};\\\", \\\"{x:123,y:565,t:1526933851712};\\\", \\\"{x:129,y:561,t:1526933851730};\\\", \\\"{x:133,y:558,t:1526933851747};\\\", \\\"{x:134,y:556,t:1526933851764};\\\", \\\"{x:134,y:555,t:1526933851780};\\\", \\\"{x:136,y:552,t:1526933851796};\\\", \\\"{x:136,y:550,t:1526933851812};\\\", \\\"{x:137,y:549,t:1526933851829};\\\", \\\"{x:137,y:548,t:1526933851846};\\\", \\\"{x:138,y:546,t:1526933851863};\\\", \\\"{x:138,y:545,t:1526933851900};\\\", \\\"{x:140,y:544,t:1526933851997};\\\", \\\"{x:142,y:544,t:1526933852014};\\\", \\\"{x:143,y:544,t:1526933852030};\\\", \\\"{x:147,y:544,t:1526933852047};\\\", \\\"{x:151,y:543,t:1526933852064};\\\", \\\"{x:156,y:543,t:1526933852080};\\\", \\\"{x:157,y:543,t:1526933852125};\\\", \\\"{x:164,y:547,t:1526933852693};\\\", \\\"{x:175,y:553,t:1526933852702};\\\", \\\"{x:189,y:558,t:1526933852713};\\\", \\\"{x:221,y:575,t:1526933852731};\\\", \\\"{x:293,y:597,t:1526933852748};\\\", \\\"{x:396,y:629,t:1526933852764};\\\", \\\"{x:611,y:683,t:1526933852780};\\\", \\\"{x:782,y:731,t:1526933852797};\\\", \\\"{x:962,y:785,t:1526933852813};\\\", \\\"{x:1116,y:827,t:1526933852831};\\\", \\\"{x:1253,y:872,t:1526933852848};\\\", \\\"{x:1402,y:916,t:1526933852863};\\\", \\\"{x:1531,y:946,t:1526933852880};\\\", \\\"{x:1624,y:967,t:1526933852898};\\\", \\\"{x:1680,y:982,t:1526933852913};\\\", \\\"{x:1698,y:987,t:1526933852930};\\\", \\\"{x:1707,y:990,t:1526933852948};\\\", \\\"{x:1707,y:989,t:1526933853044};\\\", \\\"{x:1707,y:982,t:1526933853052};\\\", \\\"{x:1706,y:971,t:1526933853063};\\\", \\\"{x:1696,y:955,t:1526933853080};\\\", \\\"{x:1688,y:939,t:1526933853096};\\\", \\\"{x:1667,y:921,t:1526933853114};\\\", \\\"{x:1636,y:903,t:1526933853130};\\\", \\\"{x:1614,y:889,t:1526933853148};\\\", \\\"{x:1594,y:879,t:1526933853164};\\\", \\\"{x:1569,y:865,t:1526933853180};\\\", \\\"{x:1563,y:860,t:1526933853197};\\\", \\\"{x:1554,y:858,t:1526933853214};\\\", \\\"{x:1551,y:856,t:1526933853231};\\\", \\\"{x:1546,y:853,t:1526933853246};\\\", \\\"{x:1544,y:849,t:1526933853263};\\\", \\\"{x:1538,y:848,t:1526933853280};\\\", \\\"{x:1530,y:847,t:1526933853296};\\\", \\\"{x:1517,y:844,t:1526933853314};\\\", \\\"{x:1505,y:843,t:1526933853330};\\\", \\\"{x:1488,y:840,t:1526933853347};\\\", \\\"{x:1478,y:840,t:1526933853363};\\\", \\\"{x:1457,y:834,t:1526933853380};\\\", \\\"{x:1449,y:833,t:1526933853397};\\\", \\\"{x:1445,y:833,t:1526933853414};\\\", \\\"{x:1444,y:833,t:1526933853431};\\\", \\\"{x:1444,y:835,t:1526933853751};\\\", \\\"{x:1447,y:839,t:1526933853764};\\\", \\\"{x:1459,y:855,t:1526933853781};\\\", \\\"{x:1465,y:866,t:1526933853797};\\\", \\\"{x:1474,y:876,t:1526933853814};\\\", \\\"{x:1479,y:887,t:1526933853831};\\\", \\\"{x:1485,y:896,t:1526933853847};\\\", \\\"{x:1495,y:908,t:1526933853864};\\\", \\\"{x:1499,y:913,t:1526933853881};\\\", \\\"{x:1500,y:915,t:1526933853897};\\\", \\\"{x:1502,y:919,t:1526933853914};\\\", \\\"{x:1503,y:921,t:1526933853931};\\\", \\\"{x:1505,y:923,t:1526933853947};\\\", \\\"{x:1507,y:929,t:1526933853964};\\\", \\\"{x:1511,y:937,t:1526933853981};\\\", \\\"{x:1514,y:941,t:1526933853997};\\\", \\\"{x:1516,y:945,t:1526933854014};\\\", \\\"{x:1518,y:950,t:1526933854031};\\\", \\\"{x:1522,y:954,t:1526933854047};\\\", \\\"{x:1524,y:960,t:1526933854063};\\\", \\\"{x:1530,y:967,t:1526933854081};\\\", \\\"{x:1531,y:971,t:1526933854096};\\\", \\\"{x:1535,y:976,t:1526933854114};\\\", \\\"{x:1538,y:978,t:1526933854131};\\\", \\\"{x:1538,y:979,t:1526933854164};\\\", \\\"{x:1538,y:980,t:1526933854188};\\\", \\\"{x:1538,y:981,t:1526933854204};\\\", \\\"{x:1538,y:982,t:1526933854372};\\\", \\\"{x:1538,y:978,t:1526933854412};\\\", \\\"{x:1539,y:976,t:1526933854420};\\\", \\\"{x:1544,y:973,t:1526933854429};\\\", \\\"{x:1550,y:968,t:1526933854447};\\\", \\\"{x:1551,y:966,t:1526933854468};\\\", \\\"{x:1553,y:963,t:1526933854485};\\\", \\\"{x:1554,y:962,t:1526933854500};\\\", \\\"{x:1554,y:960,t:1526933854516};\\\", \\\"{x:1554,y:959,t:1526933854530};\\\", \\\"{x:1553,y:955,t:1526933854546};\\\", \\\"{x:1550,y:951,t:1526933854563};\\\", \\\"{x:1544,y:946,t:1526933854580};\\\", \\\"{x:1539,y:941,t:1526933854596};\\\", \\\"{x:1537,y:938,t:1526933854614};\\\", \\\"{x:1532,y:933,t:1526933854630};\\\", \\\"{x:1529,y:926,t:1526933854647};\\\", \\\"{x:1526,y:920,t:1526933854663};\\\", \\\"{x:1524,y:915,t:1526933854679};\\\", \\\"{x:1523,y:913,t:1526933854697};\\\", \\\"{x:1523,y:910,t:1526933854714};\\\", \\\"{x:1523,y:908,t:1526933854729};\\\", \\\"{x:1523,y:904,t:1526933854746};\\\", \\\"{x:1524,y:899,t:1526933854764};\\\", \\\"{x:1526,y:894,t:1526933854779};\\\", \\\"{x:1531,y:885,t:1526933854796};\\\", \\\"{x:1532,y:880,t:1526933854814};\\\", \\\"{x:1534,y:875,t:1526933854830};\\\", \\\"{x:1537,y:872,t:1526933854847};\\\", \\\"{x:1539,y:866,t:1526933854863};\\\", \\\"{x:1541,y:861,t:1526933854880};\\\", \\\"{x:1544,y:854,t:1526933854896};\\\", \\\"{x:1544,y:851,t:1526933854914};\\\", \\\"{x:1546,y:847,t:1526933854929};\\\", \\\"{x:1547,y:846,t:1526933854946};\\\", \\\"{x:1548,y:843,t:1526933854964};\\\", \\\"{x:1550,y:840,t:1526933854979};\\\", \\\"{x:1551,y:834,t:1526933854996};\\\", \\\"{x:1552,y:828,t:1526933855014};\\\", \\\"{x:1554,y:823,t:1526933855030};\\\", \\\"{x:1556,y:816,t:1526933855047};\\\", \\\"{x:1559,y:809,t:1526933855064};\\\", \\\"{x:1562,y:802,t:1526933855080};\\\", \\\"{x:1563,y:796,t:1526933855097};\\\", \\\"{x:1564,y:790,t:1526933855114};\\\", \\\"{x:1568,y:782,t:1526933855130};\\\", \\\"{x:1569,y:776,t:1526933855147};\\\", \\\"{x:1571,y:767,t:1526933855164};\\\", \\\"{x:1574,y:755,t:1526933855180};\\\", \\\"{x:1576,y:747,t:1526933855197};\\\", \\\"{x:1577,y:742,t:1526933855213};\\\", \\\"{x:1577,y:738,t:1526933855230};\\\", \\\"{x:1576,y:729,t:1526933855247};\\\", \\\"{x:1574,y:719,t:1526933855263};\\\", \\\"{x:1573,y:712,t:1526933855279};\\\", \\\"{x:1571,y:708,t:1526933855297};\\\", \\\"{x:1570,y:705,t:1526933855313};\\\", \\\"{x:1567,y:697,t:1526933855330};\\\", \\\"{x:1565,y:692,t:1526933855347};\\\", \\\"{x:1563,y:689,t:1526933855363};\\\", \\\"{x:1561,y:684,t:1526933855379};\\\", \\\"{x:1559,y:681,t:1526933855397};\\\", \\\"{x:1557,y:679,t:1526933855414};\\\", \\\"{x:1557,y:677,t:1526933855429};\\\", \\\"{x:1556,y:675,t:1526933855447};\\\", \\\"{x:1556,y:674,t:1526933855463};\\\", \\\"{x:1555,y:672,t:1526933855480};\\\", \\\"{x:1553,y:670,t:1526933855497};\\\", \\\"{x:1552,y:668,t:1526933855514};\\\", \\\"{x:1550,y:665,t:1526933855529};\\\", \\\"{x:1548,y:661,t:1526933855547};\\\", \\\"{x:1546,y:657,t:1526933855564};\\\", \\\"{x:1546,y:655,t:1526933855580};\\\", \\\"{x:1544,y:653,t:1526933855597};\\\", \\\"{x:1543,y:650,t:1526933855614};\\\", \\\"{x:1543,y:648,t:1526933855637};\\\", \\\"{x:1543,y:647,t:1526933855647};\\\", \\\"{x:1543,y:646,t:1526933855751};\\\", \\\"{x:1543,y:643,t:1526933856357};\\\", \\\"{x:1543,y:641,t:1526933856365};\\\", \\\"{x:1543,y:640,t:1526933856398};\\\", \\\"{x:1543,y:639,t:1526933856429};\\\", \\\"{x:1542,y:638,t:1526933856447};\\\", \\\"{x:1542,y:637,t:1526933856526};\\\", \\\"{x:1542,y:636,t:1526933856533};\\\", \\\"{x:1542,y:635,t:1526933856547};\\\", \\\"{x:1542,y:634,t:1526933856565};\\\", \\\"{x:1542,y:631,t:1526933856597};\\\", \\\"{x:1542,y:629,t:1526933856613};\\\", \\\"{x:1542,y:626,t:1526933856631};\\\", \\\"{x:1542,y:623,t:1526933856647};\\\", \\\"{x:1542,y:620,t:1526933856664};\\\", \\\"{x:1543,y:620,t:1526933856680};\\\", \\\"{x:1544,y:618,t:1526933856698};\\\", \\\"{x:1544,y:616,t:1526933856713};\\\", \\\"{x:1544,y:615,t:1526933856730};\\\", \\\"{x:1545,y:612,t:1526933856747};\\\", \\\"{x:1545,y:609,t:1526933856763};\\\", \\\"{x:1546,y:608,t:1526933856780};\\\", \\\"{x:1547,y:607,t:1526933856797};\\\", \\\"{x:1547,y:605,t:1526933856821};\\\", \\\"{x:1547,y:603,t:1526933856830};\\\", \\\"{x:1549,y:602,t:1526933856847};\\\", \\\"{x:1549,y:601,t:1526933856863};\\\", \\\"{x:1550,y:599,t:1526933856880};\\\", \\\"{x:1550,y:596,t:1526933856897};\\\", \\\"{x:1550,y:594,t:1526933856913};\\\", \\\"{x:1550,y:591,t:1526933856930};\\\", \\\"{x:1551,y:590,t:1526933856957};\\\", \\\"{x:1551,y:588,t:1526933856973};\\\", \\\"{x:1551,y:586,t:1526933856989};\\\", \\\"{x:1551,y:585,t:1526933857013};\\\", \\\"{x:1552,y:584,t:1526933857030};\\\", \\\"{x:1552,y:583,t:1526933857046};\\\", \\\"{x:1552,y:582,t:1526933857063};\\\", \\\"{x:1552,y:580,t:1526933857080};\\\", \\\"{x:1553,y:580,t:1526933857096};\\\", \\\"{x:1553,y:579,t:1526933857113};\\\", \\\"{x:1553,y:578,t:1526933857157};\\\", \\\"{x:1553,y:577,t:1526933857165};\\\", \\\"{x:1553,y:576,t:1526933858390};\\\", \\\"{x:1551,y:576,t:1526933858397};\\\", \\\"{x:1545,y:573,t:1526933858413};\\\", \\\"{x:1539,y:572,t:1526933858429};\\\", \\\"{x:1533,y:569,t:1526933858446};\\\", \\\"{x:1531,y:569,t:1526933858463};\\\", \\\"{x:1530,y:569,t:1526933858479};\\\", \\\"{x:1529,y:568,t:1526933858589};\\\", \\\"{x:1529,y:566,t:1526933858597};\\\", \\\"{x:1529,y:563,t:1526933858613};\\\", \\\"{x:1529,y:562,t:1526933858629};\\\", \\\"{x:1529,y:559,t:1526933858645};\\\", \\\"{x:1529,y:558,t:1526933858668};\\\", \\\"{x:1529,y:557,t:1526933858684};\\\", \\\"{x:1530,y:556,t:1526933858724};\\\", \\\"{x:1531,y:556,t:1526933858846};\\\", \\\"{x:1534,y:556,t:1526933858863};\\\", \\\"{x:1536,y:556,t:1526933858879};\\\", \\\"{x:1540,y:556,t:1526933858897};\\\", \\\"{x:1543,y:556,t:1526933858913};\\\", \\\"{x:1547,y:556,t:1526933858929};\\\", \\\"{x:1551,y:556,t:1526933858947};\\\", \\\"{x:1554,y:556,t:1526933858963};\\\", \\\"{x:1557,y:556,t:1526933858980};\\\", \\\"{x:1559,y:556,t:1526933858996};\\\", \\\"{x:1563,y:557,t:1526933859013};\\\", \\\"{x:1564,y:557,t:1526933859030};\\\", \\\"{x:1565,y:557,t:1526933859213};\\\", \\\"{x:1565,y:558,t:1526933859230};\\\", \\\"{x:1564,y:559,t:1526933859253};\\\", \\\"{x:1563,y:560,t:1526933859534};\\\", \\\"{x:1562,y:560,t:1526933859548};\\\", \\\"{x:1561,y:560,t:1526933859563};\\\", \\\"{x:1560,y:560,t:1526933860085};\\\", \\\"{x:1559,y:560,t:1526933860398};\\\", \\\"{x:1558,y:561,t:1526933860421};\\\", \\\"{x:1556,y:562,t:1526933860477};\\\", \\\"{x:1555,y:562,t:1526933860525};\\\", \\\"{x:1553,y:562,t:1526933860541};\\\", \\\"{x:1552,y:563,t:1526933860573};\\\", \\\"{x:1551,y:563,t:1526933860597};\\\", \\\"{x:1550,y:563,t:1526933860645};\\\", \\\"{x:1550,y:564,t:1526933860988};\\\", \\\"{x:1546,y:569,t:1526933863838};\\\", \\\"{x:1520,y:589,t:1526933863845};\\\", \\\"{x:1440,y:652,t:1526933863861};\\\", \\\"{x:1359,y:714,t:1526933863878};\\\", \\\"{x:1305,y:742,t:1526933863896};\\\", \\\"{x:1280,y:754,t:1526933863911};\\\", \\\"{x:1262,y:762,t:1526933863928};\\\", \\\"{x:1253,y:767,t:1526933863945};\\\", \\\"{x:1241,y:774,t:1526933863961};\\\", \\\"{x:1232,y:781,t:1526933863979};\\\", \\\"{x:1221,y:787,t:1526933863995};\\\", \\\"{x:1211,y:792,t:1526933864011};\\\", \\\"{x:1201,y:798,t:1526933864029};\\\", \\\"{x:1185,y:809,t:1526933864045};\\\", \\\"{x:1177,y:816,t:1526933864062};\\\", \\\"{x:1173,y:819,t:1526933864078};\\\", \\\"{x:1172,y:819,t:1526933864096};\\\", \\\"{x:1169,y:818,t:1526933864190};\\\", \\\"{x:1168,y:815,t:1526933864197};\\\", \\\"{x:1166,y:811,t:1526933864212};\\\", \\\"{x:1160,y:799,t:1526933864228};\\\", \\\"{x:1150,y:780,t:1526933864245};\\\", \\\"{x:1149,y:772,t:1526933864262};\\\", \\\"{x:1148,y:769,t:1526933864278};\\\", \\\"{x:1148,y:766,t:1526933864295};\\\", \\\"{x:1148,y:764,t:1526933864312};\\\", \\\"{x:1149,y:763,t:1526933864329};\\\", \\\"{x:1150,y:761,t:1526933864344};\\\", \\\"{x:1151,y:759,t:1526933864362};\\\", \\\"{x:1153,y:757,t:1526933864378};\\\", \\\"{x:1154,y:757,t:1526933864395};\\\", \\\"{x:1156,y:756,t:1526933864412};\\\", \\\"{x:1157,y:755,t:1526933864429};\\\", \\\"{x:1158,y:755,t:1526933864453};\\\", \\\"{x:1159,y:755,t:1526933864461};\\\", \\\"{x:1160,y:755,t:1526933864478};\\\", \\\"{x:1161,y:755,t:1526933864496};\\\", \\\"{x:1163,y:755,t:1526933864533};\\\", \\\"{x:1164,y:756,t:1526933864557};\\\", \\\"{x:1165,y:757,t:1526933864573};\\\", \\\"{x:1166,y:758,t:1526933864605};\\\", \\\"{x:1166,y:759,t:1526933864751};\\\", \\\"{x:1168,y:759,t:1526933864761};\\\", \\\"{x:1170,y:759,t:1526933864778};\\\", \\\"{x:1173,y:760,t:1526933864795};\\\", \\\"{x:1184,y:760,t:1526933864812};\\\", \\\"{x:1200,y:763,t:1526933864830};\\\", \\\"{x:1205,y:763,t:1526933864845};\\\", \\\"{x:1215,y:763,t:1526933864861};\\\", \\\"{x:1219,y:764,t:1526933864879};\\\", \\\"{x:1221,y:765,t:1526933864895};\\\", \\\"{x:1223,y:766,t:1526933864911};\\\", \\\"{x:1226,y:766,t:1526933864928};\\\", \\\"{x:1230,y:766,t:1526933864944};\\\", \\\"{x:1232,y:766,t:1526933864961};\\\", \\\"{x:1234,y:765,t:1526933864979};\\\", \\\"{x:1236,y:765,t:1526933864995};\\\", \\\"{x:1236,y:764,t:1526933865054};\\\", \\\"{x:1237,y:764,t:1526933865085};\\\", \\\"{x:1238,y:763,t:1526933865125};\\\", \\\"{x:1239,y:763,t:1526933865133};\\\", \\\"{x:1240,y:763,t:1526933865693};\\\", \\\"{x:1247,y:763,t:1526933865712};\\\", \\\"{x:1254,y:763,t:1526933865729};\\\", \\\"{x:1260,y:763,t:1526933865744};\\\", \\\"{x:1263,y:763,t:1526933865761};\\\", \\\"{x:1266,y:763,t:1526933865778};\\\", \\\"{x:1268,y:763,t:1526933865797};\\\", \\\"{x:1268,y:762,t:1526933865811};\\\", \\\"{x:1269,y:762,t:1526933865828};\\\", \\\"{x:1275,y:762,t:1526933865845};\\\", \\\"{x:1278,y:761,t:1526933865861};\\\", \\\"{x:1284,y:760,t:1526933865879};\\\", \\\"{x:1291,y:760,t:1526933865894};\\\", \\\"{x:1294,y:760,t:1526933865911};\\\", \\\"{x:1299,y:759,t:1526933865927};\\\", \\\"{x:1301,y:759,t:1526933865956};\\\", \\\"{x:1302,y:758,t:1526933865972};\\\", \\\"{x:1304,y:757,t:1526933866012};\\\", \\\"{x:1304,y:756,t:1526933866029};\\\", \\\"{x:1305,y:755,t:1526933866060};\\\", \\\"{x:1307,y:755,t:1526933866109};\\\", \\\"{x:1308,y:755,t:1526933866124};\\\", \\\"{x:1310,y:755,t:1526933866149};\\\", \\\"{x:1311,y:755,t:1526933866206};\\\", \\\"{x:1312,y:755,t:1526933866237};\\\", \\\"{x:1313,y:755,t:1526933866302};\\\", \\\"{x:1313,y:756,t:1526933866365};\\\", \\\"{x:1313,y:757,t:1526933866429};\\\", \\\"{x:1313,y:758,t:1526933866469};\\\", \\\"{x:1313,y:759,t:1526933866509};\\\", \\\"{x:1314,y:759,t:1526933866533};\\\", \\\"{x:1315,y:759,t:1526933866550};\\\", \\\"{x:1317,y:760,t:1526933866561};\\\", \\\"{x:1321,y:761,t:1526933866577};\\\", \\\"{x:1326,y:761,t:1526933866595};\\\", \\\"{x:1332,y:762,t:1526933866611};\\\", \\\"{x:1340,y:763,t:1526933866628};\\\", \\\"{x:1355,y:763,t:1526933866645};\\\", \\\"{x:1362,y:764,t:1526933866661};\\\", \\\"{x:1367,y:764,t:1526933866678};\\\", \\\"{x:1369,y:764,t:1526933866694};\\\", \\\"{x:1370,y:764,t:1526933866725};\\\", \\\"{x:1371,y:764,t:1526933866741};\\\", \\\"{x:1373,y:764,t:1526933866752};\\\", \\\"{x:1376,y:764,t:1526933866773};\\\", \\\"{x:1377,y:764,t:1526933866781};\\\", \\\"{x:1378,y:764,t:1526933866795};\\\", \\\"{x:1380,y:763,t:1526933866811};\\\", \\\"{x:1381,y:763,t:1526933866827};\\\", \\\"{x:1382,y:763,t:1526933866844};\\\", \\\"{x:1376,y:764,t:1526933866940};\\\", \\\"{x:1367,y:772,t:1526933866948};\\\", \\\"{x:1352,y:781,t:1526933866961};\\\", \\\"{x:1315,y:798,t:1526933866977};\\\", \\\"{x:1289,y:814,t:1526933866995};\\\", \\\"{x:1266,y:821,t:1526933867010};\\\", \\\"{x:1259,y:823,t:1526933867028};\\\", \\\"{x:1252,y:824,t:1526933867044};\\\", \\\"{x:1250,y:824,t:1526933867198};\\\", \\\"{x:1249,y:824,t:1526933867213};\\\", \\\"{x:1248,y:824,t:1526933867229};\\\", \\\"{x:1243,y:824,t:1526933867245};\\\", \\\"{x:1238,y:824,t:1526933867261};\\\", \\\"{x:1229,y:824,t:1526933867277};\\\", \\\"{x:1224,y:824,t:1526933867294};\\\", \\\"{x:1220,y:824,t:1526933867310};\\\", \\\"{x:1217,y:824,t:1526933867328};\\\", \\\"{x:1216,y:824,t:1526933867345};\\\", \\\"{x:1215,y:824,t:1526933867389};\\\", \\\"{x:1217,y:824,t:1526933867710};\\\", \\\"{x:1218,y:824,t:1526933867728};\\\", \\\"{x:1226,y:821,t:1526933867745};\\\", \\\"{x:1229,y:820,t:1526933867760};\\\", \\\"{x:1234,y:819,t:1526933867777};\\\", \\\"{x:1238,y:819,t:1526933867794};\\\", \\\"{x:1242,y:819,t:1526933867810};\\\", \\\"{x:1245,y:817,t:1526933867827};\\\", \\\"{x:1248,y:817,t:1526933867844};\\\", \\\"{x:1250,y:817,t:1526933867859};\\\", \\\"{x:1253,y:816,t:1526933867877};\\\", \\\"{x:1255,y:815,t:1526933867894};\\\", \\\"{x:1256,y:815,t:1526933867910};\\\", \\\"{x:1257,y:815,t:1526933867927};\\\", \\\"{x:1259,y:814,t:1526933867944};\\\", \\\"{x:1261,y:814,t:1526933867960};\\\", \\\"{x:1261,y:813,t:1526933867977};\\\", \\\"{x:1262,y:813,t:1526933867994};\\\", \\\"{x:1264,y:813,t:1526933868011};\\\", \\\"{x:1266,y:813,t:1526933868036};\\\", \\\"{x:1268,y:813,t:1526933868044};\\\", \\\"{x:1272,y:813,t:1526933868060};\\\", \\\"{x:1276,y:813,t:1526933868077};\\\", \\\"{x:1278,y:813,t:1526933868095};\\\", \\\"{x:1279,y:813,t:1526933868110};\\\", \\\"{x:1280,y:813,t:1526933868128};\\\", \\\"{x:1281,y:815,t:1526933868145};\\\", \\\"{x:1282,y:815,t:1526933868161};\\\", \\\"{x:1283,y:815,t:1526933868177};\\\", \\\"{x:1284,y:816,t:1526933868293};\\\", \\\"{x:1284,y:817,t:1526933868311};\\\", \\\"{x:1286,y:818,t:1526933868328};\\\", \\\"{x:1287,y:820,t:1526933868343};\\\", \\\"{x:1288,y:820,t:1526933868361};\\\", \\\"{x:1291,y:820,t:1526933868378};\\\", \\\"{x:1293,y:821,t:1526933868393};\\\", \\\"{x:1296,y:823,t:1526933868411};\\\", \\\"{x:1299,y:824,t:1526933868428};\\\", \\\"{x:1302,y:824,t:1526933868444};\\\", \\\"{x:1308,y:824,t:1526933868460};\\\", \\\"{x:1312,y:824,t:1526933868477};\\\", \\\"{x:1316,y:824,t:1526933868494};\\\", \\\"{x:1322,y:826,t:1526933868510};\\\", \\\"{x:1324,y:826,t:1526933868527};\\\", \\\"{x:1327,y:826,t:1526933868543};\\\", \\\"{x:1328,y:826,t:1526933868560};\\\", \\\"{x:1330,y:826,t:1526933868577};\\\", \\\"{x:1331,y:826,t:1526933868593};\\\", \\\"{x:1333,y:827,t:1526933868610};\\\", \\\"{x:1336,y:827,t:1526933868627};\\\", \\\"{x:1337,y:827,t:1526933868643};\\\", \\\"{x:1343,y:828,t:1526933868660};\\\", \\\"{x:1353,y:831,t:1526933868677};\\\", \\\"{x:1355,y:831,t:1526933868694};\\\", \\\"{x:1356,y:831,t:1526933868710};\\\", \\\"{x:1358,y:832,t:1526933868727};\\\", \\\"{x:1359,y:832,t:1526933868743};\\\", \\\"{x:1361,y:832,t:1526933868760};\\\", \\\"{x:1362,y:832,t:1526933868777};\\\", \\\"{x:1363,y:832,t:1526933868793};\\\", \\\"{x:1364,y:832,t:1526933868811};\\\", \\\"{x:1364,y:831,t:1526933869166};\\\", \\\"{x:1363,y:831,t:1526933869178};\\\", \\\"{x:1363,y:835,t:1526933869194};\\\", \\\"{x:1363,y:839,t:1526933869210};\\\", \\\"{x:1363,y:847,t:1526933869228};\\\", \\\"{x:1363,y:857,t:1526933869244};\\\", \\\"{x:1370,y:867,t:1526933869260};\\\", \\\"{x:1372,y:870,t:1526933869277};\\\", \\\"{x:1374,y:872,t:1526933869294};\\\", \\\"{x:1374,y:873,t:1526933869311};\\\", \\\"{x:1374,y:874,t:1526933869328};\\\", \\\"{x:1376,y:878,t:1526933869343};\\\", \\\"{x:1377,y:878,t:1526933869360};\\\", \\\"{x:1378,y:879,t:1526933869377};\\\", \\\"{x:1378,y:881,t:1526933869393};\\\", \\\"{x:1378,y:883,t:1526933869412};\\\", \\\"{x:1378,y:884,t:1526933869443};\\\", \\\"{x:1379,y:885,t:1526933869459};\\\", \\\"{x:1379,y:888,t:1526933869477};\\\", \\\"{x:1379,y:889,t:1526933869493};\\\", \\\"{x:1379,y:890,t:1526933869510};\\\", \\\"{x:1380,y:892,t:1526933869526};\\\", \\\"{x:1381,y:893,t:1526933869543};\\\", \\\"{x:1381,y:894,t:1526933869560};\\\", \\\"{x:1382,y:894,t:1526933869950};\\\", \\\"{x:1383,y:894,t:1526933869961};\\\", \\\"{x:1386,y:894,t:1526933869976};\\\", \\\"{x:1390,y:894,t:1526933869994};\\\", \\\"{x:1395,y:896,t:1526933870010};\\\", \\\"{x:1403,y:896,t:1526933870027};\\\", \\\"{x:1411,y:899,t:1526933870043};\\\", \\\"{x:1424,y:901,t:1526933870061};\\\", \\\"{x:1432,y:901,t:1526933870077};\\\", \\\"{x:1440,y:901,t:1526933870093};\\\", \\\"{x:1448,y:901,t:1526933870110};\\\", \\\"{x:1451,y:901,t:1526933870127};\\\", \\\"{x:1453,y:901,t:1526933870144};\\\", \\\"{x:1457,y:901,t:1526933870160};\\\", \\\"{x:1455,y:901,t:1526933870421};\\\", \\\"{x:1454,y:899,t:1526933870661};\\\", \\\"{x:1453,y:899,t:1526933870677};\\\", \\\"{x:1452,y:898,t:1526933870694};\\\", \\\"{x:1451,y:898,t:1526933870711};\\\", \\\"{x:1450,y:898,t:1526933870757};\\\", \\\"{x:1449,y:898,t:1526933871142};\\\", \\\"{x:1447,y:898,t:1526933871150};\\\", \\\"{x:1445,y:896,t:1526933871165};\\\", \\\"{x:1443,y:896,t:1526933871177};\\\", \\\"{x:1441,y:896,t:1526933871194};\\\", \\\"{x:1439,y:895,t:1526933871211};\\\", \\\"{x:1437,y:894,t:1526933871227};\\\", \\\"{x:1435,y:892,t:1526933871244};\\\", \\\"{x:1433,y:890,t:1526933871259};\\\", \\\"{x:1419,y:887,t:1526933871276};\\\", \\\"{x:1416,y:884,t:1526933871294};\\\", \\\"{x:1419,y:882,t:1526933871661};\\\", \\\"{x:1420,y:876,t:1526933871677};\\\", \\\"{x:1430,y:871,t:1526933871693};\\\", \\\"{x:1440,y:866,t:1526933871710};\\\", \\\"{x:1443,y:860,t:1526933871727};\\\", \\\"{x:1456,y:852,t:1526933871744};\\\", \\\"{x:1467,y:842,t:1526933871760};\\\", \\\"{x:1481,y:829,t:1526933871777};\\\", \\\"{x:1497,y:812,t:1526933871795};\\\", \\\"{x:1515,y:794,t:1526933871810};\\\", \\\"{x:1530,y:782,t:1526933871827};\\\", \\\"{x:1547,y:769,t:1526933871844};\\\", \\\"{x:1557,y:759,t:1526933871860};\\\", \\\"{x:1562,y:750,t:1526933871876};\\\", \\\"{x:1563,y:747,t:1526933871893};\\\", \\\"{x:1564,y:745,t:1526933871910};\\\", \\\"{x:1564,y:744,t:1526933871927};\\\", \\\"{x:1565,y:743,t:1526933871944};\\\", \\\"{x:1564,y:742,t:1526933872013};\\\", \\\"{x:1558,y:742,t:1526933872026};\\\", \\\"{x:1539,y:746,t:1526933872043};\\\", \\\"{x:1528,y:753,t:1526933872060};\\\", \\\"{x:1525,y:755,t:1526933872077};\\\", \\\"{x:1520,y:755,t:1526933872093};\\\", \\\"{x:1517,y:757,t:1526933872110};\\\", \\\"{x:1516,y:758,t:1526933872180};\\\", \\\"{x:1515,y:758,t:1526933872209};\\\", \\\"{x:1514,y:759,t:1526933872226};\\\", \\\"{x:1513,y:760,t:1526933872243};\\\", \\\"{x:1512,y:761,t:1526933872259};\\\", \\\"{x:1511,y:762,t:1526933872284};\\\", \\\"{x:1510,y:764,t:1526933872292};\\\", \\\"{x:1509,y:766,t:1526933872310};\\\", \\\"{x:1508,y:768,t:1526933872326};\\\", \\\"{x:1507,y:769,t:1526933872342};\\\", \\\"{x:1506,y:770,t:1526933872359};\\\", \\\"{x:1507,y:770,t:1526933872701};\\\", \\\"{x:1508,y:770,t:1526933872725};\\\", \\\"{x:1509,y:770,t:1526933872756};\\\", \\\"{x:1510,y:770,t:1526933872804};\\\", \\\"{x:1510,y:769,t:1526933872836};\\\", \\\"{x:1511,y:769,t:1526933872910};\\\", \\\"{x:1512,y:769,t:1526933873189};\\\", \\\"{x:1514,y:768,t:1526933873197};\\\", \\\"{x:1515,y:767,t:1526933873226};\\\", \\\"{x:1516,y:767,t:1526933873252};\\\", \\\"{x:1517,y:767,t:1526933873275};\\\", \\\"{x:1519,y:766,t:1526933873517};\\\", \\\"{x:1520,y:765,t:1526933873527};\\\", \\\"{x:1522,y:764,t:1526933873550};\\\", \\\"{x:1524,y:763,t:1526933873560};\\\", \\\"{x:1526,y:763,t:1526933873575};\\\", \\\"{x:1529,y:763,t:1526933873604};\\\", \\\"{x:1530,y:763,t:1526933873611};\\\", \\\"{x:1533,y:763,t:1526933873625};\\\", \\\"{x:1537,y:761,t:1526933873643};\\\", \\\"{x:1542,y:761,t:1526933873659};\\\", \\\"{x:1549,y:761,t:1526933873675};\\\", \\\"{x:1554,y:761,t:1526933873693};\\\", \\\"{x:1561,y:761,t:1526933873710};\\\", \\\"{x:1566,y:760,t:1526933873725};\\\", \\\"{x:1569,y:760,t:1526933873742};\\\", \\\"{x:1571,y:760,t:1526933873760};\\\", \\\"{x:1572,y:760,t:1526933874086};\\\", \\\"{x:1573,y:760,t:1526933874101};\\\", \\\"{x:1575,y:760,t:1526933874133};\\\", \\\"{x:1576,y:760,t:1526933874143};\\\", \\\"{x:1577,y:760,t:1526933874221};\\\", \\\"{x:1578,y:759,t:1526933874350};\\\", \\\"{x:1576,y:759,t:1526933874885};\\\", \\\"{x:1572,y:759,t:1526933874892};\\\", \\\"{x:1562,y:759,t:1526933874909};\\\", \\\"{x:1553,y:763,t:1526933874926};\\\", \\\"{x:1546,y:763,t:1526933874942};\\\", \\\"{x:1538,y:761,t:1526933874960};\\\", \\\"{x:1537,y:761,t:1526933874976};\\\", \\\"{x:1536,y:760,t:1526933875229};\\\", \\\"{x:1536,y:759,t:1526933875243};\\\", \\\"{x:1536,y:757,t:1526933875259};\\\", \\\"{x:1536,y:751,t:1526933875276};\\\", \\\"{x:1537,y:747,t:1526933875293};\\\", \\\"{x:1539,y:743,t:1526933875309};\\\", \\\"{x:1541,y:736,t:1526933875326};\\\", \\\"{x:1542,y:730,t:1526933875343};\\\", \\\"{x:1544,y:723,t:1526933875359};\\\", \\\"{x:1546,y:716,t:1526933875376};\\\", \\\"{x:1547,y:707,t:1526933875393};\\\", \\\"{x:1550,y:695,t:1526933875409};\\\", \\\"{x:1553,y:680,t:1526933875426};\\\", \\\"{x:1555,y:667,t:1526933875443};\\\", \\\"{x:1557,y:658,t:1526933875459};\\\", \\\"{x:1560,y:649,t:1526933875477};\\\", \\\"{x:1564,y:632,t:1526933875493};\\\", \\\"{x:1565,y:622,t:1526933875509};\\\", \\\"{x:1565,y:611,t:1526933875527};\\\", \\\"{x:1566,y:602,t:1526933875543};\\\", \\\"{x:1567,y:591,t:1526933875559};\\\", \\\"{x:1567,y:580,t:1526933875576};\\\", \\\"{x:1567,y:571,t:1526933875593};\\\", \\\"{x:1567,y:563,t:1526933875609};\\\", \\\"{x:1564,y:553,t:1526933875626};\\\", \\\"{x:1558,y:542,t:1526933875643};\\\", \\\"{x:1551,y:527,t:1526933875659};\\\", \\\"{x:1544,y:517,t:1526933875676};\\\", \\\"{x:1534,y:499,t:1526933875693};\\\", \\\"{x:1530,y:489,t:1526933875708};\\\", \\\"{x:1525,y:479,t:1526933875726};\\\", \\\"{x:1522,y:473,t:1526933875743};\\\", \\\"{x:1516,y:463,t:1526933875759};\\\", \\\"{x:1514,y:455,t:1526933875776};\\\", \\\"{x:1510,y:444,t:1526933875793};\\\", \\\"{x:1505,y:434,t:1526933875809};\\\", \\\"{x:1502,y:425,t:1526933875826};\\\", \\\"{x:1499,y:417,t:1526933875843};\\\", \\\"{x:1498,y:410,t:1526933875859};\\\", \\\"{x:1496,y:399,t:1526933875876};\\\", \\\"{x:1494,y:389,t:1526933875893};\\\", \\\"{x:1494,y:380,t:1526933875909};\\\", \\\"{x:1494,y:374,t:1526933875925};\\\", \\\"{x:1494,y:368,t:1526933875941};\\\", \\\"{x:1494,y:361,t:1526933875959};\\\", \\\"{x:1497,y:352,t:1526933875975};\\\", \\\"{x:1499,y:345,t:1526933875991};\\\", \\\"{x:1502,y:339,t:1526933876009};\\\", \\\"{x:1506,y:331,t:1526933876025};\\\", \\\"{x:1507,y:327,t:1526933876042};\\\", \\\"{x:1510,y:321,t:1526933876058};\\\", \\\"{x:1513,y:314,t:1526933876075};\\\", \\\"{x:1515,y:310,t:1526933876091};\\\", \\\"{x:1516,y:305,t:1526933876108};\\\", \\\"{x:1516,y:304,t:1526933876126};\\\", \\\"{x:1517,y:301,t:1526933876141};\\\", \\\"{x:1517,y:300,t:1526933876159};\\\", \\\"{x:1518,y:299,t:1526933876176};\\\", \\\"{x:1519,y:298,t:1526933876196};\\\", \\\"{x:1519,y:299,t:1526933876421};\\\", \\\"{x:1519,y:301,t:1526933876429};\\\", \\\"{x:1519,y:303,t:1526933876442};\\\", \\\"{x:1519,y:306,t:1526933876460};\\\", \\\"{x:1519,y:310,t:1526933876476};\\\", \\\"{x:1521,y:312,t:1526933876492};\\\", \\\"{x:1523,y:315,t:1526933876508};\\\", \\\"{x:1526,y:321,t:1526933876526};\\\", \\\"{x:1528,y:326,t:1526933876542};\\\", \\\"{x:1529,y:329,t:1526933876559};\\\", \\\"{x:1529,y:332,t:1526933876576};\\\", \\\"{x:1529,y:334,t:1526933876592};\\\", \\\"{x:1530,y:339,t:1526933876608};\\\", \\\"{x:1530,y:342,t:1526933876626};\\\", \\\"{x:1530,y:347,t:1526933876641};\\\", \\\"{x:1530,y:350,t:1526933876659};\\\", \\\"{x:1530,y:354,t:1526933876675};\\\", \\\"{x:1528,y:357,t:1526933876692};\\\", \\\"{x:1523,y:367,t:1526933876708};\\\", \\\"{x:1521,y:372,t:1526933876727};\\\", \\\"{x:1520,y:377,t:1526933876742};\\\", \\\"{x:1517,y:380,t:1526933876759};\\\", \\\"{x:1514,y:385,t:1526933876776};\\\", \\\"{x:1513,y:388,t:1526933876792};\\\", \\\"{x:1512,y:394,t:1526933876809};\\\", \\\"{x:1510,y:398,t:1526933876826};\\\", \\\"{x:1508,y:404,t:1526933876842};\\\", \\\"{x:1504,y:409,t:1526933876859};\\\", \\\"{x:1501,y:411,t:1526933876876};\\\", \\\"{x:1494,y:419,t:1526933876892};\\\", \\\"{x:1485,y:423,t:1526933876909};\\\", \\\"{x:1480,y:429,t:1526933876926};\\\", \\\"{x:1473,y:430,t:1526933876942};\\\", \\\"{x:1463,y:434,t:1526933876958};\\\", \\\"{x:1457,y:435,t:1526933876976};\\\", \\\"{x:1447,y:437,t:1526933876992};\\\", \\\"{x:1444,y:437,t:1526933877008};\\\", \\\"{x:1435,y:438,t:1526933877026};\\\", \\\"{x:1425,y:439,t:1526933877042};\\\", \\\"{x:1417,y:442,t:1526933877059};\\\", \\\"{x:1413,y:443,t:1526933877075};\\\", \\\"{x:1409,y:443,t:1526933877091};\\\", \\\"{x:1407,y:443,t:1526933877108};\\\", \\\"{x:1405,y:443,t:1526933877125};\\\", \\\"{x:1404,y:443,t:1526933877309};\\\", \\\"{x:1405,y:443,t:1526933877388};\\\", \\\"{x:1406,y:443,t:1526933877420};\\\", \\\"{x:1408,y:444,t:1526933877436};\\\", \\\"{x:1409,y:445,t:1526933877444};\\\", \\\"{x:1409,y:446,t:1526933877458};\\\", \\\"{x:1411,y:448,t:1526933877474};\\\", \\\"{x:1413,y:451,t:1526933877492};\\\", \\\"{x:1416,y:454,t:1526933877509};\\\", \\\"{x:1418,y:458,t:1526933877525};\\\", \\\"{x:1423,y:462,t:1526933877542};\\\", \\\"{x:1426,y:464,t:1526933877559};\\\", \\\"{x:1430,y:468,t:1526933877574};\\\", \\\"{x:1434,y:471,t:1526933877592};\\\", \\\"{x:1434,y:472,t:1526933877609};\\\", \\\"{x:1437,y:474,t:1526933877625};\\\", \\\"{x:1438,y:476,t:1526933877641};\\\", \\\"{x:1438,y:477,t:1526933877659};\\\", \\\"{x:1440,y:480,t:1526933877675};\\\", \\\"{x:1442,y:481,t:1526933877692};\\\", \\\"{x:1444,y:487,t:1526933877709};\\\", \\\"{x:1445,y:490,t:1526933877725};\\\", \\\"{x:1445,y:495,t:1526933877742};\\\", \\\"{x:1446,y:499,t:1526933877759};\\\", \\\"{x:1446,y:505,t:1526933877775};\\\", \\\"{x:1446,y:512,t:1526933877792};\\\", \\\"{x:1446,y:522,t:1526933877808};\\\", \\\"{x:1446,y:532,t:1526933877824};\\\", \\\"{x:1443,y:543,t:1526933877842};\\\", \\\"{x:1439,y:549,t:1526933877859};\\\", \\\"{x:1437,y:555,t:1526933877874};\\\", \\\"{x:1437,y:560,t:1526933877892};\\\", \\\"{x:1435,y:564,t:1526933877908};\\\", \\\"{x:1434,y:566,t:1526933877924};\\\", \\\"{x:1432,y:569,t:1526933877942};\\\", \\\"{x:1431,y:571,t:1526933877958};\\\", \\\"{x:1429,y:574,t:1526933877974};\\\", \\\"{x:1429,y:575,t:1526933877992};\\\", \\\"{x:1428,y:576,t:1526933878028};\\\", \\\"{x:1427,y:576,t:1526933878060};\\\", \\\"{x:1425,y:576,t:1526933878075};\\\", \\\"{x:1423,y:576,t:1526933878092};\\\", \\\"{x:1420,y:578,t:1526933878108};\\\", \\\"{x:1418,y:579,t:1526933878124};\\\", \\\"{x:1415,y:579,t:1526933878142};\\\", \\\"{x:1412,y:579,t:1526933878159};\\\", \\\"{x:1411,y:579,t:1526933878174};\\\", \\\"{x:1410,y:579,t:1526933878192};\\\", \\\"{x:1409,y:579,t:1526933878209};\\\", \\\"{x:1408,y:579,t:1526933878225};\\\", \\\"{x:1406,y:577,t:1526933878242};\\\", \\\"{x:1406,y:576,t:1526933878269};\\\", \\\"{x:1406,y:575,t:1526933878412};\\\", \\\"{x:1406,y:573,t:1526933878436};\\\", \\\"{x:1406,y:572,t:1526933878452};\\\", \\\"{x:1408,y:571,t:1526933878477};\\\", \\\"{x:1409,y:571,t:1526933878508};\\\", \\\"{x:1411,y:571,t:1526933878541};\\\", \\\"{x:1412,y:569,t:1526933878709};\\\", \\\"{x:1413,y:568,t:1526933878726};\\\", \\\"{x:1414,y:567,t:1526933878741};\\\", \\\"{x:1415,y:567,t:1526933878773};\\\", \\\"{x:1416,y:566,t:1526933878797};\\\", \\\"{x:1416,y:565,t:1526933878813};\\\", \\\"{x:1419,y:565,t:1526933879213};\\\", \\\"{x:1422,y:564,t:1526933879226};\\\", \\\"{x:1430,y:561,t:1526933879242};\\\", \\\"{x:1437,y:561,t:1526933879259};\\\", \\\"{x:1445,y:560,t:1526933879275};\\\", \\\"{x:1448,y:558,t:1526933879292};\\\", \\\"{x:1449,y:557,t:1526933879308};\\\", \\\"{x:1451,y:556,t:1526933879324};\\\", \\\"{x:1453,y:556,t:1526933879342};\\\", \\\"{x:1454,y:556,t:1526933879358};\\\", \\\"{x:1449,y:556,t:1526933879588};\\\", \\\"{x:1439,y:557,t:1526933879595};\\\", \\\"{x:1427,y:557,t:1526933879607};\\\", \\\"{x:1406,y:559,t:1526933879624};\\\", \\\"{x:1373,y:559,t:1526933879641};\\\", \\\"{x:1344,y:559,t:1526933879658};\\\", \\\"{x:1323,y:559,t:1526933879674};\\\", \\\"{x:1313,y:559,t:1526933879690};\\\", \\\"{x:1310,y:559,t:1526933879707};\\\", \\\"{x:1309,y:559,t:1526933879902};\\\", \\\"{x:1306,y:559,t:1526933879909};\\\", \\\"{x:1304,y:559,t:1526933879926};\\\", \\\"{x:1300,y:560,t:1526933879941};\\\", \\\"{x:1298,y:560,t:1526933879989};\\\", \\\"{x:1295,y:560,t:1526933880005};\\\", \\\"{x:1293,y:560,t:1526933880013};\\\", \\\"{x:1291,y:561,t:1526933880025};\\\", \\\"{x:1289,y:561,t:1526933880041};\\\", \\\"{x:1287,y:561,t:1526933880058};\\\", \\\"{x:1285,y:563,t:1526933880075};\\\", \\\"{x:1288,y:563,t:1526933880291};\\\", \\\"{x:1294,y:563,t:1526933880299};\\\", \\\"{x:1304,y:563,t:1526933880314};\\\", \\\"{x:1313,y:563,t:1526933880331};\\\", \\\"{x:1320,y:563,t:1526933880348};\\\", \\\"{x:1322,y:563,t:1526933880365};\\\", \\\"{x:1323,y:563,t:1526933880402};\\\", \\\"{x:1325,y:563,t:1526933880418};\\\", \\\"{x:1326,y:563,t:1526933880431};\\\", \\\"{x:1328,y:563,t:1526933880448};\\\", \\\"{x:1330,y:563,t:1526933880464};\\\", \\\"{x:1332,y:563,t:1526933880482};\\\", \\\"{x:1333,y:563,t:1526933880499};\\\", \\\"{x:1334,y:563,t:1526933880571};\\\", \\\"{x:1336,y:563,t:1526933880582};\\\", \\\"{x:1339,y:563,t:1526933880599};\\\", \\\"{x:1342,y:563,t:1526933880615};\\\", \\\"{x:1345,y:563,t:1526933880631};\\\", \\\"{x:1347,y:563,t:1526933880650};\\\", \\\"{x:1348,y:563,t:1526933880707};\\\", \\\"{x:1350,y:563,t:1526933880724};\\\", \\\"{x:1351,y:563,t:1526933880737};\\\", \\\"{x:1352,y:563,t:1526933880753};\\\", \\\"{x:1353,y:563,t:1526933880841};\\\", \\\"{x:1355,y:563,t:1526933880874};\\\", \\\"{x:1356,y:563,t:1526933880881};\\\", \\\"{x:1360,y:564,t:1526933880897};\\\", \\\"{x:1362,y:564,t:1526933880914};\\\", \\\"{x:1366,y:564,t:1526933880931};\\\", \\\"{x:1370,y:564,t:1526933880947};\\\", \\\"{x:1374,y:564,t:1526933880964};\\\", \\\"{x:1378,y:564,t:1526933880981};\\\", \\\"{x:1381,y:566,t:1526933880998};\\\", \\\"{x:1384,y:565,t:1526933881147};\\\", \\\"{x:1387,y:565,t:1526933881178};\\\", \\\"{x:1388,y:565,t:1526933881186};\\\", \\\"{x:1391,y:565,t:1526933881198};\\\", \\\"{x:1395,y:565,t:1526933881215};\\\", \\\"{x:1398,y:565,t:1526933881231};\\\", \\\"{x:1401,y:564,t:1526933881248};\\\", \\\"{x:1404,y:563,t:1526933881265};\\\", \\\"{x:1405,y:563,t:1526933881307};\\\", \\\"{x:1405,y:562,t:1526933881315};\\\", \\\"{x:1406,y:562,t:1526933881595};\\\", \\\"{x:1409,y:561,t:1526933881603};\\\", \\\"{x:1412,y:561,t:1526933881631};\\\", \\\"{x:1418,y:561,t:1526933881648};\\\", \\\"{x:1419,y:561,t:1526933881665};\\\", \\\"{x:1421,y:561,t:1526933881756};\\\", \\\"{x:1422,y:561,t:1526933881795};\\\", \\\"{x:1426,y:561,t:1526933881802};\\\", \\\"{x:1430,y:561,t:1526933881815};\\\", \\\"{x:1436,y:561,t:1526933881832};\\\", \\\"{x:1445,y:561,t:1526933881848};\\\", \\\"{x:1454,y:561,t:1526933881864};\\\", \\\"{x:1459,y:561,t:1526933881882};\\\", \\\"{x:1463,y:561,t:1526933881897};\\\", \\\"{x:1464,y:561,t:1526933881915};\\\", \\\"{x:1465,y:561,t:1526933882146};\\\", \\\"{x:1467,y:561,t:1526933882165};\\\", \\\"{x:1469,y:561,t:1526933882181};\\\", \\\"{x:1471,y:561,t:1526933882198};\\\", \\\"{x:1472,y:561,t:1526933882226};\\\", \\\"{x:1473,y:561,t:1526933882403};\\\", \\\"{x:1474,y:561,t:1526933882415};\\\", \\\"{x:1480,y:561,t:1526933882431};\\\", \\\"{x:1488,y:561,t:1526933882448};\\\", \\\"{x:1501,y:561,t:1526933882465};\\\", \\\"{x:1505,y:561,t:1526933882481};\\\", \\\"{x:1508,y:561,t:1526933882497};\\\", \\\"{x:1513,y:559,t:1526933882515};\\\", \\\"{x:1515,y:559,t:1526933882530};\\\", \\\"{x:1516,y:558,t:1526933882571};\\\", \\\"{x:1517,y:556,t:1526933882610};\\\", \\\"{x:1518,y:556,t:1526933882642};\\\", \\\"{x:1519,y:556,t:1526933882650};\\\", \\\"{x:1520,y:556,t:1526933882665};\\\", \\\"{x:1526,y:556,t:1526933882681};\\\", \\\"{x:1535,y:555,t:1526933882698};\\\", \\\"{x:1542,y:555,t:1526933882714};\\\", \\\"{x:1550,y:552,t:1526933882730};\\\", \\\"{x:1554,y:552,t:1526933882748};\\\", \\\"{x:1560,y:552,t:1526933882765};\\\", \\\"{x:1562,y:552,t:1526933882781};\\\", \\\"{x:1568,y:552,t:1526933882798};\\\", \\\"{x:1575,y:553,t:1526933882814};\\\", \\\"{x:1582,y:553,t:1526933882831};\\\", \\\"{x:1585,y:555,t:1526933882847};\\\", \\\"{x:1586,y:555,t:1526933882864};\\\", \\\"{x:1588,y:555,t:1526933882880};\\\", \\\"{x:1589,y:555,t:1526933882921};\\\", \\\"{x:1591,y:556,t:1526933882938};\\\", \\\"{x:1591,y:558,t:1526933882947};\\\", \\\"{x:1593,y:562,t:1526933882964};\\\", \\\"{x:1596,y:568,t:1526933882980};\\\", \\\"{x:1597,y:573,t:1526933882997};\\\", \\\"{x:1597,y:577,t:1526933883014};\\\", \\\"{x:1596,y:583,t:1526933883030};\\\", \\\"{x:1592,y:588,t:1526933883048};\\\", \\\"{x:1589,y:591,t:1526933883064};\\\", \\\"{x:1583,y:598,t:1526933883080};\\\", \\\"{x:1570,y:607,t:1526933883097};\\\", \\\"{x:1556,y:614,t:1526933883113};\\\", \\\"{x:1533,y:623,t:1526933883130};\\\", \\\"{x:1497,y:631,t:1526933883148};\\\", \\\"{x:1427,y:634,t:1526933883165};\\\", \\\"{x:1318,y:638,t:1526933883180};\\\", \\\"{x:1160,y:640,t:1526933883198};\\\", \\\"{x:985,y:637,t:1526933883214};\\\", \\\"{x:791,y:628,t:1526933883230};\\\", \\\"{x:625,y:623,t:1526933883247};\\\", \\\"{x:486,y:619,t:1526933883264};\\\", \\\"{x:382,y:622,t:1526933883278};\\\", \\\"{x:302,y:622,t:1526933883296};\\\", \\\"{x:247,y:634,t:1526933883312};\\\", \\\"{x:222,y:656,t:1526933883330};\\\", \\\"{x:221,y:666,t:1526933883346};\\\", \\\"{x:221,y:678,t:1526933883362};\\\", \\\"{x:223,y:691,t:1526933883380};\\\", \\\"{x:228,y:704,t:1526933883396};\\\", \\\"{x:231,y:714,t:1526933883412};\\\", \\\"{x:233,y:728,t:1526933883429};\\\", \\\"{x:235,y:745,t:1526933883446};\\\", \\\"{x:240,y:758,t:1526933883463};\\\", \\\"{x:249,y:778,t:1526933883479};\\\", \\\"{x:262,y:792,t:1526933883496};\\\", \\\"{x:282,y:810,t:1526933883513};\\\", \\\"{x:292,y:815,t:1526933883529};\\\", \\\"{x:314,y:823,t:1526933883546};\\\", \\\"{x:337,y:830,t:1526933883564};\\\", \\\"{x:378,y:835,t:1526933883580};\\\", \\\"{x:405,y:836,t:1526933883597};\\\", \\\"{x:425,y:836,t:1526933883613};\\\", \\\"{x:454,y:835,t:1526933883630};\\\", \\\"{x:486,y:834,t:1526933883646};\\\", \\\"{x:511,y:834,t:1526933883663};\\\", \\\"{x:530,y:832,t:1526933883680};\\\", \\\"{x:543,y:832,t:1526933883696};\\\", \\\"{x:552,y:829,t:1526933883714};\\\", \\\"{x:554,y:827,t:1526933883730};\\\", \\\"{x:560,y:822,t:1526933883746};\\\", \\\"{x:566,y:816,t:1526933883763};\\\", \\\"{x:570,y:807,t:1526933883780};\\\", \\\"{x:573,y:800,t:1526933883798};\\\", \\\"{x:573,y:792,t:1526933883813};\\\", \\\"{x:573,y:784,t:1526933883830};\\\", \\\"{x:573,y:777,t:1526933883848};\\\", \\\"{x:573,y:771,t:1526933883864};\\\", \\\"{x:573,y:768,t:1526933883880};\\\", \\\"{x:573,y:764,t:1526933883898};\\\", \\\"{x:573,y:763,t:1526933883913};\\\", \\\"{x:573,y:761,t:1526933883931};\\\", \\\"{x:573,y:760,t:1526933883947};\\\", \\\"{x:573,y:759,t:1526933883978};\\\", \\\"{x:573,y:758,t:1526933883985};\\\", \\\"{x:573,y:756,t:1526933883997};\\\", \\\"{x:573,y:754,t:1526933884014};\\\", \\\"{x:573,y:753,t:1526933884031};\\\", \\\"{x:573,y:752,t:1526933884047};\\\", \\\"{x:572,y:751,t:1526933884065};\\\", \\\"{x:571,y:750,t:1526933884081};\\\", \\\"{x:571,y:749,t:1526933884097};\\\", \\\"{x:570,y:749,t:1526933884114};\\\", \\\"{x:568,y:747,t:1526933884131};\\\", \\\"{x:566,y:745,t:1526933884148};\\\", \\\"{x:564,y:745,t:1526933884165};\\\", \\\"{x:563,y:745,t:1526933884186};\\\", \\\"{x:561,y:743,t:1526933884195};\\\", \\\"{x:558,y:743,t:1526933884212};\\\", \\\"{x:555,y:742,t:1526933884228};\\\", \\\"{x:553,y:742,t:1526933884245};\\\", \\\"{x:551,y:741,t:1526933884263};\\\", \\\"{x:550,y:741,t:1526933884279};\\\", \\\"{x:549,y:740,t:1526933884296};\\\" ] }, { \\\"rt\\\": 66370, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 791649, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -B -B -B -B -F -E -G -6-F -F -F -F -A -M -J -B -I -B -B -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:740,t:1526933886505};\\\", \\\"{x:540,y:729,t:1526933886514};\\\", \\\"{x:520,y:707,t:1526933886532};\\\", \\\"{x:507,y:694,t:1526933886548};\\\", \\\"{x:495,y:682,t:1526933886566};\\\", \\\"{x:483,y:673,t:1526933886582};\\\", \\\"{x:471,y:665,t:1526933886598};\\\", \\\"{x:456,y:657,t:1526933886615};\\\", \\\"{x:451,y:655,t:1526933886631};\\\", \\\"{x:449,y:654,t:1526933886648};\\\", \\\"{x:448,y:654,t:1526933886666};\\\", \\\"{x:449,y:654,t:1526933886970};\\\", \\\"{x:457,y:656,t:1526933886982};\\\", \\\"{x:485,y:669,t:1526933886999};\\\", \\\"{x:533,y:684,t:1526933887017};\\\", \\\"{x:629,y:706,t:1526933887033};\\\", \\\"{x:710,y:726,t:1526933887049};\\\", \\\"{x:711,y:726,t:1526933887722};\\\", \\\"{x:718,y:726,t:1526933891082};\\\", \\\"{x:730,y:725,t:1526933891090};\\\", \\\"{x:752,y:719,t:1526933891103};\\\", \\\"{x:825,y:718,t:1526933891121};\\\", \\\"{x:987,y:725,t:1526933891138};\\\", \\\"{x:1105,y:733,t:1526933891155};\\\", \\\"{x:1226,y:747,t:1526933891171};\\\", \\\"{x:1347,y:755,t:1526933891188};\\\", \\\"{x:1462,y:766,t:1526933891206};\\\", \\\"{x:1556,y:775,t:1526933891220};\\\", \\\"{x:1607,y:785,t:1526933891238};\\\", \\\"{x:1622,y:788,t:1526933891255};\\\", \\\"{x:1640,y:790,t:1526933891271};\\\", \\\"{x:1650,y:792,t:1526933891288};\\\", \\\"{x:1652,y:793,t:1526933891304};\\\", \\\"{x:1653,y:794,t:1526933891338};\\\", \\\"{x:1653,y:796,t:1526933891355};\\\", \\\"{x:1653,y:805,t:1526933891371};\\\", \\\"{x:1651,y:815,t:1526933891388};\\\", \\\"{x:1650,y:824,t:1526933891406};\\\", \\\"{x:1648,y:832,t:1526933891422};\\\", \\\"{x:1646,y:837,t:1526933891438};\\\", \\\"{x:1642,y:842,t:1526933891456};\\\", \\\"{x:1639,y:846,t:1526933891473};\\\", \\\"{x:1634,y:852,t:1526933891488};\\\", \\\"{x:1626,y:858,t:1526933891506};\\\", \\\"{x:1606,y:865,t:1526933891522};\\\", \\\"{x:1586,y:870,t:1526933891538};\\\", \\\"{x:1568,y:870,t:1526933891555};\\\", \\\"{x:1554,y:870,t:1526933891572};\\\", \\\"{x:1538,y:870,t:1526933891588};\\\", \\\"{x:1525,y:870,t:1526933891605};\\\", \\\"{x:1510,y:869,t:1526933891622};\\\", \\\"{x:1496,y:868,t:1526933891638};\\\", \\\"{x:1487,y:865,t:1526933891655};\\\", \\\"{x:1483,y:865,t:1526933891673};\\\", \\\"{x:1481,y:865,t:1526933891688};\\\", \\\"{x:1481,y:863,t:1526933892090};\\\", \\\"{x:1481,y:857,t:1526933892106};\\\", \\\"{x:1481,y:854,t:1526933892123};\\\", \\\"{x:1481,y:852,t:1526933892139};\\\", \\\"{x:1481,y:851,t:1526933892157};\\\", \\\"{x:1481,y:849,t:1526933892178};\\\", \\\"{x:1481,y:848,t:1526933892189};\\\", \\\"{x:1481,y:846,t:1526933892207};\\\", \\\"{x:1481,y:844,t:1526933892222};\\\", \\\"{x:1481,y:843,t:1526933892242};\\\", \\\"{x:1481,y:842,t:1526933892256};\\\", \\\"{x:1482,y:841,t:1526933892273};\\\", \\\"{x:1483,y:839,t:1526933892323};\\\", \\\"{x:1484,y:837,t:1526933892371};\\\", \\\"{x:1484,y:836,t:1526933892395};\\\", \\\"{x:1484,y:835,t:1526933892435};\\\", \\\"{x:1484,y:834,t:1526933892461};\\\", \\\"{x:1475,y:832,t:1526933899004};\\\", \\\"{x:1457,y:828,t:1526933899014};\\\", \\\"{x:1415,y:815,t:1526933899030};\\\", \\\"{x:1374,y:806,t:1526933899047};\\\", \\\"{x:1355,y:795,t:1526933899064};\\\", \\\"{x:1329,y:781,t:1526933899081};\\\", \\\"{x:1309,y:773,t:1526933899097};\\\", \\\"{x:1298,y:765,t:1526933899114};\\\", \\\"{x:1295,y:763,t:1526933899131};\\\", \\\"{x:1293,y:761,t:1526933899148};\\\", \\\"{x:1291,y:757,t:1526933899165};\\\", \\\"{x:1289,y:752,t:1526933899181};\\\", \\\"{x:1287,y:750,t:1526933899197};\\\", \\\"{x:1287,y:749,t:1526933899214};\\\", \\\"{x:1287,y:748,t:1526933899234};\\\", \\\"{x:1287,y:747,t:1526933899266};\\\", \\\"{x:1287,y:746,t:1526933899281};\\\", \\\"{x:1287,y:745,t:1526933899298};\\\", \\\"{x:1296,y:744,t:1526933899315};\\\", \\\"{x:1302,y:744,t:1526933899331};\\\", \\\"{x:1305,y:744,t:1526933899348};\\\", \\\"{x:1311,y:744,t:1526933899365};\\\", \\\"{x:1316,y:744,t:1526933899381};\\\", \\\"{x:1319,y:744,t:1526933899397};\\\", \\\"{x:1320,y:744,t:1526933899418};\\\", \\\"{x:1324,y:744,t:1526933899434};\\\", \\\"{x:1326,y:744,t:1526933899449};\\\", \\\"{x:1330,y:744,t:1526933899465};\\\", \\\"{x:1333,y:744,t:1526933899482};\\\", \\\"{x:1337,y:745,t:1526933899498};\\\", \\\"{x:1338,y:745,t:1526933899514};\\\", \\\"{x:1340,y:746,t:1526933899545};\\\", \\\"{x:1341,y:748,t:1526933899561};\\\", \\\"{x:1341,y:749,t:1526933899569};\\\", \\\"{x:1342,y:750,t:1526933899581};\\\", \\\"{x:1343,y:752,t:1526933899598};\\\", \\\"{x:1344,y:753,t:1526933899615};\\\", \\\"{x:1344,y:754,t:1526933899630};\\\", \\\"{x:1344,y:756,t:1526933899647};\\\", \\\"{x:1344,y:758,t:1526933899665};\\\", \\\"{x:1344,y:759,t:1526933899681};\\\", \\\"{x:1344,y:764,t:1526933899698};\\\", \\\"{x:1344,y:766,t:1526933899715};\\\", \\\"{x:1345,y:768,t:1526933899731};\\\", \\\"{x:1346,y:769,t:1526933899748};\\\", \\\"{x:1346,y:770,t:1526933899765};\\\", \\\"{x:1347,y:770,t:1526933899929};\\\", \\\"{x:1347,y:768,t:1526933899945};\\\", \\\"{x:1350,y:767,t:1526933899965};\\\", \\\"{x:1350,y:766,t:1526933899982};\\\", \\\"{x:1351,y:766,t:1526933899998};\\\", \\\"{x:1351,y:765,t:1526933900015};\\\", \\\"{x:1352,y:764,t:1526933900032};\\\", \\\"{x:1352,y:763,t:1526933900129};\\\", \\\"{x:1352,y:762,t:1526933900274};\\\", \\\"{x:1351,y:762,t:1526933900290};\\\", \\\"{x:1350,y:759,t:1526933907250};\\\", \\\"{x:1349,y:752,t:1526933907258};\\\", \\\"{x:1344,y:731,t:1526933907274};\\\", \\\"{x:1343,y:709,t:1526933907291};\\\", \\\"{x:1343,y:691,t:1526933907308};\\\", \\\"{x:1340,y:674,t:1526933907323};\\\", \\\"{x:1337,y:665,t:1526933907341};\\\", \\\"{x:1336,y:656,t:1526933907357};\\\", \\\"{x:1333,y:645,t:1526933907375};\\\", \\\"{x:1330,y:633,t:1526933907391};\\\", \\\"{x:1329,y:624,t:1526933907408};\\\", \\\"{x:1326,y:618,t:1526933907424};\\\", \\\"{x:1324,y:614,t:1526933907440};\\\", \\\"{x:1317,y:608,t:1526933907457};\\\", \\\"{x:1309,y:602,t:1526933907475};\\\", \\\"{x:1305,y:599,t:1526933907491};\\\", \\\"{x:1301,y:596,t:1526933907508};\\\", \\\"{x:1298,y:592,t:1526933907525};\\\", \\\"{x:1296,y:588,t:1526933907541};\\\", \\\"{x:1294,y:584,t:1526933907558};\\\", \\\"{x:1291,y:580,t:1526933907574};\\\", \\\"{x:1286,y:574,t:1526933907591};\\\", \\\"{x:1283,y:571,t:1526933907608};\\\", \\\"{x:1281,y:568,t:1526933907625};\\\", \\\"{x:1281,y:565,t:1526933907642};\\\", \\\"{x:1281,y:564,t:1526933907673};\\\", \\\"{x:1279,y:563,t:1526933907690};\\\", \\\"{x:1279,y:562,t:1526933907714};\\\", \\\"{x:1279,y:561,t:1526933907762};\\\", \\\"{x:1280,y:561,t:1526933907970};\\\", \\\"{x:1281,y:561,t:1526933908170};\\\", \\\"{x:1282,y:561,t:1526933908274};\\\", \\\"{x:1284,y:561,t:1526933908290};\\\", \\\"{x:1286,y:561,t:1526933908297};\\\", \\\"{x:1287,y:561,t:1526933908310};\\\", \\\"{x:1292,y:561,t:1526933908326};\\\", \\\"{x:1300,y:562,t:1526933908342};\\\", \\\"{x:1304,y:563,t:1526933908359};\\\", \\\"{x:1308,y:564,t:1526933908377};\\\", \\\"{x:1310,y:564,t:1526933908392};\\\", \\\"{x:1311,y:566,t:1526933908409};\\\", \\\"{x:1315,y:566,t:1526933908426};\\\", \\\"{x:1318,y:566,t:1526933908442};\\\", \\\"{x:1325,y:566,t:1526933908459};\\\", \\\"{x:1328,y:568,t:1526933908476};\\\", \\\"{x:1334,y:569,t:1526933908493};\\\", \\\"{x:1339,y:570,t:1526933908509};\\\", \\\"{x:1341,y:570,t:1526933908526};\\\", \\\"{x:1344,y:570,t:1526933908543};\\\", \\\"{x:1346,y:570,t:1526933908559};\\\", \\\"{x:1347,y:570,t:1526933908576};\\\", \\\"{x:1350,y:570,t:1526933908593};\\\", \\\"{x:1352,y:570,t:1526933908609};\\\", \\\"{x:1353,y:570,t:1526933908626};\\\", \\\"{x:1354,y:570,t:1526933908754};\\\", \\\"{x:1353,y:570,t:1526933909042};\\\", \\\"{x:1352,y:569,t:1526933909060};\\\", \\\"{x:1351,y:568,t:1526933909077};\\\", \\\"{x:1350,y:568,t:1526933909093};\\\", \\\"{x:1350,y:567,t:1526933909110};\\\", \\\"{x:1349,y:567,t:1526933909138};\\\", \\\"{x:1350,y:567,t:1526933909586};\\\", \\\"{x:1355,y:567,t:1526933909594};\\\", \\\"{x:1362,y:567,t:1526933909610};\\\", \\\"{x:1365,y:567,t:1526933909627};\\\", \\\"{x:1367,y:568,t:1526933909643};\\\", \\\"{x:1368,y:568,t:1526933909660};\\\", \\\"{x:1369,y:568,t:1526933909729};\\\", \\\"{x:1371,y:568,t:1526933909753};\\\", \\\"{x:1372,y:568,t:1526933909770};\\\", \\\"{x:1374,y:568,t:1526933909777};\\\", \\\"{x:1375,y:568,t:1526933909794};\\\", \\\"{x:1376,y:568,t:1526933909810};\\\", \\\"{x:1377,y:568,t:1526933909827};\\\", \\\"{x:1380,y:568,t:1526933909844};\\\", \\\"{x:1381,y:568,t:1526933909866};\\\", \\\"{x:1382,y:568,t:1526933909877};\\\", \\\"{x:1383,y:568,t:1526933909894};\\\", \\\"{x:1385,y:568,t:1526933909911};\\\", \\\"{x:1386,y:568,t:1526933909928};\\\", \\\"{x:1387,y:568,t:1526933909944};\\\", \\\"{x:1390,y:568,t:1526933909961};\\\", \\\"{x:1392,y:568,t:1526933909977};\\\", \\\"{x:1393,y:568,t:1526933909994};\\\", \\\"{x:1395,y:568,t:1526933910010};\\\", \\\"{x:1396,y:568,t:1526933910028};\\\", \\\"{x:1397,y:568,t:1526933910049};\\\", \\\"{x:1398,y:567,t:1526933910074};\\\", \\\"{x:1399,y:567,t:1526933910081};\\\", \\\"{x:1400,y:567,t:1526933910098};\\\", \\\"{x:1401,y:567,t:1526933910111};\\\", \\\"{x:1403,y:566,t:1526933910128};\\\", \\\"{x:1404,y:566,t:1526933910144};\\\", \\\"{x:1406,y:566,t:1526933910161};\\\", \\\"{x:1410,y:566,t:1526933910179};\\\", \\\"{x:1413,y:564,t:1526933910195};\\\", \\\"{x:1414,y:564,t:1526933910211};\\\", \\\"{x:1416,y:564,t:1526933910234};\\\", \\\"{x:1417,y:564,t:1526933910674};\\\", \\\"{x:1418,y:564,t:1526933910682};\\\", \\\"{x:1419,y:564,t:1526933910695};\\\", \\\"{x:1421,y:564,t:1526933910714};\\\", \\\"{x:1423,y:564,t:1526933910730};\\\", \\\"{x:1425,y:564,t:1526933910754};\\\", \\\"{x:1426,y:564,t:1526933910762};\\\", \\\"{x:1428,y:564,t:1526933910779};\\\", \\\"{x:1431,y:564,t:1526933910802};\\\", \\\"{x:1432,y:564,t:1526933910818};\\\", \\\"{x:1435,y:564,t:1526933910829};\\\", \\\"{x:1438,y:564,t:1526933910845};\\\", \\\"{x:1442,y:564,t:1526933910862};\\\", \\\"{x:1444,y:564,t:1526933910879};\\\", \\\"{x:1445,y:564,t:1526933910898};\\\", \\\"{x:1446,y:564,t:1526933910912};\\\", \\\"{x:1450,y:564,t:1526933910929};\\\", \\\"{x:1456,y:564,t:1526933910945};\\\", \\\"{x:1466,y:564,t:1526933910961};\\\", \\\"{x:1468,y:564,t:1526933910978};\\\", \\\"{x:1471,y:564,t:1526933910995};\\\", \\\"{x:1473,y:564,t:1526933911012};\\\", \\\"{x:1475,y:564,t:1526933911028};\\\", \\\"{x:1477,y:564,t:1526933911046};\\\", \\\"{x:1478,y:564,t:1526933911062};\\\", \\\"{x:1481,y:564,t:1526933911079};\\\", \\\"{x:1482,y:564,t:1526933911095};\\\", \\\"{x:1483,y:564,t:1526933911112};\\\", \\\"{x:1480,y:564,t:1526933915498};\\\", \\\"{x:1469,y:564,t:1526933915506};\\\", \\\"{x:1458,y:564,t:1526933915517};\\\", \\\"{x:1399,y:563,t:1526933915535};\\\", \\\"{x:1309,y:559,t:1526933915552};\\\", \\\"{x:1211,y:551,t:1526933915568};\\\", \\\"{x:1091,y:533,t:1526933915585};\\\", \\\"{x:976,y:521,t:1526933915602};\\\", \\\"{x:762,y:497,t:1526933915618};\\\", \\\"{x:629,y:478,t:1526933915634};\\\", \\\"{x:527,y:466,t:1526933915651};\\\", \\\"{x:439,y:457,t:1526933915668};\\\", \\\"{x:380,y:451,t:1526933915684};\\\", \\\"{x:370,y:450,t:1526933915701};\\\", \\\"{x:366,y:450,t:1526933915718};\\\", \\\"{x:365,y:451,t:1526933915800};\\\", \\\"{x:362,y:454,t:1526933915817};\\\", \\\"{x:362,y:459,t:1526933915834};\\\", \\\"{x:362,y:462,t:1526933915850};\\\", \\\"{x:362,y:464,t:1526933915868};\\\", \\\"{x:362,y:468,t:1526933915885};\\\", \\\"{x:363,y:472,t:1526933915901};\\\", \\\"{x:365,y:480,t:1526933915917};\\\", \\\"{x:373,y:493,t:1526933915935};\\\", \\\"{x:379,y:505,t:1526933915951};\\\", \\\"{x:385,y:512,t:1526933915968};\\\", \\\"{x:394,y:520,t:1526933915985};\\\", \\\"{x:396,y:521,t:1526933916005};\\\", \\\"{x:397,y:522,t:1526933916041};\\\", \\\"{x:401,y:524,t:1526933916056};\\\", \\\"{x:415,y:527,t:1526933916072};\\\", \\\"{x:436,y:533,t:1526933916089};\\\", \\\"{x:462,y:536,t:1526933916106};\\\", \\\"{x:485,y:540,t:1526933916123};\\\", \\\"{x:515,y:545,t:1526933916140};\\\", \\\"{x:538,y:547,t:1526933916156};\\\", \\\"{x:557,y:550,t:1526933916173};\\\", \\\"{x:576,y:550,t:1526933916189};\\\", \\\"{x:585,y:550,t:1526933916206};\\\", \\\"{x:590,y:550,t:1526933916223};\\\", \\\"{x:591,y:549,t:1526933916240};\\\", \\\"{x:593,y:549,t:1526933916257};\\\", \\\"{x:595,y:548,t:1526933916274};\\\", \\\"{x:597,y:546,t:1526933916291};\\\", \\\"{x:599,y:544,t:1526933916306};\\\", \\\"{x:602,y:542,t:1526933916324};\\\", \\\"{x:603,y:540,t:1526933916341};\\\", \\\"{x:605,y:538,t:1526933916358};\\\", \\\"{x:607,y:536,t:1526933916374};\\\", \\\"{x:608,y:533,t:1526933916434};\\\", \\\"{x:608,y:531,t:1526933916466};\\\", \\\"{x:608,y:530,t:1526933916473};\\\", \\\"{x:608,y:529,t:1526933916490};\\\", \\\"{x:609,y:527,t:1526933916507};\\\", \\\"{x:609,y:526,t:1526933916524};\\\", \\\"{x:609,y:525,t:1526933916540};\\\", \\\"{x:610,y:523,t:1526933916557};\\\", \\\"{x:611,y:522,t:1526933916574};\\\", \\\"{x:611,y:521,t:1526933916594};\\\", \\\"{x:613,y:520,t:1526933917706};\\\", \\\"{x:619,y:517,t:1526933917713};\\\", \\\"{x:626,y:515,t:1526933917726};\\\", \\\"{x:652,y:514,t:1526933917742};\\\", \\\"{x:676,y:514,t:1526933917757};\\\", \\\"{x:713,y:514,t:1526933917773};\\\", \\\"{x:779,y:514,t:1526933917791};\\\", \\\"{x:873,y:523,t:1526933917807};\\\", \\\"{x:984,y:533,t:1526933917826};\\\", \\\"{x:1063,y:548,t:1526933917841};\\\", \\\"{x:1119,y:554,t:1526933917858};\\\", \\\"{x:1148,y:560,t:1526933917875};\\\", \\\"{x:1169,y:563,t:1526933917891};\\\", \\\"{x:1183,y:566,t:1526933917908};\\\", \\\"{x:1194,y:566,t:1526933917925};\\\", \\\"{x:1197,y:566,t:1526933917941};\\\", \\\"{x:1199,y:566,t:1526933917958};\\\", \\\"{x:1203,y:566,t:1526933917975};\\\", \\\"{x:1210,y:566,t:1526933917991};\\\", \\\"{x:1223,y:566,t:1526933918008};\\\", \\\"{x:1250,y:566,t:1526933918025};\\\", \\\"{x:1280,y:569,t:1526933918042};\\\", \\\"{x:1298,y:573,t:1526933918058};\\\", \\\"{x:1347,y:587,t:1526933918075};\\\", \\\"{x:1403,y:595,t:1526933918091};\\\", \\\"{x:1433,y:602,t:1526933918108};\\\", \\\"{x:1457,y:607,t:1526933918125};\\\", \\\"{x:1478,y:609,t:1526933918140};\\\", \\\"{x:1493,y:612,t:1526933918158};\\\", \\\"{x:1494,y:612,t:1526933918175};\\\", \\\"{x:1496,y:612,t:1526933918192};\\\", \\\"{x:1496,y:611,t:1526933918299};\\\", \\\"{x:1494,y:611,t:1526933918309};\\\", \\\"{x:1487,y:608,t:1526933918326};\\\", \\\"{x:1478,y:606,t:1526933918343};\\\", \\\"{x:1475,y:605,t:1526933918358};\\\", \\\"{x:1471,y:603,t:1526933918376};\\\", \\\"{x:1469,y:602,t:1526933918393};\\\", \\\"{x:1466,y:602,t:1526933918408};\\\", \\\"{x:1463,y:601,t:1526933918425};\\\", \\\"{x:1463,y:600,t:1526933918538};\\\", \\\"{x:1463,y:599,t:1526933918546};\\\", \\\"{x:1466,y:597,t:1526933918559};\\\", \\\"{x:1469,y:596,t:1526933918576};\\\", \\\"{x:1471,y:595,t:1526933918593};\\\", \\\"{x:1473,y:593,t:1526933918609};\\\", \\\"{x:1475,y:593,t:1526933918625};\\\", \\\"{x:1476,y:592,t:1526933918643};\\\", \\\"{x:1477,y:591,t:1526933918659};\\\", \\\"{x:1479,y:589,t:1526933918676};\\\", \\\"{x:1479,y:588,t:1526933918692};\\\", \\\"{x:1480,y:587,t:1526933918710};\\\", \\\"{x:1480,y:586,t:1526933918725};\\\", \\\"{x:1481,y:584,t:1526933918746};\\\", \\\"{x:1482,y:584,t:1526933918759};\\\", \\\"{x:1482,y:582,t:1526933918775};\\\", \\\"{x:1483,y:581,t:1526933918792};\\\", \\\"{x:1483,y:579,t:1526933918808};\\\", \\\"{x:1484,y:578,t:1526933918825};\\\", \\\"{x:1485,y:578,t:1526933918842};\\\", \\\"{x:1485,y:577,t:1526933918859};\\\", \\\"{x:1485,y:576,t:1526933918874};\\\", \\\"{x:1485,y:575,t:1526933918930};\\\", \\\"{x:1485,y:574,t:1526933918945};\\\", \\\"{x:1485,y:572,t:1526933919050};\\\", \\\"{x:1485,y:571,t:1526933919106};\\\", \\\"{x:1484,y:570,t:1526933919129};\\\", \\\"{x:1484,y:569,t:1526933919162};\\\", \\\"{x:1483,y:569,t:1526933919635};\\\", \\\"{x:1482,y:569,t:1526933919644};\\\", \\\"{x:1480,y:569,t:1526933919730};\\\", \\\"{x:1479,y:569,t:1526933919743};\\\", \\\"{x:1478,y:569,t:1526933919759};\\\", \\\"{x:1477,y:569,t:1526933919777};\\\", \\\"{x:1476,y:569,t:1526933919794};\\\", \\\"{x:1475,y:569,t:1526933919810};\\\", \\\"{x:1473,y:569,t:1526933919827};\\\", \\\"{x:1471,y:569,t:1526933919843};\\\", \\\"{x:1469,y:569,t:1526933919860};\\\", \\\"{x:1467,y:569,t:1526933919876};\\\", \\\"{x:1466,y:569,t:1526933919893};\\\", \\\"{x:1464,y:569,t:1526933919910};\\\", \\\"{x:1463,y:569,t:1526933919926};\\\", \\\"{x:1461,y:569,t:1526933919944};\\\", \\\"{x:1460,y:569,t:1526933919960};\\\", \\\"{x:1459,y:569,t:1526933919978};\\\", \\\"{x:1457,y:569,t:1526933919994};\\\", \\\"{x:1455,y:569,t:1526933920009};\\\", \\\"{x:1454,y:569,t:1526933920034};\\\", \\\"{x:1452,y:569,t:1526933920058};\\\", \\\"{x:1450,y:569,t:1526933920073};\\\", \\\"{x:1449,y:570,t:1526933920139};\\\", \\\"{x:1448,y:571,t:1526933920161};\\\", \\\"{x:1447,y:571,t:1526933920176};\\\", \\\"{x:1445,y:571,t:1526933920193};\\\", \\\"{x:1442,y:572,t:1526933920210};\\\", \\\"{x:1440,y:573,t:1526933920225};\\\", \\\"{x:1435,y:574,t:1526933920243};\\\", \\\"{x:1427,y:577,t:1526933920260};\\\", \\\"{x:1421,y:578,t:1526933920276};\\\", \\\"{x:1413,y:583,t:1526933920293};\\\", \\\"{x:1398,y:589,t:1526933920310};\\\", \\\"{x:1383,y:598,t:1526933920326};\\\", \\\"{x:1374,y:602,t:1526933920343};\\\", \\\"{x:1367,y:607,t:1526933920360};\\\", \\\"{x:1364,y:609,t:1526933920376};\\\", \\\"{x:1359,y:617,t:1526933920392};\\\", \\\"{x:1355,y:624,t:1526933920410};\\\", \\\"{x:1350,y:632,t:1526933920426};\\\", \\\"{x:1347,y:638,t:1526933920443};\\\", \\\"{x:1344,y:643,t:1526933920460};\\\", \\\"{x:1342,y:647,t:1526933920476};\\\", \\\"{x:1342,y:649,t:1526933920493};\\\", \\\"{x:1341,y:653,t:1526933920510};\\\", \\\"{x:1340,y:656,t:1526933920526};\\\", \\\"{x:1338,y:660,t:1526933920543};\\\", \\\"{x:1338,y:662,t:1526933920560};\\\", \\\"{x:1338,y:664,t:1526933920576};\\\", \\\"{x:1336,y:668,t:1526933920594};\\\", \\\"{x:1336,y:669,t:1526933920610};\\\", \\\"{x:1336,y:671,t:1526933920626};\\\", \\\"{x:1335,y:673,t:1526933920644};\\\", \\\"{x:1335,y:674,t:1526933920666};\\\", \\\"{x:1335,y:676,t:1526933920681};\\\", \\\"{x:1334,y:677,t:1526933920697};\\\", \\\"{x:1333,y:678,t:1526933920711};\\\", \\\"{x:1333,y:679,t:1526933920730};\\\", \\\"{x:1333,y:680,t:1526933920754};\\\", \\\"{x:1333,y:683,t:1526933920770};\\\", \\\"{x:1333,y:684,t:1526933920826};\\\", \\\"{x:1333,y:686,t:1526933920844};\\\", \\\"{x:1334,y:688,t:1526933920874};\\\", \\\"{x:1335,y:690,t:1526933920923};\\\", \\\"{x:1337,y:690,t:1526933920946};\\\", \\\"{x:1337,y:691,t:1526933920962};\\\", \\\"{x:1339,y:691,t:1526933920977};\\\", \\\"{x:1340,y:691,t:1526933920993};\\\", \\\"{x:1342,y:691,t:1526933921049};\\\", \\\"{x:1343,y:692,t:1526933921065};\\\", \\\"{x:1343,y:693,t:1526933921077};\\\", \\\"{x:1345,y:693,t:1526933921094};\\\", \\\"{x:1346,y:693,t:1526933921110};\\\", \\\"{x:1347,y:693,t:1526933921127};\\\", \\\"{x:1348,y:693,t:1526933921144};\\\", \\\"{x:1349,y:693,t:1526933921177};\\\", \\\"{x:1350,y:693,t:1526933921210};\\\", \\\"{x:1352,y:694,t:1526933921233};\\\", \\\"{x:1356,y:694,t:1526933921859};\\\", \\\"{x:1361,y:694,t:1526933921866};\\\", \\\"{x:1367,y:694,t:1526933921878};\\\", \\\"{x:1379,y:694,t:1526933921895};\\\", \\\"{x:1394,y:694,t:1526933921912};\\\", \\\"{x:1406,y:697,t:1526933921928};\\\", \\\"{x:1408,y:697,t:1526933921944};\\\", \\\"{x:1411,y:697,t:1526933921962};\\\", \\\"{x:1413,y:697,t:1526933922002};\\\", \\\"{x:1414,y:697,t:1526933922370};\\\", \\\"{x:1420,y:697,t:1526933922378};\\\", \\\"{x:1431,y:696,t:1526933922395};\\\", \\\"{x:1444,y:696,t:1526933922412};\\\", \\\"{x:1457,y:696,t:1526933922428};\\\", \\\"{x:1466,y:696,t:1526933922445};\\\", \\\"{x:1470,y:696,t:1526933922462};\\\", \\\"{x:1474,y:696,t:1526933922479};\\\", \\\"{x:1477,y:696,t:1526933922496};\\\", \\\"{x:1478,y:696,t:1526933922511};\\\", \\\"{x:1480,y:696,t:1526933922528};\\\", \\\"{x:1484,y:696,t:1526933922546};\\\", \\\"{x:1483,y:696,t:1526933924402};\\\", \\\"{x:1476,y:696,t:1526933924413};\\\", \\\"{x:1458,y:697,t:1526933924430};\\\", \\\"{x:1445,y:697,t:1526933924447};\\\", \\\"{x:1430,y:698,t:1526933924463};\\\", \\\"{x:1422,y:698,t:1526933924480};\\\", \\\"{x:1414,y:698,t:1526933924497};\\\", \\\"{x:1408,y:698,t:1526933924517};\\\", \\\"{x:1405,y:698,t:1526933924529};\\\", \\\"{x:1399,y:699,t:1526933924546};\\\", \\\"{x:1391,y:699,t:1526933924563};\\\", \\\"{x:1381,y:699,t:1526933924579};\\\", \\\"{x:1377,y:699,t:1526933924596};\\\", \\\"{x:1373,y:699,t:1526933924613};\\\", \\\"{x:1371,y:699,t:1526933924629};\\\", \\\"{x:1370,y:700,t:1526933924649};\\\", \\\"{x:1374,y:700,t:1526933924882};\\\", \\\"{x:1381,y:700,t:1526933924897};\\\", \\\"{x:1392,y:702,t:1526933924914};\\\", \\\"{x:1400,y:703,t:1526933924930};\\\", \\\"{x:1404,y:703,t:1526933924947};\\\", \\\"{x:1405,y:703,t:1526933924967};\\\", \\\"{x:1405,y:702,t:1526933925170};\\\", \\\"{x:1405,y:700,t:1526933925194};\\\", \\\"{x:1405,y:699,t:1526933925202};\\\", \\\"{x:1404,y:699,t:1526933925214};\\\", \\\"{x:1393,y:699,t:1526933925230};\\\", \\\"{x:1382,y:698,t:1526933925247};\\\", \\\"{x:1370,y:696,t:1526933925265};\\\", \\\"{x:1354,y:693,t:1526933925281};\\\", \\\"{x:1346,y:687,t:1526933925297};\\\", \\\"{x:1338,y:685,t:1526933925314};\\\", \\\"{x:1331,y:685,t:1526933925331};\\\", \\\"{x:1330,y:684,t:1526933925347};\\\", \\\"{x:1329,y:684,t:1526933925366};\\\", \\\"{x:1329,y:683,t:1526933925409};\\\", \\\"{x:1329,y:682,t:1526933925418};\\\", \\\"{x:1330,y:682,t:1526933925458};\\\", \\\"{x:1331,y:682,t:1526933925546};\\\", \\\"{x:1332,y:682,t:1526933925578};\\\", \\\"{x:1333,y:682,t:1526933925634};\\\", \\\"{x:1336,y:682,t:1526933925674};\\\", \\\"{x:1339,y:682,t:1526933925706};\\\", \\\"{x:1341,y:682,t:1526933925738};\\\", \\\"{x:1343,y:682,t:1526933925748};\\\", \\\"{x:1346,y:682,t:1526933925764};\\\", \\\"{x:1349,y:682,t:1526933925780};\\\", \\\"{x:1353,y:682,t:1526933925798};\\\", \\\"{x:1360,y:684,t:1526933925814};\\\", \\\"{x:1365,y:685,t:1526933925831};\\\", \\\"{x:1373,y:686,t:1526933925847};\\\", \\\"{x:1377,y:687,t:1526933925865};\\\", \\\"{x:1382,y:689,t:1526933925881};\\\", \\\"{x:1387,y:690,t:1526933925898};\\\", \\\"{x:1391,y:690,t:1526933925914};\\\", \\\"{x:1391,y:691,t:1526933925930};\\\", \\\"{x:1393,y:691,t:1526933925947};\\\", \\\"{x:1395,y:691,t:1526933925964};\\\", \\\"{x:1398,y:691,t:1526933925980};\\\", \\\"{x:1401,y:691,t:1526933925997};\\\", \\\"{x:1405,y:693,t:1526933926014};\\\", \\\"{x:1408,y:693,t:1526933926030};\\\", \\\"{x:1409,y:693,t:1526933926047};\\\", \\\"{x:1410,y:693,t:1526933926097};\\\", \\\"{x:1412,y:693,t:1526933926121};\\\", \\\"{x:1413,y:693,t:1526933926130};\\\", \\\"{x:1417,y:693,t:1526933926147};\\\", \\\"{x:1418,y:693,t:1526933926164};\\\", \\\"{x:1408,y:693,t:1526933926266};\\\", \\\"{x:1396,y:693,t:1526933926281};\\\", \\\"{x:1362,y:688,t:1526933926298};\\\", \\\"{x:1345,y:685,t:1526933926315};\\\", \\\"{x:1324,y:680,t:1526933926332};\\\", \\\"{x:1300,y:672,t:1526933926347};\\\", \\\"{x:1275,y:669,t:1526933926365};\\\", \\\"{x:1256,y:665,t:1526933926381};\\\", \\\"{x:1233,y:663,t:1526933926397};\\\", \\\"{x:1219,y:662,t:1526933926415};\\\", \\\"{x:1214,y:661,t:1526933926431};\\\", \\\"{x:1207,y:659,t:1526933926447};\\\", \\\"{x:1204,y:658,t:1526933926465};\\\", \\\"{x:1172,y:655,t:1526933926482};\\\", \\\"{x:1155,y:653,t:1526933926498};\\\", \\\"{x:1135,y:650,t:1526933926515};\\\", \\\"{x:1110,y:644,t:1526933926531};\\\", \\\"{x:1085,y:641,t:1526933926547};\\\", \\\"{x:1076,y:638,t:1526933926566};\\\", \\\"{x:1066,y:629,t:1526933926582};\\\", \\\"{x:1054,y:624,t:1526933926597};\\\", \\\"{x:1051,y:624,t:1526933926615};\\\", \\\"{x:1051,y:623,t:1526933926922};\\\", \\\"{x:1051,y:622,t:1526933926937};\\\", \\\"{x:1048,y:620,t:1526933926954};\\\", \\\"{x:1047,y:620,t:1526933926969};\\\", \\\"{x:1046,y:620,t:1526933926985};\\\", \\\"{x:1043,y:620,t:1526933926999};\\\", \\\"{x:1033,y:623,t:1526933927015};\\\", \\\"{x:1010,y:624,t:1526933927032};\\\", \\\"{x:973,y:624,t:1526933927049};\\\", \\\"{x:937,y:624,t:1526933927066};\\\", \\\"{x:865,y:620,t:1526933927082};\\\", \\\"{x:787,y:620,t:1526933927107};\\\", \\\"{x:764,y:620,t:1526933927124};\\\", \\\"{x:751,y:622,t:1526933927141};\\\", \\\"{x:751,y:619,t:1526933927225};\\\", \\\"{x:751,y:613,t:1526933927241};\\\", \\\"{x:761,y:602,t:1526933927259};\\\", \\\"{x:771,y:587,t:1526933927282};\\\", \\\"{x:781,y:579,t:1526933927299};\\\", \\\"{x:790,y:573,t:1526933927317};\\\", \\\"{x:802,y:563,t:1526933927333};\\\", \\\"{x:814,y:555,t:1526933927350};\\\", \\\"{x:821,y:550,t:1526933927366};\\\", \\\"{x:827,y:546,t:1526933927382};\\\", \\\"{x:830,y:543,t:1526933927399};\\\", \\\"{x:834,y:541,t:1526933927416};\\\", \\\"{x:836,y:540,t:1526933927433};\\\", \\\"{x:836,y:539,t:1526933927473};\\\", \\\"{x:837,y:539,t:1526933927489};\\\", \\\"{x:837,y:538,t:1526933927500};\\\", \\\"{x:839,y:536,t:1526933927517};\\\", \\\"{x:839,y:534,t:1526933927532};\\\", \\\"{x:840,y:532,t:1526933927549};\\\", \\\"{x:840,y:531,t:1526933927567};\\\", \\\"{x:840,y:530,t:1526933927582};\\\", \\\"{x:840,y:529,t:1526933927599};\\\", \\\"{x:840,y:527,t:1526933927617};\\\", \\\"{x:840,y:526,t:1526933927632};\\\", \\\"{x:840,y:524,t:1526933927650};\\\", \\\"{x:840,y:523,t:1526933927666};\\\", \\\"{x:840,y:521,t:1526933927683};\\\", \\\"{x:840,y:520,t:1526933927713};\\\", \\\"{x:838,y:519,t:1526933928634};\\\", \\\"{x:832,y:523,t:1526933928649};\\\", \\\"{x:826,y:528,t:1526933928667};\\\", \\\"{x:814,y:533,t:1526933928684};\\\", \\\"{x:801,y:537,t:1526933928701};\\\", \\\"{x:785,y:544,t:1526933928717};\\\", \\\"{x:774,y:551,t:1526933928733};\\\", \\\"{x:759,y:562,t:1526933928750};\\\", \\\"{x:740,y:576,t:1526933928768};\\\", \\\"{x:722,y:591,t:1526933928784};\\\", \\\"{x:703,y:609,t:1526933928800};\\\", \\\"{x:671,y:637,t:1526933928817};\\\", \\\"{x:654,y:649,t:1526933928834};\\\", \\\"{x:642,y:658,t:1526933928850};\\\", \\\"{x:633,y:667,t:1526933928867};\\\", \\\"{x:628,y:672,t:1526933928883};\\\", \\\"{x:622,y:679,t:1526933928900};\\\", \\\"{x:612,y:692,t:1526933928917};\\\", \\\"{x:602,y:702,t:1526933928933};\\\", \\\"{x:592,y:710,t:1526933928951};\\\", \\\"{x:585,y:715,t:1526933928967};\\\", \\\"{x:579,y:719,t:1526933928983};\\\", \\\"{x:573,y:723,t:1526933929001};\\\", \\\"{x:568,y:727,t:1526933929017};\\\", \\\"{x:564,y:729,t:1526933929033};\\\", \\\"{x:560,y:731,t:1526933929051};\\\", \\\"{x:557,y:733,t:1526933929067};\\\", \\\"{x:554,y:735,t:1526933929084};\\\", \\\"{x:552,y:735,t:1526933929101};\\\", \\\"{x:552,y:736,t:1526933929117};\\\", \\\"{x:557,y:736,t:1526933929666};\\\", \\\"{x:594,y:721,t:1526933929684};\\\", \\\"{x:650,y:694,t:1526933929699};\\\", \\\"{x:733,y:661,t:1526933929717};\\\", \\\"{x:831,y:627,t:1526933929734};\\\", \\\"{x:946,y:598,t:1526933929751};\\\", \\\"{x:1057,y:565,t:1526933929768};\\\", \\\"{x:1169,y:528,t:1526933929784};\\\", \\\"{x:1301,y:492,t:1526933929800};\\\", \\\"{x:1364,y:478,t:1526933929817};\\\", \\\"{x:1396,y:470,t:1526933929834};\\\", \\\"{x:1424,y:460,t:1526933929851};\\\", \\\"{x:1447,y:456,t:1526933929867};\\\", \\\"{x:1476,y:446,t:1526933929884};\\\", \\\"{x:1498,y:438,t:1526933929902};\\\", \\\"{x:1522,y:429,t:1526933929917};\\\", \\\"{x:1549,y:419,t:1526933929934};\\\", \\\"{x:1569,y:414,t:1526933929951};\\\", \\\"{x:1577,y:410,t:1526933929968};\\\", \\\"{x:1575,y:411,t:1526933930290};\\\", \\\"{x:1572,y:411,t:1526933930801};\\\", \\\"{x:1559,y:421,t:1526933930818};\\\", \\\"{x:1545,y:431,t:1526933930836};\\\", \\\"{x:1527,y:440,t:1526933930852};\\\", \\\"{x:1517,y:445,t:1526933930868};\\\", \\\"{x:1509,y:449,t:1526933930886};\\\", \\\"{x:1506,y:450,t:1526933930903};\\\", \\\"{x:1503,y:451,t:1526933930919};\\\", \\\"{x:1496,y:452,t:1526933930936};\\\", \\\"{x:1483,y:455,t:1526933930952};\\\", \\\"{x:1472,y:458,t:1526933930969};\\\", \\\"{x:1459,y:460,t:1526933930985};\\\", \\\"{x:1455,y:461,t:1526933931002};\\\", \\\"{x:1451,y:461,t:1526933931018};\\\", \\\"{x:1448,y:462,t:1526933931035};\\\", \\\"{x:1445,y:462,t:1526933931052};\\\", \\\"{x:1443,y:462,t:1526933931068};\\\", \\\"{x:1442,y:462,t:1526933931086};\\\", \\\"{x:1439,y:462,t:1526933931102};\\\", \\\"{x:1436,y:462,t:1526933931118};\\\", \\\"{x:1435,y:462,t:1526933931136};\\\", \\\"{x:1433,y:462,t:1526933931152};\\\", \\\"{x:1431,y:462,t:1526933931168};\\\", \\\"{x:1425,y:457,t:1526933931185};\\\", \\\"{x:1424,y:454,t:1526933931202};\\\", \\\"{x:1421,y:449,t:1526933931219};\\\", \\\"{x:1418,y:444,t:1526933931235};\\\", \\\"{x:1417,y:441,t:1526933931252};\\\", \\\"{x:1415,y:438,t:1526933931268};\\\", \\\"{x:1414,y:437,t:1526933931285};\\\", \\\"{x:1413,y:436,t:1526933931305};\\\", \\\"{x:1413,y:435,t:1526933931319};\\\", \\\"{x:1411,y:432,t:1526933931335};\\\", \\\"{x:1410,y:431,t:1526933931353};\\\", \\\"{x:1409,y:429,t:1526933931368};\\\", \\\"{x:1407,y:432,t:1526933931713};\\\", \\\"{x:1407,y:433,t:1526933931721};\\\", \\\"{x:1406,y:440,t:1526933931735};\\\", \\\"{x:1405,y:450,t:1526933931752};\\\", \\\"{x:1401,y:477,t:1526933931769};\\\", \\\"{x:1397,y:499,t:1526933931785};\\\", \\\"{x:1395,y:524,t:1526933931803};\\\", \\\"{x:1389,y:550,t:1526933931820};\\\", \\\"{x:1382,y:591,t:1526933931837};\\\", \\\"{x:1375,y:642,t:1526933931853};\\\", \\\"{x:1353,y:714,t:1526933931870};\\\", \\\"{x:1341,y:779,t:1526933931887};\\\", \\\"{x:1327,y:829,t:1526933931903};\\\", \\\"{x:1317,y:856,t:1526933931920};\\\", \\\"{x:1306,y:883,t:1526933931936};\\\", \\\"{x:1295,y:899,t:1526933931953};\\\", \\\"{x:1282,y:918,t:1526933931970};\\\", \\\"{x:1274,y:925,t:1526933931987};\\\", \\\"{x:1270,y:927,t:1526933932003};\\\", \\\"{x:1262,y:930,t:1526933932019};\\\", \\\"{x:1253,y:933,t:1526933932037};\\\", \\\"{x:1242,y:935,t:1526933932053};\\\", \\\"{x:1234,y:938,t:1526933932070};\\\", \\\"{x:1224,y:939,t:1526933932087};\\\", \\\"{x:1207,y:939,t:1526933932103};\\\", \\\"{x:1192,y:939,t:1526933932120};\\\", \\\"{x:1178,y:939,t:1526933932136};\\\", \\\"{x:1160,y:936,t:1526933932153};\\\", \\\"{x:1149,y:933,t:1526933932169};\\\", \\\"{x:1136,y:929,t:1526933932187};\\\", \\\"{x:1130,y:927,t:1526933932203};\\\", \\\"{x:1128,y:927,t:1526933932220};\\\", \\\"{x:1125,y:925,t:1526933932236};\\\", \\\"{x:1123,y:925,t:1526933932253};\\\", \\\"{x:1123,y:924,t:1526933932273};\\\", \\\"{x:1123,y:923,t:1526933932286};\\\", \\\"{x:1123,y:917,t:1526933932303};\\\", \\\"{x:1123,y:914,t:1526933932319};\\\", \\\"{x:1125,y:910,t:1526933932336};\\\", \\\"{x:1125,y:909,t:1526933932353};\\\", \\\"{x:1134,y:907,t:1526933932369};\\\", \\\"{x:1156,y:901,t:1526933932386};\\\", \\\"{x:1178,y:897,t:1526933932403};\\\", \\\"{x:1195,y:896,t:1526933932419};\\\", \\\"{x:1222,y:895,t:1526933932437};\\\", \\\"{x:1226,y:895,t:1526933932453};\\\", \\\"{x:1237,y:895,t:1526933932469};\\\", \\\"{x:1245,y:895,t:1526933932486};\\\", \\\"{x:1248,y:897,t:1526933932503};\\\", \\\"{x:1250,y:897,t:1526933932520};\\\", \\\"{x:1251,y:897,t:1526933932537};\\\", \\\"{x:1253,y:897,t:1526933932553};\\\", \\\"{x:1255,y:897,t:1526933932570};\\\", \\\"{x:1255,y:898,t:1526933932587};\\\", \\\"{x:1257,y:899,t:1526933932604};\\\", \\\"{x:1260,y:899,t:1526933932620};\\\", \\\"{x:1269,y:899,t:1526933932637};\\\", \\\"{x:1282,y:899,t:1526933932653};\\\", \\\"{x:1298,y:899,t:1526933932669};\\\", \\\"{x:1305,y:899,t:1526933932687};\\\", \\\"{x:1311,y:899,t:1526933932704};\\\", \\\"{x:1319,y:899,t:1526933932721};\\\", \\\"{x:1332,y:899,t:1526933932736};\\\", \\\"{x:1352,y:898,t:1526933932753};\\\", \\\"{x:1366,y:896,t:1526933932771};\\\", \\\"{x:1372,y:895,t:1526933932787};\\\", \\\"{x:1374,y:894,t:1526933932804};\\\", \\\"{x:1374,y:893,t:1526933932937};\\\", \\\"{x:1374,y:892,t:1526933932953};\\\", \\\"{x:1373,y:892,t:1526933933130};\\\", \\\"{x:1372,y:891,t:1526933933162};\\\", \\\"{x:1374,y:891,t:1526933934050};\\\", \\\"{x:1375,y:891,t:1526933934058};\\\", \\\"{x:1377,y:891,t:1526933934074};\\\", \\\"{x:1378,y:891,t:1526933934097};\\\", \\\"{x:1381,y:891,t:1526933934642};\\\", \\\"{x:1383,y:891,t:1526933934665};\\\", \\\"{x:1385,y:891,t:1526933934673};\\\", \\\"{x:1388,y:891,t:1526933934691};\\\", \\\"{x:1395,y:891,t:1526933934705};\\\", \\\"{x:1400,y:891,t:1526933934722};\\\", \\\"{x:1406,y:891,t:1526933934739};\\\", \\\"{x:1410,y:890,t:1526933934755};\\\", \\\"{x:1413,y:890,t:1526933934772};\\\", \\\"{x:1414,y:890,t:1526933934801};\\\", \\\"{x:1417,y:890,t:1526933934809};\\\", \\\"{x:1420,y:890,t:1526933934823};\\\", \\\"{x:1424,y:890,t:1526933934839};\\\", \\\"{x:1432,y:890,t:1526933934856};\\\", \\\"{x:1434,y:890,t:1526933934873};\\\", \\\"{x:1444,y:890,t:1526933934890};\\\", \\\"{x:1445,y:890,t:1526933934906};\\\", \\\"{x:1447,y:890,t:1526933934923};\\\", \\\"{x:1444,y:888,t:1526933935842};\\\", \\\"{x:1440,y:887,t:1526933935856};\\\", \\\"{x:1416,y:880,t:1526933935873};\\\", \\\"{x:1405,y:877,t:1526933935890};\\\", \\\"{x:1397,y:877,t:1526933935906};\\\", \\\"{x:1387,y:874,t:1526933935924};\\\", \\\"{x:1385,y:873,t:1526933935940};\\\", \\\"{x:1382,y:871,t:1526933935956};\\\", \\\"{x:1378,y:869,t:1526933935973};\\\", \\\"{x:1376,y:866,t:1526933935989};\\\", \\\"{x:1369,y:862,t:1526933936006};\\\", \\\"{x:1366,y:860,t:1526933936023};\\\", \\\"{x:1362,y:857,t:1526933936040};\\\", \\\"{x:1357,y:855,t:1526933936056};\\\", \\\"{x:1347,y:850,t:1526933936073};\\\", \\\"{x:1331,y:847,t:1526933936090};\\\", \\\"{x:1317,y:843,t:1526933936106};\\\", \\\"{x:1294,y:838,t:1526933936123};\\\", \\\"{x:1271,y:833,t:1526933936139};\\\", \\\"{x:1245,y:831,t:1526933936156};\\\", \\\"{x:1222,y:829,t:1526933936172};\\\", \\\"{x:1208,y:827,t:1526933936190};\\\", \\\"{x:1196,y:827,t:1526933936207};\\\", \\\"{x:1193,y:827,t:1526933936223};\\\", \\\"{x:1191,y:827,t:1526933936240};\\\", \\\"{x:1192,y:826,t:1526933936498};\\\", \\\"{x:1193,y:826,t:1526933936507};\\\", \\\"{x:1197,y:826,t:1526933936523};\\\", \\\"{x:1200,y:826,t:1526933936540};\\\", \\\"{x:1203,y:826,t:1526933936557};\\\", \\\"{x:1204,y:826,t:1526933936573};\\\", \\\"{x:1206,y:826,t:1526933936618};\\\", \\\"{x:1207,y:826,t:1526933936634};\\\", \\\"{x:1209,y:826,t:1526933936650};\\\", \\\"{x:1210,y:826,t:1526933936658};\\\", \\\"{x:1211,y:826,t:1526933936673};\\\", \\\"{x:1214,y:826,t:1526933937130};\\\", \\\"{x:1218,y:826,t:1526933937141};\\\", \\\"{x:1232,y:826,t:1526933937158};\\\", \\\"{x:1260,y:826,t:1526933937174};\\\", \\\"{x:1290,y:828,t:1526933937192};\\\", \\\"{x:1320,y:831,t:1526933937208};\\\", \\\"{x:1338,y:832,t:1526933937224};\\\", \\\"{x:1369,y:835,t:1526933937242};\\\", \\\"{x:1389,y:835,t:1526933937257};\\\", \\\"{x:1395,y:835,t:1526933937273};\\\", \\\"{x:1399,y:835,t:1526933937291};\\\", \\\"{x:1401,y:835,t:1526933937307};\\\", \\\"{x:1402,y:835,t:1526933937325};\\\", \\\"{x:1403,y:834,t:1526933937386};\\\", \\\"{x:1404,y:833,t:1526933937394};\\\", \\\"{x:1405,y:832,t:1526933937425};\\\", \\\"{x:1407,y:831,t:1526933937441};\\\", \\\"{x:1408,y:831,t:1526933937465};\\\", \\\"{x:1410,y:830,t:1526933937482};\\\", \\\"{x:1412,y:830,t:1526933937498};\\\", \\\"{x:1416,y:829,t:1526933937507};\\\", \\\"{x:1421,y:828,t:1526933937524};\\\", \\\"{x:1427,y:828,t:1526933937541};\\\", \\\"{x:1432,y:827,t:1526933937558};\\\", \\\"{x:1437,y:827,t:1526933937575};\\\", \\\"{x:1441,y:826,t:1526933937592};\\\", \\\"{x:1442,y:826,t:1526933937609};\\\", \\\"{x:1442,y:824,t:1526933937762};\\\", \\\"{x:1440,y:822,t:1526933937774};\\\", \\\"{x:1426,y:813,t:1526933937792};\\\", \\\"{x:1411,y:804,t:1526933937808};\\\", \\\"{x:1397,y:794,t:1526933937824};\\\", \\\"{x:1383,y:784,t:1526933937841};\\\", \\\"{x:1381,y:781,t:1526933937857};\\\", \\\"{x:1380,y:780,t:1526933937874};\\\", \\\"{x:1380,y:778,t:1526933937890};\\\", \\\"{x:1380,y:777,t:1526933937945};\\\", \\\"{x:1379,y:777,t:1526933937985};\\\", \\\"{x:1379,y:776,t:1526933938066};\\\", \\\"{x:1378,y:776,t:1526933938075};\\\", \\\"{x:1371,y:774,t:1526933938092};\\\", \\\"{x:1362,y:773,t:1526933938109};\\\", \\\"{x:1354,y:770,t:1526933938125};\\\", \\\"{x:1352,y:769,t:1526933938141};\\\", \\\"{x:1350,y:768,t:1526933938158};\\\", \\\"{x:1350,y:767,t:1526933938538};\\\", \\\"{x:1350,y:766,t:1526933938882};\\\", \\\"{x:1350,y:764,t:1526933939018};\\\", \\\"{x:1350,y:763,t:1526933939066};\\\", \\\"{x:1349,y:763,t:1526933939106};\\\", \\\"{x:1348,y:761,t:1526933939217};\\\", \\\"{x:1347,y:761,t:1526933940218};\\\", \\\"{x:1342,y:761,t:1526933940228};\\\", \\\"{x:1331,y:764,t:1526933940243};\\\", \\\"{x:1313,y:767,t:1526933940260};\\\", \\\"{x:1288,y:772,t:1526933940277};\\\", \\\"{x:1273,y:775,t:1526933940267};\\\", \\\"{x:1251,y:775,t:1526933940284};\\\", \\\"{x:1232,y:775,t:1526933940300};\\\", \\\"{x:1215,y:775,t:1526933940317};\\\", \\\"{x:1204,y:775,t:1526933940335};\\\", \\\"{x:1195,y:775,t:1526933940351};\\\", \\\"{x:1187,y:772,t:1526933940367};\\\", \\\"{x:1185,y:772,t:1526933940384};\\\", \\\"{x:1184,y:772,t:1526933940400};\\\", \\\"{x:1182,y:771,t:1526933940431};\\\", \\\"{x:1181,y:771,t:1526933940463};\\\", \\\"{x:1179,y:771,t:1526933940471};\\\", \\\"{x:1178,y:771,t:1526933940484};\\\", \\\"{x:1176,y:770,t:1526933940500};\\\", \\\"{x:1174,y:769,t:1526933940517};\\\", \\\"{x:1174,y:768,t:1526933940608};\\\", \\\"{x:1174,y:766,t:1526933940664};\\\", \\\"{x:1174,y:765,t:1526933940800};\\\", \\\"{x:1175,y:765,t:1526933940815};\\\", \\\"{x:1178,y:765,t:1526933940823};\\\", \\\"{x:1181,y:765,t:1526933940834};\\\", \\\"{x:1190,y:765,t:1526933940852};\\\", \\\"{x:1201,y:765,t:1526933940867};\\\", \\\"{x:1214,y:766,t:1526933940884};\\\", \\\"{x:1224,y:767,t:1526933940900};\\\", \\\"{x:1229,y:769,t:1526933940917};\\\", \\\"{x:1236,y:769,t:1526933940933};\\\", \\\"{x:1241,y:769,t:1526933940950};\\\", \\\"{x:1243,y:769,t:1526933940966};\\\", \\\"{x:1245,y:769,t:1526933940983};\\\", \\\"{x:1246,y:769,t:1526933941015};\\\", \\\"{x:1247,y:769,t:1526933941063};\\\", \\\"{x:1247,y:768,t:1526933941415};\\\", \\\"{x:1248,y:767,t:1526933941960};\\\", \\\"{x:1249,y:767,t:1526933941967};\\\", \\\"{x:1252,y:767,t:1526933941985};\\\", \\\"{x:1258,y:766,t:1526933942001};\\\", \\\"{x:1264,y:766,t:1526933942018};\\\", \\\"{x:1268,y:766,t:1526933942035};\\\", \\\"{x:1269,y:766,t:1526933942052};\\\", \\\"{x:1270,y:766,t:1526933942068};\\\", \\\"{x:1272,y:766,t:1526933942085};\\\", \\\"{x:1275,y:766,t:1526933942119};\\\", \\\"{x:1277,y:765,t:1526933942135};\\\", \\\"{x:1281,y:765,t:1526933942152};\\\", \\\"{x:1285,y:763,t:1526933942168};\\\", \\\"{x:1289,y:763,t:1526933942185};\\\", \\\"{x:1292,y:763,t:1526933942202};\\\", \\\"{x:1294,y:763,t:1526933942218};\\\", \\\"{x:1296,y:763,t:1526933942235};\\\", \\\"{x:1297,y:763,t:1526933942252};\\\", \\\"{x:1299,y:763,t:1526933942268};\\\", \\\"{x:1302,y:763,t:1526933942335};\\\", \\\"{x:1303,y:763,t:1526933942375};\\\", \\\"{x:1305,y:763,t:1526933942391};\\\", \\\"{x:1306,y:763,t:1526933942401};\\\", \\\"{x:1308,y:763,t:1526933942419};\\\", \\\"{x:1309,y:763,t:1526933942435};\\\", \\\"{x:1311,y:763,t:1526933942452};\\\", \\\"{x:1312,y:763,t:1526933942471};\\\", \\\"{x:1310,y:763,t:1526933942791};\\\", \\\"{x:1309,y:763,t:1526933942807};\\\", \\\"{x:1307,y:763,t:1526933942830};\\\", \\\"{x:1306,y:763,t:1526933942838};\\\", \\\"{x:1305,y:763,t:1526933942852};\\\", \\\"{x:1303,y:763,t:1526933942869};\\\", \\\"{x:1301,y:763,t:1526933942886};\\\", \\\"{x:1296,y:763,t:1526933942901};\\\", \\\"{x:1294,y:763,t:1526933942919};\\\", \\\"{x:1293,y:763,t:1526933942935};\\\", \\\"{x:1292,y:763,t:1526933942952};\\\", \\\"{x:1291,y:763,t:1526933942969};\\\", \\\"{x:1290,y:763,t:1526933942986};\\\", \\\"{x:1289,y:763,t:1526933943311};\\\", \\\"{x:1290,y:763,t:1526933944175};\\\", \\\"{x:1291,y:763,t:1526933944187};\\\", \\\"{x:1294,y:763,t:1526933944203};\\\", \\\"{x:1295,y:762,t:1526933944263};\\\", \\\"{x:1296,y:762,t:1526933944303};\\\", \\\"{x:1297,y:762,t:1526933944319};\\\", \\\"{x:1299,y:762,t:1526933944337};\\\", \\\"{x:1300,y:762,t:1526933944353};\\\", \\\"{x:1302,y:761,t:1526933944423};\\\", \\\"{x:1303,y:761,t:1526933944448};\\\", \\\"{x:1304,y:761,t:1526933944463};\\\", \\\"{x:1306,y:760,t:1526933944471};\\\", \\\"{x:1306,y:759,t:1526933944503};\\\", \\\"{x:1307,y:759,t:1526933944520};\\\", \\\"{x:1308,y:759,t:1526933944615};\\\", \\\"{x:1309,y:758,t:1526933944703};\\\", \\\"{x:1310,y:758,t:1526933944760};\\\", \\\"{x:1311,y:758,t:1526933944783};\\\", \\\"{x:1312,y:758,t:1526933944791};\\\", \\\"{x:1313,y:758,t:1526933944805};\\\", \\\"{x:1315,y:758,t:1526933944820};\\\", \\\"{x:1318,y:758,t:1526933944837};\\\", \\\"{x:1319,y:758,t:1526933944854};\\\", \\\"{x:1322,y:758,t:1526933944870};\\\", \\\"{x:1326,y:758,t:1526933944887};\\\", \\\"{x:1330,y:756,t:1526933944905};\\\", \\\"{x:1336,y:756,t:1526933944920};\\\", \\\"{x:1337,y:756,t:1526933944938};\\\", \\\"{x:1339,y:755,t:1526933944955};\\\", \\\"{x:1340,y:755,t:1526933944998};\\\", \\\"{x:1342,y:755,t:1526933945014};\\\", \\\"{x:1343,y:755,t:1526933945062};\\\", \\\"{x:1344,y:754,t:1526933945070};\\\", \\\"{x:1346,y:754,t:1526933945158};\\\", \\\"{x:1347,y:754,t:1526933945182};\\\", \\\"{x:1348,y:754,t:1526933945190};\\\", \\\"{x:1349,y:754,t:1526933945214};\\\", \\\"{x:1350,y:754,t:1526933945271};\\\", \\\"{x:1352,y:754,t:1526933945287};\\\", \\\"{x:1353,y:754,t:1526933945319};\\\", \\\"{x:1355,y:754,t:1526933945335};\\\", \\\"{x:1356,y:756,t:1526933945359};\\\", \\\"{x:1357,y:756,t:1526933945391};\\\", \\\"{x:1357,y:757,t:1526933945447};\\\", \\\"{x:1357,y:758,t:1526933945454};\\\", \\\"{x:1357,y:760,t:1526933945478};\\\", \\\"{x:1356,y:762,t:1526933945502};\\\", \\\"{x:1355,y:763,t:1526933945519};\\\", \\\"{x:1353,y:763,t:1526933945712};\\\", \\\"{x:1353,y:764,t:1526933945721};\\\", \\\"{x:1352,y:764,t:1526933945759};\\\", \\\"{x:1351,y:765,t:1526933945791};\\\", \\\"{x:1350,y:765,t:1526933945806};\\\", \\\"{x:1349,y:765,t:1526933945944};\\\", \\\"{x:1350,y:765,t:1526933946479};\\\", \\\"{x:1354,y:765,t:1526933946489};\\\", \\\"{x:1360,y:765,t:1526933946506};\\\", \\\"{x:1366,y:765,t:1526933946523};\\\", \\\"{x:1369,y:765,t:1526933946539};\\\", \\\"{x:1372,y:766,t:1526933946556};\\\", \\\"{x:1374,y:766,t:1526933946572};\\\", \\\"{x:1375,y:766,t:1526933946588};\\\", \\\"{x:1378,y:767,t:1526933946606};\\\", \\\"{x:1379,y:767,t:1526933946623};\\\", \\\"{x:1381,y:768,t:1526933946640};\\\", \\\"{x:1382,y:768,t:1526933946655};\\\", \\\"{x:1384,y:768,t:1526933946672};\\\", \\\"{x:1385,y:768,t:1526933946689};\\\", \\\"{x:1388,y:768,t:1526933946706};\\\", \\\"{x:1391,y:768,t:1526933946722};\\\", \\\"{x:1392,y:768,t:1526933946740};\\\", \\\"{x:1394,y:768,t:1526933946755};\\\", \\\"{x:1396,y:768,t:1526933946772};\\\", \\\"{x:1401,y:767,t:1526933946788};\\\", \\\"{x:1403,y:766,t:1526933946805};\\\", \\\"{x:1404,y:766,t:1526933946822};\\\", \\\"{x:1407,y:765,t:1526933946838};\\\", \\\"{x:1410,y:764,t:1526933946855};\\\", \\\"{x:1412,y:762,t:1526933946872};\\\", \\\"{x:1413,y:762,t:1526933946968};\\\", \\\"{x:1414,y:762,t:1526933946999};\\\", \\\"{x:1415,y:761,t:1526933947111};\\\", \\\"{x:1417,y:761,t:1526933948888};\\\", \\\"{x:1418,y:762,t:1526933948895};\\\", \\\"{x:1421,y:763,t:1526933948927};\\\", \\\"{x:1422,y:763,t:1526933948941};\\\", \\\"{x:1424,y:764,t:1526933948957};\\\", \\\"{x:1425,y:764,t:1526933948974};\\\", \\\"{x:1426,y:765,t:1526933948999};\\\", \\\"{x:1427,y:765,t:1526933949007};\\\", \\\"{x:1428,y:766,t:1526933949038};\\\", \\\"{x:1430,y:766,t:1526933949079};\\\", \\\"{x:1431,y:767,t:1526933949110};\\\", \\\"{x:1433,y:767,t:1526933949143};\\\", \\\"{x:1434,y:767,t:1526933949158};\\\", \\\"{x:1435,y:767,t:1526933949174};\\\", \\\"{x:1436,y:767,t:1526933949190};\\\", \\\"{x:1438,y:767,t:1526933949207};\\\", \\\"{x:1439,y:767,t:1526933949224};\\\", \\\"{x:1440,y:767,t:1526933949240};\\\", \\\"{x:1441,y:767,t:1526933949257};\\\", \\\"{x:1443,y:767,t:1526933949275};\\\", \\\"{x:1444,y:767,t:1526933949291};\\\", \\\"{x:1446,y:767,t:1526933949307};\\\", \\\"{x:1447,y:767,t:1526933949327};\\\", \\\"{x:1448,y:767,t:1526933949343};\\\", \\\"{x:1449,y:767,t:1526933949358};\\\", \\\"{x:1450,y:767,t:1526933949375};\\\", \\\"{x:1452,y:767,t:1526933949391};\\\", \\\"{x:1453,y:767,t:1526933949423};\\\", \\\"{x:1455,y:767,t:1526933949447};\\\", \\\"{x:1456,y:767,t:1526933949463};\\\", \\\"{x:1458,y:767,t:1526933949488};\\\", \\\"{x:1459,y:767,t:1526933949495};\\\", \\\"{x:1460,y:767,t:1526933949510};\\\", \\\"{x:1461,y:767,t:1526933949524};\\\", \\\"{x:1462,y:767,t:1526933949541};\\\", \\\"{x:1463,y:767,t:1526933949557};\\\", \\\"{x:1465,y:766,t:1526933949574};\\\", \\\"{x:1467,y:765,t:1526933949614};\\\", \\\"{x:1469,y:764,t:1526933949647};\\\", \\\"{x:1470,y:763,t:1526933949657};\\\", \\\"{x:1471,y:763,t:1526933949674};\\\", \\\"{x:1472,y:762,t:1526933949691};\\\", \\\"{x:1474,y:762,t:1526933949775};\\\", \\\"{x:1476,y:762,t:1526933949887};\\\", \\\"{x:1478,y:762,t:1526933949895};\\\", \\\"{x:1479,y:762,t:1526933949911};\\\", \\\"{x:1480,y:762,t:1526933949925};\\\", \\\"{x:1482,y:762,t:1526933949941};\\\", \\\"{x:1484,y:762,t:1526933949959};\\\", \\\"{x:1485,y:762,t:1526933949974};\\\", \\\"{x:1487,y:762,t:1526933950136};\\\", \\\"{x:1488,y:761,t:1526933950848};\\\", \\\"{x:1491,y:760,t:1526933950887};\\\", \\\"{x:1492,y:760,t:1526933950952};\\\", \\\"{x:1495,y:760,t:1526933950959};\\\", \\\"{x:1502,y:760,t:1526933950975};\\\", \\\"{x:1510,y:760,t:1526933950992};\\\", \\\"{x:1513,y:760,t:1526933951008};\\\", \\\"{x:1516,y:760,t:1526933951025};\\\", \\\"{x:1518,y:760,t:1526933951042};\\\", \\\"{x:1519,y:760,t:1526933951070};\\\", \\\"{x:1521,y:760,t:1526933951086};\\\", \\\"{x:1523,y:760,t:1526933951102};\\\", \\\"{x:1524,y:760,t:1526933951110};\\\", \\\"{x:1526,y:760,t:1526933951126};\\\", \\\"{x:1528,y:760,t:1526933951142};\\\", \\\"{x:1530,y:760,t:1526933951158};\\\", \\\"{x:1532,y:760,t:1526933951175};\\\", \\\"{x:1534,y:760,t:1526933951192};\\\", \\\"{x:1536,y:760,t:1526933951209};\\\", \\\"{x:1537,y:760,t:1526933951238};\\\", \\\"{x:1538,y:760,t:1526933951263};\\\", \\\"{x:1539,y:760,t:1526933951275};\\\", \\\"{x:1540,y:760,t:1526933951292};\\\", \\\"{x:1542,y:760,t:1526933951309};\\\", \\\"{x:1543,y:760,t:1526933951325};\\\", \\\"{x:1546,y:760,t:1526933951343};\\\", \\\"{x:1549,y:760,t:1526933951360};\\\", \\\"{x:1551,y:760,t:1526933951375};\\\", \\\"{x:1553,y:760,t:1526933951392};\\\", \\\"{x:1554,y:760,t:1526933951504};\\\", \\\"{x:1545,y:762,t:1526933951512};\\\", \\\"{x:1530,y:762,t:1526933951525};\\\", \\\"{x:1443,y:765,t:1526933951542};\\\", \\\"{x:1216,y:767,t:1526933951559};\\\", \\\"{x:1037,y:750,t:1526933951576};\\\", \\\"{x:850,y:734,t:1526933951593};\\\", \\\"{x:673,y:710,t:1526933951609};\\\", \\\"{x:535,y:693,t:1526933951625};\\\", \\\"{x:436,y:683,t:1526933951643};\\\", \\\"{x:396,y:677,t:1526933951659};\\\", \\\"{x:389,y:677,t:1526933951676};\\\", \\\"{x:388,y:677,t:1526933951686};\\\", \\\"{x:387,y:677,t:1526933951704};\\\", \\\"{x:385,y:679,t:1526933951720};\\\", \\\"{x:384,y:683,t:1526933951737};\\\", \\\"{x:383,y:686,t:1526933951754};\\\", \\\"{x:381,y:688,t:1526933951776};\\\", \\\"{x:379,y:691,t:1526933951793};\\\", \\\"{x:377,y:693,t:1526933951810};\\\", \\\"{x:373,y:696,t:1526933951827};\\\", \\\"{x:368,y:702,t:1526933951843};\\\", \\\"{x:368,y:706,t:1526933951860};\\\", \\\"{x:368,y:707,t:1526933951877};\\\", \\\"{x:369,y:709,t:1526933951935};\\\", \\\"{x:374,y:710,t:1526933951945};\\\", \\\"{x:403,y:720,t:1526933951960};\\\", \\\"{x:432,y:727,t:1526933951978};\\\", \\\"{x:470,y:734,t:1526933951995};\\\", \\\"{x:499,y:740,t:1526933952010};\\\", \\\"{x:519,y:747,t:1526933952027};\\\", \\\"{x:524,y:752,t:1526933952042};\\\", \\\"{x:526,y:754,t:1526933952060};\\\" ] }, { \\\"rt\\\": 45557, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 838729, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at where 12 pm is and the events lined up along that vertical axis start at 12 pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8069, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Philippines\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 847795, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12322, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 861133, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 1437, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 863902, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"5GELG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"5GELG\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 283, dom: 773, initialDom: 921",
  "javascriptErrors": []
}