var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052923606dade3ebc74f4995caac2fe5cc0477f6"] = {
  "startTime": "2018-05-29T20:03:23.1082228Z",
  "websitePageUrl": "/",
  "visitTime": 97886,
  "engagementTime": 67180,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "1123efd949354db3c3675b2a06aefbba",
    "created": "2018-05-29T20:03:22.79264+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4b7d0189768ce21ac6fe1d42077ba54a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1123efd949354db3c3675b2a06aefbba/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 307,
      "e": 307,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 10005,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15101,
      "e": 5102,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 15201,
      "e": 5202,
      "ty": 2,
      "x": 892,
      "y": 793
    },
    {
      "t": 15251,
      "e": 5252,
      "ty": 41,
      "x": 29081,
      "y": 48618,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19454,
      "e": 9455,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 20547,
      "e": 10252,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 22600,
      "e": 10252,
      "ty": 2,
      "x": 894,
      "y": 806
    },
    {
      "t": 22700,
      "e": 10352,
      "ty": 2,
      "x": 863,
      "y": 849
    },
    {
      "t": 22751,
      "e": 10403,
      "ty": 41,
      "x": 25117,
      "y": 58077,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 22801,
      "e": 10453,
      "ty": 2,
      "x": 802,
      "y": 968
    },
    {
      "t": 22908,
      "e": 10560,
      "ty": 2,
      "x": 802,
      "y": 970
    },
    {
      "t": 23001,
      "e": 10653,
      "ty": 2,
      "x": 809,
      "y": 941
    },
    {
      "t": 23002,
      "e": 10654,
      "ty": 41,
      "x": 25363,
      "y": 56415,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 23101,
      "e": 10753,
      "ty": 2,
      "x": 812,
      "y": 928
    },
    {
      "t": 23202,
      "e": 10854,
      "ty": 2,
      "x": 813,
      "y": 926
    },
    {
      "t": 23251,
      "e": 10903,
      "ty": 41,
      "x": 34610,
      "y": 16434,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 23308,
      "e": 10960,
      "ty": 2,
      "x": 814,
      "y": 914
    },
    {
      "t": 23404,
      "e": 11056,
      "ty": 3,
      "x": 814,
      "y": 914,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 23506,
      "e": 11158,
      "ty": 41,
      "x": 34610,
      "y": 9881,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 23549,
      "e": 11201,
      "ty": 4,
      "x": 34610,
      "y": 9881,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 23549,
      "e": 11201,
      "ty": 5,
      "x": 814,
      "y": 914,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 23552,
      "e": 11204,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 23557,
      "e": 11209,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 23601,
      "e": 11253,
      "ty": 2,
      "x": 798,
      "y": 920
    },
    {
      "t": 23701,
      "e": 11353,
      "ty": 2,
      "x": 733,
      "y": 993
    },
    {
      "t": 23751,
      "e": 11403,
      "ty": 41,
      "x": 22460,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 23801,
      "e": 11453,
      "ty": 2,
      "x": 819,
      "y": 1032
    },
    {
      "t": 23908,
      "e": 11560,
      "ty": 2,
      "x": 903,
      "y": 1040
    },
    {
      "t": 24008,
      "e": 11660,
      "ty": 41,
      "x": 29987,
      "y": 63271,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 24501,
      "e": 12153,
      "ty": 2,
      "x": 911,
      "y": 1026
    },
    {
      "t": 24501,
      "e": 12153,
      "ty": 41,
      "x": 30381,
      "y": 62302,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 24601,
      "e": 12253,
      "ty": 2,
      "x": 922,
      "y": 1034
    },
    {
      "t": 24752,
      "e": 12404,
      "ty": 41,
      "x": 30922,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 25251,
      "e": 12903,
      "ty": 41,
      "x": 31955,
      "y": 63548,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 25302,
      "e": 12954,
      "ty": 2,
      "x": 1004,
      "y": 1066
    },
    {
      "t": 25410,
      "e": 13062,
      "ty": 2,
      "x": 1043,
      "y": 1078
    },
    {
      "t": 25510,
      "e": 13162,
      "ty": 41,
      "x": 35643,
      "y": 59275,
      "ta": "> div.masterdiv"
    },
    {
      "t": 25673,
      "e": 13325,
      "ty": 6,
      "x": 1020,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 25701,
      "e": 13353,
      "ty": 2,
      "x": 1001,
      "y": 1100
    },
    {
      "t": 25705,
      "e": 13357,
      "ty": 7,
      "x": 978,
      "y": 1115,
      "ta": "#start"
    },
    {
      "t": 25751,
      "e": 13403,
      "ty": 41,
      "x": 32065,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 25789,
      "e": 13441,
      "ty": 6,
      "x": 961,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 25801,
      "e": 13453,
      "ty": 2,
      "x": 961,
      "y": 1101
    },
    {
      "t": 25901,
      "e": 13553,
      "ty": 2,
      "x": 969,
      "y": 1083
    },
    {
      "t": 26004,
      "e": 13656,
      "ty": 2,
      "x": 969,
      "y": 1081
    },
    {
      "t": 26004,
      "e": 13656,
      "ty": 41,
      "x": 32494,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 27805,
      "e": 15457,
      "ty": 3,
      "x": 969,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 27806,
      "e": 15458,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 27808,
      "e": 15460,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 27939,
      "e": 15591,
      "ty": 4,
      "x": 32494,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 27940,
      "e": 15592,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 27941,
      "e": 15593,
      "ty": 5,
      "x": 969,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 27941,
      "e": 15593,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 28601,
      "e": 16253,
      "ty": 2,
      "x": 997,
      "y": 959
    },
    {
      "t": 28702,
      "e": 16354,
      "ty": 2,
      "x": 1028,
      "y": 926
    },
    {
      "t": 28760,
      "e": 16412,
      "ty": 41,
      "x": 35126,
      "y": 50854,
      "ta": "html > body"
    },
    {
      "t": 28948,
      "e": 16600,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 29001,
      "e": 16653,
      "ty": 2,
      "x": 1032,
      "y": 924
    },
    {
      "t": 29002,
      "e": 16654,
      "ty": 41,
      "x": 35264,
      "y": 50743,
      "ta": "html > body"
    },
    {
      "t": 29103,
      "e": 16755,
      "ty": 2,
      "x": 1034,
      "y": 923
    },
    {
      "t": 29251,
      "e": 16903,
      "ty": 41,
      "x": 35333,
      "y": 50688,
      "ta": "html > body"
    },
    {
      "t": 29501,
      "e": 17153,
      "ty": 2,
      "x": 1053,
      "y": 787
    },
    {
      "t": 29501,
      "e": 17153,
      "ty": 41,
      "x": 35987,
      "y": 43154,
      "ta": "html > body"
    },
    {
      "t": 29542,
      "e": 17194,
      "ty": 6,
      "x": 1078,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29558,
      "e": 17210,
      "ty": 7,
      "x": 1082,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29601,
      "e": 17253,
      "ty": 2,
      "x": 1085,
      "y": 609
    },
    {
      "t": 29609,
      "e": 17261,
      "ty": 6,
      "x": 1081,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29624,
      "e": 17276,
      "ty": 7,
      "x": 1079,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29701,
      "e": 17353,
      "ty": 2,
      "x": 1075,
      "y": 570
    },
    {
      "t": 29755,
      "e": 17407,
      "ty": 41,
      "x": 55802,
      "y": 40871,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29757,
      "e": 17409,
      "ty": 6,
      "x": 1059,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29775,
      "e": 17427,
      "ty": 7,
      "x": 1041,
      "y": 623,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29801,
      "e": 17453,
      "ty": 2,
      "x": 1029,
      "y": 638
    },
    {
      "t": 29901,
      "e": 17553,
      "ty": 2,
      "x": 1026,
      "y": 638
    },
    {
      "t": 30001,
      "e": 17653,
      "ty": 2,
      "x": 1026,
      "y": 617
    },
    {
      "t": 30002,
      "e": 17654,
      "ty": 41,
      "x": 47150,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 30002,
      "e": 17654,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30102,
      "e": 17754,
      "ty": 2,
      "x": 1026,
      "y": 610
    },
    {
      "t": 30202,
      "e": 17854,
      "ty": 2,
      "x": 1027,
      "y": 608
    },
    {
      "t": 30251,
      "e": 17903,
      "ty": 41,
      "x": 47366,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 30349,
      "e": 18001,
      "ty": 6,
      "x": 1027,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30401,
      "e": 18053,
      "ty": 2,
      "x": 1027,
      "y": 600
    },
    {
      "t": 30501,
      "e": 18153,
      "ty": 2,
      "x": 1027,
      "y": 599
    },
    {
      "t": 30501,
      "e": 18153,
      "ty": 41,
      "x": 47366,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32083,
      "e": 19735,
      "ty": 3,
      "x": 1027,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32084,
      "e": 19736,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32308,
      "e": 19960,
      "ty": 4,
      "x": 47366,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32309,
      "e": 19961,
      "ty": 5,
      "x": 1027,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32594,
      "e": 20246,
      "ty": 7,
      "x": 1123,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32601,
      "e": 20253,
      "ty": 2,
      "x": 1123,
      "y": 598
    },
    {
      "t": 32701,
      "e": 20353,
      "ty": 2,
      "x": 1378,
      "y": 601
    },
    {
      "t": 32750,
      "e": 20402,
      "ty": 41,
      "x": 47179,
      "y": 32850,
      "ta": "html > body"
    },
    {
      "t": 35272,
      "e": 22924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "81"
    },
    {
      "t": 35273,
      "e": 22925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35343,
      "e": 22995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 35343,
      "e": 22995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35358,
      "e": 23010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "qu"
    },
    {
      "t": 35431,
      "e": 23083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "qu"
    },
    {
      "t": 35438,
      "e": 23090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 35439,
      "e": 23091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35527,
      "e": 23179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "que"
    },
    {
      "t": 35648,
      "e": 23300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 35648,
      "e": 23300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35782,
      "e": 23434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "queb"
    },
    {
      "t": 35823,
      "e": 23475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 35823,
      "e": 23475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35920,
      "e": 23572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 36056,
      "e": 23708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 36056,
      "e": 23708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36206,
      "e": 23858,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "quebec"
    },
    {
      "t": 36215,
      "e": 23867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||c"
    },
    {
      "t": 36367,
      "e": 24019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 36368,
      "e": 24020,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "quebec"
    },
    {
      "t": 36369,
      "e": 24021,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36370,
      "e": 24022,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36494,
      "e": 24146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 36703,
      "e": 24355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 36705,
      "e": 24357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36774,
      "e": 24426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 36854,
      "e": 24506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 36855,
      "e": 24507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36919,
      "e": 24571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 37376,
      "e": 25028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 37376,
      "e": 25028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37440,
      "e": 25092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 38584,
      "e": 26236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 38585,
      "e": 26237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38710,
      "e": 26362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 39200,
      "e": 26852,
      "ty": 2,
      "x": 1594,
      "y": 606
    },
    {
      "t": 39250,
      "e": 26902,
      "ty": 41,
      "x": 50554,
      "y": 34955,
      "ta": "html > body"
    },
    {
      "t": 39301,
      "e": 26953,
      "ty": 2,
      "x": 1170,
      "y": 726
    },
    {
      "t": 39401,
      "e": 27053,
      "ty": 2,
      "x": 1057,
      "y": 745
    },
    {
      "t": 39501,
      "e": 27153,
      "ty": 2,
      "x": 1056,
      "y": 722
    },
    {
      "t": 39501,
      "e": 27153,
      "ty": 41,
      "x": 36090,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 39601,
      "e": 27253,
      "ty": 2,
      "x": 1055,
      "y": 721
    },
    {
      "t": 39700,
      "e": 27352,
      "ty": 2,
      "x": 1070,
      "y": 713
    },
    {
      "t": 39751,
      "e": 27403,
      "ty": 41,
      "x": 60344,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39801,
      "e": 27453,
      "ty": 2,
      "x": 1087,
      "y": 704
    },
    {
      "t": 40001,
      "e": 27653,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40191,
      "e": 27843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 40262,
      "e": 27914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 40684,
      "e": 28336,
      "ty": 6,
      "x": 1068,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40700,
      "e": 28352,
      "ty": 7,
      "x": 993,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40702,
      "e": 28354,
      "ty": 2,
      "x": 993,
      "y": 665
    },
    {
      "t": 40750,
      "e": 28402,
      "ty": 41,
      "x": 30280,
      "y": 23405,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 40800,
      "e": 28452,
      "ty": 2,
      "x": 948,
      "y": 643
    },
    {
      "t": 40901,
      "e": 28553,
      "ty": 2,
      "x": 947,
      "y": 642
    },
    {
      "t": 40967,
      "e": 28619,
      "ty": 6,
      "x": 956,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40984,
      "e": 28636,
      "ty": 7,
      "x": 959,
      "y": 710,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40984,
      "e": 28636,
      "ty": 6,
      "x": 959,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41001,
      "e": 28653,
      "ty": 2,
      "x": 959,
      "y": 710
    },
    {
      "t": 41001,
      "e": 28653,
      "ty": 41,
      "x": 32509,
      "y": 3971,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41101,
      "e": 28753,
      "ty": 2,
      "x": 962,
      "y": 726
    },
    {
      "t": 41250,
      "e": 28902,
      "ty": 41,
      "x": 34055,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44324,
      "e": 31976,
      "ty": 3,
      "x": 962,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44325,
      "e": 31977,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 44325,
      "e": 31977,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44326,
      "e": 31978,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44450,
      "e": 32102,
      "ty": 4,
      "x": 34055,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44451,
      "e": 32103,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44452,
      "e": 32104,
      "ty": 5,
      "x": 962,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44452,
      "e": 32104,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 44700,
      "e": 32352,
      "ty": 2,
      "x": 977,
      "y": 756
    },
    {
      "t": 44751,
      "e": 32403,
      "ty": 41,
      "x": 33714,
      "y": 41935,
      "ta": "html > body"
    },
    {
      "t": 44801,
      "e": 32453,
      "ty": 2,
      "x": 987,
      "y": 765
    },
    {
      "t": 45200,
      "e": 32852,
      "ty": 2,
      "x": 1126,
      "y": 745
    },
    {
      "t": 45251,
      "e": 32903,
      "ty": 41,
      "x": 39568,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 45301,
      "e": 32953,
      "ty": 2,
      "x": 1158,
      "y": 738
    },
    {
      "t": 45501,
      "e": 33153,
      "ty": 41,
      "x": 39603,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 45538,
      "e": 33190,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 45566,
      "e": 33218,
      "ty": 6,
      "x": 1158,
      "y": 738,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 50002,
      "e": 37654,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52674,
      "e": 38218,
      "ty": 7,
      "x": 1165,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 52675,
      "e": 38219,
      "ty": 6,
      "x": 1165,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 52701,
      "e": 38245,
      "ty": 2,
      "x": 1167,
      "y": 711
    },
    {
      "t": 52708,
      "e": 38252,
      "ty": 7,
      "x": 1168,
      "y": 694,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 52708,
      "e": 38252,
      "ty": 6,
      "x": 1168,
      "y": 694,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 52739,
      "e": 38283,
      "ty": 7,
      "x": 1170,
      "y": 646,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 52752,
      "e": 38296,
      "ty": 41,
      "x": 43123,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 52801,
      "e": 38345,
      "ty": 2,
      "x": 1183,
      "y": 576
    },
    {
      "t": 52891,
      "e": 38435,
      "ty": 6,
      "x": 1285,
      "y": 691,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 52902,
      "e": 38446,
      "ty": 2,
      "x": 1285,
      "y": 691
    },
    {
      "t": 52907,
      "e": 38451,
      "ty": 7,
      "x": 1310,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 52907,
      "e": 38451,
      "ty": 6,
      "x": 1310,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 52924,
      "e": 38468,
      "ty": 7,
      "x": 1341,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 52924,
      "e": 38468,
      "ty": 6,
      "x": 1341,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 52941,
      "e": 38485,
      "ty": 7,
      "x": 1375,
      "y": 816,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 53000,
      "e": 38544,
      "ty": 2,
      "x": 1379,
      "y": 820
    },
    {
      "t": 53001,
      "e": 38545,
      "ty": 41,
      "x": 53405,
      "y": 44506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 54400,
      "e": 39944,
      "ty": 2,
      "x": 842,
      "y": 866
    },
    {
      "t": 54501,
      "e": 40045,
      "ty": 41,
      "x": 26986,
      "y": 51222,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 54900,
      "e": 40444,
      "ty": 2,
      "x": 868,
      "y": 838
    },
    {
      "t": 55000,
      "e": 40544,
      "ty": 2,
      "x": 925,
      "y": 794
    },
    {
      "t": 55001,
      "e": 40545,
      "ty": 41,
      "x": 31070,
      "y": 60114,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 55058,
      "e": 40602,
      "ty": 6,
      "x": 1150,
      "y": 765,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 55075,
      "e": 40619,
      "ty": 7,
      "x": 1252,
      "y": 750,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 55076,
      "e": 40620,
      "ty": 6,
      "x": 1252,
      "y": 750,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55100,
      "e": 40644,
      "ty": 2,
      "x": 1274,
      "y": 748
    },
    {
      "t": 55200,
      "e": 40744,
      "ty": 2,
      "x": 1297,
      "y": 745
    },
    {
      "t": 55251,
      "e": 40795,
      "ty": 41,
      "x": 48889,
      "y": 42166,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55400,
      "e": 40944,
      "ty": 2,
      "x": 1298,
      "y": 738
    },
    {
      "t": 55426,
      "e": 40970,
      "ty": 7,
      "x": 1293,
      "y": 724,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55427,
      "e": 40971,
      "ty": 6,
      "x": 1293,
      "y": 724,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 55500,
      "e": 41044,
      "ty": 2,
      "x": 1252,
      "y": 701
    },
    {
      "t": 55501,
      "e": 41045,
      "ty": 41,
      "x": 46609,
      "y": 4717,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 55601,
      "e": 41145,
      "ty": 2,
      "x": 1247,
      "y": 700
    },
    {
      "t": 55751,
      "e": 41295,
      "ty": 41,
      "x": 46356,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 60003,
      "e": 45547,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 62403,
      "e": 46295,
      "ty": 2,
      "x": 1280,
      "y": 702
    },
    {
      "t": 62413,
      "e": 46305,
      "ty": 7,
      "x": 1321,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 62414,
      "e": 46306,
      "ty": 6,
      "x": 1321,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 62464,
      "e": 46356,
      "ty": 7,
      "x": 1423,
      "y": 665,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 62503,
      "e": 46395,
      "ty": 2,
      "x": 1612,
      "y": 620
    },
    {
      "t": 62503,
      "e": 46395,
      "ty": 41,
      "x": 64868,
      "y": 33157,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62603,
      "e": 46495,
      "ty": 2,
      "x": 1686,
      "y": 619
    },
    {
      "t": 62703,
      "e": 46595,
      "ty": 2,
      "x": 1893,
      "y": 647
    },
    {
      "t": 62753,
      "e": 46645,
      "ty": 41,
      "x": 65087,
      "y": 35398,
      "ta": "> div.masterdiv"
    },
    {
      "t": 62804,
      "e": 46696,
      "ty": 2,
      "x": 1899,
      "y": 647
    },
    {
      "t": 63003,
      "e": 46895,
      "ty": 41,
      "x": 65121,
      "y": 35398,
      "ta": "> div.masterdiv"
    },
    {
      "t": 63603,
      "e": 47495,
      "ty": 2,
      "x": 1919,
      "y": 597
    },
    {
      "t": 63703,
      "e": 47595,
      "ty": 2,
      "x": 1919,
      "y": 608
    },
    {
      "t": 63803,
      "e": 47695,
      "ty": 2,
      "x": 1919,
      "y": 617
    },
    {
      "t": 63904,
      "e": 47796,
      "ty": 2,
      "x": 1919,
      "y": 622
    },
    {
      "t": 70004,
      "e": 52796,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 79503,
      "e": 52796,
      "ty": 2,
      "x": 1895,
      "y": 691
    },
    {
      "t": 79504,
      "e": 52797,
      "ty": 41,
      "x": 64983,
      "y": 37836,
      "ta": "> div.masterdiv"
    },
    {
      "t": 79603,
      "e": 52896,
      "ty": 2,
      "x": 1673,
      "y": 870
    },
    {
      "t": 79703,
      "e": 52996,
      "ty": 2,
      "x": 1457,
      "y": 1017
    },
    {
      "t": 79753,
      "e": 53046,
      "ty": 41,
      "x": 57243,
      "y": 61678,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79903,
      "e": 53196,
      "ty": 2,
      "x": 962,
      "y": 1160
    },
    {
      "t": 80003,
      "e": 53296,
      "ty": 2,
      "x": 799,
      "y": 1192
    },
    {
      "t": 80103,
      "e": 53396,
      "ty": 2,
      "x": 776,
      "y": 1163
    },
    {
      "t": 80201,
      "e": 53494,
      "ty": 6,
      "x": 1006,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 80203,
      "e": 53496,
      "ty": 2,
      "x": 1006,
      "y": 1101
    },
    {
      "t": 80218,
      "e": 53511,
      "ty": 7,
      "x": 1073,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 80253,
      "e": 53546,
      "ty": 41,
      "x": 38019,
      "y": 61158,
      "ta": "> div.masterdiv"
    },
    {
      "t": 80303,
      "e": 53596,
      "ty": 2,
      "x": 1112,
      "y": 1112
    },
    {
      "t": 80403,
      "e": 53696,
      "ty": 2,
      "x": 1084,
      "y": 1112
    },
    {
      "t": 80451,
      "e": 53744,
      "ty": 6,
      "x": 1007,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 80503,
      "e": 53796,
      "ty": 2,
      "x": 980,
      "y": 1098
    },
    {
      "t": 80503,
      "e": 53796,
      "ty": 41,
      "x": 38501,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 83589,
      "e": 56882,
      "ty": 3,
      "x": 980,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 83589,
      "e": 56882,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 83974,
      "e": 57267,
      "ty": 4,
      "x": 38501,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 83976,
      "e": 57269,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 83977,
      "e": 57270,
      "ty": 5,
      "x": 980,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 83979,
      "e": 57272,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 84303,
      "e": 57596,
      "ty": 2,
      "x": 973,
      "y": 1103
    },
    {
      "t": 84403,
      "e": 57696,
      "ty": 2,
      "x": 969,
      "y": 1104
    },
    {
      "t": 84504,
      "e": 57797,
      "ty": 41,
      "x": 33094,
      "y": 60715,
      "ta": "html > body"
    },
    {
      "t": 84703,
      "e": 57996,
      "ty": 2,
      "x": 967,
      "y": 1103
    },
    {
      "t": 84754,
      "e": 58047,
      "ty": 41,
      "x": 33473,
      "y": 58056,
      "ta": "html > body"
    },
    {
      "t": 84803,
      "e": 58096,
      "ty": 2,
      "x": 989,
      "y": 1021
    },
    {
      "t": 84904,
      "e": 58197,
      "ty": 2,
      "x": 992,
      "y": 1013
    },
    {
      "t": 84981,
      "e": 58274,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 85003,
      "e": 58296,
      "ty": 2,
      "x": 993,
      "y": 1012
    },
    {
      "t": 85003,
      "e": 58296,
      "ty": 41,
      "x": 44630,
      "y": 10532,
      "ta": "> p"
    },
    {
      "t": 85903,
      "e": 59196,
      "ty": 2,
      "x": 1000,
      "y": 1020
    },
    {
      "t": 86004,
      "e": 59297,
      "ty": 41,
      "x": 47108,
      "y": 29256,
      "ta": "> p"
    },
    {
      "t": 86203,
      "e": 59496,
      "ty": 2,
      "x": 1001,
      "y": 1011
    },
    {
      "t": 86253,
      "e": 59546,
      "ty": 41,
      "x": 34231,
      "y": 55175,
      "ta": "html > body"
    },
    {
      "t": 86303,
      "e": 59596,
      "ty": 2,
      "x": 1004,
      "y": 998
    },
    {
      "t": 86504,
      "e": 59797,
      "ty": 41,
      "x": 34299,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 90004,
      "e": 63297,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 95503,
      "e": 64797,
      "ty": 2,
      "x": 1009,
      "y": 989
    },
    {
      "t": 95504,
      "e": 64798,
      "ty": 41,
      "x": 35170,
      "y": 65496,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 95603,
      "e": 64897,
      "ty": 2,
      "x": 1018,
      "y": 971
    },
    {
      "t": 95754,
      "e": 65048,
      "ty": 41,
      "x": 35607,
      "y": 64098,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 96883,
      "e": 66177,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 97886,
      "e": 67180,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 362, dom: 927, initialDom: 937",
  "javascriptErrors": []
}