var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06011217fc2ee30c3fe78cb0c2850370b7a0bfe2"] = {
  "startTime": "2018-06-01T17:20:12.3964324Z",
  "websitePageUrl": "/16",
  "visitTime": 95636,
  "engagementTime": 91728,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1034f21f85e031c890b958553ab689ed",
    "created": "2018-06-01T17:20:12.218658+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=MWJFN",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "91c5b43a06342a24af04d88ef3692511",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1034f21f85e031c890b958553ab689ed/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 2,
      "x": 808,
      "y": 16
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 497,
      "y": 16
    },
    {
      "t": 252,
      "e": 252,
      "ty": 41,
      "x": 16667,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 492,
      "y": 16
    },
    {
      "t": 677,
      "e": 677,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1102,
      "e": 1102,
      "ty": 2,
      "x": 450,
      "y": 166
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 410,
      "y": 387
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 34499,
      "y": 23045,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 403,
      "y": 441
    },
    {
      "t": 1398,
      "e": 1398,
      "ty": 6,
      "x": 404,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 404,
      "y": 527
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 416,
      "y": 575
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 35848,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 427,
      "y": 602
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 37084,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 427,
      "y": 583
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 427,
      "y": 576
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 37084,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2487,
      "e": 2487,
      "ty": 3,
      "x": 427,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2488,
      "e": 2488,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2614,
      "e": 2614,
      "ty": 4,
      "x": 37084,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2615,
      "e": 2615,
      "ty": 5,
      "x": 427,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 7,
      "x": 537,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 537,
      "y": 512
    },
    {
      "t": 3202,
      "e": 3202,
      "ty": 2,
      "x": 925,
      "y": 476
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 20930,
      "y": 23993,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1206,
      "y": 473
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1227,
      "y": 476
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 31077,
      "y": 24208,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1380,
      "y": 464
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 42140,
      "y": 23349,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4802,
      "e": 4802,
      "ty": 2,
      "x": 1384,
      "y": 464
    },
    {
      "t": 6811,
      "e": 6811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7011,
      "e": 7011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7012,
      "e": 7012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7074,
      "e": 7074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 7082,
      "e": 7082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 7098,
      "e": 7098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7098,
      "e": 7098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7186,
      "e": 7186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7186,
      "e": 7186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7194,
      "e": 7194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 7273,
      "e": 7273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 7330,
      "e": 7330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 7330,
      "e": 7330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7410,
      "e": 7410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7410,
      "e": 7410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7482,
      "e": 7482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To de"
    },
    {
      "t": 7594,
      "e": 7594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8354,
      "e": 8354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8354,
      "e": 8354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8362,
      "e": 8362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 8450,
      "e": 8450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 8450,
      "e": 8450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8498,
      "e": 8498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 8571,
      "e": 8571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8635,
      "e": 8635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 8635,
      "e": 8635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8714,
      "e": 8714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 8826,
      "e": 8826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8826,
      "e": 8826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8881,
      "e": 8881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 8946,
      "e": 8946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 8947,
      "e": 8947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9026,
      "e": 9026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 9034,
      "e": 9034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9035,
      "e": 9035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9107,
      "e": 9107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 9170,
      "e": 9170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9171,
      "e": 9171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9265,
      "e": 9265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9370,
      "e": 9370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 9370,
      "e": 9370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9450,
      "e": 9450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 9483,
      "e": 9483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9483,
      "e": 9483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9554,
      "e": 9554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10105,
      "e": 10105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 10105,
      "e": 10105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10178,
      "e": 10178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 10410,
      "e": 10410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10522,
      "e": 10522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine wh"
    },
    {
      "t": 11162,
      "e": 11162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11662,
      "e": 11662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11694,
      "e": 11694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11727,
      "e": 11727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11760,
      "e": 11760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11794,
      "e": 11794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11826,
      "e": 11826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11859,
      "e": 11859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11892,
      "e": 11892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11925,
      "e": 11925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11958,
      "e": 11958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11992,
      "e": 11992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12024,
      "e": 12024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12058,
      "e": 12058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12091,
      "e": 12091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12123,
      "e": 12123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12157,
      "e": 12157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12189,
      "e": 12189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12223,
      "e": 12223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12256,
      "e": 12256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12289,
      "e": 12289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12322,
      "e": 12322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12355,
      "e": 12355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12388,
      "e": 12388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12421,
      "e": 12421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12435,
      "e": 12435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 12658,
      "e": 12658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12787,
      "e": 12787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12788,
      "e": 12788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12827,
      "e": 12827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 12835,
      "e": 12835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12835,
      "e": 12835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12865,
      "e": 12865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 12937,
      "e": 12937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 13010,
      "e": 13010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13010,
      "e": 13010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13082,
      "e": 13082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 13179,
      "e": 13179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13179,
      "e": 13179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13234,
      "e": 13234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I lo"
    },
    {
      "t": 13330,
      "e": 13330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13331,
      "e": 13331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13378,
      "e": 13378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13450,
      "e": 13450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13450,
      "e": 13450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13530,
      "e": 13530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 13579,
      "e": 13579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13580,
      "e": 13580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13650,
      "e": 13650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13650,
      "e": 13650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13689,
      "e": 13689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ed"
    },
    {
      "t": 13753,
      "e": 13753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13770,
      "e": 13770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13771,
      "e": 13771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13865,
      "e": 13865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13922,
      "e": 13922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13922,
      "e": 13922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14042,
      "e": 14042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14122,
      "e": 14122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14124,
      "e": 14124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14194,
      "e": 14194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14266,
      "e": 14266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14270,
      "e": 14270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14346,
      "e": 14346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14370,
      "e": 14370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14370,
      "e": 14370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14458,
      "e": 14458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14474,
      "e": 14474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14475,
      "e": 14475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14538,
      "e": 14538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14539,
      "e": 14539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14562,
      "e": 14562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 14610,
      "e": 14610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14682,
      "e": 14682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14683,
      "e": 14683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14771,
      "e": 14771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15404,
      "e": 15404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 15405,
      "e": 15405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15466,
      "e": 15466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 15545,
      "e": 15545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15546,
      "e": 15546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15650,
      "e": 15650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 15674,
      "e": 15674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15675,
      "e": 15675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15770,
      "e": 15770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15882,
      "e": 15882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15883,
      "e": 15883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15953,
      "e": 15953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 16114,
      "e": 16114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16114,
      "e": 16114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16219,
      "e": 16219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16219,
      "e": 16219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16241,
      "e": 16241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 16330,
      "e": 16330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17378,
      "e": 17378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17378,
      "e": 17378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17449,
      "e": 17449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17554,
      "e": 17554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17554,
      "e": 17554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17650,
      "e": 17650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17650,
      "e": 17650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17690,
      "e": 17690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 17746,
      "e": 17746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17747,
      "e": 17747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17753,
      "e": 17753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17817,
      "e": 17817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17979,
      "e": 17979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17979,
      "e": 17979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18026,
      "e": 18026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18114,
      "e": 18114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18114,
      "e": 18114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18210,
      "e": 18210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18211,
      "e": 18211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18211,
      "e": 18211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18314,
      "e": 18314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18635,
      "e": 18635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18690,
      "e": 18690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on teh"
    },
    {
      "t": 18786,
      "e": 18786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18834,
      "e": 18786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on te"
    },
    {
      "t": 18938,
      "e": 18890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18986,
      "e": 18938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on t"
    },
    {
      "t": 19202,
      "e": 19154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19203,
      "e": 19155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19297,
      "e": 19249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19314,
      "e": 19266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19314,
      "e": 19266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19370,
      "e": 19322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19393,
      "e": 19345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19394,
      "e": 19346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19482,
      "e": 19434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19778,
      "e": 19730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19954,
      "e": 19906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19956,
      "e": 19908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19956,
      "e": 19908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20026,
      "e": 19978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 20266,
      "e": 20218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 20266,
      "e": 20218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20338,
      "e": 20290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 20666,
      "e": 20618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20745,
      "e": 20697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x"
    },
    {
      "t": 20898,
      "e": 20850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 20899,
      "e": 20851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20970,
      "e": 20922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 21482,
      "e": 21434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21484,
      "e": 21436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21553,
      "e": 21505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21938,
      "e": 21890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 21939,
      "e": 21891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22002,
      "e": 21954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 22105,
      "e": 22057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22106,
      "e": 22058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22186,
      "e": 22138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22242,
      "e": 22194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22244,
      "e": 22196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22321,
      "e": 22273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22337,
      "e": 22289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22337,
      "e": 22289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22433,
      "e": 22385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22714,
      "e": 22666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22716,
      "e": 22668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22858,
      "e": 22810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22882,
      "e": 22834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22883,
      "e": 22835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22963,
      "e": 22915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22986,
      "e": 22938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22989,
      "e": 22941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23057,
      "e": 23009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23073,
      "e": 23025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23074,
      "e": 23026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23138,
      "e": 23090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23178,
      "e": 23130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23178,
      "e": 23130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23218,
      "e": 23170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23218,
      "e": 23170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23249,
      "e": 23201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 23282,
      "e": 23234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23371,
      "e": 23323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23373,
      "e": 23325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23450,
      "e": 23402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23811,
      "e": 23763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 23811,
      "e": 23763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23898,
      "e": 23850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 24003,
      "e": 23955,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 1"
    },
    {
      "t": 24018,
      "e": 23970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 24019,
      "e": 23971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24089,
      "e": 24041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 24169,
      "e": 24121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24170,
      "e": 24122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24274,
      "e": 24226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24906,
      "e": 24858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24907,
      "e": 24859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24971,
      "e": 24923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 25122,
      "e": 25074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25123,
      "e": 25075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25233,
      "e": 25185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25234,
      "e": 25186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25274,
      "e": 25226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 25322,
      "e": 25274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25642,
      "e": 25594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25644,
      "e": 25596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25722,
      "e": 25674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25754,
      "e": 25706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25755,
      "e": 25707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25833,
      "e": 25785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26323,
      "e": 26275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26324,
      "e": 26276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26386,
      "e": 26338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26458,
      "e": 26410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 26458,
      "e": 26410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26513,
      "e": 26465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26514,
      "e": 26466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26562,
      "e": 26514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 26634,
      "e": 26586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27003,
      "e": 26955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27003,
      "e": 26955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27121,
      "e": 27073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27250,
      "e": 27202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27251,
      "e": 27203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27314,
      "e": 27266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27370,
      "e": 27322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27370,
      "e": 27322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27466,
      "e": 27418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27571,
      "e": 27523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27571,
      "e": 27523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27657,
      "e": 27609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28402,
      "e": 28354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 28403,
      "e": 28355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28489,
      "e": 28441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 28593,
      "e": 28545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28594,
      "e": 28546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28658,
      "e": 28610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28787,
      "e": 28739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28787,
      "e": 28739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28841,
      "e": 28739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28921,
      "e": 28819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28922,
      "e": 28820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29001,
      "e": 28899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 29009,
      "e": 28907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29010,
      "e": 28908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29074,
      "e": 28972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29204,
      "e": 29102,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and folle"
    },
    {
      "t": 29666,
      "e": 29564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29729,
      "e": 29627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and foll"
    },
    {
      "t": 29914,
      "e": 29812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29915,
      "e": 29813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29986,
      "e": 29884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29994,
      "e": 29892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 29995,
      "e": 29893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30098,
      "e": 29996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30098,
      "e": 29996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30130,
      "e": 30028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||we"
    },
    {
      "t": 30233,
      "e": 30131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30234,
      "e": 30132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30241,
      "e": 30139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 30362,
      "e": 30260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30522,
      "e": 30420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30523,
      "e": 30421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30585,
      "e": 30483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 30738,
      "e": 30636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30794,
      "e": 30692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and follower"
    },
    {
      "t": 30874,
      "e": 30772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30930,
      "e": 30828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and followe"
    },
    {
      "t": 31035,
      "e": 30933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31035,
      "e": 30933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31105,
      "e": 31003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31161,
      "e": 31059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31161,
      "e": 31059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31266,
      "e": 31164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31338,
      "e": 31236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31339,
      "e": 31237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31417,
      "e": 31315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 32378,
      "e": 32276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32379,
      "e": 32277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32450,
      "e": 32348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32457,
      "e": 32355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32458,
      "e": 32356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32529,
      "e": 32427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32561,
      "e": 32459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32561,
      "e": 32459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32642,
      "e": 32540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32642,
      "e": 32540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32705,
      "e": 32603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 32769,
      "e": 32667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33178,
      "e": 33076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33179,
      "e": 33077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33266,
      "e": 33164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33433,
      "e": 33331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 33435,
      "e": 33333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33505,
      "e": 33403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33505,
      "e": 33403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33530,
      "e": 33428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 33609,
      "e": 33507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34090,
      "e": 33988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34090,
      "e": 33988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34145,
      "e": 34043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34186,
      "e": 34084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 34186,
      "e": 34084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34249,
      "e": 34147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 34266,
      "e": 34164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34266,
      "e": 34164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34321,
      "e": 34219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34402,
      "e": 34300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34403,
      "e": 34301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34506,
      "e": 34404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34769,
      "e": 34667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34771,
      "e": 34669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34849,
      "e": 34747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 35010,
      "e": 34908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35011,
      "e": 34909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35081,
      "e": 34979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 35203,
      "e": 35101,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and followed with my eye up"
    },
    {
      "t": 35506,
      "e": 35404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 35507,
      "e": 35405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35553,
      "e": 35451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 35697,
      "e": 35595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35698,
      "e": 35596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35770,
      "e": 35668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35842,
      "e": 35740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35842,
      "e": 35740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35921,
      "e": 35819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36050,
      "e": 35819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36051,
      "e": 35820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36162,
      "e": 35931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36163,
      "e": 35932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36209,
      "e": 35978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 36281,
      "e": 36050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36361,
      "e": 36130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36362,
      "e": 36131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36458,
      "e": 36227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36618,
      "e": 36387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36618,
      "e": 36387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36706,
      "e": 36475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36778,
      "e": 36547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36778,
      "e": 36547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36842,
      "e": 36611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36938,
      "e": 36707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36938,
      "e": 36707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37009,
      "e": 36778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 37025,
      "e": 36794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37025,
      "e": 36794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37105,
      "e": 36874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37154,
      "e": 36923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37154,
      "e": 36923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37217,
      "e": 36986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37273,
      "e": 37042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37273,
      "e": 37042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37338,
      "e": 37107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 37345,
      "e": 37114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37347,
      "e": 37116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37402,
      "e": 37171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37458,
      "e": 37227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37458,
      "e": 37227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37546,
      "e": 37315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45967,
      "e": 42315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 45967,
      "e": 42315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46046,
      "e": 42394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46110,
      "e": 42458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46110,
      "e": 42458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46188,
      "e": 42536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 46293,
      "e": 42641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46293,
      "e": 42641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46333,
      "e": 42681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46469,
      "e": 42817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46470,
      "e": 42818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46533,
      "e": 42881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 46565,
      "e": 42913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46565,
      "e": 42913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46637,
      "e": 42985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46734,
      "e": 43082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46734,
      "e": 43082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46830,
      "e": 43178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 46862,
      "e": 43210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46862,
      "e": 43210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46956,
      "e": 43304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47205,
      "e": 43553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47205,
      "e": 43553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47293,
      "e": 43641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47317,
      "e": 43665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47318,
      "e": 43666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47390,
      "e": 43738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47390,
      "e": 43738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47397,
      "e": 43745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 47485,
      "e": 43833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47485,
      "e": 43833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47516,
      "e": 43864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47589,
      "e": 43937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47597,
      "e": 43945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47598,
      "e": 43946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47718,
      "e": 44066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48829,
      "e": 45177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48830,
      "e": 45178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48918,
      "e": 45266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48918,
      "e": 45266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48957,
      "e": 45305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fa"
    },
    {
      "t": 49021,
      "e": 45369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49061,
      "e": 45409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49061,
      "e": 45409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49133,
      "e": 45481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 49198,
      "e": 45546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49198,
      "e": 45546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49269,
      "e": 45617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49269,
      "e": 45617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49284,
      "e": 45632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 49381,
      "e": 45729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49854,
      "e": 46202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49854,
      "e": 46202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49917,
      "e": 46265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49941,
      "e": 46289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49942,
      "e": 46290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49988,
      "e": 46336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 50005,
      "e": 46353,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50108,
      "e": 46456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50108,
      "e": 46456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50157,
      "e": 46505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 50254,
      "e": 46602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50254,
      "e": 46602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50324,
      "e": 46672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50356,
      "e": 46704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 50356,
      "e": 46704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50421,
      "e": 46769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 50486,
      "e": 46834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50486,
      "e": 46834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50590,
      "e": 46938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51189,
      "e": 47537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 51190,
      "e": 47538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51262,
      "e": 47610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51397,
      "e": 47745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 51398,
      "e": 47746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51445,
      "e": 47793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51445,
      "e": 47793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51476,
      "e": 47824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 51532,
      "e": 47880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51637,
      "e": 47985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51637,
      "e": 47985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51712,
      "e": 48060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 51805,
      "e": 48153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 51805,
      "e": 48153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51876,
      "e": 48224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51932,
      "e": 48280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51933,
      "e": 48281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52021,
      "e": 48369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52076,
      "e": 48424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52077,
      "e": 48425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52140,
      "e": 48488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 52204,
      "e": 48552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52204,
      "e": 48552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52277,
      "e": 48625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52356,
      "e": 48704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52357,
      "e": 48705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52420,
      "e": 48768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52517,
      "e": 48865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52517,
      "e": 48865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52556,
      "e": 48904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52829,
      "e": 49177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52892,
      "e": 49240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and followed with my eye upwards all the points that fall along my imagin"
    },
    {
      "t": 52940,
      "e": 49288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52941,
      "e": 49289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53053,
      "e": 49401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53054,
      "e": 49402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53061,
      "e": 49409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 53133,
      "e": 49481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53244,
      "e": 49592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 53245,
      "e": 49593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53397,
      "e": 49745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 53445,
      "e": 49793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53446,
      "e": 49794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53468,
      "e": 49816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53606,
      "e": 49954,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and followed with my eye upwards all the points that fall along my imaginary "
    },
    {
      "t": 54718,
      "e": 51066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54718,
      "e": 51066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54788,
      "e": 51136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54829,
      "e": 51177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 54829,
      "e": 51177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54901,
      "e": 51249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 54949,
      "e": 51297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54949,
      "e": 51297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54972,
      "e": 51320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55414,
      "e": 51762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55414,
      "e": 51762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55501,
      "e": 51849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55580,
      "e": 51928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55581,
      "e": 51929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55661,
      "e": 52009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 55701,
      "e": 52049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 55702,
      "e": 52050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55757,
      "e": 52105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 55877,
      "e": 52225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55878,
      "e": 52226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55940,
      "e": 52288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55964,
      "e": 52312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55965,
      "e": 52313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56045,
      "e": 52393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56198,
      "e": 52546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 56199,
      "e": 52547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56294,
      "e": 52642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56294,
      "e": 52642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56308,
      "e": 52656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 56372,
      "e": 52720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56541,
      "e": 52889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 56542,
      "e": 52890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56613,
      "e": 52961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 57756,
      "e": 54104,
      "ty": 41,
      "x": 47144,
      "y": 26214,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 57805,
      "e": 54153,
      "ty": 2,
      "x": 1639,
      "y": 656
    },
    {
      "t": 57905,
      "e": 54253,
      "ty": 2,
      "x": 1674,
      "y": 719
    },
    {
      "t": 58005,
      "e": 54353,
      "ty": 2,
      "x": 901,
      "y": 664
    },
    {
      "t": 58005,
      "e": 54353,
      "ty": 41,
      "x": 8104,
      "y": 37673,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 58105,
      "e": 54453,
      "ty": 2,
      "x": 880,
      "y": 674
    },
    {
      "t": 58205,
      "e": 54553,
      "ty": 2,
      "x": 569,
      "y": 644
    },
    {
      "t": 58256,
      "e": 54604,
      "ty": 41,
      "x": 44728,
      "y": 36340,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 58266,
      "e": 54606,
      "ty": 6,
      "x": 453,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 58281,
      "e": 54621,
      "ty": 7,
      "x": 373,
      "y": 698,
      "ta": "#strategyButton"
    },
    {
      "t": 58305,
      "e": 54645,
      "ty": 2,
      "x": 346,
      "y": 706
    },
    {
      "t": 58405,
      "e": 54745,
      "ty": 2,
      "x": 333,
      "y": 708
    },
    {
      "t": 58497,
      "e": 54837,
      "ty": 6,
      "x": 342,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 58505,
      "e": 54845,
      "ty": 2,
      "x": 342,
      "y": 687
    },
    {
      "t": 58505,
      "e": 54845,
      "ty": 41,
      "x": 1860,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 58605,
      "e": 54945,
      "ty": 2,
      "x": 382,
      "y": 661
    },
    {
      "t": 58705,
      "e": 55045,
      "ty": 2,
      "x": 385,
      "y": 660
    },
    {
      "t": 58729,
      "e": 55069,
      "ty": 3,
      "x": 385,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 58729,
      "e": 55069,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I looked at the graph on the x-axis at the 12 pm mark and followed with my eye upwards all the points that fall along my imaginary eye line. \n"
    },
    {
      "t": 58729,
      "e": 55069,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58729,
      "e": 55069,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 58755,
      "e": 55095,
      "ty": 41,
      "x": 25343,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 58832,
      "e": 55172,
      "ty": 4,
      "x": 25343,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 58845,
      "e": 55185,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 58847,
      "e": 55187,
      "ty": 5,
      "x": 385,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 58852,
      "e": 55192,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 59205,
      "e": 55545,
      "ty": 2,
      "x": 485,
      "y": 581
    },
    {
      "t": 59255,
      "e": 55595,
      "ty": 41,
      "x": 17391,
      "y": 30136,
      "ta": "html > body"
    },
    {
      "t": 59304,
      "e": 55644,
      "ty": 2,
      "x": 523,
      "y": 536
    },
    {
      "t": 59406,
      "e": 55746,
      "ty": 2,
      "x": 529,
      "y": 522
    },
    {
      "t": 59505,
      "e": 55845,
      "ty": 2,
      "x": 531,
      "y": 516
    },
    {
      "t": 59506,
      "e": 55846,
      "ty": 41,
      "x": 18010,
      "y": 28141,
      "ta": "html > body"
    },
    {
      "t": 59854,
      "e": 56194,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 60305,
      "e": 56645,
      "ty": 2,
      "x": 545,
      "y": 515
    },
    {
      "t": 60405,
      "e": 56745,
      "ty": 2,
      "x": 789,
      "y": 530
    },
    {
      "t": 60505,
      "e": 56845,
      "ty": 2,
      "x": 825,
      "y": 551
    },
    {
      "t": 60506,
      "e": 56846,
      "ty": 41,
      "x": 3676,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 60516,
      "e": 56856,
      "ty": 6,
      "x": 836,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60548,
      "e": 56888,
      "ty": 7,
      "x": 860,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60605,
      "e": 56945,
      "ty": 2,
      "x": 862,
      "y": 579
    },
    {
      "t": 60704,
      "e": 57044,
      "ty": 2,
      "x": 867,
      "y": 576
    },
    {
      "t": 60717,
      "e": 57057,
      "ty": 6,
      "x": 869,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60755,
      "e": 57095,
      "ty": 41,
      "x": 14058,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60805,
      "e": 57145,
      "ty": 2,
      "x": 878,
      "y": 563
    },
    {
      "t": 60906,
      "e": 57246,
      "ty": 2,
      "x": 879,
      "y": 561
    },
    {
      "t": 60970,
      "e": 57310,
      "ty": 3,
      "x": 879,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60970,
      "e": 57310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61005,
      "e": 57345,
      "ty": 41,
      "x": 15356,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61090,
      "e": 57430,
      "ty": 4,
      "x": 15356,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61090,
      "e": 57430,
      "ty": 5,
      "x": 879,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61661,
      "e": 58001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 61662,
      "e": 58002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61765,
      "e": 58105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 61765,
      "e": 58105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61804,
      "e": 58144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 61861,
      "e": 58201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 61985,
      "e": 58325,
      "ty": 7,
      "x": 882,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62005,
      "e": 58345,
      "ty": 2,
      "x": 883,
      "y": 580
    },
    {
      "t": 62005,
      "e": 58345,
      "ty": 41,
      "x": 16221,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 62105,
      "e": 58445,
      "ty": 2,
      "x": 891,
      "y": 624
    },
    {
      "t": 62205,
      "e": 58545,
      "ty": 2,
      "x": 891,
      "y": 638
    },
    {
      "t": 62255,
      "e": 58595,
      "ty": 41,
      "x": 17951,
      "y": 40166,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 62305,
      "e": 58645,
      "ty": 2,
      "x": 891,
      "y": 640
    },
    {
      "t": 62405,
      "e": 58745,
      "ty": 2,
      "x": 891,
      "y": 641
    },
    {
      "t": 62452,
      "e": 58792,
      "ty": 6,
      "x": 891,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62505,
      "e": 58845,
      "ty": 2,
      "x": 891,
      "y": 652
    },
    {
      "t": 62505,
      "e": 58845,
      "ty": 41,
      "x": 17951,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62605,
      "e": 58945,
      "ty": 2,
      "x": 891,
      "y": 654
    },
    {
      "t": 62705,
      "e": 59045,
      "ty": 2,
      "x": 892,
      "y": 655
    },
    {
      "t": 62755,
      "e": 59095,
      "ty": 41,
      "x": 18168,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62809,
      "e": 59149,
      "ty": 3,
      "x": 892,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62811,
      "e": 59151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 62811,
      "e": 59151,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62812,
      "e": 59152,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62952,
      "e": 59292,
      "ty": 4,
      "x": 18168,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62952,
      "e": 59292,
      "ty": 5,
      "x": 892,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63965,
      "e": 60305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 64221,
      "e": 60561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 64222,
      "e": 60562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64317,
      "e": 60657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 64332,
      "e": 60672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 64332,
      "e": 60672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64421,
      "e": 60761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 64461,
      "e": 60801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 64462,
      "e": 60802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64573,
      "e": 60913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 64597,
      "e": 60937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 64749,
      "e": 61089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 64749,
      "e": 61089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64837,
      "e": 61177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA\n"
    },
    {
      "t": 66149,
      "e": 62489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 66212,
      "e": 62552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66937,
      "e": 63277,
      "ty": 7,
      "x": 905,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66955,
      "e": 63295,
      "ty": 6,
      "x": 908,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67005,
      "e": 63345,
      "ty": 2,
      "x": 912,
      "y": 701
    },
    {
      "t": 67006,
      "e": 63346,
      "ty": 41,
      "x": 8286,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67071,
      "e": 63411,
      "ty": 7,
      "x": 914,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67106,
      "e": 63446,
      "ty": 2,
      "x": 919,
      "y": 713
    },
    {
      "t": 67205,
      "e": 63545,
      "ty": 6,
      "x": 928,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67206,
      "e": 63546,
      "ty": 2,
      "x": 928,
      "y": 700
    },
    {
      "t": 67255,
      "e": 63595,
      "ty": 41,
      "x": 20655,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67305,
      "e": 63645,
      "ty": 2,
      "x": 936,
      "y": 686
    },
    {
      "t": 67345,
      "e": 63685,
      "ty": 3,
      "x": 936,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67345,
      "e": 63685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67345,
      "e": 63685,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67345,
      "e": 63685,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67457,
      "e": 63797,
      "ty": 4,
      "x": 20655,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67459,
      "e": 63799,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67459,
      "e": 63799,
      "ty": 5,
      "x": 936,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67460,
      "e": 63800,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 67906,
      "e": 64246,
      "ty": 2,
      "x": 960,
      "y": 694
    },
    {
      "t": 68005,
      "e": 64345,
      "ty": 2,
      "x": 1018,
      "y": 726
    },
    {
      "t": 68005,
      "e": 64345,
      "ty": 41,
      "x": 34782,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 68478,
      "e": 64818,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 69005,
      "e": 65345,
      "ty": 2,
      "x": 1018,
      "y": 392
    },
    {
      "t": 69006,
      "e": 65346,
      "ty": 41,
      "x": 46652,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 69106,
      "e": 65446,
      "ty": 2,
      "x": 1027,
      "y": 151
    },
    {
      "t": 69205,
      "e": 65545,
      "ty": 2,
      "x": 1021,
      "y": 106
    },
    {
      "t": 69256,
      "e": 65596,
      "ty": 41,
      "x": 32095,
      "y": 7700,
      "ta": "html > body"
    },
    {
      "t": 69305,
      "e": 65645,
      "ty": 2,
      "x": 883,
      "y": 195
    },
    {
      "t": 69406,
      "e": 65746,
      "ty": 2,
      "x": 891,
      "y": 220
    },
    {
      "t": 69505,
      "e": 65845,
      "ty": 2,
      "x": 897,
      "y": 230
    },
    {
      "t": 69505,
      "e": 65845,
      "ty": 41,
      "x": 61888,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69605,
      "e": 65945,
      "ty": 2,
      "x": 901,
      "y": 235
    },
    {
      "t": 69705,
      "e": 66045,
      "ty": 2,
      "x": 901,
      "y": 238
    },
    {
      "t": 69756,
      "e": 66096,
      "ty": 41,
      "x": 65163,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70005,
      "e": 66345,
      "ty": 2,
      "x": 900,
      "y": 240
    },
    {
      "t": 70006,
      "e": 66346,
      "ty": 41,
      "x": 64345,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70105,
      "e": 66445,
      "ty": 2,
      "x": 897,
      "y": 242
    },
    {
      "t": 70160,
      "e": 66500,
      "ty": 3,
      "x": 897,
      "y": 242,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70256,
      "e": 66596,
      "ty": 41,
      "x": 61888,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70296,
      "e": 66636,
      "ty": 4,
      "x": 61888,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70296,
      "e": 66636,
      "ty": 5,
      "x": 897,
      "y": 242,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70296,
      "e": 66636,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70297,
      "e": 66637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 70705,
      "e": 67045,
      "ty": 2,
      "x": 884,
      "y": 240
    },
    {
      "t": 70756,
      "e": 67096,
      "ty": 41,
      "x": 48786,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70806,
      "e": 67146,
      "ty": 2,
      "x": 881,
      "y": 238
    },
    {
      "t": 70817,
      "e": 67157,
      "ty": 3,
      "x": 881,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70818,
      "e": 67158,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70945,
      "e": 67285,
      "ty": 4,
      "x": 48786,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70945,
      "e": 67285,
      "ty": 5,
      "x": 881,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70945,
      "e": 67285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71505,
      "e": 67845,
      "ty": 2,
      "x": 863,
      "y": 354
    },
    {
      "t": 71505,
      "e": 67845,
      "ty": 41,
      "x": 9867,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 71606,
      "e": 67946,
      "ty": 2,
      "x": 858,
      "y": 395
    },
    {
      "t": 71706,
      "e": 68046,
      "ty": 2,
      "x": 856,
      "y": 405
    },
    {
      "t": 71756,
      "e": 68096,
      "ty": 41,
      "x": 40476,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71805,
      "e": 68145,
      "ty": 2,
      "x": 856,
      "y": 409
    },
    {
      "t": 71905,
      "e": 68245,
      "ty": 2,
      "x": 857,
      "y": 443
    },
    {
      "t": 72006,
      "e": 68346,
      "ty": 2,
      "x": 857,
      "y": 466
    },
    {
      "t": 72006,
      "e": 68346,
      "ty": 41,
      "x": 37606,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 72106,
      "e": 68446,
      "ty": 2,
      "x": 857,
      "y": 484
    },
    {
      "t": 72205,
      "e": 68545,
      "ty": 2,
      "x": 857,
      "y": 499
    },
    {
      "t": 72255,
      "e": 68595,
      "ty": 41,
      "x": 31933,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72306,
      "e": 68646,
      "ty": 2,
      "x": 857,
      "y": 505
    },
    {
      "t": 72405,
      "e": 68745,
      "ty": 2,
      "x": 855,
      "y": 473
    },
    {
      "t": 72505,
      "e": 68845,
      "ty": 2,
      "x": 855,
      "y": 462
    },
    {
      "t": 72506,
      "e": 68846,
      "ty": 41,
      "x": 35492,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 72606,
      "e": 68946,
      "ty": 2,
      "x": 855,
      "y": 460
    },
    {
      "t": 72633,
      "e": 68973,
      "ty": 3,
      "x": 855,
      "y": 460,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 72635,
      "e": 68975,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72755,
      "e": 69095,
      "ty": 41,
      "x": 7968,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 72760,
      "e": 69100,
      "ty": 4,
      "x": 7968,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 72760,
      "e": 69100,
      "ty": 5,
      "x": 855,
      "y": 460,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 72906,
      "e": 69246,
      "ty": 2,
      "x": 855,
      "y": 464
    },
    {
      "t": 73006,
      "e": 69346,
      "ty": 2,
      "x": 856,
      "y": 470
    },
    {
      "t": 73006,
      "e": 69346,
      "ty": 41,
      "x": 36549,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73033,
      "e": 69373,
      "ty": 3,
      "x": 856,
      "y": 470,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73153,
      "e": 69493,
      "ty": 4,
      "x": 36549,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73154,
      "e": 69494,
      "ty": 5,
      "x": 856,
      "y": 470,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73154,
      "e": 69494,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 73156,
      "e": 69496,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 73605,
      "e": 69945,
      "ty": 2,
      "x": 846,
      "y": 459
    },
    {
      "t": 73706,
      "e": 70046,
      "ty": 2,
      "x": 866,
      "y": 465
    },
    {
      "t": 73757,
      "e": 70047,
      "ty": 41,
      "x": 20309,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 73805,
      "e": 70095,
      "ty": 2,
      "x": 948,
      "y": 569
    },
    {
      "t": 73905,
      "e": 70195,
      "ty": 2,
      "x": 972,
      "y": 640
    },
    {
      "t": 74005,
      "e": 70295,
      "ty": 2,
      "x": 972,
      "y": 650
    },
    {
      "t": 74005,
      "e": 70295,
      "ty": 41,
      "x": 35735,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 74106,
      "e": 70396,
      "ty": 2,
      "x": 957,
      "y": 661
    },
    {
      "t": 74206,
      "e": 70496,
      "ty": 2,
      "x": 945,
      "y": 664
    },
    {
      "t": 74255,
      "e": 70545,
      "ty": 41,
      "x": 29328,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 74305,
      "e": 70595,
      "ty": 2,
      "x": 942,
      "y": 667
    },
    {
      "t": 74405,
      "e": 70695,
      "ty": 2,
      "x": 920,
      "y": 691
    },
    {
      "t": 74506,
      "e": 70796,
      "ty": 2,
      "x": 907,
      "y": 711
    },
    {
      "t": 74506,
      "e": 70796,
      "ty": 41,
      "x": 21564,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74606,
      "e": 70896,
      "ty": 2,
      "x": 887,
      "y": 728
    },
    {
      "t": 74755,
      "e": 71045,
      "ty": 41,
      "x": 16459,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 75606,
      "e": 71896,
      "ty": 2,
      "x": 881,
      "y": 744
    },
    {
      "t": 75706,
      "e": 71996,
      "ty": 2,
      "x": 879,
      "y": 753
    },
    {
      "t": 75756,
      "e": 72046,
      "ty": 41,
      "x": 23190,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 75806,
      "e": 72096,
      "ty": 2,
      "x": 876,
      "y": 773
    },
    {
      "t": 75906,
      "e": 72196,
      "ty": 2,
      "x": 871,
      "y": 799
    },
    {
      "t": 76005,
      "e": 72295,
      "ty": 2,
      "x": 868,
      "y": 814
    },
    {
      "t": 76005,
      "e": 72295,
      "ty": 41,
      "x": 27492,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 76206,
      "e": 72496,
      "ty": 2,
      "x": 865,
      "y": 763
    },
    {
      "t": 76255,
      "e": 72545,
      "ty": 41,
      "x": 17765,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 76305,
      "e": 72595,
      "ty": 2,
      "x": 864,
      "y": 754
    },
    {
      "t": 76405,
      "e": 72695,
      "ty": 2,
      "x": 864,
      "y": 737
    },
    {
      "t": 76505,
      "e": 72795,
      "ty": 2,
      "x": 861,
      "y": 728
    },
    {
      "t": 76506,
      "e": 72796,
      "ty": 41,
      "x": 9933,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76605,
      "e": 72895,
      "ty": 2,
      "x": 861,
      "y": 727
    },
    {
      "t": 76649,
      "e": 72939,
      "ty": 3,
      "x": 861,
      "y": 727,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76650,
      "e": 72940,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 76755,
      "e": 73045,
      "ty": 41,
      "x": 9933,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76808,
      "e": 73098,
      "ty": 4,
      "x": 9933,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76808,
      "e": 73098,
      "ty": 5,
      "x": 861,
      "y": 727,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76809,
      "e": 73099,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 76809,
      "e": 73099,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 77904,
      "e": 74194,
      "ty": 2,
      "x": 886,
      "y": 691
    },
    {
      "t": 78005,
      "e": 74295,
      "ty": 2,
      "x": 892,
      "y": 678
    },
    {
      "t": 78005,
      "e": 74295,
      "ty": 41,
      "x": 18950,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 78104,
      "e": 74394,
      "ty": 2,
      "x": 894,
      "y": 669
    },
    {
      "t": 78205,
      "e": 74495,
      "ty": 2,
      "x": 897,
      "y": 647
    },
    {
      "t": 78255,
      "e": 74545,
      "ty": 41,
      "x": 17936,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 78305,
      "e": 74595,
      "ty": 2,
      "x": 897,
      "y": 640
    },
    {
      "t": 78605,
      "e": 74895,
      "ty": 2,
      "x": 897,
      "y": 642
    },
    {
      "t": 78704,
      "e": 74994,
      "ty": 2,
      "x": 894,
      "y": 654
    },
    {
      "t": 78755,
      "e": 75045,
      "ty": 41,
      "x": 16749,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 78805,
      "e": 75095,
      "ty": 2,
      "x": 888,
      "y": 664
    },
    {
      "t": 78905,
      "e": 75195,
      "ty": 2,
      "x": 884,
      "y": 685
    },
    {
      "t": 79005,
      "e": 75295,
      "ty": 2,
      "x": 884,
      "y": 698
    },
    {
      "t": 79005,
      "e": 75295,
      "ty": 41,
      "x": 15768,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79105,
      "e": 75395,
      "ty": 2,
      "x": 883,
      "y": 706
    },
    {
      "t": 79204,
      "e": 75494,
      "ty": 2,
      "x": 883,
      "y": 712
    },
    {
      "t": 79256,
      "e": 75495,
      "ty": 41,
      "x": 14139,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 79304,
      "e": 75543,
      "ty": 2,
      "x": 881,
      "y": 736
    },
    {
      "t": 79405,
      "e": 75644,
      "ty": 2,
      "x": 881,
      "y": 760
    },
    {
      "t": 79505,
      "e": 75744,
      "ty": 2,
      "x": 881,
      "y": 761
    },
    {
      "t": 79505,
      "e": 75744,
      "ty": 41,
      "x": 24859,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 80986,
      "e": 77225,
      "ty": 3,
      "x": 881,
      "y": 761,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 80987,
      "e": 77226,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 81112,
      "e": 77351,
      "ty": 4,
      "x": 24859,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 81112,
      "e": 77351,
      "ty": 5,
      "x": 881,
      "y": 761,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 81112,
      "e": 77351,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 81113,
      "e": 77352,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 82405,
      "e": 78644,
      "ty": 2,
      "x": 880,
      "y": 751
    },
    {
      "t": 82505,
      "e": 78744,
      "ty": 41,
      "x": 24441,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 82605,
      "e": 78844,
      "ty": 2,
      "x": 880,
      "y": 747
    },
    {
      "t": 82705,
      "e": 78944,
      "ty": 2,
      "x": 880,
      "y": 708
    },
    {
      "t": 82755,
      "e": 78994,
      "ty": 41,
      "x": 14614,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 82805,
      "e": 79044,
      "ty": 2,
      "x": 886,
      "y": 672
    },
    {
      "t": 82905,
      "e": 79144,
      "ty": 2,
      "x": 888,
      "y": 666
    },
    {
      "t": 83005,
      "e": 79244,
      "ty": 41,
      "x": 17876,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83105,
      "e": 79344,
      "ty": 2,
      "x": 889,
      "y": 681
    },
    {
      "t": 83204,
      "e": 79443,
      "ty": 2,
      "x": 889,
      "y": 701
    },
    {
      "t": 83255,
      "e": 79494,
      "ty": 41,
      "x": 17028,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 83305,
      "e": 79544,
      "ty": 2,
      "x": 889,
      "y": 718
    },
    {
      "t": 83404,
      "e": 79643,
      "ty": 2,
      "x": 888,
      "y": 731
    },
    {
      "t": 83505,
      "e": 79744,
      "ty": 2,
      "x": 884,
      "y": 748
    },
    {
      "t": 83505,
      "e": 79744,
      "ty": 41,
      "x": 14851,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 83605,
      "e": 79844,
      "ty": 2,
      "x": 882,
      "y": 760
    },
    {
      "t": 83705,
      "e": 79944,
      "ty": 2,
      "x": 881,
      "y": 771
    },
    {
      "t": 83755,
      "e": 79994,
      "ty": 41,
      "x": 13902,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 83805,
      "e": 80044,
      "ty": 2,
      "x": 880,
      "y": 779
    },
    {
      "t": 83905,
      "e": 80144,
      "ty": 2,
      "x": 879,
      "y": 795
    },
    {
      "t": 84005,
      "e": 80244,
      "ty": 2,
      "x": 879,
      "y": 812
    },
    {
      "t": 84005,
      "e": 80244,
      "ty": 41,
      "x": 33984,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 84105,
      "e": 80344,
      "ty": 2,
      "x": 881,
      "y": 825
    },
    {
      "t": 84205,
      "e": 80444,
      "ty": 2,
      "x": 882,
      "y": 830
    },
    {
      "t": 84255,
      "e": 80494,
      "ty": 41,
      "x": 14376,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 84305,
      "e": 80544,
      "ty": 2,
      "x": 882,
      "y": 831
    },
    {
      "t": 84605,
      "e": 80844,
      "ty": 2,
      "x": 880,
      "y": 756
    },
    {
      "t": 84705,
      "e": 80944,
      "ty": 2,
      "x": 881,
      "y": 753
    },
    {
      "t": 84756,
      "e": 80995,
      "ty": 41,
      "x": 24859,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 85605,
      "e": 81844,
      "ty": 2,
      "x": 881,
      "y": 738
    },
    {
      "t": 85755,
      "e": 81994,
      "ty": 41,
      "x": 14953,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 85805,
      "e": 82044,
      "ty": 2,
      "x": 881,
      "y": 733
    },
    {
      "t": 85904,
      "e": 82143,
      "ty": 2,
      "x": 881,
      "y": 722
    },
    {
      "t": 85961,
      "e": 82200,
      "ty": 3,
      "x": 881,
      "y": 722,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 85962,
      "e": 82201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 86005,
      "e": 82244,
      "ty": 41,
      "x": 14953,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86072,
      "e": 82311,
      "ty": 4,
      "x": 14953,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86072,
      "e": 82311,
      "ty": 5,
      "x": 881,
      "y": 722,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86073,
      "e": 82312,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 86073,
      "e": 82312,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 86605,
      "e": 82844,
      "ty": 2,
      "x": 879,
      "y": 762
    },
    {
      "t": 86705,
      "e": 82944,
      "ty": 2,
      "x": 879,
      "y": 829
    },
    {
      "t": 86755,
      "e": 82994,
      "ty": 41,
      "x": 14139,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 86805,
      "e": 83044,
      "ty": 2,
      "x": 883,
      "y": 870
    },
    {
      "t": 86905,
      "e": 83144,
      "ty": 2,
      "x": 881,
      "y": 886
    },
    {
      "t": 87005,
      "e": 83244,
      "ty": 2,
      "x": 872,
      "y": 913
    },
    {
      "t": 87005,
      "e": 83244,
      "ty": 41,
      "x": 12003,
      "y": 19156,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 87105,
      "e": 83344,
      "ty": 2,
      "x": 868,
      "y": 935
    },
    {
      "t": 87255,
      "e": 83494,
      "ty": 41,
      "x": 50874,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 87405,
      "e": 83644,
      "ty": 2,
      "x": 864,
      "y": 961
    },
    {
      "t": 87505,
      "e": 83744,
      "ty": 2,
      "x": 864,
      "y": 962
    },
    {
      "t": 87505,
      "e": 83744,
      "ty": 41,
      "x": 34442,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87576,
      "e": 83815,
      "ty": 3,
      "x": 864,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87577,
      "e": 83816,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 87720,
      "e": 83959,
      "ty": 4,
      "x": 34442,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87721,
      "e": 83960,
      "ty": 5,
      "x": 864,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87722,
      "e": 83961,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87724,
      "e": 83963,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 87871,
      "e": 83963,
      "ty": 6,
      "x": 872,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87905,
      "e": 83997,
      "ty": 2,
      "x": 879,
      "y": 1036
    },
    {
      "t": 88005,
      "e": 84097,
      "ty": 2,
      "x": 880,
      "y": 1036
    },
    {
      "t": 88006,
      "e": 84098,
      "ty": 41,
      "x": 26067,
      "y": 61563,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88205,
      "e": 84297,
      "ty": 2,
      "x": 876,
      "y": 1036
    },
    {
      "t": 88255,
      "e": 84347,
      "ty": 41,
      "x": 23490,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88289,
      "e": 84381,
      "ty": 3,
      "x": 875,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88291,
      "e": 84383,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 88291,
      "e": 84383,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88305,
      "e": 84397,
      "ty": 2,
      "x": 875,
      "y": 1029
    },
    {
      "t": 88416,
      "e": 84508,
      "ty": 4,
      "x": 23490,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88416,
      "e": 84508,
      "ty": 5,
      "x": 875,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88419,
      "e": 84511,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88420,
      "e": 84512,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 88420,
      "e": 84512,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 89105,
      "e": 85197,
      "ty": 2,
      "x": 873,
      "y": 1028
    },
    {
      "t": 89255,
      "e": 85347,
      "ty": 41,
      "x": 29788,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 89405,
      "e": 85497,
      "ty": 2,
      "x": 873,
      "y": 1027
    },
    {
      "t": 89505,
      "e": 85597,
      "ty": 2,
      "x": 872,
      "y": 1026
    },
    {
      "t": 89505,
      "e": 85597,
      "ty": 41,
      "x": 29754,
      "y": 56394,
      "ta": "html > body"
    },
    {
      "t": 89757,
      "e": 85849,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 90905,
      "e": 86997,
      "ty": 2,
      "x": 884,
      "y": 988
    },
    {
      "t": 91005,
      "e": 87097,
      "ty": 2,
      "x": 928,
      "y": 932
    },
    {
      "t": 91006,
      "e": 87098,
      "ty": 41,
      "x": 31217,
      "y": 55792,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91105,
      "e": 87197,
      "ty": 2,
      "x": 945,
      "y": 909
    },
    {
      "t": 91205,
      "e": 87297,
      "ty": 2,
      "x": 946,
      "y": 904
    },
    {
      "t": 91255,
      "e": 87347,
      "ty": 41,
      "x": 32349,
      "y": 36314,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91305,
      "e": 87397,
      "ty": 2,
      "x": 971,
      "y": 837
    },
    {
      "t": 91405,
      "e": 87497,
      "ty": 2,
      "x": 989,
      "y": 774
    },
    {
      "t": 91505,
      "e": 87597,
      "ty": 2,
      "x": 995,
      "y": 702
    },
    {
      "t": 91505,
      "e": 87597,
      "ty": 41,
      "x": 34513,
      "y": 19611,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 91605,
      "e": 87697,
      "ty": 2,
      "x": 996,
      "y": 651
    },
    {
      "t": 91705,
      "e": 87797,
      "ty": 2,
      "x": 996,
      "y": 777
    },
    {
      "t": 91755,
      "e": 87847,
      "ty": 41,
      "x": 34513,
      "y": 31633,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91805,
      "e": 87897,
      "ty": 2,
      "x": 983,
      "y": 966
    },
    {
      "t": 91905,
      "e": 87997,
      "ty": 2,
      "x": 971,
      "y": 1063
    },
    {
      "t": 92006,
      "e": 88098,
      "ty": 41,
      "x": 33333,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92192,
      "e": 88284,
      "ty": 6,
      "x": 972,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 92205,
      "e": 88297,
      "ty": 2,
      "x": 972,
      "y": 1073
    },
    {
      "t": 92255,
      "e": 88347,
      "ty": 41,
      "x": 35771,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 92305,
      "e": 88397,
      "ty": 2,
      "x": 975,
      "y": 1087
    },
    {
      "t": 92405,
      "e": 88497,
      "ty": 2,
      "x": 976,
      "y": 1092
    },
    {
      "t": 92425,
      "e": 88517,
      "ty": 3,
      "x": 976,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 92426,
      "e": 88518,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92506,
      "e": 88598,
      "ty": 41,
      "x": 36317,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 92537,
      "e": 88629,
      "ty": 4,
      "x": 36317,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 92538,
      "e": 88630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92539,
      "e": 88631,
      "ty": 5,
      "x": 976,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 92540,
      "e": 88632,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 93586,
      "e": 89678,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 94905,
      "e": 90997,
      "ty": 2,
      "x": 1069,
      "y": 604
    },
    {
      "t": 95005,
      "e": 91097,
      "ty": 2,
      "x": 1203,
      "y": 169
    },
    {
      "t": 95005,
      "e": 91097,
      "ty": 41,
      "x": 40829,
      "y": 32697,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 95105,
      "e": 91197,
      "ty": 2,
      "x": 1167,
      "y": 109
    },
    {
      "t": 95205,
      "e": 91297,
      "ty": 2,
      "x": 1123,
      "y": 55
    },
    {
      "t": 95255,
      "e": 91347,
      "ty": 41,
      "x": 36194,
      "y": 32673,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 95305,
      "e": 91397,
      "ty": 2,
      "x": 1009,
      "y": 16
    },
    {
      "t": 95405,
      "e": 91497,
      "ty": 2,
      "x": 988,
      "y": 16
    },
    {
      "t": 95506,
      "e": 91598,
      "ty": 2,
      "x": 617,
      "y": 16
    },
    {
      "t": 95506,
      "e": 91598,
      "ty": 41,
      "x": 21426,
      "y": 32673,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 95605,
      "e": 91697,
      "ty": 2,
      "x": 389,
      "y": 51
    },
    {
      "t": 95636,
      "e": 91728,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 46640, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 46646, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 29770, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 77503, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12789, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 91296, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14589, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 106976, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17342, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 125322, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 28421, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 154977, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-11 AM-01 PM-04 PM-05 PM-11 AM-A -11 AM-A -A -D -4\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1034,y:1006,t:1527872952547};\\\", \\\"{x:1052,y:1000,t:1527872952562};\\\", \\\"{x:1165,y:982,t:1527872952579};\\\", \\\"{x:1271,y:982,t:1527872952596};\\\", \\\"{x:1403,y:982,t:1527872952613};\\\", \\\"{x:1522,y:982,t:1527872952628};\\\", \\\"{x:1611,y:982,t:1527872952646};\\\", \\\"{x:1664,y:982,t:1527872952662};\\\", \\\"{x:1686,y:982,t:1527872952678};\\\", \\\"{x:1688,y:982,t:1527872952695};\\\", \\\"{x:1683,y:982,t:1527872952802};\\\", \\\"{x:1674,y:977,t:1527872952812};\\\", \\\"{x:1663,y:971,t:1527872952828};\\\", \\\"{x:1646,y:965,t:1527872952846};\\\", \\\"{x:1616,y:954,t:1527872952862};\\\", \\\"{x:1557,y:935,t:1527872952878};\\\", \\\"{x:1485,y:919,t:1527872952895};\\\", \\\"{x:1419,y:919,t:1527872952912};\\\", \\\"{x:1368,y:919,t:1527872952928};\\\", \\\"{x:1344,y:922,t:1527872952945};\\\", \\\"{x:1320,y:931,t:1527872952962};\\\", \\\"{x:1313,y:937,t:1527872952978};\\\", \\\"{x:1305,y:949,t:1527872952994};\\\", \\\"{x:1298,y:960,t:1527872953011};\\\", \\\"{x:1292,y:969,t:1527872953029};\\\", \\\"{x:1289,y:973,t:1527872953044};\\\", \\\"{x:1284,y:978,t:1527872953062};\\\", \\\"{x:1282,y:980,t:1527872953078};\\\", \\\"{x:1282,y:981,t:1527872953094};\\\", \\\"{x:1281,y:970,t:1527872953482};\\\", \\\"{x:1281,y:955,t:1527872953496};\\\", \\\"{x:1281,y:929,t:1527872953512};\\\", \\\"{x:1281,y:902,t:1527872953529};\\\", \\\"{x:1278,y:872,t:1527872953546};\\\", \\\"{x:1276,y:858,t:1527872953562};\\\", \\\"{x:1272,y:846,t:1527872953579};\\\", \\\"{x:1267,y:829,t:1527872953596};\\\", \\\"{x:1265,y:815,t:1527872953612};\\\", \\\"{x:1265,y:809,t:1527872953629};\\\", \\\"{x:1265,y:804,t:1527872953646};\\\", \\\"{x:1265,y:802,t:1527872953662};\\\", \\\"{x:1265,y:798,t:1527872953680};\\\", \\\"{x:1264,y:793,t:1527872953697};\\\", \\\"{x:1263,y:788,t:1527872953712};\\\", \\\"{x:1263,y:785,t:1527872953730};\\\", \\\"{x:1263,y:784,t:1527872953746};\\\", \\\"{x:1263,y:789,t:1527872953971};\\\", \\\"{x:1264,y:795,t:1527872953979};\\\", \\\"{x:1270,y:805,t:1527872953996};\\\", \\\"{x:1278,y:815,t:1527872954013};\\\", \\\"{x:1286,y:822,t:1527872954030};\\\", \\\"{x:1300,y:827,t:1527872954046};\\\", \\\"{x:1308,y:831,t:1527872954063};\\\", \\\"{x:1315,y:832,t:1527872954079};\\\", \\\"{x:1322,y:832,t:1527872954096};\\\", \\\"{x:1327,y:832,t:1527872954113};\\\", \\\"{x:1328,y:832,t:1527872954129};\\\", \\\"{x:1328,y:827,t:1527872954147};\\\", \\\"{x:1328,y:810,t:1527872954163};\\\", \\\"{x:1302,y:775,t:1527872954179};\\\", \\\"{x:1247,y:731,t:1527872954197};\\\", \\\"{x:1150,y:682,t:1527872954213};\\\", \\\"{x:1029,y:636,t:1527872954229};\\\", \\\"{x:901,y:593,t:1527872954248};\\\", \\\"{x:776,y:555,t:1527872954265};\\\", \\\"{x:676,y:525,t:1527872954279};\\\", \\\"{x:572,y:502,t:1527872954313};\\\", \\\"{x:552,y:498,t:1527872954329};\\\", \\\"{x:527,y:494,t:1527872954346};\\\", \\\"{x:503,y:491,t:1527872954363};\\\", \\\"{x:479,y:489,t:1527872954379};\\\", \\\"{x:459,y:486,t:1527872954397};\\\", \\\"{x:445,y:486,t:1527872954413};\\\", \\\"{x:437,y:486,t:1527872954429};\\\", \\\"{x:433,y:486,t:1527872954446};\\\", \\\"{x:431,y:487,t:1527872954464};\\\", \\\"{x:429,y:487,t:1527872954479};\\\", \\\"{x:427,y:489,t:1527872954497};\\\", \\\"{x:425,y:489,t:1527872954522};\\\", \\\"{x:424,y:490,t:1527872954530};\\\", \\\"{x:420,y:492,t:1527872954547};\\\", \\\"{x:416,y:494,t:1527872954564};\\\", \\\"{x:410,y:497,t:1527872954580};\\\", \\\"{x:407,y:498,t:1527872954596};\\\", \\\"{x:404,y:499,t:1527872954614};\\\", \\\"{x:400,y:500,t:1527872954629};\\\", \\\"{x:395,y:502,t:1527872954647};\\\", \\\"{x:387,y:505,t:1527872954664};\\\", \\\"{x:378,y:507,t:1527872954681};\\\", \\\"{x:364,y:511,t:1527872954696};\\\", \\\"{x:354,y:512,t:1527872954712};\\\", \\\"{x:346,y:514,t:1527872954729};\\\", \\\"{x:342,y:515,t:1527872954747};\\\", \\\"{x:339,y:516,t:1527872954763};\\\", \\\"{x:335,y:517,t:1527872954780};\\\", \\\"{x:332,y:518,t:1527872954797};\\\", \\\"{x:328,y:520,t:1527872954813};\\\", \\\"{x:328,y:521,t:1527872954830};\\\", \\\"{x:326,y:521,t:1527872954847};\\\", \\\"{x:325,y:522,t:1527872954906};\\\", \\\"{x:325,y:524,t:1527872954914};\\\", \\\"{x:325,y:526,t:1527872954930};\\\", \\\"{x:328,y:529,t:1527872954947};\\\", \\\"{x:335,y:534,t:1527872954963};\\\", \\\"{x:342,y:536,t:1527872954980};\\\", \\\"{x:347,y:537,t:1527872954997};\\\", \\\"{x:358,y:537,t:1527872955012};\\\", \\\"{x:369,y:537,t:1527872955030};\\\", \\\"{x:378,y:537,t:1527872955046};\\\", \\\"{x:381,y:537,t:1527872955064};\\\", \\\"{x:382,y:537,t:1527872955080};\\\", \\\"{x:385,y:534,t:1527872955180};\\\", \\\"{x:388,y:530,t:1527872955197};\\\", \\\"{x:389,y:529,t:1527872955213};\\\", \\\"{x:390,y:528,t:1527872955249};\\\", \\\"{x:391,y:527,t:1527872956058};\\\", \\\"{x:404,y:522,t:1527872956067};\\\", \\\"{x:448,y:494,t:1527872956083};\\\", \\\"{x:484,y:472,t:1527872956098};\\\", \\\"{x:506,y:462,t:1527872956114};\\\", \\\"{x:524,y:455,t:1527872956131};\\\", \\\"{x:534,y:450,t:1527872956147};\\\", \\\"{x:543,y:446,t:1527872956164};\\\", \\\"{x:551,y:442,t:1527872956181};\\\", \\\"{x:555,y:441,t:1527872956197};\\\", \\\"{x:559,y:441,t:1527872956214};\\\", \\\"{x:561,y:441,t:1527872956232};\\\", \\\"{x:565,y:441,t:1527872956247};\\\", \\\"{x:567,y:441,t:1527872956265};\\\", \\\"{x:569,y:441,t:1527872956370};\\\", \\\"{x:569,y:443,t:1527872956382};\\\", \\\"{x:570,y:449,t:1527872956398};\\\", \\\"{x:573,y:454,t:1527872956415};\\\", \\\"{x:573,y:458,t:1527872956432};\\\", \\\"{x:573,y:459,t:1527872956448};\\\", \\\"{x:574,y:460,t:1527872956465};\\\", \\\"{x:580,y:460,t:1527872957114};\\\", \\\"{x:590,y:460,t:1527872957122};\\\", \\\"{x:602,y:458,t:1527872957132};\\\", \\\"{x:648,y:455,t:1527872957149};\\\", \\\"{x:725,y:455,t:1527872957166};\\\", \\\"{x:809,y:455,t:1527872957182};\\\", \\\"{x:889,y:455,t:1527872957199};\\\", \\\"{x:956,y:455,t:1527872957217};\\\", \\\"{x:1030,y:459,t:1527872957232};\\\", \\\"{x:1101,y:476,t:1527872957249};\\\", \\\"{x:1195,y:499,t:1527872957266};\\\", \\\"{x:1261,y:528,t:1527872957282};\\\", \\\"{x:1311,y:559,t:1527872957299};\\\", \\\"{x:1342,y:589,t:1527872957316};\\\", \\\"{x:1357,y:610,t:1527872957332};\\\", \\\"{x:1368,y:629,t:1527872957349};\\\", \\\"{x:1373,y:651,t:1527872957367};\\\", \\\"{x:1375,y:679,t:1527872957382};\\\", \\\"{x:1379,y:705,t:1527872957399};\\\", \\\"{x:1379,y:729,t:1527872957417};\\\", \\\"{x:1372,y:749,t:1527872957432};\\\", \\\"{x:1367,y:761,t:1527872957449};\\\", \\\"{x:1363,y:786,t:1527872957466};\\\", \\\"{x:1361,y:803,t:1527872957482};\\\", \\\"{x:1357,y:820,t:1527872957499};\\\", \\\"{x:1354,y:831,t:1527872957516};\\\", \\\"{x:1350,y:838,t:1527872957532};\\\", \\\"{x:1337,y:853,t:1527872957549};\\\", \\\"{x:1323,y:864,t:1527872957566};\\\", \\\"{x:1313,y:873,t:1527872957583};\\\", \\\"{x:1305,y:883,t:1527872957600};\\\", \\\"{x:1299,y:891,t:1527872957616};\\\", \\\"{x:1295,y:896,t:1527872957633};\\\", \\\"{x:1293,y:898,t:1527872957649};\\\", \\\"{x:1292,y:898,t:1527872957730};\\\", \\\"{x:1292,y:896,t:1527872957738};\\\", \\\"{x:1292,y:892,t:1527872957749};\\\", \\\"{x:1292,y:887,t:1527872957766};\\\", \\\"{x:1292,y:881,t:1527872957783};\\\", \\\"{x:1292,y:875,t:1527872957799};\\\", \\\"{x:1292,y:871,t:1527872957816};\\\", \\\"{x:1292,y:864,t:1527872957833};\\\", \\\"{x:1292,y:857,t:1527872957849};\\\", \\\"{x:1292,y:855,t:1527872957866};\\\", \\\"{x:1292,y:854,t:1527872957883};\\\", \\\"{x:1292,y:852,t:1527872957899};\\\", \\\"{x:1292,y:851,t:1527872957929};\\\", \\\"{x:1292,y:850,t:1527872957939};\\\", \\\"{x:1292,y:849,t:1527872957949};\\\", \\\"{x:1292,y:847,t:1527872957966};\\\", \\\"{x:1292,y:846,t:1527872957983};\\\", \\\"{x:1290,y:844,t:1527872957999};\\\", \\\"{x:1290,y:843,t:1527872958051};\\\", \\\"{x:1290,y:842,t:1527872958075};\\\", \\\"{x:1290,y:841,t:1527872958083};\\\", \\\"{x:1290,y:839,t:1527872958099};\\\", \\\"{x:1290,y:835,t:1527872958116};\\\", \\\"{x:1290,y:832,t:1527872958133};\\\", \\\"{x:1290,y:826,t:1527872958150};\\\", \\\"{x:1290,y:822,t:1527872958167};\\\", \\\"{x:1290,y:820,t:1527872958183};\\\", \\\"{x:1290,y:819,t:1527872958200};\\\", \\\"{x:1290,y:818,t:1527872958218};\\\", \\\"{x:1290,y:813,t:1527872958914};\\\", \\\"{x:1290,y:807,t:1527872958922};\\\", \\\"{x:1291,y:800,t:1527872958934};\\\", \\\"{x:1292,y:790,t:1527872958950};\\\", \\\"{x:1295,y:776,t:1527872958967};\\\", \\\"{x:1296,y:772,t:1527872958983};\\\", \\\"{x:1297,y:770,t:1527872959000};\\\", \\\"{x:1297,y:769,t:1527872959017};\\\", \\\"{x:1297,y:768,t:1527872959033};\\\", \\\"{x:1297,y:767,t:1527872959050};\\\", \\\"{x:1298,y:767,t:1527872959068};\\\", \\\"{x:1298,y:766,t:1527872959083};\\\", \\\"{x:1298,y:765,t:1527872959122};\\\", \\\"{x:1298,y:768,t:1527872959425};\\\", \\\"{x:1298,y:772,t:1527872959434};\\\", \\\"{x:1298,y:785,t:1527872959449};\\\", \\\"{x:1298,y:789,t:1527872959466};\\\", \\\"{x:1298,y:791,t:1527872959484};\\\", \\\"{x:1298,y:792,t:1527872959500};\\\", \\\"{x:1298,y:793,t:1527872959529};\\\", \\\"{x:1298,y:795,t:1527872959537};\\\", \\\"{x:1298,y:796,t:1527872959549};\\\", \\\"{x:1298,y:800,t:1527872959567};\\\", \\\"{x:1298,y:803,t:1527872959583};\\\", \\\"{x:1298,y:806,t:1527872959600};\\\", \\\"{x:1298,y:809,t:1527872959616};\\\", \\\"{x:1298,y:816,t:1527872959633};\\\", \\\"{x:1298,y:820,t:1527872959651};\\\", \\\"{x:1298,y:824,t:1527872959667};\\\", \\\"{x:1298,y:827,t:1527872959684};\\\", \\\"{x:1298,y:829,t:1527872959700};\\\", \\\"{x:1298,y:830,t:1527872959717};\\\", \\\"{x:1297,y:835,t:1527872959734};\\\", \\\"{x:1297,y:839,t:1527872959751};\\\", \\\"{x:1295,y:846,t:1527872959767};\\\", \\\"{x:1294,y:851,t:1527872959784};\\\", \\\"{x:1294,y:855,t:1527872959801};\\\", \\\"{x:1294,y:858,t:1527872959818};\\\", \\\"{x:1293,y:866,t:1527872959834};\\\", \\\"{x:1290,y:874,t:1527872959851};\\\", \\\"{x:1290,y:882,t:1527872959867};\\\", \\\"{x:1289,y:890,t:1527872959884};\\\", \\\"{x:1287,y:900,t:1527872959901};\\\", \\\"{x:1286,y:913,t:1527872959917};\\\", \\\"{x:1284,y:928,t:1527872959934};\\\", \\\"{x:1281,y:940,t:1527872959951};\\\", \\\"{x:1280,y:951,t:1527872959967};\\\", \\\"{x:1279,y:961,t:1527872959984};\\\", \\\"{x:1277,y:970,t:1527872960000};\\\", \\\"{x:1276,y:976,t:1527872960016};\\\", \\\"{x:1275,y:983,t:1527872960034};\\\", \\\"{x:1275,y:987,t:1527872960051};\\\", \\\"{x:1275,y:989,t:1527872960067};\\\", \\\"{x:1275,y:991,t:1527872960084};\\\", \\\"{x:1275,y:995,t:1527872960101};\\\", \\\"{x:1275,y:997,t:1527872960118};\\\", \\\"{x:1273,y:1000,t:1527872960133};\\\", \\\"{x:1273,y:1001,t:1527872960150};\\\", \\\"{x:1272,y:996,t:1527872960242};\\\", \\\"{x:1270,y:985,t:1527872960251};\\\", \\\"{x:1267,y:961,t:1527872960268};\\\", \\\"{x:1261,y:946,t:1527872960284};\\\", \\\"{x:1261,y:938,t:1527872960301};\\\", \\\"{x:1260,y:928,t:1527872960319};\\\", \\\"{x:1260,y:921,t:1527872960334};\\\", \\\"{x:1258,y:916,t:1527872960351};\\\", \\\"{x:1257,y:907,t:1527872960368};\\\", \\\"{x:1257,y:893,t:1527872960383};\\\", \\\"{x:1257,y:878,t:1527872960401};\\\", \\\"{x:1257,y:870,t:1527872960417};\\\", \\\"{x:1258,y:862,t:1527872960433};\\\", \\\"{x:1258,y:852,t:1527872960450};\\\", \\\"{x:1258,y:847,t:1527872960468};\\\", \\\"{x:1259,y:845,t:1527872960489};\\\", \\\"{x:1259,y:842,t:1527872960505};\\\", \\\"{x:1259,y:840,t:1527872960521};\\\", \\\"{x:1260,y:839,t:1527872960534};\\\", \\\"{x:1261,y:836,t:1527872960551};\\\", \\\"{x:1261,y:835,t:1527872960567};\\\", \\\"{x:1262,y:833,t:1527872960584};\\\", \\\"{x:1262,y:830,t:1527872960601};\\\", \\\"{x:1264,y:827,t:1527872960618};\\\", \\\"{x:1265,y:825,t:1527872960634};\\\", \\\"{x:1266,y:823,t:1527872960651};\\\", \\\"{x:1266,y:822,t:1527872960668};\\\", \\\"{x:1266,y:820,t:1527872960689};\\\", \\\"{x:1266,y:819,t:1527872960730};\\\", \\\"{x:1267,y:818,t:1527872960746};\\\", \\\"{x:1267,y:817,t:1527872960754};\\\", \\\"{x:1268,y:817,t:1527872960767};\\\", \\\"{x:1270,y:812,t:1527872960785};\\\", \\\"{x:1270,y:807,t:1527872960800};\\\", \\\"{x:1271,y:806,t:1527872960817};\\\", \\\"{x:1271,y:803,t:1527872960834};\\\", \\\"{x:1271,y:802,t:1527872960851};\\\", \\\"{x:1272,y:800,t:1527872960867};\\\", \\\"{x:1272,y:799,t:1527872960884};\\\", \\\"{x:1272,y:797,t:1527872960900};\\\", \\\"{x:1272,y:796,t:1527872960917};\\\", \\\"{x:1272,y:794,t:1527872960934};\\\", \\\"{x:1272,y:792,t:1527872960953};\\\", \\\"{x:1272,y:791,t:1527872960967};\\\", \\\"{x:1272,y:788,t:1527872960984};\\\", \\\"{x:1272,y:786,t:1527872961001};\\\", \\\"{x:1273,y:781,t:1527872961018};\\\", \\\"{x:1273,y:780,t:1527872961035};\\\", \\\"{x:1273,y:779,t:1527872961057};\\\", \\\"{x:1274,y:779,t:1527872961068};\\\", \\\"{x:1274,y:777,t:1527872961085};\\\", \\\"{x:1275,y:776,t:1527872961105};\\\", \\\"{x:1275,y:775,t:1527872961117};\\\", \\\"{x:1275,y:774,t:1527872961135};\\\", \\\"{x:1276,y:774,t:1527872961151};\\\", \\\"{x:1276,y:773,t:1527872961498};\\\", \\\"{x:1277,y:770,t:1527872961506};\\\", \\\"{x:1277,y:769,t:1527872961579};\\\", \\\"{x:1277,y:771,t:1527872964538};\\\", \\\"{x:1277,y:787,t:1527872964553};\\\", \\\"{x:1277,y:800,t:1527872964571};\\\", \\\"{x:1277,y:808,t:1527872964588};\\\", \\\"{x:1277,y:819,t:1527872964604};\\\", \\\"{x:1277,y:828,t:1527872964623};\\\", \\\"{x:1277,y:833,t:1527872964636};\\\", \\\"{x:1277,y:835,t:1527872964654};\\\", \\\"{x:1278,y:840,t:1527872964670};\\\", \\\"{x:1281,y:846,t:1527872964687};\\\", \\\"{x:1284,y:854,t:1527872964703};\\\", \\\"{x:1287,y:861,t:1527872964720};\\\", \\\"{x:1290,y:866,t:1527872964736};\\\", \\\"{x:1291,y:866,t:1527872964754};\\\", \\\"{x:1292,y:866,t:1527872964826};\\\", \\\"{x:1293,y:863,t:1527872964837};\\\", \\\"{x:1294,y:855,t:1527872964854};\\\", \\\"{x:1294,y:847,t:1527872964871};\\\", \\\"{x:1294,y:840,t:1527872964887};\\\", \\\"{x:1294,y:832,t:1527872964903};\\\", \\\"{x:1293,y:820,t:1527872964921};\\\", \\\"{x:1293,y:816,t:1527872964937};\\\", \\\"{x:1293,y:809,t:1527872964954};\\\", \\\"{x:1292,y:802,t:1527872964971};\\\", \\\"{x:1291,y:797,t:1527872964987};\\\", \\\"{x:1290,y:793,t:1527872965004};\\\", \\\"{x:1289,y:787,t:1527872965021};\\\", \\\"{x:1288,y:783,t:1527872965038};\\\", \\\"{x:1287,y:778,t:1527872965054};\\\", \\\"{x:1286,y:774,t:1527872965072};\\\", \\\"{x:1286,y:769,t:1527872965088};\\\", \\\"{x:1284,y:763,t:1527872965104};\\\", \\\"{x:1282,y:757,t:1527872965121};\\\", \\\"{x:1282,y:756,t:1527872965137};\\\", \\\"{x:1279,y:752,t:1527872965154};\\\", \\\"{x:1279,y:751,t:1527872965171};\\\", \\\"{x:1279,y:749,t:1527872965188};\\\", \\\"{x:1278,y:747,t:1527872965204};\\\", \\\"{x:1278,y:746,t:1527872965221};\\\", \\\"{x:1278,y:744,t:1527872965258};\\\", \\\"{x:1278,y:743,t:1527872965514};\\\", \\\"{x:1278,y:739,t:1527872965522};\\\", \\\"{x:1278,y:726,t:1527872965538};\\\", \\\"{x:1279,y:717,t:1527872965555};\\\", \\\"{x:1280,y:714,t:1527872965572};\\\", \\\"{x:1280,y:708,t:1527872965588};\\\", \\\"{x:1281,y:696,t:1527872965605};\\\", \\\"{x:1281,y:685,t:1527872965622};\\\", \\\"{x:1281,y:671,t:1527872965639};\\\", \\\"{x:1281,y:655,t:1527872965655};\\\", \\\"{x:1281,y:641,t:1527872965672};\\\", \\\"{x:1281,y:630,t:1527872965688};\\\", \\\"{x:1281,y:622,t:1527872965705};\\\", \\\"{x:1279,y:601,t:1527872965722};\\\", \\\"{x:1274,y:576,t:1527872965738};\\\", \\\"{x:1270,y:550,t:1527872965755};\\\", \\\"{x:1267,y:533,t:1527872965771};\\\", \\\"{x:1264,y:522,t:1527872965788};\\\", \\\"{x:1263,y:511,t:1527872965804};\\\", \\\"{x:1263,y:499,t:1527872965822};\\\", \\\"{x:1261,y:487,t:1527872965839};\\\", \\\"{x:1258,y:466,t:1527872965855};\\\", \\\"{x:1253,y:443,t:1527872965872};\\\", \\\"{x:1250,y:423,t:1527872965889};\\\", \\\"{x:1246,y:401,t:1527872965906};\\\", \\\"{x:1243,y:389,t:1527872965922};\\\", \\\"{x:1240,y:380,t:1527872965938};\\\", \\\"{x:1238,y:369,t:1527872965956};\\\", \\\"{x:1236,y:353,t:1527872965971};\\\", \\\"{x:1233,y:334,t:1527872965988};\\\", \\\"{x:1231,y:317,t:1527872966006};\\\", \\\"{x:1227,y:300,t:1527872966021};\\\", \\\"{x:1222,y:286,t:1527872966038};\\\", \\\"{x:1221,y:278,t:1527872966056};\\\", \\\"{x:1217,y:270,t:1527872966072};\\\", \\\"{x:1213,y:258,t:1527872966088};\\\", \\\"{x:1205,y:242,t:1527872966105};\\\", \\\"{x:1203,y:235,t:1527872966121};\\\", \\\"{x:1200,y:231,t:1527872966138};\\\", \\\"{x:1197,y:226,t:1527872966156};\\\", \\\"{x:1195,y:224,t:1527872966171};\\\", \\\"{x:1194,y:220,t:1527872966188};\\\", \\\"{x:1193,y:219,t:1527872966206};\\\", \\\"{x:1192,y:218,t:1527872966221};\\\", \\\"{x:1191,y:217,t:1527872966238};\\\", \\\"{x:1190,y:215,t:1527872966255};\\\", \\\"{x:1189,y:214,t:1527872966274};\\\", \\\"{x:1188,y:214,t:1527872966288};\\\", \\\"{x:1185,y:212,t:1527872966305};\\\", \\\"{x:1184,y:211,t:1527872966321};\\\", \\\"{x:1183,y:210,t:1527872966338};\\\", \\\"{x:1182,y:210,t:1527872966355};\\\", \\\"{x:1181,y:210,t:1527872967010};\\\", \\\"{x:1181,y:213,t:1527872967023};\\\", \\\"{x:1184,y:218,t:1527872967040};\\\", \\\"{x:1187,y:222,t:1527872967055};\\\", \\\"{x:1194,y:227,t:1527872967073};\\\", \\\"{x:1208,y:234,t:1527872967090};\\\", \\\"{x:1220,y:241,t:1527872967105};\\\", \\\"{x:1228,y:247,t:1527872967122};\\\", \\\"{x:1243,y:258,t:1527872967139};\\\", \\\"{x:1256,y:266,t:1527872967155};\\\", \\\"{x:1272,y:276,t:1527872967173};\\\", \\\"{x:1300,y:289,t:1527872967190};\\\", \\\"{x:1350,y:312,t:1527872967206};\\\", \\\"{x:1422,y:343,t:1527872967222};\\\", \\\"{x:1518,y:381,t:1527872967240};\\\", \\\"{x:1611,y:421,t:1527872967255};\\\", \\\"{x:1704,y:452,t:1527872967273};\\\", \\\"{x:1829,y:488,t:1527872967289};\\\", \\\"{x:1879,y:504,t:1527872967306};\\\", \\\"{x:1907,y:511,t:1527872967323};\\\", \\\"{x:1919,y:520,t:1527872967339};\\\", \\\"{x:1919,y:523,t:1527872967357};\\\", \\\"{x:1919,y:527,t:1527872967373};\\\", \\\"{x:1919,y:532,t:1527872967390};\\\", \\\"{x:1919,y:538,t:1527872967407};\\\", \\\"{x:1919,y:545,t:1527872967424};\\\", \\\"{x:1919,y:555,t:1527872967441};\\\", \\\"{x:1910,y:573,t:1527872967457};\\\", \\\"{x:1901,y:580,t:1527872967474};\\\", \\\"{x:1888,y:585,t:1527872967490};\\\", \\\"{x:1859,y:591,t:1527872967507};\\\", \\\"{x:1800,y:595,t:1527872967525};\\\", \\\"{x:1716,y:595,t:1527872967540};\\\", \\\"{x:1622,y:595,t:1527872967557};\\\", \\\"{x:1528,y:595,t:1527872967574};\\\", \\\"{x:1434,y:595,t:1527872967589};\\\", \\\"{x:1325,y:595,t:1527872967607};\\\", \\\"{x:1217,y:592,t:1527872967624};\\\", \\\"{x:1073,y:581,t:1527872967640};\\\", \\\"{x:1020,y:581,t:1527872967656};\\\", \\\"{x:998,y:581,t:1527872967674};\\\", \\\"{x:992,y:581,t:1527872967690};\\\", \\\"{x:990,y:583,t:1527872967706};\\\", \\\"{x:984,y:585,t:1527872967724};\\\", \\\"{x:978,y:590,t:1527872967741};\\\", \\\"{x:968,y:601,t:1527872967757};\\\", \\\"{x:954,y:618,t:1527872967774};\\\", \\\"{x:939,y:638,t:1527872967791};\\\", \\\"{x:923,y:660,t:1527872967807};\\\", \\\"{x:911,y:678,t:1527872967824};\\\", \\\"{x:894,y:698,t:1527872967842};\\\", \\\"{x:880,y:710,t:1527872967858};\\\", \\\"{x:870,y:717,t:1527872967874};\\\", \\\"{x:862,y:721,t:1527872967891};\\\", \\\"{x:850,y:727,t:1527872967907};\\\", \\\"{x:828,y:730,t:1527872967925};\\\", \\\"{x:808,y:733,t:1527872967941};\\\", \\\"{x:793,y:735,t:1527872967957};\\\", \\\"{x:783,y:735,t:1527872967974};\\\", \\\"{x:776,y:735,t:1527872967991};\\\", \\\"{x:771,y:735,t:1527872968007};\\\", \\\"{x:769,y:735,t:1527872968026};\\\", \\\"{x:768,y:735,t:1527872968049};\\\", \\\"{x:766,y:735,t:1527872968057};\\\", \\\"{x:763,y:735,t:1527872968073};\\\", \\\"{x:758,y:735,t:1527872968091};\\\", \\\"{x:750,y:734,t:1527872968107};\\\", \\\"{x:739,y:730,t:1527872968124};\\\", \\\"{x:731,y:728,t:1527872968142};\\\", \\\"{x:727,y:727,t:1527872968157};\\\", \\\"{x:724,y:727,t:1527872968176};\\\", \\\"{x:721,y:727,t:1527872968190};\\\", \\\"{x:720,y:726,t:1527872968281};\\\", \\\"{x:725,y:722,t:1527872968291};\\\", \\\"{x:751,y:711,t:1527872968308};\\\", \\\"{x:802,y:702,t:1527872968324};\\\", \\\"{x:891,y:702,t:1527872968340};\\\", \\\"{x:1013,y:700,t:1527872968358};\\\", \\\"{x:1119,y:700,t:1527872968374};\\\", \\\"{x:1118,y:700,t:1527872968650};\\\", \\\"{x:1109,y:699,t:1527872968658};\\\", \\\"{x:1094,y:699,t:1527872968674};\\\", \\\"{x:1079,y:696,t:1527872968691};\\\", \\\"{x:1056,y:693,t:1527872968708};\\\", \\\"{x:1026,y:685,t:1527872968726};\\\", \\\"{x:975,y:669,t:1527872968741};\\\", \\\"{x:921,y:649,t:1527872968758};\\\", \\\"{x:883,y:634,t:1527872968775};\\\", \\\"{x:857,y:629,t:1527872968791};\\\", \\\"{x:840,y:626,t:1527872968808};\\\", \\\"{x:814,y:624,t:1527872968825};\\\", \\\"{x:801,y:623,t:1527872968841};\\\", \\\"{x:785,y:623,t:1527872968858};\\\", \\\"{x:772,y:623,t:1527872968875};\\\", \\\"{x:767,y:623,t:1527872968891};\\\", \\\"{x:765,y:623,t:1527872968908};\\\", \\\"{x:762,y:623,t:1527872968925};\\\", \\\"{x:756,y:623,t:1527872968942};\\\", \\\"{x:745,y:623,t:1527872968958};\\\", \\\"{x:730,y:625,t:1527872968975};\\\", \\\"{x:716,y:628,t:1527872968992};\\\", \\\"{x:704,y:632,t:1527872969008};\\\", \\\"{x:692,y:637,t:1527872969024};\\\", \\\"{x:685,y:641,t:1527872969040};\\\", \\\"{x:673,y:646,t:1527872969058};\\\", \\\"{x:659,y:651,t:1527872969075};\\\", \\\"{x:648,y:653,t:1527872969091};\\\", \\\"{x:646,y:655,t:1527872969108};\\\", \\\"{x:645,y:655,t:1527872969125};\\\", \\\"{x:642,y:657,t:1527872969142};\\\", \\\"{x:640,y:658,t:1527872969158};\\\", \\\"{x:637,y:661,t:1527872969175};\\\", \\\"{x:631,y:665,t:1527872969192};\\\", \\\"{x:623,y:671,t:1527872969208};\\\", \\\"{x:613,y:678,t:1527872969225};\\\", \\\"{x:603,y:687,t:1527872969242};\\\", \\\"{x:596,y:694,t:1527872969258};\\\", \\\"{x:593,y:697,t:1527872969275};\\\", \\\"{x:591,y:699,t:1527872969292};\\\", \\\"{x:591,y:700,t:1527872969308};\\\", \\\"{x:590,y:700,t:1527872969379};\\\", \\\"{x:588,y:700,t:1527872969391};\\\", \\\"{x:583,y:700,t:1527872969408};\\\", \\\"{x:565,y:697,t:1527872969425};\\\", \\\"{x:550,y:690,t:1527872969442};\\\", \\\"{x:532,y:688,t:1527872969458};\\\", \\\"{x:513,y:687,t:1527872969475};\\\", \\\"{x:499,y:687,t:1527872969493};\\\", \\\"{x:485,y:690,t:1527872969509};\\\", \\\"{x:471,y:694,t:1527872969526};\\\", \\\"{x:467,y:695,t:1527872969542};\\\", \\\"{x:462,y:699,t:1527872969559};\\\", \\\"{x:461,y:699,t:1527872969576};\\\", \\\"{x:461,y:701,t:1527872969627};\\\", \\\"{x:461,y:704,t:1527872969642};\\\", \\\"{x:461,y:706,t:1527872969659};\\\", \\\"{x:461,y:707,t:1527872969681};\\\", \\\"{x:461,y:708,t:1527872969691};\\\", \\\"{x:461,y:709,t:1527872969713};\\\", \\\"{x:462,y:709,t:1527872969725};\\\", \\\"{x:464,y:711,t:1527872969742};\\\", \\\"{x:466,y:712,t:1527872969759};\\\", \\\"{x:467,y:713,t:1527872969775};\\\", \\\"{x:470,y:714,t:1527872969792};\\\", \\\"{x:473,y:716,t:1527872969809};\\\", \\\"{x:476,y:716,t:1527872969826};\\\", \\\"{x:478,y:717,t:1527872969842};\\\", \\\"{x:478,y:718,t:1527872969859};\\\", \\\"{x:479,y:718,t:1527872969876};\\\", \\\"{x:480,y:718,t:1527872969892};\\\", \\\"{x:481,y:719,t:1527872969909};\\\", \\\"{x:483,y:719,t:1527872970641};\\\", \\\"{x:494,y:707,t:1527872970649};\\\", \\\"{x:506,y:696,t:1527872970660};\\\", \\\"{x:532,y:673,t:1527872970676};\\\", \\\"{x:553,y:656,t:1527872970693};\\\", \\\"{x:596,y:627,t:1527872970709};\\\", \\\"{x:655,y:596,t:1527872970726};\\\", \\\"{x:741,y:559,t:1527872970743};\\\", \\\"{x:830,y:517,t:1527872970759};\\\", \\\"{x:935,y:468,t:1527872970776};\\\", \\\"{x:1051,y:407,t:1527872970793};\\\", \\\"{x:1106,y:374,t:1527872970810};\\\", \\\"{x:1153,y:343,t:1527872970826};\\\", \\\"{x:1188,y:324,t:1527872970843};\\\", \\\"{x:1206,y:313,t:1527872970860};\\\", \\\"{x:1214,y:309,t:1527872970876};\\\", \\\"{x:1215,y:309,t:1527872970893};\\\", \\\"{x:1215,y:308,t:1527872970937};\\\" ] }, { \\\"rt\\\": 12144, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 168396, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-11 AM-D -D -D -D -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1216,y:308,t:1527872973210};\\\", \\\"{x:1238,y:313,t:1527872973229};\\\", \\\"{x:1274,y:330,t:1527872973246};\\\", \\\"{x:1322,y:344,t:1527872973262};\\\", \\\"{x:1361,y:361,t:1527872973278};\\\", \\\"{x:1377,y:367,t:1527872973296};\\\", \\\"{x:1380,y:370,t:1527872973312};\\\", \\\"{x:1381,y:370,t:1527872973329};\\\", \\\"{x:1385,y:372,t:1527872973345};\\\", \\\"{x:1393,y:382,t:1527872973362};\\\", \\\"{x:1407,y:407,t:1527872973379};\\\", \\\"{x:1427,y:454,t:1527872973396};\\\", \\\"{x:1447,y:514,t:1527872973412};\\\", \\\"{x:1464,y:575,t:1527872973428};\\\", \\\"{x:1476,y:617,t:1527872973446};\\\", \\\"{x:1485,y:650,t:1527872973461};\\\", \\\"{x:1491,y:688,t:1527872973478};\\\", \\\"{x:1497,y:721,t:1527872973496};\\\", \\\"{x:1502,y:754,t:1527872973511};\\\", \\\"{x:1506,y:781,t:1527872973529};\\\", \\\"{x:1506,y:818,t:1527872973545};\\\", \\\"{x:1506,y:839,t:1527872973562};\\\", \\\"{x:1504,y:862,t:1527872973579};\\\", \\\"{x:1500,y:886,t:1527872973596};\\\", \\\"{x:1498,y:906,t:1527872973612};\\\", \\\"{x:1495,y:923,t:1527872973629};\\\", \\\"{x:1493,y:941,t:1527872973646};\\\", \\\"{x:1490,y:958,t:1527872973662};\\\", \\\"{x:1488,y:972,t:1527872973679};\\\", \\\"{x:1484,y:988,t:1527872973696};\\\", \\\"{x:1475,y:1003,t:1527872973712};\\\", \\\"{x:1468,y:1016,t:1527872973729};\\\", \\\"{x:1455,y:1032,t:1527872973746};\\\", \\\"{x:1449,y:1038,t:1527872973762};\\\", \\\"{x:1442,y:1042,t:1527872973779};\\\", \\\"{x:1437,y:1045,t:1527872973795};\\\", \\\"{x:1429,y:1049,t:1527872973813};\\\", \\\"{x:1419,y:1053,t:1527872973828};\\\", \\\"{x:1406,y:1056,t:1527872973846};\\\", \\\"{x:1394,y:1059,t:1527872973862};\\\", \\\"{x:1388,y:1059,t:1527872973878};\\\", \\\"{x:1387,y:1059,t:1527872973895};\\\", \\\"{x:1383,y:1059,t:1527872973912};\\\", \\\"{x:1380,y:1059,t:1527872973928};\\\", \\\"{x:1374,y:1059,t:1527872973945};\\\", \\\"{x:1370,y:1059,t:1527872973962};\\\", \\\"{x:1369,y:1059,t:1527872973978};\\\", \\\"{x:1367,y:1058,t:1527872973995};\\\", \\\"{x:1365,y:1056,t:1527872974012};\\\", \\\"{x:1360,y:1049,t:1527872974029};\\\", \\\"{x:1351,y:1038,t:1527872974046};\\\", \\\"{x:1345,y:1029,t:1527872974063};\\\", \\\"{x:1338,y:1016,t:1527872974080};\\\", \\\"{x:1335,y:1011,t:1527872974095};\\\", \\\"{x:1333,y:1008,t:1527872974112};\\\", \\\"{x:1330,y:1001,t:1527872974129};\\\", \\\"{x:1330,y:998,t:1527872974145};\\\", \\\"{x:1327,y:994,t:1527872974162};\\\", \\\"{x:1327,y:991,t:1527872974179};\\\", \\\"{x:1326,y:990,t:1527872974195};\\\", \\\"{x:1326,y:988,t:1527872974212};\\\", \\\"{x:1325,y:987,t:1527872974230};\\\", \\\"{x:1324,y:985,t:1527872974245};\\\", \\\"{x:1323,y:984,t:1527872974263};\\\", \\\"{x:1322,y:982,t:1527872974279};\\\", \\\"{x:1321,y:981,t:1527872974296};\\\", \\\"{x:1320,y:979,t:1527872974313};\\\", \\\"{x:1313,y:976,t:1527872974330};\\\", \\\"{x:1306,y:974,t:1527872974345};\\\", \\\"{x:1301,y:972,t:1527872974362};\\\", \\\"{x:1292,y:969,t:1527872974380};\\\", \\\"{x:1286,y:968,t:1527872974396};\\\", \\\"{x:1284,y:968,t:1527872974412};\\\", \\\"{x:1284,y:967,t:1527872974429};\\\", \\\"{x:1284,y:963,t:1527872974594};\\\", \\\"{x:1290,y:956,t:1527872974601};\\\", \\\"{x:1301,y:951,t:1527872974613};\\\", \\\"{x:1320,y:942,t:1527872974629};\\\", \\\"{x:1351,y:932,t:1527872974647};\\\", \\\"{x:1377,y:927,t:1527872974662};\\\", \\\"{x:1405,y:925,t:1527872974680};\\\", \\\"{x:1439,y:921,t:1527872974696};\\\", \\\"{x:1460,y:921,t:1527872974713};\\\", \\\"{x:1492,y:921,t:1527872974729};\\\", \\\"{x:1504,y:921,t:1527872974747};\\\", \\\"{x:1512,y:924,t:1527872974763};\\\", \\\"{x:1518,y:925,t:1527872974779};\\\", \\\"{x:1522,y:927,t:1527872974796};\\\", \\\"{x:1525,y:928,t:1527872974813};\\\", \\\"{x:1528,y:929,t:1527872974830};\\\", \\\"{x:1532,y:930,t:1527872974847};\\\", \\\"{x:1537,y:933,t:1527872974863};\\\", \\\"{x:1542,y:935,t:1527872974880};\\\", \\\"{x:1548,y:938,t:1527872974897};\\\", \\\"{x:1558,y:944,t:1527872974913};\\\", \\\"{x:1573,y:953,t:1527872974929};\\\", \\\"{x:1577,y:955,t:1527872974947};\\\", \\\"{x:1576,y:954,t:1527872975177};\\\", \\\"{x:1569,y:946,t:1527872975185};\\\", \\\"{x:1558,y:933,t:1527872975197};\\\", \\\"{x:1546,y:919,t:1527872975214};\\\", \\\"{x:1542,y:911,t:1527872975229};\\\", \\\"{x:1538,y:908,t:1527872975246};\\\", \\\"{x:1534,y:903,t:1527872975263};\\\", \\\"{x:1532,y:900,t:1527872975280};\\\", \\\"{x:1529,y:895,t:1527872975297};\\\", \\\"{x:1521,y:877,t:1527872975314};\\\", \\\"{x:1505,y:848,t:1527872975330};\\\", \\\"{x:1485,y:817,t:1527872975346};\\\", \\\"{x:1468,y:792,t:1527872975363};\\\", \\\"{x:1457,y:779,t:1527872975380};\\\", \\\"{x:1455,y:776,t:1527872975397};\\\", \\\"{x:1453,y:773,t:1527872975414};\\\", \\\"{x:1453,y:772,t:1527872975430};\\\", \\\"{x:1451,y:770,t:1527872975447};\\\", \\\"{x:1449,y:764,t:1527872975464};\\\", \\\"{x:1440,y:748,t:1527872975481};\\\", \\\"{x:1428,y:726,t:1527872975497};\\\", \\\"{x:1403,y:685,t:1527872975514};\\\", \\\"{x:1392,y:665,t:1527872975531};\\\", \\\"{x:1380,y:642,t:1527872975546};\\\", \\\"{x:1370,y:619,t:1527872975563};\\\", \\\"{x:1357,y:594,t:1527872975581};\\\", \\\"{x:1345,y:566,t:1527872975597};\\\", \\\"{x:1335,y:542,t:1527872975614};\\\", \\\"{x:1330,y:528,t:1527872975630};\\\", \\\"{x:1325,y:512,t:1527872975646};\\\", \\\"{x:1322,y:497,t:1527872975663};\\\", \\\"{x:1316,y:482,t:1527872975681};\\\", \\\"{x:1313,y:465,t:1527872975697};\\\", \\\"{x:1309,y:447,t:1527872975714};\\\", \\\"{x:1309,y:439,t:1527872975731};\\\", \\\"{x:1308,y:432,t:1527872975747};\\\", \\\"{x:1308,y:427,t:1527872975763};\\\", \\\"{x:1308,y:423,t:1527872975780};\\\", \\\"{x:1310,y:418,t:1527872975796};\\\", \\\"{x:1315,y:410,t:1527872975814};\\\", \\\"{x:1320,y:407,t:1527872975831};\\\", \\\"{x:1324,y:403,t:1527872975846};\\\", \\\"{x:1330,y:399,t:1527872975864};\\\", \\\"{x:1340,y:395,t:1527872975880};\\\", \\\"{x:1350,y:390,t:1527872975896};\\\", \\\"{x:1367,y:384,t:1527872975914};\\\", \\\"{x:1372,y:383,t:1527872975931};\\\", \\\"{x:1379,y:380,t:1527872975948};\\\", \\\"{x:1389,y:379,t:1527872975964};\\\", \\\"{x:1407,y:379,t:1527872975981};\\\", \\\"{x:1426,y:379,t:1527872975997};\\\", \\\"{x:1440,y:379,t:1527872976014};\\\", \\\"{x:1448,y:379,t:1527872976030};\\\", \\\"{x:1453,y:379,t:1527872976047};\\\", \\\"{x:1462,y:380,t:1527872976063};\\\", \\\"{x:1469,y:381,t:1527872976080};\\\", \\\"{x:1490,y:384,t:1527872976096};\\\", \\\"{x:1506,y:386,t:1527872976113};\\\", \\\"{x:1521,y:389,t:1527872976130};\\\", \\\"{x:1533,y:390,t:1527872976147};\\\", \\\"{x:1539,y:392,t:1527872976163};\\\", \\\"{x:1546,y:394,t:1527872976179};\\\", \\\"{x:1553,y:396,t:1527872976197};\\\", \\\"{x:1567,y:404,t:1527872976213};\\\", \\\"{x:1583,y:416,t:1527872976230};\\\", \\\"{x:1598,y:429,t:1527872976247};\\\", \\\"{x:1610,y:440,t:1527872976263};\\\", \\\"{x:1615,y:447,t:1527872976280};\\\", \\\"{x:1620,y:454,t:1527872976296};\\\", \\\"{x:1622,y:458,t:1527872976313};\\\", \\\"{x:1625,y:464,t:1527872976330};\\\", \\\"{x:1626,y:468,t:1527872976347};\\\", \\\"{x:1628,y:474,t:1527872976363};\\\", \\\"{x:1633,y:482,t:1527872976380};\\\", \\\"{x:1637,y:487,t:1527872976397};\\\", \\\"{x:1643,y:491,t:1527872976414};\\\", \\\"{x:1651,y:495,t:1527872976430};\\\", \\\"{x:1660,y:498,t:1527872976447};\\\", \\\"{x:1663,y:500,t:1527872976464};\\\", \\\"{x:1664,y:499,t:1527872976538};\\\", \\\"{x:1664,y:495,t:1527872976548};\\\", \\\"{x:1661,y:485,t:1527872976564};\\\", \\\"{x:1658,y:476,t:1527872976580};\\\", \\\"{x:1654,y:469,t:1527872976597};\\\", \\\"{x:1650,y:462,t:1527872976614};\\\", \\\"{x:1648,y:459,t:1527872976630};\\\", \\\"{x:1645,y:455,t:1527872976647};\\\", \\\"{x:1640,y:451,t:1527872976665};\\\", \\\"{x:1636,y:447,t:1527872976680};\\\", \\\"{x:1633,y:443,t:1527872976696};\\\", \\\"{x:1630,y:440,t:1527872976714};\\\", \\\"{x:1627,y:435,t:1527872976730};\\\", \\\"{x:1625,y:433,t:1527872976748};\\\", \\\"{x:1623,y:430,t:1527872976765};\\\", \\\"{x:1621,y:429,t:1527872976780};\\\", \\\"{x:1620,y:429,t:1527872976799};\\\", \\\"{x:1618,y:427,t:1527872976831};\\\", \\\"{x:1616,y:427,t:1527872976847};\\\", \\\"{x:1615,y:427,t:1527872976865};\\\", \\\"{x:1614,y:426,t:1527872976880};\\\", \\\"{x:1613,y:426,t:1527872977665};\\\", \\\"{x:1613,y:430,t:1527872977681};\\\", \\\"{x:1613,y:432,t:1527872977699};\\\", \\\"{x:1613,y:434,t:1527872977714};\\\", \\\"{x:1613,y:435,t:1527872977745};\\\", \\\"{x:1613,y:436,t:1527872977763};\\\", \\\"{x:1613,y:437,t:1527872977777};\\\", \\\"{x:1613,y:438,t:1527872977841};\\\", \\\"{x:1613,y:439,t:1527872977865};\\\", \\\"{x:1613,y:440,t:1527872977881};\\\", \\\"{x:1614,y:441,t:1527872977899};\\\", \\\"{x:1614,y:442,t:1527872977922};\\\", \\\"{x:1614,y:443,t:1527872977953};\\\", \\\"{x:1614,y:444,t:1527872977965};\\\", \\\"{x:1614,y:445,t:1527872977980};\\\", \\\"{x:1614,y:446,t:1527872978008};\\\", \\\"{x:1614,y:447,t:1527872978016};\\\", \\\"{x:1615,y:448,t:1527872978040};\\\", \\\"{x:1614,y:444,t:1527872978641};\\\", \\\"{x:1614,y:442,t:1527872978649};\\\", \\\"{x:1613,y:438,t:1527872978666};\\\", \\\"{x:1613,y:436,t:1527872978682};\\\", \\\"{x:1612,y:434,t:1527872978699};\\\", \\\"{x:1612,y:431,t:1527872978716};\\\", \\\"{x:1612,y:430,t:1527872978733};\\\", \\\"{x:1612,y:428,t:1527872978749};\\\", \\\"{x:1612,y:427,t:1527872978766};\\\", \\\"{x:1612,y:426,t:1527872978783};\\\", \\\"{x:1612,y:425,t:1527872978799};\\\", \\\"{x:1612,y:424,t:1527872978817};\\\", \\\"{x:1612,y:423,t:1527872978833};\\\", \\\"{x:1612,y:422,t:1527872978865};\\\", \\\"{x:1612,y:424,t:1527872979537};\\\", \\\"{x:1612,y:427,t:1527872979550};\\\", \\\"{x:1612,y:433,t:1527872979566};\\\", \\\"{x:1612,y:437,t:1527872979583};\\\", \\\"{x:1613,y:441,t:1527872979600};\\\", \\\"{x:1613,y:444,t:1527872979617};\\\", \\\"{x:1614,y:450,t:1527872979634};\\\", \\\"{x:1614,y:453,t:1527872979650};\\\", \\\"{x:1615,y:458,t:1527872979666};\\\", \\\"{x:1615,y:461,t:1527872979683};\\\", \\\"{x:1615,y:465,t:1527872979699};\\\", \\\"{x:1615,y:468,t:1527872979717};\\\", \\\"{x:1615,y:473,t:1527872979733};\\\", \\\"{x:1615,y:476,t:1527872979749};\\\", \\\"{x:1615,y:480,t:1527872979767};\\\", \\\"{x:1615,y:484,t:1527872979783};\\\", \\\"{x:1615,y:489,t:1527872979799};\\\", \\\"{x:1615,y:493,t:1527872979816};\\\", \\\"{x:1615,y:499,t:1527872979833};\\\", \\\"{x:1615,y:504,t:1527872979850};\\\", \\\"{x:1615,y:507,t:1527872979866};\\\", \\\"{x:1615,y:511,t:1527872979884};\\\", \\\"{x:1615,y:518,t:1527872979900};\\\", \\\"{x:1615,y:524,t:1527872979917};\\\", \\\"{x:1615,y:530,t:1527872979933};\\\", \\\"{x:1615,y:535,t:1527872979950};\\\", \\\"{x:1615,y:541,t:1527872979966};\\\", \\\"{x:1615,y:545,t:1527872979984};\\\", \\\"{x:1615,y:550,t:1527872979999};\\\", \\\"{x:1615,y:558,t:1527872980018};\\\", \\\"{x:1615,y:565,t:1527872980033};\\\", \\\"{x:1615,y:571,t:1527872980050};\\\", \\\"{x:1615,y:575,t:1527872980067};\\\", \\\"{x:1615,y:579,t:1527872980084};\\\", \\\"{x:1615,y:582,t:1527872980100};\\\", \\\"{x:1615,y:583,t:1527872980117};\\\", \\\"{x:1615,y:585,t:1527872980552};\\\", \\\"{x:1615,y:602,t:1527872980566};\\\", \\\"{x:1622,y:654,t:1527872980583};\\\", \\\"{x:1622,y:716,t:1527872980600};\\\", \\\"{x:1622,y:830,t:1527872980617};\\\", \\\"{x:1622,y:894,t:1527872980634};\\\", \\\"{x:1607,y:954,t:1527872980651};\\\", \\\"{x:1582,y:1010,t:1527872980667};\\\", \\\"{x:1566,y:1037,t:1527872980684};\\\", \\\"{x:1547,y:1062,t:1527872980700};\\\", \\\"{x:1498,y:1101,t:1527872980717};\\\", \\\"{x:1422,y:1138,t:1527872980733};\\\", \\\"{x:1329,y:1162,t:1527872980751};\\\", \\\"{x:1241,y:1165,t:1527872980767};\\\", \\\"{x:1164,y:1129,t:1527872980783};\\\", \\\"{x:1074,y:1027,t:1527872980801};\\\", \\\"{x:1020,y:939,t:1527872980817};\\\", \\\"{x:979,y:856,t:1527872980834};\\\", \\\"{x:953,y:798,t:1527872980850};\\\", \\\"{x:945,y:777,t:1527872980867};\\\", \\\"{x:943,y:773,t:1527872980883};\\\", \\\"{x:945,y:770,t:1527872980913};\\\", \\\"{x:948,y:769,t:1527872980921};\\\", \\\"{x:950,y:767,t:1527872980933};\\\", \\\"{x:954,y:767,t:1527872980950};\\\", \\\"{x:955,y:767,t:1527872980967};\\\", \\\"{x:955,y:762,t:1527872981169};\\\", \\\"{x:955,y:740,t:1527872981185};\\\", \\\"{x:947,y:722,t:1527872981201};\\\", \\\"{x:929,y:713,t:1527872981217};\\\", \\\"{x:888,y:704,t:1527872981234};\\\", \\\"{x:827,y:696,t:1527872981251};\\\", \\\"{x:749,y:683,t:1527872981267};\\\", \\\"{x:658,y:673,t:1527872981284};\\\", \\\"{x:575,y:673,t:1527872981300};\\\", \\\"{x:480,y:673,t:1527872981317};\\\", \\\"{x:380,y:673,t:1527872981334};\\\", \\\"{x:303,y:673,t:1527872981350};\\\", \\\"{x:272,y:673,t:1527872981367};\\\", \\\"{x:265,y:673,t:1527872981384};\\\", \\\"{x:264,y:673,t:1527872981408};\\\", \\\"{x:264,y:672,t:1527872981425};\\\", \\\"{x:263,y:670,t:1527872981434};\\\", \\\"{x:263,y:664,t:1527872981450};\\\", \\\"{x:263,y:649,t:1527872981467};\\\", \\\"{x:263,y:630,t:1527872981484};\\\", \\\"{x:261,y:618,t:1527872981500};\\\", \\\"{x:260,y:604,t:1527872981518};\\\", \\\"{x:258,y:596,t:1527872981534};\\\", \\\"{x:256,y:588,t:1527872981551};\\\", \\\"{x:254,y:582,t:1527872981568};\\\", \\\"{x:253,y:581,t:1527872981585};\\\", \\\"{x:250,y:575,t:1527872981601};\\\", \\\"{x:238,y:569,t:1527872981619};\\\", \\\"{x:216,y:563,t:1527872981635};\\\", \\\"{x:194,y:562,t:1527872981651};\\\", \\\"{x:180,y:562,t:1527872981668};\\\", \\\"{x:176,y:562,t:1527872981685};\\\", \\\"{x:172,y:563,t:1527872981701};\\\", \\\"{x:168,y:565,t:1527872981719};\\\", \\\"{x:163,y:568,t:1527872981735};\\\", \\\"{x:161,y:569,t:1527872981751};\\\", \\\"{x:159,y:569,t:1527872981768};\\\", \\\"{x:158,y:569,t:1527872981785};\\\", \\\"{x:157,y:571,t:1527872981802};\\\", \\\"{x:155,y:572,t:1527872981819};\\\", \\\"{x:154,y:575,t:1527872981836};\\\", \\\"{x:152,y:579,t:1527872981851};\\\", \\\"{x:152,y:584,t:1527872981869};\\\", \\\"{x:152,y:589,t:1527872981888};\\\", \\\"{x:153,y:595,t:1527872981901};\\\", \\\"{x:157,y:602,t:1527872981918};\\\", \\\"{x:160,y:607,t:1527872981935};\\\", \\\"{x:160,y:608,t:1527872981952};\\\", \\\"{x:161,y:609,t:1527872981968};\\\", \\\"{x:161,y:612,t:1527872981984};\\\", \\\"{x:162,y:617,t:1527872982003};\\\", \\\"{x:162,y:620,t:1527872982019};\\\", \\\"{x:163,y:629,t:1527872982035};\\\", \\\"{x:163,y:635,t:1527872982052};\\\", \\\"{x:163,y:641,t:1527872982068};\\\", \\\"{x:163,y:646,t:1527872982085};\\\", \\\"{x:163,y:650,t:1527872982103};\\\", \\\"{x:163,y:651,t:1527872982121};\\\", \\\"{x:164,y:651,t:1527872982410};\\\", \\\"{x:164,y:650,t:1527872982426};\\\", \\\"{x:164,y:647,t:1527872982440};\\\", \\\"{x:164,y:645,t:1527872982456};\\\", \\\"{x:164,y:644,t:1527872982472};\\\", \\\"{x:164,y:643,t:1527872982488};\\\", \\\"{x:167,y:643,t:1527872982769};\\\", \\\"{x:180,y:645,t:1527872982786};\\\", \\\"{x:192,y:648,t:1527872982803};\\\", \\\"{x:211,y:655,t:1527872982819};\\\", \\\"{x:235,y:662,t:1527872982835};\\\", \\\"{x:257,y:668,t:1527872982853};\\\", \\\"{x:276,y:675,t:1527872982869};\\\", \\\"{x:292,y:679,t:1527872982885};\\\", \\\"{x:308,y:683,t:1527872982902};\\\", \\\"{x:322,y:686,t:1527872982920};\\\", \\\"{x:337,y:690,t:1527872982936};\\\", \\\"{x:349,y:694,t:1527872982953};\\\", \\\"{x:353,y:696,t:1527872982969};\\\", \\\"{x:359,y:699,t:1527872982986};\\\", \\\"{x:362,y:701,t:1527872983002};\\\", \\\"{x:366,y:703,t:1527872983019};\\\", \\\"{x:369,y:706,t:1527872983036};\\\", \\\"{x:373,y:708,t:1527872983052};\\\", \\\"{x:383,y:713,t:1527872983069};\\\", \\\"{x:399,y:720,t:1527872983087};\\\", \\\"{x:419,y:725,t:1527872983102};\\\", \\\"{x:425,y:727,t:1527872983120};\\\", \\\"{x:429,y:727,t:1527872983137};\\\", \\\"{x:430,y:727,t:1527872983161};\\\", \\\"{x:431,y:727,t:1527872983177};\\\", \\\"{x:434,y:727,t:1527872983187};\\\", \\\"{x:439,y:727,t:1527872983202};\\\", \\\"{x:442,y:726,t:1527872983219};\\\", \\\"{x:443,y:725,t:1527872983236};\\\", \\\"{x:444,y:725,t:1527872983254};\\\", \\\"{x:445,y:725,t:1527872983269};\\\", \\\"{x:448,y:725,t:1527872983286};\\\", \\\"{x:451,y:725,t:1527872983303};\\\", \\\"{x:454,y:725,t:1527872983319};\\\", \\\"{x:458,y:725,t:1527872983336};\\\", \\\"{x:462,y:726,t:1527872983352};\\\", \\\"{x:463,y:727,t:1527872983369};\\\", \\\"{x:450,y:718,t:1527872984009};\\\", \\\"{x:425,y:701,t:1527872984020};\\\", \\\"{x:385,y:672,t:1527872984037};\\\", \\\"{x:363,y:653,t:1527872984054};\\\", \\\"{x:344,y:638,t:1527872984070};\\\", \\\"{x:325,y:619,t:1527872984086};\\\", \\\"{x:307,y:605,t:1527872984104};\\\", \\\"{x:283,y:584,t:1527872984120};\\\", \\\"{x:270,y:573,t:1527872984137};\\\", \\\"{x:269,y:572,t:1527872984153};\\\", \\\"{x:267,y:572,t:1527872984696};\\\", \\\"{x:257,y:567,t:1527872984704};\\\", \\\"{x:228,y:555,t:1527872984720};\\\", \\\"{x:216,y:551,t:1527872984737};\\\" ] }, { \\\"rt\\\": 22984, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 192622, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -12 PM-C -A -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:224,y:550,t:1527872984863};\\\", \\\"{x:230,y:552,t:1527872984872};\\\", \\\"{x:258,y:560,t:1527872984889};\\\", \\\"{x:276,y:563,t:1527872984905};\\\", \\\"{x:286,y:564,t:1527872984920};\\\", \\\"{x:293,y:564,t:1527872984937};\\\", \\\"{x:297,y:564,t:1527872984956};\\\", \\\"{x:299,y:564,t:1527872984970};\\\", \\\"{x:302,y:565,t:1527872984987};\\\", \\\"{x:305,y:566,t:1527872985004};\\\", \\\"{x:307,y:566,t:1527872985020};\\\", \\\"{x:309,y:566,t:1527872985037};\\\", \\\"{x:310,y:566,t:1527872985202};\\\", \\\"{x:298,y:564,t:1527872985208};\\\", \\\"{x:272,y:552,t:1527872985221};\\\", \\\"{x:197,y:530,t:1527872985238};\\\", \\\"{x:0,y:397,t:1527872985329};\\\", \\\"{x:0,y:382,t:1527872985340};\\\", \\\"{x:0,y:360,t:1527872985354};\\\", \\\"{x:0,y:336,t:1527872985371};\\\", \\\"{x:0,y:300,t:1527872985387};\\\", \\\"{x:0,y:264,t:1527872985404};\\\", \\\"{x:0,y:239,t:1527872985421};\\\", \\\"{x:0,y:216,t:1527872985437};\\\", \\\"{x:0,y:194,t:1527872985454};\\\", \\\"{x:0,y:158,t:1527872985471};\\\", \\\"{x:0,y:128,t:1527872985487};\\\", \\\"{x:0,y:126,t:1527872985504};\\\", \\\"{x:0,y:133,t:1527872985521};\\\", \\\"{x:0,y:146,t:1527872985537};\\\", \\\"{x:0,y:147,t:1527872985554};\\\", \\\"{x:1,y:147,t:1527872985697};\\\", \\\"{x:9,y:146,t:1527872985705};\\\", \\\"{x:50,y:126,t:1527872985722};\\\", \\\"{x:129,y:81,t:1527872985737};\\\", \\\"{x:254,y:24,t:1527872985755};\\\", \\\"{x:396,y:16,t:1527872985772};\\\", \\\"{x:565,y:16,t:1527872985787};\\\", \\\"{x:739,y:16,t:1527872985805};\\\", \\\"{x:919,y:16,t:1527872985822};\\\", \\\"{x:1080,y:16,t:1527872985840};\\\", \\\"{x:1243,y:16,t:1527872985855};\\\", \\\"{x:1399,y:16,t:1527872985872};\\\", \\\"{x:1584,y:16,t:1527872985889};\\\", \\\"{x:1654,y:16,t:1527872985905};\\\", \\\"{x:1690,y:19,t:1527872985922};\\\", \\\"{x:1716,y:29,t:1527872985939};\\\", \\\"{x:1723,y:32,t:1527872985955};\\\", \\\"{x:1724,y:34,t:1527872985971};\\\", \\\"{x:1726,y:36,t:1527872985988};\\\", \\\"{x:1729,y:41,t:1527872986005};\\\", \\\"{x:1735,y:52,t:1527872986021};\\\", \\\"{x:1739,y:64,t:1527872986038};\\\", \\\"{x:1742,y:77,t:1527872986054};\\\", \\\"{x:1744,y:92,t:1527872986071};\\\", \\\"{x:1744,y:116,t:1527872986089};\\\", \\\"{x:1744,y:128,t:1527872986105};\\\", \\\"{x:1741,y:154,t:1527872986123};\\\", \\\"{x:1731,y:182,t:1527872986139};\\\", \\\"{x:1720,y:203,t:1527872986155};\\\", \\\"{x:1707,y:225,t:1527872986172};\\\", \\\"{x:1686,y:255,t:1527872986189};\\\", \\\"{x:1669,y:279,t:1527872986205};\\\", \\\"{x:1641,y:320,t:1527872986221};\\\", \\\"{x:1610,y:360,t:1527872986239};\\\", \\\"{x:1563,y:411,t:1527872986254};\\\", \\\"{x:1506,y:457,t:1527872986272};\\\", \\\"{x:1407,y:518,t:1527872986288};\\\", \\\"{x:1357,y:540,t:1527872986305};\\\", \\\"{x:1312,y:555,t:1527872986321};\\\", \\\"{x:1287,y:562,t:1527872986339};\\\", \\\"{x:1268,y:567,t:1527872986355};\\\", \\\"{x:1249,y:570,t:1527872986371};\\\", \\\"{x:1223,y:570,t:1527872986389};\\\", \\\"{x:1203,y:570,t:1527872986405};\\\", \\\"{x:1182,y:567,t:1527872986421};\\\", \\\"{x:1165,y:567,t:1527872986439};\\\", \\\"{x:1149,y:567,t:1527872986456};\\\", \\\"{x:1129,y:572,t:1527872986472};\\\", \\\"{x:1094,y:587,t:1527872986489};\\\", \\\"{x:1071,y:596,t:1527872986505};\\\", \\\"{x:1047,y:604,t:1527872986522};\\\", \\\"{x:1019,y:612,t:1527872986538};\\\", \\\"{x:1000,y:616,t:1527872986556};\\\", \\\"{x:990,y:617,t:1527872986572};\\\", \\\"{x:984,y:618,t:1527872986588};\\\", \\\"{x:977,y:619,t:1527872986606};\\\", \\\"{x:964,y:619,t:1527872986621};\\\", \\\"{x:939,y:619,t:1527872986638};\\\", \\\"{x:914,y:619,t:1527872986656};\\\", \\\"{x:889,y:616,t:1527872986672};\\\", \\\"{x:868,y:614,t:1527872986689};\\\", \\\"{x:860,y:614,t:1527872986706};\\\", \\\"{x:851,y:613,t:1527872986722};\\\", \\\"{x:845,y:612,t:1527872986740};\\\", \\\"{x:843,y:612,t:1527872986755};\\\", \\\"{x:842,y:612,t:1527872986771};\\\", \\\"{x:841,y:611,t:1527872987400};\\\", \\\"{x:835,y:609,t:1527872988113};\\\", \\\"{x:829,y:601,t:1527872988125};\\\", \\\"{x:812,y:587,t:1527872988141};\\\", \\\"{x:792,y:572,t:1527872988156};\\\", \\\"{x:777,y:561,t:1527872988173};\\\", \\\"{x:767,y:554,t:1527872988190};\\\", \\\"{x:763,y:550,t:1527872988206};\\\", \\\"{x:761,y:548,t:1527872988223};\\\", \\\"{x:761,y:546,t:1527872988240};\\\", \\\"{x:761,y:544,t:1527872988256};\\\", \\\"{x:760,y:540,t:1527872988274};\\\", \\\"{x:758,y:536,t:1527872988291};\\\", \\\"{x:756,y:530,t:1527872988306};\\\", \\\"{x:752,y:522,t:1527872988323};\\\", \\\"{x:749,y:517,t:1527872988340};\\\", \\\"{x:746,y:512,t:1527872988356};\\\", \\\"{x:744,y:508,t:1527872988373};\\\", \\\"{x:741,y:504,t:1527872988391};\\\", \\\"{x:739,y:500,t:1527872988407};\\\", \\\"{x:737,y:497,t:1527872988423};\\\", \\\"{x:732,y:492,t:1527872988440};\\\", \\\"{x:728,y:488,t:1527872988456};\\\", \\\"{x:721,y:483,t:1527872988473};\\\", \\\"{x:712,y:479,t:1527872988490};\\\", \\\"{x:704,y:475,t:1527872988506};\\\", \\\"{x:695,y:471,t:1527872988523};\\\", \\\"{x:691,y:469,t:1527872988541};\\\", \\\"{x:687,y:467,t:1527872988557};\\\", \\\"{x:684,y:467,t:1527872988573};\\\", \\\"{x:678,y:465,t:1527872988591};\\\", \\\"{x:673,y:465,t:1527872988607};\\\", \\\"{x:667,y:464,t:1527872988624};\\\", \\\"{x:659,y:464,t:1527872988641};\\\", \\\"{x:655,y:464,t:1527872988657};\\\", \\\"{x:652,y:464,t:1527872988674};\\\", \\\"{x:651,y:464,t:1527872988691};\\\", \\\"{x:649,y:464,t:1527872988707};\\\", \\\"{x:646,y:465,t:1527872988724};\\\", \\\"{x:642,y:466,t:1527872988741};\\\", \\\"{x:639,y:468,t:1527872988758};\\\", \\\"{x:635,y:469,t:1527872988773};\\\", \\\"{x:631,y:471,t:1527872988791};\\\", \\\"{x:627,y:473,t:1527872988807};\\\", \\\"{x:622,y:474,t:1527872988824};\\\", \\\"{x:618,y:476,t:1527872988841};\\\", \\\"{x:615,y:477,t:1527872988857};\\\", \\\"{x:613,y:478,t:1527872988873};\\\", \\\"{x:612,y:479,t:1527872988891};\\\", \\\"{x:610,y:480,t:1527872988908};\\\", \\\"{x:608,y:482,t:1527872988925};\\\", \\\"{x:607,y:482,t:1527872988941};\\\", \\\"{x:607,y:483,t:1527872988977};\\\", \\\"{x:615,y:485,t:1527872988991};\\\", \\\"{x:635,y:486,t:1527872989008};\\\", \\\"{x:709,y:486,t:1527872989025};\\\", \\\"{x:793,y:486,t:1527872989040};\\\", \\\"{x:879,y:486,t:1527872989058};\\\", \\\"{x:968,y:486,t:1527872989074};\\\", \\\"{x:1051,y:486,t:1527872989091};\\\", \\\"{x:1126,y:486,t:1527872989108};\\\", \\\"{x:1185,y:486,t:1527872989125};\\\", \\\"{x:1235,y:486,t:1527872989141};\\\", \\\"{x:1278,y:495,t:1527872989158};\\\", \\\"{x:1326,y:511,t:1527872989175};\\\", \\\"{x:1382,y:536,t:1527872989191};\\\", \\\"{x:1433,y:564,t:1527872989208};\\\", \\\"{x:1489,y:609,t:1527872989225};\\\", \\\"{x:1513,y:632,t:1527872989244};\\\", \\\"{x:1523,y:653,t:1527872989258};\\\", \\\"{x:1528,y:670,t:1527872989275};\\\", \\\"{x:1528,y:685,t:1527872989291};\\\", \\\"{x:1528,y:696,t:1527872989307};\\\", \\\"{x:1526,y:707,t:1527872989324};\\\", \\\"{x:1519,y:723,t:1527872989341};\\\", \\\"{x:1509,y:740,t:1527872989357};\\\", \\\"{x:1493,y:761,t:1527872989375};\\\", \\\"{x:1484,y:774,t:1527872989392};\\\", \\\"{x:1471,y:786,t:1527872989408};\\\", \\\"{x:1454,y:802,t:1527872989425};\\\", \\\"{x:1442,y:811,t:1527872989441};\\\", \\\"{x:1432,y:820,t:1527872989458};\\\", \\\"{x:1420,y:831,t:1527872989475};\\\", \\\"{x:1409,y:843,t:1527872989492};\\\", \\\"{x:1400,y:855,t:1527872989507};\\\", \\\"{x:1393,y:874,t:1527872989525};\\\", \\\"{x:1379,y:894,t:1527872989541};\\\", \\\"{x:1369,y:913,t:1527872989558};\\\", \\\"{x:1363,y:925,t:1527872989575};\\\", \\\"{x:1357,y:936,t:1527872989592};\\\", \\\"{x:1350,y:949,t:1527872989608};\\\", \\\"{x:1342,y:972,t:1527872989625};\\\", \\\"{x:1342,y:981,t:1527872989642};\\\", \\\"{x:1341,y:992,t:1527872989659};\\\", \\\"{x:1341,y:1006,t:1527872989674};\\\", \\\"{x:1341,y:1015,t:1527872989692};\\\", \\\"{x:1341,y:1027,t:1527872989709};\\\", \\\"{x:1341,y:1033,t:1527872989725};\\\", \\\"{x:1341,y:1039,t:1527872989742};\\\", \\\"{x:1341,y:1041,t:1527872989759};\\\", \\\"{x:1338,y:1036,t:1527872989929};\\\", \\\"{x:1333,y:1024,t:1527872989943};\\\", \\\"{x:1325,y:1000,t:1527872989959};\\\", \\\"{x:1315,y:975,t:1527872989976};\\\", \\\"{x:1309,y:960,t:1527872989993};\\\", \\\"{x:1301,y:948,t:1527872990009};\\\", \\\"{x:1299,y:943,t:1527872990025};\\\", \\\"{x:1298,y:942,t:1527872990042};\\\", \\\"{x:1297,y:940,t:1527872990059};\\\", \\\"{x:1297,y:939,t:1527872990076};\\\", \\\"{x:1297,y:938,t:1527872990092};\\\", \\\"{x:1296,y:938,t:1527872990121};\\\", \\\"{x:1294,y:937,t:1527872990273};\\\", \\\"{x:1291,y:938,t:1527872990281};\\\", \\\"{x:1286,y:940,t:1527872990292};\\\", \\\"{x:1282,y:942,t:1527872990309};\\\", \\\"{x:1277,y:945,t:1527872990326};\\\", \\\"{x:1273,y:947,t:1527872990342};\\\", \\\"{x:1269,y:951,t:1527872990360};\\\", \\\"{x:1268,y:953,t:1527872990376};\\\", \\\"{x:1267,y:954,t:1527872990392};\\\", \\\"{x:1264,y:957,t:1527872990409};\\\", \\\"{x:1263,y:959,t:1527872990426};\\\", \\\"{x:1261,y:960,t:1527872990443};\\\", \\\"{x:1260,y:961,t:1527872990459};\\\", \\\"{x:1258,y:962,t:1527872990476};\\\", \\\"{x:1257,y:963,t:1527872990658};\\\", \\\"{x:1253,y:964,t:1527872990676};\\\", \\\"{x:1252,y:966,t:1527872990693};\\\", \\\"{x:1251,y:966,t:1527872990709};\\\", \\\"{x:1250,y:966,t:1527872990726};\\\", \\\"{x:1250,y:967,t:1527872990743};\\\", \\\"{x:1248,y:967,t:1527872991001};\\\", \\\"{x:1245,y:966,t:1527872991010};\\\", \\\"{x:1240,y:963,t:1527872991027};\\\", \\\"{x:1238,y:961,t:1527872991043};\\\", \\\"{x:1237,y:961,t:1527872991060};\\\", \\\"{x:1236,y:961,t:1527872991076};\\\", \\\"{x:1235,y:961,t:1527872991209};\\\", \\\"{x:1234,y:960,t:1527872991228};\\\", \\\"{x:1233,y:956,t:1527872995591};\\\", \\\"{x:1229,y:946,t:1527872995599};\\\", \\\"{x:1228,y:942,t:1527872995611};\\\", \\\"{x:1227,y:936,t:1527872995628};\\\", \\\"{x:1225,y:931,t:1527872995645};\\\", \\\"{x:1224,y:928,t:1527872995662};\\\", \\\"{x:1223,y:925,t:1527872995679};\\\", \\\"{x:1223,y:922,t:1527872995694};\\\", \\\"{x:1223,y:921,t:1527872995712};\\\", \\\"{x:1222,y:919,t:1527872995729};\\\", \\\"{x:1222,y:918,t:1527872995745};\\\", \\\"{x:1222,y:916,t:1527872995762};\\\", \\\"{x:1222,y:915,t:1527872995778};\\\", \\\"{x:1222,y:912,t:1527872995794};\\\", \\\"{x:1222,y:910,t:1527872995811};\\\", \\\"{x:1221,y:908,t:1527872995828};\\\", \\\"{x:1220,y:905,t:1527872995845};\\\", \\\"{x:1220,y:902,t:1527872995862};\\\", \\\"{x:1219,y:896,t:1527872995878};\\\", \\\"{x:1219,y:893,t:1527872995895};\\\", \\\"{x:1218,y:889,t:1527872995912};\\\", \\\"{x:1218,y:886,t:1527872995929};\\\", \\\"{x:1217,y:882,t:1527872995945};\\\", \\\"{x:1216,y:880,t:1527872995962};\\\", \\\"{x:1216,y:877,t:1527872995979};\\\", \\\"{x:1215,y:874,t:1527872995995};\\\", \\\"{x:1215,y:871,t:1527872996011};\\\", \\\"{x:1214,y:868,t:1527872996029};\\\", \\\"{x:1214,y:865,t:1527872996045};\\\", \\\"{x:1214,y:861,t:1527872996062};\\\", \\\"{x:1213,y:857,t:1527872996079};\\\", \\\"{x:1213,y:853,t:1527872996095};\\\", \\\"{x:1211,y:849,t:1527872996111};\\\", \\\"{x:1211,y:846,t:1527872996129};\\\", \\\"{x:1210,y:843,t:1527872996145};\\\", \\\"{x:1210,y:840,t:1527872996161};\\\", \\\"{x:1209,y:837,t:1527872996178};\\\", \\\"{x:1209,y:836,t:1527872996195};\\\", \\\"{x:1209,y:834,t:1527872996211};\\\", \\\"{x:1209,y:832,t:1527872996228};\\\", \\\"{x:1208,y:831,t:1527872996246};\\\", \\\"{x:1208,y:828,t:1527872996261};\\\", \\\"{x:1208,y:823,t:1527872996278};\\\", \\\"{x:1208,y:820,t:1527872996295};\\\", \\\"{x:1208,y:819,t:1527872996312};\\\", \\\"{x:1208,y:818,t:1527872996328};\\\", \\\"{x:1208,y:817,t:1527872996345};\\\", \\\"{x:1207,y:817,t:1527872997047};\\\", \\\"{x:1207,y:822,t:1527872997063};\\\", \\\"{x:1207,y:830,t:1527872997080};\\\", \\\"{x:1207,y:833,t:1527872997096};\\\", \\\"{x:1208,y:837,t:1527872997113};\\\", \\\"{x:1208,y:840,t:1527872997130};\\\", \\\"{x:1211,y:846,t:1527872997146};\\\", \\\"{x:1212,y:850,t:1527872997163};\\\", \\\"{x:1213,y:855,t:1527872997180};\\\", \\\"{x:1215,y:859,t:1527872997196};\\\", \\\"{x:1217,y:866,t:1527872997213};\\\", \\\"{x:1221,y:878,t:1527872997229};\\\", \\\"{x:1231,y:903,t:1527872997246};\\\", \\\"{x:1236,y:915,t:1527872997262};\\\", \\\"{x:1240,y:931,t:1527872997280};\\\", \\\"{x:1242,y:940,t:1527872997297};\\\", \\\"{x:1244,y:948,t:1527872997313};\\\", \\\"{x:1246,y:952,t:1527872997330};\\\", \\\"{x:1247,y:959,t:1527872997347};\\\", \\\"{x:1250,y:968,t:1527872997363};\\\", \\\"{x:1251,y:972,t:1527872997380};\\\", \\\"{x:1251,y:974,t:1527872997397};\\\", \\\"{x:1251,y:966,t:1527872997566};\\\", \\\"{x:1251,y:955,t:1527872997580};\\\", \\\"{x:1248,y:939,t:1527872997596};\\\", \\\"{x:1246,y:930,t:1527872997613};\\\", \\\"{x:1246,y:921,t:1527872997630};\\\", \\\"{x:1244,y:916,t:1527872997646};\\\", \\\"{x:1243,y:912,t:1527872997665};\\\", \\\"{x:1242,y:910,t:1527872997679};\\\", \\\"{x:1241,y:906,t:1527872997697};\\\", \\\"{x:1241,y:905,t:1527872997713};\\\", \\\"{x:1240,y:904,t:1527872997729};\\\", \\\"{x:1240,y:901,t:1527872997746};\\\", \\\"{x:1240,y:897,t:1527872997763};\\\", \\\"{x:1239,y:891,t:1527872997780};\\\", \\\"{x:1236,y:879,t:1527872997796};\\\", \\\"{x:1230,y:856,t:1527872997814};\\\", \\\"{x:1226,y:842,t:1527872997829};\\\", \\\"{x:1224,y:834,t:1527872997847};\\\", \\\"{x:1223,y:830,t:1527872997863};\\\", \\\"{x:1221,y:828,t:1527872997879};\\\", \\\"{x:1221,y:826,t:1527872997896};\\\", \\\"{x:1220,y:826,t:1527872997918};\\\", \\\"{x:1222,y:826,t:1527873000231};\\\", \\\"{x:1224,y:826,t:1527873000239};\\\", \\\"{x:1226,y:826,t:1527873000249};\\\", \\\"{x:1232,y:826,t:1527873000267};\\\", \\\"{x:1236,y:826,t:1527873000283};\\\", \\\"{x:1238,y:826,t:1527873000299};\\\", \\\"{x:1240,y:826,t:1527873000316};\\\", \\\"{x:1243,y:826,t:1527873000332};\\\", \\\"{x:1245,y:826,t:1527873000349};\\\", \\\"{x:1249,y:826,t:1527873000366};\\\", \\\"{x:1251,y:826,t:1527873000382};\\\", \\\"{x:1253,y:826,t:1527873000399};\\\", \\\"{x:1255,y:826,t:1527873000416};\\\", \\\"{x:1258,y:826,t:1527873000432};\\\", \\\"{x:1259,y:826,t:1527873000449};\\\", \\\"{x:1261,y:827,t:1527873000466};\\\", \\\"{x:1262,y:827,t:1527873000483};\\\", \\\"{x:1265,y:827,t:1527873000499};\\\", \\\"{x:1267,y:827,t:1527873000534};\\\", \\\"{x:1268,y:827,t:1527873000566};\\\", \\\"{x:1270,y:827,t:1527873000614};\\\", \\\"{x:1271,y:827,t:1527873000638};\\\", \\\"{x:1273,y:827,t:1527873000662};\\\", \\\"{x:1274,y:827,t:1527873000686};\\\", \\\"{x:1276,y:827,t:1527873000751};\\\", \\\"{x:1279,y:827,t:1527873001414};\\\", \\\"{x:1280,y:828,t:1527873001422};\\\", \\\"{x:1281,y:828,t:1527873001434};\\\", \\\"{x:1287,y:828,t:1527873001451};\\\", \\\"{x:1292,y:828,t:1527873001467};\\\", \\\"{x:1299,y:828,t:1527873001484};\\\", \\\"{x:1301,y:828,t:1527873001500};\\\", \\\"{x:1302,y:828,t:1527873001527};\\\", \\\"{x:1303,y:828,t:1527873001550};\\\", \\\"{x:1304,y:828,t:1527873001567};\\\", \\\"{x:1305,y:828,t:1527873001607};\\\", \\\"{x:1306,y:828,t:1527873001623};\\\", \\\"{x:1307,y:828,t:1527873001634};\\\", \\\"{x:1309,y:828,t:1527873001650};\\\", \\\"{x:1311,y:828,t:1527873001667};\\\", \\\"{x:1313,y:828,t:1527873001684};\\\", \\\"{x:1315,y:828,t:1527873001700};\\\", \\\"{x:1317,y:828,t:1527873001717};\\\", \\\"{x:1319,y:828,t:1527873001734};\\\", \\\"{x:1321,y:828,t:1527873001751};\\\", \\\"{x:1323,y:828,t:1527873001767};\\\", \\\"{x:1324,y:828,t:1527873001785};\\\", \\\"{x:1326,y:828,t:1527873001801};\\\", \\\"{x:1329,y:828,t:1527873001817};\\\", \\\"{x:1332,y:828,t:1527873001834};\\\", \\\"{x:1334,y:828,t:1527873001851};\\\", \\\"{x:1337,y:828,t:1527873001867};\\\", \\\"{x:1339,y:828,t:1527873001886};\\\", \\\"{x:1340,y:828,t:1527873001911};\\\", \\\"{x:1342,y:828,t:1527873001935};\\\", \\\"{x:1343,y:828,t:1527873001950};\\\", \\\"{x:1343,y:829,t:1527873002183};\\\", \\\"{x:1346,y:830,t:1527873002215};\\\", \\\"{x:1348,y:831,t:1527873002230};\\\", \\\"{x:1350,y:832,t:1527873002238};\\\", \\\"{x:1352,y:832,t:1527873002254};\\\", \\\"{x:1353,y:833,t:1527873002278};\\\", \\\"{x:1353,y:834,t:1527873002886};\\\", \\\"{x:1352,y:834,t:1527873002902};\\\", \\\"{x:1350,y:834,t:1527873002918};\\\", \\\"{x:1349,y:834,t:1527873002935};\\\", \\\"{x:1348,y:833,t:1527873003071};\\\", \\\"{x:1347,y:833,t:1527873003126};\\\", \\\"{x:1346,y:833,t:1527873003142};\\\", \\\"{x:1345,y:833,t:1527873003166};\\\", \\\"{x:1345,y:838,t:1527873003447};\\\", \\\"{x:1345,y:841,t:1527873003454};\\\", \\\"{x:1345,y:843,t:1527873003469};\\\", \\\"{x:1345,y:848,t:1527873003485};\\\", \\\"{x:1345,y:856,t:1527873003502};\\\", \\\"{x:1345,y:862,t:1527873003518};\\\", \\\"{x:1345,y:868,t:1527873003535};\\\", \\\"{x:1345,y:874,t:1527873003552};\\\", \\\"{x:1345,y:881,t:1527873003569};\\\", \\\"{x:1345,y:887,t:1527873003585};\\\", \\\"{x:1345,y:890,t:1527873003602};\\\", \\\"{x:1345,y:891,t:1527873003622};\\\", \\\"{x:1339,y:887,t:1527873003711};\\\", \\\"{x:1331,y:878,t:1527873003719};\\\", \\\"{x:1304,y:847,t:1527873003736};\\\", \\\"{x:1267,y:806,t:1527873003752};\\\", \\\"{x:1237,y:772,t:1527873003769};\\\", \\\"{x:1215,y:752,t:1527873003786};\\\", \\\"{x:1193,y:736,t:1527873003802};\\\", \\\"{x:1175,y:723,t:1527873003819};\\\", \\\"{x:1163,y:715,t:1527873003836};\\\", \\\"{x:1154,y:709,t:1527873003852};\\\", \\\"{x:1143,y:702,t:1527873003869};\\\", \\\"{x:1115,y:691,t:1527873003886};\\\", \\\"{x:1092,y:683,t:1527873003902};\\\", \\\"{x:1067,y:677,t:1527873003919};\\\", \\\"{x:1037,y:668,t:1527873003936};\\\", \\\"{x:1013,y:661,t:1527873003952};\\\", \\\"{x:986,y:653,t:1527873003969};\\\", \\\"{x:956,y:641,t:1527873003987};\\\", \\\"{x:930,y:634,t:1527873004002};\\\", \\\"{x:905,y:628,t:1527873004019};\\\", \\\"{x:877,y:625,t:1527873004036};\\\", \\\"{x:847,y:625,t:1527873004052};\\\", \\\"{x:820,y:625,t:1527873004069};\\\", \\\"{x:772,y:630,t:1527873004086};\\\", \\\"{x:742,y:636,t:1527873004102};\\\", \\\"{x:720,y:641,t:1527873004121};\\\", \\\"{x:702,y:647,t:1527873004136};\\\", \\\"{x:696,y:648,t:1527873004152};\\\", \\\"{x:695,y:650,t:1527873004246};\\\", \\\"{x:701,y:650,t:1527873004254};\\\", \\\"{x:714,y:644,t:1527873004267};\\\", \\\"{x:747,y:630,t:1527873004284};\\\", \\\"{x:771,y:619,t:1527873004300};\\\", \\\"{x:797,y:608,t:1527873004318};\\\", \\\"{x:802,y:607,t:1527873004333};\\\", \\\"{x:803,y:607,t:1527873004350};\\\", \\\"{x:797,y:609,t:1527873004398};\\\", \\\"{x:785,y:614,t:1527873004406};\\\", \\\"{x:773,y:617,t:1527873004417};\\\", \\\"{x:735,y:622,t:1527873004433};\\\", \\\"{x:676,y:622,t:1527873004451};\\\", \\\"{x:623,y:622,t:1527873004467};\\\", \\\"{x:600,y:622,t:1527873004483};\\\", \\\"{x:592,y:623,t:1527873004500};\\\", \\\"{x:585,y:625,t:1527873004518};\\\", \\\"{x:578,y:626,t:1527873004533};\\\", \\\"{x:572,y:630,t:1527873004551};\\\", \\\"{x:567,y:632,t:1527873004567};\\\", \\\"{x:565,y:634,t:1527873004583};\\\", \\\"{x:562,y:634,t:1527873004600};\\\", \\\"{x:555,y:637,t:1527873004617};\\\", \\\"{x:544,y:640,t:1527873004634};\\\", \\\"{x:529,y:641,t:1527873004650};\\\", \\\"{x:510,y:641,t:1527873004668};\\\", \\\"{x:492,y:641,t:1527873004686};\\\", \\\"{x:474,y:641,t:1527873004701};\\\", \\\"{x:466,y:641,t:1527873004717};\\\", \\\"{x:463,y:641,t:1527873004734};\\\", \\\"{x:459,y:641,t:1527873004750};\\\", \\\"{x:456,y:641,t:1527873004767};\\\", \\\"{x:454,y:641,t:1527873004869};\\\", \\\"{x:453,y:641,t:1527873004884};\\\", \\\"{x:449,y:641,t:1527873004900};\\\", \\\"{x:440,y:641,t:1527873004917};\\\", \\\"{x:428,y:641,t:1527873004934};\\\", \\\"{x:415,y:641,t:1527873004951};\\\", \\\"{x:401,y:641,t:1527873004967};\\\", \\\"{x:385,y:640,t:1527873004985};\\\", \\\"{x:367,y:636,t:1527873005000};\\\", \\\"{x:349,y:630,t:1527873005018};\\\", \\\"{x:330,y:625,t:1527873005034};\\\", \\\"{x:311,y:618,t:1527873005051};\\\", \\\"{x:290,y:613,t:1527873005068};\\\", \\\"{x:271,y:609,t:1527873005085};\\\", \\\"{x:249,y:606,t:1527873005101};\\\", \\\"{x:239,y:604,t:1527873005118};\\\", \\\"{x:231,y:603,t:1527873005134};\\\", \\\"{x:228,y:603,t:1527873005152};\\\", \\\"{x:224,y:603,t:1527873005168};\\\", \\\"{x:219,y:603,t:1527873005185};\\\", \\\"{x:212,y:603,t:1527873005202};\\\", \\\"{x:202,y:603,t:1527873005218};\\\", \\\"{x:192,y:604,t:1527873005234};\\\", \\\"{x:186,y:605,t:1527873005253};\\\", \\\"{x:183,y:607,t:1527873005268};\\\", \\\"{x:179,y:608,t:1527873005285};\\\", \\\"{x:177,y:610,t:1527873005301};\\\", \\\"{x:175,y:611,t:1527873005317};\\\", \\\"{x:173,y:612,t:1527873005335};\\\", \\\"{x:171,y:613,t:1527873005353};\\\", \\\"{x:170,y:614,t:1527873005368};\\\", \\\"{x:169,y:614,t:1527873005437};\\\", \\\"{x:165,y:610,t:1527873005451};\\\", \\\"{x:159,y:597,t:1527873005468};\\\", \\\"{x:157,y:584,t:1527873005484};\\\", \\\"{x:151,y:566,t:1527873005502};\\\", \\\"{x:150,y:564,t:1527873005518};\\\", \\\"{x:150,y:562,t:1527873005535};\\\", \\\"{x:150,y:558,t:1527873005551};\\\", \\\"{x:149,y:556,t:1527873005568};\\\", \\\"{x:149,y:551,t:1527873005584};\\\", \\\"{x:148,y:549,t:1527873005602};\\\", \\\"{x:148,y:545,t:1527873005619};\\\", \\\"{x:147,y:543,t:1527873005634};\\\", \\\"{x:150,y:545,t:1527873005800};\\\", \\\"{x:151,y:551,t:1527873005819};\\\", \\\"{x:155,y:556,t:1527873005835};\\\", \\\"{x:158,y:560,t:1527873005852};\\\", \\\"{x:160,y:562,t:1527873005868};\\\", \\\"{x:161,y:564,t:1527873006910};\\\", \\\"{x:171,y:564,t:1527873006920};\\\", \\\"{x:206,y:569,t:1527873006936};\\\", \\\"{x:233,y:572,t:1527873006953};\\\", \\\"{x:255,y:576,t:1527873006970};\\\", \\\"{x:271,y:581,t:1527873006985};\\\", \\\"{x:287,y:586,t:1527873007004};\\\", \\\"{x:306,y:593,t:1527873007020};\\\", \\\"{x:331,y:607,t:1527873007035};\\\", \\\"{x:351,y:620,t:1527873007054};\\\", \\\"{x:391,y:654,t:1527873007069};\\\", \\\"{x:419,y:678,t:1527873007086};\\\", \\\"{x:435,y:691,t:1527873007102};\\\", \\\"{x:440,y:694,t:1527873007119};\\\", \\\"{x:441,y:695,t:1527873007135};\\\", \\\"{x:443,y:696,t:1527873007153};\\\", \\\"{x:444,y:698,t:1527873007169};\\\", \\\"{x:447,y:704,t:1527873007187};\\\", \\\"{x:450,y:709,t:1527873007202};\\\", \\\"{x:450,y:711,t:1527873007219};\\\", \\\"{x:451,y:713,t:1527873007237};\\\", \\\"{x:452,y:714,t:1527873007253};\\\", \\\"{x:454,y:715,t:1527873007365};\\\", \\\"{x:457,y:715,t:1527873007373};\\\", \\\"{x:461,y:715,t:1527873007387};\\\", \\\"{x:466,y:715,t:1527873007403};\\\", \\\"{x:473,y:715,t:1527873007420};\\\", \\\"{x:478,y:715,t:1527873007437};\\\", \\\"{x:480,y:715,t:1527873007454};\\\", \\\"{x:481,y:715,t:1527873007470};\\\", \\\"{x:483,y:715,t:1527873007487};\\\", \\\"{x:484,y:716,t:1527873007510};\\\", \\\"{x:486,y:718,t:1527873007550};\\\", \\\"{x:486,y:716,t:1527873008206};\\\", \\\"{x:486,y:705,t:1527873008220};\\\", \\\"{x:486,y:695,t:1527873008237};\\\", \\\"{x:486,y:686,t:1527873008254};\\\", \\\"{x:486,y:680,t:1527873008270};\\\", \\\"{x:486,y:674,t:1527873008287};\\\", \\\"{x:486,y:666,t:1527873008304};\\\", \\\"{x:486,y:659,t:1527873008321};\\\", \\\"{x:486,y:652,t:1527873008337};\\\", \\\"{x:486,y:642,t:1527873008354};\\\", \\\"{x:488,y:632,t:1527873008371};\\\", \\\"{x:488,y:623,t:1527873008386};\\\", \\\"{x:488,y:617,t:1527873008403};\\\", \\\"{x:488,y:610,t:1527873008420};\\\", \\\"{x:488,y:604,t:1527873008437};\\\", \\\"{x:488,y:596,t:1527873008453};\\\", \\\"{x:488,y:589,t:1527873008470};\\\", \\\"{x:485,y:581,t:1527873008486};\\\", \\\"{x:481,y:572,t:1527873008504};\\\", \\\"{x:478,y:563,t:1527873008521};\\\", \\\"{x:472,y:553,t:1527873008536};\\\", \\\"{x:466,y:544,t:1527873008554};\\\", \\\"{x:457,y:534,t:1527873008570};\\\", \\\"{x:453,y:528,t:1527873008587};\\\", \\\"{x:452,y:528,t:1527873008604};\\\" ] }, { \\\"rt\\\": 21249, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 215169, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:452,y:526,t:1527873010903};\\\", \\\"{x:458,y:523,t:1527873010920};\\\", \\\"{x:467,y:519,t:1527873010929};\\\", \\\"{x:490,y:512,t:1527873010944};\\\", \\\"{x:547,y:505,t:1527873010962};\\\", \\\"{x:642,y:505,t:1527873010979};\\\", \\\"{x:700,y:505,t:1527873010988};\\\", \\\"{x:885,y:505,t:1527873011006};\\\", \\\"{x:996,y:505,t:1527873011022};\\\", \\\"{x:1093,y:505,t:1527873011039};\\\", \\\"{x:1166,y:505,t:1527873011056};\\\", \\\"{x:1205,y:505,t:1527873011073};\\\", \\\"{x:1228,y:505,t:1527873011088};\\\", \\\"{x:1245,y:502,t:1527873011106};\\\", \\\"{x:1260,y:502,t:1527873011123};\\\", \\\"{x:1277,y:502,t:1527873011139};\\\", \\\"{x:1294,y:502,t:1527873011156};\\\", \\\"{x:1314,y:504,t:1527873011173};\\\", \\\"{x:1342,y:507,t:1527873011189};\\\", \\\"{x:1381,y:514,t:1527873011206};\\\", \\\"{x:1402,y:516,t:1527873011223};\\\", \\\"{x:1426,y:521,t:1527873011239};\\\", \\\"{x:1452,y:524,t:1527873011256};\\\", \\\"{x:1475,y:530,t:1527873011273};\\\", \\\"{x:1504,y:538,t:1527873011290};\\\", \\\"{x:1527,y:547,t:1527873011306};\\\", \\\"{x:1543,y:552,t:1527873011322};\\\", \\\"{x:1554,y:558,t:1527873011340};\\\", \\\"{x:1561,y:561,t:1527873011355};\\\", \\\"{x:1562,y:563,t:1527873011372};\\\", \\\"{x:1566,y:571,t:1527873011389};\\\", \\\"{x:1571,y:578,t:1527873011405};\\\", \\\"{x:1575,y:587,t:1527873011422};\\\", \\\"{x:1579,y:597,t:1527873011440};\\\", \\\"{x:1583,y:611,t:1527873011455};\\\", \\\"{x:1587,y:626,t:1527873011473};\\\", \\\"{x:1588,y:636,t:1527873011490};\\\", \\\"{x:1589,y:647,t:1527873011506};\\\", \\\"{x:1590,y:659,t:1527873011523};\\\", \\\"{x:1593,y:669,t:1527873011540};\\\", \\\"{x:1594,y:681,t:1527873011556};\\\", \\\"{x:1594,y:693,t:1527873011573};\\\", \\\"{x:1594,y:711,t:1527873011590};\\\", \\\"{x:1594,y:721,t:1527873011606};\\\", \\\"{x:1594,y:729,t:1527873011623};\\\", \\\"{x:1594,y:738,t:1527873011640};\\\", \\\"{x:1594,y:743,t:1527873011656};\\\", \\\"{x:1593,y:751,t:1527873011673};\\\", \\\"{x:1591,y:757,t:1527873011690};\\\", \\\"{x:1589,y:765,t:1527873011706};\\\", \\\"{x:1589,y:769,t:1527873011723};\\\", \\\"{x:1588,y:773,t:1527873011740};\\\", \\\"{x:1587,y:778,t:1527873011757};\\\", \\\"{x:1586,y:785,t:1527873011773};\\\", \\\"{x:1584,y:794,t:1527873011790};\\\", \\\"{x:1582,y:801,t:1527873011807};\\\", \\\"{x:1578,y:811,t:1527873011823};\\\", \\\"{x:1578,y:816,t:1527873011840};\\\", \\\"{x:1576,y:820,t:1527873011857};\\\", \\\"{x:1575,y:823,t:1527873011873};\\\", \\\"{x:1575,y:830,t:1527873011891};\\\", \\\"{x:1574,y:837,t:1527873011907};\\\", \\\"{x:1572,y:846,t:1527873011922};\\\", \\\"{x:1571,y:853,t:1527873011940};\\\", \\\"{x:1570,y:860,t:1527873011957};\\\", \\\"{x:1568,y:868,t:1527873011973};\\\", \\\"{x:1566,y:880,t:1527873011990};\\\", \\\"{x:1565,y:889,t:1527873012007};\\\", \\\"{x:1563,y:898,t:1527873012023};\\\", \\\"{x:1563,y:903,t:1527873012040};\\\", \\\"{x:1561,y:911,t:1527873012057};\\\", \\\"{x:1558,y:919,t:1527873012073};\\\", \\\"{x:1557,y:926,t:1527873012091};\\\", \\\"{x:1554,y:932,t:1527873012107};\\\", \\\"{x:1553,y:938,t:1527873012124};\\\", \\\"{x:1550,y:945,t:1527873012140};\\\", \\\"{x:1549,y:951,t:1527873012157};\\\", \\\"{x:1547,y:956,t:1527873012173};\\\", \\\"{x:1545,y:962,t:1527873012190};\\\", \\\"{x:1542,y:968,t:1527873012207};\\\", \\\"{x:1540,y:976,t:1527873012224};\\\", \\\"{x:1535,y:982,t:1527873012240};\\\", \\\"{x:1531,y:987,t:1527873012257};\\\", \\\"{x:1528,y:991,t:1527873012273};\\\", \\\"{x:1523,y:993,t:1527873012289};\\\", \\\"{x:1518,y:996,t:1527873012307};\\\", \\\"{x:1514,y:999,t:1527873012324};\\\", \\\"{x:1510,y:1001,t:1527873012340};\\\", \\\"{x:1506,y:1003,t:1527873012357};\\\", \\\"{x:1500,y:1004,t:1527873012373};\\\", \\\"{x:1492,y:1005,t:1527873012390};\\\", \\\"{x:1484,y:1005,t:1527873012407};\\\", \\\"{x:1480,y:1005,t:1527873012425};\\\", \\\"{x:1476,y:1005,t:1527873012441};\\\", \\\"{x:1473,y:1005,t:1527873012457};\\\", \\\"{x:1472,y:1005,t:1527873012478};\\\", \\\"{x:1471,y:1005,t:1527873012490};\\\", \\\"{x:1470,y:1005,t:1527873012507};\\\", \\\"{x:1468,y:1005,t:1527873012524};\\\", \\\"{x:1467,y:1005,t:1527873012540};\\\", \\\"{x:1466,y:1005,t:1527873012558};\\\", \\\"{x:1465,y:1005,t:1527873012574};\\\", \\\"{x:1460,y:1005,t:1527873012590};\\\", \\\"{x:1452,y:1005,t:1527873012607};\\\", \\\"{x:1444,y:1005,t:1527873012624};\\\", \\\"{x:1436,y:1003,t:1527873012640};\\\", \\\"{x:1427,y:1003,t:1527873012657};\\\", \\\"{x:1416,y:1001,t:1527873012674};\\\", \\\"{x:1405,y:998,t:1527873012691};\\\", \\\"{x:1399,y:996,t:1527873012707};\\\", \\\"{x:1397,y:995,t:1527873012724};\\\", \\\"{x:1396,y:994,t:1527873013054};\\\", \\\"{x:1395,y:994,t:1527873013607};\\\", \\\"{x:1393,y:994,t:1527873013614};\\\", \\\"{x:1392,y:993,t:1527873013624};\\\", \\\"{x:1387,y:991,t:1527873013641};\\\", \\\"{x:1386,y:990,t:1527873013658};\\\", \\\"{x:1385,y:990,t:1527873013675};\\\", \\\"{x:1382,y:989,t:1527873013691};\\\", \\\"{x:1381,y:988,t:1527873013708};\\\", \\\"{x:1380,y:987,t:1527873013726};\\\", \\\"{x:1377,y:987,t:1527873013741};\\\", \\\"{x:1375,y:986,t:1527873013757};\\\", \\\"{x:1375,y:985,t:1527873013776};\\\", \\\"{x:1374,y:985,t:1527873013792};\\\", \\\"{x:1373,y:984,t:1527873013814};\\\", \\\"{x:1371,y:983,t:1527873013830};\\\", \\\"{x:1371,y:982,t:1527873013842};\\\", \\\"{x:1370,y:978,t:1527873013858};\\\", \\\"{x:1369,y:974,t:1527873013875};\\\", \\\"{x:1369,y:972,t:1527873013891};\\\", \\\"{x:1369,y:971,t:1527873013907};\\\", \\\"{x:1369,y:969,t:1527873013924};\\\", \\\"{x:1369,y:968,t:1527873013941};\\\", \\\"{x:1368,y:964,t:1527873013957};\\\", \\\"{x:1368,y:959,t:1527873013975};\\\", \\\"{x:1366,y:957,t:1527873013991};\\\", \\\"{x:1366,y:950,t:1527873014008};\\\", \\\"{x:1366,y:947,t:1527873014024};\\\", \\\"{x:1365,y:944,t:1527873014041};\\\", \\\"{x:1365,y:942,t:1527873014058};\\\", \\\"{x:1364,y:940,t:1527873014075};\\\", \\\"{x:1364,y:938,t:1527873014091};\\\", \\\"{x:1364,y:935,t:1527873014108};\\\", \\\"{x:1363,y:934,t:1527873014125};\\\", \\\"{x:1362,y:929,t:1527873014142};\\\", \\\"{x:1362,y:927,t:1527873014158};\\\", \\\"{x:1359,y:923,t:1527873014175};\\\", \\\"{x:1359,y:921,t:1527873014192};\\\", \\\"{x:1359,y:917,t:1527873014209};\\\", \\\"{x:1359,y:914,t:1527873014225};\\\", \\\"{x:1359,y:910,t:1527873014243};\\\", \\\"{x:1358,y:906,t:1527873014258};\\\", \\\"{x:1357,y:904,t:1527873014275};\\\", \\\"{x:1357,y:903,t:1527873014292};\\\", \\\"{x:1357,y:902,t:1527873014308};\\\", \\\"{x:1357,y:900,t:1527873014326};\\\", \\\"{x:1356,y:899,t:1527873014342};\\\", \\\"{x:1356,y:897,t:1527873014358};\\\", \\\"{x:1356,y:896,t:1527873014376};\\\", \\\"{x:1355,y:895,t:1527873014393};\\\", \\\"{x:1355,y:894,t:1527873014414};\\\", \\\"{x:1354,y:893,t:1527873014430};\\\", \\\"{x:1353,y:892,t:1527873014453};\\\", \\\"{x:1353,y:895,t:1527873016865};\\\", \\\"{x:1353,y:902,t:1527873016877};\\\", \\\"{x:1353,y:907,t:1527873016893};\\\", \\\"{x:1353,y:912,t:1527873016909};\\\", \\\"{x:1353,y:914,t:1527873016927};\\\", \\\"{x:1353,y:915,t:1527873016943};\\\", \\\"{x:1353,y:916,t:1527873016981};\\\", \\\"{x:1355,y:915,t:1527873017414};\\\", \\\"{x:1356,y:913,t:1527873017428};\\\", \\\"{x:1357,y:908,t:1527873017444};\\\", \\\"{x:1357,y:905,t:1527873017461};\\\", \\\"{x:1358,y:903,t:1527873017478};\\\", \\\"{x:1358,y:902,t:1527873017526};\\\", \\\"{x:1357,y:902,t:1527873017686};\\\", \\\"{x:1356,y:902,t:1527873017702};\\\", \\\"{x:1354,y:902,t:1527873017726};\\\", \\\"{x:1353,y:902,t:1527873017742};\\\", \\\"{x:1351,y:901,t:1527873017758};\\\", \\\"{x:1348,y:901,t:1527873017777};\\\", \\\"{x:1347,y:901,t:1527873017794};\\\", \\\"{x:1346,y:901,t:1527873017821};\\\", \\\"{x:1342,y:899,t:1527873021333};\\\", \\\"{x:1336,y:889,t:1527873021347};\\\", \\\"{x:1292,y:828,t:1527873021363};\\\", \\\"{x:1176,y:727,t:1527873021380};\\\", \\\"{x:909,y:565,t:1527873021398};\\\", \\\"{x:727,y:482,t:1527873021414};\\\", \\\"{x:590,y:428,t:1527873021430};\\\", \\\"{x:498,y:396,t:1527873021446};\\\", \\\"{x:453,y:383,t:1527873021464};\\\", \\\"{x:437,y:379,t:1527873021481};\\\", \\\"{x:433,y:380,t:1527873021557};\\\", \\\"{x:432,y:386,t:1527873021565};\\\", \\\"{x:429,y:405,t:1527873021581};\\\", \\\"{x:425,y:431,t:1527873021597};\\\", \\\"{x:420,y:465,t:1527873021614};\\\", \\\"{x:416,y:503,t:1527873021631};\\\", \\\"{x:416,y:524,t:1527873021647};\\\", \\\"{x:416,y:540,t:1527873021665};\\\", \\\"{x:416,y:551,t:1527873021682};\\\", \\\"{x:415,y:564,t:1527873021698};\\\", \\\"{x:414,y:573,t:1527873021714};\\\", \\\"{x:406,y:584,t:1527873021732};\\\", \\\"{x:401,y:588,t:1527873021749};\\\", \\\"{x:393,y:592,t:1527873021764};\\\", \\\"{x:380,y:600,t:1527873021780};\\\", \\\"{x:372,y:603,t:1527873021798};\\\", \\\"{x:365,y:606,t:1527873021814};\\\", \\\"{x:358,y:606,t:1527873021831};\\\", \\\"{x:342,y:604,t:1527873021848};\\\", \\\"{x:325,y:595,t:1527873021864};\\\", \\\"{x:305,y:588,t:1527873021881};\\\", \\\"{x:289,y:581,t:1527873021899};\\\", \\\"{x:283,y:578,t:1527873021914};\\\", \\\"{x:278,y:576,t:1527873021931};\\\", \\\"{x:274,y:575,t:1527873021948};\\\", \\\"{x:269,y:574,t:1527873021965};\\\", \\\"{x:261,y:572,t:1527873021981};\\\", \\\"{x:253,y:571,t:1527873021998};\\\", \\\"{x:245,y:570,t:1527873022014};\\\", \\\"{x:239,y:569,t:1527873022031};\\\", \\\"{x:236,y:568,t:1527873022048};\\\", \\\"{x:235,y:568,t:1527873022064};\\\", \\\"{x:234,y:568,t:1527873022081};\\\", \\\"{x:230,y:566,t:1527873022098};\\\", \\\"{x:223,y:564,t:1527873022114};\\\", \\\"{x:218,y:562,t:1527873022131};\\\", \\\"{x:214,y:562,t:1527873022148};\\\", \\\"{x:211,y:562,t:1527873022165};\\\", \\\"{x:203,y:559,t:1527873022182};\\\", \\\"{x:196,y:558,t:1527873022199};\\\", \\\"{x:194,y:558,t:1527873022216};\\\", \\\"{x:192,y:558,t:1527873022231};\\\", \\\"{x:190,y:556,t:1527873022250};\\\", \\\"{x:187,y:556,t:1527873022265};\\\", \\\"{x:182,y:556,t:1527873022281};\\\", \\\"{x:175,y:555,t:1527873022298};\\\", \\\"{x:172,y:555,t:1527873022315};\\\", \\\"{x:170,y:555,t:1527873022331};\\\", \\\"{x:167,y:555,t:1527873022348};\\\", \\\"{x:162,y:555,t:1527873022365};\\\", \\\"{x:159,y:555,t:1527873022381};\\\", \\\"{x:158,y:555,t:1527873022398};\\\", \\\"{x:157,y:555,t:1527873022415};\\\", \\\"{x:156,y:555,t:1527873022431};\\\", \\\"{x:155,y:555,t:1527873022448};\\\", \\\"{x:155,y:556,t:1527873022518};\\\", \\\"{x:155,y:555,t:1527873022732};\\\", \\\"{x:158,y:554,t:1527873022748};\\\", \\\"{x:162,y:551,t:1527873022764};\\\", \\\"{x:164,y:550,t:1527873022782};\\\", \\\"{x:166,y:549,t:1527873022799};\\\", \\\"{x:167,y:548,t:1527873023021};\\\", \\\"{x:170,y:547,t:1527873023033};\\\", \\\"{x:173,y:547,t:1527873023048};\\\", \\\"{x:176,y:547,t:1527873023065};\\\", \\\"{x:178,y:547,t:1527873023082};\\\", \\\"{x:180,y:548,t:1527873023102};\\\", \\\"{x:180,y:549,t:1527873023198};\\\", \\\"{x:184,y:551,t:1527873023206};\\\", \\\"{x:186,y:553,t:1527873023215};\\\", \\\"{x:195,y:556,t:1527873023232};\\\", \\\"{x:205,y:561,t:1527873023249};\\\", \\\"{x:215,y:565,t:1527873023265};\\\", \\\"{x:221,y:568,t:1527873023282};\\\", \\\"{x:230,y:571,t:1527873023299};\\\", \\\"{x:242,y:577,t:1527873023317};\\\", \\\"{x:256,y:582,t:1527873023333};\\\", \\\"{x:271,y:591,t:1527873023348};\\\", \\\"{x:284,y:600,t:1527873023367};\\\", \\\"{x:298,y:611,t:1527873023382};\\\", \\\"{x:310,y:620,t:1527873023400};\\\", \\\"{x:318,y:627,t:1527873023416};\\\", \\\"{x:328,y:633,t:1527873023432};\\\", \\\"{x:335,y:636,t:1527873023449};\\\", \\\"{x:343,y:640,t:1527873023467};\\\", \\\"{x:351,y:644,t:1527873023482};\\\", \\\"{x:362,y:648,t:1527873023499};\\\", \\\"{x:374,y:651,t:1527873023518};\\\", \\\"{x:382,y:654,t:1527873023532};\\\", \\\"{x:383,y:655,t:1527873023549};\\\", \\\"{x:384,y:655,t:1527873023572};\\\", \\\"{x:386,y:657,t:1527873023581};\\\", \\\"{x:388,y:659,t:1527873023599};\\\", \\\"{x:391,y:661,t:1527873023616};\\\", \\\"{x:395,y:662,t:1527873023632};\\\", \\\"{x:401,y:665,t:1527873023649};\\\", \\\"{x:406,y:667,t:1527873023666};\\\", \\\"{x:408,y:668,t:1527873023682};\\\", \\\"{x:409,y:669,t:1527873023699};\\\", \\\"{x:411,y:669,t:1527873023717};\\\", \\\"{x:412,y:670,t:1527873023733};\\\", \\\"{x:413,y:671,t:1527873023749};\\\", \\\"{x:414,y:672,t:1527873023774};\\\", \\\"{x:416,y:673,t:1527873023783};\\\", \\\"{x:420,y:678,t:1527873023799};\\\", \\\"{x:427,y:688,t:1527873023816};\\\", \\\"{x:433,y:698,t:1527873023833};\\\", \\\"{x:437,y:707,t:1527873023849};\\\", \\\"{x:442,y:714,t:1527873023866};\\\", \\\"{x:443,y:718,t:1527873023884};\\\", \\\"{x:443,y:719,t:1527873023899};\\\", \\\"{x:444,y:720,t:1527873023918};\\\", \\\"{x:444,y:721,t:1527873023933};\\\", \\\"{x:445,y:722,t:1527873023949};\\\", \\\"{x:446,y:722,t:1527873023966};\\\", \\\"{x:446,y:723,t:1527873024005};\\\", \\\"{x:446,y:724,t:1527873024016};\\\", \\\"{x:446,y:725,t:1527873024033};\\\", \\\"{x:447,y:726,t:1527873024061};\\\", \\\"{x:447,y:727,t:1527873024069};\\\", \\\"{x:448,y:728,t:1527873024094};\\\", \\\"{x:450,y:729,t:1527873026213};\\\", \\\"{x:463,y:729,t:1527873026221};\\\", \\\"{x:491,y:729,t:1527873026234};\\\", \\\"{x:582,y:739,t:1527873026251};\\\", \\\"{x:672,y:754,t:1527873026266};\\\", \\\"{x:764,y:767,t:1527873026284};\\\", \\\"{x:866,y:779,t:1527873026300};\\\", \\\"{x:1012,y:804,t:1527873026318};\\\", \\\"{x:1072,y:816,t:1527873026334};\\\", \\\"{x:1123,y:832,t:1527873026351};\\\", \\\"{x:1149,y:846,t:1527873026369};\\\", \\\"{x:1164,y:854,t:1527873026384};\\\", \\\"{x:1169,y:862,t:1527873026401};\\\", \\\"{x:1171,y:866,t:1527873026418};\\\", \\\"{x:1172,y:871,t:1527873026434};\\\", \\\"{x:1173,y:873,t:1527873026451};\\\", \\\"{x:1173,y:875,t:1527873026468};\\\", \\\"{x:1173,y:876,t:1527873026509};\\\", \\\"{x:1173,y:880,t:1527873026519};\\\", \\\"{x:1173,y:887,t:1527873026535};\\\", \\\"{x:1173,y:892,t:1527873026552};\\\", \\\"{x:1173,y:895,t:1527873026569};\\\", \\\"{x:1173,y:897,t:1527873026585};\\\", \\\"{x:1173,y:899,t:1527873026601};\\\", \\\"{x:1175,y:901,t:1527873026619};\\\", \\\"{x:1179,y:903,t:1527873026635};\\\", \\\"{x:1184,y:905,t:1527873026652};\\\", \\\"{x:1192,y:907,t:1527873026668};\\\", \\\"{x:1205,y:910,t:1527873026685};\\\", \\\"{x:1211,y:913,t:1527873026702};\\\", \\\"{x:1215,y:914,t:1527873026718};\\\", \\\"{x:1226,y:921,t:1527873026736};\\\", \\\"{x:1236,y:929,t:1527873026751};\\\", \\\"{x:1241,y:933,t:1527873026769};\\\", \\\"{x:1244,y:934,t:1527873026786};\\\", \\\"{x:1245,y:935,t:1527873026802};\\\", \\\"{x:1246,y:936,t:1527873026818};\\\", \\\"{x:1248,y:936,t:1527873026877};\\\", \\\"{x:1248,y:937,t:1527873026885};\\\", \\\"{x:1251,y:939,t:1527873026902};\\\", \\\"{x:1254,y:940,t:1527873026918};\\\", \\\"{x:1263,y:943,t:1527873026935};\\\", \\\"{x:1284,y:948,t:1527873026952};\\\", \\\"{x:1303,y:954,t:1527873026968};\\\", \\\"{x:1321,y:957,t:1527873026985};\\\", \\\"{x:1336,y:959,t:1527873027002};\\\", \\\"{x:1346,y:960,t:1527873027019};\\\", \\\"{x:1360,y:960,t:1527873027035};\\\", \\\"{x:1370,y:960,t:1527873027052};\\\", \\\"{x:1377,y:960,t:1527873027068};\\\", \\\"{x:1378,y:960,t:1527873027085};\\\", \\\"{x:1379,y:960,t:1527873027340};\\\", \\\"{x:1379,y:955,t:1527873028948};\\\", \\\"{x:1379,y:945,t:1527873028957};\\\", \\\"{x:1378,y:937,t:1527873028970};\\\", \\\"{x:1375,y:925,t:1527873028988};\\\", \\\"{x:1373,y:922,t:1527873029003};\\\", \\\"{x:1373,y:918,t:1527873029020};\\\", \\\"{x:1371,y:909,t:1527873029037};\\\", \\\"{x:1370,y:906,t:1527873029053};\\\", \\\"{x:1369,y:903,t:1527873029071};\\\", \\\"{x:1368,y:901,t:1527873029087};\\\", \\\"{x:1368,y:899,t:1527873029103};\\\", \\\"{x:1365,y:895,t:1527873029120};\\\", \\\"{x:1360,y:888,t:1527873029137};\\\", \\\"{x:1341,y:873,t:1527873029154};\\\", \\\"{x:1287,y:844,t:1527873029170};\\\", \\\"{x:1201,y:807,t:1527873029187};\\\", \\\"{x:1130,y:778,t:1527873029203};\\\", \\\"{x:1082,y:756,t:1527873029221};\\\", \\\"{x:1048,y:731,t:1527873029238};\\\", \\\"{x:1025,y:709,t:1527873029254};\\\", \\\"{x:1004,y:688,t:1527873029270};\\\", \\\"{x:991,y:674,t:1527873029287};\\\", \\\"{x:985,y:668,t:1527873029304};\\\", \\\"{x:981,y:665,t:1527873029320};\\\", \\\"{x:969,y:659,t:1527873029338};\\\", \\\"{x:945,y:653,t:1527873029355};\\\", \\\"{x:897,y:645,t:1527873029371};\\\", \\\"{x:813,y:632,t:1527873029388};\\\", \\\"{x:714,y:621,t:1527873029406};\\\", \\\"{x:624,y:619,t:1527873029421};\\\", \\\"{x:533,y:624,t:1527873029437};\\\", \\\"{x:485,y:639,t:1527873029454};\\\", \\\"{x:447,y:653,t:1527873029471};\\\", \\\"{x:414,y:669,t:1527873029487};\\\", \\\"{x:392,y:679,t:1527873029505};\\\", \\\"{x:372,y:691,t:1527873029520};\\\", \\\"{x:361,y:698,t:1527873029537};\\\", \\\"{x:358,y:700,t:1527873029554};\\\", \\\"{x:356,y:702,t:1527873029571};\\\", \\\"{x:354,y:705,t:1527873029587};\\\", \\\"{x:354,y:706,t:1527873029603};\\\", \\\"{x:354,y:707,t:1527873029620};\\\", \\\"{x:354,y:708,t:1527873029637};\\\", \\\"{x:354,y:709,t:1527873029654};\\\", \\\"{x:354,y:710,t:1527873029670};\\\", \\\"{x:355,y:712,t:1527873029689};\\\", \\\"{x:363,y:712,t:1527873029704};\\\", \\\"{x:381,y:712,t:1527873029721};\\\", \\\"{x:403,y:705,t:1527873029738};\\\", \\\"{x:430,y:700,t:1527873029754};\\\", \\\"{x:451,y:700,t:1527873029771};\\\", \\\"{x:465,y:701,t:1527873029788};\\\", \\\"{x:476,y:706,t:1527873029804};\\\", \\\"{x:491,y:718,t:1527873029820};\\\", \\\"{x:498,y:726,t:1527873029837};\\\", \\\"{x:508,y:737,t:1527873029854};\\\", \\\"{x:516,y:744,t:1527873029871};\\\", \\\"{x:521,y:748,t:1527873029888};\\\", \\\"{x:523,y:749,t:1527873029905};\\\", \\\"{x:524,y:749,t:1527873029989};\\\", \\\"{x:525,y:744,t:1527873030004};\\\", \\\"{x:528,y:732,t:1527873030021};\\\", \\\"{x:529,y:725,t:1527873030037};\\\", \\\"{x:529,y:720,t:1527873030054};\\\", \\\"{x:529,y:718,t:1527873030071};\\\", \\\"{x:529,y:717,t:1527873030088};\\\" ] }, { \\\"rt\\\": 96039, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 312494, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -Z -12 PM-O -11 AM-I -E -E -06 PM-12 PM-11 AM-01 PM-02 PM-U -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:708,t:1527873032173};\\\", \\\"{x:514,y:656,t:1527873032190};\\\", \\\"{x:496,y:612,t:1527873032207};\\\", \\\"{x:479,y:569,t:1527873032222};\\\", \\\"{x:474,y:548,t:1527873032239};\\\", \\\"{x:468,y:533,t:1527873032256};\\\", \\\"{x:464,y:525,t:1527873032272};\\\", \\\"{x:463,y:521,t:1527873032289};\\\", \\\"{x:460,y:517,t:1527873032307};\\\", \\\"{x:459,y:512,t:1527873032322};\\\", \\\"{x:457,y:510,t:1527873032339};\\\", \\\"{x:456,y:506,t:1527873032356};\\\", \\\"{x:455,y:503,t:1527873032373};\\\", \\\"{x:454,y:500,t:1527873032390};\\\", \\\"{x:452,y:497,t:1527873032406};\\\", \\\"{x:449,y:493,t:1527873032423};\\\", \\\"{x:448,y:491,t:1527873032439};\\\", \\\"{x:447,y:490,t:1527873032461};\\\", \\\"{x:445,y:489,t:1527873032485};\\\", \\\"{x:444,y:488,t:1527873032493};\\\", \\\"{x:439,y:487,t:1527873032507};\\\", \\\"{x:435,y:487,t:1527873032524};\\\", \\\"{x:430,y:486,t:1527873032541};\\\", \\\"{x:423,y:485,t:1527873032557};\\\", \\\"{x:413,y:484,t:1527873032573};\\\", \\\"{x:404,y:483,t:1527873032590};\\\", \\\"{x:395,y:482,t:1527873032606};\\\", \\\"{x:389,y:482,t:1527873032624};\\\", \\\"{x:383,y:482,t:1527873032641};\\\", \\\"{x:379,y:482,t:1527873032658};\\\", \\\"{x:376,y:482,t:1527873032674};\\\", \\\"{x:374,y:482,t:1527873032690};\\\", \\\"{x:372,y:482,t:1527873032708};\\\", \\\"{x:369,y:482,t:1527873032724};\\\", \\\"{x:365,y:484,t:1527873032741};\\\", \\\"{x:362,y:485,t:1527873032757};\\\", \\\"{x:359,y:486,t:1527873032774};\\\", \\\"{x:356,y:487,t:1527873032791};\\\", \\\"{x:355,y:487,t:1527873032808};\\\", \\\"{x:353,y:487,t:1527873032825};\\\", \\\"{x:350,y:488,t:1527873032841};\\\", \\\"{x:349,y:489,t:1527873032857};\\\", \\\"{x:346,y:489,t:1527873032875};\\\", \\\"{x:345,y:490,t:1527873032891};\\\", \\\"{x:343,y:490,t:1527873032907};\\\", \\\"{x:342,y:491,t:1527873032925};\\\", \\\"{x:340,y:492,t:1527873032941};\\\", \\\"{x:338,y:492,t:1527873032958};\\\", \\\"{x:337,y:493,t:1527873032974};\\\", \\\"{x:336,y:493,t:1527873032996};\\\", \\\"{x:335,y:493,t:1527873033012};\\\", \\\"{x:333,y:494,t:1527873033024};\\\", \\\"{x:332,y:495,t:1527873033044};\\\", \\\"{x:330,y:495,t:1527873033076};\\\", \\\"{x:330,y:496,t:1527873033101};\\\", \\\"{x:329,y:496,t:1527873033125};\\\", \\\"{x:328,y:497,t:1527873033141};\\\", \\\"{x:327,y:498,t:1527873033180};\\\", \\\"{x:326,y:498,t:1527873033221};\\\", \\\"{x:326,y:499,t:1527873033245};\\\", \\\"{x:325,y:499,t:1527873033278};\\\", \\\"{x:324,y:499,t:1527873033301};\\\", \\\"{x:325,y:499,t:1527873036253};\\\", \\\"{x:328,y:498,t:1527873036269};\\\", \\\"{x:330,y:498,t:1527873036316};\\\", \\\"{x:331,y:498,t:1527873036364};\\\", \\\"{x:331,y:497,t:1527873036380};\\\", \\\"{x:332,y:497,t:1527873036396};\\\", \\\"{x:333,y:496,t:1527873036413};\\\", \\\"{x:334,y:495,t:1527873036453};\\\", \\\"{x:336,y:495,t:1527873036476};\\\", \\\"{x:337,y:494,t:1527873036493};\\\", \\\"{x:338,y:493,t:1527873036501};\\\", \\\"{x:339,y:493,t:1527873036515};\\\", \\\"{x:341,y:492,t:1527873036532};\\\", \\\"{x:343,y:492,t:1527873036549};\\\", \\\"{x:345,y:491,t:1527873036566};\\\", \\\"{x:345,y:490,t:1527873036583};\\\", \\\"{x:347,y:490,t:1527873036600};\\\", \\\"{x:349,y:489,t:1527873036617};\\\", \\\"{x:350,y:489,t:1527873036633};\\\", \\\"{x:352,y:489,t:1527873036650};\\\", \\\"{x:354,y:488,t:1527873036666};\\\", \\\"{x:357,y:487,t:1527873036684};\\\", \\\"{x:362,y:486,t:1527873036700};\\\", \\\"{x:370,y:483,t:1527873036717};\\\", \\\"{x:372,y:483,t:1527873036733};\\\", \\\"{x:374,y:483,t:1527873036750};\\\", \\\"{x:375,y:483,t:1527873036781};\\\", \\\"{x:377,y:483,t:1527873036789};\\\", \\\"{x:378,y:483,t:1527873036830};\\\", \\\"{x:379,y:483,t:1527873036837};\\\", \\\"{x:380,y:483,t:1527873036851};\\\", \\\"{x:381,y:483,t:1527873036867};\\\", \\\"{x:382,y:482,t:1527873036883};\\\", \\\"{x:384,y:482,t:1527873036901};\\\", \\\"{x:386,y:480,t:1527873036917};\\\", \\\"{x:390,y:480,t:1527873036934};\\\", \\\"{x:392,y:479,t:1527873036957};\\\", \\\"{x:393,y:479,t:1527873036967};\\\", \\\"{x:395,y:478,t:1527873036983};\\\", \\\"{x:397,y:478,t:1527873037001};\\\", \\\"{x:400,y:476,t:1527873037018};\\\", \\\"{x:403,y:476,t:1527873037034};\\\", \\\"{x:405,y:476,t:1527873037051};\\\", \\\"{x:407,y:475,t:1527873037067};\\\", \\\"{x:409,y:474,t:1527873037084};\\\", \\\"{x:412,y:473,t:1527873037102};\\\", \\\"{x:413,y:473,t:1527873037117};\\\", \\\"{x:414,y:473,t:1527873037149};\\\", \\\"{x:416,y:469,t:1527873037445};\\\", \\\"{x:419,y:465,t:1527873037453};\\\", \\\"{x:425,y:459,t:1527873037469};\\\", \\\"{x:430,y:452,t:1527873037485};\\\", \\\"{x:435,y:446,t:1527873037501};\\\", \\\"{x:443,y:439,t:1527873037519};\\\", \\\"{x:447,y:432,t:1527873037536};\\\", \\\"{x:454,y:427,t:1527873037552};\\\", \\\"{x:457,y:425,t:1527873037569};\\\", \\\"{x:459,y:423,t:1527873037586};\\\", \\\"{x:460,y:422,t:1527873037602};\\\", \\\"{x:462,y:421,t:1527873037619};\\\", \\\"{x:464,y:419,t:1527873037637};\\\", \\\"{x:465,y:418,t:1527873037661};\\\", \\\"{x:466,y:418,t:1527873037669};\\\", \\\"{x:469,y:416,t:1527873037686};\\\", \\\"{x:471,y:415,t:1527873037703};\\\", \\\"{x:473,y:415,t:1527873037718};\\\", \\\"{x:474,y:415,t:1527873037736};\\\", \\\"{x:477,y:415,t:1527873037753};\\\", \\\"{x:484,y:413,t:1527873037769};\\\", \\\"{x:492,y:412,t:1527873037786};\\\", \\\"{x:501,y:412,t:1527873037803};\\\", \\\"{x:507,y:412,t:1527873037819};\\\", \\\"{x:510,y:412,t:1527873037836};\\\", \\\"{x:518,y:412,t:1527873037853};\\\", \\\"{x:521,y:412,t:1527873037870};\\\", \\\"{x:524,y:412,t:1527873037886};\\\", \\\"{x:526,y:412,t:1527873037903};\\\", \\\"{x:528,y:412,t:1527873037920};\\\", \\\"{x:532,y:412,t:1527873037936};\\\", \\\"{x:539,y:412,t:1527873037953};\\\", \\\"{x:546,y:412,t:1527873037970};\\\", \\\"{x:554,y:412,t:1527873037987};\\\", \\\"{x:568,y:412,t:1527873038003};\\\", \\\"{x:578,y:411,t:1527873038020};\\\", \\\"{x:592,y:407,t:1527873038038};\\\", \\\"{x:597,y:405,t:1527873038053};\\\", \\\"{x:605,y:402,t:1527873038070};\\\", \\\"{x:614,y:399,t:1527873038087};\\\", \\\"{x:625,y:395,t:1527873038103};\\\", \\\"{x:628,y:394,t:1527873038120};\\\", \\\"{x:630,y:394,t:1527873038137};\\\", \\\"{x:631,y:394,t:1527873038318};\\\", \\\"{x:632,y:394,t:1527873038325};\\\", \\\"{x:634,y:396,t:1527873038337};\\\", \\\"{x:634,y:399,t:1527873038354};\\\", \\\"{x:635,y:402,t:1527873038371};\\\", \\\"{x:635,y:405,t:1527873038387};\\\", \\\"{x:636,y:407,t:1527873038404};\\\", \\\"{x:636,y:410,t:1527873038421};\\\", \\\"{x:636,y:412,t:1527873038437};\\\", \\\"{x:636,y:415,t:1527873038454};\\\", \\\"{x:636,y:418,t:1527873038471};\\\", \\\"{x:636,y:425,t:1527873038488};\\\", \\\"{x:636,y:433,t:1527873038504};\\\", \\\"{x:633,y:439,t:1527873038521};\\\", \\\"{x:630,y:447,t:1527873038539};\\\", \\\"{x:628,y:450,t:1527873038554};\\\", \\\"{x:627,y:453,t:1527873038571};\\\", \\\"{x:625,y:455,t:1527873038588};\\\", \\\"{x:622,y:458,t:1527873038605};\\\", \\\"{x:621,y:459,t:1527873038621};\\\", \\\"{x:620,y:460,t:1527873038638};\\\", \\\"{x:618,y:461,t:1527873038655};\\\", \\\"{x:616,y:462,t:1527873038671};\\\", \\\"{x:614,y:464,t:1527873038688};\\\", \\\"{x:612,y:465,t:1527873038705};\\\", \\\"{x:610,y:467,t:1527873038722};\\\", \\\"{x:609,y:468,t:1527873038738};\\\", \\\"{x:607,y:468,t:1527873038755};\\\", \\\"{x:606,y:470,t:1527873038773};\\\", \\\"{x:605,y:470,t:1527873038797};\\\", \\\"{x:604,y:470,t:1527873038918};\\\", \\\"{x:601,y:471,t:1527873039198};\\\", \\\"{x:600,y:472,t:1527873039206};\\\", \\\"{x:597,y:473,t:1527873039223};\\\", \\\"{x:594,y:475,t:1527873039239};\\\", \\\"{x:589,y:476,t:1527873039256};\\\", \\\"{x:585,y:477,t:1527873039273};\\\", \\\"{x:576,y:479,t:1527873039290};\\\", \\\"{x:570,y:481,t:1527873039306};\\\", \\\"{x:565,y:481,t:1527873039323};\\\", \\\"{x:559,y:483,t:1527873039340};\\\", \\\"{x:554,y:485,t:1527873039356};\\\", \\\"{x:545,y:487,t:1527873039373};\\\", \\\"{x:536,y:489,t:1527873039390};\\\", \\\"{x:527,y:490,t:1527873039407};\\\", \\\"{x:515,y:491,t:1527873039423};\\\", \\\"{x:503,y:494,t:1527873039440};\\\", \\\"{x:489,y:495,t:1527873039457};\\\", \\\"{x:479,y:496,t:1527873039473};\\\", \\\"{x:470,y:497,t:1527873039490};\\\", \\\"{x:464,y:499,t:1527873039507};\\\", \\\"{x:460,y:499,t:1527873039523};\\\", \\\"{x:458,y:500,t:1527873039540};\\\", \\\"{x:457,y:500,t:1527873039557};\\\", \\\"{x:456,y:500,t:1527873039574};\\\", \\\"{x:455,y:500,t:1527873039590};\\\", \\\"{x:453,y:502,t:1527873039607};\\\", \\\"{x:451,y:502,t:1527873040125};\\\", \\\"{x:450,y:502,t:1527873040894};\\\", \\\"{x:449,y:500,t:1527873040917};\\\", \\\"{x:448,y:498,t:1527873040928};\\\", \\\"{x:447,y:496,t:1527873040943};\\\", \\\"{x:446,y:494,t:1527873040960};\\\", \\\"{x:446,y:493,t:1527873040977};\\\", \\\"{x:446,y:492,t:1527873040994};\\\", \\\"{x:445,y:490,t:1527873041010};\\\", \\\"{x:444,y:489,t:1527873041026};\\\", \\\"{x:444,y:488,t:1527873041061};\\\", \\\"{x:444,y:486,t:1527873041492};\\\", \\\"{x:447,y:484,t:1527873041500};\\\", \\\"{x:454,y:480,t:1527873041510};\\\", \\\"{x:464,y:474,t:1527873041528};\\\", \\\"{x:471,y:472,t:1527873041545};\\\", \\\"{x:476,y:471,t:1527873041561};\\\", \\\"{x:477,y:470,t:1527873041577};\\\", \\\"{x:478,y:469,t:1527873041757};\\\", \\\"{x:480,y:468,t:1527873041765};\\\", \\\"{x:483,y:467,t:1527873041779};\\\", \\\"{x:487,y:465,t:1527873041795};\\\", \\\"{x:496,y:461,t:1527873041813};\\\", \\\"{x:506,y:460,t:1527873041830};\\\", \\\"{x:508,y:459,t:1527873041846};\\\", \\\"{x:510,y:458,t:1527873041862};\\\", \\\"{x:511,y:458,t:1527873041910};\\\", \\\"{x:512,y:457,t:1527873041918};\\\", \\\"{x:513,y:457,t:1527873041981};\\\", \\\"{x:513,y:456,t:1527873041996};\\\", \\\"{x:514,y:456,t:1527873042013};\\\", \\\"{x:516,y:456,t:1527873042045};\\\", \\\"{x:517,y:456,t:1527873042053};\\\", \\\"{x:518,y:455,t:1527873042068};\\\", \\\"{x:519,y:455,t:1527873042085};\\\", \\\"{x:520,y:454,t:1527873042096};\\\", \\\"{x:522,y:453,t:1527873042113};\\\", \\\"{x:523,y:453,t:1527873042129};\\\", \\\"{x:526,y:452,t:1527873042146};\\\", \\\"{x:527,y:451,t:1527873042163};\\\", \\\"{x:529,y:450,t:1527873042180};\\\", \\\"{x:531,y:450,t:1527873042196};\\\", \\\"{x:533,y:448,t:1527873042213};\\\", \\\"{x:535,y:448,t:1527873042230};\\\", \\\"{x:538,y:447,t:1527873042246};\\\", \\\"{x:541,y:445,t:1527873042263};\\\", \\\"{x:542,y:445,t:1527873042280};\\\", \\\"{x:544,y:444,t:1527873042297};\\\", \\\"{x:547,y:444,t:1527873042313};\\\", \\\"{x:548,y:444,t:1527873042330};\\\", \\\"{x:549,y:443,t:1527873042347};\\\", \\\"{x:551,y:442,t:1527873042363};\\\", \\\"{x:554,y:442,t:1527873042380};\\\", \\\"{x:557,y:441,t:1527873042397};\\\", \\\"{x:558,y:441,t:1527873042413};\\\", \\\"{x:559,y:441,t:1527873042437};\\\", \\\"{x:566,y:441,t:1527873044174};\\\", \\\"{x:582,y:441,t:1527873044184};\\\", \\\"{x:625,y:441,t:1527873044201};\\\", \\\"{x:678,y:441,t:1527873044218};\\\", \\\"{x:733,y:441,t:1527873044234};\\\", \\\"{x:808,y:441,t:1527873044251};\\\", \\\"{x:881,y:441,t:1527873044268};\\\", \\\"{x:1001,y:448,t:1527873044284};\\\", \\\"{x:1218,y:476,t:1527873044301};\\\", \\\"{x:1351,y:493,t:1527873044318};\\\", \\\"{x:1451,y:497,t:1527873044335};\\\", \\\"{x:1515,y:497,t:1527873044352};\\\", \\\"{x:1547,y:497,t:1527873044369};\\\", \\\"{x:1556,y:498,t:1527873044385};\\\", \\\"{x:1558,y:498,t:1527873044402};\\\", \\\"{x:1558,y:500,t:1527873044853};\\\", \\\"{x:1558,y:504,t:1527873044869};\\\", \\\"{x:1558,y:507,t:1527873044887};\\\", \\\"{x:1557,y:511,t:1527873044904};\\\", \\\"{x:1556,y:516,t:1527873044919};\\\", \\\"{x:1555,y:524,t:1527873044937};\\\", \\\"{x:1554,y:526,t:1527873044954};\\\", \\\"{x:1554,y:528,t:1527873044969};\\\", \\\"{x:1554,y:529,t:1527873044986};\\\", \\\"{x:1552,y:530,t:1527873045003};\\\", \\\"{x:1552,y:531,t:1527873045020};\\\", \\\"{x:1550,y:531,t:1527873045036};\\\", \\\"{x:1547,y:534,t:1527873045054};\\\", \\\"{x:1542,y:537,t:1527873045070};\\\", \\\"{x:1538,y:542,t:1527873045087};\\\", \\\"{x:1536,y:545,t:1527873045103};\\\", \\\"{x:1527,y:555,t:1527873045120};\\\", \\\"{x:1517,y:566,t:1527873045136};\\\", \\\"{x:1503,y:582,t:1527873045153};\\\", \\\"{x:1485,y:601,t:1527873045171};\\\", \\\"{x:1465,y:619,t:1527873045187};\\\", \\\"{x:1443,y:638,t:1527873045203};\\\", \\\"{x:1421,y:652,t:1527873045221};\\\", \\\"{x:1390,y:671,t:1527873045237};\\\", \\\"{x:1372,y:680,t:1527873045253};\\\", \\\"{x:1363,y:684,t:1527873045270};\\\", \\\"{x:1360,y:684,t:1527873045288};\\\", \\\"{x:1360,y:685,t:1527873045326};\\\", \\\"{x:1359,y:685,t:1527873045869};\\\", \\\"{x:1359,y:676,t:1527873045877};\\\", \\\"{x:1366,y:663,t:1527873045889};\\\", \\\"{x:1377,y:647,t:1527873045906};\\\", \\\"{x:1384,y:632,t:1527873045923};\\\", \\\"{x:1392,y:616,t:1527873045938};\\\", \\\"{x:1398,y:604,t:1527873045955};\\\", \\\"{x:1402,y:595,t:1527873045972};\\\", \\\"{x:1403,y:586,t:1527873045989};\\\", \\\"{x:1403,y:572,t:1527873046005};\\\", \\\"{x:1403,y:563,t:1527873046022};\\\", \\\"{x:1403,y:556,t:1527873046040};\\\", \\\"{x:1403,y:551,t:1527873046055};\\\", \\\"{x:1404,y:548,t:1527873046073};\\\", \\\"{x:1404,y:545,t:1527873046089};\\\", \\\"{x:1404,y:543,t:1527873046105};\\\", \\\"{x:1404,y:540,t:1527873046123};\\\", \\\"{x:1404,y:537,t:1527873046140};\\\", \\\"{x:1404,y:535,t:1527873046157};\\\", \\\"{x:1404,y:534,t:1527873046173};\\\", \\\"{x:1404,y:532,t:1527873046190};\\\", \\\"{x:1404,y:528,t:1527873046207};\\\", \\\"{x:1404,y:526,t:1527873046222};\\\", \\\"{x:1404,y:525,t:1527873046240};\\\", \\\"{x:1404,y:523,t:1527873046257};\\\", \\\"{x:1404,y:519,t:1527873046272};\\\", \\\"{x:1403,y:515,t:1527873046289};\\\", \\\"{x:1402,y:510,t:1527873046306};\\\", \\\"{x:1401,y:506,t:1527873046323};\\\", \\\"{x:1400,y:501,t:1527873046339};\\\", \\\"{x:1399,y:496,t:1527873046357};\\\", \\\"{x:1398,y:491,t:1527873046373};\\\", \\\"{x:1397,y:487,t:1527873046389};\\\", \\\"{x:1395,y:484,t:1527873046406};\\\", \\\"{x:1395,y:482,t:1527873046424};\\\", \\\"{x:1394,y:481,t:1527873046440};\\\", \\\"{x:1394,y:479,t:1527873046456};\\\", \\\"{x:1394,y:478,t:1527873046477};\\\", \\\"{x:1393,y:477,t:1527873046541};\\\", \\\"{x:1392,y:477,t:1527873046557};\\\", \\\"{x:1392,y:476,t:1527873046589};\\\", \\\"{x:1391,y:476,t:1527873046608};\\\", \\\"{x:1383,y:477,t:1527873046624};\\\", \\\"{x:1354,y:493,t:1527873046640};\\\", \\\"{x:1319,y:513,t:1527873046658};\\\", \\\"{x:1288,y:534,t:1527873046673};\\\", \\\"{x:1273,y:546,t:1527873046690};\\\", \\\"{x:1270,y:549,t:1527873046708};\\\", \\\"{x:1269,y:550,t:1527873046723};\\\", \\\"{x:1270,y:550,t:1527873046838};\\\", \\\"{x:1275,y:548,t:1527873046845};\\\", \\\"{x:1285,y:543,t:1527873046857};\\\", \\\"{x:1303,y:532,t:1527873046874};\\\", \\\"{x:1318,y:524,t:1527873046891};\\\", \\\"{x:1324,y:520,t:1527873046908};\\\", \\\"{x:1326,y:518,t:1527873046924};\\\", \\\"{x:1327,y:517,t:1527873046941};\\\", \\\"{x:1327,y:516,t:1527873047078};\\\", \\\"{x:1321,y:516,t:1527873047091};\\\", \\\"{x:1303,y:527,t:1527873047108};\\\", \\\"{x:1291,y:532,t:1527873047125};\\\", \\\"{x:1282,y:536,t:1527873047141};\\\", \\\"{x:1282,y:533,t:1527873047277};\\\", \\\"{x:1282,y:530,t:1527873047292};\\\", \\\"{x:1287,y:523,t:1527873047309};\\\", \\\"{x:1294,y:513,t:1527873047325};\\\", \\\"{x:1297,y:509,t:1527873047342};\\\", \\\"{x:1299,y:507,t:1527873047359};\\\", \\\"{x:1299,y:504,t:1527873047376};\\\", \\\"{x:1301,y:503,t:1527873047392};\\\", \\\"{x:1301,y:502,t:1527873047409};\\\", \\\"{x:1302,y:501,t:1527873047638};\\\", \\\"{x:1304,y:500,t:1527873047645};\\\", \\\"{x:1305,y:499,t:1527873047659};\\\", \\\"{x:1307,y:498,t:1527873047676};\\\", \\\"{x:1308,y:498,t:1527873047693};\\\", \\\"{x:1308,y:497,t:1527873047709};\\\", \\\"{x:1310,y:497,t:1527873047729};\\\", \\\"{x:1311,y:497,t:1527873047743};\\\", \\\"{x:1313,y:495,t:1527873047759};\\\", \\\"{x:1314,y:495,t:1527873047776};\\\", \\\"{x:1315,y:494,t:1527873047793};\\\", \\\"{x:1316,y:494,t:1527873047808};\\\", \\\"{x:1317,y:494,t:1527873047826};\\\", \\\"{x:1317,y:496,t:1527873048046};\\\", \\\"{x:1317,y:497,t:1527873048061};\\\", \\\"{x:1317,y:500,t:1527873048077};\\\", \\\"{x:1317,y:501,t:1527873048093};\\\", \\\"{x:1317,y:503,t:1527873048112};\\\", \\\"{x:1316,y:504,t:1527873048141};\\\", \\\"{x:1316,y:505,t:1527873049231};\\\", \\\"{x:1317,y:522,t:1527873049247};\\\", \\\"{x:1320,y:540,t:1527873049264};\\\", \\\"{x:1323,y:553,t:1527873049279};\\\", \\\"{x:1323,y:559,t:1527873049296};\\\", \\\"{x:1323,y:564,t:1527873049313};\\\", \\\"{x:1324,y:571,t:1527873049330};\\\", \\\"{x:1326,y:582,t:1527873049347};\\\", \\\"{x:1328,y:594,t:1527873049364};\\\", \\\"{x:1330,y:608,t:1527873049381};\\\", \\\"{x:1332,y:619,t:1527873049396};\\\", \\\"{x:1335,y:630,t:1527873049414};\\\", \\\"{x:1336,y:635,t:1527873049431};\\\", \\\"{x:1336,y:640,t:1527873049446};\\\", \\\"{x:1337,y:647,t:1527873049463};\\\", \\\"{x:1338,y:657,t:1527873049480};\\\", \\\"{x:1339,y:668,t:1527873049497};\\\", \\\"{x:1342,y:683,t:1527873049513};\\\", \\\"{x:1343,y:697,t:1527873049531};\\\", \\\"{x:1346,y:708,t:1527873049547};\\\", \\\"{x:1346,y:721,t:1527873049564};\\\", \\\"{x:1347,y:731,t:1527873049580};\\\", \\\"{x:1347,y:749,t:1527873049597};\\\", \\\"{x:1348,y:764,t:1527873049615};\\\", \\\"{x:1348,y:779,t:1527873049630};\\\", \\\"{x:1348,y:794,t:1527873049648};\\\", \\\"{x:1348,y:805,t:1527873049665};\\\", \\\"{x:1348,y:818,t:1527873049681};\\\", \\\"{x:1348,y:830,t:1527873049697};\\\", \\\"{x:1348,y:844,t:1527873049715};\\\", \\\"{x:1348,y:858,t:1527873049731};\\\", \\\"{x:1348,y:873,t:1527873049747};\\\", \\\"{x:1348,y:888,t:1527873049765};\\\", \\\"{x:1346,y:905,t:1527873049782};\\\", \\\"{x:1341,y:917,t:1527873049797};\\\", \\\"{x:1339,y:925,t:1527873049815};\\\", \\\"{x:1335,y:933,t:1527873049831};\\\", \\\"{x:1333,y:938,t:1527873049847};\\\", \\\"{x:1332,y:939,t:1527873049864};\\\", \\\"{x:1332,y:940,t:1527873049884};\\\", \\\"{x:1332,y:941,t:1527873049908};\\\", \\\"{x:1332,y:942,t:1527873049916};\\\", \\\"{x:1332,y:944,t:1527873049931};\\\", \\\"{x:1331,y:945,t:1527873049948};\\\", \\\"{x:1331,y:946,t:1527873049964};\\\", \\\"{x:1331,y:948,t:1527873049981};\\\", \\\"{x:1331,y:950,t:1527873049998};\\\", \\\"{x:1331,y:953,t:1527873050014};\\\", \\\"{x:1331,y:956,t:1527873050031};\\\", \\\"{x:1331,y:959,t:1527873050049};\\\", \\\"{x:1331,y:961,t:1527873050065};\\\", \\\"{x:1331,y:964,t:1527873050082};\\\", \\\"{x:1331,y:969,t:1527873050098};\\\", \\\"{x:1331,y:973,t:1527873050116};\\\", \\\"{x:1331,y:975,t:1527873050132};\\\", \\\"{x:1331,y:976,t:1527873050148};\\\", \\\"{x:1331,y:978,t:1527873050165};\\\", \\\"{x:1330,y:978,t:1527873050182};\\\", \\\"{x:1330,y:979,t:1527873050198};\\\", \\\"{x:1330,y:980,t:1527873050215};\\\", \\\"{x:1329,y:980,t:1527873050232};\\\", \\\"{x:1329,y:981,t:1527873050249};\\\", \\\"{x:1326,y:981,t:1527873050266};\\\", \\\"{x:1324,y:983,t:1527873050282};\\\", \\\"{x:1321,y:983,t:1527873050299};\\\", \\\"{x:1320,y:983,t:1527873050315};\\\", \\\"{x:1319,y:983,t:1527873050333};\\\", \\\"{x:1319,y:981,t:1527873050405};\\\", \\\"{x:1317,y:978,t:1527873050416};\\\", \\\"{x:1315,y:972,t:1527873050432};\\\", \\\"{x:1315,y:969,t:1527873050450};\\\", \\\"{x:1313,y:965,t:1527873050467};\\\", \\\"{x:1313,y:964,t:1527873050482};\\\", \\\"{x:1313,y:962,t:1527873050500};\\\", \\\"{x:1313,y:959,t:1527873051045};\\\", \\\"{x:1313,y:958,t:1527873051053};\\\", \\\"{x:1313,y:955,t:1527873051068};\\\", \\\"{x:1313,y:948,t:1527873051084};\\\", \\\"{x:1313,y:946,t:1527873051100};\\\", \\\"{x:1313,y:942,t:1527873051118};\\\", \\\"{x:1312,y:941,t:1527873051135};\\\", \\\"{x:1312,y:939,t:1527873051151};\\\", \\\"{x:1312,y:938,t:1527873051168};\\\", \\\"{x:1312,y:937,t:1527873051189};\\\", \\\"{x:1312,y:936,t:1527873051205};\\\", \\\"{x:1312,y:935,t:1527873051230};\\\", \\\"{x:1312,y:934,t:1527873051261};\\\", \\\"{x:1312,y:933,t:1527873051285};\\\", \\\"{x:1312,y:931,t:1527873051301};\\\", \\\"{x:1312,y:930,t:1527873051318};\\\", \\\"{x:1311,y:928,t:1527873051334};\\\", \\\"{x:1311,y:926,t:1527873051351};\\\", \\\"{x:1311,y:922,t:1527873051368};\\\", \\\"{x:1309,y:918,t:1527873051384};\\\", \\\"{x:1309,y:913,t:1527873051401};\\\", \\\"{x:1309,y:909,t:1527873051418};\\\", \\\"{x:1309,y:905,t:1527873051434};\\\", \\\"{x:1309,y:903,t:1527873051451};\\\", \\\"{x:1309,y:900,t:1527873051468};\\\", \\\"{x:1309,y:899,t:1527873051484};\\\", \\\"{x:1309,y:898,t:1527873051501};\\\", \\\"{x:1309,y:897,t:1527873051518};\\\", \\\"{x:1309,y:896,t:1527873051548};\\\", \\\"{x:1309,y:895,t:1527873051588};\\\", \\\"{x:1309,y:893,t:1527873051709};\\\", \\\"{x:1309,y:890,t:1527873051718};\\\", \\\"{x:1309,y:887,t:1527873051735};\\\", \\\"{x:1309,y:884,t:1527873051752};\\\", \\\"{x:1309,y:881,t:1527873051769};\\\", \\\"{x:1309,y:879,t:1527873051785};\\\", \\\"{x:1309,y:874,t:1527873051802};\\\", \\\"{x:1309,y:869,t:1527873051820};\\\", \\\"{x:1309,y:866,t:1527873051835};\\\", \\\"{x:1309,y:858,t:1527873051852};\\\", \\\"{x:1309,y:852,t:1527873051869};\\\", \\\"{x:1309,y:845,t:1527873051885};\\\", \\\"{x:1309,y:840,t:1527873051903};\\\", \\\"{x:1309,y:835,t:1527873051920};\\\", \\\"{x:1309,y:830,t:1527873051937};\\\", \\\"{x:1309,y:825,t:1527873051953};\\\", \\\"{x:1309,y:819,t:1527873051970};\\\", \\\"{x:1309,y:813,t:1527873051986};\\\", \\\"{x:1309,y:807,t:1527873052003};\\\", \\\"{x:1309,y:804,t:1527873052019};\\\", \\\"{x:1309,y:799,t:1527873052037};\\\", \\\"{x:1309,y:795,t:1527873052053};\\\", \\\"{x:1308,y:792,t:1527873052070};\\\", \\\"{x:1308,y:788,t:1527873052086};\\\", \\\"{x:1307,y:784,t:1527873052103};\\\", \\\"{x:1306,y:781,t:1527873052119};\\\", \\\"{x:1305,y:777,t:1527873052137};\\\", \\\"{x:1305,y:774,t:1527873052153};\\\", \\\"{x:1305,y:772,t:1527873052170};\\\", \\\"{x:1305,y:770,t:1527873052186};\\\", \\\"{x:1304,y:765,t:1527873052203};\\\", \\\"{x:1304,y:764,t:1527873052221};\\\", \\\"{x:1304,y:762,t:1527873052237};\\\", \\\"{x:1302,y:757,t:1527873052254};\\\", \\\"{x:1302,y:753,t:1527873052271};\\\", \\\"{x:1302,y:752,t:1527873052287};\\\", \\\"{x:1302,y:748,t:1527873052303};\\\", \\\"{x:1302,y:743,t:1527873052320};\\\", \\\"{x:1302,y:737,t:1527873052337};\\\", \\\"{x:1302,y:730,t:1527873052353};\\\", \\\"{x:1302,y:723,t:1527873052371};\\\", \\\"{x:1303,y:716,t:1527873052388};\\\", \\\"{x:1306,y:709,t:1527873052404};\\\", \\\"{x:1311,y:700,t:1527873052421};\\\", \\\"{x:1316,y:693,t:1527873052437};\\\", \\\"{x:1319,y:690,t:1527873052453};\\\", \\\"{x:1319,y:689,t:1527873052471};\\\", \\\"{x:1320,y:686,t:1527873052488};\\\", \\\"{x:1320,y:683,t:1527873052505};\\\", \\\"{x:1321,y:681,t:1527873052521};\\\", \\\"{x:1321,y:680,t:1527873052537};\\\", \\\"{x:1321,y:679,t:1527873052557};\\\", \\\"{x:1321,y:678,t:1527873052573};\\\", \\\"{x:1321,y:674,t:1527873052814};\\\", \\\"{x:1322,y:667,t:1527873052821};\\\", \\\"{x:1323,y:654,t:1527873052839};\\\", \\\"{x:1323,y:635,t:1527873052855};\\\", \\\"{x:1321,y:614,t:1527873052871};\\\", \\\"{x:1316,y:604,t:1527873052888};\\\", \\\"{x:1312,y:595,t:1527873052905};\\\", \\\"{x:1307,y:586,t:1527873052922};\\\", \\\"{x:1303,y:577,t:1527873052939};\\\", \\\"{x:1300,y:569,t:1527873052956};\\\", \\\"{x:1299,y:561,t:1527873052972};\\\", \\\"{x:1297,y:551,t:1527873052988};\\\", \\\"{x:1297,y:547,t:1527873053005};\\\", \\\"{x:1297,y:545,t:1527873053021};\\\", \\\"{x:1296,y:544,t:1527873053038};\\\", \\\"{x:1295,y:541,t:1527873053055};\\\", \\\"{x:1294,y:538,t:1527873053072};\\\", \\\"{x:1294,y:535,t:1527873053088};\\\", \\\"{x:1294,y:532,t:1527873053105};\\\", \\\"{x:1294,y:529,t:1527873053122};\\\", \\\"{x:1294,y:527,t:1527873053138};\\\", \\\"{x:1294,y:524,t:1527873053155};\\\", \\\"{x:1296,y:520,t:1527873053173};\\\", \\\"{x:1298,y:519,t:1527873053189};\\\", \\\"{x:1300,y:517,t:1527873053205};\\\", \\\"{x:1304,y:515,t:1527873053222};\\\", \\\"{x:1304,y:518,t:1527873053453};\\\", \\\"{x:1304,y:524,t:1527873053462};\\\", \\\"{x:1304,y:532,t:1527873053474};\\\", \\\"{x:1306,y:548,t:1527873053490};\\\", \\\"{x:1309,y:569,t:1527873053507};\\\", \\\"{x:1311,y:587,t:1527873053524};\\\", \\\"{x:1314,y:605,t:1527873053540};\\\", \\\"{x:1315,y:622,t:1527873053557};\\\", \\\"{x:1318,y:648,t:1527873053574};\\\", \\\"{x:1321,y:664,t:1527873053590};\\\", \\\"{x:1321,y:677,t:1527873053607};\\\", \\\"{x:1321,y:695,t:1527873053623};\\\", \\\"{x:1322,y:712,t:1527873053641};\\\", \\\"{x:1322,y:735,t:1527873053656};\\\", \\\"{x:1323,y:755,t:1527873053674};\\\", \\\"{x:1326,y:775,t:1527873053691};\\\", \\\"{x:1326,y:791,t:1527873053707};\\\", \\\"{x:1326,y:806,t:1527873053724};\\\", \\\"{x:1326,y:824,t:1527873053741};\\\", \\\"{x:1326,y:839,t:1527873053757};\\\", \\\"{x:1328,y:855,t:1527873053774};\\\", \\\"{x:1328,y:866,t:1527873053791};\\\", \\\"{x:1328,y:874,t:1527873053807};\\\", \\\"{x:1328,y:883,t:1527873053823};\\\", \\\"{x:1328,y:891,t:1527873053841};\\\", \\\"{x:1328,y:901,t:1527873053858};\\\", \\\"{x:1328,y:911,t:1527873053873};\\\", \\\"{x:1331,y:919,t:1527873053890};\\\", \\\"{x:1331,y:925,t:1527873053908};\\\", \\\"{x:1332,y:935,t:1527873053925};\\\", \\\"{x:1332,y:940,t:1527873053941};\\\", \\\"{x:1332,y:941,t:1527873053958};\\\", \\\"{x:1332,y:942,t:1527873053975};\\\", \\\"{x:1332,y:943,t:1527873053991};\\\", \\\"{x:1332,y:944,t:1527873054093};\\\", \\\"{x:1331,y:945,t:1527873054108};\\\", \\\"{x:1329,y:948,t:1527873054125};\\\", \\\"{x:1327,y:951,t:1527873054141};\\\", \\\"{x:1326,y:951,t:1527873054157};\\\", \\\"{x:1323,y:953,t:1527873054175};\\\", \\\"{x:1322,y:954,t:1527873054191};\\\", \\\"{x:1320,y:955,t:1527873054208};\\\", \\\"{x:1319,y:956,t:1527873054225};\\\", \\\"{x:1318,y:957,t:1527873054242};\\\", \\\"{x:1316,y:959,t:1527873054259};\\\", \\\"{x:1315,y:960,t:1527873054275};\\\", \\\"{x:1314,y:960,t:1527873054291};\\\", \\\"{x:1312,y:961,t:1527873054309};\\\", \\\"{x:1311,y:962,t:1527873054357};\\\", \\\"{x:1311,y:963,t:1527873054365};\\\", \\\"{x:1310,y:964,t:1527873054381};\\\", \\\"{x:1310,y:966,t:1527873054397};\\\", \\\"{x:1310,y:968,t:1527873054431};\\\", \\\"{x:1310,y:969,t:1527873054441};\\\", \\\"{x:1309,y:971,t:1527873054458};\\\", \\\"{x:1308,y:974,t:1527873054475};\\\", \\\"{x:1308,y:977,t:1527873054492};\\\", \\\"{x:1307,y:978,t:1527873054507};\\\", \\\"{x:1307,y:980,t:1527873054524};\\\", \\\"{x:1306,y:980,t:1527873054541};\\\", \\\"{x:1305,y:981,t:1527873054557};\\\", \\\"{x:1305,y:982,t:1527873054660};\\\", \\\"{x:1304,y:982,t:1527873054683};\\\", \\\"{x:1302,y:982,t:1527873054691};\\\", \\\"{x:1301,y:979,t:1527873054708};\\\", \\\"{x:1301,y:975,t:1527873054724};\\\", \\\"{x:1301,y:970,t:1527873054741};\\\", \\\"{x:1301,y:967,t:1527873054758};\\\", \\\"{x:1301,y:964,t:1527873054775};\\\", \\\"{x:1301,y:963,t:1527873054792};\\\", \\\"{x:1301,y:962,t:1527873054808};\\\", \\\"{x:1301,y:960,t:1527873054829};\\\", \\\"{x:1302,y:960,t:1527873054852};\\\", \\\"{x:1303,y:960,t:1527873055260};\\\", \\\"{x:1304,y:965,t:1527873055276};\\\", \\\"{x:1305,y:969,t:1527873055292};\\\", \\\"{x:1307,y:973,t:1527873055309};\\\", \\\"{x:1307,y:974,t:1527873055326};\\\", \\\"{x:1308,y:975,t:1527873055435};\\\", \\\"{x:1308,y:974,t:1527873055596};\\\", \\\"{x:1308,y:973,t:1527873055610};\\\", \\\"{x:1308,y:971,t:1527873055628};\\\", \\\"{x:1308,y:970,t:1527873055643};\\\", \\\"{x:1308,y:969,t:1527873055660};\\\", \\\"{x:1308,y:967,t:1527873055677};\\\", \\\"{x:1308,y:965,t:1527873055692};\\\", \\\"{x:1309,y:962,t:1527873055710};\\\", \\\"{x:1310,y:956,t:1527873055727};\\\", \\\"{x:1311,y:950,t:1527873055742};\\\", \\\"{x:1313,y:937,t:1527873055759};\\\", \\\"{x:1314,y:927,t:1527873055777};\\\", \\\"{x:1314,y:923,t:1527873055795};\\\", \\\"{x:1314,y:920,t:1527873055810};\\\", \\\"{x:1314,y:918,t:1527873055829};\\\", \\\"{x:1314,y:917,t:1527873055852};\\\", \\\"{x:1314,y:916,t:1527873055867};\\\", \\\"{x:1314,y:915,t:1527873055878};\\\", \\\"{x:1314,y:914,t:1527873055895};\\\", \\\"{x:1314,y:912,t:1527873055915};\\\", \\\"{x:1314,y:911,t:1527873055948};\\\", \\\"{x:1314,y:909,t:1527873055964};\\\", \\\"{x:1314,y:908,t:1527873055988};\\\", \\\"{x:1314,y:906,t:1527873056004};\\\", \\\"{x:1314,y:904,t:1527873056019};\\\", \\\"{x:1314,y:902,t:1527873056029};\\\", \\\"{x:1313,y:899,t:1527873056044};\\\", \\\"{x:1313,y:894,t:1527873056061};\\\", \\\"{x:1313,y:892,t:1527873056078};\\\", \\\"{x:1313,y:889,t:1527873056094};\\\", \\\"{x:1312,y:887,t:1527873056110};\\\", \\\"{x:1312,y:885,t:1527873056128};\\\", \\\"{x:1311,y:884,t:1527873056144};\\\", \\\"{x:1311,y:882,t:1527873056161};\\\", \\\"{x:1311,y:880,t:1527873056178};\\\", \\\"{x:1311,y:878,t:1527873056194};\\\", \\\"{x:1311,y:873,t:1527873056211};\\\", \\\"{x:1311,y:871,t:1527873056228};\\\", \\\"{x:1311,y:868,t:1527873056244};\\\", \\\"{x:1311,y:866,t:1527873056261};\\\", \\\"{x:1311,y:862,t:1527873056278};\\\", \\\"{x:1311,y:855,t:1527873056295};\\\", \\\"{x:1311,y:849,t:1527873056311};\\\", \\\"{x:1311,y:841,t:1527873056328};\\\", \\\"{x:1311,y:828,t:1527873056345};\\\", \\\"{x:1313,y:813,t:1527873056361};\\\", \\\"{x:1313,y:804,t:1527873056378};\\\", \\\"{x:1314,y:800,t:1527873056394};\\\", \\\"{x:1315,y:796,t:1527873056412};\\\", \\\"{x:1316,y:792,t:1527873056428};\\\", \\\"{x:1316,y:788,t:1527873056445};\\\", \\\"{x:1316,y:786,t:1527873056462};\\\", \\\"{x:1316,y:785,t:1527873056479};\\\", \\\"{x:1316,y:783,t:1527873056494};\\\", \\\"{x:1316,y:782,t:1527873056512};\\\", \\\"{x:1316,y:779,t:1527873056529};\\\", \\\"{x:1316,y:775,t:1527873056545};\\\", \\\"{x:1318,y:772,t:1527873056562};\\\", \\\"{x:1318,y:766,t:1527873056579};\\\", \\\"{x:1318,y:763,t:1527873056595};\\\", \\\"{x:1318,y:760,t:1527873056612};\\\", \\\"{x:1318,y:757,t:1527873056629};\\\", \\\"{x:1318,y:755,t:1527873056646};\\\", \\\"{x:1318,y:753,t:1527873056662};\\\", \\\"{x:1318,y:752,t:1527873056690};\\\", \\\"{x:1318,y:750,t:1527873056723};\\\", \\\"{x:1318,y:749,t:1527873056738};\\\", \\\"{x:1318,y:745,t:1527873056778};\\\", \\\"{x:1317,y:741,t:1527873056795};\\\", \\\"{x:1316,y:737,t:1527873056813};\\\", \\\"{x:1315,y:731,t:1527873056829};\\\", \\\"{x:1314,y:728,t:1527873056846};\\\", \\\"{x:1313,y:724,t:1527873056863};\\\", \\\"{x:1312,y:723,t:1527873056879};\\\", \\\"{x:1312,y:721,t:1527873056896};\\\", \\\"{x:1312,y:720,t:1527873056940};\\\", \\\"{x:1312,y:717,t:1527873056956};\\\", \\\"{x:1312,y:716,t:1527873056964};\\\", \\\"{x:1312,y:710,t:1527873056980};\\\", \\\"{x:1312,y:701,t:1527873056996};\\\", \\\"{x:1312,y:691,t:1527873057013};\\\", \\\"{x:1319,y:680,t:1527873057030};\\\", \\\"{x:1322,y:672,t:1527873057046};\\\", \\\"{x:1327,y:663,t:1527873057063};\\\", \\\"{x:1330,y:656,t:1527873057080};\\\", \\\"{x:1333,y:649,t:1527873057097};\\\", \\\"{x:1334,y:646,t:1527873057113};\\\", \\\"{x:1336,y:640,t:1527873057130};\\\", \\\"{x:1338,y:637,t:1527873057148};\\\", \\\"{x:1338,y:635,t:1527873057163};\\\", \\\"{x:1338,y:631,t:1527873057181};\\\", \\\"{x:1338,y:625,t:1527873057197};\\\", \\\"{x:1341,y:620,t:1527873057214};\\\", \\\"{x:1342,y:614,t:1527873057230};\\\", \\\"{x:1342,y:611,t:1527873057248};\\\", \\\"{x:1342,y:606,t:1527873057264};\\\", \\\"{x:1340,y:591,t:1527873057281};\\\", \\\"{x:1335,y:569,t:1527873057297};\\\", \\\"{x:1327,y:542,t:1527873057314};\\\", \\\"{x:1320,y:518,t:1527873057330};\\\", \\\"{x:1315,y:486,t:1527873057348};\\\", \\\"{x:1311,y:467,t:1527873057364};\\\", \\\"{x:1307,y:454,t:1527873057382};\\\", \\\"{x:1306,y:448,t:1527873057397};\\\", \\\"{x:1305,y:442,t:1527873057414};\\\", \\\"{x:1305,y:441,t:1527873057436};\\\", \\\"{x:1305,y:442,t:1527873057540};\\\", \\\"{x:1305,y:448,t:1527873057547};\\\", \\\"{x:1305,y:459,t:1527873057565};\\\", \\\"{x:1305,y:470,t:1527873057581};\\\", \\\"{x:1305,y:483,t:1527873057599};\\\", \\\"{x:1307,y:492,t:1527873057614};\\\", \\\"{x:1308,y:496,t:1527873057632};\\\", \\\"{x:1308,y:499,t:1527873057649};\\\", \\\"{x:1308,y:500,t:1527873057665};\\\", \\\"{x:1308,y:502,t:1527873057681};\\\", \\\"{x:1308,y:503,t:1527873057699};\\\", \\\"{x:1308,y:505,t:1527873057715};\\\", \\\"{x:1308,y:506,t:1527873058124};\\\", \\\"{x:1308,y:507,t:1527873058139};\\\", \\\"{x:1308,y:508,t:1527873058150};\\\", \\\"{x:1307,y:509,t:1527873058167};\\\", \\\"{x:1306,y:509,t:1527873058332};\\\", \\\"{x:1308,y:505,t:1527873058339};\\\", \\\"{x:1309,y:504,t:1527873058350};\\\", \\\"{x:1312,y:500,t:1527873058367};\\\", \\\"{x:1313,y:499,t:1527873058384};\\\", \\\"{x:1313,y:498,t:1527873058403};\\\", \\\"{x:1314,y:497,t:1527873058419};\\\", \\\"{x:1320,y:498,t:1527873099947};\\\", \\\"{x:1377,y:523,t:1527873099965};\\\", \\\"{x:1444,y:535,t:1527873099982};\\\", \\\"{x:1508,y:544,t:1527873099998};\\\", \\\"{x:1554,y:546,t:1527873100015};\\\", \\\"{x:1586,y:549,t:1527873100032};\\\", \\\"{x:1601,y:553,t:1527873100048};\\\", \\\"{x:1610,y:556,t:1527873100065};\\\", \\\"{x:1615,y:561,t:1527873100083};\\\", \\\"{x:1620,y:568,t:1527873100098};\\\", \\\"{x:1633,y:584,t:1527873100115};\\\", \\\"{x:1639,y:590,t:1527873100131};\\\", \\\"{x:1647,y:600,t:1527873100149};\\\", \\\"{x:1650,y:605,t:1527873100165};\\\", \\\"{x:1652,y:610,t:1527873100182};\\\", \\\"{x:1654,y:614,t:1527873100198};\\\", \\\"{x:1655,y:619,t:1527873100214};\\\", \\\"{x:1659,y:628,t:1527873100232};\\\", \\\"{x:1660,y:637,t:1527873100249};\\\", \\\"{x:1661,y:651,t:1527873100265};\\\", \\\"{x:1664,y:665,t:1527873100282};\\\", \\\"{x:1670,y:695,t:1527873100298};\\\", \\\"{x:1676,y:712,t:1527873100316};\\\", \\\"{x:1681,y:728,t:1527873100332};\\\", \\\"{x:1686,y:740,t:1527873100349};\\\", \\\"{x:1692,y:752,t:1527873100366};\\\", \\\"{x:1696,y:765,t:1527873100382};\\\", \\\"{x:1701,y:780,t:1527873100399};\\\", \\\"{x:1707,y:796,t:1527873100416};\\\", \\\"{x:1712,y:812,t:1527873100432};\\\", \\\"{x:1715,y:824,t:1527873100449};\\\", \\\"{x:1720,y:834,t:1527873100466};\\\", \\\"{x:1725,y:847,t:1527873100482};\\\", \\\"{x:1730,y:859,t:1527873100498};\\\", \\\"{x:1734,y:868,t:1527873100515};\\\", \\\"{x:1735,y:877,t:1527873100533};\\\", \\\"{x:1741,y:889,t:1527873100549};\\\", \\\"{x:1745,y:898,t:1527873100566};\\\", \\\"{x:1750,y:910,t:1527873100583};\\\", \\\"{x:1754,y:921,t:1527873100600};\\\", \\\"{x:1759,y:934,t:1527873100616};\\\", \\\"{x:1761,y:947,t:1527873100633};\\\", \\\"{x:1765,y:957,t:1527873100650};\\\", \\\"{x:1766,y:965,t:1527873100666};\\\", \\\"{x:1767,y:970,t:1527873100683};\\\", \\\"{x:1767,y:971,t:1527873100699};\\\", \\\"{x:1767,y:972,t:1527873100717};\\\", \\\"{x:1767,y:973,t:1527873100733};\\\", \\\"{x:1767,y:974,t:1527873100750};\\\", \\\"{x:1768,y:974,t:1527873100767};\\\", \\\"{x:1768,y:975,t:1527873100794};\\\", \\\"{x:1768,y:976,t:1527873100819};\\\", \\\"{x:1768,y:977,t:1527873100834};\\\", \\\"{x:1767,y:977,t:1527873100867};\\\", \\\"{x:1766,y:977,t:1527873100884};\\\", \\\"{x:1765,y:977,t:1527873100899};\\\", \\\"{x:1764,y:977,t:1527873100917};\\\", \\\"{x:1760,y:975,t:1527873100934};\\\", \\\"{x:1758,y:973,t:1527873100950};\\\", \\\"{x:1757,y:973,t:1527873100967};\\\", \\\"{x:1756,y:972,t:1527873100984};\\\", \\\"{x:1755,y:971,t:1527873101034};\\\", \\\"{x:1754,y:971,t:1527873101530};\\\", \\\"{x:1753,y:971,t:1527873101538};\\\", \\\"{x:1752,y:971,t:1527873101554};\\\", \\\"{x:1751,y:971,t:1527873101586};\\\", \\\"{x:1749,y:970,t:1527873101618};\\\", \\\"{x:1748,y:969,t:1527873101683};\\\", \\\"{x:1747,y:969,t:1527873101690};\\\", \\\"{x:1746,y:968,t:1527873103587};\\\", \\\"{x:1744,y:965,t:1527873103594};\\\", \\\"{x:1742,y:960,t:1527873103607};\\\", \\\"{x:1737,y:949,t:1527873103623};\\\", \\\"{x:1734,y:943,t:1527873103640};\\\", \\\"{x:1725,y:927,t:1527873103657};\\\", \\\"{x:1707,y:897,t:1527873103673};\\\", \\\"{x:1676,y:850,t:1527873103690};\\\", \\\"{x:1652,y:818,t:1527873103707};\\\", \\\"{x:1644,y:807,t:1527873103724};\\\", \\\"{x:1633,y:794,t:1527873103740};\\\", \\\"{x:1618,y:779,t:1527873103757};\\\", \\\"{x:1597,y:759,t:1527873103774};\\\", \\\"{x:1572,y:738,t:1527873103790};\\\", \\\"{x:1556,y:724,t:1527873103807};\\\", \\\"{x:1547,y:716,t:1527873103824};\\\", \\\"{x:1539,y:708,t:1527873103840};\\\", \\\"{x:1519,y:692,t:1527873103857};\\\", \\\"{x:1491,y:672,t:1527873103874};\\\", \\\"{x:1452,y:647,t:1527873103891};\\\", \\\"{x:1431,y:636,t:1527873103906};\\\", \\\"{x:1409,y:625,t:1527873103924};\\\", \\\"{x:1353,y:595,t:1527873103941};\\\", \\\"{x:1318,y:581,t:1527873103957};\\\", \\\"{x:1306,y:577,t:1527873103973};\\\", \\\"{x:1294,y:574,t:1527873103990};\\\", \\\"{x:1292,y:572,t:1527873104007};\\\", \\\"{x:1289,y:571,t:1527873104023};\\\", \\\"{x:1288,y:571,t:1527873104040};\\\", \\\"{x:1286,y:570,t:1527873104058};\\\", \\\"{x:1286,y:569,t:1527873104291};\\\", \\\"{x:1287,y:559,t:1527873104308};\\\", \\\"{x:1289,y:553,t:1527873104325};\\\", \\\"{x:1293,y:544,t:1527873104342};\\\", \\\"{x:1294,y:539,t:1527873104358};\\\", \\\"{x:1294,y:537,t:1527873104375};\\\", \\\"{x:1294,y:534,t:1527873104392};\\\", \\\"{x:1294,y:533,t:1527873104408};\\\", \\\"{x:1294,y:531,t:1527873104424};\\\", \\\"{x:1294,y:529,t:1527873104442};\\\", \\\"{x:1294,y:528,t:1527873104457};\\\", \\\"{x:1294,y:527,t:1527873104474};\\\", \\\"{x:1296,y:524,t:1527873104492};\\\", \\\"{x:1297,y:522,t:1527873104508};\\\", \\\"{x:1299,y:520,t:1527873104524};\\\", \\\"{x:1302,y:519,t:1527873104541};\\\", \\\"{x:1304,y:519,t:1527873104558};\\\", \\\"{x:1304,y:526,t:1527873104602};\\\", \\\"{x:1304,y:540,t:1527873104610};\\\", \\\"{x:1304,y:581,t:1527873104625};\\\", \\\"{x:1304,y:621,t:1527873104642};\\\", \\\"{x:1299,y:668,t:1527873104659};\\\", \\\"{x:1299,y:699,t:1527873104676};\\\", \\\"{x:1299,y:722,t:1527873104691};\\\", \\\"{x:1299,y:745,t:1527873104708};\\\", \\\"{x:1299,y:773,t:1527873104726};\\\", \\\"{x:1299,y:802,t:1527873104742};\\\", \\\"{x:1301,y:827,t:1527873104759};\\\", \\\"{x:1307,y:850,t:1527873104775};\\\", \\\"{x:1314,y:872,t:1527873104793};\\\", \\\"{x:1327,y:898,t:1527873104809};\\\", \\\"{x:1346,y:931,t:1527873104827};\\\", \\\"{x:1360,y:955,t:1527873104842};\\\", \\\"{x:1369,y:967,t:1527873104859};\\\", \\\"{x:1369,y:968,t:1527873104876};\\\", \\\"{x:1369,y:969,t:1527873105058};\\\", \\\"{x:1360,y:975,t:1527873105077};\\\", \\\"{x:1341,y:977,t:1527873105093};\\\", \\\"{x:1321,y:981,t:1527873105110};\\\", \\\"{x:1306,y:982,t:1527873105127};\\\", \\\"{x:1296,y:982,t:1527873105143};\\\", \\\"{x:1292,y:982,t:1527873105160};\\\", \\\"{x:1291,y:982,t:1527873105176};\\\", \\\"{x:1290,y:980,t:1527873105275};\\\", \\\"{x:1290,y:977,t:1527873105283};\\\", \\\"{x:1290,y:976,t:1527873105293};\\\", \\\"{x:1290,y:973,t:1527873105310};\\\", \\\"{x:1290,y:971,t:1527873105327};\\\", \\\"{x:1290,y:970,t:1527873105344};\\\", \\\"{x:1290,y:969,t:1527873105361};\\\", \\\"{x:1290,y:968,t:1527873105378};\\\", \\\"{x:1289,y:967,t:1527873105428};\\\", \\\"{x:1288,y:966,t:1527873105467};\\\", \\\"{x:1287,y:965,t:1527873105547};\\\", \\\"{x:1287,y:964,t:1527873105561};\\\", \\\"{x:1286,y:963,t:1527873105578};\\\", \\\"{x:1286,y:961,t:1527873105595};\\\", \\\"{x:1285,y:961,t:1527873105618};\\\", \\\"{x:1284,y:960,t:1527873105634};\\\", \\\"{x:1283,y:960,t:1527873105674};\\\", \\\"{x:1283,y:959,t:1527873105682};\\\", \\\"{x:1284,y:959,t:1527873106867};\\\", \\\"{x:1287,y:959,t:1527873106881};\\\", \\\"{x:1294,y:961,t:1527873106899};\\\", \\\"{x:1295,y:961,t:1527873106914};\\\", \\\"{x:1298,y:962,t:1527873106931};\\\", \\\"{x:1301,y:962,t:1527873106948};\\\", \\\"{x:1304,y:962,t:1527873106964};\\\", \\\"{x:1308,y:962,t:1527873106981};\\\", \\\"{x:1310,y:963,t:1527873106999};\\\", \\\"{x:1312,y:963,t:1527873107014};\\\", \\\"{x:1314,y:964,t:1527873107031};\\\", \\\"{x:1315,y:964,t:1527873107050};\\\", \\\"{x:1316,y:964,t:1527873107065};\\\", \\\"{x:1317,y:964,t:1527873107081};\\\", \\\"{x:1318,y:965,t:1527873107098};\\\", \\\"{x:1320,y:965,t:1527873107116};\\\", \\\"{x:1323,y:965,t:1527873107131};\\\", \\\"{x:1324,y:965,t:1527873107148};\\\", \\\"{x:1326,y:965,t:1527873107165};\\\", \\\"{x:1327,y:965,t:1527873107194};\\\", \\\"{x:1328,y:965,t:1527873107210};\\\", \\\"{x:1329,y:965,t:1527873107226};\\\", \\\"{x:1330,y:965,t:1527873107251};\\\", \\\"{x:1331,y:965,t:1527873107265};\\\", \\\"{x:1333,y:965,t:1527873107283};\\\", \\\"{x:1335,y:965,t:1527873107299};\\\", \\\"{x:1338,y:965,t:1527873107315};\\\", \\\"{x:1339,y:965,t:1527873107332};\\\", \\\"{x:1340,y:965,t:1527873107349};\\\", \\\"{x:1341,y:965,t:1527873107385};\\\", \\\"{x:1342,y:965,t:1527873107401};\\\", \\\"{x:1343,y:965,t:1527873107426};\\\", \\\"{x:1344,y:965,t:1527873107698};\\\", \\\"{x:1349,y:964,t:1527873107716};\\\", \\\"{x:1357,y:964,t:1527873107734};\\\", \\\"{x:1364,y:964,t:1527873107750};\\\", \\\"{x:1374,y:964,t:1527873107766};\\\", \\\"{x:1389,y:964,t:1527873107783};\\\", \\\"{x:1400,y:964,t:1527873107800};\\\", \\\"{x:1406,y:964,t:1527873107816};\\\", \\\"{x:1409,y:964,t:1527873107833};\\\", \\\"{x:1410,y:964,t:1527873107850};\\\", \\\"{x:1409,y:964,t:1527873108082};\\\", \\\"{x:1405,y:965,t:1527873108100};\\\", \\\"{x:1403,y:966,t:1527873108117};\\\", \\\"{x:1401,y:967,t:1527873108133};\\\", \\\"{x:1402,y:967,t:1527873108403};\\\", \\\"{x:1406,y:967,t:1527873108419};\\\", \\\"{x:1409,y:967,t:1527873108434};\\\", \\\"{x:1412,y:967,t:1527873108451};\\\", \\\"{x:1413,y:967,t:1527873108468};\\\", \\\"{x:1414,y:968,t:1527873108485};\\\", \\\"{x:1415,y:968,t:1527873108501};\\\", \\\"{x:1416,y:968,t:1527873108519};\\\", \\\"{x:1417,y:968,t:1527873108535};\\\", \\\"{x:1425,y:969,t:1527873108899};\\\", \\\"{x:1432,y:970,t:1527873108906};\\\", \\\"{x:1440,y:970,t:1527873108919};\\\", \\\"{x:1449,y:971,t:1527873108936};\\\", \\\"{x:1456,y:971,t:1527873108952};\\\", \\\"{x:1460,y:971,t:1527873108969};\\\", \\\"{x:1462,y:971,t:1527873108987};\\\", \\\"{x:1463,y:971,t:1527873109067};\\\", \\\"{x:1464,y:971,t:1527873109074};\\\", \\\"{x:1465,y:971,t:1527873109086};\\\", \\\"{x:1466,y:971,t:1527873109103};\\\", \\\"{x:1468,y:971,t:1527873109331};\\\", \\\"{x:1469,y:971,t:1527873109346};\\\", \\\"{x:1470,y:971,t:1527873109362};\\\", \\\"{x:1471,y:971,t:1527873109386};\\\", \\\"{x:1472,y:971,t:1527873109418};\\\", \\\"{x:1473,y:971,t:1527873109434};\\\", \\\"{x:1474,y:971,t:1527873109450};\\\", \\\"{x:1475,y:971,t:1527873109474};\\\", \\\"{x:1476,y:971,t:1527873109487};\\\", \\\"{x:1477,y:971,t:1527873109504};\\\", \\\"{x:1478,y:971,t:1527873109522};\\\", \\\"{x:1479,y:971,t:1527873109562};\\\", \\\"{x:1480,y:971,t:1527873109586};\\\", \\\"{x:1481,y:971,t:1527873109611};\\\", \\\"{x:1482,y:971,t:1527873109621};\\\", \\\"{x:1483,y:971,t:1527873109637};\\\", \\\"{x:1484,y:971,t:1527873109659};\\\", \\\"{x:1485,y:971,t:1527873109674};\\\", \\\"{x:1486,y:971,t:1527873109690};\\\", \\\"{x:1487,y:971,t:1527873109715};\\\", \\\"{x:1488,y:971,t:1527873109739};\\\", \\\"{x:1489,y:971,t:1527873109779};\\\", \\\"{x:1490,y:971,t:1527873109802};\\\", \\\"{x:1491,y:971,t:1527873109818};\\\", \\\"{x:1492,y:971,t:1527873109834};\\\", \\\"{x:1493,y:971,t:1527873109883};\\\", \\\"{x:1494,y:971,t:1527873109914};\\\", \\\"{x:1495,y:971,t:1527873109939};\\\", \\\"{x:1496,y:971,t:1527873109970};\\\", \\\"{x:1498,y:971,t:1527873109988};\\\", \\\"{x:1499,y:971,t:1527873110005};\\\", \\\"{x:1502,y:969,t:1527873110022};\\\", \\\"{x:1503,y:969,t:1527873110038};\\\", \\\"{x:1505,y:969,t:1527873110055};\\\", \\\"{x:1506,y:969,t:1527873110107};\\\", \\\"{x:1508,y:968,t:1527873110122};\\\", \\\"{x:1509,y:968,t:1527873110138};\\\", \\\"{x:1510,y:968,t:1527873110155};\\\", \\\"{x:1511,y:966,t:1527873110172};\\\", \\\"{x:1513,y:966,t:1527873110210};\\\", \\\"{x:1514,y:965,t:1527873110222};\\\", \\\"{x:1515,y:965,t:1527873110239};\\\", \\\"{x:1519,y:962,t:1527873110255};\\\", \\\"{x:1520,y:962,t:1527873110274};\\\", \\\"{x:1521,y:963,t:1527873110995};\\\", \\\"{x:1521,y:965,t:1527873111007};\\\", \\\"{x:1521,y:966,t:1527873111025};\\\", \\\"{x:1520,y:967,t:1527873111040};\\\", \\\"{x:1519,y:967,t:1527873111075};\\\", \\\"{x:1518,y:967,t:1527873111275};\\\", \\\"{x:1516,y:967,t:1527873111298};\\\", \\\"{x:1515,y:967,t:1527873111441};\\\", \\\"{x:1513,y:967,t:1527873111490};\\\", \\\"{x:1520,y:965,t:1527873112659};\\\", \\\"{x:1530,y:964,t:1527873112667};\\\", \\\"{x:1533,y:964,t:1527873112678};\\\", \\\"{x:1532,y:964,t:1527873112882};\\\", \\\"{x:1531,y:964,t:1527873112896};\\\", \\\"{x:1528,y:965,t:1527873112912};\\\", \\\"{x:1525,y:965,t:1527873112929};\\\", \\\"{x:1522,y:966,t:1527873112945};\\\", \\\"{x:1520,y:967,t:1527873112962};\\\", \\\"{x:1518,y:967,t:1527873116592};\\\", \\\"{x:1517,y:967,t:1527873116601};\\\", \\\"{x:1516,y:967,t:1527873116617};\\\", \\\"{x:1515,y:966,t:1527873116635};\\\", \\\"{x:1514,y:965,t:1527873116651};\\\", \\\"{x:1513,y:965,t:1527873117456};\\\", \\\"{x:1511,y:957,t:1527873117470};\\\", \\\"{x:1511,y:941,t:1527873117486};\\\", \\\"{x:1511,y:932,t:1527873117503};\\\", \\\"{x:1510,y:919,t:1527873117520};\\\", \\\"{x:1509,y:909,t:1527873117537};\\\", \\\"{x:1508,y:901,t:1527873117554};\\\", \\\"{x:1504,y:891,t:1527873117570};\\\", \\\"{x:1504,y:886,t:1527873117587};\\\", \\\"{x:1502,y:883,t:1527873117604};\\\", \\\"{x:1502,y:881,t:1527873117619};\\\", \\\"{x:1501,y:879,t:1527873117637};\\\", \\\"{x:1500,y:877,t:1527873117656};\\\", \\\"{x:1499,y:874,t:1527873117671};\\\", \\\"{x:1498,y:873,t:1527873117687};\\\", \\\"{x:1497,y:870,t:1527873117704};\\\", \\\"{x:1495,y:866,t:1527873117721};\\\", \\\"{x:1494,y:864,t:1527873117737};\\\", \\\"{x:1493,y:861,t:1527873117754};\\\", \\\"{x:1492,y:859,t:1527873117771};\\\", \\\"{x:1491,y:858,t:1527873117787};\\\", \\\"{x:1490,y:857,t:1527873118000};\\\", \\\"{x:1490,y:854,t:1527873118008};\\\", \\\"{x:1488,y:853,t:1527873118021};\\\", \\\"{x:1487,y:851,t:1527873118038};\\\", \\\"{x:1487,y:849,t:1527873118055};\\\", \\\"{x:1487,y:848,t:1527873118072};\\\", \\\"{x:1487,y:846,t:1527873118087};\\\", \\\"{x:1488,y:844,t:1527873118105};\\\", \\\"{x:1490,y:843,t:1527873118122};\\\", \\\"{x:1490,y:842,t:1527873118152};\\\", \\\"{x:1490,y:841,t:1527873118168};\\\", \\\"{x:1490,y:840,t:1527873118368};\\\", \\\"{x:1490,y:839,t:1527873118375};\\\", \\\"{x:1490,y:837,t:1527873118389};\\\", \\\"{x:1490,y:836,t:1527873118407};\\\", \\\"{x:1488,y:836,t:1527873118431};\\\", \\\"{x:1488,y:835,t:1527873118448};\\\", \\\"{x:1487,y:834,t:1527873118472};\\\", \\\"{x:1486,y:834,t:1527873118544};\\\", \\\"{x:1485,y:833,t:1527873118560};\\\", \\\"{x:1483,y:832,t:1527873118588};\\\", \\\"{x:1482,y:831,t:1527873118616};\\\", \\\"{x:1481,y:831,t:1527873118672};\\\", \\\"{x:1480,y:831,t:1527873118690};\\\", \\\"{x:1479,y:831,t:1527873118719};\\\", \\\"{x:1479,y:830,t:1527873118736};\\\", \\\"{x:1478,y:829,t:1527873121439};\\\", \\\"{x:1472,y:822,t:1527873121447};\\\", \\\"{x:1460,y:815,t:1527873121463};\\\", \\\"{x:1454,y:812,t:1527873121478};\\\", \\\"{x:1448,y:810,t:1527873121495};\\\", \\\"{x:1444,y:809,t:1527873121512};\\\", \\\"{x:1443,y:809,t:1527873121551};\\\", \\\"{x:1442,y:808,t:1527873121567};\\\", \\\"{x:1441,y:808,t:1527873121579};\\\", \\\"{x:1440,y:807,t:1527873121595};\\\", \\\"{x:1436,y:806,t:1527873121613};\\\", \\\"{x:1430,y:805,t:1527873121630};\\\", \\\"{x:1426,y:805,t:1527873121646};\\\", \\\"{x:1423,y:805,t:1527873121663};\\\", \\\"{x:1422,y:803,t:1527873121728};\\\", \\\"{x:1421,y:802,t:1527873121735};\\\", \\\"{x:1420,y:801,t:1527873121747};\\\", \\\"{x:1418,y:799,t:1527873121763};\\\", \\\"{x:1415,y:796,t:1527873121780};\\\", \\\"{x:1413,y:794,t:1527873121797};\\\", \\\"{x:1412,y:793,t:1527873121814};\\\", \\\"{x:1411,y:792,t:1527873121830};\\\", \\\"{x:1409,y:790,t:1527873121847};\\\", \\\"{x:1408,y:789,t:1527873121880};\\\", \\\"{x:1408,y:788,t:1527873121919};\\\", \\\"{x:1407,y:788,t:1527873121944};\\\", \\\"{x:1407,y:787,t:1527873121959};\\\", \\\"{x:1406,y:787,t:1527873121974};\\\", \\\"{x:1405,y:786,t:1527873121983};\\\", \\\"{x:1404,y:786,t:1527873122006};\\\", \\\"{x:1403,y:785,t:1527873122031};\\\", \\\"{x:1402,y:784,t:1527873122047};\\\", \\\"{x:1399,y:784,t:1527873122064};\\\", \\\"{x:1394,y:784,t:1527873122080};\\\", \\\"{x:1390,y:783,t:1527873122097};\\\", \\\"{x:1387,y:783,t:1527873122113};\\\", \\\"{x:1385,y:782,t:1527873122130};\\\", \\\"{x:1384,y:782,t:1527873122147};\\\", \\\"{x:1383,y:782,t:1527873122231};\\\", \\\"{x:1382,y:782,t:1527873122335};\\\", \\\"{x:1382,y:780,t:1527873122348};\\\", \\\"{x:1382,y:773,t:1527873122365};\\\", \\\"{x:1382,y:769,t:1527873122381};\\\", \\\"{x:1382,y:767,t:1527873122398};\\\", \\\"{x:1382,y:766,t:1527873122415};\\\", \\\"{x:1382,y:764,t:1527873124816};\\\", \\\"{x:1384,y:762,t:1527873124824};\\\", \\\"{x:1390,y:761,t:1527873124838};\\\", \\\"{x:1401,y:761,t:1527873124854};\\\", \\\"{x:1414,y:761,t:1527873124871};\\\", \\\"{x:1418,y:761,t:1527873124887};\\\", \\\"{x:1420,y:761,t:1527873124904};\\\", \\\"{x:1422,y:761,t:1527873124921};\\\", \\\"{x:1424,y:761,t:1527873124937};\\\", \\\"{x:1425,y:761,t:1527873124955};\\\", \\\"{x:1427,y:761,t:1527873124971};\\\", \\\"{x:1428,y:761,t:1527873124988};\\\", \\\"{x:1430,y:759,t:1527873125004};\\\", \\\"{x:1433,y:759,t:1527873125021};\\\", \\\"{x:1434,y:759,t:1527873125037};\\\", \\\"{x:1433,y:759,t:1527873125271};\\\", \\\"{x:1427,y:761,t:1527873125289};\\\", \\\"{x:1421,y:763,t:1527873125305};\\\", \\\"{x:1417,y:763,t:1527873125322};\\\", \\\"{x:1413,y:764,t:1527873125338};\\\", \\\"{x:1412,y:764,t:1527873125355};\\\", \\\"{x:1410,y:765,t:1527873125372};\\\", \\\"{x:1407,y:765,t:1527873125388};\\\", \\\"{x:1405,y:766,t:1527873125405};\\\", \\\"{x:1402,y:767,t:1527873125422};\\\", \\\"{x:1398,y:768,t:1527873125439};\\\", \\\"{x:1396,y:768,t:1527873125456};\\\", \\\"{x:1394,y:768,t:1527873125472};\\\", \\\"{x:1391,y:768,t:1527873125489};\\\", \\\"{x:1384,y:770,t:1527873125505};\\\", \\\"{x:1369,y:772,t:1527873125522};\\\", \\\"{x:1347,y:775,t:1527873125539};\\\", \\\"{x:1320,y:779,t:1527873125556};\\\", \\\"{x:1284,y:782,t:1527873125572};\\\", \\\"{x:1226,y:782,t:1527873125589};\\\", \\\"{x:1153,y:782,t:1527873125606};\\\", \\\"{x:1073,y:782,t:1527873125622};\\\", \\\"{x:928,y:766,t:1527873125639};\\\", \\\"{x:826,y:742,t:1527873125655};\\\", \\\"{x:750,y:730,t:1527873125672};\\\", \\\"{x:682,y:715,t:1527873125688};\\\", \\\"{x:639,y:708,t:1527873125706};\\\", \\\"{x:614,y:703,t:1527873125723};\\\", \\\"{x:604,y:702,t:1527873125738};\\\", \\\"{x:600,y:701,t:1527873125756};\\\", \\\"{x:600,y:700,t:1527873125799};\\\", \\\"{x:597,y:698,t:1527873125807};\\\", \\\"{x:591,y:693,t:1527873125823};\\\", \\\"{x:581,y:685,t:1527873125839};\\\", \\\"{x:567,y:678,t:1527873125856};\\\", \\\"{x:549,y:671,t:1527873125873};\\\", \\\"{x:517,y:660,t:1527873125891};\\\", \\\"{x:488,y:653,t:1527873125906};\\\", \\\"{x:466,y:647,t:1527873125923};\\\", \\\"{x:443,y:641,t:1527873125944};\\\", \\\"{x:432,y:637,t:1527873125960};\\\", \\\"{x:420,y:633,t:1527873125977};\\\", \\\"{x:407,y:629,t:1527873125994};\\\", \\\"{x:395,y:625,t:1527873126010};\\\", \\\"{x:383,y:620,t:1527873126027};\\\", \\\"{x:371,y:615,t:1527873126044};\\\", \\\"{x:364,y:613,t:1527873126060};\\\", \\\"{x:357,y:609,t:1527873126077};\\\", \\\"{x:353,y:608,t:1527873126093};\\\", \\\"{x:351,y:607,t:1527873126110};\\\", \\\"{x:351,y:606,t:1527873126128};\\\", \\\"{x:350,y:606,t:1527873126183};\\\", \\\"{x:349,y:605,t:1527873126193};\\\", \\\"{x:347,y:603,t:1527873126210};\\\", \\\"{x:344,y:600,t:1527873126228};\\\", \\\"{x:344,y:599,t:1527873126243};\\\", \\\"{x:344,y:597,t:1527873126260};\\\", \\\"{x:344,y:596,t:1527873126278};\\\", \\\"{x:344,y:593,t:1527873126295};\\\", \\\"{x:362,y:584,t:1527873126310};\\\", \\\"{x:372,y:580,t:1527873126327};\\\", \\\"{x:381,y:577,t:1527873126344};\\\", \\\"{x:388,y:574,t:1527873126360};\\\", \\\"{x:393,y:573,t:1527873126378};\\\", \\\"{x:395,y:573,t:1527873126394};\\\", \\\"{x:399,y:573,t:1527873126411};\\\", \\\"{x:401,y:573,t:1527873126428};\\\", \\\"{x:403,y:573,t:1527873126444};\\\", \\\"{x:406,y:576,t:1527873126998};\\\", \\\"{x:407,y:583,t:1527873127010};\\\", \\\"{x:413,y:596,t:1527873127028};\\\", \\\"{x:423,y:612,t:1527873127045};\\\", \\\"{x:434,y:626,t:1527873127061};\\\", \\\"{x:443,y:641,t:1527873127078};\\\", \\\"{x:454,y:656,t:1527873127095};\\\", \\\"{x:459,y:663,t:1527873127111};\\\", \\\"{x:464,y:670,t:1527873127128};\\\", \\\"{x:468,y:678,t:1527873127145};\\\", \\\"{x:473,y:685,t:1527873127162};\\\", \\\"{x:477,y:692,t:1527873127177};\\\", \\\"{x:479,y:696,t:1527873127195};\\\", \\\"{x:481,y:703,t:1527873127211};\\\", \\\"{x:483,y:707,t:1527873127228};\\\", \\\"{x:484,y:709,t:1527873127244};\\\", \\\"{x:485,y:711,t:1527873127262};\\\", \\\"{x:486,y:713,t:1527873127278};\\\", \\\"{x:487,y:714,t:1527873127295};\\\", \\\"{x:487,y:715,t:1527873127312};\\\", \\\"{x:487,y:717,t:1527873127328};\\\", \\\"{x:488,y:717,t:1527873127345};\\\", \\\"{x:488,y:714,t:1527873129040};\\\", \\\"{x:491,y:700,t:1527873129047};\\\", \\\"{x:502,y:669,t:1527873129063};\\\", \\\"{x:518,y:631,t:1527873129080};\\\" ] }, { \\\"rt\\\": 15374, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 329412, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:676,y:487,t:1527873129259};\\\", \\\"{x:683,y:480,t:1527873129288};\\\", \\\"{x:693,y:470,t:1527873129312};\\\", \\\"{x:703,y:461,t:1527873129329};\\\", \\\"{x:710,y:456,t:1527873129433};\\\", \\\"{x:711,y:455,t:1527873130135};\\\", \\\"{x:717,y:451,t:1527873130147};\\\", \\\"{x:729,y:444,t:1527873130164};\\\", \\\"{x:738,y:440,t:1527873130181};\\\", \\\"{x:739,y:438,t:1527873130196};\\\", \\\"{x:740,y:438,t:1527873130214};\\\", \\\"{x:740,y:434,t:1527873130414};\\\", \\\"{x:740,y:427,t:1527873130430};\\\", \\\"{x:740,y:426,t:1527873130447};\\\", \\\"{x:740,y:425,t:1527873130463};\\\", \\\"{x:740,y:423,t:1527873130481};\\\", \\\"{x:738,y:421,t:1527873130496};\\\", \\\"{x:738,y:420,t:1527873130513};\\\", \\\"{x:736,y:419,t:1527873130531};\\\", \\\"{x:735,y:418,t:1527873130546};\\\", \\\"{x:734,y:418,t:1527873130564};\\\", \\\"{x:732,y:417,t:1527873130581};\\\", \\\"{x:728,y:416,t:1527873130597};\\\", \\\"{x:717,y:414,t:1527873130614};\\\", \\\"{x:694,y:411,t:1527873130631};\\\", \\\"{x:671,y:411,t:1527873130647};\\\", \\\"{x:650,y:411,t:1527873130664};\\\", \\\"{x:628,y:411,t:1527873130681};\\\", \\\"{x:605,y:413,t:1527873130698};\\\", \\\"{x:586,y:416,t:1527873130714};\\\", \\\"{x:571,y:419,t:1527873130731};\\\", \\\"{x:565,y:419,t:1527873130748};\\\", \\\"{x:564,y:419,t:1527873130764};\\\", \\\"{x:562,y:419,t:1527873130781};\\\", \\\"{x:559,y:420,t:1527873130798};\\\", \\\"{x:556,y:420,t:1527873130814};\\\", \\\"{x:544,y:423,t:1527873130831};\\\", \\\"{x:539,y:423,t:1527873130848};\\\", \\\"{x:532,y:424,t:1527873130864};\\\", \\\"{x:524,y:425,t:1527873130881};\\\", \\\"{x:515,y:427,t:1527873130898};\\\", \\\"{x:505,y:428,t:1527873130914};\\\", \\\"{x:493,y:430,t:1527873130931};\\\", \\\"{x:474,y:433,t:1527873130948};\\\", \\\"{x:459,y:434,t:1527873130964};\\\", \\\"{x:446,y:437,t:1527873130981};\\\", \\\"{x:436,y:439,t:1527873130998};\\\", \\\"{x:426,y:442,t:1527873131014};\\\", \\\"{x:416,y:445,t:1527873131030};\\\", \\\"{x:414,y:445,t:1527873131048};\\\", \\\"{x:410,y:447,t:1527873131064};\\\", \\\"{x:406,y:448,t:1527873131081};\\\", \\\"{x:405,y:449,t:1527873131098};\\\", \\\"{x:404,y:450,t:1527873131114};\\\", \\\"{x:402,y:451,t:1527873131343};\\\", \\\"{x:402,y:452,t:1527873131359};\\\", \\\"{x:402,y:453,t:1527873131416};\\\", \\\"{x:402,y:455,t:1527873131520};\\\", \\\"{x:402,y:456,t:1527873131531};\\\", \\\"{x:402,y:457,t:1527873131548};\\\", \\\"{x:402,y:459,t:1527873131564};\\\", \\\"{x:402,y:461,t:1527873131581};\\\", \\\"{x:402,y:463,t:1527873131597};\\\", \\\"{x:402,y:466,t:1527873131615};\\\", \\\"{x:402,y:467,t:1527873131630};\\\", \\\"{x:402,y:468,t:1527873131654};\\\", \\\"{x:402,y:469,t:1527873131670};\\\", \\\"{x:402,y:470,t:1527873131695};\\\", \\\"{x:402,y:471,t:1527873131702};\\\", \\\"{x:402,y:472,t:1527873131715};\\\", \\\"{x:402,y:473,t:1527873131730};\\\", \\\"{x:403,y:473,t:1527873131748};\\\", \\\"{x:406,y:474,t:1527873132094};\\\", \\\"{x:413,y:470,t:1527873132102};\\\", \\\"{x:416,y:467,t:1527873132115};\\\", \\\"{x:427,y:460,t:1527873132132};\\\", \\\"{x:435,y:456,t:1527873132148};\\\", \\\"{x:442,y:452,t:1527873132164};\\\", \\\"{x:445,y:450,t:1527873132182};\\\", \\\"{x:447,y:449,t:1527873132197};\\\", \\\"{x:449,y:448,t:1527873132215};\\\", \\\"{x:450,y:447,t:1527873132232};\\\", \\\"{x:451,y:447,t:1527873132248};\\\", \\\"{x:453,y:446,t:1527873132265};\\\", \\\"{x:454,y:446,t:1527873132282};\\\", \\\"{x:456,y:445,t:1527873132303};\\\", \\\"{x:457,y:444,t:1527873132319};\\\", \\\"{x:458,y:444,t:1527873132332};\\\", \\\"{x:461,y:443,t:1527873132349};\\\", \\\"{x:464,y:443,t:1527873132366};\\\", \\\"{x:468,y:441,t:1527873132382};\\\", \\\"{x:476,y:441,t:1527873132399};\\\", \\\"{x:482,y:441,t:1527873132415};\\\", \\\"{x:485,y:441,t:1527873132432};\\\", \\\"{x:487,y:441,t:1527873132449};\\\", \\\"{x:492,y:441,t:1527873132465};\\\", \\\"{x:500,y:441,t:1527873132482};\\\", \\\"{x:511,y:441,t:1527873132499};\\\", \\\"{x:525,y:441,t:1527873132515};\\\", \\\"{x:536,y:441,t:1527873132532};\\\", \\\"{x:551,y:441,t:1527873132549};\\\", \\\"{x:565,y:441,t:1527873132565};\\\", \\\"{x:579,y:441,t:1527873132582};\\\", \\\"{x:601,y:441,t:1527873132599};\\\", \\\"{x:628,y:441,t:1527873132615};\\\", \\\"{x:657,y:441,t:1527873132632};\\\", \\\"{x:686,y:441,t:1527873132649};\\\", \\\"{x:708,y:441,t:1527873132665};\\\", \\\"{x:727,y:441,t:1527873132682};\\\", \\\"{x:747,y:441,t:1527873132699};\\\", \\\"{x:763,y:441,t:1527873132715};\\\", \\\"{x:772,y:441,t:1527873132732};\\\", \\\"{x:782,y:441,t:1527873132749};\\\", \\\"{x:789,y:441,t:1527873132765};\\\", \\\"{x:799,y:441,t:1527873132782};\\\", \\\"{x:818,y:439,t:1527873132800};\\\", \\\"{x:832,y:437,t:1527873132816};\\\", \\\"{x:854,y:433,t:1527873132832};\\\", \\\"{x:878,y:430,t:1527873132849};\\\", \\\"{x:906,y:428,t:1527873132866};\\\", \\\"{x:935,y:423,t:1527873132883};\\\", \\\"{x:964,y:418,t:1527873132899};\\\", \\\"{x:989,y:414,t:1527873132917};\\\", \\\"{x:1013,y:410,t:1527873132932};\\\", \\\"{x:1033,y:407,t:1527873132950};\\\", \\\"{x:1049,y:405,t:1527873132966};\\\", \\\"{x:1056,y:403,t:1527873132983};\\\", \\\"{x:1057,y:403,t:1527873132999};\\\", \\\"{x:1055,y:403,t:1527873133328};\\\", \\\"{x:1054,y:403,t:1527873133335};\\\", \\\"{x:1053,y:404,t:1527873133349};\\\", \\\"{x:1052,y:404,t:1527873133366};\\\", \\\"{x:1050,y:404,t:1527873133383};\\\", \\\"{x:1048,y:404,t:1527873133799};\\\", \\\"{x:1024,y:407,t:1527873133816};\\\", \\\"{x:987,y:410,t:1527873133833};\\\", \\\"{x:955,y:413,t:1527873133851};\\\", \\\"{x:924,y:416,t:1527873133866};\\\", \\\"{x:898,y:421,t:1527873133884};\\\", \\\"{x:875,y:424,t:1527873133900};\\\", \\\"{x:859,y:426,t:1527873133916};\\\", \\\"{x:846,y:429,t:1527873133933};\\\", \\\"{x:834,y:432,t:1527873133950};\\\", \\\"{x:825,y:435,t:1527873133967};\\\", \\\"{x:810,y:441,t:1527873133983};\\\", \\\"{x:795,y:447,t:1527873134000};\\\", \\\"{x:780,y:457,t:1527873134016};\\\", \\\"{x:763,y:468,t:1527873134033};\\\", \\\"{x:745,y:477,t:1527873134051};\\\", \\\"{x:731,y:485,t:1527873134066};\\\", \\\"{x:718,y:492,t:1527873134085};\\\", \\\"{x:709,y:498,t:1527873134099};\\\", \\\"{x:702,y:502,t:1527873134116};\\\", \\\"{x:696,y:505,t:1527873134133};\\\", \\\"{x:686,y:511,t:1527873134149};\\\", \\\"{x:662,y:522,t:1527873134167};\\\", \\\"{x:647,y:527,t:1527873134185};\\\", \\\"{x:632,y:531,t:1527873134200};\\\", \\\"{x:618,y:534,t:1527873134217};\\\", \\\"{x:605,y:537,t:1527873134233};\\\", \\\"{x:591,y:538,t:1527873134250};\\\", \\\"{x:581,y:539,t:1527873134266};\\\", \\\"{x:570,y:539,t:1527873134283};\\\", \\\"{x:564,y:539,t:1527873134301};\\\", \\\"{x:558,y:539,t:1527873134317};\\\", \\\"{x:554,y:539,t:1527873134334};\\\", \\\"{x:543,y:542,t:1527873134350};\\\", \\\"{x:534,y:545,t:1527873134367};\\\", \\\"{x:522,y:548,t:1527873134384};\\\", \\\"{x:512,y:552,t:1527873134401};\\\", \\\"{x:504,y:555,t:1527873134417};\\\", \\\"{x:493,y:561,t:1527873134434};\\\", \\\"{x:484,y:567,t:1527873134452};\\\", \\\"{x:472,y:575,t:1527873134467};\\\", \\\"{x:467,y:579,t:1527873134484};\\\", \\\"{x:463,y:583,t:1527873134500};\\\", \\\"{x:461,y:586,t:1527873134517};\\\", \\\"{x:459,y:588,t:1527873134534};\\\", \\\"{x:458,y:589,t:1527873134550};\\\", \\\"{x:458,y:590,t:1527873134567};\\\", \\\"{x:458,y:588,t:1527873134728};\\\", \\\"{x:458,y:585,t:1527873134735};\\\", \\\"{x:463,y:573,t:1527873134750};\\\", \\\"{x:469,y:565,t:1527873134767};\\\", \\\"{x:475,y:558,t:1527873134785};\\\", \\\"{x:477,y:555,t:1527873134801};\\\", \\\"{x:478,y:553,t:1527873134817};\\\", \\\"{x:478,y:551,t:1527873134833};\\\", \\\"{x:480,y:548,t:1527873134850};\\\", \\\"{x:480,y:545,t:1527873134868};\\\", \\\"{x:481,y:542,t:1527873134884};\\\", \\\"{x:483,y:540,t:1527873134900};\\\", \\\"{x:484,y:537,t:1527873134918};\\\", \\\"{x:488,y:531,t:1527873134934};\\\", \\\"{x:492,y:527,t:1527873134951};\\\", \\\"{x:496,y:523,t:1527873134969};\\\", \\\"{x:503,y:519,t:1527873134984};\\\", \\\"{x:511,y:516,t:1527873135001};\\\", \\\"{x:519,y:512,t:1527873135018};\\\", \\\"{x:528,y:508,t:1527873135033};\\\", \\\"{x:534,y:505,t:1527873135051};\\\", \\\"{x:540,y:501,t:1527873135068};\\\", \\\"{x:543,y:500,t:1527873135084};\\\", \\\"{x:548,y:497,t:1527873135101};\\\", \\\"{x:552,y:495,t:1527873135118};\\\", \\\"{x:554,y:494,t:1527873135133};\\\", \\\"{x:558,y:492,t:1527873135150};\\\", \\\"{x:560,y:492,t:1527873135168};\\\", \\\"{x:565,y:490,t:1527873135184};\\\", \\\"{x:571,y:487,t:1527873135201};\\\", \\\"{x:576,y:485,t:1527873135219};\\\", \\\"{x:582,y:482,t:1527873135234};\\\", \\\"{x:591,y:480,t:1527873135251};\\\", \\\"{x:603,y:477,t:1527873135268};\\\", \\\"{x:618,y:475,t:1527873135285};\\\", \\\"{x:639,y:470,t:1527873135301};\\\", \\\"{x:663,y:467,t:1527873135318};\\\", \\\"{x:705,y:465,t:1527873135334};\\\", \\\"{x:736,y:460,t:1527873135351};\\\", \\\"{x:765,y:457,t:1527873135368};\\\", \\\"{x:790,y:455,t:1527873135384};\\\", \\\"{x:814,y:453,t:1527873135401};\\\", \\\"{x:837,y:452,t:1527873135418};\\\", \\\"{x:859,y:452,t:1527873135435};\\\", \\\"{x:878,y:449,t:1527873135450};\\\", \\\"{x:898,y:446,t:1527873135468};\\\", \\\"{x:918,y:443,t:1527873135485};\\\", \\\"{x:942,y:441,t:1527873135501};\\\", \\\"{x:966,y:439,t:1527873135519};\\\", \\\"{x:1010,y:439,t:1527873135535};\\\", \\\"{x:1053,y:439,t:1527873135551};\\\", \\\"{x:1106,y:439,t:1527873135569};\\\", \\\"{x:1156,y:439,t:1527873135585};\\\", \\\"{x:1212,y:439,t:1527873135601};\\\", \\\"{x:1246,y:439,t:1527873135618};\\\", \\\"{x:1268,y:438,t:1527873135635};\\\", \\\"{x:1282,y:438,t:1527873135652};\\\", \\\"{x:1288,y:438,t:1527873135669};\\\", \\\"{x:1292,y:438,t:1527873135685};\\\", \\\"{x:1295,y:438,t:1527873135701};\\\", \\\"{x:1298,y:438,t:1527873135719};\\\", \\\"{x:1309,y:440,t:1527873135735};\\\", \\\"{x:1315,y:441,t:1527873135752};\\\", \\\"{x:1327,y:442,t:1527873135768};\\\", \\\"{x:1336,y:443,t:1527873135785};\\\", \\\"{x:1348,y:446,t:1527873135802};\\\", \\\"{x:1355,y:447,t:1527873135818};\\\", \\\"{x:1362,y:448,t:1527873135835};\\\", \\\"{x:1372,y:449,t:1527873135851};\\\", \\\"{x:1388,y:452,t:1527873135867};\\\", \\\"{x:1398,y:453,t:1527873135885};\\\", \\\"{x:1406,y:455,t:1527873135902};\\\", \\\"{x:1412,y:459,t:1527873135918};\\\", \\\"{x:1422,y:468,t:1527873135935};\\\", \\\"{x:1429,y:479,t:1527873135952};\\\", \\\"{x:1439,y:492,t:1527873135968};\\\", \\\"{x:1447,y:504,t:1527873135985};\\\", \\\"{x:1455,y:514,t:1527873136002};\\\", \\\"{x:1461,y:525,t:1527873136018};\\\", \\\"{x:1464,y:533,t:1527873136035};\\\", \\\"{x:1469,y:542,t:1527873136052};\\\", \\\"{x:1470,y:551,t:1527873136068};\\\", \\\"{x:1473,y:561,t:1527873136086};\\\", \\\"{x:1475,y:573,t:1527873136103};\\\", \\\"{x:1477,y:584,t:1527873136118};\\\", \\\"{x:1481,y:599,t:1527873136135};\\\", \\\"{x:1483,y:606,t:1527873136153};\\\", \\\"{x:1483,y:611,t:1527873136169};\\\", \\\"{x:1484,y:617,t:1527873136185};\\\", \\\"{x:1485,y:623,t:1527873136202};\\\", \\\"{x:1486,y:632,t:1527873136219};\\\", \\\"{x:1487,y:637,t:1527873136236};\\\", \\\"{x:1488,y:641,t:1527873136252};\\\", \\\"{x:1489,y:645,t:1527873136269};\\\", \\\"{x:1489,y:648,t:1527873136286};\\\", \\\"{x:1489,y:654,t:1527873136302};\\\", \\\"{x:1485,y:681,t:1527873136320};\\\", \\\"{x:1479,y:699,t:1527873136336};\\\", \\\"{x:1477,y:708,t:1527873136353};\\\", \\\"{x:1475,y:713,t:1527873136369};\\\", \\\"{x:1473,y:718,t:1527873136386};\\\", \\\"{x:1473,y:719,t:1527873136406};\\\", \\\"{x:1473,y:721,t:1527873136422};\\\", \\\"{x:1472,y:722,t:1527873136447};\\\", \\\"{x:1471,y:723,t:1527873136454};\\\", \\\"{x:1471,y:724,t:1527873136470};\\\", \\\"{x:1471,y:726,t:1527873136494};\\\", \\\"{x:1471,y:727,t:1527873136518};\\\", \\\"{x:1470,y:727,t:1527873136535};\\\", \\\"{x:1470,y:729,t:1527873136552};\\\", \\\"{x:1470,y:730,t:1527873136583};\\\", \\\"{x:1469,y:731,t:1527873136655};\\\", \\\"{x:1467,y:727,t:1527873137072};\\\", \\\"{x:1463,y:721,t:1527873137087};\\\", \\\"{x:1456,y:711,t:1527873137102};\\\", \\\"{x:1447,y:702,t:1527873137119};\\\", \\\"{x:1442,y:695,t:1527873137136};\\\", \\\"{x:1435,y:689,t:1527873137153};\\\", \\\"{x:1429,y:684,t:1527873137170};\\\", \\\"{x:1422,y:678,t:1527873137187};\\\", \\\"{x:1412,y:673,t:1527873137203};\\\", \\\"{x:1401,y:665,t:1527873137219};\\\", \\\"{x:1393,y:660,t:1527873137236};\\\", \\\"{x:1386,y:656,t:1527873137253};\\\", \\\"{x:1384,y:655,t:1527873137269};\\\", \\\"{x:1377,y:651,t:1527873137287};\\\", \\\"{x:1362,y:642,t:1527873137303};\\\", \\\"{x:1350,y:637,t:1527873137319};\\\", \\\"{x:1339,y:632,t:1527873137337};\\\", \\\"{x:1332,y:628,t:1527873137354};\\\", \\\"{x:1324,y:625,t:1527873137370};\\\", \\\"{x:1312,y:620,t:1527873137386};\\\", \\\"{x:1294,y:618,t:1527873137404};\\\", \\\"{x:1280,y:615,t:1527873137420};\\\", \\\"{x:1276,y:615,t:1527873137436};\\\", \\\"{x:1272,y:615,t:1527873137453};\\\", \\\"{x:1269,y:615,t:1527873137469};\\\", \\\"{x:1265,y:615,t:1527873137486};\\\", \\\"{x:1258,y:615,t:1527873137503};\\\", \\\"{x:1256,y:615,t:1527873137520};\\\", \\\"{x:1252,y:615,t:1527873137536};\\\", \\\"{x:1249,y:615,t:1527873137557};\\\", \\\"{x:1247,y:614,t:1527873137654};\\\", \\\"{x:1247,y:612,t:1527873137670};\\\", \\\"{x:1247,y:610,t:1527873137686};\\\", \\\"{x:1247,y:608,t:1527873137703};\\\", \\\"{x:1247,y:604,t:1527873137880};\\\", \\\"{x:1247,y:602,t:1527873137887};\\\", \\\"{x:1247,y:598,t:1527873137903};\\\", \\\"{x:1249,y:594,t:1527873137920};\\\", \\\"{x:1251,y:588,t:1527873137937};\\\", \\\"{x:1252,y:586,t:1527873137954};\\\", \\\"{x:1254,y:584,t:1527873137971};\\\", \\\"{x:1256,y:582,t:1527873137986};\\\", \\\"{x:1259,y:580,t:1527873138004};\\\", \\\"{x:1262,y:578,t:1527873138021};\\\", \\\"{x:1267,y:575,t:1527873138036};\\\", \\\"{x:1271,y:573,t:1527873138053};\\\", \\\"{x:1273,y:572,t:1527873138070};\\\", \\\"{x:1274,y:571,t:1527873138087};\\\", \\\"{x:1274,y:570,t:1527873138728};\\\", \\\"{x:1274,y:569,t:1527873138738};\\\", \\\"{x:1256,y:569,t:1527873138754};\\\", \\\"{x:1235,y:569,t:1527873138770};\\\", \\\"{x:1206,y:569,t:1527873138786};\\\", \\\"{x:1165,y:569,t:1527873138804};\\\", \\\"{x:1118,y:569,t:1527873138820};\\\", \\\"{x:1059,y:569,t:1527873138837};\\\", \\\"{x:978,y:569,t:1527873138854};\\\", \\\"{x:936,y:569,t:1527873138870};\\\", \\\"{x:897,y:569,t:1527873138887};\\\", \\\"{x:863,y:567,t:1527873138904};\\\", \\\"{x:830,y:566,t:1527873138920};\\\", \\\"{x:799,y:566,t:1527873138937};\\\", \\\"{x:771,y:566,t:1527873138954};\\\", \\\"{x:750,y:566,t:1527873138971};\\\", \\\"{x:728,y:566,t:1527873138987};\\\", \\\"{x:700,y:568,t:1527873139005};\\\", \\\"{x:670,y:572,t:1527873139021};\\\", \\\"{x:641,y:576,t:1527873139037};\\\", \\\"{x:598,y:582,t:1527873139055};\\\", \\\"{x:573,y:587,t:1527873139071};\\\", \\\"{x:556,y:588,t:1527873139088};\\\", \\\"{x:539,y:591,t:1527873139103};\\\", \\\"{x:524,y:592,t:1527873139121};\\\", \\\"{x:513,y:592,t:1527873139137};\\\", \\\"{x:508,y:592,t:1527873139154};\\\", \\\"{x:506,y:593,t:1527873139171};\\\", \\\"{x:505,y:593,t:1527873139188};\\\", \\\"{x:500,y:595,t:1527873139205};\\\", \\\"{x:492,y:595,t:1527873139221};\\\", \\\"{x:485,y:595,t:1527873139238};\\\", \\\"{x:482,y:595,t:1527873139254};\\\", \\\"{x:468,y:595,t:1527873139271};\\\", \\\"{x:452,y:593,t:1527873139289};\\\", \\\"{x:435,y:590,t:1527873139305};\\\", \\\"{x:413,y:584,t:1527873139322};\\\", \\\"{x:385,y:582,t:1527873139338};\\\", \\\"{x:364,y:578,t:1527873139355};\\\", \\\"{x:346,y:576,t:1527873139371};\\\", \\\"{x:331,y:573,t:1527873139388};\\\", \\\"{x:327,y:572,t:1527873139404};\\\", \\\"{x:326,y:572,t:1527873139420};\\\", \\\"{x:325,y:572,t:1527873139438};\\\", \\\"{x:324,y:572,t:1527873139478};\\\", \\\"{x:324,y:571,t:1527873139598};\\\", \\\"{x:324,y:569,t:1527873139606};\\\", \\\"{x:326,y:564,t:1527873139621};\\\", \\\"{x:355,y:554,t:1527873139639};\\\", \\\"{x:364,y:553,t:1527873139654};\\\", \\\"{x:404,y:548,t:1527873139671};\\\", \\\"{x:439,y:544,t:1527873139688};\\\", \\\"{x:479,y:543,t:1527873139705};\\\", \\\"{x:521,y:543,t:1527873139721};\\\", \\\"{x:551,y:543,t:1527873139738};\\\", \\\"{x:574,y:543,t:1527873139754};\\\", \\\"{x:594,y:543,t:1527873139772};\\\", \\\"{x:605,y:543,t:1527873139788};\\\", \\\"{x:609,y:542,t:1527873139805};\\\", \\\"{x:610,y:541,t:1527873139934};\\\", \\\"{x:610,y:540,t:1527873140000};\\\", \\\"{x:610,y:537,t:1527873140007};\\\", \\\"{x:610,y:536,t:1527873140022};\\\", \\\"{x:610,y:531,t:1527873140039};\\\", \\\"{x:608,y:527,t:1527873140056};\\\", \\\"{x:607,y:524,t:1527873140073};\\\", \\\"{x:607,y:521,t:1527873140088};\\\", \\\"{x:606,y:517,t:1527873140105};\\\", \\\"{x:605,y:515,t:1527873140122};\\\", \\\"{x:605,y:512,t:1527873140138};\\\", \\\"{x:605,y:511,t:1527873140155};\\\", \\\"{x:605,y:510,t:1527873140172};\\\", \\\"{x:605,y:509,t:1527873140188};\\\", \\\"{x:605,y:508,t:1527873140205};\\\", \\\"{x:609,y:508,t:1527873140646};\\\", \\\"{x:619,y:510,t:1527873140655};\\\", \\\"{x:650,y:512,t:1527873140672};\\\", \\\"{x:680,y:516,t:1527873140689};\\\", \\\"{x:706,y:517,t:1527873140705};\\\", \\\"{x:727,y:521,t:1527873140723};\\\", \\\"{x:736,y:521,t:1527873140739};\\\", \\\"{x:740,y:522,t:1527873140754};\\\", \\\"{x:743,y:522,t:1527873140772};\\\", \\\"{x:744,y:523,t:1527873140789};\\\", \\\"{x:747,y:523,t:1527873140805};\\\", \\\"{x:750,y:525,t:1527873140823};\\\", \\\"{x:752,y:525,t:1527873140863};\\\", \\\"{x:753,y:525,t:1527873140872};\\\", \\\"{x:753,y:526,t:1527873140889};\\\", \\\"{x:756,y:528,t:1527873140906};\\\", \\\"{x:758,y:529,t:1527873140922};\\\", \\\"{x:760,y:530,t:1527873140939};\\\", \\\"{x:761,y:531,t:1527873140957};\\\", \\\"{x:763,y:532,t:1527873140972};\\\", \\\"{x:765,y:533,t:1527873140989};\\\", \\\"{x:768,y:534,t:1527873141006};\\\", \\\"{x:770,y:534,t:1527873141023};\\\", \\\"{x:776,y:534,t:1527873141039};\\\", \\\"{x:781,y:534,t:1527873141057};\\\", \\\"{x:786,y:534,t:1527873141072};\\\", \\\"{x:790,y:534,t:1527873141090};\\\", \\\"{x:791,y:534,t:1527873141106};\\\", \\\"{x:793,y:534,t:1527873141122};\\\", \\\"{x:796,y:534,t:1527873141139};\\\", \\\"{x:799,y:534,t:1527873141156};\\\", \\\"{x:803,y:537,t:1527873141173};\\\", \\\"{x:811,y:538,t:1527873141189};\\\", \\\"{x:817,y:541,t:1527873141205};\\\", \\\"{x:821,y:541,t:1527873141223};\\\", \\\"{x:823,y:541,t:1527873141238};\\\", \\\"{x:824,y:541,t:1527873141256};\\\", \\\"{x:825,y:541,t:1527873141273};\\\", \\\"{x:826,y:541,t:1527873141289};\\\", \\\"{x:827,y:541,t:1527873141306};\\\", \\\"{x:828,y:541,t:1527873141323};\\\", \\\"{x:827,y:541,t:1527873142247};\\\", \\\"{x:826,y:541,t:1527873142257};\\\", \\\"{x:821,y:539,t:1527873142275};\\\", \\\"{x:820,y:537,t:1527873142290};\\\", \\\"{x:817,y:536,t:1527873142307};\\\", \\\"{x:815,y:534,t:1527873142323};\\\", \\\"{x:813,y:533,t:1527873142340};\\\", \\\"{x:811,y:531,t:1527873142357};\\\", \\\"{x:810,y:531,t:1527873142373};\\\", \\\"{x:805,y:528,t:1527873142390};\\\", \\\"{x:802,y:526,t:1527873142407};\\\", \\\"{x:796,y:524,t:1527873142423};\\\", \\\"{x:790,y:523,t:1527873142440};\\\", \\\"{x:774,y:521,t:1527873142457};\\\", \\\"{x:755,y:521,t:1527873142473};\\\", \\\"{x:731,y:521,t:1527873142490};\\\", \\\"{x:704,y:521,t:1527873142507};\\\", \\\"{x:679,y:521,t:1527873142523};\\\", \\\"{x:660,y:521,t:1527873142540};\\\", \\\"{x:646,y:521,t:1527873142558};\\\", \\\"{x:637,y:523,t:1527873142573};\\\", \\\"{x:629,y:524,t:1527873142591};\\\", \\\"{x:626,y:524,t:1527873142608};\\\", \\\"{x:624,y:524,t:1527873142623};\\\", \\\"{x:621,y:525,t:1527873142642};\\\", \\\"{x:618,y:525,t:1527873142657};\\\", \\\"{x:615,y:526,t:1527873142673};\\\", \\\"{x:610,y:527,t:1527873142690};\\\", \\\"{x:604,y:528,t:1527873142707};\\\", \\\"{x:598,y:529,t:1527873142724};\\\", \\\"{x:591,y:531,t:1527873142739};\\\", \\\"{x:583,y:533,t:1527873142757};\\\", \\\"{x:570,y:538,t:1527873142774};\\\", \\\"{x:562,y:540,t:1527873142790};\\\", \\\"{x:556,y:542,t:1527873142807};\\\", \\\"{x:550,y:544,t:1527873142824};\\\", \\\"{x:545,y:545,t:1527873142840};\\\", \\\"{x:545,y:546,t:1527873142857};\\\", \\\"{x:540,y:549,t:1527873142874};\\\", \\\"{x:538,y:551,t:1527873142890};\\\", \\\"{x:534,y:553,t:1527873142907};\\\", \\\"{x:532,y:555,t:1527873142924};\\\", \\\"{x:531,y:556,t:1527873142942};\\\", \\\"{x:529,y:558,t:1527873142957};\\\", \\\"{x:527,y:558,t:1527873142974};\\\", \\\"{x:524,y:560,t:1527873142991};\\\", \\\"{x:519,y:563,t:1527873143008};\\\", \\\"{x:514,y:564,t:1527873143024};\\\", \\\"{x:510,y:567,t:1527873143041};\\\", \\\"{x:504,y:571,t:1527873143057};\\\", \\\"{x:499,y:577,t:1527873143073};\\\", \\\"{x:492,y:584,t:1527873143092};\\\", \\\"{x:485,y:593,t:1527873143107};\\\", \\\"{x:481,y:602,t:1527873143125};\\\", \\\"{x:476,y:611,t:1527873143141};\\\", \\\"{x:474,y:616,t:1527873143157};\\\", \\\"{x:472,y:621,t:1527873143174};\\\", \\\"{x:472,y:624,t:1527873143190};\\\", \\\"{x:472,y:628,t:1527873143207};\\\", \\\"{x:472,y:633,t:1527873143224};\\\", \\\"{x:472,y:645,t:1527873143242};\\\", \\\"{x:472,y:653,t:1527873143257};\\\", \\\"{x:472,y:660,t:1527873143274};\\\", \\\"{x:472,y:667,t:1527873143291};\\\", \\\"{x:472,y:676,t:1527873143308};\\\", \\\"{x:472,y:683,t:1527873143324};\\\", \\\"{x:474,y:687,t:1527873143342};\\\", \\\"{x:474,y:691,t:1527873143357};\\\", \\\"{x:475,y:698,t:1527873143374};\\\", \\\"{x:475,y:701,t:1527873143391};\\\", \\\"{x:475,y:704,t:1527873143408};\\\", \\\"{x:475,y:707,t:1527873143424};\\\", \\\"{x:475,y:710,t:1527873143441};\\\", \\\"{x:475,y:714,t:1527873143459};\\\", \\\"{x:475,y:719,t:1527873143474};\\\", \\\"{x:474,y:722,t:1527873143493};\\\", \\\"{x:473,y:726,t:1527873143508};\\\", \\\"{x:473,y:729,t:1527873143524};\\\", \\\"{x:473,y:733,t:1527873143541};\\\", \\\"{x:473,y:739,t:1527873143558};\\\", \\\"{x:473,y:742,t:1527873143575};\\\", \\\"{x:473,y:744,t:1527873143591};\\\", \\\"{x:473,y:747,t:1527873143609};\\\", \\\"{x:473,y:749,t:1527873143625};\\\", \\\"{x:473,y:750,t:1527873143641};\\\", \\\"{x:473,y:752,t:1527873143658};\\\", \\\"{x:473,y:753,t:1527873143675};\\\", \\\"{x:473,y:755,t:1527873143693};\\\", \\\"{x:473,y:756,t:1527873143708};\\\", \\\"{x:473,y:758,t:1527873143724};\\\", \\\"{x:473,y:759,t:1527873143741};\\\", \\\"{x:473,y:761,t:1527873143758};\\\", \\\"{x:473,y:762,t:1527873143782};\\\", \\\"{x:473,y:763,t:1527873143895};\\\", \\\"{x:474,y:763,t:1527873143935};\\\", \\\"{x:475,y:763,t:1527873143959};\\\", \\\"{x:477,y:761,t:1527873143983};\\\", \\\"{x:477,y:760,t:1527873144015};\\\", \\\"{x:478,y:759,t:1527873144025};\\\", \\\"{x:478,y:758,t:1527873144041};\\\", \\\"{x:478,y:756,t:1527873144058};\\\", \\\"{x:478,y:755,t:1527873144078};\\\", \\\"{x:478,y:753,t:1527873144096};\\\", \\\"{x:479,y:752,t:1527873144108};\\\", \\\"{x:480,y:752,t:1527873144125};\\\", \\\"{x:480,y:751,t:1527873144142};\\\", \\\"{x:480,y:750,t:1527873144158};\\\", \\\"{x:481,y:749,t:1527873144175};\\\", \\\"{x:482,y:747,t:1527873144191};\\\", \\\"{x:482,y:746,t:1527873144208};\\\", \\\"{x:483,y:745,t:1527873144230};\\\", \\\"{x:483,y:740,t:1527873145343};\\\", \\\"{x:483,y:714,t:1527873145359};\\\", \\\"{x:483,y:695,t:1527873145376};\\\", \\\"{x:484,y:680,t:1527873145392};\\\", \\\"{x:486,y:666,t:1527873145409};\\\", \\\"{x:489,y:650,t:1527873145427};\\\", \\\"{x:490,y:636,t:1527873145442};\\\", \\\"{x:493,y:617,t:1527873145459};\\\", \\\"{x:495,y:600,t:1527873145477};\\\", \\\"{x:496,y:589,t:1527873145492};\\\", \\\"{x:498,y:579,t:1527873145510};\\\", \\\"{x:500,y:570,t:1527873145527};\\\", \\\"{x:500,y:566,t:1527873145542};\\\", \\\"{x:500,y:564,t:1527873145567};\\\", \\\"{x:500,y:557,t:1527873145707};\\\", \\\"{x:497,y:557,t:1527873145726};\\\", \\\"{x:488,y:558,t:1527873145743};\\\", \\\"{x:466,y:566,t:1527873145759};\\\", \\\"{x:445,y:573,t:1527873145776};\\\" ] }, { \\\"rt\\\": 34500, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 365218, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -4-Z -05 PM-N -D \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:442,y:573,t:1527873145947};\\\", \\\"{x:452,y:573,t:1527873152773};\\\", \\\"{x:477,y:573,t:1527873152781};\\\", \\\"{x:579,y:573,t:1527873152798};\\\", \\\"{x:703,y:586,t:1527873152814};\\\", \\\"{x:847,y:603,t:1527873152832};\\\", \\\"{x:988,y:622,t:1527873152846};\\\", \\\"{x:1112,y:639,t:1527873152864};\\\", \\\"{x:1217,y:647,t:1527873152881};\\\", \\\"{x:1279,y:652,t:1527873152898};\\\", \\\"{x:1327,y:659,t:1527873152915};\\\", \\\"{x:1354,y:666,t:1527873152932};\\\", \\\"{x:1365,y:671,t:1527873152948};\\\", \\\"{x:1370,y:674,t:1527873152965};\\\", \\\"{x:1375,y:677,t:1527873152981};\\\", \\\"{x:1394,y:694,t:1527873152999};\\\", \\\"{x:1414,y:708,t:1527873153015};\\\", \\\"{x:1426,y:716,t:1527873153031};\\\", \\\"{x:1427,y:717,t:1527873153049};\\\", \\\"{x:1426,y:717,t:1527873153118};\\\", \\\"{x:1419,y:715,t:1527873153132};\\\", \\\"{x:1401,y:710,t:1527873153149};\\\", \\\"{x:1385,y:706,t:1527873153165};\\\", \\\"{x:1381,y:704,t:1527873153182};\\\", \\\"{x:1380,y:704,t:1527873153198};\\\", \\\"{x:1378,y:704,t:1527873153215};\\\", \\\"{x:1375,y:704,t:1527873153233};\\\", \\\"{x:1372,y:704,t:1527873153249};\\\", \\\"{x:1370,y:704,t:1527873153266};\\\", \\\"{x:1366,y:704,t:1527873153282};\\\", \\\"{x:1362,y:704,t:1527873153298};\\\", \\\"{x:1359,y:704,t:1527873153316};\\\", \\\"{x:1354,y:704,t:1527873153333};\\\", \\\"{x:1348,y:705,t:1527873153349};\\\", \\\"{x:1339,y:707,t:1527873153366};\\\", \\\"{x:1319,y:711,t:1527873153383};\\\", \\\"{x:1306,y:712,t:1527873153398};\\\", \\\"{x:1292,y:715,t:1527873153416};\\\", \\\"{x:1285,y:716,t:1527873153432};\\\", \\\"{x:1282,y:716,t:1527873153449};\\\", \\\"{x:1281,y:716,t:1527873153465};\\\", \\\"{x:1280,y:716,t:1527873153495};\\\", \\\"{x:1279,y:716,t:1527873153511};\\\", \\\"{x:1278,y:716,t:1527873153519};\\\", \\\"{x:1277,y:717,t:1527873153533};\\\", \\\"{x:1274,y:719,t:1527873153549};\\\", \\\"{x:1269,y:720,t:1527873153567};\\\", \\\"{x:1263,y:723,t:1527873153584};\\\", \\\"{x:1260,y:724,t:1527873153600};\\\", \\\"{x:1257,y:726,t:1527873153616};\\\", \\\"{x:1256,y:726,t:1527873153633};\\\", \\\"{x:1254,y:726,t:1527873153735};\\\", \\\"{x:1251,y:726,t:1527873153749};\\\", \\\"{x:1246,y:720,t:1527873153766};\\\", \\\"{x:1244,y:718,t:1527873153783};\\\", \\\"{x:1244,y:717,t:1527873153800};\\\", \\\"{x:1242,y:715,t:1527873153816};\\\", \\\"{x:1242,y:714,t:1527873153833};\\\", \\\"{x:1242,y:713,t:1527873153850};\\\", \\\"{x:1242,y:712,t:1527873153866};\\\", \\\"{x:1241,y:710,t:1527873153883};\\\", \\\"{x:1241,y:707,t:1527873153900};\\\", \\\"{x:1241,y:703,t:1527873153916};\\\", \\\"{x:1241,y:700,t:1527873153933};\\\", \\\"{x:1241,y:696,t:1527873153950};\\\", \\\"{x:1241,y:692,t:1527873153965};\\\", \\\"{x:1241,y:687,t:1527873153982};\\\", \\\"{x:1241,y:684,t:1527873154000};\\\", \\\"{x:1241,y:682,t:1527873154015};\\\", \\\"{x:1241,y:681,t:1527873154038};\\\", \\\"{x:1241,y:680,t:1527873154049};\\\", \\\"{x:1241,y:682,t:1527873154407};\\\", \\\"{x:1241,y:685,t:1527873154417};\\\", \\\"{x:1241,y:689,t:1527873154433};\\\", \\\"{x:1241,y:692,t:1527873154450};\\\", \\\"{x:1241,y:693,t:1527873154467};\\\", \\\"{x:1241,y:694,t:1527873154483};\\\", \\\"{x:1241,y:695,t:1527873154703};\\\", \\\"{x:1242,y:695,t:1527873154716};\\\", \\\"{x:1245,y:694,t:1527873154734};\\\", \\\"{x:1246,y:694,t:1527873154750};\\\", \\\"{x:1247,y:694,t:1527873154774};\\\", \\\"{x:1248,y:694,t:1527873154783};\\\", \\\"{x:1255,y:694,t:1527873154799};\\\", \\\"{x:1264,y:694,t:1527873154816};\\\", \\\"{x:1271,y:694,t:1527873154834};\\\", \\\"{x:1279,y:696,t:1527873154850};\\\", \\\"{x:1289,y:696,t:1527873154866};\\\", \\\"{x:1306,y:696,t:1527873154884};\\\", \\\"{x:1326,y:696,t:1527873154899};\\\", \\\"{x:1341,y:696,t:1527873154917};\\\", \\\"{x:1347,y:696,t:1527873154935};\\\", \\\"{x:1351,y:696,t:1527873154949};\\\", \\\"{x:1352,y:696,t:1527873154966};\\\", \\\"{x:1352,y:697,t:1527873156159};\\\", \\\"{x:1352,y:704,t:1527873156170};\\\", \\\"{x:1350,y:722,t:1527873156186};\\\", \\\"{x:1347,y:735,t:1527873156201};\\\", \\\"{x:1346,y:743,t:1527873156218};\\\", \\\"{x:1346,y:747,t:1527873156235};\\\", \\\"{x:1344,y:750,t:1527873156251};\\\", \\\"{x:1344,y:753,t:1527873156268};\\\", \\\"{x:1344,y:757,t:1527873156285};\\\", \\\"{x:1344,y:760,t:1527873156302};\\\", \\\"{x:1344,y:764,t:1527873156318};\\\", \\\"{x:1344,y:765,t:1527873156335};\\\", \\\"{x:1344,y:766,t:1527873156351};\\\", \\\"{x:1344,y:767,t:1527873156368};\\\", \\\"{x:1342,y:755,t:1527873159024};\\\", \\\"{x:1338,y:736,t:1527873159037};\\\", \\\"{x:1337,y:718,t:1527873159053};\\\", \\\"{x:1336,y:711,t:1527873159071};\\\", \\\"{x:1336,y:709,t:1527873159087};\\\", \\\"{x:1336,y:705,t:1527873159104};\\\", \\\"{x:1336,y:703,t:1527873159120};\\\", \\\"{x:1334,y:699,t:1527873159137};\\\", \\\"{x:1333,y:693,t:1527873159153};\\\", \\\"{x:1333,y:690,t:1527873159170};\\\", \\\"{x:1333,y:688,t:1527873159187};\\\", \\\"{x:1333,y:686,t:1527873159204};\\\", \\\"{x:1332,y:683,t:1527873159220};\\\", \\\"{x:1331,y:681,t:1527873159237};\\\", \\\"{x:1330,y:679,t:1527873159253};\\\", \\\"{x:1330,y:683,t:1527873159447};\\\", \\\"{x:1331,y:686,t:1527873159454};\\\", \\\"{x:1332,y:693,t:1527873159471};\\\", \\\"{x:1334,y:704,t:1527873159487};\\\", \\\"{x:1334,y:709,t:1527873159505};\\\", \\\"{x:1336,y:717,t:1527873159521};\\\", \\\"{x:1336,y:720,t:1527873159537};\\\", \\\"{x:1337,y:724,t:1527873159555};\\\", \\\"{x:1337,y:728,t:1527873159570};\\\", \\\"{x:1338,y:732,t:1527873159587};\\\", \\\"{x:1338,y:735,t:1527873159604};\\\", \\\"{x:1338,y:737,t:1527873159620};\\\", \\\"{x:1338,y:738,t:1527873159638};\\\", \\\"{x:1338,y:739,t:1527873159655};\\\", \\\"{x:1339,y:739,t:1527873162711};\\\", \\\"{x:1339,y:736,t:1527873162723};\\\", \\\"{x:1340,y:732,t:1527873162740};\\\", \\\"{x:1340,y:730,t:1527873162756};\\\", \\\"{x:1340,y:728,t:1527873162773};\\\", \\\"{x:1340,y:727,t:1527873162789};\\\", \\\"{x:1340,y:725,t:1527873162806};\\\", \\\"{x:1340,y:724,t:1527873162831};\\\", \\\"{x:1340,y:723,t:1527873162839};\\\", \\\"{x:1340,y:721,t:1527873162856};\\\", \\\"{x:1340,y:719,t:1527873162874};\\\", \\\"{x:1340,y:718,t:1527873162894};\\\", \\\"{x:1340,y:717,t:1527873162906};\\\", \\\"{x:1340,y:716,t:1527873162923};\\\", \\\"{x:1340,y:712,t:1527873162939};\\\", \\\"{x:1340,y:710,t:1527873162957};\\\", \\\"{x:1340,y:706,t:1527873162972};\\\", \\\"{x:1340,y:704,t:1527873162989};\\\", \\\"{x:1340,y:698,t:1527873163006};\\\", \\\"{x:1338,y:690,t:1527873163022};\\\", \\\"{x:1337,y:685,t:1527873163039};\\\", \\\"{x:1335,y:680,t:1527873163055};\\\", \\\"{x:1334,y:679,t:1527873163072};\\\", \\\"{x:1334,y:678,t:1527873163303};\\\", \\\"{x:1331,y:678,t:1527873163311};\\\", \\\"{x:1324,y:678,t:1527873163323};\\\", \\\"{x:1296,y:684,t:1527873163341};\\\", \\\"{x:1256,y:689,t:1527873163356};\\\", \\\"{x:1208,y:689,t:1527873163373};\\\", \\\"{x:1146,y:689,t:1527873163390};\\\", \\\"{x:1112,y:689,t:1527873163405};\\\", \\\"{x:1091,y:689,t:1527873163423};\\\", \\\"{x:1070,y:689,t:1527873163439};\\\", \\\"{x:1059,y:689,t:1527873163456};\\\", \\\"{x:1053,y:689,t:1527873163472};\\\", \\\"{x:1051,y:689,t:1527873163490};\\\", \\\"{x:1047,y:689,t:1527873163505};\\\", \\\"{x:1042,y:689,t:1527873163523};\\\", \\\"{x:1036,y:690,t:1527873163540};\\\", \\\"{x:1024,y:692,t:1527873163557};\\\", \\\"{x:1013,y:692,t:1527873163573};\\\", \\\"{x:997,y:692,t:1527873163589};\\\", \\\"{x:988,y:692,t:1527873163606};\\\", \\\"{x:976,y:692,t:1527873163623};\\\", \\\"{x:962,y:692,t:1527873163640};\\\", \\\"{x:942,y:687,t:1527873163657};\\\", \\\"{x:898,y:672,t:1527873163673};\\\", \\\"{x:860,y:663,t:1527873163690};\\\", \\\"{x:812,y:655,t:1527873163708};\\\", \\\"{x:765,y:649,t:1527873163723};\\\", \\\"{x:731,y:649,t:1527873163740};\\\", \\\"{x:705,y:648,t:1527873163757};\\\", \\\"{x:684,y:648,t:1527873163773};\\\", \\\"{x:662,y:646,t:1527873163790};\\\", \\\"{x:657,y:645,t:1527873163806};\\\", \\\"{x:650,y:644,t:1527873163824};\\\", \\\"{x:645,y:642,t:1527873163841};\\\", \\\"{x:639,y:640,t:1527873163857};\\\", \\\"{x:634,y:640,t:1527873163873};\\\", \\\"{x:632,y:638,t:1527873163891};\\\", \\\"{x:633,y:636,t:1527873163967};\\\", \\\"{x:640,y:636,t:1527873163973};\\\", \\\"{x:685,y:639,t:1527873163991};\\\", \\\"{x:696,y:639,t:1527873164008};\\\", \\\"{x:697,y:637,t:1527873164231};\\\", \\\"{x:697,y:636,t:1527873164246};\\\", \\\"{x:697,y:635,t:1527873164270};\\\", \\\"{x:697,y:633,t:1527873164278};\\\", \\\"{x:696,y:632,t:1527873164290};\\\", \\\"{x:693,y:630,t:1527873164310};\\\", \\\"{x:692,y:630,t:1527873164502};\\\", \\\"{x:691,y:628,t:1527873164510};\\\", \\\"{x:689,y:620,t:1527873164521};\\\", \\\"{x:688,y:616,t:1527873164538};\\\", \\\"{x:686,y:612,t:1527873164556};\\\", \\\"{x:684,y:608,t:1527873164572};\\\", \\\"{x:683,y:605,t:1527873164588};\\\", \\\"{x:680,y:598,t:1527873164607};\\\", \\\"{x:680,y:595,t:1527873164621};\\\", \\\"{x:679,y:588,t:1527873164641};\\\", \\\"{x:674,y:576,t:1527873164657};\\\", \\\"{x:668,y:562,t:1527873164676};\\\", \\\"{x:663,y:548,t:1527873164691};\\\", \\\"{x:656,y:535,t:1527873164708};\\\", \\\"{x:649,y:524,t:1527873164725};\\\", \\\"{x:645,y:516,t:1527873164741};\\\", \\\"{x:639,y:504,t:1527873164758};\\\", \\\"{x:636,y:501,t:1527873164775};\\\", \\\"{x:635,y:499,t:1527873164791};\\\", \\\"{x:635,y:497,t:1527873164808};\\\", \\\"{x:635,y:496,t:1527873164825};\\\", \\\"{x:637,y:493,t:1527873164846};\\\", \\\"{x:641,y:492,t:1527873164858};\\\", \\\"{x:655,y:488,t:1527873164875};\\\", \\\"{x:672,y:484,t:1527873164892};\\\", \\\"{x:694,y:481,t:1527873164908};\\\", \\\"{x:722,y:481,t:1527873164924};\\\", \\\"{x:760,y:481,t:1527873164942};\\\", \\\"{x:773,y:483,t:1527873164957};\\\", \\\"{x:779,y:485,t:1527873164975};\\\", \\\"{x:782,y:487,t:1527873164992};\\\", \\\"{x:784,y:489,t:1527873165008};\\\", \\\"{x:786,y:492,t:1527873165024};\\\", \\\"{x:787,y:494,t:1527873165041};\\\", \\\"{x:788,y:494,t:1527873165058};\\\", \\\"{x:789,y:495,t:1527873165075};\\\", \\\"{x:790,y:496,t:1527873165094};\\\", \\\"{x:791,y:497,t:1527873165109};\\\", \\\"{x:792,y:497,t:1527873165126};\\\", \\\"{x:794,y:498,t:1527873165141};\\\", \\\"{x:795,y:500,t:1527873165159};\\\", \\\"{x:798,y:500,t:1527873165176};\\\", \\\"{x:801,y:502,t:1527873165191};\\\", \\\"{x:802,y:503,t:1527873165209};\\\", \\\"{x:804,y:503,t:1527873165230};\\\", \\\"{x:805,y:503,t:1527873165254};\\\", \\\"{x:807,y:503,t:1527873165262};\\\", \\\"{x:808,y:503,t:1527873165294};\\\", \\\"{x:810,y:503,t:1527873165326};\\\", \\\"{x:811,y:503,t:1527873165342};\\\", \\\"{x:813,y:503,t:1527873165359};\\\", \\\"{x:815,y:503,t:1527873165376};\\\", \\\"{x:817,y:503,t:1527873165392};\\\", \\\"{x:819,y:503,t:1527873165409};\\\", \\\"{x:820,y:503,t:1527873165426};\\\", \\\"{x:819,y:506,t:1527873166079};\\\", \\\"{x:811,y:512,t:1527873166094};\\\", \\\"{x:807,y:515,t:1527873166111};\\\", \\\"{x:803,y:517,t:1527873166128};\\\", \\\"{x:799,y:519,t:1527873166146};\\\", \\\"{x:796,y:522,t:1527873166161};\\\", \\\"{x:789,y:526,t:1527873166176};\\\", \\\"{x:783,y:527,t:1527873166192};\\\", \\\"{x:775,y:531,t:1527873166209};\\\", \\\"{x:770,y:533,t:1527873166225};\\\", \\\"{x:767,y:533,t:1527873166243};\\\", \\\"{x:774,y:529,t:1527873166350};\\\", \\\"{x:780,y:526,t:1527873166359};\\\", \\\"{x:792,y:519,t:1527873166376};\\\", \\\"{x:797,y:516,t:1527873166394};\\\", \\\"{x:800,y:515,t:1527873166409};\\\", \\\"{x:802,y:513,t:1527873166426};\\\", \\\"{x:803,y:513,t:1527873166443};\\\", \\\"{x:806,y:511,t:1527873166459};\\\", \\\"{x:810,y:509,t:1527873166476};\\\", \\\"{x:813,y:507,t:1527873166493};\\\", \\\"{x:814,y:505,t:1527873166509};\\\", \\\"{x:817,y:504,t:1527873166526};\\\", \\\"{x:818,y:503,t:1527873166544};\\\", \\\"{x:819,y:502,t:1527873166566};\\\", \\\"{x:820,y:502,t:1527873166662};\\\", \\\"{x:822,y:501,t:1527873166677};\\\", \\\"{x:824,y:500,t:1527873166693};\\\", \\\"{x:826,y:499,t:1527873166711};\\\", \\\"{x:827,y:499,t:1527873166759};\\\", \\\"{x:828,y:499,t:1527873166774};\\\", \\\"{x:829,y:499,t:1527873166782};\\\", \\\"{x:831,y:499,t:1527873166854};\\\", \\\"{x:832,y:499,t:1527873166885};\\\", \\\"{x:833,y:499,t:1527873166909};\\\", \\\"{x:834,y:500,t:1527873166949};\\\", \\\"{x:834,y:500,t:1527873166986};\\\", \\\"{x:833,y:501,t:1527873167166};\\\", \\\"{x:829,y:501,t:1527873167177};\\\", \\\"{x:814,y:504,t:1527873167193};\\\", \\\"{x:795,y:506,t:1527873167209};\\\", \\\"{x:766,y:511,t:1527873167227};\\\", \\\"{x:731,y:515,t:1527873167243};\\\", \\\"{x:697,y:521,t:1527873167261};\\\", \\\"{x:660,y:525,t:1527873167278};\\\", \\\"{x:627,y:529,t:1527873167294};\\\", \\\"{x:588,y:531,t:1527873167310};\\\", \\\"{x:570,y:534,t:1527873167327};\\\", \\\"{x:556,y:535,t:1527873167343};\\\", \\\"{x:542,y:537,t:1527873167360};\\\", \\\"{x:529,y:540,t:1527873167377};\\\", \\\"{x:515,y:542,t:1527873167393};\\\", \\\"{x:504,y:544,t:1527873167410};\\\", \\\"{x:495,y:544,t:1527873167429};\\\", \\\"{x:490,y:545,t:1527873167443};\\\", \\\"{x:485,y:546,t:1527873167460};\\\", \\\"{x:482,y:546,t:1527873167476};\\\", \\\"{x:476,y:549,t:1527873167493};\\\", \\\"{x:469,y:552,t:1527873167510};\\\", \\\"{x:458,y:557,t:1527873167527};\\\", \\\"{x:449,y:559,t:1527873167544};\\\", \\\"{x:433,y:567,t:1527873167560};\\\", \\\"{x:419,y:570,t:1527873167576};\\\", \\\"{x:405,y:575,t:1527873167594};\\\", \\\"{x:390,y:579,t:1527873167610};\\\", \\\"{x:376,y:585,t:1527873167627};\\\", \\\"{x:358,y:595,t:1527873167645};\\\", \\\"{x:340,y:599,t:1527873167659};\\\", \\\"{x:328,y:603,t:1527873167678};\\\", \\\"{x:309,y:608,t:1527873167694};\\\", \\\"{x:299,y:611,t:1527873167710};\\\", \\\"{x:289,y:613,t:1527873167727};\\\", \\\"{x:277,y:614,t:1527873167744};\\\", \\\"{x:269,y:615,t:1527873167761};\\\", \\\"{x:259,y:615,t:1527873167777};\\\", \\\"{x:255,y:615,t:1527873167794};\\\", \\\"{x:248,y:612,t:1527873167810};\\\", \\\"{x:237,y:603,t:1527873167826};\\\", \\\"{x:225,y:591,t:1527873167845};\\\", \\\"{x:215,y:581,t:1527873167860};\\\", \\\"{x:209,y:578,t:1527873167877};\\\", \\\"{x:207,y:575,t:1527873167894};\\\", \\\"{x:207,y:574,t:1527873167942};\\\", \\\"{x:206,y:573,t:1527873167958};\\\", \\\"{x:204,y:572,t:1527873167974};\\\", \\\"{x:204,y:571,t:1527873167982};\\\", \\\"{x:203,y:570,t:1527873167994};\\\", \\\"{x:200,y:567,t:1527873168011};\\\", \\\"{x:196,y:563,t:1527873168027};\\\", \\\"{x:193,y:560,t:1527873168045};\\\", \\\"{x:189,y:556,t:1527873168061};\\\", \\\"{x:186,y:552,t:1527873168078};\\\", \\\"{x:178,y:544,t:1527873168095};\\\", \\\"{x:173,y:540,t:1527873168110};\\\", \\\"{x:169,y:536,t:1527873168127};\\\", \\\"{x:168,y:535,t:1527873168143};\\\", \\\"{x:168,y:534,t:1527873168791};\\\", \\\"{x:183,y:526,t:1527873168799};\\\", \\\"{x:214,y:512,t:1527873168812};\\\", \\\"{x:266,y:494,t:1527873168828};\\\", \\\"{x:325,y:484,t:1527873168846};\\\", \\\"{x:377,y:478,t:1527873168861};\\\", \\\"{x:466,y:465,t:1527873168878};\\\", \\\"{x:532,y:456,t:1527873168895};\\\", \\\"{x:620,y:447,t:1527873168911};\\\", \\\"{x:714,y:435,t:1527873168929};\\\", \\\"{x:806,y:424,t:1527873168944};\\\", \\\"{x:903,y:412,t:1527873168961};\\\", \\\"{x:992,y:397,t:1527873168978};\\\", \\\"{x:1070,y:386,t:1527873168994};\\\", \\\"{x:1150,y:375,t:1527873169012};\\\", \\\"{x:1208,y:369,t:1527873169029};\\\", \\\"{x:1257,y:367,t:1527873169044};\\\", \\\"{x:1293,y:367,t:1527873169061};\\\", \\\"{x:1334,y:367,t:1527873169079};\\\", \\\"{x:1353,y:367,t:1527873169095};\\\", \\\"{x:1372,y:369,t:1527873169111};\\\", \\\"{x:1392,y:374,t:1527873169129};\\\", \\\"{x:1408,y:381,t:1527873169145};\\\", \\\"{x:1420,y:391,t:1527873169161};\\\", \\\"{x:1426,y:403,t:1527873169178};\\\", \\\"{x:1434,y:417,t:1527873169195};\\\", \\\"{x:1440,y:435,t:1527873169211};\\\", \\\"{x:1447,y:454,t:1527873169228};\\\", \\\"{x:1451,y:475,t:1527873169244};\\\", \\\"{x:1452,y:491,t:1527873169262};\\\", \\\"{x:1452,y:510,t:1527873169277};\\\", \\\"{x:1452,y:529,t:1527873169294};\\\", \\\"{x:1449,y:538,t:1527873169311};\\\", \\\"{x:1446,y:549,t:1527873169327};\\\", \\\"{x:1442,y:559,t:1527873169344};\\\", \\\"{x:1431,y:576,t:1527873169362};\\\", \\\"{x:1418,y:588,t:1527873169377};\\\", \\\"{x:1407,y:596,t:1527873169394};\\\", \\\"{x:1400,y:604,t:1527873169410};\\\", \\\"{x:1388,y:613,t:1527873169427};\\\", \\\"{x:1373,y:624,t:1527873169445};\\\", \\\"{x:1350,y:638,t:1527873169460};\\\", \\\"{x:1321,y:653,t:1527873169477};\\\", \\\"{x:1282,y:667,t:1527873169494};\\\", \\\"{x:1260,y:674,t:1527873169510};\\\", \\\"{x:1242,y:679,t:1527873169528};\\\", \\\"{x:1235,y:683,t:1527873169545};\\\", \\\"{x:1234,y:683,t:1527873169560};\\\", \\\"{x:1233,y:683,t:1527873169646};\\\", \\\"{x:1229,y:683,t:1527873169863};\\\", \\\"{x:1223,y:683,t:1527873169878};\\\", \\\"{x:1213,y:679,t:1527873169894};\\\", \\\"{x:1201,y:671,t:1527873169910};\\\", \\\"{x:1197,y:668,t:1527873169926};\\\", \\\"{x:1195,y:663,t:1527873169943};\\\", \\\"{x:1192,y:657,t:1527873169961};\\\", \\\"{x:1192,y:655,t:1527873169977};\\\", \\\"{x:1192,y:652,t:1527873169994};\\\", \\\"{x:1192,y:647,t:1527873170011};\\\", \\\"{x:1192,y:642,t:1527873170027};\\\", \\\"{x:1195,y:634,t:1527873170043};\\\", \\\"{x:1200,y:628,t:1527873170060};\\\", \\\"{x:1204,y:624,t:1527873170077};\\\", \\\"{x:1209,y:621,t:1527873170094};\\\", \\\"{x:1217,y:617,t:1527873170110};\\\", \\\"{x:1218,y:617,t:1527873170126};\\\", \\\"{x:1223,y:617,t:1527873170144};\\\", \\\"{x:1231,y:616,t:1527873170160};\\\", \\\"{x:1248,y:616,t:1527873170177};\\\", \\\"{x:1271,y:616,t:1527873170193};\\\", \\\"{x:1307,y:620,t:1527873170212};\\\", \\\"{x:1337,y:625,t:1527873170226};\\\", \\\"{x:1359,y:627,t:1527873170243};\\\", \\\"{x:1372,y:629,t:1527873170259};\\\", \\\"{x:1378,y:631,t:1527873170276};\\\", \\\"{x:1381,y:631,t:1527873170293};\\\", \\\"{x:1382,y:631,t:1527873170309};\\\", \\\"{x:1383,y:631,t:1527873170341};\\\", \\\"{x:1384,y:633,t:1527873170357};\\\", \\\"{x:1385,y:634,t:1527873170365};\\\", \\\"{x:1385,y:636,t:1527873170375};\\\", \\\"{x:1386,y:640,t:1527873170393};\\\", \\\"{x:1386,y:647,t:1527873170409};\\\", \\\"{x:1386,y:653,t:1527873170426};\\\", \\\"{x:1386,y:661,t:1527873170442};\\\", \\\"{x:1386,y:667,t:1527873170459};\\\", \\\"{x:1385,y:673,t:1527873170476};\\\", \\\"{x:1383,y:678,t:1527873170492};\\\", \\\"{x:1381,y:682,t:1527873170509};\\\", \\\"{x:1380,y:685,t:1527873170526};\\\", \\\"{x:1380,y:687,t:1527873170542};\\\", \\\"{x:1380,y:689,t:1527873170559};\\\", \\\"{x:1379,y:689,t:1527873170576};\\\", \\\"{x:1379,y:691,t:1527873170592};\\\", \\\"{x:1379,y:693,t:1527873170609};\\\", \\\"{x:1377,y:695,t:1527873170626};\\\", \\\"{x:1377,y:696,t:1527873170643};\\\", \\\"{x:1375,y:699,t:1527873170660};\\\", \\\"{x:1373,y:702,t:1527873170676};\\\", \\\"{x:1372,y:704,t:1527873170692};\\\", \\\"{x:1368,y:709,t:1527873170710};\\\", \\\"{x:1366,y:712,t:1527873170726};\\\", \\\"{x:1363,y:716,t:1527873170743};\\\", \\\"{x:1362,y:716,t:1527873170759};\\\", \\\"{x:1362,y:717,t:1527873170799};\\\", \\\"{x:1361,y:717,t:1527873170855};\\\", \\\"{x:1361,y:720,t:1527873170862};\\\", \\\"{x:1361,y:722,t:1527873170876};\\\", \\\"{x:1361,y:727,t:1527873170893};\\\", \\\"{x:1360,y:732,t:1527873170909};\\\", \\\"{x:1360,y:737,t:1527873170926};\\\", \\\"{x:1360,y:742,t:1527873170942};\\\", \\\"{x:1360,y:747,t:1527873170959};\\\", \\\"{x:1360,y:749,t:1527873170976};\\\", \\\"{x:1360,y:751,t:1527873170993};\\\", \\\"{x:1360,y:754,t:1527873171008};\\\", \\\"{x:1360,y:755,t:1527873171025};\\\", \\\"{x:1363,y:759,t:1527873171043};\\\", \\\"{x:1366,y:761,t:1527873171058};\\\", \\\"{x:1367,y:762,t:1527873171076};\\\", \\\"{x:1368,y:759,t:1527873174094};\\\", \\\"{x:1373,y:751,t:1527873174104};\\\", \\\"{x:1378,y:744,t:1527873174122};\\\", \\\"{x:1379,y:742,t:1527873174137};\\\", \\\"{x:1379,y:741,t:1527873174154};\\\", \\\"{x:1380,y:739,t:1527873174190};\\\", \\\"{x:1381,y:739,t:1527873174206};\\\", \\\"{x:1383,y:737,t:1527873174222};\\\", \\\"{x:1387,y:734,t:1527873174237};\\\", \\\"{x:1409,y:722,t:1527873174254};\\\", \\\"{x:1434,y:709,t:1527873174271};\\\", \\\"{x:1460,y:693,t:1527873174288};\\\", \\\"{x:1481,y:681,t:1527873174304};\\\", \\\"{x:1497,y:670,t:1527873174321};\\\", \\\"{x:1504,y:665,t:1527873174337};\\\", \\\"{x:1509,y:662,t:1527873174354};\\\", \\\"{x:1510,y:662,t:1527873174371};\\\", \\\"{x:1512,y:662,t:1527873174446};\\\", \\\"{x:1519,y:665,t:1527873174454};\\\", \\\"{x:1537,y:675,t:1527873174470};\\\", \\\"{x:1557,y:684,t:1527873174487};\\\", \\\"{x:1576,y:687,t:1527873174505};\\\", \\\"{x:1593,y:692,t:1527873174520};\\\", \\\"{x:1608,y:694,t:1527873174537};\\\", \\\"{x:1622,y:695,t:1527873174554};\\\", \\\"{x:1634,y:695,t:1527873174570};\\\", \\\"{x:1643,y:695,t:1527873174587};\\\", \\\"{x:1649,y:695,t:1527873174603};\\\", \\\"{x:1651,y:694,t:1527873174621};\\\", \\\"{x:1654,y:691,t:1527873174637};\\\", \\\"{x:1658,y:687,t:1527873174653};\\\", \\\"{x:1660,y:682,t:1527873174669};\\\", \\\"{x:1661,y:676,t:1527873174686};\\\", \\\"{x:1662,y:667,t:1527873174702};\\\", \\\"{x:1662,y:660,t:1527873174719};\\\", \\\"{x:1662,y:656,t:1527873174736};\\\", \\\"{x:1662,y:652,t:1527873174753};\\\", \\\"{x:1662,y:648,t:1527873174770};\\\", \\\"{x:1661,y:645,t:1527873174787};\\\", \\\"{x:1658,y:641,t:1527873174802};\\\", \\\"{x:1656,y:638,t:1527873174820};\\\", \\\"{x:1654,y:635,t:1527873174837};\\\", \\\"{x:1653,y:634,t:1527873174852};\\\", \\\"{x:1648,y:628,t:1527873174869};\\\", \\\"{x:1646,y:626,t:1527873174886};\\\", \\\"{x:1645,y:625,t:1527873174902};\\\", \\\"{x:1644,y:625,t:1527873174920};\\\", \\\"{x:1642,y:625,t:1527873175061};\\\", \\\"{x:1639,y:625,t:1527873175069};\\\", \\\"{x:1631,y:625,t:1527873175085};\\\", \\\"{x:1622,y:627,t:1527873175103};\\\", \\\"{x:1614,y:630,t:1527873175119};\\\", \\\"{x:1608,y:633,t:1527873175135};\\\", \\\"{x:1604,y:635,t:1527873175151};\\\", \\\"{x:1603,y:636,t:1527873175168};\\\", \\\"{x:1602,y:637,t:1527873175185};\\\", \\\"{x:1599,y:637,t:1527873175202};\\\", \\\"{x:1596,y:639,t:1527873175218};\\\", \\\"{x:1594,y:641,t:1527873175235};\\\", \\\"{x:1591,y:643,t:1527873175252};\\\", \\\"{x:1589,y:647,t:1527873175268};\\\", \\\"{x:1589,y:649,t:1527873175285};\\\", \\\"{x:1589,y:650,t:1527873175302};\\\", \\\"{x:1589,y:652,t:1527873175318};\\\", \\\"{x:1589,y:653,t:1527873175335};\\\", \\\"{x:1588,y:653,t:1527873175525};\\\", \\\"{x:1587,y:652,t:1527873175573};\\\", \\\"{x:1587,y:657,t:1527873175637};\\\", \\\"{x:1592,y:673,t:1527873175651};\\\", \\\"{x:1610,y:735,t:1527873175669};\\\", \\\"{x:1620,y:771,t:1527873175685};\\\", \\\"{x:1626,y:798,t:1527873175701};\\\", \\\"{x:1631,y:818,t:1527873175718};\\\", \\\"{x:1635,y:829,t:1527873175733};\\\", \\\"{x:1640,y:839,t:1527873175751};\\\", \\\"{x:1641,y:842,t:1527873175768};\\\", \\\"{x:1642,y:841,t:1527873175844};\\\", \\\"{x:1643,y:826,t:1527873175852};\\\", \\\"{x:1646,y:802,t:1527873175867};\\\", \\\"{x:1646,y:743,t:1527873175884};\\\", \\\"{x:1643,y:716,t:1527873175901};\\\", \\\"{x:1638,y:695,t:1527873175917};\\\", \\\"{x:1636,y:681,t:1527873175934};\\\", \\\"{x:1636,y:675,t:1527873175951};\\\", \\\"{x:1633,y:672,t:1527873175967};\\\", \\\"{x:1633,y:671,t:1527873175984};\\\", \\\"{x:1632,y:671,t:1527873176101};\\\", \\\"{x:1628,y:683,t:1527873176117};\\\", \\\"{x:1624,y:698,t:1527873176134};\\\", \\\"{x:1622,y:712,t:1527873176150};\\\", \\\"{x:1618,y:727,t:1527873176168};\\\", \\\"{x:1617,y:737,t:1527873176184};\\\", \\\"{x:1616,y:741,t:1527873176200};\\\", \\\"{x:1616,y:744,t:1527873176218};\\\", \\\"{x:1615,y:745,t:1527873176234};\\\", \\\"{x:1615,y:741,t:1527873176405};\\\", \\\"{x:1614,y:737,t:1527873176418};\\\", \\\"{x:1613,y:724,t:1527873176433};\\\", \\\"{x:1610,y:712,t:1527873176450};\\\", \\\"{x:1609,y:704,t:1527873176467};\\\", \\\"{x:1609,y:699,t:1527873176482};\\\", \\\"{x:1607,y:692,t:1527873176500};\\\", \\\"{x:1606,y:691,t:1527873176516};\\\", \\\"{x:1606,y:690,t:1527873176533};\\\", \\\"{x:1606,y:693,t:1527873176707};\\\", \\\"{x:1608,y:706,t:1527873176716};\\\", \\\"{x:1614,y:732,t:1527873176733};\\\", \\\"{x:1616,y:749,t:1527873176750};\\\", \\\"{x:1619,y:768,t:1527873176766};\\\", \\\"{x:1621,y:780,t:1527873176783};\\\", \\\"{x:1621,y:787,t:1527873176800};\\\", \\\"{x:1621,y:793,t:1527873176815};\\\", \\\"{x:1621,y:801,t:1527873176833};\\\", \\\"{x:1621,y:814,t:1527873176850};\\\", \\\"{x:1626,y:833,t:1527873176865};\\\", \\\"{x:1630,y:849,t:1527873176883};\\\", \\\"{x:1640,y:875,t:1527873176899};\\\", \\\"{x:1646,y:888,t:1527873176916};\\\", \\\"{x:1652,y:903,t:1527873176932};\\\", \\\"{x:1657,y:917,t:1527873176949};\\\", \\\"{x:1664,y:932,t:1527873176965};\\\", \\\"{x:1668,y:942,t:1527873176982};\\\", \\\"{x:1671,y:949,t:1527873176999};\\\", \\\"{x:1673,y:956,t:1527873177016};\\\", \\\"{x:1676,y:964,t:1527873177033};\\\", \\\"{x:1679,y:971,t:1527873177048};\\\", \\\"{x:1681,y:978,t:1527873177066};\\\", \\\"{x:1683,y:981,t:1527873177083};\\\", \\\"{x:1683,y:983,t:1527873177099};\\\", \\\"{x:1685,y:976,t:1527873177205};\\\", \\\"{x:1687,y:959,t:1527873177216};\\\", \\\"{x:1693,y:934,t:1527873177232};\\\", \\\"{x:1695,y:916,t:1527873177249};\\\", \\\"{x:1698,y:901,t:1527873177265};\\\", \\\"{x:1703,y:892,t:1527873177282};\\\", \\\"{x:1705,y:885,t:1527873177299};\\\", \\\"{x:1705,y:877,t:1527873177316};\\\", \\\"{x:1705,y:873,t:1527873177332};\\\", \\\"{x:1704,y:866,t:1527873177349};\\\", \\\"{x:1699,y:854,t:1527873177366};\\\", \\\"{x:1692,y:842,t:1527873177382};\\\", \\\"{x:1687,y:835,t:1527873177399};\\\", \\\"{x:1686,y:832,t:1527873177415};\\\", \\\"{x:1688,y:829,t:1527873177606};\\\", \\\"{x:1694,y:827,t:1527873177615};\\\", \\\"{x:1707,y:826,t:1527873177633};\\\", \\\"{x:1718,y:826,t:1527873177648};\\\", \\\"{x:1729,y:826,t:1527873177665};\\\", \\\"{x:1738,y:826,t:1527873177682};\\\", \\\"{x:1743,y:826,t:1527873177699};\\\", \\\"{x:1747,y:826,t:1527873177715};\\\", \\\"{x:1741,y:822,t:1527873177798};\\\", \\\"{x:1679,y:801,t:1527873177816};\\\", \\\"{x:1569,y:770,t:1527873177832};\\\", \\\"{x:1468,y:748,t:1527873177848};\\\", \\\"{x:1346,y:734,t:1527873177865};\\\", \\\"{x:1219,y:715,t:1527873177881};\\\", \\\"{x:1055,y:690,t:1527873177898};\\\", \\\"{x:881,y:664,t:1527873177915};\\\", \\\"{x:719,y:644,t:1527873177932};\\\", \\\"{x:674,y:642,t:1527873177947};\\\", \\\"{x:661,y:642,t:1527873177965};\\\", \\\"{x:660,y:642,t:1527873178028};\\\", \\\"{x:660,y:647,t:1527873178036};\\\", \\\"{x:660,y:661,t:1527873178047};\\\", \\\"{x:660,y:686,t:1527873178064};\\\", \\\"{x:662,y:706,t:1527873178080};\\\", \\\"{x:663,y:721,t:1527873178097};\\\", \\\"{x:663,y:732,t:1527873178115};\\\", \\\"{x:663,y:743,t:1527873178130};\\\", \\\"{x:660,y:761,t:1527873178147};\\\", \\\"{x:657,y:775,t:1527873178164};\\\", \\\"{x:655,y:788,t:1527873178180};\\\", \\\"{x:653,y:798,t:1527873178198};\\\", \\\"{x:650,y:802,t:1527873178214};\\\", \\\"{x:648,y:803,t:1527873178230};\\\", \\\"{x:638,y:803,t:1527873178248};\\\", \\\"{x:622,y:802,t:1527873178264};\\\", \\\"{x:576,y:777,t:1527873178281};\\\", \\\"{x:510,y:747,t:1527873178298};\\\", \\\"{x:476,y:729,t:1527873178314};\\\", \\\"{x:469,y:724,t:1527873178331};\\\", \\\"{x:465,y:721,t:1527873178350};\\\", \\\"{x:461,y:719,t:1527873178367};\\\", \\\"{x:459,y:718,t:1527873178383};\\\", \\\"{x:461,y:719,t:1527873178547};\\\", \\\"{x:461,y:720,t:1527873178556};\\\", \\\"{x:463,y:722,t:1527873178568};\\\", \\\"{x:466,y:724,t:1527873178584};\\\", \\\"{x:467,y:725,t:1527873178601};\\\", \\\"{x:469,y:725,t:1527873178618};\\\", \\\"{x:470,y:726,t:1527873178635};\\\", \\\"{x:472,y:727,t:1527873178651};\\\", \\\"{x:473,y:728,t:1527873178668};\\\", \\\"{x:476,y:728,t:1527873178685};\\\", \\\"{x:480,y:730,t:1527873178700};\\\", \\\"{x:482,y:731,t:1527873178718};\\\", \\\"{x:484,y:732,t:1527873178735};\\\", \\\"{x:485,y:732,t:1527873178756};\\\", \\\"{x:486,y:732,t:1527873178771};\\\" ] }, { \\\"rt\\\": 101506, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 467993, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-X -X -X -B -B -X -X -B -12 PM-12 PM-01 PM-02 PM-F -F -E -J -M -M -F -F -E -E -E -E -11 AM-12 PM-12 PM-01 PM-02 PM-B -F -F -F -5-B -I -I -I -I -I -10 AM-11 AM-11 AM-12 PM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:726,t:1527873182364};\\\", \\\"{x:477,y:713,t:1527873182372};\\\", \\\"{x:471,y:703,t:1527873182386};\\\", \\\"{x:459,y:678,t:1527873182404};\\\", \\\"{x:451,y:661,t:1527873182421};\\\", \\\"{x:443,y:642,t:1527873182436};\\\", \\\"{x:439,y:630,t:1527873182455};\\\", \\\"{x:434,y:618,t:1527873182471};\\\", \\\"{x:429,y:606,t:1527873182487};\\\", \\\"{x:426,y:601,t:1527873182503};\\\", \\\"{x:424,y:597,t:1527873182521};\\\", \\\"{x:423,y:595,t:1527873182537};\\\", \\\"{x:420,y:592,t:1527873182554};\\\", \\\"{x:417,y:588,t:1527873182571};\\\", \\\"{x:415,y:584,t:1527873182587};\\\", \\\"{x:410,y:579,t:1527873182604};\\\", \\\"{x:405,y:572,t:1527873182621};\\\", \\\"{x:401,y:568,t:1527873182638};\\\", \\\"{x:398,y:564,t:1527873182654};\\\", \\\"{x:394,y:560,t:1527873182671};\\\", \\\"{x:386,y:555,t:1527873182688};\\\", \\\"{x:374,y:549,t:1527873182704};\\\", \\\"{x:354,y:542,t:1527873182721};\\\", \\\"{x:339,y:540,t:1527873182738};\\\", \\\"{x:319,y:537,t:1527873182754};\\\", \\\"{x:297,y:537,t:1527873182771};\\\", \\\"{x:282,y:537,t:1527873182787};\\\", \\\"{x:278,y:537,t:1527873182804};\\\", \\\"{x:275,y:537,t:1527873182821};\\\", \\\"{x:272,y:537,t:1527873182839};\\\", \\\"{x:271,y:537,t:1527873182854};\\\", \\\"{x:270,y:537,t:1527873182871};\\\", \\\"{x:269,y:537,t:1527873182892};\\\", \\\"{x:268,y:536,t:1527873183069};\\\", \\\"{x:268,y:534,t:1527873183077};\\\", \\\"{x:276,y:525,t:1527873183089};\\\", \\\"{x:308,y:496,t:1527873183106};\\\", \\\"{x:354,y:466,t:1527873183122};\\\", \\\"{x:389,y:447,t:1527873183138};\\\", \\\"{x:408,y:435,t:1527873183155};\\\", \\\"{x:419,y:430,t:1527873183171};\\\", \\\"{x:423,y:426,t:1527873183187};\\\", \\\"{x:425,y:426,t:1527873183580};\\\", \\\"{x:432,y:423,t:1527873183587};\\\", \\\"{x:450,y:417,t:1527873183605};\\\", \\\"{x:457,y:415,t:1527873183621};\\\", \\\"{x:464,y:413,t:1527873183638};\\\", \\\"{x:473,y:411,t:1527873183655};\\\", \\\"{x:477,y:409,t:1527873183671};\\\", \\\"{x:481,y:409,t:1527873183688};\\\", \\\"{x:485,y:409,t:1527873183705};\\\", \\\"{x:487,y:409,t:1527873183721};\\\", \\\"{x:490,y:409,t:1527873183738};\\\", \\\"{x:495,y:409,t:1527873183756};\\\", \\\"{x:498,y:409,t:1527873183772};\\\", \\\"{x:506,y:409,t:1527873183788};\\\", \\\"{x:515,y:410,t:1527873183806};\\\", \\\"{x:530,y:413,t:1527873183821};\\\", \\\"{x:544,y:415,t:1527873183838};\\\", \\\"{x:556,y:416,t:1527873183855};\\\", \\\"{x:569,y:419,t:1527873183871};\\\", \\\"{x:583,y:421,t:1527873183888};\\\", \\\"{x:591,y:421,t:1527873183905};\\\", \\\"{x:597,y:421,t:1527873183922};\\\", \\\"{x:611,y:423,t:1527873183938};\\\", \\\"{x:626,y:423,t:1527873183955};\\\", \\\"{x:643,y:423,t:1527873183972};\\\", \\\"{x:649,y:423,t:1527873183989};\\\", \\\"{x:655,y:423,t:1527873184005};\\\", \\\"{x:663,y:424,t:1527873184022};\\\", \\\"{x:671,y:425,t:1527873184038};\\\", \\\"{x:676,y:425,t:1527873184055};\\\", \\\"{x:680,y:427,t:1527873184073};\\\", \\\"{x:686,y:428,t:1527873184089};\\\", \\\"{x:692,y:428,t:1527873184105};\\\", \\\"{x:700,y:428,t:1527873184123};\\\", \\\"{x:707,y:428,t:1527873184138};\\\", \\\"{x:720,y:432,t:1527873184156};\\\", \\\"{x:746,y:434,t:1527873184172};\\\", \\\"{x:770,y:437,t:1527873184189};\\\", \\\"{x:788,y:439,t:1527873184205};\\\", \\\"{x:804,y:439,t:1527873184223};\\\", \\\"{x:822,y:440,t:1527873184239};\\\", \\\"{x:844,y:440,t:1527873184256};\\\", \\\"{x:869,y:442,t:1527873184273};\\\", \\\"{x:889,y:444,t:1527873184289};\\\", \\\"{x:910,y:444,t:1527873184306};\\\", \\\"{x:926,y:444,t:1527873184322};\\\", \\\"{x:941,y:444,t:1527873184339};\\\", \\\"{x:955,y:444,t:1527873184356};\\\", \\\"{x:977,y:444,t:1527873184373};\\\", \\\"{x:991,y:444,t:1527873184389};\\\", \\\"{x:1001,y:444,t:1527873184405};\\\", \\\"{x:1005,y:444,t:1527873184423};\\\", \\\"{x:1006,y:444,t:1527873184438};\\\", \\\"{x:1007,y:444,t:1527873184456};\\\", \\\"{x:1008,y:444,t:1527873184550};\\\", \\\"{x:1017,y:444,t:1527873184557};\\\", \\\"{x:1047,y:442,t:1527873184572};\\\", \\\"{x:1098,y:439,t:1527873184589};\\\", \\\"{x:1162,y:433,t:1527873184606};\\\", \\\"{x:1210,y:431,t:1527873184622};\\\", \\\"{x:1249,y:427,t:1527873184640};\\\", \\\"{x:1275,y:425,t:1527873184656};\\\", \\\"{x:1293,y:424,t:1527873184673};\\\", \\\"{x:1300,y:424,t:1527873184690};\\\", \\\"{x:1301,y:424,t:1527873184706};\\\", \\\"{x:1297,y:426,t:1527873184820};\\\", \\\"{x:1283,y:429,t:1527873184828};\\\", \\\"{x:1271,y:433,t:1527873184839};\\\", \\\"{x:1241,y:441,t:1527873184855};\\\", \\\"{x:1215,y:449,t:1527873184872};\\\", \\\"{x:1193,y:457,t:1527873184889};\\\", \\\"{x:1171,y:462,t:1527873184905};\\\", \\\"{x:1148,y:469,t:1527873184923};\\\", \\\"{x:1130,y:475,t:1527873184940};\\\", \\\"{x:1115,y:479,t:1527873184956};\\\", \\\"{x:1102,y:480,t:1527873184972};\\\", \\\"{x:1098,y:481,t:1527873184989};\\\", \\\"{x:1090,y:483,t:1527873185006};\\\", \\\"{x:1084,y:484,t:1527873185023};\\\", \\\"{x:1078,y:487,t:1527873185040};\\\", \\\"{x:1075,y:488,t:1527873185056};\\\", \\\"{x:1072,y:490,t:1527873185072};\\\", \\\"{x:1069,y:493,t:1527873185090};\\\", \\\"{x:1067,y:494,t:1527873185105};\\\", \\\"{x:1064,y:495,t:1527873185122};\\\", \\\"{x:1063,y:496,t:1527873185147};\\\", \\\"{x:1062,y:496,t:1527873185188};\\\", \\\"{x:1061,y:497,t:1527873185196};\\\", \\\"{x:1061,y:498,t:1527873185212};\\\", \\\"{x:1060,y:499,t:1527873185228};\\\", \\\"{x:1060,y:500,t:1527873185244};\\\", \\\"{x:1059,y:505,t:1527873192134};\\\", \\\"{x:1081,y:517,t:1527873192143};\\\", \\\"{x:1136,y:539,t:1527873192161};\\\", \\\"{x:1173,y:553,t:1527873192176};\\\", \\\"{x:1219,y:569,t:1527873192193};\\\", \\\"{x:1258,y:579,t:1527873192210};\\\", \\\"{x:1285,y:587,t:1527873192226};\\\", \\\"{x:1306,y:594,t:1527873192243};\\\", \\\"{x:1319,y:598,t:1527873192260};\\\", \\\"{x:1326,y:602,t:1527873192276};\\\", \\\"{x:1334,y:611,t:1527873192293};\\\", \\\"{x:1339,y:619,t:1527873192310};\\\", \\\"{x:1344,y:627,t:1527873192326};\\\", \\\"{x:1349,y:634,t:1527873192343};\\\", \\\"{x:1352,y:642,t:1527873192360};\\\", \\\"{x:1354,y:649,t:1527873192376};\\\", \\\"{x:1356,y:657,t:1527873192393};\\\", \\\"{x:1360,y:670,t:1527873192410};\\\", \\\"{x:1362,y:681,t:1527873192426};\\\", \\\"{x:1366,y:695,t:1527873192443};\\\", \\\"{x:1368,y:703,t:1527873192460};\\\", \\\"{x:1371,y:710,t:1527873192476};\\\", \\\"{x:1371,y:712,t:1527873192492};\\\", \\\"{x:1372,y:717,t:1527873192510};\\\", \\\"{x:1374,y:723,t:1527873192527};\\\", \\\"{x:1379,y:734,t:1527873192543};\\\", \\\"{x:1381,y:739,t:1527873192560};\\\", \\\"{x:1383,y:745,t:1527873192577};\\\", \\\"{x:1383,y:748,t:1527873192593};\\\", \\\"{x:1383,y:751,t:1527873192610};\\\", \\\"{x:1383,y:753,t:1527873192628};\\\", \\\"{x:1383,y:754,t:1527873192644};\\\", \\\"{x:1383,y:755,t:1527873192660};\\\", \\\"{x:1381,y:755,t:1527873192676};\\\", \\\"{x:1379,y:756,t:1527873192693};\\\", \\\"{x:1379,y:757,t:1527873192717};\\\", \\\"{x:1378,y:757,t:1527873192757};\\\", \\\"{x:1377,y:757,t:1527873192773};\\\", \\\"{x:1375,y:757,t:1527873192781};\\\", \\\"{x:1374,y:757,t:1527873192797};\\\", \\\"{x:1372,y:757,t:1527873192810};\\\", \\\"{x:1370,y:757,t:1527873192827};\\\", \\\"{x:1367,y:757,t:1527873192843};\\\", \\\"{x:1363,y:758,t:1527873192861};\\\", \\\"{x:1360,y:760,t:1527873192877};\\\", \\\"{x:1359,y:761,t:1527873192893};\\\", \\\"{x:1357,y:762,t:1527873192910};\\\", \\\"{x:1356,y:762,t:1527873192927};\\\", \\\"{x:1355,y:763,t:1527873192943};\\\", \\\"{x:1356,y:763,t:1527873193493};\\\", \\\"{x:1362,y:763,t:1527873193510};\\\", \\\"{x:1371,y:763,t:1527873193527};\\\", \\\"{x:1381,y:766,t:1527873193545};\\\", \\\"{x:1394,y:769,t:1527873193560};\\\", \\\"{x:1405,y:773,t:1527873193577};\\\", \\\"{x:1415,y:776,t:1527873193594};\\\", \\\"{x:1419,y:778,t:1527873193610};\\\", \\\"{x:1424,y:779,t:1527873193627};\\\", \\\"{x:1430,y:782,t:1527873193645};\\\", \\\"{x:1434,y:785,t:1527873193661};\\\", \\\"{x:1437,y:786,t:1527873193677};\\\", \\\"{x:1443,y:789,t:1527873193694};\\\", \\\"{x:1446,y:791,t:1527873193710};\\\", \\\"{x:1449,y:794,t:1527873193727};\\\", \\\"{x:1453,y:797,t:1527873193744};\\\", \\\"{x:1458,y:801,t:1527873193760};\\\", \\\"{x:1463,y:805,t:1527873193777};\\\", \\\"{x:1466,y:809,t:1527873193794};\\\", \\\"{x:1466,y:810,t:1527873193810};\\\", \\\"{x:1468,y:812,t:1527873193949};\\\", \\\"{x:1469,y:812,t:1527873193960};\\\", \\\"{x:1471,y:815,t:1527873193977};\\\", \\\"{x:1474,y:817,t:1527873193994};\\\", \\\"{x:1476,y:818,t:1527873194011};\\\", \\\"{x:1477,y:819,t:1527873194027};\\\", \\\"{x:1478,y:819,t:1527873194043};\\\", \\\"{x:1480,y:821,t:1527873194061};\\\", \\\"{x:1482,y:822,t:1527873194077};\\\", \\\"{x:1484,y:823,t:1527873194094};\\\", \\\"{x:1485,y:824,t:1527873194112};\\\", \\\"{x:1486,y:824,t:1527873194127};\\\", \\\"{x:1486,y:825,t:1527873194144};\\\", \\\"{x:1484,y:825,t:1527873194464};\\\", \\\"{x:1481,y:820,t:1527873194477};\\\", \\\"{x:1477,y:812,t:1527873194493};\\\", \\\"{x:1472,y:803,t:1527873194510};\\\", \\\"{x:1466,y:796,t:1527873194527};\\\", \\\"{x:1455,y:788,t:1527873194543};\\\", \\\"{x:1445,y:784,t:1527873194560};\\\", \\\"{x:1437,y:782,t:1527873194577};\\\", \\\"{x:1428,y:778,t:1527873194593};\\\", \\\"{x:1412,y:774,t:1527873194611};\\\", \\\"{x:1383,y:766,t:1527873194628};\\\", \\\"{x:1368,y:761,t:1527873194644};\\\", \\\"{x:1361,y:761,t:1527873194661};\\\", \\\"{x:1352,y:758,t:1527873194678};\\\", \\\"{x:1341,y:756,t:1527873194694};\\\", \\\"{x:1330,y:753,t:1527873194711};\\\", \\\"{x:1325,y:752,t:1527873194727};\\\", \\\"{x:1323,y:751,t:1527873194744};\\\", \\\"{x:1322,y:751,t:1527873195013};\\\", \\\"{x:1322,y:752,t:1527873195029};\\\", \\\"{x:1324,y:754,t:1527873195045};\\\", \\\"{x:1325,y:755,t:1527873195061};\\\", \\\"{x:1327,y:757,t:1527873195078};\\\", \\\"{x:1328,y:758,t:1527873195100};\\\", \\\"{x:1328,y:759,t:1527873195116};\\\", \\\"{x:1329,y:760,t:1527873195128};\\\", \\\"{x:1332,y:761,t:1527873195144};\\\", \\\"{x:1335,y:763,t:1527873195161};\\\", \\\"{x:1337,y:764,t:1527873195178};\\\", \\\"{x:1339,y:765,t:1527873195194};\\\", \\\"{x:1340,y:765,t:1527873195211};\\\", \\\"{x:1342,y:766,t:1527873195228};\\\", \\\"{x:1344,y:766,t:1527873195244};\\\", \\\"{x:1345,y:766,t:1527873195260};\\\", \\\"{x:1348,y:767,t:1527873196124};\\\", \\\"{x:1349,y:769,t:1527873196133};\\\", \\\"{x:1350,y:769,t:1527873196145};\\\", \\\"{x:1353,y:770,t:1527873196162};\\\", \\\"{x:1354,y:770,t:1527873196178};\\\", \\\"{x:1356,y:771,t:1527873196213};\\\", \\\"{x:1357,y:772,t:1527873196237};\\\", \\\"{x:1358,y:773,t:1527873196260};\\\", \\\"{x:1359,y:773,t:1527873196268};\\\", \\\"{x:1360,y:773,t:1527873196285};\\\", \\\"{x:1359,y:775,t:1527873196484};\\\", \\\"{x:1358,y:775,t:1527873196515};\\\", \\\"{x:1357,y:775,t:1527873196531};\\\", \\\"{x:1356,y:775,t:1527873196548};\\\", \\\"{x:1355,y:775,t:1527873196621};\\\", \\\"{x:1353,y:775,t:1527873196901};\\\", \\\"{x:1351,y:775,t:1527873196933};\\\", \\\"{x:1350,y:775,t:1527873199045};\\\", \\\"{x:1350,y:773,t:1527873199093};\\\", \\\"{x:1350,y:772,t:1527873199108};\\\", \\\"{x:1350,y:771,t:1527873199132};\\\", \\\"{x:1350,y:770,t:1527873199379};\\\", \\\"{x:1350,y:768,t:1527873199395};\\\", \\\"{x:1350,y:767,t:1527873199412};\\\", \\\"{x:1350,y:766,t:1527873199430};\\\", \\\"{x:1350,y:765,t:1527873199445};\\\", \\\"{x:1350,y:764,t:1527873199462};\\\", \\\"{x:1349,y:763,t:1527873206365};\\\", \\\"{x:1348,y:763,t:1527873206388};\\\", \\\"{x:1352,y:764,t:1527873211635};\\\", \\\"{x:1362,y:767,t:1527873211652};\\\", \\\"{x:1377,y:772,t:1527873211670};\\\", \\\"{x:1391,y:778,t:1527873211686};\\\", \\\"{x:1402,y:785,t:1527873211703};\\\", \\\"{x:1413,y:790,t:1527873211719};\\\", \\\"{x:1420,y:795,t:1527873211737};\\\", \\\"{x:1427,y:799,t:1527873211753};\\\", \\\"{x:1439,y:807,t:1527873211770};\\\", \\\"{x:1455,y:815,t:1527873211787};\\\", \\\"{x:1466,y:823,t:1527873211803};\\\", \\\"{x:1479,y:831,t:1527873211821};\\\", \\\"{x:1483,y:833,t:1527873211835};\\\", \\\"{x:1486,y:835,t:1527873211854};\\\", \\\"{x:1487,y:836,t:1527873211869};\\\", \\\"{x:1489,y:838,t:1527873211886};\\\", \\\"{x:1490,y:839,t:1527873211903};\\\", \\\"{x:1492,y:841,t:1527873211920};\\\", \\\"{x:1494,y:846,t:1527873211936};\\\", \\\"{x:1496,y:849,t:1527873211953};\\\", \\\"{x:1497,y:852,t:1527873211969};\\\", \\\"{x:1498,y:853,t:1527873211987};\\\", \\\"{x:1497,y:853,t:1527873212132};\\\", \\\"{x:1496,y:853,t:1527873212140};\\\", \\\"{x:1495,y:851,t:1527873212153};\\\", \\\"{x:1491,y:847,t:1527873212170};\\\", \\\"{x:1488,y:843,t:1527873212187};\\\", \\\"{x:1485,y:839,t:1527873212203};\\\", \\\"{x:1483,y:834,t:1527873212221};\\\", \\\"{x:1482,y:832,t:1527873212508};\\\", \\\"{x:1481,y:832,t:1527873212519};\\\", \\\"{x:1479,y:832,t:1527873212536};\\\", \\\"{x:1477,y:830,t:1527873212553};\\\", \\\"{x:1476,y:830,t:1527873217492};\\\", \\\"{x:1476,y:827,t:1527873217596};\\\", \\\"{x:1470,y:814,t:1527873217607};\\\", \\\"{x:1437,y:796,t:1527873217623};\\\", \\\"{x:1411,y:784,t:1527873217638};\\\", \\\"{x:1395,y:779,t:1527873217656};\\\", \\\"{x:1386,y:777,t:1527873217673};\\\", \\\"{x:1379,y:775,t:1527873217688};\\\", \\\"{x:1374,y:774,t:1527873217706};\\\", \\\"{x:1370,y:773,t:1527873217723};\\\", \\\"{x:1367,y:771,t:1527873217739};\\\", \\\"{x:1364,y:770,t:1527873217756};\\\", \\\"{x:1360,y:768,t:1527873217772};\\\", \\\"{x:1356,y:767,t:1527873217789};\\\", \\\"{x:1353,y:766,t:1527873217806};\\\", \\\"{x:1351,y:765,t:1527873217824};\\\", \\\"{x:1350,y:772,t:1527873221301};\\\", \\\"{x:1350,y:784,t:1527873221308};\\\", \\\"{x:1350,y:803,t:1527873221323};\\\", \\\"{x:1353,y:821,t:1527873221340};\\\", \\\"{x:1357,y:836,t:1527873221357};\\\", \\\"{x:1360,y:845,t:1527873221374};\\\", \\\"{x:1360,y:850,t:1527873221391};\\\", \\\"{x:1360,y:857,t:1527873221407};\\\", \\\"{x:1360,y:867,t:1527873221424};\\\", \\\"{x:1360,y:881,t:1527873221440};\\\", \\\"{x:1360,y:896,t:1527873221458};\\\", \\\"{x:1360,y:911,t:1527873221474};\\\", \\\"{x:1360,y:926,t:1527873221490};\\\", \\\"{x:1360,y:946,t:1527873221507};\\\", \\\"{x:1360,y:959,t:1527873221524};\\\", \\\"{x:1360,y:969,t:1527873221541};\\\", \\\"{x:1360,y:979,t:1527873221558};\\\", \\\"{x:1360,y:985,t:1527873221574};\\\", \\\"{x:1360,y:991,t:1527873221591};\\\", \\\"{x:1360,y:997,t:1527873221608};\\\", \\\"{x:1361,y:1000,t:1527873221623};\\\", \\\"{x:1361,y:1001,t:1527873221641};\\\", \\\"{x:1361,y:1003,t:1527873221658};\\\", \\\"{x:1361,y:1004,t:1527873221674};\\\", \\\"{x:1361,y:1000,t:1527873221771};\\\", \\\"{x:1359,y:996,t:1527873221779};\\\", \\\"{x:1357,y:990,t:1527873221790};\\\", \\\"{x:1354,y:983,t:1527873221807};\\\", \\\"{x:1351,y:974,t:1527873221825};\\\", \\\"{x:1350,y:964,t:1527873221841};\\\", \\\"{x:1347,y:954,t:1527873221858};\\\", \\\"{x:1345,y:945,t:1527873221874};\\\", \\\"{x:1345,y:941,t:1527873221890};\\\", \\\"{x:1345,y:942,t:1527873222019};\\\", \\\"{x:1346,y:947,t:1527873222026};\\\", \\\"{x:1346,y:950,t:1527873222040};\\\", \\\"{x:1347,y:954,t:1527873222057};\\\", \\\"{x:1348,y:960,t:1527873222074};\\\", \\\"{x:1348,y:961,t:1527873222091};\\\", \\\"{x:1348,y:963,t:1527873222107};\\\", \\\"{x:1350,y:964,t:1527873223140};\\\", \\\"{x:1351,y:964,t:1527873223213};\\\", \\\"{x:1352,y:964,t:1527873223228};\\\", \\\"{x:1353,y:965,t:1527873223242};\\\", \\\"{x:1355,y:965,t:1527873223259};\\\", \\\"{x:1357,y:965,t:1527873223275};\\\", \\\"{x:1360,y:965,t:1527873223292};\\\", \\\"{x:1364,y:967,t:1527873223309};\\\", \\\"{x:1367,y:967,t:1527873223325};\\\", \\\"{x:1370,y:967,t:1527873223342};\\\", \\\"{x:1372,y:967,t:1527873223359};\\\", \\\"{x:1374,y:967,t:1527873223375};\\\", \\\"{x:1376,y:967,t:1527873223392};\\\", \\\"{x:1380,y:968,t:1527873223410};\\\", \\\"{x:1384,y:969,t:1527873223425};\\\", \\\"{x:1390,y:969,t:1527873223442};\\\", \\\"{x:1395,y:971,t:1527873223459};\\\", \\\"{x:1401,y:972,t:1527873223474};\\\", \\\"{x:1411,y:974,t:1527873223491};\\\", \\\"{x:1420,y:976,t:1527873223508};\\\", \\\"{x:1428,y:979,t:1527873223524};\\\", \\\"{x:1429,y:979,t:1527873223541};\\\", \\\"{x:1432,y:980,t:1527873224316};\\\", \\\"{x:1437,y:980,t:1527873224327};\\\", \\\"{x:1450,y:978,t:1527873224342};\\\", \\\"{x:1464,y:977,t:1527873224359};\\\", \\\"{x:1477,y:977,t:1527873224376};\\\", \\\"{x:1488,y:977,t:1527873224392};\\\", \\\"{x:1493,y:977,t:1527873224409};\\\", \\\"{x:1495,y:977,t:1527873224426};\\\", \\\"{x:1496,y:977,t:1527873224442};\\\", \\\"{x:1497,y:976,t:1527873224540};\\\", \\\"{x:1498,y:976,t:1527873224555};\\\", \\\"{x:1500,y:973,t:1527873224828};\\\", \\\"{x:1504,y:962,t:1527873224843};\\\", \\\"{x:1515,y:940,t:1527873224860};\\\", \\\"{x:1521,y:912,t:1527873224875};\\\", \\\"{x:1522,y:886,t:1527873224893};\\\", \\\"{x:1523,y:863,t:1527873224909};\\\", \\\"{x:1523,y:841,t:1527873224926};\\\", \\\"{x:1523,y:826,t:1527873224943};\\\", \\\"{x:1520,y:807,t:1527873224959};\\\", \\\"{x:1513,y:790,t:1527873224976};\\\", \\\"{x:1505,y:773,t:1527873224993};\\\", \\\"{x:1494,y:757,t:1527873225009};\\\", \\\"{x:1486,y:747,t:1527873225027};\\\", \\\"{x:1479,y:741,t:1527873225043};\\\", \\\"{x:1472,y:737,t:1527873225059};\\\", \\\"{x:1461,y:731,t:1527873225076};\\\", \\\"{x:1454,y:727,t:1527873225093};\\\", \\\"{x:1446,y:723,t:1527873225108};\\\", \\\"{x:1435,y:719,t:1527873225125};\\\", \\\"{x:1418,y:717,t:1527873225142};\\\", \\\"{x:1409,y:717,t:1527873225159};\\\", \\\"{x:1407,y:717,t:1527873225175};\\\", \\\"{x:1406,y:717,t:1527873225193};\\\", \\\"{x:1398,y:722,t:1527873225209};\\\", \\\"{x:1385,y:735,t:1527873225226};\\\", \\\"{x:1371,y:749,t:1527873225242};\\\", \\\"{x:1357,y:762,t:1527873225258};\\\", \\\"{x:1338,y:774,t:1527873225276};\\\", \\\"{x:1331,y:779,t:1527873225292};\\\", \\\"{x:1329,y:781,t:1527873225309};\\\", \\\"{x:1328,y:781,t:1527873225326};\\\", \\\"{x:1327,y:781,t:1527873225444};\\\", \\\"{x:1327,y:768,t:1527873225460};\\\", \\\"{x:1327,y:760,t:1527873225476};\\\", \\\"{x:1328,y:749,t:1527873225493};\\\", \\\"{x:1330,y:726,t:1527873225510};\\\", \\\"{x:1334,y:704,t:1527873225526};\\\", \\\"{x:1334,y:695,t:1527873225543};\\\", \\\"{x:1334,y:692,t:1527873225560};\\\", \\\"{x:1334,y:691,t:1527873225576};\\\", \\\"{x:1334,y:690,t:1527873225593};\\\", \\\"{x:1333,y:689,t:1527873225610};\\\", \\\"{x:1334,y:690,t:1527873225740};\\\", \\\"{x:1334,y:693,t:1527873225748};\\\", \\\"{x:1335,y:697,t:1527873225760};\\\", \\\"{x:1339,y:704,t:1527873225776};\\\", \\\"{x:1342,y:709,t:1527873225793};\\\", \\\"{x:1345,y:715,t:1527873225810};\\\", \\\"{x:1347,y:718,t:1527873225826};\\\", \\\"{x:1348,y:719,t:1527873225844};\\\", \\\"{x:1349,y:720,t:1527873225860};\\\", \\\"{x:1350,y:720,t:1527873226004};\\\", \\\"{x:1350,y:717,t:1527873226011};\\\", \\\"{x:1350,y:714,t:1527873226026};\\\", \\\"{x:1350,y:711,t:1527873226043};\\\", \\\"{x:1350,y:710,t:1527873226060};\\\", \\\"{x:1350,y:709,t:1527873226108};\\\", \\\"{x:1350,y:708,t:1527873226372};\\\", \\\"{x:1349,y:707,t:1527873226396};\\\", \\\"{x:1349,y:705,t:1527873226410};\\\", \\\"{x:1348,y:703,t:1527873226427};\\\", \\\"{x:1348,y:702,t:1527873226476};\\\", \\\"{x:1348,y:701,t:1527873226523};\\\", \\\"{x:1348,y:700,t:1527873226540};\\\", \\\"{x:1345,y:699,t:1527873226964};\\\", \\\"{x:1344,y:699,t:1527873226980};\\\", \\\"{x:1343,y:699,t:1527873227228};\\\", \\\"{x:1340,y:699,t:1527873227293};\\\", \\\"{x:1336,y:701,t:1527873227310};\\\", \\\"{x:1328,y:702,t:1527873227327};\\\", \\\"{x:1321,y:702,t:1527873227344};\\\", \\\"{x:1308,y:702,t:1527873227360};\\\", \\\"{x:1290,y:702,t:1527873227378};\\\", \\\"{x:1267,y:702,t:1527873227395};\\\", \\\"{x:1242,y:702,t:1527873227410};\\\", \\\"{x:1209,y:702,t:1527873227427};\\\", \\\"{x:1160,y:702,t:1527873227443};\\\", \\\"{x:1120,y:702,t:1527873227461};\\\", \\\"{x:1081,y:702,t:1527873227478};\\\", \\\"{x:1042,y:702,t:1527873227494};\\\", \\\"{x:1005,y:702,t:1527873227511};\\\", \\\"{x:961,y:699,t:1527873227527};\\\", \\\"{x:932,y:696,t:1527873227544};\\\", \\\"{x:906,y:696,t:1527873227561};\\\", \\\"{x:881,y:696,t:1527873227577};\\\", \\\"{x:853,y:696,t:1527873227594};\\\", \\\"{x:830,y:696,t:1527873227610};\\\", \\\"{x:811,y:696,t:1527873227627};\\\", \\\"{x:789,y:696,t:1527873227644};\\\", \\\"{x:779,y:696,t:1527873227660};\\\", \\\"{x:774,y:696,t:1527873227677};\\\", \\\"{x:772,y:696,t:1527873227693};\\\", \\\"{x:770,y:696,t:1527873227710};\\\", \\\"{x:768,y:696,t:1527873227731};\\\", \\\"{x:767,y:696,t:1527873227755};\\\", \\\"{x:766,y:696,t:1527873227778};\\\", \\\"{x:765,y:696,t:1527873227795};\\\", \\\"{x:764,y:696,t:1527873227811};\\\", \\\"{x:763,y:696,t:1527873227826};\\\", \\\"{x:761,y:696,t:1527873227844};\\\", \\\"{x:758,y:696,t:1527873227861};\\\", \\\"{x:756,y:696,t:1527873227877};\\\", \\\"{x:753,y:696,t:1527873227894};\\\", \\\"{x:751,y:697,t:1527873227911};\\\", \\\"{x:749,y:698,t:1527873227927};\\\", \\\"{x:747,y:699,t:1527873227944};\\\", \\\"{x:742,y:702,t:1527873227961};\\\", \\\"{x:738,y:703,t:1527873227977};\\\", \\\"{x:737,y:705,t:1527873227994};\\\", \\\"{x:732,y:707,t:1527873228011};\\\", \\\"{x:725,y:710,t:1527873228027};\\\", \\\"{x:717,y:714,t:1527873228044};\\\", \\\"{x:712,y:715,t:1527873228061};\\\", \\\"{x:708,y:717,t:1527873228077};\\\", \\\"{x:705,y:718,t:1527873228094};\\\", \\\"{x:700,y:720,t:1527873228111};\\\", \\\"{x:694,y:722,t:1527873228127};\\\", \\\"{x:689,y:724,t:1527873228144};\\\", \\\"{x:683,y:725,t:1527873228161};\\\", \\\"{x:678,y:727,t:1527873228178};\\\", \\\"{x:674,y:727,t:1527873228194};\\\", \\\"{x:671,y:727,t:1527873228211};\\\", \\\"{x:665,y:727,t:1527873228227};\\\", \\\"{x:660,y:727,t:1527873228244};\\\", \\\"{x:649,y:727,t:1527873228261};\\\", \\\"{x:631,y:722,t:1527873228278};\\\", \\\"{x:607,y:711,t:1527873228294};\\\", \\\"{x:574,y:694,t:1527873228311};\\\", \\\"{x:533,y:676,t:1527873228328};\\\", \\\"{x:483,y:653,t:1527873228346};\\\", \\\"{x:460,y:643,t:1527873228360};\\\", \\\"{x:451,y:641,t:1527873228377};\\\", \\\"{x:450,y:641,t:1527873228391};\\\", \\\"{x:454,y:641,t:1527873228490};\\\", \\\"{x:467,y:635,t:1527873228508};\\\", \\\"{x:479,y:632,t:1527873228525};\\\", \\\"{x:491,y:628,t:1527873228541};\\\", \\\"{x:505,y:621,t:1527873228558};\\\", \\\"{x:520,y:615,t:1527873228575};\\\", \\\"{x:532,y:608,t:1527873228591};\\\", \\\"{x:536,y:604,t:1527873228608};\\\", \\\"{x:537,y:601,t:1527873228625};\\\", \\\"{x:537,y:599,t:1527873228641};\\\", \\\"{x:536,y:596,t:1527873228657};\\\", \\\"{x:514,y:592,t:1527873228675};\\\", \\\"{x:484,y:589,t:1527873228692};\\\", \\\"{x:440,y:583,t:1527873228708};\\\", \\\"{x:397,y:576,t:1527873228725};\\\", \\\"{x:365,y:570,t:1527873228742};\\\", \\\"{x:347,y:568,t:1527873228757};\\\", \\\"{x:344,y:567,t:1527873228775};\\\", \\\"{x:344,y:566,t:1527873228836};\\\", \\\"{x:344,y:563,t:1527873228843};\\\", \\\"{x:344,y:562,t:1527873228860};\\\", \\\"{x:347,y:557,t:1527873228874};\\\", \\\"{x:350,y:554,t:1527873228892};\\\", \\\"{x:355,y:551,t:1527873228908};\\\", \\\"{x:358,y:549,t:1527873228924};\\\", \\\"{x:359,y:549,t:1527873228942};\\\", \\\"{x:358,y:549,t:1527873229003};\\\", \\\"{x:351,y:550,t:1527873229011};\\\", \\\"{x:345,y:552,t:1527873229024};\\\", \\\"{x:317,y:552,t:1527873229042};\\\", \\\"{x:279,y:552,t:1527873229057};\\\", \\\"{x:223,y:550,t:1527873229075};\\\", \\\"{x:201,y:544,t:1527873229090};\\\", \\\"{x:195,y:541,t:1527873229107};\\\", \\\"{x:192,y:538,t:1527873229125};\\\", \\\"{x:192,y:537,t:1527873229147};\\\", \\\"{x:191,y:536,t:1527873229159};\\\", \\\"{x:191,y:535,t:1527873229175};\\\", \\\"{x:191,y:533,t:1527873229192};\\\", \\\"{x:191,y:532,t:1527873229208};\\\", \\\"{x:191,y:529,t:1527873229224};\\\", \\\"{x:192,y:525,t:1527873229243};\\\", \\\"{x:214,y:515,t:1527873229262};\\\", \\\"{x:248,y:509,t:1527873229275};\\\", \\\"{x:306,y:509,t:1527873229292};\\\", \\\"{x:410,y:512,t:1527873229309};\\\", \\\"{x:525,y:524,t:1527873229325};\\\", \\\"{x:645,y:543,t:1527873229342};\\\", \\\"{x:740,y:558,t:1527873229359};\\\", \\\"{x:807,y:569,t:1527873229375};\\\", \\\"{x:851,y:574,t:1527873229392};\\\", \\\"{x:863,y:576,t:1527873229408};\\\", \\\"{x:864,y:574,t:1527873229531};\\\", \\\"{x:864,y:570,t:1527873229542};\\\", \\\"{x:859,y:561,t:1527873229559};\\\", \\\"{x:859,y:559,t:1527873229576};\\\", \\\"{x:858,y:558,t:1527873229592};\\\", \\\"{x:858,y:556,t:1527873229608};\\\", \\\"{x:858,y:554,t:1527873229626};\\\", \\\"{x:858,y:551,t:1527873229641};\\\", \\\"{x:857,y:546,t:1527873229660};\\\", \\\"{x:856,y:543,t:1527873229674};\\\", \\\"{x:854,y:539,t:1527873229692};\\\", \\\"{x:852,y:534,t:1527873229709};\\\", \\\"{x:850,y:530,t:1527873229726};\\\", \\\"{x:847,y:525,t:1527873229742};\\\", \\\"{x:844,y:520,t:1527873229759};\\\", \\\"{x:843,y:518,t:1527873229776};\\\", \\\"{x:842,y:515,t:1527873229792};\\\", \\\"{x:840,y:510,t:1527873229808};\\\", \\\"{x:838,y:504,t:1527873229825};\\\", \\\"{x:836,y:500,t:1527873229841};\\\", \\\"{x:834,y:496,t:1527873229859};\\\", \\\"{x:834,y:495,t:1527873229875};\\\", \\\"{x:833,y:494,t:1527873229893};\\\", \\\"{x:835,y:494,t:1527873230379};\\\", \\\"{x:839,y:494,t:1527873230393};\\\", \\\"{x:851,y:499,t:1527873230409};\\\", \\\"{x:872,y:505,t:1527873230427};\\\", \\\"{x:916,y:517,t:1527873230442};\\\", \\\"{x:956,y:530,t:1527873230459};\\\", \\\"{x:999,y:543,t:1527873230476};\\\", \\\"{x:1031,y:556,t:1527873230492};\\\", \\\"{x:1072,y:572,t:1527873230509};\\\", \\\"{x:1123,y:590,t:1527873230526};\\\", \\\"{x:1163,y:609,t:1527873230543};\\\", \\\"{x:1191,y:619,t:1527873230561};\\\", \\\"{x:1210,y:627,t:1527873230576};\\\", \\\"{x:1226,y:634,t:1527873230593};\\\", \\\"{x:1236,y:643,t:1527873230611};\\\", \\\"{x:1244,y:650,t:1527873230626};\\\", \\\"{x:1251,y:656,t:1527873230644};\\\", \\\"{x:1255,y:657,t:1527873230660};\\\", \\\"{x:1261,y:660,t:1527873230676};\\\", \\\"{x:1263,y:660,t:1527873230694};\\\", \\\"{x:1264,y:660,t:1527873230710};\\\", \\\"{x:1266,y:660,t:1527873230772};\\\", \\\"{x:1269,y:660,t:1527873230780};\\\", \\\"{x:1273,y:660,t:1527873230793};\\\", \\\"{x:1280,y:663,t:1527873230810};\\\", \\\"{x:1289,y:666,t:1527873230827};\\\", \\\"{x:1303,y:672,t:1527873230844};\\\", \\\"{x:1308,y:675,t:1527873230859};\\\", \\\"{x:1310,y:676,t:1527873230876};\\\", \\\"{x:1311,y:676,t:1527873230893};\\\", \\\"{x:1312,y:677,t:1527873230916};\\\", \\\"{x:1313,y:678,t:1527873230932};\\\", \\\"{x:1314,y:679,t:1527873231004};\\\", \\\"{x:1316,y:681,t:1527873231012};\\\", \\\"{x:1321,y:685,t:1527873231028};\\\", \\\"{x:1326,y:690,t:1527873231043};\\\", \\\"{x:1329,y:693,t:1527873231060};\\\", \\\"{x:1331,y:693,t:1527873231077};\\\", \\\"{x:1331,y:694,t:1527873231093};\\\", \\\"{x:1332,y:695,t:1527873231110};\\\", \\\"{x:1334,y:696,t:1527873231635};\\\", \\\"{x:1335,y:697,t:1527873231643};\\\", \\\"{x:1339,y:700,t:1527873231660};\\\", \\\"{x:1342,y:700,t:1527873231677};\\\", \\\"{x:1344,y:701,t:1527873231694};\\\", \\\"{x:1346,y:702,t:1527873231710};\\\", \\\"{x:1347,y:702,t:1527873231731};\\\", \\\"{x:1345,y:702,t:1527873231996};\\\", \\\"{x:1336,y:693,t:1527873232011};\\\", \\\"{x:1330,y:685,t:1527873232027};\\\", \\\"{x:1322,y:676,t:1527873232044};\\\", \\\"{x:1314,y:665,t:1527873232061};\\\", \\\"{x:1308,y:655,t:1527873232077};\\\", \\\"{x:1305,y:648,t:1527873232094};\\\", \\\"{x:1302,y:645,t:1527873232111};\\\", \\\"{x:1301,y:640,t:1527873232127};\\\", \\\"{x:1299,y:637,t:1527873232144};\\\", \\\"{x:1298,y:636,t:1527873232161};\\\", \\\"{x:1298,y:635,t:1527873232177};\\\", \\\"{x:1298,y:634,t:1527873232236};\\\", \\\"{x:1298,y:632,t:1527873232244};\\\", \\\"{x:1296,y:626,t:1527873232261};\\\", \\\"{x:1296,y:620,t:1527873232277};\\\", \\\"{x:1296,y:615,t:1527873232294};\\\", \\\"{x:1295,y:607,t:1527873232312};\\\", \\\"{x:1294,y:600,t:1527873232328};\\\", \\\"{x:1292,y:591,t:1527873232344};\\\", \\\"{x:1288,y:582,t:1527873232361};\\\", \\\"{x:1285,y:576,t:1527873232378};\\\", \\\"{x:1283,y:573,t:1527873232394};\\\", \\\"{x:1283,y:570,t:1527873232412};\\\", \\\"{x:1282,y:569,t:1527873232452};\\\", \\\"{x:1282,y:568,t:1527873232461};\\\", \\\"{x:1281,y:566,t:1527873232477};\\\", \\\"{x:1280,y:565,t:1527873232494};\\\", \\\"{x:1269,y:566,t:1527873236242};\\\", \\\"{x:1248,y:575,t:1527873236249};\\\", \\\"{x:1223,y:583,t:1527873236262};\\\", \\\"{x:1173,y:589,t:1527873236278};\\\", \\\"{x:1132,y:592,t:1527873236295};\\\", \\\"{x:1092,y:599,t:1527873236311};\\\", \\\"{x:1034,y:607,t:1527873236328};\\\", \\\"{x:997,y:608,t:1527873236344};\\\", \\\"{x:967,y:608,t:1527873236362};\\\", \\\"{x:936,y:608,t:1527873236380};\\\", \\\"{x:906,y:608,t:1527873236393};\\\", \\\"{x:885,y:608,t:1527873236411};\\\", \\\"{x:874,y:608,t:1527873236427};\\\", \\\"{x:859,y:608,t:1527873236444};\\\", \\\"{x:833,y:608,t:1527873236460};\\\", \\\"{x:802,y:608,t:1527873236478};\\\", \\\"{x:760,y:608,t:1527873236494};\\\", \\\"{x:710,y:608,t:1527873236511};\\\", \\\"{x:626,y:608,t:1527873236528};\\\", \\\"{x:589,y:608,t:1527873236545};\\\", \\\"{x:565,y:603,t:1527873236561};\\\", \\\"{x:560,y:600,t:1527873236578};\\\", \\\"{x:559,y:600,t:1527873236594};\\\", \\\"{x:559,y:588,t:1527873236611};\\\", \\\"{x:559,y:573,t:1527873236628};\\\", \\\"{x:560,y:565,t:1527873236645};\\\", \\\"{x:561,y:555,t:1527873236662};\\\", \\\"{x:562,y:547,t:1527873236678};\\\", \\\"{x:564,y:542,t:1527873236695};\\\", \\\"{x:565,y:535,t:1527873236711};\\\", \\\"{x:566,y:531,t:1527873236727};\\\", \\\"{x:566,y:529,t:1527873236744};\\\", \\\"{x:567,y:527,t:1527873236761};\\\", \\\"{x:567,y:526,t:1527873236778};\\\", \\\"{x:568,y:526,t:1527873236794};\\\", \\\"{x:568,y:525,t:1527873236811};\\\", \\\"{x:569,y:524,t:1527873236831};\\\", \\\"{x:569,y:523,t:1527873236845};\\\", \\\"{x:571,y:522,t:1527873236861};\\\", \\\"{x:573,y:521,t:1527873236878};\\\", \\\"{x:575,y:521,t:1527873236895};\\\", \\\"{x:580,y:521,t:1527873236911};\\\", \\\"{x:585,y:521,t:1527873236927};\\\", \\\"{x:591,y:522,t:1527873236945};\\\", \\\"{x:597,y:522,t:1527873236961};\\\", \\\"{x:609,y:522,t:1527873236978};\\\", \\\"{x:615,y:522,t:1527873236995};\\\", \\\"{x:619,y:521,t:1527873237011};\\\", \\\"{x:620,y:521,t:1527873237040};\\\", \\\"{x:620,y:520,t:1527873237056};\\\", \\\"{x:621,y:519,t:1527873237072};\\\", \\\"{x:622,y:518,t:1527873237088};\\\", \\\"{x:622,y:517,t:1527873237097};\\\", \\\"{x:623,y:517,t:1527873237111};\\\", \\\"{x:623,y:514,t:1527873237128};\\\", \\\"{x:623,y:513,t:1527873237146};\\\", \\\"{x:624,y:512,t:1527873237163};\\\", \\\"{x:624,y:511,t:1527873237178};\\\", \\\"{x:624,y:510,t:1527873237195};\\\", \\\"{x:625,y:507,t:1527873237212};\\\", \\\"{x:625,y:503,t:1527873237228};\\\", \\\"{x:626,y:501,t:1527873237246};\\\", \\\"{x:626,y:500,t:1527873237264};\\\", \\\"{x:637,y:494,t:1527873239953};\\\", \\\"{x:660,y:488,t:1527873239965};\\\", \\\"{x:727,y:487,t:1527873239981};\\\", \\\"{x:792,y:507,t:1527873239998};\\\", \\\"{x:864,y:527,t:1527873240014};\\\", \\\"{x:932,y:542,t:1527873240030};\\\", \\\"{x:986,y:562,t:1527873240047};\\\", \\\"{x:1047,y:584,t:1527873240064};\\\", \\\"{x:1076,y:600,t:1527873240081};\\\", \\\"{x:1101,y:620,t:1527873240097};\\\", \\\"{x:1117,y:645,t:1527873240114};\\\", \\\"{x:1136,y:684,t:1527873240132};\\\", \\\"{x:1146,y:726,t:1527873240147};\\\", \\\"{x:1150,y:759,t:1527873240164};\\\", \\\"{x:1150,y:782,t:1527873240182};\\\", \\\"{x:1150,y:804,t:1527873240197};\\\", \\\"{x:1150,y:824,t:1527873240214};\\\", \\\"{x:1149,y:838,t:1527873240231};\\\", \\\"{x:1149,y:855,t:1527873240247};\\\", \\\"{x:1150,y:878,t:1527873240264};\\\", \\\"{x:1152,y:885,t:1527873240281};\\\", \\\"{x:1153,y:888,t:1527873240298};\\\", \\\"{x:1154,y:889,t:1527873240314};\\\", \\\"{x:1156,y:889,t:1527873240353};\\\", \\\"{x:1158,y:889,t:1527873240365};\\\", \\\"{x:1161,y:889,t:1527873240381};\\\", \\\"{x:1167,y:889,t:1527873240397};\\\", \\\"{x:1171,y:888,t:1527873240415};\\\", \\\"{x:1176,y:886,t:1527873240432};\\\", \\\"{x:1182,y:883,t:1527873240448};\\\", \\\"{x:1191,y:881,t:1527873240465};\\\", \\\"{x:1192,y:881,t:1527873240482};\\\", \\\"{x:1192,y:879,t:1527873240840};\\\", \\\"{x:1192,y:876,t:1527873240848};\\\", \\\"{x:1192,y:870,t:1527873240865};\\\", \\\"{x:1194,y:865,t:1527873240882};\\\", \\\"{x:1195,y:863,t:1527873240899};\\\", \\\"{x:1195,y:861,t:1527873240914};\\\", \\\"{x:1195,y:859,t:1527873240931};\\\", \\\"{x:1195,y:858,t:1527873240953};\\\", \\\"{x:1195,y:856,t:1527873240968};\\\", \\\"{x:1196,y:856,t:1527873240984};\\\", \\\"{x:1196,y:855,t:1527873240999};\\\", \\\"{x:1196,y:853,t:1527873241016};\\\", \\\"{x:1198,y:850,t:1527873241032};\\\", \\\"{x:1200,y:846,t:1527873241049};\\\", \\\"{x:1202,y:843,t:1527873241065};\\\", \\\"{x:1205,y:840,t:1527873241081};\\\", \\\"{x:1206,y:839,t:1527873241099};\\\", \\\"{x:1209,y:836,t:1527873241115};\\\", \\\"{x:1213,y:832,t:1527873241132};\\\", \\\"{x:1214,y:831,t:1527873241149};\\\", \\\"{x:1217,y:829,t:1527873241166};\\\", \\\"{x:1218,y:828,t:1527873241182};\\\", \\\"{x:1220,y:826,t:1527873241200};\\\", \\\"{x:1220,y:825,t:1527873241216};\\\", \\\"{x:1222,y:824,t:1527873241232};\\\", \\\"{x:1227,y:820,t:1527873241249};\\\", \\\"{x:1231,y:816,t:1527873241266};\\\", \\\"{x:1233,y:813,t:1527873241282};\\\", \\\"{x:1238,y:811,t:1527873241298};\\\", \\\"{x:1244,y:810,t:1527873241316};\\\", \\\"{x:1250,y:810,t:1527873241332};\\\", \\\"{x:1258,y:809,t:1527873241349};\\\", \\\"{x:1265,y:807,t:1527873241366};\\\", \\\"{x:1270,y:806,t:1527873241382};\\\", \\\"{x:1273,y:806,t:1527873241399};\\\", \\\"{x:1279,y:806,t:1527873241416};\\\", \\\"{x:1280,y:805,t:1527873241433};\\\", \\\"{x:1282,y:805,t:1527873241512};\\\", \\\"{x:1284,y:805,t:1527873241520};\\\", \\\"{x:1288,y:805,t:1527873241532};\\\", \\\"{x:1299,y:805,t:1527873241548};\\\", \\\"{x:1309,y:805,t:1527873241565};\\\", \\\"{x:1319,y:808,t:1527873241583};\\\", \\\"{x:1334,y:814,t:1527873241598};\\\", \\\"{x:1349,y:819,t:1527873241615};\\\", \\\"{x:1372,y:833,t:1527873241632};\\\", \\\"{x:1380,y:836,t:1527873241648};\\\", \\\"{x:1383,y:838,t:1527873241666};\\\", \\\"{x:1384,y:839,t:1527873241682};\\\", \\\"{x:1385,y:839,t:1527873241698};\\\", \\\"{x:1385,y:840,t:1527873241716};\\\", \\\"{x:1387,y:842,t:1527873241732};\\\", \\\"{x:1387,y:845,t:1527873241749};\\\", \\\"{x:1387,y:851,t:1527873241766};\\\", \\\"{x:1388,y:856,t:1527873241782};\\\", \\\"{x:1388,y:865,t:1527873241799};\\\", \\\"{x:1388,y:873,t:1527873241816};\\\", \\\"{x:1387,y:882,t:1527873241832};\\\", \\\"{x:1386,y:884,t:1527873241850};\\\", \\\"{x:1383,y:888,t:1527873241865};\\\", \\\"{x:1380,y:892,t:1527873241883};\\\", \\\"{x:1375,y:896,t:1527873241900};\\\", \\\"{x:1371,y:898,t:1527873241916};\\\", \\\"{x:1370,y:898,t:1527873241932};\\\", \\\"{x:1369,y:898,t:1527873241950};\\\", \\\"{x:1367,y:894,t:1527873242080};\\\", \\\"{x:1364,y:888,t:1527873242087};\\\", \\\"{x:1362,y:880,t:1527873242099};\\\", \\\"{x:1357,y:870,t:1527873242116};\\\", \\\"{x:1355,y:860,t:1527873242132};\\\", \\\"{x:1354,y:844,t:1527873242150};\\\", \\\"{x:1354,y:818,t:1527873242165};\\\", \\\"{x:1353,y:796,t:1527873242182};\\\", \\\"{x:1353,y:773,t:1527873242199};\\\", \\\"{x:1352,y:744,t:1527873242215};\\\", \\\"{x:1352,y:714,t:1527873242232};\\\", \\\"{x:1352,y:702,t:1527873242250};\\\", \\\"{x:1355,y:689,t:1527873242266};\\\", \\\"{x:1357,y:676,t:1527873242283};\\\", \\\"{x:1359,y:663,t:1527873242299};\\\", \\\"{x:1361,y:648,t:1527873242316};\\\", \\\"{x:1361,y:641,t:1527873242332};\\\", \\\"{x:1362,y:636,t:1527873242349};\\\", \\\"{x:1362,y:635,t:1527873242367};\\\", \\\"{x:1362,y:637,t:1527873242489};\\\", \\\"{x:1357,y:648,t:1527873242500};\\\", \\\"{x:1351,y:664,t:1527873242517};\\\", \\\"{x:1344,y:678,t:1527873242532};\\\", \\\"{x:1337,y:694,t:1527873242551};\\\", \\\"{x:1330,y:712,t:1527873242566};\\\", \\\"{x:1326,y:720,t:1527873242583};\\\", \\\"{x:1325,y:724,t:1527873242600};\\\", \\\"{x:1325,y:725,t:1527873242616};\\\", \\\"{x:1326,y:725,t:1527873242866};\\\", \\\"{x:1331,y:722,t:1527873242884};\\\", \\\"{x:1334,y:719,t:1527873242900};\\\", \\\"{x:1339,y:717,t:1527873242917};\\\", \\\"{x:1340,y:716,t:1527873242934};\\\", \\\"{x:1343,y:713,t:1527873243273};\\\", \\\"{x:1345,y:712,t:1527873243284};\\\", \\\"{x:1347,y:709,t:1527873243301};\\\", \\\"{x:1349,y:707,t:1527873243316};\\\", \\\"{x:1350,y:706,t:1527873243334};\\\", \\\"{x:1350,y:705,t:1527873243537};\\\", \\\"{x:1347,y:696,t:1527873243551};\\\", \\\"{x:1277,y:646,t:1527873243568};\\\", \\\"{x:1207,y:609,t:1527873243584};\\\", \\\"{x:1178,y:597,t:1527873243601};\\\", \\\"{x:1170,y:593,t:1527873243618};\\\", \\\"{x:1164,y:590,t:1527873243634};\\\", \\\"{x:1157,y:584,t:1527873243651};\\\", \\\"{x:1152,y:580,t:1527873243668};\\\", \\\"{x:1151,y:579,t:1527873243683};\\\", \\\"{x:1150,y:577,t:1527873243701};\\\", \\\"{x:1150,y:574,t:1527873243718};\\\", \\\"{x:1150,y:571,t:1527873243734};\\\", \\\"{x:1150,y:567,t:1527873243751};\\\", \\\"{x:1154,y:565,t:1527873243768};\\\", \\\"{x:1163,y:561,t:1527873243784};\\\", \\\"{x:1183,y:558,t:1527873243801};\\\", \\\"{x:1203,y:558,t:1527873243818};\\\", \\\"{x:1225,y:558,t:1527873243834};\\\", \\\"{x:1241,y:560,t:1527873243851};\\\", \\\"{x:1251,y:563,t:1527873243868};\\\", \\\"{x:1259,y:565,t:1527873243884};\\\", \\\"{x:1263,y:568,t:1527873243901};\\\", \\\"{x:1265,y:568,t:1527873243918};\\\", \\\"{x:1265,y:569,t:1527873243934};\\\", \\\"{x:1266,y:570,t:1527873243951};\\\", \\\"{x:1267,y:571,t:1527873243967};\\\", \\\"{x:1268,y:572,t:1527873243983};\\\", \\\"{x:1274,y:571,t:1527873244096};\\\", \\\"{x:1281,y:568,t:1527873244104};\\\", \\\"{x:1287,y:564,t:1527873244118};\\\", \\\"{x:1302,y:558,t:1527873244134};\\\", \\\"{x:1312,y:551,t:1527873244151};\\\", \\\"{x:1314,y:550,t:1527873244167};\\\", \\\"{x:1314,y:549,t:1527873244273};\\\", \\\"{x:1308,y:549,t:1527873244289};\\\", \\\"{x:1299,y:549,t:1527873244301};\\\", \\\"{x:1281,y:549,t:1527873244318};\\\", \\\"{x:1269,y:549,t:1527873244336};\\\", \\\"{x:1261,y:549,t:1527873244351};\\\", \\\"{x:1259,y:550,t:1527873244368};\\\", \\\"{x:1257,y:551,t:1527873244385};\\\", \\\"{x:1256,y:552,t:1527873244537};\\\", \\\"{x:1257,y:552,t:1527873244552};\\\", \\\"{x:1263,y:552,t:1527873244568};\\\", \\\"{x:1272,y:554,t:1527873244585};\\\", \\\"{x:1275,y:555,t:1527873244602};\\\", \\\"{x:1276,y:555,t:1527873244619};\\\", \\\"{x:1279,y:556,t:1527873244721};\\\", \\\"{x:1279,y:557,t:1527873244735};\\\", \\\"{x:1281,y:563,t:1527873245145};\\\", \\\"{x:1283,y:572,t:1527873245153};\\\", \\\"{x:1286,y:590,t:1527873245168};\\\", \\\"{x:1290,y:619,t:1527873245184};\\\", \\\"{x:1295,y:666,t:1527873245201};\\\", \\\"{x:1297,y:709,t:1527873245218};\\\", \\\"{x:1298,y:752,t:1527873245236};\\\", \\\"{x:1298,y:794,t:1527873245251};\\\", \\\"{x:1298,y:824,t:1527873245268};\\\", \\\"{x:1298,y:849,t:1527873245285};\\\", \\\"{x:1298,y:866,t:1527873245301};\\\", \\\"{x:1296,y:883,t:1527873245319};\\\", \\\"{x:1294,y:903,t:1527873245335};\\\", \\\"{x:1290,y:914,t:1527873245351};\\\", \\\"{x:1288,y:921,t:1527873245368};\\\", \\\"{x:1281,y:933,t:1527873245386};\\\", \\\"{x:1275,y:942,t:1527873245401};\\\", \\\"{x:1268,y:949,t:1527873245419};\\\", \\\"{x:1264,y:953,t:1527873245436};\\\", \\\"{x:1262,y:955,t:1527873245451};\\\", \\\"{x:1260,y:959,t:1527873245469};\\\", \\\"{x:1257,y:962,t:1527873245485};\\\", \\\"{x:1257,y:966,t:1527873245502};\\\", \\\"{x:1256,y:970,t:1527873245519};\\\", \\\"{x:1256,y:972,t:1527873245536};\\\", \\\"{x:1256,y:975,t:1527873245552};\\\", \\\"{x:1256,y:976,t:1527873245569};\\\", \\\"{x:1256,y:978,t:1527873245592};\\\", \\\"{x:1256,y:979,t:1527873245617};\\\", \\\"{x:1256,y:980,t:1527873245632};\\\", \\\"{x:1257,y:980,t:1527873245737};\\\", \\\"{x:1263,y:980,t:1527873245753};\\\", \\\"{x:1271,y:980,t:1527873245769};\\\", \\\"{x:1279,y:980,t:1527873245786};\\\", \\\"{x:1287,y:981,t:1527873245803};\\\", \\\"{x:1291,y:982,t:1527873245819};\\\", \\\"{x:1294,y:982,t:1527873245835};\\\", \\\"{x:1295,y:982,t:1527873245853};\\\", \\\"{x:1296,y:983,t:1527873245869};\\\", \\\"{x:1296,y:979,t:1527873246001};\\\", \\\"{x:1297,y:976,t:1527873246009};\\\", \\\"{x:1297,y:975,t:1527873246025};\\\", \\\"{x:1299,y:975,t:1527873246504};\\\", \\\"{x:1313,y:975,t:1527873246520};\\\", \\\"{x:1327,y:975,t:1527873246535};\\\", \\\"{x:1343,y:975,t:1527873246553};\\\", \\\"{x:1361,y:975,t:1527873246569};\\\", \\\"{x:1373,y:975,t:1527873246586};\\\", \\\"{x:1379,y:975,t:1527873246602};\\\", \\\"{x:1381,y:975,t:1527873246620};\\\", \\\"{x:1379,y:975,t:1527873246839};\\\", \\\"{x:1378,y:975,t:1527873246852};\\\", \\\"{x:1374,y:976,t:1527873246870};\\\", \\\"{x:1370,y:976,t:1527873246887};\\\", \\\"{x:1364,y:976,t:1527873246903};\\\", \\\"{x:1360,y:976,t:1527873246920};\\\", \\\"{x:1359,y:976,t:1527873246944};\\\", \\\"{x:1358,y:976,t:1527873246952};\\\", \\\"{x:1356,y:976,t:1527873246970};\\\", \\\"{x:1353,y:976,t:1527873246987};\\\", \\\"{x:1350,y:978,t:1527873247003};\\\", \\\"{x:1349,y:978,t:1527873247019};\\\", \\\"{x:1348,y:978,t:1527873247036};\\\", \\\"{x:1350,y:978,t:1527873247633};\\\", \\\"{x:1354,y:978,t:1527873247640};\\\", \\\"{x:1358,y:978,t:1527873247654};\\\", \\\"{x:1370,y:977,t:1527873247671};\\\", \\\"{x:1377,y:976,t:1527873247687};\\\", \\\"{x:1386,y:974,t:1527873247704};\\\", \\\"{x:1392,y:974,t:1527873247721};\\\", \\\"{x:1395,y:974,t:1527873247737};\\\", \\\"{x:1396,y:974,t:1527873247754};\\\", \\\"{x:1398,y:973,t:1527873247824};\\\", \\\"{x:1400,y:972,t:1527873247840};\\\", \\\"{x:1403,y:972,t:1527873248329};\\\", \\\"{x:1408,y:972,t:1527873248338};\\\", \\\"{x:1418,y:972,t:1527873248355};\\\", \\\"{x:1428,y:972,t:1527873248371};\\\", \\\"{x:1438,y:974,t:1527873248388};\\\", \\\"{x:1445,y:975,t:1527873248405};\\\", \\\"{x:1449,y:975,t:1527873248421};\\\", \\\"{x:1450,y:975,t:1527873248440};\\\", \\\"{x:1451,y:975,t:1527873248481};\\\", \\\"{x:1452,y:975,t:1527873248488};\\\", \\\"{x:1456,y:974,t:1527873248504};\\\", \\\"{x:1459,y:974,t:1527873248521};\\\", \\\"{x:1462,y:971,t:1527873248538};\\\", \\\"{x:1463,y:971,t:1527873248555};\\\", \\\"{x:1464,y:971,t:1527873248768};\\\", \\\"{x:1466,y:970,t:1527873248776};\\\", \\\"{x:1468,y:969,t:1527873248788};\\\", \\\"{x:1473,y:967,t:1527873248805};\\\", \\\"{x:1492,y:959,t:1527873248821};\\\", \\\"{x:1504,y:953,t:1527873248838};\\\", \\\"{x:1511,y:952,t:1527873248855};\\\", \\\"{x:1514,y:951,t:1527873248871};\\\", \\\"{x:1515,y:951,t:1527873249057};\\\", \\\"{x:1519,y:951,t:1527873249072};\\\", \\\"{x:1523,y:953,t:1527873249088};\\\", \\\"{x:1527,y:956,t:1527873249105};\\\", \\\"{x:1529,y:957,t:1527873249122};\\\", \\\"{x:1531,y:958,t:1527873249138};\\\", \\\"{x:1532,y:958,t:1527873249155};\\\", \\\"{x:1532,y:959,t:1527873249265};\\\", \\\"{x:1533,y:959,t:1527873249744};\\\", \\\"{x:1534,y:959,t:1527873249761};\\\", \\\"{x:1535,y:959,t:1527873249772};\\\", \\\"{x:1537,y:959,t:1527873249789};\\\", \\\"{x:1538,y:959,t:1527873249806};\\\", \\\"{x:1539,y:960,t:1527873249856};\\\", \\\"{x:1540,y:960,t:1527873249904};\\\", \\\"{x:1540,y:961,t:1527873249921};\\\", \\\"{x:1541,y:961,t:1527873249936};\\\", \\\"{x:1542,y:962,t:1527873249993};\\\", \\\"{x:1537,y:961,t:1527873250248};\\\", \\\"{x:1525,y:955,t:1527873250256};\\\", \\\"{x:1491,y:937,t:1527873250273};\\\", \\\"{x:1464,y:919,t:1527873250289};\\\", \\\"{x:1449,y:908,t:1527873250306};\\\", \\\"{x:1436,y:899,t:1527873250324};\\\", \\\"{x:1421,y:888,t:1527873250339};\\\", \\\"{x:1406,y:878,t:1527873250357};\\\", \\\"{x:1395,y:869,t:1527873250373};\\\", \\\"{x:1385,y:863,t:1527873250389};\\\", \\\"{x:1384,y:862,t:1527873250406};\\\", \\\"{x:1383,y:862,t:1527873250424};\\\", \\\"{x:1382,y:860,t:1527873250481};\\\", \\\"{x:1380,y:858,t:1527873250489};\\\", \\\"{x:1377,y:852,t:1527873250506};\\\", \\\"{x:1373,y:841,t:1527873250523};\\\", \\\"{x:1367,y:821,t:1527873250539};\\\", \\\"{x:1358,y:797,t:1527873250556};\\\", \\\"{x:1349,y:777,t:1527873250573};\\\", \\\"{x:1343,y:762,t:1527873250590};\\\", \\\"{x:1339,y:753,t:1527873250607};\\\", \\\"{x:1335,y:746,t:1527873250623};\\\", \\\"{x:1331,y:738,t:1527873250640};\\\", \\\"{x:1329,y:733,t:1527873250656};\\\", \\\"{x:1328,y:732,t:1527873250673};\\\", \\\"{x:1328,y:730,t:1527873250690};\\\", \\\"{x:1326,y:728,t:1527873250706};\\\", \\\"{x:1325,y:727,t:1527873250723};\\\", \\\"{x:1325,y:726,t:1527873250740};\\\", \\\"{x:1325,y:725,t:1527873250761};\\\", \\\"{x:1325,y:724,t:1527873250774};\\\", \\\"{x:1325,y:720,t:1527873250790};\\\", \\\"{x:1325,y:708,t:1527873250806};\\\", \\\"{x:1325,y:695,t:1527873250823};\\\", \\\"{x:1327,y:684,t:1527873250841};\\\", \\\"{x:1330,y:679,t:1527873250857};\\\", \\\"{x:1330,y:675,t:1527873250873};\\\", \\\"{x:1330,y:674,t:1527873250891};\\\", \\\"{x:1331,y:673,t:1527873250907};\\\", \\\"{x:1334,y:674,t:1527873251025};\\\", \\\"{x:1340,y:682,t:1527873251040};\\\", \\\"{x:1347,y:690,t:1527873251056};\\\", \\\"{x:1350,y:695,t:1527873251074};\\\", \\\"{x:1353,y:698,t:1527873251090};\\\", \\\"{x:1354,y:699,t:1527873251108};\\\", \\\"{x:1355,y:702,t:1527873251123};\\\", \\\"{x:1356,y:702,t:1527873251144};\\\", \\\"{x:1356,y:703,t:1527873251177};\\\", \\\"{x:1356,y:704,t:1527873251369};\\\", \\\"{x:1356,y:705,t:1527873251377};\\\", \\\"{x:1355,y:705,t:1527873251393};\\\", \\\"{x:1354,y:705,t:1527873251545};\\\", \\\"{x:1353,y:705,t:1527873251557};\\\", \\\"{x:1351,y:703,t:1527873251574};\\\", \\\"{x:1350,y:700,t:1527873251591};\\\", \\\"{x:1349,y:698,t:1527873251624};\\\", \\\"{x:1348,y:697,t:1527873251640};\\\", \\\"{x:1347,y:696,t:1527873251665};\\\", \\\"{x:1346,y:696,t:1527873251721};\\\", \\\"{x:1345,y:696,t:1527873251745};\\\", \\\"{x:1345,y:695,t:1527873251760};\\\", \\\"{x:1343,y:695,t:1527873251816};\\\", \\\"{x:1342,y:695,t:1527873251873};\\\", \\\"{x:1343,y:696,t:1527873254577};\\\", \\\"{x:1346,y:699,t:1527873254592};\\\", \\\"{x:1348,y:699,t:1527873254609};\\\", \\\"{x:1352,y:701,t:1527873254627};\\\", \\\"{x:1353,y:701,t:1527873254643};\\\", \\\"{x:1355,y:702,t:1527873254660};\\\", \\\"{x:1356,y:703,t:1527873254676};\\\", \\\"{x:1357,y:703,t:1527873254703};\\\", \\\"{x:1359,y:703,t:1527873254728};\\\", \\\"{x:1360,y:704,t:1527873254742};\\\", \\\"{x:1361,y:705,t:1527873254768};\\\", \\\"{x:1362,y:705,t:1527873254783};\\\", \\\"{x:1363,y:706,t:1527873254793};\\\", \\\"{x:1363,y:708,t:1527873254840};\\\", \\\"{x:1363,y:709,t:1527873254855};\\\", \\\"{x:1363,y:711,t:1527873254871};\\\", \\\"{x:1363,y:712,t:1527873254896};\\\", \\\"{x:1363,y:714,t:1527873254936};\\\", \\\"{x:1363,y:715,t:1527873254976};\\\", \\\"{x:1355,y:715,t:1527873254993};\\\", \\\"{x:1338,y:707,t:1527873255010};\\\", \\\"{x:1305,y:687,t:1527873255026};\\\", \\\"{x:1261,y:659,t:1527873255044};\\\", \\\"{x:1229,y:642,t:1527873255060};\\\", \\\"{x:1213,y:632,t:1527873255076};\\\", \\\"{x:1202,y:626,t:1527873255093};\\\", \\\"{x:1192,y:618,t:1527873255110};\\\", \\\"{x:1182,y:611,t:1527873255126};\\\", \\\"{x:1174,y:606,t:1527873255143};\\\", \\\"{x:1160,y:597,t:1527873255160};\\\", \\\"{x:1149,y:593,t:1527873255176};\\\", \\\"{x:1142,y:590,t:1527873255194};\\\", \\\"{x:1133,y:586,t:1527873255210};\\\", \\\"{x:1119,y:583,t:1527873255226};\\\", \\\"{x:1105,y:581,t:1527873255243};\\\", \\\"{x:1091,y:578,t:1527873255261};\\\", \\\"{x:1076,y:576,t:1527873255277};\\\", \\\"{x:1067,y:575,t:1527873255294};\\\", \\\"{x:1063,y:574,t:1527873255310};\\\", \\\"{x:1061,y:574,t:1527873255327};\\\", \\\"{x:1059,y:574,t:1527873255343};\\\", \\\"{x:1056,y:572,t:1527873255360};\\\", \\\"{x:1052,y:571,t:1527873255377};\\\", \\\"{x:1047,y:570,t:1527873255394};\\\", \\\"{x:1037,y:567,t:1527873255410};\\\", \\\"{x:1026,y:566,t:1527873255427};\\\", \\\"{x:1016,y:566,t:1527873255443};\\\", \\\"{x:1006,y:563,t:1527873255460};\\\", \\\"{x:999,y:563,t:1527873255477};\\\", \\\"{x:993,y:562,t:1527873255493};\\\", \\\"{x:987,y:562,t:1527873255510};\\\", \\\"{x:984,y:562,t:1527873255527};\\\", \\\"{x:980,y:562,t:1527873255543};\\\", \\\"{x:975,y:562,t:1527873255560};\\\", \\\"{x:971,y:561,t:1527873255577};\\\", \\\"{x:966,y:561,t:1527873255593};\\\", \\\"{x:959,y:561,t:1527873255610};\\\", \\\"{x:955,y:561,t:1527873255627};\\\", \\\"{x:948,y:561,t:1527873255643};\\\", \\\"{x:943,y:561,t:1527873255659};\\\", \\\"{x:937,y:561,t:1527873255677};\\\", \\\"{x:931,y:561,t:1527873255693};\\\", \\\"{x:922,y:561,t:1527873255710};\\\", \\\"{x:904,y:561,t:1527873255728};\\\", \\\"{x:878,y:561,t:1527873255744};\\\", \\\"{x:863,y:561,t:1527873255760};\\\", \\\"{x:854,y:561,t:1527873255777};\\\", \\\"{x:849,y:561,t:1527873255793};\\\", \\\"{x:847,y:561,t:1527873255810};\\\", \\\"{x:846,y:560,t:1527873255936};\\\", \\\"{x:845,y:559,t:1527873255944};\\\", \\\"{x:841,y:555,t:1527873255962};\\\", \\\"{x:833,y:543,t:1527873255977};\\\", \\\"{x:826,y:533,t:1527873255993};\\\", \\\"{x:822,y:527,t:1527873256010};\\\", \\\"{x:820,y:525,t:1527873256027};\\\", \\\"{x:819,y:525,t:1527873256043};\\\", \\\"{x:819,y:524,t:1527873256225};\\\", \\\"{x:825,y:518,t:1527873256243};\\\", \\\"{x:835,y:513,t:1527873256261};\\\", \\\"{x:843,y:509,t:1527873256277};\\\", \\\"{x:848,y:506,t:1527873256294};\\\", \\\"{x:849,y:505,t:1527873256311};\\\", \\\"{x:847,y:515,t:1527873257945};\\\", \\\"{x:835,y:553,t:1527873257962};\\\", \\\"{x:827,y:578,t:1527873257979};\\\", \\\"{x:823,y:593,t:1527873257995};\\\", \\\"{x:821,y:602,t:1527873258012};\\\", \\\"{x:820,y:608,t:1527873258029};\\\", \\\"{x:820,y:614,t:1527873258045};\\\", \\\"{x:820,y:620,t:1527873258062};\\\", \\\"{x:822,y:629,t:1527873258078};\\\", \\\"{x:823,y:637,t:1527873258095};\\\", \\\"{x:824,y:656,t:1527873258111};\\\", \\\"{x:824,y:664,t:1527873258128};\\\", \\\"{x:825,y:674,t:1527873258146};\\\", \\\"{x:825,y:682,t:1527873258162};\\\", \\\"{x:825,y:691,t:1527873258178};\\\", \\\"{x:825,y:698,t:1527873258195};\\\", \\\"{x:825,y:702,t:1527873258212};\\\", \\\"{x:825,y:708,t:1527873258229};\\\", \\\"{x:825,y:713,t:1527873258246};\\\", \\\"{x:825,y:717,t:1527873258263};\\\", \\\"{x:825,y:718,t:1527873258279};\\\", \\\"{x:825,y:720,t:1527873258296};\\\", \\\"{x:825,y:722,t:1527873258313};\\\", \\\"{x:824,y:722,t:1527873258330};\\\", \\\"{x:823,y:723,t:1527873258346};\\\", \\\"{x:826,y:720,t:1527873258376};\\\", \\\"{x:830,y:718,t:1527873258384};\\\", \\\"{x:834,y:716,t:1527873258396};\\\", \\\"{x:841,y:711,t:1527873258413};\\\", \\\"{x:846,y:708,t:1527873258431};\\\", \\\"{x:849,y:708,t:1527873258447};\\\", \\\"{x:853,y:704,t:1527873258463};\\\", \\\"{x:855,y:702,t:1527873258479};\\\", \\\"{x:855,y:698,t:1527873264360};\\\", \\\"{x:855,y:692,t:1527873264367};\\\", \\\"{x:855,y:688,t:1527873264383};\\\", \\\"{x:853,y:680,t:1527873264399};\\\", \\\"{x:848,y:673,t:1527873264416};\\\", \\\"{x:845,y:667,t:1527873264433};\\\", \\\"{x:842,y:660,t:1527873264450};\\\", \\\"{x:841,y:657,t:1527873264466};\\\", \\\"{x:840,y:655,t:1527873264483};\\\", \\\"{x:844,y:651,t:1527873264688};\\\", \\\"{x:852,y:646,t:1527873264700};\\\", \\\"{x:876,y:639,t:1527873264717};\\\", \\\"{x:915,y:632,t:1527873264734};\\\", \\\"{x:997,y:629,t:1527873264751};\\\", \\\"{x:1062,y:630,t:1527873264766};\\\", \\\"{x:1115,y:644,t:1527873264784};\\\", \\\"{x:1154,y:661,t:1527873264801};\\\", \\\"{x:1179,y:679,t:1527873264817};\\\", \\\"{x:1193,y:696,t:1527873264834};\\\", \\\"{x:1202,y:712,t:1527873264851};\\\", \\\"{x:1210,y:735,t:1527873264868};\\\", \\\"{x:1215,y:754,t:1527873264884};\\\", \\\"{x:1219,y:771,t:1527873264901};\\\", \\\"{x:1224,y:787,t:1527873264918};\\\", \\\"{x:1230,y:807,t:1527873264935};\\\", \\\"{x:1236,y:824,t:1527873264951};\\\", \\\"{x:1240,y:839,t:1527873264968};\\\", \\\"{x:1247,y:851,t:1527873264985};\\\", \\\"{x:1248,y:855,t:1527873265001};\\\", \\\"{x:1249,y:857,t:1527873265018};\\\", \\\"{x:1249,y:856,t:1527873265279};\\\", \\\"{x:1246,y:850,t:1527873265287};\\\", \\\"{x:1245,y:848,t:1527873265302};\\\", \\\"{x:1237,y:837,t:1527873265319};\\\", \\\"{x:1233,y:832,t:1527873265336};\\\", \\\"{x:1232,y:830,t:1527873265353};\\\", \\\"{x:1230,y:827,t:1527873265369};\\\", \\\"{x:1229,y:826,t:1527873265386};\\\", \\\"{x:1230,y:826,t:1527873265583};\\\", \\\"{x:1231,y:826,t:1527873265599};\\\", \\\"{x:1232,y:826,t:1527873265615};\\\", \\\"{x:1233,y:826,t:1527873265623};\\\", \\\"{x:1235,y:827,t:1527873265639};\\\", \\\"{x:1237,y:828,t:1527873265653};\\\", \\\"{x:1242,y:832,t:1527873265670};\\\", \\\"{x:1256,y:837,t:1527873265687};\\\", \\\"{x:1269,y:841,t:1527873265704};\\\", \\\"{x:1285,y:846,t:1527873265720};\\\", \\\"{x:1298,y:849,t:1527873265737};\\\", \\\"{x:1311,y:852,t:1527873265754};\\\", \\\"{x:1325,y:854,t:1527873265771};\\\", \\\"{x:1332,y:855,t:1527873265786};\\\", \\\"{x:1335,y:855,t:1527873265803};\\\", \\\"{x:1337,y:856,t:1527873265821};\\\", \\\"{x:1338,y:856,t:1527873265837};\\\", \\\"{x:1340,y:856,t:1527873265854};\\\", \\\"{x:1343,y:856,t:1527873265871};\\\", \\\"{x:1346,y:856,t:1527873265888};\\\", \\\"{x:1354,y:856,t:1527873265904};\\\", \\\"{x:1362,y:856,t:1527873265920};\\\", \\\"{x:1375,y:855,t:1527873265938};\\\", \\\"{x:1385,y:850,t:1527873265957};\\\", \\\"{x:1400,y:844,t:1527873265971};\\\", \\\"{x:1412,y:839,t:1527873265988};\\\", \\\"{x:1421,y:834,t:1527873266005};\\\", \\\"{x:1428,y:830,t:1527873266021};\\\", \\\"{x:1430,y:828,t:1527873266038};\\\", \\\"{x:1430,y:825,t:1527873266055};\\\", \\\"{x:1430,y:817,t:1527873266071};\\\", \\\"{x:1430,y:804,t:1527873266088};\\\", \\\"{x:1426,y:795,t:1527873266105};\\\", \\\"{x:1420,y:787,t:1527873266122};\\\", \\\"{x:1414,y:779,t:1527873266139};\\\", \\\"{x:1398,y:767,t:1527873266155};\\\", \\\"{x:1382,y:759,t:1527873266172};\\\", \\\"{x:1363,y:749,t:1527873266189};\\\", \\\"{x:1344,y:741,t:1527873266205};\\\", \\\"{x:1321,y:732,t:1527873266222};\\\", \\\"{x:1248,y:711,t:1527873266239};\\\", \\\"{x:1200,y:697,t:1527873266255};\\\", \\\"{x:1160,y:689,t:1527873266272};\\\", \\\"{x:1125,y:680,t:1527873266288};\\\", \\\"{x:1101,y:676,t:1527873266306};\\\", \\\"{x:1082,y:674,t:1527873266321};\\\", \\\"{x:1068,y:671,t:1527873266339};\\\", \\\"{x:1050,y:669,t:1527873266356};\\\", \\\"{x:1029,y:664,t:1527873266372};\\\", \\\"{x:1003,y:659,t:1527873266389};\\\", \\\"{x:952,y:651,t:1527873266406};\\\", \\\"{x:828,y:635,t:1527873266423};\\\", \\\"{x:723,y:621,t:1527873266440};\\\", \\\"{x:584,y:599,t:1527873266457};\\\", \\\"{x:407,y:572,t:1527873266473};\\\", \\\"{x:319,y:572,t:1527873266485};\\\", \\\"{x:128,y:570,t:1527873266503};\\\", \\\"{x:0,y:547,t:1527873266519};\\\", \\\"{x:0,y:531,t:1527873266535};\\\", \\\"{x:0,y:508,t:1527873266552};\\\", \\\"{x:0,y:489,t:1527873266569};\\\", \\\"{x:0,y:473,t:1527873266585};\\\", \\\"{x:0,y:463,t:1527873266602};\\\", \\\"{x:0,y:456,t:1527873266619};\\\", \\\"{x:0,y:452,t:1527873266634};\\\", \\\"{x:0,y:451,t:1527873266652};\\\", \\\"{x:0,y:450,t:1527873266695};\\\", \\\"{x:0,y:449,t:1527873267160};\\\", \\\"{x:0,y:448,t:1527873267170};\\\", \\\"{x:27,y:448,t:1527873267187};\\\", \\\"{x:59,y:448,t:1527873267203};\\\", \\\"{x:124,y:450,t:1527873267220};\\\", \\\"{x:216,y:462,t:1527873267237};\\\", \\\"{x:327,y:480,t:1527873267253};\\\", \\\"{x:436,y:498,t:1527873267270};\\\", \\\"{x:599,y:545,t:1527873267287};\\\", \\\"{x:649,y:563,t:1527873267302};\\\", \\\"{x:741,y:605,t:1527873267319};\\\", \\\"{x:854,y:680,t:1527873267336};\\\", \\\"{x:908,y:729,t:1527873267352};\\\", \\\"{x:936,y:771,t:1527873267369};\\\", \\\"{x:948,y:795,t:1527873267386};\\\", \\\"{x:952,y:811,t:1527873267403};\\\", \\\"{x:952,y:815,t:1527873267418};\\\", \\\"{x:953,y:817,t:1527873267435};\\\", \\\"{x:953,y:820,t:1527873267453};\\\", \\\"{x:955,y:824,t:1527873267469};\\\", \\\"{x:957,y:827,t:1527873267486};\\\", \\\"{x:957,y:828,t:1527873267503};\\\", \\\"{x:961,y:828,t:1527873267559};\\\", \\\"{x:972,y:823,t:1527873267569};\\\", \\\"{x:998,y:813,t:1527873267586};\\\", \\\"{x:1025,y:801,t:1527873267603};\\\", \\\"{x:1063,y:787,t:1527873267620};\\\", \\\"{x:1098,y:773,t:1527873267636};\\\", \\\"{x:1130,y:766,t:1527873267653};\\\", \\\"{x:1175,y:760,t:1527873267670};\\\", \\\"{x:1205,y:755,t:1527873267686};\\\", \\\"{x:1242,y:755,t:1527873267703};\\\", \\\"{x:1263,y:754,t:1527873267720};\\\", \\\"{x:1278,y:753,t:1527873267736};\\\", \\\"{x:1285,y:752,t:1527873267753};\\\", \\\"{x:1290,y:751,t:1527873267771};\\\", \\\"{x:1295,y:750,t:1527873267786};\\\", \\\"{x:1304,y:749,t:1527873267803};\\\", \\\"{x:1312,y:749,t:1527873267820};\\\", \\\"{x:1323,y:749,t:1527873267837};\\\", \\\"{x:1333,y:749,t:1527873267853};\\\", \\\"{x:1336,y:749,t:1527873267871};\\\", \\\"{x:1333,y:751,t:1527873267967};\\\", \\\"{x:1327,y:753,t:1527873267975};\\\", \\\"{x:1317,y:759,t:1527873267987};\\\", \\\"{x:1301,y:764,t:1527873268004};\\\", \\\"{x:1289,y:769,t:1527873268020};\\\", \\\"{x:1277,y:774,t:1527873268037};\\\", \\\"{x:1269,y:777,t:1527873268054};\\\", \\\"{x:1264,y:780,t:1527873268070};\\\", \\\"{x:1259,y:782,t:1527873268087};\\\", \\\"{x:1253,y:786,t:1527873268104};\\\", \\\"{x:1250,y:789,t:1527873268120};\\\", \\\"{x:1247,y:791,t:1527873268137};\\\", \\\"{x:1243,y:793,t:1527873268154};\\\", \\\"{x:1240,y:795,t:1527873268170};\\\", \\\"{x:1239,y:796,t:1527873268187};\\\", \\\"{x:1238,y:796,t:1527873268239};\\\", \\\"{x:1238,y:795,t:1527873268319};\\\", \\\"{x:1238,y:794,t:1527873268327};\\\", \\\"{x:1238,y:792,t:1527873268337};\\\", \\\"{x:1238,y:789,t:1527873268354};\\\", \\\"{x:1239,y:787,t:1527873268371};\\\", \\\"{x:1240,y:786,t:1527873268388};\\\", \\\"{x:1242,y:784,t:1527873268404};\\\", \\\"{x:1243,y:784,t:1527873268431};\\\", \\\"{x:1243,y:783,t:1527873268447};\\\", \\\"{x:1244,y:783,t:1527873268463};\\\", \\\"{x:1245,y:783,t:1527873268502};\\\", \\\"{x:1247,y:783,t:1527873268511};\\\", \\\"{x:1248,y:783,t:1527873268521};\\\", \\\"{x:1255,y:783,t:1527873268538};\\\", \\\"{x:1264,y:783,t:1527873268554};\\\", \\\"{x:1275,y:783,t:1527873268571};\\\", \\\"{x:1285,y:783,t:1527873268588};\\\", \\\"{x:1295,y:781,t:1527873268605};\\\", \\\"{x:1305,y:781,t:1527873268621};\\\", \\\"{x:1310,y:780,t:1527873268638};\\\", \\\"{x:1318,y:777,t:1527873268655};\\\", \\\"{x:1321,y:777,t:1527873268671};\\\", \\\"{x:1327,y:775,t:1527873268688};\\\", \\\"{x:1331,y:773,t:1527873268705};\\\", \\\"{x:1336,y:771,t:1527873268721};\\\", \\\"{x:1339,y:769,t:1527873268738};\\\", \\\"{x:1341,y:768,t:1527873268755};\\\", \\\"{x:1342,y:768,t:1527873268771};\\\", \\\"{x:1344,y:767,t:1527873268935};\\\", \\\"{x:1348,y:766,t:1527873268955};\\\", \\\"{x:1353,y:766,t:1527873268972};\\\", \\\"{x:1363,y:766,t:1527873268989};\\\", \\\"{x:1371,y:766,t:1527873269005};\\\", \\\"{x:1380,y:766,t:1527873269022};\\\", \\\"{x:1391,y:766,t:1527873269039};\\\", \\\"{x:1396,y:766,t:1527873269055};\\\", \\\"{x:1399,y:766,t:1527873269072};\\\", \\\"{x:1402,y:766,t:1527873269089};\\\", \\\"{x:1404,y:766,t:1527873269105};\\\", \\\"{x:1409,y:766,t:1527873269122};\\\", \\\"{x:1412,y:766,t:1527873269138};\\\", \\\"{x:1415,y:766,t:1527873269156};\\\", \\\"{x:1417,y:766,t:1527873269172};\\\", \\\"{x:1419,y:766,t:1527873269189};\\\", \\\"{x:1423,y:766,t:1527873269206};\\\", \\\"{x:1430,y:766,t:1527873269222};\\\", \\\"{x:1441,y:766,t:1527873269239};\\\", \\\"{x:1445,y:766,t:1527873269256};\\\", \\\"{x:1445,y:765,t:1527873269655};\\\", \\\"{x:1445,y:764,t:1527873269664};\\\", \\\"{x:1441,y:763,t:1527873269673};\\\", \\\"{x:1438,y:762,t:1527873269690};\\\", \\\"{x:1431,y:761,t:1527873269706};\\\", \\\"{x:1420,y:757,t:1527873269723};\\\", \\\"{x:1407,y:753,t:1527873269740};\\\", \\\"{x:1392,y:748,t:1527873269757};\\\", \\\"{x:1381,y:746,t:1527873269773};\\\", \\\"{x:1375,y:744,t:1527873269790};\\\", \\\"{x:1370,y:742,t:1527873269807};\\\", \\\"{x:1368,y:742,t:1527873269823};\\\", \\\"{x:1365,y:741,t:1527873269840};\\\", \\\"{x:1365,y:740,t:1527873269857};\\\", \\\"{x:1363,y:740,t:1527873269975};\\\", \\\"{x:1359,y:740,t:1527873269990};\\\", \\\"{x:1338,y:740,t:1527873270007};\\\", \\\"{x:1316,y:740,t:1527873270024};\\\", \\\"{x:1293,y:740,t:1527873270040};\\\", \\\"{x:1271,y:740,t:1527873270057};\\\", \\\"{x:1252,y:740,t:1527873270074};\\\", \\\"{x:1242,y:740,t:1527873270090};\\\", \\\"{x:1236,y:740,t:1527873270108};\\\", \\\"{x:1232,y:740,t:1527873270124};\\\", \\\"{x:1228,y:740,t:1527873270141};\\\", \\\"{x:1225,y:740,t:1527873270157};\\\", \\\"{x:1222,y:740,t:1527873270174};\\\", \\\"{x:1217,y:740,t:1527873270191};\\\", \\\"{x:1215,y:740,t:1527873270207};\\\", \\\"{x:1211,y:740,t:1527873270224};\\\", \\\"{x:1203,y:740,t:1527873270241};\\\", \\\"{x:1192,y:740,t:1527873270257};\\\", \\\"{x:1187,y:740,t:1527873270274};\\\", \\\"{x:1183,y:740,t:1527873270291};\\\", \\\"{x:1180,y:740,t:1527873270307};\\\", \\\"{x:1178,y:740,t:1527873270324};\\\", \\\"{x:1176,y:740,t:1527873270341};\\\", \\\"{x:1175,y:740,t:1527873270358};\\\", \\\"{x:1173,y:740,t:1527873270375};\\\", \\\"{x:1172,y:740,t:1527873270391};\\\", \\\"{x:1170,y:740,t:1527873270408};\\\", \\\"{x:1166,y:740,t:1527873270424};\\\", \\\"{x:1159,y:740,t:1527873270441};\\\", \\\"{x:1150,y:742,t:1527873270458};\\\", \\\"{x:1141,y:744,t:1527873270474};\\\", \\\"{x:1135,y:745,t:1527873270491};\\\", \\\"{x:1128,y:745,t:1527873270508};\\\", \\\"{x:1123,y:746,t:1527873270526};\\\", \\\"{x:1120,y:748,t:1527873270541};\\\", \\\"{x:1118,y:748,t:1527873270559};\\\", \\\"{x:1119,y:753,t:1527873270726};\\\", \\\"{x:1120,y:757,t:1527873270741};\\\", \\\"{x:1126,y:764,t:1527873270758};\\\", \\\"{x:1134,y:773,t:1527873270775};\\\", \\\"{x:1137,y:776,t:1527873270792};\\\", \\\"{x:1140,y:778,t:1527873270808};\\\", \\\"{x:1142,y:779,t:1527873270824};\\\", \\\"{x:1144,y:779,t:1527873270842};\\\", \\\"{x:1145,y:779,t:1527873270858};\\\", \\\"{x:1148,y:779,t:1527873270875};\\\", \\\"{x:1152,y:779,t:1527873270892};\\\", \\\"{x:1161,y:778,t:1527873270909};\\\", \\\"{x:1169,y:772,t:1527873270925};\\\", \\\"{x:1182,y:763,t:1527873270942};\\\", \\\"{x:1196,y:751,t:1527873270959};\\\", \\\"{x:1202,y:746,t:1527873270974};\\\", \\\"{x:1204,y:743,t:1527873270992};\\\", \\\"{x:1204,y:741,t:1527873271009};\\\", \\\"{x:1206,y:739,t:1527873271025};\\\", \\\"{x:1207,y:738,t:1527873271086};\\\", \\\"{x:1211,y:738,t:1527873271184};\\\", \\\"{x:1212,y:741,t:1527873271192};\\\", \\\"{x:1217,y:743,t:1527873271210};\\\", \\\"{x:1219,y:745,t:1527873271226};\\\", \\\"{x:1223,y:747,t:1527873271242};\\\", \\\"{x:1226,y:749,t:1527873271259};\\\", \\\"{x:1229,y:750,t:1527873271277};\\\", \\\"{x:1230,y:750,t:1527873271328};\\\", \\\"{x:1231,y:750,t:1527873271344};\\\", \\\"{x:1232,y:750,t:1527873271360};\\\", \\\"{x:1235,y:750,t:1527873271377};\\\", \\\"{x:1236,y:750,t:1527873271394};\\\", \\\"{x:1238,y:750,t:1527873271409};\\\", \\\"{x:1239,y:750,t:1527873271448};\\\", \\\"{x:1241,y:752,t:1527873271460};\\\", \\\"{x:1245,y:757,t:1527873271476};\\\", \\\"{x:1248,y:761,t:1527873271493};\\\", \\\"{x:1249,y:763,t:1527873271511};\\\", \\\"{x:1250,y:764,t:1527873271526};\\\", \\\"{x:1251,y:765,t:1527873271543};\\\", \\\"{x:1252,y:766,t:1527873271560};\\\", \\\"{x:1254,y:766,t:1527873271881};\\\", \\\"{x:1255,y:766,t:1527873271895};\\\", \\\"{x:1256,y:766,t:1527873271911};\\\", \\\"{x:1258,y:765,t:1527873271927};\\\", \\\"{x:1258,y:764,t:1527873271945};\\\", \\\"{x:1258,y:763,t:1527873272128};\\\", \\\"{x:1256,y:763,t:1527873272151};\\\", \\\"{x:1255,y:764,t:1527873272168};\\\", \\\"{x:1254,y:764,t:1527873272184};\\\", \\\"{x:1253,y:764,t:1527873272241};\\\", \\\"{x:1252,y:764,t:1527873272304};\\\", \\\"{x:1251,y:764,t:1527873272319};\\\", \\\"{x:1250,y:764,t:1527873272392};\\\", \\\"{x:1249,y:765,t:1527873272464};\\\", \\\"{x:1247,y:767,t:1527873272480};\\\", \\\"{x:1239,y:770,t:1527873272496};\\\", \\\"{x:1236,y:771,t:1527873272512};\\\", \\\"{x:1232,y:772,t:1527873272528};\\\", \\\"{x:1228,y:774,t:1527873272546};\\\", \\\"{x:1226,y:774,t:1527873272562};\\\", \\\"{x:1223,y:774,t:1527873272579};\\\", \\\"{x:1216,y:774,t:1527873272596};\\\", \\\"{x:1208,y:774,t:1527873272612};\\\", \\\"{x:1202,y:774,t:1527873272628};\\\", \\\"{x:1196,y:774,t:1527873272646};\\\", \\\"{x:1192,y:774,t:1527873272665};\\\", \\\"{x:1190,y:774,t:1527873272687};\\\", \\\"{x:1189,y:773,t:1527873272768};\\\", \\\"{x:1187,y:772,t:1527873272784};\\\", \\\"{x:1185,y:770,t:1527873272796};\\\", \\\"{x:1183,y:769,t:1527873272813};\\\", \\\"{x:1182,y:769,t:1527873272829};\\\", \\\"{x:1182,y:768,t:1527873272847};\\\", \\\"{x:1181,y:765,t:1527873272864};\\\", \\\"{x:1181,y:764,t:1527873272880};\\\", \\\"{x:1181,y:763,t:1527873272895};\\\", \\\"{x:1181,y:762,t:1527873272913};\\\", \\\"{x:1181,y:761,t:1527873272944};\\\", \\\"{x:1180,y:761,t:1527873273721};\\\", \\\"{x:1179,y:765,t:1527873273731};\\\", \\\"{x:1179,y:779,t:1527873273749};\\\", \\\"{x:1179,y:792,t:1527873273764};\\\", \\\"{x:1179,y:805,t:1527873273781};\\\", \\\"{x:1179,y:817,t:1527873273798};\\\", \\\"{x:1180,y:823,t:1527873273815};\\\", \\\"{x:1183,y:830,t:1527873273831};\\\", \\\"{x:1184,y:834,t:1527873273848};\\\", \\\"{x:1184,y:835,t:1527873273865};\\\", \\\"{x:1184,y:829,t:1527873274032};\\\", \\\"{x:1182,y:816,t:1527873274048};\\\", \\\"{x:1181,y:808,t:1527873274065};\\\", \\\"{x:1180,y:799,t:1527873274082};\\\", \\\"{x:1179,y:791,t:1527873274098};\\\", \\\"{x:1178,y:786,t:1527873274115};\\\", \\\"{x:1177,y:777,t:1527873274132};\\\", \\\"{x:1177,y:771,t:1527873274148};\\\", \\\"{x:1177,y:766,t:1527873274165};\\\", \\\"{x:1177,y:761,t:1527873274182};\\\", \\\"{x:1176,y:759,t:1527873274200};\\\", \\\"{x:1176,y:756,t:1527873274215};\\\", \\\"{x:1175,y:755,t:1527873274232};\\\", \\\"{x:1175,y:756,t:1527873274568};\\\", \\\"{x:1175,y:757,t:1527873274582};\\\", \\\"{x:1175,y:759,t:1527873274599};\\\", \\\"{x:1175,y:760,t:1527873274615};\\\", \\\"{x:1175,y:761,t:1527873274640};\\\", \\\"{x:1175,y:762,t:1527873274688};\\\", \\\"{x:1175,y:763,t:1527873274704};\\\", \\\"{x:1175,y:764,t:1527873274866};\\\", \\\"{x:1175,y:769,t:1527873275992};\\\", \\\"{x:1175,y:782,t:1527873276002};\\\", \\\"{x:1178,y:801,t:1527873276018};\\\", \\\"{x:1179,y:816,t:1527873276035};\\\", \\\"{x:1180,y:832,t:1527873276052};\\\", \\\"{x:1185,y:852,t:1527873276068};\\\", \\\"{x:1186,y:869,t:1527873276085};\\\", \\\"{x:1186,y:891,t:1527873276102};\\\", \\\"{x:1186,y:910,t:1527873276118};\\\", \\\"{x:1186,y:929,t:1527873276135};\\\", \\\"{x:1185,y:949,t:1527873276152};\\\", \\\"{x:1183,y:959,t:1527873276169};\\\", \\\"{x:1181,y:963,t:1527873276185};\\\", \\\"{x:1180,y:966,t:1527873276202};\\\", \\\"{x:1179,y:968,t:1527873276219};\\\", \\\"{x:1179,y:969,t:1527873276235};\\\", \\\"{x:1179,y:971,t:1527873276344};\\\", \\\"{x:1179,y:974,t:1527873276352};\\\", \\\"{x:1177,y:975,t:1527873276368};\\\", \\\"{x:1177,y:976,t:1527873276385};\\\", \\\"{x:1176,y:976,t:1527873276608};\\\", \\\"{x:1175,y:974,t:1527873276618};\\\", \\\"{x:1174,y:967,t:1527873276635};\\\", \\\"{x:1174,y:963,t:1527873276653};\\\", \\\"{x:1173,y:960,t:1527873276670};\\\", \\\"{x:1173,y:953,t:1527873276686};\\\", \\\"{x:1173,y:947,t:1527873276703};\\\", \\\"{x:1173,y:942,t:1527873276720};\\\", \\\"{x:1173,y:937,t:1527873276735};\\\", \\\"{x:1173,y:933,t:1527873276753};\\\", \\\"{x:1173,y:929,t:1527873276769};\\\", \\\"{x:1173,y:926,t:1527873276786};\\\", \\\"{x:1173,y:925,t:1527873276803};\\\", \\\"{x:1173,y:927,t:1527873276920};\\\", \\\"{x:1173,y:934,t:1527873276937};\\\", \\\"{x:1173,y:938,t:1527873276953};\\\", \\\"{x:1174,y:941,t:1527873276970};\\\", \\\"{x:1174,y:944,t:1527873276987};\\\", \\\"{x:1175,y:948,t:1527873277003};\\\", \\\"{x:1175,y:952,t:1527873277020};\\\", \\\"{x:1176,y:955,t:1527873277037};\\\", \\\"{x:1177,y:957,t:1527873277053};\\\", \\\"{x:1177,y:959,t:1527873277070};\\\", \\\"{x:1177,y:960,t:1527873277128};\\\", \\\"{x:1178,y:961,t:1527873277143};\\\", \\\"{x:1179,y:962,t:1527873277424};\\\", \\\"{x:1180,y:962,t:1527873277455};\\\", \\\"{x:1180,y:963,t:1527873277521};\\\", \\\"{x:1181,y:963,t:1527873277584};\\\", \\\"{x:1181,y:964,t:1527873277592};\\\", \\\"{x:1181,y:965,t:1527873277616};\\\", \\\"{x:1182,y:965,t:1527873277623};\\\", \\\"{x:1183,y:966,t:1527873277638};\\\", \\\"{x:1183,y:967,t:1527873277654};\\\", \\\"{x:1184,y:968,t:1527873277680};\\\", \\\"{x:1184,y:969,t:1527873277760};\\\", \\\"{x:1184,y:970,t:1527873277775};\\\", \\\"{x:1185,y:971,t:1527873278680};\\\", \\\"{x:1186,y:971,t:1527873278690};\\\", \\\"{x:1192,y:971,t:1527873278706};\\\", \\\"{x:1199,y:971,t:1527873278723};\\\", \\\"{x:1202,y:971,t:1527873278740};\\\", \\\"{x:1207,y:971,t:1527873278756};\\\", \\\"{x:1212,y:971,t:1527873278773};\\\", \\\"{x:1216,y:971,t:1527873278790};\\\", \\\"{x:1220,y:971,t:1527873278806};\\\", \\\"{x:1224,y:971,t:1527873278823};\\\", \\\"{x:1230,y:971,t:1527873278839};\\\", \\\"{x:1233,y:971,t:1527873278857};\\\", \\\"{x:1234,y:971,t:1527873278873};\\\", \\\"{x:1236,y:971,t:1527873278891};\\\", \\\"{x:1237,y:971,t:1527873278920};\\\", \\\"{x:1240,y:971,t:1527873278936};\\\", \\\"{x:1242,y:971,t:1527873278944};\\\", \\\"{x:1245,y:971,t:1527873278956};\\\", \\\"{x:1247,y:971,t:1527873278973};\\\", \\\"{x:1251,y:971,t:1527873278990};\\\", \\\"{x:1252,y:971,t:1527873279007};\\\", \\\"{x:1254,y:971,t:1527873279023};\\\", \\\"{x:1256,y:971,t:1527873279040};\\\", \\\"{x:1257,y:971,t:1527873279057};\\\", \\\"{x:1259,y:971,t:1527873279074};\\\", \\\"{x:1260,y:971,t:1527873279090};\\\", \\\"{x:1262,y:971,t:1527873279107};\\\", \\\"{x:1265,y:971,t:1527873279124};\\\", \\\"{x:1266,y:971,t:1527873279140};\\\", \\\"{x:1267,y:971,t:1527873279156};\\\", \\\"{x:1263,y:971,t:1527873279456};\\\", \\\"{x:1261,y:971,t:1527873279466};\\\", \\\"{x:1259,y:971,t:1527873279474};\\\", \\\"{x:1255,y:971,t:1527873279491};\\\", \\\"{x:1252,y:971,t:1527873279508};\\\", \\\"{x:1251,y:970,t:1527873279524};\\\", \\\"{x:1250,y:970,t:1527873279648};\\\", \\\"{x:1249,y:970,t:1527873279658};\\\", \\\"{x:1248,y:970,t:1527873279675};\\\", \\\"{x:1247,y:970,t:1527873279691};\\\", \\\"{x:1250,y:970,t:1527873280248};\\\", \\\"{x:1258,y:970,t:1527873280260};\\\", \\\"{x:1273,y:971,t:1527873280276};\\\", \\\"{x:1286,y:973,t:1527873280292};\\\", \\\"{x:1297,y:975,t:1527873280309};\\\", \\\"{x:1303,y:976,t:1527873280326};\\\", \\\"{x:1307,y:976,t:1527873280342};\\\", \\\"{x:1311,y:976,t:1527873280360};\\\", \\\"{x:1316,y:976,t:1527873280376};\\\", \\\"{x:1317,y:976,t:1527873280392};\\\", \\\"{x:1322,y:976,t:1527873280409};\\\", \\\"{x:1326,y:976,t:1527873280426};\\\", \\\"{x:1331,y:976,t:1527873280444};\\\", \\\"{x:1336,y:976,t:1527873280459};\\\", \\\"{x:1341,y:976,t:1527873280476};\\\", \\\"{x:1345,y:976,t:1527873280493};\\\", \\\"{x:1346,y:976,t:1527873280509};\\\", \\\"{x:1348,y:976,t:1527873280526};\\\", \\\"{x:1350,y:978,t:1527873280736};\\\", \\\"{x:1343,y:978,t:1527873280760};\\\", \\\"{x:1327,y:978,t:1527873280778};\\\", \\\"{x:1313,y:978,t:1527873280793};\\\", \\\"{x:1301,y:978,t:1527873280810};\\\", \\\"{x:1298,y:978,t:1527873280827};\\\", \\\"{x:1297,y:978,t:1527873280843};\\\", \\\"{x:1298,y:977,t:1527873281008};\\\", \\\"{x:1300,y:976,t:1527873281016};\\\", \\\"{x:1305,y:975,t:1527873281028};\\\", \\\"{x:1312,y:974,t:1527873281044};\\\", \\\"{x:1320,y:974,t:1527873281060};\\\", \\\"{x:1330,y:974,t:1527873281078};\\\", \\\"{x:1339,y:974,t:1527873281094};\\\", \\\"{x:1342,y:974,t:1527873281110};\\\", \\\"{x:1343,y:974,t:1527873281127};\\\", \\\"{x:1343,y:971,t:1527873281344};\\\", \\\"{x:1340,y:966,t:1527873281362};\\\", \\\"{x:1332,y:957,t:1527873281378};\\\", \\\"{x:1323,y:948,t:1527873281394};\\\", \\\"{x:1304,y:934,t:1527873281411};\\\", \\\"{x:1283,y:916,t:1527873281429};\\\", \\\"{x:1254,y:891,t:1527873281444};\\\", \\\"{x:1213,y:856,t:1527873281461};\\\", \\\"{x:1183,y:832,t:1527873281478};\\\", \\\"{x:1165,y:812,t:1527873281493};\\\", \\\"{x:1139,y:787,t:1527873281510};\\\", \\\"{x:1133,y:781,t:1527873281528};\\\", \\\"{x:1128,y:775,t:1527873281543};\\\", \\\"{x:1123,y:769,t:1527873281561};\\\", \\\"{x:1119,y:763,t:1527873281578};\\\", \\\"{x:1116,y:757,t:1527873281595};\\\", \\\"{x:1112,y:751,t:1527873281611};\\\", \\\"{x:1111,y:747,t:1527873281627};\\\", \\\"{x:1109,y:744,t:1527873281644};\\\", \\\"{x:1107,y:741,t:1527873281661};\\\", \\\"{x:1106,y:740,t:1527873281677};\\\", \\\"{x:1104,y:740,t:1527873282191};\\\", \\\"{x:1096,y:739,t:1527873282199};\\\", \\\"{x:1080,y:735,t:1527873282212};\\\", \\\"{x:1029,y:724,t:1527873282229};\\\", \\\"{x:959,y:702,t:1527873282246};\\\", \\\"{x:840,y:671,t:1527873282262};\\\", \\\"{x:674,y:638,t:1527873282279};\\\", \\\"{x:615,y:630,t:1527873282296};\\\", \\\"{x:586,y:625,t:1527873282313};\\\", \\\"{x:569,y:624,t:1527873282328};\\\", \\\"{x:564,y:624,t:1527873282347};\\\", \\\"{x:563,y:624,t:1527873282363};\\\", \\\"{x:562,y:624,t:1527873282431};\\\", \\\"{x:561,y:626,t:1527873282447};\\\", \\\"{x:559,y:630,t:1527873282464};\\\", \\\"{x:557,y:636,t:1527873282481};\\\", \\\"{x:551,y:646,t:1527873282497};\\\", \\\"{x:546,y:656,t:1527873282515};\\\", \\\"{x:545,y:661,t:1527873282532};\\\", \\\"{x:544,y:662,t:1527873282547};\\\", \\\"{x:542,y:665,t:1527873282565};\\\", \\\"{x:542,y:666,t:1527873282632};\\\", \\\"{x:541,y:672,t:1527873282648};\\\", \\\"{x:540,y:680,t:1527873282665};\\\", \\\"{x:538,y:689,t:1527873282682};\\\", \\\"{x:537,y:701,t:1527873282698};\\\", \\\"{x:537,y:710,t:1527873282715};\\\", \\\"{x:537,y:717,t:1527873282732};\\\", \\\"{x:536,y:722,t:1527873282749};\\\", \\\"{x:536,y:724,t:1527873282765};\\\", \\\"{x:534,y:728,t:1527873282781};\\\", \\\"{x:534,y:732,t:1527873282799};\\\", \\\"{x:534,y:735,t:1527873282814};\\\", \\\"{x:534,y:736,t:1527873282831};\\\", \\\"{x:533,y:738,t:1527873282849};\\\", \\\"{x:533,y:740,t:1527873282879};\\\" ] }, { \\\"rt\\\": 35083, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 504605, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -12 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:735,t:1527873285207};\\\", \\\"{x:530,y:720,t:1527873285216};\\\", \\\"{x:530,y:697,t:1527873285233};\\\", \\\"{x:537,y:614,t:1527873285309};\\\", \\\"{x:540,y:607,t:1527873285317};\\\", \\\"{x:541,y:594,t:1527873285334};\\\", \\\"{x:543,y:582,t:1527873285350};\\\", \\\"{x:545,y:575,t:1527873285366};\\\", \\\"{x:545,y:572,t:1527873285383};\\\", \\\"{x:546,y:571,t:1527873285400};\\\", \\\"{x:546,y:569,t:1527873285417};\\\", \\\"{x:548,y:565,t:1527873285434};\\\", \\\"{x:548,y:563,t:1527873285451};\\\", \\\"{x:551,y:558,t:1527873285467};\\\", \\\"{x:553,y:555,t:1527873285484};\\\", \\\"{x:554,y:553,t:1527873285500};\\\", \\\"{x:556,y:550,t:1527873285518};\\\", \\\"{x:557,y:549,t:1527873286407};\\\", \\\"{x:565,y:546,t:1527873286419};\\\", \\\"{x:669,y:517,t:1527873286436};\\\", \\\"{x:826,y:473,t:1527873286453};\\\", \\\"{x:1000,y:450,t:1527873286467};\\\", \\\"{x:1129,y:438,t:1527873286485};\\\", \\\"{x:1216,y:434,t:1527873286501};\\\", \\\"{x:1262,y:431,t:1527873286517};\\\", \\\"{x:1358,y:429,t:1527873286534};\\\", \\\"{x:1403,y:422,t:1527873286552};\\\", \\\"{x:1428,y:412,t:1527873286567};\\\", \\\"{x:1441,y:407,t:1527873286585};\\\", \\\"{x:1448,y:403,t:1527873286602};\\\", \\\"{x:1451,y:402,t:1527873286619};\\\", \\\"{x:1452,y:402,t:1527873286635};\\\", \\\"{x:1453,y:401,t:1527873286679};\\\", \\\"{x:1450,y:401,t:1527873289616};\\\", \\\"{x:1449,y:401,t:1527873289630};\\\", \\\"{x:1446,y:403,t:1527873289646};\\\", \\\"{x:1444,y:403,t:1527873289662};\\\", \\\"{x:1443,y:404,t:1527873289720};\\\", \\\"{x:1440,y:404,t:1527873291176};\\\", \\\"{x:1424,y:409,t:1527873291184};\\\", \\\"{x:1368,y:436,t:1527873291202};\\\", \\\"{x:1313,y:457,t:1527873291218};\\\", \\\"{x:1221,y:473,t:1527873291234};\\\", \\\"{x:1123,y:493,t:1527873291252};\\\", \\\"{x:1020,y:508,t:1527873291268};\\\", \\\"{x:936,y:519,t:1527873291286};\\\", \\\"{x:876,y:525,t:1527873291302};\\\", \\\"{x:810,y:525,t:1527873291318};\\\", \\\"{x:715,y:525,t:1527873291334};\\\", \\\"{x:659,y:525,t:1527873291354};\\\", \\\"{x:624,y:525,t:1527873291372};\\\", \\\"{x:595,y:525,t:1527873291389};\\\", \\\"{x:566,y:525,t:1527873291405};\\\", \\\"{x:538,y:525,t:1527873291421};\\\", \\\"{x:503,y:524,t:1527873291439};\\\", \\\"{x:493,y:520,t:1527873291454};\\\", \\\"{x:490,y:519,t:1527873291472};\\\", \\\"{x:490,y:517,t:1527873291696};\\\", \\\"{x:489,y:512,t:1527873291704};\\\", \\\"{x:487,y:508,t:1527873291722};\\\", \\\"{x:487,y:507,t:1527873291739};\\\", \\\"{x:486,y:505,t:1527873291755};\\\", \\\"{x:486,y:504,t:1527873291782};\\\", \\\"{x:486,y:503,t:1527873291814};\\\", \\\"{x:485,y:502,t:1527873291822};\\\", \\\"{x:485,y:501,t:1527873291847};\\\", \\\"{x:484,y:501,t:1527873291855};\\\", \\\"{x:484,y:500,t:1527873291871};\\\", \\\"{x:483,y:500,t:1527873291889};\\\", \\\"{x:483,y:499,t:1527873291906};\\\", \\\"{x:483,y:497,t:1527873291922};\\\", \\\"{x:482,y:497,t:1527873291939};\\\", \\\"{x:481,y:495,t:1527873291956};\\\", \\\"{x:479,y:493,t:1527873291972};\\\", \\\"{x:478,y:491,t:1527873291989};\\\", \\\"{x:474,y:485,t:1527873292006};\\\", \\\"{x:470,y:481,t:1527873292022};\\\", \\\"{x:466,y:476,t:1527873292039};\\\", \\\"{x:463,y:474,t:1527873292056};\\\", \\\"{x:461,y:472,t:1527873292072};\\\", \\\"{x:457,y:469,t:1527873292089};\\\", \\\"{x:454,y:468,t:1527873292106};\\\", \\\"{x:452,y:466,t:1527873292122};\\\", \\\"{x:450,y:465,t:1527873292139};\\\", \\\"{x:447,y:463,t:1527873292156};\\\", \\\"{x:445,y:462,t:1527873292172};\\\", \\\"{x:443,y:461,t:1527873292190};\\\", \\\"{x:441,y:460,t:1527873292206};\\\", \\\"{x:437,y:459,t:1527873292222};\\\", \\\"{x:435,y:459,t:1527873292239};\\\", \\\"{x:433,y:458,t:1527873292256};\\\", \\\"{x:433,y:457,t:1527873292272};\\\", \\\"{x:442,y:457,t:1527873294119};\\\", \\\"{x:472,y:450,t:1527873294127};\\\", \\\"{x:517,y:446,t:1527873294140};\\\", \\\"{x:612,y:446,t:1527873294158};\\\", \\\"{x:692,y:446,t:1527873294174};\\\", \\\"{x:745,y:446,t:1527873294191};\\\", \\\"{x:805,y:446,t:1527873294207};\\\", \\\"{x:841,y:446,t:1527873294224};\\\", \\\"{x:885,y:452,t:1527873294242};\\\", \\\"{x:957,y:471,t:1527873294258};\\\", \\\"{x:1028,y:495,t:1527873294274};\\\", \\\"{x:1080,y:518,t:1527873294291};\\\", \\\"{x:1131,y:544,t:1527873294307};\\\", \\\"{x:1170,y:561,t:1527873294324};\\\", \\\"{x:1205,y:581,t:1527873294341};\\\", \\\"{x:1229,y:598,t:1527873294357};\\\", \\\"{x:1247,y:611,t:1527873294374};\\\", \\\"{x:1260,y:624,t:1527873294391};\\\", \\\"{x:1262,y:630,t:1527873294407};\\\", \\\"{x:1264,y:636,t:1527873294424};\\\", \\\"{x:1266,y:648,t:1527873294441};\\\", \\\"{x:1271,y:669,t:1527873294457};\\\", \\\"{x:1277,y:694,t:1527873294474};\\\", \\\"{x:1282,y:719,t:1527873294491};\\\", \\\"{x:1286,y:741,t:1527873294507};\\\", \\\"{x:1286,y:755,t:1527873294524};\\\", \\\"{x:1286,y:763,t:1527873294542};\\\", \\\"{x:1286,y:766,t:1527873294557};\\\", \\\"{x:1283,y:771,t:1527873294574};\\\", \\\"{x:1278,y:779,t:1527873294591};\\\", \\\"{x:1273,y:789,t:1527873294607};\\\", \\\"{x:1268,y:804,t:1527873294624};\\\", \\\"{x:1261,y:815,t:1527873294641};\\\", \\\"{x:1257,y:822,t:1527873294657};\\\", \\\"{x:1253,y:826,t:1527873294680};\\\", \\\"{x:1250,y:830,t:1527873294698};\\\", \\\"{x:1248,y:832,t:1527873294715};\\\", \\\"{x:1247,y:833,t:1527873294730};\\\", \\\"{x:1245,y:834,t:1527873294747};\\\", \\\"{x:1244,y:835,t:1527873294765};\\\", \\\"{x:1243,y:835,t:1527873294781};\\\", \\\"{x:1240,y:837,t:1527873294797};\\\", \\\"{x:1238,y:838,t:1527873294822};\\\", \\\"{x:1237,y:838,t:1527873294845};\\\", \\\"{x:1236,y:839,t:1527873294853};\\\", \\\"{x:1235,y:839,t:1527873294876};\\\", \\\"{x:1234,y:839,t:1527873294892};\\\", \\\"{x:1233,y:839,t:1527873294900};\\\", \\\"{x:1232,y:839,t:1527873294913};\\\", \\\"{x:1231,y:840,t:1527873295382};\\\", \\\"{x:1226,y:844,t:1527873295398};\\\", \\\"{x:1221,y:846,t:1527873295414};\\\", \\\"{x:1220,y:847,t:1527873295432};\\\", \\\"{x:1217,y:848,t:1527873295448};\\\", \\\"{x:1216,y:850,t:1527873296165};\\\", \\\"{x:1208,y:856,t:1527873296182};\\\", \\\"{x:1204,y:858,t:1527873296199};\\\", \\\"{x:1202,y:859,t:1527873296216};\\\", \\\"{x:1201,y:859,t:1527873296406};\\\", \\\"{x:1202,y:856,t:1527873296421};\\\", \\\"{x:1202,y:854,t:1527873296437};\\\", \\\"{x:1203,y:853,t:1527873296448};\\\", \\\"{x:1203,y:852,t:1527873296465};\\\", \\\"{x:1204,y:850,t:1527873296481};\\\", \\\"{x:1204,y:848,t:1527873296499};\\\", \\\"{x:1205,y:846,t:1527873296515};\\\", \\\"{x:1205,y:845,t:1527873296531};\\\", \\\"{x:1206,y:843,t:1527873296548};\\\", \\\"{x:1206,y:842,t:1527873296564};\\\", \\\"{x:1206,y:841,t:1527873296588};\\\", \\\"{x:1206,y:840,t:1527873296598};\\\", \\\"{x:1207,y:839,t:1527873296620};\\\", \\\"{x:1208,y:838,t:1527873296632};\\\", \\\"{x:1208,y:837,t:1527873296648};\\\", \\\"{x:1208,y:836,t:1527873296665};\\\", \\\"{x:1208,y:834,t:1527873296682};\\\", \\\"{x:1208,y:833,t:1527873296698};\\\", \\\"{x:1208,y:831,t:1527873296715};\\\", \\\"{x:1209,y:830,t:1527873296732};\\\", \\\"{x:1209,y:828,t:1527873296748};\\\", \\\"{x:1209,y:825,t:1527873296765};\\\", \\\"{x:1209,y:824,t:1527873296782};\\\", \\\"{x:1210,y:823,t:1527873304166};\\\", \\\"{x:1211,y:819,t:1527873304340};\\\", \\\"{x:1211,y:816,t:1527873304354};\\\", \\\"{x:1211,y:809,t:1527873304370};\\\", \\\"{x:1210,y:804,t:1527873304387};\\\", \\\"{x:1208,y:798,t:1527873304404};\\\", \\\"{x:1207,y:796,t:1527873304420};\\\", \\\"{x:1207,y:795,t:1527873304437};\\\", \\\"{x:1206,y:794,t:1527873304454};\\\", \\\"{x:1206,y:792,t:1527873304470};\\\", \\\"{x:1206,y:790,t:1527873304487};\\\", \\\"{x:1206,y:786,t:1527873304504};\\\", \\\"{x:1204,y:783,t:1527873304520};\\\", \\\"{x:1204,y:782,t:1527873304537};\\\", \\\"{x:1203,y:779,t:1527873304554};\\\", \\\"{x:1202,y:776,t:1527873304570};\\\", \\\"{x:1201,y:774,t:1527873304587};\\\", \\\"{x:1200,y:772,t:1527873304604};\\\", \\\"{x:1199,y:772,t:1527873304620};\\\", \\\"{x:1198,y:771,t:1527873304637};\\\", \\\"{x:1196,y:770,t:1527873304655};\\\", \\\"{x:1195,y:769,t:1527873304672};\\\", \\\"{x:1193,y:769,t:1527873304687};\\\", \\\"{x:1187,y:769,t:1527873304704};\\\", \\\"{x:1185,y:769,t:1527873304722};\\\", \\\"{x:1184,y:769,t:1527873304757};\\\", \\\"{x:1182,y:769,t:1527873306262};\\\", \\\"{x:1180,y:769,t:1527873306273};\\\", \\\"{x:1180,y:768,t:1527873306289};\\\", \\\"{x:1179,y:768,t:1527873306306};\\\", \\\"{x:1178,y:767,t:1527873306323};\\\", \\\"{x:1178,y:768,t:1527873311229};\\\", \\\"{x:1176,y:782,t:1527873311244};\\\", \\\"{x:1173,y:802,t:1527873311260};\\\", \\\"{x:1172,y:820,t:1527873311276};\\\", \\\"{x:1171,y:835,t:1527873311292};\\\", \\\"{x:1169,y:842,t:1527873311310};\\\", \\\"{x:1169,y:852,t:1527873311326};\\\", \\\"{x:1169,y:866,t:1527873311343};\\\", \\\"{x:1169,y:881,t:1527873311360};\\\", \\\"{x:1169,y:891,t:1527873311376};\\\", \\\"{x:1169,y:898,t:1527873311393};\\\", \\\"{x:1169,y:906,t:1527873311410};\\\", \\\"{x:1170,y:916,t:1527873311426};\\\", \\\"{x:1170,y:926,t:1527873311443};\\\", \\\"{x:1172,y:934,t:1527873311460};\\\", \\\"{x:1173,y:939,t:1527873311476};\\\", \\\"{x:1173,y:944,t:1527873311493};\\\", \\\"{x:1174,y:948,t:1527873311510};\\\", \\\"{x:1174,y:949,t:1527873311526};\\\", \\\"{x:1174,y:951,t:1527873311542};\\\", \\\"{x:1174,y:954,t:1527873311559};\\\", \\\"{x:1174,y:956,t:1527873311575};\\\", \\\"{x:1174,y:958,t:1527873311592};\\\", \\\"{x:1174,y:961,t:1527873311609};\\\", \\\"{x:1174,y:962,t:1527873311625};\\\", \\\"{x:1174,y:963,t:1527873311643};\\\", \\\"{x:1174,y:964,t:1527873311684};\\\", \\\"{x:1175,y:964,t:1527873312350};\\\", \\\"{x:1176,y:964,t:1527873312360};\\\", \\\"{x:1178,y:964,t:1527873312377};\\\", \\\"{x:1180,y:964,t:1527873312394};\\\", \\\"{x:1181,y:965,t:1527873312421};\\\", \\\"{x:1182,y:965,t:1527873312445};\\\", \\\"{x:1183,y:966,t:1527873312525};\\\", \\\"{x:1191,y:966,t:1527873313325};\\\", \\\"{x:1196,y:966,t:1527873313333};\\\", \\\"{x:1206,y:966,t:1527873313344};\\\", \\\"{x:1225,y:966,t:1527873313361};\\\", \\\"{x:1237,y:966,t:1527873313378};\\\", \\\"{x:1244,y:966,t:1527873313394};\\\", \\\"{x:1245,y:966,t:1527873313411};\\\", \\\"{x:1246,y:966,t:1527873313428};\\\", \\\"{x:1247,y:966,t:1527873313501};\\\", \\\"{x:1247,y:967,t:1527873313725};\\\", \\\"{x:1246,y:967,t:1527873313781};\\\", \\\"{x:1245,y:967,t:1527873313797};\\\", \\\"{x:1245,y:966,t:1527873313869};\\\", \\\"{x:1247,y:966,t:1527873313900};\\\", \\\"{x:1248,y:966,t:1527873313941};\\\", \\\"{x:1250,y:966,t:1527873313957};\\\", \\\"{x:1252,y:964,t:1527873313965};\\\", \\\"{x:1253,y:964,t:1527873313980};\\\", \\\"{x:1254,y:963,t:1527873313995};\\\", \\\"{x:1257,y:962,t:1527873314012};\\\", \\\"{x:1260,y:961,t:1527873314028};\\\", \\\"{x:1263,y:960,t:1527873314045};\\\", \\\"{x:1264,y:959,t:1527873314062};\\\", \\\"{x:1265,y:959,t:1527873314238};\\\", \\\"{x:1267,y:959,t:1527873314244};\\\", \\\"{x:1272,y:959,t:1527873314261};\\\", \\\"{x:1274,y:959,t:1527873314277};\\\", \\\"{x:1276,y:960,t:1527873314294};\\\", \\\"{x:1278,y:961,t:1527873314311};\\\", \\\"{x:1279,y:962,t:1527873314328};\\\", \\\"{x:1281,y:962,t:1527873314345};\\\", \\\"{x:1284,y:962,t:1527873314362};\\\", \\\"{x:1285,y:962,t:1527873314378};\\\", \\\"{x:1288,y:964,t:1527873314395};\\\", \\\"{x:1290,y:964,t:1527873314411};\\\", \\\"{x:1292,y:965,t:1527873314427};\\\", \\\"{x:1294,y:965,t:1527873314445};\\\", \\\"{x:1297,y:965,t:1527873314462};\\\", \\\"{x:1298,y:966,t:1527873314478};\\\", \\\"{x:1299,y:967,t:1527873314501};\\\", \\\"{x:1300,y:967,t:1527873314525};\\\", \\\"{x:1301,y:967,t:1527873314540};\\\", \\\"{x:1302,y:967,t:1527873314549};\\\", \\\"{x:1303,y:967,t:1527873314562};\\\", \\\"{x:1304,y:967,t:1527873314579};\\\", \\\"{x:1307,y:967,t:1527873314595};\\\", \\\"{x:1309,y:968,t:1527873314612};\\\", \\\"{x:1310,y:968,t:1527873314629};\\\", \\\"{x:1312,y:968,t:1527873314653};\\\", \\\"{x:1313,y:968,t:1527873314709};\\\", \\\"{x:1315,y:968,t:1527873314741};\\\", \\\"{x:1316,y:969,t:1527873315006};\\\", \\\"{x:1316,y:970,t:1527873315044};\\\", \\\"{x:1315,y:970,t:1527873315085};\\\", \\\"{x:1316,y:970,t:1527873315572};\\\", \\\"{x:1318,y:970,t:1527873315613};\\\", \\\"{x:1319,y:970,t:1527873315677};\\\", \\\"{x:1321,y:970,t:1527873315700};\\\", \\\"{x:1322,y:970,t:1527873315732};\\\", \\\"{x:1324,y:970,t:1527873315749};\\\", \\\"{x:1325,y:970,t:1527873315763};\\\", \\\"{x:1329,y:970,t:1527873315780};\\\", \\\"{x:1335,y:970,t:1527873315796};\\\", \\\"{x:1348,y:970,t:1527873315812};\\\", \\\"{x:1363,y:970,t:1527873315829};\\\", \\\"{x:1381,y:970,t:1527873315846};\\\", \\\"{x:1394,y:970,t:1527873315863};\\\", \\\"{x:1404,y:970,t:1527873315880};\\\", \\\"{x:1410,y:970,t:1527873315896};\\\", \\\"{x:1411,y:970,t:1527873315913};\\\", \\\"{x:1408,y:970,t:1527873316173};\\\", \\\"{x:1406,y:971,t:1527873316189};\\\", \\\"{x:1404,y:971,t:1527873316197};\\\", \\\"{x:1402,y:972,t:1527873316213};\\\", \\\"{x:1397,y:974,t:1527873316230};\\\", \\\"{x:1395,y:974,t:1527873316246};\\\", \\\"{x:1391,y:974,t:1527873316264};\\\", \\\"{x:1388,y:974,t:1527873316280};\\\", \\\"{x:1383,y:973,t:1527873316296};\\\", \\\"{x:1379,y:972,t:1527873316313};\\\", \\\"{x:1373,y:970,t:1527873316330};\\\", \\\"{x:1365,y:965,t:1527873316346};\\\", \\\"{x:1352,y:957,t:1527873316363};\\\", \\\"{x:1332,y:941,t:1527873316380};\\\", \\\"{x:1285,y:904,t:1527873316397};\\\", \\\"{x:1231,y:860,t:1527873316413};\\\", \\\"{x:1177,y:822,t:1527873316430};\\\", \\\"{x:1122,y:790,t:1527873316447};\\\", \\\"{x:1077,y:765,t:1527873316463};\\\", \\\"{x:1039,y:743,t:1527873316480};\\\", \\\"{x:1007,y:729,t:1527873316497};\\\", \\\"{x:973,y:713,t:1527873316513};\\\", \\\"{x:933,y:696,t:1527873316530};\\\", \\\"{x:891,y:687,t:1527873316546};\\\", \\\"{x:841,y:673,t:1527873316562};\\\", \\\"{x:750,y:649,t:1527873316579};\\\", \\\"{x:695,y:634,t:1527873316595};\\\", \\\"{x:609,y:623,t:1527873316613};\\\", \\\"{x:522,y:619,t:1527873316630};\\\", \\\"{x:463,y:619,t:1527873316647};\\\", \\\"{x:399,y:619,t:1527873316662};\\\", \\\"{x:357,y:619,t:1527873316678};\\\", \\\"{x:335,y:619,t:1527873316697};\\\", \\\"{x:325,y:619,t:1527873316714};\\\", \\\"{x:324,y:619,t:1527873316731};\\\", \\\"{x:324,y:617,t:1527873316877};\\\", \\\"{x:324,y:612,t:1527873316884};\\\", \\\"{x:324,y:609,t:1527873316897};\\\", \\\"{x:325,y:607,t:1527873316913};\\\", \\\"{x:326,y:603,t:1527873316931};\\\", \\\"{x:326,y:602,t:1527873317508};\\\", \\\"{x:332,y:599,t:1527873317518};\\\", \\\"{x:342,y:593,t:1527873317530};\\\", \\\"{x:358,y:586,t:1527873317546};\\\", \\\"{x:368,y:582,t:1527873317563};\\\", \\\"{x:372,y:580,t:1527873317580};\\\", \\\"{x:375,y:577,t:1527873317869};\\\", \\\"{x:384,y:572,t:1527873317879};\\\", \\\"{x:404,y:562,t:1527873317898};\\\", \\\"{x:418,y:553,t:1527873317915};\\\", \\\"{x:420,y:552,t:1527873317931};\\\", \\\"{x:421,y:551,t:1527873317948};\\\", \\\"{x:424,y:551,t:1527873317966};\\\", \\\"{x:425,y:550,t:1527873317982};\\\", \\\"{x:426,y:549,t:1527873317998};\\\", \\\"{x:425,y:547,t:1527873318173};\\\", \\\"{x:423,y:546,t:1527873318183};\\\", \\\"{x:419,y:544,t:1527873318199};\\\", \\\"{x:417,y:542,t:1527873318217};\\\", \\\"{x:415,y:542,t:1527873318233};\\\", \\\"{x:415,y:541,t:1527873318250};\\\", \\\"{x:413,y:539,t:1527873318265};\\\", \\\"{x:411,y:536,t:1527873318282};\\\", \\\"{x:409,y:533,t:1527873318299};\\\", \\\"{x:407,y:529,t:1527873318316};\\\", \\\"{x:404,y:525,t:1527873318333};\\\", \\\"{x:400,y:521,t:1527873318350};\\\", \\\"{x:394,y:517,t:1527873318366};\\\", \\\"{x:386,y:516,t:1527873318383};\\\", \\\"{x:364,y:511,t:1527873318399};\\\", \\\"{x:338,y:510,t:1527873318415};\\\", \\\"{x:309,y:510,t:1527873318432};\\\", \\\"{x:272,y:510,t:1527873318450};\\\", \\\"{x:233,y:510,t:1527873318465};\\\", \\\"{x:207,y:513,t:1527873318482};\\\", \\\"{x:187,y:517,t:1527873318500};\\\", \\\"{x:184,y:517,t:1527873318516};\\\", \\\"{x:183,y:518,t:1527873318533};\\\", \\\"{x:181,y:518,t:1527873318637};\\\", \\\"{x:180,y:516,t:1527873318650};\\\", \\\"{x:180,y:513,t:1527873318665};\\\", \\\"{x:178,y:511,t:1527873318683};\\\", \\\"{x:177,y:510,t:1527873318700};\\\", \\\"{x:178,y:510,t:1527873318963};\\\", \\\"{x:182,y:510,t:1527873318972};\\\", \\\"{x:188,y:510,t:1527873318983};\\\", \\\"{x:201,y:512,t:1527873319000};\\\", \\\"{x:213,y:520,t:1527873319017};\\\", \\\"{x:233,y:538,t:1527873319033};\\\", \\\"{x:254,y:567,t:1527873319051};\\\", \\\"{x:286,y:612,t:1527873319067};\\\", \\\"{x:312,y:642,t:1527873319083};\\\", \\\"{x:342,y:669,t:1527873319099};\\\", \\\"{x:356,y:680,t:1527873319117};\\\", \\\"{x:362,y:686,t:1527873319133};\\\", \\\"{x:366,y:690,t:1527873319150};\\\", \\\"{x:369,y:694,t:1527873319167};\\\", \\\"{x:374,y:702,t:1527873319183};\\\", \\\"{x:379,y:709,t:1527873319200};\\\", \\\"{x:383,y:718,t:1527873319216};\\\", \\\"{x:390,y:729,t:1527873319232};\\\", \\\"{x:398,y:742,t:1527873319250};\\\", \\\"{x:405,y:749,t:1527873319265};\\\", \\\"{x:409,y:754,t:1527873319283};\\\", \\\"{x:410,y:754,t:1527873319357};\\\", \\\"{x:413,y:754,t:1527873319366};\\\", \\\"{x:417,y:754,t:1527873319382};\\\", \\\"{x:421,y:754,t:1527873319398};\\\", \\\"{x:429,y:754,t:1527873319415};\\\", \\\"{x:437,y:751,t:1527873319433};\\\", \\\"{x:443,y:749,t:1527873319448};\\\", \\\"{x:447,y:746,t:1527873319467};\\\", \\\"{x:454,y:742,t:1527873319482};\\\", \\\"{x:472,y:730,t:1527873319501};\\\", \\\"{x:478,y:727,t:1527873319517};\\\", \\\"{x:478,y:726,t:1527873319533};\\\", \\\"{x:479,y:726,t:1527873319580};\\\", \\\"{x:480,y:726,t:1527873319852};\\\", \\\"{x:480,y:722,t:1527873320269};\\\", \\\"{x:480,y:706,t:1527873320284};\\\", \\\"{x:481,y:696,t:1527873320301};\\\", \\\"{x:484,y:680,t:1527873320318};\\\", \\\"{x:490,y:664,t:1527873320334};\\\", \\\"{x:492,y:656,t:1527873320350};\\\", \\\"{x:494,y:646,t:1527873320368};\\\", \\\"{x:498,y:636,t:1527873320384};\\\", \\\"{x:499,y:629,t:1527873320401};\\\", \\\"{x:499,y:626,t:1527873320418};\\\", \\\"{x:499,y:623,t:1527873320433};\\\", \\\"{x:499,y:622,t:1527873320451};\\\", \\\"{x:499,y:621,t:1527873320468};\\\", \\\"{x:499,y:620,t:1527873320508};\\\" ] }, { \\\"rt\\\": 57849, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 563650, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -01 PM-01 PM-03 PM-03 PM-04 PM-03 PM-02 PM-02 PM-03 PM-X -M -M -B -12 PM-01 PM-02 PM-03 PM-F -M -01 PM-02 PM-03 PM-04 PM-E -11 AM-01 PM-02 PM-02 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:616,t:1527873323325};\\\", \\\"{x:516,y:611,t:1527873323337};\\\", \\\"{x:517,y:606,t:1527873323354};\\\", \\\"{x:513,y:597,t:1527873323372};\\\", \\\"{x:511,y:589,t:1527873323388};\\\", \\\"{x:505,y:579,t:1527873323420};\\\", \\\"{x:500,y:576,t:1527873323436};\\\", \\\"{x:494,y:572,t:1527873323452};\\\", \\\"{x:486,y:569,t:1527873323468};\\\", \\\"{x:479,y:569,t:1527873323486};\\\", \\\"{x:463,y:567,t:1527873323503};\\\", \\\"{x:452,y:567,t:1527873323519};\\\", \\\"{x:442,y:565,t:1527873323536};\\\", \\\"{x:431,y:565,t:1527873323553};\\\", \\\"{x:422,y:565,t:1527873323570};\\\", \\\"{x:417,y:565,t:1527873323587};\\\", \\\"{x:412,y:565,t:1527873323602};\\\", \\\"{x:410,y:564,t:1527873323620};\\\", \\\"{x:408,y:563,t:1527873323637};\\\", \\\"{x:407,y:563,t:1527873323653};\\\", \\\"{x:400,y:559,t:1527873323671};\\\", \\\"{x:392,y:556,t:1527873323687};\\\", \\\"{x:383,y:551,t:1527873323705};\\\", \\\"{x:378,y:550,t:1527873323720};\\\", \\\"{x:377,y:547,t:1527873323737};\\\", \\\"{x:373,y:538,t:1527873323753};\\\", \\\"{x:371,y:529,t:1527873323771};\\\", \\\"{x:369,y:520,t:1527873323787};\\\", \\\"{x:367,y:511,t:1527873323804};\\\", \\\"{x:367,y:509,t:1527873323820};\\\", \\\"{x:367,y:508,t:1527873323836};\\\", \\\"{x:367,y:507,t:1527873323854};\\\", \\\"{x:367,y:506,t:1527873324029};\\\", \\\"{x:367,y:504,t:1527873324037};\\\", \\\"{x:368,y:502,t:1527873324055};\\\", \\\"{x:372,y:498,t:1527873324070};\\\", \\\"{x:375,y:496,t:1527873324088};\\\", \\\"{x:380,y:493,t:1527873324105};\\\", \\\"{x:388,y:488,t:1527873324120};\\\", \\\"{x:396,y:483,t:1527873324137};\\\", \\\"{x:399,y:482,t:1527873324154};\\\", \\\"{x:404,y:480,t:1527873324171};\\\", \\\"{x:410,y:478,t:1527873324187};\\\", \\\"{x:426,y:478,t:1527873324204};\\\", \\\"{x:435,y:478,t:1527873324221};\\\", \\\"{x:440,y:478,t:1527873324237};\\\", \\\"{x:442,y:478,t:1527873324254};\\\", \\\"{x:443,y:478,t:1527873324292};\\\", \\\"{x:444,y:478,t:1527873324325};\\\", \\\"{x:446,y:478,t:1527873324337};\\\", \\\"{x:450,y:478,t:1527873324354};\\\", \\\"{x:457,y:478,t:1527873324372};\\\", \\\"{x:465,y:478,t:1527873324387};\\\", \\\"{x:484,y:478,t:1527873324403};\\\", \\\"{x:502,y:475,t:1527873324421};\\\", \\\"{x:518,y:475,t:1527873324437};\\\", \\\"{x:530,y:473,t:1527873324453};\\\", \\\"{x:537,y:472,t:1527873324471};\\\", \\\"{x:543,y:470,t:1527873324487};\\\", \\\"{x:550,y:468,t:1527873324504};\\\", \\\"{x:556,y:466,t:1527873324520};\\\", \\\"{x:564,y:464,t:1527873324537};\\\", \\\"{x:575,y:460,t:1527873324554};\\\", \\\"{x:587,y:457,t:1527873324571};\\\", \\\"{x:602,y:455,t:1527873324588};\\\", \\\"{x:613,y:451,t:1527873324604};\\\", \\\"{x:620,y:450,t:1527873324621};\\\", \\\"{x:628,y:449,t:1527873324638};\\\", \\\"{x:632,y:447,t:1527873324654};\\\", \\\"{x:634,y:447,t:1527873324671};\\\", \\\"{x:635,y:446,t:1527873324688};\\\", \\\"{x:637,y:446,t:1527873324709};\\\", \\\"{x:638,y:446,t:1527873324725};\\\", \\\"{x:639,y:444,t:1527873324740};\\\", \\\"{x:640,y:444,t:1527873324754};\\\", \\\"{x:641,y:444,t:1527873324772};\\\", \\\"{x:642,y:444,t:1527873324788};\\\", \\\"{x:643,y:444,t:1527873324804};\\\", \\\"{x:644,y:444,t:1527873324821};\\\", \\\"{x:649,y:443,t:1527873324838};\\\", \\\"{x:655,y:442,t:1527873324855};\\\", \\\"{x:663,y:442,t:1527873324871};\\\", \\\"{x:672,y:439,t:1527873324888};\\\", \\\"{x:684,y:438,t:1527873324904};\\\", \\\"{x:702,y:435,t:1527873324921};\\\", \\\"{x:724,y:435,t:1527873324938};\\\", \\\"{x:745,y:435,t:1527873324956};\\\", \\\"{x:767,y:435,t:1527873324972};\\\", \\\"{x:809,y:435,t:1527873324988};\\\", \\\"{x:843,y:435,t:1527873325004};\\\", \\\"{x:885,y:435,t:1527873325021};\\\", \\\"{x:917,y:435,t:1527873325039};\\\", \\\"{x:950,y:435,t:1527873325055};\\\", \\\"{x:995,y:435,t:1527873325071};\\\", \\\"{x:1048,y:435,t:1527873325088};\\\", \\\"{x:1085,y:435,t:1527873325106};\\\", \\\"{x:1114,y:435,t:1527873325121};\\\", \\\"{x:1134,y:435,t:1527873325138};\\\", \\\"{x:1151,y:435,t:1527873325155};\\\", \\\"{x:1165,y:435,t:1527873325172};\\\", \\\"{x:1180,y:435,t:1527873325188};\\\", \\\"{x:1192,y:435,t:1527873325205};\\\", \\\"{x:1202,y:435,t:1527873325222};\\\", \\\"{x:1215,y:434,t:1527873325238};\\\", \\\"{x:1227,y:433,t:1527873325255};\\\", \\\"{x:1246,y:433,t:1527873325272};\\\", \\\"{x:1264,y:433,t:1527873325288};\\\", \\\"{x:1279,y:433,t:1527873325305};\\\", \\\"{x:1292,y:433,t:1527873325321};\\\", \\\"{x:1303,y:433,t:1527873325339};\\\", \\\"{x:1317,y:434,t:1527873325355};\\\", \\\"{x:1338,y:440,t:1527873325372};\\\", \\\"{x:1347,y:442,t:1527873325387};\\\", \\\"{x:1349,y:445,t:1527873325405};\\\", \\\"{x:1352,y:446,t:1527873325421};\\\", \\\"{x:1359,y:451,t:1527873325438};\\\", \\\"{x:1366,y:457,t:1527873325454};\\\", \\\"{x:1370,y:462,t:1527873325472};\\\", \\\"{x:1371,y:466,t:1527873325487};\\\", \\\"{x:1373,y:473,t:1527873325505};\\\", \\\"{x:1373,y:487,t:1527873325522};\\\", \\\"{x:1373,y:501,t:1527873325538};\\\", \\\"{x:1373,y:512,t:1527873325555};\\\", \\\"{x:1373,y:526,t:1527873325572};\\\", \\\"{x:1373,y:534,t:1527873325588};\\\", \\\"{x:1373,y:541,t:1527873325605};\\\", \\\"{x:1373,y:548,t:1527873325622};\\\", \\\"{x:1373,y:552,t:1527873325638};\\\", \\\"{x:1373,y:556,t:1527873325655};\\\", \\\"{x:1373,y:565,t:1527873325672};\\\", \\\"{x:1370,y:581,t:1527873325688};\\\", \\\"{x:1367,y:602,t:1527873325706};\\\", \\\"{x:1363,y:624,t:1527873325723};\\\", \\\"{x:1360,y:644,t:1527873325738};\\\", \\\"{x:1358,y:659,t:1527873325755};\\\", \\\"{x:1357,y:675,t:1527873325772};\\\", \\\"{x:1357,y:687,t:1527873325789};\\\", \\\"{x:1356,y:697,t:1527873325806};\\\", \\\"{x:1355,y:705,t:1527873325823};\\\", \\\"{x:1355,y:712,t:1527873325840};\\\", \\\"{x:1355,y:717,t:1527873325855};\\\", \\\"{x:1355,y:722,t:1527873325872};\\\", \\\"{x:1355,y:726,t:1527873325889};\\\", \\\"{x:1355,y:728,t:1527873325905};\\\", \\\"{x:1355,y:726,t:1527873326348};\\\", \\\"{x:1355,y:724,t:1527873326356};\\\", \\\"{x:1355,y:720,t:1527873326372};\\\", \\\"{x:1355,y:714,t:1527873326389};\\\", \\\"{x:1356,y:709,t:1527873326407};\\\", \\\"{x:1356,y:707,t:1527873326423};\\\", \\\"{x:1356,y:704,t:1527873326439};\\\", \\\"{x:1358,y:701,t:1527873326456};\\\", \\\"{x:1358,y:700,t:1527873326472};\\\", \\\"{x:1358,y:699,t:1527873326490};\\\", \\\"{x:1358,y:698,t:1527873326524};\\\", \\\"{x:1357,y:698,t:1527873327253};\\\", \\\"{x:1356,y:698,t:1527873327261};\\\", \\\"{x:1354,y:698,t:1527873327274};\\\", \\\"{x:1349,y:701,t:1527873327293};\\\", \\\"{x:1347,y:701,t:1527873327306};\\\", \\\"{x:1346,y:701,t:1527873327331};\\\", \\\"{x:1346,y:702,t:1527873330012};\\\", \\\"{x:1347,y:702,t:1527873330027};\\\", \\\"{x:1349,y:702,t:1527873330044};\\\", \\\"{x:1353,y:700,t:1527873330060};\\\", \\\"{x:1355,y:700,t:1527873330075};\\\", \\\"{x:1358,y:699,t:1527873330092};\\\", \\\"{x:1359,y:699,t:1527873330109};\\\", \\\"{x:1360,y:699,t:1527873330125};\\\", \\\"{x:1361,y:700,t:1527873330733};\\\", \\\"{x:1367,y:722,t:1527873330742};\\\", \\\"{x:1373,y:762,t:1527873330760};\\\", \\\"{x:1383,y:795,t:1527873330776};\\\", \\\"{x:1390,y:824,t:1527873330793};\\\", \\\"{x:1398,y:847,t:1527873330809};\\\", \\\"{x:1404,y:864,t:1527873330826};\\\", \\\"{x:1411,y:879,t:1527873330842};\\\", \\\"{x:1415,y:889,t:1527873330861};\\\", \\\"{x:1417,y:894,t:1527873330875};\\\", \\\"{x:1419,y:896,t:1527873330892};\\\", \\\"{x:1422,y:900,t:1527873330909};\\\", \\\"{x:1422,y:901,t:1527873330926};\\\", \\\"{x:1423,y:902,t:1527873330942};\\\", \\\"{x:1424,y:905,t:1527873330959};\\\", \\\"{x:1425,y:907,t:1527873330976};\\\", \\\"{x:1425,y:911,t:1527873330993};\\\", \\\"{x:1426,y:914,t:1527873331009};\\\", \\\"{x:1426,y:918,t:1527873331027};\\\", \\\"{x:1426,y:924,t:1527873331043};\\\", \\\"{x:1426,y:927,t:1527873331059};\\\", \\\"{x:1426,y:931,t:1527873331076};\\\", \\\"{x:1426,y:933,t:1527873331093};\\\", \\\"{x:1426,y:937,t:1527873331110};\\\", \\\"{x:1425,y:941,t:1527873331127};\\\", \\\"{x:1424,y:946,t:1527873331144};\\\", \\\"{x:1421,y:951,t:1527873331159};\\\", \\\"{x:1420,y:956,t:1527873331177};\\\", \\\"{x:1415,y:966,t:1527873331194};\\\", \\\"{x:1410,y:979,t:1527873331210};\\\", \\\"{x:1404,y:989,t:1527873331227};\\\", \\\"{x:1398,y:996,t:1527873331243};\\\", \\\"{x:1393,y:1002,t:1527873331260};\\\", \\\"{x:1389,y:1005,t:1527873331277};\\\", \\\"{x:1388,y:1007,t:1527873331294};\\\", \\\"{x:1388,y:1009,t:1527873331310};\\\", \\\"{x:1387,y:1009,t:1527873331326};\\\", \\\"{x:1387,y:1010,t:1527873331344};\\\", \\\"{x:1386,y:1009,t:1527873331485};\\\", \\\"{x:1386,y:1004,t:1527873331493};\\\", \\\"{x:1388,y:998,t:1527873331510};\\\", \\\"{x:1393,y:991,t:1527873331526};\\\", \\\"{x:1397,y:985,t:1527873331544};\\\", \\\"{x:1400,y:980,t:1527873331560};\\\", \\\"{x:1400,y:979,t:1527873331575};\\\", \\\"{x:1403,y:977,t:1527873332189};\\\", \\\"{x:1408,y:975,t:1527873332196};\\\", \\\"{x:1413,y:973,t:1527873332210};\\\", \\\"{x:1421,y:970,t:1527873332228};\\\", \\\"{x:1428,y:966,t:1527873332244};\\\", \\\"{x:1434,y:965,t:1527873332261};\\\", \\\"{x:1436,y:964,t:1527873332278};\\\", \\\"{x:1437,y:964,t:1527873332294};\\\", \\\"{x:1439,y:963,t:1527873332311};\\\", \\\"{x:1442,y:962,t:1527873332328};\\\", \\\"{x:1446,y:962,t:1527873332345};\\\", \\\"{x:1452,y:959,t:1527873332360};\\\", \\\"{x:1457,y:959,t:1527873332377};\\\", \\\"{x:1461,y:958,t:1527873332394};\\\", \\\"{x:1465,y:956,t:1527873332411};\\\", \\\"{x:1472,y:955,t:1527873332428};\\\", \\\"{x:1480,y:954,t:1527873332445};\\\", \\\"{x:1485,y:953,t:1527873332461};\\\", \\\"{x:1487,y:953,t:1527873332483};\\\", \\\"{x:1488,y:953,t:1527873332507};\\\", \\\"{x:1491,y:952,t:1527873332523};\\\", \\\"{x:1492,y:952,t:1527873332539};\\\", \\\"{x:1493,y:952,t:1527873332547};\\\", \\\"{x:1493,y:953,t:1527873332724};\\\", \\\"{x:1491,y:957,t:1527873332731};\\\", \\\"{x:1489,y:958,t:1527873332744};\\\", \\\"{x:1487,y:961,t:1527873332762};\\\", \\\"{x:1486,y:962,t:1527873332778};\\\", \\\"{x:1484,y:963,t:1527873332795};\\\", \\\"{x:1484,y:964,t:1527873332812};\\\", \\\"{x:1488,y:964,t:1527873333021};\\\", \\\"{x:1502,y:964,t:1527873333028};\\\", \\\"{x:1528,y:964,t:1527873333044};\\\", \\\"{x:1552,y:964,t:1527873333062};\\\", \\\"{x:1570,y:964,t:1527873333078};\\\", \\\"{x:1575,y:964,t:1527873333094};\\\", \\\"{x:1576,y:964,t:1527873333111};\\\", \\\"{x:1575,y:967,t:1527873333253};\\\", \\\"{x:1568,y:970,t:1527873333262};\\\", \\\"{x:1552,y:979,t:1527873333279};\\\", \\\"{x:1541,y:984,t:1527873333294};\\\", \\\"{x:1534,y:989,t:1527873333313};\\\", \\\"{x:1531,y:990,t:1527873333329};\\\", \\\"{x:1533,y:988,t:1527873333565};\\\", \\\"{x:1536,y:986,t:1527873333579};\\\", \\\"{x:1546,y:982,t:1527873333595};\\\", \\\"{x:1556,y:976,t:1527873333612};\\\", \\\"{x:1558,y:974,t:1527873333629};\\\", \\\"{x:1559,y:974,t:1527873333646};\\\", \\\"{x:1563,y:974,t:1527873334477};\\\", \\\"{x:1570,y:971,t:1527873334484};\\\", \\\"{x:1576,y:969,t:1527873334496};\\\", \\\"{x:1585,y:966,t:1527873334513};\\\", \\\"{x:1590,y:964,t:1527873334530};\\\", \\\"{x:1594,y:963,t:1527873334546};\\\", \\\"{x:1596,y:962,t:1527873334563};\\\", \\\"{x:1598,y:962,t:1527873334637};\\\", \\\"{x:1601,y:962,t:1527873334646};\\\", \\\"{x:1604,y:962,t:1527873334662};\\\", \\\"{x:1606,y:962,t:1527873334680};\\\", \\\"{x:1607,y:962,t:1527873334696};\\\", \\\"{x:1608,y:962,t:1527873334973};\\\", \\\"{x:1609,y:963,t:1527873334988};\\\", \\\"{x:1610,y:964,t:1527873335029};\\\", \\\"{x:1612,y:965,t:1527873335141};\\\", \\\"{x:1613,y:965,t:1527873337925};\\\", \\\"{x:1615,y:966,t:1527873337932};\\\", \\\"{x:1616,y:966,t:1527873338117};\\\", \\\"{x:1616,y:962,t:1527873338749};\\\", \\\"{x:1612,y:956,t:1527873338765};\\\", \\\"{x:1607,y:950,t:1527873338783};\\\", \\\"{x:1602,y:944,t:1527873338800};\\\", \\\"{x:1597,y:938,t:1527873338816};\\\", \\\"{x:1594,y:933,t:1527873338832};\\\", \\\"{x:1590,y:929,t:1527873338850};\\\", \\\"{x:1587,y:926,t:1527873338866};\\\", \\\"{x:1586,y:922,t:1527873338883};\\\", \\\"{x:1580,y:914,t:1527873338900};\\\", \\\"{x:1576,y:910,t:1527873338916};\\\", \\\"{x:1573,y:907,t:1527873338933};\\\", \\\"{x:1572,y:906,t:1527873338950};\\\", \\\"{x:1572,y:905,t:1527873338966};\\\", \\\"{x:1572,y:906,t:1527873339236};\\\", \\\"{x:1572,y:909,t:1527873339250};\\\", \\\"{x:1572,y:915,t:1527873339266};\\\", \\\"{x:1573,y:921,t:1527873339283};\\\", \\\"{x:1576,y:929,t:1527873339300};\\\", \\\"{x:1579,y:933,t:1527873339316};\\\", \\\"{x:1585,y:939,t:1527873339333};\\\", \\\"{x:1589,y:944,t:1527873339350};\\\", \\\"{x:1593,y:948,t:1527873339367};\\\", \\\"{x:1596,y:952,t:1527873339382};\\\", \\\"{x:1598,y:954,t:1527873339400};\\\", \\\"{x:1602,y:958,t:1527873339417};\\\", \\\"{x:1605,y:962,t:1527873339433};\\\", \\\"{x:1608,y:965,t:1527873339450};\\\", \\\"{x:1613,y:970,t:1527873339467};\\\", \\\"{x:1617,y:974,t:1527873339483};\\\", \\\"{x:1619,y:977,t:1527873339500};\\\", \\\"{x:1618,y:977,t:1527873339813};\\\", \\\"{x:1615,y:975,t:1527873339820};\\\", \\\"{x:1609,y:973,t:1527873339834};\\\", \\\"{x:1601,y:970,t:1527873339850};\\\", \\\"{x:1594,y:970,t:1527873339868};\\\", \\\"{x:1584,y:968,t:1527873339884};\\\", \\\"{x:1578,y:968,t:1527873339900};\\\", \\\"{x:1573,y:969,t:1527873339917};\\\", \\\"{x:1564,y:977,t:1527873339934};\\\", \\\"{x:1555,y:987,t:1527873339950};\\\", \\\"{x:1540,y:998,t:1527873339967};\\\", \\\"{x:1528,y:1005,t:1527873339984};\\\", \\\"{x:1514,y:1012,t:1527873340000};\\\", \\\"{x:1502,y:1017,t:1527873340016};\\\", \\\"{x:1496,y:1019,t:1527873340033};\\\", \\\"{x:1495,y:1019,t:1527873340117};\\\", \\\"{x:1489,y:1016,t:1527873340134};\\\", \\\"{x:1483,y:1005,t:1527873340151};\\\", \\\"{x:1479,y:997,t:1527873340167};\\\", \\\"{x:1474,y:984,t:1527873340184};\\\", \\\"{x:1469,y:972,t:1527873340201};\\\", \\\"{x:1466,y:963,t:1527873340218};\\\", \\\"{x:1464,y:953,t:1527873340235};\\\", \\\"{x:1464,y:948,t:1527873340250};\\\", \\\"{x:1462,y:942,t:1527873340267};\\\", \\\"{x:1462,y:936,t:1527873340284};\\\", \\\"{x:1461,y:936,t:1527873340301};\\\", \\\"{x:1461,y:935,t:1527873340340};\\\", \\\"{x:1462,y:935,t:1527873340396};\\\", \\\"{x:1467,y:937,t:1527873340404};\\\", \\\"{x:1469,y:942,t:1527873340417};\\\", \\\"{x:1481,y:958,t:1527873340434};\\\", \\\"{x:1491,y:973,t:1527873340451};\\\", \\\"{x:1500,y:982,t:1527873340467};\\\", \\\"{x:1508,y:989,t:1527873340485};\\\", \\\"{x:1511,y:991,t:1527873340500};\\\", \\\"{x:1514,y:991,t:1527873340612};\\\", \\\"{x:1520,y:990,t:1527873340620};\\\", \\\"{x:1529,y:985,t:1527873340634};\\\", \\\"{x:1544,y:976,t:1527873340651};\\\", \\\"{x:1556,y:970,t:1527873340668};\\\", \\\"{x:1560,y:968,t:1527873340684};\\\", \\\"{x:1560,y:966,t:1527873341020};\\\", \\\"{x:1554,y:961,t:1527873341034};\\\", \\\"{x:1537,y:948,t:1527873341051};\\\", \\\"{x:1499,y:927,t:1527873341068};\\\", \\\"{x:1485,y:923,t:1527873341084};\\\", \\\"{x:1475,y:922,t:1527873341100};\\\", \\\"{x:1456,y:918,t:1527873341118};\\\", \\\"{x:1452,y:916,t:1527873341135};\\\", \\\"{x:1451,y:915,t:1527873341151};\\\", \\\"{x:1450,y:915,t:1527873341168};\\\", \\\"{x:1450,y:914,t:1527873341316};\\\", \\\"{x:1450,y:902,t:1527873341335};\\\", \\\"{x:1450,y:890,t:1527873341351};\\\", \\\"{x:1459,y:878,t:1527873341368};\\\", \\\"{x:1465,y:871,t:1527873341385};\\\", \\\"{x:1467,y:868,t:1527873341402};\\\", \\\"{x:1467,y:867,t:1527873341418};\\\", \\\"{x:1468,y:865,t:1527873341435};\\\", \\\"{x:1468,y:863,t:1527873341476};\\\", \\\"{x:1469,y:862,t:1527873341485};\\\", \\\"{x:1469,y:859,t:1527873341502};\\\", \\\"{x:1471,y:855,t:1527873341518};\\\", \\\"{x:1471,y:852,t:1527873341535};\\\", \\\"{x:1471,y:848,t:1527873341552};\\\", \\\"{x:1473,y:845,t:1527873341568};\\\", \\\"{x:1474,y:840,t:1527873341585};\\\", \\\"{x:1475,y:832,t:1527873341602};\\\", \\\"{x:1475,y:823,t:1527873341618};\\\", \\\"{x:1477,y:819,t:1527873341635};\\\", \\\"{x:1478,y:815,t:1527873341652};\\\", \\\"{x:1478,y:814,t:1527873341668};\\\", \\\"{x:1477,y:813,t:1527873341804};\\\", \\\"{x:1462,y:813,t:1527873341818};\\\", \\\"{x:1409,y:813,t:1527873341835};\\\", \\\"{x:1243,y:813,t:1527873341852};\\\", \\\"{x:1105,y:813,t:1527873341869};\\\", \\\"{x:955,y:813,t:1527873341884};\\\", \\\"{x:806,y:813,t:1527873341901};\\\", \\\"{x:687,y:813,t:1527873341918};\\\", \\\"{x:598,y:813,t:1527873341934};\\\", \\\"{x:550,y:812,t:1527873341951};\\\", \\\"{x:526,y:807,t:1527873341968};\\\", \\\"{x:509,y:802,t:1527873341984};\\\", \\\"{x:493,y:797,t:1527873342001};\\\", \\\"{x:484,y:792,t:1527873342018};\\\", \\\"{x:473,y:786,t:1527873342034};\\\", \\\"{x:452,y:776,t:1527873342052};\\\", \\\"{x:442,y:771,t:1527873342068};\\\", \\\"{x:436,y:769,t:1527873342085};\\\", \\\"{x:433,y:766,t:1527873342102};\\\", \\\"{x:432,y:760,t:1527873342118};\\\", \\\"{x:429,y:751,t:1527873342134};\\\", \\\"{x:428,y:738,t:1527873342151};\\\", \\\"{x:427,y:727,t:1527873342169};\\\", \\\"{x:424,y:712,t:1527873342185};\\\", \\\"{x:423,y:704,t:1527873342202};\\\", \\\"{x:422,y:698,t:1527873342218};\\\", \\\"{x:420,y:694,t:1527873342235};\\\", \\\"{x:417,y:687,t:1527873342252};\\\", \\\"{x:413,y:681,t:1527873342269};\\\", \\\"{x:407,y:671,t:1527873342285};\\\", \\\"{x:401,y:661,t:1527873342303};\\\", \\\"{x:397,y:657,t:1527873342318};\\\", \\\"{x:392,y:651,t:1527873342336};\\\", \\\"{x:378,y:641,t:1527873342347};\\\", \\\"{x:363,y:630,t:1527873342364};\\\", \\\"{x:355,y:624,t:1527873342380};\\\", \\\"{x:353,y:622,t:1527873342396};\\\", \\\"{x:348,y:617,t:1527873342413};\\\", \\\"{x:345,y:609,t:1527873342430};\\\", \\\"{x:345,y:602,t:1527873342446};\\\", \\\"{x:345,y:598,t:1527873342464};\\\", \\\"{x:345,y:597,t:1527873342480};\\\", \\\"{x:345,y:595,t:1527873342531};\\\", \\\"{x:347,y:595,t:1527873342547};\\\", \\\"{x:348,y:595,t:1527873342563};\\\", \\\"{x:351,y:595,t:1527873342572};\\\", \\\"{x:355,y:594,t:1527873342586};\\\", \\\"{x:374,y:593,t:1527873342604};\\\", \\\"{x:418,y:587,t:1527873342619};\\\", \\\"{x:436,y:584,t:1527873342635};\\\", \\\"{x:453,y:581,t:1527873342651};\\\", \\\"{x:473,y:581,t:1527873342668};\\\", \\\"{x:496,y:581,t:1527873342685};\\\", \\\"{x:515,y:581,t:1527873342701};\\\", \\\"{x:525,y:581,t:1527873342718};\\\", \\\"{x:529,y:581,t:1527873342736};\\\", \\\"{x:532,y:579,t:1527873342751};\\\", \\\"{x:534,y:579,t:1527873342768};\\\", \\\"{x:536,y:579,t:1527873342786};\\\", \\\"{x:539,y:579,t:1527873342802};\\\", \\\"{x:540,y:578,t:1527873342819};\\\", \\\"{x:542,y:578,t:1527873342859};\\\", \\\"{x:546,y:578,t:1527873342869};\\\", \\\"{x:560,y:578,t:1527873342886};\\\", \\\"{x:575,y:582,t:1527873342903};\\\", \\\"{x:582,y:585,t:1527873342918};\\\", \\\"{x:584,y:585,t:1527873342936};\\\", \\\"{x:586,y:585,t:1527873342952};\\\", \\\"{x:588,y:585,t:1527873342969};\\\", \\\"{x:590,y:585,t:1527873342986};\\\", \\\"{x:595,y:586,t:1527873343002};\\\", \\\"{x:597,y:586,t:1527873343018};\\\", \\\"{x:604,y:587,t:1527873343036};\\\", \\\"{x:606,y:588,t:1527873343052};\\\", \\\"{x:608,y:588,t:1527873343068};\\\", \\\"{x:610,y:588,t:1527873343091};\\\", \\\"{x:611,y:588,t:1527873343139};\\\", \\\"{x:614,y:588,t:1527873343152};\\\", \\\"{x:617,y:586,t:1527873343170};\\\", \\\"{x:617,y:585,t:1527873343203};\\\", \\\"{x:626,y:583,t:1527873343604};\\\", \\\"{x:690,y:553,t:1527873343622};\\\", \\\"{x:772,y:525,t:1527873343637};\\\", \\\"{x:830,y:508,t:1527873343654};\\\", \\\"{x:887,y:497,t:1527873343669};\\\", \\\"{x:951,y:488,t:1527873343686};\\\", \\\"{x:1021,y:488,t:1527873343702};\\\", \\\"{x:1082,y:488,t:1527873343720};\\\", \\\"{x:1133,y:488,t:1527873343736};\\\", \\\"{x:1161,y:488,t:1527873343752};\\\", \\\"{x:1194,y:488,t:1527873343769};\\\", \\\"{x:1225,y:488,t:1527873343785};\\\", \\\"{x:1254,y:497,t:1527873343802};\\\", \\\"{x:1287,y:508,t:1527873343819};\\\", \\\"{x:1309,y:521,t:1527873343835};\\\", \\\"{x:1327,y:535,t:1527873343852};\\\", \\\"{x:1344,y:554,t:1527873343869};\\\", \\\"{x:1355,y:575,t:1527873343886};\\\", \\\"{x:1362,y:598,t:1527873343903};\\\", \\\"{x:1366,y:630,t:1527873343920};\\\", \\\"{x:1372,y:666,t:1527873343936};\\\", \\\"{x:1373,y:706,t:1527873343953};\\\", \\\"{x:1374,y:735,t:1527873343970};\\\", \\\"{x:1375,y:751,t:1527873343986};\\\", \\\"{x:1377,y:761,t:1527873344004};\\\", \\\"{x:1383,y:781,t:1527873344020};\\\", \\\"{x:1388,y:791,t:1527873344036};\\\", \\\"{x:1395,y:801,t:1527873344054};\\\", \\\"{x:1400,y:810,t:1527873344070};\\\", \\\"{x:1403,y:815,t:1527873344086};\\\", \\\"{x:1407,y:822,t:1527873344103};\\\", \\\"{x:1409,y:827,t:1527873344120};\\\", \\\"{x:1410,y:830,t:1527873344137};\\\", \\\"{x:1410,y:831,t:1527873344153};\\\", \\\"{x:1411,y:831,t:1527873344252};\\\", \\\"{x:1413,y:833,t:1527873345420};\\\", \\\"{x:1414,y:837,t:1527873345436};\\\", \\\"{x:1412,y:857,t:1527873345452};\\\", \\\"{x:1406,y:869,t:1527873345469};\\\", \\\"{x:1401,y:879,t:1527873345485};\\\", \\\"{x:1401,y:885,t:1527873345502};\\\", \\\"{x:1400,y:888,t:1527873345518};\\\", \\\"{x:1399,y:894,t:1527873345536};\\\", \\\"{x:1399,y:897,t:1527873345552};\\\", \\\"{x:1397,y:901,t:1527873345568};\\\", \\\"{x:1394,y:905,t:1527873345585};\\\", \\\"{x:1392,y:907,t:1527873345602};\\\", \\\"{x:1392,y:908,t:1527873345618};\\\", \\\"{x:1391,y:908,t:1527873345869};\\\", \\\"{x:1389,y:908,t:1527873345885};\\\", \\\"{x:1387,y:908,t:1527873345902};\\\", \\\"{x:1385,y:905,t:1527873345918};\\\", \\\"{x:1383,y:904,t:1527873345936};\\\", \\\"{x:1382,y:902,t:1527873345952};\\\", \\\"{x:1381,y:901,t:1527873345968};\\\", \\\"{x:1379,y:899,t:1527873345984};\\\", \\\"{x:1377,y:898,t:1527873346001};\\\", \\\"{x:1375,y:896,t:1527873346018};\\\", \\\"{x:1374,y:896,t:1527873346035};\\\", \\\"{x:1379,y:896,t:1527873346525};\\\", \\\"{x:1386,y:894,t:1527873346534};\\\", \\\"{x:1403,y:891,t:1527873346552};\\\", \\\"{x:1421,y:886,t:1527873346568};\\\", \\\"{x:1437,y:882,t:1527873346585};\\\", \\\"{x:1447,y:878,t:1527873346601};\\\", \\\"{x:1454,y:876,t:1527873346619};\\\", \\\"{x:1457,y:873,t:1527873346634};\\\", \\\"{x:1458,y:873,t:1527873346651};\\\", \\\"{x:1459,y:872,t:1527873346692};\\\", \\\"{x:1458,y:872,t:1527873346701};\\\", \\\"{x:1447,y:865,t:1527873346718};\\\", \\\"{x:1428,y:860,t:1527873346734};\\\", \\\"{x:1411,y:854,t:1527873346751};\\\", \\\"{x:1388,y:846,t:1527873346768};\\\", \\\"{x:1368,y:837,t:1527873346784};\\\", \\\"{x:1356,y:832,t:1527873346801};\\\", \\\"{x:1346,y:826,t:1527873346818};\\\", \\\"{x:1338,y:821,t:1527873346834};\\\", \\\"{x:1337,y:819,t:1527873346851};\\\", \\\"{x:1336,y:816,t:1527873346868};\\\", \\\"{x:1336,y:812,t:1527873346884};\\\", \\\"{x:1336,y:806,t:1527873346901};\\\", \\\"{x:1336,y:803,t:1527873346917};\\\", \\\"{x:1336,y:799,t:1527873346934};\\\", \\\"{x:1336,y:795,t:1527873346951};\\\", \\\"{x:1338,y:793,t:1527873346967};\\\", \\\"{x:1339,y:791,t:1527873346984};\\\", \\\"{x:1341,y:789,t:1527873347001};\\\", \\\"{x:1345,y:783,t:1527873347017};\\\", \\\"{x:1348,y:780,t:1527873347034};\\\", \\\"{x:1350,y:778,t:1527873347052};\\\", \\\"{x:1350,y:777,t:1527873347067};\\\", \\\"{x:1351,y:776,t:1527873347084};\\\", \\\"{x:1352,y:776,t:1527873347156};\\\", \\\"{x:1352,y:775,t:1527873347168};\\\", \\\"{x:1353,y:773,t:1527873347185};\\\", \\\"{x:1355,y:772,t:1527873347201};\\\", \\\"{x:1355,y:771,t:1527873347428};\\\", \\\"{x:1356,y:769,t:1527873347435};\\\", \\\"{x:1357,y:767,t:1527873347450};\\\", \\\"{x:1360,y:758,t:1527873347467};\\\", \\\"{x:1365,y:751,t:1527873347484};\\\", \\\"{x:1368,y:743,t:1527873347501};\\\", \\\"{x:1373,y:733,t:1527873347517};\\\", \\\"{x:1377,y:723,t:1527873347534};\\\", \\\"{x:1379,y:720,t:1527873347550};\\\", \\\"{x:1382,y:719,t:1527873347772};\\\", \\\"{x:1384,y:719,t:1527873347783};\\\", \\\"{x:1386,y:719,t:1527873347800};\\\", \\\"{x:1390,y:721,t:1527873347818};\\\", \\\"{x:1392,y:724,t:1527873347834};\\\", \\\"{x:1394,y:725,t:1527873347850};\\\", \\\"{x:1397,y:728,t:1527873347867};\\\", \\\"{x:1400,y:732,t:1527873347883};\\\", \\\"{x:1404,y:738,t:1527873347900};\\\", \\\"{x:1404,y:740,t:1527873347917};\\\", \\\"{x:1405,y:741,t:1527873347934};\\\", \\\"{x:1405,y:743,t:1527873347950};\\\", \\\"{x:1405,y:744,t:1527873347972};\\\", \\\"{x:1405,y:745,t:1527873347983};\\\", \\\"{x:1404,y:746,t:1527873348000};\\\", \\\"{x:1403,y:747,t:1527873348017};\\\", \\\"{x:1402,y:747,t:1527873348052};\\\", \\\"{x:1401,y:747,t:1527873348076};\\\", \\\"{x:1400,y:748,t:1527873348084};\\\", \\\"{x:1400,y:749,t:1527873348100};\\\", \\\"{x:1398,y:750,t:1527873348117};\\\", \\\"{x:1397,y:750,t:1527873348133};\\\", \\\"{x:1395,y:752,t:1527873348156};\\\", \\\"{x:1394,y:752,t:1527873348172};\\\", \\\"{x:1393,y:753,t:1527873348188};\\\", \\\"{x:1392,y:753,t:1527873348228};\\\", \\\"{x:1391,y:755,t:1527873348277};\\\", \\\"{x:1390,y:756,t:1527873348308};\\\", \\\"{x:1389,y:756,t:1527873348460};\\\", \\\"{x:1388,y:757,t:1527873348468};\\\", \\\"{x:1387,y:758,t:1527873348508};\\\", \\\"{x:1386,y:758,t:1527873348524};\\\", \\\"{x:1385,y:759,t:1527873348548};\\\", \\\"{x:1385,y:760,t:1527873348564};\\\", \\\"{x:1382,y:761,t:1527873348572};\\\", \\\"{x:1381,y:761,t:1527873348589};\\\", \\\"{x:1379,y:762,t:1527873348601};\\\", \\\"{x:1378,y:762,t:1527873348617};\\\", \\\"{x:1376,y:763,t:1527873348634};\\\", \\\"{x:1373,y:764,t:1527873348649};\\\", \\\"{x:1371,y:765,t:1527873348666};\\\", \\\"{x:1369,y:766,t:1527873348682};\\\", \\\"{x:1365,y:766,t:1527873348699};\\\", \\\"{x:1364,y:766,t:1527873348981};\\\", \\\"{x:1363,y:766,t:1527873348988};\\\", \\\"{x:1362,y:766,t:1527873348999};\\\", \\\"{x:1360,y:766,t:1527873349016};\\\", \\\"{x:1359,y:766,t:1527873349033};\\\", \\\"{x:1356,y:766,t:1527873349049};\\\", \\\"{x:1354,y:766,t:1527873349066};\\\", \\\"{x:1353,y:766,t:1527873349084};\\\", \\\"{x:1352,y:766,t:1527873349357};\\\", \\\"{x:1355,y:769,t:1527873349366};\\\", \\\"{x:1372,y:778,t:1527873349382};\\\", \\\"{x:1385,y:786,t:1527873349399};\\\", \\\"{x:1403,y:795,t:1527873349416};\\\", \\\"{x:1416,y:803,t:1527873349432};\\\", \\\"{x:1425,y:810,t:1527873349449};\\\", \\\"{x:1430,y:815,t:1527873349466};\\\", \\\"{x:1434,y:819,t:1527873349481};\\\", \\\"{x:1439,y:827,t:1527873349499};\\\", \\\"{x:1442,y:840,t:1527873349515};\\\", \\\"{x:1444,y:851,t:1527873349532};\\\", \\\"{x:1447,y:865,t:1527873349549};\\\", \\\"{x:1448,y:878,t:1527873349565};\\\", \\\"{x:1449,y:889,t:1527873349581};\\\", \\\"{x:1450,y:903,t:1527873349598};\\\", \\\"{x:1450,y:916,t:1527873349615};\\\", \\\"{x:1450,y:927,t:1527873349632};\\\", \\\"{x:1452,y:934,t:1527873349649};\\\", \\\"{x:1453,y:939,t:1527873349665};\\\", \\\"{x:1453,y:941,t:1527873349682};\\\", \\\"{x:1453,y:942,t:1527873349699};\\\", \\\"{x:1453,y:943,t:1527873349715};\\\", \\\"{x:1453,y:947,t:1527873349732};\\\", \\\"{x:1450,y:949,t:1527873349749};\\\", \\\"{x:1446,y:951,t:1527873349765};\\\", \\\"{x:1440,y:953,t:1527873349782};\\\", \\\"{x:1427,y:958,t:1527873349799};\\\", \\\"{x:1412,y:964,t:1527873349815};\\\", \\\"{x:1398,y:968,t:1527873349832};\\\", \\\"{x:1380,y:973,t:1527873349849};\\\", \\\"{x:1372,y:975,t:1527873349865};\\\", \\\"{x:1368,y:976,t:1527873349882};\\\", \\\"{x:1366,y:977,t:1527873349899};\\\", \\\"{x:1363,y:978,t:1527873349915};\\\", \\\"{x:1362,y:978,t:1527873349932};\\\", \\\"{x:1363,y:978,t:1527873350068};\\\", \\\"{x:1367,y:978,t:1527873350082};\\\", \\\"{x:1375,y:978,t:1527873350099};\\\", \\\"{x:1390,y:978,t:1527873350116};\\\", \\\"{x:1418,y:977,t:1527873350133};\\\", \\\"{x:1433,y:976,t:1527873350149};\\\", \\\"{x:1440,y:976,t:1527873350166};\\\", \\\"{x:1443,y:976,t:1527873350182};\\\", \\\"{x:1444,y:976,t:1527873350199};\\\", \\\"{x:1447,y:976,t:1527873350300};\\\", \\\"{x:1450,y:976,t:1527873350316};\\\", \\\"{x:1456,y:976,t:1527873350332};\\\", \\\"{x:1460,y:975,t:1527873350348};\\\", \\\"{x:1464,y:975,t:1527873350365};\\\", \\\"{x:1469,y:975,t:1527873350382};\\\", \\\"{x:1473,y:975,t:1527873350397};\\\", \\\"{x:1474,y:975,t:1527873350414};\\\", \\\"{x:1475,y:975,t:1527873350432};\\\", \\\"{x:1476,y:975,t:1527873350451};\\\", \\\"{x:1477,y:975,t:1527873350716};\\\", \\\"{x:1481,y:975,t:1527873350731};\\\", \\\"{x:1503,y:975,t:1527873350748};\\\", \\\"{x:1515,y:975,t:1527873350765};\\\", \\\"{x:1524,y:975,t:1527873350781};\\\", \\\"{x:1530,y:973,t:1527873350798};\\\", \\\"{x:1531,y:973,t:1527873350815};\\\", \\\"{x:1532,y:973,t:1527873350885};\\\", \\\"{x:1533,y:973,t:1527873350898};\\\", \\\"{x:1534,y:973,t:1527873350915};\\\", \\\"{x:1535,y:973,t:1527873350931};\\\", \\\"{x:1536,y:973,t:1527873350948};\\\", \\\"{x:1537,y:973,t:1527873350988};\\\", \\\"{x:1537,y:972,t:1527873351301};\\\", \\\"{x:1542,y:972,t:1527873351612};\\\", \\\"{x:1554,y:972,t:1527873351620};\\\", \\\"{x:1570,y:968,t:1527873351632};\\\", \\\"{x:1595,y:968,t:1527873351647};\\\", \\\"{x:1616,y:968,t:1527873351664};\\\", \\\"{x:1632,y:967,t:1527873351681};\\\", \\\"{x:1640,y:967,t:1527873351697};\\\", \\\"{x:1642,y:966,t:1527873351714};\\\", \\\"{x:1642,y:960,t:1527873351772};\\\", \\\"{x:1636,y:947,t:1527873351781};\\\", \\\"{x:1607,y:900,t:1527873351797};\\\", \\\"{x:1567,y:853,t:1527873351815};\\\", \\\"{x:1519,y:807,t:1527873351831};\\\", \\\"{x:1466,y:771,t:1527873351848};\\\", \\\"{x:1420,y:746,t:1527873351864};\\\", \\\"{x:1390,y:733,t:1527873351880};\\\", \\\"{x:1379,y:726,t:1527873351898};\\\", \\\"{x:1373,y:723,t:1527873351915};\\\", \\\"{x:1370,y:721,t:1527873351931};\\\", \\\"{x:1368,y:718,t:1527873351948};\\\", \\\"{x:1367,y:717,t:1527873351965};\\\", \\\"{x:1367,y:716,t:1527873351980};\\\", \\\"{x:1366,y:716,t:1527873351997};\\\", \\\"{x:1365,y:714,t:1527873352020};\\\", \\\"{x:1361,y:711,t:1527873352165};\\\", \\\"{x:1350,y:702,t:1527873352181};\\\", \\\"{x:1339,y:695,t:1527873352198};\\\", \\\"{x:1334,y:691,t:1527873352214};\\\", \\\"{x:1333,y:691,t:1527873352243};\\\", \\\"{x:1332,y:691,t:1527873352261};\\\", \\\"{x:1331,y:691,t:1527873352276};\\\", \\\"{x:1330,y:691,t:1527873352284};\\\", \\\"{x:1329,y:691,t:1527873352324};\\\", \\\"{x:1329,y:692,t:1527873352452};\\\", \\\"{x:1330,y:692,t:1527873352463};\\\", \\\"{x:1333,y:694,t:1527873352481};\\\", \\\"{x:1336,y:696,t:1527873352498};\\\", \\\"{x:1341,y:697,t:1527873352514};\\\", \\\"{x:1347,y:700,t:1527873352531};\\\", \\\"{x:1349,y:701,t:1527873352548};\\\", \\\"{x:1351,y:701,t:1527873352563};\\\", \\\"{x:1351,y:702,t:1527873352581};\\\", \\\"{x:1354,y:712,t:1527873354727};\\\", \\\"{x:1356,y:725,t:1527873354739};\\\", \\\"{x:1358,y:744,t:1527873354756};\\\", \\\"{x:1363,y:762,t:1527873354773};\\\", \\\"{x:1365,y:784,t:1527873354789};\\\", \\\"{x:1370,y:815,t:1527873354806};\\\", \\\"{x:1370,y:830,t:1527873354823};\\\", \\\"{x:1370,y:838,t:1527873354839};\\\", \\\"{x:1370,y:843,t:1527873354856};\\\", \\\"{x:1370,y:851,t:1527873354873};\\\", \\\"{x:1373,y:864,t:1527873354889};\\\", \\\"{x:1378,y:874,t:1527873354906};\\\", \\\"{x:1382,y:881,t:1527873354926};\\\", \\\"{x:1387,y:891,t:1527873354939};\\\", \\\"{x:1394,y:902,t:1527873354955};\\\", \\\"{x:1399,y:909,t:1527873354972};\\\", \\\"{x:1402,y:917,t:1527873354989};\\\", \\\"{x:1409,y:932,t:1527873355005};\\\", \\\"{x:1413,y:940,t:1527873355022};\\\", \\\"{x:1419,y:949,t:1527873355038};\\\", \\\"{x:1423,y:954,t:1527873355055};\\\", \\\"{x:1426,y:957,t:1527873355073};\\\", \\\"{x:1431,y:962,t:1527873355088};\\\", \\\"{x:1436,y:969,t:1527873355105};\\\", \\\"{x:1441,y:975,t:1527873355122};\\\", \\\"{x:1444,y:979,t:1527873355139};\\\", \\\"{x:1444,y:981,t:1527873355156};\\\", \\\"{x:1445,y:982,t:1527873355172};\\\", \\\"{x:1445,y:983,t:1527873355189};\\\", \\\"{x:1445,y:984,t:1527873355206};\\\", \\\"{x:1445,y:985,t:1527873355350};\\\", \\\"{x:1444,y:985,t:1527873355358};\\\", \\\"{x:1442,y:985,t:1527873355372};\\\", \\\"{x:1438,y:984,t:1527873355389};\\\", \\\"{x:1433,y:982,t:1527873355407};\\\", \\\"{x:1431,y:981,t:1527873355422};\\\", \\\"{x:1430,y:980,t:1527873355438};\\\", \\\"{x:1429,y:978,t:1527873355456};\\\", \\\"{x:1428,y:978,t:1527873355574};\\\", \\\"{x:1427,y:977,t:1527873355598};\\\", \\\"{x:1426,y:976,t:1527873355614};\\\", \\\"{x:1425,y:976,t:1527873355695};\\\", \\\"{x:1424,y:976,t:1527873356079};\\\", \\\"{x:1423,y:975,t:1527873356088};\\\", \\\"{x:1423,y:973,t:1527873356105};\\\", \\\"{x:1422,y:971,t:1527873356122};\\\", \\\"{x:1421,y:971,t:1527873356137};\\\", \\\"{x:1421,y:970,t:1527873356502};\\\", \\\"{x:1423,y:970,t:1527873356518};\\\", \\\"{x:1425,y:970,t:1527873356550};\\\", \\\"{x:1426,y:971,t:1527873356566};\\\", \\\"{x:1428,y:971,t:1527873356574};\\\", \\\"{x:1428,y:972,t:1527873356588};\\\", \\\"{x:1431,y:972,t:1527873356605};\\\", \\\"{x:1437,y:972,t:1527873356621};\\\", \\\"{x:1444,y:972,t:1527873356638};\\\", \\\"{x:1449,y:972,t:1527873356654};\\\", \\\"{x:1456,y:972,t:1527873356671};\\\", \\\"{x:1460,y:972,t:1527873356688};\\\", \\\"{x:1463,y:973,t:1527873356706};\\\", \\\"{x:1464,y:973,t:1527873356721};\\\", \\\"{x:1467,y:974,t:1527873356737};\\\", \\\"{x:1468,y:975,t:1527873356755};\\\", \\\"{x:1469,y:975,t:1527873356770};\\\", \\\"{x:1470,y:976,t:1527873356788};\\\", \\\"{x:1473,y:976,t:1527873356804};\\\", \\\"{x:1474,y:978,t:1527873356820};\\\", \\\"{x:1475,y:978,t:1527873356837};\\\", \\\"{x:1476,y:978,t:1527873356855};\\\", \\\"{x:1477,y:978,t:1527873356877};\\\", \\\"{x:1478,y:978,t:1527873356910};\\\", \\\"{x:1480,y:979,t:1527873356926};\\\", \\\"{x:1482,y:979,t:1527873357375};\\\", \\\"{x:1487,y:979,t:1527873357387};\\\", \\\"{x:1504,y:977,t:1527873357405};\\\", \\\"{x:1523,y:977,t:1527873357421};\\\", \\\"{x:1541,y:977,t:1527873357438};\\\", \\\"{x:1559,y:977,t:1527873357454};\\\", \\\"{x:1561,y:977,t:1527873357470};\\\", \\\"{x:1563,y:977,t:1527873357758};\\\", \\\"{x:1565,y:977,t:1527873357774};\\\", \\\"{x:1568,y:977,t:1527873357787};\\\", \\\"{x:1573,y:977,t:1527873357804};\\\", \\\"{x:1576,y:977,t:1527873357820};\\\", \\\"{x:1579,y:978,t:1527873357837};\\\", \\\"{x:1581,y:978,t:1527873357854};\\\", \\\"{x:1584,y:980,t:1527873357870};\\\", \\\"{x:1587,y:981,t:1527873357887};\\\", \\\"{x:1588,y:982,t:1527873357904};\\\", \\\"{x:1590,y:982,t:1527873357920};\\\", \\\"{x:1591,y:983,t:1527873357937};\\\", \\\"{x:1592,y:983,t:1527873357954};\\\", \\\"{x:1593,y:984,t:1527873357970};\\\", \\\"{x:1594,y:984,t:1527873357987};\\\", \\\"{x:1596,y:984,t:1527873358004};\\\", \\\"{x:1598,y:984,t:1527873358020};\\\", \\\"{x:1600,y:983,t:1527873358037};\\\", \\\"{x:1605,y:982,t:1527873358054};\\\", \\\"{x:1607,y:981,t:1527873358070};\\\", \\\"{x:1608,y:980,t:1527873358086};\\\", \\\"{x:1609,y:980,t:1527873358126};\\\", \\\"{x:1609,y:979,t:1527873363511};\\\", \\\"{x:1608,y:979,t:1527873363550};\\\", \\\"{x:1607,y:979,t:1527873363607};\\\", \\\"{x:1607,y:978,t:1527873364254};\\\", \\\"{x:1606,y:978,t:1527873364267};\\\", \\\"{x:1605,y:977,t:1527873364302};\\\", \\\"{x:1604,y:976,t:1527873364367};\\\", \\\"{x:1603,y:976,t:1527873364446};\\\", \\\"{x:1602,y:976,t:1527873364486};\\\", \\\"{x:1601,y:976,t:1527873364499};\\\", \\\"{x:1599,y:974,t:1527873364516};\\\", \\\"{x:1599,y:964,t:1527873364533};\\\", \\\"{x:1597,y:952,t:1527873364549};\\\", \\\"{x:1594,y:932,t:1527873364565};\\\", \\\"{x:1594,y:911,t:1527873364582};\\\", \\\"{x:1590,y:888,t:1527873364598};\\\", \\\"{x:1576,y:857,t:1527873364616};\\\", \\\"{x:1555,y:814,t:1527873364632};\\\", \\\"{x:1519,y:754,t:1527873364649};\\\", \\\"{x:1465,y:688,t:1527873364665};\\\", \\\"{x:1410,y:644,t:1527873364682};\\\", \\\"{x:1379,y:630,t:1527873364699};\\\", \\\"{x:1370,y:625,t:1527873364715};\\\", \\\"{x:1362,y:621,t:1527873364732};\\\", \\\"{x:1350,y:616,t:1527873364749};\\\", \\\"{x:1338,y:611,t:1527873364765};\\\", \\\"{x:1331,y:609,t:1527873364783};\\\", \\\"{x:1330,y:608,t:1527873364799};\\\", \\\"{x:1329,y:608,t:1527873365078};\\\", \\\"{x:1329,y:606,t:1527873365086};\\\", \\\"{x:1329,y:604,t:1527873365098};\\\", \\\"{x:1326,y:600,t:1527873365115};\\\", \\\"{x:1320,y:595,t:1527873365132};\\\", \\\"{x:1317,y:593,t:1527873365148};\\\", \\\"{x:1317,y:590,t:1527873365165};\\\", \\\"{x:1317,y:583,t:1527873365182};\\\", \\\"{x:1318,y:578,t:1527873365198};\\\", \\\"{x:1322,y:573,t:1527873365215};\\\", \\\"{x:1324,y:569,t:1527873365233};\\\", \\\"{x:1324,y:568,t:1527873365248};\\\", \\\"{x:1324,y:567,t:1527873365399};\\\", \\\"{x:1318,y:567,t:1527873365415};\\\", \\\"{x:1301,y:567,t:1527873365432};\\\", \\\"{x:1282,y:567,t:1527873365449};\\\", \\\"{x:1258,y:567,t:1527873365467};\\\", \\\"{x:1234,y:569,t:1527873365483};\\\", \\\"{x:1199,y:575,t:1527873365498};\\\", \\\"{x:1154,y:582,t:1527873365515};\\\", \\\"{x:1112,y:586,t:1527873365531};\\\", \\\"{x:1081,y:591,t:1527873365548};\\\", \\\"{x:1051,y:596,t:1527873365565};\\\", \\\"{x:1022,y:604,t:1527873365581};\\\", \\\"{x:986,y:614,t:1527873365598};\\\", \\\"{x:969,y:621,t:1527873365615};\\\", \\\"{x:956,y:628,t:1527873365631};\\\", \\\"{x:946,y:634,t:1527873365648};\\\", \\\"{x:937,y:639,t:1527873365664};\\\", \\\"{x:922,y:647,t:1527873365681};\\\", \\\"{x:908,y:655,t:1527873365698};\\\", \\\"{x:899,y:660,t:1527873365715};\\\", \\\"{x:893,y:664,t:1527873365731};\\\", \\\"{x:891,y:665,t:1527873365748};\\\", \\\"{x:890,y:665,t:1527873365765};\\\", \\\"{x:889,y:666,t:1527873365781};\\\", \\\"{x:886,y:667,t:1527873365798};\\\", \\\"{x:882,y:669,t:1527873365815};\\\", \\\"{x:876,y:672,t:1527873365831};\\\", \\\"{x:867,y:675,t:1527873365848};\\\", \\\"{x:853,y:681,t:1527873365865};\\\", \\\"{x:833,y:686,t:1527873365881};\\\", \\\"{x:820,y:688,t:1527873365898};\\\", \\\"{x:809,y:692,t:1527873365915};\\\", \\\"{x:801,y:695,t:1527873365931};\\\", \\\"{x:795,y:697,t:1527873365947};\\\", \\\"{x:791,y:699,t:1527873365964};\\\", \\\"{x:786,y:701,t:1527873365981};\\\", \\\"{x:777,y:705,t:1527873365997};\\\", \\\"{x:772,y:707,t:1527873366014};\\\", \\\"{x:769,y:709,t:1527873366031};\\\", \\\"{x:767,y:709,t:1527873366048};\\\", \\\"{x:766,y:711,t:1527873366064};\\\", \\\"{x:764,y:712,t:1527873366081};\\\", \\\"{x:769,y:712,t:1527873366271};\\\", \\\"{x:777,y:708,t:1527873366281};\\\", \\\"{x:800,y:695,t:1527873366299};\\\", \\\"{x:830,y:683,t:1527873366314};\\\", \\\"{x:853,y:681,t:1527873366331};\\\", \\\"{x:877,y:681,t:1527873366348};\\\", \\\"{x:902,y:680,t:1527873366364};\\\", \\\"{x:933,y:675,t:1527873366381};\\\", \\\"{x:1021,y:662,t:1527873366398};\\\", \\\"{x:1110,y:637,t:1527873366415};\\\", \\\"{x:1187,y:615,t:1527873366432};\\\", \\\"{x:1257,y:593,t:1527873366448};\\\", \\\"{x:1313,y:577,t:1527873366464};\\\", \\\"{x:1341,y:570,t:1527873366481};\\\", \\\"{x:1364,y:563,t:1527873366497};\\\", \\\"{x:1385,y:558,t:1527873366515};\\\", \\\"{x:1398,y:557,t:1527873366532};\\\", \\\"{x:1399,y:557,t:1527873366547};\\\", \\\"{x:1397,y:557,t:1527873366839};\\\", \\\"{x:1393,y:559,t:1527873366847};\\\", \\\"{x:1391,y:559,t:1527873366864};\\\", \\\"{x:1390,y:559,t:1527873366894};\\\", \\\"{x:1389,y:560,t:1527873366902};\\\", \\\"{x:1388,y:560,t:1527873366918};\\\", \\\"{x:1388,y:562,t:1527873366931};\\\", \\\"{x:1388,y:567,t:1527873366948};\\\", \\\"{x:1388,y:578,t:1527873366965};\\\", \\\"{x:1394,y:594,t:1527873366981};\\\", \\\"{x:1404,y:614,t:1527873366998};\\\", \\\"{x:1416,y:640,t:1527873367014};\\\", \\\"{x:1423,y:660,t:1527873367031};\\\", \\\"{x:1432,y:681,t:1527873367048};\\\", \\\"{x:1443,y:704,t:1527873367064};\\\", \\\"{x:1448,y:725,t:1527873367080};\\\", \\\"{x:1448,y:737,t:1527873367097};\\\", \\\"{x:1448,y:746,t:1527873367114};\\\", \\\"{x:1447,y:755,t:1527873367130};\\\", \\\"{x:1443,y:764,t:1527873367148};\\\", \\\"{x:1436,y:775,t:1527873367164};\\\", \\\"{x:1428,y:785,t:1527873367181};\\\", \\\"{x:1418,y:795,t:1527873367197};\\\", \\\"{x:1399,y:804,t:1527873367214};\\\", \\\"{x:1386,y:806,t:1527873367231};\\\", \\\"{x:1373,y:806,t:1527873367247};\\\", \\\"{x:1362,y:799,t:1527873367264};\\\", \\\"{x:1352,y:782,t:1527873367280};\\\", \\\"{x:1340,y:752,t:1527873367297};\\\", \\\"{x:1318,y:714,t:1527873367314};\\\", \\\"{x:1291,y:675,t:1527873367330};\\\", \\\"{x:1273,y:648,t:1527873367347};\\\", \\\"{x:1264,y:631,t:1527873367363};\\\", \\\"{x:1260,y:626,t:1527873367379};\\\", \\\"{x:1257,y:622,t:1527873367396};\\\", \\\"{x:1257,y:635,t:1527873367534};\\\", \\\"{x:1258,y:652,t:1527873367547};\\\", \\\"{x:1261,y:686,t:1527873367563};\\\", \\\"{x:1267,y:711,t:1527873367580};\\\", \\\"{x:1273,y:732,t:1527873367597};\\\", \\\"{x:1280,y:751,t:1527873367613};\\\", \\\"{x:1283,y:771,t:1527873367630};\\\", \\\"{x:1285,y:787,t:1527873367647};\\\", \\\"{x:1285,y:804,t:1527873367663};\\\", \\\"{x:1288,y:820,t:1527873367681};\\\", \\\"{x:1289,y:834,t:1527873367698};\\\", \\\"{x:1289,y:845,t:1527873367713};\\\", \\\"{x:1289,y:856,t:1527873367731};\\\", \\\"{x:1289,y:867,t:1527873367747};\\\", \\\"{x:1289,y:879,t:1527873367763};\\\", \\\"{x:1289,y:891,t:1527873367780};\\\", \\\"{x:1289,y:904,t:1527873367796};\\\", \\\"{x:1287,y:913,t:1527873367813};\\\", \\\"{x:1285,y:921,t:1527873367830};\\\", \\\"{x:1285,y:924,t:1527873367846};\\\", \\\"{x:1285,y:925,t:1527873367871};\\\", \\\"{x:1285,y:928,t:1527873367886};\\\", \\\"{x:1285,y:929,t:1527873367896};\\\", \\\"{x:1285,y:933,t:1527873367913};\\\", \\\"{x:1285,y:939,t:1527873367930};\\\", \\\"{x:1285,y:944,t:1527873367946};\\\", \\\"{x:1285,y:952,t:1527873367964};\\\", \\\"{x:1285,y:960,t:1527873367981};\\\", \\\"{x:1288,y:966,t:1527873367996};\\\", \\\"{x:1288,y:968,t:1527873368013};\\\", \\\"{x:1290,y:969,t:1527873368031};\\\", \\\"{x:1290,y:970,t:1527873368046};\\\", \\\"{x:1291,y:971,t:1527873368063};\\\", \\\"{x:1293,y:976,t:1527873368081};\\\", \\\"{x:1293,y:978,t:1527873368096};\\\", \\\"{x:1293,y:980,t:1527873368113};\\\", \\\"{x:1294,y:980,t:1527873368438};\\\", \\\"{x:1295,y:980,t:1527873368574};\\\", \\\"{x:1296,y:980,t:1527873368598};\\\", \\\"{x:1297,y:980,t:1527873368710};\\\", \\\"{x:1297,y:978,t:1527873368718};\\\", \\\"{x:1300,y:972,t:1527873368729};\\\", \\\"{x:1302,y:969,t:1527873368747};\\\", \\\"{x:1304,y:966,t:1527873368762};\\\", \\\"{x:1305,y:965,t:1527873368779};\\\", \\\"{x:1306,y:964,t:1527873368943};\\\", \\\"{x:1308,y:964,t:1527873368950};\\\", \\\"{x:1311,y:964,t:1527873368962};\\\", \\\"{x:1319,y:964,t:1527873368979};\\\", \\\"{x:1328,y:964,t:1527873368996};\\\", \\\"{x:1341,y:964,t:1527873369012};\\\", \\\"{x:1349,y:964,t:1527873369029};\\\", \\\"{x:1358,y:964,t:1527873369046};\\\", \\\"{x:1359,y:964,t:1527873369062};\\\", \\\"{x:1360,y:964,t:1527873369079};\\\", \\\"{x:1361,y:964,t:1527873369095};\\\", \\\"{x:1365,y:964,t:1527873369598};\\\", \\\"{x:1370,y:964,t:1527873369613};\\\", \\\"{x:1383,y:964,t:1527873369628};\\\", \\\"{x:1393,y:964,t:1527873369646};\\\", \\\"{x:1403,y:966,t:1527873369662};\\\", \\\"{x:1404,y:966,t:1527873369679};\\\", \\\"{x:1405,y:966,t:1527873369695};\\\", \\\"{x:1405,y:967,t:1527873369712};\\\", \\\"{x:1406,y:967,t:1527873369758};\\\", \\\"{x:1407,y:967,t:1527873369774};\\\", \\\"{x:1408,y:967,t:1527873369790};\\\", \\\"{x:1408,y:968,t:1527873369798};\\\", \\\"{x:1409,y:968,t:1527873369814};\\\", \\\"{x:1411,y:968,t:1527873369828};\\\", \\\"{x:1412,y:969,t:1527873369846};\\\", \\\"{x:1414,y:970,t:1527873369862};\\\", \\\"{x:1416,y:970,t:1527873369886};\\\", \\\"{x:1416,y:971,t:1527873369895};\\\", \\\"{x:1415,y:971,t:1527873373126};\\\", \\\"{x:1413,y:971,t:1527873373144};\\\", \\\"{x:1411,y:970,t:1527873373160};\\\", \\\"{x:1410,y:970,t:1527873373182};\\\", \\\"{x:1410,y:969,t:1527873373286};\\\", \\\"{x:1411,y:969,t:1527873373638};\\\", \\\"{x:1414,y:970,t:1527873373702};\\\", \\\"{x:1417,y:971,t:1527873373709};\\\", \\\"{x:1425,y:973,t:1527873373726};\\\", \\\"{x:1434,y:975,t:1527873373743};\\\", \\\"{x:1444,y:977,t:1527873373760};\\\", \\\"{x:1457,y:978,t:1527873373775};\\\", \\\"{x:1473,y:980,t:1527873373793};\\\", \\\"{x:1485,y:983,t:1527873373809};\\\", \\\"{x:1495,y:984,t:1527873373825};\\\", \\\"{x:1501,y:985,t:1527873373843};\\\", \\\"{x:1502,y:985,t:1527873373860};\\\", \\\"{x:1499,y:984,t:1527873374031};\\\", \\\"{x:1497,y:982,t:1527873374043};\\\", \\\"{x:1494,y:981,t:1527873374059};\\\", \\\"{x:1493,y:980,t:1527873374076};\\\", \\\"{x:1491,y:979,t:1527873374093};\\\", \\\"{x:1489,y:979,t:1527873374150};\\\", \\\"{x:1488,y:978,t:1527873374158};\\\", \\\"{x:1486,y:977,t:1527873374175};\\\", \\\"{x:1485,y:976,t:1527873374191};\\\", \\\"{x:1488,y:976,t:1527873374454};\\\", \\\"{x:1494,y:976,t:1527873374462};\\\", \\\"{x:1503,y:977,t:1527873374476};\\\", \\\"{x:1517,y:979,t:1527873374492};\\\", \\\"{x:1526,y:979,t:1527873374508};\\\", \\\"{x:1535,y:981,t:1527873374526};\\\", \\\"{x:1538,y:981,t:1527873374542};\\\", \\\"{x:1541,y:981,t:1527873374559};\\\", \\\"{x:1540,y:981,t:1527873374846};\\\", \\\"{x:1539,y:980,t:1527873374886};\\\", \\\"{x:1538,y:980,t:1527873374901};\\\", \\\"{x:1536,y:979,t:1527873374926};\\\", \\\"{x:1537,y:979,t:1527873375206};\\\", \\\"{x:1544,y:979,t:1527873375214};\\\", \\\"{x:1551,y:979,t:1527873375224};\\\", \\\"{x:1567,y:979,t:1527873375242};\\\", \\\"{x:1579,y:979,t:1527873375259};\\\", \\\"{x:1587,y:979,t:1527873375275};\\\", \\\"{x:1591,y:979,t:1527873375291};\\\", \\\"{x:1592,y:979,t:1527873375374};\\\", \\\"{x:1594,y:979,t:1527873375398};\\\", \\\"{x:1596,y:979,t:1527873375414};\\\", \\\"{x:1597,y:979,t:1527873375502};\\\", \\\"{x:1597,y:978,t:1527873375958};\\\", \\\"{x:1596,y:978,t:1527873375990};\\\", \\\"{x:1595,y:978,t:1527873375998};\\\", \\\"{x:1595,y:977,t:1527873376008};\\\", \\\"{x:1594,y:977,t:1527873376030};\\\", \\\"{x:1592,y:976,t:1527873376041};\\\", \\\"{x:1591,y:975,t:1527873376062};\\\", \\\"{x:1590,y:975,t:1527873376078};\\\", \\\"{x:1589,y:975,t:1527873376091};\\\", \\\"{x:1587,y:974,t:1527873376110};\\\", \\\"{x:1586,y:972,t:1527873376125};\\\", \\\"{x:1582,y:972,t:1527873376141};\\\", \\\"{x:1575,y:956,t:1527873376157};\\\", \\\"{x:1571,y:937,t:1527873376174};\\\", \\\"{x:1566,y:919,t:1527873376191};\\\", \\\"{x:1560,y:902,t:1527873376207};\\\", \\\"{x:1555,y:886,t:1527873376224};\\\", \\\"{x:1549,y:873,t:1527873376241};\\\", \\\"{x:1543,y:861,t:1527873376258};\\\", \\\"{x:1535,y:849,t:1527873376275};\\\", \\\"{x:1527,y:840,t:1527873376290};\\\", \\\"{x:1521,y:833,t:1527873376308};\\\", \\\"{x:1516,y:828,t:1527873376325};\\\", \\\"{x:1509,y:823,t:1527873376340};\\\", \\\"{x:1497,y:816,t:1527873376359};\\\", \\\"{x:1482,y:810,t:1527873376374};\\\", \\\"{x:1465,y:803,t:1527873376391};\\\", \\\"{x:1440,y:794,t:1527873376408};\\\", \\\"{x:1408,y:786,t:1527873376425};\\\", \\\"{x:1368,y:779,t:1527873376440};\\\", \\\"{x:1335,y:773,t:1527873376458};\\\", \\\"{x:1302,y:768,t:1527873376474};\\\", \\\"{x:1266,y:765,t:1527873376490};\\\", \\\"{x:1230,y:761,t:1527873376506};\\\", \\\"{x:1197,y:756,t:1527873376523};\\\", \\\"{x:1173,y:752,t:1527873376540};\\\", \\\"{x:1143,y:748,t:1527873376556};\\\", \\\"{x:1127,y:745,t:1527873376572};\\\", \\\"{x:1118,y:744,t:1527873376590};\\\", \\\"{x:1115,y:744,t:1527873376607};\\\", \\\"{x:1114,y:743,t:1527873376623};\\\", \\\"{x:1115,y:743,t:1527873376934};\\\", \\\"{x:1123,y:746,t:1527873376942};\\\", \\\"{x:1129,y:750,t:1527873376957};\\\", \\\"{x:1144,y:761,t:1527873376974};\\\", \\\"{x:1154,y:769,t:1527873376991};\\\", \\\"{x:1164,y:779,t:1527873377006};\\\", \\\"{x:1168,y:783,t:1527873377023};\\\", \\\"{x:1169,y:786,t:1527873377040};\\\", \\\"{x:1170,y:785,t:1527873377358};\\\", \\\"{x:1171,y:783,t:1527873377374};\\\", \\\"{x:1171,y:781,t:1527873377390};\\\", \\\"{x:1171,y:779,t:1527873377407};\\\", \\\"{x:1171,y:778,t:1527873377424};\\\", \\\"{x:1171,y:776,t:1527873377440};\\\", \\\"{x:1171,y:774,t:1527873377457};\\\", \\\"{x:1171,y:770,t:1527873377473};\\\", \\\"{x:1171,y:769,t:1527873377517};\\\", \\\"{x:1169,y:767,t:1527873377525};\\\", \\\"{x:1167,y:764,t:1527873377540};\\\", \\\"{x:1160,y:754,t:1527873377556};\\\", \\\"{x:1125,y:714,t:1527873377574};\\\", \\\"{x:1099,y:693,t:1527873377589};\\\", \\\"{x:1039,y:658,t:1527873377607};\\\", \\\"{x:962,y:614,t:1527873377624};\\\", \\\"{x:858,y:571,t:1527873377641};\\\", \\\"{x:746,y:533,t:1527873377656};\\\", \\\"{x:642,y:507,t:1527873377674};\\\", \\\"{x:546,y:490,t:1527873377690};\\\", \\\"{x:466,y:481,t:1527873377708};\\\", \\\"{x:430,y:475,t:1527873377724};\\\", \\\"{x:403,y:475,t:1527873377740};\\\", \\\"{x:387,y:476,t:1527873377757};\\\", \\\"{x:382,y:478,t:1527873377774};\\\", \\\"{x:380,y:479,t:1527873377789};\\\", \\\"{x:378,y:480,t:1527873377807};\\\", \\\"{x:374,y:481,t:1527873377824};\\\", \\\"{x:368,y:484,t:1527873377840};\\\", \\\"{x:362,y:486,t:1527873377857};\\\", \\\"{x:355,y:489,t:1527873377874};\\\", \\\"{x:347,y:492,t:1527873377890};\\\", \\\"{x:338,y:494,t:1527873377907};\\\", \\\"{x:332,y:495,t:1527873377923};\\\", \\\"{x:326,y:496,t:1527873377940};\\\", \\\"{x:321,y:497,t:1527873377957};\\\", \\\"{x:313,y:502,t:1527873377973};\\\", \\\"{x:309,y:504,t:1527873377990};\\\", \\\"{x:301,y:509,t:1527873378006};\\\", \\\"{x:298,y:510,t:1527873378024};\\\", \\\"{x:298,y:512,t:1527873378040};\\\", \\\"{x:298,y:521,t:1527873378057};\\\", \\\"{x:308,y:538,t:1527873378073};\\\", \\\"{x:325,y:556,t:1527873378092};\\\", \\\"{x:343,y:571,t:1527873378108};\\\", \\\"{x:360,y:587,t:1527873378124};\\\", \\\"{x:377,y:604,t:1527873378142};\\\", \\\"{x:387,y:614,t:1527873378157};\\\", \\\"{x:396,y:626,t:1527873378174};\\\", \\\"{x:407,y:637,t:1527873378191};\\\", \\\"{x:416,y:646,t:1527873378207};\\\", \\\"{x:424,y:655,t:1527873378224};\\\", \\\"{x:430,y:663,t:1527873378241};\\\", \\\"{x:433,y:668,t:1527873378257};\\\", \\\"{x:436,y:672,t:1527873378274};\\\", \\\"{x:438,y:674,t:1527873378291};\\\", \\\"{x:441,y:677,t:1527873378307};\\\", \\\"{x:444,y:682,t:1527873378324};\\\", \\\"{x:448,y:686,t:1527873378340};\\\", \\\"{x:452,y:689,t:1527873378357};\\\", \\\"{x:455,y:693,t:1527873378374};\\\", \\\"{x:460,y:696,t:1527873378392};\\\", \\\"{x:463,y:699,t:1527873378407};\\\", \\\"{x:465,y:701,t:1527873378424};\\\", \\\"{x:467,y:703,t:1527873378441};\\\", \\\"{x:472,y:707,t:1527873378459};\\\", \\\"{x:481,y:716,t:1527873378474};\\\", \\\"{x:487,y:722,t:1527873378493};\\\", \\\"{x:494,y:728,t:1527873378508};\\\", \\\"{x:498,y:732,t:1527873378524};\\\", \\\"{x:503,y:735,t:1527873378541};\\\", \\\"{x:504,y:737,t:1527873378558};\\\", \\\"{x:504,y:739,t:1527873378574};\\\", \\\"{x:504,y:740,t:1527873378597};\\\", \\\"{x:506,y:741,t:1527873378621};\\\", \\\"{x:506,y:742,t:1527873378637};\\\", \\\"{x:508,y:737,t:1527873379582};\\\", \\\"{x:512,y:729,t:1527873379593};\\\", \\\"{x:521,y:719,t:1527873379608};\\\", \\\"{x:526,y:713,t:1527873379625};\\\", \\\"{x:530,y:709,t:1527873379642};\\\", \\\"{x:535,y:704,t:1527873379659};\\\", \\\"{x:541,y:699,t:1527873379675};\\\", \\\"{x:546,y:691,t:1527873379692};\\\", \\\"{x:553,y:677,t:1527873379708};\\\", \\\"{x:561,y:661,t:1527873379725};\\\", \\\"{x:566,y:655,t:1527873379742};\\\", \\\"{x:570,y:645,t:1527873379758};\\\", \\\"{x:576,y:634,t:1527873379775};\\\", \\\"{x:581,y:625,t:1527873379792};\\\", \\\"{x:584,y:616,t:1527873379808};\\\", \\\"{x:589,y:599,t:1527873379825};\\\", \\\"{x:605,y:572,t:1527873379842};\\\", \\\"{x:633,y:542,t:1527873379858};\\\", \\\"{x:668,y:512,t:1527873379875};\\\", \\\"{x:737,y:458,t:1527873379941};\\\", \\\"{x:738,y:457,t:1527873379948};\\\" ] }, { \\\"rt\\\": 14684, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 579579, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -01 PM-07 PM-12 PM-B -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:747,y:457,t:1527873381558};\\\", \\\"{x:777,y:457,t:1527873381565};\\\", \\\"{x:836,y:457,t:1527873381577};\\\", \\\"{x:955,y:457,t:1527873381593};\\\", \\\"{x:1063,y:457,t:1527873381612};\\\", \\\"{x:1154,y:457,t:1527873381627};\\\", \\\"{x:1225,y:453,t:1527873381644};\\\", \\\"{x:1278,y:445,t:1527873381660};\\\", \\\"{x:1353,y:435,t:1527873381678};\\\", \\\"{x:1397,y:429,t:1527873381693};\\\", \\\"{x:1445,y:421,t:1527873381710};\\\", \\\"{x:1514,y:413,t:1527873381727};\\\", \\\"{x:1607,y:395,t:1527873381743};\\\", \\\"{x:1712,y:381,t:1527873381760};\\\", \\\"{x:1824,y:363,t:1527873381777};\\\", \\\"{x:1919,y:343,t:1527873381793};\\\", \\\"{x:1919,y:321,t:1527873381810};\\\", \\\"{x:1919,y:295,t:1527873381827};\\\", \\\"{x:1919,y:281,t:1527873381843};\\\", \\\"{x:1919,y:263,t:1527873381860};\\\", \\\"{x:1919,y:225,t:1527873381876};\\\", \\\"{x:1919,y:202,t:1527873381894};\\\", \\\"{x:1919,y:183,t:1527873381910};\\\", \\\"{x:1919,y:168,t:1527873381927};\\\", \\\"{x:1919,y:158,t:1527873381944};\\\", \\\"{x:1919,y:152,t:1527873381960};\\\", \\\"{x:1919,y:131,t:1527873381977};\\\", \\\"{x:1919,y:109,t:1527873381994};\\\", \\\"{x:1919,y:103,t:1527873382010};\\\", \\\"{x:1919,y:101,t:1527873382029};\\\", \\\"{x:1917,y:101,t:1527873382654};\\\", \\\"{x:1913,y:101,t:1527873382661};\\\", \\\"{x:1904,y:101,t:1527873382679};\\\", \\\"{x:1900,y:101,t:1527873382695};\\\", \\\"{x:1898,y:102,t:1527873382712};\\\", \\\"{x:1897,y:102,t:1527873382728};\\\", \\\"{x:1893,y:102,t:1527873382745};\\\", \\\"{x:1891,y:103,t:1527873382761};\\\", \\\"{x:1888,y:104,t:1527873382778};\\\", \\\"{x:1886,y:105,t:1527873382795};\\\", \\\"{x:1884,y:105,t:1527873382811};\\\", \\\"{x:1882,y:106,t:1527873382827};\\\", \\\"{x:1880,y:106,t:1527873382845};\\\", \\\"{x:1874,y:108,t:1527873382862};\\\", \\\"{x:1873,y:108,t:1527873382885};\\\", \\\"{x:1872,y:109,t:1527873382894};\\\", \\\"{x:1872,y:111,t:1527873383126};\\\", \\\"{x:1867,y:121,t:1527873383134};\\\", \\\"{x:1857,y:133,t:1527873383144};\\\", \\\"{x:1840,y:152,t:1527873383162};\\\", \\\"{x:1822,y:170,t:1527873383179};\\\", \\\"{x:1794,y:192,t:1527873383195};\\\", \\\"{x:1773,y:207,t:1527873383212};\\\", \\\"{x:1754,y:220,t:1527873383229};\\\", \\\"{x:1741,y:231,t:1527873383245};\\\", \\\"{x:1723,y:244,t:1527873383262};\\\", \\\"{x:1708,y:259,t:1527873383279};\\\", \\\"{x:1693,y:280,t:1527873383294};\\\", \\\"{x:1680,y:294,t:1527873383312};\\\", \\\"{x:1667,y:309,t:1527873383329};\\\", \\\"{x:1657,y:320,t:1527873383345};\\\", \\\"{x:1642,y:339,t:1527873383362};\\\", \\\"{x:1626,y:357,t:1527873383378};\\\", \\\"{x:1610,y:373,t:1527873383395};\\\", \\\"{x:1602,y:379,t:1527873383412};\\\", \\\"{x:1592,y:388,t:1527873383429};\\\", \\\"{x:1581,y:401,t:1527873383445};\\\", \\\"{x:1567,y:421,t:1527873383462};\\\", \\\"{x:1561,y:428,t:1527873383479};\\\", \\\"{x:1558,y:433,t:1527873383495};\\\", \\\"{x:1556,y:440,t:1527873383512};\\\", \\\"{x:1553,y:452,t:1527873383529};\\\", \\\"{x:1549,y:465,t:1527873383546};\\\", \\\"{x:1547,y:474,t:1527873383562};\\\", \\\"{x:1544,y:485,t:1527873383579};\\\", \\\"{x:1542,y:498,t:1527873383596};\\\", \\\"{x:1541,y:512,t:1527873383612};\\\", \\\"{x:1538,y:525,t:1527873383629};\\\", \\\"{x:1536,y:543,t:1527873383646};\\\", \\\"{x:1534,y:556,t:1527873383662};\\\", \\\"{x:1534,y:562,t:1527873383678};\\\", \\\"{x:1534,y:580,t:1527873383696};\\\", \\\"{x:1534,y:595,t:1527873383712};\\\", \\\"{x:1534,y:607,t:1527873383729};\\\", \\\"{x:1534,y:622,t:1527873383746};\\\", \\\"{x:1534,y:640,t:1527873383761};\\\", \\\"{x:1533,y:658,t:1527873383778};\\\", \\\"{x:1525,y:685,t:1527873383795};\\\", \\\"{x:1512,y:720,t:1527873383811};\\\", \\\"{x:1493,y:748,t:1527873383828};\\\", \\\"{x:1470,y:779,t:1527873383845};\\\", \\\"{x:1451,y:802,t:1527873383861};\\\", \\\"{x:1430,y:828,t:1527873383878};\\\", \\\"{x:1413,y:850,t:1527873383895};\\\", \\\"{x:1400,y:868,t:1527873383911};\\\", \\\"{x:1393,y:881,t:1527873383928};\\\", \\\"{x:1388,y:891,t:1527873383946};\\\", \\\"{x:1386,y:896,t:1527873383965};\\\", \\\"{x:1385,y:898,t:1527873383978};\\\", \\\"{x:1385,y:901,t:1527873383997};\\\", \\\"{x:1385,y:908,t:1527873384012};\\\", \\\"{x:1385,y:917,t:1527873384029};\\\", \\\"{x:1393,y:934,t:1527873384045};\\\", \\\"{x:1401,y:947,t:1527873384063};\\\", \\\"{x:1412,y:959,t:1527873384079};\\\", \\\"{x:1424,y:971,t:1527873384095};\\\", \\\"{x:1438,y:981,t:1527873384114};\\\", \\\"{x:1451,y:992,t:1527873384129};\\\", \\\"{x:1467,y:1003,t:1527873384146};\\\", \\\"{x:1485,y:1015,t:1527873384162};\\\", \\\"{x:1510,y:1028,t:1527873384179};\\\", \\\"{x:1531,y:1037,t:1527873384196};\\\", \\\"{x:1554,y:1047,t:1527873384213};\\\", \\\"{x:1568,y:1054,t:1527873384229};\\\", \\\"{x:1593,y:1062,t:1527873384245};\\\", \\\"{x:1607,y:1063,t:1527873384262};\\\", \\\"{x:1617,y:1063,t:1527873384278};\\\", \\\"{x:1623,y:1063,t:1527873384295};\\\", \\\"{x:1627,y:1063,t:1527873384312};\\\", \\\"{x:1628,y:1063,t:1527873384328};\\\", \\\"{x:1630,y:1063,t:1527873384349};\\\", \\\"{x:1632,y:1063,t:1527873384365};\\\", \\\"{x:1632,y:1062,t:1527873384379};\\\", \\\"{x:1637,y:1058,t:1527873384396};\\\", \\\"{x:1646,y:1052,t:1527873384413};\\\", \\\"{x:1661,y:1039,t:1527873384430};\\\", \\\"{x:1669,y:1031,t:1527873384446};\\\", \\\"{x:1673,y:1027,t:1527873384463};\\\", \\\"{x:1676,y:1024,t:1527873384480};\\\", \\\"{x:1678,y:1022,t:1527873384496};\\\", \\\"{x:1679,y:1021,t:1527873384513};\\\", \\\"{x:1683,y:1018,t:1527873384529};\\\", \\\"{x:1687,y:1016,t:1527873384546};\\\", \\\"{x:1688,y:1016,t:1527873384563};\\\", \\\"{x:1689,y:1015,t:1527873384580};\\\", \\\"{x:1694,y:1013,t:1527873384596};\\\", \\\"{x:1700,y:1011,t:1527873384613};\\\", \\\"{x:1710,y:1010,t:1527873384630};\\\", \\\"{x:1723,y:1010,t:1527873384646};\\\", \\\"{x:1734,y:1010,t:1527873384663};\\\", \\\"{x:1748,y:1010,t:1527873384680};\\\", \\\"{x:1763,y:1013,t:1527873384696};\\\", \\\"{x:1776,y:1015,t:1527873384713};\\\", \\\"{x:1787,y:1016,t:1527873384730};\\\", \\\"{x:1795,y:1017,t:1527873384746};\\\", \\\"{x:1802,y:1018,t:1527873384762};\\\", \\\"{x:1805,y:1018,t:1527873384780};\\\", \\\"{x:1806,y:1018,t:1527873384796};\\\", \\\"{x:1807,y:1018,t:1527873384846};\\\", \\\"{x:1809,y:1018,t:1527873384862};\\\", \\\"{x:1813,y:1016,t:1527873384880};\\\", \\\"{x:1817,y:1015,t:1527873384897};\\\", \\\"{x:1820,y:1014,t:1527873384912};\\\", \\\"{x:1822,y:1013,t:1527873384929};\\\", \\\"{x:1824,y:1012,t:1527873384947};\\\", \\\"{x:1826,y:1010,t:1527873384963};\\\", \\\"{x:1827,y:1009,t:1527873384980};\\\", \\\"{x:1827,y:1008,t:1527873384997};\\\", \\\"{x:1827,y:1005,t:1527873385013};\\\", \\\"{x:1827,y:992,t:1527873385030};\\\", \\\"{x:1822,y:972,t:1527873385048};\\\", \\\"{x:1798,y:931,t:1527873385063};\\\", \\\"{x:1763,y:890,t:1527873385080};\\\", \\\"{x:1736,y:866,t:1527873385097};\\\", \\\"{x:1706,y:844,t:1527873385113};\\\", \\\"{x:1670,y:821,t:1527873385130};\\\", \\\"{x:1619,y:794,t:1527873385147};\\\", \\\"{x:1564,y:771,t:1527873385163};\\\", \\\"{x:1494,y:747,t:1527873385180};\\\", \\\"{x:1419,y:725,t:1527873385197};\\\", \\\"{x:1355,y:708,t:1527873385213};\\\", \\\"{x:1275,y:686,t:1527873385230};\\\", \\\"{x:1220,y:673,t:1527873385247};\\\", \\\"{x:1167,y:665,t:1527873385263};\\\", \\\"{x:1116,y:657,t:1527873385280};\\\", \\\"{x:1057,y:649,t:1527873385297};\\\", \\\"{x:1001,y:641,t:1527873385313};\\\", \\\"{x:972,y:640,t:1527873385330};\\\", \\\"{x:947,y:640,t:1527873385347};\\\", \\\"{x:931,y:640,t:1527873385363};\\\", \\\"{x:919,y:641,t:1527873385380};\\\", \\\"{x:906,y:645,t:1527873385397};\\\", \\\"{x:897,y:653,t:1527873385413};\\\", \\\"{x:892,y:663,t:1527873385430};\\\", \\\"{x:888,y:680,t:1527873385446};\\\", \\\"{x:887,y:702,t:1527873385465};\\\", \\\"{x:887,y:727,t:1527873385480};\\\", \\\"{x:887,y:752,t:1527873385496};\\\", \\\"{x:887,y:776,t:1527873385514};\\\", \\\"{x:889,y:795,t:1527873385529};\\\", \\\"{x:893,y:811,t:1527873385547};\\\", \\\"{x:894,y:822,t:1527873385564};\\\", \\\"{x:899,y:840,t:1527873385580};\\\", \\\"{x:906,y:863,t:1527873385597};\\\", \\\"{x:924,y:888,t:1527873385613};\\\", \\\"{x:934,y:902,t:1527873385630};\\\", \\\"{x:941,y:914,t:1527873385646};\\\", \\\"{x:947,y:924,t:1527873385664};\\\", \\\"{x:953,y:931,t:1527873385680};\\\", \\\"{x:959,y:937,t:1527873385696};\\\", \\\"{x:969,y:942,t:1527873385714};\\\", \\\"{x:981,y:945,t:1527873385730};\\\", \\\"{x:999,y:948,t:1527873385747};\\\", \\\"{x:1023,y:950,t:1527873385764};\\\", \\\"{x:1052,y:950,t:1527873385780};\\\", \\\"{x:1083,y:951,t:1527873385797};\\\", \\\"{x:1150,y:951,t:1527873385814};\\\", \\\"{x:1187,y:951,t:1527873385831};\\\", \\\"{x:1209,y:951,t:1527873385847};\\\", \\\"{x:1223,y:946,t:1527873385864};\\\", \\\"{x:1228,y:943,t:1527873385881};\\\", \\\"{x:1233,y:940,t:1527873385897};\\\", \\\"{x:1240,y:937,t:1527873385914};\\\", \\\"{x:1246,y:935,t:1527873385931};\\\", \\\"{x:1253,y:933,t:1527873385947};\\\", \\\"{x:1258,y:933,t:1527873385964};\\\", \\\"{x:1260,y:933,t:1527873385981};\\\", \\\"{x:1264,y:933,t:1527873385997};\\\", \\\"{x:1284,y:933,t:1527873386014};\\\", \\\"{x:1304,y:933,t:1527873386031};\\\", \\\"{x:1328,y:938,t:1527873386047};\\\", \\\"{x:1349,y:945,t:1527873386064};\\\", \\\"{x:1367,y:951,t:1527873386081};\\\", \\\"{x:1375,y:956,t:1527873386097};\\\", \\\"{x:1379,y:958,t:1527873386114};\\\", \\\"{x:1381,y:960,t:1527873386130};\\\", \\\"{x:1381,y:961,t:1527873386147};\\\", \\\"{x:1382,y:961,t:1527873386163};\\\", \\\"{x:1383,y:963,t:1527873386180};\\\", \\\"{x:1383,y:964,t:1527873386310};\\\", \\\"{x:1382,y:966,t:1527873386317};\\\", \\\"{x:1381,y:968,t:1527873386331};\\\", \\\"{x:1378,y:970,t:1527873386347};\\\", \\\"{x:1371,y:975,t:1527873386363};\\\", \\\"{x:1361,y:977,t:1527873386381};\\\", \\\"{x:1356,y:977,t:1527873386397};\\\", \\\"{x:1354,y:978,t:1527873386413};\\\", \\\"{x:1353,y:978,t:1527873386430};\\\", \\\"{x:1352,y:978,t:1527873386566};\\\", \\\"{x:1350,y:977,t:1527873386581};\\\", \\\"{x:1347,y:971,t:1527873386597};\\\", \\\"{x:1347,y:970,t:1527873386621};\\\", \\\"{x:1347,y:969,t:1527873386631};\\\", \\\"{x:1346,y:966,t:1527873386649};\\\", \\\"{x:1346,y:965,t:1527873386664};\\\", \\\"{x:1346,y:963,t:1527873386681};\\\", \\\"{x:1346,y:960,t:1527873386698};\\\", \\\"{x:1346,y:957,t:1527873386714};\\\", \\\"{x:1346,y:953,t:1527873386731};\\\", \\\"{x:1346,y:946,t:1527873386748};\\\", \\\"{x:1346,y:941,t:1527873386765};\\\", \\\"{x:1346,y:934,t:1527873386781};\\\", \\\"{x:1344,y:921,t:1527873386798};\\\", \\\"{x:1344,y:913,t:1527873386815};\\\", \\\"{x:1345,y:896,t:1527873386831};\\\", \\\"{x:1346,y:887,t:1527873386848};\\\", \\\"{x:1346,y:882,t:1527873386865};\\\", \\\"{x:1346,y:874,t:1527873386881};\\\", \\\"{x:1346,y:864,t:1527873386898};\\\", \\\"{x:1346,y:854,t:1527873386914};\\\", \\\"{x:1346,y:844,t:1527873386931};\\\", \\\"{x:1346,y:837,t:1527873386948};\\\", \\\"{x:1346,y:833,t:1527873386965};\\\", \\\"{x:1346,y:829,t:1527873386981};\\\", \\\"{x:1346,y:823,t:1527873386998};\\\", \\\"{x:1346,y:821,t:1527873387015};\\\", \\\"{x:1346,y:817,t:1527873387031};\\\", \\\"{x:1346,y:813,t:1527873387048};\\\", \\\"{x:1346,y:809,t:1527873387065};\\\", \\\"{x:1346,y:807,t:1527873387080};\\\", \\\"{x:1346,y:806,t:1527873387097};\\\", \\\"{x:1346,y:803,t:1527873387114};\\\", \\\"{x:1346,y:802,t:1527873387130};\\\", \\\"{x:1346,y:800,t:1527873387147};\\\", \\\"{x:1346,y:797,t:1527873387164};\\\", \\\"{x:1346,y:796,t:1527873387188};\\\", \\\"{x:1346,y:794,t:1527873387204};\\\", \\\"{x:1346,y:793,t:1527873387221};\\\", \\\"{x:1346,y:791,t:1527873387245};\\\", \\\"{x:1346,y:790,t:1527873387278};\\\", \\\"{x:1345,y:789,t:1527873387334};\\\", \\\"{x:1345,y:788,t:1527873387366};\\\", \\\"{x:1345,y:787,t:1527873387382};\\\", \\\"{x:1345,y:785,t:1527873387414};\\\", \\\"{x:1344,y:784,t:1527873387446};\\\", \\\"{x:1344,y:782,t:1527873387470};\\\", \\\"{x:1344,y:781,t:1527873387501};\\\", \\\"{x:1344,y:779,t:1527873387517};\\\", \\\"{x:1344,y:778,t:1527873387532};\\\", \\\"{x:1344,y:777,t:1527873387548};\\\", \\\"{x:1344,y:776,t:1527873387565};\\\", \\\"{x:1343,y:775,t:1527873387582};\\\", \\\"{x:1342,y:774,t:1527873389486};\\\", \\\"{x:1342,y:767,t:1527873389500};\\\", \\\"{x:1342,y:757,t:1527873389515};\\\", \\\"{x:1342,y:750,t:1527873389533};\\\", \\\"{x:1342,y:747,t:1527873389549};\\\", \\\"{x:1342,y:746,t:1527873389565};\\\", \\\"{x:1342,y:744,t:1527873389583};\\\", \\\"{x:1342,y:743,t:1527873389600};\\\", \\\"{x:1342,y:741,t:1527873389617};\\\", \\\"{x:1342,y:751,t:1527873389829};\\\", \\\"{x:1343,y:762,t:1527873389837};\\\", \\\"{x:1344,y:770,t:1527873389851};\\\", \\\"{x:1346,y:784,t:1527873389867};\\\", \\\"{x:1348,y:797,t:1527873389882};\\\", \\\"{x:1349,y:813,t:1527873389900};\\\", \\\"{x:1349,y:825,t:1527873389916};\\\", \\\"{x:1349,y:844,t:1527873389934};\\\", \\\"{x:1349,y:865,t:1527873389949};\\\", \\\"{x:1349,y:892,t:1527873389967};\\\", \\\"{x:1349,y:914,t:1527873389982};\\\", \\\"{x:1349,y:927,t:1527873389999};\\\", \\\"{x:1349,y:938,t:1527873390017};\\\", \\\"{x:1349,y:948,t:1527873390034};\\\", \\\"{x:1351,y:955,t:1527873390049};\\\", \\\"{x:1352,y:959,t:1527873390066};\\\", \\\"{x:1352,y:962,t:1527873390084};\\\", \\\"{x:1353,y:963,t:1527873390100};\\\", \\\"{x:1354,y:965,t:1527873390116};\\\", \\\"{x:1355,y:966,t:1527873390133};\\\", \\\"{x:1356,y:969,t:1527873390150};\\\", \\\"{x:1357,y:972,t:1527873390166};\\\", \\\"{x:1358,y:973,t:1527873390183};\\\", \\\"{x:1358,y:974,t:1527873390204};\\\", \\\"{x:1357,y:973,t:1527873390334};\\\", \\\"{x:1353,y:955,t:1527873390351};\\\", \\\"{x:1351,y:928,t:1527873390367};\\\", \\\"{x:1351,y:894,t:1527873390384};\\\", \\\"{x:1351,y:870,t:1527873390400};\\\", \\\"{x:1351,y:849,t:1527873390417};\\\", \\\"{x:1351,y:836,t:1527873390433};\\\", \\\"{x:1351,y:827,t:1527873390450};\\\", \\\"{x:1356,y:810,t:1527873390466};\\\", \\\"{x:1365,y:793,t:1527873390484};\\\", \\\"{x:1370,y:778,t:1527873390500};\\\", \\\"{x:1376,y:764,t:1527873390517};\\\", \\\"{x:1378,y:758,t:1527873390533};\\\", \\\"{x:1379,y:753,t:1527873390551};\\\", \\\"{x:1379,y:751,t:1527873390567};\\\", \\\"{x:1379,y:750,t:1527873390584};\\\", \\\"{x:1379,y:747,t:1527873390601};\\\", \\\"{x:1379,y:743,t:1527873390617};\\\", \\\"{x:1378,y:740,t:1527873390634};\\\", \\\"{x:1376,y:737,t:1527873390651};\\\", \\\"{x:1376,y:736,t:1527873390667};\\\", \\\"{x:1375,y:734,t:1527873390684};\\\", \\\"{x:1374,y:731,t:1527873390701};\\\", \\\"{x:1372,y:728,t:1527873390717};\\\", \\\"{x:1371,y:726,t:1527873390733};\\\", \\\"{x:1369,y:724,t:1527873390751};\\\", \\\"{x:1364,y:719,t:1527873390768};\\\", \\\"{x:1355,y:713,t:1527873390785};\\\", \\\"{x:1342,y:703,t:1527873390802};\\\", \\\"{x:1323,y:693,t:1527873390816};\\\", \\\"{x:1294,y:681,t:1527873390834};\\\", \\\"{x:1267,y:669,t:1527873390851};\\\", \\\"{x:1233,y:659,t:1527873390868};\\\", \\\"{x:1193,y:648,t:1527873390884};\\\", \\\"{x:1129,y:630,t:1527873390901};\\\", \\\"{x:1106,y:622,t:1527873390918};\\\", \\\"{x:1086,y:617,t:1527873390934};\\\", \\\"{x:1074,y:614,t:1527873390951};\\\", \\\"{x:1065,y:611,t:1527873390967};\\\", \\\"{x:1054,y:609,t:1527873390984};\\\", \\\"{x:1040,y:604,t:1527873391001};\\\", \\\"{x:1014,y:598,t:1527873391019};\\\", \\\"{x:972,y:589,t:1527873391034};\\\", \\\"{x:920,y:576,t:1527873391053};\\\", \\\"{x:859,y:559,t:1527873391068};\\\", \\\"{x:789,y:537,t:1527873391084};\\\", \\\"{x:632,y:498,t:1527873391118};\\\", \\\"{x:584,y:484,t:1527873391134};\\\", \\\"{x:557,y:477,t:1527873391151};\\\", \\\"{x:541,y:473,t:1527873391167};\\\", \\\"{x:535,y:471,t:1527873391184};\\\", \\\"{x:533,y:471,t:1527873391201};\\\", \\\"{x:533,y:470,t:1527873391217};\\\", \\\"{x:533,y:472,t:1527873391349};\\\", \\\"{x:533,y:474,t:1527873391357};\\\", \\\"{x:533,y:477,t:1527873391368};\\\", \\\"{x:538,y:488,t:1527873391385};\\\", \\\"{x:543,y:497,t:1527873391402};\\\", \\\"{x:551,y:510,t:1527873391418};\\\", \\\"{x:560,y:516,t:1527873391434};\\\", \\\"{x:577,y:521,t:1527873391452};\\\", \\\"{x:605,y:527,t:1527873391469};\\\", \\\"{x:616,y:529,t:1527873391484};\\\", \\\"{x:623,y:529,t:1527873391501};\\\", \\\"{x:626,y:529,t:1527873391518};\\\", \\\"{x:626,y:528,t:1527873391589};\\\", \\\"{x:626,y:527,t:1527873391602};\\\", \\\"{x:626,y:526,t:1527873391618};\\\", \\\"{x:626,y:524,t:1527873391635};\\\", \\\"{x:632,y:519,t:1527873391651};\\\", \\\"{x:663,y:514,t:1527873391669};\\\", \\\"{x:688,y:514,t:1527873391684};\\\", \\\"{x:719,y:514,t:1527873391702};\\\", \\\"{x:750,y:516,t:1527873391719};\\\", \\\"{x:783,y:520,t:1527873391734};\\\", \\\"{x:811,y:523,t:1527873391752};\\\", \\\"{x:835,y:525,t:1527873391769};\\\", \\\"{x:844,y:526,t:1527873391785};\\\", \\\"{x:845,y:526,t:1527873391801};\\\", \\\"{x:846,y:526,t:1527873391958};\\\", \\\"{x:846,y:524,t:1527873391970};\\\", \\\"{x:846,y:521,t:1527873391986};\\\", \\\"{x:845,y:519,t:1527873392002};\\\", \\\"{x:845,y:515,t:1527873392020};\\\", \\\"{x:843,y:513,t:1527873392036};\\\", \\\"{x:842,y:511,t:1527873392051};\\\", \\\"{x:841,y:511,t:1527873392068};\\\", \\\"{x:840,y:509,t:1527873392085};\\\", \\\"{x:839,y:508,t:1527873392116};\\\", \\\"{x:832,y:507,t:1527873392597};\\\", \\\"{x:802,y:507,t:1527873392605};\\\", \\\"{x:749,y:508,t:1527873392618};\\\", \\\"{x:613,y:508,t:1527873392636};\\\", \\\"{x:403,y:508,t:1527873392653};\\\", \\\"{x:262,y:508,t:1527873392669};\\\", \\\"{x:121,y:508,t:1527873392685};\\\", \\\"{x:12,y:508,t:1527873392703};\\\", \\\"{x:0,y:510,t:1527873392719};\\\", \\\"{x:0,y:516,t:1527873392735};\\\", \\\"{x:0,y:517,t:1527873392752};\\\", \\\"{x:0,y:518,t:1527873392773};\\\", \\\"{x:0,y:519,t:1527873392813};\\\", \\\"{x:1,y:521,t:1527873392820};\\\", \\\"{x:5,y:524,t:1527873392836};\\\", \\\"{x:26,y:534,t:1527873392853};\\\", \\\"{x:46,y:539,t:1527873392870};\\\", \\\"{x:72,y:542,t:1527873392887};\\\", \\\"{x:104,y:545,t:1527873392903};\\\", \\\"{x:138,y:545,t:1527873392920};\\\", \\\"{x:166,y:545,t:1527873392936};\\\", \\\"{x:185,y:545,t:1527873392953};\\\", \\\"{x:191,y:545,t:1527873392969};\\\", \\\"{x:192,y:545,t:1527873392986};\\\", \\\"{x:193,y:545,t:1527873393036};\\\", \\\"{x:192,y:544,t:1527873393116};\\\", \\\"{x:191,y:544,t:1527873393125};\\\", \\\"{x:189,y:543,t:1527873393148};\\\", \\\"{x:187,y:542,t:1527873393165};\\\", \\\"{x:186,y:542,t:1527873393173};\\\", \\\"{x:184,y:542,t:1527873393186};\\\", \\\"{x:181,y:541,t:1527873393203};\\\", \\\"{x:180,y:541,t:1527873393220};\\\", \\\"{x:178,y:540,t:1527873393237};\\\", \\\"{x:176,y:540,t:1527873393253};\\\", \\\"{x:173,y:539,t:1527873393270};\\\", \\\"{x:173,y:538,t:1527873393677};\\\", \\\"{x:182,y:540,t:1527873393692};\\\", \\\"{x:199,y:548,t:1527873393703};\\\", \\\"{x:241,y:561,t:1527873393721};\\\", \\\"{x:274,y:570,t:1527873393738};\\\", \\\"{x:302,y:578,t:1527873393753};\\\", \\\"{x:326,y:585,t:1527873393769};\\\", \\\"{x:337,y:590,t:1527873393786};\\\", \\\"{x:340,y:591,t:1527873393804};\\\", \\\"{x:341,y:592,t:1527873393901};\\\", \\\"{x:341,y:598,t:1527873393910};\\\", \\\"{x:341,y:602,t:1527873393921};\\\", \\\"{x:347,y:613,t:1527873393936};\\\", \\\"{x:351,y:623,t:1527873393954};\\\", \\\"{x:357,y:636,t:1527873393970};\\\", \\\"{x:362,y:647,t:1527873393987};\\\", \\\"{x:366,y:654,t:1527873394004};\\\", \\\"{x:375,y:666,t:1527873394020};\\\", \\\"{x:389,y:681,t:1527873394037};\\\", \\\"{x:395,y:687,t:1527873394054};\\\", \\\"{x:398,y:690,t:1527873394071};\\\", \\\"{x:399,y:690,t:1527873394086};\\\", \\\"{x:400,y:690,t:1527873394125};\\\", \\\"{x:402,y:692,t:1527873394137};\\\", \\\"{x:403,y:693,t:1527873394154};\\\", \\\"{x:405,y:695,t:1527873394171};\\\", \\\"{x:407,y:697,t:1527873394187};\\\", \\\"{x:409,y:699,t:1527873394204};\\\", \\\"{x:421,y:707,t:1527873394221};\\\", \\\"{x:430,y:714,t:1527873394238};\\\", \\\"{x:434,y:718,t:1527873394254};\\\", \\\"{x:439,y:724,t:1527873394271};\\\", \\\"{x:441,y:726,t:1527873394287};\\\", \\\"{x:442,y:726,t:1527873394304};\\\", \\\"{x:443,y:727,t:1527873394373};\\\", \\\"{x:443,y:728,t:1527873394397};\\\", \\\"{x:444,y:728,t:1527873394406};\\\", \\\"{x:447,y:729,t:1527873394424};\\\", \\\"{x:450,y:731,t:1527873394437};\\\", \\\"{x:453,y:732,t:1527873394453};\\\", \\\"{x:457,y:736,t:1527873394471};\\\", \\\"{x:463,y:741,t:1527873394487};\\\", \\\"{x:464,y:742,t:1527873394503};\\\", \\\"{x:465,y:742,t:1527873394521};\\\", \\\"{x:466,y:742,t:1527873394629};\\\", \\\"{x:467,y:743,t:1527873394637};\\\", \\\"{x:469,y:743,t:1527873395797};\\\", \\\"{x:476,y:737,t:1527873395805};\\\", \\\"{x:540,y:662,t:1527873395835};\\\", \\\"{x:563,y:643,t:1527873395839};\\\", \\\"{x:623,y:596,t:1527873395855};\\\", \\\"{x:696,y:545,t:1527873395871};\\\", \\\"{x:767,y:499,t:1527873395888};\\\", \\\"{x:819,y:469,t:1527873395904};\\\" ] }, { \\\"rt\\\": 36229, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 617027, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -2-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:870,y:442,t:1527873396021};\\\", \\\"{x:874,y:441,t:1527873397686};\\\", \\\"{x:923,y:440,t:1527873397719};\\\", \\\"{x:935,y:440,t:1527873397724};\\\", \\\"{x:946,y:440,t:1527873397740};\\\", \\\"{x:954,y:440,t:1527873397755};\\\", \\\"{x:958,y:440,t:1527873397773};\\\", \\\"{x:961,y:442,t:1527873397790};\\\", \\\"{x:968,y:444,t:1527873397806};\\\", \\\"{x:978,y:446,t:1527873397822};\\\", \\\"{x:993,y:446,t:1527873397839};\\\", \\\"{x:1016,y:446,t:1527873397857};\\\", \\\"{x:1043,y:446,t:1527873397872};\\\", \\\"{x:1084,y:452,t:1527873397890};\\\", \\\"{x:1132,y:459,t:1527873397907};\\\", \\\"{x:1161,y:468,t:1527873397922};\\\", \\\"{x:1187,y:476,t:1527873397940};\\\", \\\"{x:1219,y:482,t:1527873397957};\\\", \\\"{x:1247,y:487,t:1527873397973};\\\", \\\"{x:1286,y:495,t:1527873397990};\\\", \\\"{x:1328,y:501,t:1527873398007};\\\", \\\"{x:1385,y:510,t:1527873398024};\\\", \\\"{x:1424,y:527,t:1527873398040};\\\", \\\"{x:1440,y:542,t:1527873398057};\\\", \\\"{x:1449,y:551,t:1527873398073};\\\", \\\"{x:1457,y:562,t:1527873398090};\\\", \\\"{x:1459,y:570,t:1527873398107};\\\", \\\"{x:1464,y:581,t:1527873398123};\\\", \\\"{x:1469,y:597,t:1527873398140};\\\", \\\"{x:1469,y:616,t:1527873398157};\\\", \\\"{x:1468,y:631,t:1527873398173};\\\", \\\"{x:1462,y:643,t:1527873398190};\\\", \\\"{x:1455,y:654,t:1527873398207};\\\", \\\"{x:1447,y:663,t:1527873398223};\\\", \\\"{x:1443,y:670,t:1527873398241};\\\", \\\"{x:1439,y:672,t:1527873398257};\\\", \\\"{x:1436,y:674,t:1527873398274};\\\", \\\"{x:1431,y:677,t:1527873398291};\\\", \\\"{x:1422,y:682,t:1527873398307};\\\", \\\"{x:1415,y:686,t:1527873398325};\\\", \\\"{x:1410,y:689,t:1527873398341};\\\", \\\"{x:1402,y:694,t:1527873398357};\\\", \\\"{x:1395,y:698,t:1527873398373};\\\", \\\"{x:1393,y:699,t:1527873398391};\\\", \\\"{x:1393,y:700,t:1527873398413};\\\", \\\"{x:1391,y:701,t:1527873398445};\\\", \\\"{x:1390,y:702,t:1527873398462};\\\", \\\"{x:1388,y:703,t:1527873398474};\\\", \\\"{x:1387,y:704,t:1527873398517};\\\", \\\"{x:1386,y:704,t:1527873398525};\\\", \\\"{x:1384,y:704,t:1527873398540};\\\", \\\"{x:1376,y:704,t:1527873398557};\\\", \\\"{x:1374,y:704,t:1527873398575};\\\", \\\"{x:1372,y:704,t:1527873398877};\\\", \\\"{x:1370,y:704,t:1527873398891};\\\", \\\"{x:1364,y:704,t:1527873398908};\\\", \\\"{x:1362,y:705,t:1527873398924};\\\", \\\"{x:1360,y:706,t:1527873398942};\\\", \\\"{x:1358,y:707,t:1527873398957};\\\", \\\"{x:1357,y:709,t:1527873398974};\\\", \\\"{x:1354,y:711,t:1527873398991};\\\", \\\"{x:1354,y:712,t:1527873399038};\\\", \\\"{x:1353,y:712,t:1527873399221};\\\", \\\"{x:1351,y:710,t:1527873399229};\\\", \\\"{x:1350,y:705,t:1527873399242};\\\", \\\"{x:1345,y:696,t:1527873399261};\\\", \\\"{x:1342,y:689,t:1527873399274};\\\", \\\"{x:1339,y:684,t:1527873399290};\\\", \\\"{x:1336,y:680,t:1527873399308};\\\", \\\"{x:1334,y:676,t:1527873399324};\\\", \\\"{x:1331,y:672,t:1527873399340};\\\", \\\"{x:1331,y:675,t:1527873399558};\\\", \\\"{x:1341,y:686,t:1527873399574};\\\", \\\"{x:1346,y:693,t:1527873399592};\\\", \\\"{x:1348,y:697,t:1527873399608};\\\", \\\"{x:1351,y:701,t:1527873399624};\\\", \\\"{x:1353,y:704,t:1527873399641};\\\", \\\"{x:1354,y:705,t:1527873399658};\\\", \\\"{x:1354,y:706,t:1527873399677};\\\", \\\"{x:1354,y:707,t:1527873399693};\\\", \\\"{x:1354,y:708,t:1527873399725};\\\", \\\"{x:1354,y:709,t:1527873399741};\\\", \\\"{x:1354,y:710,t:1527873399758};\\\", \\\"{x:1356,y:708,t:1527873404398};\\\", \\\"{x:1357,y:707,t:1527873404411};\\\", \\\"{x:1357,y:706,t:1527873406918};\\\", \\\"{x:1355,y:706,t:1527873407397};\\\", \\\"{x:1354,y:705,t:1527873407412};\\\", \\\"{x:1353,y:705,t:1527873407436};\\\", \\\"{x:1352,y:704,t:1527873407484};\\\", \\\"{x:1345,y:701,t:1527873408758};\\\", \\\"{x:1332,y:692,t:1527873408766};\\\", \\\"{x:1300,y:658,t:1527873408782};\\\", \\\"{x:1260,y:622,t:1527873408799};\\\", \\\"{x:1231,y:600,t:1527873408815};\\\", \\\"{x:1204,y:578,t:1527873408831};\\\", \\\"{x:1178,y:555,t:1527873408849};\\\", \\\"{x:1134,y:522,t:1527873408864};\\\", \\\"{x:1081,y:482,t:1527873408882};\\\", \\\"{x:1020,y:445,t:1527873408899};\\\", \\\"{x:948,y:409,t:1527873408915};\\\", \\\"{x:882,y:383,t:1527873408932};\\\", \\\"{x:782,y:345,t:1527873408949};\\\", \\\"{x:713,y:328,t:1527873408965};\\\", \\\"{x:659,y:316,t:1527873408981};\\\", \\\"{x:624,y:313,t:1527873408998};\\\", \\\"{x:602,y:310,t:1527873409015};\\\", \\\"{x:591,y:310,t:1527873409031};\\\", \\\"{x:586,y:310,t:1527873409048};\\\", \\\"{x:577,y:314,t:1527873409065};\\\", \\\"{x:570,y:318,t:1527873409081};\\\", \\\"{x:564,y:322,t:1527873409098};\\\", \\\"{x:561,y:324,t:1527873409115};\\\", \\\"{x:555,y:330,t:1527873409132};\\\", \\\"{x:546,y:341,t:1527873409148};\\\", \\\"{x:541,y:351,t:1527873409165};\\\", \\\"{x:536,y:366,t:1527873409182};\\\", \\\"{x:531,y:387,t:1527873409199};\\\", \\\"{x:527,y:408,t:1527873409215};\\\", \\\"{x:525,y:429,t:1527873409232};\\\", \\\"{x:523,y:443,t:1527873409249};\\\", \\\"{x:521,y:454,t:1527873409265};\\\", \\\"{x:519,y:467,t:1527873409281};\\\", \\\"{x:517,y:477,t:1527873409299};\\\", \\\"{x:516,y:485,t:1527873409316};\\\", \\\"{x:511,y:496,t:1527873409333};\\\", \\\"{x:501,y:508,t:1527873409347};\\\", \\\"{x:489,y:513,t:1527873409365};\\\", \\\"{x:473,y:517,t:1527873409382};\\\", \\\"{x:455,y:517,t:1527873409399};\\\", \\\"{x:433,y:516,t:1527873409416};\\\", \\\"{x:412,y:510,t:1527873409432};\\\", \\\"{x:396,y:509,t:1527873409449};\\\", \\\"{x:380,y:508,t:1527873409465};\\\", \\\"{x:369,y:508,t:1527873409482};\\\", \\\"{x:365,y:508,t:1527873409499};\\\", \\\"{x:356,y:511,t:1527873409515};\\\", \\\"{x:347,y:516,t:1527873409532};\\\", \\\"{x:340,y:520,t:1527873409550};\\\", \\\"{x:335,y:524,t:1527873409566};\\\", \\\"{x:331,y:527,t:1527873409583};\\\", \\\"{x:326,y:531,t:1527873409599};\\\", \\\"{x:319,y:533,t:1527873409616};\\\", \\\"{x:309,y:536,t:1527873409632};\\\", \\\"{x:300,y:538,t:1527873409649};\\\", \\\"{x:290,y:540,t:1527873409666};\\\", \\\"{x:284,y:540,t:1527873409683};\\\", \\\"{x:283,y:540,t:1527873409699};\\\", \\\"{x:282,y:541,t:1527873409716};\\\", \\\"{x:279,y:542,t:1527873409732};\\\", \\\"{x:274,y:544,t:1527873409749};\\\", \\\"{x:272,y:545,t:1527873409768};\\\", \\\"{x:268,y:547,t:1527873409783};\\\", \\\"{x:266,y:548,t:1527873409799};\\\", \\\"{x:262,y:549,t:1527873409816};\\\", \\\"{x:254,y:549,t:1527873409832};\\\", \\\"{x:239,y:549,t:1527873409848};\\\", \\\"{x:217,y:549,t:1527873409866};\\\", \\\"{x:203,y:549,t:1527873409883};\\\", \\\"{x:196,y:549,t:1527873409899};\\\", \\\"{x:190,y:547,t:1527873409916};\\\", \\\"{x:186,y:546,t:1527873409933};\\\", \\\"{x:184,y:546,t:1527873409949};\\\", \\\"{x:183,y:546,t:1527873409966};\\\", \\\"{x:190,y:549,t:1527873410725};\\\", \\\"{x:213,y:563,t:1527873410735};\\\", \\\"{x:278,y:609,t:1527873410751};\\\", \\\"{x:344,y:654,t:1527873410766};\\\", \\\"{x:411,y:700,t:1527873410783};\\\", \\\"{x:474,y:736,t:1527873410801};\\\", \\\"{x:513,y:760,t:1527873410817};\\\", \\\"{x:543,y:780,t:1527873410833};\\\", \\\"{x:560,y:795,t:1527873410850};\\\", \\\"{x:568,y:808,t:1527873410867};\\\", \\\"{x:570,y:813,t:1527873410883};\\\", \\\"{x:570,y:817,t:1527873410900};\\\", \\\"{x:569,y:823,t:1527873410917};\\\", \\\"{x:569,y:827,t:1527873410933};\\\", \\\"{x:569,y:828,t:1527873410950};\\\", \\\"{x:569,y:829,t:1527873410967};\\\", \\\"{x:567,y:829,t:1527873411117};\\\", \\\"{x:564,y:823,t:1527873411133};\\\", \\\"{x:560,y:814,t:1527873411150};\\\", \\\"{x:556,y:806,t:1527873411166};\\\", \\\"{x:552,y:799,t:1527873411184};\\\", \\\"{x:550,y:795,t:1527873411201};\\\", \\\"{x:549,y:792,t:1527873411216};\\\", \\\"{x:546,y:788,t:1527873411233};\\\", \\\"{x:546,y:786,t:1527873411251};\\\", \\\"{x:545,y:785,t:1527873411267};\\\", \\\"{x:544,y:784,t:1527873411284};\\\", \\\"{x:544,y:782,t:1527873411301};\\\", \\\"{x:543,y:779,t:1527873411317};\\\", \\\"{x:542,y:777,t:1527873411334};\\\", \\\"{x:542,y:772,t:1527873411350};\\\", \\\"{x:539,y:768,t:1527873411367};\\\", \\\"{x:538,y:761,t:1527873411383};\\\", \\\"{x:537,y:759,t:1527873411400};\\\", \\\"{x:537,y:758,t:1527873411417};\\\", \\\"{x:536,y:755,t:1527873411433};\\\", \\\"{x:536,y:754,t:1527873411449};\\\", \\\"{x:535,y:752,t:1527873411466};\\\", \\\"{x:535,y:751,t:1527873411484};\\\", \\\"{x:535,y:750,t:1527873411508};\\\", \\\"{x:538,y:746,t:1527873424797};\\\", \\\"{x:562,y:741,t:1527873424805};\\\", \\\"{x:643,y:742,t:1527873424821};\\\", \\\"{x:719,y:752,t:1527873424837};\\\", \\\"{x:794,y:763,t:1527873424854};\\\", \\\"{x:860,y:779,t:1527873424870};\\\", \\\"{x:923,y:794,t:1527873424887};\\\", \\\"{x:977,y:805,t:1527873424904};\\\", \\\"{x:1011,y:816,t:1527873424920};\\\", \\\"{x:1039,y:823,t:1527873424937};\\\", \\\"{x:1061,y:828,t:1527873424954};\\\", \\\"{x:1077,y:832,t:1527873424970};\\\", \\\"{x:1090,y:834,t:1527873424987};\\\", \\\"{x:1112,y:839,t:1527873425004};\\\", \\\"{x:1146,y:844,t:1527873425020};\\\", \\\"{x:1222,y:852,t:1527873425037};\\\", \\\"{x:1276,y:853,t:1527873425054};\\\", \\\"{x:1305,y:853,t:1527873425071};\\\", \\\"{x:1323,y:853,t:1527873425087};\\\", \\\"{x:1329,y:853,t:1527873425104};\\\", \\\"{x:1330,y:852,t:1527873425120};\\\", \\\"{x:1330,y:851,t:1527873425197};\\\", \\\"{x:1330,y:849,t:1527873425206};\\\", \\\"{x:1330,y:847,t:1527873425221};\\\", \\\"{x:1330,y:842,t:1527873425237};\\\", \\\"{x:1330,y:839,t:1527873425255};\\\", \\\"{x:1329,y:835,t:1527873425270};\\\", \\\"{x:1329,y:831,t:1527873425287};\\\", \\\"{x:1329,y:826,t:1527873425304};\\\", \\\"{x:1327,y:821,t:1527873425321};\\\", \\\"{x:1326,y:816,t:1527873425338};\\\", \\\"{x:1323,y:807,t:1527873425354};\\\", \\\"{x:1320,y:798,t:1527873425370};\\\", \\\"{x:1316,y:784,t:1527873425387};\\\", \\\"{x:1308,y:770,t:1527873425404};\\\", \\\"{x:1295,y:751,t:1527873425421};\\\", \\\"{x:1281,y:736,t:1527873425437};\\\", \\\"{x:1263,y:724,t:1527873425454};\\\", \\\"{x:1254,y:717,t:1527873425471};\\\", \\\"{x:1250,y:714,t:1527873425487};\\\", \\\"{x:1244,y:712,t:1527873425504};\\\", \\\"{x:1238,y:710,t:1527873425521};\\\", \\\"{x:1223,y:704,t:1527873425537};\\\", \\\"{x:1206,y:700,t:1527873425554};\\\", \\\"{x:1184,y:697,t:1527873425572};\\\", \\\"{x:1162,y:694,t:1527873425587};\\\", \\\"{x:1130,y:689,t:1527873425604};\\\", \\\"{x:1042,y:674,t:1527873425621};\\\", \\\"{x:983,y:666,t:1527873425637};\\\", \\\"{x:915,y:654,t:1527873425654};\\\", \\\"{x:838,y:635,t:1527873425671};\\\", \\\"{x:760,y:611,t:1527873425688};\\\", \\\"{x:697,y:594,t:1527873425704};\\\", \\\"{x:637,y:574,t:1527873425721};\\\", \\\"{x:590,y:553,t:1527873425739};\\\", \\\"{x:557,y:539,t:1527873425755};\\\", \\\"{x:526,y:519,t:1527873425772};\\\", \\\"{x:504,y:503,t:1527873425788};\\\", \\\"{x:471,y:474,t:1527873425806};\\\", \\\"{x:457,y:456,t:1527873425821};\\\", \\\"{x:449,y:444,t:1527873425838};\\\", \\\"{x:447,y:440,t:1527873425855};\\\", \\\"{x:447,y:439,t:1527873425871};\\\", \\\"{x:447,y:438,t:1527873425909};\\\", \\\"{x:448,y:436,t:1527873425921};\\\", \\\"{x:468,y:429,t:1527873425938};\\\", \\\"{x:497,y:429,t:1527873425956};\\\", \\\"{x:558,y:446,t:1527873425972};\\\", \\\"{x:628,y:467,t:1527873425988};\\\", \\\"{x:758,y:522,t:1527873426006};\\\", \\\"{x:844,y:557,t:1527873426022};\\\", \\\"{x:929,y:594,t:1527873426038};\\\", \\\"{x:993,y:622,t:1527873426055};\\\", \\\"{x:1047,y:652,t:1527873426072};\\\", \\\"{x:1086,y:678,t:1527873426088};\\\", \\\"{x:1111,y:698,t:1527873426106};\\\", \\\"{x:1126,y:716,t:1527873426123};\\\", \\\"{x:1134,y:729,t:1527873426138};\\\", \\\"{x:1140,y:740,t:1527873426155};\\\", \\\"{x:1143,y:750,t:1527873426172};\\\", \\\"{x:1145,y:756,t:1527873426188};\\\", \\\"{x:1147,y:761,t:1527873426205};\\\", \\\"{x:1147,y:762,t:1527873426229};\\\", \\\"{x:1147,y:763,t:1527873426254};\\\", \\\"{x:1147,y:764,t:1527873426270};\\\", \\\"{x:1147,y:765,t:1527873426294};\\\", \\\"{x:1146,y:766,t:1527873426309};\\\", \\\"{x:1146,y:767,t:1527873426333};\\\", \\\"{x:1144,y:768,t:1527873426350};\\\", \\\"{x:1142,y:768,t:1527873426373};\\\", \\\"{x:1140,y:769,t:1527873426390};\\\", \\\"{x:1134,y:769,t:1527873426406};\\\", \\\"{x:1126,y:770,t:1527873426423};\\\", \\\"{x:1113,y:770,t:1527873426439};\\\", \\\"{x:1089,y:770,t:1527873426455};\\\", \\\"{x:1039,y:768,t:1527873426472};\\\", \\\"{x:946,y:746,t:1527873426489};\\\", \\\"{x:824,y:710,t:1527873426505};\\\", \\\"{x:707,y:671,t:1527873426522};\\\", \\\"{x:600,y:625,t:1527873426540};\\\", \\\"{x:512,y:590,t:1527873426555};\\\", \\\"{x:435,y:558,t:1527873426572};\\\", \\\"{x:372,y:528,t:1527873426590};\\\", \\\"{x:358,y:520,t:1527873426605};\\\", \\\"{x:353,y:516,t:1527873426623};\\\", \\\"{x:353,y:515,t:1527873426639};\\\", \\\"{x:353,y:514,t:1527873426669};\\\", \\\"{x:353,y:512,t:1527873426677};\\\", \\\"{x:353,y:510,t:1527873426690};\\\", \\\"{x:353,y:508,t:1527873426705};\\\", \\\"{x:353,y:506,t:1527873426722};\\\", \\\"{x:353,y:504,t:1527873426739};\\\", \\\"{x:353,y:500,t:1527873426756};\\\", \\\"{x:353,y:496,t:1527873426772};\\\", \\\"{x:354,y:488,t:1527873426789};\\\", \\\"{x:355,y:481,t:1527873426807};\\\", \\\"{x:356,y:474,t:1527873426822};\\\", \\\"{x:358,y:468,t:1527873426839};\\\", \\\"{x:359,y:465,t:1527873426856};\\\", \\\"{x:361,y:463,t:1527873426877};\\\", \\\"{x:369,y:462,t:1527873426889};\\\", \\\"{x:399,y:459,t:1527873426906};\\\", \\\"{x:437,y:461,t:1527873426922};\\\", \\\"{x:473,y:470,t:1527873426939};\\\", \\\"{x:503,y:480,t:1527873426956};\\\", \\\"{x:525,y:485,t:1527873426972};\\\", \\\"{x:557,y:491,t:1527873426989};\\\", \\\"{x:568,y:492,t:1527873427006};\\\", \\\"{x:573,y:493,t:1527873427022};\\\", \\\"{x:576,y:493,t:1527873427141};\\\", \\\"{x:579,y:493,t:1527873427156};\\\", \\\"{x:594,y:489,t:1527873427173};\\\", \\\"{x:611,y:486,t:1527873427189};\\\", \\\"{x:629,y:484,t:1527873427206};\\\", \\\"{x:647,y:481,t:1527873427222};\\\", \\\"{x:676,y:477,t:1527873427239};\\\", \\\"{x:726,y:477,t:1527873427256};\\\", \\\"{x:793,y:477,t:1527873427272};\\\", \\\"{x:870,y:482,t:1527873427289};\\\", \\\"{x:958,y:493,t:1527873427306};\\\", \\\"{x:1053,y:520,t:1527873427323};\\\", \\\"{x:1145,y:534,t:1527873427339};\\\", \\\"{x:1229,y:551,t:1527873427356};\\\", \\\"{x:1288,y:561,t:1527873427372};\\\", \\\"{x:1345,y:572,t:1527873427389};\\\", \\\"{x:1363,y:580,t:1527873427406};\\\", \\\"{x:1371,y:588,t:1527873427422};\\\", \\\"{x:1374,y:592,t:1527873427439};\\\", \\\"{x:1378,y:606,t:1527873427456};\\\", \\\"{x:1381,y:623,t:1527873427472};\\\", \\\"{x:1382,y:643,t:1527873427489};\\\", \\\"{x:1382,y:658,t:1527873427506};\\\", \\\"{x:1382,y:668,t:1527873427523};\\\", \\\"{x:1377,y:679,t:1527873427539};\\\", \\\"{x:1367,y:689,t:1527873427556};\\\", \\\"{x:1358,y:697,t:1527873427573};\\\", \\\"{x:1339,y:707,t:1527873427590};\\\", \\\"{x:1330,y:711,t:1527873427607};\\\", \\\"{x:1325,y:713,t:1527873427623};\\\", \\\"{x:1320,y:719,t:1527873427639};\\\", \\\"{x:1314,y:730,t:1527873427656};\\\", \\\"{x:1311,y:735,t:1527873427673};\\\", \\\"{x:1310,y:737,t:1527873427689};\\\", \\\"{x:1309,y:739,t:1527873427862};\\\", \\\"{x:1309,y:738,t:1527873427873};\\\", \\\"{x:1310,y:733,t:1527873427889};\\\", \\\"{x:1314,y:728,t:1527873427906};\\\", \\\"{x:1316,y:725,t:1527873427923};\\\", \\\"{x:1319,y:722,t:1527873427939};\\\", \\\"{x:1321,y:720,t:1527873427956};\\\", \\\"{x:1323,y:717,t:1527873427973};\\\", \\\"{x:1328,y:713,t:1527873427989};\\\", \\\"{x:1335,y:708,t:1527873428006};\\\", \\\"{x:1344,y:704,t:1527873428023};\\\", \\\"{x:1350,y:702,t:1527873428039};\\\", \\\"{x:1355,y:701,t:1527873428056};\\\", \\\"{x:1359,y:700,t:1527873428073};\\\", \\\"{x:1363,y:699,t:1527873428089};\\\", \\\"{x:1368,y:699,t:1527873428107};\\\", \\\"{x:1372,y:699,t:1527873428123};\\\", \\\"{x:1374,y:699,t:1527873428139};\\\", \\\"{x:1375,y:699,t:1527873428156};\\\", \\\"{x:1375,y:700,t:1527873428174};\\\", \\\"{x:1374,y:700,t:1527873428901};\\\", \\\"{x:1373,y:700,t:1527873428917};\\\", \\\"{x:1372,y:699,t:1527873428965};\\\", \\\"{x:1370,y:699,t:1527873428981};\\\", \\\"{x:1369,y:699,t:1527873429022};\\\", \\\"{x:1369,y:698,t:1527873429046};\\\", \\\"{x:1368,y:698,t:1527873429057};\\\", \\\"{x:1367,y:698,t:1527873429077};\\\", \\\"{x:1366,y:698,t:1527873429173};\\\", \\\"{x:1364,y:698,t:1527873429190};\\\", \\\"{x:1363,y:698,t:1527873429207};\\\", \\\"{x:1362,y:698,t:1527873429223};\\\", \\\"{x:1361,y:698,t:1527873429241};\\\", \\\"{x:1357,y:699,t:1527873429853};\\\", \\\"{x:1355,y:699,t:1527873429861};\\\", \\\"{x:1353,y:699,t:1527873429874};\\\", \\\"{x:1350,y:699,t:1527873429891};\\\", \\\"{x:1347,y:699,t:1527873429907};\\\", \\\"{x:1345,y:700,t:1527873429924};\\\", \\\"{x:1343,y:700,t:1527873429940};\\\", \\\"{x:1341,y:701,t:1527873429965};\\\", \\\"{x:1340,y:712,t:1527873430254};\\\", \\\"{x:1337,y:724,t:1527873430261};\\\", \\\"{x:1337,y:734,t:1527873430275};\\\", \\\"{x:1337,y:749,t:1527873430290};\\\", \\\"{x:1337,y:759,t:1527873430307};\\\", \\\"{x:1337,y:767,t:1527873430324};\\\", \\\"{x:1337,y:771,t:1527873430341};\\\", \\\"{x:1337,y:772,t:1527873430374};\\\", \\\"{x:1335,y:772,t:1527873430469};\\\", \\\"{x:1325,y:766,t:1527873430477};\\\", \\\"{x:1307,y:755,t:1527873430491};\\\", \\\"{x:1255,y:725,t:1527873430507};\\\", \\\"{x:1162,y:687,t:1527873430525};\\\", \\\"{x:1065,y:655,t:1527873430541};\\\", \\\"{x:952,y:630,t:1527873430557};\\\", \\\"{x:895,y:625,t:1527873430575};\\\", \\\"{x:836,y:625,t:1527873430591};\\\", \\\"{x:769,y:626,t:1527873430607};\\\", \\\"{x:723,y:641,t:1527873430625};\\\", \\\"{x:700,y:650,t:1527873430642};\\\", \\\"{x:687,y:655,t:1527873430658};\\\", \\\"{x:682,y:658,t:1527873430675};\\\", \\\"{x:677,y:663,t:1527873430692};\\\", \\\"{x:668,y:673,t:1527873430709};\\\", \\\"{x:665,y:676,t:1527873430725};\\\", \\\"{x:664,y:682,t:1527873430743};\\\", \\\"{x:659,y:691,t:1527873430759};\\\", \\\"{x:655,y:697,t:1527873430776};\\\", \\\"{x:651,y:703,t:1527873430793};\\\", \\\"{x:650,y:706,t:1527873430809};\\\", \\\"{x:648,y:709,t:1527873430825};\\\", \\\"{x:648,y:710,t:1527873430842};\\\", \\\"{x:647,y:710,t:1527873430859};\\\", \\\"{x:642,y:712,t:1527873430876};\\\", \\\"{x:634,y:713,t:1527873430893};\\\", \\\"{x:609,y:710,t:1527873430910};\\\", \\\"{x:586,y:705,t:1527873430925};\\\", \\\"{x:567,y:701,t:1527873430943};\\\", \\\"{x:553,y:700,t:1527873430960};\\\", \\\"{x:546,y:700,t:1527873430976};\\\", \\\"{x:534,y:701,t:1527873430992};\\\", \\\"{x:521,y:705,t:1527873431009};\\\", \\\"{x:519,y:707,t:1527873431025};\\\", \\\"{x:518,y:708,t:1527873431042};\\\", \\\"{x:517,y:711,t:1527873431059};\\\", \\\"{x:517,y:715,t:1527873431076};\\\", \\\"{x:517,y:719,t:1527873431092};\\\", \\\"{x:517,y:723,t:1527873431110};\\\", \\\"{x:516,y:726,t:1527873431126};\\\", \\\"{x:516,y:727,t:1527873431157};\\\", \\\"{x:515,y:727,t:1527873431164};\\\", \\\"{x:515,y:729,t:1527873431175};\\\", \\\"{x:514,y:731,t:1527873431192};\\\", \\\"{x:514,y:732,t:1527873431209};\\\", \\\"{x:513,y:736,t:1527873431225};\\\", \\\"{x:512,y:739,t:1527873431242};\\\", \\\"{x:511,y:742,t:1527873431259};\\\", \\\"{x:511,y:743,t:1527873431276};\\\", \\\"{x:510,y:744,t:1527873431294};\\\" ] }, { \\\"rt\\\": 60735, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 678970, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -05 PM-O -Z -Z -04 PM-04 PM-O -O -O -X -X -O -O -04 PM-F -F -F -F -12 PM-12 PM-01 PM-02 PM-03 PM-04 PM-03 PM-02 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:745,t:1527873433942};\\\", \\\"{x:502,y:739,t:1527873433950};\\\", \\\"{x:470,y:614,t:1527873434043};\\\", \\\"{x:466,y:583,t:1527873434062};\\\", \\\"{x:463,y:556,t:1527873434079};\\\", \\\"{x:460,y:512,t:1527873434096};\\\", \\\"{x:452,y:462,t:1527873434112};\\\", \\\"{x:449,y:441,t:1527873434129};\\\", \\\"{x:446,y:421,t:1527873434144};\\\", \\\"{x:446,y:414,t:1527873434162};\\\", \\\"{x:446,y:411,t:1527873434178};\\\", \\\"{x:444,y:411,t:1527873434518};\\\", \\\"{x:437,y:426,t:1527873434528};\\\", \\\"{x:421,y:449,t:1527873434546};\\\", \\\"{x:402,y:462,t:1527873434562};\\\", \\\"{x:381,y:467,t:1527873434578};\\\", \\\"{x:359,y:468,t:1527873434595};\\\", \\\"{x:334,y:468,t:1527873434612};\\\", \\\"{x:309,y:468,t:1527873434628};\\\", \\\"{x:289,y:468,t:1527873434645};\\\", \\\"{x:268,y:466,t:1527873434662};\\\", \\\"{x:260,y:466,t:1527873434678};\\\", \\\"{x:259,y:466,t:1527873434695};\\\", \\\"{x:258,y:466,t:1527873434711};\\\", \\\"{x:257,y:466,t:1527873434728};\\\", \\\"{x:255,y:465,t:1527873434750};\\\", \\\"{x:253,y:464,t:1527873434766};\\\", \\\"{x:251,y:463,t:1527873434806};\\\", \\\"{x:250,y:462,t:1527873434830};\\\", \\\"{x:248,y:462,t:1527873434845};\\\", \\\"{x:255,y:462,t:1527873435078};\\\", \\\"{x:278,y:471,t:1527873435094};\\\", \\\"{x:291,y:478,t:1527873435110};\\\", \\\"{x:292,y:478,t:1527873435128};\\\", \\\"{x:295,y:478,t:1527873436070};\\\", \\\"{x:301,y:478,t:1527873436078};\\\", \\\"{x:313,y:474,t:1527873436093};\\\", \\\"{x:351,y:472,t:1527873436110};\\\", \\\"{x:374,y:472,t:1527873436127};\\\", \\\"{x:389,y:472,t:1527873436143};\\\", \\\"{x:393,y:472,t:1527873436160};\\\", \\\"{x:395,y:472,t:1527873436177};\\\", \\\"{x:397,y:470,t:1527873436193};\\\", \\\"{x:399,y:470,t:1527873436210};\\\", \\\"{x:401,y:470,t:1527873436227};\\\", \\\"{x:406,y:469,t:1527873436243};\\\", \\\"{x:413,y:468,t:1527873436260};\\\", \\\"{x:422,y:466,t:1527873436277};\\\", \\\"{x:431,y:465,t:1527873436293};\\\", \\\"{x:439,y:461,t:1527873436310};\\\", \\\"{x:452,y:459,t:1527873436327};\\\", \\\"{x:474,y:451,t:1527873436343};\\\", \\\"{x:501,y:444,t:1527873436360};\\\", \\\"{x:526,y:439,t:1527873436377};\\\", \\\"{x:545,y:434,t:1527873436393};\\\", \\\"{x:559,y:433,t:1527873436410};\\\", \\\"{x:583,y:429,t:1527873436426};\\\", \\\"{x:634,y:423,t:1527873436443};\\\", \\\"{x:707,y:412,t:1527873436460};\\\", \\\"{x:797,y:406,t:1527873436476};\\\", \\\"{x:896,y:399,t:1527873436493};\\\", \\\"{x:1021,y:397,t:1527873436511};\\\", \\\"{x:1071,y:397,t:1527873436526};\\\", \\\"{x:1096,y:397,t:1527873436543};\\\", \\\"{x:1106,y:395,t:1527873436561};\\\", \\\"{x:1110,y:394,t:1527873436577};\\\", \\\"{x:1115,y:393,t:1527873436593};\\\", \\\"{x:1124,y:391,t:1527873436610};\\\", \\\"{x:1148,y:384,t:1527873436627};\\\", \\\"{x:1201,y:375,t:1527873436643};\\\", \\\"{x:1298,y:365,t:1527873436659};\\\", \\\"{x:1399,y:357,t:1527873436677};\\\", \\\"{x:1496,y:357,t:1527873436693};\\\", \\\"{x:1585,y:357,t:1527873436709};\\\", \\\"{x:1686,y:356,t:1527873436726};\\\", \\\"{x:1730,y:351,t:1527873436743};\\\", \\\"{x:1756,y:351,t:1527873436759};\\\", \\\"{x:1764,y:351,t:1527873436776};\\\", \\\"{x:1765,y:351,t:1527873436793};\\\", \\\"{x:1765,y:350,t:1527873437951};\\\", \\\"{x:1764,y:346,t:1527873437958};\\\", \\\"{x:1699,y:328,t:1527873437976};\\\", \\\"{x:1580,y:292,t:1527873437991};\\\", \\\"{x:1458,y:259,t:1527873438008};\\\", \\\"{x:1334,y:225,t:1527873438025};\\\", \\\"{x:1220,y:192,t:1527873438041};\\\", \\\"{x:1145,y:168,t:1527873438058};\\\", \\\"{x:1107,y:158,t:1527873438075};\\\", \\\"{x:1083,y:146,t:1527873438091};\\\", \\\"{x:1055,y:129,t:1527873438108};\\\", \\\"{x:1022,y:107,t:1527873438125};\\\", \\\"{x:990,y:82,t:1527873438141};\\\", \\\"{x:954,y:59,t:1527873438158};\\\", \\\"{x:947,y:56,t:1527873438175};\\\", \\\"{x:950,y:47,t:1527873438510};\\\", \\\"{x:972,y:36,t:1527873438524};\\\", \\\"{x:1037,y:16,t:1527873438541};\\\", \\\"{x:1118,y:16,t:1527873438558};\\\", \\\"{x:1152,y:16,t:1527873438574};\\\", \\\"{x:1186,y:16,t:1527873438591};\\\", \\\"{x:1217,y:16,t:1527873438607};\\\", \\\"{x:1247,y:16,t:1527873438624};\\\", \\\"{x:1271,y:16,t:1527873438641};\\\", \\\"{x:1298,y:16,t:1527873438657};\\\", \\\"{x:1341,y:16,t:1527873438674};\\\", \\\"{x:1419,y:16,t:1527873438691};\\\", \\\"{x:1525,y:16,t:1527873438707};\\\", \\\"{x:1645,y:16,t:1527873438724};\\\", \\\"{x:1746,y:16,t:1527873438741};\\\", \\\"{x:1829,y:16,t:1527873438757};\\\", \\\"{x:1906,y:18,t:1527873438774};\\\", \\\"{x:1919,y:31,t:1527873438790};\\\", \\\"{x:1919,y:36,t:1527873438798};\\\", \\\"{x:1919,y:43,t:1527873438816};\\\", \\\"{x:1919,y:48,t:1527873438832};\\\", \\\"{x:1919,y:49,t:1527873438848};\\\", \\\"{x:1919,y:56,t:1527873438893};\\\", \\\"{x:1919,y:76,t:1527873438901};\\\", \\\"{x:1911,y:118,t:1527873438916};\\\", \\\"{x:1896,y:242,t:1527873438932};\\\", \\\"{x:1894,y:342,t:1527873438949};\\\", \\\"{x:1894,y:467,t:1527873438965};\\\", \\\"{x:1894,y:564,t:1527873438983};\\\", \\\"{x:1876,y:683,t:1527873438999};\\\", \\\"{x:1857,y:808,t:1527873439016};\\\", \\\"{x:1848,y:877,t:1527873439033};\\\", \\\"{x:1841,y:900,t:1527873439049};\\\", \\\"{x:1835,y:916,t:1527873439066};\\\", \\\"{x:1830,y:931,t:1527873439082};\\\", \\\"{x:1824,y:947,t:1527873439100};\\\", \\\"{x:1822,y:952,t:1527873439116};\\\", \\\"{x:1821,y:953,t:1527873439133};\\\", \\\"{x:1819,y:953,t:1527873439149};\\\", \\\"{x:1801,y:950,t:1527873439166};\\\", \\\"{x:1754,y:941,t:1527873439183};\\\", \\\"{x:1690,y:933,t:1527873439199};\\\", \\\"{x:1644,y:930,t:1527873439216};\\\", \\\"{x:1617,y:930,t:1527873439233};\\\", \\\"{x:1594,y:930,t:1527873439249};\\\", \\\"{x:1567,y:930,t:1527873439266};\\\", \\\"{x:1538,y:930,t:1527873439283};\\\", \\\"{x:1511,y:930,t:1527873439299};\\\", \\\"{x:1489,y:928,t:1527873439316};\\\", \\\"{x:1471,y:924,t:1527873439333};\\\", \\\"{x:1459,y:923,t:1527873439349};\\\", \\\"{x:1451,y:922,t:1527873439366};\\\", \\\"{x:1445,y:920,t:1527873439383};\\\", \\\"{x:1438,y:918,t:1527873439399};\\\", \\\"{x:1429,y:917,t:1527873439416};\\\", \\\"{x:1419,y:915,t:1527873439433};\\\", \\\"{x:1402,y:913,t:1527873439450};\\\", \\\"{x:1384,y:910,t:1527873439465};\\\", \\\"{x:1370,y:907,t:1527873439483};\\\", \\\"{x:1351,y:899,t:1527873439500};\\\", \\\"{x:1334,y:891,t:1527873439516};\\\", \\\"{x:1322,y:883,t:1527873439533};\\\", \\\"{x:1308,y:873,t:1527873439549};\\\", \\\"{x:1298,y:865,t:1527873439566};\\\", \\\"{x:1287,y:853,t:1527873439583};\\\", \\\"{x:1275,y:840,t:1527873439600};\\\", \\\"{x:1269,y:833,t:1527873439616};\\\", \\\"{x:1268,y:832,t:1527873439633};\\\", \\\"{x:1266,y:829,t:1527873439650};\\\", \\\"{x:1262,y:826,t:1527873439666};\\\", \\\"{x:1259,y:821,t:1527873439684};\\\", \\\"{x:1255,y:817,t:1527873439701};\\\", \\\"{x:1252,y:812,t:1527873439716};\\\", \\\"{x:1250,y:807,t:1527873439733};\\\", \\\"{x:1247,y:803,t:1527873439750};\\\", \\\"{x:1246,y:799,t:1527873439766};\\\", \\\"{x:1244,y:795,t:1527873439784};\\\", \\\"{x:1244,y:790,t:1527873439801};\\\", \\\"{x:1244,y:785,t:1527873439816};\\\", \\\"{x:1244,y:782,t:1527873439833};\\\", \\\"{x:1243,y:779,t:1527873439850};\\\", \\\"{x:1243,y:776,t:1527873439866};\\\", \\\"{x:1243,y:772,t:1527873439884};\\\", \\\"{x:1243,y:769,t:1527873439901};\\\", \\\"{x:1243,y:765,t:1527873439916};\\\", \\\"{x:1242,y:761,t:1527873439933};\\\", \\\"{x:1242,y:752,t:1527873439950};\\\", \\\"{x:1242,y:745,t:1527873439968};\\\", \\\"{x:1242,y:738,t:1527873439983};\\\", \\\"{x:1242,y:734,t:1527873440000};\\\", \\\"{x:1242,y:730,t:1527873440017};\\\", \\\"{x:1242,y:724,t:1527873440033};\\\", \\\"{x:1242,y:709,t:1527873440051};\\\", \\\"{x:1244,y:687,t:1527873440068};\\\", \\\"{x:1250,y:665,t:1527873440083};\\\", \\\"{x:1257,y:641,t:1527873440100};\\\", \\\"{x:1264,y:617,t:1527873440117};\\\", \\\"{x:1273,y:592,t:1527873440134};\\\", \\\"{x:1278,y:566,t:1527873440153};\\\", \\\"{x:1280,y:553,t:1527873440167};\\\", \\\"{x:1280,y:540,t:1527873440182};\\\", \\\"{x:1280,y:531,t:1527873440199};\\\", \\\"{x:1280,y:528,t:1527873440217};\\\", \\\"{x:1280,y:527,t:1527873440894};\\\", \\\"{x:1280,y:526,t:1527873440910};\\\", \\\"{x:1285,y:532,t:1527873441014};\\\", \\\"{x:1299,y:551,t:1527873441022};\\\", \\\"{x:1322,y:578,t:1527873441035};\\\", \\\"{x:1380,y:649,t:1527873441052};\\\", \\\"{x:1463,y:745,t:1527873441068};\\\", \\\"{x:1546,y:834,t:1527873441084};\\\", \\\"{x:1648,y:930,t:1527873441102};\\\", \\\"{x:1687,y:972,t:1527873441117};\\\", \\\"{x:1707,y:1002,t:1527873441135};\\\", \\\"{x:1718,y:1022,t:1527873441151};\\\", \\\"{x:1732,y:1045,t:1527873441167};\\\", \\\"{x:1744,y:1066,t:1527873441184};\\\", \\\"{x:1755,y:1089,t:1527873441201};\\\", \\\"{x:1758,y:1106,t:1527873441217};\\\", \\\"{x:1760,y:1115,t:1527873441234};\\\", \\\"{x:1761,y:1118,t:1527873441251};\\\", \\\"{x:1759,y:1117,t:1527873441422};\\\", \\\"{x:1749,y:1105,t:1527873441434};\\\", \\\"{x:1718,y:1070,t:1527873441451};\\\", \\\"{x:1677,y:1021,t:1527873441469};\\\", \\\"{x:1624,y:940,t:1527873441486};\\\", \\\"{x:1582,y:866,t:1527873441502};\\\", \\\"{x:1554,y:818,t:1527873441518};\\\", \\\"{x:1539,y:789,t:1527873441536};\\\", \\\"{x:1529,y:773,t:1527873441552};\\\", \\\"{x:1526,y:766,t:1527873441569};\\\", \\\"{x:1523,y:762,t:1527873441584};\\\", \\\"{x:1521,y:758,t:1527873441601};\\\", \\\"{x:1520,y:757,t:1527873441622};\\\", \\\"{x:1519,y:757,t:1527873441634};\\\", \\\"{x:1518,y:756,t:1527873441651};\\\", \\\"{x:1518,y:755,t:1527873441668};\\\", \\\"{x:1517,y:755,t:1527873441765};\\\", \\\"{x:1517,y:754,t:1527873442077};\\\", \\\"{x:1517,y:752,t:1527873442085};\\\", \\\"{x:1524,y:742,t:1527873442102};\\\", \\\"{x:1534,y:733,t:1527873442118};\\\", \\\"{x:1545,y:724,t:1527873442134};\\\", \\\"{x:1551,y:718,t:1527873442150};\\\", \\\"{x:1558,y:713,t:1527873442168};\\\", \\\"{x:1562,y:709,t:1527873442185};\\\", \\\"{x:1567,y:704,t:1527873442201};\\\", \\\"{x:1571,y:700,t:1527873442218};\\\", \\\"{x:1574,y:697,t:1527873442235};\\\", \\\"{x:1575,y:695,t:1527873442251};\\\", \\\"{x:1577,y:694,t:1527873442269};\\\", \\\"{x:1580,y:691,t:1527873442286};\\\", \\\"{x:1581,y:691,t:1527873442301};\\\", \\\"{x:1582,y:691,t:1527873442334};\\\", \\\"{x:1583,y:691,t:1527873442382};\\\", \\\"{x:1587,y:690,t:1527873442390};\\\", \\\"{x:1592,y:687,t:1527873442402};\\\", \\\"{x:1602,y:685,t:1527873442418};\\\", \\\"{x:1609,y:683,t:1527873442435};\\\", \\\"{x:1612,y:683,t:1527873442453};\\\", \\\"{x:1613,y:683,t:1527873442468};\\\", \\\"{x:1616,y:683,t:1527873442485};\\\", \\\"{x:1618,y:683,t:1527873442503};\\\", \\\"{x:1619,y:683,t:1527873442526};\\\", \\\"{x:1621,y:683,t:1527873442550};\\\", \\\"{x:1622,y:685,t:1527873442566};\\\", \\\"{x:1622,y:687,t:1527873442574};\\\", \\\"{x:1622,y:689,t:1527873442585};\\\", \\\"{x:1622,y:694,t:1527873442602};\\\", \\\"{x:1622,y:696,t:1527873442619};\\\", \\\"{x:1622,y:697,t:1527873442636};\\\", \\\"{x:1622,y:699,t:1527873442652};\\\", \\\"{x:1622,y:700,t:1527873442669};\\\", \\\"{x:1621,y:701,t:1527873442742};\\\", \\\"{x:1619,y:701,t:1527873442757};\\\", \\\"{x:1618,y:701,t:1527873442773};\\\", \\\"{x:1617,y:701,t:1527873442785};\\\", \\\"{x:1616,y:701,t:1527873442902};\\\", \\\"{x:1615,y:707,t:1527873443767};\\\", \\\"{x:1616,y:718,t:1527873443774};\\\", \\\"{x:1616,y:730,t:1527873443786};\\\", \\\"{x:1617,y:752,t:1527873443803};\\\", \\\"{x:1617,y:766,t:1527873443818};\\\", \\\"{x:1617,y:775,t:1527873443836};\\\", \\\"{x:1617,y:788,t:1527873443852};\\\", \\\"{x:1617,y:791,t:1527873443869};\\\", \\\"{x:1617,y:794,t:1527873443886};\\\", \\\"{x:1617,y:795,t:1527873443902};\\\", \\\"{x:1617,y:796,t:1527873443925};\\\", \\\"{x:1617,y:798,t:1527873443936};\\\", \\\"{x:1617,y:804,t:1527873443953};\\\", \\\"{x:1618,y:809,t:1527873443969};\\\", \\\"{x:1619,y:815,t:1527873443986};\\\", \\\"{x:1619,y:817,t:1527873444003};\\\", \\\"{x:1620,y:818,t:1527873444020};\\\", \\\"{x:1620,y:820,t:1527873444036};\\\", \\\"{x:1623,y:826,t:1527873444053};\\\", \\\"{x:1624,y:830,t:1527873444070};\\\", \\\"{x:1625,y:835,t:1527873444086};\\\", \\\"{x:1628,y:843,t:1527873444103};\\\", \\\"{x:1629,y:850,t:1527873444119};\\\", \\\"{x:1629,y:862,t:1527873444136};\\\", \\\"{x:1630,y:881,t:1527873444153};\\\", \\\"{x:1633,y:903,t:1527873444169};\\\", \\\"{x:1633,y:926,t:1527873444186};\\\", \\\"{x:1634,y:941,t:1527873444204};\\\", \\\"{x:1633,y:955,t:1527873444221};\\\", \\\"{x:1631,y:967,t:1527873444236};\\\", \\\"{x:1627,y:979,t:1527873444254};\\\", \\\"{x:1625,y:984,t:1527873444270};\\\", \\\"{x:1625,y:987,t:1527873444287};\\\", \\\"{x:1624,y:988,t:1527873444304};\\\", \\\"{x:1624,y:989,t:1527873444321};\\\", \\\"{x:1624,y:990,t:1527873444390};\\\", \\\"{x:1624,y:989,t:1527873444854};\\\", \\\"{x:1617,y:970,t:1527873444870};\\\", \\\"{x:1614,y:960,t:1527873444888};\\\", \\\"{x:1612,y:952,t:1527873444904};\\\", \\\"{x:1611,y:949,t:1527873444920};\\\", \\\"{x:1606,y:938,t:1527873444937};\\\", \\\"{x:1604,y:929,t:1527873444954};\\\", \\\"{x:1601,y:920,t:1527873444971};\\\", \\\"{x:1599,y:910,t:1527873444988};\\\", \\\"{x:1597,y:893,t:1527873445003};\\\", \\\"{x:1595,y:879,t:1527873445020};\\\", \\\"{x:1595,y:853,t:1527873445037};\\\", \\\"{x:1595,y:834,t:1527873445054};\\\", \\\"{x:1594,y:815,t:1527873445070};\\\", \\\"{x:1594,y:798,t:1527873445088};\\\", \\\"{x:1594,y:786,t:1527873445104};\\\", \\\"{x:1594,y:773,t:1527873445121};\\\", \\\"{x:1590,y:759,t:1527873445138};\\\", \\\"{x:1589,y:746,t:1527873445155};\\\", \\\"{x:1587,y:735,t:1527873445171};\\\", \\\"{x:1586,y:731,t:1527873445187};\\\", \\\"{x:1586,y:726,t:1527873445204};\\\", \\\"{x:1583,y:720,t:1527873445221};\\\", \\\"{x:1582,y:712,t:1527873445238};\\\", \\\"{x:1582,y:708,t:1527873445253};\\\", \\\"{x:1581,y:707,t:1527873445278};\\\", \\\"{x:1581,y:706,t:1527873445326};\\\", \\\"{x:1578,y:705,t:1527873445338};\\\", \\\"{x:1577,y:704,t:1527873445354};\\\", \\\"{x:1579,y:704,t:1527873445791};\\\", \\\"{x:1580,y:708,t:1527873445805};\\\", \\\"{x:1580,y:740,t:1527873445822};\\\", \\\"{x:1580,y:756,t:1527873445838};\\\", \\\"{x:1580,y:771,t:1527873445855};\\\", \\\"{x:1580,y:781,t:1527873445871};\\\", \\\"{x:1579,y:789,t:1527873445888};\\\", \\\"{x:1578,y:793,t:1527873445905};\\\", \\\"{x:1577,y:799,t:1527873445921};\\\", \\\"{x:1576,y:804,t:1527873445937};\\\", \\\"{x:1574,y:807,t:1527873445955};\\\", \\\"{x:1571,y:812,t:1527873445971};\\\", \\\"{x:1569,y:816,t:1527873445988};\\\", \\\"{x:1566,y:819,t:1527873446005};\\\", \\\"{x:1558,y:822,t:1527873446022};\\\", \\\"{x:1549,y:823,t:1527873446038};\\\", \\\"{x:1540,y:823,t:1527873446054};\\\", \\\"{x:1531,y:823,t:1527873446071};\\\", \\\"{x:1525,y:823,t:1527873446089};\\\", \\\"{x:1523,y:823,t:1527873446104};\\\", \\\"{x:1521,y:823,t:1527873446121};\\\", \\\"{x:1518,y:822,t:1527873446138};\\\", \\\"{x:1515,y:821,t:1527873446154};\\\", \\\"{x:1511,y:819,t:1527873446171};\\\", \\\"{x:1508,y:815,t:1527873446188};\\\", \\\"{x:1507,y:807,t:1527873446203};\\\", \\\"{x:1505,y:800,t:1527873446221};\\\", \\\"{x:1505,y:796,t:1527873446238};\\\", \\\"{x:1505,y:791,t:1527873446254};\\\", \\\"{x:1505,y:787,t:1527873446271};\\\", \\\"{x:1505,y:781,t:1527873446288};\\\", \\\"{x:1506,y:777,t:1527873446304};\\\", \\\"{x:1506,y:774,t:1527873446321};\\\", \\\"{x:1506,y:772,t:1527873446338};\\\", \\\"{x:1506,y:771,t:1527873446354};\\\", \\\"{x:1506,y:768,t:1527873446371};\\\", \\\"{x:1506,y:767,t:1527873446389};\\\", \\\"{x:1506,y:765,t:1527873446404};\\\", \\\"{x:1506,y:763,t:1527873446685};\\\", \\\"{x:1508,y:763,t:1527873446693};\\\", \\\"{x:1509,y:763,t:1527873446705};\\\", \\\"{x:1513,y:763,t:1527873446721};\\\", \\\"{x:1518,y:765,t:1527873446738};\\\", \\\"{x:1519,y:765,t:1527873446755};\\\", \\\"{x:1521,y:766,t:1527873446773};\\\", \\\"{x:1522,y:766,t:1527873446788};\\\", \\\"{x:1521,y:766,t:1527873447438};\\\", \\\"{x:1520,y:766,t:1527873447462};\\\", \\\"{x:1519,y:766,t:1527873447542};\\\", \\\"{x:1518,y:766,t:1527873447555};\\\", \\\"{x:1517,y:766,t:1527873447572};\\\", \\\"{x:1517,y:765,t:1527873447589};\\\", \\\"{x:1516,y:765,t:1527873447605};\\\", \\\"{x:1516,y:764,t:1527873447623};\\\", \\\"{x:1514,y:764,t:1527873447640};\\\", \\\"{x:1513,y:764,t:1527873447655};\\\", \\\"{x:1512,y:763,t:1527873447672};\\\", \\\"{x:1510,y:762,t:1527873447690};\\\", \\\"{x:1508,y:761,t:1527873447711};\\\", \\\"{x:1507,y:761,t:1527873447722};\\\", \\\"{x:1505,y:761,t:1527873447740};\\\", \\\"{x:1504,y:760,t:1527873447756};\\\", \\\"{x:1503,y:759,t:1527873447798};\\\", \\\"{x:1504,y:759,t:1527873448444};\\\", \\\"{x:1504,y:760,t:1527873448485};\\\", \\\"{x:1505,y:760,t:1527873448557};\\\", \\\"{x:1506,y:760,t:1527873448598};\\\", \\\"{x:1507,y:761,t:1527873448621};\\\", \\\"{x:1508,y:761,t:1527873448831};\\\", \\\"{x:1509,y:762,t:1527873448855};\\\", \\\"{x:1510,y:762,t:1527873448878};\\\", \\\"{x:1511,y:762,t:1527873448918};\\\", \\\"{x:1511,y:763,t:1527873448925};\\\", \\\"{x:1512,y:763,t:1527873448941};\\\", \\\"{x:1513,y:763,t:1527873448965};\\\", \\\"{x:1513,y:764,t:1527873448973};\\\", \\\"{x:1514,y:764,t:1527873449006};\\\", \\\"{x:1515,y:765,t:1527873449150};\\\", \\\"{x:1515,y:770,t:1527873449255};\\\", \\\"{x:1510,y:786,t:1527873449261};\\\", \\\"{x:1505,y:796,t:1527873449274};\\\", \\\"{x:1499,y:813,t:1527873449291};\\\", \\\"{x:1493,y:828,t:1527873449307};\\\", \\\"{x:1487,y:837,t:1527873449323};\\\", \\\"{x:1481,y:845,t:1527873449341};\\\", \\\"{x:1476,y:851,t:1527873449357};\\\", \\\"{x:1475,y:852,t:1527873449373};\\\", \\\"{x:1474,y:855,t:1527873449390};\\\", \\\"{x:1472,y:857,t:1527873449407};\\\", \\\"{x:1472,y:859,t:1527873449424};\\\", \\\"{x:1470,y:862,t:1527873449440};\\\", \\\"{x:1469,y:859,t:1527873449598};\\\", \\\"{x:1469,y:854,t:1527873449607};\\\", \\\"{x:1469,y:849,t:1527873449624};\\\", \\\"{x:1469,y:845,t:1527873449640};\\\", \\\"{x:1469,y:840,t:1527873449657};\\\", \\\"{x:1469,y:836,t:1527873449673};\\\", \\\"{x:1469,y:832,t:1527873449691};\\\", \\\"{x:1470,y:831,t:1527873449708};\\\", \\\"{x:1473,y:831,t:1527873449895};\\\", \\\"{x:1475,y:831,t:1527873449909};\\\", \\\"{x:1477,y:831,t:1527873449926};\\\", \\\"{x:1480,y:833,t:1527873449958};\\\", \\\"{x:1484,y:834,t:1527873449974};\\\", \\\"{x:1484,y:835,t:1527873449998};\\\", \\\"{x:1485,y:835,t:1527873450382};\\\", \\\"{x:1485,y:834,t:1527873451006};\\\", \\\"{x:1486,y:833,t:1527873452351};\\\", \\\"{x:1487,y:833,t:1527873452359};\\\", \\\"{x:1488,y:832,t:1527873452376};\\\", \\\"{x:1490,y:832,t:1527873452392};\\\", \\\"{x:1494,y:830,t:1527873452410};\\\", \\\"{x:1495,y:830,t:1527873452426};\\\", \\\"{x:1498,y:829,t:1527873452443};\\\", \\\"{x:1500,y:829,t:1527873452460};\\\", \\\"{x:1500,y:828,t:1527873452476};\\\", \\\"{x:1502,y:828,t:1527873452493};\\\", \\\"{x:1503,y:828,t:1527873452510};\\\", \\\"{x:1505,y:828,t:1527873452526};\\\", \\\"{x:1506,y:828,t:1527873452542};\\\", \\\"{x:1509,y:828,t:1527873452559};\\\", \\\"{x:1511,y:828,t:1527873452576};\\\", \\\"{x:1514,y:828,t:1527873452593};\\\", \\\"{x:1515,y:828,t:1527873452609};\\\", \\\"{x:1518,y:828,t:1527873452626};\\\", \\\"{x:1520,y:828,t:1527873452643};\\\", \\\"{x:1522,y:828,t:1527873452659};\\\", \\\"{x:1525,y:828,t:1527873452677};\\\", \\\"{x:1527,y:828,t:1527873452693};\\\", \\\"{x:1528,y:828,t:1527873452710};\\\", \\\"{x:1530,y:828,t:1527873452726};\\\", \\\"{x:1531,y:828,t:1527873452750};\\\", \\\"{x:1532,y:829,t:1527873452766};\\\", \\\"{x:1533,y:829,t:1527873452966};\\\", \\\"{x:1533,y:830,t:1527873452977};\\\", \\\"{x:1535,y:831,t:1527873452993};\\\", \\\"{x:1536,y:831,t:1527873453010};\\\", \\\"{x:1537,y:831,t:1527873453027};\\\", \\\"{x:1538,y:832,t:1527873453043};\\\", \\\"{x:1539,y:832,t:1527873453060};\\\", \\\"{x:1540,y:833,t:1527873453077};\\\", \\\"{x:1541,y:833,t:1527873453158};\\\", \\\"{x:1542,y:833,t:1527873453166};\\\", \\\"{x:1543,y:833,t:1527873453181};\\\", \\\"{x:1544,y:834,t:1527873453193};\\\", \\\"{x:1545,y:834,t:1527873453214};\\\", \\\"{x:1547,y:835,t:1527873453237};\\\", \\\"{x:1548,y:835,t:1527873453246};\\\", \\\"{x:1549,y:835,t:1527873453260};\\\", \\\"{x:1549,y:836,t:1527873453276};\\\", \\\"{x:1551,y:837,t:1527873453294};\\\", \\\"{x:1552,y:837,t:1527873453309};\\\", \\\"{x:1551,y:837,t:1527873453790};\\\", \\\"{x:1550,y:837,t:1527873453806};\\\", \\\"{x:1550,y:836,t:1527873453813};\\\", \\\"{x:1549,y:836,t:1527873453846};\\\", \\\"{x:1548,y:836,t:1527873453861};\\\", \\\"{x:1547,y:835,t:1527873453902};\\\", \\\"{x:1546,y:834,t:1527873453958};\\\", \\\"{x:1545,y:834,t:1527873453997};\\\", \\\"{x:1544,y:834,t:1527873454011};\\\", \\\"{x:1543,y:833,t:1527873454026};\\\", \\\"{x:1546,y:833,t:1527873455718};\\\", \\\"{x:1551,y:833,t:1527873455729};\\\", \\\"{x:1556,y:832,t:1527873455745};\\\", \\\"{x:1561,y:831,t:1527873455762};\\\", \\\"{x:1568,y:829,t:1527873455779};\\\", \\\"{x:1573,y:829,t:1527873455795};\\\", \\\"{x:1578,y:828,t:1527873455812};\\\", \\\"{x:1581,y:827,t:1527873455829};\\\", \\\"{x:1582,y:827,t:1527873455845};\\\", \\\"{x:1585,y:827,t:1527873455862};\\\", \\\"{x:1589,y:826,t:1527873455879};\\\", \\\"{x:1592,y:826,t:1527873455895};\\\", \\\"{x:1594,y:826,t:1527873455912};\\\", \\\"{x:1597,y:826,t:1527873455929};\\\", \\\"{x:1598,y:826,t:1527873455945};\\\", \\\"{x:1600,y:826,t:1527873455961};\\\", \\\"{x:1603,y:826,t:1527873455979};\\\", \\\"{x:1604,y:826,t:1527873455996};\\\", \\\"{x:1606,y:826,t:1527873456012};\\\", \\\"{x:1608,y:826,t:1527873456029};\\\", \\\"{x:1610,y:826,t:1527873456046};\\\", \\\"{x:1611,y:826,t:1527873456061};\\\", \\\"{x:1612,y:826,t:1527873456087};\\\", \\\"{x:1613,y:826,t:1527873456118};\\\", \\\"{x:1608,y:826,t:1527873456494};\\\", \\\"{x:1589,y:823,t:1527873456501};\\\", \\\"{x:1557,y:819,t:1527873456513};\\\", \\\"{x:1471,y:808,t:1527873456529};\\\", \\\"{x:1384,y:793,t:1527873456545};\\\", \\\"{x:1282,y:781,t:1527873456563};\\\", \\\"{x:1206,y:767,t:1527873456579};\\\", \\\"{x:1159,y:762,t:1527873456596};\\\", \\\"{x:1138,y:758,t:1527873456613};\\\", \\\"{x:1127,y:755,t:1527873456629};\\\", \\\"{x:1119,y:753,t:1527873456646};\\\", \\\"{x:1116,y:751,t:1527873456663};\\\", \\\"{x:1114,y:751,t:1527873456679};\\\", \\\"{x:1106,y:747,t:1527873456696};\\\", \\\"{x:1094,y:745,t:1527873456714};\\\", \\\"{x:1078,y:739,t:1527873456729};\\\", \\\"{x:1060,y:734,t:1527873456745};\\\", \\\"{x:1033,y:726,t:1527873456763};\\\", \\\"{x:1008,y:719,t:1527873456779};\\\", \\\"{x:984,y:713,t:1527873456796};\\\", \\\"{x:960,y:711,t:1527873456813};\\\", \\\"{x:933,y:707,t:1527873456830};\\\", \\\"{x:925,y:706,t:1527873456845};\\\", \\\"{x:923,y:706,t:1527873456863};\\\", \\\"{x:924,y:706,t:1527873456990};\\\", \\\"{x:928,y:708,t:1527873456997};\\\", \\\"{x:937,y:710,t:1527873457013};\\\", \\\"{x:982,y:728,t:1527873457029};\\\", \\\"{x:1040,y:743,t:1527873457045};\\\", \\\"{x:1112,y:759,t:1527873457063};\\\", \\\"{x:1190,y:771,t:1527873457080};\\\", \\\"{x:1243,y:779,t:1527873457096};\\\", \\\"{x:1293,y:785,t:1527873457113};\\\", \\\"{x:1328,y:788,t:1527873457130};\\\", \\\"{x:1348,y:791,t:1527873457146};\\\", \\\"{x:1353,y:791,t:1527873457163};\\\", \\\"{x:1352,y:790,t:1527873457238};\\\", \\\"{x:1346,y:784,t:1527873457246};\\\", \\\"{x:1318,y:767,t:1527873457263};\\\", \\\"{x:1263,y:742,t:1527873457280};\\\", \\\"{x:1181,y:709,t:1527873457295};\\\", \\\"{x:1072,y:675,t:1527873457313};\\\", \\\"{x:944,y:632,t:1527873457329};\\\", \\\"{x:795,y:590,t:1527873457346};\\\", \\\"{x:653,y:538,t:1527873457362};\\\", \\\"{x:508,y:492,t:1527873457380};\\\", \\\"{x:404,y:449,t:1527873457391};\\\", \\\"{x:343,y:423,t:1527873457407};\\\", \\\"{x:322,y:412,t:1527873457431};\\\", \\\"{x:321,y:412,t:1527873457447};\\\", \\\"{x:321,y:415,t:1527873457557};\\\", \\\"{x:324,y:425,t:1527873457565};\\\", \\\"{x:333,y:444,t:1527873457580};\\\", \\\"{x:352,y:472,t:1527873457596};\\\", \\\"{x:376,y:496,t:1527873457614};\\\", \\\"{x:413,y:514,t:1527873457631};\\\", \\\"{x:458,y:528,t:1527873457649};\\\", \\\"{x:511,y:542,t:1527873457665};\\\", \\\"{x:542,y:547,t:1527873457680};\\\", \\\"{x:564,y:549,t:1527873457697};\\\", \\\"{x:575,y:551,t:1527873457715};\\\", \\\"{x:576,y:552,t:1527873457731};\\\", \\\"{x:577,y:552,t:1527873457806};\\\", \\\"{x:580,y:554,t:1527873457815};\\\", \\\"{x:581,y:555,t:1527873457831};\\\", \\\"{x:582,y:556,t:1527873457849};\\\", \\\"{x:584,y:558,t:1527873457925};\\\", \\\"{x:586,y:562,t:1527873457933};\\\", \\\"{x:587,y:564,t:1527873457949};\\\", \\\"{x:588,y:567,t:1527873457964};\\\", \\\"{x:593,y:575,t:1527873457980};\\\", \\\"{x:598,y:582,t:1527873457998};\\\", \\\"{x:603,y:590,t:1527873458014};\\\", \\\"{x:605,y:592,t:1527873458031};\\\", \\\"{x:605,y:593,t:1527873458101};\\\", \\\"{x:606,y:593,t:1527873458114};\\\", \\\"{x:610,y:594,t:1527873458132};\\\", \\\"{x:614,y:596,t:1527873458147};\\\", \\\"{x:617,y:598,t:1527873458164};\\\", \\\"{x:618,y:598,t:1527873458180};\\\", \\\"{x:617,y:598,t:1527873458566};\\\", \\\"{x:614,y:597,t:1527873458581};\\\", \\\"{x:613,y:597,t:1527873458598};\\\", \\\"{x:612,y:597,t:1527873458615};\\\", \\\"{x:612,y:596,t:1527873458631};\\\", \\\"{x:611,y:593,t:1527873458847};\\\", \\\"{x:613,y:584,t:1527873458865};\\\", \\\"{x:614,y:580,t:1527873458881};\\\", \\\"{x:614,y:579,t:1527873458899};\\\", \\\"{x:614,y:577,t:1527873458934};\\\", \\\"{x:635,y:578,t:1527873459341};\\\", \\\"{x:695,y:589,t:1527873459349};\\\", \\\"{x:846,y:624,t:1527873459366};\\\", \\\"{x:1024,y:657,t:1527873459381};\\\", \\\"{x:1192,y:680,t:1527873459398};\\\", \\\"{x:1339,y:701,t:1527873459416};\\\", \\\"{x:1442,y:717,t:1527873459431};\\\", \\\"{x:1506,y:725,t:1527873459449};\\\", \\\"{x:1531,y:730,t:1527873459465};\\\", \\\"{x:1539,y:732,t:1527873459483};\\\", \\\"{x:1540,y:735,t:1527873459550};\\\", \\\"{x:1538,y:757,t:1527873459566};\\\", \\\"{x:1535,y:783,t:1527873459583};\\\", \\\"{x:1528,y:805,t:1527873459599};\\\", \\\"{x:1518,y:823,t:1527873459616};\\\", \\\"{x:1507,y:835,t:1527873459633};\\\", \\\"{x:1499,y:841,t:1527873459649};\\\", \\\"{x:1494,y:845,t:1527873459666};\\\", \\\"{x:1489,y:849,t:1527873459683};\\\", \\\"{x:1484,y:854,t:1527873459699};\\\", \\\"{x:1482,y:855,t:1527873459716};\\\", \\\"{x:1481,y:856,t:1527873459733};\\\", \\\"{x:1481,y:860,t:1527873459870};\\\", \\\"{x:1481,y:867,t:1527873459884};\\\", \\\"{x:1481,y:876,t:1527873459899};\\\", \\\"{x:1481,y:889,t:1527873459916};\\\", \\\"{x:1479,y:907,t:1527873459934};\\\", \\\"{x:1476,y:915,t:1527873459950};\\\", \\\"{x:1475,y:922,t:1527873459966};\\\", \\\"{x:1474,y:932,t:1527873459983};\\\", \\\"{x:1470,y:947,t:1527873460000};\\\", \\\"{x:1465,y:964,t:1527873460016};\\\", \\\"{x:1460,y:983,t:1527873460034};\\\", \\\"{x:1458,y:994,t:1527873460050};\\\", \\\"{x:1455,y:1004,t:1527873460066};\\\", \\\"{x:1452,y:1011,t:1527873460083};\\\", \\\"{x:1451,y:1012,t:1527873460100};\\\", \\\"{x:1456,y:1004,t:1527873460213};\\\", \\\"{x:1462,y:995,t:1527873460222};\\\", \\\"{x:1469,y:985,t:1527873460233};\\\", \\\"{x:1481,y:967,t:1527873460250};\\\", \\\"{x:1497,y:946,t:1527873460266};\\\", \\\"{x:1508,y:926,t:1527873460283};\\\", \\\"{x:1519,y:907,t:1527873460300};\\\", \\\"{x:1525,y:893,t:1527873460316};\\\", \\\"{x:1530,y:876,t:1527873460332};\\\", \\\"{x:1533,y:870,t:1527873460349};\\\", \\\"{x:1533,y:864,t:1527873460365};\\\", \\\"{x:1533,y:861,t:1527873460382};\\\", \\\"{x:1533,y:859,t:1527873460400};\\\", \\\"{x:1533,y:856,t:1527873460416};\\\", \\\"{x:1533,y:851,t:1527873460432};\\\", \\\"{x:1531,y:843,t:1527873460449};\\\", \\\"{x:1529,y:834,t:1527873460467};\\\", \\\"{x:1525,y:821,t:1527873460482};\\\", \\\"{x:1519,y:804,t:1527873460500};\\\", \\\"{x:1514,y:785,t:1527873460517};\\\", \\\"{x:1513,y:779,t:1527873460533};\\\", \\\"{x:1512,y:775,t:1527873460550};\\\", \\\"{x:1510,y:770,t:1527873460567};\\\", \\\"{x:1508,y:767,t:1527873460583};\\\", \\\"{x:1507,y:766,t:1527873460600};\\\", \\\"{x:1507,y:764,t:1527873460654};\\\", \\\"{x:1507,y:763,t:1527873460668};\\\", \\\"{x:1507,y:760,t:1527873460684};\\\", \\\"{x:1507,y:759,t:1527873460700};\\\", \\\"{x:1507,y:758,t:1527873460717};\\\", \\\"{x:1508,y:758,t:1527873460813};\\\", \\\"{x:1509,y:758,t:1527873460822};\\\", \\\"{x:1510,y:758,t:1527873460833};\\\", \\\"{x:1511,y:758,t:1527873460853};\\\", \\\"{x:1512,y:758,t:1527873460870};\\\", \\\"{x:1513,y:758,t:1527873460883};\\\", \\\"{x:1514,y:759,t:1527873460982};\\\", \\\"{x:1515,y:759,t:1527873461021};\\\", \\\"{x:1516,y:760,t:1527873462334};\\\", \\\"{x:1522,y:763,t:1527873462352};\\\", \\\"{x:1525,y:764,t:1527873462369};\\\", \\\"{x:1526,y:765,t:1527873462384};\\\", \\\"{x:1530,y:766,t:1527873462401};\\\", \\\"{x:1530,y:767,t:1527873462418};\\\", \\\"{x:1532,y:767,t:1527873462434};\\\", \\\"{x:1532,y:768,t:1527873462451};\\\", \\\"{x:1533,y:768,t:1527873462494};\\\", \\\"{x:1533,y:773,t:1527873462516};\\\", \\\"{x:1533,y:774,t:1527873462525};\\\", \\\"{x:1533,y:776,t:1527873462535};\\\", \\\"{x:1533,y:780,t:1527873462551};\\\", \\\"{x:1532,y:784,t:1527873462567};\\\", \\\"{x:1531,y:787,t:1527873462584};\\\", \\\"{x:1529,y:790,t:1527873462600};\\\", \\\"{x:1528,y:790,t:1527873462617};\\\", \\\"{x:1528,y:791,t:1527873462668};\\\", \\\"{x:1527,y:791,t:1527873462685};\\\", \\\"{x:1522,y:791,t:1527873462701};\\\", \\\"{x:1519,y:791,t:1527873462717};\\\", \\\"{x:1517,y:788,t:1527873462735};\\\", \\\"{x:1516,y:785,t:1527873462751};\\\", \\\"{x:1515,y:782,t:1527873462768};\\\", \\\"{x:1515,y:779,t:1527873462784};\\\", \\\"{x:1515,y:777,t:1527873462801};\\\", \\\"{x:1515,y:774,t:1527873462818};\\\", \\\"{x:1515,y:772,t:1527873462835};\\\", \\\"{x:1515,y:771,t:1527873462851};\\\", \\\"{x:1515,y:769,t:1527873462868};\\\", \\\"{x:1515,y:766,t:1527873462886};\\\", \\\"{x:1515,y:764,t:1527873462901};\\\", \\\"{x:1515,y:763,t:1527873462942};\\\", \\\"{x:1515,y:766,t:1527873463118};\\\", \\\"{x:1515,y:775,t:1527873463136};\\\", \\\"{x:1515,y:782,t:1527873463152};\\\", \\\"{x:1515,y:788,t:1527873463168};\\\", \\\"{x:1515,y:792,t:1527873463186};\\\", \\\"{x:1515,y:799,t:1527873463202};\\\", \\\"{x:1515,y:808,t:1527873463218};\\\", \\\"{x:1517,y:819,t:1527873463235};\\\", \\\"{x:1519,y:832,t:1527873463252};\\\", \\\"{x:1520,y:844,t:1527873463269};\\\", \\\"{x:1521,y:858,t:1527873463287};\\\", \\\"{x:1521,y:869,t:1527873463302};\\\", \\\"{x:1521,y:875,t:1527873463317};\\\", \\\"{x:1521,y:882,t:1527873463335};\\\", \\\"{x:1521,y:890,t:1527873463351};\\\", \\\"{x:1521,y:897,t:1527873463367};\\\", \\\"{x:1521,y:902,t:1527873463384};\\\", \\\"{x:1519,y:908,t:1527873463401};\\\", \\\"{x:1517,y:916,t:1527873463418};\\\", \\\"{x:1516,y:922,t:1527873463434};\\\", \\\"{x:1515,y:928,t:1527873463452};\\\", \\\"{x:1514,y:937,t:1527873463467};\\\", \\\"{x:1512,y:946,t:1527873463485};\\\", \\\"{x:1512,y:950,t:1527873463501};\\\", \\\"{x:1512,y:955,t:1527873463518};\\\", \\\"{x:1511,y:962,t:1527873463535};\\\", \\\"{x:1511,y:970,t:1527873463552};\\\", \\\"{x:1510,y:979,t:1527873463568};\\\", \\\"{x:1510,y:986,t:1527873463585};\\\", \\\"{x:1510,y:989,t:1527873463601};\\\", \\\"{x:1510,y:992,t:1527873463619};\\\", \\\"{x:1510,y:994,t:1527873463635};\\\", \\\"{x:1510,y:997,t:1527873463652};\\\", \\\"{x:1510,y:993,t:1527873463854};\\\", \\\"{x:1510,y:988,t:1527873463869};\\\", \\\"{x:1510,y:984,t:1527873463887};\\\", \\\"{x:1510,y:981,t:1527873463902};\\\", \\\"{x:1510,y:980,t:1527873463919};\\\", \\\"{x:1510,y:979,t:1527873463935};\\\", \\\"{x:1512,y:975,t:1527873464622};\\\", \\\"{x:1514,y:974,t:1527873464636};\\\", \\\"{x:1517,y:969,t:1527873464653};\\\", \\\"{x:1519,y:966,t:1527873464669};\\\", \\\"{x:1522,y:965,t:1527873464686};\\\", \\\"{x:1523,y:965,t:1527873464764};\\\", \\\"{x:1527,y:965,t:1527873465350};\\\", \\\"{x:1530,y:965,t:1527873465358};\\\", \\\"{x:1534,y:965,t:1527873465370};\\\", \\\"{x:1539,y:965,t:1527873465386};\\\", \\\"{x:1545,y:965,t:1527873465403};\\\", \\\"{x:1550,y:964,t:1527873465420};\\\", \\\"{x:1556,y:964,t:1527873465436};\\\", \\\"{x:1563,y:963,t:1527873465453};\\\", \\\"{x:1564,y:963,t:1527873465478};\\\", \\\"{x:1566,y:963,t:1527873465661};\\\", \\\"{x:1567,y:963,t:1527873465677};\\\", \\\"{x:1568,y:963,t:1527873465758};\\\", \\\"{x:1570,y:963,t:1527873465782};\\\", \\\"{x:1571,y:963,t:1527873465830};\\\", \\\"{x:1572,y:963,t:1527873465837};\\\", \\\"{x:1573,y:963,t:1527873465854};\\\", \\\"{x:1574,y:963,t:1527873465886};\\\", \\\"{x:1575,y:963,t:1527873465904};\\\", \\\"{x:1576,y:963,t:1527873465920};\\\", \\\"{x:1578,y:963,t:1527873465937};\\\", \\\"{x:1579,y:963,t:1527873465953};\\\", \\\"{x:1580,y:964,t:1527873465973};\\\", \\\"{x:1581,y:964,t:1527873466030};\\\", \\\"{x:1582,y:964,t:1527873466397};\\\", \\\"{x:1584,y:964,t:1527873466413};\\\", \\\"{x:1585,y:964,t:1527873466421};\\\", \\\"{x:1586,y:964,t:1527873466437};\\\", \\\"{x:1589,y:964,t:1527873466453};\\\", \\\"{x:1590,y:964,t:1527873466478};\\\", \\\"{x:1591,y:964,t:1527873466493};\\\", \\\"{x:1592,y:964,t:1527873466509};\\\", \\\"{x:1593,y:964,t:1527873466566};\\\", \\\"{x:1595,y:964,t:1527873466813};\\\", \\\"{x:1598,y:964,t:1527873466821};\\\", \\\"{x:1601,y:964,t:1527873466836};\\\", \\\"{x:1605,y:964,t:1527873466854};\\\", \\\"{x:1610,y:964,t:1527873466871};\\\", \\\"{x:1611,y:964,t:1527873466886};\\\", \\\"{x:1612,y:964,t:1527873466904};\\\", \\\"{x:1613,y:964,t:1527873466921};\\\", \\\"{x:1614,y:964,t:1527873466941};\\\", \\\"{x:1615,y:964,t:1527873466973};\\\", \\\"{x:1616,y:964,t:1527873466990};\\\", \\\"{x:1617,y:964,t:1527873467021};\\\", \\\"{x:1618,y:964,t:1527873467037};\\\", \\\"{x:1619,y:964,t:1527873467054};\\\", \\\"{x:1621,y:964,t:1527873467071};\\\", \\\"{x:1624,y:964,t:1527873467088};\\\", \\\"{x:1627,y:965,t:1527873467104};\\\", \\\"{x:1631,y:965,t:1527873467122};\\\", \\\"{x:1633,y:967,t:1527873467138};\\\", \\\"{x:1635,y:967,t:1527873467154};\\\", \\\"{x:1637,y:967,t:1527873467172};\\\", \\\"{x:1638,y:967,t:1527873467187};\\\", \\\"{x:1639,y:967,t:1527873467205};\\\", \\\"{x:1641,y:967,t:1527873467222};\\\", \\\"{x:1642,y:967,t:1527873467246};\\\", \\\"{x:1643,y:967,t:1527873467262};\\\", \\\"{x:1645,y:968,t:1527873467287};\\\", \\\"{x:1647,y:968,t:1527873467517};\\\", \\\"{x:1648,y:968,t:1527873467525};\\\", \\\"{x:1650,y:968,t:1527873467542};\\\", \\\"{x:1651,y:968,t:1527873467554};\\\", \\\"{x:1652,y:968,t:1527873467571};\\\", \\\"{x:1653,y:968,t:1527873467588};\\\", \\\"{x:1654,y:968,t:1527873467605};\\\", \\\"{x:1655,y:968,t:1527873468206};\\\", \\\"{x:1654,y:968,t:1527873468838};\\\", \\\"{x:1653,y:968,t:1527873468869};\\\", \\\"{x:1652,y:968,t:1527873468893};\\\", \\\"{x:1651,y:969,t:1527873468906};\\\", \\\"{x:1651,y:970,t:1527873468941};\\\", \\\"{x:1650,y:970,t:1527873468973};\\\", \\\"{x:1649,y:970,t:1527873468989};\\\", \\\"{x:1648,y:970,t:1527873469006};\\\", \\\"{x:1647,y:970,t:1527873469022};\\\", \\\"{x:1645,y:971,t:1527873469039};\\\", \\\"{x:1644,y:971,t:1527873469061};\\\", \\\"{x:1643,y:971,t:1527873469086};\\\", \\\"{x:1642,y:971,t:1527873469093};\\\", \\\"{x:1641,y:971,t:1527873469157};\\\", \\\"{x:1639,y:972,t:1527873469172};\\\", \\\"{x:1638,y:973,t:1527873469189};\\\", \\\"{x:1635,y:973,t:1527873469205};\\\", \\\"{x:1633,y:974,t:1527873469222};\\\", \\\"{x:1630,y:974,t:1527873469238};\\\", \\\"{x:1629,y:974,t:1527873469260};\\\", \\\"{x:1628,y:974,t:1527873469317};\\\", \\\"{x:1627,y:974,t:1527873469366};\\\", \\\"{x:1626,y:974,t:1527873469574};\\\", \\\"{x:1624,y:974,t:1527873469589};\\\", \\\"{x:1623,y:974,t:1527873469606};\\\", \\\"{x:1621,y:973,t:1527873469622};\\\", \\\"{x:1620,y:972,t:1527873469639};\\\", \\\"{x:1619,y:972,t:1527873469661};\\\", \\\"{x:1618,y:972,t:1527873469677};\\\", \\\"{x:1619,y:972,t:1527873470357};\\\", \\\"{x:1621,y:972,t:1527873470373};\\\", \\\"{x:1623,y:972,t:1527873470390};\\\", \\\"{x:1624,y:972,t:1527873470406};\\\", \\\"{x:1625,y:972,t:1527873470423};\\\", \\\"{x:1627,y:972,t:1527873470441};\\\", \\\"{x:1629,y:972,t:1527873470461};\\\", \\\"{x:1630,y:972,t:1527873470473};\\\", \\\"{x:1632,y:972,t:1527873470490};\\\", \\\"{x:1633,y:970,t:1527873470507};\\\", \\\"{x:1634,y:970,t:1527873470525};\\\", \\\"{x:1636,y:970,t:1527873471262};\\\", \\\"{x:1637,y:970,t:1527873471273};\\\", \\\"{x:1641,y:970,t:1527873471290};\\\", \\\"{x:1647,y:973,t:1527873471308};\\\", \\\"{x:1652,y:973,t:1527873471323};\\\", \\\"{x:1655,y:974,t:1527873471341};\\\", \\\"{x:1658,y:974,t:1527873471357};\\\", \\\"{x:1657,y:974,t:1527873471687};\\\", \\\"{x:1656,y:974,t:1527873471845};\\\", \\\"{x:1655,y:974,t:1527873471918};\\\", \\\"{x:1654,y:974,t:1527873471924};\\\", \\\"{x:1653,y:974,t:1527873471941};\\\", \\\"{x:1651,y:973,t:1527873471965};\\\", \\\"{x:1650,y:973,t:1527873472261};\\\", \\\"{x:1649,y:973,t:1527873473125};\\\", \\\"{x:1637,y:963,t:1527873473142};\\\", \\\"{x:1622,y:956,t:1527873473158};\\\", \\\"{x:1616,y:946,t:1527873473175};\\\", \\\"{x:1604,y:933,t:1527873473191};\\\", \\\"{x:1590,y:921,t:1527873473209};\\\", \\\"{x:1579,y:913,t:1527873473225};\\\", \\\"{x:1568,y:906,t:1527873473241};\\\", \\\"{x:1555,y:898,t:1527873473258};\\\", \\\"{x:1537,y:890,t:1527873473275};\\\", \\\"{x:1521,y:884,t:1527873473291};\\\", \\\"{x:1499,y:880,t:1527873473308};\\\", \\\"{x:1465,y:876,t:1527873473324};\\\", \\\"{x:1447,y:876,t:1527873473341};\\\", \\\"{x:1435,y:876,t:1527873473357};\\\", \\\"{x:1426,y:876,t:1527873473375};\\\", \\\"{x:1416,y:876,t:1527873473392};\\\", \\\"{x:1407,y:876,t:1527873473407};\\\", \\\"{x:1397,y:876,t:1527873473424};\\\", \\\"{x:1384,y:876,t:1527873473442};\\\", \\\"{x:1376,y:874,t:1527873473458};\\\", \\\"{x:1370,y:873,t:1527873473475};\\\", \\\"{x:1362,y:870,t:1527873473492};\\\", \\\"{x:1357,y:867,t:1527873473508};\\\", \\\"{x:1349,y:859,t:1527873473524};\\\", \\\"{x:1339,y:844,t:1527873473543};\\\", \\\"{x:1334,y:833,t:1527873473558};\\\", \\\"{x:1331,y:825,t:1527873473575};\\\", \\\"{x:1329,y:815,t:1527873473592};\\\", \\\"{x:1328,y:804,t:1527873473608};\\\", \\\"{x:1328,y:794,t:1527873473625};\\\", \\\"{x:1328,y:784,t:1527873473642};\\\", \\\"{x:1328,y:780,t:1527873473659};\\\", \\\"{x:1328,y:774,t:1527873473676};\\\", \\\"{x:1328,y:772,t:1527873473692};\\\", \\\"{x:1328,y:769,t:1527873473709};\\\", \\\"{x:1328,y:767,t:1527873473726};\\\", \\\"{x:1329,y:763,t:1527873473742};\\\", \\\"{x:1330,y:761,t:1527873473759};\\\", \\\"{x:1331,y:757,t:1527873473775};\\\", \\\"{x:1333,y:756,t:1527873473793};\\\", \\\"{x:1334,y:752,t:1527873473809};\\\", \\\"{x:1337,y:747,t:1527873473825};\\\", \\\"{x:1337,y:745,t:1527873473843};\\\", \\\"{x:1338,y:742,t:1527873473859};\\\", \\\"{x:1338,y:739,t:1527873473876};\\\", \\\"{x:1340,y:735,t:1527873473893};\\\", \\\"{x:1341,y:729,t:1527873473909};\\\", \\\"{x:1341,y:727,t:1527873473926};\\\", \\\"{x:1341,y:725,t:1527873473943};\\\", \\\"{x:1341,y:722,t:1527873473959};\\\", \\\"{x:1341,y:718,t:1527873473975};\\\", \\\"{x:1341,y:715,t:1527873473992};\\\", \\\"{x:1341,y:712,t:1527873474010};\\\", \\\"{x:1341,y:710,t:1527873474026};\\\", \\\"{x:1342,y:708,t:1527873474043};\\\", \\\"{x:1344,y:702,t:1527873474288};\\\", \\\"{x:1345,y:699,t:1527873474294};\\\", \\\"{x:1346,y:693,t:1527873474309};\\\", \\\"{x:1348,y:689,t:1527873474326};\\\", \\\"{x:1349,y:685,t:1527873474342};\\\", \\\"{x:1350,y:683,t:1527873474360};\\\", \\\"{x:1350,y:681,t:1527873474662};\\\", \\\"{x:1349,y:681,t:1527873474676};\\\", \\\"{x:1345,y:679,t:1527873474692};\\\", \\\"{x:1343,y:678,t:1527873474709};\\\", \\\"{x:1343,y:680,t:1527873475119};\\\", \\\"{x:1343,y:685,t:1527873475137};\\\", \\\"{x:1345,y:689,t:1527873475153};\\\", \\\"{x:1346,y:691,t:1527873475170};\\\", \\\"{x:1347,y:691,t:1527873475191};\\\", \\\"{x:1347,y:692,t:1527873475204};\\\", \\\"{x:1347,y:693,t:1527873475783};\\\", \\\"{x:1348,y:693,t:1527873477800};\\\", \\\"{x:1348,y:694,t:1527873477807};\\\", \\\"{x:1349,y:694,t:1527873477822};\\\", \\\"{x:1350,y:695,t:1527873477838};\\\", \\\"{x:1350,y:696,t:1527873477855};\\\", \\\"{x:1351,y:696,t:1527873477887};\\\", \\\"{x:1354,y:696,t:1527873480272};\\\", \\\"{x:1358,y:697,t:1527873480290};\\\", \\\"{x:1359,y:698,t:1527873480307};\\\", \\\"{x:1362,y:699,t:1527873480324};\\\", \\\"{x:1365,y:699,t:1527873480340};\\\", \\\"{x:1365,y:700,t:1527873480356};\\\", \\\"{x:1367,y:700,t:1527873480374};\\\", \\\"{x:1369,y:701,t:1527873480391};\\\", \\\"{x:1370,y:701,t:1527873480439};\\\", \\\"{x:1371,y:702,t:1527873480456};\\\", \\\"{x:1372,y:702,t:1527873480479};\\\", \\\"{x:1373,y:702,t:1527873480490};\\\", \\\"{x:1376,y:702,t:1527873480507};\\\", \\\"{x:1378,y:702,t:1527873480523};\\\", \\\"{x:1379,y:702,t:1527873480543};\\\", \\\"{x:1382,y:702,t:1527873480557};\\\", \\\"{x:1383,y:701,t:1527873480575};\\\", \\\"{x:1385,y:706,t:1527873480847};\\\", \\\"{x:1386,y:713,t:1527873480857};\\\", \\\"{x:1386,y:729,t:1527873480873};\\\", \\\"{x:1386,y:748,t:1527873480891};\\\", \\\"{x:1387,y:769,t:1527873480907};\\\", \\\"{x:1387,y:787,t:1527873480924};\\\", \\\"{x:1387,y:800,t:1527873480940};\\\", \\\"{x:1389,y:809,t:1527873480956};\\\", \\\"{x:1391,y:818,t:1527873480973};\\\", \\\"{x:1394,y:834,t:1527873480991};\\\", \\\"{x:1395,y:846,t:1527873481006};\\\", \\\"{x:1397,y:860,t:1527873481024};\\\", \\\"{x:1402,y:878,t:1527873481040};\\\", \\\"{x:1407,y:887,t:1527873481056};\\\", \\\"{x:1409,y:892,t:1527873481074};\\\", \\\"{x:1410,y:895,t:1527873481091};\\\", \\\"{x:1412,y:899,t:1527873481107};\\\", \\\"{x:1413,y:905,t:1527873481124};\\\", \\\"{x:1414,y:911,t:1527873481141};\\\", \\\"{x:1417,y:917,t:1527873481158};\\\", \\\"{x:1417,y:922,t:1527873481174};\\\", \\\"{x:1417,y:924,t:1527873481191};\\\", \\\"{x:1418,y:926,t:1527873481207};\\\", \\\"{x:1415,y:919,t:1527873481303};\\\", \\\"{x:1410,y:908,t:1527873481311};\\\", \\\"{x:1408,y:897,t:1527873481324};\\\", \\\"{x:1402,y:870,t:1527873481341};\\\", \\\"{x:1398,y:846,t:1527873481358};\\\", \\\"{x:1395,y:825,t:1527873481373};\\\", \\\"{x:1392,y:804,t:1527873481391};\\\", \\\"{x:1388,y:791,t:1527873481407};\\\", \\\"{x:1387,y:782,t:1527873481423};\\\", \\\"{x:1384,y:772,t:1527873481441};\\\", \\\"{x:1383,y:766,t:1527873481457};\\\", \\\"{x:1383,y:764,t:1527873481474};\\\", \\\"{x:1383,y:763,t:1527873481491};\\\", \\\"{x:1383,y:764,t:1527873481559};\\\", \\\"{x:1383,y:773,t:1527873481573};\\\", \\\"{x:1367,y:817,t:1527873481591};\\\", \\\"{x:1361,y:839,t:1527873481607};\\\", \\\"{x:1356,y:859,t:1527873481624};\\\", \\\"{x:1351,y:872,t:1527873481641};\\\", \\\"{x:1349,y:885,t:1527873481658};\\\", \\\"{x:1347,y:902,t:1527873481674};\\\", \\\"{x:1345,y:918,t:1527873481691};\\\", \\\"{x:1345,y:939,t:1527873481708};\\\", \\\"{x:1345,y:958,t:1527873481724};\\\", \\\"{x:1345,y:973,t:1527873481740};\\\", \\\"{x:1345,y:984,t:1527873481757};\\\", \\\"{x:1345,y:997,t:1527873481774};\\\", \\\"{x:1345,y:1001,t:1527873481790};\\\", \\\"{x:1345,y:1007,t:1527873481807};\\\", \\\"{x:1345,y:1013,t:1527873481824};\\\", \\\"{x:1345,y:1020,t:1527873481840};\\\", \\\"{x:1345,y:1023,t:1527873481857};\\\", \\\"{x:1345,y:1024,t:1527873481874};\\\", \\\"{x:1345,y:1018,t:1527873481975};\\\", \\\"{x:1345,y:999,t:1527873481991};\\\", \\\"{x:1345,y:981,t:1527873482008};\\\", \\\"{x:1345,y:969,t:1527873482024};\\\", \\\"{x:1345,y:967,t:1527873482041};\\\", \\\"{x:1345,y:965,t:1527873482057};\\\", \\\"{x:1345,y:964,t:1527873482368};\\\", \\\"{x:1346,y:964,t:1527873482382};\\\", \\\"{x:1349,y:964,t:1527873482391};\\\", \\\"{x:1353,y:965,t:1527873482407};\\\", \\\"{x:1359,y:966,t:1527873482424};\\\", \\\"{x:1363,y:967,t:1527873482441};\\\", \\\"{x:1366,y:968,t:1527873482457};\\\", \\\"{x:1370,y:970,t:1527873482474};\\\", \\\"{x:1374,y:970,t:1527873482491};\\\", \\\"{x:1376,y:970,t:1527873482507};\\\", \\\"{x:1377,y:970,t:1527873482524};\\\", \\\"{x:1379,y:971,t:1527873482541};\\\", \\\"{x:1379,y:972,t:1527873482557};\\\", \\\"{x:1381,y:972,t:1527873482679};\\\", \\\"{x:1382,y:972,t:1527873482691};\\\", \\\"{x:1385,y:973,t:1527873482708};\\\", \\\"{x:1387,y:973,t:1527873482725};\\\", \\\"{x:1391,y:973,t:1527873482742};\\\", \\\"{x:1394,y:973,t:1527873482759};\\\", \\\"{x:1398,y:975,t:1527873482775};\\\", \\\"{x:1404,y:976,t:1527873482791};\\\", \\\"{x:1405,y:976,t:1527873482809};\\\", \\\"{x:1407,y:976,t:1527873482824};\\\", \\\"{x:1408,y:976,t:1527873482935};\\\", \\\"{x:1409,y:978,t:1527873483392};\\\", \\\"{x:1419,y:979,t:1527873483409};\\\", \\\"{x:1426,y:979,t:1527873483425};\\\", \\\"{x:1431,y:979,t:1527873483441};\\\", \\\"{x:1432,y:979,t:1527873483459};\\\", \\\"{x:1434,y:979,t:1527873483476};\\\", \\\"{x:1435,y:979,t:1527873483492};\\\", \\\"{x:1437,y:979,t:1527873483508};\\\", \\\"{x:1438,y:979,t:1527873483535};\\\", \\\"{x:1439,y:978,t:1527873483542};\\\", \\\"{x:1442,y:978,t:1527873483559};\\\", \\\"{x:1445,y:977,t:1527873483575};\\\", \\\"{x:1449,y:976,t:1527873483592};\\\", \\\"{x:1452,y:975,t:1527873483609};\\\", \\\"{x:1454,y:974,t:1527873483626};\\\", \\\"{x:1455,y:974,t:1527873483642};\\\", \\\"{x:1456,y:974,t:1527873483671};\\\", \\\"{x:1457,y:974,t:1527873483687};\\\", \\\"{x:1458,y:973,t:1527873483696};\\\", \\\"{x:1459,y:973,t:1527873483719};\\\", \\\"{x:1460,y:972,t:1527873483726};\\\", \\\"{x:1461,y:972,t:1527873483750};\\\", \\\"{x:1462,y:972,t:1527873483783};\\\", \\\"{x:1463,y:972,t:1527873483793};\\\", \\\"{x:1464,y:972,t:1527873483809};\\\", \\\"{x:1465,y:972,t:1527873483826};\\\", \\\"{x:1468,y:972,t:1527873484959};\\\", \\\"{x:1474,y:972,t:1527873484976};\\\", \\\"{x:1476,y:973,t:1527873484993};\\\", \\\"{x:1479,y:973,t:1527873485010};\\\", \\\"{x:1483,y:976,t:1527873485027};\\\", \\\"{x:1484,y:976,t:1527873485043};\\\", \\\"{x:1485,y:976,t:1527873485060};\\\", \\\"{x:1486,y:976,t:1527873485096};\\\", \\\"{x:1487,y:976,t:1527873485119};\\\", \\\"{x:1488,y:977,t:1527873485127};\\\", \\\"{x:1490,y:977,t:1527873485142};\\\", \\\"{x:1492,y:977,t:1527873485160};\\\", \\\"{x:1496,y:977,t:1527873485177};\\\", \\\"{x:1499,y:977,t:1527873485193};\\\", \\\"{x:1502,y:977,t:1527873485210};\\\", \\\"{x:1503,y:977,t:1527873485227};\\\", \\\"{x:1508,y:977,t:1527873485243};\\\", \\\"{x:1511,y:977,t:1527873485260};\\\", \\\"{x:1514,y:977,t:1527873485277};\\\", \\\"{x:1522,y:977,t:1527873485295};\\\", \\\"{x:1527,y:977,t:1527873485310};\\\", \\\"{x:1554,y:977,t:1527873485327};\\\", \\\"{x:1569,y:977,t:1527873485343};\\\", \\\"{x:1578,y:977,t:1527873485359};\\\", \\\"{x:1582,y:976,t:1527873485377};\\\", \\\"{x:1586,y:976,t:1527873485394};\\\", \\\"{x:1585,y:976,t:1527873485623};\\\", \\\"{x:1584,y:976,t:1527873485647};\\\", \\\"{x:1586,y:976,t:1527873485919};\\\", \\\"{x:1589,y:976,t:1527873485926};\\\", \\\"{x:1597,y:976,t:1527873485944};\\\", \\\"{x:1605,y:976,t:1527873485961};\\\", \\\"{x:1612,y:976,t:1527873485977};\\\", \\\"{x:1619,y:976,t:1527873485993};\\\", \\\"{x:1621,y:976,t:1527873486011};\\\", \\\"{x:1622,y:976,t:1527873486026};\\\", \\\"{x:1624,y:976,t:1527873486046};\\\", \\\"{x:1625,y:976,t:1527873486127};\\\", \\\"{x:1627,y:976,t:1527873486151};\\\", \\\"{x:1627,y:977,t:1527873486903};\\\", \\\"{x:1626,y:977,t:1527873486934};\\\", \\\"{x:1625,y:977,t:1527873487047};\\\", \\\"{x:1624,y:978,t:1527873487062};\\\", \\\"{x:1623,y:978,t:1527873487079};\\\", \\\"{x:1621,y:979,t:1527873487096};\\\", \\\"{x:1620,y:979,t:1527873487118};\\\", \\\"{x:1619,y:979,t:1527873487142};\\\", \\\"{x:1618,y:979,t:1527873487215};\\\", \\\"{x:1617,y:979,t:1527873487255};\\\", \\\"{x:1616,y:980,t:1527873487271};\\\", \\\"{x:1614,y:980,t:1527873487311};\\\", \\\"{x:1613,y:981,t:1527873487328};\\\", \\\"{x:1611,y:982,t:1527873487345};\\\", \\\"{x:1609,y:982,t:1527873487362};\\\", \\\"{x:1602,y:983,t:1527873487378};\\\", \\\"{x:1593,y:983,t:1527873487394};\\\", \\\"{x:1584,y:983,t:1527873487411};\\\", \\\"{x:1577,y:983,t:1527873487427};\\\", \\\"{x:1570,y:983,t:1527873487444};\\\", \\\"{x:1564,y:982,t:1527873487461};\\\", \\\"{x:1562,y:982,t:1527873487477};\\\", \\\"{x:1561,y:982,t:1527873487566};\\\", \\\"{x:1560,y:982,t:1527873487578};\\\", \\\"{x:1559,y:981,t:1527873487594};\\\", \\\"{x:1557,y:981,t:1527873487611};\\\", \\\"{x:1554,y:980,t:1527873487627};\\\", \\\"{x:1550,y:980,t:1527873487645};\\\", \\\"{x:1545,y:977,t:1527873487661};\\\", \\\"{x:1540,y:977,t:1527873487677};\\\", \\\"{x:1538,y:976,t:1527873487696};\\\", \\\"{x:1536,y:976,t:1527873487712};\\\", \\\"{x:1535,y:975,t:1527873487727};\\\", \\\"{x:1534,y:975,t:1527873487935};\\\", \\\"{x:1532,y:975,t:1527873487951};\\\", \\\"{x:1530,y:975,t:1527873487967};\\\", \\\"{x:1528,y:975,t:1527873487979};\\\", \\\"{x:1526,y:976,t:1527873487995};\\\", \\\"{x:1524,y:976,t:1527873488012};\\\", \\\"{x:1523,y:976,t:1527873488029};\\\", \\\"{x:1521,y:976,t:1527873488044};\\\", \\\"{x:1519,y:977,t:1527873488063};\\\", \\\"{x:1518,y:977,t:1527873488079};\\\", \\\"{x:1517,y:977,t:1527873488097};\\\", \\\"{x:1514,y:978,t:1527873488112};\\\", \\\"{x:1510,y:978,t:1527873488129};\\\", \\\"{x:1506,y:978,t:1527873488145};\\\", \\\"{x:1501,y:978,t:1527873488163};\\\", \\\"{x:1497,y:978,t:1527873488179};\\\", \\\"{x:1496,y:978,t:1527873488194};\\\", \\\"{x:1492,y:978,t:1527873488212};\\\", \\\"{x:1490,y:978,t:1527873488228};\\\", \\\"{x:1489,y:978,t:1527873488244};\\\", \\\"{x:1487,y:978,t:1527873488262};\\\", \\\"{x:1484,y:978,t:1527873488279};\\\", \\\"{x:1483,y:978,t:1527873488298};\\\", \\\"{x:1482,y:978,t:1527873488318};\\\", \\\"{x:1481,y:978,t:1527873488334};\\\", \\\"{x:1478,y:978,t:1527873488751};\\\", \\\"{x:1477,y:978,t:1527873488762};\\\", \\\"{x:1475,y:978,t:1527873488779};\\\", \\\"{x:1472,y:977,t:1527873488795};\\\", \\\"{x:1471,y:976,t:1527873488812};\\\", \\\"{x:1468,y:976,t:1527873488829};\\\", \\\"{x:1465,y:975,t:1527873488846};\\\", \\\"{x:1460,y:975,t:1527873488863};\\\", \\\"{x:1457,y:974,t:1527873488879};\\\", \\\"{x:1453,y:974,t:1527873488896};\\\", \\\"{x:1450,y:973,t:1527873488913};\\\", \\\"{x:1448,y:973,t:1527873488928};\\\", \\\"{x:1444,y:973,t:1527873488946};\\\", \\\"{x:1439,y:971,t:1527873488963};\\\", \\\"{x:1435,y:971,t:1527873488979};\\\", \\\"{x:1430,y:970,t:1527873488995};\\\", \\\"{x:1425,y:969,t:1527873489013};\\\", \\\"{x:1423,y:969,t:1527873489029};\\\", \\\"{x:1418,y:969,t:1527873489046};\\\", \\\"{x:1414,y:969,t:1527873489062};\\\", \\\"{x:1412,y:967,t:1527873489079};\\\", \\\"{x:1411,y:967,t:1527873489175};\\\", \\\"{x:1409,y:967,t:1527873489183};\\\", \\\"{x:1407,y:967,t:1527873489199};\\\", \\\"{x:1405,y:967,t:1527873489213};\\\", \\\"{x:1403,y:967,t:1527873489229};\\\", \\\"{x:1401,y:967,t:1527873489246};\\\", \\\"{x:1399,y:967,t:1527873489328};\\\", \\\"{x:1398,y:967,t:1527873489359};\\\", \\\"{x:1396,y:967,t:1527873489383};\\\", \\\"{x:1395,y:967,t:1527873489398};\\\", \\\"{x:1393,y:967,t:1527873489415};\\\", \\\"{x:1392,y:967,t:1527873489430};\\\", \\\"{x:1390,y:967,t:1527873489447};\\\", \\\"{x:1389,y:967,t:1527873489462};\\\", \\\"{x:1387,y:967,t:1527873489479};\\\", \\\"{x:1383,y:967,t:1527873489496};\\\", \\\"{x:1378,y:967,t:1527873489513};\\\", \\\"{x:1375,y:967,t:1527873489530};\\\", \\\"{x:1372,y:967,t:1527873489546};\\\", \\\"{x:1370,y:967,t:1527873489563};\\\", \\\"{x:1369,y:967,t:1527873489580};\\\", \\\"{x:1366,y:967,t:1527873489596};\\\", \\\"{x:1365,y:967,t:1527873489613};\\\", \\\"{x:1363,y:966,t:1527873489630};\\\", \\\"{x:1362,y:966,t:1527873489647};\\\", \\\"{x:1360,y:966,t:1527873489663};\\\", \\\"{x:1359,y:965,t:1527873489687};\\\", \\\"{x:1358,y:965,t:1527873489702};\\\", \\\"{x:1357,y:965,t:1527873489726};\\\", \\\"{x:1337,y:965,t:1527873491279};\\\", \\\"{x:1295,y:965,t:1527873491287};\\\", \\\"{x:1237,y:965,t:1527873491297};\\\", \\\"{x:1117,y:959,t:1527873491314};\\\", \\\"{x:1006,y:945,t:1527873491331};\\\", \\\"{x:904,y:917,t:1527873491347};\\\", \\\"{x:831,y:893,t:1527873491364};\\\", \\\"{x:764,y:872,t:1527873491381};\\\", \\\"{x:693,y:849,t:1527873491397};\\\", \\\"{x:626,y:826,t:1527873491414};\\\", \\\"{x:503,y:788,t:1527873491431};\\\", \\\"{x:450,y:772,t:1527873491448};\\\", \\\"{x:423,y:761,t:1527873491464};\\\", \\\"{x:397,y:751,t:1527873491481};\\\", \\\"{x:362,y:731,t:1527873491498};\\\", \\\"{x:332,y:718,t:1527873491514};\\\", \\\"{x:310,y:709,t:1527873491531};\\\", \\\"{x:299,y:699,t:1527873491548};\\\", \\\"{x:287,y:660,t:1527873491565};\\\", \\\"{x:263,y:592,t:1527873491581};\\\", \\\"{x:244,y:538,t:1527873491597};\\\", \\\"{x:244,y:535,t:1527873491610};\\\", \\\"{x:245,y:534,t:1527873491734};\\\", \\\"{x:247,y:531,t:1527873491743};\\\", \\\"{x:249,y:531,t:1527873491761};\\\", \\\"{x:250,y:531,t:1527873491798};\\\", \\\"{x:251,y:531,t:1527873491810};\\\", \\\"{x:252,y:531,t:1527873491847};\\\", \\\"{x:254,y:531,t:1527873491860};\\\", \\\"{x:261,y:531,t:1527873491877};\\\", \\\"{x:293,y:553,t:1527873491895};\\\", \\\"{x:324,y:568,t:1527873491911};\\\", \\\"{x:386,y:587,t:1527873491933};\\\", \\\"{x:425,y:591,t:1527873491950};\\\", \\\"{x:452,y:591,t:1527873491967};\\\", \\\"{x:468,y:591,t:1527873491984};\\\", \\\"{x:477,y:591,t:1527873492002};\\\", \\\"{x:478,y:591,t:1527873492017};\\\", \\\"{x:479,y:591,t:1527873492053};\\\", \\\"{x:481,y:590,t:1527873492067};\\\", \\\"{x:491,y:581,t:1527873492085};\\\", \\\"{x:503,y:571,t:1527873492101};\\\", \\\"{x:513,y:566,t:1527873492117};\\\", \\\"{x:528,y:554,t:1527873492134};\\\", \\\"{x:533,y:550,t:1527873492152};\\\", \\\"{x:537,y:548,t:1527873492169};\\\", \\\"{x:541,y:543,t:1527873492184};\\\", \\\"{x:545,y:541,t:1527873492202};\\\", \\\"{x:549,y:535,t:1527873492218};\\\", \\\"{x:554,y:530,t:1527873492234};\\\", \\\"{x:561,y:522,t:1527873492252};\\\", \\\"{x:566,y:516,t:1527873492269};\\\", \\\"{x:571,y:511,t:1527873492284};\\\", \\\"{x:573,y:508,t:1527873492302};\\\", \\\"{x:577,y:502,t:1527873492318};\\\", \\\"{x:581,y:496,t:1527873492334};\\\", \\\"{x:588,y:489,t:1527873492352};\\\", \\\"{x:601,y:482,t:1527873492369};\\\", \\\"{x:617,y:475,t:1527873492385};\\\", \\\"{x:631,y:470,t:1527873492401};\\\", \\\"{x:640,y:467,t:1527873492419};\\\", \\\"{x:652,y:466,t:1527873492434};\\\", \\\"{x:672,y:465,t:1527873492452};\\\", \\\"{x:697,y:465,t:1527873492468};\\\", \\\"{x:723,y:465,t:1527873492484};\\\", \\\"{x:759,y:469,t:1527873492502};\\\", \\\"{x:784,y:475,t:1527873492518};\\\", \\\"{x:806,y:481,t:1527873492535};\\\", \\\"{x:821,y:486,t:1527873492551};\\\", \\\"{x:829,y:487,t:1527873492570};\\\", \\\"{x:832,y:489,t:1527873492586};\\\", \\\"{x:833,y:489,t:1527873492601};\\\", \\\"{x:836,y:491,t:1527873492619};\\\", \\\"{x:840,y:495,t:1527873492636};\\\", \\\"{x:846,y:500,t:1527873492651};\\\", \\\"{x:852,y:503,t:1527873492669};\\\", \\\"{x:854,y:504,t:1527873492686};\\\", \\\"{x:853,y:504,t:1527873492799};\\\", \\\"{x:850,y:503,t:1527873492806};\\\", \\\"{x:849,y:503,t:1527873492819};\\\", \\\"{x:846,y:501,t:1527873492836};\\\", \\\"{x:842,y:500,t:1527873492853};\\\", \\\"{x:840,y:499,t:1527873492869};\\\", \\\"{x:839,y:499,t:1527873493558};\\\", \\\"{x:822,y:511,t:1527873493570};\\\", \\\"{x:792,y:534,t:1527873493586};\\\", \\\"{x:757,y:556,t:1527873493602};\\\", \\\"{x:730,y:570,t:1527873493620};\\\", \\\"{x:708,y:583,t:1527873493635};\\\", \\\"{x:689,y:597,t:1527873493653};\\\", \\\"{x:665,y:617,t:1527873493670};\\\", \\\"{x:655,y:624,t:1527873493685};\\\", \\\"{x:625,y:641,t:1527873493703};\\\", \\\"{x:613,y:648,t:1527873493719};\\\", \\\"{x:606,y:652,t:1527873493736};\\\", \\\"{x:601,y:655,t:1527873493752};\\\", \\\"{x:593,y:662,t:1527873493770};\\\", \\\"{x:581,y:669,t:1527873493787};\\\", \\\"{x:567,y:680,t:1527873493802};\\\", \\\"{x:555,y:687,t:1527873493820};\\\", \\\"{x:546,y:691,t:1527873493836};\\\", \\\"{x:540,y:697,t:1527873493852};\\\", \\\"{x:531,y:707,t:1527873493870};\\\", \\\"{x:522,y:718,t:1527873493885};\\\", \\\"{x:516,y:726,t:1527873493903};\\\", \\\"{x:513,y:734,t:1527873493919};\\\", \\\"{x:511,y:740,t:1527873493936};\\\", \\\"{x:510,y:742,t:1527873493953};\\\", \\\"{x:510,y:743,t:1527873493970};\\\", \\\"{x:510,y:744,t:1527873493987};\\\", \\\"{x:510,y:745,t:1527873494003};\\\", \\\"{x:510,y:747,t:1527873494020};\\\", \\\"{x:511,y:748,t:1527873494038};\\\", \\\"{x:511,y:747,t:1527873494567};\\\", \\\"{x:510,y:747,t:1527873494582};\\\", \\\"{x:509,y:746,t:1527873494590};\\\", \\\"{x:508,y:746,t:1527873494604};\\\", \\\"{x:506,y:746,t:1527873494620};\\\", \\\"{x:503,y:744,t:1527873494637};\\\", \\\"{x:500,y:743,t:1527873494654};\\\", \\\"{x:499,y:742,t:1527873494670};\\\", \\\"{x:496,y:742,t:1527873494686};\\\", \\\"{x:495,y:741,t:1527873494703};\\\", \\\"{x:493,y:740,t:1527873494721};\\\", \\\"{x:492,y:740,t:1527873494750};\\\", \\\"{x:492,y:739,t:1527873494807};\\\", \\\"{x:491,y:739,t:1527873494943};\\\", \\\"{x:490,y:739,t:1527873494954};\\\", \\\"{x:489,y:739,t:1527873494974};\\\", \\\"{x:488,y:738,t:1527873495006};\\\" ] }, { \\\"rt\\\": 53384, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 733906, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-O -O -03 PM-O -M -12 PM-12 PM-01 PM-02 PM-03 PM-02 PM-01 PM-12 PM-01 PM-03 PM-02 PM-01 PM-12 PM-C -C -M -X -X -X -X -X -02 PM-02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:736,t:1527873496662};\\\", \\\"{x:483,y:734,t:1527873496672};\\\", \\\"{x:482,y:734,t:1527873496689};\\\", \\\"{x:480,y:733,t:1527873496705};\\\", \\\"{x:484,y:732,t:1527873496855};\\\", \\\"{x:561,y:717,t:1527873496873};\\\", \\\"{x:691,y:698,t:1527873496889};\\\", \\\"{x:842,y:683,t:1527873496905};\\\", \\\"{x:1005,y:683,t:1527873496922};\\\", \\\"{x:1163,y:683,t:1527873496940};\\\", \\\"{x:1329,y:683,t:1527873496956};\\\", \\\"{x:1497,y:683,t:1527873496973};\\\", \\\"{x:1655,y:683,t:1527873496989};\\\", \\\"{x:1814,y:700,t:1527873497006};\\\", \\\"{x:1878,y:708,t:1527873497022};\\\", \\\"{x:1903,y:712,t:1527873497038};\\\", \\\"{x:1917,y:714,t:1527873497056};\\\", \\\"{x:1919,y:717,t:1527873497072};\\\", \\\"{x:1919,y:718,t:1527873497089};\\\", \\\"{x:1919,y:720,t:1527873497105};\\\", \\\"{x:1919,y:725,t:1527873497122};\\\", \\\"{x:1919,y:735,t:1527873497138};\\\", \\\"{x:1919,y:748,t:1527873497156};\\\", \\\"{x:1919,y:760,t:1527873497172};\\\", \\\"{x:1919,y:773,t:1527873497189};\\\", \\\"{x:1919,y:789,t:1527873497206};\\\", \\\"{x:1919,y:799,t:1527873497222};\\\", \\\"{x:1915,y:808,t:1527873497239};\\\", \\\"{x:1908,y:819,t:1527873497256};\\\", \\\"{x:1902,y:826,t:1527873497273};\\\", \\\"{x:1895,y:834,t:1527873497288};\\\", \\\"{x:1886,y:844,t:1527873497306};\\\", \\\"{x:1874,y:859,t:1527873497323};\\\", \\\"{x:1863,y:878,t:1527873497338};\\\", \\\"{x:1854,y:894,t:1527873497356};\\\", \\\"{x:1842,y:912,t:1527873497372};\\\", \\\"{x:1827,y:931,t:1527873497389};\\\", \\\"{x:1802,y:955,t:1527873497405};\\\", \\\"{x:1787,y:965,t:1527873497422};\\\", \\\"{x:1773,y:978,t:1527873497438};\\\", \\\"{x:1763,y:985,t:1527873497455};\\\", \\\"{x:1756,y:990,t:1527873497473};\\\", \\\"{x:1750,y:996,t:1527873497489};\\\", \\\"{x:1740,y:1003,t:1527873497505};\\\", \\\"{x:1732,y:1008,t:1527873497523};\\\", \\\"{x:1724,y:1010,t:1527873497540};\\\", \\\"{x:1719,y:1012,t:1527873497556};\\\", \\\"{x:1717,y:1012,t:1527873497573};\\\", \\\"{x:1712,y:1012,t:1527873497590};\\\", \\\"{x:1707,y:1012,t:1527873497606};\\\", \\\"{x:1700,y:1012,t:1527873497622};\\\", \\\"{x:1690,y:1012,t:1527873497639};\\\", \\\"{x:1674,y:1012,t:1527873497655};\\\", \\\"{x:1656,y:1012,t:1527873497673};\\\", \\\"{x:1642,y:1012,t:1527873497689};\\\", \\\"{x:1633,y:1012,t:1527873497705};\\\", \\\"{x:1624,y:1011,t:1527873497723};\\\", \\\"{x:1608,y:1007,t:1527873497740};\\\", \\\"{x:1596,y:1004,t:1527873497756};\\\", \\\"{x:1587,y:1000,t:1527873497773};\\\", \\\"{x:1582,y:998,t:1527873497790};\\\", \\\"{x:1582,y:997,t:1527873497806};\\\", \\\"{x:1581,y:996,t:1527873497823};\\\", \\\"{x:1580,y:996,t:1527873497840};\\\", \\\"{x:1579,y:995,t:1527873497857};\\\", \\\"{x:1578,y:995,t:1527873497873};\\\", \\\"{x:1577,y:994,t:1527873497890};\\\", \\\"{x:1576,y:993,t:1527873497906};\\\", \\\"{x:1575,y:991,t:1527873497923};\\\", \\\"{x:1573,y:989,t:1527873497940};\\\", \\\"{x:1571,y:986,t:1527873497957};\\\", \\\"{x:1570,y:984,t:1527873497973};\\\", \\\"{x:1568,y:979,t:1527873497990};\\\", \\\"{x:1567,y:977,t:1527873498007};\\\", \\\"{x:1566,y:973,t:1527873498022};\\\", \\\"{x:1565,y:969,t:1527873498041};\\\", \\\"{x:1564,y:965,t:1527873498058};\\\", \\\"{x:1564,y:964,t:1527873498073};\\\", \\\"{x:1563,y:963,t:1527873498090};\\\", \\\"{x:1563,y:961,t:1527873498108};\\\", \\\"{x:1561,y:960,t:1527873498123};\\\", \\\"{x:1560,y:958,t:1527873498143};\\\", \\\"{x:1560,y:957,t:1527873498183};\\\", \\\"{x:1560,y:955,t:1527873498255};\\\", \\\"{x:1559,y:954,t:1527873498271};\\\", \\\"{x:1559,y:953,t:1527873498279};\\\", \\\"{x:1558,y:952,t:1527873498290};\\\", \\\"{x:1558,y:951,t:1527873498318};\\\", \\\"{x:1558,y:950,t:1527873498326};\\\", \\\"{x:1557,y:949,t:1527873498342};\\\", \\\"{x:1557,y:947,t:1527873498366};\\\", \\\"{x:1556,y:946,t:1527873498399};\\\", \\\"{x:1556,y:945,t:1527873498415};\\\", \\\"{x:1555,y:943,t:1527873498438};\\\", \\\"{x:1555,y:942,t:1527873498455};\\\", \\\"{x:1554,y:942,t:1527873498462};\\\", \\\"{x:1554,y:941,t:1527873498479};\\\", \\\"{x:1554,y:939,t:1527873498491};\\\", \\\"{x:1553,y:937,t:1527873498507};\\\", \\\"{x:1553,y:934,t:1527873498524};\\\", \\\"{x:1550,y:928,t:1527873498541};\\\", \\\"{x:1549,y:923,t:1527873498557};\\\", \\\"{x:1547,y:915,t:1527873498574};\\\", \\\"{x:1546,y:912,t:1527873498590};\\\", \\\"{x:1545,y:908,t:1527873498607};\\\", \\\"{x:1544,y:905,t:1527873498624};\\\", \\\"{x:1542,y:900,t:1527873498641};\\\", \\\"{x:1542,y:898,t:1527873498657};\\\", \\\"{x:1542,y:897,t:1527873498674};\\\", \\\"{x:1542,y:896,t:1527873498692};\\\", \\\"{x:1540,y:893,t:1527873498707};\\\", \\\"{x:1540,y:892,t:1527873498724};\\\", \\\"{x:1540,y:890,t:1527873498741};\\\", \\\"{x:1539,y:888,t:1527873498757};\\\", \\\"{x:1538,y:884,t:1527873498775};\\\", \\\"{x:1537,y:881,t:1527873498790};\\\", \\\"{x:1537,y:877,t:1527873498808};\\\", \\\"{x:1536,y:871,t:1527873498825};\\\", \\\"{x:1535,y:863,t:1527873498841};\\\", \\\"{x:1535,y:855,t:1527873498858};\\\", \\\"{x:1531,y:844,t:1527873498875};\\\", \\\"{x:1528,y:838,t:1527873498891};\\\", \\\"{x:1528,y:832,t:1527873498907};\\\", \\\"{x:1527,y:828,t:1527873498924};\\\", \\\"{x:1526,y:824,t:1527873498941};\\\", \\\"{x:1526,y:823,t:1527873498958};\\\", \\\"{x:1526,y:821,t:1527873498974};\\\", \\\"{x:1525,y:819,t:1527873498991};\\\", \\\"{x:1525,y:815,t:1527873499008};\\\", \\\"{x:1524,y:813,t:1527873499024};\\\", \\\"{x:1523,y:808,t:1527873499041};\\\", \\\"{x:1523,y:803,t:1527873499058};\\\", \\\"{x:1521,y:795,t:1527873499074};\\\", \\\"{x:1520,y:787,t:1527873499092};\\\", \\\"{x:1519,y:779,t:1527873499109};\\\", \\\"{x:1519,y:776,t:1527873499124};\\\", \\\"{x:1517,y:770,t:1527873499141};\\\", \\\"{x:1516,y:764,t:1527873499161};\\\", \\\"{x:1516,y:760,t:1527873499174};\\\", \\\"{x:1516,y:756,t:1527873499191};\\\", \\\"{x:1515,y:753,t:1527873499207};\\\", \\\"{x:1515,y:751,t:1527873499223};\\\", \\\"{x:1515,y:754,t:1527873499438};\\\", \\\"{x:1515,y:769,t:1527873499447};\\\", \\\"{x:1515,y:784,t:1527873499458};\\\", \\\"{x:1520,y:812,t:1527873499475};\\\", \\\"{x:1523,y:834,t:1527873499491};\\\", \\\"{x:1525,y:850,t:1527873499508};\\\", \\\"{x:1528,y:865,t:1527873499525};\\\", \\\"{x:1529,y:877,t:1527873499541};\\\", \\\"{x:1530,y:892,t:1527873499559};\\\", \\\"{x:1531,y:906,t:1527873499574};\\\", \\\"{x:1531,y:917,t:1527873499592};\\\", \\\"{x:1531,y:925,t:1527873499608};\\\", \\\"{x:1531,y:931,t:1527873499626};\\\", \\\"{x:1531,y:935,t:1527873499642};\\\", \\\"{x:1531,y:940,t:1527873499659};\\\", \\\"{x:1533,y:945,t:1527873499675};\\\", \\\"{x:1534,y:952,t:1527873499692};\\\", \\\"{x:1535,y:954,t:1527873499708};\\\", \\\"{x:1536,y:958,t:1527873499725};\\\", \\\"{x:1537,y:960,t:1527873499750};\\\", \\\"{x:1537,y:962,t:1527873499774};\\\", \\\"{x:1538,y:964,t:1527873499792};\\\", \\\"{x:1539,y:966,t:1527873499809};\\\", \\\"{x:1540,y:968,t:1527873499826};\\\", \\\"{x:1541,y:970,t:1527873499842};\\\", \\\"{x:1541,y:971,t:1527873499858};\\\", \\\"{x:1541,y:972,t:1527873499875};\\\", \\\"{x:1541,y:973,t:1527873499892};\\\", \\\"{x:1541,y:975,t:1527873499908};\\\", \\\"{x:1542,y:977,t:1527873499925};\\\", \\\"{x:1542,y:978,t:1527873500015};\\\", \\\"{x:1542,y:971,t:1527873500270};\\\", \\\"{x:1541,y:961,t:1527873500279};\\\", \\\"{x:1540,y:942,t:1527873500293};\\\", \\\"{x:1533,y:895,t:1527873500309};\\\", \\\"{x:1526,y:855,t:1527873500325};\\\", \\\"{x:1521,y:828,t:1527873500342};\\\", \\\"{x:1517,y:815,t:1527873500359};\\\", \\\"{x:1513,y:803,t:1527873500376};\\\", \\\"{x:1511,y:796,t:1527873500393};\\\", \\\"{x:1511,y:791,t:1527873500409};\\\", \\\"{x:1509,y:787,t:1527873500426};\\\", \\\"{x:1509,y:784,t:1527873500443};\\\", \\\"{x:1509,y:778,t:1527873500460};\\\", \\\"{x:1509,y:774,t:1527873500476};\\\", \\\"{x:1509,y:771,t:1527873500493};\\\", \\\"{x:1509,y:768,t:1527873500509};\\\", \\\"{x:1509,y:764,t:1527873500527};\\\", \\\"{x:1509,y:763,t:1527873500542};\\\", \\\"{x:1509,y:761,t:1527873500560};\\\", \\\"{x:1509,y:760,t:1527873501512};\\\", \\\"{x:1509,y:753,t:1527873501527};\\\", \\\"{x:1505,y:741,t:1527873501544};\\\", \\\"{x:1501,y:729,t:1527873501561};\\\", \\\"{x:1496,y:717,t:1527873501577};\\\", \\\"{x:1492,y:708,t:1527873501593};\\\", \\\"{x:1488,y:701,t:1527873501610};\\\", \\\"{x:1484,y:693,t:1527873501628};\\\", \\\"{x:1481,y:687,t:1527873501644};\\\", \\\"{x:1479,y:683,t:1527873501660};\\\", \\\"{x:1478,y:679,t:1527873501678};\\\", \\\"{x:1477,y:677,t:1527873501694};\\\", \\\"{x:1476,y:673,t:1527873501710};\\\", \\\"{x:1475,y:672,t:1527873501727};\\\", \\\"{x:1475,y:670,t:1527873501743};\\\", \\\"{x:1473,y:668,t:1527873501760};\\\", \\\"{x:1473,y:667,t:1527873501777};\\\", \\\"{x:1472,y:665,t:1527873501793};\\\", \\\"{x:1471,y:663,t:1527873501810};\\\", \\\"{x:1470,y:661,t:1527873501826};\\\", \\\"{x:1469,y:660,t:1527873501844};\\\", \\\"{x:1468,y:654,t:1527873501860};\\\", \\\"{x:1466,y:649,t:1527873501877};\\\", \\\"{x:1462,y:642,t:1527873501894};\\\", \\\"{x:1462,y:638,t:1527873501909};\\\", \\\"{x:1461,y:636,t:1527873501927};\\\", \\\"{x:1460,y:634,t:1527873501944};\\\", \\\"{x:1459,y:633,t:1527873501998};\\\", \\\"{x:1451,y:638,t:1527873502774};\\\", \\\"{x:1442,y:647,t:1527873502783};\\\", \\\"{x:1434,y:653,t:1527873502794};\\\", \\\"{x:1422,y:661,t:1527873502810};\\\", \\\"{x:1417,y:663,t:1527873502828};\\\", \\\"{x:1413,y:666,t:1527873502845};\\\", \\\"{x:1408,y:670,t:1527873502861};\\\", \\\"{x:1405,y:671,t:1527873502878};\\\", \\\"{x:1404,y:673,t:1527873502895};\\\", \\\"{x:1403,y:673,t:1527873502912};\\\", \\\"{x:1402,y:674,t:1527873502928};\\\", \\\"{x:1399,y:676,t:1527873502945};\\\", \\\"{x:1397,y:677,t:1527873502961};\\\", \\\"{x:1396,y:679,t:1527873502978};\\\", \\\"{x:1395,y:680,t:1527873502995};\\\", \\\"{x:1393,y:683,t:1527873503011};\\\", \\\"{x:1392,y:685,t:1527873503028};\\\", \\\"{x:1388,y:689,t:1527873503045};\\\", \\\"{x:1386,y:691,t:1527873503060};\\\", \\\"{x:1384,y:694,t:1527873503078};\\\", \\\"{x:1381,y:697,t:1527873503095};\\\", \\\"{x:1379,y:699,t:1527873503111};\\\", \\\"{x:1378,y:699,t:1527873503128};\\\", \\\"{x:1378,y:700,t:1527873503145};\\\", \\\"{x:1376,y:701,t:1527873503161};\\\", \\\"{x:1375,y:702,t:1527873503178};\\\", \\\"{x:1373,y:704,t:1527873503195};\\\", \\\"{x:1372,y:705,t:1527873503212};\\\", \\\"{x:1371,y:706,t:1527873503230};\\\", \\\"{x:1371,y:707,t:1527873503254};\\\", \\\"{x:1370,y:707,t:1527873503262};\\\", \\\"{x:1369,y:708,t:1527873503278};\\\", \\\"{x:1369,y:711,t:1527873503567};\\\", \\\"{x:1366,y:714,t:1527873503578};\\\", \\\"{x:1366,y:719,t:1527873503596};\\\", \\\"{x:1366,y:723,t:1527873503612};\\\", \\\"{x:1365,y:728,t:1527873503629};\\\", \\\"{x:1364,y:735,t:1527873503646};\\\", \\\"{x:1361,y:746,t:1527873503662};\\\", \\\"{x:1361,y:752,t:1527873503680};\\\", \\\"{x:1361,y:758,t:1527873503695};\\\", \\\"{x:1361,y:763,t:1527873503712};\\\", \\\"{x:1361,y:767,t:1527873503730};\\\", \\\"{x:1361,y:769,t:1527873503745};\\\", \\\"{x:1361,y:771,t:1527873503763};\\\", \\\"{x:1361,y:773,t:1527873503779};\\\", \\\"{x:1359,y:776,t:1527873503796};\\\", \\\"{x:1358,y:777,t:1527873503812};\\\", \\\"{x:1356,y:779,t:1527873503830};\\\", \\\"{x:1356,y:780,t:1527873503845};\\\", \\\"{x:1355,y:780,t:1527873503863};\\\", \\\"{x:1353,y:780,t:1527873503983};\\\", \\\"{x:1351,y:780,t:1527873503997};\\\", \\\"{x:1348,y:776,t:1527873504013};\\\", \\\"{x:1347,y:774,t:1527873504029};\\\", \\\"{x:1344,y:772,t:1527873504047};\\\", \\\"{x:1344,y:771,t:1527873504063};\\\", \\\"{x:1343,y:771,t:1527873504079};\\\", \\\"{x:1343,y:770,t:1527873504599};\\\", \\\"{x:1342,y:770,t:1527873504613};\\\", \\\"{x:1341,y:769,t:1527873504631};\\\", \\\"{x:1340,y:769,t:1527873504646};\\\", \\\"{x:1339,y:768,t:1527873504663};\\\", \\\"{x:1336,y:767,t:1527873504680};\\\", \\\"{x:1335,y:767,t:1527873504703};\\\", \\\"{x:1335,y:766,t:1527873505110};\\\", \\\"{x:1336,y:766,t:1527873505134};\\\", \\\"{x:1339,y:767,t:1527873505147};\\\", \\\"{x:1340,y:767,t:1527873505164};\\\", \\\"{x:1345,y:770,t:1527873505180};\\\", \\\"{x:1351,y:778,t:1527873505197};\\\", \\\"{x:1358,y:785,t:1527873505213};\\\", \\\"{x:1369,y:802,t:1527873505232};\\\", \\\"{x:1376,y:814,t:1527873505246};\\\", \\\"{x:1382,y:825,t:1527873505263};\\\", \\\"{x:1385,y:833,t:1527873505280};\\\", \\\"{x:1387,y:838,t:1527873505297};\\\", \\\"{x:1388,y:840,t:1527873505314};\\\", \\\"{x:1388,y:842,t:1527873505422};\\\", \\\"{x:1388,y:848,t:1527873505438};\\\", \\\"{x:1388,y:855,t:1527873505446};\\\", \\\"{x:1388,y:866,t:1527873505464};\\\", \\\"{x:1384,y:887,t:1527873505480};\\\", \\\"{x:1377,y:910,t:1527873505497};\\\", \\\"{x:1371,y:934,t:1527873505514};\\\", \\\"{x:1362,y:955,t:1527873505530};\\\", \\\"{x:1354,y:971,t:1527873505547};\\\", \\\"{x:1348,y:982,t:1527873505564};\\\", \\\"{x:1345,y:986,t:1527873505581};\\\", \\\"{x:1344,y:988,t:1527873505597};\\\", \\\"{x:1344,y:989,t:1527873505615};\\\", \\\"{x:1343,y:989,t:1527873505855};\\\", \\\"{x:1343,y:988,t:1527873505870};\\\", \\\"{x:1343,y:987,t:1527873505882};\\\", \\\"{x:1343,y:986,t:1527873505897};\\\", \\\"{x:1343,y:985,t:1527873505914};\\\", \\\"{x:1344,y:983,t:1527873505932};\\\", \\\"{x:1344,y:982,t:1527873505990};\\\", \\\"{x:1345,y:981,t:1527873505998};\\\", \\\"{x:1345,y:980,t:1527873506134};\\\", \\\"{x:1350,y:980,t:1527873506230};\\\", \\\"{x:1361,y:980,t:1527873506248};\\\", \\\"{x:1372,y:980,t:1527873506265};\\\", \\\"{x:1379,y:980,t:1527873506282};\\\", \\\"{x:1387,y:981,t:1527873506299};\\\", \\\"{x:1393,y:981,t:1527873506314};\\\", \\\"{x:1399,y:982,t:1527873506332};\\\", \\\"{x:1405,y:983,t:1527873506348};\\\", \\\"{x:1408,y:984,t:1527873506365};\\\", \\\"{x:1409,y:984,t:1527873506382};\\\", \\\"{x:1413,y:984,t:1527873506711};\\\", \\\"{x:1417,y:984,t:1527873506718};\\\", \\\"{x:1421,y:984,t:1527873506733};\\\", \\\"{x:1429,y:984,t:1527873506749};\\\", \\\"{x:1435,y:984,t:1527873506765};\\\", \\\"{x:1441,y:984,t:1527873506782};\\\", \\\"{x:1443,y:984,t:1527873506798};\\\", \\\"{x:1444,y:984,t:1527873506815};\\\", \\\"{x:1446,y:984,t:1527873506839};\\\", \\\"{x:1447,y:984,t:1527873506982};\\\", \\\"{x:1450,y:984,t:1527873506998};\\\", \\\"{x:1453,y:984,t:1527873507015};\\\", \\\"{x:1456,y:984,t:1527873507033};\\\", \\\"{x:1459,y:984,t:1527873507048};\\\", \\\"{x:1462,y:984,t:1527873507066};\\\", \\\"{x:1464,y:984,t:1527873507082};\\\", \\\"{x:1465,y:984,t:1527873507100};\\\", \\\"{x:1466,y:984,t:1527873508150};\\\", \\\"{x:1467,y:984,t:1527873508223};\\\", \\\"{x:1468,y:984,t:1527873508238};\\\", \\\"{x:1469,y:984,t:1527873508251};\\\", \\\"{x:1475,y:984,t:1527873508267};\\\", \\\"{x:1478,y:984,t:1527873508283};\\\", \\\"{x:1482,y:983,t:1527873508300};\\\", \\\"{x:1484,y:983,t:1527873508316};\\\", \\\"{x:1487,y:982,t:1527873508334};\\\", \\\"{x:1490,y:982,t:1527873508350};\\\", \\\"{x:1493,y:982,t:1527873508366};\\\", \\\"{x:1499,y:980,t:1527873508383};\\\", \\\"{x:1510,y:980,t:1527873508401};\\\", \\\"{x:1520,y:979,t:1527873508416};\\\", \\\"{x:1525,y:978,t:1527873508434};\\\", \\\"{x:1528,y:977,t:1527873508451};\\\", \\\"{x:1529,y:977,t:1527873508466};\\\", \\\"{x:1523,y:976,t:1527873509679};\\\", \\\"{x:1512,y:976,t:1527873509686};\\\", \\\"{x:1503,y:976,t:1527873509702};\\\", \\\"{x:1483,y:976,t:1527873509718};\\\", \\\"{x:1475,y:976,t:1527873509734};\\\", \\\"{x:1466,y:976,t:1527873509751};\\\", \\\"{x:1458,y:976,t:1527873509769};\\\", \\\"{x:1448,y:977,t:1527873509785};\\\", \\\"{x:1439,y:978,t:1527873509802};\\\", \\\"{x:1432,y:978,t:1527873509819};\\\", \\\"{x:1426,y:978,t:1527873509834};\\\", \\\"{x:1420,y:978,t:1527873509851};\\\", \\\"{x:1415,y:978,t:1527873509868};\\\", \\\"{x:1413,y:978,t:1527873509885};\\\", \\\"{x:1411,y:978,t:1527873509901};\\\", \\\"{x:1408,y:978,t:1527873509918};\\\", \\\"{x:1407,y:979,t:1527873509935};\\\", \\\"{x:1406,y:979,t:1527873511654};\\\", \\\"{x:1405,y:981,t:1527873511669};\\\", \\\"{x:1402,y:987,t:1527873511687};\\\", \\\"{x:1401,y:987,t:1527873511704};\\\", \\\"{x:1400,y:988,t:1527873511721};\\\", \\\"{x:1398,y:988,t:1527873511861};\\\", \\\"{x:1397,y:988,t:1527873511877};\\\", \\\"{x:1394,y:988,t:1527873511886};\\\", \\\"{x:1393,y:987,t:1527873511903};\\\", \\\"{x:1392,y:987,t:1527873511920};\\\", \\\"{x:1391,y:987,t:1527873511936};\\\", \\\"{x:1390,y:986,t:1527873511953};\\\", \\\"{x:1388,y:986,t:1527873511970};\\\", \\\"{x:1386,y:985,t:1527873511987};\\\", \\\"{x:1384,y:984,t:1527873512003};\\\", \\\"{x:1382,y:983,t:1527873512020};\\\", \\\"{x:1377,y:981,t:1527873512037};\\\", \\\"{x:1376,y:980,t:1527873512053};\\\", \\\"{x:1373,y:979,t:1527873512070};\\\", \\\"{x:1372,y:979,t:1527873512087};\\\", \\\"{x:1371,y:979,t:1527873512103};\\\", \\\"{x:1370,y:978,t:1527873512134};\\\", \\\"{x:1370,y:977,t:1527873512142};\\\", \\\"{x:1369,y:977,t:1527873512154};\\\", \\\"{x:1367,y:977,t:1527873512170};\\\", \\\"{x:1366,y:977,t:1527873512326};\\\", \\\"{x:1368,y:977,t:1527873512646};\\\", \\\"{x:1371,y:977,t:1527873512655};\\\", \\\"{x:1376,y:978,t:1527873512671};\\\", \\\"{x:1381,y:981,t:1527873512688};\\\", \\\"{x:1384,y:982,t:1527873512704};\\\", \\\"{x:1385,y:983,t:1527873512722};\\\", \\\"{x:1387,y:983,t:1527873512738};\\\", \\\"{x:1387,y:984,t:1527873512839};\\\", \\\"{x:1388,y:984,t:1527873512878};\\\", \\\"{x:1389,y:984,t:1527873512935};\\\", \\\"{x:1391,y:984,t:1527873512975};\\\", \\\"{x:1395,y:984,t:1527873512988};\\\", \\\"{x:1414,y:984,t:1527873513004};\\\", \\\"{x:1453,y:987,t:1527873513021};\\\", \\\"{x:1471,y:987,t:1527873513037};\\\", \\\"{x:1486,y:987,t:1527873513054};\\\", \\\"{x:1491,y:987,t:1527873513071};\\\", \\\"{x:1493,y:987,t:1527873513088};\\\", \\\"{x:1498,y:986,t:1527873513319};\\\", \\\"{x:1503,y:984,t:1527873513326};\\\", \\\"{x:1509,y:982,t:1527873513338};\\\", \\\"{x:1516,y:980,t:1527873513354};\\\", \\\"{x:1524,y:980,t:1527873513372};\\\", \\\"{x:1528,y:979,t:1527873513388};\\\", \\\"{x:1531,y:979,t:1527873513406};\\\", \\\"{x:1534,y:978,t:1527873513422};\\\", \\\"{x:1535,y:978,t:1527873513438};\\\", \\\"{x:1538,y:978,t:1527873513455};\\\", \\\"{x:1542,y:977,t:1527873513471};\\\", \\\"{x:1547,y:976,t:1527873513488};\\\", \\\"{x:1549,y:976,t:1527873513505};\\\", \\\"{x:1550,y:976,t:1527873513522};\\\", \\\"{x:1545,y:978,t:1527873513799};\\\", \\\"{x:1538,y:979,t:1527873513806};\\\", \\\"{x:1527,y:979,t:1527873513822};\\\", \\\"{x:1516,y:979,t:1527873513839};\\\", \\\"{x:1506,y:979,t:1527873513856};\\\", \\\"{x:1496,y:977,t:1527873513873};\\\", \\\"{x:1489,y:977,t:1527873513889};\\\", \\\"{x:1484,y:976,t:1527873513905};\\\", \\\"{x:1477,y:976,t:1527873513923};\\\", \\\"{x:1466,y:976,t:1527873513938};\\\", \\\"{x:1454,y:976,t:1527873513956};\\\", \\\"{x:1434,y:976,t:1527873513973};\\\", \\\"{x:1413,y:976,t:1527873513988};\\\", \\\"{x:1385,y:976,t:1527873514006};\\\", \\\"{x:1376,y:976,t:1527873514022};\\\", \\\"{x:1367,y:976,t:1527873514039};\\\", \\\"{x:1359,y:976,t:1527873514056};\\\", \\\"{x:1352,y:976,t:1527873514073};\\\", \\\"{x:1351,y:976,t:1527873514089};\\\", \\\"{x:1349,y:976,t:1527873514105};\\\", \\\"{x:1348,y:976,t:1527873514126};\\\", \\\"{x:1346,y:976,t:1527873514150};\\\", \\\"{x:1345,y:976,t:1527873514158};\\\", \\\"{x:1344,y:976,t:1527873514172};\\\", \\\"{x:1341,y:977,t:1527873514190};\\\", \\\"{x:1338,y:977,t:1527873515991};\\\", \\\"{x:1332,y:977,t:1527873516008};\\\", \\\"{x:1318,y:963,t:1527873516026};\\\", \\\"{x:1299,y:945,t:1527873516041};\\\", \\\"{x:1258,y:911,t:1527873516057};\\\", \\\"{x:1203,y:879,t:1527873516075};\\\", \\\"{x:1138,y:845,t:1527873516091};\\\", \\\"{x:1065,y:805,t:1527873516107};\\\", \\\"{x:995,y:770,t:1527873516125};\\\", \\\"{x:935,y:744,t:1527873516140};\\\", \\\"{x:874,y:717,t:1527873516158};\\\", \\\"{x:849,y:703,t:1527873516174};\\\", \\\"{x:833,y:694,t:1527873516190};\\\", \\\"{x:822,y:689,t:1527873516208};\\\", \\\"{x:817,y:685,t:1527873516225};\\\", \\\"{x:813,y:682,t:1527873516241};\\\", \\\"{x:808,y:678,t:1527873516258};\\\", \\\"{x:803,y:674,t:1527873516275};\\\", \\\"{x:791,y:664,t:1527873516292};\\\", \\\"{x:773,y:652,t:1527873516307};\\\", \\\"{x:753,y:638,t:1527873516325};\\\", \\\"{x:716,y:615,t:1527873516343};\\\", \\\"{x:690,y:599,t:1527873516357};\\\", \\\"{x:603,y:550,t:1527873516391};\\\", \\\"{x:581,y:537,t:1527873516401};\\\", \\\"{x:533,y:513,t:1527873516419};\\\", \\\"{x:450,y:482,t:1527873516438};\\\", \\\"{x:402,y:468,t:1527873516454};\\\", \\\"{x:352,y:462,t:1527873516470};\\\", \\\"{x:310,y:455,t:1527873516487};\\\", \\\"{x:280,y:454,t:1527873516504};\\\", \\\"{x:257,y:454,t:1527873516520};\\\", \\\"{x:243,y:454,t:1527873516538};\\\", \\\"{x:236,y:454,t:1527873516554};\\\", \\\"{x:231,y:454,t:1527873516570};\\\", \\\"{x:226,y:457,t:1527873516587};\\\", \\\"{x:220,y:462,t:1527873516604};\\\", \\\"{x:213,y:466,t:1527873516620};\\\", \\\"{x:203,y:473,t:1527873516638};\\\", \\\"{x:197,y:479,t:1527873516654};\\\", \\\"{x:195,y:482,t:1527873516670};\\\", \\\"{x:194,y:485,t:1527873516688};\\\", \\\"{x:194,y:490,t:1527873516706};\\\", \\\"{x:193,y:495,t:1527873516720};\\\", \\\"{x:193,y:500,t:1527873516738};\\\", \\\"{x:192,y:505,t:1527873516754};\\\", \\\"{x:191,y:512,t:1527873516771};\\\", \\\"{x:191,y:521,t:1527873516788};\\\", \\\"{x:191,y:533,t:1527873516805};\\\", \\\"{x:191,y:540,t:1527873516820};\\\", \\\"{x:191,y:545,t:1527873516837};\\\", \\\"{x:191,y:548,t:1527873516854};\\\", \\\"{x:190,y:550,t:1527873516872};\\\", \\\"{x:190,y:551,t:1527873516888};\\\", \\\"{x:190,y:552,t:1527873516904};\\\", \\\"{x:189,y:552,t:1527873517006};\\\", \\\"{x:188,y:552,t:1527873517086};\\\", \\\"{x:186,y:550,t:1527873517095};\\\", \\\"{x:186,y:549,t:1527873517104};\\\", \\\"{x:185,y:548,t:1527873517121};\\\", \\\"{x:184,y:546,t:1527873517138};\\\", \\\"{x:183,y:545,t:1527873517155};\\\", \\\"{x:181,y:543,t:1527873517171};\\\", \\\"{x:180,y:541,t:1527873517188};\\\", \\\"{x:179,y:540,t:1527873517461};\\\", \\\"{x:179,y:540,t:1527873517534};\\\", \\\"{x:184,y:540,t:1527873518190};\\\", \\\"{x:218,y:546,t:1527873518206};\\\", \\\"{x:271,y:562,t:1527873518223};\\\", \\\"{x:341,y:584,t:1527873518240};\\\", \\\"{x:434,y:619,t:1527873518256};\\\", \\\"{x:536,y:650,t:1527873518272};\\\", \\\"{x:639,y:680,t:1527873518289};\\\", \\\"{x:763,y:711,t:1527873518305};\\\", \\\"{x:870,y:738,t:1527873518322};\\\", \\\"{x:935,y:759,t:1527873518339};\\\", \\\"{x:974,y:768,t:1527873518355};\\\", \\\"{x:995,y:777,t:1527873518372};\\\", \\\"{x:1013,y:785,t:1527873518389};\\\", \\\"{x:1026,y:790,t:1527873518405};\\\", \\\"{x:1042,y:800,t:1527873518422};\\\", \\\"{x:1059,y:810,t:1527873518439};\\\", \\\"{x:1072,y:817,t:1527873518456};\\\", \\\"{x:1083,y:825,t:1527873518473};\\\", \\\"{x:1097,y:834,t:1527873518490};\\\", \\\"{x:1108,y:841,t:1527873518506};\\\", \\\"{x:1123,y:851,t:1527873518523};\\\", \\\"{x:1143,y:863,t:1527873518540};\\\", \\\"{x:1157,y:874,t:1527873518557};\\\", \\\"{x:1168,y:885,t:1527873518572};\\\", \\\"{x:1181,y:904,t:1527873518590};\\\", \\\"{x:1191,y:915,t:1527873518606};\\\", \\\"{x:1197,y:920,t:1527873518624};\\\", \\\"{x:1200,y:923,t:1527873518640};\\\", \\\"{x:1202,y:923,t:1527873518656};\\\", \\\"{x:1202,y:924,t:1527873518673};\\\", \\\"{x:1202,y:922,t:1527873518967};\\\", \\\"{x:1202,y:917,t:1527873518974};\\\", \\\"{x:1202,y:910,t:1527873518991};\\\", \\\"{x:1202,y:903,t:1527873519008};\\\", \\\"{x:1202,y:896,t:1527873519024};\\\", \\\"{x:1202,y:890,t:1527873519041};\\\", \\\"{x:1202,y:882,t:1527873519058};\\\", \\\"{x:1202,y:874,t:1527873519074};\\\", \\\"{x:1201,y:867,t:1527873519091};\\\", \\\"{x:1201,y:862,t:1527873519108};\\\", \\\"{x:1200,y:856,t:1527873519124};\\\", \\\"{x:1200,y:853,t:1527873519140};\\\", \\\"{x:1200,y:849,t:1527873519158};\\\", \\\"{x:1200,y:845,t:1527873519174};\\\", \\\"{x:1200,y:841,t:1527873519191};\\\", \\\"{x:1200,y:837,t:1527873519208};\\\", \\\"{x:1200,y:831,t:1527873519225};\\\", \\\"{x:1200,y:827,t:1527873519241};\\\", \\\"{x:1200,y:822,t:1527873519257};\\\", \\\"{x:1200,y:816,t:1527873519275};\\\", \\\"{x:1200,y:810,t:1527873519291};\\\", \\\"{x:1200,y:805,t:1527873519308};\\\", \\\"{x:1200,y:799,t:1527873519325};\\\", \\\"{x:1198,y:793,t:1527873519341};\\\", \\\"{x:1198,y:787,t:1527873519358};\\\", \\\"{x:1197,y:784,t:1527873519375};\\\", \\\"{x:1197,y:780,t:1527873519392};\\\", \\\"{x:1197,y:779,t:1527873519408};\\\", \\\"{x:1197,y:778,t:1527873519425};\\\", \\\"{x:1197,y:776,t:1527873519442};\\\", \\\"{x:1197,y:775,t:1527873519458};\\\", \\\"{x:1196,y:775,t:1527873519475};\\\", \\\"{x:1196,y:774,t:1527873519703};\\\", \\\"{x:1196,y:773,t:1527873519718};\\\", \\\"{x:1196,y:772,t:1527873519726};\\\", \\\"{x:1194,y:770,t:1527873519742};\\\", \\\"{x:1194,y:769,t:1527873519758};\\\", \\\"{x:1192,y:765,t:1527873519775};\\\", \\\"{x:1191,y:764,t:1527873519798};\\\", \\\"{x:1191,y:763,t:1527873519814};\\\", \\\"{x:1190,y:762,t:1527873519943};\\\", \\\"{x:1191,y:757,t:1527873520622};\\\", \\\"{x:1197,y:747,t:1527873520630};\\\", \\\"{x:1202,y:739,t:1527873520643};\\\", \\\"{x:1211,y:725,t:1527873520659};\\\", \\\"{x:1218,y:715,t:1527873520676};\\\", \\\"{x:1228,y:703,t:1527873520693};\\\", \\\"{x:1237,y:691,t:1527873520709};\\\", \\\"{x:1244,y:681,t:1527873520726};\\\", \\\"{x:1254,y:666,t:1527873520743};\\\", \\\"{x:1255,y:656,t:1527873520760};\\\", \\\"{x:1258,y:643,t:1527873520776};\\\", \\\"{x:1260,y:631,t:1527873520794};\\\", \\\"{x:1263,y:622,t:1527873520811};\\\", \\\"{x:1268,y:612,t:1527873520826};\\\", \\\"{x:1270,y:602,t:1527873520843};\\\", \\\"{x:1272,y:597,t:1527873520860};\\\", \\\"{x:1273,y:594,t:1527873520877};\\\", \\\"{x:1277,y:585,t:1527873520894};\\\", \\\"{x:1288,y:568,t:1527873520911};\\\", \\\"{x:1298,y:554,t:1527873520928};\\\", \\\"{x:1305,y:544,t:1527873520944};\\\", \\\"{x:1314,y:533,t:1527873520960};\\\", \\\"{x:1327,y:520,t:1527873520978};\\\", \\\"{x:1346,y:507,t:1527873520994};\\\", \\\"{x:1370,y:492,t:1527873521010};\\\", \\\"{x:1394,y:479,t:1527873521029};\\\", \\\"{x:1411,y:468,t:1527873521044};\\\", \\\"{x:1440,y:448,t:1527873521061};\\\", \\\"{x:1477,y:421,t:1527873521077};\\\", \\\"{x:1485,y:415,t:1527873521095};\\\", \\\"{x:1486,y:415,t:1527873521110};\\\", \\\"{x:1487,y:414,t:1527873521175};\\\", \\\"{x:1487,y:412,t:1527873521190};\\\", \\\"{x:1485,y:407,t:1527873521198};\\\", \\\"{x:1483,y:399,t:1527873521211};\\\", \\\"{x:1474,y:381,t:1527873521229};\\\", \\\"{x:1470,y:365,t:1527873521245};\\\", \\\"{x:1467,y:356,t:1527873521261};\\\", \\\"{x:1463,y:340,t:1527873521278};\\\", \\\"{x:1461,y:334,t:1527873521295};\\\", \\\"{x:1460,y:328,t:1527873521312};\\\", \\\"{x:1459,y:324,t:1527873521328};\\\", \\\"{x:1457,y:318,t:1527873521345};\\\", \\\"{x:1457,y:315,t:1527873521362};\\\", \\\"{x:1456,y:309,t:1527873521378};\\\", \\\"{x:1455,y:305,t:1527873521395};\\\", \\\"{x:1455,y:300,t:1527873521412};\\\", \\\"{x:1453,y:296,t:1527873521429};\\\", \\\"{x:1453,y:292,t:1527873521445};\\\", \\\"{x:1454,y:286,t:1527873521462};\\\", \\\"{x:1457,y:283,t:1527873521478};\\\", \\\"{x:1459,y:281,t:1527873521495};\\\", \\\"{x:1462,y:278,t:1527873521512};\\\", \\\"{x:1464,y:276,t:1527873521529};\\\", \\\"{x:1465,y:274,t:1527873521545};\\\", \\\"{x:1466,y:273,t:1527873521562};\\\", \\\"{x:1468,y:272,t:1527873521877};\\\", \\\"{x:1475,y:270,t:1527873521885};\\\", \\\"{x:1482,y:268,t:1527873521896};\\\", \\\"{x:1495,y:265,t:1527873521913};\\\", \\\"{x:1501,y:262,t:1527873521929};\\\", \\\"{x:1501,y:274,t:1527873522046};\\\", \\\"{x:1492,y:309,t:1527873522063};\\\", \\\"{x:1478,y:354,t:1527873522079};\\\", \\\"{x:1466,y:399,t:1527873522096};\\\", \\\"{x:1453,y:434,t:1527873522114};\\\", \\\"{x:1430,y:484,t:1527873522130};\\\", \\\"{x:1397,y:541,t:1527873522146};\\\", \\\"{x:1369,y:590,t:1527873522163};\\\", \\\"{x:1343,y:631,t:1527873522180};\\\", \\\"{x:1329,y:650,t:1527873522196};\\\", \\\"{x:1311,y:670,t:1527873522213};\\\", \\\"{x:1277,y:703,t:1527873522229};\\\", \\\"{x:1255,y:721,t:1527873522246};\\\", \\\"{x:1242,y:733,t:1527873522263};\\\", \\\"{x:1233,y:741,t:1527873522280};\\\", \\\"{x:1229,y:744,t:1527873522297};\\\", \\\"{x:1224,y:746,t:1527873522313};\\\", \\\"{x:1220,y:748,t:1527873522330};\\\", \\\"{x:1219,y:748,t:1527873522347};\\\", \\\"{x:1218,y:744,t:1527873522454};\\\", \\\"{x:1218,y:737,t:1527873522463};\\\", \\\"{x:1218,y:729,t:1527873522480};\\\", \\\"{x:1218,y:722,t:1527873522497};\\\", \\\"{x:1219,y:717,t:1527873522514};\\\", \\\"{x:1221,y:712,t:1527873522530};\\\", \\\"{x:1221,y:707,t:1527873522547};\\\", \\\"{x:1223,y:702,t:1527873522564};\\\", \\\"{x:1224,y:699,t:1527873522580};\\\", \\\"{x:1224,y:696,t:1527873522598};\\\", \\\"{x:1226,y:690,t:1527873522614};\\\", \\\"{x:1228,y:687,t:1527873522629};\\\", \\\"{x:1229,y:684,t:1527873522647};\\\", \\\"{x:1232,y:679,t:1527873522664};\\\", \\\"{x:1235,y:672,t:1527873522680};\\\", \\\"{x:1238,y:666,t:1527873522697};\\\", \\\"{x:1240,y:660,t:1527873522714};\\\", \\\"{x:1243,y:655,t:1527873522731};\\\", \\\"{x:1247,y:650,t:1527873522747};\\\", \\\"{x:1249,y:648,t:1527873522764};\\\", \\\"{x:1252,y:644,t:1527873522781};\\\", \\\"{x:1253,y:643,t:1527873522797};\\\", \\\"{x:1253,y:641,t:1527873522814};\\\", \\\"{x:1254,y:641,t:1527873523071};\\\", \\\"{x:1255,y:641,t:1527873523086};\\\", \\\"{x:1258,y:641,t:1527873523098};\\\", \\\"{x:1273,y:642,t:1527873523115};\\\", \\\"{x:1302,y:643,t:1527873523131};\\\", \\\"{x:1324,y:644,t:1527873523148};\\\", \\\"{x:1346,y:644,t:1527873523165};\\\", \\\"{x:1369,y:644,t:1527873523181};\\\", \\\"{x:1398,y:644,t:1527873523198};\\\", \\\"{x:1404,y:643,t:1527873523215};\\\", \\\"{x:1405,y:642,t:1527873523430};\\\", \\\"{x:1406,y:641,t:1527873523438};\\\", \\\"{x:1408,y:641,t:1527873523448};\\\", \\\"{x:1413,y:640,t:1527873523464};\\\", \\\"{x:1416,y:639,t:1527873523482};\\\", \\\"{x:1421,y:639,t:1527873523499};\\\", \\\"{x:1426,y:639,t:1527873523515};\\\", \\\"{x:1428,y:639,t:1527873523532};\\\", \\\"{x:1430,y:639,t:1527873523558};\\\", \\\"{x:1432,y:639,t:1527873523839};\\\", \\\"{x:1434,y:639,t:1527873523849};\\\", \\\"{x:1439,y:639,t:1527873523866};\\\", \\\"{x:1441,y:639,t:1527873523883};\\\", \\\"{x:1442,y:639,t:1527873523902};\\\", \\\"{x:1442,y:636,t:1527873524430};\\\", \\\"{x:1443,y:634,t:1527873524438};\\\", \\\"{x:1443,y:633,t:1527873526246};\\\", \\\"{x:1443,y:632,t:1527873526630};\\\", \\\"{x:1445,y:628,t:1527873526638};\\\", \\\"{x:1445,y:623,t:1527873526655};\\\", \\\"{x:1446,y:618,t:1527873526671};\\\", \\\"{x:1446,y:616,t:1527873526687};\\\", \\\"{x:1446,y:614,t:1527873526704};\\\", \\\"{x:1446,y:613,t:1527873526734};\\\", \\\"{x:1446,y:612,t:1527873526844};\\\", \\\"{x:1444,y:609,t:1527873526854};\\\", \\\"{x:1440,y:605,t:1527873526871};\\\", \\\"{x:1432,y:597,t:1527873526887};\\\", \\\"{x:1417,y:586,t:1527873526903};\\\", \\\"{x:1406,y:579,t:1527873526921};\\\", \\\"{x:1401,y:575,t:1527873526938};\\\", \\\"{x:1397,y:572,t:1527873526955};\\\", \\\"{x:1396,y:571,t:1527873526971};\\\", \\\"{x:1395,y:571,t:1527873526989};\\\", \\\"{x:1395,y:572,t:1527873527431};\\\", \\\"{x:1395,y:577,t:1527873527439};\\\", \\\"{x:1397,y:589,t:1527873527455};\\\", \\\"{x:1402,y:602,t:1527873527472};\\\", \\\"{x:1407,y:607,t:1527873527490};\\\", \\\"{x:1409,y:608,t:1527873527505};\\\", \\\"{x:1410,y:608,t:1527873527534};\\\", \\\"{x:1411,y:608,t:1527873527719};\\\", \\\"{x:1411,y:602,t:1527873527726};\\\", \\\"{x:1410,y:598,t:1527873527739};\\\", \\\"{x:1410,y:592,t:1527873527756};\\\", \\\"{x:1410,y:586,t:1527873527773};\\\", \\\"{x:1410,y:583,t:1527873527789};\\\", \\\"{x:1410,y:579,t:1527873527806};\\\", \\\"{x:1410,y:577,t:1527873527823};\\\", \\\"{x:1409,y:575,t:1527873527852};\\\", \\\"{x:1409,y:581,t:1527873528622};\\\", \\\"{x:1408,y:588,t:1527873528630};\\\", \\\"{x:1406,y:597,t:1527873528641};\\\", \\\"{x:1405,y:611,t:1527873528657};\\\", \\\"{x:1402,y:627,t:1527873528674};\\\", \\\"{x:1400,y:644,t:1527873528691};\\\", \\\"{x:1396,y:659,t:1527873528709};\\\", \\\"{x:1392,y:675,t:1527873528725};\\\", \\\"{x:1390,y:690,t:1527873528741};\\\", \\\"{x:1386,y:705,t:1527873528758};\\\", \\\"{x:1384,y:711,t:1527873528774};\\\", \\\"{x:1382,y:716,t:1527873528791};\\\", \\\"{x:1381,y:719,t:1527873528809};\\\", \\\"{x:1380,y:719,t:1527873528824};\\\", \\\"{x:1379,y:719,t:1527873528842};\\\", \\\"{x:1377,y:719,t:1527873528858};\\\", \\\"{x:1375,y:719,t:1527873528876};\\\", \\\"{x:1368,y:719,t:1527873528891};\\\", \\\"{x:1360,y:719,t:1527873528908};\\\", \\\"{x:1359,y:719,t:1527873528926};\\\", \\\"{x:1358,y:719,t:1527873529127};\\\", \\\"{x:1357,y:719,t:1527873529414};\\\", \\\"{x:1358,y:719,t:1527873532390};\\\", \\\"{x:1360,y:719,t:1527873532398};\\\", \\\"{x:1364,y:721,t:1527873532414};\\\", \\\"{x:1371,y:726,t:1527873532431};\\\", \\\"{x:1378,y:739,t:1527873532447};\\\", \\\"{x:1383,y:747,t:1527873532464};\\\", \\\"{x:1386,y:753,t:1527873532482};\\\", \\\"{x:1388,y:755,t:1527873532497};\\\", \\\"{x:1388,y:758,t:1527873532514};\\\", \\\"{x:1388,y:759,t:1527873532531};\\\", \\\"{x:1388,y:761,t:1527873532548};\\\", \\\"{x:1388,y:762,t:1527873532564};\\\", \\\"{x:1388,y:765,t:1527873532581};\\\", \\\"{x:1388,y:768,t:1527873532598};\\\", \\\"{x:1388,y:774,t:1527873532615};\\\", \\\"{x:1388,y:780,t:1527873532630};\\\", \\\"{x:1388,y:786,t:1527873532648};\\\", \\\"{x:1388,y:792,t:1527873532664};\\\", \\\"{x:1388,y:794,t:1527873532680};\\\", \\\"{x:1388,y:795,t:1527873532709};\\\", \\\"{x:1388,y:796,t:1527873532724};\\\", \\\"{x:1388,y:797,t:1527873532749};\\\", \\\"{x:1390,y:801,t:1527873532765};\\\", \\\"{x:1390,y:809,t:1527873532780};\\\", \\\"{x:1391,y:819,t:1527873532798};\\\", \\\"{x:1392,y:834,t:1527873532814};\\\", \\\"{x:1394,y:851,t:1527873532830};\\\", \\\"{x:1394,y:870,t:1527873532848};\\\", \\\"{x:1394,y:891,t:1527873532865};\\\", \\\"{x:1394,y:909,t:1527873532881};\\\", \\\"{x:1394,y:928,t:1527873532898};\\\", \\\"{x:1394,y:940,t:1527873532916};\\\", \\\"{x:1393,y:957,t:1527873532931};\\\", \\\"{x:1393,y:969,t:1527873532948};\\\", \\\"{x:1393,y:974,t:1527873532965};\\\", \\\"{x:1393,y:975,t:1527873532982};\\\", \\\"{x:1393,y:977,t:1527873533430};\\\", \\\"{x:1393,y:978,t:1527873533438};\\\", \\\"{x:1393,y:979,t:1527873533449};\\\", \\\"{x:1394,y:979,t:1527873533465};\\\", \\\"{x:1394,y:983,t:1527873533483};\\\", \\\"{x:1394,y:985,t:1527873533499};\\\", \\\"{x:1394,y:986,t:1527873533516};\\\", \\\"{x:1394,y:988,t:1527873533533};\\\", \\\"{x:1394,y:989,t:1527873533573};\\\", \\\"{x:1393,y:990,t:1527873533582};\\\", \\\"{x:1391,y:990,t:1527873533718};\\\", \\\"{x:1388,y:987,t:1527873533733};\\\", \\\"{x:1385,y:974,t:1527873533749};\\\", \\\"{x:1379,y:959,t:1527873533766};\\\", \\\"{x:1374,y:940,t:1527873533783};\\\", \\\"{x:1369,y:919,t:1527873533800};\\\", \\\"{x:1361,y:902,t:1527873533816};\\\", \\\"{x:1358,y:888,t:1527873533833};\\\", \\\"{x:1353,y:874,t:1527873533850};\\\", \\\"{x:1349,y:861,t:1527873533866};\\\", \\\"{x:1346,y:852,t:1527873533884};\\\", \\\"{x:1345,y:850,t:1527873533900};\\\", \\\"{x:1345,y:859,t:1527873534006};\\\", \\\"{x:1345,y:872,t:1527873534018};\\\", \\\"{x:1345,y:895,t:1527873534034};\\\", \\\"{x:1345,y:907,t:1527873534050};\\\", \\\"{x:1345,y:918,t:1527873534067};\\\", \\\"{x:1345,y:924,t:1527873534084};\\\", \\\"{x:1345,y:932,t:1527873534100};\\\", \\\"{x:1345,y:940,t:1527873534117};\\\", \\\"{x:1345,y:942,t:1527873534134};\\\", \\\"{x:1343,y:942,t:1527873534238};\\\", \\\"{x:1342,y:942,t:1527873534250};\\\", \\\"{x:1339,y:942,t:1527873534267};\\\", \\\"{x:1335,y:937,t:1527873534284};\\\", \\\"{x:1331,y:924,t:1527873534302};\\\", \\\"{x:1330,y:917,t:1527873534318};\\\", \\\"{x:1330,y:909,t:1527873534334};\\\", \\\"{x:1330,y:901,t:1527873534352};\\\", \\\"{x:1330,y:897,t:1527873534367};\\\", \\\"{x:1330,y:893,t:1527873534384};\\\", \\\"{x:1330,y:890,t:1527873534401};\\\", \\\"{x:1330,y:887,t:1527873534418};\\\", \\\"{x:1330,y:886,t:1527873534433};\\\", \\\"{x:1330,y:884,t:1527873534451};\\\", \\\"{x:1331,y:883,t:1527873534477};\\\", \\\"{x:1332,y:883,t:1527873534500};\\\", \\\"{x:1334,y:883,t:1527873534518};\\\", \\\"{x:1336,y:884,t:1527873534534};\\\", \\\"{x:1337,y:884,t:1527873534551};\\\", \\\"{x:1338,y:884,t:1527873534630};\\\", \\\"{x:1340,y:885,t:1527873534637};\\\", \\\"{x:1341,y:886,t:1527873534651};\\\", \\\"{x:1343,y:886,t:1527873534667};\\\", \\\"{x:1346,y:888,t:1527873534684};\\\", \\\"{x:1348,y:890,t:1527873534701};\\\", \\\"{x:1350,y:891,t:1527873534718};\\\", \\\"{x:1351,y:893,t:1527873534735};\\\", \\\"{x:1353,y:896,t:1527873534751};\\\", \\\"{x:1354,y:897,t:1527873534768};\\\", \\\"{x:1354,y:899,t:1527873534785};\\\", \\\"{x:1354,y:900,t:1527873534801};\\\", \\\"{x:1355,y:903,t:1527873534818};\\\", \\\"{x:1356,y:904,t:1527873534835};\\\", \\\"{x:1357,y:905,t:1527873534851};\\\", \\\"{x:1357,y:906,t:1527873534870};\\\", \\\"{x:1357,y:907,t:1527873534894};\\\", \\\"{x:1358,y:907,t:1527873534912};\\\", \\\"{x:1360,y:909,t:1527873534937};\\\", \\\"{x:1361,y:909,t:1527873534952};\\\", \\\"{x:1362,y:909,t:1527873534963};\\\", \\\"{x:1365,y:909,t:1527873534979};\\\", \\\"{x:1368,y:909,t:1527873534996};\\\", \\\"{x:1374,y:906,t:1527873535013};\\\", \\\"{x:1381,y:899,t:1527873535030};\\\", \\\"{x:1389,y:895,t:1527873535047};\\\", \\\"{x:1392,y:893,t:1527873535063};\\\", \\\"{x:1393,y:892,t:1527873535080};\\\", \\\"{x:1392,y:892,t:1527873535360};\\\", \\\"{x:1390,y:892,t:1527873535368};\\\", \\\"{x:1389,y:893,t:1527873535383};\\\", \\\"{x:1388,y:893,t:1527873535399};\\\", \\\"{x:1387,y:893,t:1527873535439};\\\", \\\"{x:1386,y:893,t:1527873535681};\\\", \\\"{x:1389,y:893,t:1527873536048};\\\", \\\"{x:1398,y:892,t:1527873536064};\\\", \\\"{x:1406,y:891,t:1527873536081};\\\", \\\"{x:1411,y:890,t:1527873536098};\\\", \\\"{x:1415,y:890,t:1527873536115};\\\", \\\"{x:1416,y:890,t:1527873536131};\\\", \\\"{x:1417,y:890,t:1527873536169};\\\", \\\"{x:1420,y:890,t:1527873536200};\\\", \\\"{x:1421,y:890,t:1527873536216};\\\", \\\"{x:1422,y:890,t:1527873536232};\\\", \\\"{x:1423,y:890,t:1527873536432};\\\", \\\"{x:1426,y:890,t:1527873536449};\\\", \\\"{x:1430,y:890,t:1527873536465};\\\", \\\"{x:1433,y:890,t:1527873536705};\\\", \\\"{x:1439,y:890,t:1527873536716};\\\", \\\"{x:1464,y:879,t:1527873536732};\\\", \\\"{x:1488,y:862,t:1527873536749};\\\", \\\"{x:1507,y:851,t:1527873536766};\\\", \\\"{x:1521,y:844,t:1527873536782};\\\", \\\"{x:1537,y:833,t:1527873536798};\\\", \\\"{x:1579,y:808,t:1527873536815};\\\", \\\"{x:1607,y:793,t:1527873536832};\\\", \\\"{x:1633,y:778,t:1527873536848};\\\", \\\"{x:1645,y:771,t:1527873536866};\\\", \\\"{x:1649,y:767,t:1527873536882};\\\", \\\"{x:1653,y:763,t:1527873536898};\\\", \\\"{x:1655,y:761,t:1527873536916};\\\", \\\"{x:1656,y:760,t:1527873536933};\\\", \\\"{x:1656,y:763,t:1527873537488};\\\", \\\"{x:1656,y:771,t:1527873537500};\\\", \\\"{x:1656,y:787,t:1527873537517};\\\", \\\"{x:1652,y:802,t:1527873537534};\\\", \\\"{x:1646,y:814,t:1527873537550};\\\", \\\"{x:1643,y:820,t:1527873537567};\\\", \\\"{x:1639,y:825,t:1527873537584};\\\", \\\"{x:1635,y:829,t:1527873537600};\\\", \\\"{x:1628,y:835,t:1527873537617};\\\", \\\"{x:1620,y:839,t:1527873537634};\\\", \\\"{x:1609,y:845,t:1527873537651};\\\", \\\"{x:1596,y:850,t:1527873537667};\\\", \\\"{x:1584,y:855,t:1527873537684};\\\", \\\"{x:1573,y:858,t:1527873537701};\\\", \\\"{x:1560,y:862,t:1527873537717};\\\", \\\"{x:1543,y:865,t:1527873537734};\\\", \\\"{x:1527,y:867,t:1527873537751};\\\", \\\"{x:1517,y:867,t:1527873537768};\\\", \\\"{x:1515,y:867,t:1527873537784};\\\", \\\"{x:1514,y:867,t:1527873537801};\\\", \\\"{x:1512,y:867,t:1527873537952};\\\", \\\"{x:1510,y:866,t:1527873537968};\\\", \\\"{x:1507,y:864,t:1527873537985};\\\", \\\"{x:1506,y:864,t:1527873538001};\\\", \\\"{x:1505,y:861,t:1527873538018};\\\", \\\"{x:1503,y:856,t:1527873538035};\\\", \\\"{x:1502,y:855,t:1527873538064};\\\", \\\"{x:1501,y:854,t:1527873538072};\\\", \\\"{x:1500,y:853,t:1527873538096};\\\", \\\"{x:1499,y:853,t:1527873538137};\\\", \\\"{x:1498,y:853,t:1527873538152};\\\", \\\"{x:1497,y:853,t:1527873538168};\\\", \\\"{x:1496,y:852,t:1527873538185};\\\", \\\"{x:1494,y:851,t:1527873538202};\\\", \\\"{x:1490,y:848,t:1527873538218};\\\", \\\"{x:1486,y:841,t:1527873538235};\\\", \\\"{x:1484,y:835,t:1527873538252};\\\", \\\"{x:1479,y:828,t:1527873538267};\\\", \\\"{x:1477,y:825,t:1527873538285};\\\", \\\"{x:1477,y:824,t:1527873538301};\\\", \\\"{x:1476,y:824,t:1527873538318};\\\", \\\"{x:1476,y:823,t:1527873538367};\\\", \\\"{x:1475,y:823,t:1527873538376};\\\", \\\"{x:1474,y:822,t:1527873538399};\\\", \\\"{x:1475,y:822,t:1527873538535};\\\", \\\"{x:1477,y:825,t:1527873538552};\\\", \\\"{x:1479,y:827,t:1527873538569};\\\", \\\"{x:1481,y:830,t:1527873538585};\\\", \\\"{x:1482,y:831,t:1527873538608};\\\", \\\"{x:1484,y:832,t:1527873538656};\\\", \\\"{x:1485,y:833,t:1527873538720};\\\", \\\"{x:1485,y:840,t:1527873540594};\\\", \\\"{x:1485,y:848,t:1527873540606};\\\", \\\"{x:1485,y:857,t:1527873540622};\\\", \\\"{x:1485,y:866,t:1527873540640};\\\", \\\"{x:1485,y:870,t:1527873540656};\\\", \\\"{x:1485,y:872,t:1527873540672};\\\", \\\"{x:1485,y:874,t:1527873540689};\\\", \\\"{x:1485,y:876,t:1527873540706};\\\", \\\"{x:1485,y:877,t:1527873540723};\\\", \\\"{x:1485,y:878,t:1527873540739};\\\", \\\"{x:1485,y:879,t:1527873540756};\\\", \\\"{x:1485,y:880,t:1527873540773};\\\", \\\"{x:1485,y:881,t:1527873540800};\\\", \\\"{x:1485,y:878,t:1527873540929};\\\", \\\"{x:1485,y:871,t:1527873540941};\\\", \\\"{x:1485,y:863,t:1527873540956};\\\", \\\"{x:1485,y:860,t:1527873540974};\\\", \\\"{x:1485,y:854,t:1527873540990};\\\", \\\"{x:1485,y:847,t:1527873541006};\\\", \\\"{x:1485,y:843,t:1527873541023};\\\", \\\"{x:1485,y:836,t:1527873541040};\\\", \\\"{x:1485,y:832,t:1527873541056};\\\", \\\"{x:1485,y:826,t:1527873541073};\\\", \\\"{x:1485,y:822,t:1527873541091};\\\", \\\"{x:1485,y:821,t:1527873541107};\\\", \\\"{x:1485,y:820,t:1527873541123};\\\", \\\"{x:1485,y:826,t:1527873541265};\\\", \\\"{x:1485,y:834,t:1527873541274};\\\", \\\"{x:1485,y:848,t:1527873541291};\\\", \\\"{x:1485,y:861,t:1527873541307};\\\", \\\"{x:1485,y:869,t:1527873541324};\\\", \\\"{x:1485,y:879,t:1527873541340};\\\", \\\"{x:1485,y:889,t:1527873541357};\\\", \\\"{x:1484,y:899,t:1527873541374};\\\", \\\"{x:1483,y:913,t:1527873541390};\\\", \\\"{x:1483,y:926,t:1527873541407};\\\", \\\"{x:1482,y:942,t:1527873541424};\\\", \\\"{x:1480,y:953,t:1527873541441};\\\", \\\"{x:1478,y:963,t:1527873541457};\\\", \\\"{x:1478,y:969,t:1527873541475};\\\", \\\"{x:1477,y:974,t:1527873541491};\\\", \\\"{x:1477,y:976,t:1527873541507};\\\", \\\"{x:1477,y:981,t:1527873541524};\\\", \\\"{x:1477,y:985,t:1527873541542};\\\", \\\"{x:1476,y:988,t:1527873541557};\\\", \\\"{x:1476,y:990,t:1527873541574};\\\", \\\"{x:1475,y:991,t:1527873541591};\\\", \\\"{x:1477,y:987,t:1527873541799};\\\", \\\"{x:1478,y:983,t:1527873541807};\\\", \\\"{x:1483,y:977,t:1527873541824};\\\", \\\"{x:1488,y:973,t:1527873541841};\\\", \\\"{x:1492,y:970,t:1527873541858};\\\", \\\"{x:1496,y:967,t:1527873541874};\\\", \\\"{x:1500,y:964,t:1527873541891};\\\", \\\"{x:1503,y:964,t:1527873541907};\\\", \\\"{x:1506,y:963,t:1527873541924};\\\", \\\"{x:1511,y:962,t:1527873541941};\\\", \\\"{x:1516,y:962,t:1527873541958};\\\", \\\"{x:1520,y:962,t:1527873541975};\\\", \\\"{x:1526,y:960,t:1527873541991};\\\", \\\"{x:1532,y:960,t:1527873542008};\\\", \\\"{x:1535,y:960,t:1527873542025};\\\", \\\"{x:1536,y:960,t:1527873542042};\\\", \\\"{x:1537,y:960,t:1527873542632};\\\", \\\"{x:1537,y:958,t:1527873542648};\\\", \\\"{x:1537,y:957,t:1527873542659};\\\", \\\"{x:1537,y:954,t:1527873542676};\\\", \\\"{x:1537,y:953,t:1527873542696};\\\", \\\"{x:1537,y:951,t:1527873542712};\\\", \\\"{x:1537,y:950,t:1527873542728};\\\", \\\"{x:1537,y:949,t:1527873542743};\\\", \\\"{x:1536,y:947,t:1527873542759};\\\", \\\"{x:1532,y:940,t:1527873542776};\\\", \\\"{x:1528,y:934,t:1527873542793};\\\", \\\"{x:1524,y:928,t:1527873542810};\\\", \\\"{x:1522,y:922,t:1527873542826};\\\", \\\"{x:1517,y:915,t:1527873542843};\\\", \\\"{x:1514,y:909,t:1527873542860};\\\", \\\"{x:1513,y:905,t:1527873542877};\\\", \\\"{x:1512,y:901,t:1527873542893};\\\", \\\"{x:1510,y:895,t:1527873542910};\\\", \\\"{x:1507,y:887,t:1527873542927};\\\", \\\"{x:1506,y:882,t:1527873542943};\\\", \\\"{x:1503,y:873,t:1527873542960};\\\", \\\"{x:1502,y:867,t:1527873542977};\\\", \\\"{x:1501,y:861,t:1527873542993};\\\", \\\"{x:1499,y:854,t:1527873543010};\\\", \\\"{x:1498,y:847,t:1527873543027};\\\", \\\"{x:1496,y:843,t:1527873543043};\\\", \\\"{x:1495,y:839,t:1527873543060};\\\", \\\"{x:1493,y:836,t:1527873543077};\\\", \\\"{x:1492,y:834,t:1527873543093};\\\", \\\"{x:1492,y:833,t:1527873543110};\\\", \\\"{x:1491,y:833,t:1527873543127};\\\", \\\"{x:1490,y:832,t:1527873543168};\\\", \\\"{x:1488,y:831,t:1527873543192};\\\", \\\"{x:1487,y:831,t:1527873543208};\\\", \\\"{x:1486,y:831,t:1527873543312};\\\", \\\"{x:1485,y:831,t:1527873543327};\\\", \\\"{x:1482,y:831,t:1527873543344};\\\", \\\"{x:1480,y:831,t:1527873543360};\\\", \\\"{x:1479,y:831,t:1527873543392};\\\", \\\"{x:1477,y:831,t:1527873544352};\\\", \\\"{x:1476,y:831,t:1527873544362};\\\", \\\"{x:1472,y:831,t:1527873544380};\\\", \\\"{x:1468,y:829,t:1527873544396};\\\", \\\"{x:1463,y:829,t:1527873544412};\\\", \\\"{x:1459,y:829,t:1527873544429};\\\", \\\"{x:1455,y:829,t:1527873544446};\\\", \\\"{x:1450,y:830,t:1527873544462};\\\", \\\"{x:1448,y:830,t:1527873544479};\\\", \\\"{x:1440,y:833,t:1527873544495};\\\", \\\"{x:1438,y:833,t:1527873544511};\\\", \\\"{x:1436,y:834,t:1527873544529};\\\", \\\"{x:1433,y:834,t:1527873544546};\\\", \\\"{x:1430,y:834,t:1527873544562};\\\", \\\"{x:1424,y:835,t:1527873544578};\\\", \\\"{x:1415,y:836,t:1527873544596};\\\", \\\"{x:1411,y:837,t:1527873544612};\\\", \\\"{x:1406,y:837,t:1527873544629};\\\", \\\"{x:1404,y:838,t:1527873544645};\\\", \\\"{x:1403,y:838,t:1527873544663};\\\", \\\"{x:1400,y:839,t:1527873544679};\\\", \\\"{x:1394,y:839,t:1527873544696};\\\", \\\"{x:1389,y:839,t:1527873544713};\\\", \\\"{x:1383,y:839,t:1527873544730};\\\", \\\"{x:1377,y:839,t:1527873544746};\\\", \\\"{x:1372,y:839,t:1527873544763};\\\", \\\"{x:1368,y:839,t:1527873544780};\\\", \\\"{x:1367,y:839,t:1527873544796};\\\", \\\"{x:1365,y:839,t:1527873544813};\\\", \\\"{x:1364,y:839,t:1527873544830};\\\", \\\"{x:1362,y:839,t:1527873544846};\\\", \\\"{x:1360,y:839,t:1527873544863};\\\", \\\"{x:1358,y:839,t:1527873544880};\\\", \\\"{x:1357,y:840,t:1527873544897};\\\", \\\"{x:1356,y:840,t:1527873544913};\\\", \\\"{x:1355,y:840,t:1527873544931};\\\", \\\"{x:1354,y:840,t:1527873544947};\\\", \\\"{x:1353,y:840,t:1527873545032};\\\", \\\"{x:1354,y:840,t:1527873545201};\\\", \\\"{x:1355,y:840,t:1527873545214};\\\", \\\"{x:1359,y:840,t:1527873545231};\\\", \\\"{x:1362,y:840,t:1527873545247};\\\", \\\"{x:1364,y:840,t:1527873545263};\\\", \\\"{x:1366,y:840,t:1527873545280};\\\", \\\"{x:1369,y:840,t:1527873545296};\\\", \\\"{x:1372,y:839,t:1527873545313};\\\", \\\"{x:1377,y:839,t:1527873545330};\\\", \\\"{x:1384,y:838,t:1527873545347};\\\", \\\"{x:1388,y:838,t:1527873545363};\\\", \\\"{x:1394,y:837,t:1527873545381};\\\", \\\"{x:1400,y:836,t:1527873545397};\\\", \\\"{x:1408,y:836,t:1527873545414};\\\", \\\"{x:1416,y:836,t:1527873545431};\\\", \\\"{x:1424,y:835,t:1527873545447};\\\", \\\"{x:1435,y:834,t:1527873545463};\\\", \\\"{x:1442,y:834,t:1527873545480};\\\", \\\"{x:1446,y:834,t:1527873545498};\\\", \\\"{x:1448,y:832,t:1527873545513};\\\", \\\"{x:1451,y:831,t:1527873545531};\\\", \\\"{x:1453,y:831,t:1527873545551};\\\", \\\"{x:1454,y:831,t:1527873545583};\\\", \\\"{x:1455,y:831,t:1527873545600};\\\", \\\"{x:1456,y:831,t:1527873545615};\\\", \\\"{x:1457,y:831,t:1527873545631};\\\", \\\"{x:1459,y:831,t:1527873545649};\\\", \\\"{x:1461,y:830,t:1527873545673};\\\", \\\"{x:1467,y:830,t:1527873546761};\\\", \\\"{x:1474,y:830,t:1527873546768};\\\", \\\"{x:1481,y:830,t:1527873546784};\\\", \\\"{x:1503,y:830,t:1527873546799};\\\", \\\"{x:1514,y:830,t:1527873546815};\\\", \\\"{x:1524,y:830,t:1527873546832};\\\", \\\"{x:1529,y:830,t:1527873546850};\\\", \\\"{x:1530,y:830,t:1527873546867};\\\", \\\"{x:1531,y:830,t:1527873546883};\\\", \\\"{x:1532,y:830,t:1527873546959};\\\", \\\"{x:1528,y:828,t:1527873547176};\\\", \\\"{x:1518,y:823,t:1527873547184};\\\", \\\"{x:1496,y:814,t:1527873547200};\\\", \\\"{x:1477,y:806,t:1527873547217};\\\", \\\"{x:1468,y:804,t:1527873547234};\\\", \\\"{x:1467,y:804,t:1527873547272};\\\", \\\"{x:1465,y:804,t:1527873547285};\\\", \\\"{x:1463,y:804,t:1527873547302};\\\", \\\"{x:1462,y:804,t:1527873547317};\\\", \\\"{x:1460,y:804,t:1527873547335};\\\", \\\"{x:1459,y:804,t:1527873547352};\\\", \\\"{x:1456,y:806,t:1527873547433};\\\", \\\"{x:1455,y:807,t:1527873547448};\\\", \\\"{x:1454,y:808,t:1527873547456};\\\", \\\"{x:1452,y:810,t:1527873547469};\\\", \\\"{x:1450,y:813,t:1527873547485};\\\", \\\"{x:1447,y:816,t:1527873547502};\\\", \\\"{x:1445,y:818,t:1527873547518};\\\", \\\"{x:1444,y:819,t:1527873547534};\\\", \\\"{x:1442,y:821,t:1527873547551};\\\", \\\"{x:1441,y:825,t:1527873547568};\\\", \\\"{x:1439,y:827,t:1527873547584};\\\", \\\"{x:1438,y:827,t:1527873547601};\\\", \\\"{x:1436,y:830,t:1527873547618};\\\", \\\"{x:1435,y:831,t:1527873547636};\\\", \\\"{x:1433,y:832,t:1527873547651};\\\", \\\"{x:1433,y:833,t:1527873547669};\\\", \\\"{x:1432,y:833,t:1527873547686};\\\", \\\"{x:1431,y:833,t:1527873547701};\\\", \\\"{x:1430,y:835,t:1527873547719};\\\", \\\"{x:1429,y:835,t:1527873547736};\\\", \\\"{x:1428,y:835,t:1527873547752};\\\", \\\"{x:1427,y:835,t:1527873547768};\\\", \\\"{x:1426,y:835,t:1527873547786};\\\", \\\"{x:1423,y:835,t:1527873547801};\\\", \\\"{x:1417,y:835,t:1527873547818};\\\", \\\"{x:1403,y:830,t:1527873547836};\\\", \\\"{x:1382,y:825,t:1527873547853};\\\", \\\"{x:1361,y:816,t:1527873547869};\\\", \\\"{x:1340,y:808,t:1527873547885};\\\", \\\"{x:1320,y:801,t:1527873547902};\\\", \\\"{x:1298,y:791,t:1527873547919};\\\", \\\"{x:1269,y:781,t:1527873547936};\\\", \\\"{x:1199,y:760,t:1527873547952};\\\", \\\"{x:1143,y:745,t:1527873547969};\\\", \\\"{x:1102,y:735,t:1527873547986};\\\", \\\"{x:1060,y:728,t:1527873548002};\\\", \\\"{x:1020,y:723,t:1527873548019};\\\", \\\"{x:972,y:715,t:1527873548035};\\\", \\\"{x:917,y:709,t:1527873548052};\\\", \\\"{x:856,y:709,t:1527873548069};\\\", \\\"{x:822,y:709,t:1527873548086};\\\", \\\"{x:799,y:709,t:1527873548102};\\\", \\\"{x:761,y:709,t:1527873548119};\\\", \\\"{x:730,y:709,t:1527873548136};\\\", \\\"{x:700,y:709,t:1527873548152};\\\", \\\"{x:678,y:709,t:1527873548169};\\\", \\\"{x:665,y:709,t:1527873548185};\\\", \\\"{x:655,y:709,t:1527873548202};\\\", \\\"{x:644,y:711,t:1527873548220};\\\", \\\"{x:634,y:712,t:1527873548236};\\\", \\\"{x:622,y:712,t:1527873548252};\\\", \\\"{x:611,y:712,t:1527873548269};\\\", \\\"{x:594,y:712,t:1527873548286};\\\", \\\"{x:570,y:708,t:1527873548302};\\\", \\\"{x:535,y:700,t:1527873548319};\\\", \\\"{x:515,y:697,t:1527873548335};\\\", \\\"{x:503,y:696,t:1527873548351};\\\", \\\"{x:499,y:696,t:1527873548369};\\\", \\\"{x:497,y:696,t:1527873548386};\\\", \\\"{x:494,y:696,t:1527873548402};\\\", \\\"{x:492,y:696,t:1527873548419};\\\", \\\"{x:489,y:700,t:1527873548436};\\\", \\\"{x:488,y:703,t:1527873548453};\\\", \\\"{x:488,y:705,t:1527873548469};\\\", \\\"{x:486,y:707,t:1527873548486};\\\", \\\"{x:485,y:710,t:1527873548503};\\\", \\\"{x:484,y:713,t:1527873548520};\\\", \\\"{x:484,y:716,t:1527873548535};\\\", \\\"{x:484,y:718,t:1527873548553};\\\", \\\"{x:484,y:721,t:1527873548570};\\\", \\\"{x:483,y:722,t:1527873548586};\\\", \\\"{x:483,y:723,t:1527873548602};\\\", \\\"{x:483,y:724,t:1527873548621};\\\", \\\"{x:483,y:726,t:1527873548639};\\\", \\\"{x:483,y:727,t:1527873548654};\\\", \\\"{x:483,y:729,t:1527873548672};\\\", \\\"{x:483,y:730,t:1527873549479};\\\", \\\"{x:497,y:723,t:1527873549491};\\\", \\\"{x:554,y:688,t:1527873549508};\\\", \\\"{x:624,y:655,t:1527873549524};\\\", \\\"{x:687,y:627,t:1527873549541};\\\", \\\"{x:734,y:607,t:1527873549558};\\\", \\\"{x:769,y:589,t:1527873549574};\\\", \\\"{x:793,y:575,t:1527873549591};\\\", \\\"{x:821,y:563,t:1527873549608};\\\", \\\"{x:830,y:556,t:1527873549624};\\\", \\\"{x:833,y:555,t:1527873549641};\\\", \\\"{x:834,y:554,t:1527873549658};\\\", \\\"{x:835,y:554,t:1527873549687};\\\" ] }, { \\\"rt\\\": 60815, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 796026, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-X -X -X -B -B -X -M -M -M -X -F -F -B -12 PM-01 PM-02 PM-X -X -02 PM-01 PM-12 PM-12 PM-12 PM-B -F -B -12 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:793,y:483,t:1527873551036};\\\", \\\"{x:787,y:473,t:1527873551042};\\\", \\\"{x:769,y:452,t:1527873551059};\\\", \\\"{x:739,y:422,t:1527873551075};\\\", \\\"{x:711,y:395,t:1527873551091};\\\", \\\"{x:671,y:366,t:1527873551109};\\\", \\\"{x:619,y:334,t:1527873551125};\\\", \\\"{x:552,y:305,t:1527873551142};\\\", \\\"{x:486,y:279,t:1527873551159};\\\", \\\"{x:458,y:268,t:1527873551175};\\\", \\\"{x:451,y:267,t:1527873551192};\\\", \\\"{x:448,y:267,t:1527873551209};\\\", \\\"{x:442,y:267,t:1527873551225};\\\", \\\"{x:430,y:270,t:1527873551242};\\\", \\\"{x:401,y:278,t:1527873551259};\\\", \\\"{x:366,y:295,t:1527873551275};\\\", \\\"{x:316,y:316,t:1527873551292};\\\", \\\"{x:249,y:348,t:1527873551309};\\\", \\\"{x:210,y:366,t:1527873551325};\\\", \\\"{x:179,y:380,t:1527873551342};\\\", \\\"{x:156,y:390,t:1527873551359};\\\", \\\"{x:140,y:399,t:1527873551375};\\\", \\\"{x:125,y:406,t:1527873551392};\\\", \\\"{x:121,y:409,t:1527873551409};\\\", \\\"{x:120,y:409,t:1527873551426};\\\", \\\"{x:125,y:407,t:1527873551808};\\\", \\\"{x:140,y:398,t:1527873551815};\\\", \\\"{x:156,y:388,t:1527873551825};\\\", \\\"{x:207,y:364,t:1527873551842};\\\", \\\"{x:268,y:353,t:1527873551859};\\\", \\\"{x:363,y:353,t:1527873551875};\\\", \\\"{x:460,y:353,t:1527873551893};\\\", \\\"{x:550,y:348,t:1527873551909};\\\", \\\"{x:639,y:335,t:1527873551925};\\\", \\\"{x:731,y:321,t:1527873551942};\\\", \\\"{x:849,y:303,t:1527873551960};\\\", \\\"{x:933,y:292,t:1527873551975};\\\", \\\"{x:1019,y:280,t:1527873551993};\\\", \\\"{x:1105,y:269,t:1527873552009};\\\", \\\"{x:1183,y:256,t:1527873552025};\\\", \\\"{x:1244,y:256,t:1527873552042};\\\", \\\"{x:1283,y:256,t:1527873552060};\\\", \\\"{x:1309,y:256,t:1527873552075};\\\", \\\"{x:1318,y:256,t:1527873552092};\\\", \\\"{x:1319,y:256,t:1527873552110};\\\", \\\"{x:1319,y:264,t:1527873552520};\\\", \\\"{x:1304,y:289,t:1527873552528};\\\", \\\"{x:1286,y:322,t:1527873552542};\\\", \\\"{x:1221,y:439,t:1527873552560};\\\", \\\"{x:1194,y:489,t:1527873552576};\\\", \\\"{x:1177,y:513,t:1527873552592};\\\", \\\"{x:1161,y:531,t:1527873552609};\\\", \\\"{x:1142,y:548,t:1527873552626};\\\", \\\"{x:1106,y:563,t:1527873552643};\\\", \\\"{x:1070,y:567,t:1527873552660};\\\", \\\"{x:1041,y:567,t:1527873552675};\\\", \\\"{x:1014,y:569,t:1527873552692};\\\", \\\"{x:993,y:571,t:1527873552710};\\\", \\\"{x:979,y:572,t:1527873552725};\\\", \\\"{x:969,y:571,t:1527873552742};\\\", \\\"{x:954,y:562,t:1527873552760};\\\", \\\"{x:941,y:555,t:1527873552776};\\\", \\\"{x:918,y:537,t:1527873552792};\\\", \\\"{x:880,y:507,t:1527873552809};\\\", \\\"{x:819,y:463,t:1527873552827};\\\", \\\"{x:766,y:425,t:1527873552843};\\\", \\\"{x:722,y:399,t:1527873552860};\\\", \\\"{x:711,y:392,t:1527873552876};\\\", \\\"{x:710,y:391,t:1527873552894};\\\", \\\"{x:711,y:388,t:1527873553328};\\\", \\\"{x:736,y:375,t:1527873553345};\\\", \\\"{x:786,y:351,t:1527873553361};\\\", \\\"{x:858,y:317,t:1527873553377};\\\", \\\"{x:932,y:274,t:1527873553394};\\\", \\\"{x:984,y:243,t:1527873553411};\\\", \\\"{x:1016,y:226,t:1527873553429};\\\", \\\"{x:1034,y:216,t:1527873553445};\\\", \\\"{x:1037,y:214,t:1527873553462};\\\", \\\"{x:1038,y:214,t:1527873553488};\\\", \\\"{x:1041,y:212,t:1527873553504};\\\", \\\"{x:1044,y:211,t:1527873553511};\\\", \\\"{x:1051,y:208,t:1527873553528};\\\", \\\"{x:1055,y:207,t:1527873553544};\\\", \\\"{x:1056,y:206,t:1527873553562};\\\", \\\"{x:1057,y:206,t:1527873553616};\\\", \\\"{x:1061,y:206,t:1527873553628};\\\", \\\"{x:1102,y:208,t:1527873553644};\\\", \\\"{x:1208,y:226,t:1527873553661};\\\", \\\"{x:1301,y:260,t:1527873553679};\\\", \\\"{x:1389,y:320,t:1527873553694};\\\", \\\"{x:1489,y:442,t:1527873553711};\\\", \\\"{x:1535,y:504,t:1527873553728};\\\", \\\"{x:1572,y:548,t:1527873553745};\\\", \\\"{x:1597,y:580,t:1527873553761};\\\", \\\"{x:1614,y:609,t:1527873553779};\\\", \\\"{x:1620,y:630,t:1527873553795};\\\", \\\"{x:1620,y:648,t:1527873553812};\\\", \\\"{x:1612,y:666,t:1527873553829};\\\", \\\"{x:1594,y:702,t:1527873553845};\\\", \\\"{x:1569,y:746,t:1527873553861};\\\", \\\"{x:1538,y:793,t:1527873553879};\\\", \\\"{x:1478,y:863,t:1527873553896};\\\", \\\"{x:1444,y:909,t:1527873553912};\\\", \\\"{x:1414,y:951,t:1527873553929};\\\", \\\"{x:1390,y:983,t:1527873553946};\\\", \\\"{x:1373,y:1002,t:1527873553962};\\\", \\\"{x:1357,y:1019,t:1527873553978};\\\", \\\"{x:1348,y:1029,t:1527873553996};\\\", \\\"{x:1342,y:1040,t:1527873554011};\\\", \\\"{x:1339,y:1050,t:1527873554029};\\\", \\\"{x:1337,y:1060,t:1527873554046};\\\", \\\"{x:1334,y:1072,t:1527873554062};\\\", \\\"{x:1334,y:1082,t:1527873554078};\\\", \\\"{x:1334,y:1089,t:1527873554095};\\\", \\\"{x:1336,y:1088,t:1527873554231};\\\", \\\"{x:1343,y:1083,t:1527873554246};\\\", \\\"{x:1361,y:1073,t:1527873554261};\\\", \\\"{x:1381,y:1062,t:1527873554278};\\\", \\\"{x:1412,y:1048,t:1527873554296};\\\", \\\"{x:1428,y:1039,t:1527873554312};\\\", \\\"{x:1438,y:1032,t:1527873554328};\\\", \\\"{x:1443,y:1028,t:1527873554346};\\\", \\\"{x:1445,y:1026,t:1527873554363};\\\", \\\"{x:1446,y:1026,t:1527873554378};\\\", \\\"{x:1447,y:1025,t:1527873554396};\\\", \\\"{x:1449,y:1023,t:1527873554520};\\\", \\\"{x:1451,y:1020,t:1527873554529};\\\", \\\"{x:1461,y:1006,t:1527873554546};\\\", \\\"{x:1470,y:991,t:1527873554562};\\\", \\\"{x:1480,y:977,t:1527873554579};\\\", \\\"{x:1487,y:966,t:1527873554597};\\\", \\\"{x:1491,y:962,t:1527873554613};\\\", \\\"{x:1492,y:961,t:1527873554629};\\\", \\\"{x:1493,y:962,t:1527873555024};\\\", \\\"{x:1493,y:967,t:1527873555032};\\\", \\\"{x:1494,y:970,t:1527873555046};\\\", \\\"{x:1494,y:967,t:1527873555249};\\\", \\\"{x:1491,y:956,t:1527873555263};\\\", \\\"{x:1486,y:928,t:1527873555280};\\\", \\\"{x:1484,y:912,t:1527873555296};\\\", \\\"{x:1479,y:894,t:1527873555313};\\\", \\\"{x:1474,y:877,t:1527873555329};\\\", \\\"{x:1469,y:861,t:1527873555347};\\\", \\\"{x:1468,y:856,t:1527873555363};\\\", \\\"{x:1468,y:848,t:1527873555380};\\\", \\\"{x:1466,y:841,t:1527873555397};\\\", \\\"{x:1465,y:835,t:1527873555412};\\\", \\\"{x:1464,y:830,t:1527873555430};\\\", \\\"{x:1464,y:825,t:1527873555447};\\\", \\\"{x:1464,y:822,t:1527873555462};\\\", \\\"{x:1462,y:816,t:1527873555479};\\\", \\\"{x:1462,y:814,t:1527873555496};\\\", \\\"{x:1461,y:810,t:1527873555513};\\\", \\\"{x:1461,y:808,t:1527873555530};\\\", \\\"{x:1461,y:807,t:1527873555546};\\\", \\\"{x:1461,y:806,t:1527873555568};\\\", \\\"{x:1460,y:805,t:1527873555584};\\\", \\\"{x:1460,y:807,t:1527873555728};\\\", \\\"{x:1460,y:809,t:1527873555736};\\\", \\\"{x:1461,y:811,t:1527873555747};\\\", \\\"{x:1463,y:815,t:1527873555764};\\\", \\\"{x:1464,y:819,t:1527873555779};\\\", \\\"{x:1466,y:821,t:1527873555797};\\\", \\\"{x:1466,y:823,t:1527873555813};\\\", \\\"{x:1467,y:823,t:1527873555830};\\\", \\\"{x:1468,y:827,t:1527873556496};\\\", \\\"{x:1468,y:828,t:1527873556504};\\\", \\\"{x:1469,y:829,t:1527873556513};\\\", \\\"{x:1470,y:832,t:1527873556531};\\\", \\\"{x:1470,y:834,t:1527873556548};\\\", \\\"{x:1470,y:835,t:1527873556563};\\\", \\\"{x:1470,y:836,t:1527873556581};\\\", \\\"{x:1471,y:837,t:1527873558967};\\\", \\\"{x:1474,y:837,t:1527873559876};\\\", \\\"{x:1475,y:837,t:1527873559883};\\\", \\\"{x:1476,y:837,t:1527873559898};\\\", \\\"{x:1477,y:837,t:1527873559918};\\\", \\\"{x:1478,y:837,t:1527873559935};\\\", \\\"{x:1479,y:837,t:1527873559951};\\\", \\\"{x:1480,y:836,t:1527873560254};\\\", \\\"{x:1481,y:834,t:1527873560271};\\\", \\\"{x:1482,y:833,t:1527873560299};\\\", \\\"{x:1482,y:829,t:1527873565792};\\\", \\\"{x:1482,y:828,t:1527873565805};\\\", \\\"{x:1482,y:826,t:1527873565821};\\\", \\\"{x:1483,y:823,t:1527873565839};\\\", \\\"{x:1483,y:822,t:1527873565855};\\\", \\\"{x:1483,y:823,t:1527873566495};\\\", \\\"{x:1483,y:824,t:1527873566519};\\\", \\\"{x:1483,y:825,t:1527873566536};\\\", \\\"{x:1483,y:826,t:1527873567232};\\\", \\\"{x:1482,y:826,t:1527873569591};\\\", \\\"{x:1465,y:823,t:1527873569608};\\\", \\\"{x:1448,y:819,t:1527873569624};\\\", \\\"{x:1436,y:815,t:1527873569641};\\\", \\\"{x:1428,y:813,t:1527873569658};\\\", \\\"{x:1423,y:813,t:1527873569675};\\\", \\\"{x:1421,y:812,t:1527873569691};\\\", \\\"{x:1420,y:812,t:1527873569708};\\\", \\\"{x:1420,y:811,t:1527873569735};\\\", \\\"{x:1419,y:811,t:1527873569839};\\\", \\\"{x:1413,y:806,t:1527873569858};\\\", \\\"{x:1405,y:801,t:1527873569874};\\\", \\\"{x:1394,y:794,t:1527873569891};\\\", \\\"{x:1384,y:790,t:1527873569909};\\\", \\\"{x:1376,y:787,t:1527873569924};\\\", \\\"{x:1367,y:784,t:1527873569942};\\\", \\\"{x:1359,y:780,t:1527873569958};\\\", \\\"{x:1355,y:780,t:1527873569975};\\\", \\\"{x:1354,y:779,t:1527873569992};\\\", \\\"{x:1353,y:779,t:1527873570007};\\\", \\\"{x:1352,y:779,t:1527873570025};\\\", \\\"{x:1351,y:778,t:1527873570042};\\\", \\\"{x:1350,y:778,t:1527873570058};\\\", \\\"{x:1349,y:778,t:1527873570075};\\\", \\\"{x:1348,y:778,t:1527873570091};\\\", \\\"{x:1348,y:777,t:1527873570108};\\\", \\\"{x:1346,y:777,t:1527873570232};\\\", \\\"{x:1345,y:776,t:1527873570247};\\\", \\\"{x:1344,y:775,t:1527873570262};\\\", \\\"{x:1344,y:774,t:1527873570471};\\\", \\\"{x:1342,y:773,t:1527873570672};\\\", \\\"{x:1342,y:772,t:1527873570695};\\\", \\\"{x:1342,y:771,t:1527873570708};\\\", \\\"{x:1342,y:770,t:1527873570725};\\\", \\\"{x:1342,y:769,t:1527873570742};\\\", \\\"{x:1343,y:768,t:1527873570758};\\\", \\\"{x:1343,y:767,t:1527873570847};\\\", \\\"{x:1344,y:767,t:1527873570936};\\\", \\\"{x:1344,y:766,t:1527873570975};\\\", \\\"{x:1345,y:766,t:1527873570992};\\\", \\\"{x:1345,y:765,t:1527873571031};\\\", \\\"{x:1345,y:764,t:1527873571536};\\\", \\\"{x:1345,y:763,t:1527873571543};\\\", \\\"{x:1346,y:762,t:1527873571559};\\\", \\\"{x:1348,y:761,t:1527873574663};\\\", \\\"{x:1349,y:761,t:1527873574678};\\\", \\\"{x:1351,y:761,t:1527873574695};\\\", \\\"{x:1353,y:761,t:1527873574711};\\\", \\\"{x:1354,y:761,t:1527873574744};\\\", \\\"{x:1355,y:762,t:1527873575527};\\\", \\\"{x:1355,y:763,t:1527873575536};\\\", \\\"{x:1354,y:763,t:1527873575559};\\\", \\\"{x:1353,y:764,t:1527873575583};\\\", \\\"{x:1354,y:764,t:1527873576824};\\\", \\\"{x:1355,y:764,t:1527873576839};\\\", \\\"{x:1356,y:764,t:1527873576855};\\\", \\\"{x:1357,y:764,t:1527873576863};\\\", \\\"{x:1361,y:764,t:1527873576880};\\\", \\\"{x:1366,y:764,t:1527873576896};\\\", \\\"{x:1376,y:765,t:1527873576913};\\\", \\\"{x:1383,y:766,t:1527873576930};\\\", \\\"{x:1390,y:766,t:1527873576948};\\\", \\\"{x:1394,y:766,t:1527873576963};\\\", \\\"{x:1396,y:766,t:1527873576980};\\\", \\\"{x:1397,y:766,t:1527873576997};\\\", \\\"{x:1398,y:766,t:1527873577296};\\\", \\\"{x:1404,y:766,t:1527873577303};\\\", \\\"{x:1411,y:768,t:1527873577313};\\\", \\\"{x:1422,y:768,t:1527873577330};\\\", \\\"{x:1434,y:768,t:1527873577347};\\\", \\\"{x:1443,y:768,t:1527873577364};\\\", \\\"{x:1447,y:768,t:1527873577381};\\\", \\\"{x:1450,y:768,t:1527873577397};\\\", \\\"{x:1453,y:767,t:1527873577415};\\\", \\\"{x:1457,y:767,t:1527873577430};\\\", \\\"{x:1466,y:766,t:1527873577447};\\\", \\\"{x:1470,y:766,t:1527873577464};\\\", \\\"{x:1473,y:766,t:1527873577480};\\\", \\\"{x:1475,y:765,t:1527873577497};\\\", \\\"{x:1476,y:765,t:1527873577515};\\\", \\\"{x:1476,y:764,t:1527873577703};\\\", \\\"{x:1471,y:764,t:1527873577714};\\\", \\\"{x:1443,y:760,t:1527873577731};\\\", \\\"{x:1387,y:760,t:1527873577748};\\\", \\\"{x:1277,y:750,t:1527873577765};\\\", \\\"{x:1138,y:728,t:1527873577782};\\\", \\\"{x:994,y:707,t:1527873577797};\\\", \\\"{x:883,y:693,t:1527873577814};\\\", \\\"{x:741,y:675,t:1527873577831};\\\", \\\"{x:661,y:664,t:1527873577847};\\\", \\\"{x:588,y:656,t:1527873577864};\\\", \\\"{x:528,y:649,t:1527873577881};\\\", \\\"{x:480,y:641,t:1527873577899};\\\", \\\"{x:449,y:635,t:1527873577914};\\\", \\\"{x:436,y:630,t:1527873577931};\\\", \\\"{x:434,y:629,t:1527873577943};\\\", \\\"{x:434,y:628,t:1527873577990};\\\", \\\"{x:434,y:625,t:1527873577998};\\\", \\\"{x:434,y:620,t:1527873578010};\\\", \\\"{x:430,y:610,t:1527873578027};\\\", \\\"{x:421,y:595,t:1527873578044};\\\", \\\"{x:402,y:577,t:1527873578063};\\\", \\\"{x:381,y:566,t:1527873578082};\\\", \\\"{x:355,y:556,t:1527873578097};\\\", \\\"{x:319,y:546,t:1527873578114};\\\", \\\"{x:279,y:533,t:1527873578131};\\\", \\\"{x:238,y:523,t:1527873578149};\\\", \\\"{x:195,y:514,t:1527873578164};\\\", \\\"{x:161,y:504,t:1527873578181};\\\", \\\"{x:134,y:501,t:1527873578198};\\\", \\\"{x:102,y:496,t:1527873578214};\\\", \\\"{x:71,y:496,t:1527873578230};\\\", \\\"{x:65,y:496,t:1527873578247};\\\", \\\"{x:63,y:496,t:1527873578264};\\\", \\\"{x:63,y:497,t:1527873578281};\\\", \\\"{x:63,y:499,t:1527873578298};\\\", \\\"{x:63,y:503,t:1527873578315};\\\", \\\"{x:63,y:508,t:1527873578330};\\\", \\\"{x:64,y:514,t:1527873578348};\\\", \\\"{x:70,y:523,t:1527873578363};\\\", \\\"{x:74,y:529,t:1527873578380};\\\", \\\"{x:81,y:536,t:1527873578398};\\\", \\\"{x:99,y:544,t:1527873578414};\\\", \\\"{x:111,y:547,t:1527873578431};\\\", \\\"{x:122,y:551,t:1527873578448};\\\", \\\"{x:131,y:552,t:1527873578463};\\\", \\\"{x:138,y:553,t:1527873578481};\\\", \\\"{x:145,y:554,t:1527873578497};\\\", \\\"{x:149,y:554,t:1527873578514};\\\", \\\"{x:150,y:555,t:1527873578531};\\\", \\\"{x:152,y:555,t:1527873578548};\\\", \\\"{x:156,y:554,t:1527873579030};\\\", \\\"{x:176,y:546,t:1527873579048};\\\", \\\"{x:208,y:544,t:1527873579065};\\\", \\\"{x:254,y:543,t:1527873579081};\\\", \\\"{x:326,y:543,t:1527873579099};\\\", \\\"{x:420,y:543,t:1527873579115};\\\", \\\"{x:534,y:543,t:1527873579134};\\\", \\\"{x:650,y:543,t:1527873579147};\\\", \\\"{x:780,y:543,t:1527873579165};\\\", \\\"{x:921,y:543,t:1527873579181};\\\", \\\"{x:1038,y:543,t:1527873579198};\\\", \\\"{x:1193,y:556,t:1527873579215};\\\", \\\"{x:1279,y:569,t:1527873579231};\\\", \\\"{x:1337,y:584,t:1527873579248};\\\", \\\"{x:1381,y:600,t:1527873579265};\\\", \\\"{x:1418,y:626,t:1527873579282};\\\", \\\"{x:1441,y:658,t:1527873579298};\\\", \\\"{x:1463,y:703,t:1527873579315};\\\", \\\"{x:1474,y:755,t:1527873579332};\\\", \\\"{x:1482,y:808,t:1527873579348};\\\", \\\"{x:1482,y:831,t:1527873579365};\\\", \\\"{x:1482,y:848,t:1527873579383};\\\", \\\"{x:1477,y:857,t:1527873579398};\\\", \\\"{x:1469,y:866,t:1527873579415};\\\", \\\"{x:1462,y:871,t:1527873579432};\\\", \\\"{x:1458,y:874,t:1527873579448};\\\", \\\"{x:1455,y:874,t:1527873579465};\\\", \\\"{x:1453,y:876,t:1527873579482};\\\", \\\"{x:1451,y:876,t:1527873579499};\\\", \\\"{x:1443,y:877,t:1527873579515};\\\", \\\"{x:1429,y:878,t:1527873579532};\\\", \\\"{x:1408,y:878,t:1527873579549};\\\", \\\"{x:1392,y:878,t:1527873579566};\\\", \\\"{x:1385,y:878,t:1527873579582};\\\", \\\"{x:1379,y:878,t:1527873579599};\\\", \\\"{x:1377,y:878,t:1527873579615};\\\", \\\"{x:1378,y:880,t:1527873579751};\\\", \\\"{x:1380,y:886,t:1527873579765};\\\", \\\"{x:1382,y:899,t:1527873579783};\\\", \\\"{x:1384,y:911,t:1527873579800};\\\", \\\"{x:1385,y:917,t:1527873579815};\\\", \\\"{x:1385,y:920,t:1527873579832};\\\", \\\"{x:1385,y:918,t:1527873580016};\\\", \\\"{x:1385,y:916,t:1527873580032};\\\", \\\"{x:1385,y:913,t:1527873580049};\\\", \\\"{x:1385,y:912,t:1527873580066};\\\", \\\"{x:1385,y:909,t:1527873580082};\\\", \\\"{x:1384,y:908,t:1527873580099};\\\", \\\"{x:1384,y:906,t:1527873580143};\\\", \\\"{x:1384,y:904,t:1527873580172};\\\", \\\"{x:1384,y:903,t:1527873580182};\\\", \\\"{x:1384,y:901,t:1527873580199};\\\", \\\"{x:1384,y:900,t:1527873580216};\\\", \\\"{x:1384,y:899,t:1527873580231};\\\", \\\"{x:1384,y:898,t:1527873580968};\\\", \\\"{x:1399,y:898,t:1527873580984};\\\", \\\"{x:1422,y:898,t:1527873581000};\\\", \\\"{x:1442,y:898,t:1527873581016};\\\", \\\"{x:1463,y:898,t:1527873581034};\\\", \\\"{x:1473,y:898,t:1527873581050};\\\", \\\"{x:1478,y:897,t:1527873581066};\\\", \\\"{x:1480,y:897,t:1527873581084};\\\", \\\"{x:1481,y:897,t:1527873581101};\\\", \\\"{x:1483,y:896,t:1527873581117};\\\", \\\"{x:1487,y:896,t:1527873581134};\\\", \\\"{x:1491,y:896,t:1527873581151};\\\", \\\"{x:1497,y:894,t:1527873581167};\\\", \\\"{x:1498,y:894,t:1527873581184};\\\", \\\"{x:1499,y:894,t:1527873581201};\\\", \\\"{x:1500,y:887,t:1527873583807};\\\", \\\"{x:1500,y:872,t:1527873583819};\\\", \\\"{x:1491,y:837,t:1527873583836};\\\", \\\"{x:1479,y:815,t:1527873583852};\\\", \\\"{x:1460,y:783,t:1527873583869};\\\", \\\"{x:1441,y:751,t:1527873583885};\\\", \\\"{x:1424,y:727,t:1527873583902};\\\", \\\"{x:1418,y:717,t:1527873583919};\\\", \\\"{x:1414,y:708,t:1527873583935};\\\", \\\"{x:1408,y:696,t:1527873583952};\\\", \\\"{x:1402,y:685,t:1527873583970};\\\", \\\"{x:1400,y:680,t:1527873583985};\\\", \\\"{x:1398,y:675,t:1527873584003};\\\", \\\"{x:1398,y:674,t:1527873584020};\\\", \\\"{x:1396,y:672,t:1527873584036};\\\", \\\"{x:1396,y:671,t:1527873584063};\\\", \\\"{x:1394,y:670,t:1527873584079};\\\", \\\"{x:1392,y:670,t:1527873584087};\\\", \\\"{x:1390,y:670,t:1527873584103};\\\", \\\"{x:1387,y:670,t:1527873584119};\\\", \\\"{x:1383,y:670,t:1527873584135};\\\", \\\"{x:1380,y:672,t:1527873584152};\\\", \\\"{x:1375,y:675,t:1527873584170};\\\", \\\"{x:1371,y:677,t:1527873584186};\\\", \\\"{x:1368,y:679,t:1527873584202};\\\", \\\"{x:1366,y:680,t:1527873584220};\\\", \\\"{x:1365,y:680,t:1527873584235};\\\", \\\"{x:1363,y:682,t:1527873584252};\\\", \\\"{x:1363,y:683,t:1527873584269};\\\", \\\"{x:1362,y:683,t:1527873584303};\\\", \\\"{x:1362,y:684,t:1527873584318};\\\", \\\"{x:1360,y:685,t:1527873584337};\\\", \\\"{x:1360,y:686,t:1527873584352};\\\", \\\"{x:1359,y:688,t:1527873584369};\\\", \\\"{x:1358,y:690,t:1527873584391};\\\", \\\"{x:1357,y:690,t:1527873584407};\\\", \\\"{x:1356,y:691,t:1527873584423};\\\", \\\"{x:1355,y:691,t:1527873584439};\\\", \\\"{x:1355,y:692,t:1527873584453};\\\", \\\"{x:1354,y:693,t:1527873584471};\\\", \\\"{x:1353,y:693,t:1527873584503};\\\", \\\"{x:1354,y:693,t:1527873585119};\\\", \\\"{x:1356,y:693,t:1527873585137};\\\", \\\"{x:1357,y:693,t:1527873585343};\\\", \\\"{x:1360,y:693,t:1527873585354};\\\", \\\"{x:1369,y:696,t:1527873585371};\\\", \\\"{x:1380,y:697,t:1527873585387};\\\", \\\"{x:1397,y:700,t:1527873585403};\\\", \\\"{x:1420,y:702,t:1527873585421};\\\", \\\"{x:1438,y:705,t:1527873585437};\\\", \\\"{x:1445,y:705,t:1527873585454};\\\", \\\"{x:1449,y:705,t:1527873585471};\\\", \\\"{x:1450,y:706,t:1527873585639};\\\", \\\"{x:1449,y:711,t:1527873585654};\\\", \\\"{x:1433,y:725,t:1527873585670};\\\", \\\"{x:1423,y:739,t:1527873585686};\\\", \\\"{x:1412,y:757,t:1527873585704};\\\", \\\"{x:1399,y:775,t:1527873585720};\\\", \\\"{x:1391,y:791,t:1527873585738};\\\", \\\"{x:1386,y:811,t:1527873585753};\\\", \\\"{x:1381,y:834,t:1527873585771};\\\", \\\"{x:1378,y:854,t:1527873585788};\\\", \\\"{x:1376,y:867,t:1527873585804};\\\", \\\"{x:1375,y:873,t:1527873585821};\\\", \\\"{x:1375,y:875,t:1527873585838};\\\", \\\"{x:1375,y:876,t:1527873585854};\\\", \\\"{x:1375,y:877,t:1527873585870};\\\", \\\"{x:1375,y:871,t:1527873585927};\\\", \\\"{x:1375,y:858,t:1527873585937};\\\", \\\"{x:1375,y:826,t:1527873585953};\\\", \\\"{x:1362,y:773,t:1527873585970};\\\", \\\"{x:1349,y:721,t:1527873585988};\\\", \\\"{x:1341,y:698,t:1527873586004};\\\", \\\"{x:1341,y:680,t:1527873586021};\\\", \\\"{x:1341,y:670,t:1527873586038};\\\", \\\"{x:1343,y:666,t:1527873586055};\\\", \\\"{x:1343,y:669,t:1527873586200};\\\", \\\"{x:1343,y:684,t:1527873586207};\\\", \\\"{x:1343,y:699,t:1527873586221};\\\", \\\"{x:1343,y:716,t:1527873586238};\\\", \\\"{x:1343,y:742,t:1527873586255};\\\", \\\"{x:1343,y:762,t:1527873586271};\\\", \\\"{x:1343,y:782,t:1527873586288};\\\", \\\"{x:1343,y:800,t:1527873586305};\\\", \\\"{x:1343,y:817,t:1527873586321};\\\", \\\"{x:1343,y:839,t:1527873586338};\\\", \\\"{x:1343,y:864,t:1527873586355};\\\", \\\"{x:1343,y:884,t:1527873586370};\\\", \\\"{x:1343,y:899,t:1527873586387};\\\", \\\"{x:1343,y:910,t:1527873586405};\\\", \\\"{x:1343,y:919,t:1527873586420};\\\", \\\"{x:1343,y:931,t:1527873586437};\\\", \\\"{x:1343,y:948,t:1527873586455};\\\", \\\"{x:1345,y:957,t:1527873586471};\\\", \\\"{x:1345,y:960,t:1527873586488};\\\", \\\"{x:1345,y:963,t:1527873586505};\\\", \\\"{x:1345,y:964,t:1527873586522};\\\", \\\"{x:1345,y:965,t:1527873586538};\\\", \\\"{x:1345,y:967,t:1527873586555};\\\", \\\"{x:1345,y:969,t:1527873586572};\\\", \\\"{x:1345,y:970,t:1527873586587};\\\", \\\"{x:1348,y:971,t:1527873586983};\\\", \\\"{x:1355,y:971,t:1527873586990};\\\", \\\"{x:1359,y:971,t:1527873587004};\\\", \\\"{x:1367,y:971,t:1527873587021};\\\", \\\"{x:1373,y:971,t:1527873587039};\\\", \\\"{x:1374,y:971,t:1527873587055};\\\", \\\"{x:1376,y:971,t:1527873587071};\\\", \\\"{x:1377,y:971,t:1527873587095};\\\", \\\"{x:1378,y:971,t:1527873587104};\\\", \\\"{x:1381,y:971,t:1527873587122};\\\", \\\"{x:1383,y:971,t:1527873587138};\\\", \\\"{x:1387,y:971,t:1527873587154};\\\", \\\"{x:1390,y:971,t:1527873587172};\\\", \\\"{x:1391,y:971,t:1527873587189};\\\", \\\"{x:1392,y:971,t:1527873587205};\\\", \\\"{x:1394,y:971,t:1527873587375};\\\", \\\"{x:1401,y:971,t:1527873587389};\\\", \\\"{x:1413,y:971,t:1527873587406};\\\", \\\"{x:1428,y:971,t:1527873587421};\\\", \\\"{x:1458,y:971,t:1527873587439};\\\", \\\"{x:1476,y:971,t:1527873587455};\\\", \\\"{x:1485,y:971,t:1527873587471};\\\", \\\"{x:1487,y:971,t:1527873587488};\\\", \\\"{x:1488,y:971,t:1527873587784};\\\", \\\"{x:1490,y:971,t:1527873587799};\\\", \\\"{x:1491,y:971,t:1527873587871};\\\", \\\"{x:1490,y:971,t:1527873587919};\\\", \\\"{x:1489,y:971,t:1527873587951};\\\", \\\"{x:1488,y:971,t:1527873588679};\\\", \\\"{x:1488,y:969,t:1527873588815};\\\", \\\"{x:1488,y:944,t:1527873588824};\\\", \\\"{x:1484,y:887,t:1527873588840};\\\", \\\"{x:1484,y:855,t:1527873588857};\\\", \\\"{x:1484,y:828,t:1527873588873};\\\", \\\"{x:1484,y:817,t:1527873588891};\\\", \\\"{x:1484,y:807,t:1527873588907};\\\", \\\"{x:1484,y:791,t:1527873588923};\\\", \\\"{x:1482,y:765,t:1527873588940};\\\", \\\"{x:1473,y:733,t:1527873588957};\\\", \\\"{x:1456,y:684,t:1527873588973};\\\", \\\"{x:1446,y:663,t:1527873588989};\\\", \\\"{x:1440,y:647,t:1527873589006};\\\", \\\"{x:1438,y:642,t:1527873589023};\\\", \\\"{x:1434,y:636,t:1527873589039};\\\", \\\"{x:1429,y:630,t:1527873589057};\\\", \\\"{x:1424,y:626,t:1527873589073};\\\", \\\"{x:1415,y:620,t:1527873589090};\\\", \\\"{x:1407,y:614,t:1527873589107};\\\", \\\"{x:1399,y:609,t:1527873589123};\\\", \\\"{x:1397,y:607,t:1527873589139};\\\", \\\"{x:1396,y:607,t:1527873589223};\\\", \\\"{x:1394,y:608,t:1527873589247};\\\", \\\"{x:1392,y:616,t:1527873589257};\\\", \\\"{x:1387,y:635,t:1527873589273};\\\", \\\"{x:1383,y:654,t:1527873589290};\\\", \\\"{x:1377,y:673,t:1527873589306};\\\", \\\"{x:1373,y:687,t:1527873589323};\\\", \\\"{x:1370,y:699,t:1527873589340};\\\", \\\"{x:1369,y:704,t:1527873589356};\\\", \\\"{x:1368,y:705,t:1527873589374};\\\", \\\"{x:1368,y:708,t:1527873589390};\\\", \\\"{x:1368,y:715,t:1527873589406};\\\", \\\"{x:1368,y:720,t:1527873589423};\\\", \\\"{x:1368,y:723,t:1527873589440};\\\", \\\"{x:1368,y:727,t:1527873589456};\\\", \\\"{x:1368,y:733,t:1527873589473};\\\", \\\"{x:1368,y:743,t:1527873589490};\\\", \\\"{x:1368,y:751,t:1527873589506};\\\", \\\"{x:1370,y:760,t:1527873589523};\\\", \\\"{x:1370,y:770,t:1527873589540};\\\", \\\"{x:1374,y:786,t:1527873589556};\\\", \\\"{x:1377,y:800,t:1527873589573};\\\", \\\"{x:1386,y:828,t:1527873589590};\\\", \\\"{x:1391,y:844,t:1527873589606};\\\", \\\"{x:1397,y:864,t:1527873589623};\\\", \\\"{x:1403,y:882,t:1527873589640};\\\", \\\"{x:1410,y:898,t:1527873589657};\\\", \\\"{x:1417,y:913,t:1527873589673};\\\", \\\"{x:1423,y:927,t:1527873589690};\\\", \\\"{x:1430,y:940,t:1527873589706};\\\", \\\"{x:1435,y:947,t:1527873589723};\\\", \\\"{x:1440,y:956,t:1527873589740};\\\", \\\"{x:1442,y:958,t:1527873589756};\\\", \\\"{x:1444,y:960,t:1527873589773};\\\", \\\"{x:1445,y:961,t:1527873589790};\\\", \\\"{x:1446,y:963,t:1527873589806};\\\", \\\"{x:1448,y:966,t:1527873589823};\\\", \\\"{x:1449,y:968,t:1527873589840};\\\", \\\"{x:1452,y:972,t:1527873589856};\\\", \\\"{x:1454,y:978,t:1527873589874};\\\", \\\"{x:1455,y:979,t:1527873589890};\\\", \\\"{x:1456,y:981,t:1527873589906};\\\", \\\"{x:1458,y:981,t:1527873590151};\\\", \\\"{x:1461,y:981,t:1527873590158};\\\", \\\"{x:1463,y:981,t:1527873590174};\\\", \\\"{x:1470,y:980,t:1527873590190};\\\", \\\"{x:1472,y:980,t:1527873590214};\\\", \\\"{x:1472,y:978,t:1527873590463};\\\", \\\"{x:1470,y:975,t:1527873590474};\\\", \\\"{x:1460,y:971,t:1527873590491};\\\", \\\"{x:1459,y:971,t:1527873590508};\\\", \\\"{x:1456,y:970,t:1527873590535};\\\", \\\"{x:1454,y:969,t:1527873590543};\\\", \\\"{x:1452,y:968,t:1527873590557};\\\", \\\"{x:1449,y:968,t:1527873590574};\\\", \\\"{x:1446,y:968,t:1527873590591};\\\", \\\"{x:1443,y:968,t:1527873590608};\\\", \\\"{x:1439,y:969,t:1527873590625};\\\", \\\"{x:1434,y:969,t:1527873590641};\\\", \\\"{x:1430,y:970,t:1527873590657};\\\", \\\"{x:1426,y:971,t:1527873590674};\\\", \\\"{x:1423,y:972,t:1527873590691};\\\", \\\"{x:1420,y:973,t:1527873590708};\\\", \\\"{x:1419,y:973,t:1527873590725};\\\", \\\"{x:1416,y:973,t:1527873590740};\\\", \\\"{x:1413,y:973,t:1527873590757};\\\", \\\"{x:1412,y:973,t:1527873590903};\\\", \\\"{x:1411,y:973,t:1527873590911};\\\", \\\"{x:1409,y:975,t:1527873590924};\\\", \\\"{x:1406,y:975,t:1527873590941};\\\", \\\"{x:1404,y:975,t:1527873590957};\\\", \\\"{x:1403,y:976,t:1527873590974};\\\", \\\"{x:1400,y:976,t:1527873591239};\\\", \\\"{x:1399,y:976,t:1527873591246};\\\", \\\"{x:1396,y:975,t:1527873591258};\\\", \\\"{x:1392,y:975,t:1527873591275};\\\", \\\"{x:1388,y:974,t:1527873591292};\\\", \\\"{x:1383,y:974,t:1527873591308};\\\", \\\"{x:1379,y:974,t:1527873591325};\\\", \\\"{x:1377,y:974,t:1527873591342};\\\", \\\"{x:1374,y:974,t:1527873591359};\\\", \\\"{x:1372,y:974,t:1527873591375};\\\", \\\"{x:1371,y:974,t:1527873591392};\\\", \\\"{x:1369,y:974,t:1527873591409};\\\", \\\"{x:1368,y:974,t:1527873591431};\\\", \\\"{x:1367,y:974,t:1527873591455};\\\", \\\"{x:1366,y:974,t:1527873591475};\\\", \\\"{x:1365,y:974,t:1527873591598};\\\", \\\"{x:1364,y:974,t:1527873591671};\\\", \\\"{x:1363,y:974,t:1527873591686};\\\", \\\"{x:1359,y:972,t:1527873591800};\\\", \\\"{x:1358,y:971,t:1527873591809};\\\", \\\"{x:1356,y:970,t:1527873591826};\\\", \\\"{x:1353,y:970,t:1527873591841};\\\", \\\"{x:1349,y:968,t:1527873591858};\\\", \\\"{x:1347,y:967,t:1527873592408};\\\", \\\"{x:1345,y:967,t:1527873592425};\\\", \\\"{x:1345,y:966,t:1527873592443};\\\", \\\"{x:1344,y:966,t:1527873592459};\\\", \\\"{x:1342,y:965,t:1527873592476};\\\", \\\"{x:1342,y:964,t:1527873592493};\\\", \\\"{x:1342,y:961,t:1527873592510};\\\", \\\"{x:1342,y:959,t:1527873592526};\\\", \\\"{x:1342,y:956,t:1527873592543};\\\", \\\"{x:1342,y:955,t:1527873592559};\\\", \\\"{x:1342,y:953,t:1527873592575};\\\", \\\"{x:1341,y:952,t:1527873592593};\\\", \\\"{x:1341,y:950,t:1527873592608};\\\", \\\"{x:1340,y:948,t:1527873592625};\\\", \\\"{x:1340,y:949,t:1527873593127};\\\", \\\"{x:1340,y:954,t:1527873593143};\\\", \\\"{x:1340,y:960,t:1527873593160};\\\", \\\"{x:1340,y:963,t:1527873593177};\\\", \\\"{x:1340,y:966,t:1527873593193};\\\", \\\"{x:1340,y:967,t:1527873593210};\\\", \\\"{x:1340,y:968,t:1527873593247};\\\", \\\"{x:1340,y:969,t:1527873593260};\\\", \\\"{x:1340,y:971,t:1527873593276};\\\", \\\"{x:1340,y:972,t:1527873593292};\\\", \\\"{x:1340,y:973,t:1527873593309};\\\", \\\"{x:1339,y:974,t:1527873594432};\\\", \\\"{x:1337,y:974,t:1527873594462};\\\", \\\"{x:1336,y:974,t:1527873594487};\\\", \\\"{x:1335,y:974,t:1527873594527};\\\", \\\"{x:1334,y:974,t:1527873594591};\\\", \\\"{x:1334,y:973,t:1527873594607};\\\", \\\"{x:1333,y:972,t:1527873594751};\\\", \\\"{x:1333,y:970,t:1527873594790};\\\", \\\"{x:1333,y:967,t:1527873594799};\\\", \\\"{x:1333,y:966,t:1527873594811};\\\", \\\"{x:1333,y:962,t:1527873594828};\\\", \\\"{x:1335,y:960,t:1527873594845};\\\", \\\"{x:1337,y:958,t:1527873594860};\\\", \\\"{x:1338,y:958,t:1527873594887};\\\", \\\"{x:1339,y:957,t:1527873594903};\\\", \\\"{x:1341,y:956,t:1527873594940};\\\", \\\"{x:1341,y:955,t:1527873595045};\\\", \\\"{x:1342,y:955,t:1527873595061};\\\", \\\"{x:1342,y:954,t:1527873595069};\\\", \\\"{x:1342,y:953,t:1527873595197};\\\", \\\"{x:1343,y:950,t:1527873595205};\\\", \\\"{x:1344,y:948,t:1527873595218};\\\", \\\"{x:1346,y:943,t:1527873595234};\\\", \\\"{x:1348,y:938,t:1527873595251};\\\", \\\"{x:1348,y:936,t:1527873595267};\\\", \\\"{x:1350,y:934,t:1527873595283};\\\", \\\"{x:1351,y:928,t:1527873595300};\\\", \\\"{x:1352,y:925,t:1527873595318};\\\", \\\"{x:1353,y:921,t:1527873595334};\\\", \\\"{x:1353,y:917,t:1527873595351};\\\", \\\"{x:1354,y:912,t:1527873595367};\\\", \\\"{x:1355,y:905,t:1527873595384};\\\", \\\"{x:1356,y:898,t:1527873595401};\\\", \\\"{x:1356,y:888,t:1527873595417};\\\", \\\"{x:1358,y:879,t:1527873595434};\\\", \\\"{x:1358,y:873,t:1527873595451};\\\", \\\"{x:1358,y:868,t:1527873595468};\\\", \\\"{x:1358,y:865,t:1527873595484};\\\", \\\"{x:1358,y:857,t:1527873595501};\\\", \\\"{x:1358,y:852,t:1527873595518};\\\", \\\"{x:1358,y:851,t:1527873595534};\\\", \\\"{x:1358,y:850,t:1527873595550};\\\", \\\"{x:1358,y:848,t:1527873595653};\\\", \\\"{x:1358,y:846,t:1527873595667};\\\", \\\"{x:1358,y:843,t:1527873595684};\\\", \\\"{x:1358,y:841,t:1527873595701};\\\", \\\"{x:1358,y:840,t:1527873595717};\\\", \\\"{x:1358,y:838,t:1527873595734};\\\", \\\"{x:1358,y:837,t:1527873595750};\\\", \\\"{x:1358,y:834,t:1527873595768};\\\", \\\"{x:1358,y:832,t:1527873595788};\\\", \\\"{x:1358,y:831,t:1527873595801};\\\", \\\"{x:1358,y:830,t:1527873595817};\\\", \\\"{x:1358,y:829,t:1527873595835};\\\", \\\"{x:1358,y:834,t:1527873595989};\\\", \\\"{x:1358,y:844,t:1527873596001};\\\", \\\"{x:1360,y:864,t:1527873596018};\\\", \\\"{x:1361,y:886,t:1527873596035};\\\", \\\"{x:1362,y:904,t:1527873596050};\\\", \\\"{x:1363,y:917,t:1527873596068};\\\", \\\"{x:1363,y:927,t:1527873596084};\\\", \\\"{x:1364,y:932,t:1527873596102};\\\", \\\"{x:1364,y:939,t:1527873596118};\\\", \\\"{x:1364,y:943,t:1527873596135};\\\", \\\"{x:1364,y:947,t:1527873596152};\\\", \\\"{x:1364,y:951,t:1527873596167};\\\", \\\"{x:1364,y:955,t:1527873596185};\\\", \\\"{x:1364,y:957,t:1527873596202};\\\", \\\"{x:1364,y:960,t:1527873596218};\\\", \\\"{x:1364,y:963,t:1527873596235};\\\", \\\"{x:1364,y:967,t:1527873596252};\\\", \\\"{x:1364,y:970,t:1527873596268};\\\", \\\"{x:1364,y:974,t:1527873596284};\\\", \\\"{x:1364,y:975,t:1527873596301};\\\", \\\"{x:1364,y:977,t:1527873596318};\\\", \\\"{x:1364,y:978,t:1527873596348};\\\", \\\"{x:1364,y:977,t:1527873596645};\\\", \\\"{x:1364,y:976,t:1527873596652};\\\", \\\"{x:1364,y:975,t:1527873596788};\\\", \\\"{x:1363,y:975,t:1527873596801};\\\", \\\"{x:1363,y:974,t:1527873596818};\\\", \\\"{x:1362,y:973,t:1527873596835};\\\", \\\"{x:1361,y:973,t:1527873596851};\\\", \\\"{x:1360,y:973,t:1527873596908};\\\", \\\"{x:1360,y:972,t:1527873597045};\\\", \\\"{x:1359,y:972,t:1527873597068};\\\", \\\"{x:1359,y:970,t:1527873597669};\\\", \\\"{x:1359,y:960,t:1527873597686};\\\", \\\"{x:1359,y:957,t:1527873597703};\\\", \\\"{x:1359,y:952,t:1527873597719};\\\", \\\"{x:1359,y:949,t:1527873597735};\\\", \\\"{x:1359,y:946,t:1527873597753};\\\", \\\"{x:1359,y:943,t:1527873597769};\\\", \\\"{x:1359,y:940,t:1527873597786};\\\", \\\"{x:1359,y:935,t:1527873597803};\\\", \\\"{x:1359,y:932,t:1527873597820};\\\", \\\"{x:1359,y:929,t:1527873597836};\\\", \\\"{x:1359,y:924,t:1527873597852};\\\", \\\"{x:1359,y:919,t:1527873597870};\\\", \\\"{x:1359,y:915,t:1527873597886};\\\", \\\"{x:1359,y:914,t:1527873597903};\\\", \\\"{x:1359,y:913,t:1527873597932};\\\", \\\"{x:1359,y:912,t:1527873598045};\\\", \\\"{x:1359,y:908,t:1527873598374};\\\", \\\"{x:1360,y:901,t:1527873598387};\\\", \\\"{x:1367,y:886,t:1527873598402};\\\", \\\"{x:1373,y:873,t:1527873598420};\\\", \\\"{x:1375,y:866,t:1527873598437};\\\", \\\"{x:1375,y:865,t:1527873598453};\\\", \\\"{x:1375,y:862,t:1527873598470};\\\", \\\"{x:1375,y:859,t:1527873598487};\\\", \\\"{x:1375,y:855,t:1527873598503};\\\", \\\"{x:1375,y:852,t:1527873598520};\\\", \\\"{x:1375,y:850,t:1527873598537};\\\", \\\"{x:1375,y:849,t:1527873598552};\\\", \\\"{x:1375,y:848,t:1527873598573};\\\", \\\"{x:1375,y:847,t:1527873598587};\\\", \\\"{x:1375,y:844,t:1527873598603};\\\", \\\"{x:1375,y:843,t:1527873598620};\\\", \\\"{x:1374,y:839,t:1527873598636};\\\", \\\"{x:1374,y:836,t:1527873598661};\\\", \\\"{x:1373,y:836,t:1527873598670};\\\", \\\"{x:1373,y:833,t:1527873598687};\\\", \\\"{x:1373,y:832,t:1527873598704};\\\", \\\"{x:1372,y:830,t:1527873598720};\\\", \\\"{x:1372,y:829,t:1527873598749};\\\", \\\"{x:1371,y:828,t:1527873598756};\\\", \\\"{x:1371,y:827,t:1527873598770};\\\", \\\"{x:1370,y:826,t:1527873598787};\\\", \\\"{x:1370,y:824,t:1527873598804};\\\", \\\"{x:1369,y:823,t:1527873598820};\\\", \\\"{x:1367,y:820,t:1527873598837};\\\", \\\"{x:1364,y:816,t:1527873598854};\\\", \\\"{x:1359,y:812,t:1527873598870};\\\", \\\"{x:1355,y:809,t:1527873598887};\\\", \\\"{x:1355,y:808,t:1527873598904};\\\", \\\"{x:1354,y:807,t:1527873598924};\\\", \\\"{x:1352,y:806,t:1527873598941};\\\", \\\"{x:1352,y:805,t:1527873598954};\\\", \\\"{x:1350,y:805,t:1527873598970};\\\", \\\"{x:1350,y:804,t:1527873598989};\\\", \\\"{x:1349,y:804,t:1527873599004};\\\", \\\"{x:1349,y:802,t:1527873599101};\\\", \\\"{x:1349,y:798,t:1527873599109};\\\", \\\"{x:1347,y:794,t:1527873599119};\\\", \\\"{x:1343,y:784,t:1527873599137};\\\", \\\"{x:1341,y:779,t:1527873599154};\\\", \\\"{x:1340,y:776,t:1527873599170};\\\", \\\"{x:1340,y:774,t:1527873599186};\\\", \\\"{x:1340,y:772,t:1527873599203};\\\", \\\"{x:1340,y:769,t:1527873599220};\\\", \\\"{x:1340,y:766,t:1527873599237};\\\", \\\"{x:1340,y:765,t:1527873599254};\\\", \\\"{x:1340,y:763,t:1527873599271};\\\", \\\"{x:1340,y:762,t:1527873599444};\\\", \\\"{x:1341,y:761,t:1527873599685};\\\", \\\"{x:1342,y:761,t:1527873599725};\\\", \\\"{x:1343,y:761,t:1527873599741};\\\", \\\"{x:1344,y:761,t:1527873599754};\\\", \\\"{x:1345,y:761,t:1527873599797};\\\", \\\"{x:1346,y:762,t:1527873599805};\\\", \\\"{x:1347,y:762,t:1527873599845};\\\", \\\"{x:1347,y:763,t:1527873599861};\\\", \\\"{x:1348,y:763,t:1527873599900};\\\", \\\"{x:1352,y:763,t:1527873600612};\\\", \\\"{x:1357,y:763,t:1527873600623};\\\", \\\"{x:1363,y:763,t:1527873600638};\\\", \\\"{x:1374,y:763,t:1527873600655};\\\", \\\"{x:1384,y:763,t:1527873600672};\\\", \\\"{x:1392,y:763,t:1527873600688};\\\", \\\"{x:1398,y:763,t:1527873600705};\\\", \\\"{x:1403,y:763,t:1527873600721};\\\", \\\"{x:1407,y:763,t:1527873600738};\\\", \\\"{x:1413,y:763,t:1527873600755};\\\", \\\"{x:1423,y:765,t:1527873600773};\\\", \\\"{x:1426,y:765,t:1527873600788};\\\", \\\"{x:1427,y:766,t:1527873600805};\\\", \\\"{x:1428,y:766,t:1527873600822};\\\", \\\"{x:1429,y:766,t:1527873600839};\\\", \\\"{x:1431,y:767,t:1527873601308};\\\", \\\"{x:1433,y:767,t:1527873601321};\\\", \\\"{x:1438,y:767,t:1527873601338};\\\", \\\"{x:1447,y:768,t:1527873601356};\\\", \\\"{x:1454,y:768,t:1527873601374};\\\", \\\"{x:1459,y:768,t:1527873601388};\\\", \\\"{x:1463,y:768,t:1527873601406};\\\", \\\"{x:1464,y:768,t:1527873601428};\\\", \\\"{x:1463,y:768,t:1527873601612};\\\", \\\"{x:1455,y:767,t:1527873601622};\\\", \\\"{x:1442,y:759,t:1527873601639};\\\", \\\"{x:1437,y:758,t:1527873601656};\\\", \\\"{x:1437,y:757,t:1527873601673};\\\", \\\"{x:1435,y:756,t:1527873601689};\\\", \\\"{x:1431,y:750,t:1527873601706};\\\", \\\"{x:1426,y:740,t:1527873601723};\\\", \\\"{x:1419,y:732,t:1527873601739};\\\", \\\"{x:1415,y:726,t:1527873601756};\\\", \\\"{x:1413,y:721,t:1527873601773};\\\", \\\"{x:1411,y:719,t:1527873601789};\\\", \\\"{x:1410,y:718,t:1527873601812};\\\", \\\"{x:1408,y:716,t:1527873601823};\\\", \\\"{x:1404,y:713,t:1527873601838};\\\", \\\"{x:1393,y:707,t:1527873601855};\\\", \\\"{x:1381,y:703,t:1527873601872};\\\", \\\"{x:1372,y:700,t:1527873601889};\\\", \\\"{x:1363,y:695,t:1527873601906};\\\", \\\"{x:1359,y:694,t:1527873601922};\\\", \\\"{x:1357,y:693,t:1527873601938};\\\", \\\"{x:1356,y:693,t:1527873601956};\\\", \\\"{x:1354,y:692,t:1527873601973};\\\", \\\"{x:1353,y:692,t:1527873602325};\\\", \\\"{x:1352,y:692,t:1527873602340};\\\", \\\"{x:1351,y:694,t:1527873602357};\\\", \\\"{x:1350,y:696,t:1527873602390};\\\", \\\"{x:1350,y:698,t:1527873603485};\\\", \\\"{x:1349,y:704,t:1527873603493};\\\", \\\"{x:1348,y:710,t:1527873603507};\\\", \\\"{x:1345,y:726,t:1527873603524};\\\", \\\"{x:1344,y:732,t:1527873603540};\\\", \\\"{x:1344,y:742,t:1527873603557};\\\", \\\"{x:1344,y:754,t:1527873603575};\\\", \\\"{x:1344,y:771,t:1527873603592};\\\", \\\"{x:1344,y:786,t:1527873603607};\\\", \\\"{x:1344,y:801,t:1527873603624};\\\", \\\"{x:1344,y:815,t:1527873603641};\\\", \\\"{x:1344,y:826,t:1527873603657};\\\", \\\"{x:1344,y:837,t:1527873603675};\\\", \\\"{x:1344,y:852,t:1527873603691};\\\", \\\"{x:1344,y:860,t:1527873603707};\\\", \\\"{x:1344,y:873,t:1527873603724};\\\", \\\"{x:1345,y:883,t:1527873603740};\\\", \\\"{x:1347,y:899,t:1527873603757};\\\", \\\"{x:1351,y:914,t:1527873603774};\\\", \\\"{x:1351,y:923,t:1527873603791};\\\", \\\"{x:1351,y:936,t:1527873603807};\\\", \\\"{x:1352,y:942,t:1527873603824};\\\", \\\"{x:1354,y:951,t:1527873603841};\\\", \\\"{x:1355,y:958,t:1527873603858};\\\", \\\"{x:1355,y:967,t:1527873603874};\\\", \\\"{x:1356,y:980,t:1527873603891};\\\", \\\"{x:1359,y:996,t:1527873603909};\\\", \\\"{x:1359,y:1002,t:1527873603924};\\\", \\\"{x:1359,y:1005,t:1527873603941};\\\", \\\"{x:1359,y:1006,t:1527873603958};\\\", \\\"{x:1361,y:1005,t:1527873604085};\\\", \\\"{x:1362,y:1002,t:1527873604093};\\\", \\\"{x:1367,y:1001,t:1527873604108};\\\", \\\"{x:1372,y:998,t:1527873604124};\\\", \\\"{x:1379,y:994,t:1527873604141};\\\", \\\"{x:1384,y:993,t:1527873604158};\\\", \\\"{x:1388,y:991,t:1527873604174};\\\", \\\"{x:1391,y:991,t:1527873604191};\\\", \\\"{x:1394,y:990,t:1527873604208};\\\", \\\"{x:1398,y:989,t:1527873604224};\\\", \\\"{x:1402,y:987,t:1527873604241};\\\", \\\"{x:1404,y:987,t:1527873604258};\\\", \\\"{x:1407,y:985,t:1527873604274};\\\", \\\"{x:1409,y:984,t:1527873604292};\\\", \\\"{x:1414,y:983,t:1527873604469};\\\", \\\"{x:1419,y:980,t:1527873604476};\\\", \\\"{x:1424,y:980,t:1527873604491};\\\", \\\"{x:1436,y:978,t:1527873604509};\\\", \\\"{x:1449,y:977,t:1527873604524};\\\", \\\"{x:1461,y:974,t:1527873604541};\\\", \\\"{x:1466,y:974,t:1527873604558};\\\", \\\"{x:1469,y:974,t:1527873604575};\\\", \\\"{x:1469,y:973,t:1527873604591};\\\", \\\"{x:1470,y:973,t:1527873604608};\\\", \\\"{x:1471,y:973,t:1527873604628};\\\", \\\"{x:1473,y:972,t:1527873604645};\\\", \\\"{x:1474,y:972,t:1527873604660};\\\", \\\"{x:1475,y:972,t:1527873604676};\\\", \\\"{x:1477,y:972,t:1527873606156};\\\", \\\"{x:1478,y:972,t:1527873606165};\\\", \\\"{x:1479,y:972,t:1527873606176};\\\", \\\"{x:1480,y:972,t:1527873606195};\\\", \\\"{x:1481,y:972,t:1527873606208};\\\", \\\"{x:1482,y:972,t:1527873606225};\\\", \\\"{x:1483,y:972,t:1527873606259};\\\", \\\"{x:1483,y:973,t:1527873606275};\\\", \\\"{x:1484,y:974,t:1527873606299};\\\", \\\"{x:1485,y:974,t:1527873606373};\\\", \\\"{x:1486,y:975,t:1527873606420};\\\", \\\"{x:1487,y:975,t:1527873606444};\\\", \\\"{x:1488,y:975,t:1527873606484};\\\", \\\"{x:1489,y:977,t:1527873606533};\\\", \\\"{x:1489,y:976,t:1527873607460};\\\", \\\"{x:1474,y:931,t:1527873607478};\\\", \\\"{x:1442,y:886,t:1527873607494};\\\", \\\"{x:1408,y:847,t:1527873607510};\\\", \\\"{x:1358,y:791,t:1527873607527};\\\", \\\"{x:1297,y:738,t:1527873607544};\\\", \\\"{x:1224,y:689,t:1527873607560};\\\", \\\"{x:1140,y:639,t:1527873607577};\\\", \\\"{x:1069,y:598,t:1527873607594};\\\", \\\"{x:1019,y:575,t:1527873607610};\\\", \\\"{x:985,y:561,t:1527873607628};\\\", \\\"{x:952,y:547,t:1527873607644};\\\", \\\"{x:929,y:536,t:1527873607660};\\\", \\\"{x:904,y:520,t:1527873607678};\\\", \\\"{x:870,y:496,t:1527873607693};\\\", \\\"{x:824,y:468,t:1527873607720};\\\", \\\"{x:787,y:450,t:1527873607736};\\\", \\\"{x:732,y:426,t:1527873607754};\\\", \\\"{x:659,y:407,t:1527873607771};\\\", \\\"{x:609,y:393,t:1527873607786};\\\", \\\"{x:571,y:384,t:1527873607803};\\\", \\\"{x:545,y:376,t:1527873607821};\\\", \\\"{x:518,y:373,t:1527873607837};\\\", \\\"{x:495,y:370,t:1527873607854};\\\", \\\"{x:468,y:370,t:1527873607871};\\\", \\\"{x:434,y:370,t:1527873607887};\\\", \\\"{x:411,y:370,t:1527873607903};\\\", \\\"{x:389,y:370,t:1527873607921};\\\", \\\"{x:366,y:370,t:1527873607937};\\\", \\\"{x:343,y:372,t:1527873607954};\\\", \\\"{x:322,y:378,t:1527873607970};\\\", \\\"{x:301,y:383,t:1527873607986};\\\", \\\"{x:287,y:390,t:1527873608004};\\\", \\\"{x:277,y:395,t:1527873608020};\\\", \\\"{x:268,y:399,t:1527873608038};\\\", \\\"{x:261,y:404,t:1527873608054};\\\", \\\"{x:254,y:409,t:1527873608071};\\\", \\\"{x:250,y:412,t:1527873608087};\\\", \\\"{x:246,y:416,t:1527873608104};\\\", \\\"{x:242,y:420,t:1527873608119};\\\", \\\"{x:235,y:429,t:1527873608138};\\\", \\\"{x:226,y:439,t:1527873608153};\\\", \\\"{x:222,y:443,t:1527873608170};\\\", \\\"{x:218,y:448,t:1527873608187};\\\", \\\"{x:213,y:454,t:1527873608204};\\\", \\\"{x:210,y:462,t:1527873608220};\\\", \\\"{x:204,y:474,t:1527873608237};\\\", \\\"{x:198,y:487,t:1527873608254};\\\", \\\"{x:197,y:496,t:1527873608270};\\\", \\\"{x:192,y:504,t:1527873608288};\\\", \\\"{x:189,y:516,t:1527873608304};\\\", \\\"{x:187,y:526,t:1527873608328};\\\", \\\"{x:186,y:529,t:1527873608345};\\\", \\\"{x:186,y:533,t:1527873608361};\\\", \\\"{x:186,y:539,t:1527873608378};\\\", \\\"{x:186,y:547,t:1527873608394};\\\", \\\"{x:186,y:553,t:1527873608410};\\\", \\\"{x:186,y:558,t:1527873608428};\\\", \\\"{x:186,y:559,t:1527873608556};\\\", \\\"{x:186,y:563,t:1527873608563};\\\", \\\"{x:186,y:568,t:1527873608578};\\\", \\\"{x:186,y:577,t:1527873608597};\\\", \\\"{x:186,y:584,t:1527873608611};\\\", \\\"{x:185,y:591,t:1527873608627};\\\", \\\"{x:184,y:595,t:1527873608644};\\\", \\\"{x:184,y:597,t:1527873608660};\\\", \\\"{x:183,y:599,t:1527873608678};\\\", \\\"{x:182,y:600,t:1527873608694};\\\", \\\"{x:182,y:603,t:1527873608711};\\\", \\\"{x:181,y:606,t:1527873608727};\\\", \\\"{x:180,y:609,t:1527873608744};\\\", \\\"{x:179,y:613,t:1527873608760};\\\", \\\"{x:178,y:616,t:1527873608778};\\\", \\\"{x:178,y:619,t:1527873608794};\\\", \\\"{x:178,y:622,t:1527873608810};\\\", \\\"{x:178,y:625,t:1527873608828};\\\", \\\"{x:177,y:626,t:1527873608851};\\\", \\\"{x:179,y:624,t:1527873608956};\\\", \\\"{x:184,y:617,t:1527873608965};\\\", \\\"{x:192,y:610,t:1527873608978};\\\", \\\"{x:214,y:596,t:1527873608994};\\\", \\\"{x:286,y:578,t:1527873609011};\\\", \\\"{x:334,y:577,t:1527873609027};\\\", \\\"{x:384,y:577,t:1527873609045};\\\", \\\"{x:435,y:577,t:1527873609061};\\\", \\\"{x:474,y:577,t:1527873609077};\\\", \\\"{x:497,y:577,t:1527873609094};\\\", \\\"{x:510,y:576,t:1527873609112};\\\", \\\"{x:511,y:576,t:1527873609128};\\\", \\\"{x:511,y:575,t:1527873609145};\\\", \\\"{x:513,y:574,t:1527873609269};\\\", \\\"{x:514,y:572,t:1527873609279};\\\", \\\"{x:516,y:569,t:1527873609296};\\\", \\\"{x:521,y:565,t:1527873609311};\\\", \\\"{x:532,y:560,t:1527873609327};\\\", \\\"{x:547,y:557,t:1527873609344};\\\", \\\"{x:567,y:557,t:1527873609361};\\\", \\\"{x:593,y:557,t:1527873609377};\\\", \\\"{x:618,y:557,t:1527873609395};\\\", \\\"{x:657,y:556,t:1527873609412};\\\", \\\"{x:665,y:555,t:1527873609427};\\\", \\\"{x:668,y:554,t:1527873609444};\\\", \\\"{x:670,y:553,t:1527873609540};\\\", \\\"{x:673,y:551,t:1527873609548};\\\", \\\"{x:679,y:548,t:1527873609561};\\\", \\\"{x:695,y:542,t:1527873609579};\\\", \\\"{x:711,y:540,t:1527873609595};\\\", \\\"{x:737,y:536,t:1527873609614};\\\", \\\"{x:741,y:536,t:1527873609628};\\\", \\\"{x:745,y:535,t:1527873609644};\\\", \\\"{x:752,y:533,t:1527873609662};\\\", \\\"{x:759,y:531,t:1527873609678};\\\", \\\"{x:768,y:529,t:1527873609695};\\\", \\\"{x:774,y:528,t:1527873609711};\\\", \\\"{x:775,y:528,t:1527873609729};\\\", \\\"{x:776,y:527,t:1527873609772};\\\", \\\"{x:777,y:527,t:1527873609779};\\\", \\\"{x:780,y:525,t:1527873609795};\\\", \\\"{x:791,y:524,t:1527873609812};\\\", \\\"{x:802,y:523,t:1527873609829};\\\", \\\"{x:811,y:523,t:1527873609845};\\\", \\\"{x:817,y:523,t:1527873609862};\\\", \\\"{x:822,y:523,t:1527873609878};\\\", \\\"{x:827,y:523,t:1527873609895};\\\", \\\"{x:830,y:523,t:1527873609911};\\\", \\\"{x:835,y:523,t:1527873609929};\\\", \\\"{x:840,y:523,t:1527873609944};\\\", \\\"{x:845,y:524,t:1527873609962};\\\", \\\"{x:848,y:525,t:1527873609979};\\\", \\\"{x:850,y:525,t:1527873609995};\\\", \\\"{x:851,y:525,t:1527873610356};\\\", \\\"{x:851,y:526,t:1527873610372};\\\", \\\"{x:848,y:526,t:1527873610413};\\\", \\\"{x:846,y:526,t:1527873610429};\\\", \\\"{x:845,y:526,t:1527873610446};\\\", \\\"{x:844,y:526,t:1527873610475};\\\", \\\"{x:842,y:526,t:1527873610491};\\\", \\\"{x:840,y:526,t:1527873610500};\\\", \\\"{x:837,y:526,t:1527873610512};\\\", \\\"{x:828,y:530,t:1527873610529};\\\", \\\"{x:816,y:538,t:1527873610547};\\\", \\\"{x:807,y:543,t:1527873610563};\\\", \\\"{x:797,y:548,t:1527873610579};\\\", \\\"{x:784,y:565,t:1527873610595};\\\", \\\"{x:772,y:584,t:1527873610614};\\\", \\\"{x:758,y:609,t:1527873610629};\\\", \\\"{x:744,y:640,t:1527873610646};\\\", \\\"{x:735,y:661,t:1527873610664};\\\", \\\"{x:725,y:680,t:1527873610678};\\\", \\\"{x:714,y:696,t:1527873610696};\\\", \\\"{x:700,y:713,t:1527873610712};\\\", \\\"{x:685,y:726,t:1527873610729};\\\", \\\"{x:668,y:740,t:1527873610746};\\\", \\\"{x:653,y:750,t:1527873610763};\\\", \\\"{x:634,y:762,t:1527873610778};\\\", \\\"{x:612,y:767,t:1527873610796};\\\", \\\"{x:603,y:768,t:1527873610813};\\\", \\\"{x:597,y:768,t:1527873610829};\\\", \\\"{x:588,y:763,t:1527873610846};\\\", \\\"{x:575,y:751,t:1527873610863};\\\", \\\"{x:560,y:739,t:1527873610882};\\\", \\\"{x:554,y:734,t:1527873610895};\\\", \\\"{x:552,y:732,t:1527873610913};\\\", \\\"{x:551,y:732,t:1527873610930};\\\", \\\"{x:550,y:732,t:1527873610955};\\\", \\\"{x:549,y:732,t:1527873610972};\\\", \\\"{x:548,y:732,t:1527873611003};\\\", \\\"{x:547,y:732,t:1527873611013};\\\", \\\"{x:544,y:735,t:1527873611030};\\\", \\\"{x:541,y:741,t:1527873611046};\\\", \\\"{x:539,y:744,t:1527873611062};\\\", \\\"{x:538,y:745,t:1527873611079};\\\", \\\"{x:538,y:746,t:1527873611100};\\\", \\\"{x:540,y:744,t:1527873611989};\\\", \\\"{x:559,y:733,t:1527873611996};\\\", \\\"{x:628,y:692,t:1527873612014};\\\", \\\"{x:679,y:664,t:1527873612030};\\\", \\\"{x:705,y:649,t:1527873612047};\\\", \\\"{x:721,y:639,t:1527873612063};\\\", \\\"{x:738,y:629,t:1527873612080};\\\", \\\"{x:762,y:614,t:1527873612097};\\\", \\\"{x:793,y:584,t:1527873612114};\\\", \\\"{x:847,y:521,t:1527873612130};\\\", \\\"{x:906,y:442,t:1527873612147};\\\", \\\"{x:1006,y:333,t:1527873612164};\\\", \\\"{x:1072,y:274,t:1527873612180};\\\", \\\"{x:1134,y:205,t:1527873612197};\\\", \\\"{x:1185,y:132,t:1527873612214};\\\", \\\"{x:1221,y:60,t:1527873612230};\\\", \\\"{x:1244,y:16,t:1527873612247};\\\", \\\"{x:1258,y:16,t:1527873612263};\\\", \\\"{x:1145,y:16,t:1527873612319};\\\", \\\"{x:1079,y:16,t:1527873612336};\\\", \\\"{x:1045,y:16,t:1527873612346};\\\", \\\"{x:935,y:16,t:1527873612363};\\\", \\\"{x:876,y:16,t:1527873612381};\\\", \\\"{x:840,y:16,t:1527873612396};\\\", \\\"{x:808,y:16,t:1527873612413};\\\", \\\"{x:765,y:16,t:1527873612430};\\\", \\\"{x:708,y:16,t:1527873612446};\\\", \\\"{x:643,y:16,t:1527873612464};\\\", \\\"{x:577,y:16,t:1527873612480};\\\", \\\"{x:523,y:16,t:1527873612497};\\\", \\\"{x:497,y:16,t:1527873612513};\\\", \\\"{x:492,y:16,t:1527873612531};\\\" ] }, { \\\"rt\\\": 58305, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 855926, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I looked at the graph on the x-axis at the 12 pm mark and followed with my eye upwards all the points that fall along my imaginary eye line. \\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7605, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 864538, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19941, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 885499, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 2783, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 889617, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"MWJFN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"MWJFN\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 157, dom: 622, initialDom: 697",
  "javascriptErrors": []
}