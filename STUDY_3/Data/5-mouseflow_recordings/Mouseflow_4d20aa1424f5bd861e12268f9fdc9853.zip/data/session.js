var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4d20aa1424f5bd861e12268f9fdc9853",
  "created": "2018-05-22T16:05:53.4901772-07:00",
  "lastActivity": "2018-05-22T16:06:02.8291772-07:00",
  "pageViews": [
    {
      "id": "052253994117c0fb1822c587126c05df6f65fc70",
      "startTime": "2018-05-22T16:05:53.4901772-07:00",
      "endTime": "2018-05-22T16:06:02.8291772-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 9339,
      "engagementTime": 9338,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9339,
  "engagementTime": 9338,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2KONX",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c72bfc01d291f7ef71682782683a6f2f",
  "gdpr": false
}