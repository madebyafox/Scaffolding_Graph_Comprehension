var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9645dc2b8097ca556a683c197d10c5e5",
  "created": "2018-05-15T17:08:30.4790377-07:00",
  "lastActivity": "2018-05-15T17:09:30.3710377-07:00",
  "pageViews": [
    {
      "id": "051530745e94a1dd9691f0d93094d830ca0f6e98",
      "startTime": "2018-05-15T17:08:30.4790377-07:00",
      "endTime": "2018-05-15T17:09:30.3710377-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 59892,
      "engagementTime": 30023,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 59892,
  "engagementTime": 30023,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QY1F7",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e7cc482507889fe6c010aa2e9741c5a4",
  "gdpr": false
}