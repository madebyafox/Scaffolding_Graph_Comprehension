var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "89882e60c18c8fd051fdf2ce80be9ffd",
  "created": "2018-05-21T09:15:25.1090179-07:00",
  "lastActivity": "2018-05-21T09:16:28.6450179-07:00",
  "pageViews": [
    {
      "id": "05212533fc76159437ce55e2ff5bdd37e147c847",
      "startTime": "2018-05-21T09:15:25.1090179-07:00",
      "endTime": "2018-05-21T09:16:28.6450179-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 63536,
      "engagementTime": 62532,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 63536,
  "engagementTime": 62532,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Z5Z7P",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5b278168ef3c6684a960a16ee126baf3",
  "gdpr": false
}