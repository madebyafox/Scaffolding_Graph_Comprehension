var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "162cec7c02f59e0235a125ed61aa02c0",
  "created": "2018-06-04T13:12:39.0373153-07:00",
  "lastActivity": "2018-06-04T13:17:35.8472449-07:00",
  "pageViews": [
    {
      "id": "06043845ebe0aaafe90ae9bed90406bbb2dfeb76",
      "startTime": "2018-06-04T13:12:39.0373153-07:00",
      "endTime": "2018-06-04T13:17:35.8472449-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 296975,
      "engagementTime": 74835,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 296975,
  "engagementTime": 74835,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c84220d7a8f7775b06eecf0bf743778b",
  "gdpr": false
}