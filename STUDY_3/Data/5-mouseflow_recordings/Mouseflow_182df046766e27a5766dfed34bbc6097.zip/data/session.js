var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "182df046766e27a5766dfed34bbc6097",
  "created": "2018-05-29T15:13:29.9216816-07:00",
  "lastActivity": "2018-05-29T15:14:22.8336816-07:00",
  "pageViews": [
    {
      "id": "052930384a47e284c45c79bc9bff239f85c06d6e",
      "startTime": "2018-05-29T15:13:29.9216816-07:00",
      "endTime": "2018-05-29T15:14:22.8336816-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 52912,
      "engagementTime": 31361,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 52912,
  "engagementTime": 31361,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8TUB0",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "801997a2473e3dcff676de2946576012",
  "gdpr": false
}