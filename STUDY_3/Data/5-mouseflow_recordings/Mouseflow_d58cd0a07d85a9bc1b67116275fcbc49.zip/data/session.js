var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d58cd0a07d85a9bc1b67116275fcbc49",
  "created": "2018-05-25T10:26:52.5084076-07:00",
  "lastActivity": "2018-05-25T10:28:01.2451107-07:00",
  "pageViews": [
    {
      "id": "052552053b48bae6644437784dcc24e5ad59e5ac",
      "startTime": "2018-05-25T10:26:52.5084076-07:00",
      "endTime": "2018-05-25T10:28:01.2451107-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 68772,
      "engagementTime": 49319,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 68772,
  "engagementTime": 49319,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BF0KE",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4fce70578aebf5b8cf75638c4e70834c",
  "gdpr": false
}