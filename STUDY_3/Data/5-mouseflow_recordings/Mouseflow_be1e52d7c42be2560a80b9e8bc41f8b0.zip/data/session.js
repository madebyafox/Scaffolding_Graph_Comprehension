var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "be1e52d7c42be2560a80b9e8bc41f8b0",
  "created": "2018-05-29T16:11:41.8864608-07:00",
  "lastActivity": "2018-05-29T16:12:30.3034608-07:00",
  "pageViews": [
    {
      "id": "052942355d430d1a8cc37ef9c91ba14edb2e0397",
      "startTime": "2018-05-29T16:11:41.8864608-07:00",
      "endTime": "2018-05-29T16:12:30.3034608-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 48417,
      "engagementTime": 48267,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48417,
  "engagementTime": 48267,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X2QZK",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9ba806e688c5ce7433a45b99f9fc60d0",
  "gdpr": false
}