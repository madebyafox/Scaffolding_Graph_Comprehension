var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ac9dd5ad90f4b8faa579891fe8281c30",
  "created": "2018-05-25T10:16:23.0234319-07:00",
  "lastActivity": "2018-05-25T10:16:54.5704319-07:00",
  "pageViews": [
    {
      "id": "05252306a9569f21115b5060ac6f1b6ebf2d12f4",
      "startTime": "2018-05-25T10:16:23.0234319-07:00",
      "endTime": "2018-05-25T10:16:54.5704319-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 31547,
      "engagementTime": 31547,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31547,
  "engagementTime": 31547,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=85HJP",
    "CONDITION=1/5"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4525bda121f8d4e70043318c0344cb9b",
  "gdpr": false
}