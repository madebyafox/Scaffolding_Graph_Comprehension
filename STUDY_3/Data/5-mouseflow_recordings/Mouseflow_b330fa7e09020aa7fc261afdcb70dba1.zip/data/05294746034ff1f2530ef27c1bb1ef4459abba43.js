var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05294746034ff1f2530ef27c1bb1ef4459abba43"] = {
  "startTime": "2018-05-29T17:07:47.4155899Z",
  "websitePageUrl": "/",
  "visitTime": 78329,
  "engagementTime": 59295,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "b330fa7e09020aa7fc261afdcb70dba1",
    "created": "2018-05-29T17:07:47.4155899+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4589d3976022814d171e57c28b0c63c2",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b330fa7e09020aa7fc261afdcb70dba1/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 289,
      "e": 289,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 7599,
      "e": 5101,
      "ty": 2,
      "x": 812,
      "y": 23
    },
    {
      "t": 7618,
      "e": 5120,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7699,
      "e": 5201,
      "ty": 2,
      "x": 901,
      "y": 69
    },
    {
      "t": 7750,
      "e": 5252,
      "ty": 41,
      "x": 64169,
      "y": 3881,
      "ta": "html > body"
    },
    {
      "t": 7999,
      "e": 5501,
      "ty": 2,
      "x": 924,
      "y": 784
    },
    {
      "t": 8200,
      "e": 5702,
      "ty": 2,
      "x": 892,
      "y": 814
    },
    {
      "t": 8250,
      "e": 5752,
      "ty": 41,
      "x": 55049,
      "y": 56442,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8299,
      "e": 5801,
      "ty": 2,
      "x": 802,
      "y": 718
    },
    {
      "t": 8400,
      "e": 5902,
      "ty": 2,
      "x": 741,
      "y": 168
    },
    {
      "t": 8499,
      "e": 6001,
      "ty": 2,
      "x": 689,
      "y": 92
    },
    {
      "t": 8499,
      "e": 6001,
      "ty": 41,
      "x": 48935,
      "y": 5344,
      "ta": "html > body"
    },
    {
      "t": 8594,
      "e": 6096,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8600,
      "e": 6102,
      "ty": 2,
      "x": 744,
      "y": 0
    },
    {
      "t": 8750,
      "e": 6252,
      "ty": 41,
      "x": 53462,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 9400,
      "e": 6902,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 9750,
      "e": 7252,
      "ty": 41,
      "x": 33852,
      "y": 6632,
      "ta": "html > body"
    },
    {
      "t": 9800,
      "e": 7302,
      "ty": 2,
      "x": 1006,
      "y": 263
    },
    {
      "t": 9900,
      "e": 7402,
      "ty": 2,
      "x": 1050,
      "y": 480
    },
    {
      "t": 9999,
      "e": 7501,
      "ty": 2,
      "x": 1059,
      "y": 569
    },
    {
      "t": 10000,
      "e": 7502,
      "ty": 41,
      "x": 38201,
      "y": 34610,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 7502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10100,
      "e": 7602,
      "ty": 2,
      "x": 1045,
      "y": 639
    },
    {
      "t": 10200,
      "e": 7702,
      "ty": 2,
      "x": 1045,
      "y": 666
    },
    {
      "t": 10250,
      "e": 7752,
      "ty": 41,
      "x": 37436,
      "y": 43457,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10300,
      "e": 7802,
      "ty": 2,
      "x": 1050,
      "y": 712
    },
    {
      "t": 10400,
      "e": 7902,
      "ty": 2,
      "x": 1053,
      "y": 728
    },
    {
      "t": 10500,
      "e": 8002,
      "ty": 2,
      "x": 1057,
      "y": 760
    },
    {
      "t": 10500,
      "e": 8002,
      "ty": 41,
      "x": 38092,
      "y": 50257,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10599,
      "e": 8101,
      "ty": 2,
      "x": 1063,
      "y": 780
    },
    {
      "t": 10626,
      "e": 8128,
      "ty": 3,
      "x": 1063,
      "y": 781,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10700,
      "e": 8202,
      "ty": 2,
      "x": 1064,
      "y": 784
    },
    {
      "t": 10749,
      "e": 8251,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 10750,
      "e": 8252,
      "ty": 41,
      "x": 38474,
      "y": 52878,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10800,
      "e": 8302,
      "ty": 2,
      "x": 1064,
      "y": 806
    },
    {
      "t": 10962,
      "e": 8464,
      "ty": 3,
      "x": 1064,
      "y": 806,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11000,
      "e": 8502,
      "ty": 41,
      "x": 38474,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11099,
      "e": 8601,
      "ty": 2,
      "x": 1064,
      "y": 807
    },
    {
      "t": 11122,
      "e": 8624,
      "ty": 4,
      "x": 38474,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11123,
      "e": 8625,
      "ty": 5,
      "x": 1064,
      "y": 807,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11250,
      "e": 8752,
      "ty": 41,
      "x": 38474,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11400,
      "e": 8902,
      "ty": 2,
      "x": 1064,
      "y": 805
    },
    {
      "t": 11499,
      "e": 9001,
      "ty": 2,
      "x": 1069,
      "y": 777
    },
    {
      "t": 11500,
      "e": 9002,
      "ty": 41,
      "x": 38747,
      "y": 51649,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17300,
      "e": 14002,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 17400,
      "e": 14102,
      "ty": 2,
      "x": 1069,
      "y": 843
    },
    {
      "t": 17500,
      "e": 14202,
      "ty": 41,
      "x": 38747,
      "y": 52714,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20000,
      "e": 16702,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27929,
      "e": 19202,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 29016,
      "e": 19202,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 36500,
      "e": 19202,
      "ty": 2,
      "x": 1052,
      "y": 696
    },
    {
      "t": 36500,
      "e": 19202,
      "ty": 41,
      "x": 37318,
      "y": 10773,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 36599,
      "e": 19301,
      "ty": 2,
      "x": 1060,
      "y": 687
    },
    {
      "t": 36750,
      "e": 19452,
      "ty": 41,
      "x": 37711,
      "y": 6560,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 36999,
      "e": 19701,
      "ty": 2,
      "x": 1018,
      "y": 683
    },
    {
      "t": 37000,
      "e": 19702,
      "ty": 41,
      "x": 35645,
      "y": 4688,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 37100,
      "e": 19802,
      "ty": 2,
      "x": 901,
      "y": 805
    },
    {
      "t": 37200,
      "e": 19902,
      "ty": 2,
      "x": 886,
      "y": 855
    },
    {
      "t": 37249,
      "e": 19951,
      "ty": 41,
      "x": 27823,
      "y": 61395,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 37299,
      "e": 20001,
      "ty": 2,
      "x": 858,
      "y": 896
    },
    {
      "t": 37400,
      "e": 20102,
      "ty": 2,
      "x": 817,
      "y": 904
    },
    {
      "t": 37499,
      "e": 20201,
      "ty": 2,
      "x": 792,
      "y": 919
    },
    {
      "t": 37499,
      "e": 20201,
      "ty": 41,
      "x": 24527,
      "y": 31672,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 37750,
      "e": 20452,
      "ty": 41,
      "x": 24625,
      "y": 31672,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 37799,
      "e": 20501,
      "ty": 2,
      "x": 805,
      "y": 922
    },
    {
      "t": 37900,
      "e": 20602,
      "ty": 2,
      "x": 807,
      "y": 922
    },
    {
      "t": 37923,
      "e": 20625,
      "ty": 3,
      "x": 807,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 38000,
      "e": 20702,
      "ty": 41,
      "x": 11673,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 38025,
      "e": 20727,
      "ty": 4,
      "x": 11673,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 38025,
      "e": 20727,
      "ty": 5,
      "x": 807,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 38026,
      "e": 20728,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 38030,
      "e": 20732,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 38199,
      "e": 20901,
      "ty": 2,
      "x": 935,
      "y": 1012
    },
    {
      "t": 38250,
      "e": 20952,
      "ty": 41,
      "x": 32004,
      "y": 61748,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 38300,
      "e": 21002,
      "ty": 2,
      "x": 944,
      "y": 1018
    },
    {
      "t": 38500,
      "e": 21202,
      "ty": 2,
      "x": 957,
      "y": 1058
    },
    {
      "t": 38500,
      "e": 21202,
      "ty": 41,
      "x": 32644,
      "y": 64517,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 38547,
      "e": 21249,
      "ty": 6,
      "x": 961,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 38600,
      "e": 21302,
      "ty": 2,
      "x": 962,
      "y": 1078
    },
    {
      "t": 38700,
      "e": 21402,
      "ty": 2,
      "x": 962,
      "y": 1079
    },
    {
      "t": 38730,
      "e": 21432,
      "ty": 3,
      "x": 962,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 38731,
      "e": 21433,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 38732,
      "e": 21434,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 38750,
      "e": 21452,
      "ty": 41,
      "x": 28671,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 38842,
      "e": 21544,
      "ty": 4,
      "x": 28671,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 38843,
      "e": 21545,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 38844,
      "e": 21546,
      "ty": 5,
      "x": 962,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 38845,
      "e": 21547,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 39848,
      "e": 22550,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 40000,
      "e": 22702,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40600,
      "e": 23302,
      "ty": 2,
      "x": 863,
      "y": 841
    },
    {
      "t": 40700,
      "e": 23402,
      "ty": 2,
      "x": 828,
      "y": 706
    },
    {
      "t": 40750,
      "e": 23452,
      "ty": 41,
      "x": 4325,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 40798,
      "e": 23500,
      "ty": 6,
      "x": 836,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40800,
      "e": 23502,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 40848,
      "e": 23550,
      "ty": 7,
      "x": 894,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40900,
      "e": 23602,
      "ty": 2,
      "x": 918,
      "y": 618
    },
    {
      "t": 41000,
      "e": 23702,
      "ty": 2,
      "x": 918,
      "y": 613
    },
    {
      "t": 41000,
      "e": 23702,
      "ty": 41,
      "x": 23791,
      "y": 64125,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41032,
      "e": 23734,
      "ty": 6,
      "x": 919,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41097,
      "e": 23799,
      "ty": 7,
      "x": 920,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41099,
      "e": 23801,
      "ty": 2,
      "x": 920,
      "y": 607
    },
    {
      "t": 41250,
      "e": 23952,
      "ty": 41,
      "x": 24224,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41385,
      "e": 24087,
      "ty": 6,
      "x": 922,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41400,
      "e": 24102,
      "ty": 2,
      "x": 923,
      "y": 601
    },
    {
      "t": 41500,
      "e": 24202,
      "ty": 2,
      "x": 923,
      "y": 597
    },
    {
      "t": 41500,
      "e": 24202,
      "ty": 41,
      "x": 24873,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41610,
      "e": 24312,
      "ty": 3,
      "x": 923,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41611,
      "e": 24313,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41737,
      "e": 24439,
      "ty": 4,
      "x": 24873,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41738,
      "e": 24440,
      "ty": 5,
      "x": 923,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43622,
      "e": 26324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 43774,
      "e": 26476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 43775,
      "e": 26477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43869,
      "e": 26571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "O"
    },
    {
      "t": 43973,
      "e": 26675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "O"
    },
    {
      "t": 44118,
      "e": 26820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 44118,
      "e": 26820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44245,
      "e": 26947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Os"
    },
    {
      "t": 44734,
      "e": 27436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 44735,
      "e": 27437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44868,
      "e": 27570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Osc"
    },
    {
      "t": 44885,
      "e": 27587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 44885,
      "e": 27587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45005,
      "e": 27707,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Osca"
    },
    {
      "t": 45078,
      "e": 27780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Osca"
    },
    {
      "t": 45678,
      "e": 28380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 45678,
      "e": 28380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45805,
      "e": 28507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 48117,
      "e": 30819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 48118,
      "e": 30820,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Oscar"
    },
    {
      "t": 48118,
      "e": 30820,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48119,
      "e": 30821,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48245,
      "e": 30947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 49711,
      "e": 32413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 49711,
      "e": 32413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49829,
      "e": 32531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 49926,
      "e": 32628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 49927,
      "e": 32629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50001,
      "e": 32703,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50013,
      "e": 32715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 50293,
      "e": 32995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 50293,
      "e": 32995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50398,
      "e": 33100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 50533,
      "e": 33235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 50534,
      "e": 33236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50645,
      "e": 33347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 52173,
      "e": 34875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 52262,
      "e": 34964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 53269,
      "e": 35971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 53341,
      "e": 36043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 53746,
      "e": 36448,
      "ty": 7,
      "x": 953,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53750,
      "e": 36452,
      "ty": 41,
      "x": 31361,
      "y": 58513,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 53801,
      "e": 36503,
      "ty": 2,
      "x": 1073,
      "y": 478
    },
    {
      "t": 53901,
      "e": 36603,
      "ty": 2,
      "x": 1080,
      "y": 478
    },
    {
      "t": 54000,
      "e": 36702,
      "ty": 2,
      "x": 1083,
      "y": 642
    },
    {
      "t": 54001,
      "e": 36703,
      "ty": 41,
      "x": 59478,
      "y": 21064,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 54101,
      "e": 36803,
      "ty": 2,
      "x": 1072,
      "y": 652
    },
    {
      "t": 54176,
      "e": 36878,
      "ty": 6,
      "x": 978,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54192,
      "e": 36894,
      "ty": 7,
      "x": 953,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54201,
      "e": 36903,
      "ty": 2,
      "x": 953,
      "y": 704
    },
    {
      "t": 54210,
      "e": 36912,
      "ty": 6,
      "x": 930,
      "y": 714,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54251,
      "e": 36953,
      "ty": 41,
      "x": 16017,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54300,
      "e": 37002,
      "ty": 2,
      "x": 927,
      "y": 716
    },
    {
      "t": 54400,
      "e": 37102,
      "ty": 2,
      "x": 928,
      "y": 723
    },
    {
      "t": 54501,
      "e": 37203,
      "ty": 41,
      "x": 16532,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54538,
      "e": 37240,
      "ty": 3,
      "x": 928,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54539,
      "e": 37241,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 54540,
      "e": 37242,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54541,
      "e": 37243,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54641,
      "e": 37343,
      "ty": 4,
      "x": 16532,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54643,
      "e": 37345,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54643,
      "e": 37345,
      "ty": 5,
      "x": 928,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54644,
      "e": 37346,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 54900,
      "e": 37602,
      "ty": 2,
      "x": 943,
      "y": 705
    },
    {
      "t": 55000,
      "e": 37702,
      "ty": 2,
      "x": 945,
      "y": 703
    },
    {
      "t": 55001,
      "e": 37703,
      "ty": 41,
      "x": 32268,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 55100,
      "e": 37802,
      "ty": 2,
      "x": 950,
      "y": 708
    },
    {
      "t": 55200,
      "e": 37902,
      "ty": 2,
      "x": 961,
      "y": 700
    },
    {
      "t": 55250,
      "e": 37952,
      "ty": 41,
      "x": 32853,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 55300,
      "e": 38002,
      "ty": 2,
      "x": 962,
      "y": 699
    },
    {
      "t": 55728,
      "e": 38430,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 55757,
      "e": 38459,
      "ty": 6,
      "x": 962,
      "y": 699,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 57531,
      "e": 40233,
      "ty": 7,
      "x": 963,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 57531,
      "e": 40233,
      "ty": 6,
      "x": 963,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 57546,
      "e": 40248,
      "ty": 7,
      "x": 959,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 57547,
      "e": 40249,
      "ty": 6,
      "x": 959,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 57600,
      "e": 40302,
      "ty": 2,
      "x": 950,
      "y": 723
    },
    {
      "t": 57751,
      "e": 40453,
      "ty": 41,
      "x": 31309,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 58401,
      "e": 41103,
      "ty": 2,
      "x": 949,
      "y": 723
    },
    {
      "t": 58500,
      "e": 41202,
      "ty": 41,
      "x": 31258,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 59001,
      "e": 41703,
      "ty": 2,
      "x": 947,
      "y": 723
    },
    {
      "t": 59001,
      "e": 41703,
      "ty": 41,
      "x": 31157,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 59100,
      "e": 41802,
      "ty": 2,
      "x": 946,
      "y": 723
    },
    {
      "t": 59251,
      "e": 41953,
      "ty": 41,
      "x": 31106,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 59853,
      "e": 42555,
      "ty": 7,
      "x": 942,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 59855,
      "e": 42557,
      "ty": 6,
      "x": 942,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 59904,
      "e": 42606,
      "ty": 2,
      "x": 930,
      "y": 753
    },
    {
      "t": 59918,
      "e": 42620,
      "ty": 7,
      "x": 926,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 59920,
      "e": 42622,
      "ty": 6,
      "x": 926,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 59936,
      "e": 42638,
      "ty": 7,
      "x": 923,
      "y": 789,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 60005,
      "e": 42707,
      "ty": 2,
      "x": 905,
      "y": 824
    },
    {
      "t": 60005,
      "e": 42707,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60007,
      "e": 42709,
      "ty": 41,
      "x": 30086,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 63504,
      "e": 46206,
      "ty": 2,
      "x": 905,
      "y": 828
    },
    {
      "t": 63504,
      "e": 46206,
      "ty": 41,
      "x": 30086,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 63604,
      "e": 46306,
      "ty": 2,
      "x": 916,
      "y": 856
    },
    {
      "t": 63704,
      "e": 46406,
      "ty": 2,
      "x": 982,
      "y": 922
    },
    {
      "t": 63754,
      "e": 46456,
      "ty": 41,
      "x": 35104,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 63804,
      "e": 46506,
      "ty": 2,
      "x": 1009,
      "y": 941
    },
    {
      "t": 63904,
      "e": 46606,
      "ty": 2,
      "x": 1003,
      "y": 954
    },
    {
      "t": 64004,
      "e": 46706,
      "ty": 2,
      "x": 982,
      "y": 990
    },
    {
      "t": 64005,
      "e": 46707,
      "ty": 41,
      "x": 33874,
      "y": 59809,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64104,
      "e": 46806,
      "ty": 2,
      "x": 982,
      "y": 992
    },
    {
      "t": 64255,
      "e": 46957,
      "ty": 41,
      "x": 33874,
      "y": 59947,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64404,
      "e": 47106,
      "ty": 2,
      "x": 981,
      "y": 992
    },
    {
      "t": 64503,
      "e": 47205,
      "ty": 2,
      "x": 981,
      "y": 997
    },
    {
      "t": 64503,
      "e": 47205,
      "ty": 41,
      "x": 33825,
      "y": 60293,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64604,
      "e": 47306,
      "ty": 2,
      "x": 984,
      "y": 1018
    },
    {
      "t": 64703,
      "e": 47405,
      "ty": 2,
      "x": 978,
      "y": 1053
    },
    {
      "t": 64754,
      "e": 47456,
      "ty": 41,
      "x": 33579,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64804,
      "e": 47506,
      "ty": 2,
      "x": 968,
      "y": 1061
    },
    {
      "t": 64904,
      "e": 47606,
      "ty": 2,
      "x": 963,
      "y": 1065
    },
    {
      "t": 64957,
      "e": 47659,
      "ty": 6,
      "x": 962,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 65003,
      "e": 47705,
      "ty": 2,
      "x": 961,
      "y": 1073
    },
    {
      "t": 65004,
      "e": 47706,
      "ty": 41,
      "x": 28125,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 65103,
      "e": 47805,
      "ty": 2,
      "x": 961,
      "y": 1079
    },
    {
      "t": 65254,
      "e": 47956,
      "ty": 41,
      "x": 28125,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 66742,
      "e": 49444,
      "ty": 3,
      "x": 961,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 66744,
      "e": 49446,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66965,
      "e": 49667,
      "ty": 4,
      "x": 28125,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 66967,
      "e": 49669,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66968,
      "e": 49670,
      "ty": 5,
      "x": 961,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 66970,
      "e": 49672,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 67972,
      "e": 50674,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 70004,
      "e": 52706,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73704,
      "e": 54670,
      "ty": 2,
      "x": 960,
      "y": 1079
    },
    {
      "t": 73753,
      "e": 54719,
      "ty": 41,
      "x": 32681,
      "y": 59164,
      "ta": "html > body"
    },
    {
      "t": 73804,
      "e": 54770,
      "ty": 2,
      "x": 955,
      "y": 1074
    },
    {
      "t": 73903,
      "e": 54869,
      "ty": 2,
      "x": 954,
      "y": 1073
    },
    {
      "t": 74004,
      "e": 54970,
      "ty": 2,
      "x": 951,
      "y": 1069
    },
    {
      "t": 74004,
      "e": 54970,
      "ty": 41,
      "x": 32474,
      "y": 58776,
      "ta": "html > body"
    },
    {
      "t": 74404,
      "e": 55370,
      "ty": 2,
      "x": 940,
      "y": 1067
    },
    {
      "t": 74504,
      "e": 55470,
      "ty": 2,
      "x": 936,
      "y": 1064
    },
    {
      "t": 74504,
      "e": 55470,
      "ty": 41,
      "x": 31958,
      "y": 58499,
      "ta": "html > body"
    },
    {
      "t": 74604,
      "e": 55570,
      "ty": 2,
      "x": 937,
      "y": 1056
    },
    {
      "t": 74703,
      "e": 55669,
      "ty": 2,
      "x": 943,
      "y": 1046
    },
    {
      "t": 74754,
      "e": 55720,
      "ty": 41,
      "x": 32199,
      "y": 57502,
      "ta": "html > body"
    },
    {
      "t": 74804,
      "e": 55770,
      "ty": 2,
      "x": 947,
      "y": 1043
    },
    {
      "t": 74904,
      "e": 55870,
      "ty": 2,
      "x": 953,
      "y": 1037
    },
    {
      "t": 75004,
      "e": 55970,
      "ty": 41,
      "x": 32543,
      "y": 57003,
      "ta": "html > body"
    },
    {
      "t": 75703,
      "e": 56669,
      "ty": 2,
      "x": 957,
      "y": 1034
    },
    {
      "t": 75754,
      "e": 56720,
      "ty": 41,
      "x": 32239,
      "y": 59683,
      "ta": "> p"
    },
    {
      "t": 75804,
      "e": 56770,
      "ty": 2,
      "x": 958,
      "y": 1033
    },
    {
      "t": 76254,
      "e": 57220,
      "ty": 41,
      "x": 34363,
      "y": 47980,
      "ta": "> p"
    },
    {
      "t": 76304,
      "e": 57270,
      "ty": 2,
      "x": 969,
      "y": 1024
    },
    {
      "t": 76381,
      "e": 57347,
      "ty": 3,
      "x": 970,
      "y": 1024,
      "ta": "> p"
    },
    {
      "t": 76404,
      "e": 57370,
      "ty": 2,
      "x": 970,
      "y": 1024
    },
    {
      "t": 76504,
      "e": 57470,
      "ty": 41,
      "x": 36487,
      "y": 38618,
      "ta": "> p"
    },
    {
      "t": 76541,
      "e": 57507,
      "ty": 4,
      "x": 36487,
      "y": 38618,
      "ta": "> p"
    },
    {
      "t": 76541,
      "e": 57507,
      "ty": 5,
      "x": 970,
      "y": 1024,
      "ta": "> p"
    },
    {
      "t": 77323,
      "e": 58289,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 78254,
      "e": 59220,
      "ty": 41,
      "x": 33025,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 78304,
      "e": 59270,
      "ty": 2,
      "x": 959,
      "y": 1022
    },
    {
      "t": 78329,
      "e": 59295,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 133, dom: 564, initialDom: 568",
  "javascriptErrors": []
}