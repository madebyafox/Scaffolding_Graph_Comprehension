var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05250758840a4aa1033d066efe15969481bc9afc"] = {
  "startTime": "2018-05-25T18:24:07.1612302Z",
  "websitePageUrl": "/16",
  "visitTime": 135564,
  "engagementTime": 114006,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "0cf3ee7573e9acef97b8ac96292ae176",
    "created": "2018-05-25T18:24:07.1612302+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ESMO3",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "88b7ed64a5d4ce658279144dcd0d2afe",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0cf3ee7573e9acef97b8ac96292ae176/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 237,
      "e": 237,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 42592,
      "y": 39996,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 458,
      "y": 692
    },
    {
      "t": 814,
      "e": 814,
      "ty": 6,
      "x": 455,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 451,
      "y": 676
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 450,
      "y": 674
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 60841,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 1567,
      "e": 1567,
      "ty": 7,
      "x": 433,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 1598,
      "e": 1598,
      "ty": 6,
      "x": 417,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 417,
      "y": 588
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 408,
      "y": 557
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 34948,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1853,
      "e": 1853,
      "ty": 3,
      "x": 408,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1854,
      "e": 1854,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1924,
      "e": 1924,
      "ty": 4,
      "x": 34948,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1924,
      "e": 1924,
      "ty": 5,
      "x": 408,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 400,
      "y": 583
    },
    {
      "t": 2466,
      "e": 2466,
      "ty": 7,
      "x": 400,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 414,
      "y": 634
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 44660,
      "y": 8038,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 2516,
      "e": 2516,
      "ty": 6,
      "x": 447,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 2532,
      "e": 2532,
      "ty": 7,
      "x": 473,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 582,
      "y": 739
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 742,
      "y": 790
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 4241,
      "y": 46435,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 755,
      "y": 792
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 4299,
      "y": 46435,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 672,
      "y": 638
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 642,
      "y": 618
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 61252,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 3651,
      "e": 3651,
      "ty": 6,
      "x": 621,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 570,
      "y": 570
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 52147,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 560,
      "y": 565
    },
    {
      "t": 3909,
      "e": 3909,
      "ty": 3,
      "x": 560,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3980,
      "e": 3980,
      "ty": 4,
      "x": 52035,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3981,
      "e": 3981,
      "ty": 5,
      "x": 560,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 52035,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5836,
      "e": 5836,
      "ty": 7,
      "x": 629,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 741,
      "y": 700
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 869,
      "y": 799
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 5849,
      "y": 47342,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 954,
      "y": 850
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1065,
      "y": 914
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 27553,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1213,
      "y": 967
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1188,
      "y": 972
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 28329,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1172,
      "y": 974
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 63290,
      "y": 20735,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1170,
      "y": 974
    },
    {
      "t": 6902,
      "e": 6902,
      "ty": 2,
      "x": 1151,
      "y": 974
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 2,
      "x": 1134,
      "y": 971
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 1729,
      "y": 8447,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 626,
      "y": 758
    },
    {
      "t": 7202,
      "e": 7202,
      "ty": 2,
      "x": 413,
      "y": 626
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 44192,
      "y": 2795,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 412,
      "y": 625
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 414,
      "y": 617
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 35960,
      "y": 62026,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 420,
      "y": 613
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 2,
      "x": 420,
      "y": 612
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 36297,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 8102,
      "e": 8102,
      "ty": 2,
      "x": 420,
      "y": 610
    },
    {
      "t": 8121,
      "e": 8121,
      "ty": 6,
      "x": 420,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 413,
      "y": 596
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 35173,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 406,
      "y": 591
    },
    {
      "t": 8402,
      "e": 8402,
      "ty": 2,
      "x": 399,
      "y": 590
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 398,
      "y": 590
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 33824,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10603,
      "e": 10603,
      "ty": 3,
      "x": 398,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10699,
      "e": 10699,
      "ty": 4,
      "x": 33824,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10699,
      "e": 10699,
      "ty": 5,
      "x": 398,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11479,
      "e": 11479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11624,
      "e": 11624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11624,
      "e": 11624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11703,
      "e": 11703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X"
    },
    {
      "t": 11743,
      "e": 11743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11984,
      "e": 11984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-"
    },
    {
      "t": 12031,
      "e": 12031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12031,
      "e": 12031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12095,
      "e": 12095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X- "
    },
    {
      "t": 12203,
      "e": 12203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X- "
    },
    {
      "t": 12425,
      "e": 12425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12479,
      "e": 12479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-"
    },
    {
      "t": 12603,
      "e": 12603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-"
    },
    {
      "t": 12680,
      "e": 12680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12977,
      "e": 12977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12977,
      "e": 12977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13055,
      "e": 13055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-A"
    },
    {
      "t": 13087,
      "e": 13087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-A"
    },
    {
      "t": 13184,
      "e": 13184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13185,
      "e": 13185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13264,
      "e": 13264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Ax"
    },
    {
      "t": 13303,
      "e": 13303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13304,
      "e": 13304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13375,
      "e": 13375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13535,
      "e": 13535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13535,
      "e": 13535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13543,
      "e": 13543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 13640,
      "e": 13640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13696,
      "e": 13696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13696,
      "e": 13696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13803,
      "e": 13803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis d"
    },
    {
      "t": 13847,
      "e": 13847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 13864,
      "e": 13864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13864,
      "e": 13864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14004,
      "e": 14004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis de"
    },
    {
      "t": 14016,
      "e": 14016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14048,
      "e": 14048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14049,
      "e": 14049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14120,
      "e": 14120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14168,
      "e": 14168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14169,
      "e": 14169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14248,
      "e": 14248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14249,
      "e": 14249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14311,
      "e": 14311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 14351,
      "e": 14351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14351,
      "e": 14351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14367,
      "e": 14367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 14423,
      "e": 14423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14472,
      "e": 14472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14472,
      "e": 14472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14567,
      "e": 14567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14568,
      "e": 14568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14584,
      "e": 14584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 14640,
      "e": 14640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14640,
      "e": 14640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14640,
      "e": 14640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14712,
      "e": 14712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14793,
      "e": 14793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14793,
      "e": 14793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14968,
      "e": 14968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15128,
      "e": 15128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15439,
      "e": 15439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis determines"
    },
    {
      "t": 15599,
      "e": 15599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16099,
      "e": 16099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16132,
      "e": 16132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16164,
      "e": 16164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16199,
      "e": 16199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16231,
      "e": 16231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16264,
      "e": 16264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16297,
      "e": 16297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16330,
      "e": 16330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16351,
      "e": 16351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis d"
    },
    {
      "t": 16664,
      "e": 16664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16735,
      "e": 16735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis "
    },
    {
      "t": 16952,
      "e": 16952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17024,
      "e": 17024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis"
    },
    {
      "t": 17152,
      "e": 17152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17152,
      "e": 17152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17280,
      "e": 17280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17744,
      "e": 17744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17744,
      "e": 17744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17807,
      "e": 17807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17871,
      "e": 17871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17872,
      "e": 17872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17920,
      "e": 17920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17920,
      "e": 17920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18016,
      "e": 18016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 18048,
      "e": 18048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18993,
      "e": 18993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19055,
      "e": 19055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis is"
    },
    {
      "t": 19175,
      "e": 19175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19248,
      "e": 19248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis i"
    },
    {
      "t": 19416,
      "e": 19416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19487,
      "e": 19487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis "
    },
    {
      "t": 19603,
      "e": 19603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis "
    },
    {
      "t": 19736,
      "e": 19736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19736,
      "e": 19736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19807,
      "e": 19807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19807,
      "e": 19807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19856,
      "e": 19856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 19904,
      "e": 19904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19912,
      "e": 19912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19912,
      "e": 19912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19984,
      "e": 19984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20015,
      "e": 20015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20016,
      "e": 20016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20095,
      "e": 20095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20095,
      "e": 20095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20151,
      "e": 20151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 20215,
      "e": 20215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20312,
      "e": 20312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20313,
      "e": 20313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20375,
      "e": 20375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20375,
      "e": 20375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20407,
      "e": 20407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 20464,
      "e": 20464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20600,
      "e": 20600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20600,
      "e": 20600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20655,
      "e": 20655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20704,
      "e": 20704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20704,
      "e": 20704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20799,
      "e": 20799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20936,
      "e": 20936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20937,
      "e": 20937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21048,
      "e": 21048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21063,
      "e": 21063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21064,
      "e": 21064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21160,
      "e": 21160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28757,
      "e": 26160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28758,
      "e": 26161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28819,
      "e": 26222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28876,
      "e": 26279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28876,
      "e": 26279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28980,
      "e": 26383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28981,
      "e": 26384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29019,
      "e": 26422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||im"
    },
    {
      "t": 29067,
      "e": 26470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29067,
      "e": 26470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29068,
      "e": 26471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29147,
      "e": 26550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29148,
      "e": 26551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29212,
      "e": 26615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 29308,
      "e": 26711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30006,
      "e": 27409,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 39780,
      "e": 31711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39781,
      "e": 31712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39867,
      "e": 31798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39915,
      "e": 31846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39915,
      "e": 31846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40020,
      "e": 31951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40020,
      "e": 31951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40043,
      "e": 31974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 40100,
      "e": 32031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40196,
      "e": 32127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40196,
      "e": 32127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40315,
      "e": 32246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40316,
      "e": 32247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40331,
      "e": 32262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||da"
    },
    {
      "t": 40395,
      "e": 32326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40532,
      "e": 32463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 40533,
      "e": 32464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40587,
      "e": 32518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 40828,
      "e": 32759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40828,
      "e": 32759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40868,
      "e": 32799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41008,
      "e": 32939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of days"
    },
    {
      "t": 41204,
      "e": 33135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41274,
      "e": 33205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day"
    },
    {
      "t": 42468,
      "e": 34399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 42468,
      "e": 34399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42476,
      "e": 34407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42547,
      "e": 34478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 42635,
      "e": 34566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42987,
      "e": 34918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43052,
      "e": 34983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day"
    },
    {
      "t": 43260,
      "e": 35191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 43261,
      "e": 35192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43330,
      "e": 35261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 43387,
      "e": 35318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43388,
      "e": 35319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43524,
      "e": 35455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43652,
      "e": 35583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44150,
      "e": 36081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44183,
      "e": 36114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44216,
      "e": 36147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44249,
      "e": 36180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44251,
      "e": 36182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44251,
      "e": 36182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44323,
      "e": 36254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 44348,
      "e": 36279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44484,
      "e": 36415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44485,
      "e": 36416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44571,
      "e": 36502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44643,
      "e": 36574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44643,
      "e": 36574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44747,
      "e": 36678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44749,
      "e": 36680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44803,
      "e": 36734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 44851,
      "e": 36782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44924,
      "e": 36855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44924,
      "e": 36855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45027,
      "e": 36958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45051,
      "e": 36982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45053,
      "e": 36984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45107,
      "e": 37038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45171,
      "e": 37102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45171,
      "e": 37102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45283,
      "e": 37214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45308,
      "e": 37239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45308,
      "e": 37239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45435,
      "e": 37366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45435,
      "e": 37366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45475,
      "e": 37406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 45555,
      "e": 37486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46147,
      "e": 38078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46149,
      "e": 38080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46203,
      "e": 38134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46203,
      "e": 38134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46250,
      "e": 38181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 46331,
      "e": 38262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46372,
      "e": 38303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46372,
      "e": 38303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46451,
      "e": 38382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46476,
      "e": 38407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46478,
      "e": 38409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46547,
      "e": 38478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46547,
      "e": 38478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46587,
      "e": 38518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 46675,
      "e": 38606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46756,
      "e": 38687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46757,
      "e": 38688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46835,
      "e": 38766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46835,
      "e": 38766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46898,
      "e": 38829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 46971,
      "e": 38902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47012,
      "e": 38943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47015,
      "e": 38946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47067,
      "e": 38998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47123,
      "e": 39054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47123,
      "e": 39054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47219,
      "e": 39150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47220,
      "e": 39151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47243,
      "e": 39174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 47299,
      "e": 39230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47371,
      "e": 39302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47373,
      "e": 39304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47490,
      "e": 39421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47491,
      "e": 39422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47491,
      "e": 39422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47547,
      "e": 39478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47547,
      "e": 39478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47595,
      "e": 39526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 47652,
      "e": 39583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47652,
      "e": 39583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47708,
      "e": 39639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47764,
      "e": 39695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48500,
      "e": 40431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48501,
      "e": 40432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48608,
      "e": 40539,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the s"
    },
    {
      "t": 48620,
      "e": 40541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48763,
      "e": 40684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48764,
      "e": 40685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48851,
      "e": 40772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48876,
      "e": 40797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48876,
      "e": 40797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48994,
      "e": 40915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 48996,
      "e": 40917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48996,
      "e": 40917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49075,
      "e": 40996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49179,
      "e": 41100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49180,
      "e": 41101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49315,
      "e": 41236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49444,
      "e": 41365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49445,
      "e": 41366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49538,
      "e": 41459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49562,
      "e": 41483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49563,
      "e": 41484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49619,
      "e": 41540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49684,
      "e": 41605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49684,
      "e": 41605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49808,
      "e": 41729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of"
    },
    {
      "t": 49843,
      "e": 41764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 50028,
      "e": 41949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50029,
      "e": 41950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50115,
      "e": 42036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50155,
      "e": 42076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50155,
      "e": 42076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50211,
      "e": 42132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50211,
      "e": 42132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50275,
      "e": 42196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| h"
    },
    {
      "t": 50316,
      "e": 42237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50620,
      "e": 42541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50682,
      "e": 42603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start oft "
    },
    {
      "t": 50771,
      "e": 42692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50827,
      "e": 42748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start oft"
    },
    {
      "t": 50915,
      "e": 42836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50971,
      "e": 42892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of"
    },
    {
      "t": 50986,
      "e": 42907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50987,
      "e": 42908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51091,
      "e": 43012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51092,
      "e": 43013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51092,
      "e": 43013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51163,
      "e": 43084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51171,
      "e": 43092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51171,
      "e": 43092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51266,
      "e": 43187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51282,
      "e": 43203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51283,
      "e": 43204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51347,
      "e": 43268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51347,
      "e": 43268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51379,
      "e": 43300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 51443,
      "e": 43364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51620,
      "e": 43541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51621,
      "e": 43542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51707,
      "e": 43628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 51808,
      "e": 43729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the s"
    },
    {
      "t": 51891,
      "e": 43812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51893,
      "e": 43814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51962,
      "e": 43883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52011,
      "e": 43932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52011,
      "e": 43932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52091,
      "e": 44012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52099,
      "e": 44020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 52100,
      "e": 44021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52154,
      "e": 44075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 52243,
      "e": 44164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52244,
      "e": 44165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52308,
      "e": 44229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52516,
      "e": 44437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 52517,
      "e": 44438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52586,
      "e": 44507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;"
    },
    {
      "t": 53227,
      "e": 45148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53298,
      "e": 45219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift"
    },
    {
      "t": 53408,
      "e": 45220,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift"
    },
    {
      "t": 53451,
      "e": 45263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 53452,
      "e": 45264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53515,
      "e": 45327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 54506,
      "e": 46318,
      "ty": 2,
      "x": 433,
      "y": 569
    },
    {
      "t": 54506,
      "e": 46318,
      "ty": 41,
      "x": 37759,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54606,
      "e": 46418,
      "ty": 2,
      "x": 555,
      "y": 594
    },
    {
      "t": 54706,
      "e": 46518,
      "ty": 2,
      "x": 551,
      "y": 597
    },
    {
      "t": 54756,
      "e": 46568,
      "ty": 41,
      "x": 40906,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54806,
      "e": 46618,
      "ty": 2,
      "x": 374,
      "y": 583
    },
    {
      "t": 54906,
      "e": 46718,
      "ty": 2,
      "x": 328,
      "y": 571
    },
    {
      "t": 55006,
      "e": 46818,
      "ty": 2,
      "x": 306,
      "y": 562
    },
    {
      "t": 55006,
      "e": 46818,
      "ty": 41,
      "x": 23483,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55106,
      "e": 46918,
      "ty": 2,
      "x": 271,
      "y": 558
    },
    {
      "t": 55206,
      "e": 47018,
      "ty": 2,
      "x": 256,
      "y": 553
    },
    {
      "t": 55256,
      "e": 47068,
      "ty": 41,
      "x": 14827,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55306,
      "e": 47118,
      "ty": 2,
      "x": 178,
      "y": 543
    },
    {
      "t": 55406,
      "e": 47218,
      "ty": 2,
      "x": 118,
      "y": 539
    },
    {
      "t": 55505,
      "e": 47317,
      "ty": 2,
      "x": 116,
      "y": 538
    },
    {
      "t": 55505,
      "e": 47317,
      "ty": 41,
      "x": 2125,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55606,
      "e": 47418,
      "ty": 2,
      "x": 111,
      "y": 536
    },
    {
      "t": 55656,
      "e": 47468,
      "ty": 3,
      "x": 111,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55706,
      "e": 47518,
      "ty": 2,
      "x": 111,
      "y": 533
    },
    {
      "t": 55755,
      "e": 47567,
      "ty": 41,
      "x": 1900,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55806,
      "e": 47618,
      "ty": 2,
      "x": 129,
      "y": 525
    },
    {
      "t": 55906,
      "e": 47718,
      "ty": 2,
      "x": 286,
      "y": 524
    },
    {
      "t": 56005,
      "e": 47817,
      "ty": 2,
      "x": 454,
      "y": 524
    },
    {
      "t": 56005,
      "e": 47817,
      "ty": 41,
      "x": 40119,
      "y": 1023,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56105,
      "e": 47917,
      "ty": 2,
      "x": 496,
      "y": 523
    },
    {
      "t": 56215,
      "e": 48027,
      "ty": 4,
      "x": 44841,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56216,
      "e": 48028,
      "ty": 5,
      "x": 496,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56255,
      "e": 48067,
      "ty": 41,
      "x": 46976,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56305,
      "e": 48117,
      "ty": 2,
      "x": 596,
      "y": 522
    },
    {
      "t": 56405,
      "e": 48217,
      "ty": 2,
      "x": 636,
      "y": 522
    },
    {
      "t": 56424,
      "e": 48236,
      "ty": 3,
      "x": 636,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56505,
      "e": 48317,
      "ty": 41,
      "x": 60578,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56510,
      "e": 48322,
      "ty": 4,
      "x": 60578,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56510,
      "e": 48322,
      "ty": 5,
      "x": 636,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56705,
      "e": 48517,
      "ty": 2,
      "x": 636,
      "y": 524
    },
    {
      "t": 56755,
      "e": 48567,
      "ty": 41,
      "x": 60578,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56805,
      "e": 48617,
      "ty": 2,
      "x": 639,
      "y": 531
    },
    {
      "t": 56905,
      "e": 48717,
      "ty": 2,
      "x": 643,
      "y": 539
    },
    {
      "t": 56952,
      "e": 48764,
      "ty": 3,
      "x": 643,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57005,
      "e": 48817,
      "ty": 41,
      "x": 61365,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57023,
      "e": 48835,
      "ty": 4,
      "x": 61365,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57023,
      "e": 48835,
      "ty": 5,
      "x": 643,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57205,
      "e": 49017,
      "ty": 2,
      "x": 661,
      "y": 547
    },
    {
      "t": 57256,
      "e": 49068,
      "ty": 41,
      "x": 63613,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57305,
      "e": 49117,
      "ty": 2,
      "x": 663,
      "y": 548
    },
    {
      "t": 57628,
      "e": 49440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 57628,
      "e": 49440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57675,
      "e": 49487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 57809,
      "e": 49621,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\n"
    },
    {
      "t": 58404,
      "e": 50216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58903,
      "e": 50715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58936,
      "e": 50748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58969,
      "e": 50781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59003,
      "e": 50815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59035,
      "e": 50847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59052,
      "e": 50864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59052,
      "e": 50864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59156,
      "e": 50968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 59163,
      "e": 50975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59171,
      "e": 50983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59220,
      "e": 51032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59307,
      "e": 51119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59308,
      "e": 51120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59387,
      "e": 51199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 59427,
      "e": 51239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59428,
      "e": 51240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59531,
      "e": 51343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60006,
      "e": 51818,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60139,
      "e": 51951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60139,
      "e": 51951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60211,
      "e": 52023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60316,
      "e": 52128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60316,
      "e": 52128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60371,
      "e": 52183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 60419,
      "e": 52231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60419,
      "e": 52231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60466,
      "e": 52278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60607,
      "e": 52419,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on "
    },
    {
      "t": 60627,
      "e": 52439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60628,
      "e": 52440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60675,
      "e": 52487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60700,
      "e": 52512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60700,
      "e": 52512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60763,
      "e": 52575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60779,
      "e": 52591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60779,
      "e": 52591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60851,
      "e": 52663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60851,
      "e": 52663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60907,
      "e": 52719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 60955,
      "e": 52767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61483,
      "e": 53295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 61484,
      "e": 53296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61571,
      "e": 53383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 61604,
      "e": 53416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 61604,
      "e": 53416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61650,
      "e": 53462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 61979,
      "e": 53791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62026,
      "e": 53838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the x"
    },
    {
      "t": 62122,
      "e": 53934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62179,
      "e": 53991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the "
    },
    {
      "t": 62508,
      "e": 54320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 62659,
      "e": 54471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 62660,
      "e": 54472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62675,
      "e": 54487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 62722,
      "e": 54534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62818,
      "e": 54630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 62818,
      "e": 54630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62891,
      "e": 54703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 63008,
      "e": 54820,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the X-"
    },
    {
      "t": 63331,
      "e": 55143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 63332,
      "e": 55144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63402,
      "e": 55214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 63732,
      "e": 55544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 63732,
      "e": 55544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63811,
      "e": 55623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 63844,
      "e": 55656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63845,
      "e": 55657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63898,
      "e": 55710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 63970,
      "e": 55782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63971,
      "e": 55783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64067,
      "e": 55879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 64140,
      "e": 55952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64140,
      "e": 55952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64242,
      "e": 56054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64491,
      "e": 56303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64492,
      "e": 56304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64531,
      "e": 56343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64763,
      "e": 56575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64810,
      "e": 56622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the X-axis "
    },
    {
      "t": 64971,
      "e": 56783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 64972,
      "e": 56784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65042,
      "e": 56854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 65067,
      "e": 56879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65067,
      "e": 56879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65131,
      "e": 56943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 65235,
      "e": 57047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65236,
      "e": 57048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65275,
      "e": 57087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 65347,
      "e": 57159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65347,
      "e": 57159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65404,
      "e": 57216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 65474,
      "e": 57286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65474,
      "e": 57286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65522,
      "e": 57286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 65523,
      "e": 57287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65562,
      "e": 57326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 65626,
      "e": 57390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65771,
      "e": 57535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65771,
      "e": 57535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65850,
      "e": 57614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 65890,
      "e": 57654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65890,
      "e": 57654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65994,
      "e": 57758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66131,
      "e": 57895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66131,
      "e": 57895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66227,
      "e": 57991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66227,
      "e": 57991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66250,
      "e": 58014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 66291,
      "e": 58055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66339,
      "e": 58103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66339,
      "e": 58103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66451,
      "e": 58215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66915,
      "e": 58679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 66916,
      "e": 58680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67002,
      "e": 58766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 67042,
      "e": 58806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 67042,
      "e": 58806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67107,
      "e": 58871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67107,
      "e": 58871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67162,
      "e": 58926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 67187,
      "e": 58951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67548,
      "e": 59312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 67550,
      "e": 59314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67618,
      "e": 59382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 67626,
      "e": 59390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 67626,
      "e": 59390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67698,
      "e": 59462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67698,
      "e": 59462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67730,
      "e": 59494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 67763,
      "e": 59527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67819,
      "e": 59583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 67820,
      "e": 59584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67866,
      "e": 59630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67866,
      "e": 59630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67883,
      "e": 59647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 67963,
      "e": 59727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71980,
      "e": 63744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 71980,
      "e": 63744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72066,
      "e": 63830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 72162,
      "e": 63926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 72162,
      "e": 63926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72291,
      "e": 64055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 72427,
      "e": 64191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72428,
      "e": 64192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72530,
      "e": 64294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72771,
      "e": 64535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72826,
      "e": 64590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the X-axis matters in finding 12"
    },
    {
      "t": 72946,
      "e": 64710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 72947,
      "e": 64711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73002,
      "e": 64766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 73123,
      "e": 64887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 73124,
      "e": 64888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73203,
      "e": 64967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 73267,
      "e": 65031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73267,
      "e": 65031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73346,
      "e": 65110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73410,
      "e": 65174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73410,
      "e": 65174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73498,
      "e": 65262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 73608,
      "e": 65372,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the X-axis matters in finding 12pm s"
    },
    {
      "t": 73715,
      "e": 65479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73716,
      "e": 65480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73753,
      "e": 65517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 73987,
      "e": 65751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74050,
      "e": 65814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo on the X-axis matters in finding 12pm s"
    },
    {
      "t": 74506,
      "e": 66270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74507,
      "e": 66271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74578,
      "e": 66342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74634,
      "e": 66398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74635,
      "e": 66399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74706,
      "e": 66470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74730,
      "e": 66494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 74731,
      "e": 66495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74786,
      "e": 66550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 74882,
      "e": 66646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74882,
      "e": 66646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74939,
      "e": 66703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74987,
      "e": 66751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 74987,
      "e": 66751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75050,
      "e": 66751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 77335,
      "e": 69036,
      "ty": 7,
      "x": 686,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77406,
      "e": 69107,
      "ty": 2,
      "x": 795,
      "y": 495
    },
    {
      "t": 77506,
      "e": 69207,
      "ty": 2,
      "x": 680,
      "y": 475
    },
    {
      "t": 77506,
      "e": 69207,
      "ty": 41,
      "x": 0,
      "y": 23927,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 77563,
      "e": 69264,
      "ty": 6,
      "x": 412,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77605,
      "e": 69306,
      "ty": 2,
      "x": 387,
      "y": 541
    },
    {
      "t": 77706,
      "e": 69407,
      "ty": 2,
      "x": 365,
      "y": 545
    },
    {
      "t": 77756,
      "e": 69457,
      "ty": 41,
      "x": 28204,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77806,
      "e": 69507,
      "ty": 2,
      "x": 345,
      "y": 545
    },
    {
      "t": 77905,
      "e": 69606,
      "ty": 2,
      "x": 338,
      "y": 546
    },
    {
      "t": 78006,
      "e": 69707,
      "ty": 2,
      "x": 313,
      "y": 548
    },
    {
      "t": 78006,
      "e": 69707,
      "ty": 41,
      "x": 24270,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78105,
      "e": 69806,
      "ty": 2,
      "x": 238,
      "y": 546
    },
    {
      "t": 78206,
      "e": 69907,
      "ty": 2,
      "x": 194,
      "y": 550
    },
    {
      "t": 78256,
      "e": 69957,
      "ty": 41,
      "x": 9319,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78306,
      "e": 70007,
      "ty": 2,
      "x": 146,
      "y": 550
    },
    {
      "t": 78406,
      "e": 70107,
      "ty": 2,
      "x": 131,
      "y": 553
    },
    {
      "t": 78505,
      "e": 70206,
      "ty": 2,
      "x": 125,
      "y": 556
    },
    {
      "t": 78506,
      "e": 70207,
      "ty": 41,
      "x": 3136,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78511,
      "e": 70212,
      "ty": 3,
      "x": 125,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78598,
      "e": 70299,
      "ty": 4,
      "x": 3136,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78598,
      "e": 70299,
      "ty": 5,
      "x": 125,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78705,
      "e": 70406,
      "ty": 2,
      "x": 167,
      "y": 547
    },
    {
      "t": 78756,
      "e": 70457,
      "ty": 41,
      "x": 7858,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79355,
      "e": 71056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 79458,
      "e": 71159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79666,
      "e": 71367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 79786,
      "e": 71487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80123,
      "e": 71824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 80124,
      "e": 71825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80194,
      "e": 71895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo onl the X-axis matters in finding 12pm start."
    },
    {
      "t": 80258,
      "e": 71959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 80258,
      "e": 71959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80315,
      "e": 72016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo only the X-axis matters in finding 12pm start."
    },
    {
      "t": 81406,
      "e": 73107,
      "ty": 2,
      "x": 290,
      "y": 563
    },
    {
      "t": 81506,
      "e": 73207,
      "ty": 2,
      "x": 379,
      "y": 564
    },
    {
      "t": 81506,
      "e": 73207,
      "ty": 41,
      "x": 31689,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81605,
      "e": 73306,
      "ty": 2,
      "x": 449,
      "y": 574
    },
    {
      "t": 81706,
      "e": 73407,
      "ty": 2,
      "x": 566,
      "y": 579
    },
    {
      "t": 81756,
      "e": 73457,
      "ty": 41,
      "x": 54845,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81805,
      "e": 73506,
      "ty": 2,
      "x": 585,
      "y": 571
    },
    {
      "t": 81840,
      "e": 73541,
      "ty": 3,
      "x": 585,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81934,
      "e": 73635,
      "ty": 4,
      "x": 54845,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81934,
      "e": 73635,
      "ty": 5,
      "x": 585,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82106,
      "e": 73807,
      "ty": 2,
      "x": 578,
      "y": 570
    },
    {
      "t": 82205,
      "e": 73906,
      "ty": 2,
      "x": 545,
      "y": 565
    },
    {
      "t": 82256,
      "e": 73957,
      "ty": 41,
      "x": 48662,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82267,
      "e": 73968,
      "ty": 7,
      "x": 524,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82306,
      "e": 74007,
      "ty": 2,
      "x": 513,
      "y": 655
    },
    {
      "t": 82405,
      "e": 74106,
      "ty": 2,
      "x": 505,
      "y": 674
    },
    {
      "t": 82506,
      "e": 74207,
      "ty": 41,
      "x": 45852,
      "y": 36894,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 82710,
      "e": 74411,
      "ty": 2,
      "x": 650,
      "y": 723
    },
    {
      "t": 82760,
      "e": 74461,
      "ty": 41,
      "x": 9866,
      "y": 45552,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 82809,
      "e": 74510,
      "ty": 2,
      "x": 965,
      "y": 778
    },
    {
      "t": 82909,
      "e": 74610,
      "ty": 2,
      "x": 992,
      "y": 809
    },
    {
      "t": 83010,
      "e": 74711,
      "ty": 2,
      "x": 1093,
      "y": 914
    },
    {
      "t": 83010,
      "e": 74711,
      "ty": 41,
      "x": 21634,
      "y": 55579,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 83109,
      "e": 74810,
      "ty": 2,
      "x": 1108,
      "y": 927
    },
    {
      "t": 83209,
      "e": 74910,
      "ty": 2,
      "x": 1184,
      "y": 947
    },
    {
      "t": 83259,
      "e": 74960,
      "ty": 41,
      "x": 30090,
      "y": 58086,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 83309,
      "e": 75010,
      "ty": 2,
      "x": 1214,
      "y": 948
    },
    {
      "t": 83409,
      "e": 75110,
      "ty": 2,
      "x": 1174,
      "y": 955
    },
    {
      "t": 83509,
      "e": 75210,
      "ty": 2,
      "x": 968,
      "y": 880
    },
    {
      "t": 83509,
      "e": 75210,
      "ty": 41,
      "x": 12826,
      "y": 53144,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 83609,
      "e": 75310,
      "ty": 2,
      "x": 492,
      "y": 622
    },
    {
      "t": 83709,
      "e": 75410,
      "ty": 2,
      "x": 492,
      "y": 621
    },
    {
      "t": 83755,
      "e": 75456,
      "ty": 6,
      "x": 485,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83759,
      "e": 75460,
      "ty": 41,
      "x": 43604,
      "y": 64940,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83809,
      "e": 75510,
      "ty": 2,
      "x": 482,
      "y": 583
    },
    {
      "t": 83909,
      "e": 75610,
      "ty": 2,
      "x": 479,
      "y": 567
    },
    {
      "t": 83978,
      "e": 75679,
      "ty": 3,
      "x": 478,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84009,
      "e": 75710,
      "ty": 2,
      "x": 478,
      "y": 562
    },
    {
      "t": 84010,
      "e": 75711,
      "ty": 41,
      "x": 42817,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84057,
      "e": 75758,
      "ty": 4,
      "x": 42817,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84058,
      "e": 75759,
      "ty": 5,
      "x": 478,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84409,
      "e": 76110,
      "ty": 2,
      "x": 465,
      "y": 601
    },
    {
      "t": 84440,
      "e": 76141,
      "ty": 7,
      "x": 463,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84509,
      "e": 76210,
      "ty": 2,
      "x": 455,
      "y": 613
    },
    {
      "t": 84509,
      "e": 76210,
      "ty": 41,
      "x": 40232,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 84609,
      "e": 76310,
      "ty": 2,
      "x": 425,
      "y": 646
    },
    {
      "t": 84639,
      "e": 76340,
      "ty": 6,
      "x": 420,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 84710,
      "e": 76411,
      "ty": 2,
      "x": 415,
      "y": 662
    },
    {
      "t": 84759,
      "e": 76460,
      "ty": 41,
      "x": 40635,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 84809,
      "e": 76510,
      "ty": 2,
      "x": 407,
      "y": 668
    },
    {
      "t": 84909,
      "e": 76610,
      "ty": 2,
      "x": 405,
      "y": 669
    },
    {
      "t": 85010,
      "e": 76711,
      "ty": 41,
      "x": 36266,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 85019,
      "e": 76720,
      "ty": 3,
      "x": 405,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 85020,
      "e": 76721,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "X-Axis represents time of day. The dots represent the start of the shift.\nSo only the X-axis matters in finding 12pm start."
    },
    {
      "t": 85021,
      "e": 76722,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85021,
      "e": 76722,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85098,
      "e": 76799,
      "ty": 4,
      "x": 36266,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 85107,
      "e": 76808,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85109,
      "e": 76810,
      "ty": 5,
      "x": 405,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 85115,
      "e": 76816,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 85310,
      "e": 77011,
      "ty": 2,
      "x": 405,
      "y": 687
    },
    {
      "t": 85409,
      "e": 77110,
      "ty": 2,
      "x": 414,
      "y": 739
    },
    {
      "t": 85510,
      "e": 77211,
      "ty": 41,
      "x": 13981,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 86117,
      "e": 77818,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 86408,
      "e": 78109,
      "ty": 2,
      "x": 422,
      "y": 731
    },
    {
      "t": 86508,
      "e": 78209,
      "ty": 2,
      "x": 651,
      "y": 676
    },
    {
      "t": 86509,
      "e": 78210,
      "ty": 41,
      "x": 22143,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 86590,
      "e": 78210,
      "ty": 6,
      "x": 813,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86609,
      "e": 78229,
      "ty": 2,
      "x": 838,
      "y": 658
    },
    {
      "t": 86710,
      "e": 78330,
      "ty": 2,
      "x": 855,
      "y": 651
    },
    {
      "t": 86759,
      "e": 78379,
      "ty": 41,
      "x": 10165,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86775,
      "e": 78395,
      "ty": 7,
      "x": 854,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86809,
      "e": 78429,
      "ty": 2,
      "x": 853,
      "y": 628
    },
    {
      "t": 86909,
      "e": 78529,
      "ty": 2,
      "x": 850,
      "y": 593
    },
    {
      "t": 87009,
      "e": 78629,
      "ty": 2,
      "x": 845,
      "y": 577
    },
    {
      "t": 87009,
      "e": 78629,
      "ty": 41,
      "x": 8002,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 87082,
      "e": 78702,
      "ty": 3,
      "x": 845,
      "y": 577,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 87146,
      "e": 78766,
      "ty": 4,
      "x": 8002,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 87146,
      "e": 78766,
      "ty": 5,
      "x": 845,
      "y": 577,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 87162,
      "e": 78782,
      "ty": 6,
      "x": 843,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87208,
      "e": 78828,
      "ty": 2,
      "x": 843,
      "y": 572
    },
    {
      "t": 87259,
      "e": 78879,
      "ty": 41,
      "x": 7570,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87308,
      "e": 78928,
      "ty": 2,
      "x": 843,
      "y": 567
    },
    {
      "t": 87337,
      "e": 78957,
      "ty": 3,
      "x": 843,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87338,
      "e": 78958,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87418,
      "e": 79038,
      "ty": 4,
      "x": 7570,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87418,
      "e": 79038,
      "ty": 5,
      "x": 843,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87509,
      "e": 79129,
      "ty": 41,
      "x": 7570,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87608,
      "e": 79228,
      "ty": 7,
      "x": 853,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87610,
      "e": 79230,
      "ty": 2,
      "x": 853,
      "y": 585
    },
    {
      "t": 87692,
      "e": 79312,
      "ty": 6,
      "x": 878,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87708,
      "e": 79328,
      "ty": 7,
      "x": 885,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87709,
      "e": 79329,
      "ty": 2,
      "x": 885,
      "y": 670
    },
    {
      "t": 87742,
      "e": 79362,
      "ty": 6,
      "x": 896,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87758,
      "e": 79378,
      "ty": 7,
      "x": 901,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87758,
      "e": 79378,
      "ty": 41,
      "x": 30752,
      "y": 39221,
      "ta": "html > body"
    },
    {
      "t": 87809,
      "e": 79429,
      "ty": 2,
      "x": 906,
      "y": 739
    },
    {
      "t": 87908,
      "e": 79528,
      "ty": 2,
      "x": 911,
      "y": 855
    },
    {
      "t": 88008,
      "e": 79628,
      "ty": 2,
      "x": 914,
      "y": 981
    },
    {
      "t": 88008,
      "e": 79628,
      "ty": 41,
      "x": 31200,
      "y": 53901,
      "ta": "html > body"
    },
    {
      "t": 88108,
      "e": 79728,
      "ty": 2,
      "x": 914,
      "y": 985
    },
    {
      "t": 88259,
      "e": 79879,
      "ty": 41,
      "x": 31200,
      "y": 54123,
      "ta": "html > body"
    },
    {
      "t": 90094,
      "e": 81714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 90095,
      "e": 81715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90158,
      "e": 81778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 90159,
      "e": 81779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90166,
      "e": 81786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 90197,
      "e": 81817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 90978,
      "e": 82598,
      "ty": 6,
      "x": 955,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90994,
      "e": 82614,
      "ty": 7,
      "x": 954,
      "y": 657,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90995,
      "e": 82615,
      "ty": 6,
      "x": 954,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91009,
      "e": 82629,
      "ty": 2,
      "x": 954,
      "y": 657
    },
    {
      "t": 91009,
      "e": 82629,
      "ty": 41,
      "x": 31577,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91028,
      "e": 82648,
      "ty": 7,
      "x": 953,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91109,
      "e": 82729,
      "ty": 2,
      "x": 953,
      "y": 644
    },
    {
      "t": 91259,
      "e": 82879,
      "ty": 41,
      "x": 31361,
      "y": 42985,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 91309,
      "e": 82929,
      "ty": 2,
      "x": 952,
      "y": 645
    },
    {
      "t": 91362,
      "e": 82982,
      "ty": 6,
      "x": 952,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91408,
      "e": 83028,
      "ty": 2,
      "x": 952,
      "y": 647
    },
    {
      "t": 91465,
      "e": 83085,
      "ty": 3,
      "x": 952,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91465,
      "e": 83085,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 91466,
      "e": 83086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91466,
      "e": 83086,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91509,
      "e": 83129,
      "ty": 41,
      "x": 31145,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91529,
      "e": 83149,
      "ty": 4,
      "x": 31145,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91529,
      "e": 83149,
      "ty": 5,
      "x": 952,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91709,
      "e": 83329,
      "ty": 2,
      "x": 950,
      "y": 652
    },
    {
      "t": 91759,
      "e": 83379,
      "ty": 41,
      "x": 28766,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91809,
      "e": 83429,
      "ty": 2,
      "x": 941,
      "y": 667
    },
    {
      "t": 92454,
      "e": 84074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 92622,
      "e": 84242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 92623,
      "e": 84243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92686,
      "e": 84306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 92726,
      "e": 84346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 92989,
      "e": 84609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93037,
      "e": 84657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 93118,
      "e": 84738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 93173,
      "e": 84793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 93614,
      "e": 85234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 94006,
      "e": 85626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 94007,
      "e": 85627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94069,
      "e": 85689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 94125,
      "e": 85745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 94126,
      "e": 85746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94190,
      "e": 85810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 94190,
      "e": 85810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94213,
      "e": 85833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 94270,
      "e": 85890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 94374,
      "e": 85994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 94868,
      "e": 86488,
      "ty": 7,
      "x": 940,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94868,
      "e": 86488,
      "ty": 6,
      "x": 940,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94881,
      "e": 86501,
      "ty": 7,
      "x": 932,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94908,
      "e": 86528,
      "ty": 2,
      "x": 907,
      "y": 779
    },
    {
      "t": 95009,
      "e": 86629,
      "ty": 2,
      "x": 863,
      "y": 832
    },
    {
      "t": 95009,
      "e": 86629,
      "ty": 41,
      "x": 29444,
      "y": 45647,
      "ta": "html > body"
    },
    {
      "t": 95109,
      "e": 86729,
      "ty": 2,
      "x": 862,
      "y": 832
    },
    {
      "t": 95209,
      "e": 86829,
      "ty": 2,
      "x": 868,
      "y": 810
    },
    {
      "t": 95259,
      "e": 86879,
      "ty": 41,
      "x": 30580,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 95298,
      "e": 86918,
      "ty": 6,
      "x": 920,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95308,
      "e": 86928,
      "ty": 2,
      "x": 920,
      "y": 706
    },
    {
      "t": 95409,
      "e": 87029,
      "ty": 2,
      "x": 921,
      "y": 700
    },
    {
      "t": 95509,
      "e": 87129,
      "ty": 41,
      "x": 12925,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95554,
      "e": 87174,
      "ty": 3,
      "x": 921,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95555,
      "e": 87175,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 95555,
      "e": 87175,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95557,
      "e": 87177,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95601,
      "e": 87221,
      "ty": 4,
      "x": 12925,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95601,
      "e": 87221,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95602,
      "e": 87222,
      "ty": 5,
      "x": 921,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95602,
      "e": 87222,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 96623,
      "e": 88243,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 97258,
      "e": 88878,
      "ty": 41,
      "x": 26242,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 97309,
      "e": 88929,
      "ty": 2,
      "x": 853,
      "y": 309
    },
    {
      "t": 97409,
      "e": 89029,
      "ty": 2,
      "x": 843,
      "y": 267
    },
    {
      "t": 97500,
      "e": 89120,
      "ty": 6,
      "x": 837,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 97508,
      "e": 89128,
      "ty": 2,
      "x": 837,
      "y": 268
    },
    {
      "t": 97509,
      "e": 89129,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 98000,
      "e": 89620,
      "ty": 7,
      "x": 835,
      "y": 259,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 98009,
      "e": 89629,
      "ty": 2,
      "x": 835,
      "y": 259
    },
    {
      "t": 98010,
      "e": 89630,
      "ty": 41,
      "x": 10341,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 98109,
      "e": 89729,
      "ty": 2,
      "x": 834,
      "y": 248
    },
    {
      "t": 98178,
      "e": 89798,
      "ty": 3,
      "x": 834,
      "y": 247,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 98208,
      "e": 89828,
      "ty": 2,
      "x": 834,
      "y": 247
    },
    {
      "t": 98259,
      "e": 89879,
      "ty": 41,
      "x": 10299,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 98265,
      "e": 89885,
      "ty": 4,
      "x": 10299,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 98265,
      "e": 89885,
      "ty": 5,
      "x": 834,
      "y": 245,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 98265,
      "e": 89885,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98266,
      "e": 89886,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 98309,
      "e": 89929,
      "ty": 2,
      "x": 834,
      "y": 245
    },
    {
      "t": 98633,
      "e": 90253,
      "ty": 6,
      "x": 829,
      "y": 266,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 98651,
      "e": 90271,
      "ty": 7,
      "x": 818,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 98709,
      "e": 90329,
      "ty": 2,
      "x": 812,
      "y": 338
    },
    {
      "t": 98759,
      "e": 90379,
      "ty": 41,
      "x": 27687,
      "y": 18779,
      "ta": "html > body"
    },
    {
      "t": 98808,
      "e": 90428,
      "ty": 2,
      "x": 818,
      "y": 358
    },
    {
      "t": 98909,
      "e": 90529,
      "ty": 2,
      "x": 827,
      "y": 388
    },
    {
      "t": 99001,
      "e": 90621,
      "ty": 6,
      "x": 832,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 99009,
      "e": 90629,
      "ty": 2,
      "x": 832,
      "y": 408
    },
    {
      "t": 99009,
      "e": 90629,
      "ty": 41,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 99084,
      "e": 90704,
      "ty": 7,
      "x": 833,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 99109,
      "e": 90729,
      "ty": 2,
      "x": 833,
      "y": 424
    },
    {
      "t": 99209,
      "e": 90829,
      "ty": 2,
      "x": 833,
      "y": 428
    },
    {
      "t": 99259,
      "e": 90879,
      "ty": 41,
      "x": 2747,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 99267,
      "e": 90887,
      "ty": 6,
      "x": 833,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 99284,
      "e": 90904,
      "ty": 7,
      "x": 833,
      "y": 454,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 99309,
      "e": 90929,
      "ty": 2,
      "x": 829,
      "y": 479
    },
    {
      "t": 99409,
      "e": 91029,
      "ty": 2,
      "x": 817,
      "y": 517
    },
    {
      "t": 99509,
      "e": 91129,
      "ty": 2,
      "x": 817,
      "y": 524
    },
    {
      "t": 99509,
      "e": 91129,
      "ty": 41,
      "x": 27860,
      "y": 28585,
      "ta": "html > body"
    },
    {
      "t": 99609,
      "e": 91229,
      "ty": 2,
      "x": 822,
      "y": 550
    },
    {
      "t": 99709,
      "e": 91329,
      "ty": 2,
      "x": 829,
      "y": 568
    },
    {
      "t": 99759,
      "e": 91379,
      "ty": 41,
      "x": 2273,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 99809,
      "e": 91429,
      "ty": 2,
      "x": 833,
      "y": 575
    },
    {
      "t": 99818,
      "e": 91438,
      "ty": 6,
      "x": 834,
      "y": 576,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 99909,
      "e": 91529,
      "ty": 2,
      "x": 838,
      "y": 580
    },
    {
      "t": 99984,
      "e": 91604,
      "ty": 7,
      "x": 838,
      "y": 574,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 100009,
      "e": 91629,
      "ty": 2,
      "x": 838,
      "y": 571
    },
    {
      "t": 100009,
      "e": 91629,
      "ty": 41,
      "x": 3934,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 100085,
      "e": 91705,
      "ty": 6,
      "x": 838,
      "y": 559,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 100108,
      "e": 91728,
      "ty": 2,
      "x": 838,
      "y": 558
    },
    {
      "t": 100259,
      "e": 91879,
      "ty": 41,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 100269,
      "e": 91889,
      "ty": 7,
      "x": 835,
      "y": 544,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 100309,
      "e": 91929,
      "ty": 2,
      "x": 835,
      "y": 541
    },
    {
      "t": 100409,
      "e": 92029,
      "ty": 2,
      "x": 834,
      "y": 533
    },
    {
      "t": 100476,
      "e": 92030,
      "ty": 6,
      "x": 834,
      "y": 530,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 100509,
      "e": 92063,
      "ty": 2,
      "x": 834,
      "y": 527
    },
    {
      "t": 100509,
      "e": 92063,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 100585,
      "e": 92139,
      "ty": 7,
      "x": 831,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 100602,
      "e": 92156,
      "ty": 6,
      "x": 831,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 100608,
      "e": 92162,
      "ty": 2,
      "x": 831,
      "y": 502
    },
    {
      "t": 100668,
      "e": 92222,
      "ty": 7,
      "x": 830,
      "y": 489,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 100709,
      "e": 92263,
      "ty": 2,
      "x": 830,
      "y": 489
    },
    {
      "t": 100760,
      "e": 92314,
      "ty": 41,
      "x": 7699,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 100808,
      "e": 92362,
      "ty": 2,
      "x": 828,
      "y": 481
    },
    {
      "t": 100909,
      "e": 92463,
      "ty": 2,
      "x": 828,
      "y": 477
    },
    {
      "t": 101011,
      "e": 92565,
      "ty": 41,
      "x": 6953,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 101019,
      "e": 92573,
      "ty": 6,
      "x": 828,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101109,
      "e": 92663,
      "ty": 2,
      "x": 828,
      "y": 470
    },
    {
      "t": 101259,
      "e": 92813,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101509,
      "e": 93063,
      "ty": 2,
      "x": 829,
      "y": 467
    },
    {
      "t": 101509,
      "e": 93063,
      "ty": 41,
      "x": 12996,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101570,
      "e": 93124,
      "ty": 7,
      "x": 832,
      "y": 460,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101602,
      "e": 93156,
      "ty": 6,
      "x": 838,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101609,
      "e": 93163,
      "ty": 2,
      "x": 838,
      "y": 446
    },
    {
      "t": 101709,
      "e": 93263,
      "ty": 2,
      "x": 839,
      "y": 436
    },
    {
      "t": 101719,
      "e": 93273,
      "ty": 7,
      "x": 839,
      "y": 434,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101759,
      "e": 93313,
      "ty": 41,
      "x": 14040,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101762,
      "e": 93316,
      "ty": 3,
      "x": 839,
      "y": 434,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101762,
      "e": 93316,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 101809,
      "e": 93363,
      "ty": 2,
      "x": 839,
      "y": 434
    },
    {
      "t": 101849,
      "e": 93403,
      "ty": 4,
      "x": 14040,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101849,
      "e": 93403,
      "ty": 5,
      "x": 839,
      "y": 434,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101850,
      "e": 93404,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101851,
      "e": 93405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 102066,
      "e": 93620,
      "ty": 6,
      "x": 839,
      "y": 438,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102087,
      "e": 93641,
      "ty": 7,
      "x": 839,
      "y": 453,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 102103,
      "e": 93657,
      "ty": 6,
      "x": 839,
      "y": 471,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 102109,
      "e": 93663,
      "ty": 2,
      "x": 839,
      "y": 471
    },
    {
      "t": 102120,
      "e": 93674,
      "ty": 7,
      "x": 840,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 102209,
      "e": 93763,
      "ty": 2,
      "x": 872,
      "y": 577
    },
    {
      "t": 102259,
      "e": 93813,
      "ty": 41,
      "x": 50209,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 102309,
      "e": 93863,
      "ty": 2,
      "x": 872,
      "y": 595
    },
    {
      "t": 102409,
      "e": 93963,
      "ty": 2,
      "x": 856,
      "y": 649
    },
    {
      "t": 102509,
      "e": 94063,
      "ty": 2,
      "x": 847,
      "y": 672
    },
    {
      "t": 102509,
      "e": 94063,
      "ty": 41,
      "x": 6867,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 102539,
      "e": 94064,
      "ty": 6,
      "x": 839,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 102553,
      "e": 94078,
      "ty": 7,
      "x": 833,
      "y": 688,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 102609,
      "e": 94134,
      "ty": 2,
      "x": 829,
      "y": 693
    },
    {
      "t": 102654,
      "e": 94179,
      "ty": 6,
      "x": 829,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 102709,
      "e": 94234,
      "ty": 2,
      "x": 829,
      "y": 698
    },
    {
      "t": 102759,
      "e": 94284,
      "ty": 41,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 102809,
      "e": 94334,
      "ty": 2,
      "x": 829,
      "y": 701
    },
    {
      "t": 102871,
      "e": 94396,
      "ty": 7,
      "x": 826,
      "y": 694,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 102909,
      "e": 94434,
      "ty": 2,
      "x": 825,
      "y": 689
    },
    {
      "t": 103009,
      "e": 94534,
      "ty": 2,
      "x": 825,
      "y": 680
    },
    {
      "t": 103010,
      "e": 94535,
      "ty": 41,
      "x": 960,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 103109,
      "e": 94634,
      "ty": 2,
      "x": 825,
      "y": 691
    },
    {
      "t": 103209,
      "e": 94734,
      "ty": 2,
      "x": 825,
      "y": 705
    },
    {
      "t": 103258,
      "e": 94783,
      "ty": 41,
      "x": 898,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 103271,
      "e": 94796,
      "ty": 6,
      "x": 826,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 103309,
      "e": 94834,
      "ty": 2,
      "x": 827,
      "y": 726
    },
    {
      "t": 103409,
      "e": 94934,
      "ty": 2,
      "x": 827,
      "y": 735
    },
    {
      "t": 103442,
      "e": 94967,
      "ty": 7,
      "x": 827,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 103509,
      "e": 95034,
      "ty": 2,
      "x": 827,
      "y": 751
    },
    {
      "t": 103509,
      "e": 95034,
      "ty": 41,
      "x": 2327,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 103521,
      "e": 95046,
      "ty": 6,
      "x": 827,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 103571,
      "e": 95096,
      "ty": 7,
      "x": 826,
      "y": 770,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 103609,
      "e": 95134,
      "ty": 2,
      "x": 824,
      "y": 773
    },
    {
      "t": 103709,
      "e": 95234,
      "ty": 2,
      "x": 824,
      "y": 790
    },
    {
      "t": 103759,
      "e": 95284,
      "ty": 41,
      "x": 883,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 103809,
      "e": 95334,
      "ty": 2,
      "x": 822,
      "y": 768
    },
    {
      "t": 103909,
      "e": 95434,
      "ty": 2,
      "x": 824,
      "y": 714
    },
    {
      "t": 103972,
      "e": 95497,
      "ty": 6,
      "x": 827,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104010,
      "e": 95535,
      "ty": 2,
      "x": 827,
      "y": 705
    },
    {
      "t": 104010,
      "e": 95535,
      "ty": 41,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104307,
      "e": 95832,
      "ty": 3,
      "x": 827,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104308,
      "e": 95833,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 104309,
      "e": 95834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104361,
      "e": 95886,
      "ty": 4,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104361,
      "e": 95886,
      "ty": 5,
      "x": 827,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104361,
      "e": 95886,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 104610,
      "e": 96135,
      "ty": 7,
      "x": 827,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104639,
      "e": 96164,
      "ty": 6,
      "x": 827,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 104656,
      "e": 96181,
      "ty": 7,
      "x": 827,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 104688,
      "e": 96213,
      "ty": 6,
      "x": 829,
      "y": 760,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 104705,
      "e": 96230,
      "ty": 7,
      "x": 829,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 104705,
      "e": 96230,
      "ty": 6,
      "x": 829,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 104708,
      "e": 96233,
      "ty": 2,
      "x": 829,
      "y": 791
    },
    {
      "t": 104723,
      "e": 96248,
      "ty": 7,
      "x": 830,
      "y": 800,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 104756,
      "e": 96248,
      "ty": 6,
      "x": 834,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 104759,
      "e": 96251,
      "ty": 41,
      "x": 38202,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 104809,
      "e": 96301,
      "ty": 2,
      "x": 835,
      "y": 811
    },
    {
      "t": 105009,
      "e": 96501,
      "ty": 41,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 105139,
      "e": 96631,
      "ty": 7,
      "x": 831,
      "y": 829,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 105157,
      "e": 96649,
      "ty": 6,
      "x": 826,
      "y": 839,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 105171,
      "e": 96663,
      "ty": 7,
      "x": 825,
      "y": 845,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 105208,
      "e": 96700,
      "ty": 2,
      "x": 824,
      "y": 859
    },
    {
      "t": 105259,
      "e": 96751,
      "ty": 41,
      "x": 849,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 105309,
      "e": 96801,
      "ty": 2,
      "x": 830,
      "y": 917
    },
    {
      "t": 105407,
      "e": 96899,
      "ty": 6,
      "x": 832,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105409,
      "e": 96901,
      "ty": 2,
      "x": 832,
      "y": 928
    },
    {
      "t": 105509,
      "e": 97001,
      "ty": 2,
      "x": 832,
      "y": 929
    },
    {
      "t": 105509,
      "e": 97001,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105563,
      "e": 97055,
      "ty": 3,
      "x": 835,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105563,
      "e": 97055,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105564,
      "e": 97056,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105609,
      "e": 97101,
      "ty": 2,
      "x": 836,
      "y": 930
    },
    {
      "t": 105625,
      "e": 97117,
      "ty": 4,
      "x": 48284,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105625,
      "e": 97117,
      "ty": 5,
      "x": 836,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105626,
      "e": 97118,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 105759,
      "e": 97251,
      "ty": 41,
      "x": 48284,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105809,
      "e": 97301,
      "ty": 2,
      "x": 836,
      "y": 934
    },
    {
      "t": 105857,
      "e": 97349,
      "ty": 7,
      "x": 836,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 105890,
      "e": 97382,
      "ty": 6,
      "x": 835,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 105909,
      "e": 97401,
      "ty": 2,
      "x": 835,
      "y": 962
    },
    {
      "t": 105990,
      "e": 97482,
      "ty": 7,
      "x": 835,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 106009,
      "e": 97501,
      "ty": 2,
      "x": 836,
      "y": 974
    },
    {
      "t": 106010,
      "e": 97502,
      "ty": 41,
      "x": 3459,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 106041,
      "e": 97533,
      "ty": 6,
      "x": 838,
      "y": 985,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 106090,
      "e": 97582,
      "ty": 7,
      "x": 840,
      "y": 992,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 106109,
      "e": 97601,
      "ty": 2,
      "x": 841,
      "y": 994
    },
    {
      "t": 106209,
      "e": 97701,
      "ty": 2,
      "x": 848,
      "y": 1004
    },
    {
      "t": 106227,
      "e": 97719,
      "ty": 6,
      "x": 848,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 106259,
      "e": 97751,
      "ty": 41,
      "x": 10090,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 106309,
      "e": 97801,
      "ty": 2,
      "x": 851,
      "y": 1010
    },
    {
      "t": 106510,
      "e": 98002,
      "ty": 41,
      "x": 11121,
      "y": 9929,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 106910,
      "e": 98402,
      "ty": 2,
      "x": 854,
      "y": 1013
    },
    {
      "t": 107009,
      "e": 98501,
      "ty": 2,
      "x": 855,
      "y": 1014
    },
    {
      "t": 107010,
      "e": 98502,
      "ty": 41,
      "x": 13182,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107219,
      "e": 98711,
      "ty": 3,
      "x": 855,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107219,
      "e": 98711,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 107220,
      "e": 98712,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107305,
      "e": 98797,
      "ty": 4,
      "x": 13182,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107305,
      "e": 98797,
      "ty": 5,
      "x": 855,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107307,
      "e": 98799,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 107308,
      "e": 98800,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 107308,
      "e": 98800,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 108633,
      "e": 100125,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 109509,
      "e": 101001,
      "ty": 2,
      "x": 857,
      "y": 1011
    },
    {
      "t": 109510,
      "e": 101002,
      "ty": 41,
      "x": 27724,
      "y": 61263,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109609,
      "e": 101101,
      "ty": 2,
      "x": 857,
      "y": 999
    },
    {
      "t": 109709,
      "e": 101201,
      "ty": 2,
      "x": 837,
      "y": 974
    },
    {
      "t": 109761,
      "e": 101202,
      "ty": 41,
      "x": 19656,
      "y": 8228,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 109808,
      "e": 101249,
      "ty": 2,
      "x": 340,
      "y": 599
    },
    {
      "t": 109909,
      "e": 101350,
      "ty": 2,
      "x": 283,
      "y": 501
    },
    {
      "t": 110010,
      "e": 101451,
      "ty": 2,
      "x": 306,
      "y": 452
    },
    {
      "t": 110010,
      "e": 101451,
      "ty": 41,
      "x": 617,
      "y": 55794,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 110109,
      "e": 101550,
      "ty": 2,
      "x": 438,
      "y": 395
    },
    {
      "t": 110210,
      "e": 101651,
      "ty": 2,
      "x": 475,
      "y": 388
    },
    {
      "t": 110259,
      "e": 101700,
      "ty": 41,
      "x": 63296,
      "y": 11519,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 112009,
      "e": 103450,
      "ty": 2,
      "x": 476,
      "y": 388
    },
    {
      "t": 112009,
      "e": 103450,
      "ty": 41,
      "x": 63644,
      "y": 11519,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 112110,
      "e": 103551,
      "ty": 2,
      "x": 496,
      "y": 426
    },
    {
      "t": 112210,
      "e": 103651,
      "ty": 2,
      "x": 588,
      "y": 500
    },
    {
      "t": 112260,
      "e": 103701,
      "ty": 41,
      "x": 14490,
      "y": 6832,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 112609,
      "e": 104050,
      "ty": 2,
      "x": 589,
      "y": 500
    },
    {
      "t": 112709,
      "e": 104150,
      "ty": 2,
      "x": 665,
      "y": 455
    },
    {
      "t": 112760,
      "e": 104201,
      "ty": 41,
      "x": 21181,
      "y": 24587,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 112810,
      "e": 104251,
      "ty": 2,
      "x": 758,
      "y": 386
    },
    {
      "t": 112909,
      "e": 104350,
      "ty": 2,
      "x": 791,
      "y": 371
    },
    {
      "t": 113009,
      "e": 104450,
      "ty": 41,
      "x": 24477,
      "y": 4228,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 120009,
      "e": 109450,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 131008,
      "e": 109450,
      "ty": 2,
      "x": 865,
      "y": 522
    },
    {
      "t": 131008,
      "e": 109450,
      "ty": 41,
      "x": 28118,
      "y": 15414,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 131109,
      "e": 109551,
      "ty": 2,
      "x": 951,
      "y": 725
    },
    {
      "t": 131209,
      "e": 109651,
      "ty": 2,
      "x": 984,
      "y": 797
    },
    {
      "t": 131259,
      "e": 109701,
      "ty": 41,
      "x": 33972,
      "y": 53552,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 131309,
      "e": 109751,
      "ty": 2,
      "x": 983,
      "y": 790
    },
    {
      "t": 131409,
      "e": 109851,
      "ty": 2,
      "x": 983,
      "y": 820
    },
    {
      "t": 131510,
      "e": 109952,
      "ty": 2,
      "x": 949,
      "y": 910
    },
    {
      "t": 131510,
      "e": 109952,
      "ty": 41,
      "x": 32250,
      "y": 54269,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 131609,
      "e": 110051,
      "ty": 2,
      "x": 941,
      "y": 914
    },
    {
      "t": 131759,
      "e": 110201,
      "ty": 41,
      "x": 31857,
      "y": 54546,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 131909,
      "e": 110351,
      "ty": 2,
      "x": 941,
      "y": 917
    },
    {
      "t": 132009,
      "e": 110451,
      "ty": 2,
      "x": 940,
      "y": 922
    },
    {
      "t": 132009,
      "e": 110451,
      "ty": 41,
      "x": 31808,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 132409,
      "e": 110851,
      "ty": 2,
      "x": 937,
      "y": 980
    },
    {
      "t": 132509,
      "e": 110951,
      "ty": 2,
      "x": 933,
      "y": 1059
    },
    {
      "t": 132510,
      "e": 110952,
      "ty": 41,
      "x": 31463,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 132609,
      "e": 111051,
      "ty": 2,
      "x": 933,
      "y": 1067
    },
    {
      "t": 132628,
      "e": 111070,
      "ty": 6,
      "x": 933,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 132709,
      "e": 111151,
      "ty": 2,
      "x": 935,
      "y": 1077
    },
    {
      "t": 132759,
      "e": 111201,
      "ty": 41,
      "x": 14472,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 132809,
      "e": 111251,
      "ty": 2,
      "x": 938,
      "y": 1082
    },
    {
      "t": 132909,
      "e": 111351,
      "ty": 2,
      "x": 941,
      "y": 1093
    },
    {
      "t": 132930,
      "e": 111372,
      "ty": 3,
      "x": 941,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 132931,
      "e": 111373,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133009,
      "e": 111451,
      "ty": 4,
      "x": 17202,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 133011,
      "e": 111453,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133012,
      "e": 111454,
      "ty": 5,
      "x": 941,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 133013,
      "e": 111455,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 133016,
      "e": 111458,
      "ty": 41,
      "x": 32130,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 134054,
      "e": 112496,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 135564,
      "e": 114006,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 294602, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 294609, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19611, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 315563, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10579, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 327146, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15149, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 343386, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15566, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 359953, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 40802, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 402152, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-10 AM-11 AM-11 AM-11 AM-11 AM-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1091,y:938,t:1527271771608};\\\", \\\"{x:1091,y:937,t:1527271771618};\\\", \\\"{x:1090,y:934,t:1527271771634};\\\", \\\"{x:1087,y:931,t:1527271771651};\\\", \\\"{x:1083,y:926,t:1527271771668};\\\", \\\"{x:1080,y:922,t:1527271771684};\\\", \\\"{x:1078,y:919,t:1527271771701};\\\", \\\"{x:1075,y:912,t:1527271771717};\\\", \\\"{x:1071,y:908,t:1527271771734};\\\", \\\"{x:1066,y:902,t:1527271771750};\\\", \\\"{x:1061,y:897,t:1527271771767};\\\", \\\"{x:1059,y:893,t:1527271771785};\\\", \\\"{x:1055,y:887,t:1527271771801};\\\", \\\"{x:1051,y:881,t:1527271771817};\\\", \\\"{x:1049,y:878,t:1527271771835};\\\", \\\"{x:1045,y:875,t:1527271771850};\\\", \\\"{x:1041,y:875,t:1527271771867};\\\", \\\"{x:1034,y:871,t:1527271771885};\\\", \\\"{x:1032,y:869,t:1527271771900};\\\", \\\"{x:1031,y:868,t:1527271771917};\\\", \\\"{x:1029,y:867,t:1527271771934};\\\", \\\"{x:1023,y:865,t:1527271771951};\\\", \\\"{x:1013,y:861,t:1527271771968};\\\", \\\"{x:1002,y:858,t:1527271771985};\\\", \\\"{x:996,y:857,t:1527271772000};\\\", \\\"{x:992,y:856,t:1527271772018};\\\", \\\"{x:987,y:855,t:1527271772035};\\\", \\\"{x:979,y:853,t:1527271772050};\\\", \\\"{x:975,y:850,t:1527271772068};\\\", \\\"{x:974,y:849,t:1527271772084};\\\", \\\"{x:975,y:849,t:1527271772527};\\\", \\\"{x:980,y:849,t:1527271772535};\\\", \\\"{x:993,y:849,t:1527271772552};\\\", \\\"{x:1008,y:849,t:1527271772568};\\\", \\\"{x:1020,y:850,t:1527271772585};\\\", \\\"{x:1033,y:851,t:1527271772602};\\\", \\\"{x:1041,y:853,t:1527271772619};\\\", \\\"{x:1047,y:853,t:1527271772635};\\\", \\\"{x:1057,y:855,t:1527271772652};\\\", \\\"{x:1069,y:857,t:1527271772668};\\\", \\\"{x:1080,y:860,t:1527271772685};\\\", \\\"{x:1097,y:868,t:1527271772702};\\\", \\\"{x:1104,y:872,t:1527271772718};\\\", \\\"{x:1112,y:878,t:1527271772735};\\\", \\\"{x:1121,y:884,t:1527271772752};\\\", \\\"{x:1128,y:892,t:1527271772769};\\\", \\\"{x:1137,y:904,t:1527271772785};\\\", \\\"{x:1143,y:916,t:1527271772802};\\\", \\\"{x:1146,y:922,t:1527271772819};\\\", \\\"{x:1152,y:929,t:1527271772835};\\\", \\\"{x:1167,y:936,t:1527271772852};\\\", \\\"{x:1170,y:940,t:1527271772869};\\\", \\\"{x:1170,y:944,t:1527271773270};\\\", \\\"{x:1170,y:951,t:1527271773285};\\\", \\\"{x:1170,y:957,t:1527271773301};\\\", \\\"{x:1171,y:961,t:1527271773318};\\\", \\\"{x:1173,y:964,t:1527271773335};\\\", \\\"{x:1175,y:967,t:1527271773351};\\\", \\\"{x:1177,y:972,t:1527271773368};\\\", \\\"{x:1184,y:983,t:1527271773385};\\\", \\\"{x:1191,y:990,t:1527271773401};\\\", \\\"{x:1201,y:997,t:1527271773418};\\\", \\\"{x:1212,y:1002,t:1527271773435};\\\", \\\"{x:1219,y:1003,t:1527271773451};\\\", \\\"{x:1230,y:1007,t:1527271773469};\\\", \\\"{x:1234,y:1008,t:1527271773485};\\\", \\\"{x:1236,y:1008,t:1527271773502};\\\", \\\"{x:1237,y:1008,t:1527271773551};\\\", \\\"{x:1238,y:1008,t:1527271773559};\\\", \\\"{x:1242,y:1007,t:1527271773569};\\\", \\\"{x:1244,y:1007,t:1527271773585};\\\", \\\"{x:1245,y:1004,t:1527271782967};\\\", \\\"{x:1247,y:1002,t:1527271782976};\\\", \\\"{x:1247,y:1001,t:1527271782992};\\\", \\\"{x:1236,y:987,t:1527271783009};\\\", \\\"{x:1208,y:960,t:1527271783027};\\\", \\\"{x:1171,y:934,t:1527271783042};\\\", \\\"{x:1147,y:916,t:1527271783060};\\\", \\\"{x:1127,y:898,t:1527271783076};\\\", \\\"{x:1108,y:884,t:1527271783092};\\\", \\\"{x:1083,y:868,t:1527271783110};\\\", \\\"{x:1008,y:829,t:1527271783126};\\\", \\\"{x:939,y:802,t:1527271783143};\\\", \\\"{x:898,y:782,t:1527271783159};\\\", \\\"{x:874,y:774,t:1527271783176};\\\", \\\"{x:857,y:769,t:1527271783193};\\\", \\\"{x:833,y:762,t:1527271783209};\\\", \\\"{x:804,y:754,t:1527271783225};\\\", \\\"{x:773,y:741,t:1527271783242};\\\", \\\"{x:752,y:730,t:1527271783258};\\\", \\\"{x:733,y:718,t:1527271783275};\\\", \\\"{x:707,y:700,t:1527271783292};\\\", \\\"{x:678,y:683,t:1527271783308};\\\", \\\"{x:643,y:660,t:1527271783326};\\\", \\\"{x:633,y:651,t:1527271783343};\\\", \\\"{x:628,y:643,t:1527271783360};\\\", \\\"{x:623,y:632,t:1527271783375};\\\", \\\"{x:617,y:620,t:1527271783392};\\\", \\\"{x:607,y:608,t:1527271783410};\\\", \\\"{x:599,y:598,t:1527271783426};\\\", \\\"{x:598,y:595,t:1527271783443};\\\", \\\"{x:597,y:592,t:1527271783459};\\\", \\\"{x:597,y:587,t:1527271783476};\\\", \\\"{x:596,y:575,t:1527271783493};\\\", \\\"{x:596,y:571,t:1527271783510};\\\", \\\"{x:602,y:563,t:1527271783526};\\\", \\\"{x:612,y:558,t:1527271783543};\\\", \\\"{x:624,y:553,t:1527271783559};\\\", \\\"{x:639,y:547,t:1527271783576};\\\", \\\"{x:654,y:545,t:1527271783594};\\\", \\\"{x:675,y:545,t:1527271783610};\\\", \\\"{x:698,y:545,t:1527271783627};\\\", \\\"{x:730,y:552,t:1527271783645};\\\", \\\"{x:760,y:559,t:1527271783660};\\\", \\\"{x:792,y:571,t:1527271783676};\\\", \\\"{x:844,y:605,t:1527271783694};\\\", \\\"{x:890,y:639,t:1527271783710};\\\", \\\"{x:929,y:673,t:1527271783726};\\\", \\\"{x:959,y:707,t:1527271783744};\\\", \\\"{x:982,y:729,t:1527271783760};\\\", \\\"{x:997,y:746,t:1527271783776};\\\", \\\"{x:1010,y:762,t:1527271783794};\\\", \\\"{x:1022,y:779,t:1527271783810};\\\", \\\"{x:1041,y:807,t:1527271783827};\\\", \\\"{x:1064,y:837,t:1527271783844};\\\", \\\"{x:1085,y:866,t:1527271783861};\\\", \\\"{x:1114,y:899,t:1527271783877};\\\", \\\"{x:1140,y:918,t:1527271783894};\\\", \\\"{x:1162,y:935,t:1527271783911};\\\", \\\"{x:1188,y:953,t:1527271783927};\\\", \\\"{x:1225,y:981,t:1527271783944};\\\", \\\"{x:1265,y:1011,t:1527271783961};\\\", \\\"{x:1283,y:1029,t:1527271783977};\\\", \\\"{x:1293,y:1037,t:1527271783994};\\\", \\\"{x:1295,y:1037,t:1527271784011};\\\", \\\"{x:1295,y:1039,t:1527271784311};\\\", \\\"{x:1295,y:1038,t:1527271784349};\\\", \\\"{x:1295,y:1035,t:1527271784361};\\\", \\\"{x:1293,y:1031,t:1527271784378};\\\", \\\"{x:1291,y:1029,t:1527271784394};\\\", \\\"{x:1291,y:1026,t:1527271784410};\\\", \\\"{x:1291,y:1022,t:1527271784427};\\\", \\\"{x:1291,y:1014,t:1527271784444};\\\", \\\"{x:1288,y:1008,t:1527271784461};\\\", \\\"{x:1285,y:998,t:1527271784477};\\\", \\\"{x:1283,y:994,t:1527271784494};\\\", \\\"{x:1282,y:989,t:1527271784510};\\\", \\\"{x:1282,y:983,t:1527271784528};\\\", \\\"{x:1282,y:979,t:1527271784543};\\\", \\\"{x:1282,y:976,t:1527271784561};\\\", \\\"{x:1282,y:975,t:1527271784578};\\\", \\\"{x:1282,y:972,t:1527271784594};\\\", \\\"{x:1282,y:970,t:1527271784611};\\\", \\\"{x:1282,y:969,t:1527271784628};\\\", \\\"{x:1282,y:968,t:1527271784645};\\\", \\\"{x:1282,y:967,t:1527271784661};\\\", \\\"{x:1280,y:969,t:1527271785455};\\\", \\\"{x:1280,y:971,t:1527271785462};\\\", \\\"{x:1279,y:980,t:1527271785478};\\\", \\\"{x:1278,y:985,t:1527271785496};\\\", \\\"{x:1278,y:986,t:1527271785512};\\\", \\\"{x:1278,y:985,t:1527271785775};\\\", \\\"{x:1279,y:984,t:1527271785782};\\\", \\\"{x:1280,y:983,t:1527271785974};\\\", \\\"{x:1283,y:979,t:1527271785981};\\\", \\\"{x:1283,y:978,t:1527271785995};\\\", \\\"{x:1283,y:977,t:1527271786598};\\\", \\\"{x:1284,y:977,t:1527271786918};\\\", \\\"{x:1284,y:976,t:1527271788919};\\\", \\\"{x:1285,y:975,t:1527271788932};\\\", \\\"{x:1285,y:972,t:1527271788947};\\\", \\\"{x:1285,y:970,t:1527271788964};\\\", \\\"{x:1285,y:969,t:1527271788989};\\\", \\\"{x:1285,y:968,t:1527271789037};\\\", \\\"{x:1285,y:967,t:1527271789125};\\\", \\\"{x:1285,y:966,t:1527271789133};\\\", \\\"{x:1285,y:965,t:1527271789148};\\\", \\\"{x:1285,y:963,t:1527271789165};\\\", \\\"{x:1285,y:961,t:1527271789181};\\\", \\\"{x:1285,y:960,t:1527271789213};\\\", \\\"{x:1284,y:960,t:1527271789237};\\\", \\\"{x:1283,y:960,t:1527271789254};\\\", \\\"{x:1283,y:959,t:1527271789270};\\\", \\\"{x:1282,y:958,t:1527271789282};\\\", \\\"{x:1281,y:958,t:1527271789326};\\\", \\\"{x:1279,y:958,t:1527271789422};\\\", \\\"{x:1278,y:958,t:1527271789431};\\\", \\\"{x:1277,y:958,t:1527271789582};\\\", \\\"{x:1280,y:964,t:1527271791510};\\\", \\\"{x:1286,y:973,t:1527271791518};\\\", \\\"{x:1288,y:982,t:1527271791534};\\\", \\\"{x:1289,y:986,t:1527271791550};\\\", \\\"{x:1289,y:988,t:1527271791566};\\\", \\\"{x:1289,y:989,t:1527271791584};\\\", \\\"{x:1288,y:988,t:1527271792542};\\\", \\\"{x:1253,y:972,t:1527271792550};\\\", \\\"{x:1168,y:937,t:1527271792568};\\\", \\\"{x:1114,y:913,t:1527271792583};\\\", \\\"{x:1054,y:877,t:1527271792601};\\\", \\\"{x:967,y:844,t:1527271792618};\\\", \\\"{x:867,y:816,t:1527271792634};\\\", \\\"{x:794,y:793,t:1527271792651};\\\", \\\"{x:756,y:777,t:1527271792667};\\\", \\\"{x:716,y:756,t:1527271792684};\\\", \\\"{x:677,y:739,t:1527271792701};\\\", \\\"{x:609,y:716,t:1527271792718};\\\", \\\"{x:576,y:706,t:1527271792734};\\\", \\\"{x:557,y:698,t:1527271792751};\\\", \\\"{x:539,y:688,t:1527271792768};\\\", \\\"{x:513,y:675,t:1527271792785};\\\", \\\"{x:479,y:665,t:1527271792801};\\\", \\\"{x:467,y:663,t:1527271792818};\\\", \\\"{x:462,y:662,t:1527271792834};\\\", \\\"{x:457,y:660,t:1527271792851};\\\", \\\"{x:440,y:656,t:1527271792868};\\\", \\\"{x:409,y:652,t:1527271792884};\\\", \\\"{x:369,y:645,t:1527271792902};\\\", \\\"{x:353,y:637,t:1527271792918};\\\", \\\"{x:351,y:634,t:1527271792934};\\\", \\\"{x:341,y:617,t:1527271792952};\\\", \\\"{x:316,y:585,t:1527271792968};\\\", \\\"{x:273,y:542,t:1527271792985};\\\", \\\"{x:252,y:525,t:1527271793002};\\\", \\\"{x:249,y:522,t:1527271793018};\\\", \\\"{x:248,y:520,t:1527271793033};\\\", \\\"{x:248,y:518,t:1527271793051};\\\", \\\"{x:258,y:512,t:1527271793068};\\\", \\\"{x:283,y:509,t:1527271793084};\\\", \\\"{x:382,y:512,t:1527271793101};\\\", \\\"{x:451,y:521,t:1527271793118};\\\", \\\"{x:504,y:521,t:1527271793136};\\\", \\\"{x:555,y:521,t:1527271793151};\\\", \\\"{x:588,y:521,t:1527271793168};\\\", \\\"{x:615,y:521,t:1527271793184};\\\", \\\"{x:628,y:521,t:1527271793201};\\\", \\\"{x:629,y:521,t:1527271793218};\\\", \\\"{x:631,y:522,t:1527271793234};\\\", \\\"{x:631,y:524,t:1527271793251};\\\", \\\"{x:631,y:529,t:1527271793268};\\\", \\\"{x:631,y:533,t:1527271793284};\\\", \\\"{x:631,y:534,t:1527271793301};\\\", \\\"{x:631,y:538,t:1527271793319};\\\", \\\"{x:624,y:547,t:1527271793335};\\\", \\\"{x:616,y:561,t:1527271793351};\\\", \\\"{x:610,y:576,t:1527271793369};\\\", \\\"{x:601,y:587,t:1527271793384};\\\", \\\"{x:582,y:594,t:1527271793401};\\\", \\\"{x:542,y:608,t:1527271793418};\\\", \\\"{x:502,y:619,t:1527271793434};\\\", \\\"{x:480,y:622,t:1527271793451};\\\", \\\"{x:463,y:622,t:1527271793467};\\\", \\\"{x:445,y:616,t:1527271793485};\\\", \\\"{x:437,y:608,t:1527271793501};\\\", \\\"{x:428,y:596,t:1527271793518};\\\", \\\"{x:426,y:587,t:1527271793534};\\\", \\\"{x:426,y:578,t:1527271793551};\\\", \\\"{x:430,y:566,t:1527271793569};\\\", \\\"{x:432,y:559,t:1527271793584};\\\", \\\"{x:432,y:552,t:1527271793601};\\\", \\\"{x:432,y:547,t:1527271793618};\\\", \\\"{x:431,y:545,t:1527271793634};\\\", \\\"{x:431,y:544,t:1527271793653};\\\", \\\"{x:430,y:542,t:1527271793670};\\\", \\\"{x:429,y:538,t:1527271793684};\\\", \\\"{x:416,y:528,t:1527271793702};\\\", \\\"{x:412,y:526,t:1527271793718};\\\", \\\"{x:410,y:525,t:1527271793735};\\\", \\\"{x:410,y:524,t:1527271793757};\\\", \\\"{x:409,y:522,t:1527271793769};\\\", \\\"{x:406,y:519,t:1527271793785};\\\", \\\"{x:401,y:515,t:1527271793801};\\\", \\\"{x:398,y:515,t:1527271793818};\\\", \\\"{x:396,y:515,t:1527271793835};\\\", \\\"{x:395,y:515,t:1527271794245};\\\", \\\"{x:396,y:519,t:1527271794254};\\\", \\\"{x:401,y:525,t:1527271794268};\\\", \\\"{x:435,y:556,t:1527271794285};\\\", \\\"{x:462,y:580,t:1527271794302};\\\", \\\"{x:491,y:600,t:1527271794319};\\\", \\\"{x:522,y:622,t:1527271794336};\\\", \\\"{x:558,y:643,t:1527271794352};\\\", \\\"{x:614,y:671,t:1527271794370};\\\", \\\"{x:667,y:704,t:1527271794385};\\\", \\\"{x:723,y:733,t:1527271794402};\\\", \\\"{x:765,y:755,t:1527271794418};\\\", \\\"{x:812,y:775,t:1527271794435};\\\", \\\"{x:856,y:793,t:1527271794453};\\\", \\\"{x:901,y:813,t:1527271794469};\\\", \\\"{x:962,y:838,t:1527271794486};\\\", \\\"{x:985,y:847,t:1527271794502};\\\", \\\"{x:998,y:852,t:1527271794518};\\\", \\\"{x:1017,y:859,t:1527271794536};\\\", \\\"{x:1039,y:867,t:1527271794551};\\\", \\\"{x:1057,y:875,t:1527271794568};\\\", \\\"{x:1066,y:879,t:1527271794586};\\\", \\\"{x:1068,y:880,t:1527271794601};\\\", \\\"{x:1069,y:880,t:1527271794618};\\\", \\\"{x:1070,y:881,t:1527271801278};\\\", \\\"{x:1068,y:881,t:1527271801286};\\\", \\\"{x:1063,y:881,t:1527271801301};\\\", \\\"{x:1030,y:881,t:1527271801316};\\\", \\\"{x:997,y:881,t:1527271801334};\\\", \\\"{x:952,y:876,t:1527271801351};\\\", \\\"{x:896,y:868,t:1527271801367};\\\", \\\"{x:823,y:854,t:1527271801383};\\\", \\\"{x:738,y:837,t:1527271801400};\\\", \\\"{x:687,y:819,t:1527271801416};\\\", \\\"{x:665,y:812,t:1527271801434};\\\", \\\"{x:653,y:805,t:1527271801451};\\\", \\\"{x:645,y:800,t:1527271801467};\\\", \\\"{x:643,y:799,t:1527271801484};\\\", \\\"{x:641,y:798,t:1527271801500};\\\", \\\"{x:636,y:794,t:1527271801517};\\\", \\\"{x:623,y:785,t:1527271801533};\\\", \\\"{x:595,y:773,t:1527271801549};\\\", \\\"{x:552,y:756,t:1527271801567};\\\", \\\"{x:538,y:749,t:1527271801583};\\\", \\\"{x:537,y:748,t:1527271801599};\\\", \\\"{x:536,y:746,t:1527271801616};\\\", \\\"{x:531,y:738,t:1527271801633};\\\", \\\"{x:516,y:722,t:1527271801650};\\\", \\\"{x:488,y:694,t:1527271801667};\\\", \\\"{x:469,y:678,t:1527271801682};\\\", \\\"{x:464,y:675,t:1527271801704};\\\", \\\"{x:463,y:675,t:1527271801838};\\\", \\\"{x:462,y:682,t:1527271801854};\\\", \\\"{x:462,y:685,t:1527271801871};\\\", \\\"{x:462,y:686,t:1527271801900};\\\", \\\"{x:463,y:688,t:1527271801917};\\\", \\\"{x:465,y:690,t:1527271801925};\\\", \\\"{x:468,y:694,t:1527271801937};\\\", \\\"{x:475,y:701,t:1527271801955};\\\", \\\"{x:478,y:707,t:1527271801972};\\\", \\\"{x:480,y:709,t:1527271801992};\\\", \\\"{x:481,y:709,t:1527271802008};\\\", \\\"{x:482,y:709,t:1527271802062};\\\", \\\"{x:483,y:709,t:1527271802918};\\\", \\\"{x:484,y:709,t:1527271802934};\\\", \\\"{x:485,y:710,t:1527271802943};\\\", \\\"{x:497,y:716,t:1527271805414};\\\", \\\"{x:520,y:725,t:1527271805428};\\\", \\\"{x:653,y:762,t:1527271805446};\\\", \\\"{x:763,y:790,t:1527271805461};\\\", \\\"{x:890,y:807,t:1527271805477};\\\", \\\"{x:1017,y:824,t:1527271805494};\\\", \\\"{x:1128,y:838,t:1527271805512};\\\", \\\"{x:1209,y:849,t:1527271805528};\\\", \\\"{x:1262,y:857,t:1527271805544};\\\", \\\"{x:1292,y:862,t:1527271805561};\\\", \\\"{x:1307,y:867,t:1527271805578};\\\", \\\"{x:1309,y:868,t:1527271805595};\\\", \\\"{x:1309,y:869,t:1527271805612};\\\", \\\"{x:1309,y:873,t:1527271805628};\\\", \\\"{x:1305,y:879,t:1527271805645};\\\", \\\"{x:1304,y:881,t:1527271805662};\\\", \\\"{x:1302,y:883,t:1527271805678};\\\", \\\"{x:1295,y:885,t:1527271805695};\\\", \\\"{x:1278,y:885,t:1527271805712};\\\", \\\"{x:1270,y:885,t:1527271805728};\\\", \\\"{x:1269,y:885,t:1527271805745};\\\", \\\"{x:1269,y:883,t:1527271805761};\\\", \\\"{x:1267,y:879,t:1527271805778};\\\", \\\"{x:1263,y:873,t:1527271805795};\\\", \\\"{x:1258,y:867,t:1527271805812};\\\", \\\"{x:1257,y:863,t:1527271805828};\\\", \\\"{x:1255,y:859,t:1527271805845};\\\", \\\"{x:1255,y:858,t:1527271805861};\\\", \\\"{x:1255,y:856,t:1527271805878};\\\", \\\"{x:1255,y:853,t:1527271805895};\\\", \\\"{x:1255,y:850,t:1527271805911};\\\", \\\"{x:1255,y:848,t:1527271805928};\\\", \\\"{x:1255,y:845,t:1527271805945};\\\", \\\"{x:1256,y:842,t:1527271805961};\\\", \\\"{x:1257,y:841,t:1527271805989};\\\", \\\"{x:1258,y:841,t:1527271806005};\\\", \\\"{x:1259,y:840,t:1527271806013};\\\", \\\"{x:1259,y:839,t:1527271806029};\\\", \\\"{x:1261,y:838,t:1527271806044};\\\", \\\"{x:1261,y:837,t:1527271806062};\\\", \\\"{x:1263,y:836,t:1527271806079};\\\", \\\"{x:1264,y:836,t:1527271806102};\\\", \\\"{x:1265,y:836,t:1527271806133};\\\", \\\"{x:1267,y:836,t:1527271806157};\\\", \\\"{x:1268,y:836,t:1527271806165};\\\", \\\"{x:1270,y:836,t:1527271806179};\\\", \\\"{x:1271,y:836,t:1527271806195};\\\", \\\"{x:1272,y:836,t:1527271806212};\\\", \\\"{x:1273,y:836,t:1527271806246};\\\", \\\"{x:1275,y:835,t:1527271806382};\\\", \\\"{x:1275,y:834,t:1527271806398};\\\", \\\"{x:1278,y:832,t:1527271806415};\\\", \\\"{x:1280,y:828,t:1527271806429};\\\", \\\"{x:1281,y:828,t:1527271806445};\\\", \\\"{x:1282,y:826,t:1527271806461};\\\", \\\"{x:1283,y:825,t:1527271806479};\\\", \\\"{x:1283,y:823,t:1527271806496};\\\", \\\"{x:1283,y:822,t:1527271806512};\\\", \\\"{x:1283,y:821,t:1527271806541};\\\", \\\"{x:1283,y:820,t:1527271806557};\\\", \\\"{x:1283,y:819,t:1527271806901};\\\", \\\"{x:1283,y:817,t:1527271806916};\\\", \\\"{x:1283,y:815,t:1527271806928};\\\", \\\"{x:1283,y:812,t:1527271806945};\\\", \\\"{x:1283,y:806,t:1527271806963};\\\", \\\"{x:1283,y:798,t:1527271806979};\\\", \\\"{x:1281,y:788,t:1527271806995};\\\", \\\"{x:1280,y:778,t:1527271807013};\\\", \\\"{x:1280,y:767,t:1527271807029};\\\", \\\"{x:1280,y:762,t:1527271807046};\\\", \\\"{x:1280,y:755,t:1527271807063};\\\", \\\"{x:1280,y:751,t:1527271807078};\\\", \\\"{x:1280,y:749,t:1527271807096};\\\", \\\"{x:1280,y:745,t:1527271807113};\\\", \\\"{x:1280,y:743,t:1527271807130};\\\", \\\"{x:1280,y:741,t:1527271807146};\\\", \\\"{x:1280,y:738,t:1527271807162};\\\", \\\"{x:1280,y:737,t:1527271807179};\\\", \\\"{x:1279,y:735,t:1527271807195};\\\", \\\"{x:1279,y:732,t:1527271807213};\\\", \\\"{x:1279,y:730,t:1527271807229};\\\", \\\"{x:1279,y:728,t:1527271807245};\\\", \\\"{x:1279,y:725,t:1527271807263};\\\", \\\"{x:1279,y:723,t:1527271807279};\\\", \\\"{x:1279,y:719,t:1527271807296};\\\", \\\"{x:1279,y:717,t:1527271807312};\\\", \\\"{x:1278,y:714,t:1527271807329};\\\", \\\"{x:1278,y:713,t:1527271807345};\\\", \\\"{x:1278,y:712,t:1527271807363};\\\", \\\"{x:1278,y:711,t:1527271807379};\\\", \\\"{x:1278,y:710,t:1527271807396};\\\", \\\"{x:1278,y:709,t:1527271807412};\\\", \\\"{x:1278,y:708,t:1527271807429};\\\", \\\"{x:1277,y:705,t:1527271807445};\\\", \\\"{x:1277,y:704,t:1527271807469};\\\", \\\"{x:1277,y:703,t:1527271807480};\\\", \\\"{x:1276,y:702,t:1527271807495};\\\", \\\"{x:1276,y:700,t:1527271807549};\\\", \\\"{x:1276,y:699,t:1527271807590};\\\", \\\"{x:1276,y:697,t:1527271807694};\\\", \\\"{x:1276,y:696,t:1527271807742};\\\", \\\"{x:1276,y:694,t:1527271807790};\\\", \\\"{x:1277,y:693,t:1527271807798};\\\", \\\"{x:1278,y:689,t:1527271807813};\\\", \\\"{x:1278,y:685,t:1527271807830};\\\", \\\"{x:1279,y:683,t:1527271807847};\\\", \\\"{x:1280,y:679,t:1527271807863};\\\", \\\"{x:1281,y:677,t:1527271807880};\\\", \\\"{x:1281,y:672,t:1527271807897};\\\", \\\"{x:1281,y:665,t:1527271807914};\\\", \\\"{x:1281,y:658,t:1527271807931};\\\", \\\"{x:1282,y:649,t:1527271807948};\\\", \\\"{x:1284,y:646,t:1527271807964};\\\", \\\"{x:1285,y:641,t:1527271807980};\\\", \\\"{x:1285,y:638,t:1527271807997};\\\", \\\"{x:1285,y:637,t:1527271808013};\\\", \\\"{x:1285,y:634,t:1527271808030};\\\", \\\"{x:1286,y:628,t:1527271808048};\\\", \\\"{x:1286,y:624,t:1527271808065};\\\", \\\"{x:1286,y:621,t:1527271808081};\\\", \\\"{x:1286,y:619,t:1527271808097};\\\", \\\"{x:1286,y:618,t:1527271808114};\\\", \\\"{x:1286,y:617,t:1527271808131};\\\", \\\"{x:1286,y:614,t:1527271808147};\\\", \\\"{x:1286,y:613,t:1527271808164};\\\", \\\"{x:1286,y:611,t:1527271808180};\\\", \\\"{x:1286,y:608,t:1527271808197};\\\", \\\"{x:1286,y:605,t:1527271808214};\\\", \\\"{x:1286,y:602,t:1527271808230};\\\", \\\"{x:1286,y:601,t:1527271808247};\\\", \\\"{x:1286,y:597,t:1527271808264};\\\", \\\"{x:1286,y:594,t:1527271808280};\\\", \\\"{x:1286,y:590,t:1527271808297};\\\", \\\"{x:1286,y:584,t:1527271808314};\\\", \\\"{x:1286,y:581,t:1527271808330};\\\", \\\"{x:1286,y:576,t:1527271808347};\\\", \\\"{x:1286,y:573,t:1527271808364};\\\", \\\"{x:1286,y:570,t:1527271808382};\\\", \\\"{x:1286,y:569,t:1527271808430};\\\", \\\"{x:1286,y:567,t:1527271808447};\\\", \\\"{x:1286,y:565,t:1527271808463};\\\", \\\"{x:1286,y:563,t:1527271808480};\\\", \\\"{x:1285,y:561,t:1527271808501};\\\", \\\"{x:1283,y:561,t:1527271808540};\\\", \\\"{x:1281,y:561,t:1527271808548};\\\", \\\"{x:1276,y:561,t:1527271808563};\\\", \\\"{x:1253,y:562,t:1527271808580};\\\", \\\"{x:1213,y:576,t:1527271808596};\\\", \\\"{x:1157,y:592,t:1527271808613};\\\", \\\"{x:1078,y:609,t:1527271808630};\\\", \\\"{x:995,y:620,t:1527271808647};\\\", \\\"{x:894,y:635,t:1527271808664};\\\", \\\"{x:811,y:648,t:1527271808680};\\\", \\\"{x:757,y:656,t:1527271808696};\\\", \\\"{x:726,y:660,t:1527271808713};\\\", \\\"{x:703,y:662,t:1527271808730};\\\", \\\"{x:687,y:666,t:1527271808747};\\\", \\\"{x:677,y:668,t:1527271808763};\\\", \\\"{x:668,y:674,t:1527271808781};\\\", \\\"{x:661,y:681,t:1527271808796};\\\", \\\"{x:654,y:690,t:1527271808814};\\\", \\\"{x:648,y:695,t:1527271808831};\\\", \\\"{x:643,y:699,t:1527271808848};\\\", \\\"{x:640,y:702,t:1527271808864};\\\", \\\"{x:639,y:704,t:1527271808882};\\\", \\\"{x:638,y:705,t:1527271808898};\\\", \\\"{x:637,y:708,t:1527271808913};\\\", \\\"{x:636,y:710,t:1527271808931};\\\", \\\"{x:635,y:714,t:1527271808948};\\\", \\\"{x:632,y:717,t:1527271808964};\\\", \\\"{x:631,y:720,t:1527271808981};\\\", \\\"{x:630,y:722,t:1527271808998};\\\", \\\"{x:629,y:724,t:1527271809014};\\\", \\\"{x:628,y:727,t:1527271809031};\\\", \\\"{x:625,y:730,t:1527271809048};\\\", \\\"{x:623,y:732,t:1527271809064};\\\", \\\"{x:620,y:735,t:1527271809082};\\\", \\\"{x:619,y:735,t:1527271809098};\\\", \\\"{x:618,y:737,t:1527271809114};\\\", \\\"{x:616,y:737,t:1527271809131};\\\", \\\"{x:615,y:738,t:1527271809148};\\\", \\\"{x:610,y:739,t:1527271809165};\\\", \\\"{x:602,y:739,t:1527271809181};\\\", \\\"{x:592,y:739,t:1527271809198};\\\", \\\"{x:583,y:739,t:1527271809215};\\\", \\\"{x:580,y:739,t:1527271809231};\\\", \\\"{x:579,y:740,t:1527271809248};\\\", \\\"{x:576,y:740,t:1527271809265};\\\", \\\"{x:563,y:740,t:1527271809281};\\\", \\\"{x:545,y:742,t:1527271809298};\\\", \\\"{x:521,y:750,t:1527271809315};\\\", \\\"{x:494,y:761,t:1527271809330};\\\", \\\"{x:475,y:767,t:1527271809348};\\\", \\\"{x:459,y:770,t:1527271809365};\\\", \\\"{x:458,y:770,t:1527271809381};\\\", \\\"{x:457,y:770,t:1527271809589};\\\", \\\"{x:457,y:768,t:1527271810382};\\\", \\\"{x:459,y:766,t:1527271810399};\\\", \\\"{x:460,y:766,t:1527271810416};\\\", \\\"{x:462,y:763,t:1527271810433};\\\", \\\"{x:463,y:762,t:1527271810449};\\\", \\\"{x:463,y:761,t:1527271810466};\\\", \\\"{x:463,y:760,t:1527271810558};\\\", \\\"{x:464,y:760,t:1527271810565};\\\", \\\"{x:464,y:759,t:1527271810582};\\\", \\\"{x:466,y:758,t:1527271810621};\\\", \\\"{x:468,y:756,t:1527271810632};\\\", \\\"{x:475,y:749,t:1527271810649};\\\", \\\"{x:484,y:742,t:1527271810667};\\\", \\\"{x:492,y:733,t:1527271810684};\\\", \\\"{x:495,y:729,t:1527271810699};\\\", \\\"{x:496,y:728,t:1527271810716};\\\", \\\"{x:498,y:727,t:1527271810731};\\\", \\\"{x:500,y:726,t:1527271810756};\\\" ] }, { \\\"rt\\\": 19961, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 423387, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -03 PM-04 PM-D -E -E -04 PM-04 PM-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:723,t:1527271813292};\\\", \\\"{x:510,y:719,t:1527271813300};\\\", \\\"{x:514,y:717,t:1527271813318};\\\", \\\"{x:524,y:710,t:1527271813335};\\\", \\\"{x:542,y:701,t:1527271813350};\\\", \\\"{x:557,y:691,t:1527271813368};\\\", \\\"{x:577,y:681,t:1527271813385};\\\", \\\"{x:601,y:674,t:1527271813401};\\\", \\\"{x:631,y:664,t:1527271813417};\\\", \\\"{x:662,y:656,t:1527271813434};\\\", \\\"{x:673,y:651,t:1527271813450};\\\", \\\"{x:674,y:651,t:1527271813467};\\\", \\\"{x:675,y:651,t:1527271814093};\\\", \\\"{x:676,y:651,t:1527271814101};\\\", \\\"{x:681,y:651,t:1527271814117};\\\", \\\"{x:699,y:654,t:1527271814134};\\\", \\\"{x:734,y:661,t:1527271814151};\\\", \\\"{x:803,y:669,t:1527271814167};\\\", \\\"{x:883,y:688,t:1527271814184};\\\", \\\"{x:961,y:714,t:1527271814201};\\\", \\\"{x:1030,y:731,t:1527271814218};\\\", \\\"{x:1093,y:745,t:1527271814234};\\\", \\\"{x:1137,y:763,t:1527271814251};\\\", \\\"{x:1159,y:776,t:1527271814268};\\\", \\\"{x:1171,y:788,t:1527271814284};\\\", \\\"{x:1184,y:807,t:1527271814301};\\\", \\\"{x:1192,y:814,t:1527271814318};\\\", \\\"{x:1200,y:822,t:1527271814334};\\\", \\\"{x:1208,y:830,t:1527271814351};\\\", \\\"{x:1217,y:838,t:1527271814369};\\\", \\\"{x:1227,y:851,t:1527271814384};\\\", \\\"{x:1242,y:866,t:1527271814402};\\\", \\\"{x:1262,y:884,t:1527271814418};\\\", \\\"{x:1282,y:896,t:1527271814435};\\\", \\\"{x:1305,y:907,t:1527271814452};\\\", \\\"{x:1328,y:915,t:1527271814468};\\\", \\\"{x:1354,y:923,t:1527271814485};\\\", \\\"{x:1379,y:926,t:1527271814501};\\\", \\\"{x:1385,y:926,t:1527271814518};\\\", \\\"{x:1389,y:926,t:1527271814534};\\\", \\\"{x:1393,y:923,t:1527271814551};\\\", \\\"{x:1397,y:919,t:1527271814568};\\\", \\\"{x:1402,y:912,t:1527271814584};\\\", \\\"{x:1410,y:903,t:1527271814601};\\\", \\\"{x:1417,y:894,t:1527271814618};\\\", \\\"{x:1421,y:883,t:1527271814634};\\\", \\\"{x:1427,y:868,t:1527271814651};\\\", \\\"{x:1435,y:850,t:1527271814669};\\\", \\\"{x:1443,y:834,t:1527271814684};\\\", \\\"{x:1458,y:812,t:1527271814701};\\\", \\\"{x:1466,y:798,t:1527271814719};\\\", \\\"{x:1474,y:784,t:1527271814734};\\\", \\\"{x:1482,y:772,t:1527271814751};\\\", \\\"{x:1490,y:757,t:1527271814768};\\\", \\\"{x:1495,y:749,t:1527271814784};\\\", \\\"{x:1503,y:738,t:1527271814801};\\\", \\\"{x:1510,y:724,t:1527271814818};\\\", \\\"{x:1519,y:712,t:1527271814834};\\\", \\\"{x:1527,y:698,t:1527271814851};\\\", \\\"{x:1536,y:686,t:1527271814868};\\\", \\\"{x:1541,y:674,t:1527271814884};\\\", \\\"{x:1544,y:655,t:1527271814901};\\\", \\\"{x:1540,y:638,t:1527271814918};\\\", \\\"{x:1527,y:621,t:1527271814935};\\\", \\\"{x:1518,y:608,t:1527271814951};\\\", \\\"{x:1511,y:600,t:1527271814968};\\\", \\\"{x:1507,y:594,t:1527271814984};\\\", \\\"{x:1498,y:584,t:1527271815001};\\\", \\\"{x:1476,y:574,t:1527271815017};\\\", \\\"{x:1446,y:567,t:1527271815034};\\\", \\\"{x:1424,y:561,t:1527271815051};\\\", \\\"{x:1404,y:554,t:1527271815067};\\\", \\\"{x:1393,y:550,t:1527271815084};\\\", \\\"{x:1384,y:547,t:1527271815100};\\\", \\\"{x:1366,y:544,t:1527271815118};\\\", \\\"{x:1328,y:540,t:1527271815134};\\\", \\\"{x:1299,y:540,t:1527271815150};\\\", \\\"{x:1282,y:540,t:1527271815168};\\\", \\\"{x:1276,y:541,t:1527271815184};\\\", \\\"{x:1273,y:541,t:1527271815201};\\\", \\\"{x:1272,y:541,t:1527271815218};\\\", \\\"{x:1271,y:542,t:1527271815235};\\\", \\\"{x:1271,y:543,t:1527271815253};\\\", \\\"{x:1271,y:546,t:1527271815268};\\\", \\\"{x:1273,y:566,t:1527271815285};\\\", \\\"{x:1275,y:578,t:1527271815301};\\\", \\\"{x:1280,y:590,t:1527271815318};\\\", \\\"{x:1282,y:595,t:1527271815335};\\\", \\\"{x:1286,y:601,t:1527271815351};\\\", \\\"{x:1290,y:605,t:1527271815368};\\\", \\\"{x:1296,y:608,t:1527271815385};\\\", \\\"{x:1309,y:610,t:1527271815401};\\\", \\\"{x:1321,y:610,t:1527271815418};\\\", \\\"{x:1340,y:610,t:1527271815435};\\\", \\\"{x:1362,y:610,t:1527271815451};\\\", \\\"{x:1382,y:610,t:1527271815468};\\\", \\\"{x:1412,y:600,t:1527271815485};\\\", \\\"{x:1429,y:594,t:1527271815501};\\\", \\\"{x:1445,y:587,t:1527271815519};\\\", \\\"{x:1455,y:582,t:1527271815535};\\\", \\\"{x:1462,y:577,t:1527271815551};\\\", \\\"{x:1464,y:576,t:1527271815568};\\\", \\\"{x:1466,y:575,t:1527271815586};\\\", \\\"{x:1467,y:574,t:1527271815601};\\\", \\\"{x:1472,y:571,t:1527271815618};\\\", \\\"{x:1475,y:569,t:1527271815635};\\\", \\\"{x:1483,y:565,t:1527271815651};\\\", \\\"{x:1492,y:561,t:1527271815668};\\\", \\\"{x:1493,y:560,t:1527271815685};\\\", \\\"{x:1494,y:558,t:1527271815701};\\\", \\\"{x:1496,y:557,t:1527271816108};\\\", \\\"{x:1497,y:554,t:1527271816117};\\\", \\\"{x:1502,y:545,t:1527271816135};\\\", \\\"{x:1508,y:541,t:1527271816152};\\\", \\\"{x:1514,y:535,t:1527271816168};\\\", \\\"{x:1519,y:531,t:1527271816185};\\\", \\\"{x:1521,y:528,t:1527271816202};\\\", \\\"{x:1523,y:525,t:1527271816218};\\\", \\\"{x:1527,y:522,t:1527271816235};\\\", \\\"{x:1530,y:519,t:1527271816252};\\\", \\\"{x:1534,y:515,t:1527271816268};\\\", \\\"{x:1541,y:510,t:1527271816284};\\\", \\\"{x:1547,y:506,t:1527271816302};\\\", \\\"{x:1549,y:505,t:1527271816318};\\\", \\\"{x:1551,y:503,t:1527271816335};\\\", \\\"{x:1552,y:503,t:1527271816357};\\\", \\\"{x:1553,y:503,t:1527271816367};\\\", \\\"{x:1558,y:500,t:1527271816385};\\\", \\\"{x:1562,y:497,t:1527271816402};\\\", \\\"{x:1566,y:494,t:1527271816417};\\\", \\\"{x:1569,y:491,t:1527271816435};\\\", \\\"{x:1570,y:488,t:1527271816452};\\\", \\\"{x:1573,y:482,t:1527271816467};\\\", \\\"{x:1579,y:475,t:1527271816484};\\\", \\\"{x:1583,y:470,t:1527271816502};\\\", \\\"{x:1587,y:466,t:1527271816518};\\\", \\\"{x:1590,y:464,t:1527271816535};\\\", \\\"{x:1592,y:461,t:1527271816552};\\\", \\\"{x:1593,y:459,t:1527271816573};\\\", \\\"{x:1593,y:458,t:1527271816589};\\\", \\\"{x:1593,y:457,t:1527271816602};\\\", \\\"{x:1595,y:454,t:1527271816618};\\\", \\\"{x:1596,y:452,t:1527271816635};\\\", \\\"{x:1598,y:451,t:1527271816652};\\\", \\\"{x:1600,y:449,t:1527271816685};\\\", \\\"{x:1601,y:449,t:1527271816709};\\\", \\\"{x:1602,y:449,t:1527271816718};\\\", \\\"{x:1605,y:447,t:1527271816735};\\\", \\\"{x:1606,y:446,t:1527271816753};\\\", \\\"{x:1607,y:445,t:1527271816769};\\\", \\\"{x:1608,y:445,t:1527271816785};\\\", \\\"{x:1609,y:444,t:1527271816805};\\\", \\\"{x:1610,y:443,t:1527271816819};\\\", \\\"{x:1611,y:442,t:1527271816835};\\\", \\\"{x:1612,y:442,t:1527271816852};\\\", \\\"{x:1612,y:443,t:1527271816893};\\\", \\\"{x:1613,y:450,t:1527271816902};\\\", \\\"{x:1616,y:466,t:1527271816919};\\\", \\\"{x:1621,y:479,t:1527271816936};\\\", \\\"{x:1623,y:493,t:1527271816953};\\\", \\\"{x:1626,y:506,t:1527271816969};\\\", \\\"{x:1627,y:518,t:1527271816986};\\\", \\\"{x:1627,y:531,t:1527271817002};\\\", \\\"{x:1627,y:538,t:1527271817019};\\\", \\\"{x:1627,y:540,t:1527271817036};\\\", \\\"{x:1627,y:541,t:1527271817052};\\\", \\\"{x:1627,y:542,t:1527271817069};\\\", \\\"{x:1627,y:543,t:1527271817085};\\\", \\\"{x:1626,y:546,t:1527271817102};\\\", \\\"{x:1623,y:552,t:1527271817119};\\\", \\\"{x:1621,y:556,t:1527271817135};\\\", \\\"{x:1618,y:562,t:1527271817155};\\\", \\\"{x:1617,y:564,t:1527271817168};\\\", \\\"{x:1617,y:565,t:1527271817184};\\\", \\\"{x:1616,y:566,t:1527271817202};\\\", \\\"{x:1615,y:566,t:1527271817219};\\\", \\\"{x:1614,y:567,t:1527271817235};\\\", \\\"{x:1614,y:568,t:1527271817252};\\\", \\\"{x:1613,y:568,t:1527271817269};\\\", \\\"{x:1612,y:570,t:1527271817911};\\\", \\\"{x:1612,y:572,t:1527271817919};\\\", \\\"{x:1613,y:578,t:1527271817936};\\\", \\\"{x:1613,y:581,t:1527271817953};\\\", \\\"{x:1614,y:584,t:1527271817969};\\\", \\\"{x:1614,y:586,t:1527271817986};\\\", \\\"{x:1614,y:590,t:1527271818003};\\\", \\\"{x:1614,y:593,t:1527271818019};\\\", \\\"{x:1614,y:595,t:1527271818036};\\\", \\\"{x:1614,y:596,t:1527271818052};\\\", \\\"{x:1614,y:597,t:1527271818069};\\\", \\\"{x:1614,y:598,t:1527271818086};\\\", \\\"{x:1614,y:599,t:1527271818102};\\\", \\\"{x:1614,y:600,t:1527271818182};\\\", \\\"{x:1614,y:601,t:1527271818196};\\\", \\\"{x:1614,y:602,t:1527271818213};\\\", \\\"{x:1614,y:604,t:1527271818229};\\\", \\\"{x:1614,y:605,t:1527271818237};\\\", \\\"{x:1614,y:607,t:1527271818252};\\\", \\\"{x:1616,y:611,t:1527271818269};\\\", \\\"{x:1616,y:615,t:1527271818286};\\\", \\\"{x:1617,y:621,t:1527271818302};\\\", \\\"{x:1618,y:629,t:1527271818319};\\\", \\\"{x:1621,y:635,t:1527271818336};\\\", \\\"{x:1622,y:642,t:1527271818352};\\\", \\\"{x:1624,y:645,t:1527271818368};\\\", \\\"{x:1624,y:650,t:1527271818386};\\\", \\\"{x:1624,y:655,t:1527271818402};\\\", \\\"{x:1626,y:666,t:1527271818418};\\\", \\\"{x:1629,y:678,t:1527271818435};\\\", \\\"{x:1630,y:692,t:1527271818452};\\\", \\\"{x:1633,y:700,t:1527271818468};\\\", \\\"{x:1633,y:706,t:1527271818486};\\\", \\\"{x:1633,y:712,t:1527271818503};\\\", \\\"{x:1635,y:719,t:1527271818518};\\\", \\\"{x:1635,y:724,t:1527271818535};\\\", \\\"{x:1636,y:731,t:1527271818553};\\\", \\\"{x:1636,y:738,t:1527271818569};\\\", \\\"{x:1636,y:746,t:1527271818586};\\\", \\\"{x:1638,y:754,t:1527271818603};\\\", \\\"{x:1638,y:761,t:1527271818618};\\\", \\\"{x:1638,y:767,t:1527271818636};\\\", \\\"{x:1637,y:775,t:1527271818652};\\\", \\\"{x:1637,y:780,t:1527271818669};\\\", \\\"{x:1637,y:787,t:1527271818686};\\\", \\\"{x:1637,y:795,t:1527271818703};\\\", \\\"{x:1637,y:802,t:1527271818719};\\\", \\\"{x:1637,y:811,t:1527271818736};\\\", \\\"{x:1637,y:818,t:1527271818753};\\\", \\\"{x:1637,y:824,t:1527271818769};\\\", \\\"{x:1636,y:833,t:1527271818786};\\\", \\\"{x:1634,y:841,t:1527271818803};\\\", \\\"{x:1633,y:850,t:1527271818819};\\\", \\\"{x:1629,y:858,t:1527271818836};\\\", \\\"{x:1617,y:871,t:1527271818852};\\\", \\\"{x:1595,y:878,t:1527271818869};\\\", \\\"{x:1541,y:883,t:1527271818886};\\\", \\\"{x:1478,y:887,t:1527271818903};\\\", \\\"{x:1409,y:887,t:1527271818919};\\\", \\\"{x:1307,y:878,t:1527271818936};\\\", \\\"{x:1168,y:852,t:1527271818953};\\\", \\\"{x:1020,y:822,t:1527271818969};\\\", \\\"{x:906,y:803,t:1527271818986};\\\", \\\"{x:820,y:792,t:1527271819003};\\\", \\\"{x:750,y:781,t:1527271819018};\\\", \\\"{x:661,y:770,t:1527271819036};\\\", \\\"{x:573,y:740,t:1527271819053};\\\", \\\"{x:540,y:718,t:1527271819070};\\\", \\\"{x:521,y:702,t:1527271819086};\\\", \\\"{x:513,y:691,t:1527271819103};\\\", \\\"{x:511,y:685,t:1527271819122};\\\", \\\"{x:511,y:683,t:1527271819139};\\\", \\\"{x:511,y:677,t:1527271819154};\\\", \\\"{x:511,y:663,t:1527271819172};\\\", \\\"{x:506,y:629,t:1527271819189};\\\", \\\"{x:485,y:595,t:1527271819206};\\\", \\\"{x:474,y:583,t:1527271819222};\\\", \\\"{x:471,y:579,t:1527271819238};\\\", \\\"{x:470,y:576,t:1527271819255};\\\", \\\"{x:466,y:568,t:1527271819272};\\\", \\\"{x:463,y:562,t:1527271819288};\\\", \\\"{x:456,y:554,t:1527271819305};\\\", \\\"{x:448,y:549,t:1527271819322};\\\", \\\"{x:445,y:549,t:1527271819339};\\\", \\\"{x:444,y:549,t:1527271819357};\\\", \\\"{x:442,y:549,t:1527271819372};\\\", \\\"{x:428,y:548,t:1527271819389};\\\", \\\"{x:415,y:543,t:1527271819407};\\\", \\\"{x:408,y:540,t:1527271819421};\\\", \\\"{x:409,y:540,t:1527271819469};\\\", \\\"{x:415,y:540,t:1527271819476};\\\", \\\"{x:423,y:540,t:1527271819489};\\\", \\\"{x:446,y:540,t:1527271819505};\\\", \\\"{x:487,y:540,t:1527271819522};\\\", \\\"{x:540,y:548,t:1527271819540};\\\", \\\"{x:570,y:552,t:1527271819556};\\\", \\\"{x:585,y:552,t:1527271819571};\\\", \\\"{x:590,y:552,t:1527271819588};\\\", \\\"{x:591,y:552,t:1527271819605};\\\", \\\"{x:592,y:552,t:1527271819622};\\\", \\\"{x:594,y:552,t:1527271819669};\\\", \\\"{x:599,y:554,t:1527271819678};\\\", \\\"{x:606,y:555,t:1527271819688};\\\", \\\"{x:623,y:556,t:1527271819706};\\\", \\\"{x:646,y:556,t:1527271819722};\\\", \\\"{x:662,y:556,t:1527271819739};\\\", \\\"{x:670,y:557,t:1527271819755};\\\", \\\"{x:672,y:557,t:1527271819772};\\\", \\\"{x:673,y:558,t:1527271819812};\\\", \\\"{x:671,y:559,t:1527271819852};\\\", \\\"{x:653,y:565,t:1527271819860};\\\", \\\"{x:620,y:574,t:1527271819872};\\\", \\\"{x:521,y:596,t:1527271819890};\\\", \\\"{x:434,y:613,t:1527271819906};\\\", \\\"{x:401,y:621,t:1527271819923};\\\", \\\"{x:378,y:622,t:1527271819938};\\\", \\\"{x:356,y:624,t:1527271819955};\\\", \\\"{x:321,y:616,t:1527271819974};\\\", \\\"{x:311,y:612,t:1527271819989};\\\", \\\"{x:311,y:610,t:1527271820006};\\\", \\\"{x:312,y:609,t:1527271820023};\\\", \\\"{x:313,y:609,t:1527271820039};\\\", \\\"{x:313,y:607,t:1527271820056};\\\", \\\"{x:302,y:597,t:1527271820073};\\\", \\\"{x:285,y:590,t:1527271820088};\\\", \\\"{x:276,y:586,t:1527271820106};\\\", \\\"{x:275,y:586,t:1527271820141};\\\", \\\"{x:270,y:586,t:1527271820158};\\\", \\\"{x:221,y:597,t:1527271820173};\\\", \\\"{x:182,y:609,t:1527271820189};\\\", \\\"{x:162,y:617,t:1527271820207};\\\", \\\"{x:138,y:631,t:1527271820224};\\\", \\\"{x:133,y:634,t:1527271820238};\\\", \\\"{x:132,y:635,t:1527271820256};\\\", \\\"{x:131,y:636,t:1527271820273};\\\", \\\"{x:130,y:636,t:1527271820324};\\\", \\\"{x:129,y:636,t:1527271820340};\\\", \\\"{x:128,y:636,t:1527271820356};\\\", \\\"{x:127,y:636,t:1527271820460};\\\", \\\"{x:127,y:635,t:1527271820473};\\\", \\\"{x:128,y:634,t:1527271820492};\\\", \\\"{x:129,y:634,t:1527271820540};\\\", \\\"{x:131,y:634,t:1527271820557};\\\", \\\"{x:132,y:634,t:1527271820573};\\\", \\\"{x:134,y:634,t:1527271820677};\\\", \\\"{x:135,y:634,t:1527271820689};\\\", \\\"{x:145,y:634,t:1527271820706};\\\", \\\"{x:151,y:634,t:1527271820724};\\\", \\\"{x:158,y:635,t:1527271820988};\\\", \\\"{x:175,y:644,t:1527271820996};\\\", \\\"{x:194,y:654,t:1527271821008};\\\", \\\"{x:220,y:664,t:1527271821023};\\\", \\\"{x:253,y:674,t:1527271821040};\\\", \\\"{x:298,y:681,t:1527271821057};\\\", \\\"{x:355,y:691,t:1527271821073};\\\", \\\"{x:432,y:709,t:1527271821090};\\\", \\\"{x:504,y:729,t:1527271821108};\\\", \\\"{x:562,y:746,t:1527271821123};\\\", \\\"{x:602,y:754,t:1527271821140};\\\", \\\"{x:612,y:754,t:1527271821157};\\\", \\\"{x:616,y:754,t:1527271821173};\\\", \\\"{x:617,y:754,t:1527271821212};\\\", \\\"{x:617,y:753,t:1527271821223};\\\", \\\"{x:603,y:745,t:1527271821239};\\\", \\\"{x:581,y:739,t:1527271821257};\\\", \\\"{x:574,y:737,t:1527271821272};\\\", \\\"{x:572,y:736,t:1527271821324};\\\", \\\"{x:568,y:734,t:1527271821340};\\\", \\\"{x:565,y:732,t:1527271821357};\\\", \\\"{x:563,y:731,t:1527271821375};\\\", \\\"{x:562,y:731,t:1527271821476};\\\", \\\"{x:554,y:729,t:1527271821489};\\\", \\\"{x:532,y:722,t:1527271821506};\\\", \\\"{x:524,y:721,t:1527271821523};\\\", \\\"{x:523,y:721,t:1527271821539};\\\", \\\"{x:525,y:721,t:1527271824365};\\\", \\\"{x:531,y:721,t:1527271824373};\\\", \\\"{x:543,y:721,t:1527271824384};\\\", \\\"{x:572,y:723,t:1527271824402};\\\", \\\"{x:605,y:729,t:1527271824417};\\\", \\\"{x:641,y:737,t:1527271824434};\\\", \\\"{x:683,y:750,t:1527271824450};\\\", \\\"{x:711,y:758,t:1527271824459};\\\", \\\"{x:819,y:789,t:1527271824475};\\\", \\\"{x:899,y:807,t:1527271824492};\\\", \\\"{x:976,y:826,t:1527271824509};\\\", \\\"{x:1031,y:834,t:1527271824526};\\\", \\\"{x:1088,y:844,t:1527271824543};\\\", \\\"{x:1130,y:851,t:1527271824559};\\\", \\\"{x:1172,y:863,t:1527271824576};\\\", \\\"{x:1207,y:875,t:1527271824593};\\\", \\\"{x:1230,y:878,t:1527271824609};\\\", \\\"{x:1233,y:878,t:1527271824626};\\\", \\\"{x:1242,y:880,t:1527271825037};\\\", \\\"{x:1250,y:881,t:1527271825045};\\\", \\\"{x:1266,y:886,t:1527271825061};\\\", \\\"{x:1287,y:894,t:1527271825077};\\\", \\\"{x:1309,y:902,t:1527271825093};\\\", \\\"{x:1334,y:908,t:1527271825110};\\\", \\\"{x:1361,y:914,t:1527271825126};\\\", \\\"{x:1392,y:919,t:1527271825143};\\\", \\\"{x:1424,y:925,t:1527271825161};\\\", \\\"{x:1447,y:929,t:1527271825176};\\\", \\\"{x:1468,y:932,t:1527271825193};\\\", \\\"{x:1484,y:936,t:1527271825211};\\\", \\\"{x:1503,y:941,t:1527271825226};\\\", \\\"{x:1518,y:944,t:1527271825243};\\\", \\\"{x:1530,y:949,t:1527271825261};\\\", \\\"{x:1532,y:950,t:1527271825293};\\\", \\\"{x:1536,y:953,t:1527271825310};\\\", \\\"{x:1546,y:962,t:1527271825327};\\\", \\\"{x:1560,y:971,t:1527271825343};\\\", \\\"{x:1569,y:978,t:1527271825360};\\\", \\\"{x:1576,y:982,t:1527271825376};\\\", \\\"{x:1585,y:984,t:1527271825393};\\\", \\\"{x:1599,y:984,t:1527271825410};\\\", \\\"{x:1615,y:984,t:1527271825427};\\\", \\\"{x:1623,y:984,t:1527271825443};\\\", \\\"{x:1628,y:983,t:1527271825460};\\\", \\\"{x:1630,y:983,t:1527271825476};\\\", \\\"{x:1633,y:981,t:1527271825493};\\\", \\\"{x:1634,y:981,t:1527271825516};\\\", \\\"{x:1635,y:980,t:1527271825527};\\\", \\\"{x:1636,y:980,t:1527271825686};\\\", \\\"{x:1636,y:979,t:1527271825700};\\\", \\\"{x:1636,y:977,t:1527271825725};\\\", \\\"{x:1637,y:977,t:1527271825749};\\\", \\\"{x:1638,y:975,t:1527271825765};\\\", \\\"{x:1639,y:974,t:1527271825805};\\\", \\\"{x:1639,y:972,t:1527271826005};\\\", \\\"{x:1639,y:971,t:1527271826013};\\\", \\\"{x:1639,y:969,t:1527271826028};\\\", \\\"{x:1637,y:960,t:1527271826045};\\\", \\\"{x:1634,y:951,t:1527271826061};\\\", \\\"{x:1630,y:940,t:1527271826078};\\\", \\\"{x:1625,y:926,t:1527271826094};\\\", \\\"{x:1622,y:903,t:1527271826111};\\\", \\\"{x:1617,y:873,t:1527271826128};\\\", \\\"{x:1614,y:845,t:1527271826144};\\\", \\\"{x:1610,y:815,t:1527271826160};\\\", \\\"{x:1608,y:793,t:1527271826177};\\\", \\\"{x:1608,y:774,t:1527271826194};\\\", \\\"{x:1608,y:759,t:1527271826211};\\\", \\\"{x:1608,y:750,t:1527271826227};\\\", \\\"{x:1608,y:738,t:1527271826244};\\\", \\\"{x:1608,y:736,t:1527271826261};\\\", \\\"{x:1608,y:731,t:1527271826278};\\\", \\\"{x:1608,y:725,t:1527271826295};\\\", \\\"{x:1608,y:712,t:1527271826310};\\\", \\\"{x:1608,y:693,t:1527271826329};\\\", \\\"{x:1601,y:673,t:1527271826345};\\\", \\\"{x:1598,y:658,t:1527271826361};\\\", \\\"{x:1596,y:649,t:1527271826377};\\\", \\\"{x:1595,y:640,t:1527271826395};\\\", \\\"{x:1595,y:634,t:1527271826412};\\\", \\\"{x:1595,y:626,t:1527271826427};\\\", \\\"{x:1595,y:612,t:1527271826444};\\\", \\\"{x:1595,y:602,t:1527271826461};\\\", \\\"{x:1594,y:592,t:1527271826478};\\\", \\\"{x:1593,y:585,t:1527271826495};\\\", \\\"{x:1594,y:577,t:1527271826512};\\\", \\\"{x:1596,y:569,t:1527271826528};\\\", \\\"{x:1597,y:564,t:1527271826545};\\\", \\\"{x:1597,y:559,t:1527271826561};\\\", \\\"{x:1597,y:554,t:1527271826578};\\\", \\\"{x:1597,y:549,t:1527271826595};\\\", \\\"{x:1597,y:541,t:1527271826612};\\\", \\\"{x:1599,y:533,t:1527271826628};\\\", \\\"{x:1601,y:526,t:1527271826645};\\\", \\\"{x:1601,y:522,t:1527271826661};\\\", \\\"{x:1601,y:515,t:1527271826677};\\\", \\\"{x:1602,y:508,t:1527271826694};\\\", \\\"{x:1603,y:499,t:1527271826711};\\\", \\\"{x:1607,y:488,t:1527271826728};\\\", \\\"{x:1608,y:479,t:1527271826745};\\\", \\\"{x:1608,y:473,t:1527271826761};\\\", \\\"{x:1609,y:467,t:1527271826778};\\\", \\\"{x:1610,y:464,t:1527271826794};\\\", \\\"{x:1610,y:463,t:1527271826811};\\\", \\\"{x:1611,y:463,t:1527271826828};\\\", \\\"{x:1611,y:460,t:1527271826844};\\\", \\\"{x:1611,y:455,t:1527271826862};\\\", \\\"{x:1611,y:450,t:1527271826879};\\\", \\\"{x:1613,y:446,t:1527271826895};\\\", \\\"{x:1614,y:444,t:1527271826911};\\\", \\\"{x:1614,y:443,t:1527271826930};\\\", \\\"{x:1614,y:439,t:1527271826944};\\\", \\\"{x:1614,y:436,t:1527271826962};\\\", \\\"{x:1614,y:434,t:1527271826979};\\\", \\\"{x:1615,y:433,t:1527271826994};\\\", \\\"{x:1615,y:432,t:1527271827012};\\\", \\\"{x:1615,y:435,t:1527271827245};\\\", \\\"{x:1615,y:441,t:1527271827263};\\\", \\\"{x:1615,y:453,t:1527271827278};\\\", \\\"{x:1617,y:468,t:1527271827295};\\\", \\\"{x:1618,y:486,t:1527271827311};\\\", \\\"{x:1619,y:501,t:1527271827328};\\\", \\\"{x:1619,y:515,t:1527271827345};\\\", \\\"{x:1619,y:522,t:1527271827362};\\\", \\\"{x:1619,y:529,t:1527271827379};\\\", \\\"{x:1618,y:536,t:1527271827396};\\\", \\\"{x:1618,y:541,t:1527271827411};\\\", \\\"{x:1618,y:547,t:1527271827429};\\\", \\\"{x:1618,y:549,t:1527271827445};\\\", \\\"{x:1618,y:552,t:1527271827462};\\\", \\\"{x:1618,y:555,t:1527271827479};\\\", \\\"{x:1618,y:559,t:1527271827496};\\\", \\\"{x:1618,y:562,t:1527271827511};\\\", \\\"{x:1618,y:560,t:1527271827597};\\\", \\\"{x:1618,y:554,t:1527271827613};\\\", \\\"{x:1617,y:527,t:1527271827629};\\\", \\\"{x:1617,y:497,t:1527271827646};\\\", \\\"{x:1617,y:471,t:1527271827661};\\\", \\\"{x:1617,y:452,t:1527271827678};\\\", \\\"{x:1617,y:442,t:1527271827696};\\\", \\\"{x:1617,y:441,t:1527271827711};\\\", \\\"{x:1617,y:439,t:1527271827730};\\\", \\\"{x:1617,y:441,t:1527271827796};\\\", \\\"{x:1617,y:447,t:1527271827812};\\\", \\\"{x:1617,y:484,t:1527271827829};\\\", \\\"{x:1617,y:514,t:1527271827846};\\\", \\\"{x:1617,y:543,t:1527271827862};\\\", \\\"{x:1616,y:564,t:1527271827879};\\\", \\\"{x:1616,y:575,t:1527271827897};\\\", \\\"{x:1616,y:588,t:1527271827912};\\\", \\\"{x:1618,y:605,t:1527271827931};\\\", \\\"{x:1619,y:629,t:1527271827945};\\\", \\\"{x:1619,y:644,t:1527271827962};\\\", \\\"{x:1620,y:653,t:1527271827979};\\\", \\\"{x:1620,y:659,t:1527271827996};\\\", \\\"{x:1620,y:666,t:1527271828013};\\\", \\\"{x:1620,y:674,t:1527271828029};\\\", \\\"{x:1622,y:679,t:1527271828045};\\\", \\\"{x:1623,y:688,t:1527271828063};\\\", \\\"{x:1624,y:698,t:1527271828078};\\\", \\\"{x:1624,y:706,t:1527271828095};\\\", \\\"{x:1624,y:711,t:1527271828113};\\\", \\\"{x:1624,y:716,t:1527271828130};\\\", \\\"{x:1626,y:720,t:1527271828145};\\\", \\\"{x:1626,y:725,t:1527271828163};\\\", \\\"{x:1628,y:736,t:1527271828178};\\\", \\\"{x:1630,y:746,t:1527271828195};\\\", \\\"{x:1630,y:760,t:1527271828213};\\\", \\\"{x:1630,y:765,t:1527271828228};\\\", \\\"{x:1630,y:767,t:1527271828246};\\\", \\\"{x:1631,y:769,t:1527271828263};\\\", \\\"{x:1631,y:774,t:1527271828279};\\\", \\\"{x:1631,y:779,t:1527271828295};\\\", \\\"{x:1631,y:787,t:1527271828313};\\\", \\\"{x:1631,y:800,t:1527271828330};\\\", \\\"{x:1631,y:810,t:1527271828346};\\\", \\\"{x:1631,y:818,t:1527271828363};\\\", \\\"{x:1631,y:827,t:1527271828380};\\\", \\\"{x:1631,y:838,t:1527271828396};\\\", \\\"{x:1630,y:854,t:1527271828413};\\\", \\\"{x:1630,y:867,t:1527271828429};\\\", \\\"{x:1630,y:878,t:1527271828445};\\\", \\\"{x:1630,y:886,t:1527271828463};\\\", \\\"{x:1629,y:891,t:1527271828480};\\\", \\\"{x:1629,y:896,t:1527271828496};\\\", \\\"{x:1628,y:900,t:1527271828512};\\\", \\\"{x:1627,y:908,t:1527271828531};\\\", \\\"{x:1626,y:916,t:1527271828546};\\\", \\\"{x:1626,y:922,t:1527271828563};\\\", \\\"{x:1626,y:929,t:1527271828580};\\\", \\\"{x:1626,y:933,t:1527271828596};\\\", \\\"{x:1626,y:937,t:1527271828613};\\\", \\\"{x:1625,y:940,t:1527271828629};\\\", \\\"{x:1625,y:943,t:1527271828645};\\\", \\\"{x:1624,y:948,t:1527271828663};\\\", \\\"{x:1623,y:951,t:1527271828679};\\\", \\\"{x:1623,y:952,t:1527271828696};\\\", \\\"{x:1623,y:954,t:1527271828713};\\\", \\\"{x:1623,y:957,t:1527271828731};\\\", \\\"{x:1623,y:960,t:1527271828746};\\\", \\\"{x:1623,y:963,t:1527271828762};\\\", \\\"{x:1623,y:967,t:1527271828779};\\\", \\\"{x:1623,y:970,t:1527271828796};\\\", \\\"{x:1623,y:972,t:1527271828812};\\\", \\\"{x:1623,y:973,t:1527271828829};\\\", \\\"{x:1622,y:974,t:1527271828846};\\\", \\\"{x:1621,y:978,t:1527271828862};\\\", \\\"{x:1618,y:981,t:1527271828879};\\\", \\\"{x:1616,y:985,t:1527271828896};\\\", \\\"{x:1614,y:986,t:1527271828913};\\\", \\\"{x:1614,y:987,t:1527271828929};\\\", \\\"{x:1613,y:988,t:1527271828946};\\\", \\\"{x:1613,y:989,t:1527271828962};\\\", \\\"{x:1611,y:989,t:1527271829130};\\\", \\\"{x:1611,y:987,t:1527271829145};\\\", \\\"{x:1611,y:986,t:1527271829161};\\\", \\\"{x:1609,y:983,t:1527271829169};\\\", \\\"{x:1609,y:982,t:1527271829185};\\\", \\\"{x:1608,y:981,t:1527271829201};\\\", \\\"{x:1608,y:980,t:1527271829225};\\\", \\\"{x:1608,y:979,t:1527271829234};\\\", \\\"{x:1608,y:977,t:1527271829251};\\\", \\\"{x:1608,y:974,t:1527271829269};\\\", \\\"{x:1608,y:968,t:1527271829284};\\\", \\\"{x:1608,y:964,t:1527271829302};\\\", \\\"{x:1608,y:961,t:1527271829318};\\\", \\\"{x:1608,y:958,t:1527271829334};\\\", \\\"{x:1608,y:953,t:1527271829351};\\\", \\\"{x:1608,y:949,t:1527271829368};\\\", \\\"{x:1608,y:942,t:1527271829384};\\\", \\\"{x:1605,y:927,t:1527271829401};\\\", \\\"{x:1604,y:921,t:1527271829418};\\\", \\\"{x:1604,y:916,t:1527271829434};\\\", \\\"{x:1604,y:911,t:1527271829451};\\\", \\\"{x:1604,y:906,t:1527271829469};\\\", \\\"{x:1604,y:901,t:1527271829484};\\\", \\\"{x:1603,y:896,t:1527271829502};\\\", \\\"{x:1603,y:893,t:1527271829518};\\\", \\\"{x:1601,y:890,t:1527271829534};\\\", \\\"{x:1601,y:888,t:1527271829551};\\\", \\\"{x:1601,y:886,t:1527271829568};\\\", \\\"{x:1601,y:883,t:1527271829584};\\\", \\\"{x:1601,y:876,t:1527271829601};\\\", \\\"{x:1600,y:872,t:1527271829618};\\\", \\\"{x:1600,y:868,t:1527271829634};\\\", \\\"{x:1600,y:865,t:1527271829652};\\\", \\\"{x:1600,y:861,t:1527271829668};\\\", \\\"{x:1600,y:856,t:1527271829684};\\\", \\\"{x:1600,y:852,t:1527271829702};\\\", \\\"{x:1600,y:851,t:1527271829719};\\\", \\\"{x:1600,y:849,t:1527271829735};\\\", \\\"{x:1600,y:848,t:1527271829751};\\\", \\\"{x:1600,y:845,t:1527271829768};\\\", \\\"{x:1601,y:840,t:1527271829786};\\\", \\\"{x:1602,y:836,t:1527271829801};\\\", \\\"{x:1604,y:833,t:1527271829818};\\\", \\\"{x:1604,y:830,t:1527271829835};\\\", \\\"{x:1604,y:828,t:1527271829852};\\\", \\\"{x:1606,y:825,t:1527271829868};\\\", \\\"{x:1606,y:822,t:1527271829885};\\\", \\\"{x:1607,y:820,t:1527271829902};\\\", \\\"{x:1608,y:818,t:1527271829918};\\\", \\\"{x:1608,y:817,t:1527271829935};\\\", \\\"{x:1609,y:815,t:1527271829951};\\\", \\\"{x:1610,y:814,t:1527271829968};\\\", \\\"{x:1611,y:813,t:1527271829986};\\\", \\\"{x:1611,y:810,t:1527271830001};\\\", \\\"{x:1612,y:809,t:1527271830019};\\\", \\\"{x:1612,y:808,t:1527271830035};\\\", \\\"{x:1613,y:807,t:1527271830052};\\\", \\\"{x:1614,y:805,t:1527271830069};\\\", \\\"{x:1614,y:803,t:1527271830085};\\\", \\\"{x:1615,y:799,t:1527271830101};\\\", \\\"{x:1615,y:791,t:1527271830119};\\\", \\\"{x:1615,y:783,t:1527271830135};\\\", \\\"{x:1615,y:774,t:1527271830152};\\\", \\\"{x:1615,y:765,t:1527271830168};\\\", \\\"{x:1619,y:754,t:1527271830186};\\\", \\\"{x:1619,y:750,t:1527271830202};\\\", \\\"{x:1619,y:747,t:1527271830218};\\\", \\\"{x:1619,y:742,t:1527271830236};\\\", \\\"{x:1619,y:740,t:1527271830252};\\\", \\\"{x:1619,y:736,t:1527271830268};\\\", \\\"{x:1619,y:733,t:1527271830285};\\\", \\\"{x:1619,y:730,t:1527271830302};\\\", \\\"{x:1619,y:727,t:1527271830319};\\\", \\\"{x:1619,y:721,t:1527271830335};\\\", \\\"{x:1619,y:719,t:1527271830353};\\\", \\\"{x:1619,y:714,t:1527271830368};\\\", \\\"{x:1619,y:709,t:1527271830385};\\\", \\\"{x:1619,y:704,t:1527271830402};\\\", \\\"{x:1619,y:701,t:1527271830419};\\\", \\\"{x:1619,y:697,t:1527271830436};\\\", \\\"{x:1619,y:692,t:1527271830453};\\\", \\\"{x:1619,y:687,t:1527271830469};\\\", \\\"{x:1619,y:681,t:1527271830485};\\\", \\\"{x:1619,y:677,t:1527271830501};\\\", \\\"{x:1619,y:671,t:1527271830518};\\\", \\\"{x:1618,y:665,t:1527271830535};\\\", \\\"{x:1617,y:659,t:1527271830551};\\\", \\\"{x:1616,y:653,t:1527271830567};\\\", \\\"{x:1616,y:642,t:1527271830584};\\\", \\\"{x:1616,y:633,t:1527271830602};\\\", \\\"{x:1616,y:622,t:1527271830619};\\\", \\\"{x:1616,y:612,t:1527271830634};\\\", \\\"{x:1616,y:605,t:1527271830651};\\\", \\\"{x:1616,y:600,t:1527271830669};\\\", \\\"{x:1616,y:595,t:1527271830685};\\\", \\\"{x:1616,y:590,t:1527271830702};\\\", \\\"{x:1614,y:586,t:1527271830719};\\\", \\\"{x:1614,y:583,t:1527271830735};\\\", \\\"{x:1614,y:579,t:1527271830752};\\\", \\\"{x:1614,y:574,t:1527271830769};\\\", \\\"{x:1614,y:571,t:1527271830785};\\\", \\\"{x:1614,y:570,t:1527271830802};\\\", \\\"{x:1614,y:569,t:1527271830819};\\\", \\\"{x:1614,y:568,t:1527271830835};\\\", \\\"{x:1614,y:567,t:1527271830853};\\\", \\\"{x:1614,y:566,t:1527271830873};\\\", \\\"{x:1614,y:565,t:1527271830905};\\\", \\\"{x:1609,y:564,t:1527271831386};\\\", \\\"{x:1559,y:571,t:1527271831404};\\\", \\\"{x:1475,y:586,t:1527271831419};\\\", \\\"{x:1383,y:599,t:1527271831436};\\\", \\\"{x:1325,y:614,t:1527271831452};\\\", \\\"{x:1277,y:631,t:1527271831470};\\\", \\\"{x:1197,y:661,t:1527271831487};\\\", \\\"{x:1113,y:680,t:1527271831503};\\\", \\\"{x:1055,y:687,t:1527271831520};\\\", \\\"{x:1025,y:687,t:1527271831536};\\\", \\\"{x:1016,y:687,t:1527271831554};\\\", \\\"{x:1014,y:687,t:1527271831569};\\\", \\\"{x:1010,y:687,t:1527271831586};\\\", \\\"{x:1006,y:687,t:1527271831604};\\\", \\\"{x:1001,y:687,t:1527271831620};\\\", \\\"{x:999,y:687,t:1527271831642};\\\", \\\"{x:990,y:687,t:1527271831657};\\\", \\\"{x:975,y:687,t:1527271831670};\\\", \\\"{x:906,y:694,t:1527271831687};\\\", \\\"{x:827,y:712,t:1527271831703};\\\", \\\"{x:794,y:718,t:1527271831720};\\\", \\\"{x:772,y:720,t:1527271831736};\\\", \\\"{x:752,y:721,t:1527271831753};\\\", \\\"{x:740,y:721,t:1527271831769};\\\", \\\"{x:724,y:723,t:1527271831787};\\\", \\\"{x:715,y:724,t:1527271831804};\\\", \\\"{x:712,y:724,t:1527271831819};\\\", \\\"{x:711,y:724,t:1527271831837};\\\", \\\"{x:708,y:724,t:1527271831853};\\\", \\\"{x:701,y:722,t:1527271831868};\\\", \\\"{x:672,y:722,t:1527271831886};\\\", \\\"{x:639,y:722,t:1527271831903};\\\", \\\"{x:625,y:722,t:1527271831920};\\\", \\\"{x:621,y:722,t:1527271831936};\\\", \\\"{x:619,y:722,t:1527271831953};\\\", \\\"{x:616,y:722,t:1527271832049};\\\", \\\"{x:612,y:722,t:1527271832057};\\\", \\\"{x:607,y:722,t:1527271832069};\\\", \\\"{x:601,y:722,t:1527271832086};\\\", \\\"{x:598,y:723,t:1527271832103};\\\", \\\"{x:597,y:723,t:1527271832120};\\\", \\\"{x:596,y:723,t:1527271832137};\\\", \\\"{x:590,y:723,t:1527271832153};\\\", \\\"{x:584,y:720,t:1527271832170};\\\", \\\"{x:580,y:719,t:1527271832186};\\\", \\\"{x:579,y:719,t:1527271832203};\\\", \\\"{x:577,y:718,t:1527271832249};\\\", \\\"{x:576,y:718,t:1527271832257};\\\", \\\"{x:574,y:717,t:1527271832270};\\\", \\\"{x:569,y:716,t:1527271832286};\\\", \\\"{x:552,y:716,t:1527271832304};\\\", \\\"{x:533,y:716,t:1527271832320};\\\", \\\"{x:529,y:716,t:1527271832336};\\\", \\\"{x:528,y:716,t:1527271832433};\\\", \\\"{x:529,y:717,t:1527271832898};\\\", \\\"{x:533,y:717,t:1527271832905};\\\", \\\"{x:545,y:718,t:1527271832921};\\\", \\\"{x:552,y:718,t:1527271832937};\\\" ] }, { \\\"rt\\\": 29777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 454394, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -Z -C -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:718,t:1527271834681};\\\", \\\"{x:557,y:718,t:1527271834690};\\\", \\\"{x:564,y:718,t:1527271834707};\\\", \\\"{x:572,y:712,t:1527271834725};\\\", \\\"{x:580,y:710,t:1527271834740};\\\", \\\"{x:596,y:705,t:1527271834755};\\\", \\\"{x:615,y:699,t:1527271834772};\\\", \\\"{x:631,y:695,t:1527271834789};\\\", \\\"{x:644,y:690,t:1527271834806};\\\", \\\"{x:663,y:689,t:1527271834822};\\\", \\\"{x:695,y:688,t:1527271834839};\\\", \\\"{x:745,y:684,t:1527271834856};\\\", \\\"{x:812,y:683,t:1527271834872};\\\", \\\"{x:862,y:678,t:1527271834888};\\\", \\\"{x:867,y:677,t:1527271834907};\\\", \\\"{x:868,y:677,t:1527271835786};\\\", \\\"{x:869,y:677,t:1527271835801};\\\", \\\"{x:870,y:677,t:1527271835809};\\\", \\\"{x:871,y:677,t:1527271835913};\\\", \\\"{x:873,y:677,t:1527271835923};\\\", \\\"{x:882,y:679,t:1527271835941};\\\", \\\"{x:893,y:681,t:1527271835956};\\\", \\\"{x:901,y:682,t:1527271835973};\\\", \\\"{x:926,y:690,t:1527271835990};\\\", \\\"{x:981,y:701,t:1527271836007};\\\", \\\"{x:1033,y:715,t:1527271836024};\\\", \\\"{x:1062,y:724,t:1527271836040};\\\", \\\"{x:1088,y:731,t:1527271836056};\\\", \\\"{x:1123,y:740,t:1527271836074};\\\", \\\"{x:1151,y:747,t:1527271836091};\\\", \\\"{x:1173,y:754,t:1527271836107};\\\", \\\"{x:1198,y:757,t:1527271836123};\\\", \\\"{x:1209,y:757,t:1527271836140};\\\", \\\"{x:1210,y:759,t:1527271836157};\\\", \\\"{x:1211,y:759,t:1527271836562};\\\", \\\"{x:1213,y:759,t:1527271836573};\\\", \\\"{x:1220,y:760,t:1527271836590};\\\", \\\"{x:1229,y:761,t:1527271836608};\\\", \\\"{x:1237,y:761,t:1527271836625};\\\", \\\"{x:1253,y:763,t:1527271836642};\\\", \\\"{x:1268,y:764,t:1527271836657};\\\", \\\"{x:1282,y:765,t:1527271836674};\\\", \\\"{x:1293,y:766,t:1527271836691};\\\", \\\"{x:1309,y:769,t:1527271836708};\\\", \\\"{x:1328,y:769,t:1527271836725};\\\", \\\"{x:1342,y:769,t:1527271836740};\\\", \\\"{x:1354,y:769,t:1527271836757};\\\", \\\"{x:1367,y:769,t:1527271836775};\\\", \\\"{x:1377,y:770,t:1527271836791};\\\", \\\"{x:1389,y:770,t:1527271836807};\\\", \\\"{x:1402,y:770,t:1527271836824};\\\", \\\"{x:1420,y:770,t:1527271836840};\\\", \\\"{x:1428,y:770,t:1527271836857};\\\", \\\"{x:1436,y:769,t:1527271836874};\\\", \\\"{x:1440,y:768,t:1527271836890};\\\", \\\"{x:1448,y:767,t:1527271836907};\\\", \\\"{x:1463,y:767,t:1527271836924};\\\", \\\"{x:1480,y:767,t:1527271836941};\\\", \\\"{x:1494,y:768,t:1527271836957};\\\", \\\"{x:1508,y:768,t:1527271836974};\\\", \\\"{x:1515,y:768,t:1527271836990};\\\", \\\"{x:1525,y:770,t:1527271837007};\\\", \\\"{x:1536,y:773,t:1527271837024};\\\", \\\"{x:1557,y:779,t:1527271837040};\\\", \\\"{x:1570,y:785,t:1527271837057};\\\", \\\"{x:1577,y:790,t:1527271837074};\\\", \\\"{x:1582,y:795,t:1527271837091};\\\", \\\"{x:1587,y:799,t:1527271837107};\\\", \\\"{x:1591,y:803,t:1527271837124};\\\", \\\"{x:1593,y:808,t:1527271837141};\\\", \\\"{x:1596,y:813,t:1527271837157};\\\", \\\"{x:1599,y:822,t:1527271837174};\\\", \\\"{x:1601,y:830,t:1527271837191};\\\", \\\"{x:1606,y:839,t:1527271837207};\\\", \\\"{x:1609,y:844,t:1527271837224};\\\", \\\"{x:1613,y:850,t:1527271837240};\\\", \\\"{x:1613,y:853,t:1527271837257};\\\", \\\"{x:1616,y:859,t:1527271837274};\\\", \\\"{x:1617,y:864,t:1527271837291};\\\", \\\"{x:1619,y:872,t:1527271837307};\\\", \\\"{x:1622,y:877,t:1527271837324};\\\", \\\"{x:1624,y:882,t:1527271837341};\\\", \\\"{x:1627,y:886,t:1527271837357};\\\", \\\"{x:1629,y:889,t:1527271837374};\\\", \\\"{x:1631,y:891,t:1527271837391};\\\", \\\"{x:1632,y:893,t:1527271837408};\\\", \\\"{x:1632,y:894,t:1527271837424};\\\", \\\"{x:1632,y:895,t:1527271837441};\\\", \\\"{x:1632,y:896,t:1527271837745};\\\", \\\"{x:1632,y:897,t:1527271843234};\\\", \\\"{x:1632,y:898,t:1527271843249};\\\", \\\"{x:1632,y:899,t:1527271843266};\\\", \\\"{x:1631,y:899,t:1527271844042};\\\", \\\"{x:1629,y:900,t:1527271844049};\\\", \\\"{x:1627,y:901,t:1527271844064};\\\", \\\"{x:1613,y:901,t:1527271844079};\\\", \\\"{x:1581,y:901,t:1527271844097};\\\", \\\"{x:1551,y:903,t:1527271844113};\\\", \\\"{x:1521,y:903,t:1527271844129};\\\", \\\"{x:1491,y:903,t:1527271844147};\\\", \\\"{x:1463,y:903,t:1527271844164};\\\", \\\"{x:1441,y:903,t:1527271844180};\\\", \\\"{x:1424,y:903,t:1527271844197};\\\", \\\"{x:1413,y:903,t:1527271844214};\\\", \\\"{x:1395,y:901,t:1527271844230};\\\", \\\"{x:1380,y:898,t:1527271844247};\\\", \\\"{x:1366,y:896,t:1527271844264};\\\", \\\"{x:1353,y:893,t:1527271844280};\\\", \\\"{x:1339,y:889,t:1527271844297};\\\", \\\"{x:1327,y:886,t:1527271844313};\\\", \\\"{x:1316,y:884,t:1527271844329};\\\", \\\"{x:1301,y:881,t:1527271844347};\\\", \\\"{x:1291,y:879,t:1527271844364};\\\", \\\"{x:1289,y:879,t:1527271844380};\\\", \\\"{x:1288,y:879,t:1527271845008};\\\", \\\"{x:1287,y:879,t:1527271845032};\\\", \\\"{x:1285,y:879,t:1527271845047};\\\", \\\"{x:1281,y:877,t:1527271845063};\\\", \\\"{x:1269,y:873,t:1527271845080};\\\", \\\"{x:1258,y:868,t:1527271845097};\\\", \\\"{x:1248,y:863,t:1527271845114};\\\", \\\"{x:1240,y:860,t:1527271845130};\\\", \\\"{x:1231,y:859,t:1527271845148};\\\", \\\"{x:1225,y:856,t:1527271845163};\\\", \\\"{x:1222,y:855,t:1527271845181};\\\", \\\"{x:1221,y:855,t:1527271845198};\\\", \\\"{x:1219,y:854,t:1527271845214};\\\", \\\"{x:1219,y:853,t:1527271845338};\\\", \\\"{x:1219,y:852,t:1527271845348};\\\", \\\"{x:1219,y:847,t:1527271845365};\\\", \\\"{x:1219,y:843,t:1527271845381};\\\", \\\"{x:1219,y:839,t:1527271845398};\\\", \\\"{x:1219,y:837,t:1527271845415};\\\", \\\"{x:1219,y:836,t:1527271845431};\\\", \\\"{x:1219,y:835,t:1527271845769};\\\", \\\"{x:1219,y:834,t:1527271845781};\\\", \\\"{x:1219,y:833,t:1527271845800};\\\", \\\"{x:1218,y:832,t:1527271845815};\\\", \\\"{x:1217,y:830,t:1527271845831};\\\", \\\"{x:1216,y:830,t:1527271846185};\\\", \\\"{x:1216,y:829,t:1527271846201};\\\", \\\"{x:1217,y:829,t:1527271846233};\\\", \\\"{x:1218,y:829,t:1527271846248};\\\", \\\"{x:1222,y:829,t:1527271846267};\\\", \\\"{x:1230,y:830,t:1527271846282};\\\", \\\"{x:1241,y:832,t:1527271846299};\\\", \\\"{x:1255,y:832,t:1527271846315};\\\", \\\"{x:1262,y:832,t:1527271846332};\\\", \\\"{x:1263,y:832,t:1527271846349};\\\", \\\"{x:1266,y:832,t:1527271846385};\\\", \\\"{x:1270,y:833,t:1527271846399};\\\", \\\"{x:1287,y:836,t:1527271846415};\\\", \\\"{x:1305,y:838,t:1527271846432};\\\", \\\"{x:1311,y:838,t:1527271846449};\\\", \\\"{x:1312,y:838,t:1527271846465};\\\", \\\"{x:1311,y:838,t:1527271846593};\\\", \\\"{x:1309,y:838,t:1527271846601};\\\", \\\"{x:1306,y:838,t:1527271846615};\\\", \\\"{x:1300,y:838,t:1527271846632};\\\", \\\"{x:1294,y:838,t:1527271846649};\\\", \\\"{x:1292,y:838,t:1527271846666};\\\", \\\"{x:1291,y:838,t:1527271846681};\\\", \\\"{x:1289,y:837,t:1527271846730};\\\", \\\"{x:1288,y:836,t:1527271846746};\\\", \\\"{x:1286,y:836,t:1527271846761};\\\", \\\"{x:1285,y:836,t:1527271846793};\\\", \\\"{x:1284,y:836,t:1527271846802};\\\", \\\"{x:1283,y:836,t:1527271846817};\\\", \\\"{x:1283,y:835,t:1527271846946};\\\", \\\"{x:1288,y:835,t:1527271846965};\\\", \\\"{x:1292,y:835,t:1527271846982};\\\", \\\"{x:1296,y:835,t:1527271846999};\\\", \\\"{x:1299,y:835,t:1527271847016};\\\", \\\"{x:1308,y:835,t:1527271847032};\\\", \\\"{x:1315,y:837,t:1527271847048};\\\", \\\"{x:1320,y:838,t:1527271847065};\\\", \\\"{x:1323,y:838,t:1527271847082};\\\", \\\"{x:1324,y:838,t:1527271847099};\\\", \\\"{x:1326,y:838,t:1527271847115};\\\", \\\"{x:1334,y:838,t:1527271847133};\\\", \\\"{x:1342,y:838,t:1527271847148};\\\", \\\"{x:1348,y:838,t:1527271847166};\\\", \\\"{x:1351,y:837,t:1527271847183};\\\", \\\"{x:1350,y:836,t:1527271847722};\\\", \\\"{x:1350,y:835,t:1527271847738};\\\", \\\"{x:1349,y:834,t:1527271847754};\\\", \\\"{x:1348,y:834,t:1527271847766};\\\", \\\"{x:1348,y:832,t:1527271847783};\\\", \\\"{x:1348,y:834,t:1527271852497};\\\", \\\"{x:1348,y:836,t:1527271852505};\\\", \\\"{x:1348,y:839,t:1527271852520};\\\", \\\"{x:1348,y:847,t:1527271852537};\\\", \\\"{x:1348,y:850,t:1527271852553};\\\", \\\"{x:1348,y:852,t:1527271852570};\\\", \\\"{x:1348,y:853,t:1527271852588};\\\", \\\"{x:1348,y:855,t:1527271852603};\\\", \\\"{x:1348,y:856,t:1527271852620};\\\", \\\"{x:1348,y:858,t:1527271852637};\\\", \\\"{x:1348,y:859,t:1527271852654};\\\", \\\"{x:1348,y:861,t:1527271852670};\\\", \\\"{x:1348,y:862,t:1527271852730};\\\", \\\"{x:1348,y:864,t:1527271852760};\\\", \\\"{x:1348,y:865,t:1527271852792};\\\", \\\"{x:1348,y:866,t:1527271852856};\\\", \\\"{x:1348,y:867,t:1527271852872};\\\", \\\"{x:1348,y:868,t:1527271852887};\\\", \\\"{x:1348,y:869,t:1527271852929};\\\", \\\"{x:1348,y:870,t:1527271852937};\\\", \\\"{x:1348,y:871,t:1527271852954};\\\", \\\"{x:1349,y:872,t:1527271852970};\\\", \\\"{x:1349,y:874,t:1527271852987};\\\", \\\"{x:1349,y:876,t:1527271853004};\\\", \\\"{x:1349,y:879,t:1527271853020};\\\", \\\"{x:1351,y:881,t:1527271853038};\\\", \\\"{x:1351,y:883,t:1527271853054};\\\", \\\"{x:1351,y:886,t:1527271853071};\\\", \\\"{x:1351,y:887,t:1527271853087};\\\", \\\"{x:1351,y:888,t:1527271853104};\\\", \\\"{x:1351,y:889,t:1527271853121};\\\", \\\"{x:1351,y:890,t:1527271853137};\\\", \\\"{x:1352,y:890,t:1527271853155};\\\", \\\"{x:1350,y:882,t:1527271853696};\\\", \\\"{x:1330,y:868,t:1527271853704};\\\", \\\"{x:1260,y:829,t:1527271853720};\\\", \\\"{x:1136,y:760,t:1527271853737};\\\", \\\"{x:1017,y:698,t:1527271853754};\\\", \\\"{x:928,y:657,t:1527271853771};\\\", \\\"{x:873,y:633,t:1527271853788};\\\", \\\"{x:844,y:623,t:1527271853804};\\\", \\\"{x:835,y:619,t:1527271853821};\\\", \\\"{x:834,y:619,t:1527271853848};\\\", \\\"{x:832,y:619,t:1527271853857};\\\", \\\"{x:829,y:619,t:1527271853870};\\\", \\\"{x:818,y:619,t:1527271853888};\\\", \\\"{x:794,y:619,t:1527271853903};\\\", \\\"{x:752,y:619,t:1527271853920};\\\", \\\"{x:742,y:619,t:1527271853938};\\\", \\\"{x:741,y:619,t:1527271853955};\\\", \\\"{x:740,y:619,t:1527271853977};\\\", \\\"{x:739,y:619,t:1527271853988};\\\", \\\"{x:731,y:619,t:1527271854005};\\\", \\\"{x:712,y:624,t:1527271854022};\\\", \\\"{x:687,y:629,t:1527271854038};\\\", \\\"{x:671,y:629,t:1527271854055};\\\", \\\"{x:655,y:628,t:1527271854071};\\\", \\\"{x:642,y:622,t:1527271854087};\\\", \\\"{x:604,y:603,t:1527271854105};\\\", \\\"{x:586,y:597,t:1527271854120};\\\", \\\"{x:584,y:597,t:1527271854138};\\\", \\\"{x:584,y:596,t:1527271854155};\\\", \\\"{x:584,y:595,t:1527271854171};\\\", \\\"{x:579,y:595,t:1527271854188};\\\", \\\"{x:561,y:600,t:1527271854204};\\\", \\\"{x:528,y:608,t:1527271854221};\\\", \\\"{x:477,y:623,t:1527271854238};\\\", \\\"{x:448,y:627,t:1527271854254};\\\", \\\"{x:426,y:628,t:1527271854270};\\\", \\\"{x:397,y:627,t:1527271854288};\\\", \\\"{x:388,y:626,t:1527271854303};\\\", \\\"{x:361,y:623,t:1527271854321};\\\", \\\"{x:359,y:623,t:1527271854337};\\\", \\\"{x:358,y:623,t:1527271854376};\\\", \\\"{x:357,y:624,t:1527271854387};\\\", \\\"{x:341,y:626,t:1527271854404};\\\", \\\"{x:316,y:625,t:1527271854421};\\\", \\\"{x:302,y:623,t:1527271854437};\\\", \\\"{x:298,y:622,t:1527271854455};\\\", \\\"{x:297,y:622,t:1527271854481};\\\", \\\"{x:294,y:622,t:1527271854505};\\\", \\\"{x:292,y:622,t:1527271854521};\\\", \\\"{x:291,y:622,t:1527271854538};\\\", \\\"{x:289,y:619,t:1527271854556};\\\", \\\"{x:289,y:613,t:1527271854571};\\\", \\\"{x:288,y:610,t:1527271854588};\\\", \\\"{x:284,y:602,t:1527271854605};\\\", \\\"{x:279,y:597,t:1527271854622};\\\", \\\"{x:274,y:596,t:1527271854638};\\\", \\\"{x:272,y:594,t:1527271854656};\\\", \\\"{x:272,y:590,t:1527271854671};\\\", \\\"{x:269,y:590,t:1527271854929};\\\", \\\"{x:267,y:590,t:1527271854939};\\\", \\\"{x:259,y:590,t:1527271854955};\\\", \\\"{x:237,y:590,t:1527271854972};\\\", \\\"{x:215,y:590,t:1527271854988};\\\", \\\"{x:204,y:590,t:1527271855005};\\\", \\\"{x:202,y:590,t:1527271855022};\\\", \\\"{x:200,y:590,t:1527271855038};\\\", \\\"{x:199,y:589,t:1527271855055};\\\", \\\"{x:189,y:588,t:1527271855073};\\\", \\\"{x:147,y:582,t:1527271855087};\\\", \\\"{x:133,y:580,t:1527271855104};\\\", \\\"{x:131,y:578,t:1527271855121};\\\", \\\"{x:131,y:575,t:1527271855140};\\\", \\\"{x:131,y:572,t:1527271855155};\\\", \\\"{x:130,y:568,t:1527271855172};\\\", \\\"{x:130,y:566,t:1527271855188};\\\", \\\"{x:130,y:565,t:1527271855205};\\\", \\\"{x:130,y:563,t:1527271855222};\\\", \\\"{x:131,y:562,t:1527271855237};\\\", \\\"{x:132,y:561,t:1527271855255};\\\", \\\"{x:132,y:560,t:1527271855272};\\\", \\\"{x:136,y:557,t:1527271855288};\\\", \\\"{x:143,y:553,t:1527271855305};\\\", \\\"{x:144,y:553,t:1527271855322};\\\", \\\"{x:146,y:552,t:1527271855338};\\\", \\\"{x:148,y:552,t:1527271855657};\\\", \\\"{x:159,y:554,t:1527271855672};\\\", \\\"{x:196,y:570,t:1527271855688};\\\", \\\"{x:275,y:614,t:1527271855706};\\\", \\\"{x:330,y:637,t:1527271855722};\\\", \\\"{x:365,y:657,t:1527271855739};\\\", \\\"{x:389,y:670,t:1527271855756};\\\", \\\"{x:414,y:683,t:1527271855772};\\\", \\\"{x:460,y:710,t:1527271855789};\\\", \\\"{x:515,y:732,t:1527271855805};\\\", \\\"{x:540,y:739,t:1527271855822};\\\", \\\"{x:546,y:740,t:1527271855839};\\\", \\\"{x:547,y:740,t:1527271855856};\\\", \\\"{x:545,y:740,t:1527271855928};\\\", \\\"{x:534,y:740,t:1527271855940};\\\", \\\"{x:454,y:717,t:1527271855956};\\\", \\\"{x:378,y:693,t:1527271855972};\\\", \\\"{x:365,y:690,t:1527271855989};\\\", \\\"{x:362,y:686,t:1527271856041};\\\", \\\"{x:353,y:681,t:1527271856055};\\\", \\\"{x:332,y:666,t:1527271856072};\\\", \\\"{x:328,y:659,t:1527271856089};\\\", \\\"{x:324,y:649,t:1527271856106};\\\", \\\"{x:314,y:637,t:1527271856123};\\\", \\\"{x:283,y:619,t:1527271856140};\\\", \\\"{x:236,y:605,t:1527271856156};\\\", \\\"{x:225,y:600,t:1527271856173};\\\", \\\"{x:222,y:598,t:1527271856189};\\\", \\\"{x:221,y:596,t:1527271856206};\\\", \\\"{x:219,y:594,t:1527271856223};\\\", \\\"{x:214,y:592,t:1527271856240};\\\", \\\"{x:201,y:590,t:1527271856255};\\\", \\\"{x:198,y:590,t:1527271856272};\\\", \\\"{x:196,y:589,t:1527271856289};\\\", \\\"{x:193,y:586,t:1527271856337};\\\", \\\"{x:189,y:584,t:1527271856344};\\\", \\\"{x:179,y:579,t:1527271856357};\\\", \\\"{x:153,y:569,t:1527271856373};\\\", \\\"{x:136,y:565,t:1527271856390};\\\", \\\"{x:134,y:564,t:1527271856405};\\\", \\\"{x:133,y:564,t:1527271856422};\\\", \\\"{x:132,y:563,t:1527271856439};\\\", \\\"{x:132,y:562,t:1527271856473};\\\", \\\"{x:133,y:560,t:1527271856490};\\\", \\\"{x:133,y:559,t:1527271856506};\\\", \\\"{x:133,y:558,t:1527271856523};\\\", \\\"{x:135,y:556,t:1527271856569};\\\", \\\"{x:138,y:554,t:1527271856576};\\\", \\\"{x:142,y:553,t:1527271856589};\\\", \\\"{x:145,y:551,t:1527271856605};\\\", \\\"{x:146,y:551,t:1527271857049};\\\", \\\"{x:148,y:551,t:1527271857088};\\\", \\\"{x:149,y:551,t:1527271857098};\\\", \\\"{x:150,y:551,t:1527271857120};\\\", \\\"{x:150,y:552,t:1527271857152};\\\", \\\"{x:150,y:553,t:1527271857160};\\\", \\\"{x:151,y:554,t:1527271857176};\\\", \\\"{x:152,y:555,t:1527271857192};\\\", \\\"{x:153,y:556,t:1527271857207};\\\", \\\"{x:155,y:556,t:1527271857223};\\\", \\\"{x:155,y:557,t:1527271857264};\\\", \\\"{x:155,y:559,t:1527271857529};\\\", \\\"{x:160,y:565,t:1527271857540};\\\", \\\"{x:177,y:577,t:1527271857558};\\\", \\\"{x:189,y:588,t:1527271857574};\\\", \\\"{x:196,y:593,t:1527271857590};\\\", \\\"{x:210,y:599,t:1527271857607};\\\", \\\"{x:257,y:618,t:1527271857624};\\\", \\\"{x:324,y:648,t:1527271857640};\\\", \\\"{x:411,y:683,t:1527271857657};\\\", \\\"{x:486,y:717,t:1527271857674};\\\", \\\"{x:544,y:743,t:1527271857691};\\\", \\\"{x:578,y:757,t:1527271857707};\\\", \\\"{x:599,y:764,t:1527271857723};\\\", \\\"{x:610,y:767,t:1527271857740};\\\", \\\"{x:611,y:767,t:1527271857757};\\\", \\\"{x:614,y:764,t:1527271858769};\\\", \\\"{x:617,y:762,t:1527271858776};\\\", \\\"{x:623,y:759,t:1527271858789};\\\", \\\"{x:625,y:759,t:1527271858817};\\\", \\\"{x:635,y:761,t:1527271858825};\\\", \\\"{x:657,y:781,t:1527271858839};\\\", \\\"{x:727,y:841,t:1527271858856};\\\", \\\"{x:766,y:866,t:1527271858873};\\\", \\\"{x:803,y:884,t:1527271858889};\\\", \\\"{x:857,y:901,t:1527271858906};\\\", \\\"{x:921,y:911,t:1527271858923};\\\", \\\"{x:992,y:916,t:1527271858940};\\\", \\\"{x:1032,y:918,t:1527271858956};\\\", \\\"{x:1039,y:917,t:1527271858973};\\\", \\\"{x:1042,y:916,t:1527271859137};\\\", \\\"{x:1047,y:915,t:1527271859144};\\\", \\\"{x:1054,y:913,t:1527271859156};\\\", \\\"{x:1072,y:914,t:1527271859173};\\\", \\\"{x:1092,y:921,t:1527271859189};\\\", \\\"{x:1109,y:926,t:1527271859206};\\\", \\\"{x:1120,y:929,t:1527271859223};\\\", \\\"{x:1137,y:929,t:1527271859240};\\\", \\\"{x:1180,y:922,t:1527271859257};\\\", \\\"{x:1204,y:915,t:1527271859273};\\\", \\\"{x:1215,y:909,t:1527271859289};\\\", \\\"{x:1218,y:906,t:1527271859307};\\\", \\\"{x:1219,y:902,t:1527271859323};\\\", \\\"{x:1222,y:895,t:1527271859340};\\\", \\\"{x:1223,y:889,t:1527271859356};\\\", \\\"{x:1225,y:883,t:1527271859372};\\\", \\\"{x:1225,y:877,t:1527271859390};\\\", \\\"{x:1216,y:867,t:1527271859406};\\\", \\\"{x:1206,y:861,t:1527271859421};\\\", \\\"{x:1206,y:860,t:1527271859439};\\\", \\\"{x:1206,y:857,t:1527271859455};\\\", \\\"{x:1207,y:856,t:1527271859472};\\\", \\\"{x:1208,y:855,t:1527271859528};\\\", \\\"{x:1208,y:854,t:1527271859544};\\\", \\\"{x:1209,y:854,t:1527271859576};\\\", \\\"{x:1209,y:853,t:1527271859589};\\\", \\\"{x:1210,y:851,t:1527271859605};\\\", \\\"{x:1212,y:848,t:1527271859622};\\\", \\\"{x:1213,y:846,t:1527271859638};\\\", \\\"{x:1214,y:844,t:1527271859655};\\\", \\\"{x:1214,y:843,t:1527271859705};\\\", \\\"{x:1214,y:842,t:1527271859745};\\\", \\\"{x:1214,y:841,t:1527271859761};\\\", \\\"{x:1214,y:838,t:1527271859825};\\\", \\\"{x:1215,y:837,t:1527271859839};\\\", \\\"{x:1215,y:835,t:1527271859856};\\\", \\\"{x:1215,y:834,t:1527271859873};\\\", \\\"{x:1216,y:835,t:1527271860017};\\\", \\\"{x:1216,y:836,t:1527271860026};\\\", \\\"{x:1219,y:839,t:1527271860039};\\\", \\\"{x:1221,y:842,t:1527271860055};\\\", \\\"{x:1230,y:843,t:1527271860072};\\\", \\\"{x:1241,y:843,t:1527271860088};\\\", \\\"{x:1248,y:845,t:1527271860104};\\\", \\\"{x:1250,y:846,t:1527271860122};\\\", \\\"{x:1254,y:846,t:1527271860139};\\\", \\\"{x:1262,y:846,t:1527271860155};\\\", \\\"{x:1275,y:847,t:1527271860172};\\\", \\\"{x:1289,y:847,t:1527271860188};\\\", \\\"{x:1296,y:847,t:1527271860205};\\\", \\\"{x:1303,y:847,t:1527271860221};\\\", \\\"{x:1314,y:847,t:1527271860238};\\\", \\\"{x:1328,y:845,t:1527271860255};\\\", \\\"{x:1339,y:844,t:1527271860271};\\\", \\\"{x:1347,y:842,t:1527271860289};\\\", \\\"{x:1347,y:841,t:1527271860321};\\\", \\\"{x:1347,y:839,t:1527271860353};\\\", \\\"{x:1348,y:838,t:1527271860361};\\\", \\\"{x:1349,y:837,t:1527271860372};\\\", \\\"{x:1349,y:836,t:1527271860388};\\\", \\\"{x:1349,y:835,t:1527271860409};\\\", \\\"{x:1349,y:834,t:1527271860421};\\\", \\\"{x:1347,y:832,t:1527271860438};\\\", \\\"{x:1346,y:831,t:1527271860455};\\\", \\\"{x:1346,y:830,t:1527271860473};\\\", \\\"{x:1346,y:829,t:1527271860489};\\\", \\\"{x:1346,y:831,t:1527271860682};\\\", \\\"{x:1346,y:833,t:1527271860689};\\\", \\\"{x:1346,y:836,t:1527271860705};\\\", \\\"{x:1346,y:840,t:1527271860721};\\\", \\\"{x:1347,y:847,t:1527271860738};\\\", \\\"{x:1350,y:858,t:1527271860753};\\\", \\\"{x:1350,y:865,t:1527271860771};\\\", \\\"{x:1350,y:871,t:1527271860787};\\\", \\\"{x:1350,y:875,t:1527271860804};\\\", \\\"{x:1350,y:879,t:1527271860821};\\\", \\\"{x:1350,y:885,t:1527271860836};\\\", \\\"{x:1350,y:892,t:1527271860854};\\\", \\\"{x:1350,y:898,t:1527271860871};\\\", \\\"{x:1350,y:903,t:1527271860888};\\\", \\\"{x:1350,y:906,t:1527271860904};\\\", \\\"{x:1350,y:904,t:1527271861169};\\\", \\\"{x:1350,y:893,t:1527271861188};\\\", \\\"{x:1350,y:879,t:1527271861206};\\\", \\\"{x:1350,y:867,t:1527271861220};\\\", \\\"{x:1350,y:860,t:1527271861238};\\\", \\\"{x:1349,y:854,t:1527271861254};\\\", \\\"{x:1349,y:848,t:1527271861270};\\\", \\\"{x:1350,y:841,t:1527271861288};\\\", \\\"{x:1350,y:834,t:1527271861304};\\\", \\\"{x:1350,y:827,t:1527271861321};\\\", \\\"{x:1350,y:826,t:1527271861337};\\\", \\\"{x:1350,y:825,t:1527271861521};\\\", \\\"{x:1350,y:819,t:1527271861538};\\\", \\\"{x:1350,y:811,t:1527271861553};\\\", \\\"{x:1350,y:805,t:1527271861570};\\\", \\\"{x:1350,y:801,t:1527271861587};\\\", \\\"{x:1350,y:799,t:1527271861602};\\\", \\\"{x:1350,y:796,t:1527271861619};\\\", \\\"{x:1350,y:790,t:1527271861636};\\\", \\\"{x:1350,y:787,t:1527271861653};\\\", \\\"{x:1350,y:782,t:1527271861670};\\\", \\\"{x:1350,y:778,t:1527271861686};\\\", \\\"{x:1350,y:775,t:1527271861703};\\\", \\\"{x:1350,y:769,t:1527271861719};\\\", \\\"{x:1350,y:765,t:1527271861736};\\\", \\\"{x:1350,y:760,t:1527271861753};\\\", \\\"{x:1351,y:754,t:1527271861770};\\\", \\\"{x:1352,y:750,t:1527271861786};\\\", \\\"{x:1352,y:745,t:1527271861803};\\\", \\\"{x:1352,y:741,t:1527271861820};\\\", \\\"{x:1352,y:733,t:1527271861836};\\\", \\\"{x:1352,y:729,t:1527271861853};\\\", \\\"{x:1352,y:723,t:1527271861870};\\\", \\\"{x:1354,y:717,t:1527271861886};\\\", \\\"{x:1354,y:714,t:1527271861904};\\\", \\\"{x:1356,y:708,t:1527271861921};\\\", \\\"{x:1356,y:707,t:1527271861944};\\\", \\\"{x:1356,y:705,t:1527271861953};\\\", \\\"{x:1356,y:702,t:1527271861970};\\\", \\\"{x:1356,y:701,t:1527271861985};\\\", \\\"{x:1355,y:698,t:1527271862002};\\\", \\\"{x:1349,y:695,t:1527271862019};\\\", \\\"{x:1327,y:693,t:1527271862036};\\\", \\\"{x:1280,y:691,t:1527271862053};\\\", \\\"{x:1219,y:691,t:1527271862069};\\\", \\\"{x:1153,y:699,t:1527271862086};\\\", \\\"{x:1070,y:720,t:1527271862103};\\\", \\\"{x:995,y:738,t:1527271862119};\\\", \\\"{x:915,y:758,t:1527271862136};\\\", \\\"{x:862,y:766,t:1527271862152};\\\", \\\"{x:809,y:772,t:1527271862169};\\\", \\\"{x:766,y:781,t:1527271862186};\\\", \\\"{x:721,y:787,t:1527271862203};\\\", \\\"{x:671,y:794,t:1527271862219};\\\", \\\"{x:621,y:794,t:1527271862236};\\\", \\\"{x:593,y:794,t:1527271862253};\\\", \\\"{x:573,y:792,t:1527271862269};\\\", \\\"{x:558,y:788,t:1527271862286};\\\", \\\"{x:534,y:782,t:1527271862302};\\\", \\\"{x:507,y:775,t:1527271862320};\\\", \\\"{x:495,y:769,t:1527271862336};\\\", \\\"{x:491,y:765,t:1527271862352};\\\", \\\"{x:486,y:760,t:1527271862369};\\\", \\\"{x:476,y:756,t:1527271862386};\\\", \\\"{x:469,y:752,t:1527271862402};\\\", \\\"{x:467,y:751,t:1527271862420};\\\", \\\"{x:470,y:748,t:1527271862436};\\\", \\\"{x:483,y:738,t:1527271862452};\\\", \\\"{x:494,y:728,t:1527271862470};\\\", \\\"{x:498,y:723,t:1527271862486};\\\", \\\"{x:498,y:720,t:1527271862501};\\\", \\\"{x:498,y:719,t:1527271862511};\\\" ] }, { \\\"rt\\\": 93178, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 548845, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-04 PM-03 PM-02 PM-02 PM-03 PM-04 PM-Z -U -U -04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:718,t:1527271865473};\\\", \\\"{x:506,y:717,t:1527271865481};\\\", \\\"{x:522,y:714,t:1527271865496};\\\", \\\"{x:537,y:713,t:1527271865515};\\\", \\\"{x:556,y:711,t:1527271865530};\\\", \\\"{x:583,y:713,t:1527271865546};\\\", \\\"{x:628,y:728,t:1527271865563};\\\", \\\"{x:703,y:748,t:1527271865580};\\\", \\\"{x:791,y:771,t:1527271865597};\\\", \\\"{x:881,y:786,t:1527271865613};\\\", \\\"{x:975,y:802,t:1527271865629};\\\", \\\"{x:1081,y:816,t:1527271865647};\\\", \\\"{x:1083,y:817,t:1527271866050};\\\", \\\"{x:1103,y:833,t:1527271866065};\\\", \\\"{x:1127,y:849,t:1527271866080};\\\", \\\"{x:1162,y:868,t:1527271866098};\\\", \\\"{x:1188,y:879,t:1527271866115};\\\", \\\"{x:1211,y:887,t:1527271866131};\\\", \\\"{x:1235,y:895,t:1527271866148};\\\", \\\"{x:1260,y:900,t:1527271866165};\\\", \\\"{x:1268,y:901,t:1527271866180};\\\", \\\"{x:1270,y:901,t:1527271866197};\\\", \\\"{x:1274,y:901,t:1527271866385};\\\", \\\"{x:1276,y:901,t:1527271866398};\\\", \\\"{x:1289,y:901,t:1527271866415};\\\", \\\"{x:1312,y:913,t:1527271866431};\\\", \\\"{x:1341,y:925,t:1527271866448};\\\", \\\"{x:1371,y:936,t:1527271866465};\\\", \\\"{x:1387,y:944,t:1527271866481};\\\", \\\"{x:1407,y:952,t:1527271866498};\\\", \\\"{x:1424,y:959,t:1527271866515};\\\", \\\"{x:1442,y:968,t:1527271866532};\\\", \\\"{x:1462,y:975,t:1527271866548};\\\", \\\"{x:1480,y:984,t:1527271866565};\\\", \\\"{x:1494,y:989,t:1527271866582};\\\", \\\"{x:1508,y:995,t:1527271866597};\\\", \\\"{x:1521,y:997,t:1527271866614};\\\", \\\"{x:1533,y:1000,t:1527271866632};\\\", \\\"{x:1538,y:1000,t:1527271866647};\\\", \\\"{x:1545,y:1000,t:1527271866665};\\\", \\\"{x:1548,y:998,t:1527271866682};\\\", \\\"{x:1550,y:996,t:1527271866698};\\\", \\\"{x:1552,y:991,t:1527271866715};\\\", \\\"{x:1553,y:988,t:1527271866732};\\\", \\\"{x:1553,y:983,t:1527271866748};\\\", \\\"{x:1553,y:982,t:1527271866764};\\\", \\\"{x:1553,y:983,t:1527271866881};\\\", \\\"{x:1558,y:990,t:1527271866899};\\\", \\\"{x:1568,y:997,t:1527271866915};\\\", \\\"{x:1581,y:1002,t:1527271866931};\\\", \\\"{x:1593,y:1005,t:1527271866949};\\\", \\\"{x:1594,y:1005,t:1527271867327};\\\", \\\"{x:1593,y:1005,t:1527271867416};\\\", \\\"{x:1591,y:1005,t:1527271867432};\\\", \\\"{x:1589,y:1005,t:1527271867448};\\\", \\\"{x:1587,y:1005,t:1527271867465};\\\", \\\"{x:1586,y:1005,t:1527271867481};\\\", \\\"{x:1584,y:1005,t:1527271867561};\\\", \\\"{x:1583,y:1005,t:1527271867592};\\\", \\\"{x:1580,y:1005,t:1527271867600};\\\", \\\"{x:1579,y:1005,t:1527271867616};\\\", \\\"{x:1576,y:1005,t:1527271867631};\\\", \\\"{x:1573,y:1005,t:1527271867649};\\\", \\\"{x:1571,y:1005,t:1527271867665};\\\", \\\"{x:1569,y:1005,t:1527271867681};\\\", \\\"{x:1568,y:1005,t:1527271867699};\\\", \\\"{x:1566,y:1005,t:1527271867715};\\\", \\\"{x:1563,y:1005,t:1527271867732};\\\", \\\"{x:1556,y:1005,t:1527271867749};\\\", \\\"{x:1548,y:1005,t:1527271867765};\\\", \\\"{x:1541,y:1005,t:1527271867781};\\\", \\\"{x:1539,y:1005,t:1527271867799};\\\", \\\"{x:1536,y:1005,t:1527271867815};\\\", \\\"{x:1531,y:1004,t:1527271867832};\\\", \\\"{x:1529,y:1003,t:1527271867849};\\\", \\\"{x:1527,y:1002,t:1527271867865};\\\", \\\"{x:1527,y:1001,t:1527271867883};\\\", \\\"{x:1526,y:1001,t:1527271868017};\\\", \\\"{x:1528,y:1001,t:1527271868057};\\\", \\\"{x:1535,y:1000,t:1527271868065};\\\", \\\"{x:1550,y:1000,t:1527271868083};\\\", \\\"{x:1565,y:1000,t:1527271868098};\\\", \\\"{x:1578,y:998,t:1527271868116};\\\", \\\"{x:1588,y:996,t:1527271868133};\\\", \\\"{x:1597,y:995,t:1527271868149};\\\", \\\"{x:1603,y:993,t:1527271868165};\\\", \\\"{x:1605,y:992,t:1527271868182};\\\", \\\"{x:1607,y:991,t:1527271868199};\\\", \\\"{x:1610,y:989,t:1527271868215};\\\", \\\"{x:1615,y:986,t:1527271868232};\\\", \\\"{x:1617,y:984,t:1527271868249};\\\", \\\"{x:1617,y:982,t:1527271868266};\\\", \\\"{x:1617,y:979,t:1527271868283};\\\", \\\"{x:1618,y:975,t:1527271868300};\\\", \\\"{x:1620,y:968,t:1527271868316};\\\", \\\"{x:1622,y:965,t:1527271868332};\\\", \\\"{x:1622,y:964,t:1527271868361};\\\", \\\"{x:1622,y:963,t:1527271868649};\\\", \\\"{x:1622,y:961,t:1527271868666};\\\", \\\"{x:1621,y:957,t:1527271868682};\\\", \\\"{x:1619,y:955,t:1527271868700};\\\", \\\"{x:1617,y:953,t:1527271868716};\\\", \\\"{x:1616,y:952,t:1527271868732};\\\", \\\"{x:1616,y:951,t:1527271871273};\\\", \\\"{x:1617,y:951,t:1527271871329};\\\", \\\"{x:1618,y:951,t:1527271871512};\\\", \\\"{x:1620,y:952,t:1527271871521};\\\", \\\"{x:1621,y:954,t:1527271871536};\\\", \\\"{x:1621,y:955,t:1527271871552};\\\", \\\"{x:1621,y:956,t:1527271871568};\\\", \\\"{x:1624,y:964,t:1527271871585};\\\", \\\"{x:1624,y:966,t:1527271871603};\\\", \\\"{x:1624,y:967,t:1527271871618};\\\", \\\"{x:1623,y:967,t:1527271872001};\\\", \\\"{x:1622,y:967,t:1527271872057};\\\", \\\"{x:1620,y:967,t:1527271872072};\\\", \\\"{x:1618,y:967,t:1527271872086};\\\", \\\"{x:1616,y:967,t:1527271872102};\\\", \\\"{x:1614,y:967,t:1527271872119};\\\", \\\"{x:1612,y:967,t:1527271872209};\\\", \\\"{x:1611,y:966,t:1527271872361};\\\", \\\"{x:1611,y:965,t:1527271872377};\\\", \\\"{x:1611,y:964,t:1527271872386};\\\", \\\"{x:1611,y:959,t:1527271872402};\\\", \\\"{x:1611,y:956,t:1527271872419};\\\", \\\"{x:1611,y:953,t:1527271872436};\\\", \\\"{x:1611,y:949,t:1527271872452};\\\", \\\"{x:1611,y:943,t:1527271872469};\\\", \\\"{x:1611,y:937,t:1527271872486};\\\", \\\"{x:1611,y:932,t:1527271872503};\\\", \\\"{x:1611,y:924,t:1527271872519};\\\", \\\"{x:1611,y:915,t:1527271872535};\\\", \\\"{x:1613,y:904,t:1527271872552};\\\", \\\"{x:1614,y:899,t:1527271872569};\\\", \\\"{x:1614,y:894,t:1527271872586};\\\", \\\"{x:1615,y:887,t:1527271872603};\\\", \\\"{x:1616,y:883,t:1527271872619};\\\", \\\"{x:1617,y:880,t:1527271872636};\\\", \\\"{x:1617,y:878,t:1527271872652};\\\", \\\"{x:1617,y:875,t:1527271872669};\\\", \\\"{x:1617,y:874,t:1527271872686};\\\", \\\"{x:1617,y:872,t:1527271872703};\\\", \\\"{x:1617,y:871,t:1527271872719};\\\", \\\"{x:1619,y:868,t:1527271872736};\\\", \\\"{x:1619,y:867,t:1527271872769};\\\", \\\"{x:1619,y:865,t:1527271872786};\\\", \\\"{x:1619,y:862,t:1527271872803};\\\", \\\"{x:1619,y:867,t:1527271872937};\\\", \\\"{x:1619,y:876,t:1527271872952};\\\", \\\"{x:1619,y:882,t:1527271872970};\\\", \\\"{x:1619,y:888,t:1527271872986};\\\", \\\"{x:1619,y:894,t:1527271873002};\\\", \\\"{x:1619,y:899,t:1527271873020};\\\", \\\"{x:1620,y:906,t:1527271873036};\\\", \\\"{x:1620,y:914,t:1527271873053};\\\", \\\"{x:1620,y:921,t:1527271873070};\\\", \\\"{x:1620,y:926,t:1527271873086};\\\", \\\"{x:1620,y:932,t:1527271873103};\\\", \\\"{x:1620,y:936,t:1527271873119};\\\", \\\"{x:1620,y:938,t:1527271873136};\\\", \\\"{x:1620,y:939,t:1527271873233};\\\", \\\"{x:1620,y:940,t:1527271873240};\\\", \\\"{x:1620,y:941,t:1527271873257};\\\", \\\"{x:1620,y:944,t:1527271873280};\\\", \\\"{x:1619,y:945,t:1527271873305};\\\", \\\"{x:1619,y:946,t:1527271873320};\\\", \\\"{x:1618,y:950,t:1527271873336};\\\", \\\"{x:1616,y:952,t:1527271873352};\\\", \\\"{x:1615,y:953,t:1527271873370};\\\", \\\"{x:1614,y:954,t:1527271873392};\\\", \\\"{x:1614,y:955,t:1527271873403};\\\", \\\"{x:1613,y:956,t:1527271873420};\\\", \\\"{x:1613,y:957,t:1527271873436};\\\", \\\"{x:1611,y:958,t:1527271873453};\\\", \\\"{x:1609,y:960,t:1527271873470};\\\", \\\"{x:1608,y:962,t:1527271873487};\\\", \\\"{x:1606,y:963,t:1527271873503};\\\", \\\"{x:1603,y:965,t:1527271873520};\\\", \\\"{x:1602,y:966,t:1527271873537};\\\", \\\"{x:1601,y:966,t:1527271873801};\\\", \\\"{x:1600,y:966,t:1527271873808};\\\", \\\"{x:1596,y:967,t:1527271873820};\\\", \\\"{x:1587,y:969,t:1527271873837};\\\", \\\"{x:1577,y:970,t:1527271873853};\\\", \\\"{x:1556,y:972,t:1527271873870};\\\", \\\"{x:1534,y:974,t:1527271873887};\\\", \\\"{x:1509,y:975,t:1527271873904};\\\", \\\"{x:1488,y:980,t:1527271873920};\\\", \\\"{x:1470,y:980,t:1527271873936};\\\", \\\"{x:1462,y:980,t:1527271873954};\\\", \\\"{x:1460,y:980,t:1527271873970};\\\", \\\"{x:1459,y:980,t:1527271873987};\\\", \\\"{x:1461,y:979,t:1527271874169};\\\", \\\"{x:1464,y:976,t:1527271874187};\\\", \\\"{x:1466,y:971,t:1527271874204};\\\", \\\"{x:1468,y:968,t:1527271874220};\\\", \\\"{x:1471,y:965,t:1527271874237};\\\", \\\"{x:1472,y:965,t:1527271874254};\\\", \\\"{x:1474,y:964,t:1527271874270};\\\", \\\"{x:1475,y:963,t:1527271874287};\\\", \\\"{x:1476,y:962,t:1527271874305};\\\", \\\"{x:1477,y:962,t:1527271874320};\\\", \\\"{x:1478,y:962,t:1527271874377};\\\", \\\"{x:1479,y:962,t:1527271874387};\\\", \\\"{x:1480,y:962,t:1527271874404};\\\", \\\"{x:1482,y:962,t:1527271874744};\\\", \\\"{x:1484,y:963,t:1527271874753};\\\", \\\"{x:1486,y:963,t:1527271874771};\\\", \\\"{x:1486,y:964,t:1527271874787};\\\", \\\"{x:1487,y:965,t:1527271874804};\\\", \\\"{x:1488,y:965,t:1527271874821};\\\", \\\"{x:1491,y:965,t:1527271874881};\\\", \\\"{x:1493,y:965,t:1527271874887};\\\", \\\"{x:1496,y:966,t:1527271874903};\\\", \\\"{x:1498,y:967,t:1527271874920};\\\", \\\"{x:1499,y:967,t:1527271874938};\\\", \\\"{x:1501,y:967,t:1527271874960};\\\", \\\"{x:1503,y:967,t:1527271874971};\\\", \\\"{x:1512,y:969,t:1527271874988};\\\", \\\"{x:1517,y:969,t:1527271875004};\\\", \\\"{x:1521,y:969,t:1527271875020};\\\", \\\"{x:1523,y:969,t:1527271875073};\\\", \\\"{x:1525,y:969,t:1527271875088};\\\", \\\"{x:1528,y:969,t:1527271875104};\\\", \\\"{x:1531,y:969,t:1527271875120};\\\", \\\"{x:1532,y:969,t:1527271875138};\\\", \\\"{x:1533,y:969,t:1527271875184};\\\", \\\"{x:1534,y:969,t:1527271875200};\\\", \\\"{x:1536,y:969,t:1527271875257};\\\", \\\"{x:1544,y:969,t:1527271875271};\\\", \\\"{x:1558,y:971,t:1527271875288};\\\", \\\"{x:1573,y:973,t:1527271875305};\\\", \\\"{x:1581,y:973,t:1527271875321};\\\", \\\"{x:1586,y:973,t:1527271875337};\\\", \\\"{x:1592,y:973,t:1527271875355};\\\", \\\"{x:1596,y:973,t:1527271875371};\\\", \\\"{x:1597,y:973,t:1527271875457};\\\", \\\"{x:1598,y:973,t:1527271875472};\\\", \\\"{x:1599,y:973,t:1527271875488};\\\", \\\"{x:1600,y:973,t:1527271875585};\\\", \\\"{x:1602,y:973,t:1527271875593};\\\", \\\"{x:1605,y:972,t:1527271875604};\\\", \\\"{x:1607,y:972,t:1527271875621};\\\", \\\"{x:1610,y:972,t:1527271875637};\\\", \\\"{x:1613,y:972,t:1527271875654};\\\", \\\"{x:1616,y:972,t:1527271875670};\\\", \\\"{x:1616,y:971,t:1527271875745};\\\", \\\"{x:1616,y:970,t:1527271875755};\\\", \\\"{x:1617,y:970,t:1527271875771};\\\", \\\"{x:1620,y:967,t:1527271875788};\\\", \\\"{x:1622,y:966,t:1527271875804};\\\", \\\"{x:1623,y:965,t:1527271875824};\\\", \\\"{x:1623,y:963,t:1527271875921};\\\", \\\"{x:1607,y:960,t:1527271875938};\\\", \\\"{x:1594,y:959,t:1527271875955};\\\", \\\"{x:1583,y:959,t:1527271875972};\\\", \\\"{x:1568,y:959,t:1527271875988};\\\", \\\"{x:1553,y:959,t:1527271876005};\\\", \\\"{x:1541,y:959,t:1527271876022};\\\", \\\"{x:1531,y:959,t:1527271876038};\\\", \\\"{x:1521,y:960,t:1527271876055};\\\", \\\"{x:1514,y:960,t:1527271876072};\\\", \\\"{x:1501,y:961,t:1527271876088};\\\", \\\"{x:1489,y:964,t:1527271876105};\\\", \\\"{x:1480,y:964,t:1527271876121};\\\", \\\"{x:1476,y:964,t:1527271876137};\\\", \\\"{x:1475,y:964,t:1527271876155};\\\", \\\"{x:1474,y:964,t:1527271876171};\\\", \\\"{x:1473,y:964,t:1527271876191};\\\", \\\"{x:1472,y:964,t:1527271876204};\\\", \\\"{x:1471,y:964,t:1527271876221};\\\", \\\"{x:1470,y:964,t:1527271876238};\\\", \\\"{x:1469,y:964,t:1527271876303};\\\", \\\"{x:1468,y:964,t:1527271876312};\\\", \\\"{x:1467,y:964,t:1527271876321};\\\", \\\"{x:1464,y:966,t:1527271876339};\\\", \\\"{x:1462,y:966,t:1527271876354};\\\", \\\"{x:1464,y:966,t:1527271876497};\\\", \\\"{x:1465,y:966,t:1527271876520};\\\", \\\"{x:1466,y:966,t:1527271876569};\\\", \\\"{x:1467,y:965,t:1527271876584};\\\", \\\"{x:1468,y:964,t:1527271876593};\\\", \\\"{x:1469,y:964,t:1527271876625};\\\", \\\"{x:1470,y:963,t:1527271876638};\\\", \\\"{x:1471,y:959,t:1527271876656};\\\", \\\"{x:1476,y:948,t:1527271876672};\\\", \\\"{x:1476,y:940,t:1527271876688};\\\", \\\"{x:1478,y:934,t:1527271876705};\\\", \\\"{x:1478,y:930,t:1527271876722};\\\", \\\"{x:1479,y:926,t:1527271876739};\\\", \\\"{x:1479,y:919,t:1527271876755};\\\", \\\"{x:1479,y:909,t:1527271876771};\\\", \\\"{x:1479,y:894,t:1527271876788};\\\", \\\"{x:1479,y:881,t:1527271876805};\\\", \\\"{x:1479,y:877,t:1527271876821};\\\", \\\"{x:1479,y:874,t:1527271876838};\\\", \\\"{x:1479,y:866,t:1527271876856};\\\", \\\"{x:1479,y:861,t:1527271876871};\\\", \\\"{x:1479,y:854,t:1527271876888};\\\", \\\"{x:1479,y:849,t:1527271876905};\\\", \\\"{x:1479,y:846,t:1527271876921};\\\", \\\"{x:1479,y:845,t:1527271876939};\\\", \\\"{x:1479,y:843,t:1527271876955};\\\", \\\"{x:1479,y:842,t:1527271876976};\\\", \\\"{x:1479,y:841,t:1527271876993};\\\", \\\"{x:1479,y:840,t:1527271877217};\\\", \\\"{x:1478,y:839,t:1527271877224};\\\", \\\"{x:1476,y:838,t:1527271877297};\\\", \\\"{x:1474,y:838,t:1527271877306};\\\", \\\"{x:1456,y:836,t:1527271877323};\\\", \\\"{x:1401,y:828,t:1527271877339};\\\", \\\"{x:1299,y:817,t:1527271877356};\\\", \\\"{x:1191,y:803,t:1527271877373};\\\", \\\"{x:1110,y:803,t:1527271877389};\\\", \\\"{x:1060,y:803,t:1527271877406};\\\", \\\"{x:1016,y:798,t:1527271877422};\\\", \\\"{x:981,y:793,t:1527271877439};\\\", \\\"{x:931,y:782,t:1527271877456};\\\", \\\"{x:906,y:775,t:1527271877472};\\\", \\\"{x:900,y:771,t:1527271877489};\\\", \\\"{x:898,y:770,t:1527271877505};\\\", \\\"{x:892,y:764,t:1527271877522};\\\", \\\"{x:881,y:753,t:1527271877539};\\\", \\\"{x:854,y:729,t:1527271877556};\\\", \\\"{x:809,y:706,t:1527271877573};\\\", \\\"{x:754,y:693,t:1527271877589};\\\", \\\"{x:718,y:685,t:1527271877606};\\\", \\\"{x:699,y:682,t:1527271877623};\\\", \\\"{x:682,y:676,t:1527271877639};\\\", \\\"{x:664,y:671,t:1527271877656};\\\", \\\"{x:663,y:671,t:1527271877673};\\\", \\\"{x:663,y:670,t:1527271877690};\\\", \\\"{x:663,y:669,t:1527271877706};\\\", \\\"{x:658,y:667,t:1527271877729};\\\", \\\"{x:652,y:665,t:1527271877740};\\\", \\\"{x:647,y:663,t:1527271877756};\\\", \\\"{x:644,y:660,t:1527271877773};\\\", \\\"{x:643,y:657,t:1527271877789};\\\", \\\"{x:641,y:650,t:1527271877807};\\\", \\\"{x:637,y:640,t:1527271877823};\\\", \\\"{x:630,y:635,t:1527271877839};\\\", \\\"{x:622,y:631,t:1527271877856};\\\", \\\"{x:617,y:628,t:1527271877874};\\\", \\\"{x:617,y:626,t:1527271877889};\\\", \\\"{x:616,y:619,t:1527271877907};\\\", \\\"{x:614,y:616,t:1527271877923};\\\", \\\"{x:613,y:610,t:1527271877940};\\\", \\\"{x:610,y:608,t:1527271877956};\\\", \\\"{x:607,y:604,t:1527271877973};\\\", \\\"{x:606,y:602,t:1527271877990};\\\", \\\"{x:604,y:601,t:1527271878006};\\\", \\\"{x:604,y:599,t:1527271878023};\\\", \\\"{x:608,y:600,t:1527271878327};\\\", \\\"{x:623,y:608,t:1527271878340};\\\", \\\"{x:660,y:620,t:1527271878357};\\\", \\\"{x:694,y:635,t:1527271878373};\\\", \\\"{x:718,y:640,t:1527271878391};\\\", \\\"{x:741,y:650,t:1527271878407};\\\", \\\"{x:786,y:669,t:1527271878424};\\\", \\\"{x:833,y:692,t:1527271878440};\\\", \\\"{x:889,y:717,t:1527271878458};\\\", \\\"{x:952,y:743,t:1527271878473};\\\", \\\"{x:999,y:763,t:1527271878491};\\\", \\\"{x:1045,y:780,t:1527271878508};\\\", \\\"{x:1076,y:789,t:1527271878524};\\\", \\\"{x:1116,y:802,t:1527271878541};\\\", \\\"{x:1149,y:816,t:1527271878557};\\\", \\\"{x:1176,y:832,t:1527271878575};\\\", \\\"{x:1193,y:841,t:1527271878591};\\\", \\\"{x:1204,y:849,t:1527271878608};\\\", \\\"{x:1214,y:854,t:1527271878624};\\\", \\\"{x:1226,y:859,t:1527271878641};\\\", \\\"{x:1237,y:863,t:1527271878658};\\\", \\\"{x:1243,y:865,t:1527271878675};\\\", \\\"{x:1251,y:867,t:1527271878691};\\\", \\\"{x:1265,y:871,t:1527271878708};\\\", \\\"{x:1285,y:877,t:1527271878725};\\\", \\\"{x:1311,y:882,t:1527271878742};\\\", \\\"{x:1343,y:886,t:1527271878758};\\\", \\\"{x:1375,y:893,t:1527271878776};\\\", \\\"{x:1407,y:897,t:1527271878792};\\\", \\\"{x:1412,y:898,t:1527271878808};\\\", \\\"{x:1417,y:898,t:1527271878825};\\\", \\\"{x:1421,y:899,t:1527271878843};\\\", \\\"{x:1426,y:900,t:1527271878859};\\\", \\\"{x:1429,y:901,t:1527271878875};\\\", \\\"{x:1430,y:901,t:1527271878893};\\\", \\\"{x:1432,y:901,t:1527271878912};\\\", \\\"{x:1436,y:901,t:1527271878925};\\\", \\\"{x:1453,y:900,t:1527271878942};\\\", \\\"{x:1471,y:896,t:1527271878959};\\\", \\\"{x:1490,y:888,t:1527271878977};\\\", \\\"{x:1495,y:884,t:1527271878993};\\\", \\\"{x:1498,y:880,t:1527271879009};\\\", \\\"{x:1500,y:876,t:1527271879026};\\\", \\\"{x:1502,y:873,t:1527271879042};\\\", \\\"{x:1504,y:870,t:1527271879060};\\\", \\\"{x:1504,y:869,t:1527271879076};\\\", \\\"{x:1504,y:863,t:1527271879092};\\\", \\\"{x:1504,y:856,t:1527271879109};\\\", \\\"{x:1501,y:847,t:1527271879126};\\\", \\\"{x:1500,y:846,t:1527271879143};\\\", \\\"{x:1500,y:845,t:1527271879161};\\\", \\\"{x:1500,y:843,t:1527271879184};\\\", \\\"{x:1500,y:842,t:1527271879201};\\\", \\\"{x:1499,y:839,t:1527271879209};\\\", \\\"{x:1496,y:834,t:1527271879226};\\\", \\\"{x:1496,y:833,t:1527271879243};\\\", \\\"{x:1496,y:832,t:1527271879260};\\\", \\\"{x:1495,y:832,t:1527271879313};\\\", \\\"{x:1494,y:832,t:1527271879326};\\\", \\\"{x:1492,y:832,t:1527271879343};\\\", \\\"{x:1490,y:832,t:1527271879360};\\\", \\\"{x:1488,y:833,t:1527271879376};\\\", \\\"{x:1487,y:834,t:1527271879393};\\\", \\\"{x:1486,y:834,t:1527271879410};\\\", \\\"{x:1484,y:835,t:1527271879428};\\\", \\\"{x:1483,y:835,t:1527271879504};\\\", \\\"{x:1480,y:835,t:1527271879527};\\\", \\\"{x:1478,y:835,t:1527271879544};\\\", \\\"{x:1477,y:835,t:1527271879600};\\\", \\\"{x:1474,y:834,t:1527271879610};\\\", \\\"{x:1471,y:834,t:1527271879627};\\\", \\\"{x:1470,y:834,t:1527271879644};\\\", \\\"{x:1470,y:833,t:1527271879728};\\\", \\\"{x:1474,y:831,t:1527271879744};\\\", \\\"{x:1477,y:830,t:1527271879762};\\\", \\\"{x:1480,y:829,t:1527271879778};\\\", \\\"{x:1480,y:828,t:1527271879794};\\\", \\\"{x:1482,y:828,t:1527271879810};\\\", \\\"{x:1484,y:827,t:1527271879828};\\\", \\\"{x:1489,y:827,t:1527271879844};\\\", \\\"{x:1495,y:827,t:1527271879861};\\\", \\\"{x:1502,y:827,t:1527271879878};\\\", \\\"{x:1506,y:827,t:1527271879896};\\\", \\\"{x:1510,y:827,t:1527271879911};\\\", \\\"{x:1521,y:827,t:1527271879928};\\\", \\\"{x:1532,y:827,t:1527271879944};\\\", \\\"{x:1543,y:827,t:1527271879961};\\\", \\\"{x:1553,y:827,t:1527271879978};\\\", \\\"{x:1557,y:827,t:1527271879995};\\\", \\\"{x:1561,y:827,t:1527271880011};\\\", \\\"{x:1565,y:827,t:1527271880028};\\\", \\\"{x:1568,y:826,t:1527271880045};\\\", \\\"{x:1575,y:826,t:1527271880062};\\\", \\\"{x:1579,y:825,t:1527271880078};\\\", \\\"{x:1583,y:825,t:1527271880095};\\\", \\\"{x:1585,y:825,t:1527271880112};\\\", \\\"{x:1587,y:824,t:1527271880128};\\\", \\\"{x:1588,y:824,t:1527271880145};\\\", \\\"{x:1589,y:824,t:1527271880200};\\\", \\\"{x:1589,y:823,t:1527271880212};\\\", \\\"{x:1591,y:823,t:1527271880232};\\\", \\\"{x:1592,y:823,t:1527271880248};\\\", \\\"{x:1594,y:823,t:1527271880312};\\\", \\\"{x:1597,y:823,t:1527271880329};\\\", \\\"{x:1599,y:824,t:1527271880346};\\\", \\\"{x:1600,y:824,t:1527271880368};\\\", \\\"{x:1601,y:824,t:1527271880417};\\\", \\\"{x:1602,y:824,t:1527271880521};\\\", \\\"{x:1603,y:824,t:1527271880529};\\\", \\\"{x:1604,y:824,t:1527271880560};\\\", \\\"{x:1605,y:824,t:1527271880584};\\\", \\\"{x:1606,y:824,t:1527271880596};\\\", \\\"{x:1607,y:824,t:1527271880613};\\\", \\\"{x:1609,y:825,t:1527271880631};\\\", \\\"{x:1611,y:825,t:1527271880646};\\\", \\\"{x:1612,y:825,t:1527271880663};\\\", \\\"{x:1613,y:826,t:1527271880787};\\\", \\\"{x:1613,y:827,t:1527271880823};\\\", \\\"{x:1613,y:828,t:1527271880831};\\\", \\\"{x:1614,y:830,t:1527271880846};\\\", \\\"{x:1614,y:835,t:1527271880864};\\\", \\\"{x:1614,y:839,t:1527271880880};\\\", \\\"{x:1614,y:843,t:1527271880896};\\\", \\\"{x:1614,y:848,t:1527271880914};\\\", \\\"{x:1614,y:852,t:1527271880929};\\\", \\\"{x:1615,y:856,t:1527271880946};\\\", \\\"{x:1615,y:861,t:1527271880964};\\\", \\\"{x:1615,y:866,t:1527271880980};\\\", \\\"{x:1615,y:868,t:1527271880997};\\\", \\\"{x:1615,y:870,t:1527271881014};\\\", \\\"{x:1615,y:874,t:1527271881031};\\\", \\\"{x:1615,y:878,t:1527271881047};\\\", \\\"{x:1613,y:884,t:1527271881064};\\\", \\\"{x:1613,y:889,t:1527271881081};\\\", \\\"{x:1611,y:893,t:1527271881097};\\\", \\\"{x:1610,y:896,t:1527271881114};\\\", \\\"{x:1609,y:902,t:1527271881131};\\\", \\\"{x:1608,y:908,t:1527271881148};\\\", \\\"{x:1606,y:920,t:1527271881163};\\\", \\\"{x:1606,y:929,t:1527271881181};\\\", \\\"{x:1606,y:934,t:1527271881197};\\\", \\\"{x:1606,y:939,t:1527271881215};\\\", \\\"{x:1606,y:946,t:1527271881231};\\\", \\\"{x:1608,y:967,t:1527271881248};\\\", \\\"{x:1612,y:981,t:1527271881264};\\\", \\\"{x:1616,y:993,t:1527271881281};\\\", \\\"{x:1617,y:995,t:1527271881298};\\\", \\\"{x:1618,y:996,t:1527271881315};\\\", \\\"{x:1618,y:997,t:1527271881331};\\\", \\\"{x:1619,y:997,t:1527271881348};\\\", \\\"{x:1619,y:995,t:1527271881497};\\\", \\\"{x:1619,y:992,t:1527271881504};\\\", \\\"{x:1618,y:987,t:1527271881515};\\\", \\\"{x:1613,y:976,t:1527271881532};\\\", \\\"{x:1613,y:972,t:1527271881549};\\\", \\\"{x:1613,y:969,t:1527271881565};\\\", \\\"{x:1612,y:969,t:1527271881582};\\\", \\\"{x:1612,y:967,t:1527271881777};\\\", \\\"{x:1612,y:966,t:1527271881785};\\\", \\\"{x:1612,y:965,t:1527271882720};\\\", \\\"{x:1614,y:964,t:1527271882736};\\\", \\\"{x:1616,y:964,t:1527271882752};\\\", \\\"{x:1597,y:964,t:1527271956750};\\\", \\\"{x:1559,y:957,t:1527271956763};\\\", \\\"{x:1491,y:928,t:1527271956780};\\\", \\\"{x:1418,y:904,t:1527271956796};\\\", \\\"{x:1350,y:883,t:1527271956813};\\\", \\\"{x:1313,y:870,t:1527271956829};\\\", \\\"{x:1297,y:864,t:1527271956846};\\\", \\\"{x:1292,y:860,t:1527271956863};\\\", \\\"{x:1291,y:859,t:1527271956879};\\\", \\\"{x:1285,y:855,t:1527271956896};\\\", \\\"{x:1268,y:849,t:1527271956914};\\\", \\\"{x:1234,y:837,t:1527271956930};\\\", \\\"{x:1164,y:828,t:1527271956946};\\\", \\\"{x:1108,y:820,t:1527271956963};\\\", \\\"{x:1085,y:814,t:1527271956980};\\\", \\\"{x:1076,y:812,t:1527271956996};\\\", \\\"{x:1045,y:800,t:1527271957013};\\\", \\\"{x:1001,y:796,t:1527271957031};\\\", \\\"{x:960,y:793,t:1527271957048};\\\", \\\"{x:904,y:785,t:1527271957063};\\\", \\\"{x:856,y:778,t:1527271957080};\\\", \\\"{x:824,y:772,t:1527271957097};\\\", \\\"{x:797,y:770,t:1527271957113};\\\", \\\"{x:775,y:766,t:1527271957131};\\\", \\\"{x:766,y:764,t:1527271957147};\\\", \\\"{x:765,y:763,t:1527271957158};\\\", \\\"{x:759,y:763,t:1527271957301};\\\", \\\"{x:743,y:761,t:1527271957310};\\\", \\\"{x:659,y:747,t:1527271957327};\\\", \\\"{x:544,y:736,t:1527271957343};\\\", \\\"{x:447,y:723,t:1527271957361};\\\", \\\"{x:406,y:716,t:1527271957377};\\\", \\\"{x:382,y:711,t:1527271957393};\\\", \\\"{x:365,y:707,t:1527271957410};\\\", \\\"{x:352,y:703,t:1527271957428};\\\", \\\"{x:350,y:703,t:1527271957443};\\\", \\\"{x:350,y:702,t:1527271957493};\\\", \\\"{x:350,y:701,t:1527271957500};\\\", \\\"{x:352,y:700,t:1527271957510};\\\", \\\"{x:362,y:699,t:1527271957527};\\\", \\\"{x:379,y:695,t:1527271957543};\\\", \\\"{x:391,y:695,t:1527271957561};\\\", \\\"{x:403,y:695,t:1527271957577};\\\", \\\"{x:413,y:698,t:1527271957594};\\\", \\\"{x:417,y:702,t:1527271957610};\\\", \\\"{x:419,y:704,t:1527271957628};\\\", \\\"{x:421,y:705,t:1527271957652};\\\", \\\"{x:424,y:706,t:1527271957669};\\\", \\\"{x:426,y:707,t:1527271957676};\\\", \\\"{x:430,y:709,t:1527271957694};\\\", \\\"{x:432,y:709,t:1527271957710};\\\", \\\"{x:434,y:709,t:1527271957728};\\\", \\\"{x:447,y:712,t:1527271957744};\\\", \\\"{x:463,y:714,t:1527271957760};\\\", \\\"{x:482,y:717,t:1527271957777};\\\", \\\"{x:488,y:718,t:1527271957794};\\\", \\\"{x:492,y:718,t:1527271957812};\\\", \\\"{x:496,y:719,t:1527271957827};\\\", \\\"{x:502,y:719,t:1527271957844};\\\", \\\"{x:504,y:719,t:1527271957861};\\\", \\\"{x:506,y:719,t:1527271957911};\\\", \\\"{x:506,y:719,t:1527271957974};\\\" ] }, { \\\"rt\\\": 283787, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 834119, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -10-F -11 AM-12 PM-01 PM-03 PM-H -I -08 AM-08 AM-X -I -03 PM-03 PM-02 PM-01 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:719,t:1527271959956};\\\", \\\"{x:517,y:715,t:1527271959965};\\\", \\\"{x:527,y:710,t:1527271959978};\\\", \\\"{x:538,y:704,t:1527271959994};\\\", \\\"{x:541,y:696,t:1527271960012};\\\", \\\"{x:542,y:675,t:1527271960029};\\\", \\\"{x:532,y:647,t:1527271960046};\\\", \\\"{x:510,y:606,t:1527271960063};\\\", \\\"{x:492,y:579,t:1527271960080};\\\", \\\"{x:472,y:548,t:1527271960095};\\\", \\\"{x:454,y:527,t:1527271960112};\\\", \\\"{x:432,y:509,t:1527271960129};\\\", \\\"{x:414,y:497,t:1527271960145};\\\", \\\"{x:403,y:489,t:1527271960162};\\\", \\\"{x:400,y:487,t:1527271960179};\\\", \\\"{x:399,y:485,t:1527271960205};\\\", \\\"{x:398,y:485,t:1527271960212};\\\", \\\"{x:393,y:480,t:1527271960229};\\\", \\\"{x:381,y:472,t:1527271960247};\\\", \\\"{x:377,y:467,t:1527271960262};\\\", \\\"{x:377,y:465,t:1527271960280};\\\", \\\"{x:377,y:463,t:1527271960296};\\\", \\\"{x:376,y:462,t:1527271960317};\\\", \\\"{x:375,y:462,t:1527271960341};\\\", \\\"{x:374,y:462,t:1527271960349};\\\", \\\"{x:373,y:462,t:1527271960405};\\\", \\\"{x:370,y:463,t:1527271960412};\\\", \\\"{x:360,y:463,t:1527271960430};\\\", \\\"{x:351,y:464,t:1527271960446};\\\", \\\"{x:348,y:464,t:1527271960463};\\\", \\\"{x:347,y:464,t:1527271960479};\\\", \\\"{x:345,y:464,t:1527271960597};\\\", \\\"{x:343,y:463,t:1527271960613};\\\", \\\"{x:342,y:463,t:1527271960630};\\\", \\\"{x:341,y:463,t:1527271960701};\\\", \\\"{x:338,y:462,t:1527271960713};\\\", \\\"{x:334,y:461,t:1527271960730};\\\", \\\"{x:333,y:460,t:1527271960746};\\\", \\\"{x:332,y:460,t:1527271960773};\\\", \\\"{x:331,y:459,t:1527271960780};\\\", \\\"{x:330,y:459,t:1527271960804};\\\", \\\"{x:330,y:458,t:1527271960893};\\\", \\\"{x:329,y:458,t:1527271960900};\\\", \\\"{x:332,y:458,t:1527271961141};\\\", \\\"{x:340,y:458,t:1527271961149};\\\", \\\"{x:346,y:458,t:1527271961164};\\\", \\\"{x:365,y:458,t:1527271961180};\\\", \\\"{x:381,y:460,t:1527271961196};\\\", \\\"{x:400,y:461,t:1527271961213};\\\", \\\"{x:424,y:466,t:1527271961231};\\\", \\\"{x:447,y:467,t:1527271961246};\\\", \\\"{x:466,y:469,t:1527271961264};\\\", \\\"{x:482,y:471,t:1527271961280};\\\", \\\"{x:491,y:471,t:1527271961296};\\\", \\\"{x:497,y:471,t:1527271961313};\\\", \\\"{x:503,y:471,t:1527271961330};\\\", \\\"{x:506,y:471,t:1527271961346};\\\", \\\"{x:510,y:471,t:1527271961363};\\\", \\\"{x:523,y:472,t:1527271961381};\\\", \\\"{x:539,y:474,t:1527271961396};\\\", \\\"{x:563,y:476,t:1527271961414};\\\", \\\"{x:588,y:478,t:1527271961430};\\\", \\\"{x:603,y:478,t:1527271961446};\\\", \\\"{x:614,y:478,t:1527271961463};\\\", \\\"{x:621,y:478,t:1527271961480};\\\", \\\"{x:625,y:478,t:1527271961497};\\\", \\\"{x:630,y:478,t:1527271961514};\\\", \\\"{x:636,y:478,t:1527271961530};\\\", \\\"{x:641,y:478,t:1527271961548};\\\", \\\"{x:647,y:478,t:1527271961563};\\\", \\\"{x:648,y:478,t:1527271961581};\\\", \\\"{x:654,y:478,t:1527271961597};\\\", \\\"{x:660,y:478,t:1527271961614};\\\", \\\"{x:671,y:478,t:1527271961630};\\\", \\\"{x:680,y:479,t:1527271961648};\\\", \\\"{x:685,y:479,t:1527271961663};\\\", \\\"{x:687,y:479,t:1527271961680};\\\", \\\"{x:688,y:479,t:1527271961741};\\\", \\\"{x:688,y:479,t:1527271961773};\\\", \\\"{x:695,y:486,t:1527271965029};\\\", \\\"{x:717,y:511,t:1527271965037};\\\", \\\"{x:752,y:541,t:1527271965047};\\\", \\\"{x:855,y:610,t:1527271965065};\\\", \\\"{x:968,y:687,t:1527271965084};\\\", \\\"{x:1052,y:728,t:1527271965099};\\\", \\\"{x:1052,y:730,t:1527271965117};\\\", \\\"{x:1054,y:730,t:1527271965469};\\\", \\\"{x:1057,y:730,t:1527271965483};\\\", \\\"{x:1080,y:741,t:1527271965501};\\\", \\\"{x:1103,y:749,t:1527271965516};\\\", \\\"{x:1140,y:759,t:1527271965534};\\\", \\\"{x:1197,y:769,t:1527271965550};\\\", \\\"{x:1261,y:779,t:1527271965567};\\\", \\\"{x:1325,y:786,t:1527271965583};\\\", \\\"{x:1367,y:793,t:1527271965601};\\\", \\\"{x:1397,y:794,t:1527271965616};\\\", \\\"{x:1417,y:794,t:1527271965634};\\\", \\\"{x:1429,y:796,t:1527271965650};\\\", \\\"{x:1432,y:796,t:1527271965667};\\\", \\\"{x:1434,y:798,t:1527271966445};\\\", \\\"{x:1444,y:803,t:1527271966453};\\\", \\\"{x:1458,y:809,t:1527271966468};\\\", \\\"{x:1493,y:821,t:1527271966485};\\\", \\\"{x:1515,y:830,t:1527271966501};\\\", \\\"{x:1540,y:843,t:1527271966518};\\\", \\\"{x:1568,y:850,t:1527271966535};\\\", \\\"{x:1586,y:852,t:1527271966551};\\\", \\\"{x:1605,y:856,t:1527271966568};\\\", \\\"{x:1622,y:854,t:1527271966586};\\\", \\\"{x:1623,y:853,t:1527271966601};\\\", \\\"{x:1622,y:853,t:1527271966949};\\\", \\\"{x:1617,y:853,t:1527271966957};\\\", \\\"{x:1612,y:853,t:1527271966968};\\\", \\\"{x:1605,y:853,t:1527271966985};\\\", \\\"{x:1602,y:853,t:1527271967002};\\\", \\\"{x:1597,y:854,t:1527271967018};\\\", \\\"{x:1590,y:857,t:1527271967034};\\\", \\\"{x:1578,y:859,t:1527271967051};\\\", \\\"{x:1571,y:862,t:1527271967067};\\\", \\\"{x:1563,y:864,t:1527271967084};\\\", \\\"{x:1555,y:866,t:1527271967101};\\\", \\\"{x:1548,y:867,t:1527271967118};\\\", \\\"{x:1543,y:868,t:1527271967135};\\\", \\\"{x:1540,y:870,t:1527271967152};\\\", \\\"{x:1538,y:871,t:1527271967168};\\\", \\\"{x:1534,y:874,t:1527271967186};\\\", \\\"{x:1526,y:879,t:1527271967202};\\\", \\\"{x:1515,y:882,t:1527271967218};\\\", \\\"{x:1502,y:882,t:1527271967235};\\\", \\\"{x:1495,y:880,t:1527271967253};\\\", \\\"{x:1486,y:871,t:1527271967269};\\\", \\\"{x:1459,y:839,t:1527271967285};\\\", \\\"{x:1417,y:785,t:1527271967302};\\\", \\\"{x:1381,y:722,t:1527271967318};\\\", \\\"{x:1363,y:666,t:1527271967335};\\\", \\\"{x:1355,y:623,t:1527271967352};\\\", \\\"{x:1351,y:592,t:1527271967368};\\\", \\\"{x:1346,y:573,t:1527271967385};\\\", \\\"{x:1345,y:564,t:1527271967402};\\\", \\\"{x:1345,y:561,t:1527271967418};\\\", \\\"{x:1345,y:559,t:1527271967437};\\\", \\\"{x:1345,y:558,t:1527271967461};\\\", \\\"{x:1346,y:557,t:1527271967533};\\\", \\\"{x:1345,y:554,t:1527271967541};\\\", \\\"{x:1345,y:550,t:1527271967551};\\\", \\\"{x:1340,y:543,t:1527271967569};\\\", \\\"{x:1333,y:537,t:1527271967585};\\\", \\\"{x:1330,y:535,t:1527271967601};\\\", \\\"{x:1328,y:534,t:1527271967619};\\\", \\\"{x:1327,y:530,t:1527271967635};\\\", \\\"{x:1324,y:526,t:1527271967652};\\\", \\\"{x:1323,y:522,t:1527271967669};\\\", \\\"{x:1323,y:520,t:1527271967685};\\\", \\\"{x:1323,y:519,t:1527271967758};\\\", \\\"{x:1323,y:517,t:1527271967769};\\\", \\\"{x:1323,y:514,t:1527271967787};\\\", \\\"{x:1322,y:510,t:1527271967802};\\\", \\\"{x:1320,y:507,t:1527271967819};\\\", \\\"{x:1318,y:504,t:1527271967834};\\\", \\\"{x:1318,y:503,t:1527271967851};\\\", \\\"{x:1317,y:503,t:1527271967869};\\\", \\\"{x:1317,y:501,t:1527271968977};\\\", \\\"{x:1317,y:500,t:1527271969003};\\\", \\\"{x:1316,y:502,t:1527271971365};\\\", \\\"{x:1317,y:513,t:1527271971375};\\\", \\\"{x:1318,y:520,t:1527271971389};\\\", \\\"{x:1318,y:529,t:1527271971404};\\\", \\\"{x:1318,y:540,t:1527271971422};\\\", \\\"{x:1318,y:545,t:1527271971438};\\\", \\\"{x:1318,y:551,t:1527271971455};\\\", \\\"{x:1318,y:553,t:1527271971472};\\\", \\\"{x:1318,y:558,t:1527271971488};\\\", \\\"{x:1318,y:560,t:1527271971504};\\\", \\\"{x:1318,y:563,t:1527271971521};\\\", \\\"{x:1318,y:569,t:1527271971539};\\\", \\\"{x:1318,y:574,t:1527271971554};\\\", \\\"{x:1318,y:583,t:1527271971571};\\\", \\\"{x:1318,y:591,t:1527271971588};\\\", \\\"{x:1318,y:603,t:1527271971605};\\\", \\\"{x:1318,y:605,t:1527271971622};\\\", \\\"{x:1318,y:606,t:1527271971638};\\\", \\\"{x:1313,y:610,t:1527272141471};\\\", \\\"{x:1293,y:616,t:1527272141482};\\\", \\\"{x:1231,y:586,t:1527272141499};\\\", \\\"{x:1158,y:503,t:1527272141516};\\\", \\\"{x:1095,y:411,t:1527272141533};\\\", \\\"{x:1051,y:300,t:1527272141550};\\\", \\\"{x:1021,y:241,t:1527272141567};\\\", \\\"{x:977,y:189,t:1527272141582};\\\", \\\"{x:922,y:153,t:1527272141600};\\\", \\\"{x:857,y:130,t:1527272141616};\\\", \\\"{x:804,y:122,t:1527272141632};\\\", \\\"{x:788,y:122,t:1527272141649};\\\", \\\"{x:779,y:130,t:1527272141666};\\\", \\\"{x:771,y:151,t:1527272141682};\\\", \\\"{x:755,y:184,t:1527272141700};\\\", \\\"{x:729,y:216,t:1527272141716};\\\", \\\"{x:696,y:253,t:1527272141732};\\\", \\\"{x:671,y:292,t:1527272141750};\\\", \\\"{x:669,y:314,t:1527272141765};\\\", \\\"{x:669,y:345,t:1527272141783};\\\", \\\"{x:673,y:379,t:1527272141799};\\\", \\\"{x:677,y:418,t:1527272141817};\\\", \\\"{x:683,y:449,t:1527272141833};\\\", \\\"{x:692,y:483,t:1527272141849};\\\", \\\"{x:720,y:546,t:1527272141868};\\\", \\\"{x:726,y:563,t:1527272141884};\\\", \\\"{x:726,y:566,t:1527272142143};\\\", \\\"{x:719,y:574,t:1527272142156};\\\", \\\"{x:707,y:596,t:1527272142171};\\\", \\\"{x:697,y:618,t:1527272142187};\\\", \\\"{x:684,y:646,t:1527272142204};\\\", \\\"{x:677,y:669,t:1527272142220};\\\", \\\"{x:666,y:698,t:1527272142237};\\\", \\\"{x:657,y:712,t:1527272142253};\\\", \\\"{x:647,y:720,t:1527272142270};\\\", \\\"{x:636,y:724,t:1527272142287};\\\", \\\"{x:623,y:730,t:1527272142303};\\\", \\\"{x:617,y:734,t:1527272142320};\\\", \\\"{x:607,y:743,t:1527272142337};\\\", \\\"{x:595,y:754,t:1527272142353};\\\", \\\"{x:584,y:759,t:1527272142370};\\\", \\\"{x:563,y:764,t:1527272142387};\\\", \\\"{x:541,y:776,t:1527272142403};\\\", \\\"{x:514,y:787,t:1527272142420};\\\", \\\"{x:487,y:794,t:1527272142437};\\\", \\\"{x:461,y:794,t:1527272142453};\\\", \\\"{x:454,y:794,t:1527272142470};\\\", \\\"{x:452,y:794,t:1527272142487};\\\", \\\"{x:451,y:794,t:1527272142526};\\\", \\\"{x:451,y:793,t:1527272142537};\\\", \\\"{x:451,y:783,t:1527272142554};\\\", \\\"{x:447,y:769,t:1527272142571};\\\", \\\"{x:444,y:756,t:1527272142587};\\\", \\\"{x:444,y:752,t:1527272142604};\\\", \\\"{x:444,y:749,t:1527272142620};\\\", \\\"{x:444,y:748,t:1527272142636};\\\", \\\"{x:445,y:745,t:1527272142654};\\\", \\\"{x:449,y:743,t:1527272142671};\\\", \\\"{x:455,y:739,t:1527272142686};\\\", \\\"{x:462,y:736,t:1527272142703};\\\", \\\"{x:466,y:734,t:1527272142719};\\\", \\\"{x:469,y:732,t:1527272142737};\\\", \\\"{x:470,y:732,t:1527272142754};\\\", \\\"{x:471,y:731,t:1527272142770};\\\", \\\"{x:472,y:730,t:1527272142789};\\\", \\\"{x:474,y:730,t:1527272142806};\\\", \\\"{x:477,y:729,t:1527272142819};\\\", \\\"{x:486,y:725,t:1527272142836};\\\", \\\"{x:490,y:724,t:1527272142852};\\\", \\\"{x:493,y:721,t:1527272142869};\\\", \\\"{x:494,y:721,t:1527272142886};\\\", \\\"{x:494,y:719,t:1527272148958};\\\", \\\"{x:541,y:717,t:1527272148975};\\\", \\\"{x:663,y:717,t:1527272148992};\\\", \\\"{x:771,y:717,t:1527272149007};\\\", \\\"{x:909,y:717,t:1527272149024};\\\", \\\"{x:1081,y:717,t:1527272149042};\\\", \\\"{x:1247,y:719,t:1527272149059};\\\", \\\"{x:1382,y:719,t:1527272149076};\\\", \\\"{x:1494,y:718,t:1527272149092};\\\", \\\"{x:1581,y:711,t:1527272149109};\\\", \\\"{x:1594,y:709,t:1527272149126};\\\", \\\"{x:1594,y:714,t:1527272149238};\\\", \\\"{x:1593,y:722,t:1527272149246};\\\", \\\"{x:1590,y:729,t:1527272149259};\\\", \\\"{x:1581,y:748,t:1527272149276};\\\", \\\"{x:1567,y:772,t:1527272149293};\\\", \\\"{x:1544,y:805,t:1527272149309};\\\", \\\"{x:1534,y:818,t:1527272149327};\\\", \\\"{x:1532,y:824,t:1527272149343};\\\", \\\"{x:1528,y:829,t:1527272149360};\\\", \\\"{x:1525,y:833,t:1527272149377};\\\", \\\"{x:1521,y:833,t:1527272149394};\\\", \\\"{x:1519,y:833,t:1527272149410};\\\", \\\"{x:1518,y:833,t:1527272149427};\\\", \\\"{x:1516,y:833,t:1527272149710};\\\", \\\"{x:1511,y:835,t:1527272149726};\\\", \\\"{x:1507,y:837,t:1527272149743};\\\", \\\"{x:1503,y:839,t:1527272149761};\\\", \\\"{x:1499,y:841,t:1527272149776};\\\", \\\"{x:1493,y:843,t:1527272149793};\\\", \\\"{x:1490,y:845,t:1527272149810};\\\", \\\"{x:1485,y:848,t:1527272149826};\\\", \\\"{x:1482,y:849,t:1527272149843};\\\", \\\"{x:1477,y:852,t:1527272149860};\\\", \\\"{x:1474,y:853,t:1527272149876};\\\", \\\"{x:1473,y:853,t:1527272149893};\\\", \\\"{x:1472,y:853,t:1527272150055};\\\", \\\"{x:1471,y:853,t:1527272150062};\\\", \\\"{x:1470,y:853,t:1527272150077};\\\", \\\"{x:1468,y:851,t:1527272150094};\\\", \\\"{x:1464,y:847,t:1527272150110};\\\", \\\"{x:1453,y:841,t:1527272150127};\\\", \\\"{x:1443,y:833,t:1527272150144};\\\", \\\"{x:1436,y:828,t:1527272150161};\\\", \\\"{x:1433,y:826,t:1527272150178};\\\", \\\"{x:1431,y:825,t:1527272150194};\\\", \\\"{x:1427,y:822,t:1527272150211};\\\", \\\"{x:1422,y:819,t:1527272150228};\\\", \\\"{x:1415,y:815,t:1527272150243};\\\", \\\"{x:1409,y:810,t:1527272150261};\\\", \\\"{x:1397,y:804,t:1527272150277};\\\", \\\"{x:1390,y:799,t:1527272150294};\\\", \\\"{x:1386,y:796,t:1527272150311};\\\", \\\"{x:1381,y:792,t:1527272150328};\\\", \\\"{x:1375,y:787,t:1527272150343};\\\", \\\"{x:1365,y:779,t:1527272150361};\\\", \\\"{x:1358,y:774,t:1527272150377};\\\", \\\"{x:1354,y:771,t:1527272150393};\\\", \\\"{x:1354,y:770,t:1527272150438};\\\", \\\"{x:1354,y:767,t:1527272150526};\\\", \\\"{x:1355,y:766,t:1527272150534};\\\", \\\"{x:1356,y:766,t:1527272150543};\\\", \\\"{x:1360,y:764,t:1527272150561};\\\", \\\"{x:1361,y:764,t:1527272150578};\\\", \\\"{x:1362,y:764,t:1527272150600};\\\", \\\"{x:1365,y:764,t:1527272150613};\\\", \\\"{x:1367,y:764,t:1527272150628};\\\", \\\"{x:1375,y:765,t:1527272150645};\\\", \\\"{x:1381,y:768,t:1527272150662};\\\", \\\"{x:1391,y:772,t:1527272150679};\\\", \\\"{x:1393,y:773,t:1527272150694};\\\", \\\"{x:1394,y:773,t:1527272151022};\\\", \\\"{x:1393,y:776,t:1527272151030};\\\", \\\"{x:1392,y:781,t:1527272151045};\\\", \\\"{x:1383,y:791,t:1527272151062};\\\", \\\"{x:1378,y:798,t:1527272151077};\\\", \\\"{x:1370,y:807,t:1527272151095};\\\", \\\"{x:1367,y:812,t:1527272151112};\\\", \\\"{x:1363,y:816,t:1527272151128};\\\", \\\"{x:1358,y:820,t:1527272151145};\\\", \\\"{x:1353,y:823,t:1527272151162};\\\", \\\"{x:1350,y:824,t:1527272151178};\\\", \\\"{x:1346,y:827,t:1527272151195};\\\", \\\"{x:1343,y:829,t:1527272151212};\\\", \\\"{x:1340,y:831,t:1527272151228};\\\", \\\"{x:1339,y:831,t:1527272151245};\\\", \\\"{x:1338,y:831,t:1527272151262};\\\", \\\"{x:1336,y:831,t:1527272151278};\\\", \\\"{x:1334,y:832,t:1527272151294};\\\", \\\"{x:1331,y:832,t:1527272151312};\\\", \\\"{x:1329,y:832,t:1527272151328};\\\", \\\"{x:1325,y:834,t:1527272151345};\\\", \\\"{x:1321,y:835,t:1527272151362};\\\", \\\"{x:1314,y:837,t:1527272151379};\\\", \\\"{x:1309,y:839,t:1527272151394};\\\", \\\"{x:1304,y:840,t:1527272151412};\\\", \\\"{x:1300,y:841,t:1527272151429};\\\", \\\"{x:1296,y:843,t:1527272151444};\\\", \\\"{x:1294,y:843,t:1527272151461};\\\", \\\"{x:1293,y:843,t:1527272151478};\\\", \\\"{x:1292,y:843,t:1527272151518};\\\", \\\"{x:1291,y:843,t:1527272151558};\\\", \\\"{x:1290,y:842,t:1527272151566};\\\", \\\"{x:1288,y:842,t:1527272151579};\\\", \\\"{x:1282,y:838,t:1527272151595};\\\", \\\"{x:1273,y:835,t:1527272151611};\\\", \\\"{x:1267,y:832,t:1527272151629};\\\", \\\"{x:1266,y:831,t:1527272151644};\\\", \\\"{x:1265,y:831,t:1527272151662};\\\", \\\"{x:1264,y:831,t:1527272152006};\\\", \\\"{x:1264,y:833,t:1527272152014};\\\", \\\"{x:1267,y:836,t:1527272152029};\\\", \\\"{x:1272,y:843,t:1527272152045};\\\", \\\"{x:1275,y:846,t:1527272152061};\\\", \\\"{x:1276,y:849,t:1527272152079};\\\", \\\"{x:1279,y:857,t:1527272152096};\\\", \\\"{x:1280,y:863,t:1527272152112};\\\", \\\"{x:1283,y:872,t:1527272152129};\\\", \\\"{x:1283,y:881,t:1527272152146};\\\", \\\"{x:1283,y:887,t:1527272152162};\\\", \\\"{x:1283,y:893,t:1527272152179};\\\", \\\"{x:1283,y:901,t:1527272152196};\\\", \\\"{x:1284,y:909,t:1527272152212};\\\", \\\"{x:1284,y:914,t:1527272152228};\\\", \\\"{x:1287,y:921,t:1527272152245};\\\", \\\"{x:1290,y:929,t:1527272152262};\\\", \\\"{x:1292,y:933,t:1527272152279};\\\", \\\"{x:1294,y:937,t:1527272152295};\\\", \\\"{x:1295,y:937,t:1527272152312};\\\", \\\"{x:1295,y:938,t:1527272152373};\\\", \\\"{x:1295,y:940,t:1527272152381};\\\", \\\"{x:1295,y:941,t:1527272152395};\\\", \\\"{x:1295,y:946,t:1527272152413};\\\", \\\"{x:1295,y:948,t:1527272152428};\\\", \\\"{x:1295,y:950,t:1527272152445};\\\", \\\"{x:1294,y:951,t:1527272152478};\\\", \\\"{x:1294,y:954,t:1527272152496};\\\", \\\"{x:1293,y:959,t:1527272152513};\\\", \\\"{x:1289,y:965,t:1527272152529};\\\", \\\"{x:1288,y:967,t:1527272152546};\\\", \\\"{x:1287,y:969,t:1527272152563};\\\", \\\"{x:1290,y:969,t:1527272153014};\\\", \\\"{x:1297,y:969,t:1527272153030};\\\", \\\"{x:1305,y:969,t:1527272153046};\\\", \\\"{x:1316,y:969,t:1527272153063};\\\", \\\"{x:1329,y:969,t:1527272153081};\\\", \\\"{x:1338,y:969,t:1527272153097};\\\", \\\"{x:1348,y:969,t:1527272153112};\\\", \\\"{x:1356,y:969,t:1527272153129};\\\", \\\"{x:1360,y:969,t:1527272153147};\\\", \\\"{x:1363,y:969,t:1527272153162};\\\", \\\"{x:1366,y:969,t:1527272153180};\\\", \\\"{x:1369,y:969,t:1527272153197};\\\", \\\"{x:1374,y:969,t:1527272153213};\\\", \\\"{x:1382,y:969,t:1527272153230};\\\", \\\"{x:1387,y:969,t:1527272153247};\\\", \\\"{x:1391,y:969,t:1527272153263};\\\", \\\"{x:1394,y:969,t:1527272153280};\\\", \\\"{x:1400,y:969,t:1527272153297};\\\", \\\"{x:1407,y:969,t:1527272153312};\\\", \\\"{x:1415,y:969,t:1527272153330};\\\", \\\"{x:1423,y:969,t:1527272153346};\\\", \\\"{x:1428,y:969,t:1527272153363};\\\", \\\"{x:1432,y:969,t:1527272153380};\\\", \\\"{x:1435,y:968,t:1527272153397};\\\", \\\"{x:1436,y:968,t:1527272153422};\\\", \\\"{x:1437,y:968,t:1527272153470};\\\", \\\"{x:1438,y:968,t:1527272153485};\\\", \\\"{x:1441,y:967,t:1527272153501};\\\", \\\"{x:1442,y:966,t:1527272153514};\\\", \\\"{x:1444,y:966,t:1527272153530};\\\", \\\"{x:1448,y:966,t:1527272153548};\\\", \\\"{x:1452,y:965,t:1527272153564};\\\", \\\"{x:1453,y:965,t:1527272153580};\\\", \\\"{x:1454,y:964,t:1527272153598};\\\", \\\"{x:1455,y:964,t:1527272153614};\\\", \\\"{x:1456,y:963,t:1527272153630};\\\", \\\"{x:1458,y:963,t:1527272153647};\\\", \\\"{x:1460,y:962,t:1527272153664};\\\", \\\"{x:1461,y:962,t:1527272153680};\\\", \\\"{x:1463,y:962,t:1527272153750};\\\", \\\"{x:1464,y:962,t:1527272153773};\\\", \\\"{x:1466,y:962,t:1527272153790};\\\", \\\"{x:1468,y:962,t:1527272153799};\\\", \\\"{x:1473,y:962,t:1527272153813};\\\", \\\"{x:1478,y:964,t:1527272153831};\\\", \\\"{x:1490,y:967,t:1527272153847};\\\", \\\"{x:1504,y:970,t:1527272153864};\\\", \\\"{x:1524,y:975,t:1527272153881};\\\", \\\"{x:1545,y:980,t:1527272153897};\\\", \\\"{x:1563,y:983,t:1527272153914};\\\", \\\"{x:1581,y:985,t:1527272153931};\\\", \\\"{x:1602,y:989,t:1527272153947};\\\", \\\"{x:1621,y:994,t:1527272153964};\\\", \\\"{x:1640,y:997,t:1527272153981};\\\", \\\"{x:1658,y:1000,t:1527272153998};\\\", \\\"{x:1663,y:1001,t:1527272154013};\\\", \\\"{x:1666,y:1001,t:1527272154031};\\\", \\\"{x:1668,y:1002,t:1527272154047};\\\", \\\"{x:1670,y:1002,t:1527272154063};\\\", \\\"{x:1671,y:1002,t:1527272154081};\\\", \\\"{x:1672,y:1002,t:1527272154158};\\\", \\\"{x:1672,y:1001,t:1527272154165};\\\", \\\"{x:1672,y:999,t:1527272154181};\\\", \\\"{x:1665,y:989,t:1527272154197};\\\", \\\"{x:1622,y:934,t:1527272154213};\\\", \\\"{x:1583,y:889,t:1527272154230};\\\", \\\"{x:1567,y:867,t:1527272154247};\\\", \\\"{x:1556,y:848,t:1527272154264};\\\", \\\"{x:1541,y:825,t:1527272154281};\\\", \\\"{x:1522,y:801,t:1527272154298};\\\", \\\"{x:1493,y:768,t:1527272154314};\\\", \\\"{x:1478,y:747,t:1527272154331};\\\", \\\"{x:1472,y:733,t:1527272154348};\\\", \\\"{x:1470,y:722,t:1527272154364};\\\", \\\"{x:1466,y:710,t:1527272154381};\\\", \\\"{x:1458,y:687,t:1527272154399};\\\", \\\"{x:1451,y:664,t:1527272154414};\\\", \\\"{x:1442,y:629,t:1527272154431};\\\", \\\"{x:1436,y:604,t:1527272154448};\\\", \\\"{x:1433,y:589,t:1527272154464};\\\", \\\"{x:1431,y:576,t:1527272154481};\\\", \\\"{x:1424,y:564,t:1527272154497};\\\", \\\"{x:1418,y:551,t:1527272154514};\\\", \\\"{x:1413,y:546,t:1527272154531};\\\", \\\"{x:1410,y:540,t:1527272154548};\\\", \\\"{x:1406,y:534,t:1527272154564};\\\", \\\"{x:1395,y:521,t:1527272154580};\\\", \\\"{x:1368,y:493,t:1527272154599};\\\", \\\"{x:1358,y:481,t:1527272154615};\\\", \\\"{x:1355,y:477,t:1527272154631};\\\", \\\"{x:1353,y:474,t:1527272154648};\\\", \\\"{x:1352,y:472,t:1527272154665};\\\", \\\"{x:1349,y:467,t:1527272154681};\\\", \\\"{x:1345,y:459,t:1527272154698};\\\", \\\"{x:1344,y:447,t:1527272154715};\\\", \\\"{x:1342,y:435,t:1527272154731};\\\", \\\"{x:1342,y:426,t:1527272154747};\\\", \\\"{x:1342,y:415,t:1527272154765};\\\", \\\"{x:1342,y:412,t:1527272154781};\\\", \\\"{x:1341,y:415,t:1527272154829};\\\", \\\"{x:1335,y:443,t:1527272154848};\\\", \\\"{x:1311,y:498,t:1527272154865};\\\", \\\"{x:1281,y:547,t:1527272154882};\\\", \\\"{x:1241,y:604,t:1527272154898};\\\", \\\"{x:1192,y:661,t:1527272154915};\\\", \\\"{x:1147,y:721,t:1527272154931};\\\", \\\"{x:1094,y:779,t:1527272154948};\\\", \\\"{x:1061,y:815,t:1527272154965};\\\", \\\"{x:1042,y:837,t:1527272154981};\\\", \\\"{x:1034,y:849,t:1527272154998};\\\", \\\"{x:1033,y:852,t:1527272155015};\\\", \\\"{x:1032,y:857,t:1527272155031};\\\", \\\"{x:1032,y:859,t:1527272155048};\\\", \\\"{x:1032,y:862,t:1527272155065};\\\", \\\"{x:1032,y:867,t:1527272155082};\\\", \\\"{x:1032,y:875,t:1527272155098};\\\", \\\"{x:1032,y:887,t:1527272155115};\\\", \\\"{x:1035,y:911,t:1527272155132};\\\", \\\"{x:1044,y:938,t:1527272155148};\\\", \\\"{x:1050,y:957,t:1527272155165};\\\", \\\"{x:1057,y:974,t:1527272155181};\\\", \\\"{x:1060,y:979,t:1527272155199};\\\", \\\"{x:1063,y:984,t:1527272155214};\\\", \\\"{x:1064,y:987,t:1527272155231};\\\", \\\"{x:1065,y:995,t:1527272155248};\\\", \\\"{x:1065,y:998,t:1527272155264};\\\", \\\"{x:1065,y:999,t:1527272155285};\\\", \\\"{x:1063,y:1000,t:1527272155422};\\\", \\\"{x:1062,y:1002,t:1527272155432};\\\", \\\"{x:1058,y:1005,t:1527272155449};\\\", \\\"{x:1055,y:1008,t:1527272155465};\\\", \\\"{x:1054,y:1009,t:1527272155482};\\\", \\\"{x:1054,y:1011,t:1527272155499};\\\", \\\"{x:1053,y:1011,t:1527272155515};\\\", \\\"{x:1055,y:1010,t:1527272155710};\\\", \\\"{x:1056,y:1009,t:1527272155725};\\\", \\\"{x:1057,y:1007,t:1527272155741};\\\", \\\"{x:1058,y:1006,t:1527272155749};\\\", \\\"{x:1059,y:1005,t:1527272155765};\\\", \\\"{x:1063,y:1000,t:1527272155781};\\\", \\\"{x:1065,y:998,t:1527272155799};\\\", \\\"{x:1068,y:994,t:1527272155815};\\\", \\\"{x:1071,y:990,t:1527272155832};\\\", \\\"{x:1077,y:983,t:1527272155850};\\\", \\\"{x:1087,y:973,t:1527272155866};\\\", \\\"{x:1094,y:966,t:1527272155882};\\\", \\\"{x:1102,y:958,t:1527272155899};\\\", \\\"{x:1108,y:951,t:1527272155916};\\\", \\\"{x:1113,y:944,t:1527272155932};\\\", \\\"{x:1117,y:939,t:1527272155949};\\\", \\\"{x:1122,y:934,t:1527272155966};\\\", \\\"{x:1125,y:932,t:1527272155982};\\\", \\\"{x:1127,y:930,t:1527272155999};\\\", \\\"{x:1129,y:927,t:1527272156016};\\\", \\\"{x:1133,y:922,t:1527272156032};\\\", \\\"{x:1138,y:914,t:1527272156049};\\\", \\\"{x:1142,y:907,t:1527272156066};\\\", \\\"{x:1146,y:901,t:1527272156081};\\\", \\\"{x:1151,y:889,t:1527272156099};\\\", \\\"{x:1156,y:878,t:1527272156116};\\\", \\\"{x:1164,y:863,t:1527272156132};\\\", \\\"{x:1181,y:839,t:1527272156150};\\\", \\\"{x:1189,y:826,t:1527272156165};\\\", \\\"{x:1196,y:813,t:1527272156182};\\\", \\\"{x:1206,y:795,t:1527272156201};\\\", \\\"{x:1212,y:777,t:1527272156216};\\\", \\\"{x:1221,y:755,t:1527272156232};\\\", \\\"{x:1230,y:727,t:1527272156249};\\\", \\\"{x:1239,y:703,t:1527272156265};\\\", \\\"{x:1252,y:671,t:1527272156283};\\\", \\\"{x:1266,y:637,t:1527272156298};\\\", \\\"{x:1277,y:614,t:1527272156316};\\\", \\\"{x:1295,y:573,t:1527272156333};\\\", \\\"{x:1306,y:550,t:1527272156349};\\\", \\\"{x:1316,y:527,t:1527272156365};\\\", \\\"{x:1325,y:506,t:1527272156383};\\\", \\\"{x:1336,y:487,t:1527272156399};\\\", \\\"{x:1353,y:462,t:1527272156416};\\\", \\\"{x:1376,y:435,t:1527272156433};\\\", \\\"{x:1408,y:393,t:1527272156449};\\\", \\\"{x:1408,y:391,t:1527272156466};\\\", \\\"{x:1410,y:387,t:1527272156974};\\\", \\\"{x:1412,y:378,t:1527272156983};\\\", \\\"{x:1413,y:369,t:1527272157000};\\\", \\\"{x:1415,y:360,t:1527272157016};\\\", \\\"{x:1419,y:348,t:1527272157033};\\\", \\\"{x:1419,y:337,t:1527272157050};\\\", \\\"{x:1419,y:323,t:1527272157066};\\\", \\\"{x:1420,y:307,t:1527272157083};\\\", \\\"{x:1423,y:294,t:1527272157100};\\\", \\\"{x:1424,y:285,t:1527272157117};\\\", \\\"{x:1427,y:277,t:1527272157133};\\\", \\\"{x:1429,y:271,t:1527272157149};\\\", \\\"{x:1431,y:263,t:1527272157168};\\\", \\\"{x:1432,y:256,t:1527272157183};\\\", \\\"{x:1433,y:247,t:1527272157200};\\\", \\\"{x:1438,y:237,t:1527272157216};\\\", \\\"{x:1446,y:226,t:1527272157232};\\\", \\\"{x:1452,y:217,t:1527272157249};\\\", \\\"{x:1458,y:210,t:1527272157266};\\\", \\\"{x:1465,y:200,t:1527272157282};\\\", \\\"{x:1466,y:194,t:1527272157299};\\\", \\\"{x:1469,y:187,t:1527272157316};\\\", \\\"{x:1474,y:180,t:1527272157333};\\\", \\\"{x:1479,y:171,t:1527272157350};\\\", \\\"{x:1483,y:165,t:1527272157367};\\\", \\\"{x:1487,y:158,t:1527272157383};\\\", \\\"{x:1489,y:155,t:1527272157400};\\\", \\\"{x:1489,y:153,t:1527272157416};\\\", \\\"{x:1489,y:151,t:1527272157433};\\\", \\\"{x:1489,y:150,t:1527272157450};\\\", \\\"{x:1489,y:149,t:1527272157467};\\\", \\\"{x:1489,y:150,t:1527272157742};\\\", \\\"{x:1489,y:151,t:1527272157750};\\\", \\\"{x:1489,y:152,t:1527272157767};\\\", \\\"{x:1489,y:155,t:1527272157784};\\\", \\\"{x:1488,y:158,t:1527272157800};\\\", \\\"{x:1488,y:159,t:1527272157821};\\\", \\\"{x:1484,y:138,t:1527272187750};\\\", \\\"{x:1473,y:102,t:1527272187760};\\\", \\\"{x:1444,y:18,t:1527272187776};\\\", \\\"{x:1415,y:0,t:1527272187794};\\\", \\\"{x:1375,y:0,t:1527272187810};\\\", \\\"{x:1342,y:0,t:1527272187826};\\\", \\\"{x:1312,y:0,t:1527272187843};\\\", \\\"{x:1292,y:0,t:1527272187860};\\\", \\\"{x:1279,y:0,t:1527272187876};\\\", \\\"{x:1251,y:0,t:1527272187893};\\\", \\\"{x:1237,y:0,t:1527272187910};\\\", \\\"{x:1232,y:0,t:1527272187926};\\\", \\\"{x:1230,y:0,t:1527272187943};\\\", \\\"{x:1229,y:0,t:1527272187989};\\\", \\\"{x:1229,y:9,t:1527272187999};\\\", \\\"{x:1231,y:30,t:1527272188009};\\\", \\\"{x:1235,y:56,t:1527272188026};\\\", \\\"{x:1236,y:87,t:1527272188043};\\\", \\\"{x:1240,y:117,t:1527272188060};\\\", \\\"{x:1248,y:142,t:1527272188077};\\\", \\\"{x:1295,y:199,t:1527272188093};\\\", \\\"{x:1348,y:234,t:1527272188111};\\\", \\\"{x:1399,y:263,t:1527272188127};\\\", \\\"{x:1448,y:282,t:1527272188143};\\\", \\\"{x:1495,y:294,t:1527272188160};\\\", \\\"{x:1548,y:314,t:1527272188177};\\\", \\\"{x:1580,y:334,t:1527272188193};\\\", \\\"{x:1599,y:347,t:1527272188210};\\\", \\\"{x:1605,y:362,t:1527272188227};\\\", \\\"{x:1605,y:381,t:1527272188243};\\\", \\\"{x:1602,y:404,t:1527272188260};\\\", \\\"{x:1597,y:444,t:1527272188277};\\\", \\\"{x:1597,y:468,t:1527272188293};\\\", \\\"{x:1596,y:486,t:1527272188310};\\\", \\\"{x:1592,y:498,t:1527272188327};\\\", \\\"{x:1581,y:511,t:1527272188343};\\\", \\\"{x:1563,y:518,t:1527272188360};\\\", \\\"{x:1545,y:524,t:1527272188377};\\\", \\\"{x:1532,y:525,t:1527272188393};\\\", \\\"{x:1526,y:525,t:1527272188410};\\\", \\\"{x:1521,y:525,t:1527272188427};\\\", \\\"{x:1508,y:526,t:1527272188443};\\\", \\\"{x:1480,y:526,t:1527272188460};\\\", \\\"{x:1421,y:529,t:1527272188477};\\\", \\\"{x:1389,y:529,t:1527272188494};\\\", \\\"{x:1363,y:529,t:1527272188510};\\\", \\\"{x:1342,y:529,t:1527272188527};\\\", \\\"{x:1321,y:526,t:1527272188544};\\\", \\\"{x:1306,y:521,t:1527272188560};\\\", \\\"{x:1292,y:518,t:1527272188577};\\\", \\\"{x:1285,y:517,t:1527272188594};\\\", \\\"{x:1284,y:517,t:1527272188610};\\\", \\\"{x:1287,y:515,t:1527272188862};\\\", \\\"{x:1288,y:514,t:1527272188877};\\\", \\\"{x:1289,y:514,t:1527272188894};\\\", \\\"{x:1292,y:513,t:1527272188910};\\\", \\\"{x:1298,y:511,t:1527272188927};\\\", \\\"{x:1311,y:509,t:1527272188944};\\\", \\\"{x:1324,y:506,t:1527272188960};\\\", \\\"{x:1330,y:506,t:1527272188977};\\\", \\\"{x:1332,y:505,t:1527272188994};\\\", \\\"{x:1332,y:504,t:1527272189086};\\\", \\\"{x:1331,y:504,t:1527272189245};\\\", \\\"{x:1329,y:503,t:1527272189262};\\\", \\\"{x:1327,y:502,t:1527272189277};\\\", \\\"{x:1325,y:502,t:1527272189294};\\\", \\\"{x:1323,y:502,t:1527272189311};\\\", \\\"{x:1321,y:502,t:1527272189328};\\\", \\\"{x:1319,y:502,t:1527272189345};\\\", \\\"{x:1316,y:502,t:1527272189441};\\\", \\\"{x:1311,y:502,t:1527272189465};\\\", \\\"{x:1309,y:503,t:1527272189482};\\\", \\\"{x:1308,y:504,t:1527272189498};\\\", \\\"{x:1308,y:507,t:1527272189929};\\\", \\\"{x:1308,y:513,t:1527272189936};\\\", \\\"{x:1310,y:519,t:1527272189949};\\\", \\\"{x:1315,y:534,t:1527272189965};\\\", \\\"{x:1326,y:552,t:1527272189982};\\\", \\\"{x:1344,y:578,t:1527272189999};\\\", \\\"{x:1365,y:603,t:1527272190015};\\\", \\\"{x:1383,y:622,t:1527272190032};\\\", \\\"{x:1406,y:648,t:1527272190049};\\\", \\\"{x:1417,y:664,t:1527272190065};\\\", \\\"{x:1430,y:676,t:1527272190082};\\\", \\\"{x:1442,y:684,t:1527272190100};\\\", \\\"{x:1450,y:691,t:1527272190115};\\\", \\\"{x:1457,y:701,t:1527272190132};\\\", \\\"{x:1461,y:707,t:1527272190149};\\\", \\\"{x:1461,y:709,t:1527272190177};\\\", \\\"{x:1462,y:709,t:1527272190193};\\\", \\\"{x:1462,y:713,t:1527272190208};\\\", \\\"{x:1463,y:719,t:1527272190216};\\\", \\\"{x:1465,y:727,t:1527272190233};\\\", \\\"{x:1466,y:744,t:1527272190248};\\\", \\\"{x:1466,y:750,t:1527272190266};\\\", \\\"{x:1467,y:752,t:1527272190282};\\\", \\\"{x:1467,y:756,t:1527272190299};\\\", \\\"{x:1472,y:766,t:1527272190316};\\\", \\\"{x:1477,y:782,t:1527272190333};\\\", \\\"{x:1482,y:800,t:1527272190349};\\\", \\\"{x:1488,y:814,t:1527272190366};\\\", \\\"{x:1490,y:818,t:1527272190382};\\\", \\\"{x:1492,y:823,t:1527272190399};\\\", \\\"{x:1495,y:828,t:1527272190416};\\\", \\\"{x:1498,y:834,t:1527272190432};\\\", \\\"{x:1503,y:845,t:1527272190449};\\\", \\\"{x:1506,y:852,t:1527272190466};\\\", \\\"{x:1507,y:856,t:1527272190482};\\\", \\\"{x:1507,y:859,t:1527272190499};\\\", \\\"{x:1508,y:862,t:1527272190516};\\\", \\\"{x:1509,y:866,t:1527272190533};\\\", \\\"{x:1510,y:870,t:1527272190549};\\\", \\\"{x:1514,y:879,t:1527272190566};\\\", \\\"{x:1515,y:889,t:1527272190583};\\\", \\\"{x:1518,y:898,t:1527272190599};\\\", \\\"{x:1520,y:904,t:1527272190616};\\\", \\\"{x:1520,y:909,t:1527272190633};\\\", \\\"{x:1522,y:913,t:1527272190649};\\\", \\\"{x:1523,y:916,t:1527272190666};\\\", \\\"{x:1524,y:922,t:1527272190683};\\\", \\\"{x:1527,y:928,t:1527272190699};\\\", \\\"{x:1530,y:936,t:1527272190716};\\\", \\\"{x:1532,y:941,t:1527272190733};\\\", \\\"{x:1534,y:945,t:1527272190749};\\\", \\\"{x:1535,y:946,t:1527272190766};\\\", \\\"{x:1535,y:948,t:1527272190783};\\\", \\\"{x:1537,y:951,t:1527272190799};\\\", \\\"{x:1541,y:958,t:1527272190816};\\\", \\\"{x:1548,y:967,t:1527272190833};\\\", \\\"{x:1550,y:970,t:1527272190855};\\\", \\\"{x:1551,y:971,t:1527272190865};\\\", \\\"{x:1551,y:970,t:1527272191482};\\\", \\\"{x:1551,y:968,t:1527272191490};\\\", \\\"{x:1551,y:967,t:1527272191504};\\\", \\\"{x:1551,y:965,t:1527272192105};\\\", \\\"{x:1551,y:964,t:1527272192129};\\\", \\\"{x:1550,y:963,t:1527272192161};\\\", \\\"{x:1548,y:959,t:1527272224009};\\\", \\\"{x:1535,y:941,t:1527272224016};\\\", \\\"{x:1526,y:927,t:1527272224028};\\\", \\\"{x:1501,y:898,t:1527272224045};\\\", \\\"{x:1464,y:864,t:1527272224060};\\\", \\\"{x:1444,y:845,t:1527272224078};\\\", \\\"{x:1435,y:837,t:1527272224095};\\\", \\\"{x:1433,y:834,t:1527272224110};\\\", \\\"{x:1432,y:834,t:1527272224128};\\\", \\\"{x:1431,y:833,t:1527272224145};\\\", \\\"{x:1429,y:830,t:1527272224161};\\\", \\\"{x:1426,y:827,t:1527272224177};\\\", \\\"{x:1424,y:824,t:1527272224195};\\\", \\\"{x:1423,y:823,t:1527272224215};\\\", \\\"{x:1426,y:823,t:1527272224464};\\\", \\\"{x:1428,y:826,t:1527272224478};\\\", \\\"{x:1430,y:826,t:1527272224495};\\\", \\\"{x:1431,y:827,t:1527272224512};\\\", \\\"{x:1433,y:828,t:1527272224528};\\\", \\\"{x:1434,y:828,t:1527272224545};\\\", \\\"{x:1434,y:829,t:1527272224568};\\\", \\\"{x:1435,y:830,t:1527272224579};\\\", \\\"{x:1439,y:834,t:1527272224595};\\\", \\\"{x:1442,y:836,t:1527272224612};\\\", \\\"{x:1444,y:837,t:1527272224628};\\\", \\\"{x:1447,y:838,t:1527272224645};\\\", \\\"{x:1450,y:841,t:1527272224662};\\\", \\\"{x:1455,y:842,t:1527272224678};\\\", \\\"{x:1459,y:844,t:1527272224695};\\\", \\\"{x:1465,y:845,t:1527272224712};\\\", \\\"{x:1466,y:845,t:1527272224728};\\\", \\\"{x:1467,y:845,t:1527272224760};\\\", \\\"{x:1468,y:845,t:1527272224768};\\\", \\\"{x:1469,y:844,t:1527272224778};\\\", \\\"{x:1473,y:843,t:1527272224795};\\\", \\\"{x:1474,y:842,t:1527272224811};\\\", \\\"{x:1475,y:842,t:1527272224828};\\\", \\\"{x:1476,y:842,t:1527272224848};\\\", \\\"{x:1476,y:841,t:1527272224862};\\\", \\\"{x:1480,y:841,t:1527272224879};\\\", \\\"{x:1482,y:841,t:1527272224894};\\\", \\\"{x:1483,y:841,t:1527272225160};\\\", \\\"{x:1484,y:840,t:1527272225176};\\\", \\\"{x:1484,y:839,t:1527272225249};\\\", \\\"{x:1484,y:838,t:1527272225262};\\\", \\\"{x:1484,y:841,t:1527272226073};\\\", \\\"{x:1485,y:846,t:1527272226080};\\\", \\\"{x:1487,y:859,t:1527272226096};\\\", \\\"{x:1493,y:872,t:1527272226114};\\\", \\\"{x:1499,y:888,t:1527272226130};\\\", \\\"{x:1506,y:903,t:1527272226146};\\\", \\\"{x:1508,y:906,t:1527272226163};\\\", \\\"{x:1508,y:909,t:1527272226180};\\\", \\\"{x:1509,y:910,t:1527272226196};\\\", \\\"{x:1510,y:912,t:1527272226213};\\\", \\\"{x:1512,y:915,t:1527272226230};\\\", \\\"{x:1515,y:923,t:1527272226246};\\\", \\\"{x:1518,y:930,t:1527272226264};\\\", \\\"{x:1522,y:938,t:1527272226280};\\\", \\\"{x:1523,y:940,t:1527272226296};\\\", \\\"{x:1524,y:942,t:1527272226313};\\\", \\\"{x:1527,y:946,t:1527272226330};\\\", \\\"{x:1527,y:947,t:1527272226346};\\\", \\\"{x:1529,y:950,t:1527272226364};\\\", \\\"{x:1530,y:952,t:1527272226408};\\\", \\\"{x:1532,y:953,t:1527272226416};\\\", \\\"{x:1533,y:954,t:1527272226430};\\\", \\\"{x:1537,y:959,t:1527272226447};\\\", \\\"{x:1538,y:960,t:1527272226464};\\\", \\\"{x:1539,y:960,t:1527272226488};\\\", \\\"{x:1540,y:960,t:1527272226512};\\\", \\\"{x:1540,y:961,t:1527272226531};\\\", \\\"{x:1541,y:962,t:1527272226547};\\\", \\\"{x:1541,y:964,t:1527272226928};\\\", \\\"{x:1541,y:965,t:1527272226936};\\\", \\\"{x:1541,y:967,t:1527272226952};\\\", \\\"{x:1541,y:968,t:1527272226983};\\\", \\\"{x:1541,y:969,t:1527272227000};\\\", \\\"{x:1541,y:970,t:1527272227014};\\\", \\\"{x:1541,y:972,t:1527272227030};\\\", \\\"{x:1531,y:975,t:1527272227047};\\\", \\\"{x:1495,y:981,t:1527272227064};\\\", \\\"{x:1458,y:982,t:1527272227081};\\\", \\\"{x:1413,y:983,t:1527272227098};\\\", \\\"{x:1351,y:983,t:1527272227115};\\\", \\\"{x:1295,y:983,t:1527272227130};\\\", \\\"{x:1230,y:959,t:1527272227148};\\\", \\\"{x:1128,y:917,t:1527272227164};\\\", \\\"{x:1019,y:858,t:1527272227180};\\\", \\\"{x:926,y:822,t:1527272227197};\\\", \\\"{x:843,y:798,t:1527272227214};\\\", \\\"{x:764,y:767,t:1527272227231};\\\", \\\"{x:664,y:716,t:1527272227248};\\\", \\\"{x:619,y:682,t:1527272227264};\\\", \\\"{x:603,y:666,t:1527272227281};\\\", \\\"{x:602,y:664,t:1527272227298};\\\", \\\"{x:602,y:662,t:1527272227314};\\\", \\\"{x:601,y:662,t:1527272227330};\\\", \\\"{x:601,y:661,t:1527272227359};\\\", \\\"{x:601,y:660,t:1527272227375};\\\", \\\"{x:601,y:659,t:1527272227423};\\\", \\\"{x:599,y:661,t:1527272228448};\\\", \\\"{x:594,y:665,t:1527272228461};\\\", \\\"{x:583,y:670,t:1527272228477};\\\", \\\"{x:569,y:671,t:1527272228493};\\\", \\\"{x:549,y:671,t:1527272228510};\\\", \\\"{x:527,y:671,t:1527272228526};\\\", \\\"{x:499,y:671,t:1527272228543};\\\", \\\"{x:485,y:671,t:1527272228559};\\\", \\\"{x:476,y:668,t:1527272228577};\\\", \\\"{x:465,y:663,t:1527272228593};\\\", \\\"{x:454,y:658,t:1527272228610};\\\", \\\"{x:449,y:654,t:1527272228626};\\\", \\\"{x:449,y:652,t:1527272228643};\\\", \\\"{x:449,y:649,t:1527272228659};\\\", \\\"{x:452,y:643,t:1527272228676};\\\", \\\"{x:454,y:640,t:1527272228694};\\\", \\\"{x:455,y:638,t:1527272228709};\\\", \\\"{x:455,y:637,t:1527272228727};\\\", \\\"{x:458,y:635,t:1527272228744};\\\", \\\"{x:468,y:633,t:1527272228761};\\\", \\\"{x:488,y:641,t:1527272228778};\\\", \\\"{x:508,y:652,t:1527272228793};\\\", \\\"{x:518,y:660,t:1527272228809};\\\", \\\"{x:518,y:661,t:1527272228826};\\\", \\\"{x:514,y:662,t:1527272228843};\\\", \\\"{x:509,y:664,t:1527272228860};\\\", \\\"{x:502,y:662,t:1527272228877};\\\", \\\"{x:491,y:657,t:1527272228895};\\\", \\\"{x:468,y:648,t:1527272228910};\\\", \\\"{x:440,y:640,t:1527272228927};\\\", \\\"{x:401,y:625,t:1527272228944};\\\", \\\"{x:388,y:619,t:1527272228960};\\\", \\\"{x:385,y:617,t:1527272228977};\\\", \\\"{x:384,y:615,t:1527272229023};\\\", \\\"{x:382,y:613,t:1527272229039};\\\", \\\"{x:379,y:610,t:1527272229046};\\\", \\\"{x:372,y:606,t:1527272229059};\\\", \\\"{x:361,y:603,t:1527272229076};\\\", \\\"{x:337,y:601,t:1527272229094};\\\", \\\"{x:311,y:600,t:1527272229110};\\\", \\\"{x:279,y:596,t:1527272229127};\\\", \\\"{x:234,y:589,t:1527272229144};\\\", \\\"{x:204,y:582,t:1527272229160};\\\", \\\"{x:189,y:580,t:1527272229178};\\\", \\\"{x:183,y:580,t:1527272229194};\\\", \\\"{x:178,y:583,t:1527272229209};\\\", \\\"{x:177,y:583,t:1527272229297};\\\", \\\"{x:176,y:584,t:1527272229311};\\\", \\\"{x:171,y:588,t:1527272229327};\\\", \\\"{x:170,y:589,t:1527272229344};\\\", \\\"{x:170,y:591,t:1527272229361};\\\", \\\"{x:172,y:595,t:1527272229376};\\\", \\\"{x:181,y:601,t:1527272229395};\\\", \\\"{x:189,y:604,t:1527272229411};\\\", \\\"{x:194,y:604,t:1527272229427};\\\", \\\"{x:197,y:604,t:1527272229444};\\\", \\\"{x:202,y:603,t:1527272229461};\\\", \\\"{x:214,y:601,t:1527272229476};\\\", \\\"{x:236,y:601,t:1527272229494};\\\", \\\"{x:258,y:601,t:1527272229511};\\\", \\\"{x:273,y:601,t:1527272229528};\\\", \\\"{x:288,y:601,t:1527272229544};\\\", \\\"{x:308,y:598,t:1527272229561};\\\", \\\"{x:338,y:598,t:1527272229577};\\\", \\\"{x:361,y:598,t:1527272229594};\\\", \\\"{x:379,y:598,t:1527272229611};\\\", \\\"{x:385,y:595,t:1527272229627};\\\", \\\"{x:387,y:595,t:1527272229648};\\\", \\\"{x:389,y:594,t:1527272229671};\\\", \\\"{x:390,y:593,t:1527272229680};\\\", \\\"{x:392,y:593,t:1527272229694};\\\", \\\"{x:392,y:592,t:1527272229752};\\\", \\\"{x:393,y:592,t:1527272229761};\\\", \\\"{x:400,y:589,t:1527272229777};\\\", \\\"{x:424,y:588,t:1527272229795};\\\", \\\"{x:444,y:583,t:1527272229811};\\\", \\\"{x:465,y:580,t:1527272229827};\\\", \\\"{x:491,y:580,t:1527272229844};\\\", \\\"{x:523,y:580,t:1527272229861};\\\", \\\"{x:550,y:581,t:1527272229877};\\\", \\\"{x:580,y:585,t:1527272229894};\\\", \\\"{x:602,y:585,t:1527272229910};\\\", \\\"{x:608,y:584,t:1527272229927};\\\", \\\"{x:611,y:581,t:1527272229943};\\\", \\\"{x:612,y:581,t:1527272229961};\\\", \\\"{x:613,y:579,t:1527272229978};\\\", \\\"{x:605,y:577,t:1527272229994};\\\", \\\"{x:596,y:573,t:1527272230011};\\\", \\\"{x:595,y:573,t:1527272230028};\\\", \\\"{x:594,y:572,t:1527272230055};\\\", \\\"{x:595,y:572,t:1527272230063};\\\", \\\"{x:595,y:571,t:1527272230078};\\\", \\\"{x:596,y:570,t:1527272230094};\\\", \\\"{x:596,y:564,t:1527272230111};\\\", \\\"{x:596,y:567,t:1527272230184};\\\", \\\"{x:596,y:576,t:1527272230194};\\\", \\\"{x:594,y:598,t:1527272230212};\\\", \\\"{x:594,y:604,t:1527272230227};\\\", \\\"{x:594,y:605,t:1527272230245};\\\", \\\"{x:594,y:607,t:1527272230383};\\\", \\\"{x:593,y:609,t:1527272230776};\\\", \\\"{x:592,y:611,t:1527272230783};\\\", \\\"{x:591,y:617,t:1527272230795};\\\", \\\"{x:590,y:624,t:1527272230812};\\\", \\\"{x:585,y:637,t:1527272230829};\\\", \\\"{x:576,y:650,t:1527272230845};\\\", \\\"{x:571,y:661,t:1527272230861};\\\", \\\"{x:566,y:667,t:1527272230878};\\\", \\\"{x:563,y:671,t:1527272230895};\\\", \\\"{x:561,y:675,t:1527272230911};\\\", \\\"{x:556,y:690,t:1527272230928};\\\", \\\"{x:552,y:716,t:1527272230946};\\\", \\\"{x:551,y:732,t:1527272230962};\\\", \\\"{x:551,y:733,t:1527272230984};\\\", \\\"{x:552,y:732,t:1527272230995};\\\", \\\"{x:557,y:716,t:1527272231012};\\\", \\\"{x:564,y:703,t:1527272231030};\\\", \\\"{x:577,y:690,t:1527272231044};\\\", \\\"{x:592,y:677,t:1527272231062};\\\", \\\"{x:607,y:667,t:1527272231079};\\\", \\\"{x:612,y:664,t:1527272231095};\\\", \\\"{x:613,y:664,t:1527272231119};\\\", \\\"{x:616,y:661,t:1527272231128};\\\", \\\"{x:624,y:650,t:1527272231145};\\\", \\\"{x:630,y:642,t:1527272231161};\\\", \\\"{x:634,y:639,t:1527272231179};\\\", \\\"{x:635,y:637,t:1527272231195};\\\", \\\"{x:635,y:632,t:1527272231213};\\\", \\\"{x:633,y:626,t:1527272231230};\\\", \\\"{x:628,y:616,t:1527272231245};\\\", \\\"{x:627,y:612,t:1527272231261};\\\", \\\"{x:623,y:608,t:1527272231278};\\\", \\\"{x:621,y:607,t:1527272231294};\\\", \\\"{x:615,y:605,t:1527272231313};\\\", \\\"{x:614,y:605,t:1527272231344};\\\", \\\"{x:612,y:605,t:1527272231360};\\\", \\\"{x:610,y:605,t:1527272231368};\\\", \\\"{x:609,y:605,t:1527272231379};\\\", \\\"{x:608,y:605,t:1527272231615};\\\", \\\"{x:607,y:613,t:1527272231629};\\\", \\\"{x:600,y:643,t:1527272231647};\\\", \\\"{x:581,y:683,t:1527272231662};\\\", \\\"{x:549,y:742,t:1527272231679};\\\", \\\"{x:534,y:764,t:1527272231697};\\\", \\\"{x:526,y:772,t:1527272231712};\\\", \\\"{x:520,y:777,t:1527272231729};\\\", \\\"{x:518,y:778,t:1527272231745};\\\", \\\"{x:517,y:774,t:1527272231815};\\\", \\\"{x:517,y:766,t:1527272231829};\\\", \\\"{x:515,y:746,t:1527272231846};\\\", \\\"{x:515,y:741,t:1527272231862};\\\", \\\"{x:515,y:738,t:1527272231936};\\\", \\\"{x:515,y:733,t:1527272231947};\\\", \\\"{x:514,y:727,t:1527272231963};\\\" ] }, { \\\"rt\\\": 15688, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 851342, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:706,t:1527272244839};\\\", \\\"{x:535,y:648,t:1527272244866};\\\", \\\"{x:537,y:634,t:1527272244875};\\\", \\\"{x:539,y:622,t:1527272244889};\\\", \\\"{x:539,y:619,t:1527272244906};\\\", \\\"{x:548,y:618,t:1527272245983};\\\", \\\"{x:560,y:614,t:1527272245991};\\\", \\\"{x:578,y:610,t:1527272246005};\\\", \\\"{x:608,y:605,t:1527272246023};\\\", \\\"{x:656,y:602,t:1527272246039};\\\", \\\"{x:705,y:600,t:1527272246057};\\\", \\\"{x:793,y:607,t:1527272246074};\\\", \\\"{x:895,y:623,t:1527272246090};\\\", \\\"{x:984,y:634,t:1527272246108};\\\", \\\"{x:1036,y:647,t:1527272246123};\\\", \\\"{x:1074,y:655,t:1527272246141};\\\", \\\"{x:1099,y:663,t:1527272246157};\\\", \\\"{x:1127,y:671,t:1527272246173};\\\", \\\"{x:1172,y:683,t:1527272246190};\\\", \\\"{x:1225,y:702,t:1527272246207};\\\", \\\"{x:1234,y:707,t:1527272246224};\\\", \\\"{x:1234,y:708,t:1527272246240};\\\", \\\"{x:1235,y:708,t:1527272246511};\\\", \\\"{x:1237,y:708,t:1527272246524};\\\", \\\"{x:1250,y:707,t:1527272246542};\\\", \\\"{x:1269,y:706,t:1527272246558};\\\", \\\"{x:1285,y:706,t:1527272246575};\\\", \\\"{x:1303,y:702,t:1527272246592};\\\", \\\"{x:1318,y:701,t:1527272246608};\\\", \\\"{x:1329,y:700,t:1527272246625};\\\", \\\"{x:1338,y:700,t:1527272246642};\\\", \\\"{x:1345,y:700,t:1527272246660};\\\", \\\"{x:1349,y:700,t:1527272246674};\\\", \\\"{x:1351,y:700,t:1527272246691};\\\", \\\"{x:1352,y:696,t:1527272247415};\\\", \\\"{x:1352,y:693,t:1527272247426};\\\", \\\"{x:1351,y:682,t:1527272247444};\\\", \\\"{x:1341,y:652,t:1527272247460};\\\", \\\"{x:1314,y:608,t:1527272247476};\\\", \\\"{x:1275,y:568,t:1527272247493};\\\", \\\"{x:1231,y:539,t:1527272247510};\\\", \\\"{x:1183,y:515,t:1527272247526};\\\", \\\"{x:1156,y:509,t:1527272247543};\\\", \\\"{x:1124,y:508,t:1527272247559};\\\", \\\"{x:1100,y:508,t:1527272247576};\\\", \\\"{x:1053,y:508,t:1527272247593};\\\", \\\"{x:970,y:506,t:1527272247611};\\\", \\\"{x:891,y:502,t:1527272247628};\\\", \\\"{x:838,y:502,t:1527272247643};\\\", \\\"{x:809,y:502,t:1527272247658};\\\", \\\"{x:784,y:505,t:1527272247674};\\\", \\\"{x:761,y:509,t:1527272247691};\\\", \\\"{x:735,y:515,t:1527272247708};\\\", \\\"{x:711,y:530,t:1527272247726};\\\", \\\"{x:700,y:539,t:1527272247741};\\\", \\\"{x:697,y:545,t:1527272247758};\\\", \\\"{x:694,y:548,t:1527272247774};\\\", \\\"{x:693,y:548,t:1527272247815};\\\", \\\"{x:693,y:549,t:1527272248080};\\\", \\\"{x:691,y:549,t:1527272248092};\\\", \\\"{x:688,y:553,t:1527272248108};\\\", \\\"{x:688,y:556,t:1527272248127};\\\", \\\"{x:688,y:557,t:1527272248141};\\\", \\\"{x:688,y:559,t:1527272248159};\\\", \\\"{x:704,y:562,t:1527272248175};\\\", \\\"{x:723,y:564,t:1527272248193};\\\", \\\"{x:748,y:567,t:1527272248210};\\\", \\\"{x:781,y:573,t:1527272248226};\\\", \\\"{x:835,y:581,t:1527272248243};\\\", \\\"{x:883,y:583,t:1527272248259};\\\", \\\"{x:931,y:584,t:1527272248276};\\\", \\\"{x:976,y:584,t:1527272248294};\\\", \\\"{x:1018,y:584,t:1527272248309};\\\", \\\"{x:1044,y:584,t:1527272248326};\\\", \\\"{x:1072,y:584,t:1527272248343};\\\", \\\"{x:1076,y:584,t:1527272248359};\\\", \\\"{x:1080,y:584,t:1527272248376};\\\", \\\"{x:1079,y:584,t:1527272250644};\\\", \\\"{x:1077,y:584,t:1527272250652};\\\", \\\"{x:1075,y:584,t:1527272250664};\\\", \\\"{x:1069,y:587,t:1527272250680};\\\", \\\"{x:1058,y:591,t:1527272250697};\\\", \\\"{x:1045,y:595,t:1527272250713};\\\", \\\"{x:1029,y:599,t:1527272250729};\\\", \\\"{x:1015,y:602,t:1527272250746};\\\", \\\"{x:1007,y:603,t:1527272250763};\\\", \\\"{x:998,y:603,t:1527272250779};\\\", \\\"{x:983,y:603,t:1527272250796};\\\", \\\"{x:967,y:603,t:1527272250814};\\\", \\\"{x:950,y:604,t:1527272250830};\\\", \\\"{x:938,y:604,t:1527272250846};\\\", \\\"{x:929,y:604,t:1527272250865};\\\", \\\"{x:916,y:604,t:1527272250881};\\\", \\\"{x:881,y:607,t:1527272250898};\\\", \\\"{x:863,y:609,t:1527272250915};\\\", \\\"{x:847,y:609,t:1527272250932};\\\", \\\"{x:838,y:609,t:1527272250949};\\\", \\\"{x:825,y:610,t:1527272250965};\\\", \\\"{x:814,y:610,t:1527272250981};\\\", \\\"{x:805,y:610,t:1527272250998};\\\", \\\"{x:798,y:610,t:1527272251014};\\\", \\\"{x:796,y:610,t:1527272251031};\\\", \\\"{x:795,y:610,t:1527272251048};\\\", \\\"{x:794,y:610,t:1527272251064};\\\", \\\"{x:791,y:610,t:1527272251082};\\\", \\\"{x:777,y:610,t:1527272251098};\\\", \\\"{x:760,y:610,t:1527272251114};\\\", \\\"{x:745,y:610,t:1527272251131};\\\", \\\"{x:738,y:610,t:1527272251148};\\\", \\\"{x:734,y:610,t:1527272251165};\\\", \\\"{x:728,y:610,t:1527272251181};\\\", \\\"{x:721,y:610,t:1527272251199};\\\", \\\"{x:715,y:610,t:1527272251216};\\\", \\\"{x:707,y:610,t:1527272251231};\\\", \\\"{x:702,y:610,t:1527272251249};\\\", \\\"{x:695,y:610,t:1527272251266};\\\", \\\"{x:688,y:610,t:1527272251281};\\\", \\\"{x:663,y:610,t:1527272251299};\\\", \\\"{x:648,y:610,t:1527272251315};\\\", \\\"{x:642,y:610,t:1527272251333};\\\", \\\"{x:640,y:610,t:1527272251349};\\\", \\\"{x:639,y:610,t:1527272251365};\\\", \\\"{x:632,y:610,t:1527272251381};\\\", \\\"{x:622,y:606,t:1527272251399};\\\", \\\"{x:610,y:602,t:1527272251416};\\\", \\\"{x:603,y:599,t:1527272251431};\\\", \\\"{x:598,y:597,t:1527272251448};\\\", \\\"{x:592,y:595,t:1527272251466};\\\", \\\"{x:581,y:590,t:1527272251482};\\\", \\\"{x:562,y:584,t:1527272251498};\\\", \\\"{x:552,y:578,t:1527272251516};\\\", \\\"{x:544,y:571,t:1527272251532};\\\", \\\"{x:534,y:564,t:1527272251549};\\\", \\\"{x:522,y:555,t:1527272251567};\\\", \\\"{x:502,y:545,t:1527272251583};\\\", \\\"{x:478,y:537,t:1527272251600};\\\", \\\"{x:468,y:534,t:1527272251615};\\\", \\\"{x:462,y:530,t:1527272251631};\\\", \\\"{x:455,y:527,t:1527272251649};\\\", \\\"{x:441,y:520,t:1527272251667};\\\", \\\"{x:396,y:503,t:1527272251684};\\\", \\\"{x:380,y:501,t:1527272251698};\\\", \\\"{x:377,y:501,t:1527272251715};\\\", \\\"{x:376,y:501,t:1527272251755};\\\", \\\"{x:373,y:501,t:1527272251766};\\\", \\\"{x:352,y:501,t:1527272251781};\\\", \\\"{x:331,y:503,t:1527272251800};\\\", \\\"{x:322,y:508,t:1527272251816};\\\", \\\"{x:316,y:509,t:1527272251833};\\\", \\\"{x:311,y:511,t:1527272251849};\\\", \\\"{x:291,y:511,t:1527272251866};\\\", \\\"{x:268,y:511,t:1527272251884};\\\", \\\"{x:255,y:514,t:1527272251899};\\\", \\\"{x:241,y:519,t:1527272251916};\\\", \\\"{x:230,y:522,t:1527272251932};\\\", \\\"{x:222,y:522,t:1527272251949};\\\", \\\"{x:217,y:522,t:1527272251966};\\\", \\\"{x:213,y:522,t:1527272251982};\\\", \\\"{x:208,y:523,t:1527272251998};\\\", \\\"{x:204,y:527,t:1527272252016};\\\", \\\"{x:199,y:537,t:1527272252032};\\\", \\\"{x:197,y:548,t:1527272252049};\\\", \\\"{x:197,y:553,t:1527272252066};\\\", \\\"{x:197,y:560,t:1527272252083};\\\", \\\"{x:197,y:570,t:1527272252100};\\\", \\\"{x:198,y:585,t:1527272252116};\\\", \\\"{x:203,y:601,t:1527272252134};\\\", \\\"{x:207,y:613,t:1527272252150};\\\", \\\"{x:208,y:616,t:1527272252165};\\\", \\\"{x:208,y:618,t:1527272252182};\\\", \\\"{x:209,y:624,t:1527272252199};\\\", \\\"{x:210,y:629,t:1527272252216};\\\", \\\"{x:215,y:635,t:1527272252233};\\\", \\\"{x:216,y:637,t:1527272252250};\\\", \\\"{x:224,y:638,t:1527272252266};\\\", \\\"{x:258,y:633,t:1527272252282};\\\", \\\"{x:325,y:621,t:1527272252301};\\\", \\\"{x:400,y:610,t:1527272252316};\\\", \\\"{x:448,y:604,t:1527272252333};\\\", \\\"{x:488,y:597,t:1527272252350};\\\", \\\"{x:524,y:594,t:1527272252367};\\\", \\\"{x:553,y:588,t:1527272252383};\\\", \\\"{x:569,y:583,t:1527272252399};\\\", \\\"{x:570,y:583,t:1527272252415};\\\", \\\"{x:569,y:583,t:1527272252468};\\\", \\\"{x:570,y:586,t:1527272252483};\\\", \\\"{x:572,y:588,t:1527272252500};\\\", \\\"{x:577,y:588,t:1527272252516};\\\", \\\"{x:582,y:588,t:1527272252533};\\\", \\\"{x:589,y:588,t:1527272252549};\\\", \\\"{x:604,y:588,t:1527272252568};\\\", \\\"{x:624,y:590,t:1527272252583};\\\", \\\"{x:646,y:590,t:1527272252600};\\\", \\\"{x:664,y:590,t:1527272252616};\\\", \\\"{x:677,y:590,t:1527272252633};\\\", \\\"{x:680,y:589,t:1527272252650};\\\", \\\"{x:684,y:585,t:1527272252666};\\\", \\\"{x:688,y:579,t:1527272252683};\\\", \\\"{x:694,y:557,t:1527272252701};\\\", \\\"{x:700,y:539,t:1527272252717};\\\", \\\"{x:701,y:533,t:1527272252732};\\\", \\\"{x:702,y:530,t:1527272252750};\\\", \\\"{x:702,y:528,t:1527272252765};\\\", \\\"{x:708,y:525,t:1527272252782};\\\", \\\"{x:716,y:521,t:1527272252800};\\\", \\\"{x:712,y:520,t:1527272252996};\\\", \\\"{x:703,y:517,t:1527272253004};\\\", \\\"{x:698,y:516,t:1527272253016};\\\", \\\"{x:691,y:515,t:1527272253033};\\\", \\\"{x:690,y:515,t:1527272253049};\\\", \\\"{x:684,y:515,t:1527272253066};\\\", \\\"{x:673,y:515,t:1527272253083};\\\", \\\"{x:663,y:512,t:1527272253099};\\\", \\\"{x:658,y:509,t:1527272253116};\\\", \\\"{x:654,y:505,t:1527272253133};\\\", \\\"{x:650,y:503,t:1527272253150};\\\", \\\"{x:645,y:502,t:1527272253167};\\\", \\\"{x:640,y:501,t:1527272253185};\\\", \\\"{x:638,y:501,t:1527272253201};\\\", \\\"{x:634,y:501,t:1527272253217};\\\", \\\"{x:626,y:501,t:1527272253234};\\\", \\\"{x:612,y:501,t:1527272253251};\\\", \\\"{x:609,y:501,t:1527272253266};\\\", \\\"{x:608,y:501,t:1527272253315};\\\", \\\"{x:606,y:501,t:1527272253635};\\\", \\\"{x:600,y:506,t:1527272253651};\\\", \\\"{x:594,y:512,t:1527272253667};\\\", \\\"{x:584,y:520,t:1527272253685};\\\", \\\"{x:572,y:526,t:1527272253702};\\\", \\\"{x:561,y:533,t:1527272253717};\\\", \\\"{x:559,y:533,t:1527272253733};\\\", \\\"{x:556,y:534,t:1527272253751};\\\", \\\"{x:551,y:534,t:1527272253767};\\\", \\\"{x:546,y:534,t:1527272253784};\\\", \\\"{x:538,y:539,t:1527272253801};\\\", \\\"{x:522,y:545,t:1527272253818};\\\", \\\"{x:502,y:550,t:1527272253833};\\\", \\\"{x:473,y:558,t:1527272253852};\\\", \\\"{x:454,y:560,t:1527272253868};\\\", \\\"{x:432,y:564,t:1527272253883};\\\", \\\"{x:408,y:566,t:1527272253900};\\\", \\\"{x:382,y:571,t:1527272253918};\\\", \\\"{x:367,y:573,t:1527272253933};\\\", \\\"{x:362,y:574,t:1527272253950};\\\", \\\"{x:361,y:574,t:1527272253968};\\\", \\\"{x:359,y:574,t:1527272253994};\\\", \\\"{x:358,y:574,t:1527272254010};\\\", \\\"{x:355,y:573,t:1527272254018};\\\", \\\"{x:340,y:565,t:1527272254034};\\\", \\\"{x:322,y:563,t:1527272254051};\\\", \\\"{x:306,y:561,t:1527272254068};\\\", \\\"{x:292,y:560,t:1527272254085};\\\", \\\"{x:277,y:559,t:1527272254100};\\\", \\\"{x:266,y:556,t:1527272254117};\\\", \\\"{x:250,y:551,t:1527272254135};\\\", \\\"{x:233,y:550,t:1527272254150};\\\", \\\"{x:225,y:550,t:1527272254167};\\\", \\\"{x:219,y:551,t:1527272254185};\\\", \\\"{x:218,y:551,t:1527272254201};\\\", \\\"{x:217,y:551,t:1527272254219};\\\", \\\"{x:216,y:551,t:1527272254300};\\\", \\\"{x:214,y:553,t:1527272254315};\\\", \\\"{x:213,y:554,t:1527272254323};\\\", \\\"{x:212,y:560,t:1527272254336};\\\", \\\"{x:211,y:570,t:1527272254351};\\\", \\\"{x:212,y:581,t:1527272254367};\\\", \\\"{x:223,y:597,t:1527272254384};\\\", \\\"{x:242,y:608,t:1527272254400};\\\", \\\"{x:264,y:621,t:1527272254417};\\\", \\\"{x:291,y:631,t:1527272254435};\\\", \\\"{x:314,y:636,t:1527272254451};\\\", \\\"{x:348,y:641,t:1527272254468};\\\", \\\"{x:396,y:649,t:1527272254485};\\\", \\\"{x:451,y:654,t:1527272254500};\\\", \\\"{x:493,y:659,t:1527272254518};\\\", \\\"{x:523,y:659,t:1527272254535};\\\", \\\"{x:552,y:659,t:1527272254551};\\\", \\\"{x:583,y:660,t:1527272254567};\\\", \\\"{x:615,y:660,t:1527272254585};\\\", \\\"{x:642,y:660,t:1527272254601};\\\", \\\"{x:667,y:657,t:1527272254617};\\\", \\\"{x:691,y:646,t:1527272254635};\\\", \\\"{x:708,y:636,t:1527272254650};\\\", \\\"{x:726,y:624,t:1527272254669};\\\", \\\"{x:745,y:613,t:1527272254684};\\\", \\\"{x:758,y:604,t:1527272254700};\\\", \\\"{x:762,y:601,t:1527272254717};\\\", \\\"{x:766,y:598,t:1527272254735};\\\", \\\"{x:774,y:594,t:1527272254752};\\\", \\\"{x:783,y:590,t:1527272254768};\\\", \\\"{x:789,y:586,t:1527272254784};\\\", \\\"{x:791,y:584,t:1527272254802};\\\", \\\"{x:794,y:581,t:1527272254818};\\\", \\\"{x:797,y:580,t:1527272254834};\\\", \\\"{x:799,y:579,t:1527272254851};\\\", \\\"{x:800,y:578,t:1527272254868};\\\", \\\"{x:801,y:577,t:1527272254898};\\\", \\\"{x:801,y:575,t:1527272254907};\\\", \\\"{x:802,y:573,t:1527272254918};\\\", \\\"{x:805,y:570,t:1527272254935};\\\", \\\"{x:816,y:564,t:1527272254951};\\\", \\\"{x:827,y:557,t:1527272254970};\\\", \\\"{x:834,y:550,t:1527272254986};\\\", \\\"{x:835,y:547,t:1527272255002};\\\", \\\"{x:835,y:546,t:1527272255018};\\\", \\\"{x:837,y:541,t:1527272255034};\\\", \\\"{x:841,y:538,t:1527272255052};\\\", \\\"{x:845,y:534,t:1527272255068};\\\", \\\"{x:846,y:533,t:1527272255085};\\\", \\\"{x:846,y:532,t:1527272255102};\\\", \\\"{x:846,y:533,t:1527272255411};\\\", \\\"{x:844,y:535,t:1527272255418};\\\", \\\"{x:843,y:537,t:1527272255435};\\\", \\\"{x:842,y:538,t:1527272255451};\\\", \\\"{x:840,y:540,t:1527272255469};\\\", \\\"{x:828,y:546,t:1527272255484};\\\", \\\"{x:797,y:566,t:1527272255505};\\\", \\\"{x:743,y:606,t:1527272255519};\\\", \\\"{x:704,y:640,t:1527272255536};\\\", \\\"{x:663,y:671,t:1527272255552};\\\", \\\"{x:637,y:684,t:1527272255568};\\\", \\\"{x:622,y:689,t:1527272255586};\\\", \\\"{x:609,y:693,t:1527272255601};\\\", \\\"{x:595,y:698,t:1527272255618};\\\", \\\"{x:588,y:702,t:1527272255636};\\\", \\\"{x:581,y:707,t:1527272255651};\\\", \\\"{x:576,y:713,t:1527272255668};\\\", \\\"{x:572,y:719,t:1527272255685};\\\", \\\"{x:570,y:723,t:1527272255701};\\\", \\\"{x:568,y:727,t:1527272255719};\\\", \\\"{x:567,y:729,t:1527272255736};\\\", \\\"{x:566,y:730,t:1527272255751};\\\", \\\"{x:565,y:730,t:1527272255769};\\\", \\\"{x:565,y:732,t:1527272255786};\\\", \\\"{x:564,y:733,t:1527272255803};\\\", \\\"{x:561,y:738,t:1527272255818};\\\", \\\"{x:560,y:740,t:1527272255835};\\\", \\\"{x:559,y:740,t:1527272255853};\\\", \\\"{x:557,y:742,t:1527272255868};\\\", \\\"{x:560,y:743,t:1527272256715};\\\", \\\"{x:567,y:743,t:1527272256724};\\\", \\\"{x:580,y:743,t:1527272256736};\\\", \\\"{x:632,y:742,t:1527272256753};\\\", \\\"{x:730,y:740,t:1527272256770};\\\", \\\"{x:844,y:738,t:1527272256786};\\\", \\\"{x:1044,y:730,t:1527272256803};\\\", \\\"{x:1177,y:728,t:1527272256821};\\\", \\\"{x:1294,y:726,t:1527272256836};\\\", \\\"{x:1412,y:716,t:1527272256854};\\\", \\\"{x:1503,y:708,t:1527272256870};\\\", \\\"{x:1553,y:702,t:1527272256888};\\\", \\\"{x:1565,y:700,t:1527272256903};\\\", \\\"{x:1566,y:700,t:1527272256988};\\\", \\\"{x:1561,y:700,t:1527272257139};\\\", \\\"{x:1550,y:700,t:1527272257153};\\\", \\\"{x:1528,y:697,t:1527272257171};\\\", \\\"{x:1495,y:692,t:1527272257188};\\\", \\\"{x:1474,y:689,t:1527272257203};\\\", \\\"{x:1450,y:681,t:1527272257219};\\\", \\\"{x:1425,y:677,t:1527272257237};\\\", \\\"{x:1410,y:674,t:1527272257252};\\\", \\\"{x:1403,y:673,t:1527272257270};\\\", \\\"{x:1402,y:673,t:1527272257286};\\\", \\\"{x:1400,y:673,t:1527272257303};\\\", \\\"{x:1398,y:673,t:1527272257323};\\\", \\\"{x:1394,y:673,t:1527272257337};\\\", \\\"{x:1385,y:671,t:1527272257353};\\\", \\\"{x:1378,y:668,t:1527272257370};\\\", \\\"{x:1371,y:666,t:1527272257387};\\\", \\\"{x:1364,y:664,t:1527272257404};\\\", \\\"{x:1355,y:660,t:1527272257420};\\\", \\\"{x:1343,y:656,t:1527272257437};\\\", \\\"{x:1331,y:651,t:1527272257454};\\\", \\\"{x:1327,y:651,t:1527272257470};\\\", \\\"{x:1325,y:650,t:1527272257488};\\\", \\\"{x:1323,y:649,t:1527272257571};\\\", \\\"{x:1322,y:647,t:1527272257586};\\\", \\\"{x:1320,y:646,t:1527272257604};\\\", \\\"{x:1319,y:645,t:1527272257708};\\\", \\\"{x:1318,y:644,t:1527272257723};\\\", \\\"{x:1317,y:643,t:1527272257740};\\\", \\\"{x:1316,y:642,t:1527272257755};\\\", \\\"{x:1316,y:641,t:1527272257772};\\\", \\\"{x:1314,y:640,t:1527272258259};\\\", \\\"{x:1312,y:639,t:1527272258272};\\\", \\\"{x:1308,y:637,t:1527272258288};\\\", \\\"{x:1302,y:633,t:1527272258304};\\\", \\\"{x:1286,y:627,t:1527272258321};\\\", \\\"{x:1269,y:617,t:1527272258338};\\\", \\\"{x:1253,y:602,t:1527272258353};\\\", \\\"{x:1247,y:596,t:1527272258370};\\\", \\\"{x:1247,y:595,t:1527272258388};\\\", \\\"{x:1245,y:593,t:1527272258404};\\\", \\\"{x:1245,y:592,t:1527272258421};\\\", \\\"{x:1245,y:590,t:1527272258443};\\\", \\\"{x:1245,y:589,t:1527272258483};\\\", \\\"{x:1245,y:588,t:1527272258491};\\\", \\\"{x:1245,y:587,t:1527272258505};\\\", \\\"{x:1245,y:585,t:1527272258522};\\\", \\\"{x:1245,y:582,t:1527272258538};\\\", \\\"{x:1245,y:579,t:1527272258554};\\\", \\\"{x:1245,y:576,t:1527272258571};\\\", \\\"{x:1245,y:575,t:1527272258588};\\\", \\\"{x:1245,y:573,t:1527272258636};\\\", \\\"{x:1247,y:571,t:1527272258651};\\\", \\\"{x:1248,y:571,t:1527272258660};\\\", \\\"{x:1249,y:570,t:1527272258671};\\\", \\\"{x:1252,y:568,t:1527272258689};\\\", \\\"{x:1256,y:567,t:1527272258705};\\\", \\\"{x:1259,y:565,t:1527272258721};\\\", \\\"{x:1262,y:565,t:1527272258738};\\\", \\\"{x:1262,y:564,t:1527272258754};\\\", \\\"{x:1265,y:563,t:1527272258908};\\\", \\\"{x:1271,y:563,t:1527272258921};\\\", \\\"{x:1286,y:563,t:1527272258939};\\\", \\\"{x:1303,y:561,t:1527272258956};\\\", \\\"{x:1305,y:561,t:1527272258971};\\\", \\\"{x:1307,y:560,t:1527272258989};\\\", \\\"{x:1309,y:560,t:1527272259005};\\\", \\\"{x:1313,y:560,t:1527272259022};\\\", \\\"{x:1321,y:560,t:1527272259039};\\\", \\\"{x:1330,y:560,t:1527272259055};\\\", \\\"{x:1333,y:560,t:1527272259071};\\\", \\\"{x:1334,y:560,t:1527272259132};\\\", \\\"{x:1337,y:560,t:1527272259139};\\\", \\\"{x:1344,y:560,t:1527272259154};\\\", \\\"{x:1348,y:560,t:1527272259172};\\\", \\\"{x:1351,y:560,t:1527272259189};\\\", \\\"{x:1353,y:560,t:1527272259243};\\\", \\\"{x:1355,y:560,t:1527272259256};\\\", \\\"{x:1362,y:560,t:1527272259274};\\\", \\\"{x:1368,y:560,t:1527272259288};\\\", \\\"{x:1380,y:560,t:1527272259305};\\\", \\\"{x:1398,y:568,t:1527272259322};\\\", \\\"{x:1411,y:577,t:1527272259339};\\\", \\\"{x:1434,y:579,t:1527272259355};\\\", \\\"{x:1440,y:579,t:1527272259372};\\\", \\\"{x:1445,y:579,t:1527272259389};\\\", \\\"{x:1448,y:579,t:1527272259405};\\\", \\\"{x:1449,y:579,t:1527272259452};\\\", \\\"{x:1451,y:579,t:1527272259467};\\\", \\\"{x:1452,y:579,t:1527272259475};\\\", \\\"{x:1454,y:579,t:1527272259487};\\\", \\\"{x:1456,y:579,t:1527272259505};\\\", \\\"{x:1453,y:579,t:1527272259562};\\\", \\\"{x:1446,y:581,t:1527272259572};\\\", \\\"{x:1390,y:597,t:1527272259588};\\\", \\\"{x:1324,y:622,t:1527272259605};\\\", \\\"{x:1240,y:651,t:1527272259622};\\\", \\\"{x:1153,y:681,t:1527272259637};\\\", \\\"{x:1051,y:710,t:1527272259655};\\\", \\\"{x:954,y:735,t:1527272259673};\\\", \\\"{x:879,y:755,t:1527272259689};\\\", \\\"{x:838,y:765,t:1527272259704};\\\", \\\"{x:815,y:768,t:1527272259722};\\\", \\\"{x:808,y:768,t:1527272259739};\\\", \\\"{x:807,y:767,t:1527272259804};\\\", \\\"{x:805,y:763,t:1527272259811};\\\", \\\"{x:804,y:761,t:1527272259822};\\\", \\\"{x:803,y:753,t:1527272259839};\\\", \\\"{x:803,y:745,t:1527272259856};\\\", \\\"{x:798,y:732,t:1527272259874};\\\", \\\"{x:785,y:720,t:1527272259889};\\\", \\\"{x:765,y:711,t:1527272259905};\\\", \\\"{x:754,y:709,t:1527272259922};\\\", \\\"{x:749,y:709,t:1527272259939};\\\", \\\"{x:744,y:708,t:1527272259955};\\\", \\\"{x:733,y:706,t:1527272259973};\\\", \\\"{x:704,y:706,t:1527272259989};\\\", \\\"{x:672,y:710,t:1527272260005};\\\", \\\"{x:639,y:725,t:1527272260022};\\\", \\\"{x:615,y:732,t:1527272260039};\\\", \\\"{x:596,y:732,t:1527272260055};\\\", \\\"{x:588,y:729,t:1527272260073};\\\", \\\"{x:582,y:729,t:1527272260259};\\\", \\\"{x:573,y:729,t:1527272260274};\\\", \\\"{x:557,y:727,t:1527272260290};\\\", \\\"{x:553,y:726,t:1527272260306};\\\", \\\"{x:551,y:726,t:1527272260322};\\\", \\\"{x:549,y:725,t:1527272260338};\\\", \\\"{x:545,y:724,t:1527272260356};\\\", \\\"{x:544,y:724,t:1527272260684};\\\", \\\"{x:538,y:724,t:1527272260971};\\\", \\\"{x:537,y:724,t:1527272260979};\\\", \\\"{x:536,y:723,t:1527272260990};\\\", \\\"{x:534,y:720,t:1527272261007};\\\", \\\"{x:530,y:713,t:1527272261024};\\\", \\\"{x:520,y:702,t:1527272261040};\\\", \\\"{x:514,y:696,t:1527272261057};\\\", \\\"{x:513,y:690,t:1527272261074};\\\" ] }, { \\\"rt\\\": 37101, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 889667, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -12 PM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:684,t:1527272262187};\\\", \\\"{x:498,y:672,t:1527272262194};\\\", \\\"{x:482,y:652,t:1527272262207};\\\", \\\"{x:448,y:628,t:1527272262224};\\\", \\\"{x:413,y:606,t:1527272262241};\\\", \\\"{x:390,y:594,t:1527272262258};\\\", \\\"{x:374,y:584,t:1527272262274};\\\", \\\"{x:355,y:574,t:1527272262290};\\\", \\\"{x:350,y:571,t:1527272262306};\\\", \\\"{x:346,y:568,t:1527272262324};\\\", \\\"{x:345,y:567,t:1527272262341};\\\", \\\"{x:343,y:566,t:1527272262361};\\\", \\\"{x:343,y:565,t:1527272262443};\\\", \\\"{x:343,y:564,t:1527272262457};\\\", \\\"{x:343,y:561,t:1527272262475};\\\", \\\"{x:343,y:555,t:1527272262491};\\\", \\\"{x:343,y:548,t:1527272262508};\\\", \\\"{x:340,y:540,t:1527272262523};\\\", \\\"{x:338,y:536,t:1527272262541};\\\", \\\"{x:336,y:533,t:1527272262557};\\\", \\\"{x:336,y:531,t:1527272264203};\\\", \\\"{x:336,y:528,t:1527272264211};\\\", \\\"{x:342,y:525,t:1527272264225};\\\", \\\"{x:356,y:518,t:1527272264243};\\\", \\\"{x:384,y:505,t:1527272264259};\\\", \\\"{x:425,y:505,t:1527272264276};\\\", \\\"{x:465,y:511,t:1527272264292};\\\", \\\"{x:501,y:515,t:1527272264310};\\\", \\\"{x:546,y:527,t:1527272264328};\\\", \\\"{x:583,y:534,t:1527272264342};\\\", \\\"{x:592,y:534,t:1527272264359};\\\", \\\"{x:592,y:535,t:1527272264723};\\\", \\\"{x:596,y:540,t:1527272269003};\\\", \\\"{x:619,y:553,t:1527272269013};\\\", \\\"{x:705,y:576,t:1527272269031};\\\", \\\"{x:810,y:592,t:1527272269046};\\\", \\\"{x:911,y:610,t:1527272269063};\\\", \\\"{x:1008,y:622,t:1527272269080};\\\", \\\"{x:1107,y:635,t:1527272269096};\\\", \\\"{x:1174,y:652,t:1527272269113};\\\", \\\"{x:1227,y:660,t:1527272269129};\\\", \\\"{x:1277,y:669,t:1527272269146};\\\", \\\"{x:1297,y:675,t:1527272269162};\\\", \\\"{x:1311,y:680,t:1527272269179};\\\", \\\"{x:1313,y:680,t:1527272269196};\\\", \\\"{x:1314,y:680,t:1527272270307};\\\", \\\"{x:1315,y:681,t:1527272270451};\\\", \\\"{x:1315,y:684,t:1527272270464};\\\", \\\"{x:1315,y:689,t:1527272270480};\\\", \\\"{x:1316,y:693,t:1527272270497};\\\", \\\"{x:1318,y:699,t:1527272270514};\\\", \\\"{x:1321,y:705,t:1527272270530};\\\", \\\"{x:1323,y:707,t:1527272270547};\\\", \\\"{x:1323,y:708,t:1527272270564};\\\", \\\"{x:1325,y:711,t:1527272270581};\\\", \\\"{x:1325,y:709,t:1527272270676};\\\", \\\"{x:1325,y:703,t:1527272270683};\\\", \\\"{x:1325,y:700,t:1527272270697};\\\", \\\"{x:1318,y:674,t:1527272270715};\\\", \\\"{x:1309,y:658,t:1527272270730};\\\", \\\"{x:1307,y:647,t:1527272270748};\\\", \\\"{x:1307,y:645,t:1527272270765};\\\", \\\"{x:1307,y:643,t:1527272270781};\\\", \\\"{x:1305,y:641,t:1527272270797};\\\", \\\"{x:1305,y:640,t:1527272270814};\\\", \\\"{x:1305,y:636,t:1527272270830};\\\", \\\"{x:1304,y:633,t:1527272270847};\\\", \\\"{x:1303,y:627,t:1527272270864};\\\", \\\"{x:1302,y:623,t:1527272270880};\\\", \\\"{x:1302,y:619,t:1527272270897};\\\", \\\"{x:1302,y:613,t:1527272270915};\\\", \\\"{x:1302,y:609,t:1527272270940};\\\", \\\"{x:1302,y:608,t:1527272270947};\\\", \\\"{x:1302,y:606,t:1527272270964};\\\", \\\"{x:1302,y:602,t:1527272270981};\\\", \\\"{x:1302,y:598,t:1527272270997};\\\", \\\"{x:1301,y:594,t:1527272271014};\\\", \\\"{x:1300,y:590,t:1527272271031};\\\", \\\"{x:1299,y:585,t:1527272271047};\\\", \\\"{x:1297,y:579,t:1527272271064};\\\", \\\"{x:1296,y:574,t:1527272271081};\\\", \\\"{x:1295,y:571,t:1527272271098};\\\", \\\"{x:1295,y:569,t:1527272271114};\\\", \\\"{x:1295,y:566,t:1527272271131};\\\", \\\"{x:1295,y:565,t:1527272271147};\\\", \\\"{x:1295,y:563,t:1527272271164};\\\", \\\"{x:1294,y:563,t:1527272271181};\\\", \\\"{x:1294,y:562,t:1527272271198};\\\", \\\"{x:1292,y:562,t:1527272272395};\\\", \\\"{x:1291,y:563,t:1527272272467};\\\", \\\"{x:1291,y:564,t:1527272272491};\\\", \\\"{x:1291,y:565,t:1527272272507};\\\", \\\"{x:1290,y:565,t:1527272272516};\\\", \\\"{x:1290,y:567,t:1527272272532};\\\", \\\"{x:1289,y:569,t:1527272272549};\\\", \\\"{x:1288,y:570,t:1527272272566};\\\", \\\"{x:1287,y:572,t:1527272272583};\\\", \\\"{x:1287,y:573,t:1527272272610};\\\", \\\"{x:1287,y:576,t:1527272272619};\\\", \\\"{x:1287,y:579,t:1527272272633};\\\", \\\"{x:1285,y:584,t:1527272272649};\\\", \\\"{x:1282,y:595,t:1527272272665};\\\", \\\"{x:1278,y:610,t:1527272272683};\\\", \\\"{x:1275,y:618,t:1527272272700};\\\", \\\"{x:1275,y:623,t:1527272272715};\\\", \\\"{x:1274,y:626,t:1527272272732};\\\", \\\"{x:1274,y:629,t:1527272272749};\\\", \\\"{x:1274,y:632,t:1527272272766};\\\", \\\"{x:1274,y:637,t:1527272272783};\\\", \\\"{x:1274,y:641,t:1527272272799};\\\", \\\"{x:1274,y:648,t:1527272272816};\\\", \\\"{x:1273,y:651,t:1527272272833};\\\", \\\"{x:1273,y:652,t:1527272272849};\\\", \\\"{x:1273,y:653,t:1527272272867};\\\", \\\"{x:1272,y:652,t:1527272273107};\\\", \\\"{x:1271,y:650,t:1527272273116};\\\", \\\"{x:1271,y:647,t:1527272273132};\\\", \\\"{x:1271,y:645,t:1527272273150};\\\", \\\"{x:1271,y:644,t:1527272273171};\\\", \\\"{x:1272,y:642,t:1527272274500};\\\", \\\"{x:1278,y:639,t:1527272274517};\\\", \\\"{x:1288,y:637,t:1527272274534};\\\", \\\"{x:1302,y:637,t:1527272274550};\\\", \\\"{x:1320,y:637,t:1527272274567};\\\", \\\"{x:1340,y:637,t:1527272274584};\\\", \\\"{x:1360,y:637,t:1527272274601};\\\", \\\"{x:1381,y:637,t:1527272274616};\\\", \\\"{x:1404,y:637,t:1527272274634};\\\", \\\"{x:1430,y:637,t:1527272274650};\\\", \\\"{x:1442,y:637,t:1527272274666};\\\", \\\"{x:1448,y:637,t:1527272274683};\\\", \\\"{x:1449,y:637,t:1527272274795};\\\", \\\"{x:1451,y:637,t:1527272274932};\\\", \\\"{x:1453,y:636,t:1527272274939};\\\", \\\"{x:1453,y:635,t:1527272274951};\\\", \\\"{x:1455,y:634,t:1527272274968};\\\", \\\"{x:1454,y:635,t:1527272276403};\\\", \\\"{x:1448,y:641,t:1527272276419};\\\", \\\"{x:1437,y:650,t:1527272276435};\\\", \\\"{x:1424,y:659,t:1527272276453};\\\", \\\"{x:1411,y:670,t:1527272276469};\\\", \\\"{x:1393,y:682,t:1527272276485};\\\", \\\"{x:1380,y:691,t:1527272276502};\\\", \\\"{x:1371,y:698,t:1527272276519};\\\", \\\"{x:1364,y:705,t:1527272276534};\\\", \\\"{x:1360,y:711,t:1527272276552};\\\", \\\"{x:1355,y:715,t:1527272276569};\\\", \\\"{x:1352,y:719,t:1527272276585};\\\", \\\"{x:1352,y:721,t:1527272276602};\\\", \\\"{x:1352,y:723,t:1527272276660};\\\", \\\"{x:1352,y:725,t:1527272276690};\\\", \\\"{x:1352,y:726,t:1527272276702};\\\", \\\"{x:1352,y:728,t:1527272276719};\\\", \\\"{x:1352,y:729,t:1527272276736};\\\", \\\"{x:1352,y:730,t:1527272276955};\\\", \\\"{x:1353,y:729,t:1527272277019};\\\", \\\"{x:1353,y:728,t:1527272277036};\\\", \\\"{x:1353,y:727,t:1527272277052};\\\", \\\"{x:1353,y:726,t:1527272277069};\\\", \\\"{x:1353,y:724,t:1527272277086};\\\", \\\"{x:1353,y:722,t:1527272277102};\\\", \\\"{x:1353,y:720,t:1527272277119};\\\", \\\"{x:1353,y:717,t:1527272277136};\\\", \\\"{x:1352,y:717,t:1527272277153};\\\", \\\"{x:1352,y:716,t:1527272277179};\\\", \\\"{x:1352,y:715,t:1527272277187};\\\", \\\"{x:1351,y:714,t:1527272277203};\\\", \\\"{x:1350,y:712,t:1527272277219};\\\", \\\"{x:1344,y:715,t:1527272281578};\\\", \\\"{x:1333,y:717,t:1527272281588};\\\", \\\"{x:1280,y:723,t:1527272281606};\\\", \\\"{x:1277,y:719,t:1527272281622};\\\", \\\"{x:1275,y:719,t:1527272281915};\\\", \\\"{x:1262,y:718,t:1527272281922};\\\", \\\"{x:1227,y:712,t:1527272281939};\\\", \\\"{x:1160,y:702,t:1527272281956};\\\", \\\"{x:1079,y:691,t:1527272281973};\\\", \\\"{x:990,y:677,t:1527272281989};\\\", \\\"{x:896,y:668,t:1527272282006};\\\", \\\"{x:802,y:656,t:1527272282023};\\\", \\\"{x:746,y:648,t:1527272282039};\\\", \\\"{x:720,y:642,t:1527272282056};\\\", \\\"{x:706,y:636,t:1527272282073};\\\", \\\"{x:700,y:632,t:1527272282089};\\\", \\\"{x:693,y:631,t:1527272282107};\\\", \\\"{x:685,y:629,t:1527272282122};\\\", \\\"{x:684,y:629,t:1527272282139};\\\", \\\"{x:683,y:629,t:1527272282153};\\\", \\\"{x:679,y:627,t:1527272282169};\\\", \\\"{x:653,y:619,t:1527272282186};\\\", \\\"{x:639,y:617,t:1527272282204};\\\", \\\"{x:636,y:617,t:1527272282220};\\\", \\\"{x:635,y:616,t:1527272282240};\\\", \\\"{x:634,y:614,t:1527272282257};\\\", \\\"{x:629,y:609,t:1527272282273};\\\", \\\"{x:621,y:601,t:1527272282290};\\\", \\\"{x:608,y:587,t:1527272282307};\\\", \\\"{x:605,y:582,t:1527272282324};\\\", \\\"{x:605,y:576,t:1527272282340};\\\", \\\"{x:605,y:567,t:1527272282357};\\\", \\\"{x:611,y:556,t:1527272282374};\\\", \\\"{x:632,y:544,t:1527272282390};\\\", \\\"{x:689,y:520,t:1527272282407};\\\", \\\"{x:771,y:497,t:1527272282424};\\\", \\\"{x:838,y:478,t:1527272282440};\\\", \\\"{x:866,y:469,t:1527272282456};\\\", \\\"{x:890,y:465,t:1527272282474};\\\", \\\"{x:895,y:464,t:1527272282490};\\\", \\\"{x:892,y:464,t:1527272282530};\\\", \\\"{x:887,y:468,t:1527272282541};\\\", \\\"{x:881,y:475,t:1527272282557};\\\", \\\"{x:877,y:484,t:1527272282574};\\\", \\\"{x:876,y:494,t:1527272282591};\\\", \\\"{x:876,y:504,t:1527272282606};\\\", \\\"{x:872,y:512,t:1527272282623};\\\", \\\"{x:869,y:513,t:1527272282640};\\\", \\\"{x:857,y:516,t:1527272282657};\\\", \\\"{x:846,y:516,t:1527272282673};\\\", \\\"{x:844,y:516,t:1527272282786};\\\", \\\"{x:844,y:515,t:1527272282794};\\\", \\\"{x:842,y:513,t:1527272282807};\\\", \\\"{x:840,y:513,t:1527272282994};\\\", \\\"{x:838,y:513,t:1527272283007};\\\", \\\"{x:835,y:514,t:1527272283024};\\\", \\\"{x:828,y:518,t:1527272283041};\\\", \\\"{x:812,y:523,t:1527272283056};\\\", \\\"{x:748,y:536,t:1527272283074};\\\", \\\"{x:709,y:541,t:1527272283091};\\\", \\\"{x:668,y:549,t:1527272283107};\\\", \\\"{x:628,y:556,t:1527272283124};\\\", \\\"{x:570,y:556,t:1527272283141};\\\", \\\"{x:511,y:556,t:1527272283157};\\\", \\\"{x:471,y:556,t:1527272283174};\\\", \\\"{x:463,y:554,t:1527272283191};\\\", \\\"{x:462,y:554,t:1527272283208};\\\", \\\"{x:461,y:553,t:1527272283223};\\\", \\\"{x:453,y:552,t:1527272283241};\\\", \\\"{x:430,y:552,t:1527272283258};\\\", \\\"{x:387,y:558,t:1527272283275};\\\", \\\"{x:347,y:558,t:1527272283291};\\\", \\\"{x:312,y:557,t:1527272283308};\\\", \\\"{x:272,y:544,t:1527272283325};\\\", \\\"{x:232,y:535,t:1527272283340};\\\", \\\"{x:186,y:532,t:1527272283357};\\\", \\\"{x:180,y:532,t:1527272283374};\\\", \\\"{x:179,y:532,t:1527272283426};\\\", \\\"{x:178,y:532,t:1527272283441};\\\", \\\"{x:176,y:532,t:1527272283457};\\\", \\\"{x:175,y:532,t:1527272283522};\\\", \\\"{x:175,y:533,t:1527272283554};\\\", \\\"{x:173,y:535,t:1527272283562};\\\", \\\"{x:173,y:536,t:1527272283574};\\\", \\\"{x:173,y:537,t:1527272283874};\\\", \\\"{x:179,y:537,t:1527272283892};\\\", \\\"{x:195,y:544,t:1527272283908};\\\", \\\"{x:212,y:550,t:1527272283925};\\\", \\\"{x:240,y:560,t:1527272283942};\\\", \\\"{x:306,y:575,t:1527272283958};\\\", \\\"{x:407,y:599,t:1527272283976};\\\", \\\"{x:531,y:626,t:1527272283992};\\\", \\\"{x:681,y:652,t:1527272284008};\\\", \\\"{x:836,y:674,t:1527272284024};\\\", \\\"{x:1075,y:709,t:1527272284042};\\\", \\\"{x:1145,y:718,t:1527272284058};\\\", \\\"{x:1301,y:718,t:1527272284075};\\\", \\\"{x:1351,y:718,t:1527272284092};\\\", \\\"{x:1377,y:718,t:1527272284109};\\\", \\\"{x:1387,y:718,t:1527272284125};\\\", \\\"{x:1387,y:716,t:1527272284154};\\\", \\\"{x:1387,y:713,t:1527272284163};\\\", \\\"{x:1384,y:707,t:1527272284175};\\\", \\\"{x:1378,y:700,t:1527272284192};\\\", \\\"{x:1375,y:699,t:1527272284210};\\\", \\\"{x:1372,y:698,t:1527272284227};\\\", \\\"{x:1372,y:697,t:1527272284242};\\\", \\\"{x:1372,y:696,t:1527272284283};\\\", \\\"{x:1372,y:695,t:1527272284300};\\\", \\\"{x:1372,y:693,t:1527272284310};\\\", \\\"{x:1372,y:690,t:1527272284327};\\\", \\\"{x:1372,y:688,t:1527272284344};\\\", \\\"{x:1372,y:685,t:1527272284359};\\\", \\\"{x:1372,y:684,t:1527272284376};\\\", \\\"{x:1371,y:684,t:1527272284393};\\\", \\\"{x:1362,y:686,t:1527272284411};\\\", \\\"{x:1352,y:709,t:1527272284427};\\\", \\\"{x:1347,y:717,t:1527272284443};\\\", \\\"{x:1344,y:720,t:1527272284460};\\\", \\\"{x:1342,y:720,t:1527272284476};\\\", \\\"{x:1340,y:720,t:1527272284493};\\\", \\\"{x:1337,y:720,t:1527272284547};\\\", \\\"{x:1336,y:717,t:1527272284560};\\\", \\\"{x:1334,y:708,t:1527272284577};\\\", \\\"{x:1332,y:702,t:1527272284594};\\\", \\\"{x:1331,y:699,t:1527272284610};\\\", \\\"{x:1331,y:704,t:1527272284675};\\\", \\\"{x:1331,y:711,t:1527272284682};\\\", \\\"{x:1331,y:719,t:1527272284695};\\\", \\\"{x:1333,y:734,t:1527272284711};\\\", \\\"{x:1338,y:747,t:1527272284727};\\\", \\\"{x:1342,y:756,t:1527272284745};\\\", \\\"{x:1345,y:763,t:1527272284764};\\\", \\\"{x:1346,y:765,t:1527272284777};\\\", \\\"{x:1347,y:766,t:1527272284922};\\\", \\\"{x:1347,y:765,t:1527272284929};\\\", \\\"{x:1347,y:762,t:1527272284945};\\\", \\\"{x:1347,y:755,t:1527272284962};\\\", \\\"{x:1347,y:737,t:1527272284979};\\\", \\\"{x:1347,y:726,t:1527272284994};\\\", \\\"{x:1347,y:718,t:1527272285011};\\\", \\\"{x:1345,y:714,t:1527272285027};\\\", \\\"{x:1345,y:713,t:1527272285045};\\\", \\\"{x:1345,y:712,t:1527272285061};\\\", \\\"{x:1345,y:711,t:1527272285082};\\\", \\\"{x:1345,y:714,t:1527272285163};\\\", \\\"{x:1346,y:732,t:1527272285178};\\\", \\\"{x:1346,y:748,t:1527272285196};\\\", \\\"{x:1346,y:757,t:1527272285212};\\\", \\\"{x:1346,y:764,t:1527272285230};\\\", \\\"{x:1346,y:770,t:1527272285247};\\\", \\\"{x:1346,y:772,t:1527272285262};\\\", \\\"{x:1346,y:774,t:1527272285279};\\\", \\\"{x:1346,y:767,t:1527272285323};\\\", \\\"{x:1346,y:741,t:1527272285348};\\\", \\\"{x:1346,y:723,t:1527272285363};\\\", \\\"{x:1346,y:710,t:1527272285379};\\\", \\\"{x:1346,y:705,t:1527272285397};\\\", \\\"{x:1346,y:703,t:1527272285414};\\\", \\\"{x:1346,y:706,t:1527272285515};\\\", \\\"{x:1346,y:717,t:1527272285531};\\\", \\\"{x:1346,y:726,t:1527272285547};\\\", \\\"{x:1346,y:733,t:1527272285563};\\\", \\\"{x:1346,y:737,t:1527272285580};\\\", \\\"{x:1346,y:740,t:1527272285597};\\\", \\\"{x:1346,y:731,t:1527272285691};\\\", \\\"{x:1345,y:725,t:1527272285700};\\\", \\\"{x:1343,y:715,t:1527272285714};\\\", \\\"{x:1343,y:710,t:1527272285730};\\\", \\\"{x:1342,y:708,t:1527272285747};\\\", \\\"{x:1343,y:705,t:1527272290010};\\\", \\\"{x:1362,y:704,t:1527272290027};\\\", \\\"{x:1373,y:701,t:1527272290044};\\\", \\\"{x:1387,y:698,t:1527272290061};\\\", \\\"{x:1403,y:694,t:1527272290077};\\\", \\\"{x:1408,y:691,t:1527272290094};\\\", \\\"{x:1412,y:689,t:1527272290111};\\\", \\\"{x:1415,y:687,t:1527272290128};\\\", \\\"{x:1424,y:682,t:1527272290144};\\\", \\\"{x:1442,y:675,t:1527272290160};\\\", \\\"{x:1478,y:666,t:1527272290178};\\\", \\\"{x:1499,y:659,t:1527272290194};\\\", \\\"{x:1511,y:656,t:1527272290211};\\\", \\\"{x:1516,y:655,t:1527272290228};\\\", \\\"{x:1517,y:654,t:1527272290245};\\\", \\\"{x:1518,y:653,t:1527272290314};\\\", \\\"{x:1518,y:652,t:1527272290328};\\\", \\\"{x:1509,y:650,t:1527272290346};\\\", \\\"{x:1488,y:650,t:1527272290362};\\\", \\\"{x:1477,y:650,t:1527272290378};\\\", \\\"{x:1471,y:650,t:1527272290395};\\\", \\\"{x:1459,y:650,t:1527272290412};\\\", \\\"{x:1449,y:650,t:1527272290430};\\\", \\\"{x:1447,y:650,t:1527272290446};\\\", \\\"{x:1446,y:650,t:1527272290462};\\\", \\\"{x:1445,y:650,t:1527272290523};\\\", \\\"{x:1445,y:649,t:1527272290531};\\\", \\\"{x:1445,y:647,t:1527272290547};\\\", \\\"{x:1444,y:645,t:1527272290562};\\\", \\\"{x:1442,y:643,t:1527272290580};\\\", \\\"{x:1440,y:645,t:1527272290803};\\\", \\\"{x:1440,y:649,t:1527272290814};\\\", \\\"{x:1440,y:654,t:1527272290830};\\\", \\\"{x:1439,y:662,t:1527272290847};\\\", \\\"{x:1438,y:670,t:1527272290864};\\\", \\\"{x:1438,y:687,t:1527272290881};\\\", \\\"{x:1438,y:709,t:1527272290898};\\\", \\\"{x:1438,y:729,t:1527272290914};\\\", \\\"{x:1441,y:741,t:1527272290931};\\\", \\\"{x:1441,y:742,t:1527272290947};\\\", \\\"{x:1441,y:746,t:1527272290965};\\\", \\\"{x:1441,y:749,t:1527272290980};\\\", \\\"{x:1440,y:754,t:1527272290998};\\\", \\\"{x:1440,y:758,t:1527272291014};\\\", \\\"{x:1439,y:762,t:1527272291030};\\\", \\\"{x:1439,y:764,t:1527272291048};\\\", \\\"{x:1439,y:767,t:1527272291065};\\\", \\\"{x:1439,y:772,t:1527272291082};\\\", \\\"{x:1439,y:778,t:1527272291098};\\\", \\\"{x:1443,y:790,t:1527272291114};\\\", \\\"{x:1445,y:795,t:1527272291132};\\\", \\\"{x:1448,y:800,t:1527272291147};\\\", \\\"{x:1449,y:802,t:1527272291164};\\\", \\\"{x:1451,y:802,t:1527272291182};\\\", \\\"{x:1452,y:802,t:1527272291199};\\\", \\\"{x:1453,y:802,t:1527272291267};\\\", \\\"{x:1453,y:799,t:1527272291282};\\\", \\\"{x:1455,y:786,t:1527272291300};\\\", \\\"{x:1458,y:771,t:1527272291315};\\\", \\\"{x:1462,y:759,t:1527272291331};\\\", \\\"{x:1466,y:747,t:1527272291348};\\\", \\\"{x:1467,y:736,t:1527272291365};\\\", \\\"{x:1467,y:725,t:1527272291382};\\\", \\\"{x:1467,y:707,t:1527272291398};\\\", \\\"{x:1467,y:693,t:1527272291415};\\\", \\\"{x:1471,y:682,t:1527272291432};\\\", \\\"{x:1473,y:674,t:1527272291448};\\\", \\\"{x:1474,y:670,t:1527272291466};\\\", \\\"{x:1475,y:669,t:1527272291482};\\\", \\\"{x:1475,y:666,t:1527272291502};\\\", \\\"{x:1476,y:659,t:1527272291515};\\\", \\\"{x:1479,y:652,t:1527272291531};\\\", \\\"{x:1480,y:648,t:1527272291549};\\\", \\\"{x:1480,y:646,t:1527272291565};\\\", \\\"{x:1480,y:645,t:1527272291582};\\\", \\\"{x:1480,y:644,t:1527272291599};\\\", \\\"{x:1480,y:643,t:1527272291625};\\\", \\\"{x:1480,y:642,t:1527272291642};\\\", \\\"{x:1480,y:641,t:1527272291649};\\\", \\\"{x:1480,y:640,t:1527272291665};\\\", \\\"{x:1481,y:639,t:1527272291714};\\\", \\\"{x:1482,y:639,t:1527272291722};\\\", \\\"{x:1483,y:638,t:1527272291733};\\\", \\\"{x:1484,y:637,t:1527272291749};\\\", \\\"{x:1485,y:637,t:1527272291851};\\\", \\\"{x:1486,y:636,t:1527272291923};\\\", \\\"{x:1488,y:634,t:1527272291938};\\\", \\\"{x:1488,y:633,t:1527272291951};\\\", \\\"{x:1489,y:627,t:1527272291968};\\\", \\\"{x:1489,y:623,t:1527272291983};\\\", \\\"{x:1489,y:620,t:1527272292001};\\\", \\\"{x:1489,y:621,t:1527272292154};\\\", \\\"{x:1488,y:624,t:1527272292167};\\\", \\\"{x:1485,y:632,t:1527272292185};\\\", \\\"{x:1481,y:641,t:1527272292201};\\\", \\\"{x:1479,y:646,t:1527272292218};\\\", \\\"{x:1478,y:652,t:1527272292235};\\\", \\\"{x:1477,y:653,t:1527272292251};\\\", \\\"{x:1477,y:657,t:1527272292269};\\\", \\\"{x:1474,y:665,t:1527272292284};\\\", \\\"{x:1473,y:670,t:1527272292301};\\\", \\\"{x:1472,y:676,t:1527272292318};\\\", \\\"{x:1472,y:682,t:1527272292336};\\\", \\\"{x:1472,y:686,t:1527272292352};\\\", \\\"{x:1472,y:688,t:1527272292368};\\\", \\\"{x:1472,y:690,t:1527272292385};\\\", \\\"{x:1472,y:696,t:1527272292402};\\\", \\\"{x:1474,y:711,t:1527272292418};\\\", \\\"{x:1477,y:721,t:1527272292436};\\\", \\\"{x:1479,y:728,t:1527272292452};\\\", \\\"{x:1482,y:735,t:1527272292468};\\\", \\\"{x:1483,y:741,t:1527272292485};\\\", \\\"{x:1483,y:749,t:1527272292503};\\\", \\\"{x:1487,y:760,t:1527272292519};\\\", \\\"{x:1488,y:771,t:1527272292536};\\\", \\\"{x:1492,y:784,t:1527272292553};\\\", \\\"{x:1494,y:794,t:1527272292569};\\\", \\\"{x:1494,y:803,t:1527272292586};\\\", \\\"{x:1494,y:821,t:1527272292603};\\\", \\\"{x:1494,y:834,t:1527272292620};\\\", \\\"{x:1490,y:845,t:1527272292637};\\\", \\\"{x:1488,y:852,t:1527272292652};\\\", \\\"{x:1487,y:856,t:1527272292670};\\\", \\\"{x:1487,y:857,t:1527272292687};\\\", \\\"{x:1486,y:853,t:1527272292779};\\\", \\\"{x:1486,y:849,t:1527272292786};\\\", \\\"{x:1486,y:833,t:1527272292803};\\\", \\\"{x:1486,y:813,t:1527272292820};\\\", \\\"{x:1486,y:796,t:1527272292837};\\\", \\\"{x:1486,y:781,t:1527272292853};\\\", \\\"{x:1489,y:764,t:1527272292870};\\\", \\\"{x:1490,y:748,t:1527272292887};\\\", \\\"{x:1492,y:736,t:1527272292903};\\\", \\\"{x:1492,y:720,t:1527272292921};\\\", \\\"{x:1492,y:711,t:1527272292937};\\\", \\\"{x:1495,y:700,t:1527272292954};\\\", \\\"{x:1500,y:687,t:1527272292970};\\\", \\\"{x:1504,y:679,t:1527272292987};\\\", \\\"{x:1507,y:672,t:1527272293004};\\\", \\\"{x:1508,y:668,t:1527272293021};\\\", \\\"{x:1508,y:666,t:1527272293037};\\\", \\\"{x:1510,y:664,t:1527272293055};\\\", \\\"{x:1511,y:663,t:1527272293070};\\\", \\\"{x:1512,y:663,t:1527272293088};\\\", \\\"{x:1513,y:662,t:1527272293104};\\\", \\\"{x:1513,y:669,t:1527272293130};\\\", \\\"{x:1513,y:682,t:1527272293139};\\\", \\\"{x:1513,y:723,t:1527272293155};\\\", \\\"{x:1513,y:771,t:1527272293170};\\\", \\\"{x:1513,y:798,t:1527272293188};\\\", \\\"{x:1513,y:812,t:1527272293205};\\\", \\\"{x:1514,y:822,t:1527272293222};\\\", \\\"{x:1519,y:835,t:1527272293238};\\\", \\\"{x:1523,y:851,t:1527272293255};\\\", \\\"{x:1526,y:862,t:1527272293271};\\\", \\\"{x:1530,y:870,t:1527272293288};\\\", \\\"{x:1530,y:872,t:1527272293305};\\\", \\\"{x:1530,y:873,t:1527272293322};\\\", \\\"{x:1530,y:870,t:1527272293379};\\\", \\\"{x:1536,y:859,t:1527272293388};\\\", \\\"{x:1551,y:827,t:1527272293406};\\\", \\\"{x:1569,y:785,t:1527272293421};\\\", \\\"{x:1588,y:746,t:1527272293439};\\\", \\\"{x:1595,y:726,t:1527272293456};\\\", \\\"{x:1601,y:714,t:1527272293471};\\\", \\\"{x:1603,y:705,t:1527272293489};\\\", \\\"{x:1604,y:696,t:1527272293505};\\\", \\\"{x:1605,y:678,t:1527272293522};\\\", \\\"{x:1605,y:668,t:1527272293539};\\\", \\\"{x:1605,y:662,t:1527272293555};\\\", \\\"{x:1606,y:659,t:1527272293572};\\\", \\\"{x:1606,y:658,t:1527272293589};\\\", \\\"{x:1606,y:656,t:1527272293605};\\\", \\\"{x:1606,y:653,t:1527272293622};\\\", \\\"{x:1604,y:650,t:1527272293639};\\\", \\\"{x:1600,y:647,t:1527272293655};\\\", \\\"{x:1599,y:647,t:1527272293672};\\\", \\\"{x:1599,y:645,t:1527272293689};\\\", \\\"{x:1599,y:639,t:1527272293705};\\\", \\\"{x:1599,y:634,t:1527272293722};\\\", \\\"{x:1597,y:631,t:1527272293739};\\\", \\\"{x:1596,y:630,t:1527272293756};\\\", \\\"{x:1595,y:630,t:1527272293850};\\\", \\\"{x:1593,y:630,t:1527272293865};\\\", \\\"{x:1590,y:633,t:1527272293874};\\\", \\\"{x:1588,y:640,t:1527272293889};\\\", \\\"{x:1584,y:667,t:1527272293906};\\\", \\\"{x:1583,y:683,t:1527272293923};\\\", \\\"{x:1582,y:699,t:1527272293940};\\\", \\\"{x:1582,y:714,t:1527272293956};\\\", \\\"{x:1583,y:736,t:1527272293973};\\\", \\\"{x:1590,y:757,t:1527272293990};\\\", \\\"{x:1595,y:779,t:1527272294006};\\\", \\\"{x:1598,y:800,t:1527272294022};\\\", \\\"{x:1598,y:807,t:1527272294040};\\\", \\\"{x:1600,y:811,t:1527272294057};\\\", \\\"{x:1601,y:813,t:1527272294073};\\\", \\\"{x:1604,y:820,t:1527272294090};\\\", \\\"{x:1608,y:830,t:1527272294108};\\\", \\\"{x:1611,y:845,t:1527272294124};\\\", \\\"{x:1615,y:857,t:1527272294140};\\\", \\\"{x:1619,y:866,t:1527272294157};\\\", \\\"{x:1621,y:872,t:1527272294174};\\\", \\\"{x:1622,y:876,t:1527272294190};\\\", \\\"{x:1624,y:885,t:1527272294207};\\\", \\\"{x:1625,y:893,t:1527272294225};\\\", \\\"{x:1625,y:906,t:1527272294241};\\\", \\\"{x:1627,y:913,t:1527272294257};\\\", \\\"{x:1627,y:915,t:1527272294274};\\\", \\\"{x:1627,y:917,t:1527272294291};\\\", \\\"{x:1627,y:920,t:1527272294307};\\\", \\\"{x:1627,y:928,t:1527272294324};\\\", \\\"{x:1626,y:935,t:1527272294341};\\\", \\\"{x:1625,y:942,t:1527272294358};\\\", \\\"{x:1624,y:946,t:1527272294374};\\\", \\\"{x:1623,y:945,t:1527272294451};\\\", \\\"{x:1622,y:935,t:1527272294459};\\\", \\\"{x:1617,y:903,t:1527272294476};\\\", \\\"{x:1617,y:858,t:1527272294491};\\\", \\\"{x:1616,y:829,t:1527272294509};\\\", \\\"{x:1615,y:816,t:1527272294525};\\\", \\\"{x:1612,y:805,t:1527272294542};\\\", \\\"{x:1611,y:801,t:1527272294559};\\\", \\\"{x:1611,y:800,t:1527272294586};\\\", \\\"{x:1611,y:798,t:1527272294594};\\\", \\\"{x:1611,y:797,t:1527272294608};\\\", \\\"{x:1611,y:790,t:1527272294626};\\\", \\\"{x:1608,y:775,t:1527272294642};\\\", \\\"{x:1608,y:769,t:1527272294659};\\\", \\\"{x:1608,y:762,t:1527272294675};\\\", \\\"{x:1608,y:756,t:1527272294693};\\\", \\\"{x:1608,y:752,t:1527272294709};\\\", \\\"{x:1608,y:748,t:1527272294726};\\\", \\\"{x:1608,y:743,t:1527272294742};\\\", \\\"{x:1609,y:747,t:1527272294843};\\\", \\\"{x:1616,y:775,t:1527272294859};\\\", \\\"{x:1622,y:796,t:1527272294876};\\\", \\\"{x:1628,y:810,t:1527272294893};\\\", \\\"{x:1635,y:828,t:1527272294909};\\\", \\\"{x:1646,y:851,t:1527272294926};\\\", \\\"{x:1656,y:877,t:1527272294943};\\\", \\\"{x:1667,y:900,t:1527272294960};\\\", \\\"{x:1676,y:915,t:1527272294976};\\\", \\\"{x:1685,y:922,t:1527272294993};\\\", \\\"{x:1689,y:923,t:1527272295010};\\\", \\\"{x:1690,y:923,t:1527272295026};\\\", \\\"{x:1693,y:923,t:1527272295043};\\\", \\\"{x:1698,y:914,t:1527272295060};\\\", \\\"{x:1709,y:889,t:1527272295077};\\\", \\\"{x:1721,y:865,t:1527272295093};\\\", \\\"{x:1727,y:847,t:1527272295110};\\\", \\\"{x:1732,y:837,t:1527272295127};\\\", \\\"{x:1732,y:836,t:1527272295144};\\\", \\\"{x:1732,y:840,t:1527272295195};\\\", \\\"{x:1736,y:863,t:1527272295211};\\\", \\\"{x:1743,y:886,t:1527272295227};\\\", \\\"{x:1754,y:902,t:1527272295244};\\\", \\\"{x:1766,y:913,t:1527272295261};\\\", \\\"{x:1772,y:914,t:1527272295277};\\\", \\\"{x:1776,y:914,t:1527272295294};\\\", \\\"{x:1780,y:914,t:1527272295311};\\\", \\\"{x:1787,y:907,t:1527272295327};\\\", \\\"{x:1794,y:894,t:1527272295345};\\\", \\\"{x:1799,y:884,t:1527272295362};\\\", \\\"{x:1799,y:881,t:1527272295378};\\\", \\\"{x:1799,y:887,t:1527272295410};\\\", \\\"{x:1793,y:906,t:1527272295429};\\\", \\\"{x:1763,y:941,t:1527272295444};\\\", \\\"{x:1698,y:989,t:1527272295461};\\\", \\\"{x:1611,y:1006,t:1527272295478};\\\", \\\"{x:1524,y:1011,t:1527272295495};\\\", \\\"{x:1434,y:1011,t:1527272295511};\\\", \\\"{x:1333,y:970,t:1527272295528};\\\", \\\"{x:1265,y:934,t:1527272295546};\\\", \\\"{x:1223,y:914,t:1527272295562};\\\", \\\"{x:1186,y:891,t:1527272295578};\\\", \\\"{x:1173,y:877,t:1527272295596};\\\", \\\"{x:1168,y:863,t:1527272295613};\\\", \\\"{x:1166,y:842,t:1527272295629};\\\", \\\"{x:1166,y:820,t:1527272295646};\\\", \\\"{x:1166,y:804,t:1527272295663};\\\", \\\"{x:1166,y:793,t:1527272295679};\\\", \\\"{x:1166,y:787,t:1527272295696};\\\", \\\"{x:1170,y:777,t:1527272295712};\\\", \\\"{x:1176,y:768,t:1527272295729};\\\", \\\"{x:1177,y:758,t:1527272295745};\\\", \\\"{x:1178,y:748,t:1527272295762};\\\", \\\"{x:1178,y:747,t:1527272295779};\\\", \\\"{x:1178,y:753,t:1527272295843};\\\", \\\"{x:1178,y:773,t:1527272295851};\\\", \\\"{x:1178,y:801,t:1527272295863};\\\", \\\"{x:1180,y:844,t:1527272295879};\\\", \\\"{x:1180,y:872,t:1527272295896};\\\", \\\"{x:1182,y:898,t:1527272295914};\\\", \\\"{x:1186,y:921,t:1527272295930};\\\", \\\"{x:1191,y:936,t:1527272295946};\\\", \\\"{x:1193,y:938,t:1527272295964};\\\", \\\"{x:1195,y:941,t:1527272295980};\\\", \\\"{x:1196,y:944,t:1527272295996};\\\", \\\"{x:1197,y:945,t:1527272296013};\\\", \\\"{x:1197,y:946,t:1527272296031};\\\", \\\"{x:1199,y:950,t:1527272296047};\\\", \\\"{x:1201,y:953,t:1527272296063};\\\", \\\"{x:1209,y:953,t:1527272296080};\\\", \\\"{x:1223,y:948,t:1527272296097};\\\", \\\"{x:1235,y:940,t:1527272296114};\\\", \\\"{x:1269,y:910,t:1527272296130};\\\", \\\"{x:1294,y:878,t:1527272296148};\\\", \\\"{x:1314,y:848,t:1527272296164};\\\", \\\"{x:1324,y:829,t:1527272296180};\\\", \\\"{x:1328,y:816,t:1527272296198};\\\", \\\"{x:1328,y:788,t:1527272296214};\\\", \\\"{x:1305,y:740,t:1527272296231};\\\", \\\"{x:1297,y:724,t:1527272296248};\\\", \\\"{x:1297,y:722,t:1527272296265};\\\", \\\"{x:1298,y:722,t:1527272296338};\\\", \\\"{x:1300,y:722,t:1527272296347};\\\", \\\"{x:1302,y:722,t:1527272296365};\\\", \\\"{x:1304,y:722,t:1527272296381};\\\", \\\"{x:1306,y:722,t:1527272296397};\\\", \\\"{x:1307,y:722,t:1527272296426};\\\", \\\"{x:1305,y:728,t:1527272296442};\\\", \\\"{x:1301,y:731,t:1527272296450};\\\", \\\"{x:1293,y:737,t:1527272296465};\\\", \\\"{x:1276,y:743,t:1527272296482};\\\", \\\"{x:1253,y:752,t:1527272296499};\\\", \\\"{x:1240,y:753,t:1527272296514};\\\", \\\"{x:1221,y:758,t:1527272296532};\\\", \\\"{x:1177,y:772,t:1527272296549};\\\", \\\"{x:1099,y:794,t:1527272296566};\\\", \\\"{x:1019,y:816,t:1527272296581};\\\", \\\"{x:935,y:829,t:1527272296598};\\\", \\\"{x:842,y:837,t:1527272296615};\\\", \\\"{x:805,y:844,t:1527272296631};\\\", \\\"{x:796,y:847,t:1527272296649};\\\", \\\"{x:794,y:847,t:1527272296665};\\\", \\\"{x:791,y:848,t:1527272296682};\\\", \\\"{x:789,y:848,t:1527272296706};\\\", \\\"{x:788,y:848,t:1527272296722};\\\", \\\"{x:786,y:848,t:1527272296738};\\\", \\\"{x:783,y:847,t:1527272296749};\\\", \\\"{x:769,y:838,t:1527272296765};\\\", \\\"{x:738,y:827,t:1527272296782};\\\", \\\"{x:699,y:815,t:1527272296799};\\\", \\\"{x:676,y:810,t:1527272296815};\\\", \\\"{x:656,y:806,t:1527272296832};\\\", \\\"{x:636,y:804,t:1527272296849};\\\", \\\"{x:610,y:800,t:1527272296866};\\\", \\\"{x:602,y:799,t:1527272296882};\\\", \\\"{x:594,y:797,t:1527272296902};\\\", \\\"{x:578,y:791,t:1527272296916};\\\", \\\"{x:554,y:786,t:1527272296933};\\\", \\\"{x:518,y:781,t:1527272296949};\\\", \\\"{x:500,y:778,t:1527272296967};\\\", \\\"{x:494,y:775,t:1527272296983};\\\", \\\"{x:490,y:772,t:1527272296999};\\\", \\\"{x:487,y:763,t:1527272297017};\\\", \\\"{x:486,y:757,t:1527272297034};\\\", \\\"{x:485,y:755,t:1527272297049};\\\", \\\"{x:485,y:754,t:1527272297068};\\\", \\\"{x:486,y:751,t:1527272297082};\\\", \\\"{x:491,y:747,t:1527272297100};\\\", \\\"{x:494,y:744,t:1527272297118};\\\", \\\"{x:494,y:743,t:1527272297137};\\\", \\\"{x:495,y:742,t:1527272297177};\\\", \\\"{x:497,y:740,t:1527272297835};\\\", \\\"{x:499,y:740,t:1527272297851};\\\", \\\"{x:500,y:739,t:1527272297867};\\\", \\\"{x:502,y:738,t:1527272297885};\\\", \\\"{x:503,y:737,t:1527272297902};\\\" ] }, { \\\"rt\\\": 94929, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 985865, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -F -E -E -X -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:732,t:1527272300682};\\\", \\\"{x:501,y:715,t:1527272300690};\\\", \\\"{x:483,y:686,t:1527272300707};\\\", \\\"{x:471,y:667,t:1527272300721};\\\", \\\"{x:453,y:646,t:1527272300738};\\\", \\\"{x:437,y:628,t:1527272300754};\\\", \\\"{x:425,y:612,t:1527272300771};\\\", \\\"{x:419,y:604,t:1527272300787};\\\", \\\"{x:418,y:602,t:1527272300804};\\\", \\\"{x:417,y:602,t:1527272300821};\\\", \\\"{x:418,y:602,t:1527272301227};\\\", \\\"{x:420,y:602,t:1527272301242};\\\", \\\"{x:421,y:602,t:1527272301255};\\\", \\\"{x:426,y:600,t:1527272301273};\\\", \\\"{x:429,y:594,t:1527272301288};\\\", \\\"{x:430,y:580,t:1527272301306};\\\", \\\"{x:430,y:569,t:1527272301321};\\\", \\\"{x:426,y:558,t:1527272301338};\\\", \\\"{x:421,y:551,t:1527272301356};\\\", \\\"{x:414,y:544,t:1527272301372};\\\", \\\"{x:410,y:542,t:1527272301387};\\\", \\\"{x:408,y:540,t:1527272301405};\\\", \\\"{x:409,y:540,t:1527272301571};\\\", \\\"{x:412,y:539,t:1527272301577};\\\", \\\"{x:413,y:539,t:1527272301589};\\\", \\\"{x:423,y:539,t:1527272301606};\\\", \\\"{x:438,y:539,t:1527272301620};\\\", \\\"{x:456,y:539,t:1527272301638};\\\", \\\"{x:483,y:540,t:1527272301655};\\\", \\\"{x:513,y:543,t:1527272301673};\\\", \\\"{x:561,y:543,t:1527272301688};\\\", \\\"{x:653,y:543,t:1527272301706};\\\", \\\"{x:731,y:543,t:1527272301723};\\\", \\\"{x:822,y:543,t:1527272301739};\\\", \\\"{x:925,y:543,t:1527272301755};\\\", \\\"{x:1011,y:543,t:1527272301773};\\\", \\\"{x:1094,y:543,t:1527272301789};\\\", \\\"{x:1180,y:543,t:1527272301806};\\\", \\\"{x:1269,y:554,t:1527272301823};\\\", \\\"{x:1337,y:566,t:1527272301839};\\\", \\\"{x:1384,y:572,t:1527272301855};\\\", \\\"{x:1421,y:577,t:1527272301873};\\\", \\\"{x:1454,y:580,t:1527272301890};\\\", \\\"{x:1460,y:580,t:1527272301905};\\\", \\\"{x:1462,y:580,t:1527272301923};\\\", \\\"{x:1462,y:584,t:1527272308507};\\\", \\\"{x:1457,y:596,t:1527272308514};\\\", \\\"{x:1453,y:606,t:1527272308528};\\\", \\\"{x:1441,y:629,t:1527272308544};\\\", \\\"{x:1434,y:645,t:1527272308561};\\\", \\\"{x:1429,y:655,t:1527272308578};\\\", \\\"{x:1427,y:658,t:1527272308595};\\\", \\\"{x:1426,y:662,t:1527272308611};\\\", \\\"{x:1421,y:670,t:1527272308628};\\\", \\\"{x:1418,y:673,t:1527272308644};\\\", \\\"{x:1413,y:679,t:1527272308661};\\\", \\\"{x:1409,y:684,t:1527272308678};\\\", \\\"{x:1401,y:693,t:1527272308694};\\\", \\\"{x:1390,y:704,t:1527272308711};\\\", \\\"{x:1379,y:717,t:1527272308728};\\\", \\\"{x:1369,y:728,t:1527272308744};\\\", \\\"{x:1361,y:738,t:1527272308761};\\\", \\\"{x:1349,y:753,t:1527272308778};\\\", \\\"{x:1345,y:761,t:1527272308797};\\\", \\\"{x:1341,y:770,t:1527272308810};\\\", \\\"{x:1340,y:773,t:1527272308828};\\\", \\\"{x:1340,y:772,t:1527272309202};\\\", \\\"{x:1340,y:769,t:1527272309211};\\\", \\\"{x:1339,y:762,t:1527272309228};\\\", \\\"{x:1339,y:756,t:1527272309246};\\\", \\\"{x:1337,y:752,t:1527272309261};\\\", \\\"{x:1336,y:749,t:1527272309278};\\\", \\\"{x:1336,y:748,t:1527272309338};\\\", \\\"{x:1335,y:748,t:1527272309346};\\\", \\\"{x:1333,y:763,t:1527272309362};\\\", \\\"{x:1330,y:780,t:1527272309378};\\\", \\\"{x:1330,y:787,t:1527272309394};\\\", \\\"{x:1330,y:792,t:1527272309412};\\\", \\\"{x:1329,y:797,t:1527272309429};\\\", \\\"{x:1329,y:800,t:1527272309445};\\\", \\\"{x:1329,y:801,t:1527272309461};\\\", \\\"{x:1330,y:802,t:1527272309482};\\\", \\\"{x:1330,y:800,t:1527272309559};\\\", \\\"{x:1330,y:798,t:1527272309566};\\\", \\\"{x:1331,y:791,t:1527272309583};\\\", \\\"{x:1333,y:777,t:1527272309599};\\\", \\\"{x:1334,y:766,t:1527272309617};\\\", \\\"{x:1335,y:763,t:1527272309633};\\\", \\\"{x:1336,y:760,t:1527272309651};\\\", \\\"{x:1338,y:760,t:1527272321207};\\\", \\\"{x:1341,y:761,t:1527272321225};\\\", \\\"{x:1344,y:762,t:1527272321242};\\\", \\\"{x:1349,y:763,t:1527272321257};\\\", \\\"{x:1356,y:765,t:1527272321275};\\\", \\\"{x:1365,y:768,t:1527272321291};\\\", \\\"{x:1369,y:768,t:1527272321307};\\\", \\\"{x:1371,y:768,t:1527272321324};\\\", \\\"{x:1373,y:768,t:1527272321365};\\\", \\\"{x:1370,y:768,t:1527272321527};\\\", \\\"{x:1365,y:769,t:1527272321542};\\\", \\\"{x:1358,y:772,t:1527272321558};\\\", \\\"{x:1352,y:775,t:1527272321574};\\\", \\\"{x:1350,y:775,t:1527272321592};\\\", \\\"{x:1349,y:776,t:1527272321609};\\\", \\\"{x:1348,y:776,t:1527272321927};\\\", \\\"{x:1345,y:769,t:1527272321942};\\\", \\\"{x:1343,y:764,t:1527272321960};\\\", \\\"{x:1341,y:762,t:1527272321976};\\\", \\\"{x:1340,y:761,t:1527272321992};\\\", \\\"{x:1339,y:760,t:1527272322009};\\\", \\\"{x:1340,y:760,t:1527272326822};\\\", \\\"{x:1342,y:760,t:1527272326830};\\\", \\\"{x:1343,y:760,t:1527272326847};\\\", \\\"{x:1344,y:761,t:1527272326909};\\\", \\\"{x:1338,y:761,t:1527272354503};\\\", \\\"{x:1320,y:761,t:1527272354516};\\\", \\\"{x:1244,y:761,t:1527272354533};\\\", \\\"{x:1060,y:737,t:1527272354550};\\\", \\\"{x:930,y:718,t:1527272354566};\\\", \\\"{x:808,y:699,t:1527272354583};\\\", \\\"{x:689,y:683,t:1527272354600};\\\", \\\"{x:572,y:666,t:1527272354615};\\\", \\\"{x:526,y:656,t:1527272354632};\\\", \\\"{x:524,y:654,t:1527272354650};\\\", \\\"{x:525,y:654,t:1527272354693};\\\", \\\"{x:519,y:654,t:1527272355021};\\\", \\\"{x:509,y:651,t:1527272355032};\\\", \\\"{x:479,y:643,t:1527272355050};\\\", \\\"{x:457,y:640,t:1527272355066};\\\", \\\"{x:450,y:638,t:1527272355083};\\\", \\\"{x:445,y:636,t:1527272355103};\\\", \\\"{x:442,y:630,t:1527272355119};\\\", \\\"{x:431,y:619,t:1527272355135};\\\", \\\"{x:421,y:610,t:1527272355152};\\\", \\\"{x:414,y:605,t:1527272355169};\\\", \\\"{x:413,y:605,t:1527272355185};\\\", \\\"{x:411,y:604,t:1527272355202};\\\", \\\"{x:411,y:603,t:1527272355220};\\\", \\\"{x:411,y:602,t:1527272355269};\\\", \\\"{x:410,y:601,t:1527272355285};\\\", \\\"{x:407,y:598,t:1527272355302};\\\", \\\"{x:404,y:595,t:1527272355320};\\\", \\\"{x:403,y:595,t:1527272355335};\\\", \\\"{x:403,y:594,t:1527272355365};\\\", \\\"{x:403,y:593,t:1527272355373};\\\", \\\"{x:403,y:592,t:1527272355386};\\\", \\\"{x:401,y:589,t:1527272355403};\\\", \\\"{x:399,y:588,t:1527272355419};\\\", \\\"{x:397,y:585,t:1527272355436};\\\", \\\"{x:394,y:584,t:1527272355453};\\\", \\\"{x:392,y:584,t:1527272355469};\\\", \\\"{x:391,y:582,t:1527272355487};\\\", \\\"{x:387,y:580,t:1527272355502};\\\", \\\"{x:376,y:573,t:1527272355519};\\\", \\\"{x:357,y:568,t:1527272355537};\\\", \\\"{x:342,y:563,t:1527272355552};\\\", \\\"{x:335,y:561,t:1527272355569};\\\", \\\"{x:334,y:561,t:1527272355586};\\\", \\\"{x:335,y:559,t:1527272355612};\\\", \\\"{x:330,y:559,t:1527272355685};\\\", \\\"{x:322,y:565,t:1527272355694};\\\", \\\"{x:315,y:570,t:1527272355702};\\\", \\\"{x:300,y:576,t:1527272355720};\\\", \\\"{x:285,y:581,t:1527272355736};\\\", \\\"{x:271,y:581,t:1527272355753};\\\", \\\"{x:268,y:581,t:1527272355769};\\\", \\\"{x:267,y:582,t:1527272355829};\\\", \\\"{x:267,y:583,t:1527272355836};\\\", \\\"{x:262,y:585,t:1527272355852};\\\", \\\"{x:256,y:587,t:1527272355869};\\\", \\\"{x:255,y:588,t:1527272355887};\\\", \\\"{x:252,y:588,t:1527272355903};\\\", \\\"{x:245,y:588,t:1527272355919};\\\", \\\"{x:233,y:594,t:1527272355937};\\\", \\\"{x:219,y:598,t:1527272355953};\\\", \\\"{x:209,y:599,t:1527272355969};\\\", \\\"{x:203,y:599,t:1527272355986};\\\", \\\"{x:198,y:595,t:1527272356003};\\\", \\\"{x:194,y:587,t:1527272356020};\\\", \\\"{x:193,y:582,t:1527272356037};\\\", \\\"{x:193,y:579,t:1527272356053};\\\", \\\"{x:207,y:570,t:1527272356069};\\\", \\\"{x:235,y:566,t:1527272356086};\\\", \\\"{x:323,y:572,t:1527272356104};\\\", \\\"{x:419,y:578,t:1527272356119};\\\", \\\"{x:500,y:582,t:1527272356137};\\\", \\\"{x:559,y:582,t:1527272356153};\\\", \\\"{x:604,y:582,t:1527272356170};\\\", \\\"{x:626,y:582,t:1527272356186};\\\", \\\"{x:634,y:582,t:1527272356203};\\\", \\\"{x:640,y:582,t:1527272356219};\\\", \\\"{x:641,y:582,t:1527272356236};\\\", \\\"{x:642,y:581,t:1527272356278};\\\", \\\"{x:645,y:581,t:1527272356287};\\\", \\\"{x:655,y:575,t:1527272356304};\\\", \\\"{x:675,y:566,t:1527272356319};\\\", \\\"{x:691,y:560,t:1527272356337};\\\", \\\"{x:704,y:556,t:1527272356354};\\\", \\\"{x:708,y:553,t:1527272356370};\\\", \\\"{x:709,y:552,t:1527272356387};\\\", \\\"{x:710,y:551,t:1527272356403};\\\", \\\"{x:711,y:551,t:1527272356436};\\\", \\\"{x:713,y:550,t:1527272356461};\\\", \\\"{x:716,y:548,t:1527272356470};\\\", \\\"{x:728,y:544,t:1527272356487};\\\", \\\"{x:751,y:538,t:1527272356504};\\\", \\\"{x:774,y:535,t:1527272356521};\\\", \\\"{x:788,y:530,t:1527272356537};\\\", \\\"{x:797,y:525,t:1527272356553};\\\", \\\"{x:808,y:515,t:1527272356572};\\\", \\\"{x:814,y:509,t:1527272356588};\\\", \\\"{x:815,y:508,t:1527272356603};\\\", \\\"{x:815,y:507,t:1527272356620};\\\", \\\"{x:815,y:506,t:1527272356677};\\\", \\\"{x:815,y:505,t:1527272356687};\\\", \\\"{x:815,y:502,t:1527272356703};\\\", \\\"{x:818,y:501,t:1527272357197};\\\", \\\"{x:822,y:501,t:1527272357205};\\\", \\\"{x:827,y:501,t:1527272357220};\\\", \\\"{x:828,y:501,t:1527272357237};\\\", \\\"{x:833,y:502,t:1527272357686};\\\", \\\"{x:857,y:518,t:1527272357694};\\\", \\\"{x:886,y:530,t:1527272357706};\\\", \\\"{x:979,y:565,t:1527272357722};\\\", \\\"{x:1075,y:608,t:1527272357738};\\\", \\\"{x:1170,y:639,t:1527272357754};\\\", \\\"{x:1270,y:669,t:1527272357772};\\\", \\\"{x:1351,y:696,t:1527272357787};\\\", \\\"{x:1424,y:724,t:1527272357804};\\\", \\\"{x:1464,y:746,t:1527272357822};\\\", \\\"{x:1488,y:765,t:1527272357838};\\\", \\\"{x:1506,y:787,t:1527272357855};\\\", \\\"{x:1512,y:797,t:1527272357871};\\\", \\\"{x:1513,y:798,t:1527272357887};\\\", \\\"{x:1511,y:802,t:1527272357982};\\\", \\\"{x:1508,y:802,t:1527272357990};\\\", \\\"{x:1491,y:807,t:1527272358005};\\\", \\\"{x:1468,y:808,t:1527272358022};\\\", \\\"{x:1451,y:812,t:1527272358038};\\\", \\\"{x:1439,y:816,t:1527272358055};\\\", \\\"{x:1421,y:822,t:1527272358072};\\\", \\\"{x:1408,y:825,t:1527272358087};\\\", \\\"{x:1386,y:830,t:1527272358105};\\\", \\\"{x:1369,y:830,t:1527272358122};\\\", \\\"{x:1360,y:827,t:1527272358139};\\\", \\\"{x:1348,y:815,t:1527272358155};\\\", \\\"{x:1339,y:803,t:1527272358172};\\\", \\\"{x:1330,y:791,t:1527272358188};\\\", \\\"{x:1327,y:787,t:1527272358205};\\\", \\\"{x:1326,y:785,t:1527272358222};\\\", \\\"{x:1326,y:780,t:1527272358239};\\\", \\\"{x:1326,y:768,t:1527272358255};\\\", \\\"{x:1326,y:756,t:1527272358272};\\\", \\\"{x:1326,y:744,t:1527272358289};\\\", \\\"{x:1327,y:741,t:1527272358305};\\\", \\\"{x:1327,y:740,t:1527272358322};\\\", \\\"{x:1327,y:738,t:1527272358340};\\\", \\\"{x:1329,y:736,t:1527272358365};\\\", \\\"{x:1330,y:732,t:1527272358373};\\\", \\\"{x:1332,y:725,t:1527272358389};\\\", \\\"{x:1333,y:720,t:1527272358405};\\\", \\\"{x:1334,y:718,t:1527272358422};\\\", \\\"{x:1334,y:717,t:1527272358439};\\\", \\\"{x:1335,y:717,t:1527272358454};\\\", \\\"{x:1335,y:715,t:1527272358502};\\\", \\\"{x:1335,y:714,t:1527272358509};\\\", \\\"{x:1335,y:712,t:1527272358525};\\\", \\\"{x:1335,y:711,t:1527272358550};\\\", \\\"{x:1335,y:709,t:1527272358574};\\\", \\\"{x:1335,y:706,t:1527272358589};\\\", \\\"{x:1335,y:703,t:1527272358605};\\\", \\\"{x:1335,y:698,t:1527272358623};\\\", \\\"{x:1335,y:696,t:1527272358640};\\\", \\\"{x:1335,y:695,t:1527272358655};\\\", \\\"{x:1335,y:694,t:1527272358672};\\\", \\\"{x:1335,y:690,t:1527272368325};\\\", \\\"{x:1331,y:680,t:1527272368333};\\\", \\\"{x:1325,y:671,t:1527272368344};\\\", \\\"{x:1320,y:657,t:1527272368361};\\\", \\\"{x:1311,y:639,t:1527272368378};\\\", \\\"{x:1304,y:627,t:1527272368394};\\\", \\\"{x:1298,y:617,t:1527272368411};\\\", \\\"{x:1296,y:613,t:1527272368429};\\\", \\\"{x:1295,y:608,t:1527272368445};\\\", \\\"{x:1293,y:606,t:1527272368461};\\\", \\\"{x:1292,y:603,t:1527272368478};\\\", \\\"{x:1290,y:599,t:1527272368496};\\\", \\\"{x:1289,y:596,t:1527272368512};\\\", \\\"{x:1288,y:591,t:1527272368529};\\\", \\\"{x:1285,y:585,t:1527272368546};\\\", \\\"{x:1283,y:577,t:1527272368561};\\\", \\\"{x:1280,y:572,t:1527272368578};\\\", \\\"{x:1279,y:568,t:1527272368596};\\\", \\\"{x:1279,y:567,t:1527272368611};\\\", \\\"{x:1278,y:566,t:1527272368628};\\\", \\\"{x:1278,y:565,t:1527272368669};\\\", \\\"{x:1278,y:564,t:1527272368678};\\\", \\\"{x:1278,y:562,t:1527272368695};\\\", \\\"{x:1277,y:560,t:1527272368725};\\\", \\\"{x:1252,y:564,t:1527272371459};\\\", \\\"{x:1204,y:567,t:1527272371467};\\\", \\\"{x:1104,y:567,t:1527272371484};\\\", \\\"{x:1021,y:567,t:1527272371499};\\\", \\\"{x:929,y:567,t:1527272371517};\\\", \\\"{x:835,y:567,t:1527272371533};\\\", \\\"{x:752,y:557,t:1527272371549};\\\", \\\"{x:711,y:551,t:1527272371570};\\\", \\\"{x:709,y:549,t:1527272371585};\\\", \\\"{x:709,y:548,t:1527272371663};\\\", \\\"{x:709,y:545,t:1527272371680};\\\", \\\"{x:709,y:544,t:1527272371687};\\\", \\\"{x:709,y:541,t:1527272371702};\\\", \\\"{x:703,y:529,t:1527272371720};\\\", \\\"{x:682,y:524,t:1527272371736};\\\", \\\"{x:664,y:522,t:1527272371752};\\\", \\\"{x:660,y:522,t:1527272371769};\\\", \\\"{x:659,y:522,t:1527272371785};\\\", \\\"{x:658,y:521,t:1527272371807};\\\", \\\"{x:658,y:520,t:1527272371820};\\\", \\\"{x:658,y:519,t:1527272371836};\\\", \\\"{x:658,y:517,t:1527272371858};\\\", \\\"{x:658,y:516,t:1527272371869};\\\", \\\"{x:656,y:513,t:1527272371885};\\\", \\\"{x:654,y:513,t:1527272371902};\\\", \\\"{x:645,y:512,t:1527272371919};\\\", \\\"{x:641,y:510,t:1527272371937};\\\", \\\"{x:640,y:509,t:1527272371952};\\\", \\\"{x:640,y:508,t:1527272371999};\\\", \\\"{x:642,y:508,t:1527272372353};\\\", \\\"{x:707,y:530,t:1527272372372};\\\", \\\"{x:822,y:574,t:1527272372387};\\\", \\\"{x:944,y:616,t:1527272372404};\\\", \\\"{x:1070,y:639,t:1527272372420};\\\", \\\"{x:1166,y:649,t:1527272372436};\\\", \\\"{x:1242,y:653,t:1527272372453};\\\", \\\"{x:1287,y:653,t:1527272372470};\\\", \\\"{x:1304,y:648,t:1527272372486};\\\", \\\"{x:1309,y:643,t:1527272372503};\\\", \\\"{x:1312,y:634,t:1527272372520};\\\", \\\"{x:1312,y:628,t:1527272372536};\\\", \\\"{x:1311,y:624,t:1527272372553};\\\", \\\"{x:1311,y:620,t:1527272372569};\\\", \\\"{x:1311,y:616,t:1527272372587};\\\", \\\"{x:1307,y:608,t:1527272372602};\\\", \\\"{x:1297,y:598,t:1527272372619};\\\", \\\"{x:1283,y:587,t:1527272372636};\\\", \\\"{x:1271,y:578,t:1527272372653};\\\", \\\"{x:1269,y:576,t:1527272372670};\\\", \\\"{x:1268,y:573,t:1527272372686};\\\", \\\"{x:1268,y:569,t:1527272372703};\\\", \\\"{x:1265,y:565,t:1527272372720};\\\", \\\"{x:1264,y:563,t:1527272372737};\\\", \\\"{x:1264,y:562,t:1527272372833};\\\", \\\"{x:1265,y:562,t:1527272372841};\\\", \\\"{x:1266,y:560,t:1527272372854};\\\", \\\"{x:1268,y:559,t:1527272372870};\\\", \\\"{x:1269,y:559,t:1527272372887};\\\", \\\"{x:1270,y:559,t:1527272373009};\\\", \\\"{x:1272,y:559,t:1527272373041};\\\", \\\"{x:1272,y:560,t:1527272373289};\\\", \\\"{x:1272,y:562,t:1527272374009};\\\", \\\"{x:1275,y:564,t:1527272374019};\\\", \\\"{x:1276,y:565,t:1527272374037};\\\", \\\"{x:1277,y:565,t:1527272374052};\\\", \\\"{x:1279,y:566,t:1527272374121};\\\", \\\"{x:1279,y:567,t:1527272374144};\\\", \\\"{x:1279,y:568,t:1527272382873};\\\", \\\"{x:1284,y:579,t:1527272382881};\\\", \\\"{x:1288,y:586,t:1527272382896};\\\", \\\"{x:1295,y:605,t:1527272382912};\\\", \\\"{x:1298,y:613,t:1527272382928};\\\", \\\"{x:1298,y:617,t:1527272382945};\\\", \\\"{x:1299,y:618,t:1527272382962};\\\", \\\"{x:1299,y:620,t:1527272382978};\\\", \\\"{x:1301,y:626,t:1527272382995};\\\", \\\"{x:1303,y:637,t:1527272383012};\\\", \\\"{x:1306,y:653,t:1527272383028};\\\", \\\"{x:1307,y:671,t:1527272383046};\\\", \\\"{x:1308,y:690,t:1527272383063};\\\", \\\"{x:1308,y:701,t:1527272383078};\\\", \\\"{x:1308,y:707,t:1527272383095};\\\", \\\"{x:1308,y:716,t:1527272383113};\\\", \\\"{x:1308,y:721,t:1527272383128};\\\", \\\"{x:1308,y:728,t:1527272383146};\\\", \\\"{x:1308,y:732,t:1527272383162};\\\", \\\"{x:1308,y:736,t:1527272383178};\\\", \\\"{x:1308,y:739,t:1527272383196};\\\", \\\"{x:1308,y:742,t:1527272383212};\\\", \\\"{x:1315,y:754,t:1527272383229};\\\", \\\"{x:1320,y:767,t:1527272383246};\\\", \\\"{x:1325,y:778,t:1527272383263};\\\", \\\"{x:1328,y:785,t:1527272383278};\\\", \\\"{x:1331,y:793,t:1527272383296};\\\", \\\"{x:1337,y:801,t:1527272383312};\\\", \\\"{x:1352,y:819,t:1527272383329};\\\", \\\"{x:1370,y:834,t:1527272383346};\\\", \\\"{x:1388,y:849,t:1527272383362};\\\", \\\"{x:1410,y:861,t:1527272383379};\\\", \\\"{x:1436,y:869,t:1527272383395};\\\", \\\"{x:1461,y:875,t:1527272383411};\\\", \\\"{x:1480,y:875,t:1527272383428};\\\", \\\"{x:1496,y:875,t:1527272383445};\\\", \\\"{x:1508,y:875,t:1527272383462};\\\", \\\"{x:1520,y:869,t:1527272383479};\\\", \\\"{x:1529,y:863,t:1527272383495};\\\", \\\"{x:1540,y:855,t:1527272383511};\\\", \\\"{x:1546,y:849,t:1527272383528};\\\", \\\"{x:1547,y:848,t:1527272383545};\\\", \\\"{x:1545,y:839,t:1527272383562};\\\", \\\"{x:1539,y:830,t:1527272383579};\\\", \\\"{x:1533,y:820,t:1527272383596};\\\", \\\"{x:1530,y:816,t:1527272383611};\\\", \\\"{x:1530,y:813,t:1527272383629};\\\", \\\"{x:1527,y:812,t:1527272383646};\\\", \\\"{x:1521,y:812,t:1527272383662};\\\", \\\"{x:1515,y:812,t:1527272383679};\\\", \\\"{x:1511,y:822,t:1527272383695};\\\", \\\"{x:1507,y:841,t:1527272383712};\\\", \\\"{x:1504,y:854,t:1527272383728};\\\", \\\"{x:1504,y:851,t:1527272383833};\\\", \\\"{x:1504,y:844,t:1527272383844};\\\", \\\"{x:1504,y:835,t:1527272383862};\\\", \\\"{x:1504,y:831,t:1527272383879};\\\", \\\"{x:1504,y:830,t:1527272383895};\\\", \\\"{x:1506,y:830,t:1527272384128};\\\", \\\"{x:1507,y:830,t:1527272384144};\\\", \\\"{x:1509,y:830,t:1527272384161};\\\", \\\"{x:1511,y:831,t:1527272384178};\\\", \\\"{x:1512,y:832,t:1527272384195};\\\", \\\"{x:1513,y:832,t:1527272384212};\\\", \\\"{x:1514,y:833,t:1527272384228};\\\", \\\"{x:1516,y:835,t:1527272384245};\\\", \\\"{x:1511,y:835,t:1527272384376};\\\", \\\"{x:1496,y:833,t:1527272384394};\\\", \\\"{x:1489,y:830,t:1527272384411};\\\", \\\"{x:1484,y:829,t:1527272384428};\\\", \\\"{x:1481,y:828,t:1527272384444};\\\", \\\"{x:1476,y:828,t:1527272384461};\\\", \\\"{x:1473,y:828,t:1527272384479};\\\", \\\"{x:1467,y:828,t:1527272384494};\\\", \\\"{x:1466,y:828,t:1527272384511};\\\", \\\"{x:1462,y:828,t:1527272384528};\\\", \\\"{x:1456,y:830,t:1527272384544};\\\", \\\"{x:1452,y:831,t:1527272384561};\\\", \\\"{x:1451,y:831,t:1527272384616};\\\", \\\"{x:1447,y:831,t:1527272384627};\\\", \\\"{x:1431,y:832,t:1527272384645};\\\", \\\"{x:1409,y:832,t:1527272384661};\\\", \\\"{x:1391,y:832,t:1527272384678};\\\", \\\"{x:1372,y:830,t:1527272384694};\\\", \\\"{x:1354,y:828,t:1527272384711};\\\", \\\"{x:1342,y:827,t:1527272384727};\\\", \\\"{x:1335,y:825,t:1527272384744};\\\", \\\"{x:1334,y:825,t:1527272384760};\\\", \\\"{x:1335,y:824,t:1527272384793};\\\", \\\"{x:1337,y:822,t:1527272384800};\\\", \\\"{x:1338,y:821,t:1527272384811};\\\", \\\"{x:1341,y:817,t:1527272384828};\\\", \\\"{x:1342,y:815,t:1527272384845};\\\", \\\"{x:1343,y:812,t:1527272384860};\\\", \\\"{x:1345,y:809,t:1527272384877};\\\", \\\"{x:1349,y:803,t:1527272384894};\\\", \\\"{x:1350,y:791,t:1527272384909};\\\", \\\"{x:1351,y:778,t:1527272384927};\\\", \\\"{x:1351,y:770,t:1527272384944};\\\", \\\"{x:1351,y:769,t:1527272384960};\\\", \\\"{x:1356,y:769,t:1527272385064};\\\", \\\"{x:1359,y:772,t:1527272385078};\\\", \\\"{x:1363,y:777,t:1527272385093};\\\", \\\"{x:1365,y:784,t:1527272385110};\\\", \\\"{x:1365,y:789,t:1527272385127};\\\", \\\"{x:1365,y:791,t:1527272385143};\\\", \\\"{x:1367,y:794,t:1527272385161};\\\", \\\"{x:1367,y:798,t:1527272385177};\\\", \\\"{x:1370,y:805,t:1527272385193};\\\", \\\"{x:1370,y:819,t:1527272385211};\\\", \\\"{x:1370,y:834,t:1527272385228};\\\", \\\"{x:1370,y:843,t:1527272385244};\\\", \\\"{x:1370,y:845,t:1527272385260};\\\", \\\"{x:1371,y:846,t:1527272385305};\\\", \\\"{x:1374,y:846,t:1527272385408};\\\", \\\"{x:1378,y:846,t:1527272385416};\\\", \\\"{x:1384,y:845,t:1527272385427};\\\", \\\"{x:1395,y:843,t:1527272385443};\\\", \\\"{x:1407,y:841,t:1527272385460};\\\", \\\"{x:1422,y:841,t:1527272385476};\\\", \\\"{x:1438,y:841,t:1527272385493};\\\", \\\"{x:1453,y:841,t:1527272385511};\\\", \\\"{x:1474,y:842,t:1527272385527};\\\", \\\"{x:1498,y:846,t:1527272385544};\\\", \\\"{x:1516,y:846,t:1527272385560};\\\", \\\"{x:1518,y:846,t:1527272385576};\\\", \\\"{x:1519,y:846,t:1527272385594};\\\", \\\"{x:1514,y:846,t:1527272385673};\\\", \\\"{x:1506,y:845,t:1527272385681};\\\", \\\"{x:1495,y:845,t:1527272385693};\\\", \\\"{x:1479,y:845,t:1527272385710};\\\", \\\"{x:1465,y:845,t:1527272385727};\\\", \\\"{x:1451,y:844,t:1527272385744};\\\", \\\"{x:1432,y:842,t:1527272385759};\\\", \\\"{x:1400,y:839,t:1527272385777};\\\", \\\"{x:1383,y:836,t:1527272385793};\\\", \\\"{x:1363,y:835,t:1527272385809};\\\", \\\"{x:1341,y:830,t:1527272385827};\\\", \\\"{x:1324,y:828,t:1527272385844};\\\", \\\"{x:1316,y:826,t:1527272385860};\\\", \\\"{x:1317,y:826,t:1527272385897};\\\", \\\"{x:1319,y:826,t:1527272385910};\\\", \\\"{x:1321,y:825,t:1527272385927};\\\", \\\"{x:1322,y:825,t:1527272385952};\\\", \\\"{x:1324,y:825,t:1527272385960};\\\", \\\"{x:1338,y:825,t:1527272385976};\\\", \\\"{x:1368,y:826,t:1527272385994};\\\", \\\"{x:1394,y:829,t:1527272386010};\\\", \\\"{x:1416,y:829,t:1527272386026};\\\", \\\"{x:1432,y:829,t:1527272386044};\\\", \\\"{x:1442,y:829,t:1527272386059};\\\", \\\"{x:1454,y:827,t:1527272386076};\\\", \\\"{x:1460,y:826,t:1527272386093};\\\", \\\"{x:1463,y:825,t:1527272386109};\\\", \\\"{x:1463,y:823,t:1527272386137};\\\", \\\"{x:1461,y:821,t:1527272386152};\\\", \\\"{x:1460,y:820,t:1527272386160};\\\", \\\"{x:1460,y:819,t:1527272386177};\\\", \\\"{x:1459,y:819,t:1527272386193};\\\", \\\"{x:1455,y:817,t:1527272386209};\\\", \\\"{x:1444,y:817,t:1527272386227};\\\", \\\"{x:1423,y:815,t:1527272386242};\\\", \\\"{x:1400,y:815,t:1527272386260};\\\", \\\"{x:1390,y:815,t:1527272386276};\\\", \\\"{x:1382,y:815,t:1527272386293};\\\", \\\"{x:1376,y:815,t:1527272386310};\\\", \\\"{x:1372,y:815,t:1527272386327};\\\", \\\"{x:1370,y:815,t:1527272386343};\\\", \\\"{x:1369,y:815,t:1527272386360};\\\", \\\"{x:1369,y:816,t:1527272386433};\\\", \\\"{x:1369,y:819,t:1527272386449};\\\", \\\"{x:1372,y:821,t:1527272386460};\\\", \\\"{x:1387,y:826,t:1527272386477};\\\", \\\"{x:1410,y:834,t:1527272386493};\\\", \\\"{x:1427,y:837,t:1527272386509};\\\", \\\"{x:1444,y:840,t:1527272386527};\\\", \\\"{x:1450,y:841,t:1527272386543};\\\", \\\"{x:1451,y:841,t:1527272386559};\\\", \\\"{x:1452,y:841,t:1527272386617};\\\", \\\"{x:1452,y:840,t:1527272386627};\\\", \\\"{x:1450,y:836,t:1527272386642};\\\", \\\"{x:1436,y:831,t:1527272386660};\\\", \\\"{x:1421,y:828,t:1527272386675};\\\", \\\"{x:1406,y:828,t:1527272386692};\\\", \\\"{x:1384,y:827,t:1527272386709};\\\", \\\"{x:1366,y:825,t:1527272386725};\\\", \\\"{x:1348,y:820,t:1527272386742};\\\", \\\"{x:1333,y:815,t:1527272386759};\\\", \\\"{x:1320,y:809,t:1527272386775};\\\", \\\"{x:1316,y:805,t:1527272386792};\\\", \\\"{x:1316,y:804,t:1527272386809};\\\", \\\"{x:1316,y:803,t:1527272386825};\\\", \\\"{x:1316,y:801,t:1527272386842};\\\", \\\"{x:1316,y:799,t:1527272386859};\\\", \\\"{x:1317,y:796,t:1527272386875};\\\", \\\"{x:1317,y:790,t:1527272386892};\\\", \\\"{x:1317,y:785,t:1527272386909};\\\", \\\"{x:1317,y:781,t:1527272386925};\\\", \\\"{x:1317,y:778,t:1527272386942};\\\", \\\"{x:1316,y:774,t:1527272386959};\\\", \\\"{x:1316,y:773,t:1527272386976};\\\", \\\"{x:1316,y:772,t:1527272386992};\\\", \\\"{x:1316,y:771,t:1527272387009};\\\", \\\"{x:1316,y:768,t:1527272387025};\\\", \\\"{x:1318,y:761,t:1527272387042};\\\", \\\"{x:1324,y:745,t:1527272387059};\\\", \\\"{x:1331,y:724,t:1527272387075};\\\", \\\"{x:1338,y:708,t:1527272387092};\\\", \\\"{x:1340,y:702,t:1527272387109};\\\", \\\"{x:1340,y:697,t:1527272387125};\\\", \\\"{x:1336,y:695,t:1527272387142};\\\", \\\"{x:1330,y:695,t:1527272387159};\\\", \\\"{x:1325,y:695,t:1527272387175};\\\", \\\"{x:1308,y:700,t:1527272387193};\\\", \\\"{x:1296,y:707,t:1527272387209};\\\", \\\"{x:1275,y:722,t:1527272387225};\\\", \\\"{x:1248,y:746,t:1527272387242};\\\", \\\"{x:1230,y:769,t:1527272387259};\\\", \\\"{x:1209,y:789,t:1527272387276};\\\", \\\"{x:1191,y:801,t:1527272387293};\\\", \\\"{x:1176,y:809,t:1527272387308};\\\", \\\"{x:1169,y:814,t:1527272387326};\\\", \\\"{x:1166,y:817,t:1527272387343};\\\", \\\"{x:1166,y:824,t:1527272387358};\\\", \\\"{x:1166,y:836,t:1527272387375};\\\", \\\"{x:1168,y:849,t:1527272387392};\\\", \\\"{x:1169,y:851,t:1527272387408};\\\", \\\"{x:1172,y:852,t:1527272387425};\\\", \\\"{x:1180,y:852,t:1527272387442};\\\", \\\"{x:1192,y:852,t:1527272387458};\\\", \\\"{x:1199,y:852,t:1527272387476};\\\", \\\"{x:1205,y:852,t:1527272387492};\\\", \\\"{x:1209,y:850,t:1527272387509};\\\", \\\"{x:1212,y:848,t:1527272387526};\\\", \\\"{x:1213,y:846,t:1527272387542};\\\", \\\"{x:1213,y:841,t:1527272387559};\\\", \\\"{x:1213,y:829,t:1527272387575};\\\", \\\"{x:1212,y:816,t:1527272387592};\\\", \\\"{x:1205,y:804,t:1527272387609};\\\", \\\"{x:1196,y:791,t:1527272387625};\\\", \\\"{x:1177,y:778,t:1527272387641};\\\", \\\"{x:1155,y:765,t:1527272387658};\\\", \\\"{x:1144,y:758,t:1527272387675};\\\", \\\"{x:1143,y:757,t:1527272387692};\\\", \\\"{x:1142,y:755,t:1527272387708};\\\", \\\"{x:1142,y:761,t:1527272387776};\\\", \\\"{x:1147,y:781,t:1527272387792};\\\", \\\"{x:1176,y:854,t:1527272387808};\\\", \\\"{x:1191,y:870,t:1527272387825};\\\", \\\"{x:1207,y:877,t:1527272387841};\\\", \\\"{x:1222,y:882,t:1527272387859};\\\", \\\"{x:1231,y:882,t:1527272387876};\\\", \\\"{x:1243,y:883,t:1527272387891};\\\", \\\"{x:1251,y:883,t:1527272387909};\\\", \\\"{x:1260,y:881,t:1527272387925};\\\", \\\"{x:1266,y:874,t:1527272387942};\\\", \\\"{x:1268,y:856,t:1527272387959};\\\", \\\"{x:1268,y:833,t:1527272387975};\\\", \\\"{x:1249,y:807,t:1527272387992};\\\", \\\"{x:1220,y:783,t:1527272388008};\\\", \\\"{x:1207,y:777,t:1527272388024};\\\", \\\"{x:1190,y:774,t:1527272388041};\\\", \\\"{x:1168,y:773,t:1527272388059};\\\", \\\"{x:1152,y:777,t:1527272388074};\\\", \\\"{x:1137,y:793,t:1527272388091};\\\", \\\"{x:1133,y:815,t:1527272388109};\\\", \\\"{x:1133,y:842,t:1527272388125};\\\", \\\"{x:1138,y:862,t:1527272388142};\\\", \\\"{x:1152,y:881,t:1527272388159};\\\", \\\"{x:1167,y:893,t:1527272388175};\\\", \\\"{x:1187,y:902,t:1527272388191};\\\", \\\"{x:1225,y:905,t:1527272388208};\\\", \\\"{x:1248,y:905,t:1527272388225};\\\", \\\"{x:1265,y:903,t:1527272388242};\\\", \\\"{x:1274,y:892,t:1527272388258};\\\", \\\"{x:1280,y:871,t:1527272388274};\\\", \\\"{x:1281,y:843,t:1527272388291};\\\", \\\"{x:1278,y:814,t:1527272388309};\\\", \\\"{x:1260,y:792,t:1527272388324};\\\", \\\"{x:1237,y:777,t:1527272388342};\\\", \\\"{x:1216,y:773,t:1527272388358};\\\", \\\"{x:1206,y:771,t:1527272388374};\\\", \\\"{x:1194,y:771,t:1527272388391};\\\", \\\"{x:1189,y:771,t:1527272388407};\\\", \\\"{x:1184,y:779,t:1527272388424};\\\", \\\"{x:1184,y:794,t:1527272388441};\\\", \\\"{x:1184,y:812,t:1527272388457};\\\", \\\"{x:1189,y:830,t:1527272388474};\\\", \\\"{x:1201,y:847,t:1527272388491};\\\", \\\"{x:1212,y:856,t:1527272388507};\\\", \\\"{x:1220,y:857,t:1527272388524};\\\", \\\"{x:1221,y:858,t:1527272388541};\\\", \\\"{x:1221,y:852,t:1527272388583};\\\", \\\"{x:1220,y:842,t:1527272388592};\\\", \\\"{x:1217,y:830,t:1527272388607};\\\", \\\"{x:1206,y:811,t:1527272388625};\\\", \\\"{x:1205,y:809,t:1527272388641};\\\", \\\"{x:1204,y:809,t:1527272388721};\\\", \\\"{x:1203,y:813,t:1527272388728};\\\", \\\"{x:1203,y:824,t:1527272388741};\\\", \\\"{x:1210,y:845,t:1527272388758};\\\", \\\"{x:1219,y:855,t:1527272388775};\\\", \\\"{x:1226,y:859,t:1527272388791};\\\", \\\"{x:1233,y:862,t:1527272388808};\\\", \\\"{x:1239,y:862,t:1527272388824};\\\", \\\"{x:1247,y:862,t:1527272388840};\\\", \\\"{x:1255,y:862,t:1527272388858};\\\", \\\"{x:1265,y:855,t:1527272388873};\\\", \\\"{x:1271,y:842,t:1527272388890};\\\", \\\"{x:1271,y:825,t:1527272388907};\\\", \\\"{x:1270,y:812,t:1527272388924};\\\", \\\"{x:1257,y:803,t:1527272388940};\\\", \\\"{x:1236,y:797,t:1527272388957};\\\", \\\"{x:1218,y:795,t:1527272388974};\\\", \\\"{x:1197,y:795,t:1527272388990};\\\", \\\"{x:1181,y:795,t:1527272389007};\\\", \\\"{x:1167,y:795,t:1527272389024};\\\", \\\"{x:1161,y:799,t:1527272389040};\\\", \\\"{x:1159,y:806,t:1527272389058};\\\", \\\"{x:1160,y:820,t:1527272389074};\\\", \\\"{x:1170,y:836,t:1527272389090};\\\", \\\"{x:1180,y:850,t:1527272389107};\\\", \\\"{x:1194,y:858,t:1527272389124};\\\", \\\"{x:1208,y:862,t:1527272389141};\\\", \\\"{x:1229,y:864,t:1527272389157};\\\", \\\"{x:1249,y:864,t:1527272389174};\\\", \\\"{x:1271,y:864,t:1527272389191};\\\", \\\"{x:1300,y:861,t:1527272389207};\\\", \\\"{x:1310,y:856,t:1527272389224};\\\", \\\"{x:1327,y:841,t:1527272389239};\\\", \\\"{x:1330,y:833,t:1527272389257};\\\", \\\"{x:1331,y:825,t:1527272389273};\\\", \\\"{x:1331,y:819,t:1527272389290};\\\", \\\"{x:1334,y:813,t:1527272389307};\\\", \\\"{x:1338,y:805,t:1527272389323};\\\", \\\"{x:1345,y:794,t:1527272389340};\\\", \\\"{x:1352,y:778,t:1527272389357};\\\", \\\"{x:1355,y:764,t:1527272389373};\\\", \\\"{x:1356,y:754,t:1527272389390};\\\", \\\"{x:1355,y:745,t:1527272389407};\\\", \\\"{x:1354,y:739,t:1527272389424};\\\", \\\"{x:1354,y:737,t:1527272389440};\\\", \\\"{x:1354,y:736,t:1527272389458};\\\", \\\"{x:1354,y:751,t:1527272389617};\\\", \\\"{x:1355,y:765,t:1527272389625};\\\", \\\"{x:1360,y:793,t:1527272389641};\\\", \\\"{x:1361,y:812,t:1527272389656};\\\", \\\"{x:1362,y:819,t:1527272389674};\\\", \\\"{x:1362,y:822,t:1527272389691};\\\", \\\"{x:1362,y:825,t:1527272389707};\\\", \\\"{x:1362,y:826,t:1527272389724};\\\", \\\"{x:1362,y:829,t:1527272389740};\\\", \\\"{x:1362,y:832,t:1527272389757};\\\", \\\"{x:1362,y:835,t:1527272389774};\\\", \\\"{x:1362,y:826,t:1527272389841};\\\", \\\"{x:1359,y:796,t:1527272389856};\\\", \\\"{x:1359,y:770,t:1527272389873};\\\", \\\"{x:1359,y:748,t:1527272389890};\\\", \\\"{x:1359,y:732,t:1527272389906};\\\", \\\"{x:1359,y:722,t:1527272389923};\\\", \\\"{x:1359,y:714,t:1527272389940};\\\", \\\"{x:1358,y:711,t:1527272389956};\\\", \\\"{x:1357,y:710,t:1527272390000};\\\", \\\"{x:1356,y:710,t:1527272390008};\\\", \\\"{x:1350,y:725,t:1527272390024};\\\", \\\"{x:1349,y:772,t:1527272390039};\\\", \\\"{x:1349,y:825,t:1527272390056};\\\", \\\"{x:1349,y:853,t:1527272390073};\\\", \\\"{x:1349,y:868,t:1527272390089};\\\", \\\"{x:1349,y:869,t:1527272390106};\\\", \\\"{x:1349,y:868,t:1527272390167};\\\", \\\"{x:1349,y:857,t:1527272390177};\\\", \\\"{x:1348,y:842,t:1527272390189};\\\", \\\"{x:1343,y:809,t:1527272390207};\\\", \\\"{x:1338,y:765,t:1527272390223};\\\", \\\"{x:1336,y:746,t:1527272390239};\\\", \\\"{x:1333,y:738,t:1527272390256};\\\", \\\"{x:1332,y:734,t:1527272390273};\\\", \\\"{x:1330,y:733,t:1527272390328};\\\", \\\"{x:1328,y:740,t:1527272390339};\\\", \\\"{x:1328,y:769,t:1527272390356};\\\", \\\"{x:1332,y:800,t:1527272390373};\\\", \\\"{x:1337,y:824,t:1527272390390};\\\", \\\"{x:1338,y:830,t:1527272390407};\\\", \\\"{x:1339,y:831,t:1527272390425};\\\", \\\"{x:1340,y:831,t:1527272390472};\\\", \\\"{x:1340,y:809,t:1527272390489};\\\", \\\"{x:1340,y:786,t:1527272390507};\\\", \\\"{x:1340,y:757,t:1527272390522};\\\", \\\"{x:1340,y:737,t:1527272390540};\\\", \\\"{x:1340,y:724,t:1527272390556};\\\", \\\"{x:1340,y:723,t:1527272390573};\\\", \\\"{x:1337,y:722,t:1527272394001};\\\", \\\"{x:1318,y:722,t:1527272394008};\\\", \\\"{x:1304,y:724,t:1527272394021};\\\", \\\"{x:1241,y:724,t:1527272394037};\\\", \\\"{x:1158,y:724,t:1527272394054};\\\", \\\"{x:1063,y:724,t:1527272394071};\\\", \\\"{x:964,y:724,t:1527272394086};\\\", \\\"{x:844,y:724,t:1527272394104};\\\", \\\"{x:794,y:724,t:1527272394120};\\\", \\\"{x:756,y:724,t:1527272394136};\\\", \\\"{x:739,y:724,t:1527272394153};\\\", \\\"{x:735,y:724,t:1527272394170};\\\", \\\"{x:734,y:724,t:1527272394256};\\\", \\\"{x:731,y:724,t:1527272394272};\\\", \\\"{x:728,y:724,t:1527272394287};\\\", \\\"{x:720,y:725,t:1527272394303};\\\", \\\"{x:714,y:734,t:1527272394319};\\\", \\\"{x:697,y:753,t:1527272394336};\\\", \\\"{x:672,y:772,t:1527272394353};\\\", \\\"{x:641,y:788,t:1527272394370};\\\", \\\"{x:616,y:795,t:1527272394387};\\\", \\\"{x:593,y:795,t:1527272394404};\\\", \\\"{x:578,y:788,t:1527272394419};\\\", \\\"{x:559,y:777,t:1527272394437};\\\", \\\"{x:532,y:766,t:1527272394454};\\\", \\\"{x:506,y:759,t:1527272394470};\\\", \\\"{x:492,y:758,t:1527272394487};\\\", \\\"{x:487,y:758,t:1527272394504};\\\", \\\"{x:486,y:757,t:1527272394528};\\\", \\\"{x:485,y:756,t:1527272394536};\\\", \\\"{x:482,y:753,t:1527272394555};\\\", \\\"{x:479,y:751,t:1527272394569};\\\", \\\"{x:476,y:746,t:1527272394586};\\\", \\\"{x:473,y:743,t:1527272394604};\\\", \\\"{x:472,y:741,t:1527272394619};\\\", \\\"{x:471,y:739,t:1527272394637};\\\", \\\"{x:471,y:738,t:1527272394663};\\\", \\\"{x:470,y:738,t:1527272394671};\\\", \\\"{x:470,y:736,t:1527272394711};\\\", \\\"{x:469,y:736,t:1527272394752};\\\" ] }, { \\\"rt\\\": 55921, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 1043322, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:735,t:1527272399536};\\\", \\\"{x:527,y:740,t:1527272399548};\\\", \\\"{x:650,y:767,t:1527272399567};\\\", \\\"{x:772,y:783,t:1527272399582};\\\", \\\"{x:919,y:805,t:1527272399599};\\\", \\\"{x:1261,y:847,t:1527272399623};\\\", \\\"{x:1435,y:869,t:1527272399641};\\\", \\\"{x:1579,y:889,t:1527272399657};\\\", \\\"{x:1669,y:897,t:1527272399674};\\\", \\\"{x:1698,y:897,t:1527272399690};\\\", \\\"{x:1707,y:898,t:1527272399706};\\\", \\\"{x:1702,y:898,t:1527272400210};\\\", \\\"{x:1680,y:898,t:1527272400224};\\\", \\\"{x:1653,y:898,t:1527272400241};\\\", \\\"{x:1617,y:898,t:1527272400257};\\\", \\\"{x:1563,y:898,t:1527272400274};\\\", \\\"{x:1513,y:898,t:1527272400291};\\\", \\\"{x:1483,y:898,t:1527272400308};\\\", \\\"{x:1453,y:898,t:1527272400324};\\\", \\\"{x:1434,y:898,t:1527272400341};\\\", \\\"{x:1420,y:896,t:1527272400357};\\\", \\\"{x:1411,y:895,t:1527272400373};\\\", \\\"{x:1400,y:892,t:1527272400390};\\\", \\\"{x:1384,y:887,t:1527272400406};\\\", \\\"{x:1369,y:883,t:1527272400423};\\\", \\\"{x:1365,y:883,t:1527272400440};\\\", \\\"{x:1362,y:884,t:1527272400456};\\\", \\\"{x:1362,y:889,t:1527272400473};\\\", \\\"{x:1362,y:891,t:1527272400490};\\\", \\\"{x:1359,y:891,t:1527272400880};\\\", \\\"{x:1356,y:891,t:1527272400891};\\\", \\\"{x:1351,y:891,t:1527272400907};\\\", \\\"{x:1346,y:891,t:1527272400924};\\\", \\\"{x:1334,y:891,t:1527272400940};\\\", \\\"{x:1318,y:895,t:1527272400958};\\\", \\\"{x:1295,y:895,t:1527272400974};\\\", \\\"{x:1272,y:895,t:1527272400991};\\\", \\\"{x:1247,y:895,t:1527272401007};\\\", \\\"{x:1245,y:895,t:1527272401024};\\\", \\\"{x:1235,y:895,t:1527272401041};\\\", \\\"{x:1223,y:895,t:1527272401058};\\\", \\\"{x:1209,y:891,t:1527272401074};\\\", \\\"{x:1196,y:883,t:1527272401091};\\\", \\\"{x:1181,y:870,t:1527272401108};\\\", \\\"{x:1164,y:857,t:1527272401123};\\\", \\\"{x:1156,y:852,t:1527272401141};\\\", \\\"{x:1154,y:851,t:1527272401157};\\\", \\\"{x:1154,y:850,t:1527272401174};\\\", \\\"{x:1154,y:849,t:1527272401256};\\\", \\\"{x:1154,y:848,t:1527272401263};\\\", \\\"{x:1154,y:847,t:1527272401274};\\\", \\\"{x:1159,y:843,t:1527272401291};\\\", \\\"{x:1163,y:840,t:1527272401308};\\\", \\\"{x:1165,y:840,t:1527272401324};\\\", \\\"{x:1165,y:839,t:1527272401410};\\\", \\\"{x:1166,y:837,t:1527272401425};\\\", \\\"{x:1165,y:832,t:1527272401441};\\\", \\\"{x:1164,y:831,t:1527272401464};\\\", \\\"{x:1163,y:831,t:1527272401480};\\\", \\\"{x:1159,y:831,t:1527272401491};\\\", \\\"{x:1144,y:831,t:1527272401508};\\\", \\\"{x:1127,y:831,t:1527272401524};\\\", \\\"{x:1125,y:831,t:1527272401541};\\\", \\\"{x:1126,y:831,t:1527272401656};\\\", \\\"{x:1129,y:831,t:1527272401664};\\\", \\\"{x:1131,y:831,t:1527272401674};\\\", \\\"{x:1137,y:831,t:1527272401691};\\\", \\\"{x:1140,y:831,t:1527272401708};\\\", \\\"{x:1141,y:831,t:1527272401724};\\\", \\\"{x:1142,y:831,t:1527272401741};\\\", \\\"{x:1143,y:831,t:1527272401760};\\\", \\\"{x:1144,y:831,t:1527272401776};\\\", \\\"{x:1145,y:831,t:1527272401809};\\\", \\\"{x:1146,y:831,t:1527272401824};\\\", \\\"{x:1147,y:831,t:1527272401856};\\\", \\\"{x:1149,y:831,t:1527272403128};\\\", \\\"{x:1151,y:831,t:1527272403141};\\\", \\\"{x:1157,y:831,t:1527272403158};\\\", \\\"{x:1161,y:831,t:1527272403175};\\\", \\\"{x:1165,y:831,t:1527272403192};\\\", \\\"{x:1166,y:831,t:1527272403208};\\\", \\\"{x:1167,y:831,t:1527272403272};\\\", \\\"{x:1169,y:831,t:1527272403279};\\\", \\\"{x:1173,y:828,t:1527272403292};\\\", \\\"{x:1179,y:820,t:1527272403308};\\\", \\\"{x:1185,y:813,t:1527272403325};\\\", \\\"{x:1186,y:811,t:1527272403342};\\\", \\\"{x:1187,y:806,t:1527272403358};\\\", \\\"{x:1187,y:803,t:1527272403376};\\\", \\\"{x:1187,y:800,t:1527272403392};\\\", \\\"{x:1187,y:799,t:1527272403448};\\\", \\\"{x:1187,y:796,t:1527272403464};\\\", \\\"{x:1187,y:793,t:1527272403475};\\\", \\\"{x:1187,y:789,t:1527272403492};\\\", \\\"{x:1187,y:786,t:1527272403508};\\\", \\\"{x:1187,y:785,t:1527272403528};\\\", \\\"{x:1187,y:783,t:1527272403544};\\\", \\\"{x:1187,y:777,t:1527272403558};\\\", \\\"{x:1187,y:772,t:1527272403576};\\\", \\\"{x:1185,y:765,t:1527272403595};\\\", \\\"{x:1185,y:763,t:1527272403609};\\\", \\\"{x:1184,y:762,t:1527272403624};\\\", \\\"{x:1184,y:761,t:1527272421080};\\\", \\\"{x:1183,y:761,t:1527272421097};\\\", \\\"{x:1182,y:761,t:1527272421114};\\\", \\\"{x:1182,y:762,t:1527272423392};\\\", \\\"{x:1182,y:764,t:1527272423407};\\\", \\\"{x:1182,y:770,t:1527272423416};\\\", \\\"{x:1182,y:773,t:1527272423431};\\\", \\\"{x:1182,y:774,t:1527272423448};\\\", \\\"{x:1182,y:775,t:1527272423544};\\\", \\\"{x:1181,y:776,t:1527272423552};\\\", \\\"{x:1181,y:777,t:1527272423564};\\\", \\\"{x:1181,y:781,t:1527272423582};\\\", \\\"{x:1181,y:785,t:1527272423598};\\\", \\\"{x:1181,y:795,t:1527272423615};\\\", \\\"{x:1178,y:812,t:1527272423631};\\\", \\\"{x:1176,y:827,t:1527272423647};\\\", \\\"{x:1174,y:846,t:1527272423665};\\\", \\\"{x:1174,y:858,t:1527272423682};\\\", \\\"{x:1174,y:873,t:1527272423698};\\\", \\\"{x:1174,y:888,t:1527272423714};\\\", \\\"{x:1174,y:902,t:1527272423732};\\\", \\\"{x:1174,y:917,t:1527272423748};\\\", \\\"{x:1174,y:932,t:1527272423765};\\\", \\\"{x:1174,y:946,t:1527272423782};\\\", \\\"{x:1174,y:957,t:1527272423798};\\\", \\\"{x:1174,y:969,t:1527272423814};\\\", \\\"{x:1174,y:977,t:1527272423830};\\\", \\\"{x:1174,y:978,t:1527272423886};\\\", \\\"{x:1174,y:980,t:1527272423897};\\\", \\\"{x:1174,y:984,t:1527272423914};\\\", \\\"{x:1174,y:986,t:1527272423931};\\\", \\\"{x:1174,y:978,t:1527272426063};\\\", \\\"{x:1172,y:970,t:1527272426071};\\\", \\\"{x:1171,y:960,t:1527272426082};\\\", \\\"{x:1171,y:937,t:1527272426099};\\\", \\\"{x:1171,y:922,t:1527272426116};\\\", \\\"{x:1168,y:910,t:1527272426132};\\\", \\\"{x:1166,y:897,t:1527272426149};\\\", \\\"{x:1162,y:887,t:1527272426166};\\\", \\\"{x:1158,y:876,t:1527272426182};\\\", \\\"{x:1154,y:865,t:1527272426199};\\\", \\\"{x:1154,y:862,t:1527272426215};\\\", \\\"{x:1154,y:861,t:1527272426231};\\\", \\\"{x:1153,y:859,t:1527272426248};\\\", \\\"{x:1153,y:858,t:1527272426265};\\\", \\\"{x:1153,y:855,t:1527272426281};\\\", \\\"{x:1153,y:852,t:1527272426299};\\\", \\\"{x:1153,y:848,t:1527272426315};\\\", \\\"{x:1153,y:844,t:1527272426332};\\\", \\\"{x:1153,y:840,t:1527272426348};\\\", \\\"{x:1153,y:833,t:1527272426366};\\\", \\\"{x:1153,y:826,t:1527272426383};\\\", \\\"{x:1153,y:819,t:1527272426399};\\\", \\\"{x:1153,y:814,t:1527272426416};\\\", \\\"{x:1154,y:805,t:1527272426432};\\\", \\\"{x:1156,y:800,t:1527272426448};\\\", \\\"{x:1157,y:796,t:1527272426466};\\\", \\\"{x:1159,y:794,t:1527272426482};\\\", \\\"{x:1159,y:793,t:1527272426519};\\\", \\\"{x:1159,y:791,t:1527272426568};\\\", \\\"{x:1160,y:788,t:1527272426583};\\\", \\\"{x:1160,y:787,t:1527272426599};\\\", \\\"{x:1160,y:785,t:1527272426920};\\\", \\\"{x:1146,y:784,t:1527272426933};\\\", \\\"{x:1106,y:781,t:1527272426949};\\\", \\\"{x:1031,y:773,t:1527272426966};\\\", \\\"{x:861,y:755,t:1527272426984};\\\", \\\"{x:770,y:755,t:1527272426999};\\\", \\\"{x:692,y:755,t:1527272427015};\\\", \\\"{x:627,y:751,t:1527272427033};\\\", \\\"{x:564,y:739,t:1527272427049};\\\", \\\"{x:511,y:730,t:1527272427065};\\\", \\\"{x:482,y:722,t:1527272427082};\\\", \\\"{x:479,y:722,t:1527272427096};\\\", \\\"{x:478,y:720,t:1527272427182};\\\", \\\"{x:478,y:719,t:1527272427199};\\\", \\\"{x:479,y:718,t:1527272427214};\\\", \\\"{x:484,y:716,t:1527272427231};\\\", \\\"{x:487,y:716,t:1527272427351};\\\", \\\"{x:489,y:720,t:1527272427365};\\\", \\\"{x:492,y:725,t:1527272427380};\\\", \\\"{x:492,y:727,t:1527272427431};\\\", \\\"{x:492,y:728,t:1527272427454};\\\", \\\"{x:494,y:729,t:1527272427464};\\\", \\\"{x:500,y:731,t:1527272427704};\\\", \\\"{x:512,y:738,t:1527272427713};\\\", \\\"{x:541,y:751,t:1527272427731};\\\", \\\"{x:585,y:763,t:1527272427749};\\\", \\\"{x:647,y:771,t:1527272427764};\\\", \\\"{x:730,y:782,t:1527272427780};\\\", \\\"{x:813,y:794,t:1527272427798};\\\", \\\"{x:907,y:807,t:1527272427814};\\\", \\\"{x:944,y:811,t:1527272427830};\\\", \\\"{x:972,y:817,t:1527272427848};\\\", \\\"{x:996,y:825,t:1527272427864};\\\", \\\"{x:1021,y:833,t:1527272427881};\\\", \\\"{x:1039,y:837,t:1527272427898};\\\", \\\"{x:1053,y:838,t:1527272427914};\\\", \\\"{x:1070,y:842,t:1527272427930};\\\", \\\"{x:1092,y:848,t:1527272427947};\\\", \\\"{x:1113,y:853,t:1527272427964};\\\", \\\"{x:1141,y:859,t:1527272427980};\\\", \\\"{x:1175,y:865,t:1527272427998};\\\", \\\"{x:1209,y:870,t:1527272428015};\\\", \\\"{x:1227,y:871,t:1527272428031};\\\", \\\"{x:1230,y:871,t:1527272428047};\\\", \\\"{x:1231,y:871,t:1527272428065};\\\", \\\"{x:1232,y:871,t:1527272428095};\\\", \\\"{x:1231,y:868,t:1527272428103};\\\", \\\"{x:1226,y:866,t:1527272428115};\\\", \\\"{x:1223,y:863,t:1527272428131};\\\", \\\"{x:1222,y:863,t:1527272428148};\\\", \\\"{x:1222,y:862,t:1527272428164};\\\", \\\"{x:1220,y:860,t:1527272428182};\\\", \\\"{x:1214,y:856,t:1527272428197};\\\", \\\"{x:1209,y:852,t:1527272428215};\\\", \\\"{x:1209,y:851,t:1527272428240};\\\", \\\"{x:1208,y:851,t:1527272428248};\\\", \\\"{x:1207,y:848,t:1527272428265};\\\", \\\"{x:1205,y:846,t:1527272428282};\\\", \\\"{x:1204,y:844,t:1527272428298};\\\", \\\"{x:1203,y:841,t:1527272428315};\\\", \\\"{x:1202,y:840,t:1527272428331};\\\", \\\"{x:1202,y:839,t:1527272428348};\\\", \\\"{x:1202,y:838,t:1527272428365};\\\", \\\"{x:1202,y:836,t:1527272428382};\\\", \\\"{x:1202,y:835,t:1527272428397};\\\", \\\"{x:1204,y:833,t:1527272428415};\\\", \\\"{x:1205,y:832,t:1527272428519};\\\", \\\"{x:1206,y:832,t:1527272428552};\\\", \\\"{x:1208,y:831,t:1527272428912};\\\", \\\"{x:1208,y:830,t:1527272428927};\\\", \\\"{x:1208,y:828,t:1527272428935};\\\", \\\"{x:1207,y:822,t:1527272428948};\\\", \\\"{x:1198,y:809,t:1527272428966};\\\", \\\"{x:1194,y:794,t:1527272428982};\\\", \\\"{x:1191,y:786,t:1527272428999};\\\", \\\"{x:1187,y:781,t:1527272429015};\\\", \\\"{x:1187,y:780,t:1527272429063};\\\", \\\"{x:1186,y:779,t:1527272429287};\\\", \\\"{x:1185,y:779,t:1527272429299};\\\", \\\"{x:1184,y:778,t:1527272429316};\\\", \\\"{x:1182,y:776,t:1527272429332};\\\", \\\"{x:1181,y:775,t:1527272429360};\\\", \\\"{x:1181,y:773,t:1527272429375};\\\", \\\"{x:1180,y:773,t:1527272430420};\\\", \\\"{x:1179,y:772,t:1527272430437};\\\", \\\"{x:1179,y:771,t:1527272430483};\\\", \\\"{x:1179,y:770,t:1527272430499};\\\", \\\"{x:1179,y:769,t:1527272430515};\\\", \\\"{x:1179,y:768,t:1527272434540};\\\", \\\"{x:1196,y:767,t:1527272434558};\\\", \\\"{x:1207,y:767,t:1527272434574};\\\", \\\"{x:1213,y:767,t:1527272434591};\\\", \\\"{x:1219,y:767,t:1527272434607};\\\", \\\"{x:1220,y:767,t:1527272434624};\\\", \\\"{x:1222,y:767,t:1527272434641};\\\", \\\"{x:1223,y:767,t:1527272434684};\\\", \\\"{x:1226,y:767,t:1527272434691};\\\", \\\"{x:1229,y:767,t:1527272434707};\\\", \\\"{x:1233,y:767,t:1527272434725};\\\", \\\"{x:1235,y:766,t:1527272434741};\\\", \\\"{x:1237,y:765,t:1527272434758};\\\", \\\"{x:1240,y:765,t:1527272434779};\\\", \\\"{x:1244,y:765,t:1527272434791};\\\", \\\"{x:1252,y:765,t:1527272434808};\\\", \\\"{x:1261,y:765,t:1527272434824};\\\", \\\"{x:1262,y:765,t:1527272434841};\\\", \\\"{x:1261,y:765,t:1527272435131};\\\", \\\"{x:1258,y:766,t:1527272435140};\\\", \\\"{x:1254,y:766,t:1527272435158};\\\", \\\"{x:1253,y:766,t:1527272435174};\\\", \\\"{x:1257,y:766,t:1527272435235};\\\", \\\"{x:1261,y:766,t:1527272435243};\\\", \\\"{x:1266,y:766,t:1527272435259};\\\", \\\"{x:1273,y:766,t:1527272435275};\\\", \\\"{x:1276,y:766,t:1527272435291};\\\", \\\"{x:1278,y:766,t:1527272435332};\\\", \\\"{x:1280,y:766,t:1527272435341};\\\", \\\"{x:1285,y:766,t:1527272435359};\\\", \\\"{x:1292,y:766,t:1527272435375};\\\", \\\"{x:1295,y:766,t:1527272435391};\\\", \\\"{x:1296,y:766,t:1527272435409};\\\", \\\"{x:1297,y:766,t:1527272435460};\\\", \\\"{x:1301,y:766,t:1527272435475};\\\", \\\"{x:1306,y:766,t:1527272435491};\\\", \\\"{x:1312,y:767,t:1527272435508};\\\", \\\"{x:1314,y:767,t:1527272435525};\\\", \\\"{x:1316,y:767,t:1527272435542};\\\", \\\"{x:1317,y:767,t:1527272435652};\\\", \\\"{x:1319,y:767,t:1527272435796};\\\", \\\"{x:1324,y:767,t:1527272435808};\\\", \\\"{x:1339,y:768,t:1527272435825};\\\", \\\"{x:1355,y:769,t:1527272435842};\\\", \\\"{x:1368,y:772,t:1527272435858};\\\", \\\"{x:1372,y:773,t:1527272435875};\\\", \\\"{x:1373,y:773,t:1527272435923};\\\", \\\"{x:1376,y:773,t:1527272435931};\\\", \\\"{x:1380,y:772,t:1527272435942};\\\", \\\"{x:1382,y:771,t:1527272435959};\\\", \\\"{x:1383,y:771,t:1527272435975};\\\", \\\"{x:1383,y:770,t:1527272436211};\\\", \\\"{x:1383,y:769,t:1527272436227};\\\", \\\"{x:1382,y:768,t:1527272450219};\\\", \\\"{x:1320,y:756,t:1527272450237};\\\", \\\"{x:1267,y:756,t:1527272450255};\\\", \\\"{x:1232,y:759,t:1527272450271};\\\", \\\"{x:1188,y:763,t:1527272450288};\\\", \\\"{x:1151,y:770,t:1527272450304};\\\", \\\"{x:1118,y:778,t:1527272450321};\\\", \\\"{x:1103,y:782,t:1527272450338};\\\", \\\"{x:1098,y:784,t:1527272450355};\\\", \\\"{x:1097,y:785,t:1527272450371};\\\", \\\"{x:1097,y:788,t:1527272450427};\\\", \\\"{x:1098,y:790,t:1527272450438};\\\", \\\"{x:1100,y:792,t:1527272450454};\\\", \\\"{x:1102,y:792,t:1527272450482};\\\", \\\"{x:1104,y:792,t:1527272450491};\\\", \\\"{x:1107,y:792,t:1527272450505};\\\", \\\"{x:1113,y:792,t:1527272450521};\\\", \\\"{x:1120,y:792,t:1527272450538};\\\", \\\"{x:1138,y:788,t:1527272450555};\\\", \\\"{x:1149,y:785,t:1527272450571};\\\", \\\"{x:1164,y:781,t:1527272450588};\\\", \\\"{x:1176,y:778,t:1527272450605};\\\", \\\"{x:1184,y:777,t:1527272450622};\\\", \\\"{x:1185,y:777,t:1527272450637};\\\", \\\"{x:1188,y:777,t:1527272450655};\\\", \\\"{x:1189,y:777,t:1527272450672};\\\", \\\"{x:1190,y:777,t:1527272450723};\\\", \\\"{x:1191,y:777,t:1527272450737};\\\", \\\"{x:1195,y:777,t:1527272450755};\\\", \\\"{x:1197,y:786,t:1527272450772};\\\", \\\"{x:1197,y:796,t:1527272450788};\\\", \\\"{x:1197,y:800,t:1527272450805};\\\", \\\"{x:1197,y:803,t:1527272450821};\\\", \\\"{x:1196,y:804,t:1527272450839};\\\", \\\"{x:1195,y:804,t:1527272450915};\\\", \\\"{x:1194,y:802,t:1527272450923};\\\", \\\"{x:1194,y:794,t:1527272450939};\\\", \\\"{x:1189,y:786,t:1527272450955};\\\", \\\"{x:1181,y:776,t:1527272450971};\\\", \\\"{x:1177,y:772,t:1527272450988};\\\", \\\"{x:1173,y:772,t:1527272451005};\\\", \\\"{x:1171,y:772,t:1527272451022};\\\", \\\"{x:1166,y:772,t:1527272451039};\\\", \\\"{x:1160,y:783,t:1527272451054};\\\", \\\"{x:1158,y:796,t:1527272451071};\\\", \\\"{x:1158,y:807,t:1527272451088};\\\", \\\"{x:1163,y:817,t:1527272451105};\\\", \\\"{x:1167,y:821,t:1527272451122};\\\", \\\"{x:1175,y:824,t:1527272451138};\\\", \\\"{x:1178,y:824,t:1527272451155};\\\", \\\"{x:1180,y:824,t:1527272451172};\\\", \\\"{x:1182,y:824,t:1527272451188};\\\", \\\"{x:1184,y:816,t:1527272451206};\\\", \\\"{x:1184,y:798,t:1527272451221};\\\", \\\"{x:1181,y:775,t:1527272451238};\\\", \\\"{x:1172,y:756,t:1527272451255};\\\", \\\"{x:1166,y:745,t:1527272451271};\\\", \\\"{x:1164,y:743,t:1527272451288};\\\", \\\"{x:1163,y:742,t:1527272451305};\\\", \\\"{x:1160,y:742,t:1527272451321};\\\", \\\"{x:1148,y:750,t:1527272451338};\\\", \\\"{x:1146,y:763,t:1527272451355};\\\", \\\"{x:1146,y:778,t:1527272451371};\\\", \\\"{x:1153,y:792,t:1527272451388};\\\", \\\"{x:1162,y:803,t:1527272451405};\\\", \\\"{x:1170,y:808,t:1527272451421};\\\", \\\"{x:1179,y:810,t:1527272451438};\\\", \\\"{x:1184,y:810,t:1527272451455};\\\", \\\"{x:1188,y:809,t:1527272451471};\\\", \\\"{x:1192,y:802,t:1527272451488};\\\", \\\"{x:1194,y:786,t:1527272451506};\\\", \\\"{x:1194,y:769,t:1527272451522};\\\", \\\"{x:1180,y:743,t:1527272451538};\\\", \\\"{x:1158,y:733,t:1527272451556};\\\", \\\"{x:1147,y:732,t:1527272451571};\\\", \\\"{x:1140,y:732,t:1527272451588};\\\", \\\"{x:1133,y:742,t:1527272451605};\\\", \\\"{x:1125,y:753,t:1527272451622};\\\", \\\"{x:1124,y:766,t:1527272451638};\\\", \\\"{x:1124,y:778,t:1527272451655};\\\", \\\"{x:1132,y:793,t:1527272451672};\\\", \\\"{x:1136,y:799,t:1527272451689};\\\", \\\"{x:1137,y:800,t:1527272451706};\\\", \\\"{x:1134,y:803,t:1527272451723};\\\", \\\"{x:1100,y:803,t:1527272451738};\\\", \\\"{x:1017,y:795,t:1527272451755};\\\", \\\"{x:889,y:774,t:1527272451773};\\\", \\\"{x:738,y:756,t:1527272451789};\\\", \\\"{x:600,y:742,t:1527272451805};\\\", \\\"{x:491,y:738,t:1527272451822};\\\", \\\"{x:413,y:738,t:1527272451839};\\\", \\\"{x:381,y:738,t:1527272451855};\\\", \\\"{x:374,y:738,t:1527272451868};\\\", \\\"{x:373,y:738,t:1527272451885};\\\", \\\"{x:374,y:738,t:1527272451902};\\\", \\\"{x:385,y:739,t:1527272451918};\\\", \\\"{x:403,y:742,t:1527272451935};\\\", \\\"{x:418,y:745,t:1527272451952};\\\", \\\"{x:428,y:746,t:1527272451968};\\\", \\\"{x:435,y:749,t:1527272451985};\\\", \\\"{x:458,y:756,t:1527272452002};\\\", \\\"{x:486,y:761,t:1527272452018};\\\", \\\"{x:513,y:764,t:1527272452035};\\\", \\\"{x:531,y:763,t:1527272452053};\\\", \\\"{x:539,y:759,t:1527272452068};\\\", \\\"{x:542,y:758,t:1527272452085};\\\", \\\"{x:543,y:757,t:1527272452102};\\\", \\\"{x:543,y:753,t:1527272452220};\\\", \\\"{x:543,y:743,t:1527272452235};\\\", \\\"{x:543,y:742,t:1527272452254};\\\", \\\"{x:543,y:741,t:1527272452979};\\\" ] }, { \\\"rt\\\": 82942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 1127530, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -Z -X -X -X -X -X -X -B -B -F -Z -Z -C -E -G -A -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:741,t:1527272454353};\\\", \\\"{x:562,y:740,t:1527272454378};\\\", \\\"{x:570,y:739,t:1527272454391};\\\", \\\"{x:587,y:734,t:1527272454407};\\\", \\\"{x:606,y:731,t:1527272454422};\\\", \\\"{x:608,y:731,t:1527272454439};\\\", \\\"{x:609,y:731,t:1527272454456};\\\", \\\"{x:609,y:730,t:1527272455034};\\\", \\\"{x:610,y:725,t:1527272455690};\\\", \\\"{x:595,y:699,t:1527272455707};\\\", \\\"{x:564,y:654,t:1527272455725};\\\", \\\"{x:535,y:614,t:1527272455742};\\\", \\\"{x:512,y:571,t:1527272455758};\\\", \\\"{x:495,y:541,t:1527272455774};\\\", \\\"{x:489,y:524,t:1527272455790};\\\", \\\"{x:481,y:511,t:1527272455807};\\\", \\\"{x:470,y:499,t:1527272455823};\\\", \\\"{x:462,y:492,t:1527272455840};\\\", \\\"{x:456,y:487,t:1527272455856};\\\", \\\"{x:451,y:482,t:1527272455873};\\\", \\\"{x:443,y:473,t:1527272455890};\\\", \\\"{x:440,y:469,t:1527272455908};\\\", \\\"{x:440,y:467,t:1527272455923};\\\", \\\"{x:440,y:465,t:1527272455945};\\\", \\\"{x:440,y:464,t:1527272456075};\\\", \\\"{x:442,y:461,t:1527272456090};\\\", \\\"{x:445,y:459,t:1527272456107};\\\", \\\"{x:450,y:457,t:1527272456123};\\\", \\\"{x:454,y:456,t:1527272456141};\\\", \\\"{x:464,y:456,t:1527272456158};\\\", \\\"{x:476,y:456,t:1527272456174};\\\", \\\"{x:493,y:456,t:1527272456191};\\\", \\\"{x:515,y:456,t:1527272456208};\\\", \\\"{x:539,y:456,t:1527272456224};\\\", \\\"{x:562,y:456,t:1527272456241};\\\", \\\"{x:574,y:456,t:1527272456258};\\\", \\\"{x:580,y:456,t:1527272456274};\\\", \\\"{x:581,y:456,t:1527272456290};\\\", \\\"{x:583,y:456,t:1527272456314};\\\", \\\"{x:585,y:456,t:1527272456330};\\\", \\\"{x:586,y:456,t:1527272456341};\\\", \\\"{x:590,y:456,t:1527272456357};\\\", \\\"{x:594,y:456,t:1527272456375};\\\", \\\"{x:604,y:456,t:1527272456390};\\\", \\\"{x:614,y:459,t:1527272456408};\\\", \\\"{x:629,y:463,t:1527272456424};\\\", \\\"{x:644,y:468,t:1527272456441};\\\", \\\"{x:657,y:471,t:1527272456458};\\\", \\\"{x:673,y:474,t:1527272456474};\\\", \\\"{x:680,y:477,t:1527272456491};\\\", \\\"{x:687,y:478,t:1527272456507};\\\", \\\"{x:694,y:481,t:1527272456525};\\\", \\\"{x:696,y:481,t:1527272456540};\\\", \\\"{x:697,y:481,t:1527272456557};\\\", \\\"{x:699,y:483,t:1527272456690};\\\", \\\"{x:702,y:486,t:1527272456708};\\\", \\\"{x:709,y:493,t:1527272456726};\\\", \\\"{x:715,y:498,t:1527272456742};\\\", \\\"{x:729,y:505,t:1527272456757};\\\", \\\"{x:750,y:516,t:1527272456774};\\\", \\\"{x:775,y:530,t:1527272456791};\\\", \\\"{x:808,y:545,t:1527272456807};\\\", \\\"{x:865,y:563,t:1527272456825};\\\", \\\"{x:896,y:577,t:1527272456840};\\\", \\\"{x:942,y:592,t:1527272456857};\\\", \\\"{x:1012,y:613,t:1527272456875};\\\", \\\"{x:1049,y:626,t:1527272456891};\\\", \\\"{x:1080,y:634,t:1527272456907};\\\", \\\"{x:1104,y:643,t:1527272456924};\\\", \\\"{x:1124,y:651,t:1527272456941};\\\", \\\"{x:1138,y:657,t:1527272456957};\\\", \\\"{x:1148,y:663,t:1527272456974};\\\", \\\"{x:1153,y:668,t:1527272456991};\\\", \\\"{x:1159,y:675,t:1527272457007};\\\", \\\"{x:1164,y:680,t:1527272457025};\\\", \\\"{x:1167,y:682,t:1527272457042};\\\", \\\"{x:1167,y:683,t:1527272457090};\\\", \\\"{x:1168,y:684,t:1527272457107};\\\", \\\"{x:1168,y:685,t:1527272457123};\\\", \\\"{x:1169,y:685,t:1527272457130};\\\", \\\"{x:1170,y:686,t:1527272457142};\\\", \\\"{x:1170,y:688,t:1527272457158};\\\", \\\"{x:1172,y:690,t:1527272457175};\\\", \\\"{x:1175,y:693,t:1527272457192};\\\", \\\"{x:1181,y:699,t:1527272457207};\\\", \\\"{x:1187,y:704,t:1527272457225};\\\", \\\"{x:1197,y:712,t:1527272457241};\\\", \\\"{x:1205,y:719,t:1527272457258};\\\", \\\"{x:1213,y:723,t:1527272457274};\\\", \\\"{x:1216,y:725,t:1527272457292};\\\", \\\"{x:1217,y:726,t:1527272457315};\\\", \\\"{x:1220,y:729,t:1527272457451};\\\", \\\"{x:1223,y:730,t:1527272457459};\\\", \\\"{x:1229,y:735,t:1527272457476};\\\", \\\"{x:1236,y:739,t:1527272457491};\\\", \\\"{x:1242,y:746,t:1527272457509};\\\", \\\"{x:1250,y:749,t:1527272457525};\\\", \\\"{x:1253,y:750,t:1527272457541};\\\", \\\"{x:1256,y:751,t:1527272457559};\\\", \\\"{x:1257,y:752,t:1527272457575};\\\", \\\"{x:1259,y:752,t:1527272457591};\\\", \\\"{x:1260,y:752,t:1527272457608};\\\", \\\"{x:1262,y:752,t:1527272457625};\\\", \\\"{x:1263,y:752,t:1527272457666};\\\", \\\"{x:1265,y:752,t:1527272457676};\\\", \\\"{x:1270,y:752,t:1527272457692};\\\", \\\"{x:1277,y:752,t:1527272457709};\\\", \\\"{x:1287,y:751,t:1527272457726};\\\", \\\"{x:1297,y:750,t:1527272457741};\\\", \\\"{x:1309,y:748,t:1527272457759};\\\", \\\"{x:1316,y:744,t:1527272457776};\\\", \\\"{x:1321,y:740,t:1527272457791};\\\", \\\"{x:1330,y:734,t:1527272457809};\\\", \\\"{x:1337,y:729,t:1527272457826};\\\", \\\"{x:1343,y:724,t:1527272457841};\\\", \\\"{x:1349,y:719,t:1527272457859};\\\", \\\"{x:1349,y:717,t:1527272457876};\\\", \\\"{x:1352,y:713,t:1527272457892};\\\", \\\"{x:1352,y:710,t:1527272457909};\\\", \\\"{x:1352,y:708,t:1527272457926};\\\", \\\"{x:1353,y:706,t:1527272457942};\\\", \\\"{x:1354,y:704,t:1527272457959};\\\", \\\"{x:1354,y:702,t:1527272457978};\\\", \\\"{x:1355,y:701,t:1527272457992};\\\", \\\"{x:1355,y:699,t:1527272458008};\\\", \\\"{x:1356,y:697,t:1527272458026};\\\", \\\"{x:1356,y:696,t:1527272458059};\\\", \\\"{x:1355,y:695,t:1527272458979};\\\", \\\"{x:1353,y:695,t:1527272459005};\\\", \\\"{x:1351,y:695,t:1527272459025};\\\", \\\"{x:1350,y:695,t:1527272459050};\\\", \\\"{x:1349,y:696,t:1527272459065};\\\", \\\"{x:1351,y:697,t:1527272476754};\\\", \\\"{x:1353,y:697,t:1527272476762};\\\", \\\"{x:1355,y:697,t:1527272476828};\\\", \\\"{x:1359,y:698,t:1527272476842};\\\", \\\"{x:1361,y:699,t:1527272476857};\\\", \\\"{x:1369,y:703,t:1527272476874};\\\", \\\"{x:1372,y:703,t:1527272476891};\\\", \\\"{x:1374,y:704,t:1527272476908};\\\", \\\"{x:1375,y:704,t:1527272476925};\\\", \\\"{x:1376,y:704,t:1527272476941};\\\", \\\"{x:1378,y:705,t:1527272476958};\\\", \\\"{x:1379,y:706,t:1527272477026};\\\", \\\"{x:1381,y:706,t:1527272477040};\\\", \\\"{x:1386,y:707,t:1527272477058};\\\", \\\"{x:1392,y:710,t:1527272477074};\\\", \\\"{x:1395,y:710,t:1527272477092};\\\", \\\"{x:1400,y:710,t:1527272477108};\\\", \\\"{x:1411,y:710,t:1527272477124};\\\", \\\"{x:1421,y:710,t:1527272477142};\\\", \\\"{x:1430,y:710,t:1527272477158};\\\", \\\"{x:1433,y:710,t:1527272477175};\\\", \\\"{x:1437,y:710,t:1527272477191};\\\", \\\"{x:1435,y:709,t:1527272477323};\\\", \\\"{x:1419,y:704,t:1527272477342};\\\", \\\"{x:1407,y:700,t:1527272477358};\\\", \\\"{x:1405,y:700,t:1527272477374};\\\", \\\"{x:1404,y:699,t:1527272477475};\\\", \\\"{x:1407,y:699,t:1527272477560};\\\", \\\"{x:1413,y:699,t:1527272477573};\\\", \\\"{x:1427,y:699,t:1527272477591};\\\", \\\"{x:1436,y:699,t:1527272477607};\\\", \\\"{x:1441,y:699,t:1527272477624};\\\", \\\"{x:1444,y:699,t:1527272477641};\\\", \\\"{x:1446,y:699,t:1527272477657};\\\", \\\"{x:1449,y:698,t:1527272477673};\\\", \\\"{x:1454,y:698,t:1527272477691};\\\", \\\"{x:1460,y:698,t:1527272477708};\\\", \\\"{x:1462,y:698,t:1527272477724};\\\", \\\"{x:1464,y:698,t:1527272477785};\\\", \\\"{x:1465,y:698,t:1527272477802};\\\", \\\"{x:1466,y:698,t:1527272477817};\\\", \\\"{x:1467,y:698,t:1527272477866};\\\", \\\"{x:1471,y:698,t:1527272477874};\\\", \\\"{x:1480,y:698,t:1527272477891};\\\", \\\"{x:1483,y:698,t:1527272477909};\\\", \\\"{x:1484,y:698,t:1527272477979};\\\", \\\"{x:1485,y:698,t:1527272478146};\\\", \\\"{x:1487,y:698,t:1527272478158};\\\", \\\"{x:1496,y:698,t:1527272478175};\\\", \\\"{x:1508,y:698,t:1527272478192};\\\", \\\"{x:1523,y:698,t:1527272478208};\\\", \\\"{x:1532,y:698,t:1527272478225};\\\", \\\"{x:1539,y:698,t:1527272478242};\\\", \\\"{x:1553,y:696,t:1527272478258};\\\", \\\"{x:1556,y:696,t:1527272478275};\\\", \\\"{x:1557,y:696,t:1527272478297};\\\", \\\"{x:1554,y:696,t:1527272478426};\\\", \\\"{x:1553,y:696,t:1527272478442};\\\", \\\"{x:1555,y:695,t:1527272478571};\\\", \\\"{x:1565,y:695,t:1527272478578};\\\", \\\"{x:1576,y:695,t:1527272478592};\\\", \\\"{x:1589,y:695,t:1527272478609};\\\", \\\"{x:1610,y:695,t:1527272478627};\\\", \\\"{x:1620,y:695,t:1527272478642};\\\", \\\"{x:1624,y:695,t:1527272478660};\\\", \\\"{x:1625,y:695,t:1527272478676};\\\", \\\"{x:1624,y:695,t:1527272478858};\\\", \\\"{x:1623,y:695,t:1527272478876};\\\", \\\"{x:1622,y:695,t:1527272479202};\\\", \\\"{x:1620,y:695,t:1527272479210};\\\", \\\"{x:1617,y:696,t:1527272479225};\\\", \\\"{x:1612,y:696,t:1527272479241};\\\", \\\"{x:1611,y:696,t:1527272479329};\\\", \\\"{x:1610,y:696,t:1527272479341};\\\", \\\"{x:1609,y:696,t:1527272479362};\\\", \\\"{x:1608,y:699,t:1527272481404};\\\", \\\"{x:1608,y:702,t:1527272481412};\\\", \\\"{x:1608,y:707,t:1527272481428};\\\", \\\"{x:1608,y:712,t:1527272481445};\\\", \\\"{x:1608,y:715,t:1527272481462};\\\", \\\"{x:1608,y:716,t:1527272481478};\\\", \\\"{x:1607,y:718,t:1527272481494};\\\", \\\"{x:1607,y:720,t:1527272481512};\\\", \\\"{x:1607,y:724,t:1527272481527};\\\", \\\"{x:1607,y:729,t:1527272481545};\\\", \\\"{x:1607,y:740,t:1527272481562};\\\", \\\"{x:1607,y:743,t:1527272481578};\\\", \\\"{x:1607,y:752,t:1527272481594};\\\", \\\"{x:1607,y:755,t:1527272481611};\\\", \\\"{x:1607,y:758,t:1527272481627};\\\", \\\"{x:1607,y:763,t:1527272481645};\\\", \\\"{x:1607,y:767,t:1527272481661};\\\", \\\"{x:1607,y:774,t:1527272481677};\\\", \\\"{x:1607,y:781,t:1527272481694};\\\", \\\"{x:1607,y:791,t:1527272481711};\\\", \\\"{x:1607,y:801,t:1527272481727};\\\", \\\"{x:1607,y:810,t:1527272481744};\\\", \\\"{x:1607,y:817,t:1527272481761};\\\", \\\"{x:1607,y:819,t:1527272481777};\\\", \\\"{x:1607,y:823,t:1527272481794};\\\", \\\"{x:1607,y:827,t:1527272481811};\\\", \\\"{x:1607,y:834,t:1527272481828};\\\", \\\"{x:1607,y:842,t:1527272481844};\\\", \\\"{x:1607,y:847,t:1527272481861};\\\", \\\"{x:1607,y:853,t:1527272481879};\\\", \\\"{x:1607,y:859,t:1527272481894};\\\", \\\"{x:1607,y:870,t:1527272481911};\\\", \\\"{x:1607,y:878,t:1527272481929};\\\", \\\"{x:1607,y:888,t:1527272481944};\\\", \\\"{x:1610,y:902,t:1527272481961};\\\", \\\"{x:1611,y:912,t:1527272481977};\\\", \\\"{x:1612,y:919,t:1527272481995};\\\", \\\"{x:1612,y:922,t:1527272482012};\\\", \\\"{x:1612,y:926,t:1527272482029};\\\", \\\"{x:1612,y:931,t:1527272482045};\\\", \\\"{x:1612,y:937,t:1527272482062};\\\", \\\"{x:1612,y:944,t:1527272482078};\\\", \\\"{x:1612,y:948,t:1527272482094};\\\", \\\"{x:1612,y:949,t:1527272482112};\\\", \\\"{x:1612,y:951,t:1527272482128};\\\", \\\"{x:1612,y:952,t:1527272482211};\\\", \\\"{x:1612,y:957,t:1527272482229};\\\", \\\"{x:1612,y:959,t:1527272482245};\\\", \\\"{x:1610,y:950,t:1527272496670};\\\", \\\"{x:1605,y:941,t:1527272496677};\\\", \\\"{x:1599,y:925,t:1527272496694};\\\", \\\"{x:1592,y:908,t:1527272496710};\\\", \\\"{x:1583,y:892,t:1527272496727};\\\", \\\"{x:1575,y:876,t:1527272496745};\\\", \\\"{x:1566,y:861,t:1527272496761};\\\", \\\"{x:1560,y:848,t:1527272496777};\\\", \\\"{x:1554,y:835,t:1527272496794};\\\", \\\"{x:1547,y:827,t:1527272496811};\\\", \\\"{x:1543,y:822,t:1527272496828};\\\", \\\"{x:1538,y:818,t:1527272496844};\\\", \\\"{x:1531,y:813,t:1527272496861};\\\", \\\"{x:1528,y:812,t:1527272496877};\\\", \\\"{x:1526,y:810,t:1527272496894};\\\", \\\"{x:1520,y:807,t:1527272496911};\\\", \\\"{x:1512,y:803,t:1527272496927};\\\", \\\"{x:1503,y:801,t:1527272496944};\\\", \\\"{x:1497,y:800,t:1527272496961};\\\", \\\"{x:1493,y:800,t:1527272496977};\\\", \\\"{x:1491,y:800,t:1527272496994};\\\", \\\"{x:1485,y:800,t:1527272497011};\\\", \\\"{x:1476,y:800,t:1527272497027};\\\", \\\"{x:1471,y:801,t:1527272497044};\\\", \\\"{x:1465,y:804,t:1527272497062};\\\", \\\"{x:1463,y:808,t:1527272497078};\\\", \\\"{x:1462,y:813,t:1527272497094};\\\", \\\"{x:1460,y:815,t:1527272497111};\\\", \\\"{x:1460,y:818,t:1527272497128};\\\", \\\"{x:1460,y:821,t:1527272497144};\\\", \\\"{x:1460,y:822,t:1527272497161};\\\", \\\"{x:1460,y:824,t:1527272497181};\\\", \\\"{x:1462,y:824,t:1527272497294};\\\", \\\"{x:1463,y:824,t:1527272497311};\\\", \\\"{x:1467,y:824,t:1527272497329};\\\", \\\"{x:1469,y:824,t:1527272497344};\\\", \\\"{x:1472,y:824,t:1527272497361};\\\", \\\"{x:1473,y:824,t:1527272497379};\\\", \\\"{x:1475,y:824,t:1527272497394};\\\", \\\"{x:1476,y:824,t:1527272497411};\\\", \\\"{x:1478,y:824,t:1527272497428};\\\", \\\"{x:1481,y:823,t:1527272497444};\\\", \\\"{x:1483,y:821,t:1527272497461};\\\", \\\"{x:1484,y:820,t:1527272497478};\\\", \\\"{x:1486,y:816,t:1527272497496};\\\", \\\"{x:1486,y:812,t:1527272497512};\\\", \\\"{x:1486,y:808,t:1527272497528};\\\", \\\"{x:1487,y:804,t:1527272497545};\\\", \\\"{x:1489,y:799,t:1527272497562};\\\", \\\"{x:1489,y:802,t:1527272497654};\\\", \\\"{x:1489,y:805,t:1527272497661};\\\", \\\"{x:1489,y:809,t:1527272497678};\\\", \\\"{x:1489,y:811,t:1527272497694};\\\", \\\"{x:1488,y:811,t:1527272497711};\\\", \\\"{x:1488,y:812,t:1527272497733};\\\", \\\"{x:1488,y:813,t:1527272497773};\\\", \\\"{x:1488,y:814,t:1527272497789};\\\", \\\"{x:1487,y:814,t:1527272497796};\\\", \\\"{x:1486,y:816,t:1527272497811};\\\", \\\"{x:1485,y:819,t:1527272497828};\\\", \\\"{x:1484,y:821,t:1527272497845};\\\", \\\"{x:1483,y:822,t:1527272497894};\\\", \\\"{x:1483,y:823,t:1527272497902};\\\", \\\"{x:1482,y:823,t:1527272497911};\\\", \\\"{x:1480,y:827,t:1527272497929};\\\", \\\"{x:1480,y:831,t:1527272497945};\\\", \\\"{x:1479,y:834,t:1527272497962};\\\", \\\"{x:1479,y:837,t:1527272498943};\\\", \\\"{x:1479,y:838,t:1527272498950};\\\", \\\"{x:1479,y:841,t:1527272498963};\\\", \\\"{x:1479,y:846,t:1527272498979};\\\", \\\"{x:1480,y:853,t:1527272498996};\\\", \\\"{x:1480,y:867,t:1527272499012};\\\", \\\"{x:1482,y:884,t:1527272499029};\\\", \\\"{x:1482,y:889,t:1527272499046};\\\", \\\"{x:1482,y:893,t:1527272499062};\\\", \\\"{x:1482,y:896,t:1527272499079};\\\", \\\"{x:1482,y:897,t:1527272499097};\\\", \\\"{x:1482,y:901,t:1527272499112};\\\", \\\"{x:1482,y:906,t:1527272499129};\\\", \\\"{x:1482,y:910,t:1527272499147};\\\", \\\"{x:1484,y:912,t:1527272499162};\\\", \\\"{x:1484,y:915,t:1527272499179};\\\", \\\"{x:1484,y:917,t:1527272499197};\\\", \\\"{x:1484,y:918,t:1527272499212};\\\", \\\"{x:1485,y:922,t:1527272499228};\\\", \\\"{x:1485,y:925,t:1527272499245};\\\", \\\"{x:1485,y:924,t:1527272499405};\\\", \\\"{x:1485,y:921,t:1527272499413};\\\", \\\"{x:1484,y:917,t:1527272499429};\\\", \\\"{x:1483,y:917,t:1527272499621};\\\", \\\"{x:1481,y:912,t:1527272499629};\\\", \\\"{x:1480,y:906,t:1527272499646};\\\", \\\"{x:1476,y:896,t:1527272499662};\\\", \\\"{x:1471,y:887,t:1527272499680};\\\", \\\"{x:1469,y:878,t:1527272499696};\\\", \\\"{x:1469,y:870,t:1527272499713};\\\", \\\"{x:1469,y:864,t:1527272499730};\\\", \\\"{x:1469,y:862,t:1527272499746};\\\", \\\"{x:1469,y:860,t:1527272499854};\\\", \\\"{x:1469,y:858,t:1527272499863};\\\", \\\"{x:1469,y:852,t:1527272499879};\\\", \\\"{x:1470,y:849,t:1527272499896};\\\", \\\"{x:1471,y:847,t:1527272499913};\\\", \\\"{x:1472,y:845,t:1527272499933};\\\", \\\"{x:1472,y:844,t:1527272499949};\\\", \\\"{x:1474,y:842,t:1527272499973};\\\", \\\"{x:1474,y:841,t:1527272499997};\\\", \\\"{x:1475,y:840,t:1527272500013};\\\", \\\"{x:1475,y:839,t:1527272500031};\\\", \\\"{x:1477,y:838,t:1527272500069};\\\", \\\"{x:1478,y:838,t:1527272500081};\\\", \\\"{x:1484,y:836,t:1527272500098};\\\", \\\"{x:1486,y:835,t:1527272500114};\\\", \\\"{x:1491,y:834,t:1527272500130};\\\", \\\"{x:1496,y:833,t:1527272500147};\\\", \\\"{x:1508,y:831,t:1527272500163};\\\", \\\"{x:1523,y:830,t:1527272500181};\\\", \\\"{x:1543,y:828,t:1527272500197};\\\", \\\"{x:1547,y:828,t:1527272500214};\\\", \\\"{x:1549,y:827,t:1527272500230};\\\", \\\"{x:1550,y:827,t:1527272500446};\\\", \\\"{x:1561,y:827,t:1527272500463};\\\", \\\"{x:1573,y:827,t:1527272500480};\\\", \\\"{x:1583,y:827,t:1527272500497};\\\", \\\"{x:1587,y:827,t:1527272500513};\\\", \\\"{x:1588,y:826,t:1527272500529};\\\", \\\"{x:1589,y:826,t:1527272500546};\\\", \\\"{x:1590,y:826,t:1527272500565};\\\", \\\"{x:1591,y:826,t:1527272500579};\\\", \\\"{x:1593,y:826,t:1527272500597};\\\", \\\"{x:1594,y:826,t:1527272500790};\\\", \\\"{x:1597,y:826,t:1527272500798};\\\", \\\"{x:1604,y:826,t:1527272500814};\\\", \\\"{x:1609,y:826,t:1527272500830};\\\", \\\"{x:1615,y:825,t:1527272500847};\\\", \\\"{x:1619,y:822,t:1527272500864};\\\", \\\"{x:1621,y:822,t:1527272500880};\\\", \\\"{x:1622,y:821,t:1527272500897};\\\", \\\"{x:1621,y:821,t:1527272501846};\\\", \\\"{x:1620,y:821,t:1527272501910};\\\", \\\"{x:1620,y:822,t:1527272501942};\\\", \\\"{x:1619,y:823,t:1527272501949};\\\", \\\"{x:1619,y:824,t:1527272502134};\\\", \\\"{x:1618,y:825,t:1527272502149};\\\", \\\"{x:1617,y:826,t:1527272502165};\\\", \\\"{x:1615,y:827,t:1527272502181};\\\", \\\"{x:1613,y:828,t:1527272502198};\\\", \\\"{x:1611,y:828,t:1527272502406};\\\", \\\"{x:1610,y:828,t:1527272502415};\\\", \\\"{x:1602,y:829,t:1527272502433};\\\", \\\"{x:1594,y:830,t:1527272502448};\\\", \\\"{x:1589,y:832,t:1527272502466};\\\", \\\"{x:1587,y:832,t:1527272502482};\\\", \\\"{x:1586,y:832,t:1527272502498};\\\", \\\"{x:1581,y:832,t:1527272502516};\\\", \\\"{x:1563,y:832,t:1527272502532};\\\", \\\"{x:1536,y:832,t:1527272502548};\\\", \\\"{x:1497,y:833,t:1527272502565};\\\", \\\"{x:1480,y:835,t:1527272502582};\\\", \\\"{x:1470,y:835,t:1527272502599};\\\", \\\"{x:1463,y:835,t:1527272502615};\\\", \\\"{x:1459,y:835,t:1527272502633};\\\", \\\"{x:1464,y:834,t:1527272502758};\\\", \\\"{x:1470,y:834,t:1527272502765};\\\", \\\"{x:1480,y:834,t:1527272502782};\\\", \\\"{x:1483,y:834,t:1527272502799};\\\", \\\"{x:1485,y:834,t:1527272502815};\\\", \\\"{x:1485,y:833,t:1527272502998};\\\", \\\"{x:1484,y:832,t:1527272503015};\\\", \\\"{x:1482,y:832,t:1527272503109};\\\", \\\"{x:1478,y:832,t:1527272503117};\\\", \\\"{x:1474,y:832,t:1527272503134};\\\", \\\"{x:1429,y:829,t:1527272503149};\\\", \\\"{x:1335,y:815,t:1527272503165};\\\", \\\"{x:1191,y:796,t:1527272503183};\\\", \\\"{x:1022,y:771,t:1527272503199};\\\", \\\"{x:842,y:740,t:1527272503217};\\\", \\\"{x:711,y:721,t:1527272503232};\\\", \\\"{x:620,y:708,t:1527272503249};\\\", \\\"{x:579,y:701,t:1527272503266};\\\", \\\"{x:563,y:694,t:1527272503283};\\\", \\\"{x:560,y:691,t:1527272503300};\\\", \\\"{x:559,y:689,t:1527272503317};\\\", \\\"{x:562,y:683,t:1527272503332};\\\", \\\"{x:575,y:671,t:1527272503349};\\\", \\\"{x:578,y:666,t:1527272503366};\\\", \\\"{x:579,y:662,t:1527272503382};\\\", \\\"{x:579,y:657,t:1527272503399};\\\", \\\"{x:579,y:654,t:1527272503416};\\\", \\\"{x:587,y:647,t:1527272503433};\\\", \\\"{x:604,y:635,t:1527272503450};\\\", \\\"{x:614,y:624,t:1527272503467};\\\", \\\"{x:615,y:619,t:1527272503482};\\\", \\\"{x:617,y:612,t:1527272503499};\\\", \\\"{x:616,y:605,t:1527272503513};\\\", \\\"{x:616,y:598,t:1527272503530};\\\", \\\"{x:616,y:594,t:1527272503547};\\\", \\\"{x:616,y:583,t:1527272503567};\\\", \\\"{x:617,y:576,t:1527272503582};\\\", \\\"{x:617,y:574,t:1527272503598};\\\", \\\"{x:617,y:572,t:1527272503616};\\\", \\\"{x:617,y:569,t:1527272503632};\\\", \\\"{x:622,y:571,t:1527272503949};\\\", \\\"{x:634,y:587,t:1527272503965};\\\", \\\"{x:652,y:606,t:1527272503984};\\\", \\\"{x:695,y:625,t:1527272503999};\\\", \\\"{x:768,y:648,t:1527272504016};\\\", \\\"{x:867,y:672,t:1527272504032};\\\", \\\"{x:940,y:686,t:1527272504048};\\\", \\\"{x:1023,y:698,t:1527272504066};\\\", \\\"{x:1136,y:729,t:1527272504083};\\\", \\\"{x:1269,y:763,t:1527272504099};\\\", \\\"{x:1394,y:803,t:1527272504116};\\\", \\\"{x:1507,y:824,t:1527272504133};\\\", \\\"{x:1530,y:824,t:1527272504148};\\\", \\\"{x:1538,y:824,t:1527272504165};\\\", \\\"{x:1545,y:824,t:1527272504184};\\\", \\\"{x:1555,y:826,t:1527272504199};\\\", \\\"{x:1563,y:826,t:1527272504216};\\\", \\\"{x:1565,y:817,t:1527272504233};\\\", \\\"{x:1563,y:817,t:1527272504454};\\\", \\\"{x:1556,y:820,t:1527272504466};\\\", \\\"{x:1533,y:825,t:1527272504483};\\\", \\\"{x:1520,y:833,t:1527272504500};\\\", \\\"{x:1513,y:836,t:1527272504516};\\\", \\\"{x:1512,y:837,t:1527272504557};\\\", \\\"{x:1510,y:837,t:1527272504580};\\\", \\\"{x:1506,y:837,t:1527272504589};\\\", \\\"{x:1499,y:837,t:1527272504600};\\\", \\\"{x:1483,y:837,t:1527272504616};\\\", \\\"{x:1470,y:837,t:1527272504633};\\\", \\\"{x:1464,y:838,t:1527272504650};\\\", \\\"{x:1462,y:839,t:1527272504666};\\\", \\\"{x:1463,y:839,t:1527272505470};\\\", \\\"{x:1464,y:839,t:1527272505484};\\\", \\\"{x:1466,y:839,t:1527272505501};\\\", \\\"{x:1468,y:839,t:1527272505517};\\\", \\\"{x:1470,y:838,t:1527272505854};\\\", \\\"{x:1472,y:838,t:1527272505867};\\\", \\\"{x:1477,y:837,t:1527272505884};\\\", \\\"{x:1481,y:835,t:1527272505902};\\\", \\\"{x:1484,y:831,t:1527272508910};\\\", \\\"{x:1484,y:826,t:1527272508920};\\\", \\\"{x:1487,y:820,t:1527272508938};\\\", \\\"{x:1489,y:814,t:1527272508953};\\\", \\\"{x:1489,y:810,t:1527272508970};\\\", \\\"{x:1491,y:806,t:1527272508987};\\\", \\\"{x:1492,y:805,t:1527272509004};\\\", \\\"{x:1492,y:804,t:1527272509021};\\\", \\\"{x:1492,y:803,t:1527272509206};\\\", \\\"{x:1492,y:802,t:1527272509220};\\\", \\\"{x:1495,y:797,t:1527272509236};\\\", \\\"{x:1500,y:791,t:1527272509253};\\\", \\\"{x:1502,y:788,t:1527272509270};\\\", \\\"{x:1505,y:785,t:1527272509286};\\\", \\\"{x:1507,y:783,t:1527272509303};\\\", \\\"{x:1510,y:781,t:1527272509320};\\\", \\\"{x:1511,y:779,t:1527272509336};\\\", \\\"{x:1514,y:776,t:1527272509353};\\\", \\\"{x:1521,y:770,t:1527272509370};\\\", \\\"{x:1525,y:766,t:1527272509387};\\\", \\\"{x:1526,y:765,t:1527272509403};\\\", \\\"{x:1528,y:763,t:1527272509421};\\\", \\\"{x:1528,y:762,t:1527272509438};\\\", \\\"{x:1527,y:765,t:1527272509533};\\\", \\\"{x:1524,y:770,t:1527272509541};\\\", \\\"{x:1521,y:775,t:1527272509554};\\\", \\\"{x:1513,y:787,t:1527272509570};\\\", \\\"{x:1507,y:796,t:1527272509588};\\\", \\\"{x:1503,y:800,t:1527272509603};\\\", \\\"{x:1502,y:802,t:1527272509621};\\\", \\\"{x:1502,y:804,t:1527272509677};\\\", \\\"{x:1502,y:806,t:1527272509688};\\\", \\\"{x:1502,y:809,t:1527272509704};\\\", \\\"{x:1500,y:813,t:1527272509720};\\\", \\\"{x:1500,y:814,t:1527272509737};\\\", \\\"{x:1499,y:815,t:1527272509754};\\\", \\\"{x:1498,y:815,t:1527272509771};\\\", \\\"{x:1497,y:816,t:1527272509788};\\\", \\\"{x:1495,y:819,t:1527272509803};\\\", \\\"{x:1495,y:822,t:1527272509821};\\\", \\\"{x:1492,y:827,t:1527272509837};\\\", \\\"{x:1491,y:830,t:1527272509854};\\\", \\\"{x:1490,y:831,t:1527272509871};\\\", \\\"{x:1489,y:833,t:1527272509888};\\\", \\\"{x:1490,y:833,t:1527272510085};\\\", \\\"{x:1491,y:833,t:1527272510100};\\\", \\\"{x:1493,y:833,t:1527272510132};\\\", \\\"{x:1494,y:833,t:1527272510140};\\\", \\\"{x:1495,y:833,t:1527272510157};\\\", \\\"{x:1497,y:833,t:1527272510170};\\\", \\\"{x:1500,y:833,t:1527272510187};\\\", \\\"{x:1505,y:833,t:1527272510204};\\\", \\\"{x:1518,y:834,t:1527272510220};\\\", \\\"{x:1534,y:836,t:1527272510238};\\\", \\\"{x:1545,y:836,t:1527272510255};\\\", \\\"{x:1552,y:836,t:1527272510271};\\\", \\\"{x:1556,y:836,t:1527272510287};\\\", \\\"{x:1560,y:836,t:1527272510305};\\\", \\\"{x:1562,y:835,t:1527272510321};\\\", \\\"{x:1564,y:834,t:1527272510397};\\\", \\\"{x:1565,y:834,t:1527272510405};\\\", \\\"{x:1566,y:834,t:1527272510421};\\\", \\\"{x:1567,y:834,t:1527272510453};\\\", \\\"{x:1570,y:833,t:1527272510471};\\\", \\\"{x:1577,y:833,t:1527272510488};\\\", \\\"{x:1588,y:833,t:1527272510504};\\\", \\\"{x:1600,y:833,t:1527272510521};\\\", \\\"{x:1608,y:831,t:1527272510538};\\\", \\\"{x:1611,y:830,t:1527272510555};\\\", \\\"{x:1613,y:828,t:1527272510572};\\\", \\\"{x:1615,y:827,t:1527272510589};\\\", \\\"{x:1616,y:826,t:1527272510605};\\\", \\\"{x:1617,y:824,t:1527272512621};\\\", \\\"{x:1609,y:817,t:1527272512640};\\\", \\\"{x:1599,y:813,t:1527272512656};\\\", \\\"{x:1591,y:810,t:1527272512673};\\\", \\\"{x:1585,y:807,t:1527272512690};\\\", \\\"{x:1578,y:804,t:1527272512705};\\\", \\\"{x:1573,y:801,t:1527272512723};\\\", \\\"{x:1564,y:797,t:1527272512740};\\\", \\\"{x:1554,y:792,t:1527272512757};\\\", \\\"{x:1544,y:786,t:1527272512773};\\\", \\\"{x:1537,y:784,t:1527272512790};\\\", \\\"{x:1528,y:780,t:1527272512807};\\\", \\\"{x:1519,y:778,t:1527272512823};\\\", \\\"{x:1511,y:775,t:1527272512840};\\\", \\\"{x:1507,y:774,t:1527272512857};\\\", \\\"{x:1505,y:772,t:1527272513006};\\\", \\\"{x:1504,y:771,t:1527272513029};\\\", \\\"{x:1504,y:770,t:1527272513198};\\\", \\\"{x:1507,y:770,t:1527272513207};\\\", \\\"{x:1512,y:770,t:1527272513223};\\\", \\\"{x:1521,y:770,t:1527272513240};\\\", \\\"{x:1534,y:770,t:1527272513257};\\\", \\\"{x:1538,y:770,t:1527272513273};\\\", \\\"{x:1539,y:770,t:1527272513292};\\\", \\\"{x:1539,y:769,t:1527272513332};\\\", \\\"{x:1541,y:769,t:1527272513341};\\\", \\\"{x:1542,y:770,t:1527272513356};\\\", \\\"{x:1548,y:772,t:1527272513373};\\\", \\\"{x:1554,y:773,t:1527272513389};\\\", \\\"{x:1561,y:774,t:1527272513407};\\\", \\\"{x:1568,y:774,t:1527272513423};\\\", \\\"{x:1570,y:774,t:1527272513439};\\\", \\\"{x:1571,y:774,t:1527272513509};\\\", \\\"{x:1573,y:774,t:1527272513572};\\\", \\\"{x:1580,y:774,t:1527272513589};\\\", \\\"{x:1585,y:774,t:1527272513606};\\\", \\\"{x:1591,y:774,t:1527272513624};\\\", \\\"{x:1596,y:774,t:1527272513639};\\\", \\\"{x:1608,y:774,t:1527272513656};\\\", \\\"{x:1622,y:774,t:1527272513673};\\\", \\\"{x:1633,y:776,t:1527272513690};\\\", \\\"{x:1638,y:777,t:1527272513707};\\\", \\\"{x:1640,y:778,t:1527272513724};\\\", \\\"{x:1640,y:777,t:1527272513854};\\\", \\\"{x:1640,y:776,t:1527272513869};\\\", \\\"{x:1640,y:775,t:1527272513878};\\\", \\\"{x:1642,y:774,t:1527272513891};\\\", \\\"{x:1644,y:773,t:1527272513908};\\\", \\\"{x:1648,y:769,t:1527272513924};\\\", \\\"{x:1655,y:767,t:1527272513941};\\\", \\\"{x:1665,y:765,t:1527272513958};\\\", \\\"{x:1674,y:764,t:1527272513974};\\\", \\\"{x:1681,y:764,t:1527272513991};\\\", \\\"{x:1684,y:764,t:1527272514007};\\\", \\\"{x:1685,y:764,t:1527272514078};\\\", \\\"{x:1688,y:764,t:1527272514094};\\\", \\\"{x:1692,y:764,t:1527272514107};\\\", \\\"{x:1698,y:764,t:1527272514124};\\\", \\\"{x:1701,y:763,t:1527272514141};\\\", \\\"{x:1702,y:763,t:1527272514157};\\\", \\\"{x:1703,y:763,t:1527272514229};\\\", \\\"{x:1705,y:763,t:1527272514240};\\\", \\\"{x:1708,y:763,t:1527272514258};\\\", \\\"{x:1709,y:763,t:1527272514517};\\\", \\\"{x:1709,y:765,t:1527272514526};\\\", \\\"{x:1709,y:771,t:1527272514541};\\\", \\\"{x:1708,y:774,t:1527272514558};\\\", \\\"{x:1707,y:778,t:1527272514574};\\\", \\\"{x:1705,y:780,t:1527272514591};\\\", \\\"{x:1704,y:781,t:1527272514607};\\\", \\\"{x:1697,y:782,t:1527272514624};\\\", \\\"{x:1680,y:786,t:1527272514641};\\\", \\\"{x:1643,y:789,t:1527272514659};\\\", \\\"{x:1601,y:796,t:1527272514675};\\\", \\\"{x:1569,y:803,t:1527272514691};\\\", \\\"{x:1536,y:808,t:1527272514708};\\\", \\\"{x:1499,y:809,t:1527272514725};\\\", \\\"{x:1455,y:809,t:1527272514742};\\\", \\\"{x:1445,y:809,t:1527272514758};\\\", \\\"{x:1442,y:809,t:1527272514775};\\\", \\\"{x:1437,y:809,t:1527272514791};\\\", \\\"{x:1431,y:807,t:1527272514808};\\\", \\\"{x:1426,y:806,t:1527272514825};\\\", \\\"{x:1425,y:806,t:1527272514841};\\\", \\\"{x:1422,y:804,t:1527272514858};\\\", \\\"{x:1417,y:801,t:1527272514875};\\\", \\\"{x:1406,y:797,t:1527272514891};\\\", \\\"{x:1389,y:789,t:1527272514908};\\\", \\\"{x:1366,y:783,t:1527272514925};\\\", \\\"{x:1364,y:782,t:1527272514941};\\\", \\\"{x:1363,y:781,t:1527272514990};\\\", \\\"{x:1363,y:780,t:1527272515008};\\\", \\\"{x:1362,y:778,t:1527272515025};\\\", \\\"{x:1362,y:776,t:1527272515041};\\\", \\\"{x:1362,y:775,t:1527272515126};\\\", \\\"{x:1362,y:771,t:1527272515141};\\\", \\\"{x:1362,y:770,t:1527272515158};\\\", \\\"{x:1362,y:769,t:1527272515175};\\\", \\\"{x:1360,y:767,t:1527272515192};\\\", \\\"{x:1358,y:767,t:1527272515207};\\\", \\\"{x:1354,y:767,t:1527272515224};\\\", \\\"{x:1353,y:767,t:1527272515261};\\\", \\\"{x:1353,y:766,t:1527272515517};\\\", \\\"{x:1350,y:764,t:1527272515526};\\\", \\\"{x:1349,y:761,t:1527272515541};\\\", \\\"{x:1346,y:755,t:1527272515558};\\\", \\\"{x:1345,y:746,t:1527272515575};\\\", \\\"{x:1341,y:733,t:1527272515592};\\\", \\\"{x:1339,y:722,t:1527272515609};\\\", \\\"{x:1339,y:717,t:1527272515625};\\\", \\\"{x:1339,y:713,t:1527272515642};\\\", \\\"{x:1337,y:709,t:1527272515660};\\\", \\\"{x:1337,y:707,t:1527272515674};\\\", \\\"{x:1337,y:705,t:1527272515692};\\\", \\\"{x:1337,y:703,t:1527272515708};\\\", \\\"{x:1337,y:702,t:1527272515725};\\\", \\\"{x:1337,y:700,t:1527272515742};\\\", \\\"{x:1339,y:698,t:1527272515759};\\\", \\\"{x:1341,y:697,t:1527272515775};\\\", \\\"{x:1342,y:695,t:1527272515793};\\\", \\\"{x:1343,y:695,t:1527272515809};\\\", \\\"{x:1344,y:694,t:1527272515824};\\\", \\\"{x:1345,y:694,t:1527272515853};\\\", \\\"{x:1345,y:693,t:1527272515861};\\\", \\\"{x:1346,y:693,t:1527272515875};\\\", \\\"{x:1347,y:693,t:1527272515949};\\\", \\\"{x:1348,y:693,t:1527272516301};\\\", \\\"{x:1351,y:693,t:1527272516309};\\\", \\\"{x:1354,y:693,t:1527272516327};\\\", \\\"{x:1358,y:696,t:1527272516397};\\\", \\\"{x:1360,y:696,t:1527272516409};\\\", \\\"{x:1365,y:696,t:1527272516425};\\\", \\\"{x:1368,y:696,t:1527272516442};\\\", \\\"{x:1370,y:696,t:1527272516460};\\\", \\\"{x:1373,y:696,t:1527272516476};\\\", \\\"{x:1383,y:696,t:1527272516492};\\\", \\\"{x:1407,y:696,t:1527272516509};\\\", \\\"{x:1419,y:696,t:1527272516525};\\\", \\\"{x:1423,y:696,t:1527272516543};\\\", \\\"{x:1425,y:696,t:1527272516559};\\\", \\\"{x:1426,y:696,t:1527272516773};\\\", \\\"{x:1429,y:697,t:1527272516782};\\\", \\\"{x:1435,y:699,t:1527272516793};\\\", \\\"{x:1447,y:701,t:1527272516809};\\\", \\\"{x:1455,y:701,t:1527272516826};\\\", \\\"{x:1461,y:701,t:1527272516843};\\\", \\\"{x:1467,y:701,t:1527272516861};\\\", \\\"{x:1468,y:701,t:1527272516876};\\\", \\\"{x:1475,y:701,t:1527272516893};\\\", \\\"{x:1481,y:701,t:1527272516909};\\\", \\\"{x:1487,y:701,t:1527272516926};\\\", \\\"{x:1489,y:701,t:1527272516943};\\\", \\\"{x:1490,y:701,t:1527272517006};\\\", \\\"{x:1493,y:701,t:1527272517013};\\\", \\\"{x:1494,y:701,t:1527272517026};\\\", \\\"{x:1501,y:701,t:1527272517043};\\\", \\\"{x:1505,y:701,t:1527272517060};\\\", \\\"{x:1511,y:701,t:1527272517076};\\\", \\\"{x:1518,y:701,t:1527272517094};\\\", \\\"{x:1523,y:701,t:1527272517109};\\\", \\\"{x:1528,y:701,t:1527272517126};\\\", \\\"{x:1534,y:701,t:1527272517143};\\\", \\\"{x:1539,y:701,t:1527272517160};\\\", \\\"{x:1543,y:701,t:1527272517176};\\\", \\\"{x:1546,y:701,t:1527272517193};\\\", \\\"{x:1549,y:701,t:1527272517209};\\\", \\\"{x:1550,y:701,t:1527272517229};\\\", \\\"{x:1552,y:700,t:1527272517245};\\\", \\\"{x:1553,y:700,t:1527272517277};\\\", \\\"{x:1558,y:700,t:1527272517293};\\\", \\\"{x:1566,y:700,t:1527272517309};\\\", \\\"{x:1577,y:700,t:1527272517325};\\\", \\\"{x:1584,y:700,t:1527272517342};\\\", \\\"{x:1589,y:700,t:1527272517360};\\\", \\\"{x:1596,y:700,t:1527272517375};\\\", \\\"{x:1603,y:700,t:1527272517393};\\\", \\\"{x:1614,y:700,t:1527272517409};\\\", \\\"{x:1622,y:700,t:1527272517425};\\\", \\\"{x:1624,y:700,t:1527272517442};\\\", \\\"{x:1622,y:700,t:1527272517757};\\\", \\\"{x:1617,y:700,t:1527272517766};\\\", \\\"{x:1606,y:695,t:1527272517778};\\\", \\\"{x:1585,y:694,t:1527272517793};\\\", \\\"{x:1569,y:690,t:1527272517810};\\\", \\\"{x:1562,y:687,t:1527272517827};\\\", \\\"{x:1550,y:685,t:1527272517843};\\\", \\\"{x:1536,y:681,t:1527272517860};\\\", \\\"{x:1514,y:675,t:1527272517877};\\\", \\\"{x:1509,y:674,t:1527272517893};\\\", \\\"{x:1506,y:673,t:1527272517966};\\\", \\\"{x:1505,y:671,t:1527272517977};\\\", \\\"{x:1492,y:663,t:1527272517994};\\\", \\\"{x:1472,y:656,t:1527272518010};\\\", \\\"{x:1451,y:650,t:1527272518027};\\\", \\\"{x:1447,y:649,t:1527272518043};\\\", \\\"{x:1445,y:649,t:1527272518060};\\\", \\\"{x:1445,y:648,t:1527272518077};\\\", \\\"{x:1444,y:645,t:1527272518093};\\\", \\\"{x:1441,y:640,t:1527272518110};\\\", \\\"{x:1439,y:636,t:1527272518127};\\\", \\\"{x:1438,y:636,t:1527272518144};\\\", \\\"{x:1439,y:635,t:1527272518333};\\\", \\\"{x:1443,y:633,t:1527272518344};\\\", \\\"{x:1446,y:633,t:1527272518359};\\\", \\\"{x:1449,y:632,t:1527272518377};\\\", \\\"{x:1450,y:632,t:1527272518454};\\\", \\\"{x:1450,y:631,t:1527272518469};\\\", \\\"{x:1454,y:631,t:1527272519262};\\\", \\\"{x:1474,y:637,t:1527272519277};\\\", \\\"{x:1488,y:639,t:1527272519293};\\\", \\\"{x:1499,y:640,t:1527272519311};\\\", \\\"{x:1508,y:640,t:1527272519327};\\\", \\\"{x:1512,y:640,t:1527272519344};\\\", \\\"{x:1515,y:640,t:1527272519360};\\\", \\\"{x:1517,y:640,t:1527272519380};\\\", \\\"{x:1518,y:640,t:1527272519614};\\\", \\\"{x:1522,y:640,t:1527272519628};\\\", \\\"{x:1531,y:640,t:1527272519645};\\\", \\\"{x:1532,y:639,t:1527272519661};\\\", \\\"{x:1530,y:637,t:1527272519702};\\\", \\\"{x:1514,y:633,t:1527272519711};\\\", \\\"{x:1473,y:616,t:1527272519728};\\\", \\\"{x:1443,y:608,t:1527272519745};\\\", \\\"{x:1427,y:600,t:1527272519761};\\\", \\\"{x:1419,y:595,t:1527272519778};\\\", \\\"{x:1412,y:587,t:1527272519795};\\\", \\\"{x:1408,y:583,t:1527272519812};\\\", \\\"{x:1408,y:580,t:1527272519828};\\\", \\\"{x:1399,y:574,t:1527272519845};\\\", \\\"{x:1381,y:570,t:1527272519861};\\\", \\\"{x:1359,y:566,t:1527272519878};\\\", \\\"{x:1341,y:565,t:1527272519895};\\\", \\\"{x:1331,y:565,t:1527272519912};\\\", \\\"{x:1324,y:565,t:1527272519928};\\\", \\\"{x:1315,y:565,t:1527272519945};\\\", \\\"{x:1301,y:565,t:1527272519962};\\\", \\\"{x:1292,y:565,t:1527272519978};\\\", \\\"{x:1290,y:565,t:1527272520140};\\\", \\\"{x:1289,y:565,t:1527272520221};\\\", \\\"{x:1287,y:565,t:1527272520229};\\\", \\\"{x:1281,y:565,t:1527272520245};\\\", \\\"{x:1276,y:565,t:1527272520262};\\\", \\\"{x:1282,y:565,t:1527272521037};\\\", \\\"{x:1291,y:566,t:1527272521046};\\\", \\\"{x:1306,y:567,t:1527272521062};\\\", \\\"{x:1315,y:567,t:1527272521079};\\\", \\\"{x:1317,y:567,t:1527272521097};\\\", \\\"{x:1321,y:567,t:1527272521141};\\\", \\\"{x:1326,y:567,t:1527272521149};\\\", \\\"{x:1331,y:567,t:1527272521162};\\\", \\\"{x:1342,y:567,t:1527272521179};\\\", \\\"{x:1344,y:567,t:1527272521196};\\\", \\\"{x:1345,y:567,t:1527272521422};\\\", \\\"{x:1347,y:567,t:1527272521429};\\\", \\\"{x:1349,y:566,t:1527272521446};\\\", \\\"{x:1351,y:566,t:1527272521463};\\\", \\\"{x:1356,y:566,t:1527272521479};\\\", \\\"{x:1365,y:566,t:1527272521496};\\\", \\\"{x:1372,y:566,t:1527272521513};\\\", \\\"{x:1374,y:566,t:1527272521529};\\\", \\\"{x:1376,y:566,t:1527272521549};\\\", \\\"{x:1377,y:566,t:1527272521565};\\\", \\\"{x:1380,y:566,t:1527272521579};\\\", \\\"{x:1387,y:566,t:1527272521596};\\\", \\\"{x:1392,y:566,t:1527272521613};\\\", \\\"{x:1394,y:566,t:1527272521662};\\\", \\\"{x:1397,y:566,t:1527272521669};\\\", \\\"{x:1400,y:567,t:1527272521679};\\\", \\\"{x:1404,y:568,t:1527272521696};\\\", \\\"{x:1406,y:568,t:1527272521758};\\\", \\\"{x:1408,y:568,t:1527272521773};\\\", \\\"{x:1409,y:568,t:1527272521781};\\\", \\\"{x:1411,y:568,t:1527272521990};\\\", \\\"{x:1413,y:568,t:1527272521997};\\\", \\\"{x:1416,y:568,t:1527272522013};\\\", \\\"{x:1418,y:568,t:1527272522031};\\\", \\\"{x:1427,y:568,t:1527272522046};\\\", \\\"{x:1438,y:568,t:1527272522063};\\\", \\\"{x:1444,y:568,t:1527272522081};\\\", \\\"{x:1445,y:568,t:1527272522096};\\\", \\\"{x:1446,y:568,t:1527272522125};\\\", \\\"{x:1449,y:568,t:1527272522133};\\\", \\\"{x:1456,y:568,t:1527272522146};\\\", \\\"{x:1466,y:568,t:1527272522163};\\\", \\\"{x:1467,y:568,t:1527272522180};\\\", \\\"{x:1468,y:568,t:1527272522221};\\\", \\\"{x:1470,y:568,t:1527272522230};\\\", \\\"{x:1476,y:568,t:1527272522247};\\\", \\\"{x:1479,y:568,t:1527272522263};\\\", \\\"{x:1480,y:568,t:1527272522302};\\\", \\\"{x:1481,y:568,t:1527272522406};\\\", \\\"{x:1482,y:567,t:1527272522413};\\\", \\\"{x:1483,y:566,t:1527272522430};\\\", \\\"{x:1484,y:566,t:1527272522448};\\\", \\\"{x:1486,y:565,t:1527272522463};\\\", \\\"{x:1487,y:565,t:1527272522484};\\\", \\\"{x:1488,y:564,t:1527272522496};\\\", \\\"{x:1495,y:564,t:1527272522512};\\\", \\\"{x:1517,y:564,t:1527272522529};\\\", \\\"{x:1538,y:564,t:1527272522547};\\\", \\\"{x:1553,y:562,t:1527272522563};\\\", \\\"{x:1557,y:561,t:1527272522580};\\\", \\\"{x:1558,y:560,t:1527272522596};\\\", \\\"{x:1560,y:560,t:1527272522613};\\\", \\\"{x:1562,y:560,t:1527272522630};\\\", \\\"{x:1563,y:560,t:1527272522646};\\\", \\\"{x:1564,y:559,t:1527272522662};\\\", \\\"{x:1561,y:559,t:1527272522765};\\\", \\\"{x:1557,y:559,t:1527272522780};\\\", \\\"{x:1532,y:559,t:1527272522797};\\\", \\\"{x:1530,y:559,t:1527272522814};\\\", \\\"{x:1532,y:559,t:1527272522981};\\\", \\\"{x:1549,y:561,t:1527272522997};\\\", \\\"{x:1570,y:565,t:1527272523015};\\\", \\\"{x:1590,y:565,t:1527272523030};\\\", \\\"{x:1605,y:565,t:1527272523047};\\\", \\\"{x:1615,y:565,t:1527272523064};\\\", \\\"{x:1616,y:565,t:1527272523080};\\\", \\\"{x:1621,y:565,t:1527272523341};\\\", \\\"{x:1631,y:568,t:1527272523348};\\\", \\\"{x:1639,y:568,t:1527272523363};\\\", \\\"{x:1659,y:568,t:1527272523380};\\\", \\\"{x:1666,y:568,t:1527272523397};\\\", \\\"{x:1667,y:568,t:1527272524158};\\\", \\\"{x:1670,y:568,t:1527272524165};\\\", \\\"{x:1672,y:566,t:1527272524180};\\\", \\\"{x:1673,y:565,t:1527272524198};\\\", \\\"{x:1674,y:565,t:1527272524215};\\\", \\\"{x:1675,y:563,t:1527272524231};\\\", \\\"{x:1676,y:563,t:1527272524260};\\\", \\\"{x:1676,y:566,t:1527272530013};\\\", \\\"{x:1669,y:569,t:1527272530021};\\\", \\\"{x:1659,y:574,t:1527272530035};\\\", \\\"{x:1608,y:579,t:1527272530052};\\\", \\\"{x:1430,y:581,t:1527272530069};\\\", \\\"{x:1300,y:581,t:1527272530085};\\\", \\\"{x:1195,y:581,t:1527272530101};\\\", \\\"{x:1131,y:590,t:1527272530119};\\\", \\\"{x:1102,y:594,t:1527272530135};\\\", \\\"{x:1085,y:596,t:1527272530152};\\\", \\\"{x:1081,y:598,t:1527272530168};\\\", \\\"{x:1080,y:599,t:1527272530805};\\\", \\\"{x:1084,y:603,t:1527272530819};\\\", \\\"{x:1100,y:607,t:1527272530836};\\\", \\\"{x:1147,y:614,t:1527272530852};\\\", \\\"{x:1191,y:618,t:1527272530869};\\\", \\\"{x:1242,y:621,t:1527272530886};\\\", \\\"{x:1277,y:621,t:1527272530903};\\\", \\\"{x:1303,y:619,t:1527272530919};\\\", \\\"{x:1323,y:616,t:1527272530936};\\\", \\\"{x:1340,y:613,t:1527272530953};\\\", \\\"{x:1354,y:610,t:1527272530969};\\\", \\\"{x:1363,y:609,t:1527272530986};\\\", \\\"{x:1368,y:606,t:1527272531004};\\\", \\\"{x:1371,y:602,t:1527272531019};\\\", \\\"{x:1375,y:598,t:1527272531477};\\\", \\\"{x:1379,y:592,t:1527272531486};\\\", \\\"{x:1388,y:579,t:1527272531503};\\\", \\\"{x:1395,y:570,t:1527272531521};\\\", \\\"{x:1399,y:564,t:1527272531536};\\\", \\\"{x:1399,y:559,t:1527272531554};\\\", \\\"{x:1400,y:553,t:1527272531571};\\\", \\\"{x:1405,y:544,t:1527272531587};\\\", \\\"{x:1408,y:537,t:1527272531603};\\\", \\\"{x:1413,y:528,t:1527272531620};\\\", \\\"{x:1417,y:514,t:1527272531637};\\\", \\\"{x:1417,y:504,t:1527272531653};\\\", \\\"{x:1416,y:496,t:1527272531671};\\\", \\\"{x:1415,y:491,t:1527272531687};\\\", \\\"{x:1415,y:488,t:1527272531703};\\\", \\\"{x:1415,y:486,t:1527272531720};\\\", \\\"{x:1415,y:485,t:1527272531737};\\\", \\\"{x:1415,y:482,t:1527272531753};\\\", \\\"{x:1415,y:480,t:1527272531770};\\\", \\\"{x:1415,y:477,t:1527272531787};\\\", \\\"{x:1413,y:474,t:1527272531803};\\\", \\\"{x:1412,y:470,t:1527272531820};\\\", \\\"{x:1412,y:466,t:1527272531837};\\\", \\\"{x:1412,y:463,t:1527272531853};\\\", \\\"{x:1412,y:462,t:1527272531871};\\\", \\\"{x:1410,y:459,t:1527272531887};\\\", \\\"{x:1406,y:456,t:1527272531903};\\\", \\\"{x:1406,y:451,t:1527272531921};\\\", \\\"{x:1405,y:448,t:1527272531937};\\\", \\\"{x:1405,y:447,t:1527272531954};\\\", \\\"{x:1405,y:445,t:1527272531970};\\\", \\\"{x:1405,y:444,t:1527272531989};\\\", \\\"{x:1405,y:442,t:1527272532005};\\\", \\\"{x:1405,y:441,t:1527272532020};\\\", \\\"{x:1412,y:436,t:1527272532037};\\\", \\\"{x:1418,y:434,t:1527272532054};\\\", \\\"{x:1433,y:431,t:1527272532071};\\\", \\\"{x:1447,y:428,t:1527272532087};\\\", \\\"{x:1461,y:427,t:1527272532104};\\\", \\\"{x:1478,y:422,t:1527272532120};\\\", \\\"{x:1497,y:420,t:1527272532137};\\\", \\\"{x:1518,y:418,t:1527272532155};\\\", \\\"{x:1537,y:417,t:1527272532170};\\\", \\\"{x:1554,y:416,t:1527272532188};\\\", \\\"{x:1574,y:416,t:1527272532205};\\\", \\\"{x:1584,y:416,t:1527272532220};\\\", \\\"{x:1593,y:416,t:1527272532236};\\\", \\\"{x:1605,y:419,t:1527272532253};\\\", \\\"{x:1626,y:425,t:1527272532269};\\\", \\\"{x:1654,y:433,t:1527272532287};\\\", \\\"{x:1679,y:440,t:1527272532304};\\\", \\\"{x:1694,y:447,t:1527272532320};\\\", \\\"{x:1699,y:451,t:1527272532337};\\\", \\\"{x:1701,y:460,t:1527272532354};\\\", \\\"{x:1701,y:476,t:1527272532370};\\\", \\\"{x:1699,y:501,t:1527272532387};\\\", \\\"{x:1683,y:530,t:1527272532404};\\\", \\\"{x:1656,y:547,t:1527272532420};\\\", \\\"{x:1606,y:561,t:1527272532437};\\\", \\\"{x:1546,y:573,t:1527272532454};\\\", \\\"{x:1482,y:592,t:1527272532470};\\\", \\\"{x:1433,y:609,t:1527272532487};\\\", \\\"{x:1398,y:627,t:1527272532504};\\\", \\\"{x:1374,y:641,t:1527272532520};\\\", \\\"{x:1356,y:652,t:1527272532537};\\\", \\\"{x:1345,y:660,t:1527272532555};\\\", \\\"{x:1334,y:669,t:1527272532572};\\\", \\\"{x:1329,y:681,t:1527272532588};\\\", \\\"{x:1327,y:710,t:1527272532605};\\\", \\\"{x:1327,y:729,t:1527272532621};\\\", \\\"{x:1327,y:747,t:1527272532639};\\\", \\\"{x:1328,y:758,t:1527272532655};\\\", \\\"{x:1331,y:766,t:1527272532671};\\\", \\\"{x:1333,y:774,t:1527272532687};\\\", \\\"{x:1333,y:789,t:1527272532705};\\\", \\\"{x:1333,y:808,t:1527272532721};\\\", \\\"{x:1333,y:831,t:1527272532738};\\\", \\\"{x:1333,y:847,t:1527272532754};\\\", \\\"{x:1331,y:860,t:1527272532771};\\\", \\\"{x:1329,y:874,t:1527272532787};\\\", \\\"{x:1329,y:898,t:1527272532804};\\\", \\\"{x:1330,y:914,t:1527272532820};\\\", \\\"{x:1331,y:926,t:1527272532837};\\\", \\\"{x:1335,y:939,t:1527272532854};\\\", \\\"{x:1341,y:953,t:1527272532871};\\\", \\\"{x:1343,y:961,t:1527272532887};\\\", \\\"{x:1345,y:963,t:1527272532904};\\\", \\\"{x:1346,y:967,t:1527272532921};\\\", \\\"{x:1347,y:967,t:1527272532937};\\\", \\\"{x:1348,y:969,t:1527272532954};\\\", \\\"{x:1348,y:972,t:1527272532971};\\\", \\\"{x:1348,y:973,t:1527272532987};\\\", \\\"{x:1350,y:977,t:1527272533004};\\\", \\\"{x:1349,y:980,t:1527272533021};\\\", \\\"{x:1345,y:984,t:1527272533038};\\\", \\\"{x:1340,y:986,t:1527272533055};\\\", \\\"{x:1335,y:990,t:1527272533072};\\\", \\\"{x:1331,y:993,t:1527272533089};\\\", \\\"{x:1326,y:996,t:1527272533104};\\\", \\\"{x:1326,y:997,t:1527272533122};\\\", \\\"{x:1325,y:997,t:1527272533138};\\\", \\\"{x:1319,y:997,t:1527272534118};\\\", \\\"{x:1302,y:997,t:1527272534125};\\\", \\\"{x:1280,y:997,t:1527272534139};\\\", \\\"{x:1218,y:997,t:1527272534155};\\\", \\\"{x:1091,y:997,t:1527272534173};\\\", \\\"{x:1010,y:997,t:1527272534189};\\\", \\\"{x:962,y:997,t:1527272534205};\\\", \\\"{x:920,y:997,t:1527272534222};\\\", \\\"{x:888,y:997,t:1527272534238};\\\", \\\"{x:857,y:995,t:1527272534255};\\\", \\\"{x:830,y:994,t:1527272534272};\\\", \\\"{x:808,y:994,t:1527272534288};\\\", \\\"{x:797,y:993,t:1527272534305};\\\", \\\"{x:789,y:993,t:1527272534322};\\\", \\\"{x:785,y:992,t:1527272534338};\\\", \\\"{x:781,y:991,t:1527272534355};\\\", \\\"{x:779,y:991,t:1527272534372};\\\", \\\"{x:779,y:990,t:1527272534413};\\\", \\\"{x:778,y:990,t:1527272535701};\\\", \\\"{x:764,y:990,t:1527272535709};\\\", \\\"{x:733,y:980,t:1527272535723};\\\", \\\"{x:644,y:938,t:1527272535739};\\\", \\\"{x:541,y:895,t:1527272535756};\\\", \\\"{x:513,y:881,t:1527272535773};\\\", \\\"{x:500,y:873,t:1527272535790};\\\", \\\"{x:496,y:870,t:1527272535807};\\\", \\\"{x:491,y:867,t:1527272535823};\\\", \\\"{x:485,y:863,t:1527272535840};\\\", \\\"{x:482,y:859,t:1527272535856};\\\", \\\"{x:481,y:856,t:1527272535873};\\\", \\\"{x:481,y:851,t:1527272535890};\\\", \\\"{x:481,y:845,t:1527272535906};\\\", \\\"{x:483,y:832,t:1527272535923};\\\", \\\"{x:490,y:818,t:1527272535940};\\\", \\\"{x:501,y:810,t:1527272535957};\\\", \\\"{x:520,y:799,t:1527272535973};\\\", \\\"{x:541,y:785,t:1527272535990};\\\", \\\"{x:556,y:773,t:1527272536006};\\\", \\\"{x:564,y:764,t:1527272536023};\\\", \\\"{x:567,y:756,t:1527272536041};\\\", \\\"{x:568,y:747,t:1527272536056};\\\", \\\"{x:570,y:742,t:1527272536073};\\\", \\\"{x:570,y:738,t:1527272536090};\\\", \\\"{x:570,y:735,t:1527272536106};\\\", \\\"{x:570,y:729,t:1527272536123};\\\", \\\"{x:562,y:717,t:1527272536140};\\\", \\\"{x:561,y:714,t:1527272536155};\\\", \\\"{x:558,y:714,t:1527272536421};\\\", \\\"{x:552,y:716,t:1527272536428};\\\", \\\"{x:546,y:718,t:1527272536442};\\\", \\\"{x:542,y:719,t:1527272536459};\\\", \\\"{x:542,y:720,t:1527272536478};\\\", \\\"{x:541,y:720,t:1527272536499};\\\", \\\"{x:540,y:720,t:1527272536524};\\\" ] }, { \\\"rt\\\": 14606, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 1143734, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -12 PM-2-J -01 PM-12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:720,t:1527272539109};\\\", \\\"{x:561,y:720,t:1527272539127};\\\", \\\"{x:584,y:720,t:1527272539143};\\\", \\\"{x:612,y:720,t:1527272539160};\\\", \\\"{x:655,y:720,t:1527272539177};\\\", \\\"{x:730,y:720,t:1527272539195};\\\", \\\"{x:805,y:718,t:1527272539211};\\\", \\\"{x:872,y:716,t:1527272539227};\\\", \\\"{x:978,y:716,t:1527272539245};\\\", \\\"{x:1039,y:716,t:1527272539261};\\\", \\\"{x:1098,y:716,t:1527272539277};\\\", \\\"{x:1151,y:716,t:1527272539294};\\\", \\\"{x:1201,y:716,t:1527272539312};\\\", \\\"{x:1224,y:716,t:1527272539328};\\\", \\\"{x:1236,y:716,t:1527272539345};\\\", \\\"{x:1237,y:716,t:1527272539361};\\\", \\\"{x:1242,y:714,t:1527272539605};\\\", \\\"{x:1248,y:712,t:1527272539612};\\\", \\\"{x:1261,y:709,t:1527272539629};\\\", \\\"{x:1280,y:709,t:1527272539644};\\\", \\\"{x:1300,y:713,t:1527272539662};\\\", \\\"{x:1324,y:716,t:1527272539678};\\\", \\\"{x:1344,y:719,t:1527272539695};\\\", \\\"{x:1359,y:719,t:1527272539712};\\\", \\\"{x:1361,y:719,t:1527272539729};\\\", \\\"{x:1358,y:721,t:1527272540060};\\\", \\\"{x:1356,y:721,t:1527272540067};\\\", \\\"{x:1354,y:722,t:1527272540078};\\\", \\\"{x:1350,y:722,t:1527272540095};\\\", \\\"{x:1349,y:722,t:1527272540342};\\\", \\\"{x:1348,y:723,t:1527272542741};\\\", \\\"{x:1348,y:730,t:1527272542773};\\\", \\\"{x:1348,y:741,t:1527272542780};\\\", \\\"{x:1348,y:762,t:1527272542801};\\\", \\\"{x:1349,y:784,t:1527272542814};\\\", \\\"{x:1354,y:806,t:1527272542831};\\\", \\\"{x:1356,y:824,t:1527272542847};\\\", \\\"{x:1358,y:836,t:1527272542864};\\\", \\\"{x:1358,y:852,t:1527272542881};\\\", \\\"{x:1358,y:864,t:1527272542897};\\\", \\\"{x:1358,y:875,t:1527272542914};\\\", \\\"{x:1360,y:884,t:1527272542931};\\\", \\\"{x:1363,y:890,t:1527272542947};\\\", \\\"{x:1363,y:898,t:1527272542963};\\\", \\\"{x:1365,y:909,t:1527272542981};\\\", \\\"{x:1367,y:918,t:1527272542997};\\\", \\\"{x:1368,y:924,t:1527272543014};\\\", \\\"{x:1368,y:926,t:1527272543125};\\\", \\\"{x:1368,y:929,t:1527272543140};\\\", \\\"{x:1368,y:930,t:1527272543149};\\\", \\\"{x:1368,y:935,t:1527272543165};\\\", \\\"{x:1368,y:941,t:1527272543182};\\\", \\\"{x:1367,y:945,t:1527272543198};\\\", \\\"{x:1366,y:948,t:1527272543214};\\\", \\\"{x:1364,y:949,t:1527272543231};\\\", \\\"{x:1364,y:950,t:1527272543248};\\\", \\\"{x:1364,y:951,t:1527272543267};\\\", \\\"{x:1363,y:952,t:1527272543283};\\\", \\\"{x:1359,y:955,t:1527272543297};\\\", \\\"{x:1347,y:961,t:1527272543314};\\\", \\\"{x:1337,y:966,t:1527272543331};\\\", \\\"{x:1330,y:970,t:1527272543348};\\\", \\\"{x:1328,y:970,t:1527272543468};\\\", \\\"{x:1328,y:966,t:1527272543482};\\\", \\\"{x:1326,y:957,t:1527272543498};\\\", \\\"{x:1325,y:943,t:1527272543515};\\\", \\\"{x:1323,y:929,t:1527272543532};\\\", \\\"{x:1323,y:903,t:1527272543548};\\\", \\\"{x:1323,y:892,t:1527272543565};\\\", \\\"{x:1321,y:877,t:1527272543581};\\\", \\\"{x:1320,y:862,t:1527272543598};\\\", \\\"{x:1318,y:846,t:1527272543615};\\\", \\\"{x:1318,y:828,t:1527272543631};\\\", \\\"{x:1318,y:815,t:1527272543648};\\\", \\\"{x:1320,y:804,t:1527272543665};\\\", \\\"{x:1322,y:798,t:1527272543681};\\\", \\\"{x:1322,y:791,t:1527272543698};\\\", \\\"{x:1323,y:786,t:1527272543716};\\\", \\\"{x:1323,y:780,t:1527272543731};\\\", \\\"{x:1327,y:771,t:1527272543748};\\\", \\\"{x:1327,y:767,t:1527272543766};\\\", \\\"{x:1328,y:763,t:1527272543781};\\\", \\\"{x:1328,y:761,t:1527272543799};\\\", \\\"{x:1328,y:756,t:1527272543816};\\\", \\\"{x:1326,y:753,t:1527272543831};\\\", \\\"{x:1325,y:750,t:1527272543849};\\\", \\\"{x:1318,y:746,t:1527272543866};\\\", \\\"{x:1296,y:743,t:1527272543882};\\\", \\\"{x:1248,y:730,t:1527272543898};\\\", \\\"{x:1181,y:724,t:1527272543916};\\\", \\\"{x:1108,y:720,t:1527272543931};\\\", \\\"{x:1019,y:720,t:1527272543948};\\\", \\\"{x:947,y:720,t:1527272543965};\\\", \\\"{x:858,y:720,t:1527272543982};\\\", \\\"{x:758,y:718,t:1527272543998};\\\", \\\"{x:691,y:718,t:1527272544015};\\\", \\\"{x:652,y:718,t:1527272544032};\\\", \\\"{x:633,y:720,t:1527272544049};\\\", \\\"{x:617,y:722,t:1527272544066};\\\", \\\"{x:605,y:723,t:1527272544083};\\\", \\\"{x:593,y:725,t:1527272544098};\\\", \\\"{x:586,y:727,t:1527272544115};\\\", \\\"{x:584,y:727,t:1527272544132};\\\", \\\"{x:582,y:727,t:1527272544164};\\\", \\\"{x:579,y:727,t:1527272544172};\\\", \\\"{x:575,y:727,t:1527272544183};\\\", \\\"{x:561,y:727,t:1527272544200};\\\", \\\"{x:552,y:724,t:1527272544215};\\\", \\\"{x:551,y:722,t:1527272544232};\\\", \\\"{x:550,y:721,t:1527272544248};\\\", \\\"{x:548,y:717,t:1527272544264};\\\", \\\"{x:545,y:709,t:1527272544281};\\\", \\\"{x:541,y:700,t:1527272544298};\\\", \\\"{x:541,y:691,t:1527272544314};\\\", \\\"{x:546,y:681,t:1527272544331};\\\", \\\"{x:554,y:655,t:1527272544348};\\\", \\\"{x:553,y:637,t:1527272544365};\\\", \\\"{x:542,y:624,t:1527272544382};\\\", \\\"{x:527,y:612,t:1527272544398};\\\", \\\"{x:510,y:605,t:1527272544415};\\\", \\\"{x:498,y:603,t:1527272544432};\\\", \\\"{x:482,y:603,t:1527272544448};\\\", \\\"{x:457,y:603,t:1527272544465};\\\", \\\"{x:412,y:599,t:1527272544482};\\\", \\\"{x:355,y:587,t:1527272544499};\\\", \\\"{x:323,y:584,t:1527272544515};\\\", \\\"{x:321,y:583,t:1527272544531};\\\", \\\"{x:321,y:580,t:1527272544548};\\\", \\\"{x:324,y:575,t:1527272544565};\\\", \\\"{x:328,y:570,t:1527272544581};\\\", \\\"{x:330,y:568,t:1527272544598};\\\", \\\"{x:336,y:563,t:1527272544615};\\\", \\\"{x:345,y:557,t:1527272544631};\\\", \\\"{x:355,y:551,t:1527272544649};\\\", \\\"{x:367,y:546,t:1527272544665};\\\", \\\"{x:373,y:543,t:1527272544683};\\\", \\\"{x:375,y:542,t:1527272544698};\\\", \\\"{x:366,y:542,t:1527272544741};\\\", \\\"{x:343,y:542,t:1527272544748};\\\", \\\"{x:276,y:542,t:1527272544765};\\\", \\\"{x:252,y:542,t:1527272544783};\\\", \\\"{x:237,y:542,t:1527272544798};\\\", \\\"{x:232,y:541,t:1527272544815};\\\", \\\"{x:231,y:541,t:1527272544832};\\\", \\\"{x:230,y:541,t:1527272544860};\\\", \\\"{x:227,y:540,t:1527272544868};\\\", \\\"{x:224,y:540,t:1527272544882};\\\", \\\"{x:219,y:540,t:1527272544898};\\\", \\\"{x:216,y:540,t:1527272544965};\\\", \\\"{x:211,y:539,t:1527272544972};\\\", \\\"{x:202,y:539,t:1527272544983};\\\", \\\"{x:184,y:535,t:1527272545000};\\\", \\\"{x:176,y:532,t:1527272545015};\\\", \\\"{x:175,y:532,t:1527272545032};\\\", \\\"{x:174,y:532,t:1527272545052};\\\", \\\"{x:173,y:531,t:1527272545065};\\\", \\\"{x:167,y:528,t:1527272545082};\\\", \\\"{x:160,y:524,t:1527272545099};\\\", \\\"{x:159,y:522,t:1527272545115};\\\", \\\"{x:158,y:522,t:1527272545341};\\\", \\\"{x:157,y:523,t:1527272545364};\\\", \\\"{x:157,y:526,t:1527272545373};\\\", \\\"{x:157,y:527,t:1527272545382};\\\", \\\"{x:158,y:530,t:1527272545399};\\\", \\\"{x:159,y:531,t:1527272545428};\\\", \\\"{x:162,y:531,t:1527272545620};\\\", \\\"{x:171,y:534,t:1527272545632};\\\", \\\"{x:192,y:536,t:1527272545650};\\\", \\\"{x:232,y:540,t:1527272545666};\\\", \\\"{x:298,y:549,t:1527272545683};\\\", \\\"{x:371,y:551,t:1527272545699};\\\", \\\"{x:513,y:551,t:1527272545717};\\\", \\\"{x:635,y:551,t:1527272545732};\\\", \\\"{x:767,y:551,t:1527272545750};\\\", \\\"{x:873,y:551,t:1527272545765};\\\", \\\"{x:967,y:551,t:1527272545783};\\\", \\\"{x:1015,y:551,t:1527272545799};\\\", \\\"{x:1033,y:548,t:1527272545817};\\\", \\\"{x:1040,y:543,t:1527272545832};\\\", \\\"{x:1041,y:541,t:1527272545850};\\\", \\\"{x:1041,y:540,t:1527272545866};\\\", \\\"{x:1033,y:538,t:1527272545882};\\\", \\\"{x:1022,y:538,t:1527272545899};\\\", \\\"{x:1002,y:538,t:1527272545916};\\\", \\\"{x:991,y:538,t:1527272545932};\\\", \\\"{x:983,y:538,t:1527272545950};\\\", \\\"{x:965,y:538,t:1527272545967};\\\", \\\"{x:932,y:538,t:1527272545983};\\\", \\\"{x:881,y:538,t:1527272545999};\\\", \\\"{x:844,y:538,t:1527272546017};\\\", \\\"{x:831,y:538,t:1527272546032};\\\", \\\"{x:820,y:540,t:1527272546050};\\\", \\\"{x:816,y:540,t:1527272546066};\\\", \\\"{x:815,y:540,t:1527272546084};\\\", \\\"{x:815,y:539,t:1527272546099};\\\", \\\"{x:815,y:536,t:1527272546115};\\\", \\\"{x:814,y:534,t:1527272546134};\\\", \\\"{x:814,y:532,t:1527272546150};\\\", \\\"{x:815,y:526,t:1527272546166};\\\", \\\"{x:817,y:520,t:1527272546184};\\\", \\\"{x:822,y:515,t:1527272546200};\\\", \\\"{x:823,y:512,t:1527272546216};\\\", \\\"{x:824,y:511,t:1527272546233};\\\", \\\"{x:824,y:510,t:1527272546308};\\\", \\\"{x:825,y:509,t:1527272546324};\\\", \\\"{x:826,y:508,t:1527272546333};\\\", \\\"{x:826,y:508,t:1527272546389};\\\", \\\"{x:827,y:510,t:1527272546556};\\\", \\\"{x:827,y:520,t:1527272546568};\\\", \\\"{x:827,y:559,t:1527272546584};\\\", \\\"{x:827,y:592,t:1527272546601};\\\", \\\"{x:828,y:616,t:1527272546618};\\\", \\\"{x:832,y:630,t:1527272546634};\\\", \\\"{x:842,y:642,t:1527272546651};\\\", \\\"{x:862,y:655,t:1527272546666};\\\", \\\"{x:903,y:676,t:1527272546684};\\\", \\\"{x:966,y:705,t:1527272546701};\\\", \\\"{x:1024,y:732,t:1527272546717};\\\", \\\"{x:1107,y:755,t:1527272546734};\\\", \\\"{x:1179,y:775,t:1527272546751};\\\", \\\"{x:1235,y:781,t:1527272546767};\\\", \\\"{x:1270,y:783,t:1527272546783};\\\", \\\"{x:1285,y:783,t:1527272546801};\\\", \\\"{x:1287,y:779,t:1527272546817};\\\", \\\"{x:1263,y:747,t:1527272546834};\\\", \\\"{x:1158,y:680,t:1527272546851};\\\", \\\"{x:1034,y:606,t:1527272546867};\\\", \\\"{x:976,y:568,t:1527272546884};\\\", \\\"{x:953,y:551,t:1527272546900};\\\", \\\"{x:938,y:540,t:1527272546917};\\\", \\\"{x:927,y:532,t:1527272546933};\\\", \\\"{x:926,y:531,t:1527272546950};\\\", \\\"{x:925,y:530,t:1527272546967};\\\", \\\"{x:924,y:528,t:1527272547124};\\\", \\\"{x:924,y:525,t:1527272547244};\\\", \\\"{x:919,y:520,t:1527272547254};\\\", \\\"{x:904,y:514,t:1527272547268};\\\", \\\"{x:879,y:507,t:1527272547284};\\\", \\\"{x:873,y:504,t:1527272547300};\\\", \\\"{x:872,y:503,t:1527272547348};\\\", \\\"{x:870,y:502,t:1527272547364};\\\", \\\"{x:867,y:502,t:1527272547374};\\\", \\\"{x:862,y:500,t:1527272547384};\\\", \\\"{x:861,y:500,t:1527272547412};\\\", \\\"{x:859,y:500,t:1527272547421};\\\", \\\"{x:858,y:500,t:1527272547435};\\\", \\\"{x:852,y:500,t:1527272547451};\\\", \\\"{x:847,y:499,t:1527272547468};\\\", \\\"{x:844,y:499,t:1527272547485};\\\", \\\"{x:842,y:499,t:1527272547524};\\\", \\\"{x:840,y:499,t:1527272547541};\\\", \\\"{x:837,y:499,t:1527272547551};\\\", \\\"{x:836,y:499,t:1527272547584};\\\", \\\"{x:836,y:499,t:1527272547648};\\\", \\\"{x:835,y:508,t:1527272547812};\\\", \\\"{x:835,y:520,t:1527272547820};\\\", \\\"{x:837,y:536,t:1527272547835};\\\", \\\"{x:844,y:573,t:1527272547851};\\\", \\\"{x:851,y:615,t:1527272547868};\\\", \\\"{x:854,y:634,t:1527272547885};\\\", \\\"{x:865,y:651,t:1527272547900};\\\", \\\"{x:878,y:673,t:1527272547917};\\\", \\\"{x:894,y:696,t:1527272547934};\\\", \\\"{x:907,y:719,t:1527272547950};\\\", \\\"{x:922,y:742,t:1527272547967};\\\", \\\"{x:935,y:760,t:1527272547984};\\\", \\\"{x:946,y:777,t:1527272548000};\\\", \\\"{x:955,y:785,t:1527272548017};\\\", \\\"{x:960,y:791,t:1527272548033};\\\", \\\"{x:965,y:800,t:1527272548050};\\\", \\\"{x:970,y:806,t:1527272548068};\\\", \\\"{x:973,y:810,t:1527272548083};\\\", \\\"{x:981,y:815,t:1527272548100};\\\", \\\"{x:984,y:817,t:1527272548117};\\\", \\\"{x:988,y:818,t:1527272548134};\\\", \\\"{x:995,y:820,t:1527272548150};\\\", \\\"{x:1005,y:822,t:1527272548166};\\\", \\\"{x:1013,y:824,t:1527272548184};\\\", \\\"{x:1021,y:825,t:1527272548201};\\\", \\\"{x:1037,y:828,t:1527272548216};\\\", \\\"{x:1057,y:829,t:1527272548234};\\\", \\\"{x:1088,y:829,t:1527272548249};\\\", \\\"{x:1132,y:829,t:1527272548267};\\\", \\\"{x:1195,y:832,t:1527272548283};\\\", \\\"{x:1210,y:832,t:1527272548300};\\\", \\\"{x:1265,y:832,t:1527272548317};\\\", \\\"{x:1306,y:835,t:1527272548334};\\\", \\\"{x:1337,y:836,t:1527272548350};\\\", \\\"{x:1358,y:837,t:1527272548367};\\\", \\\"{x:1372,y:837,t:1527272548383};\\\", \\\"{x:1379,y:837,t:1527272548400};\\\", \\\"{x:1382,y:837,t:1527272548416};\\\", \\\"{x:1384,y:837,t:1527272548433};\\\", \\\"{x:1384,y:840,t:1527272549333};\\\", \\\"{x:1385,y:849,t:1527272549347};\\\", \\\"{x:1388,y:880,t:1527272549364};\\\", \\\"{x:1388,y:908,t:1527272549380};\\\", \\\"{x:1394,y:933,t:1527272549397};\\\", \\\"{x:1399,y:947,t:1527272549414};\\\", \\\"{x:1401,y:953,t:1527272549431};\\\", \\\"{x:1401,y:957,t:1527272549447};\\\", \\\"{x:1403,y:963,t:1527272549465};\\\", \\\"{x:1404,y:967,t:1527272549480};\\\", \\\"{x:1404,y:970,t:1527272549498};\\\", \\\"{x:1404,y:971,t:1527272549514};\\\", \\\"{x:1404,y:972,t:1527272549533};\\\", \\\"{x:1404,y:973,t:1527272549557};\\\", \\\"{x:1403,y:974,t:1527272549564};\\\", \\\"{x:1403,y:975,t:1527272549580};\\\", \\\"{x:1395,y:978,t:1527272549596};\\\", \\\"{x:1388,y:981,t:1527272549613};\\\", \\\"{x:1387,y:982,t:1527272549630};\\\", \\\"{x:1385,y:982,t:1527272549889};\\\", \\\"{x:1384,y:982,t:1527272549905};\\\", \\\"{x:1382,y:982,t:1527272549918};\\\", \\\"{x:1377,y:982,t:1527272549934};\\\", \\\"{x:1367,y:981,t:1527272549951};\\\", \\\"{x:1346,y:976,t:1527272549967};\\\", \\\"{x:1332,y:976,t:1527272549983};\\\", \\\"{x:1329,y:976,t:1527272550001};\\\", \\\"{x:1328,y:974,t:1527272550122};\\\", \\\"{x:1328,y:971,t:1527272550134};\\\", \\\"{x:1325,y:969,t:1527272550150};\\\", \\\"{x:1325,y:968,t:1527272550170};\\\", \\\"{x:1324,y:967,t:1527272550193};\\\", \\\"{x:1324,y:966,t:1527272550209};\\\", \\\"{x:1323,y:965,t:1527272550217};\\\", \\\"{x:1323,y:963,t:1527272550233};\\\", \\\"{x:1323,y:962,t:1527272550250};\\\", \\\"{x:1324,y:961,t:1527272550330};\\\", \\\"{x:1327,y:961,t:1527272550337};\\\", \\\"{x:1329,y:961,t:1527272550350};\\\", \\\"{x:1332,y:962,t:1527272550366};\\\", \\\"{x:1333,y:962,t:1527272550383};\\\", \\\"{x:1334,y:962,t:1527272550400};\\\", \\\"{x:1335,y:962,t:1527272550416};\\\", \\\"{x:1338,y:962,t:1527272550433};\\\", \\\"{x:1341,y:962,t:1527272550448};\\\", \\\"{x:1342,y:961,t:1527272550465};\\\", \\\"{x:1342,y:960,t:1527272550483};\\\", \\\"{x:1342,y:959,t:1527272550618};\\\", \\\"{x:1342,y:957,t:1527272550632};\\\", \\\"{x:1343,y:951,t:1527272550650};\\\", \\\"{x:1344,y:944,t:1527272550665};\\\", \\\"{x:1344,y:937,t:1527272550682};\\\", \\\"{x:1344,y:924,t:1527272550699};\\\", \\\"{x:1344,y:900,t:1527272550715};\\\", \\\"{x:1344,y:873,t:1527272550732};\\\", \\\"{x:1344,y:842,t:1527272550749};\\\", \\\"{x:1344,y:818,t:1527272550764};\\\", \\\"{x:1344,y:801,t:1527272550782};\\\", \\\"{x:1344,y:792,t:1527272550799};\\\", \\\"{x:1344,y:788,t:1527272550815};\\\", \\\"{x:1344,y:787,t:1527272550831};\\\", \\\"{x:1344,y:786,t:1527272550906};\\\", \\\"{x:1344,y:785,t:1527272550915};\\\", \\\"{x:1344,y:783,t:1527272550936};\\\", \\\"{x:1344,y:782,t:1527272550993};\\\", \\\"{x:1344,y:780,t:1527272551000};\\\", \\\"{x:1344,y:776,t:1527272551015};\\\", \\\"{x:1344,y:766,t:1527272551030};\\\", \\\"{x:1344,y:760,t:1527272551047};\\\", \\\"{x:1344,y:756,t:1527272551065};\\\", \\\"{x:1344,y:752,t:1527272551426};\\\", \\\"{x:1344,y:741,t:1527272551434};\\\", \\\"{x:1344,y:733,t:1527272551447};\\\", \\\"{x:1344,y:719,t:1527272551463};\\\", \\\"{x:1344,y:712,t:1527272551480};\\\", \\\"{x:1343,y:708,t:1527272551497};\\\", \\\"{x:1343,y:707,t:1527272551570};\\\", \\\"{x:1341,y:707,t:1527272551738};\\\", \\\"{x:1336,y:707,t:1527272551745};\\\", \\\"{x:1328,y:707,t:1527272551763};\\\", \\\"{x:1316,y:708,t:1527272551779};\\\", \\\"{x:1298,y:713,t:1527272551796};\\\", \\\"{x:1277,y:719,t:1527272551812};\\\", \\\"{x:1241,y:729,t:1527272551829};\\\", \\\"{x:1188,y:737,t:1527272551846};\\\", \\\"{x:1138,y:744,t:1527272551862};\\\", \\\"{x:1108,y:749,t:1527272551879};\\\", \\\"{x:1085,y:751,t:1527272551896};\\\", \\\"{x:1067,y:754,t:1527272551913};\\\", \\\"{x:1048,y:756,t:1527272551930};\\\", \\\"{x:1033,y:760,t:1527272551945};\\\", \\\"{x:1018,y:764,t:1527272551962};\\\", \\\"{x:1008,y:768,t:1527272551979};\\\", \\\"{x:1001,y:773,t:1527272551994};\\\", \\\"{x:982,y:782,t:1527272552012};\\\", \\\"{x:928,y:802,t:1527272552029};\\\", \\\"{x:842,y:814,t:1527272552045};\\\", \\\"{x:829,y:814,t:1527272552062};\\\", \\\"{x:826,y:813,t:1527272552321};\\\", \\\"{x:780,y:810,t:1527272552329};\\\", \\\"{x:733,y:810,t:1527272552344};\\\", \\\"{x:653,y:806,t:1527272552361};\\\", \\\"{x:623,y:806,t:1527272552377};\\\", \\\"{x:619,y:805,t:1527272552394};\\\", \\\"{x:618,y:805,t:1527272552425};\\\", \\\"{x:618,y:803,t:1527272552441};\\\", \\\"{x:618,y:802,t:1527272552449};\\\", \\\"{x:617,y:801,t:1527272552461};\\\", \\\"{x:614,y:799,t:1527272552476};\\\", \\\"{x:610,y:795,t:1527272552494};\\\", \\\"{x:595,y:785,t:1527272552517};\\\", \\\"{x:581,y:779,t:1527272552526};\\\", \\\"{x:525,y:765,t:1527272552543};\\\", \\\"{x:479,y:756,t:1527272552559};\\\", \\\"{x:461,y:756,t:1527272552576};\\\", \\\"{x:458,y:756,t:1527272552593};\\\", \\\"{x:457,y:755,t:1527272552609};\\\", \\\"{x:455,y:753,t:1527272552627};\\\", \\\"{x:451,y:749,t:1527272552643};\\\", \\\"{x:445,y:743,t:1527272552659};\\\", \\\"{x:445,y:741,t:1527272552676};\\\", \\\"{x:444,y:740,t:1527272552696};\\\" ] }, { \\\"rt\\\": 16058, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 1161083, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-B -F -B -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:444,y:742,t:1527272555377};\\\", \\\"{x:453,y:750,t:1527272555385};\\\", \\\"{x:477,y:759,t:1527272555400};\\\", \\\"{x:529,y:782,t:1527272555413};\\\", \\\"{x:607,y:806,t:1527272555428};\\\", \\\"{x:707,y:834,t:1527272555444};\\\", \\\"{x:814,y:856,t:1527272555460};\\\", \\\"{x:936,y:872,t:1527272555478};\\\", \\\"{x:1061,y:891,t:1527272555495};\\\", \\\"{x:1178,y:895,t:1527272555511};\\\", \\\"{x:1264,y:897,t:1527272555528};\\\", \\\"{x:1312,y:897,t:1527272555544};\\\", \\\"{x:1315,y:897,t:1527272555560};\\\", \\\"{x:1316,y:897,t:1527272555666};\\\", \\\"{x:1317,y:897,t:1527272555678};\\\", \\\"{x:1321,y:896,t:1527272555695};\\\", \\\"{x:1325,y:895,t:1527272555711};\\\", \\\"{x:1327,y:894,t:1527272555728};\\\", \\\"{x:1328,y:893,t:1527272555744};\\\", \\\"{x:1331,y:890,t:1527272555760};\\\", \\\"{x:1336,y:884,t:1527272555778};\\\", \\\"{x:1346,y:875,t:1527272555795};\\\", \\\"{x:1357,y:863,t:1527272555811};\\\", \\\"{x:1369,y:848,t:1527272555828};\\\", \\\"{x:1376,y:837,t:1527272555845};\\\", \\\"{x:1381,y:829,t:1527272555860};\\\", \\\"{x:1392,y:816,t:1527272555877};\\\", \\\"{x:1406,y:807,t:1527272555895};\\\", \\\"{x:1414,y:801,t:1527272555910};\\\", \\\"{x:1415,y:798,t:1527272555927};\\\", \\\"{x:1416,y:798,t:1527272556321};\\\", \\\"{x:1418,y:798,t:1527272556337};\\\", \\\"{x:1421,y:797,t:1527272556352};\\\", \\\"{x:1423,y:796,t:1527272556392};\\\", \\\"{x:1424,y:795,t:1527272556409};\\\", \\\"{x:1426,y:794,t:1527272556424};\\\", \\\"{x:1427,y:794,t:1527272556497};\\\", \\\"{x:1429,y:794,t:1527272556513};\\\", \\\"{x:1430,y:794,t:1527272556537};\\\", \\\"{x:1434,y:794,t:1527272556585};\\\", \\\"{x:1441,y:797,t:1527272556594};\\\", \\\"{x:1463,y:810,t:1527272556611};\\\", \\\"{x:1485,y:823,t:1527272556627};\\\", \\\"{x:1506,y:832,t:1527272556645};\\\", \\\"{x:1523,y:841,t:1527272556661};\\\", \\\"{x:1543,y:850,t:1527272556678};\\\", \\\"{x:1562,y:861,t:1527272556695};\\\", \\\"{x:1590,y:876,t:1527272556711};\\\", \\\"{x:1610,y:885,t:1527272556727};\\\", \\\"{x:1618,y:886,t:1527272556745};\\\", \\\"{x:1616,y:887,t:1527272556873};\\\", \\\"{x:1613,y:890,t:1527272556881};\\\", \\\"{x:1610,y:891,t:1527272556895};\\\", \\\"{x:1602,y:895,t:1527272556911};\\\", \\\"{x:1594,y:898,t:1527272556927};\\\", \\\"{x:1584,y:899,t:1527272556944};\\\", \\\"{x:1579,y:899,t:1527272556961};\\\", \\\"{x:1575,y:899,t:1527272556977};\\\", \\\"{x:1573,y:899,t:1527272557000};\\\", \\\"{x:1571,y:899,t:1527272557032};\\\", \\\"{x:1569,y:900,t:1527272557045};\\\", \\\"{x:1568,y:900,t:1527272557061};\\\", \\\"{x:1566,y:900,t:1527272558001};\\\", \\\"{x:1563,y:900,t:1527272558011};\\\", \\\"{x:1550,y:898,t:1527272558028};\\\", \\\"{x:1535,y:897,t:1527272558045};\\\", \\\"{x:1511,y:892,t:1527272558062};\\\", \\\"{x:1495,y:891,t:1527272558079};\\\", \\\"{x:1484,y:890,t:1527272558095};\\\", \\\"{x:1483,y:890,t:1527272558112};\\\", \\\"{x:1482,y:890,t:1527272558128};\\\", \\\"{x:1481,y:889,t:1527272558145};\\\", \\\"{x:1481,y:888,t:1527272558169};\\\", \\\"{x:1480,y:887,t:1527272558178};\\\", \\\"{x:1475,y:884,t:1527272558195};\\\", \\\"{x:1473,y:883,t:1527272558211};\\\", \\\"{x:1467,y:880,t:1527272558228};\\\", \\\"{x:1463,y:877,t:1527272558245};\\\", \\\"{x:1460,y:876,t:1527272558261};\\\", \\\"{x:1456,y:874,t:1527272558278};\\\", \\\"{x:1453,y:873,t:1527272558295};\\\", \\\"{x:1451,y:872,t:1527272558312};\\\", \\\"{x:1450,y:872,t:1527272558329};\\\", \\\"{x:1449,y:872,t:1527272558345};\\\", \\\"{x:1447,y:870,t:1527272558441};\\\", \\\"{x:1445,y:868,t:1527272558448};\\\", \\\"{x:1443,y:866,t:1527272558461};\\\", \\\"{x:1436,y:859,t:1527272558478};\\\", \\\"{x:1426,y:850,t:1527272558495};\\\", \\\"{x:1411,y:830,t:1527272558513};\\\", \\\"{x:1388,y:799,t:1527272558528};\\\", \\\"{x:1335,y:728,t:1527272558545};\\\", \\\"{x:1292,y:678,t:1527272558562};\\\", \\\"{x:1282,y:666,t:1527272558578};\\\", \\\"{x:1279,y:664,t:1527272558595};\\\", \\\"{x:1279,y:663,t:1527272558714};\\\", \\\"{x:1282,y:662,t:1527272558728};\\\", \\\"{x:1293,y:659,t:1527272558744};\\\", \\\"{x:1296,y:659,t:1527272558762};\\\", \\\"{x:1304,y:661,t:1527272558778};\\\", \\\"{x:1311,y:670,t:1527272558795};\\\", \\\"{x:1322,y:689,t:1527272558812};\\\", \\\"{x:1331,y:707,t:1527272558828};\\\", \\\"{x:1336,y:723,t:1527272558845};\\\", \\\"{x:1341,y:734,t:1527272558862};\\\", \\\"{x:1342,y:740,t:1527272558879};\\\", \\\"{x:1342,y:743,t:1527272558896};\\\", \\\"{x:1342,y:744,t:1527272558912};\\\", \\\"{x:1342,y:745,t:1527272558928};\\\", \\\"{x:1342,y:746,t:1527272558945};\\\", \\\"{x:1342,y:747,t:1527272558962};\\\", \\\"{x:1342,y:748,t:1527272559026};\\\", \\\"{x:1341,y:750,t:1527272559041};\\\", \\\"{x:1340,y:750,t:1527272559049};\\\", \\\"{x:1338,y:751,t:1527272559062};\\\", \\\"{x:1334,y:753,t:1527272559078};\\\", \\\"{x:1331,y:754,t:1527272559095};\\\", \\\"{x:1329,y:756,t:1527272559112};\\\", \\\"{x:1327,y:758,t:1527272559128};\\\", \\\"{x:1321,y:761,t:1527272559145};\\\", \\\"{x:1312,y:763,t:1527272559162};\\\", \\\"{x:1306,y:765,t:1527272559178};\\\", \\\"{x:1301,y:766,t:1527272559195};\\\", \\\"{x:1296,y:768,t:1527272559212};\\\", \\\"{x:1289,y:768,t:1527272559228};\\\", \\\"{x:1280,y:768,t:1527272559245};\\\", \\\"{x:1250,y:767,t:1527272559262};\\\", \\\"{x:1163,y:747,t:1527272559278};\\\", \\\"{x:1059,y:727,t:1527272559295};\\\", \\\"{x:996,y:722,t:1527272559312};\\\", \\\"{x:970,y:722,t:1527272559328};\\\", \\\"{x:949,y:722,t:1527272559345};\\\", \\\"{x:941,y:722,t:1527272559362};\\\", \\\"{x:938,y:722,t:1527272559378};\\\", \\\"{x:937,y:722,t:1527272559395};\\\", \\\"{x:934,y:721,t:1527272559489};\\\", \\\"{x:933,y:720,t:1527272559497};\\\", \\\"{x:930,y:716,t:1527272559512};\\\", \\\"{x:928,y:707,t:1527272559528};\\\", \\\"{x:927,y:707,t:1527272559905};\\\", \\\"{x:926,y:707,t:1527272559952};\\\", \\\"{x:893,y:703,t:1527272559961};\\\", \\\"{x:810,y:692,t:1527272559977};\\\", \\\"{x:772,y:685,t:1527272559995};\\\", \\\"{x:756,y:683,t:1527272560011};\\\", \\\"{x:752,y:681,t:1527272560028};\\\", \\\"{x:747,y:678,t:1527272560045};\\\", \\\"{x:740,y:672,t:1527272560062};\\\", \\\"{x:727,y:664,t:1527272560077};\\\", \\\"{x:713,y:658,t:1527272560095};\\\", \\\"{x:704,y:654,t:1527272560112};\\\", \\\"{x:694,y:653,t:1527272560128};\\\", \\\"{x:685,y:653,t:1527272560145};\\\", \\\"{x:684,y:652,t:1527272560162};\\\", \\\"{x:682,y:649,t:1527272560178};\\\", \\\"{x:675,y:636,t:1527272560195};\\\", \\\"{x:668,y:624,t:1527272560213};\\\", \\\"{x:660,y:611,t:1527272560228};\\\", \\\"{x:655,y:603,t:1527272560244};\\\", \\\"{x:635,y:591,t:1527272560267};\\\", \\\"{x:616,y:583,t:1527272560281};\\\", \\\"{x:605,y:576,t:1527272560299};\\\", \\\"{x:602,y:573,t:1527272560315};\\\", \\\"{x:600,y:569,t:1527272560332};\\\", \\\"{x:595,y:562,t:1527272560349};\\\", \\\"{x:588,y:557,t:1527272560365};\\\", \\\"{x:585,y:555,t:1527272560383};\\\", \\\"{x:586,y:552,t:1527272560400};\\\", \\\"{x:592,y:550,t:1527272560415};\\\", \\\"{x:602,y:544,t:1527272560432};\\\", \\\"{x:602,y:543,t:1527272560464};\\\", \\\"{x:602,y:542,t:1527272560480};\\\", \\\"{x:600,y:542,t:1527272560488};\\\", \\\"{x:594,y:542,t:1527272560499};\\\", \\\"{x:581,y:539,t:1527272560516};\\\", \\\"{x:560,y:537,t:1527272560532};\\\", \\\"{x:517,y:525,t:1527272560549};\\\", \\\"{x:443,y:505,t:1527272560567};\\\", \\\"{x:346,y:494,t:1527272560583};\\\", \\\"{x:300,y:489,t:1527272560599};\\\", \\\"{x:292,y:489,t:1527272560616};\\\", \\\"{x:291,y:490,t:1527272560632};\\\", \\\"{x:292,y:490,t:1527272560650};\\\", \\\"{x:293,y:490,t:1527272560666};\\\", \\\"{x:295,y:490,t:1527272560705};\\\", \\\"{x:299,y:490,t:1527272560716};\\\", \\\"{x:312,y:500,t:1527272560733};\\\", \\\"{x:332,y:509,t:1527272560750};\\\", \\\"{x:350,y:516,t:1527272560766};\\\", \\\"{x:372,y:521,t:1527272560784};\\\", \\\"{x:422,y:530,t:1527272560800};\\\", \\\"{x:525,y:546,t:1527272560816};\\\", \\\"{x:703,y:548,t:1527272560832};\\\", \\\"{x:800,y:548,t:1527272560850};\\\", \\\"{x:880,y:548,t:1527272560865};\\\", \\\"{x:928,y:541,t:1527272560882};\\\", \\\"{x:945,y:535,t:1527272560900};\\\", \\\"{x:951,y:533,t:1527272560917};\\\", \\\"{x:950,y:533,t:1527272560953};\\\", \\\"{x:947,y:533,t:1527272560967};\\\", \\\"{x:940,y:533,t:1527272560982};\\\", \\\"{x:926,y:533,t:1527272560999};\\\", \\\"{x:911,y:532,t:1527272561016};\\\", \\\"{x:890,y:530,t:1527272561032};\\\", \\\"{x:871,y:530,t:1527272561050};\\\", \\\"{x:841,y:530,t:1527272561067};\\\", \\\"{x:802,y:530,t:1527272561082};\\\", \\\"{x:780,y:530,t:1527272561100};\\\", \\\"{x:763,y:530,t:1527272561116};\\\", \\\"{x:743,y:530,t:1527272561132};\\\", \\\"{x:713,y:530,t:1527272561151};\\\", \\\"{x:624,y:530,t:1527272561167};\\\", \\\"{x:469,y:530,t:1527272561183};\\\", \\\"{x:286,y:526,t:1527272561200};\\\", \\\"{x:109,y:527,t:1527272561218};\\\", \\\"{x:79,y:528,t:1527272561233};\\\", \\\"{x:82,y:528,t:1527272561272};\\\", \\\"{x:87,y:527,t:1527272561282};\\\", \\\"{x:111,y:520,t:1527272561300};\\\", \\\"{x:128,y:511,t:1527272561316};\\\", \\\"{x:132,y:505,t:1527272561333};\\\", \\\"{x:131,y:503,t:1527272561350};\\\", \\\"{x:125,y:501,t:1527272561367};\\\", \\\"{x:119,y:501,t:1527272561383};\\\", \\\"{x:114,y:501,t:1527272561400};\\\", \\\"{x:107,y:501,t:1527272561416};\\\", \\\"{x:106,y:503,t:1527272561434};\\\", \\\"{x:105,y:511,t:1527272561450};\\\", \\\"{x:115,y:517,t:1527272561467};\\\", \\\"{x:126,y:520,t:1527272561484};\\\", \\\"{x:131,y:520,t:1527272561499};\\\", \\\"{x:132,y:521,t:1527272561553};\\\", \\\"{x:136,y:524,t:1527272561567};\\\", \\\"{x:142,y:529,t:1527272561586};\\\", \\\"{x:143,y:530,t:1527272561599};\\\", \\\"{x:144,y:530,t:1527272561672};\\\", \\\"{x:147,y:533,t:1527272561696};\\\", \\\"{x:151,y:535,t:1527272561707};\\\", \\\"{x:154,y:538,t:1527272561716};\\\", \\\"{x:156,y:540,t:1527272561733};\\\", \\\"{x:156,y:541,t:1527272562458};\\\", \\\"{x:157,y:541,t:1527272562468};\\\", \\\"{x:181,y:564,t:1527272562484};\\\", \\\"{x:223,y:594,t:1527272562501};\\\", \\\"{x:275,y:624,t:1527272562518};\\\", \\\"{x:361,y:663,t:1527272562535};\\\", \\\"{x:459,y:699,t:1527272562551};\\\", \\\"{x:564,y:729,t:1527272562569};\\\", \\\"{x:672,y:757,t:1527272562584};\\\", \\\"{x:799,y:778,t:1527272562600};\\\", \\\"{x:849,y:786,t:1527272562617};\\\", \\\"{x:877,y:788,t:1527272562635};\\\", \\\"{x:900,y:792,t:1527272562650};\\\", \\\"{x:920,y:796,t:1527272562668};\\\", \\\"{x:927,y:797,t:1527272562684};\\\", \\\"{x:928,y:797,t:1527272562701};\\\", \\\"{x:929,y:797,t:1527272563537};\\\", \\\"{x:932,y:797,t:1527272563552};\\\", \\\"{x:955,y:802,t:1527272563568};\\\", \\\"{x:984,y:806,t:1527272563586};\\\", \\\"{x:1025,y:810,t:1527272563602};\\\", \\\"{x:1089,y:817,t:1527272563618};\\\", \\\"{x:1150,y:817,t:1527272563636};\\\", \\\"{x:1198,y:817,t:1527272563652};\\\", \\\"{x:1232,y:817,t:1527272563669};\\\", \\\"{x:1255,y:817,t:1527272563686};\\\", \\\"{x:1261,y:817,t:1527272563702};\\\", \\\"{x:1264,y:816,t:1527272563719};\\\", \\\"{x:1264,y:815,t:1527272563825};\\\", \\\"{x:1264,y:814,t:1527272563837};\\\", \\\"{x:1264,y:813,t:1527272563852};\\\", \\\"{x:1265,y:813,t:1527272563869};\\\", \\\"{x:1265,y:812,t:1527272563886};\\\", \\\"{x:1266,y:810,t:1527272563902};\\\", \\\"{x:1268,y:808,t:1527272563919};\\\", \\\"{x:1272,y:805,t:1527272563936};\\\", \\\"{x:1282,y:802,t:1527272563951};\\\", \\\"{x:1288,y:800,t:1527272563968};\\\", \\\"{x:1293,y:799,t:1527272563986};\\\", \\\"{x:1298,y:797,t:1527272564002};\\\", \\\"{x:1305,y:796,t:1527272564018};\\\", \\\"{x:1314,y:793,t:1527272564035};\\\", \\\"{x:1318,y:792,t:1527272564053};\\\", \\\"{x:1321,y:790,t:1527272564068};\\\", \\\"{x:1325,y:787,t:1527272564086};\\\", \\\"{x:1330,y:784,t:1527272564103};\\\", \\\"{x:1337,y:776,t:1527272564118};\\\", \\\"{x:1347,y:766,t:1527272564137};\\\", \\\"{x:1359,y:747,t:1527272564152};\\\", \\\"{x:1363,y:740,t:1527272564169};\\\", \\\"{x:1364,y:734,t:1527272564186};\\\", \\\"{x:1366,y:730,t:1527272564203};\\\", \\\"{x:1366,y:727,t:1527272564219};\\\", \\\"{x:1366,y:724,t:1527272564236};\\\", \\\"{x:1366,y:721,t:1527272564253};\\\", \\\"{x:1366,y:720,t:1527272564269};\\\", \\\"{x:1366,y:718,t:1527272564286};\\\", \\\"{x:1366,y:715,t:1527272564302};\\\", \\\"{x:1366,y:712,t:1527272564320};\\\", \\\"{x:1366,y:708,t:1527272564336};\\\", \\\"{x:1366,y:704,t:1527272564353};\\\", \\\"{x:1365,y:703,t:1527272564378};\\\", \\\"{x:1365,y:702,t:1527272564401};\\\", \\\"{x:1365,y:701,t:1527272564409};\\\", \\\"{x:1364,y:698,t:1527272564420};\\\", \\\"{x:1361,y:695,t:1527272564436};\\\", \\\"{x:1358,y:689,t:1527272564454};\\\", \\\"{x:1357,y:688,t:1527272564470};\\\", \\\"{x:1356,y:689,t:1527272564898};\\\", \\\"{x:1354,y:691,t:1527272564904};\\\", \\\"{x:1353,y:692,t:1527272564920};\\\", \\\"{x:1353,y:694,t:1527272564938};\\\", \\\"{x:1352,y:694,t:1527272564970};\\\", \\\"{x:1352,y:695,t:1527272564988};\\\", \\\"{x:1352,y:696,t:1527272565005};\\\", \\\"{x:1352,y:697,t:1527272565020};\\\", \\\"{x:1350,y:698,t:1527272565037};\\\", \\\"{x:1350,y:699,t:1527272565112};\\\", \\\"{x:1349,y:700,t:1527272567785};\\\", \\\"{x:1349,y:702,t:1527272567793};\\\", \\\"{x:1349,y:709,t:1527272567808};\\\", \\\"{x:1349,y:716,t:1527272567824};\\\", \\\"{x:1348,y:726,t:1527272567841};\\\", \\\"{x:1348,y:728,t:1527272567857};\\\", \\\"{x:1348,y:729,t:1527272567873};\\\", \\\"{x:1348,y:732,t:1527272567890};\\\", \\\"{x:1348,y:734,t:1527272567906};\\\", \\\"{x:1348,y:741,t:1527272567923};\\\", \\\"{x:1348,y:748,t:1527272567941};\\\", \\\"{x:1347,y:757,t:1527272567956};\\\", \\\"{x:1347,y:760,t:1527272567974};\\\", \\\"{x:1346,y:761,t:1527272568009};\\\", \\\"{x:1343,y:762,t:1527272569193};\\\", \\\"{x:1338,y:762,t:1527272569209};\\\", \\\"{x:1327,y:763,t:1527272569225};\\\", \\\"{x:1318,y:765,t:1527272569242};\\\", \\\"{x:1313,y:766,t:1527272569259};\\\", \\\"{x:1311,y:767,t:1527272569275};\\\", \\\"{x:1310,y:767,t:1527272569441};\\\", \\\"{x:1303,y:767,t:1527272569458};\\\", \\\"{x:1295,y:767,t:1527272569475};\\\", \\\"{x:1280,y:767,t:1527272569491};\\\", \\\"{x:1257,y:767,t:1527272569509};\\\", \\\"{x:1216,y:767,t:1527272569526};\\\", \\\"{x:1141,y:767,t:1527272569541};\\\", \\\"{x:1060,y:767,t:1527272569559};\\\", \\\"{x:1023,y:767,t:1527272569576};\\\", \\\"{x:1012,y:767,t:1527272569591};\\\", \\\"{x:1008,y:767,t:1527272569608};\\\", \\\"{x:1006,y:767,t:1527272569625};\\\", \\\"{x:1005,y:766,t:1527272569665};\\\", \\\"{x:1003,y:765,t:1527272569681};\\\", \\\"{x:1000,y:763,t:1527272569692};\\\", \\\"{x:985,y:757,t:1527272569708};\\\", \\\"{x:960,y:749,t:1527272569725};\\\", \\\"{x:908,y:736,t:1527272569742};\\\", \\\"{x:827,y:723,t:1527272569758};\\\", \\\"{x:774,y:723,t:1527272569775};\\\", \\\"{x:717,y:723,t:1527272569792};\\\", \\\"{x:696,y:725,t:1527272569809};\\\", \\\"{x:690,y:726,t:1527272569825};\\\", \\\"{x:689,y:726,t:1527272569944};\\\", \\\"{x:687,y:726,t:1527272569959};\\\", \\\"{x:677,y:726,t:1527272569976};\\\", \\\"{x:637,y:731,t:1527272569993};\\\", \\\"{x:573,y:731,t:1527272570009};\\\", \\\"{x:508,y:726,t:1527272570027};\\\", \\\"{x:487,y:725,t:1527272570042};\\\", \\\"{x:485,y:725,t:1527272570058};\\\", \\\"{x:484,y:725,t:1527272570096};\\\" ] }, { \\\"rt\\\": 21096, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 1183473, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -X -Z -F -Z -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:724,t:1527272572304};\\\", \\\"{x:483,y:723,t:1527272572360};\\\", \\\"{x:481,y:714,t:1527272572376};\\\", \\\"{x:479,y:707,t:1527272572392};\\\", \\\"{x:479,y:702,t:1527272572409};\\\", \\\"{x:477,y:690,t:1527272572424};\\\", \\\"{x:476,y:679,t:1527272572442};\\\", \\\"{x:474,y:668,t:1527272572459};\\\", \\\"{x:472,y:654,t:1527272572475};\\\", \\\"{x:471,y:645,t:1527272572492};\\\", \\\"{x:469,y:637,t:1527272572509};\\\", \\\"{x:468,y:629,t:1527272572526};\\\", \\\"{x:467,y:620,t:1527272572541};\\\", \\\"{x:463,y:609,t:1527272572558};\\\", \\\"{x:460,y:600,t:1527272572575};\\\", \\\"{x:453,y:576,t:1527272572592};\\\", \\\"{x:449,y:564,t:1527272572609};\\\", \\\"{x:444,y:547,t:1527272572625};\\\", \\\"{x:443,y:532,t:1527272572642};\\\", \\\"{x:441,y:520,t:1527272572660};\\\", \\\"{x:439,y:510,t:1527272572676};\\\", \\\"{x:435,y:501,t:1527272572692};\\\", \\\"{x:434,y:496,t:1527272572709};\\\", \\\"{x:434,y:493,t:1527272572725};\\\", \\\"{x:433,y:490,t:1527272572742};\\\", \\\"{x:433,y:486,t:1527272572759};\\\", \\\"{x:434,y:479,t:1527272572776};\\\", \\\"{x:435,y:476,t:1527272572793};\\\", \\\"{x:436,y:475,t:1527272572809};\\\", \\\"{x:437,y:474,t:1527272572826};\\\", \\\"{x:438,y:473,t:1527272572842};\\\", \\\"{x:438,y:472,t:1527272572859};\\\", \\\"{x:442,y:471,t:1527272572876};\\\", \\\"{x:446,y:469,t:1527272572893};\\\", \\\"{x:448,y:468,t:1527272572910};\\\", \\\"{x:450,y:467,t:1527272572927};\\\", \\\"{x:450,y:466,t:1527272572969};\\\", \\\"{x:452,y:466,t:1527272572992};\\\", \\\"{x:453,y:466,t:1527272573009};\\\", \\\"{x:456,y:466,t:1527272573026};\\\", \\\"{x:462,y:466,t:1527272573043};\\\", \\\"{x:464,y:466,t:1527272573059};\\\", \\\"{x:466,y:466,t:1527272573076};\\\", \\\"{x:468,y:466,t:1527272573096};\\\", \\\"{x:469,y:466,t:1527272573129};\\\", \\\"{x:470,y:466,t:1527272573144};\\\", \\\"{x:471,y:466,t:1527272573161};\\\", \\\"{x:477,y:466,t:1527272573176};\\\", \\\"{x:488,y:466,t:1527272573192};\\\", \\\"{x:506,y:466,t:1527272573209};\\\", \\\"{x:521,y:466,t:1527272573226};\\\", \\\"{x:540,y:466,t:1527272573243};\\\", \\\"{x:555,y:466,t:1527272573258};\\\", \\\"{x:565,y:466,t:1527272573276};\\\", \\\"{x:579,y:466,t:1527272573292};\\\", \\\"{x:590,y:466,t:1527272573309};\\\", \\\"{x:597,y:466,t:1527272573326};\\\", \\\"{x:598,y:466,t:1527272573343};\\\", \\\"{x:599,y:466,t:1527272573400};\\\", \\\"{x:601,y:466,t:1527272573416};\\\", \\\"{x:603,y:466,t:1527272573426};\\\", \\\"{x:607,y:466,t:1527272573443};\\\", \\\"{x:611,y:466,t:1527272573460};\\\", \\\"{x:616,y:466,t:1527272573476};\\\", \\\"{x:622,y:466,t:1527272573493};\\\", \\\"{x:633,y:466,t:1527272573510};\\\", \\\"{x:652,y:466,t:1527272573527};\\\", \\\"{x:677,y:466,t:1527272573543};\\\", \\\"{x:720,y:466,t:1527272573560};\\\", \\\"{x:741,y:468,t:1527272573576};\\\", \\\"{x:770,y:471,t:1527272573594};\\\", \\\"{x:806,y:478,t:1527272573610};\\\", \\\"{x:855,y:482,t:1527272573626};\\\", \\\"{x:902,y:493,t:1527272573645};\\\", \\\"{x:961,y:505,t:1527272573661};\\\", \\\"{x:1020,y:521,t:1527272573676};\\\", \\\"{x:1076,y:538,t:1527272573692};\\\", \\\"{x:1132,y:556,t:1527272573709};\\\", \\\"{x:1191,y:573,t:1527272573726};\\\", \\\"{x:1256,y:597,t:1527272573742};\\\", \\\"{x:1313,y:619,t:1527272573760};\\\", \\\"{x:1386,y:649,t:1527272573776};\\\", \\\"{x:1419,y:665,t:1527272573792};\\\", \\\"{x:1448,y:680,t:1527272573809};\\\", \\\"{x:1476,y:698,t:1527272573826};\\\", \\\"{x:1503,y:715,t:1527272573844};\\\", \\\"{x:1522,y:729,t:1527272573859};\\\", \\\"{x:1538,y:744,t:1527272573876};\\\", \\\"{x:1551,y:756,t:1527272573893};\\\", \\\"{x:1568,y:768,t:1527272573910};\\\", \\\"{x:1574,y:773,t:1527272573927};\\\", \\\"{x:1578,y:773,t:1527272573944};\\\", \\\"{x:1579,y:773,t:1527272573960};\\\", \\\"{x:1579,y:774,t:1527272574154};\\\", \\\"{x:1577,y:776,t:1527272574161};\\\", \\\"{x:1571,y:779,t:1527272574176};\\\", \\\"{x:1561,y:783,t:1527272574193};\\\", \\\"{x:1548,y:788,t:1527272574210};\\\", \\\"{x:1535,y:793,t:1527272574226};\\\", \\\"{x:1523,y:798,t:1527272574243};\\\", \\\"{x:1511,y:806,t:1527272574259};\\\", \\\"{x:1505,y:811,t:1527272574276};\\\", \\\"{x:1501,y:816,t:1527272574293};\\\", \\\"{x:1496,y:824,t:1527272574309};\\\", \\\"{x:1492,y:831,t:1527272574326};\\\", \\\"{x:1489,y:837,t:1527272574343};\\\", \\\"{x:1488,y:841,t:1527272574359};\\\", \\\"{x:1488,y:843,t:1527272574376};\\\", \\\"{x:1488,y:844,t:1527272574433};\\\", \\\"{x:1488,y:846,t:1527272574449};\\\", \\\"{x:1488,y:847,t:1527272574473};\\\", \\\"{x:1488,y:848,t:1527272574481};\\\", \\\"{x:1488,y:849,t:1527272574493};\\\", \\\"{x:1489,y:850,t:1527272574509};\\\", \\\"{x:1490,y:851,t:1527272574526};\\\", \\\"{x:1493,y:854,t:1527272574543};\\\", \\\"{x:1494,y:858,t:1527272574559};\\\", \\\"{x:1497,y:862,t:1527272574576};\\\", \\\"{x:1497,y:863,t:1527272574616};\\\", \\\"{x:1498,y:863,t:1527272574697};\\\", \\\"{x:1499,y:863,t:1527272574713};\\\", \\\"{x:1501,y:863,t:1527272574728};\\\", \\\"{x:1503,y:863,t:1527272574744};\\\", \\\"{x:1511,y:864,t:1527272574761};\\\", \\\"{x:1523,y:864,t:1527272574777};\\\", \\\"{x:1538,y:864,t:1527272574794};\\\", \\\"{x:1557,y:864,t:1527272574811};\\\", \\\"{x:1578,y:864,t:1527272574827};\\\", \\\"{x:1598,y:864,t:1527272574844};\\\", \\\"{x:1610,y:864,t:1527272574861};\\\", \\\"{x:1617,y:864,t:1527272574877};\\\", \\\"{x:1625,y:860,t:1527272574893};\\\", \\\"{x:1630,y:856,t:1527272574910};\\\", \\\"{x:1633,y:851,t:1527272574926};\\\", \\\"{x:1639,y:841,t:1527272574943};\\\", \\\"{x:1642,y:824,t:1527272574960};\\\", \\\"{x:1643,y:806,t:1527272574976};\\\", \\\"{x:1643,y:784,t:1527272574994};\\\", \\\"{x:1641,y:765,t:1527272575010};\\\", \\\"{x:1640,y:752,t:1527272575027};\\\", \\\"{x:1639,y:745,t:1527272575044};\\\", \\\"{x:1637,y:741,t:1527272575060};\\\", \\\"{x:1637,y:740,t:1527272575076};\\\", \\\"{x:1637,y:739,t:1527272575128};\\\", \\\"{x:1637,y:738,t:1527272575144};\\\", \\\"{x:1633,y:729,t:1527272575160};\\\", \\\"{x:1629,y:721,t:1527272575177};\\\", \\\"{x:1627,y:717,t:1527272575193};\\\", \\\"{x:1626,y:716,t:1527272575210};\\\", \\\"{x:1625,y:714,t:1527272575227};\\\", \\\"{x:1624,y:711,t:1527272575244};\\\", \\\"{x:1620,y:702,t:1527272575261};\\\", \\\"{x:1616,y:690,t:1527272575277};\\\", \\\"{x:1612,y:679,t:1527272575293};\\\", \\\"{x:1610,y:676,t:1527272575311};\\\", \\\"{x:1610,y:675,t:1527272575326};\\\", \\\"{x:1610,y:677,t:1527272575489};\\\", \\\"{x:1610,y:678,t:1527272575497};\\\", \\\"{x:1610,y:679,t:1527272575510};\\\", \\\"{x:1610,y:680,t:1527272575528};\\\", \\\"{x:1610,y:681,t:1527272575544};\\\", \\\"{x:1610,y:685,t:1527272575560};\\\", \\\"{x:1611,y:692,t:1527272575579};\\\", \\\"{x:1613,y:696,t:1527272575594};\\\", \\\"{x:1613,y:699,t:1527272575825};\\\", \\\"{x:1613,y:700,t:1527272575832};\\\", \\\"{x:1613,y:701,t:1527272575905};\\\", \\\"{x:1612,y:701,t:1527272579465};\\\", \\\"{x:1600,y:704,t:1527272579480};\\\", \\\"{x:1547,y:704,t:1527272579496};\\\", \\\"{x:1413,y:677,t:1527272579512};\\\", \\\"{x:1126,y:632,t:1527272579529};\\\", \\\"{x:944,y:607,t:1527272579547};\\\", \\\"{x:807,y:598,t:1527272579561};\\\", \\\"{x:713,y:598,t:1527272579578};\\\", \\\"{x:678,y:598,t:1527272579597};\\\", \\\"{x:658,y:597,t:1527272579614};\\\", \\\"{x:653,y:597,t:1527272579631};\\\", \\\"{x:652,y:597,t:1527272579647};\\\", \\\"{x:651,y:597,t:1527272579664};\\\", \\\"{x:649,y:597,t:1527272579681};\\\", \\\"{x:647,y:597,t:1527272579697};\\\", \\\"{x:642,y:599,t:1527272579714};\\\", \\\"{x:636,y:599,t:1527272579730};\\\", \\\"{x:622,y:604,t:1527272579748};\\\", \\\"{x:602,y:606,t:1527272579764};\\\", \\\"{x:587,y:610,t:1527272579782};\\\", \\\"{x:580,y:611,t:1527272579798};\\\", \\\"{x:576,y:614,t:1527272579814};\\\", \\\"{x:575,y:614,t:1527272579831};\\\", \\\"{x:568,y:617,t:1527272579847};\\\", \\\"{x:561,y:619,t:1527272579864};\\\", \\\"{x:552,y:623,t:1527272579881};\\\", \\\"{x:542,y:623,t:1527272579899};\\\", \\\"{x:531,y:622,t:1527272579914};\\\", \\\"{x:505,y:614,t:1527272579932};\\\", \\\"{x:460,y:600,t:1527272579949};\\\", \\\"{x:409,y:589,t:1527272579964};\\\", \\\"{x:388,y:586,t:1527272579982};\\\", \\\"{x:383,y:586,t:1527272579998};\\\", \\\"{x:381,y:586,t:1527272580014};\\\", \\\"{x:380,y:586,t:1527272580040};\\\", \\\"{x:378,y:586,t:1527272580055};\\\", \\\"{x:377,y:586,t:1527272580064};\\\", \\\"{x:369,y:582,t:1527272580082};\\\", \\\"{x:361,y:577,t:1527272580098};\\\", \\\"{x:349,y:573,t:1527272580114};\\\", \\\"{x:334,y:568,t:1527272580131};\\\", \\\"{x:325,y:565,t:1527272580148};\\\", \\\"{x:325,y:564,t:1527272580165};\\\", \\\"{x:325,y:562,t:1527272580218};\\\", \\\"{x:332,y:559,t:1527272580232};\\\", \\\"{x:370,y:541,t:1527272580248};\\\", \\\"{x:406,y:540,t:1527272580266};\\\", \\\"{x:445,y:540,t:1527272580281};\\\", \\\"{x:476,y:540,t:1527272580298};\\\", \\\"{x:506,y:542,t:1527272580315};\\\", \\\"{x:537,y:548,t:1527272580331};\\\", \\\"{x:567,y:556,t:1527272580349};\\\", \\\"{x:594,y:559,t:1527272580365};\\\", \\\"{x:610,y:561,t:1527272580381};\\\", \\\"{x:611,y:561,t:1527272580398};\\\", \\\"{x:614,y:561,t:1527272580415};\\\", \\\"{x:623,y:562,t:1527272580431};\\\", \\\"{x:647,y:564,t:1527272580450};\\\", \\\"{x:657,y:564,t:1527272580465};\\\", \\\"{x:660,y:564,t:1527272580481};\\\", \\\"{x:662,y:564,t:1527272580504};\\\", \\\"{x:663,y:564,t:1527272580515};\\\", \\\"{x:665,y:563,t:1527272580536};\\\", \\\"{x:667,y:563,t:1527272580600};\\\", \\\"{x:672,y:561,t:1527272580617};\\\", \\\"{x:709,y:536,t:1527272580632};\\\", \\\"{x:733,y:523,t:1527272580649};\\\", \\\"{x:749,y:514,t:1527272580666};\\\", \\\"{x:758,y:510,t:1527272580682};\\\", \\\"{x:758,y:509,t:1527272580698};\\\", \\\"{x:760,y:509,t:1527272580715};\\\", \\\"{x:761,y:509,t:1527272580768};\\\", \\\"{x:763,y:508,t:1527272580782};\\\", \\\"{x:769,y:506,t:1527272580799};\\\", \\\"{x:776,y:503,t:1527272580816};\\\", \\\"{x:778,y:502,t:1527272580833};\\\", \\\"{x:782,y:500,t:1527272580849};\\\", \\\"{x:799,y:499,t:1527272580865};\\\", \\\"{x:820,y:499,t:1527272580882};\\\", \\\"{x:828,y:499,t:1527272580900};\\\", \\\"{x:829,y:499,t:1527272580916};\\\", \\\"{x:830,y:499,t:1527272581305};\\\", \\\"{x:835,y:503,t:1527272581315};\\\", \\\"{x:857,y:519,t:1527272581334};\\\", \\\"{x:887,y:534,t:1527272581350};\\\", \\\"{x:920,y:547,t:1527272581365};\\\", \\\"{x:980,y:569,t:1527272581383};\\\", \\\"{x:1052,y:589,t:1527272581399};\\\", \\\"{x:1157,y:618,t:1527272581415};\\\", \\\"{x:1212,y:632,t:1527272581432};\\\", \\\"{x:1270,y:647,t:1527272581449};\\\", \\\"{x:1294,y:654,t:1527272581466};\\\", \\\"{x:1311,y:659,t:1527272581482};\\\", \\\"{x:1323,y:662,t:1527272581499};\\\", \\\"{x:1336,y:666,t:1527272581517};\\\", \\\"{x:1357,y:672,t:1527272581532};\\\", \\\"{x:1381,y:675,t:1527272581550};\\\", \\\"{x:1384,y:673,t:1527272581566};\\\", \\\"{x:1389,y:673,t:1527272581865};\\\", \\\"{x:1405,y:683,t:1527272581872};\\\", \\\"{x:1420,y:697,t:1527272581885};\\\", \\\"{x:1440,y:715,t:1527272581901};\\\", \\\"{x:1454,y:726,t:1527272581918};\\\", \\\"{x:1461,y:730,t:1527272581934};\\\", \\\"{x:1464,y:733,t:1527272581951};\\\", \\\"{x:1465,y:734,t:1527272581968};\\\", \\\"{x:1470,y:739,t:1527272581983};\\\", \\\"{x:1474,y:747,t:1527272582002};\\\", \\\"{x:1479,y:752,t:1527272582017};\\\", \\\"{x:1480,y:753,t:1527272582034};\\\", \\\"{x:1481,y:754,t:1527272582056};\\\", \\\"{x:1481,y:756,t:1527272582097};\\\", \\\"{x:1483,y:760,t:1527272582105};\\\", \\\"{x:1485,y:766,t:1527272582119};\\\", \\\"{x:1485,y:779,t:1527272582134};\\\", \\\"{x:1485,y:798,t:1527272582152};\\\", \\\"{x:1483,y:822,t:1527272582169};\\\", \\\"{x:1478,y:835,t:1527272582185};\\\", \\\"{x:1472,y:844,t:1527272582202};\\\", \\\"{x:1463,y:855,t:1527272582219};\\\", \\\"{x:1449,y:870,t:1527272582234};\\\", \\\"{x:1438,y:880,t:1527272582251};\\\", \\\"{x:1427,y:890,t:1527272582268};\\\", \\\"{x:1414,y:899,t:1527272582285};\\\", \\\"{x:1397,y:910,t:1527272582301};\\\", \\\"{x:1389,y:914,t:1527272582318};\\\", \\\"{x:1385,y:917,t:1527272582335};\\\", \\\"{x:1384,y:917,t:1527272582352};\\\", \\\"{x:1384,y:918,t:1527272582368};\\\", \\\"{x:1386,y:919,t:1527272582505};\\\", \\\"{x:1389,y:919,t:1527272582520};\\\", \\\"{x:1394,y:919,t:1527272582536};\\\", \\\"{x:1407,y:913,t:1527272582553};\\\", \\\"{x:1420,y:905,t:1527272582570};\\\", \\\"{x:1431,y:898,t:1527272582587};\\\", \\\"{x:1438,y:893,t:1527272582603};\\\", \\\"{x:1445,y:888,t:1527272582621};\\\", \\\"{x:1449,y:884,t:1527272582636};\\\", \\\"{x:1454,y:879,t:1527272582653};\\\", \\\"{x:1457,y:874,t:1527272582670};\\\", \\\"{x:1459,y:869,t:1527272582687};\\\", \\\"{x:1463,y:865,t:1527272582704};\\\", \\\"{x:1465,y:862,t:1527272582720};\\\", \\\"{x:1467,y:858,t:1527272582736};\\\", \\\"{x:1470,y:854,t:1527272582754};\\\", \\\"{x:1473,y:848,t:1527272582770};\\\", \\\"{x:1476,y:845,t:1527272582787};\\\", \\\"{x:1476,y:844,t:1527272582804};\\\", \\\"{x:1477,y:843,t:1527272582821};\\\", \\\"{x:1471,y:839,t:1527272582921};\\\", \\\"{x:1385,y:812,t:1527272582938};\\\", \\\"{x:1244,y:768,t:1527272582954};\\\", \\\"{x:1134,y:746,t:1527272582971};\\\", \\\"{x:1045,y:744,t:1527272582988};\\\", \\\"{x:936,y:736,t:1527272583004};\\\", \\\"{x:830,y:720,t:1527272583021};\\\", \\\"{x:741,y:707,t:1527272583037};\\\", \\\"{x:684,y:693,t:1527272583054};\\\", \\\"{x:655,y:687,t:1527272583071};\\\", \\\"{x:627,y:684,t:1527272583088};\\\", \\\"{x:596,y:678,t:1527272583105};\\\", \\\"{x:590,y:678,t:1527272583120};\\\", \\\"{x:589,y:678,t:1527272583138};\\\", \\\"{x:588,y:676,t:1527272583177};\\\", \\\"{x:586,y:674,t:1527272583188};\\\", \\\"{x:580,y:664,t:1527272583205};\\\", \\\"{x:566,y:650,t:1527272583221};\\\", \\\"{x:552,y:640,t:1527272583237};\\\", \\\"{x:546,y:638,t:1527272583254};\\\", \\\"{x:541,y:637,t:1527272583271};\\\", \\\"{x:514,y:632,t:1527272583288};\\\", \\\"{x:489,y:629,t:1527272583304};\\\", \\\"{x:471,y:626,t:1527272583321};\\\", \\\"{x:469,y:626,t:1527272583338};\\\", \\\"{x:462,y:626,t:1527272583447};\\\", \\\"{x:450,y:626,t:1527272583456};\\\", \\\"{x:439,y:626,t:1527272583467};\\\", \\\"{x:419,y:624,t:1527272583484};\\\", \\\"{x:398,y:618,t:1527272583501};\\\", \\\"{x:376,y:608,t:1527272583518};\\\", \\\"{x:344,y:595,t:1527272583535};\\\", \\\"{x:310,y:585,t:1527272583550};\\\", \\\"{x:294,y:583,t:1527272583568};\\\", \\\"{x:295,y:582,t:1527272583592};\\\", \\\"{x:300,y:579,t:1527272583600};\\\", \\\"{x:309,y:574,t:1527272583617};\\\", \\\"{x:313,y:573,t:1527272583634};\\\", \\\"{x:309,y:573,t:1527272583705};\\\", \\\"{x:307,y:575,t:1527272583718};\\\", \\\"{x:303,y:575,t:1527272583801};\\\", \\\"{x:277,y:563,t:1527272583817};\\\", \\\"{x:235,y:551,t:1527272583837};\\\", \\\"{x:195,y:544,t:1527272583851};\\\", \\\"{x:188,y:541,t:1527272583867};\\\", \\\"{x:186,y:540,t:1527272583884};\\\", \\\"{x:183,y:538,t:1527272583901};\\\", \\\"{x:176,y:535,t:1527272583917};\\\", \\\"{x:170,y:533,t:1527272583934};\\\", \\\"{x:169,y:533,t:1527272583951};\\\", \\\"{x:168,y:532,t:1527272583991};\\\", \\\"{x:170,y:530,t:1527272584007};\\\", \\\"{x:172,y:529,t:1527272584017};\\\", \\\"{x:185,y:523,t:1527272584035};\\\", \\\"{x:213,y:520,t:1527272584051};\\\", \\\"{x:247,y:515,t:1527272584068};\\\", \\\"{x:274,y:515,t:1527272584085};\\\", \\\"{x:289,y:515,t:1527272584101};\\\", \\\"{x:301,y:517,t:1527272584118};\\\", \\\"{x:312,y:519,t:1527272584135};\\\", \\\"{x:345,y:519,t:1527272584151};\\\", \\\"{x:372,y:520,t:1527272584167};\\\", \\\"{x:394,y:521,t:1527272584184};\\\", \\\"{x:408,y:521,t:1527272584201};\\\", \\\"{x:412,y:522,t:1527272584218};\\\", \\\"{x:417,y:523,t:1527272584234};\\\", \\\"{x:419,y:523,t:1527272584255};\\\", \\\"{x:420,y:523,t:1527272584296};\\\", \\\"{x:424,y:523,t:1527272584303};\\\", \\\"{x:433,y:524,t:1527272584317};\\\", \\\"{x:452,y:531,t:1527272584335};\\\", \\\"{x:483,y:539,t:1527272584350};\\\", \\\"{x:530,y:548,t:1527272584368};\\\", \\\"{x:564,y:549,t:1527272584384};\\\", \\\"{x:588,y:550,t:1527272584401};\\\", \\\"{x:607,y:550,t:1527272584419};\\\", \\\"{x:630,y:550,t:1527272584435};\\\", \\\"{x:645,y:550,t:1527272584452};\\\", \\\"{x:650,y:550,t:1527272584469};\\\", \\\"{x:650,y:548,t:1527272584504};\\\", \\\"{x:649,y:548,t:1527272584520};\\\", \\\"{x:647,y:548,t:1527272584576};\\\", \\\"{x:645,y:549,t:1527272584585};\\\", \\\"{x:637,y:555,t:1527272584602};\\\", \\\"{x:631,y:559,t:1527272584620};\\\", \\\"{x:628,y:562,t:1527272584636};\\\", \\\"{x:626,y:562,t:1527272584664};\\\", \\\"{x:622,y:562,t:1527272584672};\\\", \\\"{x:620,y:562,t:1527272584686};\\\", \\\"{x:614,y:563,t:1527272584703};\\\", \\\"{x:611,y:566,t:1527272584718};\\\", \\\"{x:610,y:574,t:1527272584960};\\\", \\\"{x:610,y:580,t:1527272584970};\\\", \\\"{x:610,y:585,t:1527272584985};\\\", \\\"{x:610,y:586,t:1527272585002};\\\", \\\"{x:610,y:594,t:1527272585546};\\\", \\\"{x:611,y:605,t:1527272585552};\\\", \\\"{x:620,y:622,t:1527272585570};\\\", \\\"{x:622,y:626,t:1527272585585};\\\", \\\"{x:623,y:626,t:1527272585647};\\\", \\\"{x:623,y:616,t:1527272585655};\\\", \\\"{x:622,y:604,t:1527272585669};\\\", \\\"{x:613,y:586,t:1527272585686};\\\", \\\"{x:612,y:584,t:1527272585702};\\\", \\\"{x:612,y:581,t:1527272586273};\\\", \\\"{x:626,y:580,t:1527272586287};\\\", \\\"{x:746,y:625,t:1527272586304};\\\", \\\"{x:827,y:663,t:1527272586320};\\\", \\\"{x:904,y:709,t:1527272586337};\\\", \\\"{x:997,y:766,t:1527272586354};\\\", \\\"{x:1134,y:836,t:1527272586369};\\\", \\\"{x:1262,y:886,t:1527272586386};\\\", \\\"{x:1291,y:894,t:1527272586404};\\\", \\\"{x:1292,y:894,t:1527272586769};\\\", \\\"{x:1294,y:894,t:1527272586776};\\\", \\\"{x:1295,y:894,t:1527272586825};\\\", \\\"{x:1297,y:894,t:1527272586836};\\\", \\\"{x:1301,y:893,t:1527272586853};\\\", \\\"{x:1307,y:893,t:1527272586870};\\\", \\\"{x:1310,y:891,t:1527272586887};\\\", \\\"{x:1318,y:890,t:1527272586903};\\\", \\\"{x:1328,y:889,t:1527272586920};\\\", \\\"{x:1352,y:889,t:1527272586936};\\\", \\\"{x:1386,y:889,t:1527272586953};\\\", \\\"{x:1428,y:889,t:1527272586970};\\\", \\\"{x:1458,y:886,t:1527272586986};\\\", \\\"{x:1478,y:883,t:1527272587004};\\\", \\\"{x:1490,y:880,t:1527272587020};\\\", \\\"{x:1511,y:875,t:1527272587036};\\\", \\\"{x:1525,y:875,t:1527272587054};\\\", \\\"{x:1535,y:873,t:1527272587071};\\\", \\\"{x:1536,y:873,t:1527272587087};\\\", \\\"{x:1536,y:871,t:1527272587112};\\\", \\\"{x:1536,y:870,t:1527272587120};\\\", \\\"{x:1536,y:867,t:1527272587137};\\\", \\\"{x:1536,y:866,t:1527272587154};\\\", \\\"{x:1536,y:865,t:1527272587171};\\\", \\\"{x:1536,y:849,t:1527272587187};\\\", \\\"{x:1536,y:840,t:1527272587204};\\\", \\\"{x:1536,y:839,t:1527272587280};\\\", \\\"{x:1534,y:836,t:1527272587288};\\\", \\\"{x:1533,y:834,t:1527272587304};\\\", \\\"{x:1572,y:787,t:1527272587321};\\\", \\\"{x:1604,y:757,t:1527272587338};\\\", \\\"{x:1606,y:747,t:1527272587354};\\\", \\\"{x:1606,y:737,t:1527272587371};\\\", \\\"{x:1599,y:721,t:1527272587388};\\\", \\\"{x:1589,y:704,t:1527272587404};\\\", \\\"{x:1582,y:687,t:1527272587421};\\\", \\\"{x:1581,y:680,t:1527272587438};\\\", \\\"{x:1583,y:674,t:1527272587454};\\\", \\\"{x:1591,y:670,t:1527272587471};\\\", \\\"{x:1600,y:666,t:1527272587489};\\\", \\\"{x:1601,y:670,t:1527272587632};\\\", \\\"{x:1604,y:679,t:1527272587640};\\\", \\\"{x:1608,y:691,t:1527272587653};\\\", \\\"{x:1617,y:706,t:1527272587670};\\\", \\\"{x:1618,y:710,t:1527272587688};\\\", \\\"{x:1619,y:710,t:1527272587753};\\\", \\\"{x:1619,y:712,t:1527272587761};\\\", \\\"{x:1619,y:715,t:1527272587771};\\\", \\\"{x:1620,y:717,t:1527272587788};\\\", \\\"{x:1620,y:716,t:1527272588009};\\\", \\\"{x:1620,y:712,t:1527272588021};\\\", \\\"{x:1620,y:708,t:1527272588039};\\\", \\\"{x:1620,y:704,t:1527272588055};\\\", \\\"{x:1620,y:702,t:1527272588071};\\\", \\\"{x:1620,y:701,t:1527272588121};\\\", \\\"{x:1620,y:700,t:1527272588441};\\\", \\\"{x:1618,y:700,t:1527272588456};\\\", \\\"{x:1617,y:700,t:1527272588471};\\\", \\\"{x:1614,y:700,t:1527272588688};\\\", \\\"{x:1607,y:698,t:1527272588706};\\\", \\\"{x:1601,y:698,t:1527272588723};\\\", \\\"{x:1596,y:698,t:1527272588739};\\\", \\\"{x:1582,y:698,t:1527272588755};\\\", \\\"{x:1560,y:698,t:1527272588773};\\\", \\\"{x:1524,y:698,t:1527272588789};\\\", \\\"{x:1477,y:698,t:1527272588805};\\\", \\\"{x:1418,y:698,t:1527272588822};\\\", \\\"{x:1384,y:698,t:1527272588839};\\\", \\\"{x:1360,y:698,t:1527272588855};\\\", \\\"{x:1353,y:698,t:1527272588872};\\\", \\\"{x:1355,y:697,t:1527272588914};\\\", \\\"{x:1356,y:697,t:1527272588922};\\\", \\\"{x:1357,y:696,t:1527272588970};\\\", \\\"{x:1359,y:696,t:1527272589008};\\\", \\\"{x:1363,y:696,t:1527272589022};\\\", \\\"{x:1369,y:696,t:1527272589039};\\\", \\\"{x:1371,y:695,t:1527272589055};\\\", \\\"{x:1372,y:695,t:1527272589088};\\\", \\\"{x:1372,y:697,t:1527272589105};\\\", \\\"{x:1367,y:698,t:1527272589122};\\\", \\\"{x:1365,y:698,t:1527272589139};\\\", \\\"{x:1364,y:698,t:1527272589209};\\\", \\\"{x:1368,y:699,t:1527272589335};\\\", \\\"{x:1378,y:699,t:1527272589344};\\\", \\\"{x:1390,y:699,t:1527272589355};\\\", \\\"{x:1448,y:708,t:1527272589371};\\\", \\\"{x:1528,y:708,t:1527272589388};\\\", \\\"{x:1562,y:708,t:1527272589406};\\\", \\\"{x:1590,y:708,t:1527272589422};\\\", \\\"{x:1608,y:708,t:1527272589439};\\\", \\\"{x:1620,y:704,t:1527272589456};\\\", \\\"{x:1622,y:703,t:1527272589472};\\\", \\\"{x:1621,y:701,t:1527272589521};\\\", \\\"{x:1617,y:701,t:1527272589536};\\\", \\\"{x:1601,y:701,t:1527272589557};\\\", \\\"{x:1580,y:701,t:1527272589571};\\\", \\\"{x:1562,y:705,t:1527272589588};\\\", \\\"{x:1547,y:719,t:1527272589606};\\\", \\\"{x:1531,y:735,t:1527272589622};\\\", \\\"{x:1519,y:754,t:1527272589639};\\\", \\\"{x:1504,y:782,t:1527272589657};\\\", \\\"{x:1493,y:801,t:1527272589672};\\\", \\\"{x:1483,y:818,t:1527272589689};\\\", \\\"{x:1472,y:829,t:1527272589706};\\\", \\\"{x:1467,y:835,t:1527272589723};\\\", \\\"{x:1461,y:838,t:1527272589739};\\\", \\\"{x:1457,y:841,t:1527272589756};\\\", \\\"{x:1455,y:844,t:1527272589773};\\\", \\\"{x:1451,y:849,t:1527272589789};\\\", \\\"{x:1444,y:855,t:1527272589806};\\\", \\\"{x:1430,y:871,t:1527272589823};\\\", \\\"{x:1414,y:889,t:1527272589839};\\\", \\\"{x:1394,y:904,t:1527272589856};\\\", \\\"{x:1381,y:913,t:1527272589873};\\\", \\\"{x:1368,y:917,t:1527272589889};\\\", \\\"{x:1356,y:920,t:1527272589906};\\\", \\\"{x:1353,y:921,t:1527272589923};\\\", \\\"{x:1352,y:921,t:1527272589939};\\\", \\\"{x:1353,y:917,t:1527272590017};\\\", \\\"{x:1356,y:916,t:1527272590025};\\\", \\\"{x:1369,y:909,t:1527272590039};\\\", \\\"{x:1431,y:882,t:1527272590056};\\\", \\\"{x:1481,y:860,t:1527272590073};\\\", \\\"{x:1512,y:845,t:1527272590090};\\\", \\\"{x:1532,y:834,t:1527272590107};\\\", \\\"{x:1539,y:830,t:1527272590123};\\\", \\\"{x:1540,y:830,t:1527272590140};\\\", \\\"{x:1539,y:830,t:1527272590184};\\\", \\\"{x:1535,y:830,t:1527272590192};\\\", \\\"{x:1526,y:830,t:1527272590206};\\\", \\\"{x:1513,y:830,t:1527272590223};\\\", \\\"{x:1489,y:830,t:1527272590240};\\\", \\\"{x:1483,y:830,t:1527272590257};\\\", \\\"{x:1480,y:830,t:1527272590273};\\\", \\\"{x:1479,y:830,t:1527272590345};\\\", \\\"{x:1477,y:830,t:1527272590416};\\\", \\\"{x:1479,y:830,t:1527272590505};\\\", \\\"{x:1482,y:831,t:1527272590512};\\\", \\\"{x:1484,y:831,t:1527272590523};\\\", \\\"{x:1487,y:831,t:1527272590542};\\\", \\\"{x:1491,y:831,t:1527272590557};\\\", \\\"{x:1499,y:832,t:1527272590573};\\\", \\\"{x:1516,y:835,t:1527272590590};\\\", \\\"{x:1534,y:835,t:1527272590607};\\\", \\\"{x:1544,y:835,t:1527272590623};\\\", \\\"{x:1545,y:835,t:1527272590640};\\\", \\\"{x:1547,y:835,t:1527272590657};\\\", \\\"{x:1552,y:834,t:1527272590674};\\\", \\\"{x:1561,y:831,t:1527272590690};\\\", \\\"{x:1572,y:828,t:1527272590707};\\\", \\\"{x:1583,y:825,t:1527272590723};\\\", \\\"{x:1592,y:825,t:1527272590741};\\\", \\\"{x:1601,y:823,t:1527272590757};\\\", \\\"{x:1609,y:823,t:1527272590773};\\\", \\\"{x:1615,y:823,t:1527272590790};\\\", \\\"{x:1617,y:823,t:1527272590807};\\\", \\\"{x:1617,y:825,t:1527272591945};\\\", \\\"{x:1617,y:826,t:1527272591958};\\\", \\\"{x:1617,y:835,t:1527272591974};\\\", \\\"{x:1615,y:843,t:1527272591991};\\\", \\\"{x:1602,y:856,t:1527272592008};\\\", \\\"{x:1575,y:863,t:1527272592024};\\\", \\\"{x:1503,y:863,t:1527272592041};\\\", \\\"{x:1362,y:847,t:1527272592059};\\\", \\\"{x:1151,y:812,t:1527272592074};\\\", \\\"{x:916,y:770,t:1527272592091};\\\", \\\"{x:715,y:747,t:1527272592108};\\\", \\\"{x:604,y:747,t:1527272592124};\\\", \\\"{x:551,y:747,t:1527272592142};\\\", \\\"{x:529,y:747,t:1527272592157};\\\", \\\"{x:527,y:747,t:1527272592173};\\\", \\\"{x:527,y:746,t:1527272592231};\\\", \\\"{x:529,y:746,t:1527272592239};\\\", \\\"{x:532,y:747,t:1527272592250};\\\", \\\"{x:534,y:747,t:1527272592267};\\\", \\\"{x:534,y:748,t:1527272592283};\\\", \\\"{x:536,y:749,t:1527272592312};\\\", \\\"{x:536,y:750,t:1527272592344};\\\", \\\"{x:537,y:753,t:1527272592352};\\\", \\\"{x:538,y:755,t:1527272592367};\\\", \\\"{x:542,y:760,t:1527272592384};\\\", \\\"{x:542,y:755,t:1527272592448};\\\", \\\"{x:540,y:753,t:1527272592459};\\\" ] }, { \\\"rt\\\": 24597, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 1209300, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-M -X -03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:750,t:1527272594520};\\\", \\\"{x:549,y:747,t:1527272594529};\\\", \\\"{x:567,y:742,t:1527272594545};\\\", \\\"{x:599,y:742,t:1527272594562};\\\", \\\"{x:651,y:746,t:1527272594577};\\\", \\\"{x:704,y:754,t:1527272594593};\\\", \\\"{x:754,y:762,t:1527272594609};\\\", \\\"{x:821,y:772,t:1527272594625};\\\", \\\"{x:905,y:783,t:1527272594642};\\\", \\\"{x:999,y:795,t:1527272594660};\\\", \\\"{x:1082,y:808,t:1527272594677};\\\", \\\"{x:1152,y:817,t:1527272594693};\\\", \\\"{x:1208,y:818,t:1527272594710};\\\", \\\"{x:1236,y:818,t:1527272594727};\\\", \\\"{x:1242,y:817,t:1527272594743};\\\", \\\"{x:1245,y:817,t:1527272594992};\\\", \\\"{x:1254,y:824,t:1527272594999};\\\", \\\"{x:1260,y:830,t:1527272595010};\\\", \\\"{x:1266,y:842,t:1527272595027};\\\", \\\"{x:1267,y:848,t:1527272595043};\\\", \\\"{x:1267,y:855,t:1527272595059};\\\", \\\"{x:1270,y:862,t:1527272595077};\\\", \\\"{x:1273,y:871,t:1527272595094};\\\", \\\"{x:1279,y:884,t:1527272595109};\\\", \\\"{x:1284,y:894,t:1527272595127};\\\", \\\"{x:1288,y:903,t:1527272595143};\\\", \\\"{x:1290,y:905,t:1527272595160};\\\", \\\"{x:1300,y:907,t:1527272595177};\\\", \\\"{x:1325,y:913,t:1527272595194};\\\", \\\"{x:1358,y:918,t:1527272595210};\\\", \\\"{x:1388,y:919,t:1527272595227};\\\", \\\"{x:1406,y:919,t:1527272595243};\\\", \\\"{x:1427,y:919,t:1527272595260};\\\", \\\"{x:1449,y:921,t:1527272595276};\\\", \\\"{x:1461,y:922,t:1527272595294};\\\", \\\"{x:1471,y:924,t:1527272595310};\\\", \\\"{x:1477,y:927,t:1527272595327};\\\", \\\"{x:1485,y:930,t:1527272595343};\\\", \\\"{x:1489,y:933,t:1527272595360};\\\", \\\"{x:1496,y:939,t:1527272595377};\\\", \\\"{x:1504,y:948,t:1527272595393};\\\", \\\"{x:1511,y:952,t:1527272595410};\\\", \\\"{x:1514,y:954,t:1527272595427};\\\", \\\"{x:1515,y:954,t:1527272595444};\\\", \\\"{x:1517,y:954,t:1527272595460};\\\", \\\"{x:1519,y:954,t:1527272595477};\\\", \\\"{x:1521,y:956,t:1527272595494};\\\", \\\"{x:1523,y:958,t:1527272595510};\\\", \\\"{x:1525,y:961,t:1527272595527};\\\", \\\"{x:1529,y:963,t:1527272595544};\\\", \\\"{x:1530,y:964,t:1527272595560};\\\", \\\"{x:1534,y:965,t:1527272595576};\\\", \\\"{x:1538,y:967,t:1527272595594};\\\", \\\"{x:1543,y:969,t:1527272595611};\\\", \\\"{x:1549,y:973,t:1527272595626};\\\", \\\"{x:1551,y:975,t:1527272595644};\\\", \\\"{x:1553,y:975,t:1527272595660};\\\", \\\"{x:1561,y:975,t:1527272595676};\\\", \\\"{x:1574,y:975,t:1527272595694};\\\", \\\"{x:1575,y:975,t:1527272595711};\\\", \\\"{x:1576,y:975,t:1527272595760};\\\", \\\"{x:1576,y:974,t:1527272595784};\\\", \\\"{x:1577,y:973,t:1527272595794};\\\", \\\"{x:1577,y:971,t:1527272595811};\\\", \\\"{x:1572,y:966,t:1527272595827};\\\", \\\"{x:1570,y:963,t:1527272595844};\\\", \\\"{x:1568,y:962,t:1527272595861};\\\", \\\"{x:1567,y:961,t:1527272595879};\\\", \\\"{x:1565,y:960,t:1527272595896};\\\", \\\"{x:1561,y:957,t:1527272595911};\\\", \\\"{x:1558,y:955,t:1527272595927};\\\", \\\"{x:1557,y:955,t:1527272595992};\\\", \\\"{x:1556,y:955,t:1527272596009};\\\", \\\"{x:1555,y:955,t:1527272596057};\\\", \\\"{x:1554,y:955,t:1527272596072};\\\", \\\"{x:1552,y:955,t:1527272596080};\\\", \\\"{x:1550,y:955,t:1527272596094};\\\", \\\"{x:1545,y:955,t:1527272596111};\\\", \\\"{x:1538,y:955,t:1527272596127};\\\", \\\"{x:1536,y:955,t:1527272596144};\\\", \\\"{x:1535,y:955,t:1527272596161};\\\", \\\"{x:1534,y:955,t:1527272596208};\\\", \\\"{x:1533,y:955,t:1527272596241};\\\", \\\"{x:1532,y:954,t:1527272596281};\\\", \\\"{x:1531,y:953,t:1527272596294};\\\", \\\"{x:1531,y:952,t:1527272596384};\\\", \\\"{x:1530,y:950,t:1527272596568};\\\", \\\"{x:1529,y:948,t:1527272596578};\\\", \\\"{x:1528,y:939,t:1527272596596};\\\", \\\"{x:1527,y:931,t:1527272596611};\\\", \\\"{x:1526,y:921,t:1527272596628};\\\", \\\"{x:1523,y:910,t:1527272596645};\\\", \\\"{x:1523,y:904,t:1527272596661};\\\", \\\"{x:1523,y:901,t:1527272596678};\\\", \\\"{x:1523,y:899,t:1527272596695};\\\", \\\"{x:1523,y:898,t:1527272596711};\\\", \\\"{x:1523,y:897,t:1527272596729};\\\", \\\"{x:1524,y:897,t:1527272596849};\\\", \\\"{x:1527,y:897,t:1527272596864};\\\", \\\"{x:1528,y:899,t:1527272596878};\\\", \\\"{x:1531,y:903,t:1527272596896};\\\", \\\"{x:1533,y:909,t:1527272596911};\\\", \\\"{x:1535,y:917,t:1527272596928};\\\", \\\"{x:1536,y:922,t:1527272596945};\\\", \\\"{x:1537,y:926,t:1527272596962};\\\", \\\"{x:1539,y:930,t:1527272596978};\\\", \\\"{x:1539,y:933,t:1527272596996};\\\", \\\"{x:1539,y:931,t:1527272597136};\\\", \\\"{x:1539,y:926,t:1527272597146};\\\", \\\"{x:1539,y:915,t:1527272597163};\\\", \\\"{x:1539,y:904,t:1527272597178};\\\", \\\"{x:1537,y:895,t:1527272597195};\\\", \\\"{x:1537,y:884,t:1527272597213};\\\", \\\"{x:1537,y:871,t:1527272597228};\\\", \\\"{x:1537,y:862,t:1527272597245};\\\", \\\"{x:1537,y:857,t:1527272597262};\\\", \\\"{x:1537,y:856,t:1527272597279};\\\", \\\"{x:1537,y:854,t:1527272597295};\\\", \\\"{x:1537,y:852,t:1527272597312};\\\", \\\"{x:1537,y:847,t:1527272597329};\\\", \\\"{x:1537,y:844,t:1527272597345};\\\", \\\"{x:1537,y:842,t:1527272597363};\\\", \\\"{x:1537,y:839,t:1527272597379};\\\", \\\"{x:1537,y:837,t:1527272597395};\\\", \\\"{x:1536,y:833,t:1527272597412};\\\", \\\"{x:1535,y:830,t:1527272597430};\\\", \\\"{x:1535,y:825,t:1527272597446};\\\", \\\"{x:1535,y:821,t:1527272597463};\\\", \\\"{x:1535,y:817,t:1527272597479};\\\", \\\"{x:1535,y:815,t:1527272597495};\\\", \\\"{x:1535,y:811,t:1527272597512};\\\", \\\"{x:1536,y:804,t:1527272597529};\\\", \\\"{x:1537,y:796,t:1527272597546};\\\", \\\"{x:1540,y:786,t:1527272597562};\\\", \\\"{x:1543,y:779,t:1527272597579};\\\", \\\"{x:1544,y:775,t:1527272597596};\\\", \\\"{x:1544,y:772,t:1527272597614};\\\", \\\"{x:1544,y:768,t:1527272597630};\\\", \\\"{x:1545,y:762,t:1527272597645};\\\", \\\"{x:1547,y:759,t:1527272597663};\\\", \\\"{x:1548,y:753,t:1527272597679};\\\", \\\"{x:1548,y:751,t:1527272597696};\\\", \\\"{x:1548,y:745,t:1527272597712};\\\", \\\"{x:1548,y:742,t:1527272597730};\\\", \\\"{x:1548,y:737,t:1527272597745};\\\", \\\"{x:1548,y:729,t:1527272597763};\\\", \\\"{x:1548,y:723,t:1527272597779};\\\", \\\"{x:1548,y:715,t:1527272597796};\\\", \\\"{x:1548,y:710,t:1527272597812};\\\", \\\"{x:1548,y:705,t:1527272597829};\\\", \\\"{x:1549,y:702,t:1527272597845};\\\", \\\"{x:1549,y:699,t:1527272597862};\\\", \\\"{x:1549,y:696,t:1527272597879};\\\", \\\"{x:1549,y:690,t:1527272597895};\\\", \\\"{x:1549,y:686,t:1527272597911};\\\", \\\"{x:1549,y:682,t:1527272597928};\\\", \\\"{x:1549,y:678,t:1527272597946};\\\", \\\"{x:1549,y:673,t:1527272597962};\\\", \\\"{x:1549,y:667,t:1527272597979};\\\", \\\"{x:1549,y:662,t:1527272597996};\\\", \\\"{x:1548,y:658,t:1527272598011};\\\", \\\"{x:1547,y:653,t:1527272598029};\\\", \\\"{x:1547,y:647,t:1527272598046};\\\", \\\"{x:1544,y:641,t:1527272598062};\\\", \\\"{x:1544,y:636,t:1527272598079};\\\", \\\"{x:1544,y:630,t:1527272598095};\\\", \\\"{x:1544,y:625,t:1527272598112};\\\", \\\"{x:1544,y:620,t:1527272598129};\\\", \\\"{x:1543,y:613,t:1527272598146};\\\", \\\"{x:1543,y:607,t:1527272598162};\\\", \\\"{x:1541,y:602,t:1527272598179};\\\", \\\"{x:1541,y:598,t:1527272598196};\\\", \\\"{x:1541,y:593,t:1527272598213};\\\", \\\"{x:1541,y:588,t:1527272598229};\\\", \\\"{x:1541,y:583,t:1527272598245};\\\", \\\"{x:1541,y:575,t:1527272598261};\\\", \\\"{x:1541,y:566,t:1527272598279};\\\", \\\"{x:1541,y:558,t:1527272598295};\\\", \\\"{x:1541,y:552,t:1527272598312};\\\", \\\"{x:1541,y:548,t:1527272598329};\\\", \\\"{x:1541,y:545,t:1527272598346};\\\", \\\"{x:1543,y:539,t:1527272598363};\\\", \\\"{x:1543,y:536,t:1527272598379};\\\", \\\"{x:1543,y:534,t:1527272598397};\\\", \\\"{x:1543,y:530,t:1527272598415};\\\", \\\"{x:1543,y:527,t:1527272598430};\\\", \\\"{x:1545,y:520,t:1527272598447};\\\", \\\"{x:1547,y:514,t:1527272598464};\\\", \\\"{x:1549,y:504,t:1527272598479};\\\", \\\"{x:1553,y:490,t:1527272598496};\\\", \\\"{x:1553,y:482,t:1527272598513};\\\", \\\"{x:1553,y:470,t:1527272598529};\\\", \\\"{x:1553,y:465,t:1527272598546};\\\", \\\"{x:1553,y:459,t:1527272598563};\\\", \\\"{x:1554,y:454,t:1527272598579};\\\", \\\"{x:1556,y:449,t:1527272598597};\\\", \\\"{x:1557,y:444,t:1527272598615};\\\", \\\"{x:1559,y:440,t:1527272598629};\\\", \\\"{x:1559,y:439,t:1527272598645};\\\", \\\"{x:1559,y:438,t:1527272598663};\\\", \\\"{x:1559,y:437,t:1527272598679};\\\", \\\"{x:1559,y:435,t:1527272598695};\\\", \\\"{x:1559,y:434,t:1527272598712};\\\", \\\"{x:1560,y:433,t:1527272598729};\\\", \\\"{x:1560,y:432,t:1527272598768};\\\", \\\"{x:1560,y:431,t:1527272598783};\\\", \\\"{x:1560,y:430,t:1527272598796};\\\", \\\"{x:1560,y:429,t:1527272598815};\\\", \\\"{x:1559,y:426,t:1527272598830};\\\", \\\"{x:1559,y:423,t:1527272598846};\\\", \\\"{x:1559,y:419,t:1527272598863};\\\", \\\"{x:1558,y:416,t:1527272598879};\\\", \\\"{x:1557,y:412,t:1527272598897};\\\", \\\"{x:1556,y:408,t:1527272598913};\\\", \\\"{x:1555,y:402,t:1527272598930};\\\", \\\"{x:1554,y:396,t:1527272598947};\\\", \\\"{x:1551,y:388,t:1527272598963};\\\", \\\"{x:1550,y:381,t:1527272598980};\\\", \\\"{x:1548,y:373,t:1527272598996};\\\", \\\"{x:1547,y:366,t:1527272599015};\\\", \\\"{x:1546,y:361,t:1527272599030};\\\", \\\"{x:1546,y:356,t:1527272599046};\\\", \\\"{x:1546,y:349,t:1527272599063};\\\", \\\"{x:1543,y:335,t:1527272599079};\\\", \\\"{x:1543,y:327,t:1527272599096};\\\", \\\"{x:1543,y:320,t:1527272599114};\\\", \\\"{x:1543,y:315,t:1527272599130};\\\", \\\"{x:1542,y:312,t:1527272599147};\\\", \\\"{x:1541,y:309,t:1527272599164};\\\", \\\"{x:1541,y:307,t:1527272599180};\\\", \\\"{x:1541,y:306,t:1527272599196};\\\", \\\"{x:1541,y:305,t:1527272599215};\\\", \\\"{x:1541,y:312,t:1527272599392};\\\", \\\"{x:1538,y:326,t:1527272599400};\\\", \\\"{x:1537,y:337,t:1527272599414};\\\", \\\"{x:1534,y:359,t:1527272599430};\\\", \\\"{x:1530,y:375,t:1527272599447};\\\", \\\"{x:1528,y:390,t:1527272599464};\\\", \\\"{x:1528,y:424,t:1527272599480};\\\", \\\"{x:1528,y:462,t:1527272599497};\\\", \\\"{x:1528,y:495,t:1527272599514};\\\", \\\"{x:1528,y:529,t:1527272599530};\\\", \\\"{x:1528,y:549,t:1527272599547};\\\", \\\"{x:1527,y:563,t:1527272599564};\\\", \\\"{x:1526,y:573,t:1527272599581};\\\", \\\"{x:1526,y:584,t:1527272599597};\\\", \\\"{x:1528,y:602,t:1527272599614};\\\", \\\"{x:1531,y:622,t:1527272599630};\\\", \\\"{x:1535,y:643,t:1527272599647};\\\", \\\"{x:1537,y:661,t:1527272599663};\\\", \\\"{x:1539,y:678,t:1527272599680};\\\", \\\"{x:1539,y:685,t:1527272599698};\\\", \\\"{x:1540,y:689,t:1527272599714};\\\", \\\"{x:1541,y:697,t:1527272599730};\\\", \\\"{x:1543,y:707,t:1527272599747};\\\", \\\"{x:1544,y:719,t:1527272599763};\\\", \\\"{x:1545,y:728,t:1527272599780};\\\", \\\"{x:1545,y:733,t:1527272599797};\\\", \\\"{x:1544,y:741,t:1527272599814};\\\", \\\"{x:1543,y:753,t:1527272599830};\\\", \\\"{x:1541,y:765,t:1527272599847};\\\", \\\"{x:1539,y:774,t:1527272599863};\\\", \\\"{x:1536,y:786,t:1527272599880};\\\", \\\"{x:1534,y:791,t:1527272599897};\\\", \\\"{x:1532,y:795,t:1527272599914};\\\", \\\"{x:1531,y:799,t:1527272599930};\\\", \\\"{x:1529,y:801,t:1527272600000};\\\", \\\"{x:1529,y:802,t:1527272600040};\\\", \\\"{x:1527,y:806,t:1527272601665};\\\", \\\"{x:1521,y:823,t:1527272601682};\\\", \\\"{x:1515,y:832,t:1527272601698};\\\", \\\"{x:1511,y:840,t:1527272601716};\\\", \\\"{x:1508,y:844,t:1527272601732};\\\", \\\"{x:1506,y:846,t:1527272601749};\\\", \\\"{x:1502,y:853,t:1527272601766};\\\", \\\"{x:1497,y:866,t:1527272601783};\\\", \\\"{x:1490,y:876,t:1527272601799};\\\", \\\"{x:1484,y:887,t:1527272601816};\\\", \\\"{x:1480,y:894,t:1527272601832};\\\", \\\"{x:1480,y:896,t:1527272601849};\\\", \\\"{x:1479,y:899,t:1527272601866};\\\", \\\"{x:1478,y:899,t:1527272601888};\\\", \\\"{x:1477,y:900,t:1527272601976};\\\", \\\"{x:1474,y:902,t:1527272601983};\\\", \\\"{x:1471,y:903,t:1527272601998};\\\", \\\"{x:1466,y:905,t:1527272602016};\\\", \\\"{x:1454,y:910,t:1527272602032};\\\", \\\"{x:1446,y:912,t:1527272602049};\\\", \\\"{x:1436,y:912,t:1527272602066};\\\", \\\"{x:1430,y:914,t:1527272602082};\\\", \\\"{x:1429,y:914,t:1527272602145};\\\", \\\"{x:1425,y:914,t:1527272602152};\\\", \\\"{x:1418,y:915,t:1527272602166};\\\", \\\"{x:1397,y:915,t:1527272602183};\\\", \\\"{x:1385,y:915,t:1527272602200};\\\", \\\"{x:1384,y:915,t:1527272602216};\\\", \\\"{x:1382,y:915,t:1527272602232};\\\", \\\"{x:1381,y:915,t:1527272602250};\\\", \\\"{x:1379,y:915,t:1527272602266};\\\", \\\"{x:1374,y:915,t:1527272602282};\\\", \\\"{x:1368,y:913,t:1527272602300};\\\", \\\"{x:1366,y:911,t:1527272602315};\\\", \\\"{x:1365,y:910,t:1527272602333};\\\", \\\"{x:1364,y:909,t:1527272602368};\\\", \\\"{x:1364,y:907,t:1527272602382};\\\", \\\"{x:1363,y:905,t:1527272602399};\\\", \\\"{x:1365,y:898,t:1527272602415};\\\", \\\"{x:1380,y:889,t:1527272602432};\\\", \\\"{x:1402,y:879,t:1527272602450};\\\", \\\"{x:1424,y:869,t:1527272602465};\\\", \\\"{x:1440,y:864,t:1527272602483};\\\", \\\"{x:1443,y:862,t:1527272602500};\\\", \\\"{x:1445,y:861,t:1527272602592};\\\", \\\"{x:1446,y:859,t:1527272602608};\\\", \\\"{x:1448,y:857,t:1527272602616};\\\", \\\"{x:1457,y:850,t:1527272602632};\\\", \\\"{x:1462,y:847,t:1527272602649};\\\", \\\"{x:1466,y:845,t:1527272602666};\\\", \\\"{x:1467,y:844,t:1527272602688};\\\", \\\"{x:1469,y:844,t:1527272602703};\\\", \\\"{x:1471,y:843,t:1527272602716};\\\", \\\"{x:1475,y:842,t:1527272602732};\\\", \\\"{x:1476,y:842,t:1527272602749};\\\", \\\"{x:1477,y:842,t:1527272602766};\\\", \\\"{x:1477,y:841,t:1527272602888};\\\", \\\"{x:1478,y:839,t:1527272602904};\\\", \\\"{x:1479,y:838,t:1527272602917};\\\", \\\"{x:1481,y:836,t:1527272602933};\\\", \\\"{x:1481,y:835,t:1527272602970};\\\", \\\"{x:1481,y:834,t:1527272603168};\\\", \\\"{x:1481,y:832,t:1527272604144};\\\", \\\"{x:1481,y:830,t:1527272604152};\\\", \\\"{x:1481,y:828,t:1527272604168};\\\", \\\"{x:1481,y:827,t:1527272604184};\\\", \\\"{x:1481,y:825,t:1527272604224};\\\", \\\"{x:1480,y:825,t:1527272604936};\\\", \\\"{x:1479,y:825,t:1527272604952};\\\", \\\"{x:1477,y:825,t:1527272604969};\\\", \\\"{x:1476,y:825,t:1527272605016};\\\", \\\"{x:1471,y:825,t:1527272607648};\\\", \\\"{x:1470,y:825,t:1527272607656};\\\", \\\"{x:1468,y:824,t:1527272607670};\\\", \\\"{x:1467,y:823,t:1527272607687};\\\", \\\"{x:1458,y:816,t:1527272607703};\\\", \\\"{x:1435,y:803,t:1527272607720};\\\", \\\"{x:1412,y:794,t:1527272607737};\\\", \\\"{x:1385,y:787,t:1527272607752};\\\", \\\"{x:1363,y:782,t:1527272607769};\\\", \\\"{x:1337,y:776,t:1527272607787};\\\", \\\"{x:1318,y:771,t:1527272607803};\\\", \\\"{x:1312,y:769,t:1527272607820};\\\", \\\"{x:1312,y:768,t:1527272607945};\\\", \\\"{x:1313,y:768,t:1527272607954};\\\", \\\"{x:1319,y:767,t:1527272607970};\\\", \\\"{x:1326,y:767,t:1527272607987};\\\", \\\"{x:1340,y:767,t:1527272608004};\\\", \\\"{x:1361,y:767,t:1527272608020};\\\", \\\"{x:1377,y:768,t:1527272608037};\\\", \\\"{x:1389,y:769,t:1527272608054};\\\", \\\"{x:1396,y:769,t:1527272608069};\\\", \\\"{x:1399,y:769,t:1527272608087};\\\", \\\"{x:1401,y:769,t:1527272608104};\\\", \\\"{x:1401,y:768,t:1527272608184};\\\", \\\"{x:1401,y:765,t:1527272608192};\\\", \\\"{x:1401,y:761,t:1527272608203};\\\", \\\"{x:1392,y:755,t:1527272608220};\\\", \\\"{x:1389,y:754,t:1527272608237};\\\", \\\"{x:1388,y:754,t:1527272608320};\\\", \\\"{x:1385,y:754,t:1527272608337};\\\", \\\"{x:1382,y:754,t:1527272608354};\\\", \\\"{x:1380,y:754,t:1527272608371};\\\", \\\"{x:1386,y:754,t:1527272609385};\\\", \\\"{x:1401,y:754,t:1527272609392};\\\", \\\"{x:1429,y:759,t:1527272609404};\\\", \\\"{x:1487,y:765,t:1527272609420};\\\", \\\"{x:1557,y:767,t:1527272609437};\\\", \\\"{x:1632,y:767,t:1527272609454};\\\", \\\"{x:1677,y:767,t:1527272609470};\\\", \\\"{x:1693,y:767,t:1527272609486};\\\", \\\"{x:1693,y:766,t:1527272609504};\\\", \\\"{x:1693,y:765,t:1527272609520};\\\", \\\"{x:1693,y:764,t:1527272609538};\\\", \\\"{x:1693,y:763,t:1527272609584};\\\", \\\"{x:1690,y:763,t:1527272609592};\\\", \\\"{x:1683,y:763,t:1527272609604};\\\", \\\"{x:1655,y:760,t:1527272609621};\\\", \\\"{x:1620,y:758,t:1527272609638};\\\", \\\"{x:1597,y:758,t:1527272609655};\\\", \\\"{x:1577,y:760,t:1527272609671};\\\", \\\"{x:1537,y:766,t:1527272609688};\\\", \\\"{x:1512,y:769,t:1527272609705};\\\", \\\"{x:1502,y:771,t:1527272609722};\\\", \\\"{x:1498,y:773,t:1527272609738};\\\", \\\"{x:1498,y:777,t:1527272609792};\\\", \\\"{x:1498,y:784,t:1527272609805};\\\", \\\"{x:1499,y:814,t:1527272609822};\\\", \\\"{x:1514,y:867,t:1527272609838};\\\", \\\"{x:1528,y:919,t:1527272609855};\\\", \\\"{x:1540,y:953,t:1527272609871};\\\", \\\"{x:1541,y:954,t:1527272609956};\\\", \\\"{x:1541,y:953,t:1527272610012};\\\", \\\"{x:1541,y:952,t:1527272610027};\\\", \\\"{x:1541,y:954,t:1527272610100};\\\", \\\"{x:1541,y:963,t:1527272610108};\\\", \\\"{x:1543,y:984,t:1527272610126};\\\", \\\"{x:1546,y:994,t:1527272610142};\\\", \\\"{x:1548,y:996,t:1527272610158};\\\", \\\"{x:1548,y:993,t:1527272610284};\\\", \\\"{x:1547,y:986,t:1527272610292};\\\", \\\"{x:1546,y:979,t:1527272610309};\\\", \\\"{x:1544,y:972,t:1527272610326};\\\", \\\"{x:1543,y:969,t:1527272610343};\\\", \\\"{x:1542,y:967,t:1527272610359};\\\", \\\"{x:1542,y:965,t:1527272610375};\\\", \\\"{x:1541,y:964,t:1527272610392};\\\", \\\"{x:1539,y:962,t:1527272610409};\\\", \\\"{x:1537,y:962,t:1527272610426};\\\", \\\"{x:1537,y:961,t:1527272610540};\\\", \\\"{x:1537,y:960,t:1527272612420};\\\", \\\"{x:1538,y:960,t:1527272612428};\\\", \\\"{x:1540,y:960,t:1527272612444};\\\", \\\"{x:1526,y:958,t:1527272617500};\\\", \\\"{x:1487,y:945,t:1527272617513};\\\", \\\"{x:1365,y:905,t:1527272617530};\\\", \\\"{x:1113,y:829,t:1527272617547};\\\", \\\"{x:958,y:802,t:1527272617563};\\\", \\\"{x:842,y:790,t:1527272617580};\\\", \\\"{x:763,y:785,t:1527272617597};\\\", \\\"{x:712,y:783,t:1527272617613};\\\", \\\"{x:675,y:783,t:1527272617630};\\\", \\\"{x:656,y:783,t:1527272617647};\\\", \\\"{x:654,y:783,t:1527272617664};\\\", \\\"{x:651,y:783,t:1527272617731};\\\", \\\"{x:638,y:787,t:1527272617747};\\\", \\\"{x:612,y:791,t:1527272617764};\\\", \\\"{x:582,y:793,t:1527272617780};\\\", \\\"{x:550,y:788,t:1527272617797};\\\", \\\"{x:504,y:768,t:1527272617815};\\\", \\\"{x:453,y:752,t:1527272617831};\\\", \\\"{x:432,y:747,t:1527272617848};\\\", \\\"{x:431,y:746,t:1527272617864};\\\", \\\"{x:433,y:745,t:1527272617930};\\\", \\\"{x:437,y:741,t:1527272617947};\\\", \\\"{x:439,y:737,t:1527272617964};\\\", \\\"{x:439,y:735,t:1527272617980};\\\", \\\"{x:439,y:733,t:1527272617997};\\\", \\\"{x:441,y:724,t:1527272618014};\\\", \\\"{x:448,y:707,t:1527272618030};\\\", \\\"{x:453,y:697,t:1527272618047};\\\", \\\"{x:455,y:697,t:1527272618179};\\\", \\\"{x:463,y:703,t:1527272618187};\\\", \\\"{x:468,y:708,t:1527272618197};\\\", \\\"{x:483,y:717,t:1527272618214};\\\", \\\"{x:490,y:725,t:1527272618231};\\\", \\\"{x:493,y:730,t:1527272618247};\\\", \\\"{x:498,y:742,t:1527272618265};\\\", \\\"{x:500,y:750,t:1527272618282};\\\", \\\"{x:500,y:752,t:1527272618299};\\\" ] }, { \\\"rt\\\": 26698, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1237217, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -02 PM-E -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:752,t:1527272622067};\\\", \\\"{x:561,y:749,t:1527272622085};\\\", \\\"{x:724,y:770,t:1527272622104};\\\", \\\"{x:923,y:796,t:1527272622118};\\\", \\\"{x:1140,y:816,t:1527272622136};\\\", \\\"{x:1354,y:826,t:1527272622152};\\\", \\\"{x:1539,y:826,t:1527272622168};\\\", \\\"{x:1699,y:826,t:1527272622185};\\\", \\\"{x:1849,y:826,t:1527272622203};\\\", \\\"{x:1888,y:826,t:1527272622218};\\\", \\\"{x:1913,y:826,t:1527272622235};\\\", \\\"{x:1919,y:826,t:1527272622252};\\\", \\\"{x:1918,y:826,t:1527272622531};\\\", \\\"{x:1917,y:826,t:1527272622539};\\\", \\\"{x:1916,y:826,t:1527272622553};\\\", \\\"{x:1913,y:826,t:1527272622569};\\\", \\\"{x:1906,y:826,t:1527272622987};\\\", \\\"{x:1897,y:826,t:1527272623003};\\\", \\\"{x:1871,y:826,t:1527272623020};\\\", \\\"{x:1848,y:826,t:1527272623036};\\\", \\\"{x:1809,y:826,t:1527272623052};\\\", \\\"{x:1747,y:825,t:1527272623072};\\\", \\\"{x:1708,y:827,t:1527272623088};\\\", \\\"{x:1682,y:838,t:1527272623103};\\\", \\\"{x:1661,y:847,t:1527272623119};\\\", \\\"{x:1642,y:857,t:1527272623137};\\\", \\\"{x:1617,y:866,t:1527272623153};\\\", \\\"{x:1592,y:875,t:1527272623170};\\\", \\\"{x:1557,y:893,t:1527272623187};\\\", \\\"{x:1546,y:901,t:1527272623203};\\\", \\\"{x:1524,y:918,t:1527272623219};\\\", \\\"{x:1517,y:923,t:1527272623237};\\\", \\\"{x:1508,y:925,t:1527272623253};\\\", \\\"{x:1489,y:927,t:1527272623270};\\\", \\\"{x:1471,y:929,t:1527272623287};\\\", \\\"{x:1459,y:937,t:1527272623303};\\\", \\\"{x:1452,y:944,t:1527272623320};\\\", \\\"{x:1449,y:949,t:1527272623337};\\\", \\\"{x:1448,y:950,t:1527272623353};\\\", \\\"{x:1448,y:952,t:1527272623370};\\\", \\\"{x:1447,y:953,t:1527272623387};\\\", \\\"{x:1447,y:960,t:1527272623404};\\\", \\\"{x:1448,y:967,t:1527272623420};\\\", \\\"{x:1449,y:972,t:1527272623437};\\\", \\\"{x:1449,y:973,t:1527272623454};\\\", \\\"{x:1449,y:974,t:1527272623556};\\\", \\\"{x:1451,y:974,t:1527272623579};\\\", \\\"{x:1454,y:974,t:1527272623587};\\\", \\\"{x:1461,y:971,t:1527272623604};\\\", \\\"{x:1468,y:965,t:1527272623620};\\\", \\\"{x:1475,y:961,t:1527272623637};\\\", \\\"{x:1479,y:958,t:1527272623655};\\\", \\\"{x:1485,y:957,t:1527272623670};\\\", \\\"{x:1486,y:957,t:1527272623687};\\\", \\\"{x:1488,y:957,t:1527272623724};\\\", \\\"{x:1489,y:957,t:1527272623739};\\\", \\\"{x:1490,y:954,t:1527272623947};\\\", \\\"{x:1490,y:937,t:1527272623955};\\\", \\\"{x:1488,y:912,t:1527272623971};\\\", \\\"{x:1488,y:896,t:1527272623988};\\\", \\\"{x:1488,y:881,t:1527272624003};\\\", \\\"{x:1488,y:859,t:1527272624020};\\\", \\\"{x:1488,y:840,t:1527272624036};\\\", \\\"{x:1486,y:825,t:1527272624053};\\\", \\\"{x:1486,y:818,t:1527272624070};\\\", \\\"{x:1486,y:815,t:1527272624087};\\\", \\\"{x:1485,y:814,t:1527272630612};\\\", \\\"{x:1485,y:820,t:1527272630627};\\\", \\\"{x:1485,y:844,t:1527272630643};\\\", \\\"{x:1488,y:896,t:1527272630659};\\\", \\\"{x:1488,y:915,t:1527272630675};\\\", \\\"{x:1485,y:933,t:1527272630692};\\\", \\\"{x:1480,y:950,t:1527272630709};\\\", \\\"{x:1477,y:960,t:1527272630725};\\\", \\\"{x:1477,y:970,t:1527272630743};\\\", \\\"{x:1477,y:979,t:1527272630759};\\\", \\\"{x:1477,y:981,t:1527272630775};\\\", \\\"{x:1477,y:982,t:1527272630792};\\\", \\\"{x:1477,y:980,t:1527272632204};\\\", \\\"{x:1477,y:978,t:1527272632211};\\\", \\\"{x:1477,y:977,t:1527272632226};\\\", \\\"{x:1478,y:973,t:1527272632243};\\\", \\\"{x:1480,y:970,t:1527272632260};\\\", \\\"{x:1481,y:969,t:1527272632283};\\\", \\\"{x:1481,y:968,t:1527272632294};\\\", \\\"{x:1481,y:967,t:1527272632311};\\\", \\\"{x:1480,y:967,t:1527272635708};\\\", \\\"{x:1459,y:960,t:1527272635715};\\\", \\\"{x:1425,y:949,t:1527272635730};\\\", \\\"{x:1337,y:912,t:1527272635747};\\\", \\\"{x:1237,y:880,t:1527272635763};\\\", \\\"{x:1081,y:829,t:1527272635780};\\\", \\\"{x:984,y:799,t:1527272635796};\\\", \\\"{x:914,y:780,t:1527272635812};\\\", \\\"{x:869,y:766,t:1527272635829};\\\", \\\"{x:838,y:750,t:1527272635846};\\\", \\\"{x:814,y:738,t:1527272635862};\\\", \\\"{x:803,y:729,t:1527272635880};\\\", \\\"{x:798,y:724,t:1527272635896};\\\", \\\"{x:798,y:720,t:1527272635912};\\\", \\\"{x:798,y:718,t:1527272635929};\\\", \\\"{x:798,y:711,t:1527272635947};\\\", \\\"{x:789,y:691,t:1527272635963};\\\", \\\"{x:759,y:655,t:1527272635980};\\\", \\\"{x:744,y:634,t:1527272635997};\\\", \\\"{x:722,y:613,t:1527272636012};\\\", \\\"{x:689,y:592,t:1527272636029};\\\", \\\"{x:640,y:573,t:1527272636047};\\\", \\\"{x:590,y:559,t:1527272636064};\\\", \\\"{x:553,y:554,t:1527272636080};\\\", \\\"{x:544,y:553,t:1527272636097};\\\", \\\"{x:542,y:553,t:1527272636146};\\\", \\\"{x:536,y:553,t:1527272636164};\\\", \\\"{x:533,y:554,t:1527272636179};\\\", \\\"{x:530,y:555,t:1527272636196};\\\", \\\"{x:529,y:556,t:1527272636214};\\\", \\\"{x:527,y:557,t:1527272636230};\\\", \\\"{x:520,y:557,t:1527272636247};\\\", \\\"{x:511,y:557,t:1527272636264};\\\", \\\"{x:504,y:555,t:1527272636280};\\\", \\\"{x:500,y:554,t:1527272636297};\\\", \\\"{x:494,y:550,t:1527272636316};\\\", \\\"{x:468,y:541,t:1527272636330};\\\", \\\"{x:427,y:528,t:1527272636347};\\\", \\\"{x:401,y:520,t:1527272636364};\\\", \\\"{x:383,y:514,t:1527272636380};\\\", \\\"{x:371,y:509,t:1527272636397};\\\", \\\"{x:368,y:508,t:1527272636413};\\\", \\\"{x:367,y:508,t:1527272636433};\\\", \\\"{x:366,y:508,t:1527272636449};\\\", \\\"{x:364,y:508,t:1527272636464};\\\", \\\"{x:360,y:508,t:1527272636480};\\\", \\\"{x:369,y:512,t:1527272636547};\\\", \\\"{x:400,y:518,t:1527272636564};\\\", \\\"{x:430,y:523,t:1527272636579};\\\", \\\"{x:452,y:525,t:1527272636597};\\\", \\\"{x:473,y:526,t:1527272636614};\\\", \\\"{x:487,y:526,t:1527272636630};\\\", \\\"{x:497,y:529,t:1527272636647};\\\", \\\"{x:505,y:530,t:1527272636666};\\\", \\\"{x:507,y:530,t:1527272636680};\\\", \\\"{x:508,y:530,t:1527272636697};\\\", \\\"{x:509,y:530,t:1527272636713};\\\", \\\"{x:513,y:530,t:1527272636730};\\\", \\\"{x:531,y:530,t:1527272636747};\\\", \\\"{x:547,y:530,t:1527272636764};\\\", \\\"{x:565,y:530,t:1527272636780};\\\", \\\"{x:580,y:530,t:1527272636797};\\\", \\\"{x:590,y:530,t:1527272636814};\\\", \\\"{x:608,y:530,t:1527272636830};\\\", \\\"{x:635,y:530,t:1527272636847};\\\", \\\"{x:662,y:526,t:1527272636864};\\\", \\\"{x:670,y:522,t:1527272636880};\\\", \\\"{x:672,y:521,t:1527272636897};\\\", \\\"{x:672,y:520,t:1527272636914};\\\", \\\"{x:672,y:519,t:1527272636979};\\\", \\\"{x:660,y:515,t:1527272636997};\\\", \\\"{x:650,y:515,t:1527272637014};\\\", \\\"{x:641,y:515,t:1527272637031};\\\", \\\"{x:628,y:520,t:1527272637047};\\\", \\\"{x:616,y:526,t:1527272637063};\\\", \\\"{x:608,y:527,t:1527272637081};\\\", \\\"{x:606,y:529,t:1527272637098};\\\", \\\"{x:604,y:529,t:1527272637113};\\\", \\\"{x:602,y:529,t:1527272637291};\\\", \\\"{x:628,y:527,t:1527272637307};\\\", \\\"{x:659,y:527,t:1527272637314};\\\", \\\"{x:691,y:527,t:1527272637331};\\\", \\\"{x:713,y:524,t:1527272637347};\\\", \\\"{x:731,y:522,t:1527272637366};\\\", \\\"{x:753,y:521,t:1527272637381};\\\", \\\"{x:776,y:521,t:1527272637397};\\\", \\\"{x:794,y:521,t:1527272637414};\\\", \\\"{x:806,y:521,t:1527272637431};\\\", \\\"{x:807,y:521,t:1527272637448};\\\", \\\"{x:812,y:521,t:1527272637464};\\\", \\\"{x:821,y:521,t:1527272637481};\\\", \\\"{x:830,y:521,t:1527272637499};\\\", \\\"{x:836,y:520,t:1527272637514};\\\", \\\"{x:834,y:520,t:1527272637834};\\\", \\\"{x:813,y:518,t:1527272637848};\\\", \\\"{x:752,y:512,t:1527272637865};\\\", \\\"{x:709,y:510,t:1527272637882};\\\", \\\"{x:641,y:508,t:1527272637898};\\\", \\\"{x:596,y:508,t:1527272637914};\\\", \\\"{x:574,y:508,t:1527272637931};\\\", \\\"{x:571,y:508,t:1527272637948};\\\", \\\"{x:571,y:507,t:1527272637986};\\\", \\\"{x:572,y:506,t:1527272638092};\\\", \\\"{x:578,y:506,t:1527272638098};\\\", \\\"{x:588,y:506,t:1527272638114};\\\", \\\"{x:596,y:506,t:1527272638132};\\\", \\\"{x:602,y:507,t:1527272638149};\\\", \\\"{x:606,y:508,t:1527272638163};\\\", \\\"{x:609,y:512,t:1527272638451};\\\", \\\"{x:609,y:514,t:1527272638464};\\\", \\\"{x:610,y:517,t:1527272638482};\\\", \\\"{x:610,y:520,t:1527272638547};\\\", \\\"{x:610,y:526,t:1527272638554};\\\", \\\"{x:613,y:534,t:1527272638567};\\\", \\\"{x:613,y:550,t:1527272638582};\\\", \\\"{x:613,y:556,t:1527272638597};\\\", \\\"{x:613,y:559,t:1527272638642};\\\", \\\"{x:614,y:566,t:1527272638650};\\\", \\\"{x:625,y:581,t:1527272638665};\\\", \\\"{x:704,y:693,t:1527272638682};\\\", \\\"{x:792,y:805,t:1527272638699};\\\", \\\"{x:877,y:907,t:1527272638715};\\\", \\\"{x:969,y:976,t:1527272638732};\\\", \\\"{x:1056,y:1022,t:1527272638749};\\\", \\\"{x:1133,y:1054,t:1527272638764};\\\", \\\"{x:1212,y:1070,t:1527272638782};\\\", \\\"{x:1263,y:1080,t:1527272638799};\\\", \\\"{x:1289,y:1083,t:1527272638815};\\\", \\\"{x:1306,y:1083,t:1527272638832};\\\", \\\"{x:1317,y:1082,t:1527272638849};\\\", \\\"{x:1322,y:1077,t:1527272638865};\\\", \\\"{x:1323,y:1066,t:1527272638882};\\\", \\\"{x:1316,y:1048,t:1527272638898};\\\", \\\"{x:1293,y:1027,t:1527272638915};\\\", \\\"{x:1276,y:1020,t:1527272638932};\\\", \\\"{x:1275,y:1018,t:1527272638949};\\\", \\\"{x:1273,y:1017,t:1527272638965};\\\", \\\"{x:1268,y:1012,t:1527272638982};\\\", \\\"{x:1257,y:1003,t:1527272638999};\\\", \\\"{x:1248,y:990,t:1527272639015};\\\", \\\"{x:1246,y:978,t:1527272639032};\\\", \\\"{x:1246,y:966,t:1527272639049};\\\", \\\"{x:1246,y:943,t:1527272639066};\\\", \\\"{x:1246,y:922,t:1527272639082};\\\", \\\"{x:1243,y:892,t:1527272639099};\\\", \\\"{x:1242,y:860,t:1527272639115};\\\", \\\"{x:1242,y:830,t:1527272639133};\\\", \\\"{x:1242,y:808,t:1527272639149};\\\", \\\"{x:1242,y:800,t:1527272639166};\\\", \\\"{x:1242,y:796,t:1527272639183};\\\", \\\"{x:1242,y:795,t:1527272639199};\\\", \\\"{x:1242,y:789,t:1527272639216};\\\", \\\"{x:1239,y:780,t:1527272639232};\\\", \\\"{x:1239,y:775,t:1527272639249};\\\", \\\"{x:1241,y:759,t:1527272639266};\\\", \\\"{x:1248,y:747,t:1527272639281};\\\", \\\"{x:1251,y:739,t:1527272639298};\\\", \\\"{x:1254,y:731,t:1527272639316};\\\", \\\"{x:1255,y:721,t:1527272639331};\\\", \\\"{x:1257,y:712,t:1527272639348};\\\", \\\"{x:1258,y:702,t:1527272639366};\\\", \\\"{x:1259,y:690,t:1527272639382};\\\", \\\"{x:1259,y:680,t:1527272639399};\\\", \\\"{x:1259,y:673,t:1527272639416};\\\", \\\"{x:1259,y:667,t:1527272639432};\\\", \\\"{x:1259,y:665,t:1527272639449};\\\", \\\"{x:1259,y:664,t:1527272639466};\\\", \\\"{x:1258,y:662,t:1527272639482};\\\", \\\"{x:1258,y:658,t:1527272639586};\\\", \\\"{x:1258,y:651,t:1527272639599};\\\", \\\"{x:1265,y:635,t:1527272639616};\\\", \\\"{x:1268,y:621,t:1527272639633};\\\", \\\"{x:1269,y:611,t:1527272639649};\\\", \\\"{x:1269,y:600,t:1527272639666};\\\", \\\"{x:1269,y:594,t:1527272639682};\\\", \\\"{x:1269,y:589,t:1527272639699};\\\", \\\"{x:1269,y:585,t:1527272639716};\\\", \\\"{x:1269,y:581,t:1527272639733};\\\", \\\"{x:1269,y:578,t:1527272639749};\\\", \\\"{x:1269,y:576,t:1527272639766};\\\", \\\"{x:1269,y:575,t:1527272639811};\\\", \\\"{x:1270,y:569,t:1527272639826};\\\", \\\"{x:1270,y:566,t:1527272639834};\\\", \\\"{x:1272,y:563,t:1527272639849};\\\", \\\"{x:1272,y:562,t:1527272639866};\\\", \\\"{x:1272,y:560,t:1527272639883};\\\", \\\"{x:1273,y:560,t:1527272639980};\\\", \\\"{x:1275,y:561,t:1527272639987};\\\", \\\"{x:1276,y:561,t:1527272640001};\\\", \\\"{x:1278,y:562,t:1527272640017};\\\", \\\"{x:1279,y:562,t:1527272640035};\\\", \\\"{x:1280,y:563,t:1527272640516};\\\", \\\"{x:1281,y:564,t:1527272640523};\\\", \\\"{x:1282,y:565,t:1527272640534};\\\", \\\"{x:1284,y:571,t:1527272640551};\\\", \\\"{x:1287,y:575,t:1527272640567};\\\", \\\"{x:1292,y:583,t:1527272640584};\\\", \\\"{x:1301,y:598,t:1527272640600};\\\", \\\"{x:1311,y:621,t:1527272640617};\\\", \\\"{x:1325,y:653,t:1527272640634};\\\", \\\"{x:1353,y:706,t:1527272640651};\\\", \\\"{x:1370,y:729,t:1527272640667};\\\", \\\"{x:1386,y:747,t:1527272640683};\\\", \\\"{x:1392,y:753,t:1527272640700};\\\", \\\"{x:1396,y:759,t:1527272640717};\\\", \\\"{x:1397,y:762,t:1527272640734};\\\", \\\"{x:1399,y:766,t:1527272640751};\\\", \\\"{x:1400,y:770,t:1527272640767};\\\", \\\"{x:1402,y:774,t:1527272640784};\\\", \\\"{x:1404,y:781,t:1527272640801};\\\", \\\"{x:1406,y:786,t:1527272640818};\\\", \\\"{x:1407,y:787,t:1527272640835};\\\", \\\"{x:1407,y:788,t:1527272640899};\\\", \\\"{x:1407,y:793,t:1527272640918};\\\", \\\"{x:1411,y:798,t:1527272640935};\\\", \\\"{x:1414,y:803,t:1527272640950};\\\", \\\"{x:1414,y:805,t:1527272640967};\\\", \\\"{x:1414,y:806,t:1527272640994};\\\", \\\"{x:1414,y:807,t:1527272641002};\\\", \\\"{x:1414,y:810,t:1527272641017};\\\", \\\"{x:1420,y:832,t:1527272641034};\\\", \\\"{x:1425,y:854,t:1527272641050};\\\", \\\"{x:1431,y:875,t:1527272641067};\\\", \\\"{x:1436,y:887,t:1527272641084};\\\", \\\"{x:1437,y:891,t:1527272641100};\\\", \\\"{x:1438,y:892,t:1527272641117};\\\", \\\"{x:1439,y:892,t:1527272641134};\\\", \\\"{x:1440,y:893,t:1527272641150};\\\", \\\"{x:1443,y:899,t:1527272641167};\\\", \\\"{x:1444,y:904,t:1527272641185};\\\", \\\"{x:1449,y:913,t:1527272641200};\\\", \\\"{x:1453,y:919,t:1527272641217};\\\", \\\"{x:1455,y:922,t:1527272641235};\\\", \\\"{x:1455,y:923,t:1527272641266};\\\", \\\"{x:1457,y:927,t:1527272641284};\\\", \\\"{x:1460,y:933,t:1527272641302};\\\", \\\"{x:1464,y:938,t:1527272641318};\\\", \\\"{x:1467,y:943,t:1527272641334};\\\", \\\"{x:1468,y:944,t:1527272641351};\\\", \\\"{x:1469,y:945,t:1527272641387};\\\", \\\"{x:1473,y:946,t:1527272641401};\\\", \\\"{x:1477,y:949,t:1527272641418};\\\", \\\"{x:1485,y:954,t:1527272641435};\\\", \\\"{x:1487,y:956,t:1527272641450};\\\", \\\"{x:1487,y:958,t:1527272641467};\\\", \\\"{x:1490,y:962,t:1527272641484};\\\", \\\"{x:1490,y:963,t:1527272641501};\\\", \\\"{x:1491,y:966,t:1527272641517};\\\", \\\"{x:1491,y:967,t:1527272641535};\\\", \\\"{x:1492,y:968,t:1527272641551};\\\", \\\"{x:1492,y:970,t:1527272641715};\\\", \\\"{x:1487,y:966,t:1527272644596};\\\", \\\"{x:1476,y:954,t:1527272644603};\\\", \\\"{x:1447,y:923,t:1527272644621};\\\", \\\"{x:1403,y:887,t:1527272644637};\\\", \\\"{x:1380,y:861,t:1527272644653};\\\", \\\"{x:1370,y:848,t:1527272644671};\\\", \\\"{x:1363,y:837,t:1527272644686};\\\", \\\"{x:1358,y:828,t:1527272644703};\\\", \\\"{x:1353,y:819,t:1527272644721};\\\", \\\"{x:1347,y:810,t:1527272644738};\\\", \\\"{x:1341,y:794,t:1527272644754};\\\", \\\"{x:1334,y:777,t:1527272644771};\\\", \\\"{x:1330,y:768,t:1527272644787};\\\", \\\"{x:1327,y:759,t:1527272644804};\\\", \\\"{x:1323,y:750,t:1527272644820};\\\", \\\"{x:1321,y:742,t:1527272644838};\\\", \\\"{x:1320,y:734,t:1527272644854};\\\", \\\"{x:1316,y:721,t:1527272644871};\\\", \\\"{x:1311,y:705,t:1527272644888};\\\", \\\"{x:1302,y:685,t:1527272644903};\\\", \\\"{x:1290,y:662,t:1527272644920};\\\", \\\"{x:1283,y:647,t:1527272644938};\\\", \\\"{x:1279,y:636,t:1527272644953};\\\", \\\"{x:1277,y:620,t:1527272644970};\\\", \\\"{x:1275,y:612,t:1527272644987};\\\", \\\"{x:1275,y:600,t:1527272645003};\\\", \\\"{x:1272,y:586,t:1527272645021};\\\", \\\"{x:1270,y:569,t:1527272645038};\\\", \\\"{x:1268,y:556,t:1527272645054};\\\", \\\"{x:1265,y:545,t:1527272645071};\\\", \\\"{x:1262,y:534,t:1527272645088};\\\", \\\"{x:1259,y:529,t:1527272645104};\\\", \\\"{x:1258,y:525,t:1527272645121};\\\", \\\"{x:1258,y:527,t:1527272645235};\\\", \\\"{x:1260,y:535,t:1527272645242};\\\", \\\"{x:1266,y:547,t:1527272645255};\\\", \\\"{x:1271,y:566,t:1527272645270};\\\", \\\"{x:1277,y:581,t:1527272645287};\\\", \\\"{x:1282,y:593,t:1527272645304};\\\", \\\"{x:1287,y:605,t:1527272645320};\\\", \\\"{x:1291,y:615,t:1527272645337};\\\", \\\"{x:1298,y:631,t:1527272645354};\\\", \\\"{x:1304,y:646,t:1527272645370};\\\", \\\"{x:1313,y:662,t:1527272645387};\\\", \\\"{x:1322,y:681,t:1527272645404};\\\", \\\"{x:1328,y:696,t:1527272645421};\\\", \\\"{x:1331,y:702,t:1527272645438};\\\", \\\"{x:1337,y:711,t:1527272645454};\\\", \\\"{x:1343,y:719,t:1527272645470};\\\", \\\"{x:1348,y:727,t:1527272645487};\\\", \\\"{x:1357,y:742,t:1527272645505};\\\", \\\"{x:1365,y:758,t:1527272645522};\\\", \\\"{x:1377,y:777,t:1527272645538};\\\", \\\"{x:1394,y:810,t:1527272645554};\\\", \\\"{x:1405,y:825,t:1527272645571};\\\", \\\"{x:1414,y:838,t:1527272645588};\\\", \\\"{x:1419,y:846,t:1527272645605};\\\", \\\"{x:1423,y:852,t:1527272645621};\\\", \\\"{x:1425,y:858,t:1527272645637};\\\", \\\"{x:1425,y:873,t:1527272645655};\\\", \\\"{x:1425,y:896,t:1527272645671};\\\", \\\"{x:1423,y:922,t:1527272645688};\\\", \\\"{x:1413,y:941,t:1527272645704};\\\", \\\"{x:1395,y:953,t:1527272645722};\\\", \\\"{x:1365,y:966,t:1527272645738};\\\", \\\"{x:1313,y:983,t:1527272645755};\\\", \\\"{x:1262,y:992,t:1527272645771};\\\", \\\"{x:1190,y:1002,t:1527272645788};\\\", \\\"{x:1146,y:1007,t:1527272645805};\\\", \\\"{x:1125,y:1007,t:1527272645822};\\\", \\\"{x:1109,y:1007,t:1527272645838};\\\", \\\"{x:1093,y:1004,t:1527272645854};\\\", \\\"{x:1070,y:992,t:1527272645871};\\\", \\\"{x:995,y:954,t:1527272645887};\\\", \\\"{x:901,y:914,t:1527272645904};\\\", \\\"{x:834,y:891,t:1527272645921};\\\", \\\"{x:785,y:873,t:1527272645937};\\\", \\\"{x:702,y:831,t:1527272645954};\\\", \\\"{x:645,y:800,t:1527272645971};\\\", \\\"{x:602,y:775,t:1527272645989};\\\", \\\"{x:559,y:760,t:1527272646006};\\\", \\\"{x:536,y:754,t:1527272646021};\\\", \\\"{x:521,y:750,t:1527272646038};\\\", \\\"{x:504,y:748,t:1527272646054};\\\", \\\"{x:495,y:747,t:1527272646071};\\\", \\\"{x:493,y:747,t:1527272646088};\\\", \\\"{x:491,y:747,t:1527272646146};\\\", \\\"{x:489,y:747,t:1527272646155};\\\", \\\"{x:486,y:747,t:1527272646171};\\\" ] }, { \\\"rt\\\": 84864, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1323346, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"X-Axis represents time of day. The dots represent the start of the shift.\\\\nSo only the X-axis matters in finding 12pm start.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9487, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1333839, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10685, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1345544, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 24384, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1371249, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ESMO3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"ESMO3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 327, dom: 898, initialDom: 969",
  "javascriptErrors": []
}