var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05292753db3433f71c02deb5d6b5dd5746325624"] = {
  "startTime": "2018-05-29T19:15:26.7781158Z",
  "websitePageUrl": "/16",
  "visitTime": 95944,
  "engagementTime": 91644,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "6aedacc487b6f6a26c3fa475eb2857e8",
    "created": "2018-05-29T19:15:26.7781158+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=Y9NLY",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "86017b7cc5fa839131cc4d567b3517c4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6aedacc487b6f6a26c3fa475eb2857e8/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 1020,
      "y": 899
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 1028,
      "y": 888
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 35298,
      "y": 48361,
      "ta": "html > body"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 1059,
      "y": 859
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 1119,
      "y": 820
    },
    {
      "t": 506,
      "e": 506,
      "ty": 41,
      "x": 23466,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 669,
      "e": 669,
      "ty": 2,
      "x": 1121,
      "y": 821
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 23607,
      "y": 48918,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 1108,
      "y": 823
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 16842,
      "y": 49204,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 920,
      "y": 804
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 796,
      "y": 763
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 752,
      "y": 753
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 4127,
      "y": 43666,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 745,
      "y": 751
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 3667,
      "y": 43524,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 744,
      "y": 751
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 743,
      "y": 751
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 3610,
      "y": 43524,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 494,
      "y": 642
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 35623,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 2263,
      "e": 2263,
      "ty": 6,
      "x": 404,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 398,
      "y": 600
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 391,
      "y": 595
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 33037,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 384,
      "y": 579
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 378,
      "y": 561
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 31576,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6214,
      "e": 6214,
      "ty": 3,
      "x": 378,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6215,
      "e": 6215,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6357,
      "e": 6357,
      "ty": 4,
      "x": 31576,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6357,
      "e": 6357,
      "ty": 5,
      "x": 378,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15291,
      "e": 11357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15789,
      "e": 11855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15822,
      "e": 11888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15855,
      "e": 11921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15888,
      "e": 11954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15921,
      "e": 11987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15954,
      "e": 12020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15987,
      "e": 12053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16019,
      "e": 12085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16052,
      "e": 12118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16085,
      "e": 12151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16118,
      "e": 12184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16151,
      "e": 12217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16184,
      "e": 12250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16217,
      "e": 12283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16250,
      "e": 12316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16284,
      "e": 12350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16317,
      "e": 12383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16349,
      "e": 12415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16383,
      "e": 12449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16416,
      "e": 12482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16449,
      "e": 12515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16482,
      "e": 12548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16515,
      "e": 12581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16548,
      "e": 12614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16581,
      "e": 12647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16614,
      "e": 12680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16647,
      "e": 12713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16680,
      "e": 12746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16713,
      "e": 12779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16746,
      "e": 12812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16778,
      "e": 12844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16812,
      "e": 12878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16845,
      "e": 12911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16878,
      "e": 12944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16910,
      "e": 12976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16944,
      "e": 13010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16978,
      "e": 13044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17010,
      "e": 13076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17043,
      "e": 13109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17076,
      "e": 13142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17109,
      "e": 13175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17142,
      "e": 13208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17174,
      "e": 13240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17208,
      "e": 13274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17241,
      "e": 13307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17274,
      "e": 13340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17307,
      "e": 13373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17340,
      "e": 13406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17373,
      "e": 13439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17406,
      "e": 13472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17439,
      "e": 13505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17471,
      "e": 13537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17505,
      "e": 13571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17538,
      "e": 13604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17571,
      "e": 13637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17604,
      "e": 13670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17637,
      "e": 13703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17670,
      "e": 13736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17703,
      "e": 13769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17736,
      "e": 13802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17769,
      "e": 13835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17803,
      "e": 13869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17835,
      "e": 13901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17868,
      "e": 13934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17901,
      "e": 13967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17934,
      "e": 14000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17967,
      "e": 14033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18000,
      "e": 14066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18033,
      "e": 14099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18066,
      "e": 14132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18099,
      "e": 14165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18132,
      "e": 14198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18165,
      "e": 14231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18198,
      "e": 14264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18231,
      "e": 14297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18264,
      "e": 14330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18297,
      "e": 14363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18330,
      "e": 14396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18363,
      "e": 14429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18396,
      "e": 14462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18429,
      "e": 14495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18462,
      "e": 14528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18495,
      "e": 14561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18528,
      "e": 14594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18561,
      "e": 14627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18594,
      "e": 14660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18627,
      "e": 14693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18660,
      "e": 14726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18693,
      "e": 14759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18725,
      "e": 14791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18758,
      "e": 14824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18791,
      "e": 14857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18824,
      "e": 14890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18857,
      "e": 14923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18890,
      "e": 14956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18923,
      "e": 14989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18956,
      "e": 15022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18989,
      "e": 15055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19023,
      "e": 15089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19056,
      "e": 15122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19089,
      "e": 15155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19090,
      "e": 15156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19091,
      "e": 15157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19201,
      "e": 15267,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 19265,
      "e": 15331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 19481,
      "e": 15547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 22778,
      "e": 18844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22952,
      "e": 19018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 23209,
      "e": 19275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23360,
      "e": 19426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23360,
      "e": 19426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23465,
      "e": 19531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 23480,
      "e": 19546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 23593,
      "e": 19659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23594,
      "e": 19660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23704,
      "e": 19770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23704,
      "e": 19770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23712,
      "e": 19778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 23833,
      "e": 19899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23833,
      "e": 19899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23880,
      "e": 19946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 23960,
      "e": 20026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24577,
      "e": 20643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24579,
      "e": 20643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24712,
      "e": 20776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24713,
      "e": 20777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24760,
      "e": 20824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 24840,
      "e": 20904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24976,
      "e": 21040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24977,
      "e": 21041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25041,
      "e": 21105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25201,
      "e": 21265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25202,
      "e": 21266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25289,
      "e": 21353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25290,
      "e": 21354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25296,
      "e": 21360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 25402,
      "e": 21466,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point"
    },
    {
      "t": 25417,
      "e": 21481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25417,
      "e": 21481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25440,
      "e": 21504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25536,
      "e": 21600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25689,
      "e": 21753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 25690,
      "e": 21754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25784,
      "e": 21848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25784,
      "e": 21848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25816,
      "e": 21880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 25897,
      "e": 21961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25929,
      "e": 21993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25930,
      "e": 21994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26017,
      "e": 22081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26017,
      "e": 22081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26048,
      "e": 22112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 26169,
      "e": 22233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26170,
      "e": 22234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26232,
      "e": 22296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26272,
      "e": 22336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26272,
      "e": 22336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26312,
      "e": 22376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26425,
      "e": 22489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26426,
      "e": 22490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26426,
      "e": 22490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26488,
      "e": 22552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26488,
      "e": 22552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26576,
      "e": 22640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 26584,
      "e": 22648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26609,
      "e": 22673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26609,
      "e": 22673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26673,
      "e": 22737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26673,
      "e": 22737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26721,
      "e": 22785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26769,
      "e": 22833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26770,
      "e": 22834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26784,
      "e": 22848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26880,
      "e": 22944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26929,
      "e": 22993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26929,
      "e": 22993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27049,
      "e": 23113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27056,
      "e": 23120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27057,
      "e": 23121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27136,
      "e": 23200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27264,
      "e": 23328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27265,
      "e": 23329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27337,
      "e": 23401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27338,
      "e": 23402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27352,
      "e": 23416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 27480,
      "e": 23544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27481,
      "e": 23545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27537,
      "e": 23601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 27577,
      "e": 23641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27577,
      "e": 23641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27624,
      "e": 23688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27680,
      "e": 23744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27688,
      "e": 23752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27688,
      "e": 23752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27768,
      "e": 23832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27776,
      "e": 23840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27776,
      "e": 23840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27865,
      "e": 23929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27865,
      "e": 23929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27904,
      "e": 23968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 27968,
      "e": 24032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28937,
      "e": 25001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28938,
      "e": 25002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29008,
      "e": 25072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29144,
      "e": 25208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29145,
      "e": 25209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29225,
      "e": 25289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29249,
      "e": 25313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29249,
      "e": 25313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29377,
      "e": 25441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29401,
      "e": 25465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29401,
      "e": 25465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29465,
      "e": 25529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29521,
      "e": 25585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29521,
      "e": 25585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29617,
      "e": 25681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29618,
      "e": 25682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29625,
      "e": 25689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 29696,
      "e": 25760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29696,
      "e": 25760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29713,
      "e": 25777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29784,
      "e": 25848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30000,
      "e": 26064,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30233,
      "e": 26297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 30233,
      "e": 26297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30312,
      "e": 26376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30312,
      "e": 26376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30368,
      "e": 26432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gr"
    },
    {
      "t": 30393,
      "e": 26457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30393,
      "e": 26457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30432,
      "e": 26496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30472,
      "e": 26536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30472,
      "e": 26536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30505,
      "e": 26569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 30592,
      "e": 26656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30617,
      "e": 26681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30617,
      "e": 26681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30737,
      "e": 26801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30753,
      "e": 26817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30754,
      "e": 26818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30848,
      "e": 26912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30856,
      "e": 26920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30856,
      "e": 26920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30945,
      "e": 27009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30953,
      "e": 27017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30953,
      "e": 27017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31032,
      "e": 27096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31032,
      "e": 27096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31072,
      "e": 27136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 31145,
      "e": 27209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31145,
      "e": 27209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31145,
      "e": 27209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31217,
      "e": 27281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31249,
      "e": 27313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31249,
      "e": 27313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31320,
      "e": 27384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31321,
      "e": 27385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31336,
      "e": 27400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 31424,
      "e": 27488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31424,
      "e": 27488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31424,
      "e": 27488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31480,
      "e": 27544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31603,
      "e": 27667,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the "
    },
    {
      "t": 31825,
      "e": 27889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31825,
      "e": 27889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31928,
      "e": 27992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31929,
      "e": 27993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31960,
      "e": 28024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 32072,
      "e": 28136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32209,
      "e": 28273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32210,
      "e": 28274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32296,
      "e": 28360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32296,
      "e": 28360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32352,
      "e": 28416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 32400,
      "e": 28464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32401,
      "e": 28465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32432,
      "e": 28496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32513,
      "e": 28577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32704,
      "e": 28768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32706,
      "e": 28770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32792,
      "e": 28856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32792,
      "e": 28856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32800,
      "e": 28864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 32888,
      "e": 28952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32889,
      "e": 28953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32896,
      "e": 28960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32952,
      "e": 29016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 32953,
      "e": 29017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32976,
      "e": 29040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33032,
      "e": 29096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33057,
      "e": 29121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33057,
      "e": 29121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33137,
      "e": 29201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33305,
      "e": 29369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 33306,
      "e": 29370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33440,
      "e": 29504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33441,
      "e": 29505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33457,
      "e": 29521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 33529,
      "e": 29593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33530,
      "e": 29594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33552,
      "e": 29616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33632,
      "e": 29696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33633,
      "e": 29697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33633,
      "e": 29697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33721,
      "e": 29785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33737,
      "e": 29801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33737,
      "e": 29801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33832,
      "e": 29896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33856,
      "e": 29920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33856,
      "e": 29920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33960,
      "e": 30024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33992,
      "e": 30056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33992,
      "e": 30056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34073,
      "e": 30137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34112,
      "e": 30176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34113,
      "e": 30177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34193,
      "e": 30257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 34233,
      "e": 30297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34234,
      "e": 30298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34320,
      "e": 30384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34320,
      "e": 30384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34344,
      "e": 30408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 34408,
      "e": 30472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34529,
      "e": 30593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34530,
      "e": 30594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34584,
      "e": 30648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34584,
      "e": 30648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34592,
      "e": 30656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 34664,
      "e": 30728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34664,
      "e": 30728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34713,
      "e": 30777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 34736,
      "e": 30800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34736,
      "e": 30800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34800,
      "e": 30864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34824,
      "e": 30888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34825,
      "e": 30889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34848,
      "e": 30912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34921,
      "e": 30985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34953,
      "e": 31017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34954,
      "e": 31018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35080,
      "e": 31144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35136,
      "e": 31200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35137,
      "e": 31201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35257,
      "e": 31321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35258,
      "e": 31322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35265,
      "e": 31329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 35312,
      "e": 31376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35985,
      "e": 32049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35986,
      "e": 32050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36072,
      "e": 32136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36187,
      "e": 32139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36189,
      "e": 32141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36239,
      "e": 32191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36568,
      "e": 32520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36640,
      "e": 32592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is d"
    },
    {
      "t": 36656,
      "e": 32608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36657,
      "e": 32609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36752,
      "e": 32704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36753,
      "e": 32705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36776,
      "e": 32728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||et"
    },
    {
      "t": 36856,
      "e": 32808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36977,
      "e": 32929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36977,
      "e": 32929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37120,
      "e": 33072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37121,
      "e": 33073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37184,
      "e": 33136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 37257,
      "e": 33209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37258,
      "e": 33210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37264,
      "e": 33216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 37344,
      "e": 33296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37400,
      "e": 33352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37401,
      "e": 33353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37489,
      "e": 33441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37505,
      "e": 33457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37505,
      "e": 33457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37584,
      "e": 33536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37584,
      "e": 33536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37616,
      "e": 33568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 37672,
      "e": 33624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37777,
      "e": 33729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37778,
      "e": 33730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37872,
      "e": 33824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37873,
      "e": 33825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37880,
      "e": 33832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 37952,
      "e": 33904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37985,
      "e": 33937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 37985,
      "e": 33937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38072,
      "e": 34024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 38080,
      "e": 34032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38080,
      "e": 34032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38168,
      "e": 34120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38169,
      "e": 34121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38184,
      "e": 34136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 38241,
      "e": 34193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38313,
      "e": 34265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38313,
      "e": 34265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38384,
      "e": 34336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38392,
      "e": 34344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38393,
      "e": 34345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38472,
      "e": 34424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38520,
      "e": 34472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38520,
      "e": 34472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38585,
      "e": 34537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38585,
      "e": 34537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38593,
      "e": 34545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 38672,
      "e": 34624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42041,
      "e": 37993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 42042,
      "e": 37994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42136,
      "e": 38088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 42152,
      "e": 38104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 42153,
      "e": 38105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42248,
      "e": 38200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 42337,
      "e": 38289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42338,
      "e": 38290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42504,
      "e": 38456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42561,
      "e": 38513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 42562,
      "e": 38514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42688,
      "e": 38640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42688,
      "e": 38640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42712,
      "e": 38664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 42785,
      "e": 38737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42833,
      "e": 38785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42833,
      "e": 38785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42952,
      "e": 38904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 43000,
      "e": 38952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 43001,
      "e": 38953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43080,
      "e": 39032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 43409,
      "e": 39361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43456,
      "e": 39408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis"
    },
    {
      "t": 43602,
      "e": 39554,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis"
    },
    {
      "t": 43672,
      "e": 39624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 43674,
      "e": 39626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43768,
      "e": 39720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 43864,
      "e": 39816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 43864,
      "e": 39816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43985,
      "e": 39937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 43986,
      "e": 39938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 43987,
      "e": 39939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44088,
      "e": 40040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 44104,
      "e": 40056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44104,
      "e": 40056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44184,
      "e": 40136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44272,
      "e": 40224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44273,
      "e": 40225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44320,
      "e": 40272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44320,
      "e": 40272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44369,
      "e": 40273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 44376,
      "e": 40280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44377,
      "e": 40281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44423,
      "e": 40327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44448,
      "e": 40352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44448,
      "e": 40352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44480,
      "e": 40384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44529,
      "e": 40433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44625,
      "e": 40529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44627,
      "e": 40531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44680,
      "e": 40584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 44802,
      "e": 40706,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duratiom"
    },
    {
      "t": 45041,
      "e": 40945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45112,
      "e": 41016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duratio"
    },
    {
      "t": 45280,
      "e": 41184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 45282,
      "e": 41186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45283,
      "e": 41187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45283,
      "e": 41187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45312,
      "e": 41216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bn"
    },
    {
      "t": 45312,
      "e": 41216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45729,
      "e": 41633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45776,
      "e": 41680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duratiob"
    },
    {
      "t": 45856,
      "e": 41760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45928,
      "e": 41832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duratio"
    },
    {
      "t": 46114,
      "e": 42018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46115,
      "e": 42019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46208,
      "e": 42112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 46240,
      "e": 42144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 46240,
      "e": 42144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46288,
      "e": 42192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 46352,
      "e": 42256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46353,
      "e": 42257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46432,
      "e": 42336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48200,
      "e": 44104,
      "ty": 2,
      "x": 387,
      "y": 551
    },
    {
      "t": 48250,
      "e": 44154,
      "ty": 41,
      "x": 34162,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48300,
      "e": 44204,
      "ty": 2,
      "x": 408,
      "y": 533
    },
    {
      "t": 48333,
      "e": 44237,
      "ty": 7,
      "x": 431,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48401,
      "e": 44305,
      "ty": 2,
      "x": 466,
      "y": 504
    },
    {
      "t": 48500,
      "e": 44404,
      "ty": 41,
      "x": 41468,
      "y": 21686,
      "ta": "#.strategy > p"
    },
    {
      "t": 48533,
      "e": 44437,
      "ty": 6,
      "x": 467,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48600,
      "e": 44504,
      "ty": 2,
      "x": 472,
      "y": 553
    },
    {
      "t": 48750,
      "e": 44654,
      "ty": 41,
      "x": 42143,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49016,
      "e": 44920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49167,
      "e": 45071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 49168,
      "e": 45072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49256,
      "e": 45160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 49264,
      "e": 45168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49288,
      "e": 45192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49304,
      "e": 45208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49345,
      "e": 45249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49345,
      "e": 45249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49456,
      "e": 45360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49585,
      "e": 45489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 49585,
      "e": 45489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49672,
      "e": 45576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 49736,
      "e": 45640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49736,
      "e": 45640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49832,
      "e": 45736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50000,
      "e": 45904,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52257,
      "e": 48161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52257,
      "e": 48161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52368,
      "e": 48272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52368,
      "e": 48272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52375,
      "e": 48279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 52489,
      "e": 48393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52560,
      "e": 48464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52561,
      "e": 48465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52656,
      "e": 48560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52808,
      "e": 48712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52810,
      "e": 48714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52888,
      "e": 48792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52888,
      "e": 48792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52936,
      "e": 48840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 52984,
      "e": 48888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53112,
      "e": 49016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53168,
      "e": 49072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duration. So, go o"
    },
    {
      "t": 53272,
      "e": 49176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53327,
      "e": 49231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duration. So, go "
    },
    {
      "t": 53368,
      "e": 49272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53368,
      "e": 49272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53456,
      "e": 49360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53472,
      "e": 49376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53473,
      "e": 49377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53552,
      "e": 49456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 53617,
      "e": 49521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53617,
      "e": 49521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53720,
      "e": 49624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53736,
      "e": 49640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53736,
      "e": 49640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53792,
      "e": 49696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53824,
      "e": 49728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53825,
      "e": 49729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53961,
      "e": 49865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 53969,
      "e": 49873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53969,
      "e": 49873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54056,
      "e": 49960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54064,
      "e": 49968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54064,
      "e": 49968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54147,
      "e": 50051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54740,
      "e": 50644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 54740,
      "e": 50644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54827,
      "e": 50731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 54828,
      "e": 50732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54932,
      "e": 50836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 54972,
      "e": 50876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55012,
      "e": 50916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55013,
      "e": 50917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55067,
      "e": 50971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 55206,
      "e": 51110,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duration. So, go to the 12p"
    },
    {
      "t": 55220,
      "e": 51124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55220,
      "e": 51124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55324,
      "e": 51228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 56157,
      "e": 52061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56158,
      "e": 52062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56259,
      "e": 52163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57028,
      "e": 52932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57029,
      "e": 52933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57107,
      "e": 53011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57131,
      "e": 53035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57131,
      "e": 53035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57204,
      "e": 53108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57268,
      "e": 53172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 57269,
      "e": 53173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57372,
      "e": 53276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 57372,
      "e": 53276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57404,
      "e": 53308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ck"
    },
    {
      "t": 57435,
      "e": 53339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57475,
      "e": 53379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57476,
      "e": 53380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57587,
      "e": 53491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 57587,
      "e": 53491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57595,
      "e": 53499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| m"
    },
    {
      "t": 57691,
      "e": 53595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57708,
      "e": 53612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57708,
      "e": 53612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57804,
      "e": 53708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57805,
      "e": 53709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57851,
      "e": 53755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 57915,
      "e": 53819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57915,
      "e": 53819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 57916,
      "e": 53820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58011,
      "e": 53915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 58028,
      "e": 53932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58030,
      "e": 53934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58115,
      "e": 54019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58179,
      "e": 54083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58179,
      "e": 54083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58236,
      "e": 54140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 58348,
      "e": 54252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58349,
      "e": 54253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58436,
      "e": 54340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 58444,
      "e": 54348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58444,
      "e": 54348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58556,
      "e": 54460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58556,
      "e": 54460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58564,
      "e": 54468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 58595,
      "e": 54499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58596,
      "e": 54500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58635,
      "e": 54539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58692,
      "e": 54596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58739,
      "e": 54643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58740,
      "e": 54644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58812,
      "e": 54716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58812,
      "e": 54716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58819,
      "e": 54723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 58907,
      "e": 54811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59076,
      "e": 54980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59077,
      "e": 54981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59196,
      "e": 55100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 59197,
      "e": 55101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59204,
      "e": 55108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ax"
    },
    {
      "t": 59380,
      "e": 55284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59548,
      "e": 55452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59549,
      "e": 55453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59619,
      "e": 55523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59619,
      "e": 55523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59636,
      "e": 55540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 59723,
      "e": 55627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59965,
      "e": 55869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59965,
      "e": 55869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60051,
      "e": 55955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60068,
      "e": 55972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60068,
      "e": 55972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60172,
      "e": 56076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 60211,
      "e": 56115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60212,
      "e": 56116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60308,
      "e": 56212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 60315,
      "e": 56219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 60316,
      "e": 56220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60371,
      "e": 56275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60372,
      "e": 56276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60379,
      "e": 56283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 60459,
      "e": 56363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60523,
      "e": 56427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 60523,
      "e": 56427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60588,
      "e": 56492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 60644,
      "e": 56548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60645,
      "e": 56549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60707,
      "e": 56611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60731,
      "e": 56635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60732,
      "e": 56636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60819,
      "e": 56723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60860,
      "e": 56764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 60860,
      "e": 56764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60940,
      "e": 56844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 61101,
      "e": 57005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 61101,
      "e": 57005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61164,
      "e": 57068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 61580,
      "e": 57484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 61581,
      "e": 57485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61716,
      "e": 57620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 62504,
      "e": 58408,
      "ty": 2,
      "x": 430,
      "y": 594
    },
    {
      "t": 62504,
      "e": 58408,
      "ty": 41,
      "x": 37421,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62516,
      "e": 58420,
      "ty": 7,
      "x": 403,
      "y": 632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62604,
      "e": 58508,
      "ty": 2,
      "x": 395,
      "y": 642
    },
    {
      "t": 62703,
      "e": 58607,
      "ty": 2,
      "x": 394,
      "y": 643
    },
    {
      "t": 62755,
      "e": 58659,
      "ty": 41,
      "x": 35298,
      "y": 13936,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 62783,
      "e": 58687,
      "ty": 6,
      "x": 387,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 62804,
      "e": 58708,
      "ty": 2,
      "x": 383,
      "y": 664
    },
    {
      "t": 62904,
      "e": 58808,
      "ty": 2,
      "x": 381,
      "y": 668
    },
    {
      "t": 63004,
      "e": 58908,
      "ty": 2,
      "x": 381,
      "y": 671
    },
    {
      "t": 63005,
      "e": 58909,
      "ty": 41,
      "x": 23159,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 63303,
      "e": 59207,
      "ty": 2,
      "x": 380,
      "y": 674
    },
    {
      "t": 63405,
      "e": 59309,
      "ty": 2,
      "x": 380,
      "y": 676
    },
    {
      "t": 63505,
      "e": 59409,
      "ty": 41,
      "x": 22612,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 63793,
      "e": 59697,
      "ty": 3,
      "x": 380,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 63794,
      "e": 59698,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duration. So, go to the 12pm tick mark on the axis and go up."
    },
    {
      "t": 63796,
      "e": 59700,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63796,
      "e": 59700,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 63920,
      "e": 59824,
      "ty": 4,
      "x": 22612,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 63929,
      "e": 59833,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 63931,
      "e": 59835,
      "ty": 5,
      "x": 380,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 63940,
      "e": 59844,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 64936,
      "e": 60840,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 65604,
      "e": 61508,
      "ty": 2,
      "x": 421,
      "y": 669
    },
    {
      "t": 65703,
      "e": 61607,
      "ty": 2,
      "x": 556,
      "y": 628
    },
    {
      "t": 65753,
      "e": 61657,
      "ty": 41,
      "x": 24898,
      "y": 34124,
      "ta": "html > body"
    },
    {
      "t": 65803,
      "e": 61707,
      "ty": 2,
      "x": 844,
      "y": 613
    },
    {
      "t": 65904,
      "e": 61808,
      "ty": 2,
      "x": 877,
      "y": 600
    },
    {
      "t": 66003,
      "e": 61907,
      "ty": 2,
      "x": 910,
      "y": 582
    },
    {
      "t": 66004,
      "e": 61908,
      "ty": 41,
      "x": 22061,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 66102,
      "e": 62006,
      "ty": 6,
      "x": 913,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66103,
      "e": 62007,
      "ty": 2,
      "x": 913,
      "y": 572
    },
    {
      "t": 66203,
      "e": 62107,
      "ty": 2,
      "x": 916,
      "y": 568
    },
    {
      "t": 66254,
      "e": 62158,
      "ty": 41,
      "x": 23575,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66303,
      "e": 62207,
      "ty": 2,
      "x": 917,
      "y": 560
    },
    {
      "t": 66449,
      "e": 62353,
      "ty": 3,
      "x": 917,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66450,
      "e": 62354,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66504,
      "e": 62355,
      "ty": 41,
      "x": 23575,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66551,
      "e": 62402,
      "ty": 4,
      "x": 23575,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66552,
      "e": 62403,
      "ty": 5,
      "x": 917,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67172,
      "e": 63023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "40"
    },
    {
      "t": 67300,
      "e": 63151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "45"
    },
    {
      "t": 67324,
      "e": 63175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 67404,
      "e": 63255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 69036,
      "e": 64887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 69036,
      "e": 64887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69084,
      "e": 64935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 69084,
      "e": 64935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69099,
      "e": 64950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 69131,
      "e": 64982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 69803,
      "e": 65654,
      "ty": 2,
      "x": 917,
      "y": 566
    },
    {
      "t": 69803,
      "e": 65654,
      "ty": 7,
      "x": 905,
      "y": 592,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69838,
      "e": 65689,
      "ty": 6,
      "x": 865,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69855,
      "e": 65706,
      "ty": 7,
      "x": 861,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69903,
      "e": 65754,
      "ty": 2,
      "x": 861,
      "y": 687
    },
    {
      "t": 70004,
      "e": 65855,
      "ty": 41,
      "x": 29375,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 70204,
      "e": 66055,
      "ty": 2,
      "x": 857,
      "y": 677
    },
    {
      "t": 70254,
      "e": 66105,
      "ty": 41,
      "x": 10165,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70289,
      "e": 66140,
      "ty": 6,
      "x": 853,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70304,
      "e": 66155,
      "ty": 2,
      "x": 853,
      "y": 665
    },
    {
      "t": 70403,
      "e": 66254,
      "ty": 2,
      "x": 853,
      "y": 664
    },
    {
      "t": 70432,
      "e": 66283,
      "ty": 3,
      "x": 853,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70432,
      "e": 66283,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 70432,
      "e": 66283,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70433,
      "e": 66284,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70503,
      "e": 66354,
      "ty": 41,
      "x": 9732,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70536,
      "e": 66387,
      "ty": 4,
      "x": 9732,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70536,
      "e": 66387,
      "ty": 5,
      "x": 853,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71156,
      "e": 67007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 71156,
      "e": 67007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71260,
      "e": 67111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 71260,
      "e": 67111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "57"
    },
    {
      "t": 71260,
      "e": 67111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71316,
      "e": 67167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "19"
    },
    {
      "t": 71388,
      "e": 67239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "57"
    },
    {
      "t": 71389,
      "e": 67240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71491,
      "e": 67342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "19*"
    },
    {
      "t": 71500,
      "e": 67351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 71501,
      "e": 67352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71579,
      "e": 67430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "19**"
    },
    {
      "t": 72254,
      "e": 68105,
      "ty": 41,
      "x": 9732,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72303,
      "e": 68154,
      "ty": 2,
      "x": 853,
      "y": 663
    },
    {
      "t": 72313,
      "e": 68164,
      "ty": 7,
      "x": 859,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72404,
      "e": 68255,
      "ty": 2,
      "x": 871,
      "y": 685
    },
    {
      "t": 72457,
      "e": 68308,
      "ty": 6,
      "x": 898,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72503,
      "e": 68354,
      "ty": 2,
      "x": 903,
      "y": 689
    },
    {
      "t": 72504,
      "e": 68355,
      "ty": 41,
      "x": 3647,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72604,
      "e": 68455,
      "ty": 2,
      "x": 908,
      "y": 689
    },
    {
      "t": 72696,
      "e": 68547,
      "ty": 3,
      "x": 909,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72698,
      "e": 68549,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "19**"
    },
    {
      "t": 72698,
      "e": 68549,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72699,
      "e": 68550,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72704,
      "e": 68555,
      "ty": 2,
      "x": 909,
      "y": 689
    },
    {
      "t": 72754,
      "e": 68605,
      "ty": 41,
      "x": 6740,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72800,
      "e": 68651,
      "ty": 4,
      "x": 6740,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72800,
      "e": 68651,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72800,
      "e": 68651,
      "ty": 5,
      "x": 909,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72800,
      "e": 68651,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 73003,
      "e": 68854,
      "ty": 2,
      "x": 862,
      "y": 743
    },
    {
      "t": 73004,
      "e": 68855,
      "ty": 41,
      "x": 29409,
      "y": 40717,
      "ta": "html > body"
    },
    {
      "t": 73104,
      "e": 68955,
      "ty": 2,
      "x": 814,
      "y": 779
    },
    {
      "t": 73204,
      "e": 69055,
      "ty": 2,
      "x": 787,
      "y": 790
    },
    {
      "t": 73254,
      "e": 69105,
      "ty": 41,
      "x": 26826,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 73815,
      "e": 69666,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 74403,
      "e": 70254,
      "ty": 2,
      "x": 783,
      "y": 789
    },
    {
      "t": 74504,
      "e": 70355,
      "ty": 2,
      "x": 783,
      "y": 748
    },
    {
      "t": 74504,
      "e": 70355,
      "ty": 41,
      "x": 26689,
      "y": 40993,
      "ta": "html > body"
    },
    {
      "t": 74603,
      "e": 70454,
      "ty": 2,
      "x": 793,
      "y": 685
    },
    {
      "t": 74703,
      "e": 70554,
      "ty": 2,
      "x": 794,
      "y": 681
    },
    {
      "t": 74754,
      "e": 70605,
      "ty": 41,
      "x": 26999,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 74804,
      "e": 70655,
      "ty": 2,
      "x": 797,
      "y": 737
    },
    {
      "t": 74904,
      "e": 70755,
      "ty": 2,
      "x": 806,
      "y": 817
    },
    {
      "t": 75004,
      "e": 70855,
      "ty": 2,
      "x": 810,
      "y": 868
    },
    {
      "t": 75004,
      "e": 70855,
      "ty": 41,
      "x": 27619,
      "y": 47641,
      "ta": "html > body"
    },
    {
      "t": 75104,
      "e": 70955,
      "ty": 2,
      "x": 804,
      "y": 934
    },
    {
      "t": 75204,
      "e": 71055,
      "ty": 2,
      "x": 800,
      "y": 963
    },
    {
      "t": 75253,
      "e": 71104,
      "ty": 41,
      "x": 27033,
      "y": 53236,
      "ta": "html > body"
    },
    {
      "t": 75304,
      "e": 71155,
      "ty": 2,
      "x": 785,
      "y": 969
    },
    {
      "t": 75404,
      "e": 71255,
      "ty": 2,
      "x": 747,
      "y": 703
    },
    {
      "t": 75503,
      "e": 71354,
      "ty": 2,
      "x": 794,
      "y": 513
    },
    {
      "t": 75504,
      "e": 71355,
      "ty": 41,
      "x": 27068,
      "y": 27975,
      "ta": "html > body"
    },
    {
      "t": 75604,
      "e": 71455,
      "ty": 2,
      "x": 827,
      "y": 406
    },
    {
      "t": 75703,
      "e": 71554,
      "ty": 2,
      "x": 848,
      "y": 342
    },
    {
      "t": 75754,
      "e": 71605,
      "ty": 41,
      "x": 8443,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 75804,
      "e": 71655,
      "ty": 2,
      "x": 862,
      "y": 272
    },
    {
      "t": 75903,
      "e": 71754,
      "ty": 2,
      "x": 859,
      "y": 236
    },
    {
      "t": 76004,
      "e": 71855,
      "ty": 2,
      "x": 849,
      "y": 223
    },
    {
      "t": 76004,
      "e": 71855,
      "ty": 41,
      "x": 6544,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 76104,
      "e": 71955,
      "ty": 2,
      "x": 844,
      "y": 223
    },
    {
      "t": 76161,
      "e": 72012,
      "ty": 6,
      "x": 835,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 76203,
      "e": 72054,
      "ty": 2,
      "x": 833,
      "y": 237
    },
    {
      "t": 76253,
      "e": 72104,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 76295,
      "e": 72146,
      "ty": 7,
      "x": 833,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 76304,
      "e": 72155,
      "ty": 2,
      "x": 833,
      "y": 246
    },
    {
      "t": 76404,
      "e": 72255,
      "ty": 2,
      "x": 831,
      "y": 251
    },
    {
      "t": 76504,
      "e": 72355,
      "ty": 2,
      "x": 830,
      "y": 255
    },
    {
      "t": 76504,
      "e": 72355,
      "ty": 41,
      "x": 2035,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 76603,
      "e": 72454,
      "ty": 2,
      "x": 829,
      "y": 257
    },
    {
      "t": 76639,
      "e": 72454,
      "ty": 6,
      "x": 829,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 76704,
      "e": 72519,
      "ty": 2,
      "x": 829,
      "y": 262
    },
    {
      "t": 76754,
      "e": 72569,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 77178,
      "e": 72993,
      "ty": 7,
      "x": 827,
      "y": 259,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 77204,
      "e": 73019,
      "ty": 2,
      "x": 826,
      "y": 253
    },
    {
      "t": 77254,
      "e": 73069,
      "ty": 41,
      "x": 2930,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 77304,
      "e": 73119,
      "ty": 2,
      "x": 825,
      "y": 241
    },
    {
      "t": 77377,
      "e": 73192,
      "ty": 6,
      "x": 826,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77404,
      "e": 73219,
      "ty": 2,
      "x": 826,
      "y": 237
    },
    {
      "t": 77503,
      "e": 73318,
      "ty": 2,
      "x": 827,
      "y": 237
    },
    {
      "t": 77504,
      "e": 73319,
      "ty": 41,
      "x": 2914,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77584,
      "e": 73399,
      "ty": 3,
      "x": 827,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77586,
      "e": 73401,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77711,
      "e": 73526,
      "ty": 4,
      "x": 2914,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77713,
      "e": 73528,
      "ty": 5,
      "x": 827,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77714,
      "e": 73529,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 77995,
      "e": 73810,
      "ty": 7,
      "x": 828,
      "y": 249,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 78004,
      "e": 73819,
      "ty": 2,
      "x": 828,
      "y": 249
    },
    {
      "t": 78004,
      "e": 73819,
      "ty": 41,
      "x": 1561,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 78011,
      "e": 73826,
      "ty": 6,
      "x": 831,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 78028,
      "e": 73843,
      "ty": 7,
      "x": 833,
      "y": 286,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 78061,
      "e": 73876,
      "ty": 6,
      "x": 837,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 78078,
      "e": 73893,
      "ty": 7,
      "x": 838,
      "y": 334,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 78104,
      "e": 73919,
      "ty": 2,
      "x": 837,
      "y": 355
    },
    {
      "t": 78127,
      "e": 73942,
      "ty": 6,
      "x": 839,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78144,
      "e": 73959,
      "ty": 7,
      "x": 842,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78203,
      "e": 74018,
      "ty": 2,
      "x": 845,
      "y": 481
    },
    {
      "t": 78254,
      "e": 74069,
      "ty": 41,
      "x": 5595,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 78304,
      "e": 74119,
      "ty": 2,
      "x": 844,
      "y": 495
    },
    {
      "t": 78404,
      "e": 74219,
      "ty": 2,
      "x": 842,
      "y": 507
    },
    {
      "t": 78505,
      "e": 74320,
      "ty": 41,
      "x": 18469,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 78529,
      "e": 74344,
      "ty": 6,
      "x": 839,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 78562,
      "e": 74377,
      "ty": 7,
      "x": 838,
      "y": 490,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 78604,
      "e": 74419,
      "ty": 2,
      "x": 834,
      "y": 478
    },
    {
      "t": 78613,
      "e": 74428,
      "ty": 6,
      "x": 831,
      "y": 471,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 78646,
      "e": 74461,
      "ty": 7,
      "x": 826,
      "y": 459,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 78703,
      "e": 74518,
      "ty": 2,
      "x": 821,
      "y": 443
    },
    {
      "t": 78757,
      "e": 74521,
      "ty": 41,
      "x": 1260,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 78804,
      "e": 74568,
      "ty": 2,
      "x": 825,
      "y": 430
    },
    {
      "t": 78904,
      "e": 74668,
      "ty": 2,
      "x": 826,
      "y": 429
    },
    {
      "t": 79004,
      "e": 74768,
      "ty": 2,
      "x": 841,
      "y": 437
    },
    {
      "t": 79005,
      "e": 74769,
      "ty": 41,
      "x": 15638,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 79204,
      "e": 74968,
      "ty": 2,
      "x": 840,
      "y": 441
    },
    {
      "t": 79253,
      "e": 75017,
      "ty": 41,
      "x": 14839,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 79279,
      "e": 75043,
      "ty": 6,
      "x": 839,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 79304,
      "e": 75068,
      "ty": 2,
      "x": 839,
      "y": 442
    },
    {
      "t": 79404,
      "e": 75168,
      "ty": 2,
      "x": 839,
      "y": 443
    },
    {
      "t": 79505,
      "e": 75269,
      "ty": 41,
      "x": 63408,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80104,
      "e": 75868,
      "ty": 2,
      "x": 838,
      "y": 443
    },
    {
      "t": 80197,
      "e": 75961,
      "ty": 7,
      "x": 822,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80204,
      "e": 75968,
      "ty": 2,
      "x": 822,
      "y": 443
    },
    {
      "t": 80255,
      "e": 76019,
      "ty": 41,
      "x": 0,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 80304,
      "e": 76068,
      "ty": 2,
      "x": 821,
      "y": 442
    },
    {
      "t": 80404,
      "e": 76168,
      "ty": 2,
      "x": 824,
      "y": 443
    },
    {
      "t": 80414,
      "e": 76178,
      "ty": 6,
      "x": 827,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80504,
      "e": 76268,
      "ty": 2,
      "x": 828,
      "y": 443
    },
    {
      "t": 80504,
      "e": 76268,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80604,
      "e": 76368,
      "ty": 2,
      "x": 831,
      "y": 444
    },
    {
      "t": 80704,
      "e": 76468,
      "ty": 2,
      "x": 833,
      "y": 444
    },
    {
      "t": 80754,
      "e": 76518,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80816,
      "e": 76580,
      "ty": 3,
      "x": 833,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80818,
      "e": 76582,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80818,
      "e": 76582,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80919,
      "e": 76683,
      "ty": 4,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80920,
      "e": 76684,
      "ty": 5,
      "x": 833,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80920,
      "e": 76684,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 81025,
      "e": 76789,
      "ty": 7,
      "x": 833,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 81080,
      "e": 76844,
      "ty": 6,
      "x": 833,
      "y": 528,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 81097,
      "e": 76861,
      "ty": 7,
      "x": 836,
      "y": 550,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 81097,
      "e": 76861,
      "ty": 6,
      "x": 836,
      "y": 550,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 81104,
      "e": 76868,
      "ty": 2,
      "x": 836,
      "y": 550
    },
    {
      "t": 81113,
      "e": 76877,
      "ty": 7,
      "x": 840,
      "y": 566,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 81204,
      "e": 76968,
      "ty": 2,
      "x": 838,
      "y": 639
    },
    {
      "t": 81254,
      "e": 77018,
      "ty": 41,
      "x": 3459,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 81304,
      "e": 77068,
      "ty": 2,
      "x": 834,
      "y": 648
    },
    {
      "t": 81381,
      "e": 77145,
      "ty": 6,
      "x": 826,
      "y": 670,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 81404,
      "e": 77168,
      "ty": 2,
      "x": 826,
      "y": 678
    },
    {
      "t": 81414,
      "e": 77178,
      "ty": 7,
      "x": 826,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 81447,
      "e": 77211,
      "ty": 6,
      "x": 826,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81504,
      "e": 77268,
      "ty": 2,
      "x": 826,
      "y": 702
    },
    {
      "t": 81504,
      "e": 77268,
      "ty": 41,
      "x": 0,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81604,
      "e": 77368,
      "ty": 2,
      "x": 827,
      "y": 703
    },
    {
      "t": 81704,
      "e": 77468,
      "ty": 2,
      "x": 828,
      "y": 703
    },
    {
      "t": 81755,
      "e": 77519,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81804,
      "e": 77568,
      "ty": 2,
      "x": 832,
      "y": 703
    },
    {
      "t": 81904,
      "e": 77668,
      "ty": 2,
      "x": 834,
      "y": 704
    },
    {
      "t": 82004,
      "e": 77768,
      "ty": 2,
      "x": 835,
      "y": 708
    },
    {
      "t": 82004,
      "e": 77768,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82204,
      "e": 77968,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 82215,
      "e": 77979,
      "ty": 7,
      "x": 836,
      "y": 692,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82254,
      "e": 78018,
      "ty": 41,
      "x": 3222,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 82304,
      "e": 78068,
      "ty": 2,
      "x": 835,
      "y": 685
    },
    {
      "t": 82404,
      "e": 78168,
      "ty": 2,
      "x": 835,
      "y": 681
    },
    {
      "t": 82424,
      "e": 78188,
      "ty": 6,
      "x": 835,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 82504,
      "e": 78268,
      "ty": 2,
      "x": 835,
      "y": 677
    },
    {
      "t": 82504,
      "e": 78268,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 82604,
      "e": 78368,
      "ty": 2,
      "x": 837,
      "y": 673
    },
    {
      "t": 82648,
      "e": 78412,
      "ty": 7,
      "x": 837,
      "y": 685,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 82704,
      "e": 78468,
      "ty": 2,
      "x": 843,
      "y": 694
    },
    {
      "t": 82754,
      "e": 78468,
      "ty": 41,
      "x": 5437,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 83204,
      "e": 78918,
      "ty": 2,
      "x": 842,
      "y": 703
    },
    {
      "t": 83233,
      "e": 78947,
      "ty": 6,
      "x": 839,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83254,
      "e": 78968,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83304,
      "e": 79018,
      "ty": 2,
      "x": 839,
      "y": 708
    },
    {
      "t": 83503,
      "e": 79217,
      "ty": 2,
      "x": 833,
      "y": 702
    },
    {
      "t": 83503,
      "e": 79217,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83550,
      "e": 79264,
      "ty": 7,
      "x": 831,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83605,
      "e": 79319,
      "ty": 2,
      "x": 831,
      "y": 693
    },
    {
      "t": 83716,
      "e": 79430,
      "ty": 6,
      "x": 831,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83750,
      "e": 79464,
      "ty": 7,
      "x": 831,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83754,
      "e": 79468,
      "ty": 41,
      "x": 2413,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 83800,
      "e": 79514,
      "ty": 6,
      "x": 828,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83804,
      "e": 79518,
      "ty": 2,
      "x": 828,
      "y": 726
    },
    {
      "t": 83832,
      "e": 79546,
      "ty": 7,
      "x": 825,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83904,
      "e": 79618,
      "ty": 2,
      "x": 824,
      "y": 749
    },
    {
      "t": 84004,
      "e": 79718,
      "ty": 2,
      "x": 823,
      "y": 762
    },
    {
      "t": 84004,
      "e": 79718,
      "ty": 41,
      "x": 658,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 84104,
      "e": 79818,
      "ty": 2,
      "x": 823,
      "y": 764
    },
    {
      "t": 84255,
      "e": 79969,
      "ty": 41,
      "x": 658,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 84404,
      "e": 80118,
      "ty": 2,
      "x": 823,
      "y": 762
    },
    {
      "t": 84434,
      "e": 80148,
      "ty": 6,
      "x": 826,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 84450,
      "e": 80164,
      "ty": 7,
      "x": 827,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 84504,
      "e": 80218,
      "ty": 2,
      "x": 831,
      "y": 740
    },
    {
      "t": 84504,
      "e": 80218,
      "ty": 41,
      "x": 2403,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 84534,
      "e": 80248,
      "ty": 6,
      "x": 833,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84584,
      "e": 80298,
      "ty": 7,
      "x": 838,
      "y": 722,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84604,
      "e": 80318,
      "ty": 2,
      "x": 838,
      "y": 720
    },
    {
      "t": 84705,
      "e": 80419,
      "ty": 2,
      "x": 841,
      "y": 709
    },
    {
      "t": 84754,
      "e": 80468,
      "ty": 41,
      "x": 4933,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 84804,
      "e": 80518,
      "ty": 2,
      "x": 841,
      "y": 706
    },
    {
      "t": 84905,
      "e": 80619,
      "ty": 2,
      "x": 841,
      "y": 704
    },
    {
      "t": 85005,
      "e": 80719,
      "ty": 41,
      "x": 4933,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85081,
      "e": 80795,
      "ty": 3,
      "x": 841,
      "y": 704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85081,
      "e": 80795,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85207,
      "e": 80921,
      "ty": 4,
      "x": 4933,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85207,
      "e": 80921,
      "ty": 5,
      "x": 841,
      "y": 704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85207,
      "e": 80921,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85208,
      "e": 80922,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 85504,
      "e": 81218,
      "ty": 2,
      "x": 845,
      "y": 711
    },
    {
      "t": 85504,
      "e": 81218,
      "ty": 41,
      "x": 5941,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85604,
      "e": 81318,
      "ty": 2,
      "x": 858,
      "y": 802
    },
    {
      "t": 85705,
      "e": 81419,
      "ty": 2,
      "x": 862,
      "y": 868
    },
    {
      "t": 85754,
      "e": 81468,
      "ty": 41,
      "x": 8680,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 85804,
      "e": 81518,
      "ty": 2,
      "x": 851,
      "y": 921
    },
    {
      "t": 85904,
      "e": 81618,
      "ty": 2,
      "x": 840,
      "y": 939
    },
    {
      "t": 86005,
      "e": 81719,
      "ty": 41,
      "x": 20291,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86204,
      "e": 81918,
      "ty": 2,
      "x": 843,
      "y": 943
    },
    {
      "t": 86254,
      "e": 81968,
      "ty": 41,
      "x": 5121,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 86305,
      "e": 82019,
      "ty": 2,
      "x": 843,
      "y": 961
    },
    {
      "t": 86404,
      "e": 82118,
      "ty": 2,
      "x": 841,
      "y": 964
    },
    {
      "t": 86419,
      "e": 82119,
      "ty": 6,
      "x": 839,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86504,
      "e": 82204,
      "ty": 2,
      "x": 836,
      "y": 968
    },
    {
      "t": 86504,
      "e": 82204,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86569,
      "e": 82269,
      "ty": 7,
      "x": 825,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86604,
      "e": 82304,
      "ty": 2,
      "x": 825,
      "y": 968
    },
    {
      "t": 86754,
      "e": 82454,
      "ty": 41,
      "x": 2894,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87144,
      "e": 82844,
      "ty": 6,
      "x": 827,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87204,
      "e": 82904,
      "ty": 2,
      "x": 833,
      "y": 967
    },
    {
      "t": 87254,
      "e": 82954,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87288,
      "e": 82988,
      "ty": 7,
      "x": 840,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87305,
      "e": 83005,
      "ty": 2,
      "x": 840,
      "y": 966
    },
    {
      "t": 87505,
      "e": 83205,
      "ty": 41,
      "x": 15028,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 87585,
      "e": 83285,
      "ty": 6,
      "x": 838,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87603,
      "e": 83303,
      "ty": 2,
      "x": 837,
      "y": 964
    },
    {
      "t": 87705,
      "e": 83405,
      "ty": 2,
      "x": 833,
      "y": 959
    },
    {
      "t": 87755,
      "e": 83455,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87881,
      "e": 83581,
      "ty": 3,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87882,
      "e": 83582,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87883,
      "e": 83583,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87975,
      "e": 83675,
      "ty": 4,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87976,
      "e": 83676,
      "ty": 5,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 87976,
      "e": 83676,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 88153,
      "e": 83853,
      "ty": 7,
      "x": 842,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 88203,
      "e": 83903,
      "ty": 6,
      "x": 882,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88203,
      "e": 83903,
      "ty": 2,
      "x": 882,
      "y": 1009
    },
    {
      "t": 88254,
      "e": 83954,
      "ty": 41,
      "x": 33282,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88305,
      "e": 84005,
      "ty": 2,
      "x": 894,
      "y": 1019
    },
    {
      "t": 88520,
      "e": 84220,
      "ty": 3,
      "x": 894,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88522,
      "e": 84222,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 88522,
      "e": 84222,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88607,
      "e": 84307,
      "ty": 4,
      "x": 33282,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88607,
      "e": 84307,
      "ty": 5,
      "x": 894,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88609,
      "e": 84309,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 88610,
      "e": 84310,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 88611,
      "e": 84311,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 88755,
      "e": 84455,
      "ty": 41,
      "x": 30477,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 88803,
      "e": 84503,
      "ty": 2,
      "x": 887,
      "y": 1004
    },
    {
      "t": 88904,
      "e": 84604,
      "ty": 2,
      "x": 853,
      "y": 936
    },
    {
      "t": 89004,
      "e": 84704,
      "ty": 2,
      "x": 804,
      "y": 843
    },
    {
      "t": 89004,
      "e": 84704,
      "ty": 41,
      "x": 27412,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 89105,
      "e": 84805,
      "ty": 2,
      "x": 756,
      "y": 666
    },
    {
      "t": 89204,
      "e": 84904,
      "ty": 2,
      "x": 765,
      "y": 584
    },
    {
      "t": 89253,
      "e": 84953,
      "ty": 41,
      "x": 26792,
      "y": 29194,
      "ta": "html > body"
    },
    {
      "t": 89304,
      "e": 85004,
      "ty": 2,
      "x": 815,
      "y": 484
    },
    {
      "t": 89403,
      "e": 85103,
      "ty": 2,
      "x": 864,
      "y": 455
    },
    {
      "t": 89504,
      "e": 85204,
      "ty": 2,
      "x": 983,
      "y": 443
    },
    {
      "t": 89504,
      "e": 85204,
      "ty": 41,
      "x": 33576,
      "y": 24097,
      "ta": "html > body"
    },
    {
      "t": 89603,
      "e": 85303,
      "ty": 2,
      "x": 1195,
      "y": 502
    },
    {
      "t": 89703,
      "e": 85403,
      "ty": 2,
      "x": 1216,
      "y": 530
    },
    {
      "t": 89754,
      "e": 85454,
      "ty": 41,
      "x": 41635,
      "y": 28917,
      "ta": "html > body"
    },
    {
      "t": 89804,
      "e": 85504,
      "ty": 2,
      "x": 1217,
      "y": 530
    },
    {
      "t": 89942,
      "e": 85642,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 90753,
      "e": 86453,
      "ty": 41,
      "x": 45435,
      "y": 18925,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90804,
      "e": 86504,
      "ty": 2,
      "x": 1217,
      "y": 531
    },
    {
      "t": 90904,
      "e": 86604,
      "ty": 2,
      "x": 1200,
      "y": 538
    },
    {
      "t": 91003,
      "e": 86703,
      "ty": 2,
      "x": 1172,
      "y": 584
    },
    {
      "t": 91003,
      "e": 86703,
      "ty": 41,
      "x": 43221,
      "y": 39600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91103,
      "e": 86803,
      "ty": 2,
      "x": 1138,
      "y": 686
    },
    {
      "t": 91203,
      "e": 86903,
      "ty": 2,
      "x": 1113,
      "y": 792
    },
    {
      "t": 91253,
      "e": 86953,
      "ty": 41,
      "x": 39286,
      "y": 59116,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91304,
      "e": 87004,
      "ty": 2,
      "x": 1077,
      "y": 890
    },
    {
      "t": 91404,
      "e": 87104,
      "ty": 2,
      "x": 1019,
      "y": 961
    },
    {
      "t": 91503,
      "e": 87203,
      "ty": 2,
      "x": 976,
      "y": 1020
    },
    {
      "t": 91504,
      "e": 87204,
      "ty": 41,
      "x": 33579,
      "y": 61886,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91604,
      "e": 87304,
      "ty": 2,
      "x": 967,
      "y": 1056
    },
    {
      "t": 91640,
      "e": 87340,
      "ty": 6,
      "x": 959,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 91704,
      "e": 87404,
      "ty": 2,
      "x": 953,
      "y": 1083
    },
    {
      "t": 91754,
      "e": 87454,
      "ty": 41,
      "x": 22664,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 91803,
      "e": 87503,
      "ty": 2,
      "x": 950,
      "y": 1090
    },
    {
      "t": 91903,
      "e": 87603,
      "ty": 2,
      "x": 949,
      "y": 1091
    },
    {
      "t": 92004,
      "e": 87704,
      "ty": 41,
      "x": 21571,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 93216,
      "e": 88916,
      "ty": 3,
      "x": 949,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 93217,
      "e": 88917,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 93319,
      "e": 89019,
      "ty": 4,
      "x": 21571,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 93320,
      "e": 89020,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 93320,
      "e": 89020,
      "ty": 5,
      "x": 949,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 93320,
      "e": 89020,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 94361,
      "e": 90061,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 95944,
      "e": 91644,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 88429, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 88436, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17286, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 107058, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11461, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"PAPA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 119527, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9729, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 130353, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11798, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 143155, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 27542, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 172081, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-3-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1212,y:809,t:1527620749096};\\\", \\\"{x:1212,y:808,t:1527620749112};\\\", \\\"{x:1212,y:807,t:1527620749144};\\\", \\\"{x:1211,y:806,t:1527620749226};\\\", \\\"{x:1210,y:805,t:1527620749241};\\\", \\\"{x:1209,y:805,t:1527620749252};\\\", \\\"{x:1207,y:804,t:1527620749269};\\\", \\\"{x:1206,y:804,t:1527620749289};\\\", \\\"{x:1206,y:803,t:1527620749302};\\\", \\\"{x:1199,y:802,t:1527620749318};\\\", \\\"{x:1191,y:801,t:1527620749336};\\\", \\\"{x:1184,y:801,t:1527620749352};\\\", \\\"{x:1178,y:801,t:1527620749369};\\\", \\\"{x:1170,y:803,t:1527620749385};\\\", \\\"{x:1165,y:805,t:1527620749404};\\\", \\\"{x:1162,y:807,t:1527620749418};\\\", \\\"{x:1160,y:808,t:1527620749436};\\\", \\\"{x:1158,y:810,t:1527620749452};\\\", \\\"{x:1155,y:816,t:1527620749469};\\\", \\\"{x:1152,y:820,t:1527620749485};\\\", \\\"{x:1149,y:827,t:1527620749502};\\\", \\\"{x:1147,y:833,t:1527620749519};\\\", \\\"{x:1143,y:838,t:1527620749535};\\\", \\\"{x:1143,y:843,t:1527620749553};\\\", \\\"{x:1144,y:849,t:1527620749569};\\\", \\\"{x:1148,y:856,t:1527620749586};\\\", \\\"{x:1155,y:867,t:1527620749604};\\\", \\\"{x:1164,y:876,t:1527620749619};\\\", \\\"{x:1182,y:887,t:1527620749636};\\\", \\\"{x:1200,y:899,t:1527620749653};\\\", \\\"{x:1219,y:911,t:1527620749669};\\\", \\\"{x:1236,y:924,t:1527620749686};\\\", \\\"{x:1255,y:931,t:1527620749702};\\\", \\\"{x:1267,y:941,t:1527620749719};\\\", \\\"{x:1281,y:948,t:1527620749736};\\\", \\\"{x:1289,y:950,t:1527620749753};\\\", \\\"{x:1290,y:950,t:1527620749769};\\\", \\\"{x:1290,y:951,t:1527620749962};\\\", \\\"{x:1290,y:952,t:1527620749977};\\\", \\\"{x:1290,y:953,t:1527620749986};\\\", \\\"{x:1289,y:954,t:1527620750025};\\\", \\\"{x:1289,y:956,t:1527620750036};\\\", \\\"{x:1288,y:958,t:1527620750052};\\\", \\\"{x:1287,y:960,t:1527620750070};\\\", \\\"{x:1287,y:962,t:1527620750086};\\\", \\\"{x:1286,y:964,t:1527620750103};\\\", \\\"{x:1286,y:965,t:1527620750120};\\\", \\\"{x:1285,y:966,t:1527620750136};\\\", \\\"{x:1285,y:968,t:1527620750153};\\\", \\\"{x:1285,y:969,t:1527620750170};\\\", \\\"{x:1283,y:970,t:1527620750186};\\\", \\\"{x:1283,y:972,t:1527620750204};\\\", \\\"{x:1283,y:971,t:1527620751281};\\\", \\\"{x:1283,y:969,t:1527620751289};\\\", \\\"{x:1283,y:968,t:1527620751328};\\\", \\\"{x:1283,y:967,t:1527620751400};\\\", \\\"{x:1283,y:966,t:1527620751473};\\\", \\\"{x:1283,y:964,t:1527620751713};\\\", \\\"{x:1283,y:962,t:1527620751753};\\\", \\\"{x:1283,y:960,t:1527620751771};\\\", \\\"{x:1283,y:959,t:1527620751841};\\\", \\\"{x:1283,y:956,t:1527620751954};\\\", \\\"{x:1283,y:955,t:1527620751985};\\\", \\\"{x:1284,y:953,t:1527620752002};\\\", \\\"{x:1284,y:952,t:1527620752113};\\\", \\\"{x:1284,y:951,t:1527620752153};\\\", \\\"{x:1284,y:950,t:1527620752177};\\\", \\\"{x:1284,y:949,t:1527620752250};\\\", \\\"{x:1284,y:948,t:1527620752281};\\\", \\\"{x:1284,y:947,t:1527620752345};\\\", \\\"{x:1284,y:946,t:1527620752409};\\\", \\\"{x:1286,y:943,t:1527620752432};\\\", \\\"{x:1287,y:942,t:1527620752456};\\\", \\\"{x:1287,y:941,t:1527620752505};\\\", \\\"{x:1287,y:940,t:1527620752544};\\\", \\\"{x:1287,y:939,t:1527620752577};\\\", \\\"{x:1287,y:938,t:1527620752593};\\\", \\\"{x:1288,y:938,t:1527620752604};\\\", \\\"{x:1288,y:937,t:1527620752697};\\\", \\\"{x:1288,y:936,t:1527620752737};\\\", \\\"{x:1288,y:935,t:1527620752769};\\\", \\\"{x:1288,y:934,t:1527620752785};\\\", \\\"{x:1288,y:933,t:1527620752803};\\\", \\\"{x:1288,y:932,t:1527620752825};\\\", \\\"{x:1288,y:930,t:1527620752849};\\\", \\\"{x:1288,y:929,t:1527620752857};\\\", \\\"{x:1288,y:928,t:1527620752873};\\\", \\\"{x:1288,y:927,t:1527620752888};\\\", \\\"{x:1288,y:925,t:1527620752904};\\\", \\\"{x:1288,y:924,t:1527620752922};\\\", \\\"{x:1288,y:923,t:1527620752938};\\\", \\\"{x:1288,y:921,t:1527620752977};\\\", \\\"{x:1289,y:920,t:1527620753003};\\\", \\\"{x:1289,y:919,t:1527620753009};\\\", \\\"{x:1289,y:918,t:1527620753021};\\\", \\\"{x:1289,y:917,t:1527620753048};\\\", \\\"{x:1289,y:916,t:1527620753136};\\\", \\\"{x:1289,y:915,t:1527620753144};\\\", \\\"{x:1289,y:914,t:1527620753154};\\\", \\\"{x:1289,y:912,t:1527620753171};\\\", \\\"{x:1289,y:910,t:1527620753187};\\\", \\\"{x:1289,y:909,t:1527620753208};\\\", \\\"{x:1287,y:906,t:1527620753221};\\\", \\\"{x:1285,y:904,t:1527620753237};\\\", \\\"{x:1285,y:901,t:1527620753255};\\\", \\\"{x:1283,y:898,t:1527620753272};\\\", \\\"{x:1277,y:889,t:1527620753288};\\\", \\\"{x:1277,y:886,t:1527620753305};\\\", \\\"{x:1274,y:880,t:1527620753321};\\\", \\\"{x:1273,y:877,t:1527620753338};\\\", \\\"{x:1270,y:873,t:1527620753355};\\\", \\\"{x:1270,y:869,t:1527620753372};\\\", \\\"{x:1267,y:865,t:1527620753388};\\\", \\\"{x:1266,y:862,t:1527620753405};\\\", \\\"{x:1265,y:859,t:1527620753421};\\\", \\\"{x:1264,y:856,t:1527620753439};\\\", \\\"{x:1262,y:852,t:1527620753454};\\\", \\\"{x:1261,y:849,t:1527620753471};\\\", \\\"{x:1259,y:844,t:1527620753488};\\\", \\\"{x:1259,y:840,t:1527620753504};\\\", \\\"{x:1258,y:837,t:1527620753521};\\\", \\\"{x:1258,y:834,t:1527620753539};\\\", \\\"{x:1258,y:833,t:1527620753561};\\\", \\\"{x:1256,y:832,t:1527620753572};\\\", \\\"{x:1256,y:831,t:1527620753592};\\\", \\\"{x:1256,y:830,t:1527620753604};\\\", \\\"{x:1256,y:828,t:1527620753622};\\\", \\\"{x:1256,y:826,t:1527620753638};\\\", \\\"{x:1257,y:824,t:1527620753655};\\\", \\\"{x:1257,y:823,t:1527620753671};\\\", \\\"{x:1258,y:820,t:1527620753688};\\\", \\\"{x:1259,y:819,t:1527620753705};\\\", \\\"{x:1259,y:818,t:1527620753736};\\\", \\\"{x:1259,y:817,t:1527620753768};\\\", \\\"{x:1259,y:816,t:1527620753776};\\\", \\\"{x:1260,y:816,t:1527620753792};\\\", \\\"{x:1261,y:814,t:1527620753808};\\\", \\\"{x:1262,y:814,t:1527620753848};\\\", \\\"{x:1263,y:813,t:1527620753864};\\\", \\\"{x:1264,y:812,t:1527620754003};\\\", \\\"{x:1263,y:812,t:1527620757762};\\\", \\\"{x:1261,y:812,t:1527620757776};\\\", \\\"{x:1254,y:812,t:1527620757793};\\\", \\\"{x:1248,y:810,t:1527620757808};\\\", \\\"{x:1221,y:800,t:1527620757825};\\\", \\\"{x:1200,y:793,t:1527620757843};\\\", \\\"{x:1186,y:787,t:1527620757858};\\\", \\\"{x:1175,y:784,t:1527620757875};\\\", \\\"{x:1167,y:781,t:1527620757892};\\\", \\\"{x:1166,y:781,t:1527620757908};\\\", \\\"{x:1163,y:780,t:1527620757925};\\\", \\\"{x:1151,y:779,t:1527620757943};\\\", \\\"{x:1141,y:778,t:1527620757958};\\\", \\\"{x:1133,y:775,t:1527620757975};\\\", \\\"{x:1122,y:773,t:1527620757992};\\\", \\\"{x:1109,y:771,t:1527620758009};\\\", \\\"{x:1092,y:765,t:1527620758025};\\\", \\\"{x:1074,y:762,t:1527620758042};\\\", \\\"{x:1061,y:760,t:1527620758059};\\\", \\\"{x:1039,y:756,t:1527620758076};\\\", \\\"{x:1023,y:751,t:1527620758092};\\\", \\\"{x:1009,y:747,t:1527620758109};\\\", \\\"{x:998,y:747,t:1527620758125};\\\", \\\"{x:988,y:745,t:1527620758143};\\\", \\\"{x:984,y:743,t:1527620758159};\\\", \\\"{x:976,y:742,t:1527620758175};\\\", \\\"{x:965,y:738,t:1527620758193};\\\", \\\"{x:945,y:736,t:1527620758207};\\\", \\\"{x:933,y:727,t:1527620758224};\\\", \\\"{x:918,y:718,t:1527620758241};\\\", \\\"{x:909,y:718,t:1527620758258};\\\", \\\"{x:905,y:717,t:1527620758274};\\\", \\\"{x:902,y:717,t:1527620758825};\\\", \\\"{x:902,y:716,t:1527620758977};\\\", \\\"{x:901,y:716,t:1527620760449};\\\", \\\"{x:901,y:715,t:1527620760936};\\\", \\\"{x:902,y:715,t:1527620760952};\\\", \\\"{x:906,y:715,t:1527620761008};\\\", \\\"{x:909,y:715,t:1527620761015};\\\", \\\"{x:914,y:715,t:1527620761026};\\\", \\\"{x:923,y:715,t:1527620761044};\\\", \\\"{x:937,y:716,t:1527620761060};\\\", \\\"{x:962,y:720,t:1527620761076};\\\", \\\"{x:990,y:729,t:1527620761094};\\\", \\\"{x:1014,y:738,t:1527620761110};\\\", \\\"{x:1053,y:746,t:1527620761127};\\\", \\\"{x:1106,y:762,t:1527620761144};\\\", \\\"{x:1206,y:780,t:1527620761161};\\\", \\\"{x:1270,y:796,t:1527620761177};\\\", \\\"{x:1298,y:805,t:1527620761194};\\\", \\\"{x:1324,y:815,t:1527620761211};\\\", \\\"{x:1347,y:818,t:1527620761227};\\\", \\\"{x:1356,y:820,t:1527620761244};\\\", \\\"{x:1357,y:820,t:1527620761261};\\\", \\\"{x:1358,y:821,t:1527620761277};\\\", \\\"{x:1357,y:821,t:1527620761352};\\\", \\\"{x:1353,y:821,t:1527620761359};\\\", \\\"{x:1336,y:824,t:1527620761378};\\\", \\\"{x:1317,y:824,t:1527620761393};\\\", \\\"{x:1306,y:824,t:1527620761411};\\\", \\\"{x:1300,y:824,t:1527620761428};\\\", \\\"{x:1299,y:824,t:1527620761444};\\\", \\\"{x:1297,y:824,t:1527620761520};\\\", \\\"{x:1293,y:824,t:1527620761553};\\\", \\\"{x:1291,y:824,t:1527620761560};\\\", \\\"{x:1283,y:828,t:1527620761580};\\\", \\\"{x:1275,y:832,t:1527620761594};\\\", \\\"{x:1260,y:839,t:1527620761611};\\\", \\\"{x:1246,y:847,t:1527620761628};\\\", \\\"{x:1236,y:851,t:1527620761643};\\\", \\\"{x:1227,y:854,t:1527620761661};\\\", \\\"{x:1223,y:856,t:1527620761678};\\\", \\\"{x:1221,y:856,t:1527620761694};\\\", \\\"{x:1222,y:856,t:1527620761825};\\\", \\\"{x:1226,y:856,t:1527620761833};\\\", \\\"{x:1233,y:855,t:1527620761844};\\\", \\\"{x:1241,y:852,t:1527620761861};\\\", \\\"{x:1241,y:849,t:1527620761878};\\\", \\\"{x:1249,y:847,t:1527620761895};\\\", \\\"{x:1253,y:844,t:1527620761910};\\\", \\\"{x:1257,y:844,t:1527620761929};\\\", \\\"{x:1259,y:842,t:1527620761944};\\\", \\\"{x:1260,y:842,t:1527620761977};\\\", \\\"{x:1261,y:842,t:1527620761985};\\\", \\\"{x:1261,y:841,t:1527620761995};\\\", \\\"{x:1262,y:841,t:1527620762011};\\\", \\\"{x:1265,y:839,t:1527620762028};\\\", \\\"{x:1268,y:837,t:1527620762045};\\\", \\\"{x:1269,y:837,t:1527620762061};\\\", \\\"{x:1270,y:837,t:1527620762097};\\\", \\\"{x:1270,y:835,t:1527620762121};\\\", \\\"{x:1270,y:833,t:1527620762129};\\\", \\\"{x:1255,y:827,t:1527620762145};\\\", \\\"{x:1232,y:821,t:1527620762161};\\\", \\\"{x:1193,y:812,t:1527620762178};\\\", \\\"{x:1126,y:800,t:1527620762194};\\\", \\\"{x:1044,y:785,t:1527620762210};\\\", \\\"{x:969,y:772,t:1527620762228};\\\", \\\"{x:903,y:757,t:1527620762245};\\\", \\\"{x:859,y:747,t:1527620762260};\\\", \\\"{x:820,y:735,t:1527620762278};\\\", \\\"{x:772,y:722,t:1527620762295};\\\", \\\"{x:738,y:711,t:1527620762311};\\\", \\\"{x:707,y:701,t:1527620762328};\\\", \\\"{x:679,y:686,t:1527620762344};\\\", \\\"{x:633,y:676,t:1527620762362};\\\", \\\"{x:593,y:662,t:1527620762378};\\\", \\\"{x:537,y:644,t:1527620762396};\\\", \\\"{x:461,y:620,t:1527620762413};\\\", \\\"{x:382,y:588,t:1527620762428};\\\", \\\"{x:262,y:519,t:1527620762463};\\\", \\\"{x:233,y:504,t:1527620762480};\\\", \\\"{x:224,y:497,t:1527620762495};\\\", \\\"{x:223,y:497,t:1527620762512};\\\", \\\"{x:227,y:498,t:1527620762737};\\\", \\\"{x:236,y:500,t:1527620762746};\\\", \\\"{x:261,y:509,t:1527620762764};\\\", \\\"{x:286,y:515,t:1527620762779};\\\", \\\"{x:314,y:523,t:1527620762796};\\\", \\\"{x:336,y:528,t:1527620762812};\\\", \\\"{x:346,y:529,t:1527620762829};\\\", \\\"{x:349,y:529,t:1527620762846};\\\", \\\"{x:352,y:530,t:1527620763065};\\\", \\\"{x:355,y:530,t:1527620763081};\\\", \\\"{x:359,y:530,t:1527620763096};\\\", \\\"{x:362,y:530,t:1527620763114};\\\", \\\"{x:364,y:530,t:1527620763130};\\\", \\\"{x:365,y:530,t:1527620763147};\\\", \\\"{x:367,y:528,t:1527620767841};\\\", \\\"{x:368,y:527,t:1527620767851};\\\", \\\"{x:373,y:526,t:1527620767868};\\\", \\\"{x:375,y:525,t:1527620767885};\\\", \\\"{x:376,y:525,t:1527620767901};\\\", \\\"{x:377,y:525,t:1527620767967};\\\", \\\"{x:380,y:523,t:1527620768337};\\\", \\\"{x:380,y:522,t:1527620768361};\\\", \\\"{x:382,y:521,t:1527620768368};\\\", \\\"{x:385,y:519,t:1527620768385};\\\", \\\"{x:386,y:518,t:1527620768403};\\\", \\\"{x:387,y:517,t:1527620768418};\\\", \\\"{x:387,y:516,t:1527620768435};\\\", \\\"{x:388,y:516,t:1527620768452};\\\", \\\"{x:390,y:515,t:1527620768469};\\\", \\\"{x:390,y:514,t:1527620768485};\\\", \\\"{x:391,y:513,t:1527620768512};\\\", \\\"{x:392,y:512,t:1527620768569};\\\", \\\"{x:394,y:511,t:1527620769553};\\\", \\\"{x:402,y:508,t:1527620769569};\\\", \\\"{x:416,y:507,t:1527620769585};\\\", \\\"{x:431,y:505,t:1527620769603};\\\", \\\"{x:452,y:501,t:1527620769619};\\\", \\\"{x:475,y:501,t:1527620769635};\\\", \\\"{x:501,y:501,t:1527620769652};\\\", \\\"{x:545,y:501,t:1527620769669};\\\", \\\"{x:609,y:501,t:1527620769685};\\\", \\\"{x:677,y:500,t:1527620769702};\\\", \\\"{x:752,y:500,t:1527620769719};\\\", \\\"{x:828,y:513,t:1527620769736};\\\", \\\"{x:923,y:532,t:1527620769753};\\\", \\\"{x:964,y:540,t:1527620769769};\\\", \\\"{x:986,y:546,t:1527620769786};\\\", \\\"{x:1000,y:551,t:1527620769802};\\\", \\\"{x:1011,y:556,t:1527620769819};\\\", \\\"{x:1014,y:558,t:1527620769835};\\\", \\\"{x:1019,y:559,t:1527620769852};\\\", \\\"{x:1022,y:561,t:1527620769869};\\\", \\\"{x:1024,y:561,t:1527620769885};\\\", \\\"{x:1029,y:562,t:1527620769903};\\\", \\\"{x:1042,y:569,t:1527620769920};\\\", \\\"{x:1059,y:577,t:1527620769935};\\\", \\\"{x:1078,y:583,t:1527620769953};\\\", \\\"{x:1093,y:589,t:1527620769970};\\\", \\\"{x:1104,y:593,t:1527620769986};\\\", \\\"{x:1108,y:596,t:1527620770003};\\\", \\\"{x:1109,y:597,t:1527620770033};\\\", \\\"{x:1109,y:599,t:1527620770049};\\\", \\\"{x:1111,y:599,t:1527620770056};\\\", \\\"{x:1112,y:600,t:1527620770069};\\\", \\\"{x:1115,y:602,t:1527620770087};\\\", \\\"{x:1124,y:609,t:1527620770103};\\\", \\\"{x:1134,y:613,t:1527620770119};\\\", \\\"{x:1150,y:621,t:1527620770136};\\\", \\\"{x:1159,y:626,t:1527620770152};\\\", \\\"{x:1168,y:632,t:1527620770170};\\\", \\\"{x:1173,y:634,t:1527620770186};\\\", \\\"{x:1180,y:640,t:1527620770203};\\\", \\\"{x:1184,y:641,t:1527620770220};\\\", \\\"{x:1188,y:645,t:1527620770237};\\\", \\\"{x:1192,y:648,t:1527620770253};\\\", \\\"{x:1202,y:657,t:1527620770270};\\\", \\\"{x:1211,y:666,t:1527620770287};\\\", \\\"{x:1221,y:674,t:1527620770303};\\\", \\\"{x:1233,y:686,t:1527620770320};\\\", \\\"{x:1247,y:700,t:1527620770337};\\\", \\\"{x:1255,y:713,t:1527620770353};\\\", \\\"{x:1261,y:720,t:1527620770370};\\\", \\\"{x:1264,y:726,t:1527620770387};\\\", \\\"{x:1269,y:732,t:1527620770404};\\\", \\\"{x:1270,y:735,t:1527620770419};\\\", \\\"{x:1272,y:740,t:1527620770437};\\\", \\\"{x:1274,y:745,t:1527620770454};\\\", \\\"{x:1277,y:754,t:1527620770470};\\\", \\\"{x:1278,y:762,t:1527620770486};\\\", \\\"{x:1281,y:769,t:1527620770504};\\\", \\\"{x:1281,y:775,t:1527620770520};\\\", \\\"{x:1281,y:786,t:1527620770537};\\\", \\\"{x:1281,y:793,t:1527620770553};\\\", \\\"{x:1281,y:797,t:1527620770569};\\\", \\\"{x:1281,y:802,t:1527620770586};\\\", \\\"{x:1281,y:808,t:1527620770603};\\\", \\\"{x:1281,y:811,t:1527620770620};\\\", \\\"{x:1281,y:813,t:1527620770637};\\\", \\\"{x:1281,y:814,t:1527620770654};\\\", \\\"{x:1282,y:816,t:1527620770669};\\\", \\\"{x:1282,y:817,t:1527620770689};\\\", \\\"{x:1282,y:819,t:1527620770704};\\\", \\\"{x:1282,y:822,t:1527620770719};\\\", \\\"{x:1284,y:829,t:1527620770737};\\\", \\\"{x:1284,y:831,t:1527620770754};\\\", \\\"{x:1284,y:832,t:1527620770770};\\\", \\\"{x:1284,y:833,t:1527620770809};\\\", \\\"{x:1284,y:834,t:1527620770832};\\\", \\\"{x:1284,y:835,t:1527620770856};\\\", \\\"{x:1284,y:836,t:1527620771161};\\\", \\\"{x:1284,y:837,t:1527620771170};\\\", \\\"{x:1280,y:840,t:1527620771187};\\\", \\\"{x:1274,y:844,t:1527620771204};\\\", \\\"{x:1271,y:846,t:1527620771220};\\\", \\\"{x:1269,y:847,t:1527620771237};\\\", \\\"{x:1269,y:848,t:1527620771253};\\\", \\\"{x:1266,y:849,t:1527620771270};\\\", \\\"{x:1266,y:850,t:1527620771288};\\\", \\\"{x:1265,y:851,t:1527620771303};\\\", \\\"{x:1265,y:853,t:1527620771352};\\\", \\\"{x:1265,y:855,t:1527620771360};\\\", \\\"{x:1265,y:856,t:1527620771370};\\\", \\\"{x:1265,y:861,t:1527620771387};\\\", \\\"{x:1266,y:867,t:1527620771403};\\\", \\\"{x:1266,y:868,t:1527620771421};\\\", \\\"{x:1267,y:874,t:1527620771437};\\\", \\\"{x:1267,y:879,t:1527620771453};\\\", \\\"{x:1268,y:883,t:1527620771471};\\\", \\\"{x:1271,y:887,t:1527620771487};\\\", \\\"{x:1271,y:893,t:1527620771503};\\\", \\\"{x:1271,y:900,t:1527620771520};\\\", \\\"{x:1271,y:905,t:1527620771537};\\\", \\\"{x:1271,y:910,t:1527620771553};\\\", \\\"{x:1271,y:916,t:1527620771571};\\\", \\\"{x:1271,y:918,t:1527620771587};\\\", \\\"{x:1271,y:920,t:1527620771603};\\\", \\\"{x:1273,y:922,t:1527620771620};\\\", \\\"{x:1274,y:923,t:1527620771640};\\\", \\\"{x:1274,y:925,t:1527620771654};\\\", \\\"{x:1274,y:926,t:1527620771671};\\\", \\\"{x:1274,y:930,t:1527620771688};\\\", \\\"{x:1274,y:934,t:1527620771705};\\\", \\\"{x:1274,y:935,t:1527620771721};\\\", \\\"{x:1274,y:937,t:1527620771738};\\\", \\\"{x:1273,y:938,t:1527620771784};\\\", \\\"{x:1273,y:935,t:1527620772121};\\\", \\\"{x:1273,y:927,t:1527620772138};\\\", \\\"{x:1273,y:925,t:1527620772155};\\\", \\\"{x:1276,y:919,t:1527620772172};\\\", \\\"{x:1279,y:915,t:1527620772192};\\\", \\\"{x:1280,y:914,t:1527620772273};\\\", \\\"{x:1280,y:913,t:1527620772289};\\\", \\\"{x:1280,y:907,t:1527620772305};\\\", \\\"{x:1268,y:890,t:1527620772321};\\\", \\\"{x:1240,y:871,t:1527620772338};\\\", \\\"{x:1200,y:851,t:1527620772355};\\\", \\\"{x:1136,y:833,t:1527620772372};\\\", \\\"{x:1085,y:824,t:1527620772388};\\\", \\\"{x:1051,y:814,t:1527620772404};\\\", \\\"{x:1012,y:805,t:1527620772421};\\\", \\\"{x:982,y:798,t:1527620772437};\\\", \\\"{x:954,y:792,t:1527620772454};\\\", \\\"{x:932,y:786,t:1527620772470};\\\", \\\"{x:912,y:778,t:1527620772487};\\\", \\\"{x:875,y:771,t:1527620772504};\\\", \\\"{x:825,y:763,t:1527620772521};\\\", \\\"{x:789,y:756,t:1527620772538};\\\", \\\"{x:754,y:750,t:1527620772554};\\\", \\\"{x:730,y:745,t:1527620772570};\\\", \\\"{x:712,y:743,t:1527620772588};\\\", \\\"{x:689,y:740,t:1527620772603};\\\", \\\"{x:675,y:732,t:1527620772620};\\\", \\\"{x:661,y:729,t:1527620772638};\\\", \\\"{x:647,y:727,t:1527620772654};\\\", \\\"{x:633,y:724,t:1527620772671};\\\", \\\"{x:594,y:716,t:1527620772688};\\\", \\\"{x:571,y:709,t:1527620772704};\\\", \\\"{x:564,y:707,t:1527620772724};\\\", \\\"{x:558,y:705,t:1527620772738};\\\", \\\"{x:555,y:704,t:1527620772753};\\\", \\\"{x:554,y:704,t:1527620772807};\\\", \\\"{x:553,y:704,t:1527620772821};\\\", \\\"{x:550,y:706,t:1527620772838};\\\", \\\"{x:544,y:710,t:1527620772854};\\\", \\\"{x:543,y:714,t:1527620772871};\\\", \\\"{x:541,y:716,t:1527620772888};\\\", \\\"{x:540,y:717,t:1527620772904};\\\", \\\"{x:541,y:718,t:1527620773280};\\\", \\\"{x:543,y:718,t:1527620773288};\\\", \\\"{x:560,y:716,t:1527620773305};\\\", \\\"{x:573,y:712,t:1527620773321};\\\", \\\"{x:581,y:712,t:1527620773338};\\\", \\\"{x:599,y:712,t:1527620773355};\\\", \\\"{x:620,y:712,t:1527620773372};\\\", \\\"{x:639,y:714,t:1527620773388};\\\", \\\"{x:665,y:714,t:1527620773405};\\\", \\\"{x:691,y:715,t:1527620773422};\\\", \\\"{x:710,y:715,t:1527620773438};\\\", \\\"{x:737,y:715,t:1527620773455};\\\", \\\"{x:784,y:715,t:1527620773472};\\\", \\\"{x:800,y:715,t:1527620773488};\\\", \\\"{x:825,y:715,t:1527620773505};\\\", \\\"{x:835,y:715,t:1527620773522};\\\", \\\"{x:849,y:715,t:1527620773538};\\\", \\\"{x:859,y:715,t:1527620773555};\\\", \\\"{x:863,y:715,t:1527620773572};\\\", \\\"{x:864,y:715,t:1527620773777};\\\" ] }, { \\\"rt\\\": 16058, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 189425, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:871,y:712,t:1527620775752};\\\", \\\"{x:882,y:704,t:1527620775767};\\\", \\\"{x:900,y:700,t:1527620775776};\\\", \\\"{x:907,y:697,t:1527620775790};\\\", \\\"{x:931,y:692,t:1527620775807};\\\", \\\"{x:948,y:690,t:1527620775823};\\\", \\\"{x:998,y:680,t:1527620775840};\\\", \\\"{x:1032,y:680,t:1527620775857};\\\", \\\"{x:1093,y:680,t:1527620775874};\\\", \\\"{x:1171,y:680,t:1527620775890};\\\", \\\"{x:1252,y:680,t:1527620775907};\\\", \\\"{x:1321,y:680,t:1527620775925};\\\", \\\"{x:1368,y:680,t:1527620775940};\\\", \\\"{x:1403,y:678,t:1527620775957};\\\", \\\"{x:1431,y:674,t:1527620775974};\\\", \\\"{x:1449,y:674,t:1527620775990};\\\", \\\"{x:1467,y:673,t:1527620776007};\\\", \\\"{x:1491,y:668,t:1527620776024};\\\", \\\"{x:1497,y:667,t:1527620776041};\\\", \\\"{x:1503,y:665,t:1527620776057};\\\", \\\"{x:1505,y:665,t:1527620776074};\\\", \\\"{x:1505,y:664,t:1527620776090};\\\", \\\"{x:1506,y:664,t:1527620776108};\\\", \\\"{x:1507,y:663,t:1527620776125};\\\", \\\"{x:1508,y:663,t:1527620776140};\\\", \\\"{x:1509,y:661,t:1527620776158};\\\", \\\"{x:1511,y:657,t:1527620776177};\\\", \\\"{x:1511,y:655,t:1527620776190};\\\", \\\"{x:1513,y:647,t:1527620776208};\\\", \\\"{x:1514,y:636,t:1527620776224};\\\", \\\"{x:1515,y:622,t:1527620776241};\\\", \\\"{x:1513,y:609,t:1527620776259};\\\", \\\"{x:1511,y:603,t:1527620776274};\\\", \\\"{x:1507,y:590,t:1527620776291};\\\", \\\"{x:1502,y:579,t:1527620776308};\\\", \\\"{x:1497,y:569,t:1527620776325};\\\", \\\"{x:1493,y:563,t:1527620776342};\\\", \\\"{x:1491,y:560,t:1527620776358};\\\", \\\"{x:1489,y:558,t:1527620776375};\\\", \\\"{x:1488,y:557,t:1527620776391};\\\", \\\"{x:1488,y:556,t:1527620776513};\\\", \\\"{x:1489,y:556,t:1527620776525};\\\", \\\"{x:1495,y:556,t:1527620776542};\\\", \\\"{x:1512,y:559,t:1527620776557};\\\", \\\"{x:1530,y:563,t:1527620776574};\\\", \\\"{x:1543,y:569,t:1527620776592};\\\", \\\"{x:1554,y:572,t:1527620776608};\\\", \\\"{x:1561,y:575,t:1527620776625};\\\", \\\"{x:1564,y:578,t:1527620776641};\\\", \\\"{x:1565,y:584,t:1527620776658};\\\", \\\"{x:1570,y:598,t:1527620776675};\\\", \\\"{x:1576,y:627,t:1527620776692};\\\", \\\"{x:1583,y:656,t:1527620776708};\\\", \\\"{x:1588,y:698,t:1527620776725};\\\", \\\"{x:1592,y:749,t:1527620776742};\\\", \\\"{x:1592,y:773,t:1527620776758};\\\", \\\"{x:1587,y:795,t:1527620776774};\\\", \\\"{x:1572,y:819,t:1527620776792};\\\", \\\"{x:1554,y:845,t:1527620776808};\\\", \\\"{x:1539,y:866,t:1527620776824};\\\", \\\"{x:1531,y:879,t:1527620776841};\\\", \\\"{x:1517,y:895,t:1527620776859};\\\", \\\"{x:1505,y:908,t:1527620776874};\\\", \\\"{x:1493,y:917,t:1527620776892};\\\", \\\"{x:1487,y:921,t:1527620776909};\\\", \\\"{x:1483,y:922,t:1527620776925};\\\", \\\"{x:1483,y:923,t:1527620776942};\\\", \\\"{x:1482,y:923,t:1527620776968};\\\", \\\"{x:1482,y:924,t:1527620776985};\\\", \\\"{x:1481,y:925,t:1527620776992};\\\", \\\"{x:1472,y:929,t:1527620777008};\\\", \\\"{x:1460,y:933,t:1527620777024};\\\", \\\"{x:1446,y:933,t:1527620777041};\\\", \\\"{x:1427,y:935,t:1527620777059};\\\", \\\"{x:1413,y:935,t:1527620777075};\\\", \\\"{x:1403,y:935,t:1527620777092};\\\", \\\"{x:1402,y:935,t:1527620777108};\\\", \\\"{x:1400,y:935,t:1527620777125};\\\", \\\"{x:1399,y:934,t:1527620777144};\\\", \\\"{x:1398,y:933,t:1527620777159};\\\", \\\"{x:1398,y:931,t:1527620777175};\\\", \\\"{x:1396,y:926,t:1527620777191};\\\", \\\"{x:1395,y:914,t:1527620777208};\\\", \\\"{x:1395,y:899,t:1527620777226};\\\", \\\"{x:1396,y:889,t:1527620777241};\\\", \\\"{x:1404,y:878,t:1527620777259};\\\", \\\"{x:1414,y:864,t:1527620777276};\\\", \\\"{x:1432,y:850,t:1527620777292};\\\", \\\"{x:1447,y:836,t:1527620777309};\\\", \\\"{x:1457,y:827,t:1527620777326};\\\", \\\"{x:1467,y:819,t:1527620777341};\\\", \\\"{x:1476,y:808,t:1527620777359};\\\", \\\"{x:1486,y:786,t:1527620777377};\\\", \\\"{x:1487,y:780,t:1527620777392};\\\", \\\"{x:1491,y:768,t:1527620777409};\\\", \\\"{x:1491,y:762,t:1527620777426};\\\", \\\"{x:1489,y:755,t:1527620777441};\\\", \\\"{x:1486,y:747,t:1527620777459};\\\", \\\"{x:1482,y:742,t:1527620777476};\\\", \\\"{x:1481,y:737,t:1527620777491};\\\", \\\"{x:1476,y:727,t:1527620777508};\\\", \\\"{x:1470,y:715,t:1527620777525};\\\", \\\"{x:1466,y:710,t:1527620777542};\\\", \\\"{x:1459,y:699,t:1527620777558};\\\", \\\"{x:1446,y:687,t:1527620777578};\\\", \\\"{x:1438,y:682,t:1527620777593};\\\", \\\"{x:1425,y:678,t:1527620777609};\\\", \\\"{x:1416,y:677,t:1527620777626};\\\", \\\"{x:1408,y:675,t:1527620777642};\\\", \\\"{x:1405,y:673,t:1527620777659};\\\", \\\"{x:1400,y:673,t:1527620777676};\\\", \\\"{x:1398,y:672,t:1527620777693};\\\", \\\"{x:1397,y:671,t:1527620777708};\\\", \\\"{x:1396,y:671,t:1527620777726};\\\", \\\"{x:1394,y:669,t:1527620777742};\\\", \\\"{x:1390,y:663,t:1527620777759};\\\", \\\"{x:1384,y:654,t:1527620777777};\\\", \\\"{x:1382,y:650,t:1527620777792};\\\", \\\"{x:1381,y:640,t:1527620777808};\\\", \\\"{x:1381,y:633,t:1527620777826};\\\", \\\"{x:1381,y:623,t:1527620777843};\\\", \\\"{x:1385,y:613,t:1527620777859};\\\", \\\"{x:1403,y:601,t:1527620777875};\\\", \\\"{x:1428,y:590,t:1527620777893};\\\", \\\"{x:1456,y:585,t:1527620777909};\\\", \\\"{x:1487,y:585,t:1527620777925};\\\", \\\"{x:1538,y:585,t:1527620777943};\\\", \\\"{x:1560,y:592,t:1527620777959};\\\", \\\"{x:1601,y:606,t:1527620777977};\\\", \\\"{x:1622,y:612,t:1527620777993};\\\", \\\"{x:1627,y:612,t:1527620778008};\\\", \\\"{x:1629,y:612,t:1527620778026};\\\", \\\"{x:1630,y:612,t:1527620778043};\\\", \\\"{x:1632,y:612,t:1527620778065};\\\", \\\"{x:1633,y:611,t:1527620778076};\\\", \\\"{x:1635,y:611,t:1527620778096};\\\", \\\"{x:1637,y:609,t:1527620778120};\\\", \\\"{x:1641,y:607,t:1527620778129};\\\", \\\"{x:1641,y:606,t:1527620778142};\\\", \\\"{x:1645,y:600,t:1527620778160};\\\", \\\"{x:1651,y:594,t:1527620778175};\\\", \\\"{x:1658,y:586,t:1527620778193};\\\", \\\"{x:1662,y:582,t:1527620778210};\\\", \\\"{x:1664,y:574,t:1527620778225};\\\", \\\"{x:1665,y:570,t:1527620778243};\\\", \\\"{x:1666,y:563,t:1527620778260};\\\", \\\"{x:1666,y:559,t:1527620778276};\\\", \\\"{x:1664,y:549,t:1527620778292};\\\", \\\"{x:1661,y:541,t:1527620778310};\\\", \\\"{x:1659,y:536,t:1527620778325};\\\", \\\"{x:1658,y:533,t:1527620778342};\\\", \\\"{x:1657,y:531,t:1527620778360};\\\", \\\"{x:1656,y:530,t:1527620778378};\\\", \\\"{x:1656,y:529,t:1527620778392};\\\", \\\"{x:1655,y:527,t:1527620778410};\\\", \\\"{x:1651,y:522,t:1527620778427};\\\", \\\"{x:1648,y:517,t:1527620778442};\\\", \\\"{x:1645,y:511,t:1527620778460};\\\", \\\"{x:1641,y:502,t:1527620778476};\\\", \\\"{x:1635,y:493,t:1527620778493};\\\", \\\"{x:1631,y:484,t:1527620778509};\\\", \\\"{x:1629,y:479,t:1527620778527};\\\", \\\"{x:1626,y:472,t:1527620778543};\\\", \\\"{x:1625,y:469,t:1527620778560};\\\", \\\"{x:1622,y:466,t:1527620778577};\\\", \\\"{x:1622,y:464,t:1527620778592};\\\", \\\"{x:1622,y:461,t:1527620778609};\\\", \\\"{x:1620,y:458,t:1527620778627};\\\", \\\"{x:1620,y:456,t:1527620778643};\\\", \\\"{x:1620,y:454,t:1527620778660};\\\", \\\"{x:1620,y:452,t:1527620778677};\\\", \\\"{x:1620,y:449,t:1527620778705};\\\", \\\"{x:1619,y:448,t:1527620778729};\\\", \\\"{x:1618,y:448,t:1527620778752};\\\", \\\"{x:1618,y:447,t:1527620778778};\\\", \\\"{x:1618,y:445,t:1527620778800};\\\", \\\"{x:1616,y:443,t:1527620778841};\\\", \\\"{x:1616,y:442,t:1527620778857};\\\", \\\"{x:1616,y:441,t:1527620778881};\\\", \\\"{x:1615,y:441,t:1527620778893};\\\", \\\"{x:1614,y:440,t:1527620778910};\\\", \\\"{x:1613,y:440,t:1527620778937};\\\", \\\"{x:1613,y:439,t:1527620778968};\\\", \\\"{x:1612,y:439,t:1527620778984};\\\", \\\"{x:1612,y:438,t:1527620779008};\\\", \\\"{x:1612,y:437,t:1527620779048};\\\", \\\"{x:1611,y:437,t:1527620779065};\\\", \\\"{x:1611,y:436,t:1527620779129};\\\", \\\"{x:1611,y:435,t:1527620779264};\\\", \\\"{x:1611,y:436,t:1527620779295};\\\", \\\"{x:1612,y:439,t:1527620779309};\\\", \\\"{x:1612,y:443,t:1527620779327};\\\", \\\"{x:1614,y:450,t:1527620779343};\\\", \\\"{x:1615,y:457,t:1527620779360};\\\", \\\"{x:1616,y:462,t:1527620779376};\\\", \\\"{x:1616,y:467,t:1527620779393};\\\", \\\"{x:1618,y:473,t:1527620779410};\\\", \\\"{x:1620,y:478,t:1527620779426};\\\", \\\"{x:1622,y:484,t:1527620779443};\\\", \\\"{x:1622,y:488,t:1527620779461};\\\", \\\"{x:1622,y:496,t:1527620779477};\\\", \\\"{x:1621,y:506,t:1527620779494};\\\", \\\"{x:1618,y:514,t:1527620779510};\\\", \\\"{x:1618,y:518,t:1527620779526};\\\", \\\"{x:1618,y:521,t:1527620779544};\\\", \\\"{x:1618,y:525,t:1527620779560};\\\", \\\"{x:1618,y:526,t:1527620779577};\\\", \\\"{x:1618,y:531,t:1527620779593};\\\", \\\"{x:1618,y:535,t:1527620779611};\\\", \\\"{x:1618,y:536,t:1527620779627};\\\", \\\"{x:1618,y:537,t:1527620779644};\\\", \\\"{x:1618,y:538,t:1527620779697};\\\", \\\"{x:1618,y:539,t:1527620779736};\\\", \\\"{x:1618,y:540,t:1527620779761};\\\", \\\"{x:1619,y:540,t:1527620779784};\\\", \\\"{x:1619,y:541,t:1527620779794};\\\", \\\"{x:1619,y:542,t:1527620779816};\\\", \\\"{x:1619,y:544,t:1527620779828};\\\", \\\"{x:1619,y:546,t:1527620779843};\\\", \\\"{x:1621,y:548,t:1527620779861};\\\", \\\"{x:1622,y:550,t:1527620779878};\\\", \\\"{x:1622,y:552,t:1527620779894};\\\", \\\"{x:1623,y:553,t:1527620779911};\\\", \\\"{x:1623,y:555,t:1527620779936};\\\", \\\"{x:1623,y:556,t:1527620779945};\\\", \\\"{x:1623,y:557,t:1527620779961};\\\", \\\"{x:1623,y:558,t:1527620779977};\\\", \\\"{x:1623,y:559,t:1527620779994};\\\", \\\"{x:1624,y:560,t:1527620780011};\\\", \\\"{x:1625,y:561,t:1527620780028};\\\", \\\"{x:1626,y:562,t:1527620780044};\\\", \\\"{x:1626,y:563,t:1527620780060};\\\", \\\"{x:1627,y:563,t:1527620780077};\\\", \\\"{x:1627,y:564,t:1527620780093};\\\", \\\"{x:1628,y:566,t:1527620780110};\\\", \\\"{x:1628,y:567,t:1527620780128};\\\", \\\"{x:1628,y:568,t:1527620780143};\\\", \\\"{x:1628,y:570,t:1527620780160};\\\", \\\"{x:1628,y:571,t:1527620780199};\\\", \\\"{x:1626,y:574,t:1527620780430};\\\", \\\"{x:1625,y:575,t:1527620780534};\\\", \\\"{x:1624,y:576,t:1527620780550};\\\", \\\"{x:1623,y:577,t:1527620780558};\\\", \\\"{x:1622,y:578,t:1527620780575};\\\", \\\"{x:1621,y:579,t:1527620780593};\\\", \\\"{x:1620,y:581,t:1527620780608};\\\", \\\"{x:1620,y:582,t:1527620780625};\\\", \\\"{x:1618,y:585,t:1527620780642};\\\", \\\"{x:1617,y:589,t:1527620780658};\\\", \\\"{x:1614,y:593,t:1527620780675};\\\", \\\"{x:1614,y:598,t:1527620780692};\\\", \\\"{x:1613,y:601,t:1527620780709};\\\", \\\"{x:1611,y:606,t:1527620780725};\\\", \\\"{x:1610,y:609,t:1527620780742};\\\", \\\"{x:1609,y:613,t:1527620780759};\\\", \\\"{x:1607,y:615,t:1527620780782};\\\", \\\"{x:1607,y:617,t:1527620780797};\\\", \\\"{x:1607,y:619,t:1527620780809};\\\", \\\"{x:1607,y:620,t:1527620780825};\\\", \\\"{x:1607,y:621,t:1527620780845};\\\", \\\"{x:1607,y:623,t:1527620780860};\\\", \\\"{x:1606,y:626,t:1527620780876};\\\", \\\"{x:1605,y:628,t:1527620780892};\\\", \\\"{x:1605,y:630,t:1527620780908};\\\", \\\"{x:1604,y:633,t:1527620780925};\\\", \\\"{x:1604,y:636,t:1527620780941};\\\", \\\"{x:1604,y:638,t:1527620780959};\\\", \\\"{x:1604,y:641,t:1527620780974};\\\", \\\"{x:1604,y:643,t:1527620780992};\\\", \\\"{x:1604,y:644,t:1527620781009};\\\", \\\"{x:1604,y:645,t:1527620781025};\\\", \\\"{x:1604,y:648,t:1527620781042};\\\", \\\"{x:1604,y:651,t:1527620781058};\\\", \\\"{x:1607,y:656,t:1527620781075};\\\", \\\"{x:1607,y:659,t:1527620781091};\\\", \\\"{x:1609,y:665,t:1527620781109};\\\", \\\"{x:1611,y:670,t:1527620781124};\\\", \\\"{x:1612,y:676,t:1527620781142};\\\", \\\"{x:1613,y:682,t:1527620781158};\\\", \\\"{x:1615,y:688,t:1527620781175};\\\", \\\"{x:1616,y:697,t:1527620781192};\\\", \\\"{x:1618,y:706,t:1527620781209};\\\", \\\"{x:1620,y:711,t:1527620781226};\\\", \\\"{x:1620,y:713,t:1527620781242};\\\", \\\"{x:1621,y:716,t:1527620781259};\\\", \\\"{x:1622,y:717,t:1527620781301};\\\", \\\"{x:1623,y:713,t:1527620781710};\\\", \\\"{x:1623,y:697,t:1527620781729};\\\", \\\"{x:1623,y:680,t:1527620781743};\\\", \\\"{x:1623,y:669,t:1527620781758};\\\", \\\"{x:1623,y:655,t:1527620781775};\\\", \\\"{x:1622,y:641,t:1527620781792};\\\", \\\"{x:1619,y:631,t:1527620781808};\\\", \\\"{x:1616,y:624,t:1527620781825};\\\", \\\"{x:1614,y:618,t:1527620781842};\\\", \\\"{x:1612,y:614,t:1527620781859};\\\", \\\"{x:1610,y:609,t:1527620781876};\\\", \\\"{x:1609,y:600,t:1527620781893};\\\", \\\"{x:1609,y:594,t:1527620781908};\\\", \\\"{x:1605,y:588,t:1527620781925};\\\", \\\"{x:1604,y:578,t:1527620781942};\\\", \\\"{x:1602,y:570,t:1527620781959};\\\", \\\"{x:1602,y:561,t:1527620781976};\\\", \\\"{x:1602,y:554,t:1527620781993};\\\", \\\"{x:1606,y:548,t:1527620782009};\\\", \\\"{x:1609,y:543,t:1527620782026};\\\", \\\"{x:1612,y:538,t:1527620782042};\\\", \\\"{x:1613,y:534,t:1527620782150};\\\", \\\"{x:1615,y:533,t:1527620782181};\\\", \\\"{x:1615,y:532,t:1527620782197};\\\", \\\"{x:1617,y:530,t:1527620782209};\\\", \\\"{x:1618,y:529,t:1527620782228};\\\", \\\"{x:1619,y:528,t:1527620782317};\\\", \\\"{x:1620,y:528,t:1527620782325};\\\", \\\"{x:1621,y:564,t:1527620782343};\\\", \\\"{x:1629,y:622,t:1527620782360};\\\", \\\"{x:1628,y:701,t:1527620782376};\\\", \\\"{x:1628,y:759,t:1527620782393};\\\", \\\"{x:1628,y:793,t:1527620782410};\\\", \\\"{x:1629,y:821,t:1527620782427};\\\", \\\"{x:1631,y:851,t:1527620782442};\\\", \\\"{x:1631,y:874,t:1527620782459};\\\", \\\"{x:1625,y:894,t:1527620782477};\\\", \\\"{x:1622,y:900,t:1527620782493};\\\", \\\"{x:1619,y:906,t:1527620782510};\\\", \\\"{x:1619,y:907,t:1527620782526};\\\", \\\"{x:1619,y:909,t:1527620782543};\\\", \\\"{x:1618,y:910,t:1527620782565};\\\", \\\"{x:1617,y:913,t:1527620782589};\\\", \\\"{x:1616,y:913,t:1527620782605};\\\", \\\"{x:1615,y:914,t:1527620782613};\\\", \\\"{x:1615,y:915,t:1527620782627};\\\", \\\"{x:1614,y:919,t:1527620782643};\\\", \\\"{x:1611,y:924,t:1527620782660};\\\", \\\"{x:1610,y:933,t:1527620782677};\\\", \\\"{x:1610,y:938,t:1527620782693};\\\", \\\"{x:1610,y:940,t:1527620782709};\\\", \\\"{x:1610,y:942,t:1527620782727};\\\", \\\"{x:1609,y:947,t:1527620782743};\\\", \\\"{x:1608,y:949,t:1527620782760};\\\", \\\"{x:1608,y:953,t:1527620782777};\\\", \\\"{x:1608,y:957,t:1527620782792};\\\", \\\"{x:1608,y:959,t:1527620782810};\\\", \\\"{x:1608,y:961,t:1527620782827};\\\", \\\"{x:1609,y:962,t:1527620782949};\\\", \\\"{x:1610,y:962,t:1527620783078};\\\", \\\"{x:1611,y:962,t:1527620783134};\\\", \\\"{x:1612,y:961,t:1527620783182};\\\", \\\"{x:1613,y:961,t:1527620783254};\\\", \\\"{x:1614,y:960,t:1527620783311};\\\", \\\"{x:1616,y:958,t:1527620783462};\\\", \\\"{x:1618,y:954,t:1527620783477};\\\", \\\"{x:1618,y:949,t:1527620783493};\\\", \\\"{x:1618,y:941,t:1527620783511};\\\", \\\"{x:1618,y:928,t:1527620783527};\\\", \\\"{x:1618,y:917,t:1527620783545};\\\", \\\"{x:1618,y:909,t:1527620783561};\\\", \\\"{x:1618,y:897,t:1527620783577};\\\", \\\"{x:1619,y:883,t:1527620783594};\\\", \\\"{x:1622,y:863,t:1527620783611};\\\", \\\"{x:1622,y:839,t:1527620783628};\\\", \\\"{x:1623,y:810,t:1527620783644};\\\", \\\"{x:1623,y:770,t:1527620783662};\\\", \\\"{x:1620,y:745,t:1527620783678};\\\", \\\"{x:1620,y:722,t:1527620783694};\\\", \\\"{x:1620,y:695,t:1527620783711};\\\", \\\"{x:1623,y:677,t:1527620783727};\\\", \\\"{x:1629,y:665,t:1527620783744};\\\", \\\"{x:1633,y:646,t:1527620783761};\\\", \\\"{x:1637,y:628,t:1527620783778};\\\", \\\"{x:1639,y:611,t:1527620783794};\\\", \\\"{x:1643,y:593,t:1527620783811};\\\", \\\"{x:1645,y:578,t:1527620783828};\\\", \\\"{x:1649,y:560,t:1527620783844};\\\", \\\"{x:1649,y:547,t:1527620783861};\\\", \\\"{x:1655,y:529,t:1527620783878};\\\", \\\"{x:1658,y:524,t:1527620783894};\\\", \\\"{x:1658,y:522,t:1527620783911};\\\", \\\"{x:1658,y:521,t:1527620783928};\\\", \\\"{x:1659,y:518,t:1527620784030};\\\", \\\"{x:1659,y:510,t:1527620784045};\\\", \\\"{x:1656,y:486,t:1527620784061};\\\", \\\"{x:1651,y:476,t:1527620784078};\\\", \\\"{x:1644,y:466,t:1527620784094};\\\", \\\"{x:1641,y:462,t:1527620784111};\\\", \\\"{x:1639,y:461,t:1527620784128};\\\", \\\"{x:1639,y:460,t:1527620784158};\\\", \\\"{x:1638,y:460,t:1527620784222};\\\", \\\"{x:1636,y:460,t:1527620784230};\\\", \\\"{x:1632,y:455,t:1527620784245};\\\", \\\"{x:1628,y:452,t:1527620784262};\\\", \\\"{x:1613,y:448,t:1527620784277};\\\", \\\"{x:1603,y:445,t:1527620784295};\\\", \\\"{x:1592,y:441,t:1527620784311};\\\", \\\"{x:1589,y:438,t:1527620784328};\\\", \\\"{x:1586,y:438,t:1527620784345};\\\", \\\"{x:1585,y:437,t:1527620784361};\\\", \\\"{x:1582,y:435,t:1527620784379};\\\", \\\"{x:1581,y:434,t:1527620784422};\\\", \\\"{x:1581,y:433,t:1527620784469};\\\", \\\"{x:1583,y:431,t:1527620784478};\\\", \\\"{x:1591,y:428,t:1527620784496};\\\", \\\"{x:1599,y:424,t:1527620784511};\\\", \\\"{x:1599,y:422,t:1527620784528};\\\", \\\"{x:1600,y:421,t:1527620784545};\\\", \\\"{x:1601,y:421,t:1527620784646};\\\", \\\"{x:1602,y:421,t:1527620784662};\\\", \\\"{x:1603,y:421,t:1527620784734};\\\", \\\"{x:1604,y:421,t:1527620784750};\\\", \\\"{x:1605,y:421,t:1527620784797};\\\", \\\"{x:1606,y:421,t:1527620784814};\\\", \\\"{x:1606,y:422,t:1527620784829};\\\", \\\"{x:1607,y:422,t:1527620784845};\\\", \\\"{x:1607,y:423,t:1527620784869};\\\", \\\"{x:1609,y:424,t:1527620784885};\\\", \\\"{x:1610,y:425,t:1527620784926};\\\", \\\"{x:1611,y:425,t:1527620784936};\\\", \\\"{x:1612,y:425,t:1527620784945};\\\", \\\"{x:1612,y:426,t:1527620784962};\\\", \\\"{x:1613,y:427,t:1527620785036};\\\", \\\"{x:1615,y:428,t:1527620785309};\\\", \\\"{x:1615,y:429,t:1527620785342};\\\", \\\"{x:1615,y:431,t:1527620785357};\\\", \\\"{x:1615,y:432,t:1527620785365};\\\", \\\"{x:1615,y:434,t:1527620785379};\\\", \\\"{x:1615,y:436,t:1527620785397};\\\", \\\"{x:1615,y:439,t:1527620785411};\\\", \\\"{x:1615,y:442,t:1527620785429};\\\", \\\"{x:1615,y:443,t:1527620785444};\\\", \\\"{x:1615,y:444,t:1527620785460};\\\", \\\"{x:1616,y:447,t:1527620785476};\\\", \\\"{x:1617,y:448,t:1527620785494};\\\", \\\"{x:1617,y:449,t:1527620785511};\\\", \\\"{x:1618,y:451,t:1527620785527};\\\", \\\"{x:1618,y:452,t:1527620785544};\\\", \\\"{x:1618,y:453,t:1527620785561};\\\", \\\"{x:1618,y:455,t:1527620785577};\\\", \\\"{x:1618,y:457,t:1527620785594};\\\", \\\"{x:1617,y:459,t:1527620785613};\\\", \\\"{x:1617,y:460,t:1527620785629};\\\", \\\"{x:1617,y:462,t:1527620785653};\\\", \\\"{x:1617,y:463,t:1527620785669};\\\", \\\"{x:1617,y:465,t:1527620785684};\\\", \\\"{x:1617,y:466,t:1527620785709};\\\", \\\"{x:1617,y:468,t:1527620785725};\\\", \\\"{x:1617,y:469,t:1527620785765};\\\", \\\"{x:1617,y:470,t:1527620785777};\\\", \\\"{x:1617,y:472,t:1527620785797};\\\", \\\"{x:1617,y:474,t:1527620785821};\\\", \\\"{x:1617,y:475,t:1527620785829};\\\", \\\"{x:1617,y:476,t:1527620785846};\\\", \\\"{x:1617,y:478,t:1527620785862};\\\", \\\"{x:1617,y:481,t:1527620785877};\\\", \\\"{x:1617,y:485,t:1527620785894};\\\", \\\"{x:1617,y:489,t:1527620785910};\\\", \\\"{x:1619,y:495,t:1527620785929};\\\", \\\"{x:1620,y:501,t:1527620785945};\\\", \\\"{x:1620,y:504,t:1527620785963};\\\", \\\"{x:1621,y:509,t:1527620785979};\\\", \\\"{x:1622,y:511,t:1527620785996};\\\", \\\"{x:1623,y:514,t:1527620786013};\\\", \\\"{x:1623,y:518,t:1527620786029};\\\", \\\"{x:1623,y:523,t:1527620786046};\\\", \\\"{x:1622,y:527,t:1527620786063};\\\", \\\"{x:1622,y:528,t:1527620786080};\\\", \\\"{x:1621,y:532,t:1527620786095};\\\", \\\"{x:1620,y:532,t:1527620786113};\\\", \\\"{x:1620,y:533,t:1527620786133};\\\", \\\"{x:1619,y:535,t:1527620786174};\\\", \\\"{x:1618,y:538,t:1527620786181};\\\", \\\"{x:1618,y:539,t:1527620786197};\\\", \\\"{x:1618,y:540,t:1527620786221};\\\", \\\"{x:1618,y:541,t:1527620786229};\\\", \\\"{x:1618,y:542,t:1527620786269};\\\", \\\"{x:1618,y:543,t:1527620786280};\\\", \\\"{x:1618,y:544,t:1527620786296};\\\", \\\"{x:1618,y:545,t:1527620786317};\\\", \\\"{x:1618,y:546,t:1527620786334};\\\", \\\"{x:1618,y:547,t:1527620786346};\\\", \\\"{x:1618,y:548,t:1527620786362};\\\", \\\"{x:1618,y:551,t:1527620786379};\\\", \\\"{x:1618,y:552,t:1527620786413};\\\", \\\"{x:1618,y:553,t:1527620786430};\\\", \\\"{x:1618,y:553,t:1527620786607};\\\", \\\"{x:1618,y:554,t:1527620786701};\\\", \\\"{x:1619,y:553,t:1527620786717};\\\", \\\"{x:1623,y:549,t:1527620786731};\\\", \\\"{x:1629,y:544,t:1527620786747};\\\", \\\"{x:1641,y:537,t:1527620786764};\\\", \\\"{x:1649,y:530,t:1527620786781};\\\", \\\"{x:1664,y:522,t:1527620786797};\\\", \\\"{x:1676,y:515,t:1527620786814};\\\", \\\"{x:1683,y:510,t:1527620786830};\\\", \\\"{x:1693,y:502,t:1527620786848};\\\", \\\"{x:1702,y:496,t:1527620786863};\\\", \\\"{x:1712,y:488,t:1527620786880};\\\", \\\"{x:1716,y:485,t:1527620786897};\\\", \\\"{x:1718,y:483,t:1527620786913};\\\", \\\"{x:1720,y:482,t:1527620786930};\\\", \\\"{x:1714,y:486,t:1527620787149};\\\", \\\"{x:1709,y:491,t:1527620787163};\\\", \\\"{x:1687,y:510,t:1527620787180};\\\", \\\"{x:1663,y:531,t:1527620787196};\\\", \\\"{x:1628,y:547,t:1527620787213};\\\", \\\"{x:1564,y:568,t:1527620787230};\\\", \\\"{x:1483,y:590,t:1527620787247};\\\", \\\"{x:1380,y:612,t:1527620787264};\\\", \\\"{x:1239,y:649,t:1527620787280};\\\", \\\"{x:1126,y:680,t:1527620787297};\\\", \\\"{x:1026,y:706,t:1527620787313};\\\", \\\"{x:946,y:728,t:1527620787331};\\\", \\\"{x:881,y:742,t:1527620787347};\\\", \\\"{x:852,y:745,t:1527620787364};\\\", \\\"{x:817,y:739,t:1527620787380};\\\", \\\"{x:800,y:732,t:1527620787397};\\\", \\\"{x:796,y:729,t:1527620787414};\\\", \\\"{x:796,y:728,t:1527620787437};\\\", \\\"{x:795,y:728,t:1527620787446};\\\", \\\"{x:793,y:726,t:1527620787464};\\\", \\\"{x:792,y:720,t:1527620787481};\\\", \\\"{x:787,y:713,t:1527620787497};\\\", \\\"{x:780,y:700,t:1527620787514};\\\", \\\"{x:775,y:691,t:1527620787531};\\\", \\\"{x:769,y:679,t:1527620787547};\\\", \\\"{x:762,y:668,t:1527620787564};\\\", \\\"{x:750,y:645,t:1527620787581};\\\", \\\"{x:743,y:626,t:1527620787597};\\\", \\\"{x:739,y:616,t:1527620787614};\\\", \\\"{x:739,y:607,t:1527620787633};\\\", \\\"{x:745,y:599,t:1527620787648};\\\", \\\"{x:753,y:589,t:1527620787663};\\\", \\\"{x:766,y:577,t:1527620787681};\\\", \\\"{x:779,y:570,t:1527620787697};\\\", \\\"{x:784,y:565,t:1527620787713};\\\", \\\"{x:786,y:560,t:1527620787731};\\\", \\\"{x:793,y:555,t:1527620787747};\\\", \\\"{x:798,y:551,t:1527620787763};\\\", \\\"{x:801,y:550,t:1527620787780};\\\", \\\"{x:798,y:543,t:1527620787798};\\\", \\\"{x:787,y:538,t:1527620787813};\\\", \\\"{x:756,y:532,t:1527620787831};\\\", \\\"{x:694,y:531,t:1527620787848};\\\", \\\"{x:613,y:527,t:1527620787863};\\\", \\\"{x:520,y:521,t:1527620787881};\\\", \\\"{x:480,y:523,t:1527620787899};\\\", \\\"{x:455,y:529,t:1527620787914};\\\", \\\"{x:444,y:535,t:1527620787930};\\\", \\\"{x:442,y:537,t:1527620787948};\\\", \\\"{x:440,y:540,t:1527620787963};\\\", \\\"{x:433,y:549,t:1527620787981};\\\", \\\"{x:430,y:553,t:1527620787997};\\\", \\\"{x:426,y:561,t:1527620788013};\\\", \\\"{x:423,y:567,t:1527620788031};\\\", \\\"{x:419,y:574,t:1527620788048};\\\", \\\"{x:418,y:577,t:1527620788063};\\\", \\\"{x:417,y:580,t:1527620788080};\\\", \\\"{x:415,y:581,t:1527620788140};\\\", \\\"{x:408,y:581,t:1527620788148};\\\", \\\"{x:391,y:583,t:1527620788165};\\\", \\\"{x:374,y:587,t:1527620788181};\\\", \\\"{x:355,y:588,t:1527620788198};\\\", \\\"{x:347,y:588,t:1527620788215};\\\", \\\"{x:345,y:588,t:1527620788230};\\\", \\\"{x:343,y:588,t:1527620788247};\\\", \\\"{x:340,y:588,t:1527620788309};\\\", \\\"{x:339,y:588,t:1527620788325};\\\", \\\"{x:337,y:588,t:1527620788374};\\\", \\\"{x:336,y:588,t:1527620788382};\\\", \\\"{x:335,y:588,t:1527620788398};\\\", \\\"{x:331,y:586,t:1527620788415};\\\", \\\"{x:331,y:585,t:1527620788470};\\\", \\\"{x:330,y:585,t:1527620788501};\\\", \\\"{x:330,y:584,t:1527620788517};\\\", \\\"{x:330,y:583,t:1527620788582};\\\", \\\"{x:329,y:583,t:1527620788598};\\\", \\\"{x:330,y:581,t:1527620788655};\\\", \\\"{x:330,y:580,t:1527620788664};\\\", \\\"{x:334,y:579,t:1527620788682};\\\", \\\"{x:336,y:578,t:1527620788697};\\\", \\\"{x:327,y:578,t:1527620788878};\\\", \\\"{x:316,y:580,t:1527620788886};\\\", \\\"{x:304,y:584,t:1527620788900};\\\", \\\"{x:281,y:588,t:1527620788914};\\\", \\\"{x:260,y:590,t:1527620788932};\\\", \\\"{x:248,y:591,t:1527620788948};\\\", \\\"{x:230,y:591,t:1527620788964};\\\", \\\"{x:223,y:591,t:1527620788981};\\\", \\\"{x:218,y:593,t:1527620788997};\\\", \\\"{x:212,y:594,t:1527620789015};\\\", \\\"{x:205,y:594,t:1527620789031};\\\", \\\"{x:205,y:595,t:1527620789047};\\\", \\\"{x:203,y:596,t:1527620789064};\\\", \\\"{x:201,y:598,t:1527620789165};\\\", \\\"{x:199,y:601,t:1527620789182};\\\", \\\"{x:197,y:604,t:1527620789198};\\\", \\\"{x:193,y:611,t:1527620789215};\\\", \\\"{x:185,y:618,t:1527620789233};\\\", \\\"{x:179,y:623,t:1527620789250};\\\", \\\"{x:172,y:627,t:1527620789266};\\\", \\\"{x:170,y:630,t:1527620789282};\\\", \\\"{x:164,y:633,t:1527620789298};\\\", \\\"{x:164,y:634,t:1527620789612};\\\", \\\"{x:174,y:634,t:1527620789637};\\\", \\\"{x:179,y:634,t:1527620789648};\\\", \\\"{x:213,y:639,t:1527620789666};\\\", \\\"{x:242,y:645,t:1527620789682};\\\", \\\"{x:264,y:653,t:1527620789699};\\\", \\\"{x:278,y:659,t:1527620789716};\\\", \\\"{x:291,y:665,t:1527620789732};\\\", \\\"{x:318,y:676,t:1527620789749};\\\", \\\"{x:333,y:682,t:1527620789765};\\\", \\\"{x:353,y:690,t:1527620789782};\\\", \\\"{x:377,y:702,t:1527620789799};\\\", \\\"{x:404,y:716,t:1527620789816};\\\", \\\"{x:423,y:719,t:1527620789832};\\\", \\\"{x:446,y:728,t:1527620789849};\\\", \\\"{x:459,y:732,t:1527620789865};\\\", \\\"{x:469,y:734,t:1527620789882};\\\", \\\"{x:474,y:735,t:1527620789898};\\\", \\\"{x:475,y:735,t:1527620789916};\\\", \\\"{x:479,y:735,t:1527620789933};\\\", \\\"{x:484,y:735,t:1527620789949};\\\", \\\"{x:493,y:735,t:1527620789965};\\\", \\\"{x:508,y:735,t:1527620789983};\\\", \\\"{x:531,y:735,t:1527620789998};\\\", \\\"{x:554,y:739,t:1527620790017};\\\", \\\"{x:566,y:739,t:1527620790032};\\\", \\\"{x:565,y:737,t:1527620790133};\\\", \\\"{x:560,y:732,t:1527620790150};\\\", \\\"{x:556,y:728,t:1527620790166};\\\", \\\"{x:550,y:724,t:1527620790183};\\\", \\\"{x:549,y:722,t:1527620790200};\\\", \\\"{x:548,y:722,t:1527620790216};\\\", \\\"{x:554,y:722,t:1527620790789};\\\", \\\"{x:566,y:721,t:1527620790800};\\\", \\\"{x:595,y:721,t:1527620790817};\\\", \\\"{x:631,y:721,t:1527620790833};\\\", \\\"{x:664,y:720,t:1527620790850};\\\", \\\"{x:708,y:720,t:1527620790866};\\\", \\\"{x:747,y:720,t:1527620790883};\\\", \\\"{x:778,y:720,t:1527620790900};\\\", \\\"{x:860,y:720,t:1527620790917};\\\", \\\"{x:916,y:720,t:1527620790933};\\\", \\\"{x:966,y:720,t:1527620790950};\\\", \\\"{x:992,y:720,t:1527620790966};\\\", \\\"{x:1023,y:720,t:1527620790983};\\\", \\\"{x:1045,y:720,t:1527620791000};\\\", \\\"{x:1050,y:720,t:1527620791016};\\\", \\\"{x:1054,y:720,t:1527620791032};\\\", \\\"{x:1055,y:720,t:1527620791050};\\\", \\\"{x:1056,y:719,t:1527620791182};\\\" ] }, { \\\"rt\\\": 47752, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 238405, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1058,y:720,t:1527620794429};\\\", \\\"{x:1058,y:719,t:1527620794444};\\\", \\\"{x:1065,y:720,t:1527620794492};\\\", \\\"{x:1066,y:720,t:1527620794503};\\\", \\\"{x:1074,y:722,t:1527620794519};\\\", \\\"{x:1100,y:722,t:1527620794535};\\\", \\\"{x:1106,y:727,t:1527620794553};\\\", \\\"{x:1139,y:730,t:1527620794569};\\\", \\\"{x:1164,y:736,t:1527620794585};\\\", \\\"{x:1180,y:740,t:1527620794602};\\\", \\\"{x:1192,y:741,t:1527620794619};\\\", \\\"{x:1213,y:746,t:1527620794636};\\\", \\\"{x:1241,y:752,t:1527620794652};\\\", \\\"{x:1249,y:754,t:1527620794669};\\\", \\\"{x:1253,y:755,t:1527620794686};\\\", \\\"{x:1254,y:756,t:1527620794703};\\\", \\\"{x:1254,y:757,t:1527620794774};\\\", \\\"{x:1254,y:758,t:1527620794787};\\\", \\\"{x:1251,y:761,t:1527620794804};\\\", \\\"{x:1249,y:766,t:1527620794820};\\\", \\\"{x:1245,y:770,t:1527620794837};\\\", \\\"{x:1242,y:775,t:1527620794853};\\\", \\\"{x:1239,y:780,t:1527620794870};\\\", \\\"{x:1239,y:782,t:1527620794887};\\\", \\\"{x:1235,y:787,t:1527620794904};\\\", \\\"{x:1234,y:792,t:1527620794920};\\\", \\\"{x:1229,y:800,t:1527620794937};\\\", \\\"{x:1226,y:806,t:1527620794954};\\\", \\\"{x:1223,y:812,t:1527620794969};\\\", \\\"{x:1222,y:814,t:1527620794986};\\\", \\\"{x:1222,y:815,t:1527620795003};\\\", \\\"{x:1222,y:817,t:1527620795021};\\\", \\\"{x:1222,y:818,t:1527620795037};\\\", \\\"{x:1222,y:821,t:1527620795053};\\\", \\\"{x:1221,y:822,t:1527620795071};\\\", \\\"{x:1220,y:823,t:1527620795087};\\\", \\\"{x:1220,y:825,t:1527620795104};\\\", \\\"{x:1219,y:826,t:1527620795123};\\\", \\\"{x:1218,y:826,t:1527620795136};\\\", \\\"{x:1218,y:827,t:1527620795333};\\\", \\\"{x:1218,y:828,t:1527620795590};\\\", \\\"{x:1215,y:832,t:1527620801342};\\\", \\\"{x:1215,y:833,t:1527620801357};\\\", \\\"{x:1213,y:834,t:1527620801374};\\\", \\\"{x:1212,y:834,t:1527620801391};\\\", \\\"{x:1212,y:835,t:1527620801460};\\\", \\\"{x:1210,y:835,t:1527620801509};\\\", \\\"{x:1209,y:835,t:1527620801564};\\\", \\\"{x:1208,y:835,t:1527620801604};\\\", \\\"{x:1208,y:832,t:1527620802710};\\\", \\\"{x:1209,y:831,t:1527620802734};\\\", \\\"{x:1210,y:831,t:1527620802742};\\\", \\\"{x:1211,y:831,t:1527620802759};\\\", \\\"{x:1213,y:830,t:1527620802781};\\\", \\\"{x:1215,y:828,t:1527620802837};\\\", \\\"{x:1216,y:828,t:1527620802869};\\\", \\\"{x:1218,y:828,t:1527620802901};\\\", \\\"{x:1219,y:828,t:1527620802925};\\\", \\\"{x:1220,y:827,t:1527620802944};\\\", \\\"{x:1221,y:827,t:1527620803038};\\\", \\\"{x:1221,y:826,t:1527620803678};\\\", \\\"{x:1220,y:826,t:1527620803709};\\\", \\\"{x:1219,y:826,t:1527620803727};\\\", \\\"{x:1217,y:826,t:1527620803743};\\\", \\\"{x:1214,y:826,t:1527620803760};\\\", \\\"{x:1212,y:826,t:1527620803776};\\\", \\\"{x:1210,y:826,t:1527620803792};\\\", \\\"{x:1208,y:827,t:1527620803810};\\\", \\\"{x:1206,y:827,t:1527620803826};\\\", \\\"{x:1206,y:828,t:1527620804116};\\\", \\\"{x:1207,y:828,t:1527620804149};\\\", \\\"{x:1209,y:829,t:1527620804189};\\\", \\\"{x:1210,y:829,t:1527620804229};\\\", \\\"{x:1211,y:830,t:1527620804245};\\\", \\\"{x:1212,y:830,t:1527620804325};\\\", \\\"{x:1214,y:831,t:1527620804365};\\\", \\\"{x:1216,y:832,t:1527620804469};\\\", \\\"{x:1217,y:832,t:1527620804485};\\\", \\\"{x:1218,y:832,t:1527620804509};\\\", \\\"{x:1219,y:832,t:1527620804541};\\\", \\\"{x:1217,y:835,t:1527620806444};\\\", \\\"{x:1216,y:835,t:1527620806468};\\\", \\\"{x:1215,y:835,t:1527620806516};\\\", \\\"{x:1214,y:835,t:1527620806532};\\\", \\\"{x:1213,y:835,t:1527620806653};\\\", \\\"{x:1212,y:836,t:1527620807591};\\\", \\\"{x:1214,y:836,t:1527620813804};\\\", \\\"{x:1215,y:836,t:1527620813876};\\\", \\\"{x:1217,y:836,t:1527620813957};\\\", \\\"{x:1218,y:836,t:1527620815926};\\\", \\\"{x:1221,y:836,t:1527620825174};\\\", \\\"{x:1225,y:836,t:1527620825181};\\\", \\\"{x:1228,y:835,t:1527620825193};\\\", \\\"{x:1230,y:834,t:1527620825209};\\\", \\\"{x:1230,y:833,t:1527620825317};\\\", \\\"{x:1230,y:832,t:1527620825341};\\\", \\\"{x:1232,y:831,t:1527620825357};\\\", \\\"{x:1232,y:830,t:1527620825405};\\\", \\\"{x:1232,y:829,t:1527620825414};\\\", \\\"{x:1233,y:828,t:1527620825426};\\\", \\\"{x:1235,y:828,t:1527620825443};\\\", \\\"{x:1242,y:828,t:1527620825459};\\\", \\\"{x:1260,y:831,t:1527620825476};\\\", \\\"{x:1305,y:845,t:1527620825492};\\\", \\\"{x:1345,y:858,t:1527620825509};\\\", \\\"{x:1363,y:872,t:1527620825525};\\\", \\\"{x:1392,y:882,t:1527620825542};\\\", \\\"{x:1413,y:886,t:1527620825559};\\\", \\\"{x:1417,y:895,t:1527620825575};\\\", \\\"{x:1418,y:895,t:1527620825592};\\\", \\\"{x:1418,y:896,t:1527620825628};\\\", \\\"{x:1418,y:898,t:1527620825644};\\\", \\\"{x:1418,y:899,t:1527620825660};\\\", \\\"{x:1417,y:900,t:1527620825676};\\\", \\\"{x:1410,y:903,t:1527620825692};\\\", \\\"{x:1404,y:907,t:1527620825709};\\\", \\\"{x:1402,y:908,t:1527620825726};\\\", \\\"{x:1401,y:908,t:1527620825742};\\\", \\\"{x:1399,y:909,t:1527620825759};\\\", \\\"{x:1398,y:909,t:1527620825813};\\\", \\\"{x:1395,y:912,t:1527620825829};\\\", \\\"{x:1395,y:913,t:1527620825843};\\\", \\\"{x:1395,y:915,t:1527620825869};\\\", \\\"{x:1395,y:916,t:1527620825876};\\\", \\\"{x:1394,y:920,t:1527620825893};\\\", \\\"{x:1391,y:924,t:1527620825910};\\\", \\\"{x:1390,y:927,t:1527620825926};\\\", \\\"{x:1387,y:931,t:1527620825943};\\\", \\\"{x:1383,y:936,t:1527620825960};\\\", \\\"{x:1380,y:939,t:1527620825976};\\\", \\\"{x:1379,y:941,t:1527620825993};\\\", \\\"{x:1377,y:942,t:1527620826010};\\\", \\\"{x:1373,y:946,t:1527620826027};\\\", \\\"{x:1371,y:948,t:1527620826042};\\\", \\\"{x:1368,y:951,t:1527620826060};\\\", \\\"{x:1363,y:953,t:1527620826077};\\\", \\\"{x:1360,y:955,t:1527620826093};\\\", \\\"{x:1358,y:957,t:1527620826110};\\\", \\\"{x:1357,y:958,t:1527620826127};\\\", \\\"{x:1356,y:959,t:1527620826143};\\\", \\\"{x:1355,y:959,t:1527620826164};\\\", \\\"{x:1353,y:959,t:1527620826301};\\\", \\\"{x:1352,y:958,t:1527620826310};\\\", \\\"{x:1352,y:954,t:1527620826327};\\\", \\\"{x:1351,y:951,t:1527620826343};\\\", \\\"{x:1349,y:945,t:1527620826360};\\\", \\\"{x:1348,y:941,t:1527620826376};\\\", \\\"{x:1348,y:934,t:1527620826393};\\\", \\\"{x:1347,y:928,t:1527620826409};\\\", \\\"{x:1347,y:924,t:1527620826426};\\\", \\\"{x:1347,y:920,t:1527620826443};\\\", \\\"{x:1345,y:917,t:1527620826459};\\\", \\\"{x:1345,y:911,t:1527620826476};\\\", \\\"{x:1345,y:910,t:1527620826493};\\\", \\\"{x:1345,y:906,t:1527620826509};\\\", \\\"{x:1345,y:902,t:1527620826527};\\\", \\\"{x:1345,y:899,t:1527620826543};\\\", \\\"{x:1346,y:895,t:1527620826559};\\\", \\\"{x:1346,y:894,t:1527620826576};\\\", \\\"{x:1346,y:892,t:1527620826594};\\\", \\\"{x:1346,y:888,t:1527620826609};\\\", \\\"{x:1347,y:885,t:1527620826626};\\\", \\\"{x:1348,y:883,t:1527620826644};\\\", \\\"{x:1348,y:880,t:1527620826659};\\\", \\\"{x:1349,y:879,t:1527620826677};\\\", \\\"{x:1349,y:876,t:1527620826694};\\\", \\\"{x:1350,y:875,t:1527620826717};\\\", \\\"{x:1350,y:874,t:1527620826732};\\\", \\\"{x:1351,y:872,t:1527620826743};\\\", \\\"{x:1351,y:871,t:1527620826789};\\\", \\\"{x:1352,y:870,t:1527620826797};\\\", \\\"{x:1352,y:869,t:1527620826810};\\\", \\\"{x:1352,y:868,t:1527620826869};\\\", \\\"{x:1352,y:866,t:1527620826918};\\\", \\\"{x:1353,y:864,t:1527620826941};\\\", \\\"{x:1353,y:863,t:1527620826973};\\\", \\\"{x:1354,y:862,t:1527620826989};\\\", \\\"{x:1355,y:860,t:1527620827005};\\\", \\\"{x:1355,y:859,t:1527620827061};\\\", \\\"{x:1356,y:856,t:1527620827085};\\\", \\\"{x:1356,y:854,t:1527620827109};\\\", \\\"{x:1357,y:853,t:1527620827117};\\\", \\\"{x:1357,y:852,t:1527620827133};\\\", \\\"{x:1357,y:851,t:1527620827144};\\\", \\\"{x:1358,y:849,t:1527620827161};\\\", \\\"{x:1358,y:848,t:1527620827177};\\\", \\\"{x:1359,y:843,t:1527620827194};\\\", \\\"{x:1359,y:838,t:1527620827211};\\\", \\\"{x:1360,y:832,t:1527620827227};\\\", \\\"{x:1362,y:829,t:1527620827244};\\\", \\\"{x:1363,y:825,t:1527620827261};\\\", \\\"{x:1363,y:824,t:1527620827277};\\\", \\\"{x:1363,y:822,t:1527620827300};\\\", \\\"{x:1363,y:821,t:1527620827333};\\\", \\\"{x:1363,y:820,t:1527620827344};\\\", \\\"{x:1363,y:818,t:1527620827361};\\\", \\\"{x:1363,y:817,t:1527620827380};\\\", \\\"{x:1363,y:816,t:1527620827394};\\\", \\\"{x:1363,y:815,t:1527620827413};\\\", \\\"{x:1363,y:813,t:1527620827428};\\\", \\\"{x:1363,y:812,t:1527620827477};\\\", \\\"{x:1363,y:810,t:1527620827548};\\\", \\\"{x:1363,y:809,t:1527620827560};\\\", \\\"{x:1363,y:807,t:1527620827577};\\\", \\\"{x:1363,y:806,t:1527620827593};\\\", \\\"{x:1363,y:804,t:1527620827611};\\\", \\\"{x:1363,y:802,t:1527620827627};\\\", \\\"{x:1363,y:801,t:1527620827644};\\\", \\\"{x:1362,y:800,t:1527620827830};\\\", \\\"{x:1361,y:800,t:1527620828414};\\\", \\\"{x:1351,y:802,t:1527620828428};\\\", \\\"{x:1249,y:789,t:1527620828445};\\\", \\\"{x:1158,y:770,t:1527620828463};\\\", \\\"{x:1136,y:759,t:1527620828478};\\\", \\\"{x:1102,y:745,t:1527620828494};\\\", \\\"{x:1073,y:728,t:1527620828511};\\\", \\\"{x:1036,y:710,t:1527620828527};\\\", \\\"{x:972,y:684,t:1527620828544};\\\", \\\"{x:967,y:681,t:1527620828561};\\\", \\\"{x:964,y:681,t:1527620829061};\\\", \\\"{x:955,y:679,t:1527620829079};\\\", \\\"{x:946,y:676,t:1527620829095};\\\", \\\"{x:931,y:671,t:1527620829112};\\\", \\\"{x:921,y:669,t:1527620829129};\\\", \\\"{x:912,y:668,t:1527620829145};\\\", \\\"{x:895,y:665,t:1527620829162};\\\", \\\"{x:880,y:664,t:1527620829178};\\\", \\\"{x:866,y:661,t:1527620829195};\\\", \\\"{x:849,y:659,t:1527620829211};\\\", \\\"{x:819,y:656,t:1527620829229};\\\", \\\"{x:804,y:652,t:1527620829245};\\\", \\\"{x:789,y:651,t:1527620829262};\\\", \\\"{x:780,y:649,t:1527620829278};\\\", \\\"{x:770,y:646,t:1527620829295};\\\", \\\"{x:760,y:645,t:1527620829311};\\\", \\\"{x:740,y:642,t:1527620829329};\\\", \\\"{x:732,y:640,t:1527620829346};\\\", \\\"{x:715,y:640,t:1527620829364};\\\", \\\"{x:709,y:637,t:1527620829378};\\\", \\\"{x:696,y:634,t:1527620829395};\\\", \\\"{x:682,y:633,t:1527620829415};\\\", \\\"{x:673,y:632,t:1527620829431};\\\", \\\"{x:665,y:629,t:1527620829449};\\\", \\\"{x:662,y:628,t:1527620829465};\\\", \\\"{x:661,y:627,t:1527620829482};\\\", \\\"{x:658,y:627,t:1527620829498};\\\", \\\"{x:656,y:627,t:1527620829515};\\\", \\\"{x:652,y:627,t:1527620829532};\\\", \\\"{x:652,y:626,t:1527620829556};\\\", \\\"{x:652,y:625,t:1527620829572};\\\", \\\"{x:651,y:624,t:1527620829581};\\\", \\\"{x:651,y:626,t:1527620830028};\\\", \\\"{x:650,y:626,t:1527620830141};\\\", \\\"{x:648,y:626,t:1527620830156};\\\", \\\"{x:647,y:624,t:1527620830213};\\\", \\\"{x:643,y:623,t:1527620830221};\\\", \\\"{x:642,y:622,t:1527620830232};\\\", \\\"{x:641,y:621,t:1527620830249};\\\", \\\"{x:638,y:617,t:1527620830268};\\\", \\\"{x:627,y:617,t:1527620830282};\\\", \\\"{x:614,y:615,t:1527620830298};\\\", \\\"{x:607,y:614,t:1527620830316};\\\", \\\"{x:603,y:612,t:1527620830332};\\\", \\\"{x:603,y:611,t:1527620830364};\\\", \\\"{x:601,y:610,t:1527620830372};\\\", \\\"{x:600,y:610,t:1527620830382};\\\", \\\"{x:597,y:607,t:1527620830399};\\\", \\\"{x:587,y:604,t:1527620830416};\\\", \\\"{x:578,y:604,t:1527620830432};\\\", \\\"{x:571,y:602,t:1527620830450};\\\", \\\"{x:564,y:599,t:1527620830465};\\\", \\\"{x:563,y:599,t:1527620830482};\\\", \\\"{x:554,y:598,t:1527620830499};\\\", \\\"{x:550,y:596,t:1527620830515};\\\", \\\"{x:532,y:594,t:1527620830532};\\\", \\\"{x:527,y:593,t:1527620830549};\\\", \\\"{x:523,y:590,t:1527620830566};\\\", \\\"{x:512,y:587,t:1527620830582};\\\", \\\"{x:504,y:586,t:1527620830599};\\\", \\\"{x:500,y:584,t:1527620830615};\\\", \\\"{x:495,y:582,t:1527620830634};\\\", \\\"{x:488,y:579,t:1527620830649};\\\", \\\"{x:477,y:579,t:1527620830666};\\\", \\\"{x:474,y:579,t:1527620830683};\\\", \\\"{x:469,y:579,t:1527620830699};\\\", \\\"{x:463,y:579,t:1527620830716};\\\", \\\"{x:456,y:579,t:1527620830732};\\\", \\\"{x:453,y:579,t:1527620830749};\\\", \\\"{x:451,y:579,t:1527620830766};\\\", \\\"{x:450,y:579,t:1527620830783};\\\", \\\"{x:450,y:577,t:1527620830837};\\\", \\\"{x:448,y:577,t:1527620830849};\\\", \\\"{x:444,y:577,t:1527620830867};\\\", \\\"{x:442,y:578,t:1527620830884};\\\", \\\"{x:438,y:578,t:1527620830900};\\\", \\\"{x:436,y:578,t:1527620831805};\\\", \\\"{x:435,y:578,t:1527620831877};\\\", \\\"{x:433,y:578,t:1527620831884};\\\", \\\"{x:432,y:578,t:1527620831925};\\\", \\\"{x:428,y:579,t:1527620831940};\\\", \\\"{x:426,y:581,t:1527620831951};\\\", \\\"{x:420,y:583,t:1527620831969};\\\", \\\"{x:414,y:585,t:1527620831985};\\\", \\\"{x:409,y:586,t:1527620831998};\\\", \\\"{x:403,y:587,t:1527620832013};\\\", \\\"{x:397,y:587,t:1527620832030};\\\", \\\"{x:394,y:588,t:1527620832048};\\\", \\\"{x:390,y:589,t:1527620832063};\\\", \\\"{x:388,y:589,t:1527620832081};\\\", \\\"{x:385,y:589,t:1527620832096};\\\", \\\"{x:383,y:589,t:1527620832113};\\\", \\\"{x:381,y:591,t:1527620832130};\\\", \\\"{x:379,y:592,t:1527620832146};\\\", \\\"{x:374,y:593,t:1527620832164};\\\", \\\"{x:367,y:594,t:1527620832181};\\\", \\\"{x:366,y:594,t:1527620832204};\\\", \\\"{x:365,y:595,t:1527620832217};\\\", \\\"{x:363,y:595,t:1527620832233};\\\", \\\"{x:362,y:597,t:1527620832249};\\\", \\\"{x:360,y:598,t:1527620832266};\\\", \\\"{x:358,y:599,t:1527620832284};\\\", \\\"{x:355,y:602,t:1527620832299};\\\", \\\"{x:353,y:605,t:1527620832316};\\\", \\\"{x:348,y:609,t:1527620832333};\\\", \\\"{x:347,y:612,t:1527620832350};\\\", \\\"{x:344,y:615,t:1527620832367};\\\", \\\"{x:342,y:618,t:1527620832383};\\\", \\\"{x:340,y:620,t:1527620832401};\\\", \\\"{x:339,y:623,t:1527620832418};\\\", \\\"{x:337,y:624,t:1527620832433};\\\", \\\"{x:336,y:626,t:1527620832450};\\\", \\\"{x:335,y:628,t:1527620832468};\\\", \\\"{x:334,y:631,t:1527620832484};\\\", \\\"{x:333,y:632,t:1527620832501};\\\", \\\"{x:332,y:633,t:1527620832517};\\\", \\\"{x:331,y:634,t:1527620832534};\\\", \\\"{x:330,y:636,t:1527620832550};\\\", \\\"{x:329,y:637,t:1527620832568};\\\", \\\"{x:329,y:638,t:1527620832588};\\\", \\\"{x:328,y:639,t:1527620832604};\\\", \\\"{x:327,y:640,t:1527620832629};\\\", \\\"{x:327,y:643,t:1527620832644};\\\", \\\"{x:325,y:644,t:1527620832652};\\\", \\\"{x:325,y:646,t:1527620832668};\\\", \\\"{x:324,y:649,t:1527620832685};\\\", \\\"{x:323,y:650,t:1527620832708};\\\", \\\"{x:323,y:651,t:1527620832719};\\\", \\\"{x:322,y:652,t:1527620832734};\\\", \\\"{x:321,y:653,t:1527620832751};\\\", \\\"{x:321,y:655,t:1527620832767};\\\", \\\"{x:320,y:655,t:1527620832788};\\\", \\\"{x:320,y:656,t:1527620832812};\\\", \\\"{x:319,y:657,t:1527620832852};\\\", \\\"{x:319,y:658,t:1527620832876};\\\", \\\"{x:318,y:658,t:1527620832892};\\\", \\\"{x:318,y:659,t:1527620832981};\\\", \\\"{x:316,y:660,t:1527620833141};\\\", \\\"{x:314,y:662,t:1527620833301};\\\", \\\"{x:312,y:662,t:1527620833701};\\\", \\\"{x:311,y:662,t:1527620833821};\\\", \\\"{x:310,y:662,t:1527620833836};\\\", \\\"{x:309,y:662,t:1527620833877};\\\", \\\"{x:308,y:662,t:1527620833965};\\\", \\\"{x:307,y:662,t:1527620834013};\\\", \\\"{x:306,y:662,t:1527620834036};\\\", \\\"{x:305,y:662,t:1527620834197};\\\", \\\"{x:304,y:662,t:1527620834277};\\\", \\\"{x:304,y:656,t:1527620837397};\\\", \\\"{x:308,y:638,t:1527620837415};\\\", \\\"{x:312,y:626,t:1527620837430};\\\", \\\"{x:312,y:615,t:1527620837439};\\\", \\\"{x:312,y:603,t:1527620837455};\\\", \\\"{x:312,y:596,t:1527620837472};\\\", \\\"{x:313,y:590,t:1527620837488};\\\", \\\"{x:313,y:587,t:1527620837504};\\\", \\\"{x:313,y:586,t:1527620837522};\\\", \\\"{x:313,y:584,t:1527620837539};\\\", \\\"{x:312,y:584,t:1527620837555};\\\", \\\"{x:308,y:581,t:1527620837572};\\\", \\\"{x:306,y:580,t:1527620837588};\\\", \\\"{x:303,y:579,t:1527620837605};\\\", \\\"{x:297,y:579,t:1527620837622};\\\", \\\"{x:290,y:579,t:1527620837639};\\\", \\\"{x:273,y:577,t:1527620837655};\\\", \\\"{x:254,y:577,t:1527620837672};\\\", \\\"{x:230,y:577,t:1527620837689};\\\", \\\"{x:205,y:577,t:1527620837706};\\\", \\\"{x:191,y:577,t:1527620837722};\\\", \\\"{x:178,y:581,t:1527620837739};\\\", \\\"{x:177,y:581,t:1527620837837};\\\", \\\"{x:175,y:581,t:1527620837844};\\\", \\\"{x:172,y:581,t:1527620837856};\\\", \\\"{x:172,y:582,t:1527620837875};\\\", \\\"{x:171,y:582,t:1527620837916};\\\", \\\"{x:167,y:584,t:1527620837932};\\\", \\\"{x:165,y:586,t:1527620837948};\\\", \\\"{x:164,y:586,t:1527620837956};\\\", \\\"{x:164,y:585,t:1527620838028};\\\", \\\"{x:164,y:578,t:1527620838039};\\\", \\\"{x:164,y:567,t:1527620838057};\\\", \\\"{x:163,y:554,t:1527620838072};\\\", \\\"{x:163,y:551,t:1527620838089};\\\", \\\"{x:163,y:550,t:1527620838105};\\\", \\\"{x:170,y:556,t:1527620838476};\\\", \\\"{x:181,y:562,t:1527620838488};\\\", \\\"{x:204,y:572,t:1527620838506};\\\", \\\"{x:222,y:584,t:1527620838523};\\\", \\\"{x:246,y:599,t:1527620838538};\\\", \\\"{x:267,y:610,t:1527620838556};\\\", \\\"{x:270,y:611,t:1527620838572};\\\", \\\"{x:273,y:614,t:1527620838589};\\\", \\\"{x:273,y:615,t:1527620838605};\\\", \\\"{x:275,y:616,t:1527620838623};\\\", \\\"{x:281,y:619,t:1527620838638};\\\", \\\"{x:291,y:626,t:1527620838656};\\\", \\\"{x:313,y:639,t:1527620838673};\\\", \\\"{x:357,y:656,t:1527620838689};\\\", \\\"{x:381,y:667,t:1527620838705};\\\", \\\"{x:399,y:672,t:1527620838723};\\\", \\\"{x:420,y:678,t:1527620838739};\\\", \\\"{x:427,y:680,t:1527620838756};\\\", \\\"{x:428,y:684,t:1527620838989};\\\", \\\"{x:432,y:690,t:1527620838996};\\\", \\\"{x:434,y:692,t:1527620839006};\\\", \\\"{x:437,y:695,t:1527620839024};\\\", \\\"{x:438,y:695,t:1527620839085};\\\", \\\"{x:440,y:697,t:1527620839092};\\\", \\\"{x:444,y:698,t:1527620839106};\\\", \\\"{x:459,y:703,t:1527620839124};\\\", \\\"{x:481,y:713,t:1527620839140};\\\", \\\"{x:489,y:719,t:1527620839156};\\\", \\\"{x:492,y:720,t:1527620839172};\\\", \\\"{x:491,y:721,t:1527620839660};\\\", \\\"{x:482,y:722,t:1527620839673};\\\", \\\"{x:464,y:724,t:1527620839690};\\\", \\\"{x:433,y:728,t:1527620839707};\\\", \\\"{x:397,y:732,t:1527620839724};\\\", \\\"{x:379,y:733,t:1527620839740};\\\", \\\"{x:370,y:735,t:1527620839757};\\\", \\\"{x:368,y:735,t:1527620839774};\\\", \\\"{x:364,y:737,t:1527620839790};\\\", \\\"{x:362,y:737,t:1527620839807};\\\", \\\"{x:360,y:738,t:1527620839823};\\\", \\\"{x:354,y:738,t:1527620839840};\\\", \\\"{x:349,y:738,t:1527620839857};\\\", \\\"{x:346,y:738,t:1527620839874};\\\", \\\"{x:345,y:738,t:1527620839890};\\\", \\\"{x:344,y:738,t:1527620839916};\\\", \\\"{x:343,y:738,t:1527620839940};\\\", \\\"{x:341,y:736,t:1527620839972};\\\", \\\"{x:340,y:734,t:1527620839988};\\\", \\\"{x:339,y:734,t:1527620839996};\\\", \\\"{x:339,y:733,t:1527620840007};\\\", \\\"{x:337,y:730,t:1527620840024};\\\", \\\"{x:336,y:728,t:1527620840040};\\\", \\\"{x:336,y:727,t:1527620840060};\\\", \\\"{x:336,y:726,t:1527620840108};\\\", \\\"{x:336,y:725,t:1527620840132};\\\", \\\"{x:335,y:724,t:1527620840245};\\\" ] }, { \\\"rt\\\": 39575, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 279264, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -U -U -X -X -X -Z -Z -Z -F -F -U -U -U -F -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:335,y:723,t:1527620841867};\\\", \\\"{x:335,y:722,t:1527620841874};\\\", \\\"{x:336,y:719,t:1527620841890};\\\", \\\"{x:338,y:718,t:1527620841907};\\\", \\\"{x:345,y:714,t:1527620841924};\\\", \\\"{x:357,y:710,t:1527620841940};\\\", \\\"{x:376,y:703,t:1527620841958};\\\", \\\"{x:388,y:699,t:1527620841973};\\\", \\\"{x:407,y:699,t:1527620841990};\\\", \\\"{x:425,y:699,t:1527620842007};\\\", \\\"{x:455,y:699,t:1527620842023};\\\", \\\"{x:482,y:699,t:1527620842040};\\\", \\\"{x:503,y:699,t:1527620842057};\\\", \\\"{x:511,y:699,t:1527620842073};\\\", \\\"{x:543,y:697,t:1527620842090};\\\", \\\"{x:568,y:697,t:1527620842107};\\\", \\\"{x:595,y:700,t:1527620842123};\\\", \\\"{x:638,y:700,t:1527620842140};\\\", \\\"{x:696,y:707,t:1527620842157};\\\", \\\"{x:762,y:710,t:1527620842174};\\\", \\\"{x:822,y:717,t:1527620842190};\\\", \\\"{x:884,y:727,t:1527620842207};\\\", \\\"{x:946,y:735,t:1527620842223};\\\", \\\"{x:977,y:740,t:1527620842240};\\\", \\\"{x:1004,y:749,t:1527620842258};\\\", \\\"{x:1041,y:755,t:1527620842274};\\\", \\\"{x:1065,y:758,t:1527620842291};\\\", \\\"{x:1074,y:763,t:1527620842308};\\\", \\\"{x:1097,y:771,t:1527620842325};\\\", \\\"{x:1120,y:777,t:1527620842341};\\\", \\\"{x:1154,y:783,t:1527620842357};\\\", \\\"{x:1179,y:788,t:1527620842374};\\\", \\\"{x:1204,y:796,t:1527620842391};\\\", \\\"{x:1224,y:805,t:1527620842407};\\\", \\\"{x:1234,y:808,t:1527620842425};\\\", \\\"{x:1243,y:813,t:1527620842441};\\\", \\\"{x:1252,y:816,t:1527620842458};\\\", \\\"{x:1271,y:820,t:1527620842474};\\\", \\\"{x:1288,y:824,t:1527620842490};\\\", \\\"{x:1302,y:826,t:1527620842508};\\\", \\\"{x:1320,y:832,t:1527620842524};\\\", \\\"{x:1340,y:837,t:1527620842541};\\\", \\\"{x:1356,y:843,t:1527620842558};\\\", \\\"{x:1381,y:852,t:1527620842574};\\\", \\\"{x:1411,y:863,t:1527620842590};\\\", \\\"{x:1429,y:869,t:1527620842608};\\\", \\\"{x:1450,y:876,t:1527620842624};\\\", \\\"{x:1464,y:882,t:1527620842641};\\\", \\\"{x:1472,y:885,t:1527620842657};\\\", \\\"{x:1478,y:888,t:1527620842675};\\\", \\\"{x:1480,y:889,t:1527620842691};\\\", \\\"{x:1483,y:892,t:1527620842708};\\\", \\\"{x:1489,y:895,t:1527620842724};\\\", \\\"{x:1498,y:903,t:1527620842742};\\\", \\\"{x:1517,y:915,t:1527620842757};\\\", \\\"{x:1529,y:922,t:1527620842775};\\\", \\\"{x:1541,y:929,t:1527620842792};\\\", \\\"{x:1551,y:934,t:1527620842808};\\\", \\\"{x:1554,y:936,t:1527620842824};\\\", \\\"{x:1555,y:936,t:1527620842842};\\\", \\\"{x:1555,y:937,t:1527620842883};\\\", \\\"{x:1557,y:939,t:1527620842915};\\\", \\\"{x:1558,y:939,t:1527620842925};\\\", \\\"{x:1561,y:941,t:1527620842941};\\\", \\\"{x:1565,y:943,t:1527620842958};\\\", \\\"{x:1575,y:945,t:1527620842975};\\\", \\\"{x:1581,y:948,t:1527620842992};\\\", \\\"{x:1588,y:949,t:1527620843008};\\\", \\\"{x:1591,y:951,t:1527620843024};\\\", \\\"{x:1593,y:951,t:1527620843042};\\\", \\\"{x:1594,y:951,t:1527620843091};\\\", \\\"{x:1594,y:949,t:1527620843275};\\\", \\\"{x:1591,y:943,t:1527620843292};\\\", \\\"{x:1587,y:939,t:1527620843309};\\\", \\\"{x:1585,y:937,t:1527620843325};\\\", \\\"{x:1584,y:934,t:1527620843342};\\\", \\\"{x:1583,y:932,t:1527620843359};\\\", \\\"{x:1583,y:930,t:1527620843378};\\\", \\\"{x:1583,y:928,t:1527620843419};\\\", \\\"{x:1583,y:927,t:1527620843435};\\\", \\\"{x:1583,y:926,t:1527620843443};\\\", \\\"{x:1583,y:923,t:1527620843459};\\\", \\\"{x:1583,y:921,t:1527620843475};\\\", \\\"{x:1583,y:919,t:1527620843492};\\\", \\\"{x:1583,y:916,t:1527620843509};\\\", \\\"{x:1583,y:913,t:1527620843526};\\\", \\\"{x:1583,y:908,t:1527620843542};\\\", \\\"{x:1583,y:905,t:1527620843559};\\\", \\\"{x:1585,y:900,t:1527620843576};\\\", \\\"{x:1586,y:895,t:1527620843592};\\\", \\\"{x:1586,y:891,t:1527620843609};\\\", \\\"{x:1588,y:887,t:1527620843625};\\\", \\\"{x:1588,y:886,t:1527620843642};\\\", \\\"{x:1588,y:884,t:1527620843658};\\\", \\\"{x:1588,y:883,t:1527620843740};\\\", \\\"{x:1589,y:883,t:1527620843755};\\\", \\\"{x:1589,y:881,t:1527620843780};\\\", \\\"{x:1589,y:880,t:1527620843795};\\\", \\\"{x:1589,y:879,t:1527620843809};\\\", \\\"{x:1589,y:877,t:1527620843826};\\\", \\\"{x:1589,y:875,t:1527620843842};\\\", \\\"{x:1589,y:871,t:1527620843859};\\\", \\\"{x:1589,y:868,t:1527620843876};\\\", \\\"{x:1589,y:864,t:1527620843892};\\\", \\\"{x:1589,y:859,t:1527620843909};\\\", \\\"{x:1589,y:853,t:1527620843926};\\\", \\\"{x:1589,y:849,t:1527620843942};\\\", \\\"{x:1590,y:842,t:1527620843959};\\\", \\\"{x:1592,y:836,t:1527620843975};\\\", \\\"{x:1592,y:834,t:1527620843993};\\\", \\\"{x:1592,y:829,t:1527620844008};\\\", \\\"{x:1592,y:826,t:1527620844026};\\\", \\\"{x:1593,y:823,t:1527620844043};\\\", \\\"{x:1593,y:822,t:1527620844059};\\\", \\\"{x:1593,y:820,t:1527620844076};\\\", \\\"{x:1594,y:815,t:1527620844093};\\\", \\\"{x:1595,y:812,t:1527620844109};\\\", \\\"{x:1595,y:809,t:1527620844126};\\\", \\\"{x:1596,y:808,t:1527620844146};\\\", \\\"{x:1596,y:806,t:1527620844171};\\\", \\\"{x:1596,y:805,t:1527620844179};\\\", \\\"{x:1596,y:804,t:1527620844193};\\\", \\\"{x:1596,y:803,t:1527620844211};\\\", \\\"{x:1596,y:802,t:1527620844235};\\\", \\\"{x:1596,y:801,t:1527620844243};\\\", \\\"{x:1596,y:800,t:1527620844259};\\\", \\\"{x:1596,y:797,t:1527620844276};\\\", \\\"{x:1596,y:796,t:1527620844292};\\\", \\\"{x:1596,y:794,t:1527620844310};\\\", \\\"{x:1596,y:793,t:1527620844326};\\\", \\\"{x:1596,y:790,t:1527620844343};\\\", \\\"{x:1596,y:786,t:1527620844359};\\\", \\\"{x:1594,y:782,t:1527620844376};\\\", \\\"{x:1593,y:780,t:1527620844393};\\\", \\\"{x:1592,y:778,t:1527620844410};\\\", \\\"{x:1591,y:776,t:1527620844426};\\\", \\\"{x:1590,y:773,t:1527620844443};\\\", \\\"{x:1590,y:772,t:1527620844460};\\\", \\\"{x:1588,y:769,t:1527620844476};\\\", \\\"{x:1588,y:768,t:1527620844492};\\\", \\\"{x:1587,y:767,t:1527620844510};\\\", \\\"{x:1587,y:766,t:1527620844526};\\\", \\\"{x:1586,y:766,t:1527620844543};\\\", \\\"{x:1586,y:764,t:1527620844587};\\\", \\\"{x:1585,y:764,t:1527620844699};\\\", \\\"{x:1577,y:756,t:1527620845612};\\\", \\\"{x:1557,y:742,t:1527620845628};\\\", \\\"{x:1543,y:734,t:1527620845644};\\\", \\\"{x:1527,y:725,t:1527620845660};\\\", \\\"{x:1516,y:719,t:1527620845677};\\\", \\\"{x:1515,y:718,t:1527620845694};\\\", \\\"{x:1513,y:716,t:1527620845710};\\\", \\\"{x:1512,y:714,t:1527620845727};\\\", \\\"{x:1511,y:712,t:1527620845744};\\\", \\\"{x:1509,y:710,t:1527620845761};\\\", \\\"{x:1507,y:708,t:1527620845779};\\\", \\\"{x:1507,y:706,t:1527620845835};\\\", \\\"{x:1506,y:704,t:1527620845851};\\\", \\\"{x:1506,y:702,t:1527620845867};\\\", \\\"{x:1506,y:700,t:1527620845877};\\\", \\\"{x:1505,y:694,t:1527620845894};\\\", \\\"{x:1505,y:685,t:1527620845911};\\\", \\\"{x:1505,y:682,t:1527620845927};\\\", \\\"{x:1506,y:677,t:1527620845943};\\\", \\\"{x:1507,y:671,t:1527620845961};\\\", \\\"{x:1508,y:665,t:1527620845977};\\\", \\\"{x:1508,y:660,t:1527620845994};\\\", \\\"{x:1509,y:650,t:1527620846011};\\\", \\\"{x:1509,y:647,t:1527620846027};\\\", \\\"{x:1509,y:644,t:1527620846044};\\\", \\\"{x:1509,y:642,t:1527620846061};\\\", \\\"{x:1509,y:641,t:1527620846091};\\\", \\\"{x:1510,y:639,t:1527620846098};\\\", \\\"{x:1510,y:637,t:1527620846148};\\\", \\\"{x:1510,y:636,t:1527620846178};\\\", \\\"{x:1511,y:635,t:1527620846194};\\\", \\\"{x:1511,y:634,t:1527620846214};\\\", \\\"{x:1511,y:633,t:1527620846227};\\\", \\\"{x:1511,y:631,t:1527620846298};\\\", \\\"{x:1512,y:631,t:1527620846322};\\\", \\\"{x:1512,y:632,t:1527620846659};\\\", \\\"{x:1512,y:638,t:1527620846668};\\\", \\\"{x:1512,y:641,t:1527620846678};\\\", \\\"{x:1512,y:659,t:1527620846695};\\\", \\\"{x:1508,y:684,t:1527620846711};\\\", \\\"{x:1504,y:713,t:1527620846728};\\\", \\\"{x:1500,y:744,t:1527620846745};\\\", \\\"{x:1496,y:766,t:1527620846760};\\\", \\\"{x:1492,y:788,t:1527620846778};\\\", \\\"{x:1489,y:818,t:1527620846794};\\\", \\\"{x:1489,y:826,t:1527620846810};\\\", \\\"{x:1488,y:830,t:1527620846827};\\\", \\\"{x:1488,y:833,t:1527620846850};\\\", \\\"{x:1488,y:836,t:1527620846860};\\\", \\\"{x:1488,y:844,t:1527620846877};\\\", \\\"{x:1488,y:861,t:1527620846895};\\\", \\\"{x:1488,y:875,t:1527620846911};\\\", \\\"{x:1488,y:886,t:1527620846928};\\\", \\\"{x:1488,y:897,t:1527620846945};\\\", \\\"{x:1488,y:902,t:1527620846960};\\\", \\\"{x:1488,y:904,t:1527620846977};\\\", \\\"{x:1488,y:906,t:1527620846994};\\\", \\\"{x:1488,y:909,t:1527620847010};\\\", \\\"{x:1488,y:912,t:1527620847027};\\\", \\\"{x:1488,y:915,t:1527620847044};\\\", \\\"{x:1488,y:919,t:1527620847061};\\\", \\\"{x:1488,y:920,t:1527620847098};\\\", \\\"{x:1488,y:918,t:1527620847291};\\\", \\\"{x:1488,y:915,t:1527620847299};\\\", \\\"{x:1488,y:908,t:1527620847312};\\\", \\\"{x:1488,y:893,t:1527620847328};\\\", \\\"{x:1488,y:883,t:1527620847345};\\\", \\\"{x:1488,y:878,t:1527620847362};\\\", \\\"{x:1488,y:871,t:1527620847378};\\\", \\\"{x:1488,y:869,t:1527620847395};\\\", \\\"{x:1487,y:867,t:1527620847412};\\\", \\\"{x:1487,y:864,t:1527620847428};\\\", \\\"{x:1487,y:860,t:1527620847445};\\\", \\\"{x:1487,y:854,t:1527620847462};\\\", \\\"{x:1487,y:850,t:1527620847478};\\\", \\\"{x:1487,y:845,t:1527620847495};\\\", \\\"{x:1486,y:839,t:1527620847513};\\\", \\\"{x:1486,y:836,t:1527620847529};\\\", \\\"{x:1485,y:835,t:1527620847545};\\\", \\\"{x:1485,y:833,t:1527620847562};\\\", \\\"{x:1485,y:832,t:1527620847579};\\\", \\\"{x:1484,y:831,t:1527620847619};\\\", \\\"{x:1483,y:830,t:1527620848083};\\\", \\\"{x:1481,y:829,t:1527620848147};\\\", \\\"{x:1480,y:828,t:1527620848179};\\\", \\\"{x:1479,y:828,t:1527620848195};\\\", \\\"{x:1464,y:828,t:1527620848685};\\\", \\\"{x:1436,y:821,t:1527620848696};\\\", \\\"{x:1336,y:808,t:1527620848713};\\\", \\\"{x:1192,y:786,t:1527620848729};\\\", \\\"{x:1032,y:764,t:1527620848747};\\\", \\\"{x:859,y:730,t:1527620848763};\\\", \\\"{x:811,y:721,t:1527620848780};\\\", \\\"{x:796,y:719,t:1527620848796};\\\", \\\"{x:792,y:717,t:1527620848813};\\\", \\\"{x:790,y:717,t:1527620848850};\\\", \\\"{x:789,y:718,t:1527620848866};\\\", \\\"{x:784,y:718,t:1527620848880};\\\", \\\"{x:768,y:718,t:1527620848896};\\\", \\\"{x:753,y:718,t:1527620848913};\\\", \\\"{x:725,y:718,t:1527620848929};\\\", \\\"{x:685,y:712,t:1527620848946};\\\", \\\"{x:635,y:696,t:1527620848963};\\\", \\\"{x:619,y:688,t:1527620848980};\\\", \\\"{x:610,y:679,t:1527620848996};\\\", \\\"{x:609,y:673,t:1527620849013};\\\", \\\"{x:608,y:663,t:1527620849030};\\\", \\\"{x:603,y:647,t:1527620849047};\\\", \\\"{x:600,y:638,t:1527620849062};\\\", \\\"{x:599,y:634,t:1527620849079};\\\", \\\"{x:599,y:630,t:1527620849096};\\\", \\\"{x:599,y:628,t:1527620849112};\\\", \\\"{x:599,y:627,t:1527620849128};\\\", \\\"{x:599,y:625,t:1527620849146};\\\", \\\"{x:601,y:622,t:1527620849162};\\\", \\\"{x:603,y:619,t:1527620849179};\\\", \\\"{x:606,y:616,t:1527620849196};\\\", \\\"{x:606,y:615,t:1527620849212};\\\", \\\"{x:607,y:614,t:1527620849229};\\\", \\\"{x:607,y:613,t:1527620849245};\\\", \\\"{x:609,y:613,t:1527620849263};\\\", \\\"{x:610,y:612,t:1527620849291};\\\", \\\"{x:610,y:611,t:1527620849314};\\\", \\\"{x:613,y:608,t:1527620849330};\\\", \\\"{x:614,y:605,t:1527620849345};\\\", \\\"{x:615,y:604,t:1527620849363};\\\", \\\"{x:616,y:602,t:1527620849380};\\\", \\\"{x:617,y:602,t:1527620849451};\\\", \\\"{x:620,y:602,t:1527620849722};\\\", \\\"{x:628,y:608,t:1527620849730};\\\", \\\"{x:679,y:621,t:1527620849747};\\\", \\\"{x:763,y:636,t:1527620849764};\\\", \\\"{x:868,y:650,t:1527620849779};\\\", \\\"{x:978,y:677,t:1527620849797};\\\", \\\"{x:1069,y:686,t:1527620849813};\\\", \\\"{x:1153,y:698,t:1527620849829};\\\", \\\"{x:1214,y:706,t:1527620849846};\\\", \\\"{x:1237,y:708,t:1527620849864};\\\", \\\"{x:1257,y:716,t:1527620849879};\\\", \\\"{x:1281,y:719,t:1527620849897};\\\", \\\"{x:1299,y:723,t:1527620849914};\\\", \\\"{x:1319,y:729,t:1527620849930};\\\", \\\"{x:1336,y:737,t:1527620849947};\\\", \\\"{x:1352,y:742,t:1527620849963};\\\", \\\"{x:1372,y:746,t:1527620849980};\\\", \\\"{x:1386,y:751,t:1527620849997};\\\", \\\"{x:1395,y:755,t:1527620850013};\\\", \\\"{x:1400,y:755,t:1527620850031};\\\", \\\"{x:1401,y:757,t:1527620850115};\\\", \\\"{x:1403,y:763,t:1527620850130};\\\", \\\"{x:1417,y:770,t:1527620850147};\\\", \\\"{x:1427,y:775,t:1527620850164};\\\", \\\"{x:1434,y:778,t:1527620850181};\\\", \\\"{x:1447,y:782,t:1527620850197};\\\", \\\"{x:1451,y:783,t:1527620850214};\\\", \\\"{x:1452,y:784,t:1527620850231};\\\", \\\"{x:1453,y:784,t:1527620850267};\\\", \\\"{x:1454,y:784,t:1527620850291};\\\", \\\"{x:1455,y:784,t:1527620850306};\\\", \\\"{x:1456,y:784,t:1527620850314};\\\", \\\"{x:1463,y:786,t:1527620850330};\\\", \\\"{x:1470,y:789,t:1527620850347};\\\", \\\"{x:1485,y:791,t:1527620850364};\\\", \\\"{x:1496,y:795,t:1527620850381};\\\", \\\"{x:1500,y:797,t:1527620850398};\\\", \\\"{x:1501,y:799,t:1527620850490};\\\", \\\"{x:1500,y:804,t:1527620850498};\\\", \\\"{x:1498,y:813,t:1527620850514};\\\", \\\"{x:1495,y:820,t:1527620850531};\\\", \\\"{x:1493,y:827,t:1527620850547};\\\", \\\"{x:1488,y:834,t:1527620850563};\\\", \\\"{x:1486,y:836,t:1527620850580};\\\", \\\"{x:1486,y:834,t:1527620850771};\\\", \\\"{x:1486,y:832,t:1527620850781};\\\", \\\"{x:1486,y:828,t:1527620850798};\\\", \\\"{x:1486,y:824,t:1527620850816};\\\", \\\"{x:1485,y:820,t:1527620850830};\\\", \\\"{x:1485,y:815,t:1527620850848};\\\", \\\"{x:1482,y:810,t:1527620850865};\\\", \\\"{x:1482,y:806,t:1527620850881};\\\", \\\"{x:1481,y:796,t:1527620850898};\\\", \\\"{x:1479,y:785,t:1527620850914};\\\", \\\"{x:1479,y:778,t:1527620850931};\\\", \\\"{x:1479,y:769,t:1527620850947};\\\", \\\"{x:1477,y:761,t:1527620850964};\\\", \\\"{x:1477,y:755,t:1527620850981};\\\", \\\"{x:1477,y:752,t:1527620850997};\\\", \\\"{x:1475,y:749,t:1527620851014};\\\", \\\"{x:1474,y:744,t:1527620851031};\\\", \\\"{x:1473,y:738,t:1527620851047};\\\", \\\"{x:1473,y:729,t:1527620851065};\\\", \\\"{x:1471,y:721,t:1527620851080};\\\", \\\"{x:1469,y:708,t:1527620851098};\\\", \\\"{x:1468,y:702,t:1527620851114};\\\", \\\"{x:1468,y:698,t:1527620851131};\\\", \\\"{x:1467,y:695,t:1527620851148};\\\", \\\"{x:1466,y:691,t:1527620851164};\\\", \\\"{x:1465,y:689,t:1527620851180};\\\", \\\"{x:1465,y:688,t:1527620851198};\\\", \\\"{x:1465,y:679,t:1527620851779};\\\", \\\"{x:1464,y:669,t:1527620851787};\\\", \\\"{x:1464,y:664,t:1527620851799};\\\", \\\"{x:1462,y:647,t:1527620851815};\\\", \\\"{x:1461,y:630,t:1527620851831};\\\", \\\"{x:1461,y:606,t:1527620851849};\\\", \\\"{x:1461,y:583,t:1527620851864};\\\", \\\"{x:1461,y:529,t:1527620851881};\\\", \\\"{x:1465,y:490,t:1527620851898};\\\", \\\"{x:1472,y:445,t:1527620851914};\\\", \\\"{x:1478,y:415,t:1527620851931};\\\", \\\"{x:1483,y:378,t:1527620851949};\\\", \\\"{x:1481,y:352,t:1527620851965};\\\", \\\"{x:1475,y:331,t:1527620851981};\\\", \\\"{x:1471,y:314,t:1527620851999};\\\", \\\"{x:1469,y:301,t:1527620852015};\\\", \\\"{x:1467,y:294,t:1527620852031};\\\", \\\"{x:1465,y:287,t:1527620852048};\\\", \\\"{x:1465,y:284,t:1527620852065};\\\", \\\"{x:1465,y:276,t:1527620852082};\\\", \\\"{x:1465,y:258,t:1527620852099};\\\", \\\"{x:1464,y:248,t:1527620852115};\\\", \\\"{x:1464,y:242,t:1527620852132};\\\", \\\"{x:1464,y:232,t:1527620852149};\\\", \\\"{x:1464,y:223,t:1527620852166};\\\", \\\"{x:1466,y:216,t:1527620852182};\\\", \\\"{x:1467,y:211,t:1527620852198};\\\", \\\"{x:1467,y:206,t:1527620852216};\\\", \\\"{x:1467,y:199,t:1527620852232};\\\", \\\"{x:1470,y:189,t:1527620852249};\\\", \\\"{x:1473,y:178,t:1527620852266};\\\", \\\"{x:1476,y:171,t:1527620852282};\\\", \\\"{x:1477,y:164,t:1527620852299};\\\", \\\"{x:1477,y:162,t:1527620852316};\\\", \\\"{x:1477,y:161,t:1527620852332};\\\", \\\"{x:1477,y:159,t:1527620853859};\\\", \\\"{x:1479,y:157,t:1527620853867};\\\", \\\"{x:1483,y:154,t:1527620853884};\\\", \\\"{x:1484,y:153,t:1527620853900};\\\", \\\"{x:1485,y:153,t:1527620853924};\\\", \\\"{x:1486,y:153,t:1527620853934};\\\", \\\"{x:1486,y:154,t:1527620854211};\\\", \\\"{x:1486,y:156,t:1527620854227};\\\", \\\"{x:1486,y:159,t:1527620854242};\\\", \\\"{x:1485,y:159,t:1527620854251};\\\", \\\"{x:1485,y:161,t:1527620854267};\\\", \\\"{x:1485,y:163,t:1527620854284};\\\", \\\"{x:1483,y:165,t:1527620854301};\\\", \\\"{x:1482,y:167,t:1527620854317};\\\", \\\"{x:1482,y:168,t:1527620854338};\\\", \\\"{x:1482,y:170,t:1527620854352};\\\", \\\"{x:1482,y:171,t:1527620854371};\\\", \\\"{x:1482,y:172,t:1527620854384};\\\", \\\"{x:1482,y:174,t:1527620854402};\\\", \\\"{x:1482,y:177,t:1527620854417};\\\", \\\"{x:1482,y:185,t:1527620854434};\\\", \\\"{x:1482,y:188,t:1527620854451};\\\", \\\"{x:1482,y:191,t:1527620854469};\\\", \\\"{x:1482,y:193,t:1527620854483};\\\", \\\"{x:1482,y:196,t:1527620854501};\\\", \\\"{x:1482,y:198,t:1527620854516};\\\", \\\"{x:1483,y:201,t:1527620854534};\\\", \\\"{x:1483,y:206,t:1527620854550};\\\", \\\"{x:1483,y:209,t:1527620854566};\\\", \\\"{x:1485,y:214,t:1527620854584};\\\", \\\"{x:1485,y:223,t:1527620854601};\\\", \\\"{x:1485,y:229,t:1527620854617};\\\", \\\"{x:1485,y:236,t:1527620854634};\\\", \\\"{x:1488,y:248,t:1527620854650};\\\", \\\"{x:1488,y:257,t:1527620854669};\\\", \\\"{x:1488,y:266,t:1527620854684};\\\", \\\"{x:1488,y:276,t:1527620854700};\\\", \\\"{x:1488,y:283,t:1527620854718};\\\", \\\"{x:1488,y:292,t:1527620854734};\\\", \\\"{x:1488,y:300,t:1527620854751};\\\", \\\"{x:1486,y:313,t:1527620854768};\\\", \\\"{x:1485,y:318,t:1527620854784};\\\", \\\"{x:1485,y:327,t:1527620854801};\\\", \\\"{x:1482,y:344,t:1527620854819};\\\", \\\"{x:1478,y:357,t:1527620854835};\\\", \\\"{x:1477,y:372,t:1527620854851};\\\", \\\"{x:1472,y:391,t:1527620854868};\\\", \\\"{x:1469,y:398,t:1527620854885};\\\", \\\"{x:1466,y:406,t:1527620854902};\\\", \\\"{x:1466,y:408,t:1527620854919};\\\", \\\"{x:1464,y:410,t:1527620854934};\\\", \\\"{x:1463,y:412,t:1527620854951};\\\", \\\"{x:1461,y:417,t:1527620854968};\\\", \\\"{x:1460,y:425,t:1527620854984};\\\", \\\"{x:1459,y:435,t:1527620855001};\\\", \\\"{x:1459,y:444,t:1527620855018};\\\", \\\"{x:1456,y:448,t:1527620855035};\\\", \\\"{x:1456,y:449,t:1527620855051};\\\", \\\"{x:1456,y:451,t:1527620855069};\\\", \\\"{x:1456,y:457,t:1527620855084};\\\", \\\"{x:1456,y:463,t:1527620855102};\\\", \\\"{x:1456,y:466,t:1527620855118};\\\", \\\"{x:1456,y:470,t:1527620855135};\\\", \\\"{x:1456,y:472,t:1527620855151};\\\", \\\"{x:1458,y:480,t:1527620855168};\\\", \\\"{x:1460,y:488,t:1527620855185};\\\", \\\"{x:1461,y:493,t:1527620855202};\\\", \\\"{x:1463,y:498,t:1527620855218};\\\", \\\"{x:1466,y:502,t:1527620855235};\\\", \\\"{x:1466,y:508,t:1527620855252};\\\", \\\"{x:1466,y:514,t:1527620855270};\\\", \\\"{x:1466,y:519,t:1527620855285};\\\", \\\"{x:1466,y:526,t:1527620855301};\\\", \\\"{x:1466,y:527,t:1527620855318};\\\", \\\"{x:1467,y:530,t:1527620855335};\\\", \\\"{x:1467,y:536,t:1527620855352};\\\", \\\"{x:1467,y:542,t:1527620855369};\\\", \\\"{x:1467,y:549,t:1527620855385};\\\", \\\"{x:1467,y:555,t:1527620855401};\\\", \\\"{x:1465,y:564,t:1527620855418};\\\", \\\"{x:1463,y:572,t:1527620855434};\\\", \\\"{x:1462,y:582,t:1527620855451};\\\", \\\"{x:1462,y:588,t:1527620855469};\\\", \\\"{x:1461,y:595,t:1527620855485};\\\", \\\"{x:1460,y:603,t:1527620855502};\\\", \\\"{x:1460,y:612,t:1527620855519};\\\", \\\"{x:1460,y:620,t:1527620855535};\\\", \\\"{x:1460,y:628,t:1527620855553};\\\", \\\"{x:1460,y:636,t:1527620855569};\\\", \\\"{x:1460,y:644,t:1527620855586};\\\", \\\"{x:1460,y:654,t:1527620855603};\\\", \\\"{x:1460,y:658,t:1527620855619};\\\", \\\"{x:1460,y:664,t:1527620855635};\\\", \\\"{x:1459,y:668,t:1527620855652};\\\", \\\"{x:1459,y:672,t:1527620855669};\\\", \\\"{x:1459,y:679,t:1527620855685};\\\", \\\"{x:1461,y:687,t:1527620855702};\\\", \\\"{x:1461,y:692,t:1527620855718};\\\", \\\"{x:1461,y:700,t:1527620855735};\\\", \\\"{x:1461,y:704,t:1527620855753};\\\", \\\"{x:1461,y:706,t:1527620855768};\\\", \\\"{x:1462,y:710,t:1527620855785};\\\", \\\"{x:1462,y:714,t:1527620855802};\\\", \\\"{x:1464,y:720,t:1527620855818};\\\", \\\"{x:1464,y:725,t:1527620855835};\\\", \\\"{x:1466,y:734,t:1527620855853};\\\", \\\"{x:1466,y:743,t:1527620855869};\\\", \\\"{x:1470,y:752,t:1527620855886};\\\", \\\"{x:1472,y:762,t:1527620855902};\\\", \\\"{x:1476,y:771,t:1527620855919};\\\", \\\"{x:1480,y:778,t:1527620855935};\\\", \\\"{x:1484,y:786,t:1527620855953};\\\", \\\"{x:1486,y:792,t:1527620855970};\\\", \\\"{x:1487,y:796,t:1527620855986};\\\", \\\"{x:1488,y:799,t:1527620856002};\\\", \\\"{x:1490,y:802,t:1527620856018};\\\", \\\"{x:1491,y:806,t:1527620856035};\\\", \\\"{x:1492,y:809,t:1527620856052};\\\", \\\"{x:1492,y:810,t:1527620856068};\\\", \\\"{x:1493,y:812,t:1527620856085};\\\", \\\"{x:1493,y:813,t:1527620856102};\\\", \\\"{x:1493,y:815,t:1527620856119};\\\", \\\"{x:1493,y:818,t:1527620856135};\\\", \\\"{x:1493,y:822,t:1527620856151};\\\", \\\"{x:1493,y:827,t:1527620856169};\\\", \\\"{x:1493,y:831,t:1527620856185};\\\", \\\"{x:1493,y:834,t:1527620856202};\\\", \\\"{x:1493,y:837,t:1527620856219};\\\", \\\"{x:1493,y:838,t:1527620856235};\\\", \\\"{x:1493,y:840,t:1527620856258};\\\", \\\"{x:1493,y:841,t:1527620856269};\\\", \\\"{x:1493,y:843,t:1527620856285};\\\", \\\"{x:1493,y:845,t:1527620856302};\\\", \\\"{x:1493,y:846,t:1527620856319};\\\", \\\"{x:1493,y:847,t:1527620856362};\\\", \\\"{x:1494,y:848,t:1527620856370};\\\", \\\"{x:1494,y:849,t:1527620856426};\\\", \\\"{x:1494,y:850,t:1527620856450};\\\", \\\"{x:1494,y:851,t:1527620856467};\\\", \\\"{x:1494,y:852,t:1527620856508};\\\", \\\"{x:1493,y:851,t:1527620856883};\\\", \\\"{x:1493,y:849,t:1527620856891};\\\", \\\"{x:1493,y:848,t:1527620856903};\\\", \\\"{x:1493,y:843,t:1527620856919};\\\", \\\"{x:1494,y:838,t:1527620856936};\\\", \\\"{x:1494,y:836,t:1527620856953};\\\", \\\"{x:1495,y:830,t:1527620856970};\\\", \\\"{x:1495,y:822,t:1527620856987};\\\", \\\"{x:1495,y:801,t:1527620857003};\\\", \\\"{x:1495,y:786,t:1527620857020};\\\", \\\"{x:1495,y:759,t:1527620857036};\\\", \\\"{x:1489,y:729,t:1527620857054};\\\", \\\"{x:1469,y:686,t:1527620857069};\\\", \\\"{x:1443,y:648,t:1527620857086};\\\", \\\"{x:1395,y:603,t:1527620857104};\\\", \\\"{x:1331,y:557,t:1527620857119};\\\", \\\"{x:1272,y:529,t:1527620857136};\\\", \\\"{x:1241,y:517,t:1527620857153};\\\", \\\"{x:1207,y:507,t:1527620857169};\\\", \\\"{x:1173,y:500,t:1527620857186};\\\", \\\"{x:1146,y:500,t:1527620857203};\\\", \\\"{x:1126,y:501,t:1527620857219};\\\", \\\"{x:1110,y:509,t:1527620857236};\\\", \\\"{x:1071,y:530,t:1527620857253};\\\", \\\"{x:1032,y:553,t:1527620857270};\\\", \\\"{x:992,y:583,t:1527620857287};\\\", \\\"{x:964,y:602,t:1527620857303};\\\", \\\"{x:935,y:628,t:1527620857321};\\\", \\\"{x:919,y:642,t:1527620857336};\\\", \\\"{x:903,y:656,t:1527620857353};\\\", \\\"{x:884,y:671,t:1527620857370};\\\", \\\"{x:879,y:675,t:1527620857386};\\\", \\\"{x:878,y:676,t:1527620857403};\\\", \\\"{x:877,y:676,t:1527620857859};\\\", \\\"{x:875,y:675,t:1527620857870};\\\", \\\"{x:874,y:674,t:1527620857887};\\\", \\\"{x:871,y:674,t:1527620857902};\\\", \\\"{x:870,y:674,t:1527620857920};\\\", \\\"{x:869,y:674,t:1527620857937};\\\", \\\"{x:867,y:674,t:1527620857952};\\\", \\\"{x:866,y:674,t:1527620857978};\\\", \\\"{x:865,y:674,t:1527620857993};\\\", \\\"{x:864,y:674,t:1527620858003};\\\", \\\"{x:862,y:674,t:1527620858019};\\\", \\\"{x:860,y:674,t:1527620858037};\\\", \\\"{x:858,y:674,t:1527620858053};\\\", \\\"{x:856,y:674,t:1527620858070};\\\", \\\"{x:855,y:674,t:1527620858087};\\\", \\\"{x:854,y:675,t:1527620858139};\\\", \\\"{x:853,y:676,t:1527620858153};\\\", \\\"{x:862,y:678,t:1527620858306};\\\", \\\"{x:877,y:678,t:1527620858320};\\\", \\\"{x:923,y:682,t:1527620858337};\\\", \\\"{x:1021,y:682,t:1527620858354};\\\", \\\"{x:1090,y:682,t:1527620858370};\\\", \\\"{x:1138,y:682,t:1527620858387};\\\", \\\"{x:1170,y:685,t:1527620858404};\\\", \\\"{x:1197,y:686,t:1527620858420};\\\", \\\"{x:1217,y:688,t:1527620858437};\\\", \\\"{x:1237,y:691,t:1527620858454};\\\", \\\"{x:1262,y:689,t:1527620858470};\\\", \\\"{x:1283,y:693,t:1527620858487};\\\", \\\"{x:1331,y:698,t:1527620858505};\\\", \\\"{x:1385,y:708,t:1527620858520};\\\", \\\"{x:1449,y:716,t:1527620858538};\\\", \\\"{x:1506,y:725,t:1527620858555};\\\", \\\"{x:1537,y:729,t:1527620858570};\\\", \\\"{x:1562,y:736,t:1527620858587};\\\", \\\"{x:1576,y:740,t:1527620858604};\\\", \\\"{x:1583,y:744,t:1527620858620};\\\", \\\"{x:1589,y:746,t:1527620858637};\\\", \\\"{x:1591,y:748,t:1527620858655};\\\", \\\"{x:1597,y:754,t:1527620858671};\\\", \\\"{x:1602,y:764,t:1527620858687};\\\", \\\"{x:1610,y:777,t:1527620858704};\\\", \\\"{x:1619,y:792,t:1527620858720};\\\", \\\"{x:1625,y:803,t:1527620858736};\\\", \\\"{x:1632,y:831,t:1527620858754};\\\", \\\"{x:1639,y:846,t:1527620858771};\\\", \\\"{x:1641,y:864,t:1527620858787};\\\", \\\"{x:1641,y:878,t:1527620858804};\\\", \\\"{x:1640,y:890,t:1527620858820};\\\", \\\"{x:1640,y:899,t:1527620858836};\\\", \\\"{x:1636,y:906,t:1527620858853};\\\", \\\"{x:1634,y:910,t:1527620858871};\\\", \\\"{x:1632,y:912,t:1527620858887};\\\", \\\"{x:1628,y:915,t:1527620858904};\\\", \\\"{x:1627,y:916,t:1527620858921};\\\", \\\"{x:1623,y:920,t:1527620858937};\\\", \\\"{x:1621,y:922,t:1527620859259};\\\", \\\"{x:1618,y:923,t:1527620859555};\\\", \\\"{x:1617,y:919,t:1527620859627};\\\", \\\"{x:1616,y:912,t:1527620859638};\\\", \\\"{x:1613,y:897,t:1527620859656};\\\", \\\"{x:1608,y:882,t:1527620859671};\\\", \\\"{x:1601,y:864,t:1527620859688};\\\", \\\"{x:1596,y:853,t:1527620859705};\\\", \\\"{x:1590,y:839,t:1527620859721};\\\", \\\"{x:1586,y:823,t:1527620859739};\\\", \\\"{x:1583,y:818,t:1527620859755};\\\", \\\"{x:1582,y:814,t:1527620859771};\\\", \\\"{x:1582,y:813,t:1527620859803};\\\", \\\"{x:1581,y:813,t:1527620859867};\\\", \\\"{x:1580,y:813,t:1527620859875};\\\", \\\"{x:1577,y:813,t:1527620859888};\\\", \\\"{x:1569,y:825,t:1527620859905};\\\", \\\"{x:1540,y:855,t:1527620859922};\\\", \\\"{x:1520,y:876,t:1527620859938};\\\", \\\"{x:1499,y:899,t:1527620859955};\\\", \\\"{x:1468,y:919,t:1527620859972};\\\", \\\"{x:1446,y:936,t:1527620859988};\\\", \\\"{x:1433,y:945,t:1527620860005};\\\", \\\"{x:1427,y:950,t:1527620860022};\\\", \\\"{x:1422,y:952,t:1527620860038};\\\", \\\"{x:1419,y:953,t:1527620860056};\\\", \\\"{x:1418,y:954,t:1527620860072};\\\", \\\"{x:1415,y:955,t:1527620860088};\\\", \\\"{x:1413,y:957,t:1527620860105};\\\", \\\"{x:1405,y:958,t:1527620860122};\\\", \\\"{x:1400,y:960,t:1527620860139};\\\", \\\"{x:1395,y:961,t:1527620860155};\\\", \\\"{x:1386,y:962,t:1527620860173};\\\", \\\"{x:1377,y:964,t:1527620860189};\\\", \\\"{x:1364,y:965,t:1527620860205};\\\", \\\"{x:1354,y:965,t:1527620860223};\\\", \\\"{x:1347,y:965,t:1527620860238};\\\", \\\"{x:1340,y:965,t:1527620860255};\\\", \\\"{x:1333,y:965,t:1527620860272};\\\", \\\"{x:1327,y:965,t:1527620860288};\\\", \\\"{x:1325,y:965,t:1527620860305};\\\", \\\"{x:1319,y:961,t:1527620860322};\\\", \\\"{x:1317,y:959,t:1527620860339};\\\", \\\"{x:1315,y:953,t:1527620860355};\\\", \\\"{x:1313,y:947,t:1527620860372};\\\", \\\"{x:1313,y:942,t:1527620860389};\\\", \\\"{x:1313,y:937,t:1527620860405};\\\", \\\"{x:1313,y:934,t:1527620860422};\\\", \\\"{x:1313,y:931,t:1527620860439};\\\", \\\"{x:1313,y:927,t:1527620860455};\\\", \\\"{x:1314,y:924,t:1527620860471};\\\", \\\"{x:1317,y:920,t:1527620860490};\\\", \\\"{x:1322,y:914,t:1527620860505};\\\", \\\"{x:1328,y:906,t:1527620860522};\\\", \\\"{x:1331,y:903,t:1527620860538};\\\", \\\"{x:1332,y:901,t:1527620860555};\\\", \\\"{x:1333,y:900,t:1527620860572};\\\", \\\"{x:1334,y:900,t:1527620860618};\\\", \\\"{x:1335,y:899,t:1527620860633};\\\", \\\"{x:1336,y:898,t:1527620860649};\\\", \\\"{x:1337,y:898,t:1527620860658};\\\", \\\"{x:1337,y:897,t:1527620860672};\\\", \\\"{x:1338,y:897,t:1527620860689};\\\", \\\"{x:1338,y:895,t:1527620860770};\\\", \\\"{x:1340,y:894,t:1527620860818};\\\", \\\"{x:1341,y:893,t:1527620860890};\\\", \\\"{x:1343,y:893,t:1527620860986};\\\", \\\"{x:1344,y:893,t:1527620861026};\\\", \\\"{x:1345,y:891,t:1527620861040};\\\", \\\"{x:1346,y:891,t:1527620861074};\\\", \\\"{x:1347,y:891,t:1527620861210};\\\", \\\"{x:1348,y:891,t:1527620861402};\\\", \\\"{x:1350,y:891,t:1527620861442};\\\", \\\"{x:1351,y:891,t:1527620861473};\\\", \\\"{x:1353,y:891,t:1527620861489};\\\", \\\"{x:1356,y:891,t:1527620861506};\\\", \\\"{x:1357,y:891,t:1527620861530};\\\", \\\"{x:1359,y:891,t:1527620861546};\\\", \\\"{x:1360,y:892,t:1527620861570};\\\", \\\"{x:1362,y:892,t:1527620861593};\\\", \\\"{x:1363,y:892,t:1527620861606};\\\", \\\"{x:1366,y:892,t:1527620861623};\\\", \\\"{x:1369,y:892,t:1527620861639};\\\", \\\"{x:1374,y:892,t:1527620861656};\\\", \\\"{x:1378,y:892,t:1527620861673};\\\", \\\"{x:1388,y:892,t:1527620861690};\\\", \\\"{x:1393,y:892,t:1527620861705};\\\", \\\"{x:1399,y:892,t:1527620861723};\\\", \\\"{x:1403,y:892,t:1527620861740};\\\", \\\"{x:1407,y:892,t:1527620861756};\\\", \\\"{x:1410,y:892,t:1527620861772};\\\", \\\"{x:1411,y:892,t:1527620861790};\\\", \\\"{x:1412,y:892,t:1527620861850};\\\", \\\"{x:1413,y:892,t:1527620861858};\\\", \\\"{x:1414,y:892,t:1527620861874};\\\", \\\"{x:1415,y:890,t:1527620863354};\\\", \\\"{x:1415,y:888,t:1527620863361};\\\", \\\"{x:1412,y:879,t:1527620863374};\\\", \\\"{x:1408,y:857,t:1527620863391};\\\", \\\"{x:1398,y:830,t:1527620863408};\\\", \\\"{x:1389,y:799,t:1527620863424};\\\", \\\"{x:1383,y:785,t:1527620863441};\\\", \\\"{x:1380,y:776,t:1527620863457};\\\", \\\"{x:1377,y:773,t:1527620863474};\\\", \\\"{x:1375,y:771,t:1527620863491};\\\", \\\"{x:1375,y:770,t:1527620863546};\\\", \\\"{x:1375,y:769,t:1527620863585};\\\", \\\"{x:1374,y:768,t:1527620863594};\\\", \\\"{x:1374,y:767,t:1527620863649};\\\", \\\"{x:1375,y:765,t:1527620863722};\\\", \\\"{x:1376,y:765,t:1527620863737};\\\", \\\"{x:1378,y:763,t:1527620863758};\\\", \\\"{x:1379,y:762,t:1527620863774};\\\", \\\"{x:1382,y:760,t:1527620863791};\\\", \\\"{x:1383,y:760,t:1527620863808};\\\", \\\"{x:1384,y:759,t:1527620863826};\\\", \\\"{x:1385,y:759,t:1527620863914};\\\", \\\"{x:1382,y:761,t:1527620866713};\\\", \\\"{x:1380,y:762,t:1527620867097};\\\", \\\"{x:1379,y:762,t:1527620867130};\\\", \\\"{x:1378,y:762,t:1527620867144};\\\", \\\"{x:1377,y:763,t:1527620867160};\\\", \\\"{x:1376,y:764,t:1527620867194};\\\", \\\"{x:1375,y:764,t:1527620867329};\\\", \\\"{x:1379,y:764,t:1527620867482};\\\", \\\"{x:1382,y:764,t:1527620867494};\\\", \\\"{x:1394,y:766,t:1527620867512};\\\", \\\"{x:1416,y:767,t:1527620867527};\\\", \\\"{x:1434,y:767,t:1527620867544};\\\", \\\"{x:1449,y:767,t:1527620867561};\\\", \\\"{x:1458,y:767,t:1527620867577};\\\", \\\"{x:1464,y:767,t:1527620867594};\\\", \\\"{x:1466,y:767,t:1527620867641};\\\", \\\"{x:1467,y:768,t:1527620867674};\\\", \\\"{x:1469,y:768,t:1527620867762};\\\", \\\"{x:1470,y:768,t:1527620867777};\\\", \\\"{x:1471,y:768,t:1527620867794};\\\", \\\"{x:1473,y:768,t:1527620867811};\\\", \\\"{x:1475,y:769,t:1527620867828};\\\", \\\"{x:1478,y:770,t:1527620867845};\\\", \\\"{x:1479,y:770,t:1527620867862};\\\", \\\"{x:1480,y:770,t:1527620867878};\\\", \\\"{x:1481,y:770,t:1527620867894};\\\", \\\"{x:1482,y:770,t:1527620867911};\\\", \\\"{x:1484,y:770,t:1527620867928};\\\", \\\"{x:1486,y:770,t:1527620867945};\\\", \\\"{x:1487,y:770,t:1527620867961};\\\", \\\"{x:1488,y:770,t:1527620868202};\\\", \\\"{x:1488,y:768,t:1527620868233};\\\", \\\"{x:1488,y:767,t:1527620868265};\\\", \\\"{x:1488,y:766,t:1527620868354};\\\", \\\"{x:1488,y:765,t:1527620868361};\\\", \\\"{x:1488,y:764,t:1527620868434};\\\", \\\"{x:1488,y:762,t:1527620868490};\\\", \\\"{x:1488,y:761,t:1527620868498};\\\", \\\"{x:1489,y:760,t:1527620868513};\\\", \\\"{x:1489,y:759,t:1527620868529};\\\", \\\"{x:1489,y:758,t:1527620868578};\\\", \\\"{x:1489,y:757,t:1527620868625};\\\", \\\"{x:1489,y:758,t:1527620869354};\\\", \\\"{x:1489,y:761,t:1527620869385};\\\", \\\"{x:1489,y:762,t:1527620869457};\\\", \\\"{x:1489,y:761,t:1527620870490};\\\", \\\"{x:1489,y:760,t:1527620870497};\\\", \\\"{x:1488,y:760,t:1527620870514};\\\", \\\"{x:1488,y:759,t:1527620870530};\\\", \\\"{x:1486,y:763,t:1527620870834};\\\", \\\"{x:1485,y:770,t:1527620870847};\\\", \\\"{x:1481,y:783,t:1527620870863};\\\", \\\"{x:1479,y:794,t:1527620870880};\\\", \\\"{x:1479,y:796,t:1527620870896};\\\", \\\"{x:1479,y:798,t:1527620870913};\\\", \\\"{x:1479,y:799,t:1527620871018};\\\", \\\"{x:1479,y:800,t:1527620871042};\\\", \\\"{x:1479,y:801,t:1527620871058};\\\", \\\"{x:1479,y:802,t:1527620871082};\\\", \\\"{x:1479,y:803,t:1527620871097};\\\", \\\"{x:1479,y:805,t:1527620871114};\\\", \\\"{x:1479,y:806,t:1527620871130};\\\", \\\"{x:1479,y:808,t:1527620871147};\\\", \\\"{x:1480,y:809,t:1527620871163};\\\", \\\"{x:1481,y:812,t:1527620871181};\\\", \\\"{x:1481,y:814,t:1527620871197};\\\", \\\"{x:1482,y:815,t:1527620871213};\\\", \\\"{x:1484,y:816,t:1527620871230};\\\", \\\"{x:1485,y:818,t:1527620871248};\\\", \\\"{x:1485,y:819,t:1527620871263};\\\", \\\"{x:1487,y:821,t:1527620871281};\\\", \\\"{x:1487,y:822,t:1527620871298};\\\", \\\"{x:1487,y:823,t:1527620871347};\\\", \\\"{x:1488,y:825,t:1527620871363};\\\", \\\"{x:1488,y:826,t:1527620871419};\\\", \\\"{x:1488,y:827,t:1527620871482};\\\", \\\"{x:1488,y:828,t:1527620871706};\\\", \\\"{x:1487,y:828,t:1527620871738};\\\", \\\"{x:1486,y:828,t:1527620871753};\\\", \\\"{x:1486,y:829,t:1527620871764};\\\", \\\"{x:1484,y:829,t:1527620871802};\\\", \\\"{x:1480,y:829,t:1527620871826};\\\", \\\"{x:1479,y:829,t:1527620871841};\\\", \\\"{x:1476,y:830,t:1527620871858};\\\", \\\"{x:1474,y:830,t:1527620871914};\\\", \\\"{x:1473,y:830,t:1527620872283};\\\", \\\"{x:1473,y:829,t:1527620872516};\\\", \\\"{x:1474,y:829,t:1527620872532};\\\", \\\"{x:1476,y:829,t:1527620872571};\\\", \\\"{x:1477,y:829,t:1527620872610};\\\", \\\"{x:1478,y:829,t:1527620872650};\\\", \\\"{x:1479,y:829,t:1527620872666};\\\", \\\"{x:1481,y:829,t:1527620872682};\\\", \\\"{x:1482,y:829,t:1527620872699};\\\", \\\"{x:1483,y:829,t:1527620872722};\\\", \\\"{x:1484,y:829,t:1527620872732};\\\", \\\"{x:1485,y:828,t:1527620872749};\\\", \\\"{x:1487,y:828,t:1527620872786};\\\", \\\"{x:1489,y:827,t:1527620872801};\\\", \\\"{x:1491,y:827,t:1527620872825};\\\", \\\"{x:1492,y:827,t:1527620872833};\\\", \\\"{x:1494,y:827,t:1527620872849};\\\", \\\"{x:1497,y:827,t:1527620872866};\\\", \\\"{x:1501,y:826,t:1527620872881};\\\", \\\"{x:1503,y:826,t:1527620872905};\\\", \\\"{x:1505,y:826,t:1527620872915};\\\", \\\"{x:1510,y:826,t:1527620872931};\\\", \\\"{x:1516,y:826,t:1527620872949};\\\", \\\"{x:1521,y:826,t:1527620872966};\\\", \\\"{x:1527,y:826,t:1527620872982};\\\", \\\"{x:1538,y:826,t:1527620872999};\\\", \\\"{x:1544,y:826,t:1527620873015};\\\", \\\"{x:1548,y:826,t:1527620873032};\\\", \\\"{x:1549,y:826,t:1527620873049};\\\", \\\"{x:1552,y:826,t:1527620873066};\\\", \\\"{x:1553,y:826,t:1527620873082};\\\", \\\"{x:1556,y:826,t:1527620873099};\\\", \\\"{x:1558,y:826,t:1527620873116};\\\", \\\"{x:1565,y:825,t:1527620873133};\\\", \\\"{x:1567,y:825,t:1527620873149};\\\", \\\"{x:1575,y:824,t:1527620873165};\\\", \\\"{x:1577,y:824,t:1527620873186};\\\", \\\"{x:1577,y:823,t:1527620873202};\\\", \\\"{x:1578,y:823,t:1527620873290};\\\", \\\"{x:1580,y:821,t:1527620873338};\\\", \\\"{x:1581,y:821,t:1527620874259};\\\", \\\"{x:1582,y:821,t:1527620874266};\\\", \\\"{x:1582,y:823,t:1527620874283};\\\", \\\"{x:1582,y:825,t:1527620874300};\\\", \\\"{x:1582,y:827,t:1527620874317};\\\", \\\"{x:1582,y:828,t:1527620874334};\\\", \\\"{x:1583,y:828,t:1527620874351};\\\", \\\"{x:1584,y:829,t:1527620874367};\\\", \\\"{x:1583,y:821,t:1527620875171};\\\", \\\"{x:1579,y:813,t:1527620875184};\\\", \\\"{x:1572,y:796,t:1527620875201};\\\", \\\"{x:1561,y:779,t:1527620875218};\\\", \\\"{x:1555,y:764,t:1527620875234};\\\", \\\"{x:1552,y:747,t:1527620875251};\\\", \\\"{x:1544,y:724,t:1527620875267};\\\", \\\"{x:1536,y:702,t:1527620875283};\\\", \\\"{x:1534,y:684,t:1527620875301};\\\", \\\"{x:1532,y:679,t:1527620875318};\\\", \\\"{x:1531,y:678,t:1527620875334};\\\", \\\"{x:1531,y:676,t:1527620875350};\\\", \\\"{x:1531,y:675,t:1527620875369};\\\", \\\"{x:1531,y:678,t:1527620875649};\\\", \\\"{x:1530,y:688,t:1527620875656};\\\", \\\"{x:1525,y:696,t:1527620875667};\\\", \\\"{x:1522,y:713,t:1527620875685};\\\", \\\"{x:1521,y:724,t:1527620875700};\\\", \\\"{x:1520,y:734,t:1527620875717};\\\", \\\"{x:1520,y:742,t:1527620875734};\\\", \\\"{x:1520,y:754,t:1527620875750};\\\", \\\"{x:1517,y:772,t:1527620875768};\\\", \\\"{x:1517,y:787,t:1527620875785};\\\", \\\"{x:1516,y:799,t:1527620875801};\\\", \\\"{x:1516,y:812,t:1527620875817};\\\", \\\"{x:1515,y:824,t:1527620875834};\\\", \\\"{x:1511,y:836,t:1527620875850};\\\", \\\"{x:1507,y:845,t:1527620875867};\\\", \\\"{x:1507,y:848,t:1527620875884};\\\", \\\"{x:1507,y:852,t:1527620875900};\\\", \\\"{x:1505,y:855,t:1527620875917};\\\", \\\"{x:1503,y:859,t:1527620875935};\\\", \\\"{x:1499,y:864,t:1527620875951};\\\", \\\"{x:1494,y:868,t:1527620875967};\\\", \\\"{x:1489,y:875,t:1527620875984};\\\", \\\"{x:1485,y:878,t:1527620876001};\\\", \\\"{x:1481,y:880,t:1527620876017};\\\", \\\"{x:1480,y:881,t:1527620876034};\\\", \\\"{x:1479,y:882,t:1527620876050};\\\", \\\"{x:1478,y:883,t:1527620876089};\\\", \\\"{x:1474,y:883,t:1527620876113};\\\", \\\"{x:1472,y:885,t:1527620876138};\\\", \\\"{x:1471,y:885,t:1527620876151};\\\", \\\"{x:1471,y:886,t:1527620876168};\\\", \\\"{x:1469,y:888,t:1527620876242};\\\", \\\"{x:1468,y:891,t:1527620876258};\\\", \\\"{x:1466,y:894,t:1527620876273};\\\", \\\"{x:1466,y:896,t:1527620876298};\\\", \\\"{x:1465,y:898,t:1527620876306};\\\", \\\"{x:1465,y:899,t:1527620876322};\\\", \\\"{x:1463,y:900,t:1527620876419};\\\", \\\"{x:1462,y:900,t:1527620876441};\\\", \\\"{x:1460,y:901,t:1527620876451};\\\", \\\"{x:1455,y:902,t:1527620876467};\\\", \\\"{x:1451,y:904,t:1527620876485};\\\", \\\"{x:1447,y:904,t:1527620876502};\\\", \\\"{x:1445,y:904,t:1527620876518};\\\", \\\"{x:1444,y:904,t:1527620876535};\\\", \\\"{x:1443,y:904,t:1527620876554};\\\", \\\"{x:1442,y:904,t:1527620876567};\\\", \\\"{x:1441,y:904,t:1527620876594};\\\", \\\"{x:1438,y:898,t:1527620876675};\\\", \\\"{x:1438,y:896,t:1527620876686};\\\", \\\"{x:1433,y:881,t:1527620876702};\\\", \\\"{x:1428,y:865,t:1527620876720};\\\", \\\"{x:1425,y:848,t:1527620876736};\\\", \\\"{x:1425,y:838,t:1527620876752};\\\", \\\"{x:1425,y:831,t:1527620876769};\\\", \\\"{x:1423,y:827,t:1527620876786};\\\", \\\"{x:1422,y:821,t:1527620876802};\\\", \\\"{x:1422,y:819,t:1527620876819};\\\", \\\"{x:1421,y:816,t:1527620876835};\\\", \\\"{x:1418,y:814,t:1527620876851};\\\", \\\"{x:1412,y:809,t:1527620876868};\\\", \\\"{x:1402,y:804,t:1527620876885};\\\", \\\"{x:1388,y:797,t:1527620876902};\\\", \\\"{x:1376,y:789,t:1527620876919};\\\", \\\"{x:1366,y:782,t:1527620876934};\\\", \\\"{x:1359,y:779,t:1527620876952};\\\", \\\"{x:1357,y:777,t:1527620876969};\\\", \\\"{x:1357,y:776,t:1527620877107};\\\", \\\"{x:1357,y:774,t:1527620877119};\\\", \\\"{x:1360,y:770,t:1527620877136};\\\", \\\"{x:1363,y:769,t:1527620877152};\\\", \\\"{x:1363,y:768,t:1527620877169};\\\", \\\"{x:1365,y:768,t:1527620877267};\\\", \\\"{x:1366,y:768,t:1527620877307};\\\", \\\"{x:1367,y:768,t:1527620877323};\\\", \\\"{x:1368,y:768,t:1527620877339};\\\", \\\"{x:1369,y:768,t:1527620877353};\\\", \\\"{x:1369,y:767,t:1527620877370};\\\", \\\"{x:1370,y:767,t:1527620877411};\\\", \\\"{x:1371,y:767,t:1527620877420};\\\", \\\"{x:1373,y:766,t:1527620877635};\\\", \\\"{x:1374,y:766,t:1527620877675};\\\", \\\"{x:1376,y:766,t:1527620877690};\\\", \\\"{x:1377,y:765,t:1527620877720};\\\", \\\"{x:1378,y:765,t:1527620877738};\\\", \\\"{x:1379,y:765,t:1527620877779};\\\", \\\"{x:1380,y:764,t:1527620877787};\\\", \\\"{x:1381,y:764,t:1527620877803};\\\", \\\"{x:1384,y:764,t:1527620877834};\\\", \\\"{x:1385,y:764,t:1527620877842};\\\", \\\"{x:1386,y:764,t:1527620877857};\\\", \\\"{x:1388,y:764,t:1527620877869};\\\", \\\"{x:1390,y:764,t:1527620878202};\\\", \\\"{x:1391,y:764,t:1527620878221};\\\", \\\"{x:1394,y:764,t:1527620878237};\\\", \\\"{x:1398,y:763,t:1527620878254};\\\", \\\"{x:1400,y:762,t:1527620878271};\\\", \\\"{x:1403,y:760,t:1527620878286};\\\", \\\"{x:1405,y:759,t:1527620878304};\\\", \\\"{x:1406,y:757,t:1527620878321};\\\", \\\"{x:1407,y:753,t:1527620878336};\\\", \\\"{x:1407,y:752,t:1527620878354};\\\", \\\"{x:1408,y:743,t:1527620878370};\\\", \\\"{x:1409,y:738,t:1527620878387};\\\", \\\"{x:1409,y:734,t:1527620878403};\\\", \\\"{x:1409,y:721,t:1527620878421};\\\", \\\"{x:1409,y:705,t:1527620878437};\\\", \\\"{x:1409,y:683,t:1527620878454};\\\", \\\"{x:1409,y:660,t:1527620878471};\\\", \\\"{x:1414,y:637,t:1527620878487};\\\", \\\"{x:1419,y:611,t:1527620878502};\\\", \\\"{x:1420,y:595,t:1527620878520};\\\", \\\"{x:1421,y:579,t:1527620878537};\\\", \\\"{x:1424,y:567,t:1527620878553};\\\", \\\"{x:1426,y:557,t:1527620878569};\\\", \\\"{x:1427,y:553,t:1527620878586};\\\", \\\"{x:1427,y:551,t:1527620878633};\\\", \\\"{x:1426,y:551,t:1527620878971};\\\", \\\"{x:1426,y:552,t:1527620879002};\\\", \\\"{x:1426,y:554,t:1527620879011};\\\", \\\"{x:1425,y:554,t:1527620879026};\\\", \\\"{x:1425,y:555,t:1527620879042};\\\", \\\"{x:1425,y:556,t:1527620879054};\\\", \\\"{x:1424,y:557,t:1527620879218};\\\", \\\"{x:1422,y:558,t:1527620879435};\\\", \\\"{x:1417,y:559,t:1527620879443};\\\", \\\"{x:1412,y:563,t:1527620879455};\\\", \\\"{x:1390,y:577,t:1527620879470};\\\", \\\"{x:1355,y:590,t:1527620879487};\\\", \\\"{x:1306,y:604,t:1527620879503};\\\", \\\"{x:1237,y:613,t:1527620879521};\\\", \\\"{x:1147,y:619,t:1527620879537};\\\", \\\"{x:945,y:655,t:1527620879554};\\\", \\\"{x:833,y:678,t:1527620879571};\\\", \\\"{x:742,y:701,t:1527620879586};\\\", \\\"{x:653,y:728,t:1527620879604};\\\", \\\"{x:608,y:742,t:1527620879621};\\\", \\\"{x:594,y:744,t:1527620879637};\\\", \\\"{x:590,y:745,t:1527620879654};\\\", \\\"{x:588,y:747,t:1527620879681};\\\", \\\"{x:586,y:748,t:1527620879697};\\\", \\\"{x:585,y:749,t:1527620879705};\\\", \\\"{x:584,y:749,t:1527620879729};\\\", \\\"{x:582,y:749,t:1527620879834};\\\", \\\"{x:577,y:748,t:1527620879842};\\\", \\\"{x:572,y:743,t:1527620879854};\\\", \\\"{x:562,y:737,t:1527620879871};\\\", \\\"{x:555,y:731,t:1527620879890};\\\", \\\"{x:542,y:728,t:1527620879904};\\\", \\\"{x:529,y:724,t:1527620879921};\\\", \\\"{x:524,y:722,t:1527620879937};\\\", \\\"{x:523,y:721,t:1527620879955};\\\", \\\"{x:523,y:718,t:1527620880410};\\\", \\\"{x:523,y:713,t:1527620880421};\\\", \\\"{x:528,y:713,t:1527620880439};\\\", \\\"{x:550,y:708,t:1527620880455};\\\", \\\"{x:582,y:703,t:1527620880472};\\\", \\\"{x:637,y:700,t:1527620880488};\\\", \\\"{x:700,y:695,t:1527620880505};\\\", \\\"{x:770,y:695,t:1527620880521};\\\", \\\"{x:817,y:695,t:1527620880539};\\\", \\\"{x:862,y:695,t:1527620880555};\\\", \\\"{x:911,y:699,t:1527620880571};\\\", \\\"{x:951,y:704,t:1527620880589};\\\", \\\"{x:985,y:709,t:1527620880604};\\\", \\\"{x:1021,y:709,t:1527620880621};\\\", \\\"{x:1072,y:716,t:1527620880639};\\\", \\\"{x:1148,y:720,t:1527620880655};\\\", \\\"{x:1178,y:718,t:1527620880672};\\\", \\\"{x:1185,y:718,t:1527620880688};\\\", \\\"{x:1190,y:719,t:1527620880705};\\\" ] }, { \\\"rt\\\": 63842, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 344339, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -F -F -F -A -Z -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1193,y:719,t:1527620885763};\\\", \\\"{x:1207,y:710,t:1527620885777};\\\", \\\"{x:1240,y:695,t:1527620885794};\\\", \\\"{x:1278,y:682,t:1527620885810};\\\", \\\"{x:1356,y:668,t:1527620885827};\\\", \\\"{x:1396,y:659,t:1527620885843};\\\", \\\"{x:1426,y:654,t:1527620885860};\\\", \\\"{x:1445,y:649,t:1527620885876};\\\", \\\"{x:1452,y:649,t:1527620885893};\\\", \\\"{x:1455,y:649,t:1527620885910};\\\", \\\"{x:1457,y:649,t:1527620885926};\\\", \\\"{x:1459,y:649,t:1527620885943};\\\", \\\"{x:1459,y:648,t:1527620886211};\\\", \\\"{x:1459,y:646,t:1527620886228};\\\", \\\"{x:1459,y:644,t:1527620886244};\\\", \\\"{x:1457,y:642,t:1527620886261};\\\", \\\"{x:1456,y:640,t:1527620886278};\\\", \\\"{x:1454,y:633,t:1527620886294};\\\", \\\"{x:1452,y:628,t:1527620886311};\\\", \\\"{x:1452,y:626,t:1527620886328};\\\", \\\"{x:1451,y:624,t:1527620886344};\\\", \\\"{x:1451,y:622,t:1527620886361};\\\", \\\"{x:1448,y:620,t:1527620886378};\\\", \\\"{x:1442,y:618,t:1527620886394};\\\", \\\"{x:1425,y:611,t:1527620886411};\\\", \\\"{x:1420,y:603,t:1527620886427};\\\", \\\"{x:1420,y:602,t:1527620886851};\\\", \\\"{x:1416,y:602,t:1527620886874};\\\", \\\"{x:1414,y:602,t:1527620886882};\\\", \\\"{x:1412,y:601,t:1527620886895};\\\", \\\"{x:1409,y:600,t:1527620886910};\\\", \\\"{x:1402,y:599,t:1527620886928};\\\", \\\"{x:1388,y:595,t:1527620886945};\\\", \\\"{x:1375,y:590,t:1527620886960};\\\", \\\"{x:1361,y:587,t:1527620886978};\\\", \\\"{x:1347,y:585,t:1527620886994};\\\", \\\"{x:1341,y:584,t:1527620887010};\\\", \\\"{x:1337,y:582,t:1527620887028};\\\", \\\"{x:1334,y:580,t:1527620887045};\\\", \\\"{x:1333,y:580,t:1527620887062};\\\", \\\"{x:1332,y:580,t:1527620887078};\\\", \\\"{x:1330,y:579,t:1527620887094};\\\", \\\"{x:1328,y:577,t:1527620887111};\\\", \\\"{x:1325,y:574,t:1527620887128};\\\", \\\"{x:1323,y:572,t:1527620887145};\\\", \\\"{x:1320,y:566,t:1527620887162};\\\", \\\"{x:1318,y:563,t:1527620887178};\\\", \\\"{x:1310,y:553,t:1527620887195};\\\", \\\"{x:1305,y:548,t:1527620887212};\\\", \\\"{x:1301,y:543,t:1527620887228};\\\", \\\"{x:1298,y:540,t:1527620887244};\\\", \\\"{x:1297,y:539,t:1527620887262};\\\", \\\"{x:1297,y:537,t:1527620887278};\\\", \\\"{x:1296,y:537,t:1527620887294};\\\", \\\"{x:1296,y:536,t:1527620887311};\\\", \\\"{x:1295,y:534,t:1527620887331};\\\", \\\"{x:1295,y:533,t:1527620887345};\\\", \\\"{x:1295,y:532,t:1527620887361};\\\", \\\"{x:1295,y:530,t:1527620887378};\\\", \\\"{x:1295,y:529,t:1527620887394};\\\", \\\"{x:1295,y:527,t:1527620887411};\\\", \\\"{x:1295,y:525,t:1527620887428};\\\", \\\"{x:1296,y:519,t:1527620887444};\\\", \\\"{x:1296,y:517,t:1527620887462};\\\", \\\"{x:1298,y:514,t:1527620887479};\\\", \\\"{x:1299,y:511,t:1527620887498};\\\", \\\"{x:1301,y:509,t:1527620887512};\\\", \\\"{x:1303,y:506,t:1527620887529};\\\", \\\"{x:1305,y:503,t:1527620887544};\\\", \\\"{x:1305,y:502,t:1527620887561};\\\", \\\"{x:1306,y:500,t:1527620887578};\\\", \\\"{x:1307,y:500,t:1527620887595};\\\", \\\"{x:1309,y:500,t:1527620887618};\\\", \\\"{x:1309,y:499,t:1527620887636};\\\", \\\"{x:1311,y:497,t:1527620887665};\\\", \\\"{x:1312,y:497,t:1527620887818};\\\", \\\"{x:1313,y:497,t:1527620889650};\\\", \\\"{x:1313,y:499,t:1527620889662};\\\", \\\"{x:1313,y:505,t:1527620889681};\\\", \\\"{x:1313,y:507,t:1527620889697};\\\", \\\"{x:1314,y:509,t:1527620889714};\\\", \\\"{x:1315,y:511,t:1527620889754};\\\", \\\"{x:1315,y:512,t:1527620889770};\\\", \\\"{x:1315,y:514,t:1527620889780};\\\", \\\"{x:1315,y:518,t:1527620889796};\\\", \\\"{x:1315,y:522,t:1527620889814};\\\", \\\"{x:1315,y:526,t:1527620889829};\\\", \\\"{x:1315,y:528,t:1527620889847};\\\", \\\"{x:1315,y:530,t:1527620889864};\\\", \\\"{x:1315,y:531,t:1527620889880};\\\", \\\"{x:1315,y:535,t:1527620889897};\\\", \\\"{x:1315,y:539,t:1527620889914};\\\", \\\"{x:1315,y:547,t:1527620889930};\\\", \\\"{x:1315,y:551,t:1527620889947};\\\", \\\"{x:1314,y:554,t:1527620889964};\\\", \\\"{x:1314,y:557,t:1527620889980};\\\", \\\"{x:1314,y:560,t:1527620889996};\\\", \\\"{x:1312,y:562,t:1527620890014};\\\", \\\"{x:1311,y:563,t:1527620890030};\\\", \\\"{x:1311,y:564,t:1527620890047};\\\", \\\"{x:1311,y:566,t:1527620890064};\\\", \\\"{x:1311,y:568,t:1527620890080};\\\", \\\"{x:1310,y:571,t:1527620890097};\\\", \\\"{x:1310,y:573,t:1527620890114};\\\", \\\"{x:1310,y:574,t:1527620890130};\\\", \\\"{x:1310,y:576,t:1527620890146};\\\", \\\"{x:1308,y:579,t:1527620890164};\\\", \\\"{x:1307,y:581,t:1527620890180};\\\", \\\"{x:1307,y:583,t:1527620890197};\\\", \\\"{x:1307,y:584,t:1527620890214};\\\", \\\"{x:1307,y:587,t:1527620890231};\\\", \\\"{x:1307,y:589,t:1527620890247};\\\", \\\"{x:1307,y:590,t:1527620890282};\\\", \\\"{x:1307,y:592,t:1527620890297};\\\", \\\"{x:1307,y:594,t:1527620890314};\\\", \\\"{x:1306,y:597,t:1527620890331};\\\", \\\"{x:1306,y:598,t:1527620890354};\\\", \\\"{x:1306,y:600,t:1527620890370};\\\", \\\"{x:1306,y:602,t:1527620890386};\\\", \\\"{x:1306,y:603,t:1527620890402};\\\", \\\"{x:1306,y:604,t:1527620890414};\\\", \\\"{x:1306,y:606,t:1527620890431};\\\", \\\"{x:1306,y:608,t:1527620890446};\\\", \\\"{x:1306,y:609,t:1527620890464};\\\", \\\"{x:1306,y:611,t:1527620890481};\\\", \\\"{x:1306,y:613,t:1527620890497};\\\", \\\"{x:1306,y:616,t:1527620890514};\\\", \\\"{x:1308,y:619,t:1527620890531};\\\", \\\"{x:1309,y:621,t:1527620890547};\\\", \\\"{x:1310,y:623,t:1527620890564};\\\", \\\"{x:1311,y:625,t:1527620890582};\\\", \\\"{x:1312,y:626,t:1527620890597};\\\", \\\"{x:1314,y:627,t:1527620890613};\\\", \\\"{x:1315,y:629,t:1527620890630};\\\", \\\"{x:1317,y:631,t:1527620890647};\\\", \\\"{x:1318,y:632,t:1527620890663};\\\", \\\"{x:1318,y:633,t:1527620890680};\\\", \\\"{x:1319,y:634,t:1527620890698};\\\", \\\"{x:1319,y:636,t:1527620890713};\\\", \\\"{x:1319,y:637,t:1527620890730};\\\", \\\"{x:1320,y:637,t:1527620890754};\\\", \\\"{x:1320,y:638,t:1527620890769};\\\", \\\"{x:1320,y:639,t:1527620890843};\\\", \\\"{x:1320,y:640,t:1527620890850};\\\", \\\"{x:1320,y:641,t:1527620890874};\\\", \\\"{x:1321,y:642,t:1527620890882};\\\", \\\"{x:1321,y:644,t:1527620890898};\\\", \\\"{x:1321,y:647,t:1527620890915};\\\", \\\"{x:1321,y:651,t:1527620890931};\\\", \\\"{x:1321,y:654,t:1527620890948};\\\", \\\"{x:1321,y:656,t:1527620890964};\\\", \\\"{x:1322,y:659,t:1527620890980};\\\", \\\"{x:1323,y:661,t:1527620890998};\\\", \\\"{x:1323,y:662,t:1527620891015};\\\", \\\"{x:1323,y:663,t:1527620891034};\\\", \\\"{x:1323,y:665,t:1527620891050};\\\", \\\"{x:1323,y:666,t:1527620891082};\\\", \\\"{x:1324,y:668,t:1527620891107};\\\", \\\"{x:1324,y:670,t:1527620891131};\\\", \\\"{x:1324,y:671,t:1527620891148};\\\", \\\"{x:1324,y:675,t:1527620891164};\\\", \\\"{x:1322,y:678,t:1527620891180};\\\", \\\"{x:1321,y:681,t:1527620891198};\\\", \\\"{x:1320,y:683,t:1527620891215};\\\", \\\"{x:1319,y:685,t:1527620891231};\\\", \\\"{x:1319,y:687,t:1527620891248};\\\", \\\"{x:1319,y:688,t:1527620891265};\\\", \\\"{x:1319,y:689,t:1527620891290};\\\", \\\"{x:1318,y:691,t:1527620891330};\\\", \\\"{x:1318,y:692,t:1527620891347};\\\", \\\"{x:1318,y:693,t:1527620891401};\\\", \\\"{x:1317,y:695,t:1527620891417};\\\", \\\"{x:1317,y:696,t:1527620891458};\\\", \\\"{x:1317,y:697,t:1527620891465};\\\", \\\"{x:1317,y:698,t:1527620891481};\\\", \\\"{x:1317,y:700,t:1527620891498};\\\", \\\"{x:1317,y:701,t:1527620891515};\\\", \\\"{x:1317,y:703,t:1527620891531};\\\", \\\"{x:1317,y:704,t:1527620891548};\\\", \\\"{x:1317,y:706,t:1527620891564};\\\", \\\"{x:1317,y:708,t:1527620891585};\\\", \\\"{x:1317,y:709,t:1527620891598};\\\", \\\"{x:1317,y:710,t:1527620891614};\\\", \\\"{x:1317,y:711,t:1527620891632};\\\", \\\"{x:1317,y:712,t:1527620891647};\\\", \\\"{x:1317,y:714,t:1527620891665};\\\", \\\"{x:1317,y:716,t:1527620891682};\\\", \\\"{x:1317,y:717,t:1527620891747};\\\", \\\"{x:1317,y:719,t:1527620891765};\\\", \\\"{x:1317,y:723,t:1527620891782};\\\", \\\"{x:1316,y:725,t:1527620891798};\\\", \\\"{x:1315,y:728,t:1527620891814};\\\", \\\"{x:1314,y:730,t:1527620891831};\\\", \\\"{x:1314,y:733,t:1527620891849};\\\", \\\"{x:1314,y:734,t:1527620891898};\\\", \\\"{x:1314,y:735,t:1527620891970};\\\", \\\"{x:1314,y:736,t:1527620891982};\\\", \\\"{x:1313,y:737,t:1527620891998};\\\", \\\"{x:1313,y:739,t:1527620892015};\\\", \\\"{x:1313,y:741,t:1527620892031};\\\", \\\"{x:1313,y:743,t:1527620892048};\\\", \\\"{x:1313,y:746,t:1527620892065};\\\", \\\"{x:1313,y:751,t:1527620892082};\\\", \\\"{x:1312,y:753,t:1527620892098};\\\", \\\"{x:1312,y:754,t:1527620892146};\\\", \\\"{x:1311,y:755,t:1527620892162};\\\", \\\"{x:1311,y:756,t:1527620892170};\\\", \\\"{x:1311,y:757,t:1527620892250};\\\", \\\"{x:1311,y:759,t:1527620892275};\\\", \\\"{x:1311,y:761,t:1527620892330};\\\", \\\"{x:1310,y:762,t:1527620892338};\\\", \\\"{x:1310,y:764,t:1527620892394};\\\", \\\"{x:1310,y:765,t:1527620892402};\\\", \\\"{x:1310,y:766,t:1527620892434};\\\", \\\"{x:1310,y:767,t:1527620892451};\\\", \\\"{x:1310,y:768,t:1527620892466};\\\", \\\"{x:1310,y:766,t:1527620892810};\\\", \\\"{x:1310,y:765,t:1527620892818};\\\", \\\"{x:1310,y:762,t:1527620892832};\\\", \\\"{x:1310,y:759,t:1527620892848};\\\", \\\"{x:1310,y:756,t:1527620892865};\\\", \\\"{x:1310,y:754,t:1527620892882};\\\", \\\"{x:1310,y:752,t:1527620892899};\\\", \\\"{x:1310,y:751,t:1527620892915};\\\", \\\"{x:1310,y:750,t:1527620892932};\\\", \\\"{x:1310,y:749,t:1527620892948};\\\", \\\"{x:1310,y:748,t:1527620892965};\\\", \\\"{x:1310,y:746,t:1527620892982};\\\", \\\"{x:1310,y:745,t:1527620893033};\\\", \\\"{x:1310,y:744,t:1527620893050};\\\", \\\"{x:1310,y:743,t:1527620893066};\\\", \\\"{x:1310,y:742,t:1527620893089};\\\", \\\"{x:1310,y:741,t:1527620893098};\\\", \\\"{x:1310,y:739,t:1527620893116};\\\", \\\"{x:1311,y:737,t:1527620893132};\\\", \\\"{x:1312,y:734,t:1527620893149};\\\", \\\"{x:1314,y:728,t:1527620893165};\\\", \\\"{x:1315,y:723,t:1527620893183};\\\", \\\"{x:1316,y:716,t:1527620893199};\\\", \\\"{x:1316,y:713,t:1527620893215};\\\", \\\"{x:1316,y:709,t:1527620893232};\\\", \\\"{x:1318,y:699,t:1527620893249};\\\", \\\"{x:1320,y:692,t:1527620893265};\\\", \\\"{x:1322,y:688,t:1527620893283};\\\", \\\"{x:1322,y:683,t:1527620893299};\\\", \\\"{x:1322,y:679,t:1527620893316};\\\", \\\"{x:1323,y:677,t:1527620893333};\\\", \\\"{x:1323,y:676,t:1527620893349};\\\", \\\"{x:1323,y:680,t:1527620893458};\\\", \\\"{x:1323,y:684,t:1527620893466};\\\", \\\"{x:1322,y:693,t:1527620893483};\\\", \\\"{x:1322,y:700,t:1527620893500};\\\", \\\"{x:1322,y:711,t:1527620893515};\\\", \\\"{x:1320,y:718,t:1527620893533};\\\", \\\"{x:1320,y:722,t:1527620893550};\\\", \\\"{x:1320,y:729,t:1527620893566};\\\", \\\"{x:1320,y:734,t:1527620893582};\\\", \\\"{x:1320,y:739,t:1527620893599};\\\", \\\"{x:1320,y:743,t:1527620893617};\\\", \\\"{x:1320,y:746,t:1527620893632};\\\", \\\"{x:1320,y:748,t:1527620893649};\\\", \\\"{x:1320,y:750,t:1527620893682};\\\", \\\"{x:1320,y:751,t:1527620893706};\\\", \\\"{x:1320,y:753,t:1527620893723};\\\", \\\"{x:1320,y:754,t:1527620893738};\\\", \\\"{x:1320,y:755,t:1527620893750};\\\", \\\"{x:1320,y:756,t:1527620893767};\\\", \\\"{x:1320,y:757,t:1527620893783};\\\", \\\"{x:1320,y:759,t:1527620893803};\\\", \\\"{x:1320,y:760,t:1527620893834};\\\", \\\"{x:1321,y:762,t:1527620893850};\\\", \\\"{x:1321,y:763,t:1527620893875};\\\", \\\"{x:1321,y:764,t:1527620893890};\\\", \\\"{x:1321,y:765,t:1527620893900};\\\", \\\"{x:1321,y:767,t:1527620893916};\\\", \\\"{x:1321,y:769,t:1527620893933};\\\", \\\"{x:1320,y:773,t:1527620893950};\\\", \\\"{x:1318,y:776,t:1527620893967};\\\", \\\"{x:1317,y:780,t:1527620893983};\\\", \\\"{x:1315,y:785,t:1527620894000};\\\", \\\"{x:1314,y:787,t:1527620894017};\\\", \\\"{x:1313,y:791,t:1527620894033};\\\", \\\"{x:1310,y:794,t:1527620894050};\\\", \\\"{x:1310,y:796,t:1527620894066};\\\", \\\"{x:1309,y:797,t:1527620894084};\\\", \\\"{x:1309,y:798,t:1527620894218};\\\", \\\"{x:1309,y:803,t:1527620894234};\\\", \\\"{x:1309,y:806,t:1527620894250};\\\", \\\"{x:1309,y:808,t:1527620894267};\\\", \\\"{x:1309,y:809,t:1527620894284};\\\", \\\"{x:1309,y:813,t:1527620894300};\\\", \\\"{x:1309,y:814,t:1527620894317};\\\", \\\"{x:1309,y:815,t:1527620894334};\\\", \\\"{x:1309,y:818,t:1527620894350};\\\", \\\"{x:1309,y:819,t:1527620894367};\\\", \\\"{x:1309,y:820,t:1527620894386};\\\", \\\"{x:1309,y:821,t:1527620894400};\\\", \\\"{x:1310,y:822,t:1527620894416};\\\", \\\"{x:1310,y:823,t:1527620894474};\\\", \\\"{x:1304,y:821,t:1527620901871};\\\", \\\"{x:1298,y:819,t:1527620901886};\\\", \\\"{x:1242,y:801,t:1527620901903};\\\", \\\"{x:1237,y:792,t:1527620901920};\\\", \\\"{x:1190,y:765,t:1527620901936};\\\", \\\"{x:1119,y:738,t:1527620901954};\\\", \\\"{x:1072,y:723,t:1527620901970};\\\", \\\"{x:971,y:685,t:1527620901987};\\\", \\\"{x:904,y:656,t:1527620902003};\\\", \\\"{x:889,y:642,t:1527620902020};\\\", \\\"{x:844,y:617,t:1527620902037};\\\", \\\"{x:821,y:599,t:1527620902052};\\\", \\\"{x:810,y:587,t:1527620902070};\\\", \\\"{x:800,y:570,t:1527620902087};\\\", \\\"{x:799,y:564,t:1527620902104};\\\", \\\"{x:797,y:560,t:1527620902120};\\\", \\\"{x:797,y:559,t:1527620902149};\\\", \\\"{x:797,y:558,t:1527620902470};\\\", \\\"{x:797,y:557,t:1527620902488};\\\", \\\"{x:797,y:556,t:1527620902510};\\\", \\\"{x:797,y:555,t:1527620902521};\\\", \\\"{x:797,y:553,t:1527620902537};\\\", \\\"{x:799,y:552,t:1527620902553};\\\", \\\"{x:801,y:550,t:1527620902572};\\\", \\\"{x:803,y:548,t:1527620902587};\\\", \\\"{x:805,y:546,t:1527620902603};\\\", \\\"{x:810,y:543,t:1527620902621};\\\", \\\"{x:814,y:542,t:1527620902638};\\\", \\\"{x:819,y:539,t:1527620902653};\\\", \\\"{x:826,y:537,t:1527620902670};\\\", \\\"{x:827,y:535,t:1527620902687};\\\", \\\"{x:828,y:535,t:1527620902703};\\\", \\\"{x:829,y:535,t:1527620902727};\\\", \\\"{x:833,y:533,t:1527620902742};\\\", \\\"{x:834,y:532,t:1527620902753};\\\", \\\"{x:834,y:531,t:1527620902771};\\\", \\\"{x:836,y:529,t:1527620902788};\\\", \\\"{x:837,y:529,t:1527620902815};\\\", \\\"{x:838,y:529,t:1527620902855};\\\", \\\"{x:837,y:532,t:1527620903390};\\\", \\\"{x:837,y:534,t:1527620903405};\\\", \\\"{x:835,y:547,t:1527620903421};\\\", \\\"{x:830,y:564,t:1527620903438};\\\", \\\"{x:823,y:595,t:1527620903455};\\\", \\\"{x:819,y:613,t:1527620903471};\\\", \\\"{x:818,y:616,t:1527620903487};\\\", \\\"{x:819,y:619,t:1527620903505};\\\", \\\"{x:820,y:619,t:1527620903639};\\\", \\\"{x:822,y:619,t:1527620903654};\\\", \\\"{x:822,y:620,t:1527620903672};\\\", \\\"{x:822,y:622,t:1527620903688};\\\", \\\"{x:822,y:625,t:1527620903705};\\\", \\\"{x:822,y:627,t:1527620903728};\\\", \\\"{x:822,y:628,t:1527620903737};\\\", \\\"{x:822,y:630,t:1527620903754};\\\", \\\"{x:821,y:633,t:1527620903771};\\\", \\\"{x:820,y:641,t:1527620903788};\\\", \\\"{x:819,y:643,t:1527620903805};\\\", \\\"{x:819,y:649,t:1527620903821};\\\", \\\"{x:818,y:657,t:1527620903838};\\\", \\\"{x:818,y:663,t:1527620903855};\\\", \\\"{x:820,y:671,t:1527620903871};\\\", \\\"{x:827,y:686,t:1527620903889};\\\", \\\"{x:835,y:697,t:1527620903904};\\\", \\\"{x:849,y:706,t:1527620903921};\\\", \\\"{x:868,y:718,t:1527620903938};\\\", \\\"{x:886,y:727,t:1527620903954};\\\", \\\"{x:905,y:736,t:1527620903971};\\\", \\\"{x:925,y:744,t:1527620903989};\\\", \\\"{x:949,y:749,t:1527620904005};\\\", \\\"{x:974,y:758,t:1527620904021};\\\", \\\"{x:1003,y:765,t:1527620904038};\\\", \\\"{x:1028,y:769,t:1527620904055};\\\", \\\"{x:1043,y:770,t:1527620904072};\\\", \\\"{x:1063,y:772,t:1527620904089};\\\", \\\"{x:1083,y:774,t:1527620904106};\\\", \\\"{x:1102,y:774,t:1527620904122};\\\", \\\"{x:1120,y:774,t:1527620904139};\\\", \\\"{x:1145,y:771,t:1527620904155};\\\", \\\"{x:1179,y:761,t:1527620904172};\\\", \\\"{x:1220,y:751,t:1527620904189};\\\", \\\"{x:1254,y:740,t:1527620904206};\\\", \\\"{x:1285,y:732,t:1527620904222};\\\", \\\"{x:1324,y:722,t:1527620904238};\\\", \\\"{x:1337,y:713,t:1527620904256};\\\", \\\"{x:1347,y:707,t:1527620904272};\\\", \\\"{x:1351,y:703,t:1527620904289};\\\", \\\"{x:1354,y:702,t:1527620904307};\\\", \\\"{x:1355,y:702,t:1527620904351};\\\", \\\"{x:1356,y:700,t:1527620904367};\\\", \\\"{x:1357,y:699,t:1527620904375};\\\", \\\"{x:1357,y:698,t:1527620904389};\\\", \\\"{x:1357,y:696,t:1527620904406};\\\", \\\"{x:1358,y:693,t:1527620904422};\\\", \\\"{x:1359,y:691,t:1527620904439};\\\", \\\"{x:1359,y:690,t:1527620904463};\\\", \\\"{x:1359,y:688,t:1527620904487};\\\", \\\"{x:1359,y:687,t:1527620904519};\\\", \\\"{x:1360,y:684,t:1527620904526};\\\", \\\"{x:1360,y:682,t:1527620904551};\\\", \\\"{x:1361,y:680,t:1527620904559};\\\", \\\"{x:1361,y:679,t:1527620904574};\\\", \\\"{x:1361,y:678,t:1527620904589};\\\", \\\"{x:1361,y:677,t:1527620904606};\\\", \\\"{x:1363,y:675,t:1527620904623};\\\", \\\"{x:1364,y:674,t:1527620904646};\\\", \\\"{x:1365,y:674,t:1527620904663};\\\", \\\"{x:1366,y:674,t:1527620905583};\\\", \\\"{x:1366,y:677,t:1527620905703};\\\", \\\"{x:1366,y:678,t:1527620905710};\\\", \\\"{x:1366,y:679,t:1527620905724};\\\", \\\"{x:1366,y:683,t:1527620905740};\\\", \\\"{x:1364,y:685,t:1527620905757};\\\", \\\"{x:1364,y:686,t:1527620905774};\\\", \\\"{x:1363,y:687,t:1527620905920};\\\", \\\"{x:1360,y:687,t:1527620906231};\\\", \\\"{x:1355,y:686,t:1527620906241};\\\", \\\"{x:1348,y:680,t:1527620906258};\\\", \\\"{x:1341,y:670,t:1527620906274};\\\", \\\"{x:1341,y:669,t:1527620906291};\\\", \\\"{x:1341,y:668,t:1527620907183};\\\", \\\"{x:1341,y:666,t:1527620907198};\\\", \\\"{x:1341,y:665,t:1527620907215};\\\", \\\"{x:1341,y:663,t:1527620907225};\\\", \\\"{x:1341,y:662,t:1527620907242};\\\", \\\"{x:1340,y:659,t:1527620907258};\\\", \\\"{x:1340,y:658,t:1527620907275};\\\", \\\"{x:1339,y:657,t:1527620907293};\\\", \\\"{x:1339,y:656,t:1527620907327};\\\", \\\"{x:1339,y:659,t:1527620914751};\\\", \\\"{x:1339,y:677,t:1527620914766};\\\", \\\"{x:1341,y:698,t:1527620914783};\\\", \\\"{x:1343,y:708,t:1527620914800};\\\", \\\"{x:1348,y:718,t:1527620914817};\\\", \\\"{x:1353,y:731,t:1527620914832};\\\", \\\"{x:1359,y:737,t:1527620914850};\\\", \\\"{x:1361,y:738,t:1527620914866};\\\", \\\"{x:1362,y:739,t:1527620914883};\\\", \\\"{x:1362,y:740,t:1527620914900};\\\", \\\"{x:1364,y:741,t:1527620914916};\\\", \\\"{x:1366,y:743,t:1527620914933};\\\", \\\"{x:1366,y:744,t:1527620914974};\\\", \\\"{x:1367,y:747,t:1527620914998};\\\", \\\"{x:1375,y:751,t:1527620915017};\\\", \\\"{x:1375,y:756,t:1527620915032};\\\", \\\"{x:1375,y:758,t:1527620915159};\\\", \\\"{x:1375,y:759,t:1527620915167};\\\", \\\"{x:1373,y:763,t:1527620915182};\\\", \\\"{x:1374,y:763,t:1527620915199};\\\", \\\"{x:1375,y:764,t:1527620915217};\\\", \\\"{x:1375,y:765,t:1527620915271};\\\", \\\"{x:1377,y:765,t:1527620915284};\\\", \\\"{x:1378,y:766,t:1527620915742};\\\", \\\"{x:1378,y:767,t:1527620915943};\\\", \\\"{x:1378,y:768,t:1527620915950};\\\", \\\"{x:1378,y:772,t:1527620915969};\\\", \\\"{x:1378,y:775,t:1527620915984};\\\", \\\"{x:1378,y:781,t:1527620916000};\\\", \\\"{x:1378,y:790,t:1527620916017};\\\", \\\"{x:1378,y:798,t:1527620916033};\\\", \\\"{x:1378,y:812,t:1527620916050};\\\", \\\"{x:1378,y:823,t:1527620916067};\\\", \\\"{x:1378,y:833,t:1527620916083};\\\", \\\"{x:1377,y:842,t:1527620916100};\\\", \\\"{x:1376,y:855,t:1527620916117};\\\", \\\"{x:1375,y:859,t:1527620916133};\\\", \\\"{x:1373,y:869,t:1527620916150};\\\", \\\"{x:1373,y:880,t:1527620916167};\\\", \\\"{x:1373,y:888,t:1527620916183};\\\", \\\"{x:1373,y:904,t:1527620916200};\\\", \\\"{x:1373,y:922,t:1527620916217};\\\", \\\"{x:1373,y:940,t:1527620916234};\\\", \\\"{x:1373,y:956,t:1527620916250};\\\", \\\"{x:1373,y:970,t:1527620916267};\\\", \\\"{x:1374,y:981,t:1527620916284};\\\", \\\"{x:1374,y:988,t:1527620916301};\\\", \\\"{x:1375,y:991,t:1527620916317};\\\", \\\"{x:1375,y:992,t:1527620916334};\\\", \\\"{x:1377,y:991,t:1527620916582};\\\", \\\"{x:1377,y:990,t:1527620916590};\\\", \\\"{x:1377,y:988,t:1527620916601};\\\", \\\"{x:1377,y:986,t:1527620916617};\\\", \\\"{x:1378,y:982,t:1527620916634};\\\", \\\"{x:1378,y:981,t:1527620916654};\\\", \\\"{x:1378,y:980,t:1527620916686};\\\", \\\"{x:1378,y:979,t:1527620916701};\\\", \\\"{x:1378,y:976,t:1527620916734};\\\", \\\"{x:1378,y:974,t:1527620916751};\\\", \\\"{x:1378,y:972,t:1527620916767};\\\", \\\"{x:1380,y:970,t:1527620916790};\\\", \\\"{x:1380,y:969,t:1527620916815};\\\", \\\"{x:1381,y:967,t:1527620916830};\\\", \\\"{x:1381,y:966,t:1527620916854};\\\", \\\"{x:1382,y:965,t:1527620916868};\\\", \\\"{x:1382,y:964,t:1527620916886};\\\", \\\"{x:1382,y:963,t:1527620916910};\\\", \\\"{x:1382,y:961,t:1527620916935};\\\", \\\"{x:1382,y:960,t:1527620916952};\\\", \\\"{x:1382,y:958,t:1527620916969};\\\", \\\"{x:1382,y:957,t:1527620916985};\\\", \\\"{x:1382,y:956,t:1527620917001};\\\", \\\"{x:1382,y:955,t:1527620917018};\\\", \\\"{x:1382,y:953,t:1527620917035};\\\", \\\"{x:1382,y:952,t:1527620917051};\\\", \\\"{x:1382,y:949,t:1527620917069};\\\", \\\"{x:1383,y:947,t:1527620917085};\\\", \\\"{x:1383,y:943,t:1527620917101};\\\", \\\"{x:1383,y:934,t:1527620917119};\\\", \\\"{x:1385,y:928,t:1527620917135};\\\", \\\"{x:1385,y:924,t:1527620917151};\\\", \\\"{x:1385,y:916,t:1527620917169};\\\", \\\"{x:1383,y:907,t:1527620917185};\\\", \\\"{x:1383,y:896,t:1527620917202};\\\", \\\"{x:1382,y:889,t:1527620917219};\\\", \\\"{x:1381,y:877,t:1527620917235};\\\", \\\"{x:1381,y:868,t:1527620917252};\\\", \\\"{x:1381,y:857,t:1527620917268};\\\", \\\"{x:1381,y:843,t:1527620917286};\\\", \\\"{x:1381,y:829,t:1527620917302};\\\", \\\"{x:1385,y:809,t:1527620917319};\\\", \\\"{x:1387,y:793,t:1527620917335};\\\", \\\"{x:1389,y:783,t:1527620917351};\\\", \\\"{x:1392,y:768,t:1527620917368};\\\", \\\"{x:1394,y:763,t:1527620917385};\\\", \\\"{x:1395,y:758,t:1527620917401};\\\", \\\"{x:1395,y:756,t:1527620917418};\\\", \\\"{x:1395,y:755,t:1527620917436};\\\", \\\"{x:1394,y:755,t:1527620917855};\\\", \\\"{x:1393,y:756,t:1527620917871};\\\", \\\"{x:1391,y:758,t:1527620918263};\\\", \\\"{x:1391,y:759,t:1527620918278};\\\", \\\"{x:1390,y:760,t:1527620918294};\\\", \\\"{x:1389,y:760,t:1527620918302};\\\", \\\"{x:1388,y:760,t:1527620918320};\\\", \\\"{x:1386,y:761,t:1527620918351};\\\", \\\"{x:1384,y:762,t:1527620918369};\\\", \\\"{x:1382,y:762,t:1527620918423};\\\", \\\"{x:1381,y:763,t:1527620918438};\\\", \\\"{x:1380,y:763,t:1527620918454};\\\", \\\"{x:1378,y:763,t:1527620918470};\\\", \\\"{x:1374,y:763,t:1527620918487};\\\", \\\"{x:1370,y:763,t:1527620918503};\\\", \\\"{x:1368,y:763,t:1527620918520};\\\", \\\"{x:1367,y:763,t:1527620918537};\\\", \\\"{x:1367,y:762,t:1527620918821};\\\", \\\"{x:1368,y:762,t:1527620918950};\\\", \\\"{x:1369,y:762,t:1527620919047};\\\", \\\"{x:1370,y:762,t:1527620919063};\\\", \\\"{x:1371,y:762,t:1527620919070};\\\", \\\"{x:1372,y:761,t:1527620919087};\\\", \\\"{x:1372,y:760,t:1527620919104};\\\", \\\"{x:1374,y:760,t:1527620919120};\\\", \\\"{x:1375,y:760,t:1527620919230};\\\", \\\"{x:1376,y:760,t:1527620919247};\\\", \\\"{x:1377,y:760,t:1527620920567};\\\", \\\"{x:1379,y:760,t:1527620920574};\\\", \\\"{x:1380,y:760,t:1527620920614};\\\", \\\"{x:1383,y:761,t:1527620923303};\\\", \\\"{x:1385,y:763,t:1527620923310};\\\", \\\"{x:1387,y:765,t:1527620923325};\\\", \\\"{x:1391,y:768,t:1527620923340};\\\", \\\"{x:1399,y:772,t:1527620923357};\\\", \\\"{x:1401,y:773,t:1527620923373};\\\", \\\"{x:1402,y:775,t:1527620923390};\\\", \\\"{x:1403,y:775,t:1527620923408};\\\", \\\"{x:1403,y:776,t:1527620923454};\\\", \\\"{x:1403,y:777,t:1527620923461};\\\", \\\"{x:1404,y:779,t:1527620923477};\\\", \\\"{x:1407,y:781,t:1527620923494};\\\", \\\"{x:1408,y:782,t:1527620923508};\\\", \\\"{x:1412,y:786,t:1527620923524};\\\", \\\"{x:1413,y:788,t:1527620923541};\\\", \\\"{x:1414,y:792,t:1527620923558};\\\", \\\"{x:1418,y:800,t:1527620923574};\\\", \\\"{x:1418,y:804,t:1527620923590};\\\", \\\"{x:1420,y:805,t:1527620923607};\\\", \\\"{x:1422,y:806,t:1527620923625};\\\", \\\"{x:1423,y:807,t:1527620923645};\\\", \\\"{x:1423,y:808,t:1527620923870};\\\", \\\"{x:1423,y:810,t:1527620923901};\\\", \\\"{x:1423,y:811,t:1527620923949};\\\", \\\"{x:1423,y:813,t:1527620924014};\\\", \\\"{x:1423,y:814,t:1527620924053};\\\", \\\"{x:1423,y:816,t:1527620924094};\\\", \\\"{x:1423,y:817,t:1527620924407};\\\", \\\"{x:1423,y:818,t:1527620924422};\\\", \\\"{x:1423,y:819,t:1527620924759};\\\", \\\"{x:1423,y:821,t:1527620924790};\\\", \\\"{x:1420,y:822,t:1527620925695};\\\", \\\"{x:1419,y:822,t:1527620925711};\\\", \\\"{x:1417,y:822,t:1527620925726};\\\", \\\"{x:1416,y:822,t:1527620925743};\\\", \\\"{x:1415,y:822,t:1527620925760};\\\", \\\"{x:1413,y:823,t:1527620925791};\\\", \\\"{x:1413,y:824,t:1527620925799};\\\", \\\"{x:1411,y:824,t:1527620925814};\\\", \\\"{x:1410,y:824,t:1527620925828};\\\", \\\"{x:1409,y:824,t:1527620925854};\\\", \\\"{x:1409,y:825,t:1527620926047};\\\", \\\"{x:1407,y:827,t:1527620926071};\\\", \\\"{x:1406,y:827,t:1527620926095};\\\", \\\"{x:1405,y:827,t:1527620926159};\\\", \\\"{x:1402,y:828,t:1527620926182};\\\", \\\"{x:1402,y:829,t:1527620926207};\\\", \\\"{x:1401,y:829,t:1527620926214};\\\", \\\"{x:1400,y:830,t:1527620926238};\\\", \\\"{x:1397,y:831,t:1527620926327};\\\", \\\"{x:1396,y:831,t:1527620926568};\\\", \\\"{x:1396,y:833,t:1527620926599};\\\", \\\"{x:1395,y:833,t:1527620926611};\\\", \\\"{x:1394,y:834,t:1527620926628};\\\", \\\"{x:1393,y:836,t:1527620926644};\\\", \\\"{x:1393,y:837,t:1527620926661};\\\", \\\"{x:1389,y:841,t:1527620926678};\\\", \\\"{x:1387,y:843,t:1527620926694};\\\", \\\"{x:1387,y:844,t:1527620926711};\\\", \\\"{x:1386,y:845,t:1527620926735};\\\", \\\"{x:1385,y:846,t:1527620926807};\\\", \\\"{x:1384,y:846,t:1527620926815};\\\", \\\"{x:1383,y:847,t:1527620926827};\\\", \\\"{x:1381,y:849,t:1527620926845};\\\", \\\"{x:1380,y:851,t:1527620926861};\\\", \\\"{x:1378,y:853,t:1527620926877};\\\", \\\"{x:1374,y:854,t:1527620926894};\\\", \\\"{x:1374,y:855,t:1527620926990};\\\", \\\"{x:1373,y:856,t:1527620927022};\\\", \\\"{x:1371,y:856,t:1527620927038};\\\", \\\"{x:1369,y:856,t:1527620927046};\\\", \\\"{x:1366,y:856,t:1527620927060};\\\", \\\"{x:1361,y:856,t:1527620927078};\\\", \\\"{x:1356,y:856,t:1527620927094};\\\", \\\"{x:1351,y:856,t:1527620927111};\\\", \\\"{x:1347,y:856,t:1527620927128};\\\", \\\"{x:1340,y:854,t:1527620927145};\\\", \\\"{x:1336,y:853,t:1527620927161};\\\", \\\"{x:1333,y:853,t:1527620927178};\\\", \\\"{x:1331,y:852,t:1527620927195};\\\", \\\"{x:1329,y:851,t:1527620927211};\\\", \\\"{x:1326,y:851,t:1527620927228};\\\", \\\"{x:1324,y:851,t:1527620927245};\\\", \\\"{x:1315,y:847,t:1527620927262};\\\", \\\"{x:1311,y:844,t:1527620927278};\\\", \\\"{x:1309,y:844,t:1527620927295};\\\", \\\"{x:1307,y:842,t:1527620927312};\\\", \\\"{x:1306,y:841,t:1527620927328};\\\", \\\"{x:1305,y:841,t:1527620927345};\\\", \\\"{x:1303,y:840,t:1527620927363};\\\", \\\"{x:1301,y:840,t:1527620927378};\\\", \\\"{x:1300,y:840,t:1527620927399};\\\", \\\"{x:1300,y:839,t:1527620927543};\\\", \\\"{x:1300,y:838,t:1527620927687};\\\", \\\"{x:1298,y:837,t:1527620927695};\\\", \\\"{x:1295,y:835,t:1527620927712};\\\", \\\"{x:1292,y:834,t:1527620927728};\\\", \\\"{x:1290,y:833,t:1527620927744};\\\", \\\"{x:1289,y:832,t:1527620927762};\\\", \\\"{x:1288,y:831,t:1527620927830};\\\", \\\"{x:1286,y:831,t:1527620927886};\\\", \\\"{x:1285,y:831,t:1527620927895};\\\", \\\"{x:1284,y:831,t:1527620927941};\\\", \\\"{x:1283,y:831,t:1527620928085};\\\", \\\"{x:1282,y:831,t:1527620928141};\\\", \\\"{x:1281,y:831,t:1527620928189};\\\", \\\"{x:1280,y:831,t:1527620928197};\\\", \\\"{x:1279,y:831,t:1527620928221};\\\", \\\"{x:1278,y:831,t:1527620928359};\\\", \\\"{x:1279,y:831,t:1527620928838};\\\", \\\"{x:1283,y:831,t:1527620928846};\\\", \\\"{x:1287,y:832,t:1527620928865};\\\", \\\"{x:1298,y:833,t:1527620928881};\\\", \\\"{x:1310,y:838,t:1527620928896};\\\", \\\"{x:1323,y:841,t:1527620928913};\\\", \\\"{x:1329,y:843,t:1527620928930};\\\", \\\"{x:1335,y:846,t:1527620928947};\\\", \\\"{x:1337,y:847,t:1527620928963};\\\", \\\"{x:1338,y:848,t:1527620928980};\\\", \\\"{x:1340,y:850,t:1527620928998};\\\", \\\"{x:1341,y:852,t:1527620929015};\\\", \\\"{x:1343,y:853,t:1527620929031};\\\", \\\"{x:1347,y:855,t:1527620929046};\\\", \\\"{x:1348,y:856,t:1527620929063};\\\", \\\"{x:1349,y:858,t:1527620929080};\\\", \\\"{x:1352,y:861,t:1527620929097};\\\", \\\"{x:1354,y:865,t:1527620929113};\\\", \\\"{x:1358,y:869,t:1527620929130};\\\", \\\"{x:1359,y:871,t:1527620929147};\\\", \\\"{x:1359,y:872,t:1527620929215};\\\", \\\"{x:1359,y:873,t:1527620930079};\\\", \\\"{x:1359,y:875,t:1527620930126};\\\", \\\"{x:1359,y:877,t:1527620930135};\\\", \\\"{x:1359,y:878,t:1527620930148};\\\", \\\"{x:1359,y:880,t:1527620930164};\\\", \\\"{x:1358,y:884,t:1527620930182};\\\", \\\"{x:1356,y:887,t:1527620930198};\\\", \\\"{x:1355,y:888,t:1527620930215};\\\", \\\"{x:1355,y:889,t:1527620930238};\\\", \\\"{x:1355,y:890,t:1527620930262};\\\", \\\"{x:1355,y:891,t:1527620930270};\\\", \\\"{x:1354,y:892,t:1527620930286};\\\", \\\"{x:1353,y:893,t:1527620930327};\\\", \\\"{x:1353,y:894,t:1527620930359};\\\", \\\"{x:1352,y:894,t:1527620930390};\\\", \\\"{x:1352,y:895,t:1527620930398};\\\", \\\"{x:1351,y:896,t:1527620930438};\\\", \\\"{x:1350,y:896,t:1527620930454};\\\", \\\"{x:1349,y:897,t:1527620930465};\\\", \\\"{x:1348,y:897,t:1527620930486};\\\", \\\"{x:1346,y:898,t:1527620930502};\\\", \\\"{x:1345,y:899,t:1527620930515};\\\", \\\"{x:1343,y:899,t:1527620930551};\\\", \\\"{x:1346,y:899,t:1527620930895};\\\", \\\"{x:1347,y:898,t:1527620931727};\\\", \\\"{x:1349,y:896,t:1527620931734};\\\", \\\"{x:1350,y:896,t:1527620931749};\\\", \\\"{x:1355,y:894,t:1527620931768};\\\", \\\"{x:1356,y:894,t:1527620931822};\\\", \\\"{x:1357,y:894,t:1527620931839};\\\", \\\"{x:1359,y:894,t:1527620931854};\\\", \\\"{x:1362,y:894,t:1527620931878};\\\", \\\"{x:1365,y:894,t:1527620931886};\\\", \\\"{x:1368,y:894,t:1527620931899};\\\", \\\"{x:1374,y:894,t:1527620931916};\\\", \\\"{x:1383,y:894,t:1527620931933};\\\", \\\"{x:1390,y:894,t:1527620931949};\\\", \\\"{x:1400,y:894,t:1527620931967};\\\", \\\"{x:1402,y:894,t:1527620931982};\\\", \\\"{x:1408,y:894,t:1527620931999};\\\", \\\"{x:1414,y:894,t:1527620932016};\\\", \\\"{x:1422,y:894,t:1527620932034};\\\", \\\"{x:1428,y:894,t:1527620932049};\\\", \\\"{x:1432,y:895,t:1527620932067};\\\", \\\"{x:1434,y:896,t:1527620932083};\\\", \\\"{x:1435,y:896,t:1527620932099};\\\", \\\"{x:1435,y:897,t:1527620932117};\\\", \\\"{x:1435,y:898,t:1527620932406};\\\", \\\"{x:1435,y:899,t:1527620932519};\\\", \\\"{x:1433,y:900,t:1527620932663};\\\", \\\"{x:1432,y:900,t:1527620932670};\\\", \\\"{x:1429,y:900,t:1527620932686};\\\", \\\"{x:1428,y:900,t:1527620932700};\\\", \\\"{x:1427,y:900,t:1527620932719};\\\", \\\"{x:1426,y:900,t:1527620932798};\\\", \\\"{x:1425,y:899,t:1527620932807};\\\", \\\"{x:1424,y:899,t:1527620932818};\\\", \\\"{x:1422,y:898,t:1527620932833};\\\", \\\"{x:1419,y:898,t:1527620932849};\\\", \\\"{x:1417,y:898,t:1527620932869};\\\", \\\"{x:1415,y:897,t:1527620932883};\\\", \\\"{x:1411,y:896,t:1527620932900};\\\", \\\"{x:1409,y:895,t:1527620932917};\\\", \\\"{x:1406,y:895,t:1527620932933};\\\", \\\"{x:1401,y:895,t:1527620932950};\\\", \\\"{x:1399,y:893,t:1527620932967};\\\", \\\"{x:1397,y:892,t:1527620932983};\\\", \\\"{x:1396,y:892,t:1527620933000};\\\", \\\"{x:1395,y:892,t:1527620933017};\\\", \\\"{x:1394,y:892,t:1527620933034};\\\", \\\"{x:1392,y:892,t:1527620933050};\\\", \\\"{x:1390,y:892,t:1527620933066};\\\", \\\"{x:1388,y:892,t:1527620933084};\\\", \\\"{x:1386,y:893,t:1527620933100};\\\", \\\"{x:1385,y:893,t:1527620933455};\\\", \\\"{x:1384,y:893,t:1527620933470};\\\", \\\"{x:1383,y:894,t:1527620933486};\\\", \\\"{x:1382,y:895,t:1527620933502};\\\", \\\"{x:1381,y:895,t:1527620933519};\\\", \\\"{x:1380,y:896,t:1527620933535};\\\", \\\"{x:1379,y:896,t:1527620933590};\\\", \\\"{x:1379,y:897,t:1527620933615};\\\", \\\"{x:1376,y:899,t:1527620933631};\\\", \\\"{x:1376,y:898,t:1527620935966};\\\", \\\"{x:1376,y:876,t:1527620935975};\\\", \\\"{x:1376,y:864,t:1527620935986};\\\", \\\"{x:1376,y:849,t:1527620936004};\\\", \\\"{x:1376,y:835,t:1527620936021};\\\", \\\"{x:1376,y:825,t:1527620936036};\\\", \\\"{x:1376,y:823,t:1527620936053};\\\", \\\"{x:1376,y:819,t:1527620936070};\\\", \\\"{x:1376,y:815,t:1527620936086};\\\", \\\"{x:1376,y:809,t:1527620936104};\\\", \\\"{x:1377,y:802,t:1527620936120};\\\", \\\"{x:1381,y:789,t:1527620936136};\\\", \\\"{x:1382,y:782,t:1527620936153};\\\", \\\"{x:1386,y:776,t:1527620936170};\\\", \\\"{x:1388,y:767,t:1527620936187};\\\", \\\"{x:1388,y:761,t:1527620936203};\\\", \\\"{x:1388,y:759,t:1527620936220};\\\", \\\"{x:1389,y:756,t:1527620936237};\\\", \\\"{x:1389,y:754,t:1527620936253};\\\", \\\"{x:1389,y:753,t:1527620936270};\\\", \\\"{x:1390,y:751,t:1527620936287};\\\", \\\"{x:1390,y:750,t:1527620936343};\\\", \\\"{x:1388,y:752,t:1527620936871};\\\", \\\"{x:1385,y:756,t:1527620936888};\\\", \\\"{x:1383,y:758,t:1527620936905};\\\", \\\"{x:1380,y:758,t:1527620937374};\\\", \\\"{x:1379,y:758,t:1527620937614};\\\", \\\"{x:1379,y:759,t:1527620937622};\\\", \\\"{x:1377,y:759,t:1527620937830};\\\", \\\"{x:1376,y:760,t:1527620937895};\\\", \\\"{x:1376,y:761,t:1527620940710};\\\", \\\"{x:1377,y:761,t:1527620940902};\\\", \\\"{x:1379,y:761,t:1527620940966};\\\", \\\"{x:1380,y:761,t:1527620941014};\\\", \\\"{x:1382,y:761,t:1527620941047};\\\", \\\"{x:1383,y:761,t:1527620941094};\\\", \\\"{x:1385,y:761,t:1527620941206};\\\", \\\"{x:1386,y:762,t:1527620941302};\\\", \\\"{x:1388,y:762,t:1527620941326};\\\", \\\"{x:1389,y:763,t:1527620941341};\\\", \\\"{x:1390,y:764,t:1527620941382};\\\", \\\"{x:1391,y:764,t:1527620941397};\\\", \\\"{x:1392,y:764,t:1527620941409};\\\", \\\"{x:1393,y:765,t:1527620941461};\\\", \\\"{x:1394,y:765,t:1527620941518};\\\", \\\"{x:1395,y:766,t:1527620941525};\\\", \\\"{x:1395,y:767,t:1527620941590};\\\", \\\"{x:1396,y:767,t:1527620941598};\\\", \\\"{x:1398,y:769,t:1527620941614};\\\", \\\"{x:1399,y:770,t:1527620941646};\\\", \\\"{x:1400,y:770,t:1527620941670};\\\", \\\"{x:1402,y:771,t:1527620941678};\\\", \\\"{x:1404,y:771,t:1527620941750};\\\", \\\"{x:1406,y:772,t:1527620941782};\\\", \\\"{x:1406,y:773,t:1527620941792};\\\", \\\"{x:1407,y:773,t:1527620941810};\\\", \\\"{x:1408,y:773,t:1527620941826};\\\", \\\"{x:1409,y:774,t:1527620941843};\\\", \\\"{x:1410,y:774,t:1527620941887};\\\", \\\"{x:1411,y:775,t:1527620941934};\\\", \\\"{x:1412,y:776,t:1527620941967};\\\", \\\"{x:1412,y:777,t:1527620942013};\\\", \\\"{x:1413,y:777,t:1527620942029};\\\", \\\"{x:1413,y:778,t:1527620942061};\\\", \\\"{x:1415,y:779,t:1527620942118};\\\", \\\"{x:1417,y:780,t:1527620942166};\\\", \\\"{x:1417,y:781,t:1527620942189};\\\", \\\"{x:1417,y:782,t:1527620942214};\\\", \\\"{x:1417,y:783,t:1527620942230};\\\", \\\"{x:1418,y:783,t:1527620942242};\\\", \\\"{x:1421,y:784,t:1527620942259};\\\", \\\"{x:1421,y:785,t:1527620942276};\\\", \\\"{x:1422,y:786,t:1527620942292};\\\", \\\"{x:1422,y:788,t:1527620942309};\\\", \\\"{x:1423,y:789,t:1527620942326};\\\", \\\"{x:1424,y:789,t:1527620942343};\\\", \\\"{x:1424,y:790,t:1527620942390};\\\", \\\"{x:1425,y:791,t:1527620942414};\\\", \\\"{x:1426,y:792,t:1527620942446};\\\", \\\"{x:1427,y:792,t:1527620942487};\\\", \\\"{x:1427,y:794,t:1527620942502};\\\", \\\"{x:1427,y:795,t:1527620942527};\\\", \\\"{x:1427,y:797,t:1527620942559};\\\", \\\"{x:1428,y:797,t:1527620942568};\\\", \\\"{x:1428,y:798,t:1527620942589};\\\", \\\"{x:1429,y:799,t:1527620942614};\\\", \\\"{x:1430,y:800,t:1527620942638};\\\", \\\"{x:1430,y:801,t:1527620942661};\\\", \\\"{x:1430,y:803,t:1527620942685};\\\", \\\"{x:1430,y:804,t:1527620942702};\\\", \\\"{x:1431,y:804,t:1527620942709};\\\", \\\"{x:1432,y:805,t:1527620942726};\\\", \\\"{x:1432,y:807,t:1527620942743};\\\", \\\"{x:1433,y:807,t:1527620942759};\\\", \\\"{x:1433,y:809,t:1527620942776};\\\", \\\"{x:1433,y:811,t:1527620942793};\\\", \\\"{x:1433,y:813,t:1527620942809};\\\", \\\"{x:1433,y:815,t:1527620942826};\\\", \\\"{x:1434,y:816,t:1527620942843};\\\", \\\"{x:1434,y:818,t:1527620942859};\\\", \\\"{x:1435,y:820,t:1527620942876};\\\", \\\"{x:1435,y:823,t:1527620942894};\\\", \\\"{x:1435,y:825,t:1527620942911};\\\", \\\"{x:1436,y:827,t:1527620942927};\\\", \\\"{x:1436,y:828,t:1527620942943};\\\", \\\"{x:1436,y:830,t:1527620942961};\\\", \\\"{x:1437,y:832,t:1527620942977};\\\", \\\"{x:1437,y:833,t:1527620942998};\\\", \\\"{x:1437,y:835,t:1527620943011};\\\", \\\"{x:1437,y:836,t:1527620943030};\\\", \\\"{x:1437,y:837,t:1527620943044};\\\", \\\"{x:1437,y:838,t:1527620943061};\\\", \\\"{x:1437,y:840,t:1527620943077};\\\", \\\"{x:1436,y:841,t:1527620943093};\\\", \\\"{x:1436,y:842,t:1527620943110};\\\", \\\"{x:1436,y:843,t:1527620943150};\\\", \\\"{x:1435,y:844,t:1527620943161};\\\", \\\"{x:1434,y:844,t:1527620943177};\\\", \\\"{x:1433,y:845,t:1527620943193};\\\", \\\"{x:1433,y:846,t:1527620943214};\\\", \\\"{x:1432,y:846,t:1527620943247};\\\", \\\"{x:1432,y:847,t:1527620943261};\\\", \\\"{x:1431,y:848,t:1527620943278};\\\", \\\"{x:1430,y:849,t:1527620943422};\\\", \\\"{x:1429,y:849,t:1527620943447};\\\", \\\"{x:1426,y:851,t:1527620943461};\\\", \\\"{x:1424,y:852,t:1527620943478};\\\", \\\"{x:1423,y:852,t:1527620943502};\\\", \\\"{x:1419,y:852,t:1527620943510};\\\", \\\"{x:1406,y:856,t:1527620943528};\\\", \\\"{x:1395,y:858,t:1527620943544};\\\", \\\"{x:1378,y:858,t:1527620943560};\\\", \\\"{x:1354,y:858,t:1527620943577};\\\", \\\"{x:1338,y:858,t:1527620943595};\\\", \\\"{x:1305,y:854,t:1527620943611};\\\", \\\"{x:1268,y:847,t:1527620943627};\\\", \\\"{x:1220,y:840,t:1527620943645};\\\", \\\"{x:1177,y:832,t:1527620943661};\\\", \\\"{x:1047,y:825,t:1527620943678};\\\", \\\"{x:962,y:817,t:1527620943694};\\\", \\\"{x:881,y:816,t:1527620943711};\\\", \\\"{x:843,y:815,t:1527620943728};\\\", \\\"{x:827,y:811,t:1527620943744};\\\", \\\"{x:815,y:809,t:1527620943760};\\\", \\\"{x:801,y:806,t:1527620943778};\\\", \\\"{x:794,y:804,t:1527620943794};\\\", \\\"{x:790,y:803,t:1527620943822};\\\", \\\"{x:780,y:799,t:1527620943829};\\\", \\\"{x:775,y:796,t:1527620943844};\\\", \\\"{x:774,y:793,t:1527620943860};\\\", \\\"{x:767,y:788,t:1527620943877};\\\", \\\"{x:766,y:787,t:1527620943894};\\\", \\\"{x:761,y:782,t:1527620943910};\\\", \\\"{x:754,y:781,t:1527620943927};\\\", \\\"{x:751,y:779,t:1527620943944};\\\", \\\"{x:743,y:776,t:1527620943961};\\\", \\\"{x:728,y:773,t:1527620943977};\\\", \\\"{x:724,y:772,t:1527620943994};\\\", \\\"{x:721,y:768,t:1527620944011};\\\", \\\"{x:709,y:767,t:1527620944027};\\\", \\\"{x:700,y:763,t:1527620944044};\\\", \\\"{x:692,y:763,t:1527620944061};\\\", \\\"{x:685,y:762,t:1527620944077};\\\", \\\"{x:680,y:759,t:1527620944094};\\\", \\\"{x:678,y:759,t:1527620944111};\\\", \\\"{x:676,y:758,t:1527620944127};\\\", \\\"{x:672,y:756,t:1527620944270};\\\", \\\"{x:670,y:755,t:1527620944278};\\\", \\\"{x:668,y:752,t:1527620944295};\\\", \\\"{x:667,y:752,t:1527620944311};\\\", \\\"{x:666,y:752,t:1527620944328};\\\", \\\"{x:665,y:752,t:1527620944749};\\\", \\\"{x:661,y:751,t:1527620944761};\\\", \\\"{x:655,y:748,t:1527620944778};\\\", \\\"{x:651,y:748,t:1527620944795};\\\", \\\"{x:651,y:750,t:1527620944837};\\\", \\\"{x:651,y:751,t:1527620944861};\\\", \\\"{x:644,y:751,t:1527620944878};\\\", \\\"{x:639,y:751,t:1527620944894};\\\", \\\"{x:632,y:750,t:1527620944911};\\\", \\\"{x:625,y:749,t:1527620944928};\\\", \\\"{x:612,y:749,t:1527620944945};\\\", \\\"{x:599,y:749,t:1527620944962};\\\", \\\"{x:586,y:747,t:1527620944978};\\\", \\\"{x:576,y:744,t:1527620944995};\\\", \\\"{x:560,y:740,t:1527620945012};\\\", \\\"{x:550,y:736,t:1527620945028};\\\", \\\"{x:537,y:734,t:1527620945045};\\\", \\\"{x:529,y:732,t:1527620945069};\\\", \\\"{x:524,y:731,t:1527620945086};\\\", \\\"{x:519,y:731,t:1527620945103};\\\", \\\"{x:517,y:731,t:1527620945119};\\\", \\\"{x:516,y:731,t:1527620945149};\\\", \\\"{x:516,y:731,t:1527620945272};\\\", \\\"{x:515,y:731,t:1527620945949};\\\", \\\"{x:518,y:731,t:1527620945974};\\\", \\\"{x:524,y:730,t:1527620945989};\\\", \\\"{x:534,y:728,t:1527620946006};\\\", \\\"{x:548,y:727,t:1527620946022};\\\", \\\"{x:562,y:727,t:1527620946039};\\\", \\\"{x:574,y:727,t:1527620946056};\\\", \\\"{x:586,y:727,t:1527620946073};\\\", \\\"{x:599,y:726,t:1527620946089};\\\", \\\"{x:618,y:723,t:1527620946106};\\\", \\\"{x:634,y:717,t:1527620946123};\\\", \\\"{x:656,y:715,t:1527620946139};\\\", \\\"{x:669,y:714,t:1527620946156};\\\", \\\"{x:680,y:710,t:1527620946173};\\\", \\\"{x:695,y:708,t:1527620946190};\\\", \\\"{x:707,y:707,t:1527620946206};\\\", \\\"{x:715,y:704,t:1527620946224};\\\", \\\"{x:728,y:702,t:1527620946240};\\\", \\\"{x:738,y:702,t:1527620946256};\\\", \\\"{x:750,y:699,t:1527620946274};\\\", \\\"{x:761,y:697,t:1527620946289};\\\", \\\"{x:769,y:696,t:1527620946307};\\\", \\\"{x:778,y:694,t:1527620946323};\\\", \\\"{x:783,y:694,t:1527620946339};\\\", \\\"{x:787,y:693,t:1527620946356};\\\", \\\"{x:789,y:693,t:1527620946373};\\\", \\\"{x:790,y:693,t:1527620946429};\\\" ] }, { \\\"rt\\\": 8370, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 354221, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:795,y:690,t:1527620947797};\\\", \\\"{x:804,y:682,t:1527620947808};\\\", \\\"{x:823,y:667,t:1527620947824};\\\", \\\"{x:840,y:651,t:1527620947841};\\\", \\\"{x:863,y:637,t:1527620947857};\\\", \\\"{x:879,y:626,t:1527620947874};\\\", \\\"{x:894,y:617,t:1527620947891};\\\", \\\"{x:895,y:617,t:1527620947907};\\\", \\\"{x:897,y:617,t:1527620947924};\\\", \\\"{x:913,y:615,t:1527620947941};\\\", \\\"{x:931,y:609,t:1527620947957};\\\", \\\"{x:944,y:602,t:1527620947974};\\\", \\\"{x:966,y:596,t:1527620947992};\\\", \\\"{x:1006,y:592,t:1527620948007};\\\", \\\"{x:1061,y:586,t:1527620948024};\\\", \\\"{x:1119,y:579,t:1527620948041};\\\", \\\"{x:1203,y:576,t:1527620948058};\\\", \\\"{x:1284,y:576,t:1527620948075};\\\", \\\"{x:1364,y:576,t:1527620948091};\\\", \\\"{x:1429,y:577,t:1527620948107};\\\", \\\"{x:1478,y:588,t:1527620948124};\\\", \\\"{x:1560,y:599,t:1527620948141};\\\", \\\"{x:1605,y:611,t:1527620948159};\\\", \\\"{x:1637,y:614,t:1527620948175};\\\", \\\"{x:1672,y:626,t:1527620948191};\\\", \\\"{x:1709,y:639,t:1527620948208};\\\", \\\"{x:1735,y:652,t:1527620948224};\\\", \\\"{x:1761,y:665,t:1527620948241};\\\", \\\"{x:1786,y:679,t:1527620948258};\\\", \\\"{x:1799,y:693,t:1527620948274};\\\", \\\"{x:1813,y:707,t:1527620948291};\\\", \\\"{x:1820,y:724,t:1527620948308};\\\", \\\"{x:1825,y:745,t:1527620948324};\\\", \\\"{x:1826,y:783,t:1527620948341};\\\", \\\"{x:1816,y:818,t:1527620948358};\\\", \\\"{x:1789,y:868,t:1527620948374};\\\", \\\"{x:1759,y:911,t:1527620948391};\\\", \\\"{x:1715,y:957,t:1527620948409};\\\", \\\"{x:1687,y:984,t:1527620948424};\\\", \\\"{x:1666,y:1008,t:1527620948441};\\\", \\\"{x:1614,y:1048,t:1527620948458};\\\", \\\"{x:1524,y:1100,t:1527620948474};\\\", \\\"{x:1428,y:1123,t:1527620948491};\\\", \\\"{x:1331,y:1151,t:1527620948508};\\\", \\\"{x:1325,y:1154,t:1527620948525};\\\", \\\"{x:1324,y:1154,t:1527620949029};\\\", \\\"{x:1325,y:1154,t:1527620949042};\\\", \\\"{x:1325,y:1153,t:1527620949058};\\\", \\\"{x:1332,y:1151,t:1527620949075};\\\", \\\"{x:1336,y:1138,t:1527620949092};\\\", \\\"{x:1329,y:1113,t:1527620949109};\\\", \\\"{x:1328,y:1051,t:1527620949125};\\\", \\\"{x:1318,y:995,t:1527620949143};\\\", \\\"{x:1318,y:958,t:1527620949159};\\\", \\\"{x:1318,y:928,t:1527620949176};\\\", \\\"{x:1318,y:898,t:1527620949193};\\\", \\\"{x:1320,y:868,t:1527620949208};\\\", \\\"{x:1326,y:833,t:1527620949225};\\\", \\\"{x:1328,y:804,t:1527620949243};\\\", \\\"{x:1334,y:785,t:1527620949258};\\\", \\\"{x:1334,y:771,t:1527620949276};\\\", \\\"{x:1333,y:752,t:1527620949292};\\\", \\\"{x:1328,y:737,t:1527620949309};\\\", \\\"{x:1322,y:718,t:1527620949325};\\\", \\\"{x:1321,y:705,t:1527620949343};\\\", \\\"{x:1315,y:687,t:1527620949358};\\\", \\\"{x:1314,y:678,t:1527620949375};\\\", \\\"{x:1309,y:664,t:1527620949392};\\\", \\\"{x:1301,y:648,t:1527620949408};\\\", \\\"{x:1296,y:637,t:1527620949426};\\\", \\\"{x:1289,y:624,t:1527620949442};\\\", \\\"{x:1285,y:615,t:1527620949459};\\\", \\\"{x:1277,y:602,t:1527620949475};\\\", \\\"{x:1274,y:594,t:1527620949492};\\\", \\\"{x:1266,y:585,t:1527620949509};\\\", \\\"{x:1265,y:582,t:1527620949525};\\\", \\\"{x:1265,y:579,t:1527620949543};\\\", \\\"{x:1264,y:578,t:1527620949565};\\\", \\\"{x:1264,y:575,t:1527620949806};\\\", \\\"{x:1270,y:569,t:1527620949813};\\\", \\\"{x:1274,y:568,t:1527620949825};\\\", \\\"{x:1274,y:567,t:1527620949842};\\\", \\\"{x:1277,y:567,t:1527620950126};\\\", \\\"{x:1282,y:566,t:1527620950142};\\\", \\\"{x:1294,y:565,t:1527620950161};\\\", \\\"{x:1309,y:565,t:1527620950176};\\\", \\\"{x:1324,y:565,t:1527620950192};\\\", \\\"{x:1335,y:565,t:1527620950209};\\\", \\\"{x:1345,y:565,t:1527620950226};\\\", \\\"{x:1346,y:565,t:1527620950245};\\\", \\\"{x:1348,y:565,t:1527620950259};\\\", \\\"{x:1349,y:565,t:1527620950285};\\\", \\\"{x:1350,y:565,t:1527620950293};\\\", \\\"{x:1356,y:565,t:1527620950309};\\\", \\\"{x:1362,y:565,t:1527620950326};\\\", \\\"{x:1370,y:565,t:1527620950343};\\\", \\\"{x:1382,y:565,t:1527620950360};\\\", \\\"{x:1394,y:565,t:1527620950376};\\\", \\\"{x:1411,y:565,t:1527620950393};\\\", \\\"{x:1424,y:565,t:1527620950410};\\\", \\\"{x:1433,y:566,t:1527620950427};\\\", \\\"{x:1435,y:566,t:1527620950444};\\\", \\\"{x:1436,y:567,t:1527620950917};\\\", \\\"{x:1434,y:568,t:1527620950941};\\\", \\\"{x:1434,y:569,t:1527620950965};\\\", \\\"{x:1433,y:569,t:1527620950976};\\\", \\\"{x:1432,y:570,t:1527620950993};\\\", \\\"{x:1431,y:570,t:1527620951010};\\\", \\\"{x:1430,y:570,t:1527620951026};\\\", \\\"{x:1415,y:573,t:1527620951043};\\\", \\\"{x:1341,y:575,t:1527620951061};\\\", \\\"{x:1232,y:570,t:1527620951076};\\\", \\\"{x:1029,y:552,t:1527620951093};\\\", \\\"{x:915,y:558,t:1527620951110};\\\", \\\"{x:823,y:574,t:1527620951127};\\\", \\\"{x:722,y:592,t:1527620951143};\\\", \\\"{x:612,y:618,t:1527620951160};\\\", \\\"{x:509,y:634,t:1527620951175};\\\", \\\"{x:433,y:651,t:1527620951194};\\\", \\\"{x:385,y:651,t:1527620951211};\\\", \\\"{x:376,y:652,t:1527620951227};\\\", \\\"{x:375,y:652,t:1527620951243};\\\", \\\"{x:375,y:651,t:1527620951373};\\\", \\\"{x:376,y:648,t:1527620951380};\\\", \\\"{x:382,y:641,t:1527620951393};\\\", \\\"{x:386,y:632,t:1527620951410};\\\", \\\"{x:394,y:624,t:1527620951427};\\\", \\\"{x:405,y:617,t:1527620951444};\\\", \\\"{x:417,y:610,t:1527620951461};\\\", \\\"{x:449,y:600,t:1527620951478};\\\", \\\"{x:462,y:594,t:1527620951494};\\\", \\\"{x:490,y:593,t:1527620951511};\\\", \\\"{x:521,y:591,t:1527620951527};\\\", \\\"{x:553,y:590,t:1527620951543};\\\", \\\"{x:585,y:586,t:1527620951560};\\\", \\\"{x:606,y:582,t:1527620951577};\\\", \\\"{x:613,y:579,t:1527620951593};\\\", \\\"{x:615,y:577,t:1527620951610};\\\", \\\"{x:615,y:575,t:1527620951637};\\\", \\\"{x:614,y:573,t:1527620951652};\\\", \\\"{x:613,y:573,t:1527620951661};\\\", \\\"{x:608,y:570,t:1527620951677};\\\", \\\"{x:603,y:567,t:1527620951693};\\\", \\\"{x:593,y:563,t:1527620951711};\\\", \\\"{x:590,y:560,t:1527620951727};\\\", \\\"{x:588,y:558,t:1527620951745};\\\", \\\"{x:588,y:557,t:1527620951765};\\\", \\\"{x:588,y:556,t:1527620951777};\\\", \\\"{x:588,y:552,t:1527620951795};\\\", \\\"{x:588,y:547,t:1527620951810};\\\", \\\"{x:588,y:540,t:1527620951828};\\\", \\\"{x:588,y:536,t:1527620951845};\\\", \\\"{x:587,y:531,t:1527620951861};\\\", \\\"{x:587,y:525,t:1527620951877};\\\", \\\"{x:587,y:521,t:1527620951894};\\\", \\\"{x:587,y:519,t:1527620951912};\\\", \\\"{x:587,y:518,t:1527620951927};\\\", \\\"{x:587,y:516,t:1527620951958};\\\", \\\"{x:588,y:514,t:1527620951997};\\\", \\\"{x:589,y:512,t:1527620952029};\\\", \\\"{x:591,y:510,t:1527620952045};\\\", \\\"{x:593,y:507,t:1527620952068};\\\", \\\"{x:595,y:505,t:1527620952085};\\\", \\\"{x:597,y:503,t:1527620952100};\\\", \\\"{x:598,y:503,t:1527620952117};\\\", \\\"{x:598,y:502,t:1527620952127};\\\", \\\"{x:599,y:502,t:1527620952145};\\\", \\\"{x:602,y:501,t:1527620952161};\\\", \\\"{x:603,y:500,t:1527620952177};\\\", \\\"{x:604,y:500,t:1527620952197};\\\", \\\"{x:605,y:500,t:1527620952221};\\\", \\\"{x:606,y:499,t:1527620952237};\\\", \\\"{x:606,y:499,t:1527620952359};\\\", \\\"{x:607,y:499,t:1527620952501};\\\", \\\"{x:611,y:499,t:1527620952511};\\\", \\\"{x:626,y:506,t:1527620952529};\\\", \\\"{x:667,y:517,t:1527620952544};\\\", \\\"{x:691,y:525,t:1527620952561};\\\", \\\"{x:705,y:536,t:1527620952578};\\\", \\\"{x:726,y:538,t:1527620952595};\\\", \\\"{x:729,y:538,t:1527620952611};\\\", \\\"{x:731,y:538,t:1527620952677};\\\", \\\"{x:732,y:538,t:1527620952684};\\\", \\\"{x:734,y:538,t:1527620952695};\\\", \\\"{x:739,y:536,t:1527620952711};\\\", \\\"{x:746,y:535,t:1527620952728};\\\", \\\"{x:750,y:533,t:1527620952745};\\\", \\\"{x:753,y:533,t:1527620952762};\\\", \\\"{x:757,y:532,t:1527620952779};\\\", \\\"{x:763,y:531,t:1527620952795};\\\", \\\"{x:768,y:529,t:1527620952811};\\\", \\\"{x:774,y:529,t:1527620952828};\\\", \\\"{x:780,y:529,t:1527620952845};\\\", \\\"{x:791,y:529,t:1527620952861};\\\", \\\"{x:806,y:529,t:1527620952878};\\\", \\\"{x:823,y:533,t:1527620952896};\\\", \\\"{x:836,y:535,t:1527620952911};\\\", \\\"{x:841,y:538,t:1527620952928};\\\", \\\"{x:843,y:538,t:1527620952946};\\\", \\\"{x:843,y:539,t:1527620952988};\\\", \\\"{x:844,y:539,t:1527620953045};\\\", \\\"{x:844,y:538,t:1527620953276};\\\", \\\"{x:838,y:539,t:1527620953284};\\\", \\\"{x:834,y:540,t:1527620953295};\\\", \\\"{x:824,y:545,t:1527620953312};\\\", \\\"{x:813,y:553,t:1527620953328};\\\", \\\"{x:804,y:559,t:1527620953346};\\\", \\\"{x:785,y:568,t:1527620953363};\\\", \\\"{x:767,y:580,t:1527620953378};\\\", \\\"{x:740,y:600,t:1527620953396};\\\", \\\"{x:725,y:615,t:1527620953413};\\\", \\\"{x:713,y:623,t:1527620953429};\\\", \\\"{x:712,y:623,t:1527620953469};\\\", \\\"{x:711,y:623,t:1527620953478};\\\", \\\"{x:710,y:623,t:1527620953605};\\\", \\\"{x:708,y:623,t:1527620953620};\\\", \\\"{x:707,y:623,t:1527620953629};\\\", \\\"{x:692,y:637,t:1527620953646};\\\", \\\"{x:669,y:659,t:1527620953662};\\\", \\\"{x:651,y:680,t:1527620953678};\\\", \\\"{x:630,y:700,t:1527620953695};\\\", \\\"{x:627,y:704,t:1527620953711};\\\", \\\"{x:627,y:706,t:1527620953729};\\\", \\\"{x:624,y:706,t:1527620953789};\\\", \\\"{x:622,y:706,t:1527620953813};\\\", \\\"{x:617,y:705,t:1527620953837};\\\", \\\"{x:617,y:703,t:1527620953845};\\\", \\\"{x:615,y:701,t:1527620953869};\\\", \\\"{x:614,y:701,t:1527620953879};\\\", \\\"{x:611,y:699,t:1527620953895};\\\", \\\"{x:598,y:697,t:1527620953911};\\\", \\\"{x:575,y:697,t:1527620953928};\\\", \\\"{x:559,y:697,t:1527620953946};\\\", \\\"{x:553,y:698,t:1527620953961};\\\", \\\"{x:550,y:700,t:1527620953979};\\\", \\\"{x:549,y:700,t:1527620954037};\\\", \\\"{x:548,y:699,t:1527620954053};\\\", \\\"{x:546,y:701,t:1527620954213};\\\", \\\"{x:540,y:704,t:1527620954229};\\\", \\\"{x:525,y:714,t:1527620954245};\\\", \\\"{x:519,y:724,t:1527620954262};\\\", \\\"{x:510,y:731,t:1527620954279};\\\", \\\"{x:500,y:739,t:1527620954296};\\\", \\\"{x:496,y:742,t:1527620954312};\\\", \\\"{x:493,y:745,t:1527620954330};\\\", \\\"{x:490,y:747,t:1527620954346};\\\", \\\"{x:487,y:749,t:1527620954362};\\\", \\\"{x:482,y:753,t:1527620954380};\\\", \\\"{x:479,y:755,t:1527620954396};\\\", \\\"{x:475,y:758,t:1527620954412};\\\", \\\"{x:467,y:766,t:1527620954430};\\\", \\\"{x:464,y:768,t:1527620954446};\\\", \\\"{x:463,y:769,t:1527620954621};\\\", \\\"{x:463,y:768,t:1527620954629};\\\", \\\"{x:463,y:765,t:1527620954646};\\\", \\\"{x:463,y:760,t:1527620954663};\\\", \\\"{x:463,y:759,t:1527620954679};\\\", \\\"{x:463,y:758,t:1527620954700};\\\", \\\"{x:464,y:754,t:1527620954837};\\\", \\\"{x:464,y:752,t:1527620954846};\\\", \\\"{x:464,y:751,t:1527620954863};\\\", \\\"{x:466,y:750,t:1527620954879};\\\", \\\"{x:466,y:747,t:1527620954909};\\\", \\\"{x:466,y:746,t:1527620954933};\\\", \\\"{x:467,y:743,t:1527620954946};\\\", \\\"{x:468,y:740,t:1527620954964};\\\", \\\"{x:469,y:737,t:1527620954979};\\\", \\\"{x:470,y:736,t:1527620954997};\\\", \\\"{x:470,y:734,t:1527620955013};\\\", \\\"{x:472,y:732,t:1527620955031};\\\", \\\"{x:472,y:731,t:1527620955046};\\\", \\\"{x:473,y:731,t:1527620955266};\\\", \\\"{x:474,y:729,t:1527620955280};\\\", \\\"{x:474,y:727,t:1527620955296};\\\", \\\"{x:474,y:725,t:1527620956381};\\\", \\\"{x:478,y:720,t:1527620956397};\\\" ] }, { \\\"rt\\\": 62285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 417761, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -M -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:703,t:1527620956503};\\\", \\\"{x:498,y:702,t:1527620956518};\\\", \\\"{x:500,y:700,t:1527620956547};\\\", \\\"{x:501,y:700,t:1527620956551};\\\", \\\"{x:503,y:697,t:1527620956564};\\\", \\\"{x:506,y:694,t:1527620956581};\\\", \\\"{x:509,y:692,t:1527620956617};\\\", \\\"{x:511,y:689,t:1527620956632};\\\", \\\"{x:514,y:686,t:1527620956648};\\\", \\\"{x:516,y:684,t:1527620956664};\\\", \\\"{x:518,y:683,t:1527620956681};\\\", \\\"{x:522,y:683,t:1527620956699};\\\", \\\"{x:526,y:682,t:1527620956714};\\\", \\\"{x:529,y:680,t:1527620956731};\\\", \\\"{x:531,y:679,t:1527620956748};\\\", \\\"{x:533,y:679,t:1527620956764};\\\", \\\"{x:537,y:677,t:1527620956782};\\\", \\\"{x:539,y:677,t:1527620956798};\\\", \\\"{x:544,y:675,t:1527620956814};\\\", \\\"{x:548,y:675,t:1527620956832};\\\", \\\"{x:554,y:672,t:1527620956848};\\\", \\\"{x:557,y:672,t:1527620956864};\\\", \\\"{x:561,y:671,t:1527620956881};\\\", \\\"{x:565,y:669,t:1527620957008};\\\", \\\"{x:566,y:669,t:1527620959565};\\\", \\\"{x:573,y:669,t:1527620959573};\\\", \\\"{x:578,y:669,t:1527620959583};\\\", \\\"{x:595,y:669,t:1527620959601};\\\", \\\"{x:617,y:670,t:1527620959617};\\\", \\\"{x:638,y:674,t:1527620959634};\\\", \\\"{x:667,y:685,t:1527620959651};\\\", \\\"{x:720,y:696,t:1527620959667};\\\", \\\"{x:771,y:707,t:1527620959683};\\\", \\\"{x:836,y:724,t:1527620959701};\\\", \\\"{x:868,y:730,t:1527620959717};\\\", \\\"{x:891,y:737,t:1527620959733};\\\", \\\"{x:919,y:743,t:1527620959751};\\\", \\\"{x:947,y:745,t:1527620959768};\\\", \\\"{x:972,y:750,t:1527620959783};\\\", \\\"{x:994,y:753,t:1527620959800};\\\", \\\"{x:1020,y:755,t:1527620959818};\\\", \\\"{x:1044,y:756,t:1527620959833};\\\", \\\"{x:1064,y:761,t:1527620959851};\\\", \\\"{x:1082,y:762,t:1527620959868};\\\", \\\"{x:1102,y:762,t:1527620959883};\\\", \\\"{x:1129,y:767,t:1527620959901};\\\", \\\"{x:1146,y:771,t:1527620959918};\\\", \\\"{x:1160,y:771,t:1527620959934};\\\", \\\"{x:1173,y:775,t:1527620959950};\\\", \\\"{x:1196,y:781,t:1527620959968};\\\", \\\"{x:1213,y:785,t:1527620959983};\\\", \\\"{x:1229,y:790,t:1527620960001};\\\", \\\"{x:1250,y:793,t:1527620960018};\\\", \\\"{x:1264,y:796,t:1527620960034};\\\", \\\"{x:1272,y:798,t:1527620960051};\\\", \\\"{x:1276,y:800,t:1527620960068};\\\", \\\"{x:1277,y:800,t:1527620960085};\\\", \\\"{x:1275,y:800,t:1527620960293};\\\", \\\"{x:1272,y:800,t:1527620960309};\\\", \\\"{x:1270,y:800,t:1527620960318};\\\", \\\"{x:1263,y:800,t:1527620960334};\\\", \\\"{x:1252,y:795,t:1527620960350};\\\", \\\"{x:1238,y:792,t:1527620960367};\\\", \\\"{x:1231,y:790,t:1527620960384};\\\", \\\"{x:1224,y:789,t:1527620960401};\\\", \\\"{x:1213,y:784,t:1527620960418};\\\", \\\"{x:1197,y:783,t:1527620960435};\\\", \\\"{x:1184,y:778,t:1527620960451};\\\", \\\"{x:1168,y:775,t:1527620960467};\\\", \\\"{x:1158,y:773,t:1527620960485};\\\", \\\"{x:1157,y:771,t:1527620960501};\\\", \\\"{x:1157,y:769,t:1527620960922};\\\", \\\"{x:1157,y:768,t:1527620960933};\\\", \\\"{x:1157,y:767,t:1527620960971};\\\", \\\"{x:1157,y:766,t:1527620960987};\\\", \\\"{x:1157,y:765,t:1527620961019};\\\", \\\"{x:1157,y:764,t:1527620961033};\\\", \\\"{x:1157,y:763,t:1527620961148};\\\", \\\"{x:1157,y:761,t:1527620961483};\\\", \\\"{x:1157,y:757,t:1527620961500};\\\", \\\"{x:1159,y:758,t:1527620967395};\\\", \\\"{x:1164,y:759,t:1527620967405};\\\", \\\"{x:1175,y:759,t:1527620967421};\\\", \\\"{x:1190,y:759,t:1527620967439};\\\", \\\"{x:1198,y:759,t:1527620967455};\\\", \\\"{x:1204,y:758,t:1527620967471};\\\", \\\"{x:1206,y:757,t:1527620967488};\\\", \\\"{x:1209,y:756,t:1527620967505};\\\", \\\"{x:1210,y:755,t:1527620967531};\\\", \\\"{x:1214,y:755,t:1527620968026};\\\", \\\"{x:1220,y:760,t:1527620968039};\\\", \\\"{x:1223,y:765,t:1527620968055};\\\", \\\"{x:1226,y:776,t:1527620968072};\\\", \\\"{x:1229,y:780,t:1527620968089};\\\", \\\"{x:1231,y:782,t:1527620968105};\\\", \\\"{x:1232,y:784,t:1527620968122};\\\", \\\"{x:1234,y:788,t:1527620968139};\\\", \\\"{x:1234,y:789,t:1527620968155};\\\", \\\"{x:1234,y:791,t:1527620968172};\\\", \\\"{x:1234,y:794,t:1527620968190};\\\", \\\"{x:1234,y:796,t:1527620968205};\\\", \\\"{x:1234,y:799,t:1527620968222};\\\", \\\"{x:1234,y:802,t:1527620968239};\\\", \\\"{x:1234,y:804,t:1527620968259};\\\", \\\"{x:1233,y:805,t:1527620968272};\\\", \\\"{x:1232,y:807,t:1527620968289};\\\", \\\"{x:1231,y:809,t:1527620968315};\\\", \\\"{x:1231,y:810,t:1527620968379};\\\", \\\"{x:1231,y:811,t:1527620968426};\\\", \\\"{x:1231,y:812,t:1527620968439};\\\", \\\"{x:1230,y:814,t:1527620968456};\\\", \\\"{x:1228,y:816,t:1527620968531};\\\", \\\"{x:1227,y:817,t:1527620968539};\\\", \\\"{x:1227,y:818,t:1527620968557};\\\", \\\"{x:1221,y:823,t:1527620968572};\\\", \\\"{x:1217,y:826,t:1527620968590};\\\", \\\"{x:1215,y:828,t:1527620968606};\\\", \\\"{x:1213,y:829,t:1527620968622};\\\", \\\"{x:1213,y:830,t:1527620968639};\\\", \\\"{x:1212,y:830,t:1527620968700};\\\", \\\"{x:1211,y:830,t:1527620968723};\\\", \\\"{x:1210,y:830,t:1527620968739};\\\", \\\"{x:1209,y:830,t:1527620968771};\\\", \\\"{x:1208,y:831,t:1527620968787};\\\", \\\"{x:1208,y:832,t:1527620969051};\\\", \\\"{x:1209,y:832,t:1527620969275};\\\", \\\"{x:1210,y:832,t:1527620969539};\\\", \\\"{x:1212,y:832,t:1527620969651};\\\", \\\"{x:1213,y:831,t:1527620969979};\\\", \\\"{x:1214,y:830,t:1527620972963};\\\", \\\"{x:1215,y:830,t:1527620972976};\\\", \\\"{x:1217,y:829,t:1527620973091};\\\", \\\"{x:1219,y:827,t:1527620973098};\\\", \\\"{x:1220,y:827,t:1527620973131};\\\", \\\"{x:1222,y:825,t:1527620973147};\\\", \\\"{x:1224,y:824,t:1527620973162};\\\", \\\"{x:1225,y:824,t:1527620973176};\\\", \\\"{x:1230,y:824,t:1527620973192};\\\", \\\"{x:1245,y:828,t:1527620973210};\\\", \\\"{x:1264,y:831,t:1527620973226};\\\", \\\"{x:1284,y:837,t:1527620973242};\\\", \\\"{x:1299,y:840,t:1527620973259};\\\", \\\"{x:1314,y:843,t:1527620973276};\\\", \\\"{x:1327,y:845,t:1527620973294};\\\", \\\"{x:1338,y:847,t:1527620973310};\\\", \\\"{x:1345,y:848,t:1527620973326};\\\", \\\"{x:1349,y:848,t:1527620973344};\\\", \\\"{x:1354,y:848,t:1527620973359};\\\", \\\"{x:1359,y:848,t:1527620973376};\\\", \\\"{x:1362,y:849,t:1527620973393};\\\", \\\"{x:1364,y:849,t:1527620973410};\\\", \\\"{x:1367,y:849,t:1527620973427};\\\", \\\"{x:1368,y:849,t:1527620973443};\\\", \\\"{x:1370,y:849,t:1527620973474};\\\", \\\"{x:1371,y:849,t:1527620973490};\\\", \\\"{x:1373,y:849,t:1527620973514};\\\", \\\"{x:1374,y:850,t:1527620973626};\\\", \\\"{x:1374,y:852,t:1527620973643};\\\", \\\"{x:1374,y:854,t:1527620973659};\\\", \\\"{x:1374,y:856,t:1527620973676};\\\", \\\"{x:1374,y:860,t:1527620973693};\\\", \\\"{x:1374,y:861,t:1527620973710};\\\", \\\"{x:1374,y:863,t:1527620973726};\\\", \\\"{x:1374,y:865,t:1527620973743};\\\", \\\"{x:1374,y:866,t:1527620973763};\\\", \\\"{x:1375,y:868,t:1527620973795};\\\", \\\"{x:1375,y:869,t:1527620973811};\\\", \\\"{x:1376,y:870,t:1527620973826};\\\", \\\"{x:1376,y:871,t:1527620973843};\\\", \\\"{x:1376,y:872,t:1527620973866};\\\", \\\"{x:1376,y:873,t:1527620973899};\\\", \\\"{x:1377,y:875,t:1527620973922};\\\", \\\"{x:1377,y:876,t:1527620973962};\\\", \\\"{x:1377,y:877,t:1527620973976};\\\", \\\"{x:1378,y:879,t:1527620973995};\\\", \\\"{x:1378,y:881,t:1527620974018};\\\", \\\"{x:1378,y:882,t:1527620974026};\\\", \\\"{x:1378,y:883,t:1527620974051};\\\", \\\"{x:1378,y:884,t:1527620974067};\\\", \\\"{x:1378,y:885,t:1527620974099};\\\", \\\"{x:1378,y:886,t:1527620974187};\\\", \\\"{x:1379,y:887,t:1527620974227};\\\", \\\"{x:1380,y:888,t:1527620974250};\\\", \\\"{x:1381,y:888,t:1527620974354};\\\", \\\"{x:1382,y:889,t:1527620974786};\\\", \\\"{x:1382,y:890,t:1527620982155};\\\", \\\"{x:1382,y:891,t:1527620982186};\\\", \\\"{x:1382,y:892,t:1527620982219};\\\", \\\"{x:1382,y:893,t:1527620982250};\\\", \\\"{x:1382,y:894,t:1527620982266};\\\", \\\"{x:1382,y:895,t:1527620982283};\\\", \\\"{x:1381,y:895,t:1527620982299};\\\", \\\"{x:1380,y:896,t:1527620982316};\\\", \\\"{x:1379,y:897,t:1527620982334};\\\", \\\"{x:1378,y:897,t:1527620982350};\\\", \\\"{x:1377,y:897,t:1527620982367};\\\", \\\"{x:1377,y:898,t:1527620982384};\\\", \\\"{x:1375,y:899,t:1527620982400};\\\", \\\"{x:1373,y:900,t:1527620982417};\\\", \\\"{x:1369,y:901,t:1527620982434};\\\", \\\"{x:1368,y:901,t:1527620982449};\\\", \\\"{x:1366,y:901,t:1527620982466};\\\", \\\"{x:1363,y:903,t:1527620982484};\\\", \\\"{x:1364,y:902,t:1527620985819};\\\", \\\"{x:1365,y:902,t:1527620985826};\\\", \\\"{x:1367,y:902,t:1527620985842};\\\", \\\"{x:1368,y:901,t:1527620985914};\\\", \\\"{x:1369,y:901,t:1527620985954};\\\", \\\"{x:1370,y:901,t:1527620985970};\\\", \\\"{x:1372,y:901,t:1527620985986};\\\", \\\"{x:1379,y:901,t:1527620986003};\\\", \\\"{x:1380,y:901,t:1527620986020};\\\", \\\"{x:1382,y:901,t:1527620986036};\\\", \\\"{x:1384,y:901,t:1527620986053};\\\", \\\"{x:1385,y:901,t:1527620986070};\\\", \\\"{x:1386,y:901,t:1527620986154};\\\", \\\"{x:1387,y:901,t:1527620986170};\\\", \\\"{x:1388,y:901,t:1527620986187};\\\", \\\"{x:1389,y:901,t:1527620986203};\\\", \\\"{x:1390,y:901,t:1527620986220};\\\", \\\"{x:1391,y:901,t:1527620986237};\\\", \\\"{x:1393,y:901,t:1527620986253};\\\", \\\"{x:1395,y:901,t:1527620986270};\\\", \\\"{x:1396,y:901,t:1527620986287};\\\", \\\"{x:1399,y:901,t:1527620986303};\\\", \\\"{x:1401,y:901,t:1527620986320};\\\", \\\"{x:1404,y:901,t:1527620986346};\\\", \\\"{x:1405,y:901,t:1527620986362};\\\", \\\"{x:1408,y:902,t:1527620986370};\\\", \\\"{x:1409,y:903,t:1527620986387};\\\", \\\"{x:1410,y:903,t:1527620986403};\\\", \\\"{x:1411,y:903,t:1527620986420};\\\", \\\"{x:1411,y:904,t:1527620986437};\\\", \\\"{x:1410,y:904,t:1527620990467};\\\", \\\"{x:1409,y:904,t:1527620990474};\\\", \\\"{x:1407,y:904,t:1527620990490};\\\", \\\"{x:1402,y:904,t:1527620990506};\\\", \\\"{x:1401,y:905,t:1527620990523};\\\", \\\"{x:1397,y:906,t:1527620990540};\\\", \\\"{x:1392,y:907,t:1527620990557};\\\", \\\"{x:1386,y:909,t:1527620990573};\\\", \\\"{x:1378,y:911,t:1527620990590};\\\", \\\"{x:1371,y:911,t:1527620990607};\\\", \\\"{x:1360,y:912,t:1527620990623};\\\", \\\"{x:1348,y:912,t:1527620990640};\\\", \\\"{x:1336,y:912,t:1527620990657};\\\", \\\"{x:1329,y:912,t:1527620990673};\\\", \\\"{x:1324,y:912,t:1527620990690};\\\", \\\"{x:1314,y:912,t:1527620990707};\\\", \\\"{x:1304,y:912,t:1527620990723};\\\", \\\"{x:1291,y:909,t:1527620990740};\\\", \\\"{x:1272,y:908,t:1527620990757};\\\", \\\"{x:1251,y:905,t:1527620990773};\\\", \\\"{x:1229,y:902,t:1527620990790};\\\", \\\"{x:1214,y:898,t:1527620990807};\\\", \\\"{x:1203,y:895,t:1527620990823};\\\", \\\"{x:1194,y:893,t:1527620990840};\\\", \\\"{x:1185,y:889,t:1527620990857};\\\", \\\"{x:1173,y:886,t:1527620990874};\\\", \\\"{x:1167,y:884,t:1527620990890};\\\", \\\"{x:1159,y:881,t:1527620990907};\\\", \\\"{x:1158,y:881,t:1527620990924};\\\", \\\"{x:1157,y:881,t:1527620990940};\\\", \\\"{x:1156,y:880,t:1527620990957};\\\", \\\"{x:1155,y:880,t:1527620990974};\\\", \\\"{x:1153,y:878,t:1527620990990};\\\", \\\"{x:1151,y:877,t:1527620991007};\\\", \\\"{x:1148,y:875,t:1527620991024};\\\", \\\"{x:1142,y:870,t:1527620991040};\\\", \\\"{x:1139,y:867,t:1527620991057};\\\", \\\"{x:1137,y:865,t:1527620991074};\\\", \\\"{x:1134,y:863,t:1527620991090};\\\", \\\"{x:1132,y:862,t:1527620991107};\\\", \\\"{x:1131,y:861,t:1527620991124};\\\", \\\"{x:1130,y:860,t:1527620991140};\\\", \\\"{x:1130,y:858,t:1527620991157};\\\", \\\"{x:1130,y:856,t:1527620991175};\\\", \\\"{x:1128,y:855,t:1527620991190};\\\", \\\"{x:1128,y:854,t:1527620991210};\\\", \\\"{x:1128,y:853,t:1527620991226};\\\", \\\"{x:1128,y:852,t:1527620991258};\\\", \\\"{x:1128,y:851,t:1527620991818};\\\", \\\"{x:1124,y:846,t:1527621014098};\\\", \\\"{x:1107,y:811,t:1527621014109};\\\", \\\"{x:1085,y:774,t:1527621014125};\\\", \\\"{x:1054,y:752,t:1527621014142};\\\", \\\"{x:1014,y:733,t:1527621014159};\\\", \\\"{x:961,y:720,t:1527621014176};\\\", \\\"{x:889,y:702,t:1527621014192};\\\", \\\"{x:834,y:686,t:1527621014209};\\\", \\\"{x:800,y:673,t:1527621014226};\\\", \\\"{x:796,y:673,t:1527621014242};\\\", \\\"{x:796,y:669,t:1527621014714};\\\", \\\"{x:796,y:667,t:1527621014726};\\\", \\\"{x:796,y:663,t:1527621014744};\\\", \\\"{x:797,y:658,t:1527621014759};\\\", \\\"{x:807,y:646,t:1527621014776};\\\", \\\"{x:810,y:631,t:1527621014794};\\\", \\\"{x:813,y:618,t:1527621014809};\\\", \\\"{x:815,y:604,t:1527621014826};\\\", \\\"{x:818,y:589,t:1527621014845};\\\", \\\"{x:820,y:574,t:1527621014861};\\\", \\\"{x:824,y:560,t:1527621014878};\\\", \\\"{x:825,y:547,t:1527621014895};\\\", \\\"{x:826,y:536,t:1527621014911};\\\", \\\"{x:828,y:531,t:1527621014928};\\\", \\\"{x:829,y:526,t:1527621014945};\\\", \\\"{x:831,y:519,t:1527621014962};\\\", \\\"{x:834,y:507,t:1527621014978};\\\", \\\"{x:835,y:505,t:1527621014994};\\\", \\\"{x:835,y:503,t:1527621015011};\\\", \\\"{x:835,y:499,t:1527621015028};\\\", \\\"{x:837,y:497,t:1527621015045};\\\", \\\"{x:837,y:493,t:1527621015061};\\\", \\\"{x:838,y:492,t:1527621015082};\\\", \\\"{x:834,y:492,t:1527621016394};\\\", \\\"{x:825,y:492,t:1527621016403};\\\", \\\"{x:818,y:496,t:1527621016413};\\\", \\\"{x:805,y:498,t:1527621016429};\\\", \\\"{x:786,y:498,t:1527621016446};\\\", \\\"{x:772,y:498,t:1527621016462};\\\", \\\"{x:752,y:498,t:1527621016479};\\\", \\\"{x:723,y:498,t:1527621016496};\\\", \\\"{x:682,y:498,t:1527621016512};\\\", \\\"{x:651,y:500,t:1527621016530};\\\", \\\"{x:613,y:513,t:1527621016545};\\\", \\\"{x:546,y:526,t:1527621016563};\\\", \\\"{x:514,y:534,t:1527621016579};\\\", \\\"{x:495,y:536,t:1527621016596};\\\", \\\"{x:489,y:537,t:1527621016613};\\\", \\\"{x:474,y:544,t:1527621016629};\\\", \\\"{x:449,y:551,t:1527621016645};\\\", \\\"{x:428,y:555,t:1527621016662};\\\", \\\"{x:416,y:556,t:1527621016680};\\\", \\\"{x:400,y:556,t:1527621016696};\\\", \\\"{x:380,y:558,t:1527621016712};\\\", \\\"{x:378,y:558,t:1527621016729};\\\", \\\"{x:369,y:559,t:1527621016746};\\\", \\\"{x:359,y:560,t:1527621016762};\\\", \\\"{x:354,y:560,t:1527621016779};\\\", \\\"{x:353,y:560,t:1527621016796};\\\", \\\"{x:346,y:558,t:1527621016812};\\\", \\\"{x:335,y:552,t:1527621016830};\\\", \\\"{x:328,y:552,t:1527621016850};\\\", \\\"{x:322,y:549,t:1527621016862};\\\", \\\"{x:314,y:548,t:1527621016879};\\\", \\\"{x:312,y:548,t:1527621016896};\\\", \\\"{x:310,y:548,t:1527621016912};\\\", \\\"{x:310,y:547,t:1527621016929};\\\", \\\"{x:302,y:541,t:1527621016946};\\\", \\\"{x:294,y:538,t:1527621016963};\\\", \\\"{x:282,y:535,t:1527621016979};\\\", \\\"{x:274,y:534,t:1527621016996};\\\", \\\"{x:270,y:531,t:1527621017014};\\\", \\\"{x:267,y:531,t:1527621017029};\\\", \\\"{x:266,y:531,t:1527621017046};\\\", \\\"{x:259,y:531,t:1527621017064};\\\", \\\"{x:243,y:531,t:1527621017079};\\\", \\\"{x:233,y:531,t:1527621017096};\\\", \\\"{x:215,y:531,t:1527621017113};\\\", \\\"{x:205,y:531,t:1527621017129};\\\", \\\"{x:185,y:531,t:1527621017146};\\\", \\\"{x:175,y:531,t:1527621017163};\\\", \\\"{x:165,y:532,t:1527621017179};\\\", \\\"{x:152,y:534,t:1527621017197};\\\", \\\"{x:144,y:542,t:1527621017213};\\\", \\\"{x:137,y:542,t:1527621017229};\\\", \\\"{x:131,y:542,t:1527621017246};\\\", \\\"{x:127,y:542,t:1527621017263};\\\", \\\"{x:130,y:542,t:1527621017467};\\\", \\\"{x:131,y:542,t:1527621017482};\\\", \\\"{x:133,y:542,t:1527621017496};\\\", \\\"{x:135,y:542,t:1527621017514};\\\", \\\"{x:136,y:542,t:1527621017530};\\\", \\\"{x:138,y:542,t:1527621017546};\\\", \\\"{x:140,y:541,t:1527621017563};\\\", \\\"{x:141,y:541,t:1527621017594};\\\", \\\"{x:142,y:541,t:1527621017602};\\\", \\\"{x:143,y:541,t:1527621017614};\\\", \\\"{x:145,y:541,t:1527621017634};\\\", \\\"{x:146,y:540,t:1527621017646};\\\", \\\"{x:148,y:539,t:1527621017666};\\\", \\\"{x:149,y:538,t:1527621017682};\\\", \\\"{x:151,y:538,t:1527621017706};\\\", \\\"{x:152,y:538,t:1527621017730};\\\", \\\"{x:155,y:538,t:1527621017971};\\\", \\\"{x:163,y:546,t:1527621017980};\\\", \\\"{x:187,y:559,t:1527621017998};\\\", \\\"{x:239,y:584,t:1527621018014};\\\", \\\"{x:317,y:620,t:1527621018031};\\\", \\\"{x:391,y:649,t:1527621018048};\\\", \\\"{x:428,y:676,t:1527621018063};\\\", \\\"{x:458,y:689,t:1527621018080};\\\", \\\"{x:484,y:700,t:1527621018098};\\\", \\\"{x:496,y:708,t:1527621018113};\\\", \\\"{x:513,y:721,t:1527621018130};\\\", \\\"{x:522,y:732,t:1527621018148};\\\", \\\"{x:534,y:744,t:1527621018163};\\\", \\\"{x:547,y:753,t:1527621018180};\\\", \\\"{x:550,y:756,t:1527621018198};\\\", \\\"{x:552,y:757,t:1527621018213};\\\", \\\"{x:553,y:757,t:1527621018231};\\\", \\\"{x:554,y:758,t:1527621018371};\\\", \\\"{x:553,y:758,t:1527621018434};\\\", \\\"{x:550,y:755,t:1527621018448};\\\", \\\"{x:545,y:743,t:1527621018464};\\\", \\\"{x:541,y:738,t:1527621018481};\\\", \\\"{x:540,y:737,t:1527621018497};\\\", \\\"{x:539,y:736,t:1527621018514};\\\", \\\"{x:540,y:736,t:1527621019026};\\\", \\\"{x:545,y:736,t:1527621019034};\\\", \\\"{x:551,y:736,t:1527621019047};\\\", \\\"{x:571,y:736,t:1527621019065};\\\", \\\"{x:601,y:739,t:1527621019081};\\\", \\\"{x:644,y:741,t:1527621019098};\\\", \\\"{x:737,y:750,t:1527621019114};\\\", \\\"{x:789,y:755,t:1527621019131};\\\", \\\"{x:830,y:758,t:1527621019147};\\\", \\\"{x:860,y:759,t:1527621019164};\\\", \\\"{x:898,y:759,t:1527621019181};\\\", \\\"{x:922,y:759,t:1527621019199};\\\", \\\"{x:948,y:759,t:1527621019214};\\\", \\\"{x:971,y:762,t:1527621019231};\\\", \\\"{x:988,y:764,t:1527621019249};\\\", \\\"{x:1007,y:764,t:1527621019264};\\\", \\\"{x:1020,y:767,t:1527621019281};\\\", \\\"{x:1029,y:768,t:1527621019298};\\\", \\\"{x:1030,y:768,t:1527621019314};\\\" ] }, { \\\"rt\\\": 42641, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 461913, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"G\\\", \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -J -X -F -F -C -C -C -M -M -M -N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1029,y:768,t:1527621021443};\\\", \\\"{x:1028,y:768,t:1527621021450};\\\", \\\"{x:1020,y:770,t:1527621021467};\\\", \\\"{x:1015,y:771,t:1527621021484};\\\", \\\"{x:1010,y:772,t:1527621021500};\\\", \\\"{x:1007,y:774,t:1527621021517};\\\", \\\"{x:1005,y:774,t:1527621021534};\\\", \\\"{x:1004,y:774,t:1527621021550};\\\", \\\"{x:1004,y:775,t:1527621021567};\\\", \\\"{x:1002,y:775,t:1527621021584};\\\", \\\"{x:997,y:778,t:1527621021600};\\\", \\\"{x:996,y:779,t:1527621021617};\\\", \\\"{x:992,y:782,t:1527621021634};\\\", \\\"{x:991,y:782,t:1527621021650};\\\", \\\"{x:986,y:785,t:1527621021667};\\\", \\\"{x:978,y:785,t:1527621021684};\\\", \\\"{x:973,y:786,t:1527621021700};\\\", \\\"{x:968,y:787,t:1527621021717};\\\", \\\"{x:961,y:789,t:1527621021734};\\\", \\\"{x:953,y:790,t:1527621021750};\\\", \\\"{x:947,y:790,t:1527621021767};\\\", \\\"{x:945,y:791,t:1527621021784};\\\", \\\"{x:941,y:793,t:1527621021801};\\\", \\\"{x:936,y:795,t:1527621021817};\\\", \\\"{x:933,y:795,t:1527621021834};\\\", \\\"{x:928,y:796,t:1527621021851};\\\", \\\"{x:921,y:796,t:1527621021867};\\\", \\\"{x:910,y:797,t:1527621021884};\\\", \\\"{x:892,y:797,t:1527621021901};\\\", \\\"{x:875,y:797,t:1527621021917};\\\", \\\"{x:859,y:797,t:1527621021934};\\\", \\\"{x:843,y:797,t:1527621021951};\\\", \\\"{x:830,y:797,t:1527621021967};\\\", \\\"{x:821,y:796,t:1527621021984};\\\", \\\"{x:806,y:794,t:1527621022001};\\\", \\\"{x:789,y:790,t:1527621022017};\\\", \\\"{x:770,y:786,t:1527621022034};\\\", \\\"{x:748,y:784,t:1527621022050};\\\", \\\"{x:735,y:780,t:1527621022067};\\\", \\\"{x:724,y:775,t:1527621022084};\\\", \\\"{x:722,y:774,t:1527621022101};\\\", \\\"{x:719,y:771,t:1527621022117};\\\", \\\"{x:718,y:771,t:1527621022134};\\\", \\\"{x:718,y:768,t:1527621023091};\\\", \\\"{x:720,y:768,t:1527621023102};\\\", \\\"{x:723,y:768,t:1527621023118};\\\", \\\"{x:724,y:767,t:1527621023135};\\\", \\\"{x:728,y:765,t:1527621023152};\\\", \\\"{x:729,y:765,t:1527621023168};\\\", \\\"{x:730,y:765,t:1527621023185};\\\", \\\"{x:731,y:764,t:1527621023219};\\\", \\\"{x:732,y:764,t:1527621023250};\\\", \\\"{x:733,y:764,t:1527621023274};\\\", \\\"{x:736,y:764,t:1527621023285};\\\", \\\"{x:741,y:761,t:1527621023302};\\\", \\\"{x:745,y:761,t:1527621023318};\\\", \\\"{x:752,y:761,t:1527621023335};\\\", \\\"{x:758,y:761,t:1527621023352};\\\", \\\"{x:763,y:760,t:1527621023368};\\\", \\\"{x:766,y:760,t:1527621023386};\\\", \\\"{x:767,y:760,t:1527621023419};\\\", \\\"{x:774,y:758,t:1527621023435};\\\", \\\"{x:784,y:758,t:1527621023452};\\\", \\\"{x:799,y:759,t:1527621023468};\\\", \\\"{x:813,y:759,t:1527621023485};\\\", \\\"{x:838,y:759,t:1527621023502};\\\", \\\"{x:853,y:759,t:1527621023518};\\\", \\\"{x:877,y:759,t:1527621023535};\\\", \\\"{x:915,y:759,t:1527621023552};\\\", \\\"{x:954,y:759,t:1527621023569};\\\", \\\"{x:986,y:759,t:1527621023585};\\\", \\\"{x:1047,y:765,t:1527621023602};\\\", \\\"{x:1153,y:775,t:1527621023618};\\\", \\\"{x:1224,y:779,t:1527621023635};\\\", \\\"{x:1294,y:779,t:1527621023652};\\\", \\\"{x:1363,y:785,t:1527621023669};\\\", \\\"{x:1457,y:785,t:1527621023685};\\\", \\\"{x:1493,y:785,t:1527621023703};\\\", \\\"{x:1546,y:785,t:1527621023719};\\\", \\\"{x:1599,y:785,t:1527621023735};\\\", \\\"{x:1621,y:785,t:1527621023752};\\\", \\\"{x:1655,y:785,t:1527621023769};\\\", \\\"{x:1665,y:785,t:1527621023785};\\\", \\\"{x:1674,y:785,t:1527621023802};\\\", \\\"{x:1677,y:785,t:1527621023819};\\\", \\\"{x:1678,y:785,t:1527621023995};\\\", \\\"{x:1678,y:783,t:1527621024027};\\\", \\\"{x:1678,y:778,t:1527621024036};\\\", \\\"{x:1672,y:770,t:1527621024052};\\\", \\\"{x:1655,y:758,t:1527621024070};\\\", \\\"{x:1642,y:749,t:1527621024086};\\\", \\\"{x:1617,y:738,t:1527621024102};\\\", \\\"{x:1574,y:721,t:1527621024119};\\\", \\\"{x:1543,y:710,t:1527621024136};\\\", \\\"{x:1492,y:702,t:1527621024152};\\\", \\\"{x:1421,y:686,t:1527621024169};\\\", \\\"{x:1369,y:667,t:1527621024186};\\\", \\\"{x:1313,y:651,t:1527621024203};\\\", \\\"{x:1286,y:641,t:1527621024219};\\\", \\\"{x:1277,y:638,t:1527621024236};\\\", \\\"{x:1273,y:635,t:1527621024252};\\\", \\\"{x:1273,y:634,t:1527621024269};\\\", \\\"{x:1273,y:630,t:1527621024286};\\\", \\\"{x:1275,y:626,t:1527621024303};\\\", \\\"{x:1280,y:623,t:1527621024319};\\\", \\\"{x:1282,y:621,t:1527621024336};\\\", \\\"{x:1285,y:619,t:1527621024353};\\\", \\\"{x:1286,y:619,t:1527621024369};\\\", \\\"{x:1288,y:619,t:1527621024386};\\\", \\\"{x:1300,y:619,t:1527621024402};\\\", \\\"{x:1317,y:626,t:1527621024419};\\\", \\\"{x:1331,y:634,t:1527621024436};\\\", \\\"{x:1348,y:646,t:1527621024453};\\\", \\\"{x:1349,y:646,t:1527621024470};\\\", \\\"{x:1349,y:647,t:1527621024514};\\\", \\\"{x:1349,y:649,t:1527621024555};\\\", \\\"{x:1349,y:650,t:1527621024579};\\\", \\\"{x:1349,y:653,t:1527621024587};\\\", \\\"{x:1345,y:655,t:1527621024602};\\\", \\\"{x:1343,y:656,t:1527621024619};\\\", \\\"{x:1343,y:657,t:1527621024636};\\\", \\\"{x:1342,y:660,t:1527621024653};\\\", \\\"{x:1341,y:662,t:1527621024669};\\\", \\\"{x:1338,y:666,t:1527621024686};\\\", \\\"{x:1337,y:667,t:1527621024703};\\\", \\\"{x:1336,y:670,t:1527621024719};\\\", \\\"{x:1336,y:673,t:1527621024736};\\\", \\\"{x:1336,y:674,t:1527621024754};\\\", \\\"{x:1336,y:677,t:1527621024769};\\\", \\\"{x:1338,y:681,t:1527621024786};\\\", \\\"{x:1339,y:686,t:1527621024803};\\\", \\\"{x:1340,y:691,t:1527621024819};\\\", \\\"{x:1340,y:695,t:1527621024836};\\\", \\\"{x:1340,y:702,t:1527621024854};\\\", \\\"{x:1340,y:706,t:1527621024870};\\\", \\\"{x:1341,y:710,t:1527621024886};\\\", \\\"{x:1342,y:716,t:1527621024903};\\\", \\\"{x:1343,y:722,t:1527621024920};\\\", \\\"{x:1343,y:727,t:1527621024936};\\\", \\\"{x:1344,y:732,t:1527621024953};\\\", \\\"{x:1345,y:736,t:1527621024970};\\\", \\\"{x:1346,y:739,t:1527621024986};\\\", \\\"{x:1348,y:741,t:1527621025004};\\\", \\\"{x:1349,y:743,t:1527621025020};\\\", \\\"{x:1349,y:744,t:1527621025037};\\\", \\\"{x:1350,y:746,t:1527621025053};\\\", \\\"{x:1350,y:749,t:1527621025070};\\\", \\\"{x:1351,y:750,t:1527621025087};\\\", \\\"{x:1351,y:753,t:1527621025103};\\\", \\\"{x:1351,y:755,t:1527621025120};\\\", \\\"{x:1352,y:756,t:1527621025137};\\\", \\\"{x:1352,y:758,t:1527621025153};\\\", \\\"{x:1352,y:759,t:1527621025211};\\\", \\\"{x:1352,y:761,t:1527621025267};\\\", \\\"{x:1352,y:762,t:1527621025307};\\\", \\\"{x:1353,y:762,t:1527621025323};\\\", \\\"{x:1353,y:764,t:1527621025355};\\\", \\\"{x:1353,y:765,t:1527621025370};\\\", \\\"{x:1354,y:768,t:1527621025387};\\\", \\\"{x:1354,y:769,t:1527621025706};\\\", \\\"{x:1355,y:769,t:1527621025811};\\\", \\\"{x:1356,y:769,t:1527621025931};\\\", \\\"{x:1355,y:769,t:1527621026523};\\\", \\\"{x:1353,y:769,t:1527621028115};\\\", \\\"{x:1353,y:771,t:1527621029747};\\\", \\\"{x:1355,y:776,t:1527621029758};\\\", \\\"{x:1368,y:782,t:1527621029773};\\\", \\\"{x:1380,y:788,t:1527621029791};\\\", \\\"{x:1388,y:796,t:1527621029808};\\\", \\\"{x:1395,y:800,t:1527621029824};\\\", \\\"{x:1399,y:802,t:1527621029841};\\\", \\\"{x:1403,y:804,t:1527621029858};\\\", \\\"{x:1406,y:805,t:1527621029873};\\\", \\\"{x:1410,y:807,t:1527621029891};\\\", \\\"{x:1412,y:807,t:1527621029908};\\\", \\\"{x:1414,y:809,t:1527621029923};\\\", \\\"{x:1418,y:810,t:1527621029941};\\\", \\\"{x:1420,y:812,t:1527621029958};\\\", \\\"{x:1424,y:814,t:1527621029973};\\\", \\\"{x:1427,y:816,t:1527621029991};\\\", \\\"{x:1429,y:817,t:1527621030008};\\\", \\\"{x:1431,y:818,t:1527621030024};\\\", \\\"{x:1433,y:819,t:1527621030040};\\\", \\\"{x:1435,y:820,t:1527621030058};\\\", \\\"{x:1439,y:823,t:1527621030073};\\\", \\\"{x:1445,y:827,t:1527621030091};\\\", \\\"{x:1451,y:829,t:1527621030108};\\\", \\\"{x:1454,y:830,t:1527621030124};\\\", \\\"{x:1457,y:833,t:1527621030140};\\\", \\\"{x:1463,y:835,t:1527621030158};\\\", \\\"{x:1467,y:835,t:1527621030175};\\\", \\\"{x:1471,y:837,t:1527621030191};\\\", \\\"{x:1473,y:837,t:1527621030207};\\\", \\\"{x:1474,y:837,t:1527621030224};\\\", \\\"{x:1475,y:837,t:1527621030240};\\\", \\\"{x:1473,y:837,t:1527621030762};\\\", \\\"{x:1471,y:837,t:1527621030774};\\\", \\\"{x:1465,y:834,t:1527621030791};\\\", \\\"{x:1456,y:831,t:1527621030807};\\\", \\\"{x:1443,y:827,t:1527621030825};\\\", \\\"{x:1429,y:824,t:1527621030842};\\\", \\\"{x:1409,y:824,t:1527621030858};\\\", \\\"{x:1365,y:824,t:1527621030874};\\\", \\\"{x:1237,y:825,t:1527621030892};\\\", \\\"{x:1224,y:828,t:1527621030907};\\\", \\\"{x:1220,y:828,t:1527621030924};\\\", \\\"{x:1219,y:828,t:1527621030942};\\\", \\\"{x:1217,y:828,t:1527621030958};\\\", \\\"{x:1220,y:828,t:1527621031059};\\\", \\\"{x:1222,y:827,t:1527621031075};\\\", \\\"{x:1227,y:826,t:1527621031092};\\\", \\\"{x:1228,y:824,t:1527621031109};\\\", \\\"{x:1231,y:822,t:1527621031124};\\\", \\\"{x:1236,y:818,t:1527621031142};\\\", \\\"{x:1239,y:816,t:1527621031159};\\\", \\\"{x:1243,y:815,t:1527621031175};\\\", \\\"{x:1251,y:811,t:1527621031191};\\\", \\\"{x:1272,y:809,t:1527621031209};\\\", \\\"{x:1280,y:809,t:1527621031225};\\\", \\\"{x:1300,y:809,t:1527621031241};\\\", \\\"{x:1319,y:809,t:1527621031259};\\\", \\\"{x:1322,y:809,t:1527621031275};\\\", \\\"{x:1326,y:809,t:1527621031291};\\\", \\\"{x:1329,y:809,t:1527621031309};\\\", \\\"{x:1331,y:809,t:1527621031324};\\\", \\\"{x:1333,y:809,t:1527621031347};\\\", \\\"{x:1336,y:809,t:1527621031358};\\\", \\\"{x:1341,y:813,t:1527621031374};\\\", \\\"{x:1343,y:817,t:1527621031391};\\\", \\\"{x:1343,y:820,t:1527621031409};\\\", \\\"{x:1343,y:824,t:1527621031425};\\\", \\\"{x:1343,y:831,t:1527621031442};\\\", \\\"{x:1343,y:841,t:1527621031459};\\\", \\\"{x:1341,y:850,t:1527621031475};\\\", \\\"{x:1339,y:860,t:1527621031492};\\\", \\\"{x:1337,y:865,t:1527621031509};\\\", \\\"{x:1335,y:870,t:1527621031531};\\\", \\\"{x:1332,y:871,t:1527621031542};\\\", \\\"{x:1329,y:877,t:1527621031558};\\\", \\\"{x:1329,y:880,t:1527621031576};\\\", \\\"{x:1326,y:887,t:1527621031591};\\\", \\\"{x:1324,y:890,t:1527621031608};\\\", \\\"{x:1324,y:892,t:1527621031625};\\\", \\\"{x:1323,y:894,t:1527621031642};\\\", \\\"{x:1322,y:895,t:1527621031658};\\\", \\\"{x:1322,y:896,t:1527621031683};\\\", \\\"{x:1322,y:897,t:1527621031723};\\\", \\\"{x:1322,y:896,t:1527621031834};\\\", \\\"{x:1322,y:895,t:1527621031842};\\\", \\\"{x:1325,y:888,t:1527621031858};\\\", \\\"{x:1329,y:882,t:1527621031875};\\\", \\\"{x:1336,y:875,t:1527621031893};\\\", \\\"{x:1341,y:865,t:1527621031909};\\\", \\\"{x:1342,y:864,t:1527621031926};\\\", \\\"{x:1348,y:855,t:1527621031942};\\\", \\\"{x:1352,y:846,t:1527621031959};\\\", \\\"{x:1359,y:831,t:1527621031976};\\\", \\\"{x:1363,y:825,t:1527621031992};\\\", \\\"{x:1369,y:816,t:1527621032008};\\\", \\\"{x:1372,y:811,t:1527621032025};\\\", \\\"{x:1377,y:804,t:1527621032043};\\\", \\\"{x:1379,y:801,t:1527621032059};\\\", \\\"{x:1382,y:801,t:1527621032075};\\\", \\\"{x:1383,y:800,t:1527621032093};\\\", \\\"{x:1384,y:799,t:1527621032109};\\\", \\\"{x:1386,y:798,t:1527621032126};\\\", \\\"{x:1390,y:795,t:1527621032142};\\\", \\\"{x:1397,y:793,t:1527621032159};\\\", \\\"{x:1400,y:793,t:1527621032175};\\\", \\\"{x:1407,y:793,t:1527621032193};\\\", \\\"{x:1421,y:791,t:1527621032208};\\\", \\\"{x:1435,y:792,t:1527621032226};\\\", \\\"{x:1455,y:796,t:1527621032243};\\\", \\\"{x:1465,y:800,t:1527621032258};\\\", \\\"{x:1473,y:805,t:1527621032276};\\\", \\\"{x:1476,y:805,t:1527621032293};\\\", \\\"{x:1480,y:806,t:1527621032310};\\\", \\\"{x:1486,y:810,t:1527621032326};\\\", \\\"{x:1486,y:812,t:1527621032371};\\\", \\\"{x:1489,y:813,t:1527621032378};\\\", \\\"{x:1491,y:814,t:1527621032393};\\\", \\\"{x:1492,y:815,t:1527621032410};\\\", \\\"{x:1493,y:816,t:1527621032443};\\\", \\\"{x:1493,y:817,t:1527621032843};\\\", \\\"{x:1492,y:817,t:1527621033451};\\\", \\\"{x:1491,y:817,t:1527621033707};\\\", \\\"{x:1491,y:818,t:1527621040907};\\\", \\\"{x:1488,y:819,t:1527621041363};\\\", \\\"{x:1477,y:819,t:1527621041372};\\\", \\\"{x:1469,y:817,t:1527621041383};\\\", \\\"{x:1445,y:812,t:1527621041399};\\\", \\\"{x:1420,y:808,t:1527621041416};\\\", \\\"{x:1393,y:805,t:1527621041433};\\\", \\\"{x:1367,y:797,t:1527621041450};\\\", \\\"{x:1352,y:794,t:1527621041466};\\\", \\\"{x:1346,y:791,t:1527621041483};\\\", \\\"{x:1343,y:790,t:1527621041500};\\\", \\\"{x:1343,y:785,t:1527621041517};\\\", \\\"{x:1342,y:780,t:1527621041533};\\\", \\\"{x:1341,y:765,t:1527621041550};\\\", \\\"{x:1341,y:748,t:1527621041567};\\\", \\\"{x:1341,y:738,t:1527621041583};\\\", \\\"{x:1341,y:736,t:1527621041600};\\\", \\\"{x:1341,y:735,t:1527621041617};\\\", \\\"{x:1342,y:733,t:1527621041633};\\\", \\\"{x:1343,y:731,t:1527621041650};\\\", \\\"{x:1344,y:730,t:1527621041666};\\\", \\\"{x:1344,y:727,t:1527621041683};\\\", \\\"{x:1345,y:726,t:1527621041700};\\\", \\\"{x:1346,y:725,t:1527621041717};\\\", \\\"{x:1346,y:724,t:1527621041819};\\\", \\\"{x:1349,y:721,t:1527621041842};\\\", \\\"{x:1350,y:719,t:1527621041858};\\\", \\\"{x:1351,y:718,t:1527621041867};\\\", \\\"{x:1351,y:717,t:1527621041883};\\\", \\\"{x:1352,y:715,t:1527621041900};\\\", \\\"{x:1353,y:714,t:1527621041923};\\\", \\\"{x:1353,y:712,t:1527621041954};\\\", \\\"{x:1354,y:708,t:1527621041970};\\\", \\\"{x:1356,y:703,t:1527621041984};\\\", \\\"{x:1357,y:699,t:1527621042000};\\\", \\\"{x:1358,y:696,t:1527621042017};\\\", \\\"{x:1359,y:693,t:1527621042034};\\\", \\\"{x:1359,y:692,t:1527621042050};\\\", \\\"{x:1360,y:690,t:1527621042066};\\\", \\\"{x:1361,y:689,t:1527621042731};\\\", \\\"{x:1363,y:689,t:1527621042746};\\\", \\\"{x:1363,y:688,t:1527621042762};\\\", \\\"{x:1364,y:688,t:1527621042770};\\\", \\\"{x:1365,y:687,t:1527621042786};\\\", \\\"{x:1366,y:687,t:1527621042801};\\\", \\\"{x:1366,y:686,t:1527621042818};\\\", \\\"{x:1364,y:686,t:1527621043074};\\\", \\\"{x:1363,y:686,t:1527621043084};\\\", \\\"{x:1360,y:686,t:1527621043101};\\\", \\\"{x:1359,y:686,t:1527621043117};\\\", \\\"{x:1357,y:686,t:1527621043134};\\\", \\\"{x:1356,y:686,t:1527621043151};\\\", \\\"{x:1355,y:686,t:1527621043167};\\\", \\\"{x:1354,y:686,t:1527621043184};\\\", \\\"{x:1353,y:686,t:1527621043242};\\\", \\\"{x:1352,y:686,t:1527621043307};\\\", \\\"{x:1351,y:686,t:1527621043338};\\\", \\\"{x:1350,y:686,t:1527621043395};\\\", \\\"{x:1349,y:686,t:1527621043490};\\\", \\\"{x:1347,y:686,t:1527621043501};\\\", \\\"{x:1347,y:688,t:1527621043517};\\\", \\\"{x:1347,y:689,t:1527621043538};\\\", \\\"{x:1347,y:690,t:1527621043554};\\\", \\\"{x:1347,y:691,t:1527621043594};\\\", \\\"{x:1347,y:692,t:1527621043651};\\\", \\\"{x:1348,y:693,t:1527621043730};\\\", \\\"{x:1349,y:694,t:1527621043794};\\\", \\\"{x:1350,y:695,t:1527621043923};\\\", \\\"{x:1350,y:696,t:1527621044018};\\\", \\\"{x:1350,y:697,t:1527621044090};\\\", \\\"{x:1350,y:699,t:1527621044131};\\\", \\\"{x:1350,y:701,t:1527621044194};\\\", \\\"{x:1350,y:702,t:1527621044219};\\\", \\\"{x:1349,y:703,t:1527621044267};\\\", \\\"{x:1349,y:704,t:1527621044443};\\\", \\\"{x:1350,y:704,t:1527621045243};\\\", \\\"{x:1351,y:704,t:1527621045267};\\\", \\\"{x:1352,y:704,t:1527621045274};\\\", \\\"{x:1353,y:703,t:1527621045298};\\\", \\\"{x:1354,y:703,t:1527621045338};\\\", \\\"{x:1356,y:702,t:1527621045371};\\\", \\\"{x:1357,y:702,t:1527621045411};\\\", \\\"{x:1357,y:701,t:1527621045659};\\\", \\\"{x:1360,y:700,t:1527621045670};\\\", \\\"{x:1372,y:695,t:1527621045686};\\\", \\\"{x:1381,y:674,t:1527621045703};\\\", \\\"{x:1396,y:656,t:1527621045720};\\\", \\\"{x:1402,y:647,t:1527621045736};\\\", \\\"{x:1408,y:637,t:1527621045753};\\\", \\\"{x:1417,y:620,t:1527621045770};\\\", \\\"{x:1423,y:613,t:1527621045786};\\\", \\\"{x:1427,y:604,t:1527621045803};\\\", \\\"{x:1431,y:599,t:1527621045820};\\\", \\\"{x:1433,y:596,t:1527621045836};\\\", \\\"{x:1434,y:594,t:1527621045852};\\\", \\\"{x:1434,y:593,t:1527621045870};\\\", \\\"{x:1434,y:592,t:1527621045886};\\\", \\\"{x:1434,y:591,t:1527621045903};\\\", \\\"{x:1434,y:590,t:1527621045921};\\\", \\\"{x:1434,y:588,t:1527621045937};\\\", \\\"{x:1434,y:587,t:1527621045962};\\\", \\\"{x:1434,y:585,t:1527621045970};\\\", \\\"{x:1434,y:583,t:1527621045986};\\\", \\\"{x:1433,y:582,t:1527621046026};\\\", \\\"{x:1432,y:581,t:1527621046051};\\\", \\\"{x:1431,y:581,t:1527621046066};\\\", \\\"{x:1428,y:579,t:1527621046074};\\\", \\\"{x:1425,y:578,t:1527621046087};\\\", \\\"{x:1421,y:577,t:1527621046103};\\\", \\\"{x:1415,y:575,t:1527621046120};\\\", \\\"{x:1411,y:573,t:1527621046137};\\\", \\\"{x:1408,y:572,t:1527621046154};\\\", \\\"{x:1407,y:572,t:1527621046170};\\\", \\\"{x:1407,y:571,t:1527621046450};\\\", \\\"{x:1407,y:570,t:1527621046491};\\\", \\\"{x:1407,y:569,t:1527621046507};\\\", \\\"{x:1408,y:569,t:1527621046530};\\\", \\\"{x:1408,y:568,t:1527621046554};\\\", \\\"{x:1409,y:567,t:1527621046723};\\\", \\\"{x:1405,y:569,t:1527621047330};\\\", \\\"{x:1368,y:573,t:1527621047339};\\\", \\\"{x:1257,y:573,t:1527621047354};\\\", \\\"{x:1132,y:572,t:1527621047372};\\\", \\\"{x:1017,y:564,t:1527621047388};\\\", \\\"{x:912,y:555,t:1527621047405};\\\", \\\"{x:884,y:552,t:1527621047421};\\\", \\\"{x:852,y:542,t:1527621047437};\\\", \\\"{x:845,y:541,t:1527621047453};\\\", \\\"{x:845,y:540,t:1527621047554};\\\", \\\"{x:847,y:540,t:1527621047570};\\\", \\\"{x:850,y:540,t:1527621047587};\\\", \\\"{x:853,y:540,t:1527621047604};\\\", \\\"{x:855,y:540,t:1527621047620};\\\", \\\"{x:854,y:540,t:1527621047818};\\\", \\\"{x:850,y:539,t:1527621047826};\\\", \\\"{x:849,y:538,t:1527621047842};\\\", \\\"{x:847,y:537,t:1527621047858};\\\", \\\"{x:845,y:537,t:1527621047907};\\\", \\\"{x:844,y:537,t:1527621047922};\\\", \\\"{x:842,y:537,t:1527621047946};\\\", \\\"{x:841,y:537,t:1527621047962};\\\", \\\"{x:840,y:536,t:1527621049067};\\\", \\\"{x:843,y:535,t:1527621049083};\\\", \\\"{x:851,y:534,t:1527621049091};\\\", \\\"{x:879,y:538,t:1527621049107};\\\", \\\"{x:920,y:548,t:1527621049124};\\\", \\\"{x:970,y:560,t:1527621049141};\\\", \\\"{x:1026,y:568,t:1527621049157};\\\", \\\"{x:1085,y:578,t:1527621049173};\\\", \\\"{x:1129,y:590,t:1527621049190};\\\", \\\"{x:1192,y:603,t:1527621049206};\\\", \\\"{x:1262,y:612,t:1527621049224};\\\", \\\"{x:1321,y:621,t:1527621049240};\\\", \\\"{x:1381,y:624,t:1527621049256};\\\", \\\"{x:1423,y:631,t:1527621049273};\\\", \\\"{x:1465,y:635,t:1527621049290};\\\", \\\"{x:1491,y:636,t:1527621049306};\\\", \\\"{x:1500,y:639,t:1527621049323};\\\", \\\"{x:1501,y:639,t:1527621049341};\\\", \\\"{x:1501,y:636,t:1527621049483};\\\", \\\"{x:1501,y:633,t:1527621049490};\\\", \\\"{x:1500,y:626,t:1527621049506};\\\", \\\"{x:1491,y:617,t:1527621049523};\\\", \\\"{x:1477,y:607,t:1527621049541};\\\", \\\"{x:1461,y:601,t:1527621049556};\\\", \\\"{x:1444,y:595,t:1527621049573};\\\", \\\"{x:1427,y:590,t:1527621049590};\\\", \\\"{x:1415,y:590,t:1527621049606};\\\", \\\"{x:1403,y:589,t:1527621049623};\\\", \\\"{x:1393,y:589,t:1527621049641};\\\", \\\"{x:1390,y:589,t:1527621049656};\\\", \\\"{x:1389,y:589,t:1527621049674};\\\", \\\"{x:1389,y:588,t:1527621049827};\\\", \\\"{x:1389,y:587,t:1527621049841};\\\", \\\"{x:1390,y:585,t:1527621049857};\\\", \\\"{x:1391,y:584,t:1527621049873};\\\", \\\"{x:1393,y:583,t:1527621049890};\\\", \\\"{x:1396,y:581,t:1527621049907};\\\", \\\"{x:1397,y:580,t:1527621050051};\\\", \\\"{x:1398,y:580,t:1527621050123};\\\", \\\"{x:1400,y:580,t:1527621050178};\\\", \\\"{x:1402,y:581,t:1527621050191};\\\", \\\"{x:1403,y:591,t:1527621050207};\\\", \\\"{x:1408,y:604,t:1527621050224};\\\", \\\"{x:1411,y:609,t:1527621050240};\\\", \\\"{x:1411,y:611,t:1527621050257};\\\", \\\"{x:1412,y:612,t:1527621050273};\\\", \\\"{x:1413,y:612,t:1527621050307};\\\", \\\"{x:1413,y:613,t:1527621050363};\\\", \\\"{x:1414,y:613,t:1527621050379};\\\", \\\"{x:1415,y:615,t:1527621050402};\\\", \\\"{x:1416,y:616,t:1527621050411};\\\", \\\"{x:1416,y:617,t:1527621050424};\\\", \\\"{x:1417,y:618,t:1527621050440};\\\", \\\"{x:1419,y:622,t:1527621050457};\\\", \\\"{x:1420,y:623,t:1527621050473};\\\", \\\"{x:1423,y:627,t:1527621050490};\\\", \\\"{x:1424,y:627,t:1527621050507};\\\", \\\"{x:1424,y:628,t:1527621050523};\\\", \\\"{x:1425,y:629,t:1527621050540};\\\", \\\"{x:1426,y:629,t:1527621050557};\\\", \\\"{x:1427,y:629,t:1527621050573};\\\", \\\"{x:1429,y:630,t:1527621050602};\\\", \\\"{x:1430,y:631,t:1527621050666};\\\", \\\"{x:1430,y:632,t:1527621050811};\\\", \\\"{x:1431,y:632,t:1527621050826};\\\", \\\"{x:1432,y:632,t:1527621050841};\\\", \\\"{x:1433,y:632,t:1527621050883};\\\", \\\"{x:1434,y:632,t:1527621050890};\\\", \\\"{x:1435,y:632,t:1527621050907};\\\", \\\"{x:1438,y:632,t:1527621050924};\\\", \\\"{x:1441,y:632,t:1527621050941};\\\", \\\"{x:1442,y:632,t:1527621050995};\\\", \\\"{x:1444,y:632,t:1527621051651};\\\", \\\"{x:1442,y:632,t:1527621053395};\\\", \\\"{x:1433,y:632,t:1527621053409};\\\", \\\"{x:1400,y:632,t:1527621053424};\\\", \\\"{x:1358,y:632,t:1527621053442};\\\", \\\"{x:1314,y:632,t:1527621053458};\\\", \\\"{x:1283,y:630,t:1527621053474};\\\", \\\"{x:1249,y:628,t:1527621053492};\\\", \\\"{x:1206,y:624,t:1527621053508};\\\", \\\"{x:1157,y:622,t:1527621053524};\\\", \\\"{x:1099,y:620,t:1527621053541};\\\", \\\"{x:1071,y:620,t:1527621053558};\\\", \\\"{x:1046,y:620,t:1527621053575};\\\", \\\"{x:1027,y:620,t:1527621053591};\\\", \\\"{x:1008,y:620,t:1527621053609};\\\", \\\"{x:988,y:620,t:1527621053625};\\\", \\\"{x:963,y:620,t:1527621053641};\\\", \\\"{x:889,y:611,t:1527621053659};\\\", \\\"{x:836,y:604,t:1527621053675};\\\", \\\"{x:788,y:604,t:1527621053694};\\\", \\\"{x:735,y:598,t:1527621053711};\\\", \\\"{x:690,y:596,t:1527621053728};\\\", \\\"{x:664,y:588,t:1527621053743};\\\", \\\"{x:636,y:582,t:1527621053761};\\\", \\\"{x:612,y:575,t:1527621053777};\\\", \\\"{x:593,y:565,t:1527621053793};\\\", \\\"{x:572,y:561,t:1527621053811};\\\", \\\"{x:570,y:557,t:1527621053827};\\\", \\\"{x:567,y:555,t:1527621054074};\\\", \\\"{x:557,y:554,t:1527621054082};\\\", \\\"{x:547,y:550,t:1527621054094};\\\", \\\"{x:528,y:546,t:1527621054111};\\\", \\\"{x:511,y:545,t:1527621054127};\\\", \\\"{x:496,y:545,t:1527621054144};\\\", \\\"{x:484,y:546,t:1527621054162};\\\", \\\"{x:476,y:552,t:1527621054177};\\\", \\\"{x:460,y:567,t:1527621054195};\\\", \\\"{x:438,y:583,t:1527621054211};\\\", \\\"{x:414,y:597,t:1527621054228};\\\", \\\"{x:401,y:612,t:1527621054244};\\\", \\\"{x:370,y:613,t:1527621054261};\\\", \\\"{x:348,y:616,t:1527621054278};\\\", \\\"{x:323,y:622,t:1527621054295};\\\", \\\"{x:309,y:627,t:1527621054310};\\\", \\\"{x:298,y:630,t:1527621054327};\\\", \\\"{x:286,y:635,t:1527621054345};\\\", \\\"{x:266,y:637,t:1527621054361};\\\", \\\"{x:251,y:637,t:1527621054377};\\\", \\\"{x:233,y:635,t:1527621054394};\\\", \\\"{x:218,y:633,t:1527621054412};\\\", \\\"{x:200,y:631,t:1527621054428};\\\", \\\"{x:190,y:628,t:1527621054444};\\\", \\\"{x:177,y:627,t:1527621054462};\\\", \\\"{x:173,y:626,t:1527621054477};\\\", \\\"{x:171,y:626,t:1527621054494};\\\", \\\"{x:170,y:624,t:1527621054511};\\\", \\\"{x:168,y:621,t:1527621054528};\\\", \\\"{x:165,y:617,t:1527621054544};\\\", \\\"{x:161,y:612,t:1527621054561};\\\", \\\"{x:160,y:611,t:1527621054578};\\\", \\\"{x:158,y:606,t:1527621054595};\\\", \\\"{x:157,y:604,t:1527621054611};\\\", \\\"{x:154,y:598,t:1527621054628};\\\", \\\"{x:151,y:593,t:1527621054645};\\\", \\\"{x:151,y:589,t:1527621054661};\\\", \\\"{x:150,y:586,t:1527621054678};\\\", \\\"{x:150,y:582,t:1527621054695};\\\", \\\"{x:150,y:580,t:1527621054711};\\\", \\\"{x:156,y:580,t:1527621055082};\\\", \\\"{x:175,y:580,t:1527621055095};\\\", \\\"{x:264,y:580,t:1527621055112};\\\", \\\"{x:377,y:580,t:1527621055130};\\\", \\\"{x:486,y:580,t:1527621055145};\\\", \\\"{x:615,y:591,t:1527621055161};\\\", \\\"{x:817,y:612,t:1527621055178};\\\", \\\"{x:931,y:629,t:1527621055195};\\\", \\\"{x:1045,y:645,t:1527621055212};\\\", \\\"{x:1147,y:659,t:1527621055229};\\\", \\\"{x:1231,y:674,t:1527621055245};\\\", \\\"{x:1292,y:688,t:1527621055261};\\\", \\\"{x:1336,y:693,t:1527621055278};\\\", \\\"{x:1362,y:697,t:1527621055295};\\\", \\\"{x:1379,y:701,t:1527621055312};\\\", \\\"{x:1389,y:703,t:1527621055329};\\\", \\\"{x:1398,y:704,t:1527621055346};\\\", \\\"{x:1408,y:707,t:1527621055362};\\\", \\\"{x:1421,y:711,t:1527621055378};\\\", \\\"{x:1438,y:716,t:1527621055395};\\\", \\\"{x:1459,y:722,t:1527621055412};\\\", \\\"{x:1476,y:727,t:1527621055428};\\\", \\\"{x:1503,y:729,t:1527621055446};\\\", \\\"{x:1527,y:735,t:1527621055461};\\\", \\\"{x:1549,y:740,t:1527621055478};\\\", \\\"{x:1563,y:745,t:1527621055496};\\\", \\\"{x:1565,y:745,t:1527621055511};\\\", \\\"{x:1566,y:745,t:1527621055554};\\\", \\\"{x:1566,y:746,t:1527621055579};\\\", \\\"{x:1566,y:748,t:1527621055595};\\\", \\\"{x:1557,y:756,t:1527621055611};\\\", \\\"{x:1545,y:765,t:1527621055628};\\\", \\\"{x:1537,y:769,t:1527621055645};\\\", \\\"{x:1529,y:772,t:1527621055662};\\\", \\\"{x:1515,y:777,t:1527621055678};\\\", \\\"{x:1502,y:781,t:1527621055695};\\\", \\\"{x:1496,y:781,t:1527621055711};\\\", \\\"{x:1491,y:782,t:1527621055728};\\\", \\\"{x:1484,y:782,t:1527621055746};\\\", \\\"{x:1480,y:782,t:1527621055762};\\\", \\\"{x:1476,y:780,t:1527621055778};\\\", \\\"{x:1471,y:776,t:1527621055795};\\\", \\\"{x:1470,y:774,t:1527621055812};\\\", \\\"{x:1470,y:772,t:1527621055828};\\\", \\\"{x:1469,y:767,t:1527621055846};\\\", \\\"{x:1467,y:762,t:1527621055863};\\\", \\\"{x:1466,y:760,t:1527621055879};\\\", \\\"{x:1465,y:758,t:1527621055895};\\\", \\\"{x:1464,y:756,t:1527621055912};\\\", \\\"{x:1463,y:754,t:1527621055928};\\\", \\\"{x:1461,y:752,t:1527621055945};\\\", \\\"{x:1458,y:746,t:1527621055962};\\\", \\\"{x:1455,y:740,t:1527621055978};\\\", \\\"{x:1454,y:731,t:1527621055995};\\\", \\\"{x:1452,y:722,t:1527621056013};\\\", \\\"{x:1450,y:714,t:1527621056029};\\\", \\\"{x:1449,y:705,t:1527621056045};\\\", \\\"{x:1448,y:696,t:1527621056063};\\\", \\\"{x:1444,y:686,t:1527621056079};\\\", \\\"{x:1441,y:673,t:1527621056095};\\\", \\\"{x:1439,y:664,t:1527621056112};\\\", \\\"{x:1439,y:657,t:1527621056129};\\\", \\\"{x:1439,y:651,t:1527621056146};\\\", \\\"{x:1439,y:640,t:1527621056162};\\\", \\\"{x:1440,y:631,t:1527621056180};\\\", \\\"{x:1442,y:622,t:1527621056195};\\\", \\\"{x:1446,y:613,t:1527621056212};\\\", \\\"{x:1450,y:604,t:1527621056229};\\\", \\\"{x:1453,y:598,t:1527621056245};\\\", \\\"{x:1454,y:595,t:1527621056262};\\\", \\\"{x:1455,y:593,t:1527621056290};\\\", \\\"{x:1455,y:594,t:1527621056482};\\\", \\\"{x:1455,y:596,t:1527621056496};\\\", \\\"{x:1455,y:600,t:1527621056512};\\\", \\\"{x:1455,y:603,t:1527621056529};\\\", \\\"{x:1455,y:604,t:1527621056546};\\\", \\\"{x:1455,y:605,t:1527621056602};\\\", \\\"{x:1455,y:606,t:1527621056634};\\\", \\\"{x:1455,y:607,t:1527621056715};\\\", \\\"{x:1454,y:609,t:1527621056730};\\\", \\\"{x:1448,y:610,t:1527621056747};\\\", \\\"{x:1444,y:611,t:1527621056762};\\\", \\\"{x:1441,y:613,t:1527621056780};\\\", \\\"{x:1439,y:614,t:1527621056796};\\\", \\\"{x:1435,y:617,t:1527621056813};\\\", \\\"{x:1428,y:624,t:1527621056829};\\\", \\\"{x:1421,y:634,t:1527621056846};\\\", \\\"{x:1419,y:640,t:1527621056863};\\\", \\\"{x:1413,y:654,t:1527621056879};\\\", \\\"{x:1410,y:671,t:1527621056897};\\\", \\\"{x:1403,y:688,t:1527621056914};\\\", \\\"{x:1397,y:709,t:1527621056930};\\\", \\\"{x:1394,y:732,t:1527621056946};\\\", \\\"{x:1391,y:745,t:1527621056964};\\\", \\\"{x:1391,y:760,t:1527621056979};\\\", \\\"{x:1391,y:775,t:1527621056996};\\\", \\\"{x:1391,y:784,t:1527621057013};\\\", \\\"{x:1392,y:791,t:1527621057030};\\\", \\\"{x:1393,y:801,t:1527621057046};\\\", \\\"{x:1393,y:808,t:1527621057063};\\\", \\\"{x:1393,y:816,t:1527621057079};\\\", \\\"{x:1393,y:826,t:1527621057097};\\\", \\\"{x:1396,y:843,t:1527621057114};\\\", \\\"{x:1397,y:851,t:1527621057130};\\\", \\\"{x:1398,y:856,t:1527621057146};\\\", \\\"{x:1398,y:858,t:1527621057164};\\\", \\\"{x:1397,y:862,t:1527621057180};\\\", \\\"{x:1397,y:863,t:1527621057197};\\\", \\\"{x:1396,y:868,t:1527621057214};\\\", \\\"{x:1394,y:873,t:1527621057231};\\\", \\\"{x:1391,y:879,t:1527621057246};\\\", \\\"{x:1390,y:883,t:1527621057264};\\\", \\\"{x:1387,y:885,t:1527621057280};\\\", \\\"{x:1385,y:887,t:1527621057297};\\\", \\\"{x:1384,y:887,t:1527621057314};\\\", \\\"{x:1384,y:889,t:1527621057329};\\\", \\\"{x:1384,y:890,t:1527621057354};\\\", \\\"{x:1382,y:893,t:1527621057378};\\\", \\\"{x:1381,y:894,t:1527621057396};\\\", \\\"{x:1381,y:895,t:1527621057414};\\\", \\\"{x:1380,y:895,t:1527621057435};\\\", \\\"{x:1378,y:896,t:1527621057466};\\\", \\\"{x:1378,y:897,t:1527621057842};\\\", \\\"{x:1379,y:898,t:1527621057867};\\\", \\\"{x:1381,y:900,t:1527621057883};\\\", \\\"{x:1383,y:900,t:1527621057899};\\\", \\\"{x:1383,y:901,t:1527621057946};\\\", \\\"{x:1383,y:899,t:1527621058458};\\\", \\\"{x:1382,y:899,t:1527621058466};\\\", \\\"{x:1382,y:898,t:1527621058482};\\\", \\\"{x:1381,y:895,t:1527621058498};\\\", \\\"{x:1381,y:893,t:1527621058514};\\\", \\\"{x:1380,y:892,t:1527621058532};\\\", \\\"{x:1379,y:891,t:1527621058562};\\\", \\\"{x:1375,y:885,t:1527621058803};\\\", \\\"{x:1333,y:875,t:1527621058815};\\\", \\\"{x:1210,y:852,t:1527621058832};\\\", \\\"{x:1085,y:834,t:1527621058849};\\\", \\\"{x:991,y:804,t:1527621058865};\\\", \\\"{x:919,y:788,t:1527621058882};\\\", \\\"{x:850,y:765,t:1527621058898};\\\", \\\"{x:809,y:750,t:1527621058915};\\\", \\\"{x:764,y:736,t:1527621058932};\\\", \\\"{x:703,y:719,t:1527621058948};\\\", \\\"{x:680,y:709,t:1527621058964};\\\", \\\"{x:665,y:704,t:1527621058982};\\\", \\\"{x:650,y:697,t:1527621058998};\\\", \\\"{x:639,y:691,t:1527621059014};\\\", \\\"{x:636,y:690,t:1527621059032};\\\", \\\"{x:636,y:688,t:1527621059049};\\\", \\\"{x:632,y:683,t:1527621059065};\\\", \\\"{x:621,y:671,t:1527621059081};\\\", \\\"{x:581,y:636,t:1527621059098};\\\", \\\"{x:563,y:616,t:1527621059115};\\\", \\\"{x:545,y:611,t:1527621059131};\\\", \\\"{x:532,y:607,t:1527621059149};\\\", \\\"{x:530,y:606,t:1527621059164};\\\", \\\"{x:529,y:604,t:1527621059658};\\\", \\\"{x:532,y:602,t:1527621059673};\\\", \\\"{x:534,y:602,t:1527621059682};\\\", \\\"{x:539,y:602,t:1527621059697};\\\", \\\"{x:561,y:602,t:1527621059714};\\\", \\\"{x:583,y:602,t:1527621059732};\\\", \\\"{x:616,y:602,t:1527621059748};\\\", \\\"{x:661,y:602,t:1527621059765};\\\", \\\"{x:747,y:602,t:1527621059782};\\\", \\\"{x:853,y:602,t:1527621059798};\\\", \\\"{x:928,y:604,t:1527621059816};\\\", \\\"{x:1023,y:620,t:1527621059832};\\\", \\\"{x:1111,y:643,t:1527621059849};\\\", \\\"{x:1219,y:671,t:1527621059866};\\\", \\\"{x:1310,y:699,t:1527621059882};\\\", \\\"{x:1443,y:733,t:1527621059899};\\\", \\\"{x:1531,y:756,t:1527621059915};\\\", \\\"{x:1617,y:779,t:1527621059931};\\\", \\\"{x:1662,y:792,t:1527621059949};\\\", \\\"{x:1681,y:804,t:1527621059966};\\\", \\\"{x:1698,y:809,t:1527621059982};\\\", \\\"{x:1707,y:813,t:1527621059998};\\\", \\\"{x:1709,y:814,t:1527621060016};\\\", \\\"{x:1709,y:815,t:1527621060074};\\\", \\\"{x:1707,y:818,t:1527621060082};\\\", \\\"{x:1700,y:822,t:1527621060099};\\\", \\\"{x:1685,y:828,t:1527621060116};\\\", \\\"{x:1669,y:832,t:1527621060133};\\\", \\\"{x:1643,y:842,t:1527621060149};\\\", \\\"{x:1633,y:847,t:1527621060166};\\\", \\\"{x:1624,y:852,t:1527621060183};\\\", \\\"{x:1620,y:852,t:1527621060198};\\\", \\\"{x:1615,y:852,t:1527621060216};\\\", \\\"{x:1612,y:853,t:1527621060233};\\\", \\\"{x:1602,y:851,t:1527621060248};\\\", \\\"{x:1590,y:851,t:1527621060266};\\\", \\\"{x:1585,y:853,t:1527621060322};\\\", \\\"{x:1574,y:854,t:1527621060333};\\\", \\\"{x:1554,y:858,t:1527621060349};\\\", \\\"{x:1538,y:862,t:1527621060366};\\\", \\\"{x:1508,y:863,t:1527621060383};\\\", \\\"{x:1455,y:847,t:1527621060398};\\\", \\\"{x:1380,y:837,t:1527621060415};\\\", \\\"{x:1302,y:824,t:1527621060433};\\\", \\\"{x:1240,y:816,t:1527621060449};\\\", \\\"{x:1153,y:797,t:1527621060466};\\\", \\\"{x:954,y:765,t:1527621060483};\\\", \\\"{x:806,y:734,t:1527621060500};\\\", \\\"{x:650,y:704,t:1527621060516};\\\", \\\"{x:550,y:686,t:1527621060533};\\\", \\\"{x:450,y:674,t:1527621060550};\\\", \\\"{x:399,y:663,t:1527621060566};\\\", \\\"{x:376,y:655,t:1527621060583};\\\", \\\"{x:359,y:653,t:1527621060600};\\\", \\\"{x:353,y:650,t:1527621060818};\\\", \\\"{x:342,y:648,t:1527621060833};\\\", \\\"{x:317,y:639,t:1527621060850};\\\", \\\"{x:260,y:617,t:1527621060866};\\\", \\\"{x:211,y:599,t:1527621060883};\\\", \\\"{x:193,y:594,t:1527621060899};\\\", \\\"{x:181,y:590,t:1527621060916};\\\", \\\"{x:169,y:587,t:1527621060933};\\\", \\\"{x:168,y:587,t:1527621060950};\\\", \\\"{x:170,y:585,t:1527621061083};\\\", \\\"{x:178,y:578,t:1527621061099};\\\", \\\"{x:206,y:570,t:1527621061116};\\\", \\\"{x:228,y:566,t:1527621061133};\\\", \\\"{x:251,y:560,t:1527621061150};\\\", \\\"{x:269,y:558,t:1527621061166};\\\", \\\"{x:291,y:558,t:1527621061182};\\\", \\\"{x:315,y:562,t:1527621061200};\\\", \\\"{x:328,y:563,t:1527621061217};\\\", \\\"{x:337,y:563,t:1527621061233};\\\", \\\"{x:341,y:563,t:1527621061249};\\\", \\\"{x:342,y:563,t:1527621061307};\\\", \\\"{x:343,y:563,t:1527621061338};\\\", \\\"{x:344,y:563,t:1527621061354};\\\", \\\"{x:345,y:563,t:1527621061378};\\\", \\\"{x:346,y:563,t:1527621061386};\\\", \\\"{x:347,y:563,t:1527621061399};\\\", \\\"{x:348,y:563,t:1527621061417};\\\", \\\"{x:354,y:563,t:1527621061434};\\\", \\\"{x:361,y:563,t:1527621061450};\\\", \\\"{x:383,y:563,t:1527621061467};\\\", \\\"{x:386,y:563,t:1527621061484};\\\", \\\"{x:387,y:563,t:1527621061499};\\\", \\\"{x:388,y:563,t:1527621061546};\\\", \\\"{x:389,y:563,t:1527621061626};\\\", \\\"{x:390,y:561,t:1527621061643};\\\", \\\"{x:390,y:557,t:1527621061650};\\\", \\\"{x:389,y:550,t:1527621061667};\\\", \\\"{x:389,y:548,t:1527621061684};\\\", \\\"{x:387,y:546,t:1527621061700};\\\", \\\"{x:386,y:546,t:1527621061716};\\\", \\\"{x:386,y:544,t:1527621061733};\\\", \\\"{x:386,y:543,t:1527621062026};\\\", \\\"{x:387,y:545,t:1527621062107};\\\", \\\"{x:393,y:551,t:1527621062116};\\\", \\\"{x:396,y:556,t:1527621062134};\\\", \\\"{x:396,y:561,t:1527621062151};\\\", \\\"{x:390,y:573,t:1527621062168};\\\", \\\"{x:386,y:579,t:1527621062184};\\\", \\\"{x:384,y:587,t:1527621062200};\\\", \\\"{x:382,y:596,t:1527621062218};\\\", \\\"{x:388,y:610,t:1527621062235};\\\", \\\"{x:404,y:643,t:1527621062251};\\\", \\\"{x:411,y:657,t:1527621062268};\\\", \\\"{x:417,y:665,t:1527621062283};\\\", \\\"{x:427,y:677,t:1527621062301};\\\", \\\"{x:431,y:685,t:1527621062318};\\\", \\\"{x:436,y:692,t:1527621062334};\\\", \\\"{x:443,y:704,t:1527621062351};\\\", \\\"{x:452,y:716,t:1527621062368};\\\", \\\"{x:464,y:730,t:1527621062384};\\\", \\\"{x:480,y:743,t:1527621062401};\\\", \\\"{x:493,y:752,t:1527621062418};\\\", \\\"{x:505,y:757,t:1527621062435};\\\", \\\"{x:507,y:760,t:1527621062451};\\\", \\\"{x:508,y:760,t:1527621062468};\\\", \\\"{x:509,y:760,t:1527621062484};\\\", \\\"{x:511,y:760,t:1527621062501};\\\", \\\"{x:512,y:760,t:1527621062602};\\\", \\\"{x:512,y:759,t:1527621062618};\\\", \\\"{x:513,y:753,t:1527621062635};\\\", \\\"{x:513,y:752,t:1527621062651};\\\", \\\"{x:513,y:751,t:1527621062668};\\\", \\\"{x:513,y:750,t:1527621062683};\\\", \\\"{x:513,y:749,t:1527621062700};\\\", \\\"{x:513,y:747,t:1527621062717};\\\", \\\"{x:512,y:746,t:1527621062735};\\\", \\\"{x:512,y:744,t:1527621062751};\\\", \\\"{x:511,y:742,t:1527621062768};\\\", \\\"{x:511,y:741,t:1527621062784};\\\", \\\"{x:509,y:737,t:1527621063011};\\\", \\\"{x:504,y:730,t:1527621063018};\\\", \\\"{x:497,y:725,t:1527621063034};\\\", \\\"{x:497,y:724,t:1527621063730};\\\", \\\"{x:497,y:723,t:1527621063737};\\\", \\\"{x:497,y:721,t:1527621063751};\\\", \\\"{x:504,y:714,t:1527621063769};\\\", \\\"{x:509,y:710,t:1527621063786};\\\", \\\"{x:512,y:709,t:1527621063802};\\\", \\\"{x:516,y:703,t:1527621063819};\\\", \\\"{x:518,y:703,t:1527621063835};\\\", \\\"{x:523,y:699,t:1527621063851};\\\", \\\"{x:529,y:695,t:1527621063868};\\\", \\\"{x:530,y:692,t:1527621063886};\\\", \\\"{x:538,y:686,t:1527621063902};\\\", \\\"{x:552,y:678,t:1527621063919};\\\", \\\"{x:555,y:676,t:1527621063935};\\\", \\\"{x:567,y:671,t:1527621063957};\\\", \\\"{x:570,y:670,t:1527621063968};\\\", \\\"{x:586,y:665,t:1527621063986};\\\", \\\"{x:596,y:659,t:1527621064001};\\\", \\\"{x:614,y:659,t:1527621064018};\\\", \\\"{x:626,y:659,t:1527621064036};\\\", \\\"{x:641,y:659,t:1527621064052};\\\" ] }, { \\\"rt\\\": 25338, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 488466, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -N -J -B -J -J -I -I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:689,y:668,t:1527621064155};\\\", \\\"{x:691,y:668,t:1527621064169};\\\", \\\"{x:691,y:670,t:1527621064234};\\\", \\\"{x:689,y:672,t:1527621064242};\\\", \\\"{x:687,y:673,t:1527621064253};\\\", \\\"{x:686,y:678,t:1527621064278};\\\", \\\"{x:687,y:678,t:1527621067154};\\\", \\\"{x:688,y:676,t:1527621067171};\\\", \\\"{x:707,y:670,t:1527621067188};\\\", \\\"{x:733,y:669,t:1527621067205};\\\", \\\"{x:754,y:662,t:1527621067221};\\\", \\\"{x:767,y:659,t:1527621067238};\\\", \\\"{x:773,y:655,t:1527621067255};\\\", \\\"{x:785,y:654,t:1527621067272};\\\", \\\"{x:795,y:650,t:1527621067288};\\\", \\\"{x:810,y:643,t:1527621067305};\\\", \\\"{x:839,y:635,t:1527621067322};\\\", \\\"{x:863,y:626,t:1527621067339};\\\", \\\"{x:884,y:621,t:1527621067355};\\\", \\\"{x:910,y:612,t:1527621067372};\\\", \\\"{x:932,y:608,t:1527621067387};\\\", \\\"{x:979,y:608,t:1527621067404};\\\", \\\"{x:1060,y:607,t:1527621067420};\\\", \\\"{x:1129,y:607,t:1527621067438};\\\", \\\"{x:1202,y:607,t:1527621067455};\\\", \\\"{x:1265,y:611,t:1527621067472};\\\", \\\"{x:1335,y:615,t:1527621067488};\\\", \\\"{x:1420,y:633,t:1527621067505};\\\", \\\"{x:1531,y:662,t:1527621067522};\\\", \\\"{x:1613,y:681,t:1527621067539};\\\", \\\"{x:1696,y:702,t:1527621067556};\\\", \\\"{x:1768,y:725,t:1527621067572};\\\", \\\"{x:1822,y:752,t:1527621067589};\\\", \\\"{x:1877,y:777,t:1527621067605};\\\", \\\"{x:1917,y:802,t:1527621067622};\\\", \\\"{x:1919,y:820,t:1527621067639};\\\", \\\"{x:1919,y:831,t:1527621067655};\\\", \\\"{x:1919,y:836,t:1527621067672};\\\", \\\"{x:1919,y:838,t:1527621067688};\\\", \\\"{x:1919,y:840,t:1527621067704};\\\", \\\"{x:1917,y:847,t:1527621067722};\\\", \\\"{x:1916,y:850,t:1527621067738};\\\", \\\"{x:1909,y:854,t:1527621067755};\\\", \\\"{x:1893,y:862,t:1527621067772};\\\", \\\"{x:1876,y:868,t:1527621067788};\\\", \\\"{x:1861,y:874,t:1527621067805};\\\", \\\"{x:1841,y:880,t:1527621067822};\\\", \\\"{x:1831,y:887,t:1527621067839};\\\", \\\"{x:1815,y:891,t:1527621067855};\\\", \\\"{x:1812,y:894,t:1527621067872};\\\", \\\"{x:1809,y:894,t:1527621067889};\\\", \\\"{x:1806,y:894,t:1527621067905};\\\", \\\"{x:1805,y:894,t:1527621067922};\\\", \\\"{x:1804,y:894,t:1527621067939};\\\", \\\"{x:1802,y:894,t:1527621068035};\\\", \\\"{x:1795,y:892,t:1527621068042};\\\", \\\"{x:1793,y:888,t:1527621068055};\\\", \\\"{x:1784,y:878,t:1527621068072};\\\", \\\"{x:1763,y:868,t:1527621068089};\\\", \\\"{x:1735,y:861,t:1527621068106};\\\", \\\"{x:1715,y:847,t:1527621068122};\\\", \\\"{x:1704,y:833,t:1527621068139};\\\", \\\"{x:1697,y:831,t:1527621068156};\\\", \\\"{x:1694,y:828,t:1527621068172};\\\", \\\"{x:1689,y:829,t:1527621068826};\\\", \\\"{x:1685,y:829,t:1527621068850};\\\", \\\"{x:1676,y:834,t:1527621068874};\\\", \\\"{x:1669,y:837,t:1527621068889};\\\", \\\"{x:1653,y:840,t:1527621068906};\\\", \\\"{x:1650,y:842,t:1527621068923};\\\", \\\"{x:1646,y:842,t:1527621068946};\\\", \\\"{x:1641,y:843,t:1527621068956};\\\", \\\"{x:1628,y:847,t:1527621068973};\\\", \\\"{x:1617,y:851,t:1527621068990};\\\", \\\"{x:1594,y:855,t:1527621069006};\\\", \\\"{x:1588,y:855,t:1527621069023};\\\", \\\"{x:1573,y:856,t:1527621069040};\\\", \\\"{x:1563,y:860,t:1527621069056};\\\", \\\"{x:1547,y:861,t:1527621069073};\\\", \\\"{x:1524,y:862,t:1527621069090};\\\", \\\"{x:1511,y:860,t:1527621069106};\\\", \\\"{x:1496,y:858,t:1527621069123};\\\", \\\"{x:1483,y:851,t:1527621069140};\\\", \\\"{x:1450,y:847,t:1527621069156};\\\", \\\"{x:1448,y:844,t:1527621069173};\\\", \\\"{x:1443,y:838,t:1527621069190};\\\", \\\"{x:1439,y:838,t:1527621069206};\\\", \\\"{x:1438,y:838,t:1527621070394};\\\", \\\"{x:1436,y:838,t:1527621070407};\\\", \\\"{x:1433,y:838,t:1527621070424};\\\", \\\"{x:1432,y:838,t:1527621070441};\\\", \\\"{x:1431,y:838,t:1527621070457};\\\", \\\"{x:1428,y:840,t:1527621070474};\\\", \\\"{x:1428,y:842,t:1527621070491};\\\", \\\"{x:1426,y:844,t:1527621070507};\\\", \\\"{x:1424,y:846,t:1527621070525};\\\", \\\"{x:1419,y:847,t:1527621070541};\\\", \\\"{x:1416,y:848,t:1527621070558};\\\", \\\"{x:1411,y:848,t:1527621070575};\\\", \\\"{x:1402,y:848,t:1527621070591};\\\", \\\"{x:1389,y:848,t:1527621070607};\\\", \\\"{x:1375,y:849,t:1527621070625};\\\", \\\"{x:1356,y:849,t:1527621070641};\\\", \\\"{x:1344,y:849,t:1527621070658};\\\", \\\"{x:1315,y:849,t:1527621070673};\\\", \\\"{x:1294,y:852,t:1527621070691};\\\", \\\"{x:1280,y:852,t:1527621070707};\\\", \\\"{x:1274,y:853,t:1527621070724};\\\", \\\"{x:1272,y:853,t:1527621070741};\\\", \\\"{x:1267,y:853,t:1527621070758};\\\", \\\"{x:1259,y:852,t:1527621070774};\\\", \\\"{x:1240,y:852,t:1527621070791};\\\", \\\"{x:1227,y:852,t:1527621070808};\\\", \\\"{x:1206,y:852,t:1527621070824};\\\", \\\"{x:1183,y:852,t:1527621070841};\\\", \\\"{x:1147,y:850,t:1527621070857};\\\", \\\"{x:1124,y:848,t:1527621070874};\\\", \\\"{x:1110,y:845,t:1527621070891};\\\", \\\"{x:1106,y:845,t:1527621070909};\\\", \\\"{x:1105,y:845,t:1527621070924};\\\", \\\"{x:1104,y:845,t:1527621070941};\\\", \\\"{x:1109,y:842,t:1527621071074};\\\", \\\"{x:1119,y:834,t:1527621071091};\\\", \\\"{x:1137,y:830,t:1527621071108};\\\", \\\"{x:1157,y:830,t:1527621071124};\\\", \\\"{x:1174,y:830,t:1527621071142};\\\", \\\"{x:1193,y:830,t:1527621071158};\\\", \\\"{x:1200,y:830,t:1527621071175};\\\", \\\"{x:1205,y:830,t:1527621071191};\\\", \\\"{x:1206,y:830,t:1527621071234};\\\", \\\"{x:1207,y:830,t:1527621071259};\\\", \\\"{x:1208,y:830,t:1527621071282};\\\", \\\"{x:1209,y:830,t:1527621071427};\\\", \\\"{x:1210,y:830,t:1527621071474};\\\", \\\"{x:1211,y:830,t:1527621071514};\\\", \\\"{x:1212,y:830,t:1527621071834};\\\", \\\"{x:1213,y:830,t:1527621071898};\\\", \\\"{x:1215,y:830,t:1527621071908};\\\", \\\"{x:1217,y:831,t:1527621071925};\\\", \\\"{x:1218,y:833,t:1527621071942};\\\", \\\"{x:1220,y:833,t:1527621071959};\\\", \\\"{x:1224,y:835,t:1527621071975};\\\", \\\"{x:1225,y:835,t:1527621071992};\\\", \\\"{x:1227,y:835,t:1527621072008};\\\", \\\"{x:1228,y:835,t:1527621072026};\\\", \\\"{x:1230,y:835,t:1527621072067};\\\", \\\"{x:1231,y:835,t:1527621072075};\\\", \\\"{x:1234,y:835,t:1527621072092};\\\", \\\"{x:1235,y:835,t:1527621072138};\\\", \\\"{x:1234,y:835,t:1527621072634};\\\", \\\"{x:1233,y:835,t:1527621072666};\\\", \\\"{x:1231,y:835,t:1527621072676};\\\", \\\"{x:1230,y:835,t:1527621072692};\\\", \\\"{x:1228,y:835,t:1527621072709};\\\", \\\"{x:1226,y:835,t:1527621072726};\\\", \\\"{x:1225,y:834,t:1527621072742};\\\", \\\"{x:1224,y:834,t:1527621072771};\\\", \\\"{x:1223,y:834,t:1527621072794};\\\", \\\"{x:1222,y:834,t:1527621072826};\\\", \\\"{x:1222,y:833,t:1527621072858};\\\", \\\"{x:1221,y:833,t:1527621072883};\\\", \\\"{x:1223,y:833,t:1527621073010};\\\", \\\"{x:1230,y:832,t:1527621073026};\\\", \\\"{x:1238,y:830,t:1527621073044};\\\", \\\"{x:1240,y:829,t:1527621073060};\\\", \\\"{x:1242,y:828,t:1527621073076};\\\", \\\"{x:1251,y:825,t:1527621073093};\\\", \\\"{x:1259,y:823,t:1527621073109};\\\", \\\"{x:1263,y:822,t:1527621073126};\\\", \\\"{x:1271,y:819,t:1527621073143};\\\", \\\"{x:1272,y:818,t:1527621073159};\\\", \\\"{x:1276,y:816,t:1527621073176};\\\", \\\"{x:1280,y:815,t:1527621073193};\\\", \\\"{x:1284,y:812,t:1527621073209};\\\", \\\"{x:1289,y:809,t:1527621073226};\\\", \\\"{x:1292,y:809,t:1527621073258};\\\", \\\"{x:1292,y:808,t:1527621073265};\\\", \\\"{x:1293,y:808,t:1527621073276};\\\", \\\"{x:1295,y:807,t:1527621073322};\\\", \\\"{x:1297,y:806,t:1527621073338};\\\", \\\"{x:1297,y:805,t:1527621073362};\\\", \\\"{x:1299,y:805,t:1527621073378};\\\", \\\"{x:1299,y:804,t:1527621073393};\\\", \\\"{x:1301,y:803,t:1527621073410};\\\", \\\"{x:1303,y:801,t:1527621073427};\\\", \\\"{x:1304,y:800,t:1527621073443};\\\", \\\"{x:1304,y:799,t:1527621073460};\\\", \\\"{x:1306,y:797,t:1527621073476};\\\", \\\"{x:1310,y:795,t:1527621073494};\\\", \\\"{x:1311,y:792,t:1527621073510};\\\", \\\"{x:1314,y:791,t:1527621073527};\\\", \\\"{x:1317,y:788,t:1527621073543};\\\", \\\"{x:1319,y:787,t:1527621073560};\\\", \\\"{x:1322,y:786,t:1527621073577};\\\", \\\"{x:1324,y:785,t:1527621073593};\\\", \\\"{x:1328,y:781,t:1527621073610};\\\", \\\"{x:1329,y:780,t:1527621073626};\\\", \\\"{x:1331,y:779,t:1527621073644};\\\", \\\"{x:1332,y:778,t:1527621073660};\\\", \\\"{x:1334,y:776,t:1527621073676};\\\", \\\"{x:1337,y:773,t:1527621073693};\\\", \\\"{x:1338,y:772,t:1527621073710};\\\", \\\"{x:1341,y:768,t:1527621073727};\\\", \\\"{x:1342,y:766,t:1527621073743};\\\", \\\"{x:1342,y:764,t:1527621073760};\\\", \\\"{x:1343,y:764,t:1527621073777};\\\", \\\"{x:1342,y:764,t:1527621075475};\\\", \\\"{x:1341,y:764,t:1527621075490};\\\", \\\"{x:1340,y:764,t:1527621075530};\\\", \\\"{x:1339,y:764,t:1527621075578};\\\", \\\"{x:1338,y:764,t:1527621075610};\\\", \\\"{x:1337,y:764,t:1527621075634};\\\", \\\"{x:1335,y:764,t:1527621075650};\\\", \\\"{x:1335,y:765,t:1527621075661};\\\", \\\"{x:1334,y:765,t:1527621075678};\\\", \\\"{x:1329,y:766,t:1527621075696};\\\", \\\"{x:1318,y:770,t:1527621075711};\\\", \\\"{x:1312,y:772,t:1527621075728};\\\", \\\"{x:1307,y:774,t:1527621075745};\\\", \\\"{x:1298,y:777,t:1527621075762};\\\", \\\"{x:1291,y:778,t:1527621075778};\\\", \\\"{x:1287,y:780,t:1527621075795};\\\", \\\"{x:1285,y:780,t:1527621075811};\\\", \\\"{x:1282,y:780,t:1527621075828};\\\", \\\"{x:1278,y:782,t:1527621075846};\\\", \\\"{x:1274,y:782,t:1527621075861};\\\", \\\"{x:1271,y:784,t:1527621075878};\\\", \\\"{x:1263,y:786,t:1527621075895};\\\", \\\"{x:1258,y:788,t:1527621075912};\\\", \\\"{x:1250,y:790,t:1527621075928};\\\", \\\"{x:1241,y:794,t:1527621075945};\\\", \\\"{x:1232,y:795,t:1527621075962};\\\", \\\"{x:1229,y:797,t:1527621075979};\\\", \\\"{x:1228,y:797,t:1527621075995};\\\", \\\"{x:1227,y:797,t:1527621076011};\\\", \\\"{x:1223,y:798,t:1527621076029};\\\", \\\"{x:1221,y:800,t:1527621076046};\\\", \\\"{x:1217,y:802,t:1527621076062};\\\", \\\"{x:1215,y:803,t:1527621076079};\\\", \\\"{x:1211,y:805,t:1527621076096};\\\", \\\"{x:1208,y:807,t:1527621076113};\\\", \\\"{x:1205,y:808,t:1527621076129};\\\", \\\"{x:1203,y:808,t:1527621076145};\\\", \\\"{x:1198,y:811,t:1527621076162};\\\", \\\"{x:1195,y:812,t:1527621076179};\\\", \\\"{x:1193,y:814,t:1527621076195};\\\", \\\"{x:1191,y:814,t:1527621076213};\\\", \\\"{x:1187,y:815,t:1527621076228};\\\", \\\"{x:1186,y:815,t:1527621076246};\\\", \\\"{x:1184,y:817,t:1527621076262};\\\", \\\"{x:1183,y:817,t:1527621076338};\\\", \\\"{x:1182,y:817,t:1527621076362};\\\", \\\"{x:1181,y:818,t:1527621076378};\\\", \\\"{x:1184,y:818,t:1527621076834};\\\", \\\"{x:1190,y:821,t:1527621076846};\\\", \\\"{x:1207,y:824,t:1527621076862};\\\", \\\"{x:1212,y:827,t:1527621076879};\\\", \\\"{x:1217,y:828,t:1527621076897};\\\", \\\"{x:1219,y:830,t:1527621076912};\\\", \\\"{x:1220,y:830,t:1527621077010};\\\", \\\"{x:1221,y:830,t:1527621077042};\\\", \\\"{x:1220,y:830,t:1527621077411};\\\", \\\"{x:1218,y:830,t:1527621077430};\\\", \\\"{x:1217,y:830,t:1527621077447};\\\", \\\"{x:1215,y:830,t:1527621077466};\\\", \\\"{x:1214,y:830,t:1527621077480};\\\", \\\"{x:1212,y:830,t:1527621077497};\\\", \\\"{x:1211,y:830,t:1527621078122};\\\", \\\"{x:1210,y:830,t:1527621078129};\\\", \\\"{x:1208,y:829,t:1527621078147};\\\", \\\"{x:1208,y:828,t:1527621078242};\\\", \\\"{x:1207,y:828,t:1527621078282};\\\", \\\"{x:1206,y:828,t:1527621078314};\\\", \\\"{x:1206,y:827,t:1527621078330};\\\", \\\"{x:1205,y:826,t:1527621078370};\\\", \\\"{x:1205,y:825,t:1527621078381};\\\", \\\"{x:1201,y:820,t:1527621078398};\\\", \\\"{x:1197,y:815,t:1527621078414};\\\", \\\"{x:1193,y:808,t:1527621078431};\\\", \\\"{x:1183,y:801,t:1527621078448};\\\", \\\"{x:1180,y:798,t:1527621078463};\\\", \\\"{x:1174,y:793,t:1527621078481};\\\", \\\"{x:1168,y:789,t:1527621078498};\\\", \\\"{x:1166,y:785,t:1527621078514};\\\", \\\"{x:1164,y:782,t:1527621078531};\\\", \\\"{x:1164,y:780,t:1527621078548};\\\", \\\"{x:1164,y:779,t:1527621078602};\\\", \\\"{x:1164,y:777,t:1527621078618};\\\", \\\"{x:1164,y:776,t:1527621078649};\\\", \\\"{x:1163,y:774,t:1527621078665};\\\", \\\"{x:1163,y:773,t:1527621078681};\\\", \\\"{x:1163,y:772,t:1527621078698};\\\", \\\"{x:1163,y:770,t:1527621078714};\\\", \\\"{x:1163,y:768,t:1527621078731};\\\", \\\"{x:1163,y:767,t:1527621078747};\\\", \\\"{x:1163,y:766,t:1527621078764};\\\", \\\"{x:1163,y:765,t:1527621078780};\\\", \\\"{x:1163,y:763,t:1527621078798};\\\", \\\"{x:1163,y:762,t:1527621078859};\\\", \\\"{x:1163,y:761,t:1527621078906};\\\", \\\"{x:1164,y:760,t:1527621078938};\\\", \\\"{x:1166,y:760,t:1527621078977};\\\", \\\"{x:1167,y:760,t:1527621079002};\\\", \\\"{x:1169,y:759,t:1527621079018};\\\", \\\"{x:1170,y:759,t:1527621079058};\\\", \\\"{x:1172,y:759,t:1527621079073};\\\", \\\"{x:1173,y:759,t:1527621079082};\\\", \\\"{x:1176,y:759,t:1527621079098};\\\", \\\"{x:1179,y:759,t:1527621079114};\\\", \\\"{x:1182,y:759,t:1527621079131};\\\", \\\"{x:1183,y:759,t:1527621079147};\\\", \\\"{x:1184,y:759,t:1527621079164};\\\", \\\"{x:1185,y:759,t:1527621079266};\\\", \\\"{x:1185,y:760,t:1527621079418};\\\", \\\"{x:1186,y:760,t:1527621079866};\\\", \\\"{x:1188,y:761,t:1527621080067};\\\", \\\"{x:1187,y:761,t:1527621080314};\\\", \\\"{x:1181,y:761,t:1527621080322};\\\", \\\"{x:1170,y:761,t:1527621080332};\\\", \\\"{x:1140,y:754,t:1527621080349};\\\", \\\"{x:1128,y:749,t:1527621080366};\\\", \\\"{x:1081,y:733,t:1527621080382};\\\", \\\"{x:1046,y:717,t:1527621080398};\\\", \\\"{x:1000,y:700,t:1527621080416};\\\", \\\"{x:915,y:677,t:1527621080433};\\\", \\\"{x:841,y:652,t:1527621080449};\\\", \\\"{x:774,y:633,t:1527621080466};\\\", \\\"{x:772,y:633,t:1527621080482};\\\", \\\"{x:771,y:633,t:1527621081243};\\\", \\\"{x:769,y:633,t:1527621081260};\\\", \\\"{x:749,y:630,t:1527621081276};\\\", \\\"{x:726,y:628,t:1527621081292};\\\", \\\"{x:695,y:622,t:1527621081310};\\\", \\\"{x:670,y:616,t:1527621081326};\\\", \\\"{x:647,y:611,t:1527621081342};\\\", \\\"{x:621,y:606,t:1527621081359};\\\", \\\"{x:599,y:599,t:1527621081376};\\\", \\\"{x:574,y:594,t:1527621081392};\\\", \\\"{x:557,y:590,t:1527621081409};\\\", \\\"{x:544,y:588,t:1527621081426};\\\", \\\"{x:538,y:585,t:1527621081443};\\\", \\\"{x:538,y:584,t:1527621081459};\\\", \\\"{x:538,y:583,t:1527621081900};\\\", \\\"{x:537,y:583,t:1527621081911};\\\", \\\"{x:534,y:581,t:1527621081927};\\\", \\\"{x:530,y:581,t:1527621081944};\\\", \\\"{x:522,y:579,t:1527621081961};\\\", \\\"{x:509,y:576,t:1527621081977};\\\", \\\"{x:493,y:571,t:1527621081995};\\\", \\\"{x:471,y:568,t:1527621082012};\\\", \\\"{x:452,y:565,t:1527621082027};\\\", \\\"{x:429,y:562,t:1527621082042};\\\", \\\"{x:405,y:560,t:1527621082059};\\\", \\\"{x:372,y:559,t:1527621082076};\\\", \\\"{x:354,y:557,t:1527621082093};\\\", \\\"{x:332,y:557,t:1527621082110};\\\", \\\"{x:319,y:557,t:1527621082126};\\\", \\\"{x:305,y:557,t:1527621082143};\\\", \\\"{x:301,y:556,t:1527621082160};\\\", \\\"{x:300,y:556,t:1527621082187};\\\", \\\"{x:299,y:556,t:1527621082196};\\\", \\\"{x:297,y:556,t:1527621082210};\\\", \\\"{x:291,y:559,t:1527621082227};\\\", \\\"{x:267,y:569,t:1527621082243};\\\", \\\"{x:246,y:575,t:1527621082260};\\\", \\\"{x:231,y:580,t:1527621082277};\\\", \\\"{x:213,y:580,t:1527621082293};\\\", \\\"{x:199,y:580,t:1527621082311};\\\", \\\"{x:192,y:580,t:1527621082328};\\\", \\\"{x:186,y:580,t:1527621082344};\\\", \\\"{x:182,y:575,t:1527621082360};\\\", \\\"{x:180,y:574,t:1527621082377};\\\", \\\"{x:176,y:567,t:1527621082393};\\\", \\\"{x:170,y:546,t:1527621082411};\\\", \\\"{x:170,y:516,t:1527621082427};\\\", \\\"{x:170,y:493,t:1527621082444};\\\", \\\"{x:170,y:467,t:1527621082461};\\\", \\\"{x:169,y:463,t:1527621082478};\\\", \\\"{x:167,y:466,t:1527621082660};\\\", \\\"{x:167,y:471,t:1527621082667};\\\", \\\"{x:166,y:477,t:1527621082677};\\\", \\\"{x:166,y:485,t:1527621082694};\\\", \\\"{x:168,y:488,t:1527621082712};\\\", \\\"{x:170,y:491,t:1527621082728};\\\", \\\"{x:171,y:491,t:1527621082744};\\\", \\\"{x:171,y:492,t:1527621082916};\\\", \\\"{x:171,y:494,t:1527621083275};\\\", \\\"{x:186,y:496,t:1527621083283};\\\", \\\"{x:221,y:500,t:1527621083295};\\\", \\\"{x:318,y:515,t:1527621083311};\\\", \\\"{x:420,y:539,t:1527621083327};\\\", \\\"{x:538,y:562,t:1527621083344};\\\", \\\"{x:645,y:592,t:1527621083361};\\\", \\\"{x:756,y:623,t:1527621083377};\\\", \\\"{x:850,y:651,t:1527621083395};\\\", \\\"{x:945,y:691,t:1527621083411};\\\", \\\"{x:989,y:716,t:1527621083428};\\\", \\\"{x:1023,y:740,t:1527621083444};\\\", \\\"{x:1045,y:760,t:1527621083461};\\\", \\\"{x:1074,y:781,t:1527621083477};\\\", \\\"{x:1097,y:801,t:1527621083494};\\\", \\\"{x:1119,y:817,t:1527621083511};\\\", \\\"{x:1137,y:834,t:1527621083527};\\\", \\\"{x:1150,y:843,t:1527621083544};\\\", \\\"{x:1163,y:855,t:1527621083561};\\\", \\\"{x:1174,y:867,t:1527621083577};\\\", \\\"{x:1194,y:884,t:1527621083594};\\\", \\\"{x:1222,y:905,t:1527621083611};\\\", \\\"{x:1240,y:921,t:1527621083628};\\\", \\\"{x:1257,y:930,t:1527621083644};\\\", \\\"{x:1272,y:939,t:1527621083661};\\\", \\\"{x:1290,y:944,t:1527621083678};\\\", \\\"{x:1305,y:950,t:1527621083695};\\\", \\\"{x:1318,y:952,t:1527621083711};\\\", \\\"{x:1331,y:954,t:1527621083728};\\\", \\\"{x:1340,y:957,t:1527621083744};\\\", \\\"{x:1349,y:959,t:1527621083761};\\\", \\\"{x:1352,y:959,t:1527621083777};\\\", \\\"{x:1356,y:959,t:1527621083794};\\\", \\\"{x:1357,y:959,t:1527621083811};\\\", \\\"{x:1358,y:959,t:1527621083859};\\\", \\\"{x:1358,y:958,t:1527621083883};\\\", \\\"{x:1358,y:957,t:1527621083894};\\\", \\\"{x:1358,y:954,t:1527621083910};\\\", \\\"{x:1357,y:948,t:1527621083927};\\\", \\\"{x:1355,y:945,t:1527621083944};\\\", \\\"{x:1352,y:939,t:1527621083960};\\\", \\\"{x:1345,y:930,t:1527621083977};\\\", \\\"{x:1339,y:920,t:1527621083994};\\\", \\\"{x:1336,y:917,t:1527621084010};\\\", \\\"{x:1332,y:908,t:1527621084027};\\\", \\\"{x:1330,y:904,t:1527621084044};\\\", \\\"{x:1328,y:900,t:1527621084060};\\\", \\\"{x:1326,y:897,t:1527621084078};\\\", \\\"{x:1325,y:893,t:1527621084094};\\\", \\\"{x:1324,y:889,t:1527621084111};\\\", \\\"{x:1324,y:885,t:1527621084128};\\\", \\\"{x:1323,y:883,t:1527621084143};\\\", \\\"{x:1323,y:881,t:1527621084163};\\\", \\\"{x:1323,y:880,t:1527621084177};\\\", \\\"{x:1323,y:879,t:1527621084193};\\\", \\\"{x:1320,y:876,t:1527621084210};\\\", \\\"{x:1318,y:871,t:1527621084227};\\\", \\\"{x:1318,y:870,t:1527621084243};\\\", \\\"{x:1318,y:866,t:1527621084260};\\\", \\\"{x:1317,y:863,t:1527621084277};\\\", \\\"{x:1317,y:860,t:1527621084293};\\\", \\\"{x:1316,y:857,t:1527621084310};\\\", \\\"{x:1314,y:853,t:1527621084327};\\\", \\\"{x:1313,y:850,t:1527621084343};\\\", \\\"{x:1310,y:847,t:1527621084360};\\\", \\\"{x:1310,y:845,t:1527621084377};\\\", \\\"{x:1309,y:844,t:1527621084395};\\\", \\\"{x:1309,y:843,t:1527621084410};\\\", \\\"{x:1306,y:841,t:1527621084427};\\\", \\\"{x:1304,y:839,t:1527621084443};\\\", \\\"{x:1301,y:838,t:1527621084460};\\\", \\\"{x:1297,y:835,t:1527621084477};\\\", \\\"{x:1289,y:834,t:1527621084493};\\\", \\\"{x:1281,y:830,t:1527621084510};\\\", \\\"{x:1278,y:829,t:1527621084527};\\\", \\\"{x:1276,y:829,t:1527621084547};\\\", \\\"{x:1275,y:827,t:1527621084560};\\\", \\\"{x:1273,y:827,t:1527621084576};\\\", \\\"{x:1272,y:827,t:1527621084593};\\\", \\\"{x:1270,y:825,t:1527621084610};\\\", \\\"{x:1265,y:824,t:1527621084626};\\\", \\\"{x:1249,y:820,t:1527621084643};\\\", \\\"{x:1237,y:819,t:1527621084660};\\\", \\\"{x:1233,y:818,t:1527621084676};\\\", \\\"{x:1229,y:818,t:1527621084693};\\\", \\\"{x:1227,y:818,t:1527621084710};\\\", \\\"{x:1226,y:818,t:1527621084726};\\\", \\\"{x:1225,y:818,t:1527621084771};\\\", \\\"{x:1224,y:816,t:1527621084787};\\\", \\\"{x:1222,y:815,t:1527621084859};\\\", \\\"{x:1222,y:812,t:1527621084876};\\\", \\\"{x:1221,y:808,t:1527621084893};\\\", \\\"{x:1221,y:797,t:1527621084910};\\\", \\\"{x:1219,y:788,t:1527621084926};\\\", \\\"{x:1219,y:785,t:1527621084943};\\\", \\\"{x:1223,y:778,t:1527621084959};\\\", \\\"{x:1225,y:772,t:1527621084976};\\\", \\\"{x:1228,y:767,t:1527621084993};\\\", \\\"{x:1233,y:759,t:1527621085009};\\\", \\\"{x:1240,y:746,t:1527621085026};\\\", \\\"{x:1248,y:727,t:1527621085043};\\\", \\\"{x:1256,y:713,t:1527621085059};\\\", \\\"{x:1263,y:705,t:1527621085076};\\\", \\\"{x:1268,y:694,t:1527621085093};\\\", \\\"{x:1270,y:690,t:1527621085109};\\\", \\\"{x:1271,y:687,t:1527621085126};\\\", \\\"{x:1273,y:681,t:1527621085144};\\\", \\\"{x:1274,y:675,t:1527621085159};\\\", \\\"{x:1275,y:671,t:1527621085176};\\\", \\\"{x:1276,y:667,t:1527621085194};\\\", \\\"{x:1276,y:664,t:1527621085209};\\\", \\\"{x:1276,y:659,t:1527621085226};\\\", \\\"{x:1276,y:655,t:1527621085243};\\\", \\\"{x:1278,y:651,t:1527621085259};\\\", \\\"{x:1278,y:648,t:1527621085276};\\\", \\\"{x:1278,y:645,t:1527621085293};\\\", \\\"{x:1277,y:642,t:1527621085309};\\\", \\\"{x:1275,y:637,t:1527621085326};\\\", \\\"{x:1274,y:630,t:1527621085342};\\\", \\\"{x:1274,y:624,t:1527621085359};\\\", \\\"{x:1274,y:619,t:1527621085376};\\\", \\\"{x:1274,y:618,t:1527621085392};\\\", \\\"{x:1274,y:616,t:1527621085409};\\\", \\\"{x:1272,y:614,t:1527621085426};\\\", \\\"{x:1271,y:613,t:1527621085442};\\\", \\\"{x:1271,y:612,t:1527621085475};\\\", \\\"{x:1271,y:611,t:1527621085491};\\\", \\\"{x:1271,y:609,t:1527621085499};\\\", \\\"{x:1271,y:608,t:1527621085523};\\\", \\\"{x:1271,y:607,t:1527621085531};\\\", \\\"{x:1271,y:606,t:1527621085547};\\\", \\\"{x:1273,y:604,t:1527621085563};\\\", \\\"{x:1273,y:603,t:1527621085580};\\\", \\\"{x:1273,y:602,t:1527621085592};\\\", \\\"{x:1274,y:601,t:1527621085609};\\\", \\\"{x:1274,y:600,t:1527621085626};\\\", \\\"{x:1274,y:598,t:1527621085642};\\\", \\\"{x:1275,y:597,t:1527621085659};\\\", \\\"{x:1275,y:595,t:1527621085676};\\\", \\\"{x:1276,y:594,t:1527621085693};\\\", \\\"{x:1276,y:593,t:1527621085715};\\\", \\\"{x:1278,y:591,t:1527621085731};\\\", \\\"{x:1278,y:590,t:1527621085763};\\\", \\\"{x:1279,y:590,t:1527621085787};\\\", \\\"{x:1280,y:589,t:1527621085795};\\\", \\\"{x:1280,y:587,t:1527621085819};\\\", \\\"{x:1281,y:587,t:1527621085827};\\\", \\\"{x:1282,y:585,t:1527621085851};\\\", \\\"{x:1282,y:584,t:1527621085924};\\\", \\\"{x:1282,y:582,t:1527621085955};\\\", \\\"{x:1284,y:581,t:1527621085996};\\\", \\\"{x:1284,y:580,t:1527621086010};\\\", \\\"{x:1284,y:578,t:1527621086027};\\\", \\\"{x:1285,y:576,t:1527621086052};\\\", \\\"{x:1285,y:575,t:1527621086075};\\\", \\\"{x:1286,y:575,t:1527621086092};\\\", \\\"{x:1287,y:574,t:1527621086116};\\\", \\\"{x:1287,y:572,t:1527621086156};\\\", \\\"{x:1287,y:571,t:1527621086692};\\\", \\\"{x:1287,y:570,t:1527621087524};\\\", \\\"{x:1287,y:569,t:1527621087539};\\\", \\\"{x:1286,y:569,t:1527621087547};\\\", \\\"{x:1284,y:569,t:1527621087563};\\\", \\\"{x:1281,y:569,t:1527621087574};\\\", \\\"{x:1277,y:569,t:1527621087591};\\\", \\\"{x:1276,y:569,t:1527621087607};\\\", \\\"{x:1273,y:569,t:1527621087625};\\\", \\\"{x:1271,y:570,t:1527621087640};\\\", \\\"{x:1264,y:580,t:1527621087657};\\\", \\\"{x:1254,y:589,t:1527621087675};\\\", \\\"{x:1250,y:596,t:1527621087690};\\\", \\\"{x:1231,y:612,t:1527621087707};\\\", \\\"{x:1223,y:623,t:1527621087725};\\\", \\\"{x:1214,y:633,t:1527621087741};\\\", \\\"{x:1211,y:635,t:1527621087758};\\\", \\\"{x:1211,y:636,t:1527621087774};\\\", \\\"{x:1210,y:637,t:1527621087790};\\\", \\\"{x:1208,y:638,t:1527621087807};\\\", \\\"{x:1206,y:641,t:1527621087825};\\\", \\\"{x:1205,y:643,t:1527621087841};\\\", \\\"{x:1202,y:643,t:1527621087858};\\\", \\\"{x:1202,y:642,t:1527621087874};\\\", \\\"{x:1201,y:639,t:1527621087890};\\\", \\\"{x:1201,y:638,t:1527621088316};\\\", \\\"{x:1200,y:637,t:1527621088324};\\\", \\\"{x:1194,y:637,t:1527621088340};\\\", \\\"{x:1186,y:638,t:1527621088357};\\\", \\\"{x:1179,y:642,t:1527621088373};\\\", \\\"{x:1165,y:648,t:1527621088390};\\\", \\\"{x:1151,y:661,t:1527621088407};\\\", \\\"{x:1115,y:679,t:1527621088424};\\\", \\\"{x:1095,y:694,t:1527621088441};\\\", \\\"{x:1020,y:729,t:1527621088456};\\\", \\\"{x:949,y:756,t:1527621088474};\\\", \\\"{x:900,y:784,t:1527621088491};\\\", \\\"{x:876,y:801,t:1527621088506};\\\", \\\"{x:853,y:822,t:1527621088523};\\\", \\\"{x:851,y:824,t:1527621088541};\\\", \\\"{x:851,y:825,t:1527621088557};\\\", \\\"{x:850,y:826,t:1527621088573};\\\", \\\"{x:845,y:829,t:1527621088590};\\\", \\\"{x:836,y:834,t:1527621088606};\\\", \\\"{x:813,y:834,t:1527621088624};\\\", \\\"{x:780,y:834,t:1527621088640};\\\", \\\"{x:701,y:820,t:1527621088657};\\\", \\\"{x:639,y:804,t:1527621088673};\\\", \\\"{x:592,y:790,t:1527621088691};\\\", \\\"{x:551,y:774,t:1527621088707};\\\", \\\"{x:501,y:760,t:1527621088724};\\\", \\\"{x:468,y:751,t:1527621088741};\\\", \\\"{x:436,y:744,t:1527621088756};\\\", \\\"{x:429,y:743,t:1527621088774};\\\", \\\"{x:428,y:743,t:1527621088783};\\\", \\\"{x:422,y:743,t:1527621088798};\\\", \\\"{x:421,y:743,t:1527621088816};\\\", \\\"{x:424,y:741,t:1527621088940};\\\", \\\"{x:425,y:741,t:1527621088950};\\\", \\\"{x:427,y:741,t:1527621088965};\\\", \\\"{x:428,y:740,t:1527621088982};\\\", \\\"{x:429,y:740,t:1527621088999};\\\", \\\"{x:431,y:740,t:1527621089016};\\\", \\\"{x:433,y:739,t:1527621089033};\\\", \\\"{x:434,y:739,t:1527621089059};\\\", \\\"{x:435,y:738,t:1527621089075};\\\", \\\"{x:437,y:737,t:1527621089084};\\\", \\\"{x:438,y:736,t:1527621089099};\\\", \\\"{x:440,y:736,t:1527621089116};\\\", \\\"{x:443,y:736,t:1527621089133};\\\", \\\"{x:446,y:736,t:1527621089150};\\\", \\\"{x:447,y:736,t:1527621089167};\\\", \\\"{x:449,y:737,t:1527621089183};\\\", \\\"{x:452,y:737,t:1527621089199};\\\", \\\"{x:452,y:738,t:1527621089216};\\\", \\\"{x:454,y:738,t:1527621089233};\\\", \\\"{x:460,y:738,t:1527621089250};\\\", \\\"{x:463,y:739,t:1527621089265};\\\", \\\"{x:466,y:740,t:1527621089282};\\\", \\\"{x:468,y:741,t:1527621089299};\\\", \\\"{x:473,y:741,t:1527621089667};\\\", \\\"{x:483,y:738,t:1527621089682};\\\", \\\"{x:525,y:727,t:1527621089699};\\\", \\\"{x:546,y:722,t:1527621089715};\\\", \\\"{x:578,y:716,t:1527621089733};\\\", \\\"{x:614,y:713,t:1527621089749};\\\", \\\"{x:655,y:710,t:1527621089767};\\\", \\\"{x:679,y:711,t:1527621089782};\\\", \\\"{x:721,y:718,t:1527621089800};\\\", \\\"{x:740,y:718,t:1527621089817};\\\", \\\"{x:762,y:720,t:1527621089832};\\\", \\\"{x:777,y:720,t:1527621089849};\\\", \\\"{x:799,y:720,t:1527621089866};\\\", \\\"{x:810,y:720,t:1527621089882};\\\", \\\"{x:814,y:720,t:1527621089899};\\\", \\\"{x:815,y:720,t:1527621089916};\\\" ] }, { \\\"rt\\\": 29881, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 519561, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -M -M -X -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:818,y:720,t:1527621094148};\\\", \\\"{x:820,y:720,t:1527621094155};\\\", \\\"{x:820,y:719,t:1527621094170};\\\", \\\"{x:819,y:718,t:1527621094507};\\\", \\\"{x:809,y:715,t:1527621094521};\\\", \\\"{x:791,y:710,t:1527621094537};\\\", \\\"{x:776,y:704,t:1527621094554};\\\", \\\"{x:762,y:700,t:1527621094571};\\\", \\\"{x:739,y:691,t:1527621094587};\\\", \\\"{x:689,y:669,t:1527621094603};\\\", \\\"{x:607,y:648,t:1527621094620};\\\", \\\"{x:570,y:625,t:1527621094637};\\\", \\\"{x:495,y:598,t:1527621094654};\\\", \\\"{x:399,y:574,t:1527621094670};\\\", \\\"{x:323,y:562,t:1527621094687};\\\", \\\"{x:292,y:554,t:1527621094704};\\\", \\\"{x:273,y:551,t:1527621094721};\\\", \\\"{x:256,y:551,t:1527621094737};\\\", \\\"{x:248,y:551,t:1527621094753};\\\", \\\"{x:239,y:551,t:1527621094771};\\\", \\\"{x:231,y:550,t:1527621094787};\\\", \\\"{x:225,y:550,t:1527621094803};\\\", \\\"{x:216,y:549,t:1527621094821};\\\", \\\"{x:206,y:547,t:1527621094838};\\\", \\\"{x:192,y:546,t:1527621094854};\\\", \\\"{x:181,y:546,t:1527621094871};\\\", \\\"{x:169,y:546,t:1527621094887};\\\", \\\"{x:159,y:545,t:1527621094904};\\\", \\\"{x:155,y:544,t:1527621094920};\\\", \\\"{x:154,y:544,t:1527621094938};\\\", \\\"{x:154,y:543,t:1527621095060};\\\", \\\"{x:154,y:542,t:1527621095076};\\\", \\\"{x:154,y:541,t:1527621095091};\\\", \\\"{x:154,y:540,t:1527621095104};\\\", \\\"{x:154,y:538,t:1527621095120};\\\", \\\"{x:154,y:536,t:1527621095138};\\\", \\\"{x:154,y:535,t:1527621095153};\\\", \\\"{x:154,y:533,t:1527621095171};\\\", \\\"{x:153,y:533,t:1527621095188};\\\", \\\"{x:152,y:533,t:1527621095204};\\\", \\\"{x:151,y:533,t:1527621095676};\\\", \\\"{x:151,y:534,t:1527621095691};\\\", \\\"{x:152,y:534,t:1527621095724};\\\", \\\"{x:153,y:534,t:1527621095780};\\\", \\\"{x:154,y:534,t:1527621095788};\\\", \\\"{x:155,y:534,t:1527621095915};\\\", \\\"{x:156,y:534,t:1527621095931};\\\", \\\"{x:158,y:534,t:1527621095955};\\\", \\\"{x:174,y:534,t:1527621095971};\\\", \\\"{x:212,y:536,t:1527621095988};\\\", \\\"{x:226,y:543,t:1527621096004};\\\", \\\"{x:277,y:554,t:1527621096022};\\\", \\\"{x:318,y:561,t:1527621096039};\\\", \\\"{x:403,y:566,t:1527621096055};\\\", \\\"{x:437,y:569,t:1527621096072};\\\", \\\"{x:513,y:582,t:1527621096088};\\\", \\\"{x:573,y:591,t:1527621096105};\\\", \\\"{x:607,y:593,t:1527621096122};\\\", \\\"{x:648,y:598,t:1527621096139};\\\", \\\"{x:667,y:602,t:1527621096155};\\\", \\\"{x:705,y:605,t:1527621096171};\\\", \\\"{x:732,y:606,t:1527621096189};\\\", \\\"{x:755,y:608,t:1527621096205};\\\", \\\"{x:772,y:610,t:1527621096221};\\\", \\\"{x:793,y:609,t:1527621096238};\\\", \\\"{x:815,y:608,t:1527621096255};\\\", \\\"{x:841,y:607,t:1527621096272};\\\", \\\"{x:871,y:607,t:1527621096289};\\\", \\\"{x:895,y:607,t:1527621096304};\\\", \\\"{x:918,y:607,t:1527621096322};\\\", \\\"{x:943,y:608,t:1527621096339};\\\", \\\"{x:966,y:608,t:1527621096355};\\\", \\\"{x:1000,y:608,t:1527621096372};\\\", \\\"{x:1020,y:608,t:1527621096389};\\\", \\\"{x:1041,y:608,t:1527621096404};\\\", \\\"{x:1065,y:608,t:1527621096421};\\\", \\\"{x:1081,y:608,t:1527621096439};\\\", \\\"{x:1100,y:607,t:1527621096454};\\\", \\\"{x:1119,y:606,t:1527621096472};\\\", \\\"{x:1149,y:606,t:1527621096489};\\\", \\\"{x:1186,y:607,t:1527621096505};\\\", \\\"{x:1228,y:611,t:1527621096522};\\\", \\\"{x:1268,y:611,t:1527621096539};\\\", \\\"{x:1298,y:611,t:1527621096555};\\\", \\\"{x:1313,y:613,t:1527621096572};\\\", \\\"{x:1322,y:614,t:1527621096589};\\\", \\\"{x:1325,y:615,t:1527621096605};\\\", \\\"{x:1328,y:616,t:1527621096622};\\\", \\\"{x:1329,y:617,t:1527621096639};\\\", \\\"{x:1329,y:618,t:1527621096655};\\\", \\\"{x:1330,y:618,t:1527621097172};\\\", \\\"{x:1331,y:619,t:1527621097212};\\\", \\\"{x:1332,y:619,t:1527621097222};\\\", \\\"{x:1333,y:621,t:1527621097238};\\\", \\\"{x:1333,y:623,t:1527621097256};\\\", \\\"{x:1334,y:626,t:1527621097291};\\\", \\\"{x:1335,y:630,t:1527621097306};\\\", \\\"{x:1335,y:638,t:1527621097323};\\\", \\\"{x:1335,y:640,t:1527621097339};\\\", \\\"{x:1335,y:649,t:1527621097356};\\\", \\\"{x:1335,y:656,t:1527621097373};\\\", \\\"{x:1338,y:663,t:1527621097389};\\\", \\\"{x:1340,y:670,t:1527621097406};\\\", \\\"{x:1342,y:677,t:1527621097423};\\\", \\\"{x:1345,y:681,t:1527621097439};\\\", \\\"{x:1347,y:686,t:1527621097456};\\\", \\\"{x:1348,y:690,t:1527621097473};\\\", \\\"{x:1348,y:691,t:1527621097490};\\\", \\\"{x:1348,y:692,t:1527621097507};\\\", \\\"{x:1348,y:693,t:1527621098708};\\\", \\\"{x:1349,y:694,t:1527621098724};\\\", \\\"{x:1350,y:695,t:1527621098779};\\\", \\\"{x:1351,y:695,t:1527621099211};\\\", \\\"{x:1351,y:696,t:1527621099235};\\\", \\\"{x:1351,y:697,t:1527621106011};\\\", \\\"{x:1352,y:698,t:1527621106035};\\\", \\\"{x:1361,y:698,t:1527621106047};\\\", \\\"{x:1370,y:700,t:1527621106063};\\\", \\\"{x:1372,y:700,t:1527621106079};\\\", \\\"{x:1375,y:701,t:1527621106096};\\\", \\\"{x:1376,y:701,t:1527621106113};\\\", \\\"{x:1377,y:701,t:1527621106523};\\\", \\\"{x:1377,y:702,t:1527621107020};\\\", \\\"{x:1379,y:702,t:1527621107030};\\\", \\\"{x:1379,y:704,t:1527621107459};\\\", \\\"{x:1379,y:705,t:1527621107467};\\\", \\\"{x:1379,y:707,t:1527621107480};\\\", \\\"{x:1379,y:711,t:1527621107498};\\\", \\\"{x:1379,y:714,t:1527621107514};\\\", \\\"{x:1379,y:716,t:1527621107530};\\\", \\\"{x:1378,y:721,t:1527621107547};\\\", \\\"{x:1376,y:726,t:1527621107564};\\\", \\\"{x:1374,y:729,t:1527621107580};\\\", \\\"{x:1373,y:730,t:1527621107597};\\\", \\\"{x:1372,y:732,t:1527621107614};\\\", \\\"{x:1370,y:735,t:1527621107631};\\\", \\\"{x:1370,y:736,t:1527621107647};\\\", \\\"{x:1367,y:739,t:1527621107664};\\\", \\\"{x:1365,y:743,t:1527621107681};\\\", \\\"{x:1362,y:746,t:1527621107697};\\\", \\\"{x:1361,y:747,t:1527621107714};\\\", \\\"{x:1359,y:751,t:1527621107731};\\\", \\\"{x:1358,y:752,t:1527621107747};\\\", \\\"{x:1357,y:753,t:1527621107764};\\\", \\\"{x:1357,y:754,t:1527621107781};\\\", \\\"{x:1356,y:755,t:1527621107797};\\\", \\\"{x:1354,y:756,t:1527621107851};\\\", \\\"{x:1354,y:757,t:1527621107899};\\\", \\\"{x:1353,y:758,t:1527621107923};\\\", \\\"{x:1352,y:758,t:1527621107947};\\\", \\\"{x:1351,y:759,t:1527621107987};\\\", \\\"{x:1350,y:759,t:1527621108043};\\\", \\\"{x:1351,y:759,t:1527621108435};\\\", \\\"{x:1352,y:759,t:1527621108448};\\\", \\\"{x:1355,y:759,t:1527621108466};\\\", \\\"{x:1359,y:759,t:1527621108482};\\\", \\\"{x:1363,y:758,t:1527621108499};\\\", \\\"{x:1365,y:758,t:1527621108515};\\\", \\\"{x:1369,y:758,t:1527621108532};\\\", \\\"{x:1377,y:758,t:1527621108548};\\\", \\\"{x:1384,y:758,t:1527621108565};\\\", \\\"{x:1394,y:758,t:1527621108582};\\\", \\\"{x:1406,y:762,t:1527621108598};\\\", \\\"{x:1411,y:764,t:1527621108615};\\\", \\\"{x:1414,y:766,t:1527621108631};\\\", \\\"{x:1417,y:769,t:1527621108649};\\\", \\\"{x:1419,y:773,t:1527621108665};\\\", \\\"{x:1422,y:776,t:1527621108681};\\\", \\\"{x:1423,y:777,t:1527621108698};\\\", \\\"{x:1425,y:778,t:1527621108715};\\\", \\\"{x:1425,y:779,t:1527621108732};\\\", \\\"{x:1426,y:780,t:1527621108748};\\\", \\\"{x:1426,y:781,t:1527621108803};\\\", \\\"{x:1426,y:782,t:1527621108843};\\\", \\\"{x:1427,y:783,t:1527621108851};\\\", \\\"{x:1427,y:784,t:1527621108963};\\\", \\\"{x:1427,y:785,t:1527621108995};\\\", \\\"{x:1427,y:786,t:1527621109003};\\\", \\\"{x:1427,y:788,t:1527621109035};\\\", \\\"{x:1427,y:789,t:1527621109051};\\\", \\\"{x:1427,y:791,t:1527621109065};\\\", \\\"{x:1426,y:796,t:1527621109082};\\\", \\\"{x:1425,y:799,t:1527621109099};\\\", \\\"{x:1421,y:808,t:1527621109115};\\\", \\\"{x:1420,y:810,t:1527621109133};\\\", \\\"{x:1419,y:813,t:1527621109148};\\\", \\\"{x:1419,y:814,t:1527621109187};\\\", \\\"{x:1418,y:814,t:1527621109260};\\\", \\\"{x:1417,y:816,t:1527621109275};\\\", \\\"{x:1416,y:817,t:1527621109283};\\\", \\\"{x:1415,y:819,t:1527621109299};\\\", \\\"{x:1413,y:821,t:1527621109315};\\\", \\\"{x:1413,y:822,t:1527621109332};\\\", \\\"{x:1411,y:825,t:1527621109349};\\\", \\\"{x:1411,y:826,t:1527621109365};\\\", \\\"{x:1411,y:830,t:1527621109382};\\\", \\\"{x:1411,y:833,t:1527621109399};\\\", \\\"{x:1408,y:838,t:1527621109415};\\\", \\\"{x:1406,y:841,t:1527621109432};\\\", \\\"{x:1403,y:844,t:1527621109449};\\\", \\\"{x:1402,y:847,t:1527621109465};\\\", \\\"{x:1402,y:849,t:1527621109482};\\\", \\\"{x:1400,y:851,t:1527621109499};\\\", \\\"{x:1400,y:852,t:1527621109516};\\\", \\\"{x:1398,y:854,t:1527621109532};\\\", \\\"{x:1398,y:856,t:1527621109550};\\\", \\\"{x:1396,y:860,t:1527621109566};\\\", \\\"{x:1392,y:863,t:1527621109583};\\\", \\\"{x:1390,y:866,t:1527621109599};\\\", \\\"{x:1385,y:871,t:1527621109615};\\\", \\\"{x:1385,y:873,t:1527621109632};\\\", \\\"{x:1385,y:875,t:1527621109649};\\\", \\\"{x:1385,y:878,t:1527621109665};\\\", \\\"{x:1384,y:879,t:1527621109682};\\\", \\\"{x:1384,y:881,t:1527621109763};\\\", \\\"{x:1384,y:882,t:1527621109771};\\\", \\\"{x:1384,y:883,t:1527621109795};\\\", \\\"{x:1384,y:884,t:1527621109803};\\\", \\\"{x:1384,y:885,t:1527621109817};\\\", \\\"{x:1385,y:886,t:1527621109835};\\\", \\\"{x:1386,y:887,t:1527621109883};\\\", \\\"{x:1387,y:887,t:1527621109900};\\\", \\\"{x:1388,y:888,t:1527621109917};\\\", \\\"{x:1389,y:888,t:1527621109932};\\\", \\\"{x:1389,y:890,t:1527621109980};\\\", \\\"{x:1390,y:891,t:1527621110068};\\\", \\\"{x:1389,y:891,t:1527621110500};\\\", \\\"{x:1388,y:891,t:1527621110531};\\\", \\\"{x:1387,y:891,t:1527621110539};\\\", \\\"{x:1385,y:891,t:1527621110635};\\\", \\\"{x:1384,y:891,t:1527621110739};\\\", \\\"{x:1384,y:890,t:1527621110787};\\\", \\\"{x:1387,y:886,t:1527621110801};\\\", \\\"{x:1392,y:881,t:1527621110816};\\\", \\\"{x:1398,y:874,t:1527621110833};\\\", \\\"{x:1414,y:863,t:1527621110851};\\\", \\\"{x:1421,y:861,t:1527621110866};\\\", \\\"{x:1434,y:852,t:1527621110884};\\\", \\\"{x:1442,y:847,t:1527621110900};\\\", \\\"{x:1448,y:840,t:1527621110917};\\\", \\\"{x:1453,y:838,t:1527621110933};\\\", \\\"{x:1461,y:836,t:1527621110950};\\\", \\\"{x:1468,y:834,t:1527621110966};\\\", \\\"{x:1471,y:833,t:1527621110984};\\\", \\\"{x:1476,y:832,t:1527621111000};\\\", \\\"{x:1480,y:830,t:1527621111017};\\\", \\\"{x:1483,y:830,t:1527621111034};\\\", \\\"{x:1483,y:829,t:1527621111050};\\\", \\\"{x:1485,y:829,t:1527621111068};\\\", \\\"{x:1486,y:829,t:1527621111211};\\\", \\\"{x:1485,y:829,t:1527621112107};\\\", \\\"{x:1483,y:830,t:1527621112507};\\\", \\\"{x:1482,y:832,t:1527621112603};\\\", \\\"{x:1481,y:833,t:1527621112651};\\\", \\\"{x:1480,y:833,t:1527621112669};\\\", \\\"{x:1480,y:834,t:1527621112685};\\\", \\\"{x:1479,y:835,t:1527621112701};\\\", \\\"{x:1479,y:836,t:1527621113147};\\\", \\\"{x:1480,y:836,t:1527621113171};\\\", \\\"{x:1481,y:836,t:1527621113185};\\\", \\\"{x:1482,y:836,t:1527621113202};\\\", \\\"{x:1485,y:836,t:1527621113219};\\\", \\\"{x:1486,y:836,t:1527621113307};\\\", \\\"{x:1485,y:836,t:1527621113531};\\\", \\\"{x:1476,y:839,t:1527621113539};\\\", \\\"{x:1462,y:837,t:1527621113552};\\\", \\\"{x:1436,y:826,t:1527621113568};\\\", \\\"{x:1308,y:793,t:1527621113586};\\\", \\\"{x:1257,y:780,t:1527621113603};\\\", \\\"{x:1188,y:755,t:1527621113618};\\\", \\\"{x:1049,y:714,t:1527621113636};\\\", \\\"{x:1004,y:697,t:1527621113653};\\\", \\\"{x:993,y:694,t:1527621113670};\\\", \\\"{x:991,y:692,t:1527621113685};\\\", \\\"{x:990,y:691,t:1527621113703};\\\", \\\"{x:989,y:691,t:1527621113719};\\\", \\\"{x:988,y:691,t:1527621113907};\\\", \\\"{x:985,y:689,t:1527621113939};\\\", \\\"{x:971,y:688,t:1527621113952};\\\", \\\"{x:914,y:668,t:1527621113970};\\\", \\\"{x:828,y:644,t:1527621113985};\\\", \\\"{x:728,y:626,t:1527621114003};\\\", \\\"{x:574,y:606,t:1527621114019};\\\", \\\"{x:488,y:593,t:1527621114036};\\\", \\\"{x:426,y:585,t:1527621114053};\\\", \\\"{x:399,y:580,t:1527621114069};\\\", \\\"{x:384,y:576,t:1527621114086};\\\", \\\"{x:378,y:575,t:1527621114103};\\\", \\\"{x:377,y:574,t:1527621114179};\\\", \\\"{x:379,y:574,t:1527621114219};\\\", \\\"{x:385,y:570,t:1527621114227};\\\", \\\"{x:396,y:568,t:1527621114237};\\\", \\\"{x:421,y:568,t:1527621114253};\\\", \\\"{x:438,y:569,t:1527621114269};\\\", \\\"{x:479,y:580,t:1527621114287};\\\", \\\"{x:552,y:595,t:1527621114304};\\\", \\\"{x:562,y:602,t:1527621114321};\\\", \\\"{x:579,y:609,t:1527621114337};\\\", \\\"{x:590,y:612,t:1527621114354};\\\", \\\"{x:591,y:612,t:1527621114369};\\\", \\\"{x:590,y:612,t:1527621114419};\\\", \\\"{x:589,y:612,t:1527621114426};\\\", \\\"{x:584,y:611,t:1527621114436};\\\", \\\"{x:581,y:608,t:1527621114453};\\\", \\\"{x:569,y:604,t:1527621114470};\\\", \\\"{x:558,y:600,t:1527621114487};\\\", \\\"{x:556,y:597,t:1527621114503};\\\", \\\"{x:555,y:595,t:1527621114521};\\\", \\\"{x:554,y:593,t:1527621114537};\\\", \\\"{x:554,y:590,t:1527621114553};\\\", \\\"{x:557,y:586,t:1527621114571};\\\", \\\"{x:559,y:585,t:1527621114586};\\\", \\\"{x:564,y:581,t:1527621114603};\\\", \\\"{x:569,y:578,t:1527621114620};\\\", \\\"{x:576,y:577,t:1527621114636};\\\", \\\"{x:580,y:575,t:1527621114653};\\\", \\\"{x:583,y:574,t:1527621114670};\\\", \\\"{x:586,y:574,t:1527621114686};\\\", \\\"{x:587,y:574,t:1527621114703};\\\", \\\"{x:588,y:574,t:1527621114763};\\\", \\\"{x:589,y:574,t:1527621114787};\\\", \\\"{x:590,y:574,t:1527621114811};\\\", \\\"{x:591,y:574,t:1527621114820};\\\", \\\"{x:592,y:574,t:1527621114851};\\\", \\\"{x:595,y:574,t:1527621114931};\\\", \\\"{x:596,y:574,t:1527621114947};\\\", \\\"{x:597,y:574,t:1527621114955};\\\", \\\"{x:598,y:574,t:1527621114987};\\\", \\\"{x:599,y:574,t:1527621115003};\\\", \\\"{x:601,y:574,t:1527621115284};\\\", \\\"{x:620,y:576,t:1527621115291};\\\", \\\"{x:653,y:583,t:1527621115304};\\\", \\\"{x:739,y:594,t:1527621115321};\\\", \\\"{x:851,y:617,t:1527621115338};\\\", \\\"{x:982,y:644,t:1527621115356};\\\", \\\"{x:1167,y:671,t:1527621115370};\\\", \\\"{x:1274,y:696,t:1527621115388};\\\", \\\"{x:1319,y:706,t:1527621115404};\\\", \\\"{x:1355,y:717,t:1527621115420};\\\", \\\"{x:1377,y:726,t:1527621115438};\\\", \\\"{x:1396,y:733,t:1527621115454};\\\", \\\"{x:1402,y:736,t:1527621115471};\\\", \\\"{x:1405,y:737,t:1527621115487};\\\", \\\"{x:1401,y:740,t:1527621115587};\\\", \\\"{x:1373,y:740,t:1527621115603};\\\", \\\"{x:1309,y:740,t:1527621115620};\\\", \\\"{x:1225,y:735,t:1527621115638};\\\", \\\"{x:1127,y:721,t:1527621115653};\\\", \\\"{x:1040,y:702,t:1527621115670};\\\", \\\"{x:953,y:675,t:1527621115688};\\\", \\\"{x:874,y:657,t:1527621115704};\\\", \\\"{x:815,y:646,t:1527621115721};\\\", \\\"{x:757,y:632,t:1527621115738};\\\", \\\"{x:706,y:623,t:1527621115754};\\\", \\\"{x:665,y:618,t:1527621115770};\\\", \\\"{x:630,y:616,t:1527621115787};\\\", \\\"{x:611,y:611,t:1527621115805};\\\", \\\"{x:609,y:609,t:1527621115821};\\\", \\\"{x:607,y:609,t:1527621115837};\\\", \\\"{x:606,y:608,t:1527621115979};\\\", \\\"{x:607,y:605,t:1527621115995};\\\", \\\"{x:609,y:603,t:1527621116004};\\\", \\\"{x:611,y:601,t:1527621116021};\\\", \\\"{x:613,y:598,t:1527621116038};\\\", \\\"{x:614,y:596,t:1527621116054};\\\", \\\"{x:614,y:595,t:1527621116147};\\\", \\\"{x:614,y:594,t:1527621116162};\\\", \\\"{x:614,y:592,t:1527621116188};\\\", \\\"{x:614,y:591,t:1527621116259};\\\", \\\"{x:614,y:589,t:1527621116272};\\\", \\\"{x:614,y:587,t:1527621116288};\\\", \\\"{x:614,y:586,t:1527621116305};\\\", \\\"{x:614,y:585,t:1527621116321};\\\", \\\"{x:614,y:584,t:1527621116635};\\\", \\\"{x:625,y:584,t:1527621116643};\\\", \\\"{x:639,y:588,t:1527621116655};\\\", \\\"{x:726,y:603,t:1527621116672};\\\", \\\"{x:792,y:616,t:1527621116688};\\\", \\\"{x:876,y:631,t:1527621116705};\\\", \\\"{x:960,y:660,t:1527621116722};\\\", \\\"{x:1073,y:687,t:1527621116738};\\\", \\\"{x:1124,y:698,t:1527621116754};\\\", \\\"{x:1180,y:714,t:1527621116772};\\\", \\\"{x:1228,y:730,t:1527621116789};\\\", \\\"{x:1276,y:744,t:1527621116806};\\\", \\\"{x:1312,y:754,t:1527621116822};\\\", \\\"{x:1344,y:765,t:1527621116838};\\\", \\\"{x:1371,y:773,t:1527621116856};\\\", \\\"{x:1385,y:776,t:1527621116872};\\\", \\\"{x:1402,y:785,t:1527621116889};\\\", \\\"{x:1421,y:792,t:1527621116906};\\\", \\\"{x:1438,y:798,t:1527621116921};\\\", \\\"{x:1468,y:809,t:1527621116939};\\\", \\\"{x:1489,y:813,t:1527621116955};\\\", \\\"{x:1497,y:816,t:1527621116972};\\\", \\\"{x:1514,y:823,t:1527621116989};\\\", \\\"{x:1526,y:828,t:1527621117006};\\\", \\\"{x:1540,y:833,t:1527621117022};\\\", \\\"{x:1552,y:838,t:1527621117038};\\\", \\\"{x:1557,y:840,t:1527621117056};\\\", \\\"{x:1557,y:841,t:1527621117071};\\\", \\\"{x:1557,y:842,t:1527621117315};\\\", \\\"{x:1558,y:842,t:1527621117322};\\\", \\\"{x:1561,y:842,t:1527621117355};\\\", \\\"{x:1561,y:841,t:1527621117555};\\\", \\\"{x:1558,y:838,t:1527621117572};\\\", \\\"{x:1554,y:833,t:1527621117589};\\\", \\\"{x:1545,y:827,t:1527621117605};\\\", \\\"{x:1536,y:822,t:1527621117623};\\\", \\\"{x:1527,y:815,t:1527621117638};\\\", \\\"{x:1519,y:809,t:1527621117655};\\\", \\\"{x:1513,y:805,t:1527621117673};\\\", \\\"{x:1509,y:804,t:1527621117689};\\\", \\\"{x:1505,y:802,t:1527621117705};\\\", \\\"{x:1504,y:801,t:1527621117722};\\\", \\\"{x:1502,y:800,t:1527621117755};\\\", \\\"{x:1502,y:798,t:1527621118027};\\\", \\\"{x:1502,y:794,t:1527621118039};\\\", \\\"{x:1504,y:789,t:1527621118055};\\\", \\\"{x:1505,y:787,t:1527621118072};\\\", \\\"{x:1507,y:784,t:1527621118090};\\\", \\\"{x:1509,y:780,t:1527621118105};\\\", \\\"{x:1510,y:778,t:1527621118203};\\\", \\\"{x:1512,y:775,t:1527621118211};\\\", \\\"{x:1512,y:774,t:1527621118234};\\\", \\\"{x:1513,y:774,t:1527621118242};\\\", \\\"{x:1514,y:773,t:1527621118258};\\\", \\\"{x:1514,y:772,t:1527621118274};\\\", \\\"{x:1514,y:771,t:1527621118331};\\\", \\\"{x:1513,y:771,t:1527621119435};\\\", \\\"{x:1502,y:772,t:1527621119443};\\\", \\\"{x:1497,y:773,t:1527621119457};\\\", \\\"{x:1482,y:773,t:1527621119474};\\\", \\\"{x:1435,y:784,t:1527621119490};\\\", \\\"{x:1297,y:793,t:1527621119507};\\\", \\\"{x:1190,y:803,t:1527621119524};\\\", \\\"{x:1078,y:811,t:1527621119540};\\\", \\\"{x:943,y:826,t:1527621119557};\\\", \\\"{x:819,y:838,t:1527621119573};\\\", \\\"{x:688,y:842,t:1527621119590};\\\", \\\"{x:567,y:857,t:1527621119607};\\\", \\\"{x:458,y:854,t:1527621119624};\\\", \\\"{x:368,y:850,t:1527621119639};\\\", \\\"{x:312,y:850,t:1527621119657};\\\", \\\"{x:284,y:850,t:1527621119673};\\\", \\\"{x:267,y:849,t:1527621119689};\\\", \\\"{x:251,y:847,t:1527621119707};\\\", \\\"{x:245,y:847,t:1527621119723};\\\", \\\"{x:233,y:847,t:1527621119740};\\\", \\\"{x:230,y:847,t:1527621119757};\\\", \\\"{x:230,y:846,t:1527621119971};\\\", \\\"{x:232,y:844,t:1527621120003};\\\", \\\"{x:236,y:842,t:1527621120011};\\\", \\\"{x:240,y:840,t:1527621120024};\\\", \\\"{x:255,y:828,t:1527621120040};\\\", \\\"{x:282,y:811,t:1527621120057};\\\", \\\"{x:310,y:791,t:1527621120073};\\\", \\\"{x:397,y:744,t:1527621120091};\\\", \\\"{x:457,y:723,t:1527621120106};\\\", \\\"{x:478,y:715,t:1527621120124};\\\", \\\"{x:492,y:709,t:1527621120140};\\\", \\\"{x:500,y:707,t:1527621120155};\\\", \\\"{x:501,y:707,t:1527621120171};\\\", \\\"{x:502,y:707,t:1527621120227};\\\", \\\"{x:502,y:711,t:1527621120238};\\\", \\\"{x:510,y:720,t:1527621120255};\\\", \\\"{x:516,y:726,t:1527621120272};\\\", \\\"{x:523,y:727,t:1527621120292};\\\", \\\"{x:526,y:727,t:1527621120308};\\\", \\\"{x:526,y:728,t:1527621120387};\\\", \\\"{x:527,y:728,t:1527621120794};\\\", \\\"{x:531,y:728,t:1527621120809};\\\", \\\"{x:552,y:725,t:1527621120824};\\\", \\\"{x:575,y:715,t:1527621120841};\\\", \\\"{x:612,y:708,t:1527621120858};\\\", \\\"{x:637,y:702,t:1527621120875};\\\", \\\"{x:654,y:698,t:1527621120892};\\\", \\\"{x:672,y:698,t:1527621120909};\\\", \\\"{x:682,y:695,t:1527621120925};\\\", \\\"{x:693,y:693,t:1527621120942};\\\", \\\"{x:701,y:692,t:1527621120958};\\\", \\\"{x:709,y:690,t:1527621120975};\\\", \\\"{x:712,y:689,t:1527621120992};\\\", \\\"{x:718,y:687,t:1527621121008};\\\", \\\"{x:720,y:686,t:1527621121026};\\\", \\\"{x:723,y:686,t:1527621121041};\\\", \\\"{x:723,y:685,t:1527621121058};\\\", \\\"{x:723,y:684,t:1527621121210};\\\", \\\"{x:724,y:683,t:1527621121226};\\\", \\\"{x:727,y:680,t:1527621121241};\\\", \\\"{x:736,y:673,t:1527621121259};\\\", \\\"{x:741,y:671,t:1527621121276};\\\", \\\"{x:742,y:670,t:1527621121292};\\\", \\\"{x:743,y:669,t:1527621121346};\\\", \\\"{x:744,y:668,t:1527621121450};\\\", \\\"{x:746,y:667,t:1527621121467};\\\", \\\"{x:747,y:666,t:1527621121476};\\\", \\\"{x:748,y:666,t:1527621121491};\\\", \\\"{x:751,y:664,t:1527621121515};\\\" ] }, { \\\"rt\\\": 15555, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 536369, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:752,y:666,t:1527621122305};\\\", \\\"{x:752,y:667,t:1527621122346};\\\", \\\"{x:751,y:667,t:1527621122360};\\\", \\\"{x:750,y:667,t:1527621122379};\\\", \\\"{x:750,y:666,t:1527621122393};\\\", \\\"{x:750,y:665,t:1527621122409};\\\", \\\"{x:750,y:662,t:1527621122427};\\\", \\\"{x:749,y:661,t:1527621122627};\\\", \\\"{x:748,y:661,t:1527621122667};\\\", \\\"{x:747,y:661,t:1527621122677};\\\", \\\"{x:744,y:662,t:1527621122694};\\\", \\\"{x:738,y:667,t:1527621122709};\\\", \\\"{x:732,y:669,t:1527621122727};\\\", \\\"{x:723,y:669,t:1527621122744};\\\", \\\"{x:715,y:666,t:1527621122760};\\\", \\\"{x:713,y:665,t:1527621122776};\\\", \\\"{x:716,y:666,t:1527621124043};\\\", \\\"{x:729,y:668,t:1527621124051};\\\", \\\"{x:744,y:672,t:1527621124061};\\\", \\\"{x:845,y:689,t:1527621124078};\\\", \\\"{x:989,y:713,t:1527621124095};\\\", \\\"{x:1158,y:733,t:1527621124111};\\\", \\\"{x:1325,y:769,t:1527621124127};\\\", \\\"{x:1503,y:800,t:1527621124145};\\\", \\\"{x:1662,y:833,t:1527621124161};\\\", \\\"{x:1791,y:867,t:1527621124177};\\\", \\\"{x:1877,y:891,t:1527621124194};\\\", \\\"{x:1884,y:894,t:1527621124211};\\\", \\\"{x:1882,y:897,t:1527621124291};\\\", \\\"{x:1876,y:900,t:1527621124299};\\\", \\\"{x:1874,y:900,t:1527621124311};\\\", \\\"{x:1859,y:906,t:1527621124328};\\\", \\\"{x:1829,y:914,t:1527621124345};\\\", \\\"{x:1806,y:918,t:1527621124362};\\\", \\\"{x:1780,y:922,t:1527621124377};\\\", \\\"{x:1697,y:924,t:1527621124395};\\\", \\\"{x:1628,y:924,t:1527621124412};\\\", \\\"{x:1536,y:924,t:1527621124428};\\\", \\\"{x:1458,y:930,t:1527621124445};\\\", \\\"{x:1403,y:929,t:1527621124462};\\\", \\\"{x:1398,y:929,t:1527621124478};\\\", \\\"{x:1393,y:929,t:1527621124495};\\\", \\\"{x:1390,y:927,t:1527621124512};\\\", \\\"{x:1388,y:927,t:1527621124731};\\\", \\\"{x:1387,y:926,t:1527621124745};\\\", \\\"{x:1385,y:925,t:1527621124762};\\\", \\\"{x:1383,y:925,t:1527621124779};\\\", \\\"{x:1383,y:926,t:1527621124803};\\\", \\\"{x:1382,y:926,t:1527621124883};\\\", \\\"{x:1380,y:926,t:1527621124947};\\\", \\\"{x:1380,y:929,t:1527621126403};\\\", \\\"{x:1377,y:931,t:1527621126413};\\\", \\\"{x:1377,y:932,t:1527621126435};\\\", \\\"{x:1377,y:933,t:1527621126446};\\\", \\\"{x:1376,y:934,t:1527621126463};\\\", \\\"{x:1374,y:934,t:1527621126731};\\\", \\\"{x:1372,y:934,t:1527621126755};\\\", \\\"{x:1371,y:934,t:1527621126795};\\\", \\\"{x:1368,y:934,t:1527621126891};\\\", \\\"{x:1365,y:935,t:1527621126906};\\\", \\\"{x:1363,y:936,t:1527621126915};\\\", \\\"{x:1360,y:937,t:1527621126930};\\\", \\\"{x:1356,y:940,t:1527621126947};\\\", \\\"{x:1355,y:940,t:1527621126970};\\\", \\\"{x:1354,y:940,t:1527621127027};\\\", \\\"{x:1352,y:940,t:1527621127059};\\\", \\\"{x:1351,y:941,t:1527621127491};\\\", \\\"{x:1350,y:942,t:1527621127595};\\\", \\\"{x:1350,y:943,t:1527621127635};\\\", \\\"{x:1346,y:946,t:1527621127647};\\\", \\\"{x:1343,y:949,t:1527621127664};\\\", \\\"{x:1342,y:950,t:1527621127681};\\\", \\\"{x:1341,y:951,t:1527621127739};\\\", \\\"{x:1340,y:951,t:1527621127867};\\\", \\\"{x:1340,y:952,t:1527621127915};\\\", \\\"{x:1340,y:953,t:1527621127932};\\\", \\\"{x:1340,y:954,t:1527621128051};\\\", \\\"{x:1342,y:955,t:1527621128074};\\\", \\\"{x:1343,y:955,t:1527621128091};\\\", \\\"{x:1344,y:955,t:1527621128124};\\\", \\\"{x:1345,y:955,t:1527621128163};\\\", \\\"{x:1347,y:955,t:1527621128315};\\\", \\\"{x:1348,y:955,t:1527621128347};\\\", \\\"{x:1349,y:955,t:1527621128355};\\\", \\\"{x:1350,y:954,t:1527621128515};\\\", \\\"{x:1350,y:950,t:1527621128531};\\\", \\\"{x:1349,y:948,t:1527621128548};\\\", \\\"{x:1347,y:944,t:1527621128565};\\\", \\\"{x:1346,y:942,t:1527621128581};\\\", \\\"{x:1345,y:939,t:1527621128598};\\\", \\\"{x:1344,y:937,t:1527621128615};\\\", \\\"{x:1342,y:933,t:1527621128631};\\\", \\\"{x:1340,y:928,t:1527621128648};\\\", \\\"{x:1339,y:924,t:1527621128665};\\\", \\\"{x:1336,y:916,t:1527621128681};\\\", \\\"{x:1334,y:904,t:1527621128698};\\\", \\\"{x:1333,y:891,t:1527621128715};\\\", \\\"{x:1331,y:884,t:1527621128732};\\\", \\\"{x:1329,y:879,t:1527621128748};\\\", \\\"{x:1328,y:877,t:1527621128765};\\\", \\\"{x:1328,y:874,t:1527621128782};\\\", \\\"{x:1328,y:871,t:1527621128798};\\\", \\\"{x:1328,y:869,t:1527621128816};\\\", \\\"{x:1330,y:865,t:1527621128832};\\\", \\\"{x:1331,y:862,t:1527621128848};\\\", \\\"{x:1331,y:859,t:1527621128865};\\\", \\\"{x:1333,y:856,t:1527621128882};\\\", \\\"{x:1333,y:854,t:1527621128898};\\\", \\\"{x:1333,y:852,t:1527621128915};\\\", \\\"{x:1333,y:851,t:1527621128947};\\\", \\\"{x:1334,y:849,t:1527621128955};\\\", \\\"{x:1334,y:848,t:1527621128970};\\\", \\\"{x:1334,y:847,t:1527621128986};\\\", \\\"{x:1335,y:845,t:1527621128998};\\\", \\\"{x:1335,y:844,t:1527621129019};\\\", \\\"{x:1335,y:843,t:1527621129059};\\\", \\\"{x:1335,y:842,t:1527621129083};\\\", \\\"{x:1336,y:842,t:1527621129098};\\\", \\\"{x:1336,y:841,t:1527621129179};\\\", \\\"{x:1337,y:839,t:1527621129203};\\\", \\\"{x:1337,y:838,t:1527621129214};\\\", \\\"{x:1337,y:837,t:1527621129234};\\\", \\\"{x:1337,y:835,t:1527621129249};\\\", \\\"{x:1337,y:834,t:1527621129266};\\\", \\\"{x:1338,y:831,t:1527621129282};\\\", \\\"{x:1338,y:830,t:1527621129299};\\\", \\\"{x:1338,y:829,t:1527621129315};\\\", \\\"{x:1338,y:828,t:1527621129355};\\\", \\\"{x:1338,y:827,t:1527621129379};\\\", \\\"{x:1338,y:826,t:1527621129419};\\\", \\\"{x:1340,y:827,t:1527621130107};\\\", \\\"{x:1343,y:827,t:1527621130123};\\\", \\\"{x:1343,y:828,t:1527621130139};\\\", \\\"{x:1344,y:829,t:1527621130150};\\\", \\\"{x:1345,y:830,t:1527621130170};\\\", \\\"{x:1346,y:830,t:1527621130186};\\\", \\\"{x:1348,y:830,t:1527621130387};\\\", \\\"{x:1348,y:829,t:1527621130399};\\\", \\\"{x:1349,y:825,t:1527621130417};\\\", \\\"{x:1349,y:823,t:1527621130433};\\\", \\\"{x:1349,y:822,t:1527621130450};\\\", \\\"{x:1349,y:818,t:1527621130466};\\\", \\\"{x:1349,y:815,t:1527621130483};\\\", \\\"{x:1349,y:813,t:1527621130500};\\\", \\\"{x:1349,y:812,t:1527621130516};\\\", \\\"{x:1349,y:810,t:1527621130587};\\\", \\\"{x:1349,y:809,t:1527621130600};\\\", \\\"{x:1349,y:808,t:1527621130627};\\\", \\\"{x:1349,y:806,t:1527621130642};\\\", \\\"{x:1349,y:805,t:1527621130658};\\\", \\\"{x:1349,y:804,t:1527621130667};\\\", \\\"{x:1349,y:802,t:1527621130683};\\\", \\\"{x:1349,y:799,t:1527621130700};\\\", \\\"{x:1348,y:797,t:1527621130716};\\\", \\\"{x:1347,y:793,t:1527621130733};\\\", \\\"{x:1346,y:792,t:1527621130751};\\\", \\\"{x:1346,y:785,t:1527621130766};\\\", \\\"{x:1346,y:778,t:1527621130783};\\\", \\\"{x:1346,y:773,t:1527621130800};\\\", \\\"{x:1346,y:770,t:1527621130816};\\\", \\\"{x:1346,y:767,t:1527621130834};\\\", \\\"{x:1345,y:762,t:1527621130851};\\\", \\\"{x:1344,y:759,t:1527621130866};\\\", \\\"{x:1342,y:755,t:1527621130884};\\\", \\\"{x:1342,y:753,t:1527621130900};\\\", \\\"{x:1342,y:751,t:1527621130923};\\\", \\\"{x:1342,y:750,t:1527621130938};\\\", \\\"{x:1342,y:744,t:1527621131387};\\\", \\\"{x:1342,y:737,t:1527621131400};\\\", \\\"{x:1344,y:728,t:1527621131417};\\\", \\\"{x:1345,y:722,t:1527621131434};\\\", \\\"{x:1345,y:719,t:1527621131450};\\\", \\\"{x:1345,y:717,t:1527621131467};\\\", \\\"{x:1345,y:716,t:1527621131555};\\\", \\\"{x:1345,y:713,t:1527621131568};\\\", \\\"{x:1345,y:705,t:1527621131584};\\\", \\\"{x:1345,y:697,t:1527621131601};\\\", \\\"{x:1345,y:692,t:1527621131618};\\\", \\\"{x:1344,y:686,t:1527621131635};\\\", \\\"{x:1343,y:681,t:1527621131650};\\\", \\\"{x:1343,y:680,t:1527621131667};\\\", \\\"{x:1343,y:678,t:1527621131684};\\\", \\\"{x:1343,y:677,t:1527621131701};\\\", \\\"{x:1343,y:676,t:1527621131717};\\\", \\\"{x:1343,y:675,t:1527621131734};\\\", \\\"{x:1340,y:671,t:1527621131843};\\\", \\\"{x:1333,y:669,t:1527621131851};\\\", \\\"{x:1313,y:661,t:1527621131868};\\\", \\\"{x:1288,y:655,t:1527621131884};\\\", \\\"{x:1265,y:649,t:1527621131901};\\\", \\\"{x:1200,y:637,t:1527621131918};\\\", \\\"{x:1150,y:631,t:1527621131934};\\\", \\\"{x:1095,y:626,t:1527621131951};\\\", \\\"{x:1050,y:625,t:1527621131967};\\\", \\\"{x:1017,y:625,t:1527621131985};\\\", \\\"{x:989,y:627,t:1527621132001};\\\", \\\"{x:966,y:631,t:1527621132017};\\\", \\\"{x:964,y:632,t:1527621132043};\\\", \\\"{x:963,y:633,t:1527621132083};\\\", \\\"{x:964,y:635,t:1527621132090};\\\", \\\"{x:961,y:635,t:1527621132354};\\\", \\\"{x:957,y:636,t:1527621132368};\\\", \\\"{x:949,y:637,t:1527621132384};\\\", \\\"{x:940,y:637,t:1527621132401};\\\", \\\"{x:921,y:635,t:1527621132418};\\\", \\\"{x:896,y:628,t:1527621132434};\\\", \\\"{x:820,y:618,t:1527621132451};\\\", \\\"{x:765,y:603,t:1527621132468};\\\", \\\"{x:717,y:596,t:1527621132486};\\\", \\\"{x:664,y:581,t:1527621132502};\\\", \\\"{x:641,y:571,t:1527621132519};\\\", \\\"{x:619,y:565,t:1527621132535};\\\", \\\"{x:600,y:562,t:1527621132551};\\\", \\\"{x:585,y:558,t:1527621132568};\\\", \\\"{x:571,y:555,t:1527621132586};\\\", \\\"{x:559,y:555,t:1527621132601};\\\", \\\"{x:555,y:555,t:1527621132619};\\\", \\\"{x:552,y:555,t:1527621132635};\\\", \\\"{x:559,y:555,t:1527621132843};\\\", \\\"{x:574,y:556,t:1527621132852};\\\", \\\"{x:615,y:563,t:1527621132869};\\\", \\\"{x:648,y:569,t:1527621132886};\\\", \\\"{x:673,y:572,t:1527621132902};\\\", \\\"{x:677,y:572,t:1527621132918};\\\", \\\"{x:676,y:571,t:1527621132978};\\\", \\\"{x:675,y:571,t:1527621132987};\\\", \\\"{x:674,y:571,t:1527621133011};\\\", \\\"{x:672,y:569,t:1527621133018};\\\", \\\"{x:669,y:566,t:1527621133036};\\\", \\\"{x:665,y:563,t:1527621133052};\\\", \\\"{x:663,y:557,t:1527621133069};\\\", \\\"{x:659,y:550,t:1527621133086};\\\", \\\"{x:654,y:544,t:1527621133102};\\\", \\\"{x:643,y:535,t:1527621133118};\\\", \\\"{x:631,y:529,t:1527621133134};\\\", \\\"{x:611,y:524,t:1527621133152};\\\", \\\"{x:597,y:519,t:1527621133170};\\\", \\\"{x:577,y:519,t:1527621133185};\\\", \\\"{x:565,y:518,t:1527621133202};\\\", \\\"{x:561,y:518,t:1527621133219};\\\", \\\"{x:560,y:519,t:1527621133236};\\\", \\\"{x:559,y:519,t:1527621133515};\\\", \\\"{x:556,y:522,t:1527621133522};\\\", \\\"{x:547,y:529,t:1527621133538};\\\", \\\"{x:528,y:541,t:1527621133554};\\\", \\\"{x:514,y:549,t:1527621133568};\\\", \\\"{x:483,y:563,t:1527621133586};\\\", \\\"{x:473,y:569,t:1527621133601};\\\", \\\"{x:406,y:585,t:1527621133620};\\\", \\\"{x:345,y:593,t:1527621133636};\\\", \\\"{x:320,y:597,t:1527621133652};\\\", \\\"{x:314,y:597,t:1527621133669};\\\", \\\"{x:313,y:597,t:1527621133931};\\\", \\\"{x:313,y:596,t:1527621133938};\\\", \\\"{x:313,y:594,t:1527621134002};\\\", \\\"{x:312,y:588,t:1527621134019};\\\", \\\"{x:305,y:581,t:1527621134036};\\\", \\\"{x:302,y:579,t:1527621134053};\\\", \\\"{x:301,y:578,t:1527621134069};\\\", \\\"{x:298,y:576,t:1527621134086};\\\", \\\"{x:291,y:573,t:1527621134103};\\\", \\\"{x:275,y:569,t:1527621134120};\\\", \\\"{x:253,y:561,t:1527621134136};\\\", \\\"{x:241,y:556,t:1527621134154};\\\", \\\"{x:222,y:549,t:1527621134170};\\\", \\\"{x:209,y:545,t:1527621134187};\\\", \\\"{x:189,y:540,t:1527621134202};\\\", \\\"{x:181,y:540,t:1527621134220};\\\", \\\"{x:173,y:538,t:1527621134236};\\\", \\\"{x:156,y:537,t:1527621134253};\\\", \\\"{x:144,y:536,t:1527621134269};\\\", \\\"{x:140,y:534,t:1527621134286};\\\", \\\"{x:139,y:534,t:1527621134303};\\\", \\\"{x:140,y:534,t:1527621134522};\\\", \\\"{x:141,y:534,t:1527621134536};\\\", \\\"{x:143,y:534,t:1527621134553};\\\", \\\"{x:145,y:534,t:1527621134570};\\\", \\\"{x:147,y:533,t:1527621134587};\\\", \\\"{x:148,y:533,t:1527621134603};\\\", \\\"{x:149,y:533,t:1527621134620};\\\", \\\"{x:151,y:533,t:1527621134682};\\\", \\\"{x:153,y:533,t:1527621134691};\\\", \\\"{x:155,y:533,t:1527621134706};\\\", \\\"{x:156,y:533,t:1527621134723};\\\", \\\"{x:157,y:533,t:1527621135067};\\\", \\\"{x:175,y:536,t:1527621135075};\\\", \\\"{x:213,y:543,t:1527621135087};\\\", \\\"{x:302,y:558,t:1527621135103};\\\", \\\"{x:417,y:581,t:1527621135121};\\\", \\\"{x:540,y:606,t:1527621135138};\\\", \\\"{x:661,y:633,t:1527621135154};\\\", \\\"{x:811,y:662,t:1527621135170};\\\", \\\"{x:878,y:671,t:1527621135186};\\\", \\\"{x:904,y:677,t:1527621135204};\\\", \\\"{x:920,y:677,t:1527621135221};\\\", \\\"{x:932,y:678,t:1527621135237};\\\", \\\"{x:938,y:678,t:1527621135254};\\\", \\\"{x:941,y:677,t:1527621135270};\\\", \\\"{x:946,y:674,t:1527621135288};\\\", \\\"{x:949,y:671,t:1527621135304};\\\", \\\"{x:954,y:665,t:1527621135320};\\\", \\\"{x:960,y:662,t:1527621135338};\\\", \\\"{x:963,y:656,t:1527621135354};\\\", \\\"{x:963,y:645,t:1527621135371};\\\", \\\"{x:955,y:634,t:1527621135387};\\\", \\\"{x:943,y:618,t:1527621135404};\\\", \\\"{x:917,y:599,t:1527621135422};\\\", \\\"{x:890,y:581,t:1527621135437};\\\", \\\"{x:865,y:567,t:1527621135453};\\\", \\\"{x:840,y:554,t:1527621135471};\\\", \\\"{x:832,y:547,t:1527621135487};\\\", \\\"{x:831,y:546,t:1527621135505};\\\", \\\"{x:830,y:546,t:1527621135520};\\\", \\\"{x:830,y:545,t:1527621135547};\\\", \\\"{x:830,y:544,t:1527621135554};\\\", \\\"{x:829,y:541,t:1527621135571};\\\", \\\"{x:829,y:537,t:1527621135587};\\\", \\\"{x:829,y:527,t:1527621135605};\\\", \\\"{x:831,y:521,t:1527621135620};\\\", \\\"{x:835,y:511,t:1527621135638};\\\", \\\"{x:838,y:508,t:1527621135654};\\\", \\\"{x:840,y:504,t:1527621135670};\\\", \\\"{x:840,y:505,t:1527621136067};\\\", \\\"{x:831,y:511,t:1527621136074};\\\", \\\"{x:821,y:520,t:1527621136089};\\\", \\\"{x:802,y:540,t:1527621136105};\\\", \\\"{x:779,y:559,t:1527621136122};\\\", \\\"{x:778,y:560,t:1527621136203};\\\", \\\"{x:777,y:560,t:1527621136210};\\\", \\\"{x:774,y:560,t:1527621136234};\\\", \\\"{x:774,y:561,t:1527621136315};\\\", \\\"{x:774,y:562,t:1527621136322};\\\", \\\"{x:774,y:564,t:1527621136347};\\\", \\\"{x:774,y:565,t:1527621136354};\\\", \\\"{x:772,y:568,t:1527621136371};\\\", \\\"{x:770,y:571,t:1527621136387};\\\", \\\"{x:769,y:573,t:1527621136405};\\\", \\\"{x:767,y:577,t:1527621136421};\\\", \\\"{x:763,y:583,t:1527621136438};\\\", \\\"{x:758,y:592,t:1527621136455};\\\", \\\"{x:753,y:600,t:1527621136472};\\\", \\\"{x:748,y:608,t:1527621136488};\\\", \\\"{x:744,y:614,t:1527621136504};\\\", \\\"{x:744,y:616,t:1527621136521};\\\", \\\"{x:739,y:620,t:1527621136538};\\\", \\\"{x:737,y:623,t:1527621136554};\\\", \\\"{x:728,y:634,t:1527621136572};\\\", \\\"{x:713,y:649,t:1527621136588};\\\", \\\"{x:713,y:650,t:1527621136605};\\\", \\\"{x:712,y:651,t:1527621136859};\\\", \\\"{x:709,y:651,t:1527621136871};\\\", \\\"{x:701,y:651,t:1527621136888};\\\", \\\"{x:680,y:651,t:1527621136904};\\\", \\\"{x:665,y:656,t:1527621136922};\\\", \\\"{x:638,y:666,t:1527621136938};\\\", \\\"{x:616,y:682,t:1527621136955};\\\", \\\"{x:597,y:695,t:1527621136972};\\\", \\\"{x:576,y:711,t:1527621136989};\\\", \\\"{x:557,y:727,t:1527621137005};\\\", \\\"{x:544,y:735,t:1527621137022};\\\", \\\"{x:535,y:742,t:1527621137038};\\\", \\\"{x:533,y:743,t:1527621137056};\\\", \\\"{x:532,y:744,t:1527621137072};\\\", \\\"{x:529,y:746,t:1527621137131};\\\", \\\"{x:528,y:747,t:1527621137154};\\\", \\\"{x:530,y:747,t:1527621137587};\\\", \\\"{x:532,y:747,t:1527621137594};\\\", \\\"{x:540,y:747,t:1527621137606};\\\", \\\"{x:563,y:744,t:1527621137622};\\\", \\\"{x:591,y:743,t:1527621137639};\\\", \\\"{x:623,y:743,t:1527621137655};\\\", \\\"{x:662,y:743,t:1527621137672};\\\", \\\"{x:696,y:743,t:1527621137690};\\\", \\\"{x:719,y:743,t:1527621137706};\\\", \\\"{x:753,y:743,t:1527621137722};\\\", \\\"{x:771,y:743,t:1527621137739};\\\", \\\"{x:782,y:743,t:1527621137756};\\\", \\\"{x:799,y:743,t:1527621137772};\\\", \\\"{x:813,y:740,t:1527621137789};\\\", \\\"{x:816,y:740,t:1527621137806};\\\", \\\"{x:822,y:740,t:1527621137822};\\\", \\\"{x:824,y:740,t:1527621137839};\\\", \\\"{x:826,y:740,t:1527621137855};\\\" ] }, { \\\"rt\\\": 10998, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 548571, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:832,y:740,t:1527621140836};\\\", \\\"{x:838,y:737,t:1527621140851};\\\", \\\"{x:874,y:729,t:1527621140868};\\\", \\\"{x:930,y:729,t:1527621140883};\\\", \\\"{x:1003,y:732,t:1527621140901};\\\", \\\"{x:1105,y:744,t:1527621140918};\\\", \\\"{x:1203,y:759,t:1527621140934};\\\", \\\"{x:1295,y:773,t:1527621140951};\\\", \\\"{x:1357,y:785,t:1527621140968};\\\", \\\"{x:1383,y:788,t:1527621140984};\\\", \\\"{x:1405,y:791,t:1527621141000};\\\", \\\"{x:1407,y:791,t:1527621141018};\\\", \\\"{x:1408,y:792,t:1527621141034};\\\", \\\"{x:1407,y:793,t:1527621141228};\\\", \\\"{x:1406,y:793,t:1527621141268};\\\", \\\"{x:1403,y:784,t:1527621141684};\\\", \\\"{x:1394,y:758,t:1527621141692};\\\", \\\"{x:1390,y:733,t:1527621141702};\\\", \\\"{x:1386,y:713,t:1527621141718};\\\", \\\"{x:1384,y:702,t:1527621141735};\\\", \\\"{x:1380,y:690,t:1527621141752};\\\", \\\"{x:1380,y:688,t:1527621141769};\\\", \\\"{x:1380,y:687,t:1527621141785};\\\", \\\"{x:1379,y:687,t:1527621141802};\\\", \\\"{x:1379,y:686,t:1527621141836};\\\", \\\"{x:1378,y:685,t:1527621141876};\\\", \\\"{x:1377,y:685,t:1527621141956};\\\", \\\"{x:1375,y:685,t:1527621141970};\\\", \\\"{x:1369,y:688,t:1527621141985};\\\", \\\"{x:1359,y:694,t:1527621142003};\\\", \\\"{x:1357,y:696,t:1527621142019};\\\", \\\"{x:1356,y:696,t:1527621142035};\\\", \\\"{x:1355,y:696,t:1527621142085};\\\", \\\"{x:1354,y:697,t:1527621142102};\\\", \\\"{x:1352,y:697,t:1527621142121};\\\", \\\"{x:1348,y:699,t:1527621142152};\\\", \\\"{x:1345,y:699,t:1527621142169};\\\", \\\"{x:1341,y:700,t:1527621142185};\\\", \\\"{x:1339,y:700,t:1527621142204};\\\", \\\"{x:1338,y:700,t:1527621142219};\\\", \\\"{x:1333,y:700,t:1527621142492};\\\", \\\"{x:1312,y:700,t:1527621142502};\\\", \\\"{x:1292,y:689,t:1527621142519};\\\", \\\"{x:1249,y:683,t:1527621142536};\\\", \\\"{x:1208,y:681,t:1527621142552};\\\", \\\"{x:1156,y:676,t:1527621142569};\\\", \\\"{x:1109,y:668,t:1527621142586};\\\", \\\"{x:1045,y:662,t:1527621142602};\\\", \\\"{x:963,y:656,t:1527621142619};\\\", \\\"{x:920,y:653,t:1527621142636};\\\", \\\"{x:900,y:656,t:1527621142653};\\\", \\\"{x:880,y:656,t:1527621142669};\\\", \\\"{x:868,y:655,t:1527621142686};\\\", \\\"{x:851,y:654,t:1527621142702};\\\", \\\"{x:798,y:646,t:1527621142718};\\\", \\\"{x:736,y:637,t:1527621142735};\\\", \\\"{x:714,y:633,t:1527621142753};\\\", \\\"{x:713,y:633,t:1527621142771};\\\", \\\"{x:717,y:633,t:1527621143764};\\\", \\\"{x:721,y:633,t:1527621143772};\\\", \\\"{x:724,y:633,t:1527621143787};\\\", \\\"{x:746,y:634,t:1527621143802};\\\", \\\"{x:823,y:635,t:1527621143819};\\\", \\\"{x:908,y:639,t:1527621143837};\\\", \\\"{x:997,y:643,t:1527621143853};\\\", \\\"{x:1106,y:647,t:1527621143869};\\\", \\\"{x:1206,y:658,t:1527621143887};\\\", \\\"{x:1299,y:666,t:1527621143903};\\\", \\\"{x:1382,y:677,t:1527621143920};\\\", \\\"{x:1439,y:680,t:1527621143937};\\\", \\\"{x:1481,y:682,t:1527621143953};\\\", \\\"{x:1501,y:679,t:1527621143970};\\\", \\\"{x:1516,y:679,t:1527621143987};\\\", \\\"{x:1537,y:679,t:1527621144004};\\\", \\\"{x:1545,y:680,t:1527621144020};\\\", \\\"{x:1548,y:680,t:1527621144037};\\\", \\\"{x:1548,y:682,t:1527621144164};\\\", \\\"{x:1541,y:683,t:1527621144171};\\\", \\\"{x:1535,y:683,t:1527621144187};\\\", \\\"{x:1520,y:683,t:1527621144204};\\\", \\\"{x:1505,y:683,t:1527621144220};\\\", \\\"{x:1491,y:685,t:1527621144237};\\\", \\\"{x:1476,y:686,t:1527621144254};\\\", \\\"{x:1464,y:686,t:1527621144270};\\\", \\\"{x:1457,y:686,t:1527621144287};\\\", \\\"{x:1451,y:686,t:1527621144304};\\\", \\\"{x:1439,y:686,t:1527621144319};\\\", \\\"{x:1427,y:687,t:1527621144337};\\\", \\\"{x:1421,y:689,t:1527621144354};\\\", \\\"{x:1417,y:689,t:1527621144371};\\\", \\\"{x:1414,y:691,t:1527621144387};\\\", \\\"{x:1411,y:691,t:1527621144404};\\\", \\\"{x:1407,y:691,t:1527621144421};\\\", \\\"{x:1402,y:693,t:1527621144437};\\\", \\\"{x:1401,y:693,t:1527621144454};\\\", \\\"{x:1395,y:696,t:1527621144500};\\\", \\\"{x:1391,y:697,t:1527621144508};\\\", \\\"{x:1389,y:697,t:1527621144520};\\\", \\\"{x:1384,y:699,t:1527621144537};\\\", \\\"{x:1384,y:700,t:1527621144555};\\\", \\\"{x:1383,y:700,t:1527621144571};\\\", \\\"{x:1379,y:700,t:1527621144587};\\\", \\\"{x:1363,y:698,t:1527621144603};\\\", \\\"{x:1351,y:694,t:1527621144622};\\\", \\\"{x:1256,y:686,t:1527621144637};\\\", \\\"{x:1159,y:672,t:1527621144654};\\\", \\\"{x:1055,y:675,t:1527621144671};\\\", \\\"{x:951,y:667,t:1527621144687};\\\", \\\"{x:865,y:657,t:1527621144704};\\\", \\\"{x:841,y:654,t:1527621144721};\\\", \\\"{x:839,y:654,t:1527621144737};\\\", \\\"{x:838,y:654,t:1527621145148};\\\", \\\"{x:837,y:654,t:1527621145155};\\\", \\\"{x:835,y:654,t:1527621145170};\\\", \\\"{x:824,y:654,t:1527621145188};\\\", \\\"{x:822,y:653,t:1527621145204};\\\", \\\"{x:821,y:653,t:1527621145293};\\\", \\\"{x:814,y:651,t:1527621145304};\\\", \\\"{x:790,y:646,t:1527621145321};\\\", \\\"{x:770,y:642,t:1527621145338};\\\", \\\"{x:751,y:635,t:1527621145354};\\\", \\\"{x:728,y:630,t:1527621145372};\\\", \\\"{x:715,y:625,t:1527621145388};\\\", \\\"{x:711,y:622,t:1527621145405};\\\", \\\"{x:710,y:621,t:1527621145416};\\\", \\\"{x:707,y:621,t:1527621145433};\\\", \\\"{x:701,y:618,t:1527621145449};\\\", \\\"{x:691,y:612,t:1527621145466};\\\", \\\"{x:681,y:606,t:1527621145483};\\\", \\\"{x:676,y:604,t:1527621145499};\\\", \\\"{x:672,y:602,t:1527621145516};\\\", \\\"{x:671,y:602,t:1527621145533};\\\", \\\"{x:683,y:603,t:1527621145549};\\\", \\\"{x:682,y:602,t:1527621145804};\\\", \\\"{x:681,y:601,t:1527621145816};\\\", \\\"{x:679,y:601,t:1527621145832};\\\", \\\"{x:678,y:601,t:1527621145860};\\\", \\\"{x:677,y:599,t:1527621145869};\\\", \\\"{x:676,y:599,t:1527621145891};\\\", \\\"{x:673,y:598,t:1527621145905};\\\", \\\"{x:671,y:596,t:1527621145921};\\\", \\\"{x:669,y:592,t:1527621145939};\\\", \\\"{x:669,y:587,t:1527621145955};\\\", \\\"{x:666,y:585,t:1527621145971};\\\", \\\"{x:665,y:583,t:1527621145988};\\\", \\\"{x:665,y:581,t:1527621146011};\\\", \\\"{x:665,y:580,t:1527621146036};\\\", \\\"{x:664,y:580,t:1527621146068};\\\", \\\"{x:662,y:580,t:1527621146076};\\\", \\\"{x:660,y:580,t:1527621146089};\\\", \\\"{x:657,y:580,t:1527621146105};\\\", \\\"{x:652,y:580,t:1527621146122};\\\", \\\"{x:647,y:580,t:1527621146139};\\\", \\\"{x:640,y:580,t:1527621146156};\\\", \\\"{x:619,y:580,t:1527621146172};\\\", \\\"{x:604,y:580,t:1527621146189};\\\", \\\"{x:574,y:580,t:1527621146205};\\\", \\\"{x:489,y:572,t:1527621146222};\\\", \\\"{x:403,y:570,t:1527621146240};\\\", \\\"{x:331,y:562,t:1527621146255};\\\", \\\"{x:299,y:559,t:1527621146272};\\\", \\\"{x:277,y:558,t:1527621146289};\\\", \\\"{x:268,y:558,t:1527621146305};\\\", \\\"{x:265,y:558,t:1527621146322};\\\", \\\"{x:263,y:558,t:1527621146355};\\\", \\\"{x:262,y:559,t:1527621146372};\\\", \\\"{x:262,y:560,t:1527621146389};\\\", \\\"{x:259,y:563,t:1527621146405};\\\", \\\"{x:253,y:567,t:1527621146422};\\\", \\\"{x:244,y:570,t:1527621146439};\\\", \\\"{x:232,y:576,t:1527621146455};\\\", \\\"{x:216,y:581,t:1527621146471};\\\", \\\"{x:199,y:587,t:1527621146489};\\\", \\\"{x:181,y:590,t:1527621146506};\\\", \\\"{x:168,y:591,t:1527621146521};\\\", \\\"{x:161,y:592,t:1527621146539};\\\", \\\"{x:155,y:593,t:1527621146555};\\\", \\\"{x:152,y:593,t:1527621146572};\\\", \\\"{x:148,y:594,t:1527621146590};\\\", \\\"{x:146,y:594,t:1527621146606};\\\", \\\"{x:145,y:594,t:1527621146622};\\\", \\\"{x:144,y:594,t:1527621146651};\\\", \\\"{x:144,y:592,t:1527621146684};\\\", \\\"{x:144,y:587,t:1527621146692};\\\", \\\"{x:144,y:583,t:1527621146706};\\\", \\\"{x:144,y:578,t:1527621146721};\\\", \\\"{x:146,y:574,t:1527621146739};\\\", \\\"{x:152,y:566,t:1527621146756};\\\", \\\"{x:157,y:562,t:1527621146773};\\\", \\\"{x:159,y:559,t:1527621146789};\\\", \\\"{x:160,y:558,t:1527621146908};\\\", \\\"{x:161,y:558,t:1527621146922};\\\", \\\"{x:162,y:556,t:1527621146939};\\\", \\\"{x:162,y:555,t:1527621147012};\\\", \\\"{x:160,y:555,t:1527621147044};\\\", \\\"{x:160,y:552,t:1527621147068};\\\", \\\"{x:159,y:552,t:1527621147075};\\\", \\\"{x:159,y:551,t:1527621147092};\\\", \\\"{x:158,y:549,t:1527621147228};\\\", \\\"{x:160,y:554,t:1527621148604};\\\", \\\"{x:169,y:560,t:1527621148612};\\\", \\\"{x:177,y:567,t:1527621148624};\\\", \\\"{x:200,y:574,t:1527621148642};\\\", \\\"{x:221,y:584,t:1527621148657};\\\", \\\"{x:236,y:592,t:1527621148674};\\\", \\\"{x:247,y:597,t:1527621148692};\\\", \\\"{x:253,y:597,t:1527621148707};\\\", \\\"{x:260,y:604,t:1527621148725};\\\", \\\"{x:263,y:605,t:1527621148741};\\\", \\\"{x:265,y:605,t:1527621148804};\\\", \\\"{x:272,y:606,t:1527621148812};\\\", \\\"{x:274,y:606,t:1527621148825};\\\", \\\"{x:280,y:611,t:1527621148859};\\\", \\\"{x:281,y:613,t:1527621148874};\\\", \\\"{x:287,y:616,t:1527621148891};\\\", \\\"{x:287,y:618,t:1527621148907};\\\", \\\"{x:298,y:629,t:1527621148924};\\\", \\\"{x:300,y:630,t:1527621148941};\\\", \\\"{x:302,y:633,t:1527621148957};\\\", \\\"{x:320,y:635,t:1527621148974};\\\", \\\"{x:322,y:637,t:1527621148991};\\\", \\\"{x:329,y:644,t:1527621149008};\\\", \\\"{x:342,y:653,t:1527621149024};\\\", \\\"{x:353,y:663,t:1527621149041};\\\", \\\"{x:365,y:675,t:1527621149058};\\\", \\\"{x:376,y:682,t:1527621149074};\\\", \\\"{x:391,y:692,t:1527621149091};\\\", \\\"{x:402,y:700,t:1527621149108};\\\", \\\"{x:409,y:703,t:1527621149124};\\\", \\\"{x:418,y:709,t:1527621149141};\\\", \\\"{x:423,y:713,t:1527621149159};\\\", \\\"{x:428,y:716,t:1527621149175};\\\", \\\"{x:437,y:724,t:1527621149191};\\\", \\\"{x:446,y:732,t:1527621149209};\\\", \\\"{x:457,y:738,t:1527621149225};\\\", \\\"{x:465,y:743,t:1527621149241};\\\", \\\"{x:475,y:748,t:1527621149258};\\\", \\\"{x:483,y:749,t:1527621149274};\\\", \\\"{x:486,y:750,t:1527621149291};\\\" ] }, { \\\"rt\\\": 50411, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 600180, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -X -X -F -F -B -M -M -X -X -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:750,t:1527621151603};\\\", \\\"{x:517,y:747,t:1527621151629};\\\", \\\"{x:543,y:747,t:1527621151643};\\\", \\\"{x:579,y:748,t:1527621151660};\\\", \\\"{x:606,y:751,t:1527621151676};\\\", \\\"{x:625,y:752,t:1527621151693};\\\", \\\"{x:637,y:752,t:1527621151710};\\\", \\\"{x:646,y:753,t:1527621151726};\\\", \\\"{x:650,y:754,t:1527621151744};\\\", \\\"{x:659,y:754,t:1527621151761};\\\", \\\"{x:666,y:754,t:1527621151777};\\\", \\\"{x:673,y:750,t:1527621151793};\\\", \\\"{x:676,y:749,t:1527621151810};\\\", \\\"{x:677,y:749,t:1527621151827};\\\", \\\"{x:683,y:749,t:1527621151843};\\\", \\\"{x:702,y:745,t:1527621151860};\\\", \\\"{x:703,y:744,t:1527621151877};\\\", \\\"{x:706,y:743,t:1527621151893};\\\", \\\"{x:707,y:743,t:1527621151910};\\\", \\\"{x:708,y:743,t:1527621151964};\\\", \\\"{x:708,y:741,t:1527621156612};\\\", \\\"{x:712,y:736,t:1527621156620};\\\", \\\"{x:724,y:730,t:1527621156631};\\\", \\\"{x:797,y:730,t:1527621156647};\\\", \\\"{x:899,y:730,t:1527621156664};\\\", \\\"{x:1032,y:730,t:1527621156681};\\\", \\\"{x:1149,y:730,t:1527621156698};\\\", \\\"{x:1259,y:730,t:1527621156714};\\\", \\\"{x:1433,y:722,t:1527621156731};\\\", \\\"{x:1541,y:722,t:1527621156748};\\\", \\\"{x:1629,y:722,t:1527621156764};\\\", \\\"{x:1704,y:713,t:1527621156781};\\\", \\\"{x:1774,y:702,t:1527621156799};\\\", \\\"{x:1819,y:698,t:1527621156814};\\\", \\\"{x:1871,y:691,t:1527621156831};\\\", \\\"{x:1919,y:683,t:1527621156848};\\\", \\\"{x:1919,y:676,t:1527621156864};\\\", \\\"{x:1919,y:669,t:1527621156881};\\\", \\\"{x:1919,y:667,t:1527621156897};\\\", \\\"{x:1919,y:664,t:1527621156914};\\\", \\\"{x:1917,y:664,t:1527621156988};\\\", \\\"{x:1916,y:664,t:1527621156997};\\\", \\\"{x:1907,y:669,t:1527621157015};\\\", \\\"{x:1898,y:670,t:1527621157031};\\\", \\\"{x:1891,y:670,t:1527621157048};\\\", \\\"{x:1888,y:672,t:1527621157065};\\\", \\\"{x:1883,y:673,t:1527621157081};\\\", \\\"{x:1874,y:676,t:1527621157098};\\\", \\\"{x:1863,y:678,t:1527621157114};\\\", \\\"{x:1838,y:682,t:1527621157131};\\\", \\\"{x:1817,y:684,t:1527621157148};\\\", \\\"{x:1795,y:688,t:1527621157164};\\\", \\\"{x:1772,y:689,t:1527621157181};\\\", \\\"{x:1753,y:692,t:1527621157197};\\\", \\\"{x:1732,y:693,t:1527621157215};\\\", \\\"{x:1727,y:695,t:1527621157231};\\\", \\\"{x:1721,y:698,t:1527621157248};\\\", \\\"{x:1715,y:702,t:1527621157264};\\\", \\\"{x:1709,y:703,t:1527621157281};\\\", \\\"{x:1701,y:705,t:1527621157297};\\\", \\\"{x:1698,y:706,t:1527621157315};\\\", \\\"{x:1693,y:707,t:1527621157332};\\\", \\\"{x:1689,y:709,t:1527621157348};\\\", \\\"{x:1683,y:710,t:1527621157365};\\\", \\\"{x:1678,y:710,t:1527621157381};\\\", \\\"{x:1671,y:712,t:1527621157398};\\\", \\\"{x:1663,y:715,t:1527621157415};\\\", \\\"{x:1657,y:716,t:1527621157432};\\\", \\\"{x:1654,y:719,t:1527621157448};\\\", \\\"{x:1651,y:721,t:1527621157464};\\\", \\\"{x:1650,y:721,t:1527621157508};\\\", \\\"{x:1649,y:721,t:1527621157540};\\\", \\\"{x:1648,y:722,t:1527621157547};\\\", \\\"{x:1648,y:723,t:1527621164859};\\\", \\\"{x:1648,y:735,t:1527621164870};\\\", \\\"{x:1656,y:754,t:1527621164887};\\\", \\\"{x:1661,y:762,t:1527621164904};\\\", \\\"{x:1665,y:764,t:1527621164921};\\\", \\\"{x:1666,y:764,t:1527621164937};\\\", \\\"{x:1668,y:766,t:1527621165011};\\\", \\\"{x:1668,y:772,t:1527621165021};\\\", \\\"{x:1668,y:778,t:1527621165037};\\\", \\\"{x:1665,y:789,t:1527621165054};\\\", \\\"{x:1662,y:802,t:1527621165071};\\\", \\\"{x:1660,y:812,t:1527621165088};\\\", \\\"{x:1659,y:825,t:1527621165104};\\\", \\\"{x:1655,y:837,t:1527621165121};\\\", \\\"{x:1651,y:850,t:1527621165138};\\\", \\\"{x:1650,y:864,t:1527621165154};\\\", \\\"{x:1643,y:876,t:1527621165171};\\\", \\\"{x:1639,y:894,t:1527621165187};\\\", \\\"{x:1636,y:898,t:1527621165204};\\\", \\\"{x:1636,y:899,t:1527621165221};\\\", \\\"{x:1636,y:905,t:1527621165238};\\\", \\\"{x:1636,y:906,t:1527621165254};\\\", \\\"{x:1636,y:911,t:1527621165271};\\\", \\\"{x:1636,y:918,t:1527621165288};\\\", \\\"{x:1636,y:924,t:1527621165304};\\\", \\\"{x:1636,y:928,t:1527621165321};\\\", \\\"{x:1635,y:938,t:1527621165338};\\\", \\\"{x:1634,y:945,t:1527621165355};\\\", \\\"{x:1633,y:947,t:1527621165371};\\\", \\\"{x:1631,y:951,t:1527621165388};\\\", \\\"{x:1630,y:954,t:1527621165405};\\\", \\\"{x:1630,y:957,t:1527621165421};\\\", \\\"{x:1630,y:960,t:1527621165438};\\\", \\\"{x:1630,y:961,t:1527621165454};\\\", \\\"{x:1629,y:962,t:1527621165472};\\\", \\\"{x:1629,y:963,t:1527621165533};\\\", \\\"{x:1630,y:963,t:1527621165764};\\\", \\\"{x:1631,y:962,t:1527621165779};\\\", \\\"{x:1632,y:961,t:1527621165795};\\\", \\\"{x:1633,y:961,t:1527621165828};\\\", \\\"{x:1633,y:960,t:1527621165851};\\\", \\\"{x:1633,y:959,t:1527621165868};\\\", \\\"{x:1633,y:958,t:1527621165900};\\\", \\\"{x:1633,y:956,t:1527621165908};\\\", \\\"{x:1633,y:955,t:1527621165922};\\\", \\\"{x:1633,y:953,t:1527621165938};\\\", \\\"{x:1633,y:951,t:1527621165955};\\\", \\\"{x:1633,y:950,t:1527621165972};\\\", \\\"{x:1633,y:949,t:1527621165988};\\\", \\\"{x:1633,y:947,t:1527621166052};\\\", \\\"{x:1633,y:946,t:1527621166067};\\\", \\\"{x:1633,y:945,t:1527621166076};\\\", \\\"{x:1632,y:942,t:1527621166088};\\\", \\\"{x:1630,y:938,t:1527621166105};\\\", \\\"{x:1630,y:937,t:1527621166122};\\\", \\\"{x:1628,y:935,t:1527621166137};\\\", \\\"{x:1628,y:933,t:1527621166155};\\\", \\\"{x:1627,y:931,t:1527621166172};\\\", \\\"{x:1625,y:931,t:1527621166203};\\\", \\\"{x:1625,y:933,t:1527621166412};\\\", \\\"{x:1626,y:933,t:1527621166428};\\\", \\\"{x:1627,y:935,t:1527621166440};\\\", \\\"{x:1629,y:937,t:1527621166455};\\\", \\\"{x:1630,y:941,t:1527621166473};\\\", \\\"{x:1633,y:944,t:1527621166490};\\\", \\\"{x:1635,y:946,t:1527621166506};\\\", \\\"{x:1639,y:948,t:1527621166522};\\\", \\\"{x:1642,y:949,t:1527621166540};\\\", \\\"{x:1643,y:949,t:1527621166572};\\\", \\\"{x:1644,y:950,t:1527621166604};\\\", \\\"{x:1645,y:950,t:1527621166622};\\\", \\\"{x:1646,y:950,t:1527621166652};\\\", \\\"{x:1647,y:952,t:1527621166667};\\\", \\\"{x:1647,y:954,t:1527621166675};\\\", \\\"{x:1647,y:956,t:1527621166689};\\\", \\\"{x:1647,y:957,t:1527621166705};\\\", \\\"{x:1647,y:959,t:1527621166731};\\\", \\\"{x:1647,y:960,t:1527621166739};\\\", \\\"{x:1647,y:961,t:1527621166780};\\\", \\\"{x:1647,y:962,t:1527621166789};\\\", \\\"{x:1647,y:963,t:1527621167517};\\\", \\\"{x:1646,y:963,t:1527621168221};\\\", \\\"{x:1645,y:963,t:1527621168228};\\\", \\\"{x:1644,y:963,t:1527621168371};\\\", \\\"{x:1643,y:963,t:1527621168395};\\\", \\\"{x:1642,y:963,t:1527621168419};\\\", \\\"{x:1640,y:963,t:1527621168452};\\\", \\\"{x:1639,y:963,t:1527621168460};\\\", \\\"{x:1637,y:963,t:1527621168476};\\\", \\\"{x:1635,y:963,t:1527621168490};\\\", \\\"{x:1632,y:962,t:1527621168507};\\\", \\\"{x:1626,y:961,t:1527621168524};\\\", \\\"{x:1625,y:959,t:1527621168540};\\\", \\\"{x:1621,y:956,t:1527621168557};\\\", \\\"{x:1616,y:951,t:1527621168575};\\\", \\\"{x:1612,y:945,t:1527621168591};\\\", \\\"{x:1605,y:937,t:1527621168607};\\\", \\\"{x:1596,y:926,t:1527621168624};\\\", \\\"{x:1581,y:910,t:1527621168641};\\\", \\\"{x:1562,y:899,t:1527621168657};\\\", \\\"{x:1546,y:885,t:1527621168674};\\\", \\\"{x:1534,y:873,t:1527621168691};\\\", \\\"{x:1524,y:858,t:1527621168708};\\\", \\\"{x:1511,y:838,t:1527621168724};\\\", \\\"{x:1505,y:823,t:1527621168741};\\\", \\\"{x:1496,y:808,t:1527621168758};\\\", \\\"{x:1489,y:795,t:1527621168774};\\\", \\\"{x:1486,y:790,t:1527621168790};\\\", \\\"{x:1484,y:786,t:1527621168807};\\\", \\\"{x:1483,y:785,t:1527621168824};\\\", \\\"{x:1482,y:783,t:1527621168840};\\\", \\\"{x:1482,y:781,t:1527621168860};\\\", \\\"{x:1482,y:780,t:1527621168874};\\\", \\\"{x:1482,y:777,t:1527621168892};\\\", \\\"{x:1482,y:775,t:1527621168908};\\\", \\\"{x:1482,y:773,t:1527621168924};\\\", \\\"{x:1482,y:770,t:1527621168941};\\\", \\\"{x:1484,y:768,t:1527621168957};\\\", \\\"{x:1485,y:766,t:1527621168974};\\\", \\\"{x:1487,y:764,t:1527621168991};\\\", \\\"{x:1488,y:764,t:1527621169008};\\\", \\\"{x:1488,y:763,t:1527621169024};\\\", \\\"{x:1489,y:763,t:1527621169042};\\\", \\\"{x:1491,y:761,t:1527621169058};\\\", \\\"{x:1493,y:761,t:1527621169075};\\\", \\\"{x:1495,y:759,t:1527621169092};\\\", \\\"{x:1497,y:759,t:1527621169108};\\\", \\\"{x:1497,y:758,t:1527621169132};\\\", \\\"{x:1498,y:757,t:1527621169172};\\\", \\\"{x:1499,y:757,t:1527621169461};\\\", \\\"{x:1500,y:757,t:1527621169475};\\\", \\\"{x:1502,y:757,t:1527621169805};\\\", \\\"{x:1502,y:758,t:1527621170372};\\\", \\\"{x:1502,y:759,t:1527621170421};\\\", \\\"{x:1503,y:760,t:1527621170445};\\\", \\\"{x:1505,y:760,t:1527621170468};\\\", \\\"{x:1505,y:761,t:1527621170476};\\\", \\\"{x:1506,y:761,t:1527621170493};\\\", \\\"{x:1507,y:762,t:1527621170508};\\\", \\\"{x:1508,y:762,t:1527621170526};\\\", \\\"{x:1509,y:763,t:1527621170559};\\\", \\\"{x:1510,y:764,t:1527621170591};\\\", \\\"{x:1511,y:764,t:1527621170644};\\\", \\\"{x:1512,y:765,t:1527621174732};\\\", \\\"{x:1512,y:766,t:1527621174812};\\\", \\\"{x:1512,y:767,t:1527621174851};\\\", \\\"{x:1512,y:768,t:1527621174924};\\\", \\\"{x:1512,y:770,t:1527621175076};\\\", \\\"{x:1512,y:771,t:1527621175293};\\\", \\\"{x:1512,y:772,t:1527621175356};\\\", \\\"{x:1512,y:773,t:1527621175365};\\\", \\\"{x:1512,y:775,t:1527621175381};\\\", \\\"{x:1512,y:777,t:1527621175396};\\\", \\\"{x:1512,y:779,t:1527621175413};\\\", \\\"{x:1512,y:782,t:1527621175430};\\\", \\\"{x:1512,y:785,t:1527621175446};\\\", \\\"{x:1511,y:786,t:1527621175463};\\\", \\\"{x:1511,y:788,t:1527621175480};\\\", \\\"{x:1509,y:789,t:1527621175496};\\\", \\\"{x:1508,y:791,t:1527621175512};\\\", \\\"{x:1507,y:792,t:1527621175530};\\\", \\\"{x:1506,y:793,t:1527621175572};\\\", \\\"{x:1504,y:795,t:1527621175596};\\\", \\\"{x:1503,y:798,t:1527621175613};\\\", \\\"{x:1500,y:801,t:1527621175629};\\\", \\\"{x:1498,y:803,t:1527621175646};\\\", \\\"{x:1497,y:805,t:1527621175663};\\\", \\\"{x:1494,y:807,t:1527621175680};\\\", \\\"{x:1491,y:810,t:1527621175696};\\\", \\\"{x:1490,y:812,t:1527621175712};\\\", \\\"{x:1487,y:815,t:1527621175729};\\\", \\\"{x:1484,y:817,t:1527621175746};\\\", \\\"{x:1479,y:820,t:1527621175788};\\\", \\\"{x:1478,y:821,t:1527621175804};\\\", \\\"{x:1476,y:823,t:1527621175813};\\\", \\\"{x:1475,y:823,t:1527621175837};\\\", \\\"{x:1474,y:823,t:1527621176068};\\\", \\\"{x:1473,y:825,t:1527621180549};\\\", \\\"{x:1473,y:827,t:1527621180556};\\\", \\\"{x:1473,y:828,t:1527621180567};\\\", \\\"{x:1472,y:834,t:1527621180584};\\\", \\\"{x:1472,y:836,t:1527621180600};\\\", \\\"{x:1472,y:837,t:1527621180618};\\\", \\\"{x:1473,y:838,t:1527621180893};\\\", \\\"{x:1474,y:838,t:1527621181012};\\\", \\\"{x:1475,y:837,t:1527621181021};\\\", \\\"{x:1476,y:836,t:1527621181035};\\\", \\\"{x:1477,y:835,t:1527621181052};\\\", \\\"{x:1478,y:834,t:1527621181716};\\\", \\\"{x:1480,y:833,t:1527621181733};\\\", \\\"{x:1480,y:832,t:1527621181755};\\\", \\\"{x:1481,y:832,t:1527621181876};\\\", \\\"{x:1481,y:831,t:1527621181996};\\\", \\\"{x:1481,y:830,t:1527621182011};\\\", \\\"{x:1482,y:828,t:1527621182035};\\\", \\\"{x:1483,y:828,t:1527621182051};\\\", \\\"{x:1483,y:826,t:1527621182067};\\\", \\\"{x:1484,y:824,t:1527621182092};\\\", \\\"{x:1485,y:824,t:1527621182100};\\\", \\\"{x:1485,y:823,t:1527621182132};\\\", \\\"{x:1486,y:823,t:1527621182147};\\\", \\\"{x:1491,y:824,t:1527621186500};\\\", \\\"{x:1497,y:826,t:1527621186508};\\\", \\\"{x:1499,y:827,t:1527621186521};\\\", \\\"{x:1506,y:827,t:1527621186538};\\\", \\\"{x:1513,y:828,t:1527621186556};\\\", \\\"{x:1516,y:830,t:1527621186572};\\\", \\\"{x:1520,y:830,t:1527621186588};\\\", \\\"{x:1521,y:830,t:1527621186619};\\\", \\\"{x:1523,y:830,t:1527621186627};\\\", \\\"{x:1526,y:830,t:1527621186643};\\\", \\\"{x:1529,y:829,t:1527621186655};\\\", \\\"{x:1538,y:825,t:1527621186672};\\\", \\\"{x:1550,y:821,t:1527621186688};\\\", \\\"{x:1563,y:816,t:1527621186704};\\\", \\\"{x:1584,y:810,t:1527621186722};\\\", \\\"{x:1601,y:802,t:1527621186738};\\\", \\\"{x:1611,y:798,t:1527621186755};\\\", \\\"{x:1619,y:792,t:1527621186772};\\\", \\\"{x:1619,y:791,t:1527621186892};\\\", \\\"{x:1619,y:789,t:1527621186906};\\\", \\\"{x:1620,y:785,t:1527621186923};\\\", \\\"{x:1622,y:777,t:1527621186938};\\\", \\\"{x:1623,y:773,t:1527621186955};\\\", \\\"{x:1625,y:768,t:1527621186972};\\\", \\\"{x:1627,y:764,t:1527621186990};\\\", \\\"{x:1628,y:755,t:1527621187005};\\\", \\\"{x:1629,y:746,t:1527621187022};\\\", \\\"{x:1630,y:740,t:1527621187040};\\\", \\\"{x:1630,y:735,t:1527621187056};\\\", \\\"{x:1630,y:732,t:1527621187072};\\\", \\\"{x:1630,y:728,t:1527621187090};\\\", \\\"{x:1630,y:725,t:1527621187105};\\\", \\\"{x:1630,y:721,t:1527621187123};\\\", \\\"{x:1630,y:715,t:1527621187140};\\\", \\\"{x:1631,y:712,t:1527621187155};\\\", \\\"{x:1632,y:707,t:1527621187172};\\\", \\\"{x:1632,y:703,t:1527621187189};\\\", \\\"{x:1632,y:701,t:1527621187206};\\\", \\\"{x:1632,y:698,t:1527621187223};\\\", \\\"{x:1632,y:697,t:1527621187239};\\\", \\\"{x:1632,y:696,t:1527621187256};\\\", \\\"{x:1632,y:697,t:1527621187461};\\\", \\\"{x:1632,y:702,t:1527621187473};\\\", \\\"{x:1630,y:712,t:1527621187489};\\\", \\\"{x:1628,y:733,t:1527621187507};\\\", \\\"{x:1623,y:761,t:1527621187523};\\\", \\\"{x:1617,y:786,t:1527621187539};\\\", \\\"{x:1613,y:818,t:1527621187556};\\\", \\\"{x:1613,y:836,t:1527621187572};\\\", \\\"{x:1613,y:847,t:1527621187589};\\\", \\\"{x:1613,y:855,t:1527621187606};\\\", \\\"{x:1613,y:861,t:1527621187622};\\\", \\\"{x:1613,y:863,t:1527621187640};\\\", \\\"{x:1613,y:864,t:1527621187656};\\\", \\\"{x:1613,y:866,t:1527621187672};\\\", \\\"{x:1613,y:868,t:1527621187689};\\\", \\\"{x:1613,y:869,t:1527621187706};\\\", \\\"{x:1613,y:874,t:1527621187722};\\\", \\\"{x:1613,y:877,t:1527621187739};\\\", \\\"{x:1613,y:881,t:1527621187756};\\\", \\\"{x:1614,y:884,t:1527621187772};\\\", \\\"{x:1614,y:887,t:1527621187795};\\\", \\\"{x:1614,y:888,t:1527621187806};\\\", \\\"{x:1616,y:892,t:1527621187823};\\\", \\\"{x:1616,y:896,t:1527621187839};\\\", \\\"{x:1616,y:907,t:1527621187856};\\\", \\\"{x:1616,y:913,t:1527621187872};\\\", \\\"{x:1617,y:916,t:1527621187889};\\\", \\\"{x:1618,y:917,t:1527621187906};\\\", \\\"{x:1620,y:919,t:1527621187924};\\\", \\\"{x:1621,y:921,t:1527621187939};\\\", \\\"{x:1621,y:926,t:1527621187956};\\\", \\\"{x:1621,y:928,t:1527621187973};\\\", \\\"{x:1621,y:931,t:1527621187989};\\\", \\\"{x:1621,y:934,t:1527621188007};\\\", \\\"{x:1621,y:936,t:1527621188023};\\\", \\\"{x:1621,y:937,t:1527621188039};\\\", \\\"{x:1621,y:939,t:1527621188057};\\\", \\\"{x:1621,y:940,t:1527621188074};\\\", \\\"{x:1620,y:941,t:1527621188090};\\\", \\\"{x:1619,y:941,t:1527621188108};\\\", \\\"{x:1619,y:943,t:1527621188124};\\\", \\\"{x:1619,y:945,t:1527621188140};\\\", \\\"{x:1616,y:950,t:1527621188157};\\\", \\\"{x:1616,y:952,t:1527621188174};\\\", \\\"{x:1614,y:955,t:1527621188190};\\\", \\\"{x:1614,y:956,t:1527621188206};\\\", \\\"{x:1614,y:957,t:1527621188237};\\\", \\\"{x:1613,y:957,t:1527621188244};\\\", \\\"{x:1612,y:958,t:1527621188436};\\\", \\\"{x:1612,y:959,t:1527621188460};\\\", \\\"{x:1612,y:960,t:1527621188476};\\\", \\\"{x:1611,y:960,t:1527621188749};\\\", \\\"{x:1606,y:957,t:1527621188757};\\\", \\\"{x:1604,y:950,t:1527621188774};\\\", \\\"{x:1597,y:941,t:1527621188791};\\\", \\\"{x:1593,y:935,t:1527621188808};\\\", \\\"{x:1590,y:928,t:1527621188824};\\\", \\\"{x:1587,y:923,t:1527621188841};\\\", \\\"{x:1579,y:911,t:1527621188858};\\\", \\\"{x:1565,y:896,t:1527621188874};\\\", \\\"{x:1550,y:880,t:1527621188891};\\\", \\\"{x:1515,y:854,t:1527621188908};\\\", \\\"{x:1460,y:820,t:1527621188924};\\\", \\\"{x:1409,y:790,t:1527621188941};\\\", \\\"{x:1392,y:777,t:1527621188957};\\\", \\\"{x:1380,y:762,t:1527621188974};\\\", \\\"{x:1371,y:747,t:1527621188990};\\\", \\\"{x:1364,y:737,t:1527621189007};\\\", \\\"{x:1359,y:728,t:1527621189024};\\\", \\\"{x:1357,y:721,t:1527621189041};\\\", \\\"{x:1355,y:720,t:1527621189057};\\\", \\\"{x:1353,y:716,t:1527621189073};\\\", \\\"{x:1352,y:712,t:1527621189090};\\\", \\\"{x:1351,y:710,t:1527621189108};\\\", \\\"{x:1351,y:709,t:1527621189124};\\\", \\\"{x:1351,y:707,t:1527621189140};\\\", \\\"{x:1351,y:706,t:1527621189157};\\\", \\\"{x:1351,y:704,t:1527621189174};\\\", \\\"{x:1350,y:701,t:1527621189191};\\\", \\\"{x:1349,y:700,t:1527621189228};\\\", \\\"{x:1343,y:700,t:1527621189540};\\\", \\\"{x:1275,y:700,t:1527621189559};\\\", \\\"{x:1138,y:692,t:1527621189574};\\\", \\\"{x:981,y:674,t:1527621189591};\\\", \\\"{x:817,y:645,t:1527621189607};\\\", \\\"{x:651,y:619,t:1527621189626};\\\", \\\"{x:535,y:590,t:1527621189641};\\\", \\\"{x:421,y:570,t:1527621189657};\\\", \\\"{x:357,y:559,t:1527621189692};\\\", \\\"{x:362,y:559,t:1527621189715};\\\", \\\"{x:371,y:558,t:1527621189725};\\\", \\\"{x:372,y:557,t:1527621189988};\\\", \\\"{x:375,y:554,t:1527621189998};\\\", \\\"{x:378,y:554,t:1527621190008};\\\", \\\"{x:391,y:554,t:1527621190025};\\\", \\\"{x:408,y:553,t:1527621190042};\\\", \\\"{x:428,y:553,t:1527621190059};\\\", \\\"{x:449,y:553,t:1527621190075};\\\", \\\"{x:468,y:553,t:1527621190092};\\\", \\\"{x:480,y:553,t:1527621190109};\\\", \\\"{x:489,y:553,t:1527621190124};\\\", \\\"{x:496,y:552,t:1527621190142};\\\", \\\"{x:505,y:551,t:1527621190159};\\\", \\\"{x:515,y:551,t:1527621190175};\\\", \\\"{x:526,y:551,t:1527621190192};\\\", \\\"{x:532,y:552,t:1527621190208};\\\", \\\"{x:541,y:554,t:1527621190225};\\\", \\\"{x:547,y:555,t:1527621190242};\\\", \\\"{x:551,y:555,t:1527621190258};\\\", \\\"{x:554,y:555,t:1527621190275};\\\", \\\"{x:555,y:555,t:1527621190307};\\\", \\\"{x:557,y:555,t:1527621190315};\\\", \\\"{x:558,y:554,t:1527621190325};\\\", \\\"{x:560,y:550,t:1527621190342};\\\", \\\"{x:564,y:545,t:1527621190359};\\\", \\\"{x:566,y:541,t:1527621190375};\\\", \\\"{x:567,y:539,t:1527621190392};\\\", \\\"{x:568,y:536,t:1527621190409};\\\", \\\"{x:569,y:535,t:1527621190428};\\\", \\\"{x:569,y:534,t:1527621190442};\\\", \\\"{x:569,y:533,t:1527621190459};\\\", \\\"{x:569,y:531,t:1527621190475};\\\", \\\"{x:567,y:527,t:1527621190492};\\\", \\\"{x:555,y:524,t:1527621190510};\\\", \\\"{x:538,y:520,t:1527621190525};\\\", \\\"{x:521,y:519,t:1527621190542};\\\", \\\"{x:504,y:522,t:1527621190559};\\\", \\\"{x:498,y:527,t:1527621190575};\\\", \\\"{x:498,y:528,t:1527621190592};\\\", \\\"{x:499,y:528,t:1527621190652};\\\", \\\"{x:504,y:527,t:1527621190659};\\\", \\\"{x:522,y:523,t:1527621190675};\\\", \\\"{x:554,y:518,t:1527621190692};\\\", \\\"{x:568,y:516,t:1527621190710};\\\", \\\"{x:584,y:512,t:1527621190725};\\\", \\\"{x:599,y:508,t:1527621190742};\\\", \\\"{x:617,y:508,t:1527621190760};\\\", \\\"{x:627,y:503,t:1527621190776};\\\", \\\"{x:629,y:502,t:1527621190792};\\\", \\\"{x:630,y:502,t:1527621190809};\\\", \\\"{x:631,y:502,t:1527621190826};\\\", \\\"{x:635,y:502,t:1527621190842};\\\", \\\"{x:642,y:500,t:1527621190859};\\\", \\\"{x:650,y:498,t:1527621190876};\\\", \\\"{x:658,y:498,t:1527621190892};\\\", \\\"{x:673,y:497,t:1527621190909};\\\", \\\"{x:684,y:497,t:1527621190926};\\\", \\\"{x:693,y:497,t:1527621190942};\\\", \\\"{x:704,y:500,t:1527621190959};\\\", \\\"{x:714,y:500,t:1527621190976};\\\", \\\"{x:719,y:501,t:1527621190992};\\\", \\\"{x:722,y:501,t:1527621191009};\\\", \\\"{x:723,y:501,t:1527621191043};\\\", \\\"{x:724,y:501,t:1527621191061};\\\", \\\"{x:729,y:504,t:1527621191076};\\\", \\\"{x:739,y:505,t:1527621191092};\\\", \\\"{x:754,y:506,t:1527621191109};\\\", \\\"{x:763,y:510,t:1527621191127};\\\", \\\"{x:771,y:510,t:1527621191143};\\\", \\\"{x:775,y:510,t:1527621191160};\\\", \\\"{x:777,y:510,t:1527621191176};\\\", \\\"{x:778,y:510,t:1527621191193};\\\", \\\"{x:781,y:510,t:1527621191252};\\\", \\\"{x:782,y:510,t:1527621191268};\\\", \\\"{x:784,y:510,t:1527621191277};\\\", \\\"{x:788,y:510,t:1527621191293};\\\", \\\"{x:791,y:510,t:1527621191309};\\\", \\\"{x:797,y:510,t:1527621191327};\\\", \\\"{x:802,y:510,t:1527621191344};\\\", \\\"{x:804,y:510,t:1527621191359};\\\", \\\"{x:806,y:510,t:1527621191376};\\\", \\\"{x:807,y:510,t:1527621191404};\\\", \\\"{x:809,y:509,t:1527621191412};\\\", \\\"{x:812,y:509,t:1527621191426};\\\", \\\"{x:816,y:509,t:1527621191443};\\\", \\\"{x:819,y:509,t:1527621191459};\\\", \\\"{x:824,y:509,t:1527621191476};\\\", \\\"{x:827,y:509,t:1527621191493};\\\", \\\"{x:828,y:508,t:1527621191509};\\\", \\\"{x:830,y:508,t:1527621191526};\\\", \\\"{x:831,y:508,t:1527621191899};\\\", \\\"{x:835,y:508,t:1527621191910};\\\", \\\"{x:857,y:514,t:1527621191927};\\\", \\\"{x:888,y:523,t:1527621191944};\\\", \\\"{x:932,y:534,t:1527621191960};\\\", \\\"{x:972,y:550,t:1527621191977};\\\", \\\"{x:1018,y:567,t:1527621191993};\\\", \\\"{x:1068,y:583,t:1527621192010};\\\", \\\"{x:1113,y:602,t:1527621192027};\\\", \\\"{x:1142,y:615,t:1527621192043};\\\", \\\"{x:1175,y:627,t:1527621192060};\\\", \\\"{x:1204,y:635,t:1527621192077};\\\", \\\"{x:1244,y:654,t:1527621192093};\\\", \\\"{x:1283,y:673,t:1527621192110};\\\", \\\"{x:1309,y:681,t:1527621192127};\\\", \\\"{x:1331,y:689,t:1527621192143};\\\", \\\"{x:1346,y:699,t:1527621192161};\\\", \\\"{x:1358,y:704,t:1527621192178};\\\", \\\"{x:1370,y:710,t:1527621192194};\\\", \\\"{x:1382,y:717,t:1527621192211};\\\", \\\"{x:1409,y:728,t:1527621192227};\\\", \\\"{x:1425,y:735,t:1527621192244};\\\", \\\"{x:1448,y:742,t:1527621192260};\\\", \\\"{x:1467,y:747,t:1527621192277};\\\", \\\"{x:1480,y:752,t:1527621192293};\\\", \\\"{x:1483,y:752,t:1527621192311};\\\", \\\"{x:1486,y:752,t:1527621192327};\\\", \\\"{x:1487,y:752,t:1527621192343};\\\", \\\"{x:1490,y:752,t:1527621192444};\\\", \\\"{x:1496,y:750,t:1527621192461};\\\", \\\"{x:1502,y:746,t:1527621192478};\\\", \\\"{x:1506,y:744,t:1527621192494};\\\", \\\"{x:1508,y:743,t:1527621192511};\\\", \\\"{x:1511,y:742,t:1527621192528};\\\", \\\"{x:1517,y:739,t:1527621192545};\\\", \\\"{x:1523,y:737,t:1527621192561};\\\", \\\"{x:1536,y:733,t:1527621192578};\\\", \\\"{x:1546,y:729,t:1527621192595};\\\", \\\"{x:1557,y:725,t:1527621192611};\\\", \\\"{x:1560,y:723,t:1527621192627};\\\", \\\"{x:1560,y:722,t:1527621192644};\\\", \\\"{x:1560,y:721,t:1527621192660};\\\", \\\"{x:1561,y:721,t:1527621192723};\\\", \\\"{x:1563,y:719,t:1527621192731};\\\", \\\"{x:1566,y:717,t:1527621192747};\\\", \\\"{x:1571,y:716,t:1527621192760};\\\", \\\"{x:1579,y:713,t:1527621192777};\\\", \\\"{x:1593,y:710,t:1527621192794};\\\", \\\"{x:1603,y:707,t:1527621192810};\\\", \\\"{x:1615,y:705,t:1527621192827};\\\", \\\"{x:1618,y:705,t:1527621192845};\\\", \\\"{x:1617,y:705,t:1527621193300};\\\", \\\"{x:1616,y:705,t:1527621193316};\\\", \\\"{x:1614,y:706,t:1527621193332};\\\", \\\"{x:1612,y:707,t:1527621193344};\\\", \\\"{x:1607,y:710,t:1527621193362};\\\", \\\"{x:1604,y:712,t:1527621193379};\\\", \\\"{x:1600,y:713,t:1527621193395};\\\", \\\"{x:1595,y:718,t:1527621193411};\\\", \\\"{x:1589,y:720,t:1527621193428};\\\", \\\"{x:1575,y:726,t:1527621193444};\\\", \\\"{x:1555,y:730,t:1527621193461};\\\", \\\"{x:1533,y:733,t:1527621193478};\\\", \\\"{x:1508,y:737,t:1527621193494};\\\", \\\"{x:1497,y:737,t:1527621193511};\\\", \\\"{x:1478,y:742,t:1527621193528};\\\", \\\"{x:1462,y:745,t:1527621193545};\\\", \\\"{x:1450,y:748,t:1527621193561};\\\", \\\"{x:1442,y:749,t:1527621193578};\\\", \\\"{x:1419,y:754,t:1527621193594};\\\", \\\"{x:1390,y:755,t:1527621193612};\\\", \\\"{x:1378,y:755,t:1527621193628};\\\", \\\"{x:1374,y:755,t:1527621193644};\\\", \\\"{x:1373,y:755,t:1527621193661};\\\", \\\"{x:1372,y:755,t:1527621193781};\\\", \\\"{x:1371,y:755,t:1527621193813};\\\", \\\"{x:1369,y:755,t:1527621193828};\\\", \\\"{x:1366,y:757,t:1527621193845};\\\", \\\"{x:1364,y:758,t:1527621193861};\\\", \\\"{x:1363,y:758,t:1527621193878};\\\", \\\"{x:1362,y:758,t:1527621193895};\\\", \\\"{x:1360,y:760,t:1527621193911};\\\", \\\"{x:1359,y:760,t:1527621193928};\\\", \\\"{x:1358,y:760,t:1527621193945};\\\", \\\"{x:1357,y:761,t:1527621193964};\\\", \\\"{x:1356,y:761,t:1527621193978};\\\", \\\"{x:1356,y:762,t:1527621193996};\\\", \\\"{x:1355,y:762,t:1527621194028};\\\", \\\"{x:1352,y:763,t:1527621194085};\\\", \\\"{x:1351,y:764,t:1527621194111};\\\", \\\"{x:1349,y:765,t:1527621194188};\\\", \\\"{x:1348,y:765,t:1527621194220};\\\", \\\"{x:1347,y:766,t:1527621194236};\\\", \\\"{x:1346,y:767,t:1527621194316};\\\", \\\"{x:1345,y:769,t:1527621194517};\\\", \\\"{x:1345,y:771,t:1527621194529};\\\", \\\"{x:1345,y:778,t:1527621194545};\\\", \\\"{x:1347,y:785,t:1527621194563};\\\", \\\"{x:1352,y:796,t:1527621194580};\\\", \\\"{x:1356,y:805,t:1527621194596};\\\", \\\"{x:1360,y:818,t:1527621194612};\\\", \\\"{x:1363,y:835,t:1527621194630};\\\", \\\"{x:1367,y:850,t:1527621194646};\\\", \\\"{x:1369,y:871,t:1527621194663};\\\", \\\"{x:1373,y:883,t:1527621194680};\\\", \\\"{x:1377,y:900,t:1527621194696};\\\", \\\"{x:1382,y:912,t:1527621194714};\\\", \\\"{x:1383,y:916,t:1527621194730};\\\", \\\"{x:1383,y:918,t:1527621194746};\\\", \\\"{x:1383,y:919,t:1527621194762};\\\", \\\"{x:1385,y:918,t:1527621194988};\\\", \\\"{x:1385,y:917,t:1527621194996};\\\", \\\"{x:1385,y:913,t:1527621195012};\\\", \\\"{x:1386,y:909,t:1527621195029};\\\", \\\"{x:1386,y:907,t:1527621195046};\\\", \\\"{x:1386,y:905,t:1527621195062};\\\", \\\"{x:1386,y:904,t:1527621195079};\\\", \\\"{x:1386,y:903,t:1527621195099};\\\", \\\"{x:1386,y:902,t:1527621195112};\\\", \\\"{x:1386,y:900,t:1527621195172};\\\", \\\"{x:1386,y:899,t:1527621195292};\\\", \\\"{x:1387,y:897,t:1527621195314};\\\", \\\"{x:1390,y:894,t:1527621195330};\\\", \\\"{x:1395,y:888,t:1527621195347};\\\", \\\"{x:1400,y:883,t:1527621195363};\\\", \\\"{x:1414,y:873,t:1527621195380};\\\", \\\"{x:1427,y:863,t:1527621195397};\\\", \\\"{x:1434,y:857,t:1527621195414};\\\", \\\"{x:1441,y:851,t:1527621195430};\\\", \\\"{x:1445,y:849,t:1527621195447};\\\", \\\"{x:1451,y:843,t:1527621195464};\\\", \\\"{x:1456,y:838,t:1527621195480};\\\", \\\"{x:1463,y:833,t:1527621195496};\\\", \\\"{x:1469,y:829,t:1527621195514};\\\", \\\"{x:1470,y:829,t:1527621195530};\\\", \\\"{x:1472,y:827,t:1527621195547};\\\", \\\"{x:1473,y:826,t:1527621195564};\\\", \\\"{x:1474,y:825,t:1527621195892};\\\", \\\"{x:1474,y:824,t:1527621195900};\\\", \\\"{x:1475,y:824,t:1527621195913};\\\", \\\"{x:1476,y:824,t:1527621195940};\\\", \\\"{x:1477,y:824,t:1527621195956};\\\", \\\"{x:1478,y:824,t:1527621195972};\\\", \\\"{x:1479,y:824,t:1527621195996};\\\", \\\"{x:1480,y:824,t:1527621196020};\\\", \\\"{x:1481,y:824,t:1527621196035};\\\", \\\"{x:1482,y:824,t:1527621196075};\\\", \\\"{x:1484,y:825,t:1527621196091};\\\", \\\"{x:1485,y:826,t:1527621196139};\\\", \\\"{x:1486,y:827,t:1527621196163};\\\", \\\"{x:1487,y:828,t:1527621196181};\\\", \\\"{x:1488,y:829,t:1527621196197};\\\", \\\"{x:1492,y:832,t:1527621196213};\\\", \\\"{x:1493,y:834,t:1527621196230};\\\", \\\"{x:1493,y:835,t:1527621196260};\\\", \\\"{x:1493,y:836,t:1527621197076};\\\", \\\"{x:1493,y:843,t:1527621197084};\\\", \\\"{x:1495,y:850,t:1527621197098};\\\", \\\"{x:1495,y:864,t:1527621197116};\\\", \\\"{x:1495,y:869,t:1527621197131};\\\", \\\"{x:1496,y:885,t:1527621197149};\\\", \\\"{x:1497,y:893,t:1527621197165};\\\", \\\"{x:1497,y:901,t:1527621197181};\\\", \\\"{x:1497,y:906,t:1527621197198};\\\", \\\"{x:1497,y:912,t:1527621197216};\\\", \\\"{x:1497,y:917,t:1527621197232};\\\", \\\"{x:1497,y:921,t:1527621197247};\\\", \\\"{x:1497,y:926,t:1527621197265};\\\", \\\"{x:1496,y:934,t:1527621197282};\\\", \\\"{x:1494,y:943,t:1527621197298};\\\", \\\"{x:1494,y:947,t:1527621197314};\\\", \\\"{x:1492,y:957,t:1527621197332};\\\", \\\"{x:1492,y:961,t:1527621197348};\\\", \\\"{x:1491,y:964,t:1527621197365};\\\", \\\"{x:1491,y:966,t:1527621197382};\\\", \\\"{x:1490,y:969,t:1527621197398};\\\", \\\"{x:1490,y:971,t:1527621197428};\\\", \\\"{x:1489,y:971,t:1527621197444};\\\", \\\"{x:1488,y:971,t:1527621198092};\\\", \\\"{x:1487,y:968,t:1527621198181};\\\", \\\"{x:1484,y:962,t:1527621198199};\\\", \\\"{x:1479,y:955,t:1527621198215};\\\", \\\"{x:1466,y:941,t:1527621198231};\\\", \\\"{x:1443,y:922,t:1527621198249};\\\", \\\"{x:1402,y:896,t:1527621198265};\\\", \\\"{x:1347,y:862,t:1527621198281};\\\", \\\"{x:1259,y:827,t:1527621198298};\\\", \\\"{x:1111,y:777,t:1527621198315};\\\", \\\"{x:1005,y:744,t:1527621198332};\\\", \\\"{x:908,y:716,t:1527621198348};\\\", \\\"{x:818,y:695,t:1527621198365};\\\", \\\"{x:732,y:674,t:1527621198382};\\\", \\\"{x:674,y:660,t:1527621198398};\\\", \\\"{x:653,y:653,t:1527621198415};\\\", \\\"{x:645,y:648,t:1527621198431};\\\", \\\"{x:641,y:644,t:1527621198448};\\\", \\\"{x:637,y:639,t:1527621198465};\\\", \\\"{x:631,y:626,t:1527621198483};\\\", \\\"{x:627,y:616,t:1527621198498};\\\", \\\"{x:617,y:597,t:1527621198515};\\\", \\\"{x:616,y:594,t:1527621198532};\\\", \\\"{x:616,y:590,t:1527621198548};\\\", \\\"{x:616,y:585,t:1527621198565};\\\", \\\"{x:619,y:579,t:1527621198582};\\\", \\\"{x:627,y:575,t:1527621198598};\\\", \\\"{x:633,y:572,t:1527621198615};\\\", \\\"{x:641,y:567,t:1527621198632};\\\", \\\"{x:656,y:563,t:1527621198648};\\\", \\\"{x:667,y:563,t:1527621198666};\\\", \\\"{x:673,y:562,t:1527621198683};\\\", \\\"{x:678,y:561,t:1527621198699};\\\", \\\"{x:677,y:561,t:1527621198739};\\\", \\\"{x:672,y:561,t:1527621198748};\\\", \\\"{x:660,y:561,t:1527621198766};\\\", \\\"{x:640,y:567,t:1527621198783};\\\", \\\"{x:626,y:573,t:1527621198799};\\\", \\\"{x:592,y:580,t:1527621198815};\\\", \\\"{x:561,y:590,t:1527621198832};\\\", \\\"{x:527,y:595,t:1527621198850};\\\", \\\"{x:504,y:599,t:1527621198865};\\\", \\\"{x:485,y:601,t:1527621198882};\\\", \\\"{x:461,y:603,t:1527621198899};\\\", \\\"{x:457,y:603,t:1527621198915};\\\", \\\"{x:456,y:605,t:1527621198932};\\\", \\\"{x:455,y:605,t:1527621198963};\\\", \\\"{x:453,y:606,t:1527621198971};\\\", \\\"{x:447,y:606,t:1527621198982};\\\", \\\"{x:425,y:606,t:1527621198999};\\\", \\\"{x:404,y:603,t:1527621199015};\\\", \\\"{x:390,y:597,t:1527621199033};\\\", \\\"{x:374,y:593,t:1527621199049};\\\", \\\"{x:369,y:592,t:1527621199065};\\\", \\\"{x:368,y:592,t:1527621199083};\\\", \\\"{x:372,y:590,t:1527621199147};\\\", \\\"{x:383,y:588,t:1527621199155};\\\", \\\"{x:399,y:583,t:1527621199165};\\\", \\\"{x:431,y:583,t:1527621199183};\\\", \\\"{x:496,y:579,t:1527621199199};\\\", \\\"{x:549,y:579,t:1527621199216};\\\", \\\"{x:567,y:575,t:1527621199232};\\\", \\\"{x:580,y:576,t:1527621199249};\\\", \\\"{x:583,y:576,t:1527621199266};\\\", \\\"{x:584,y:576,t:1527621199364};\\\", \\\"{x:585,y:576,t:1527621199452};\\\", \\\"{x:586,y:575,t:1527621199467};\\\", \\\"{x:586,y:577,t:1527621199756};\\\", \\\"{x:586,y:581,t:1527621199766};\\\", \\\"{x:581,y:590,t:1527621199783};\\\", \\\"{x:579,y:595,t:1527621199802};\\\", \\\"{x:579,y:597,t:1527621199816};\\\", \\\"{x:581,y:596,t:1527621199981};\\\", \\\"{x:584,y:594,t:1527621199987};\\\", \\\"{x:588,y:592,t:1527621200002};\\\", \\\"{x:596,y:588,t:1527621200016};\\\", \\\"{x:599,y:587,t:1527621200033};\\\", \\\"{x:600,y:586,t:1527621200050};\\\", \\\"{x:597,y:588,t:1527621200436};\\\", \\\"{x:590,y:595,t:1527621200450};\\\", \\\"{x:576,y:610,t:1527621200467};\\\", \\\"{x:570,y:618,t:1527621200483};\\\", \\\"{x:561,y:631,t:1527621200500};\\\", \\\"{x:554,y:645,t:1527621200517};\\\", \\\"{x:546,y:658,t:1527621200533};\\\", \\\"{x:537,y:673,t:1527621200551};\\\", \\\"{x:532,y:678,t:1527621200567};\\\", \\\"{x:531,y:683,t:1527621200587};\\\", \\\"{x:529,y:685,t:1527621200600};\\\", \\\"{x:527,y:692,t:1527621200618};\\\", \\\"{x:527,y:694,t:1527621200634};\\\", \\\"{x:525,y:698,t:1527621200650};\\\", \\\"{x:523,y:702,t:1527621200668};\\\", \\\"{x:522,y:704,t:1527621200685};\\\", \\\"{x:522,y:705,t:1527621200755};\\\", \\\"{x:522,y:706,t:1527621200767};\\\", \\\"{x:517,y:715,t:1527621200785};\\\", \\\"{x:516,y:720,t:1527621200802};\\\", \\\"{x:515,y:721,t:1527621200817};\\\", \\\"{x:513,y:724,t:1527621200844};\\\", \\\"{x:513,y:725,t:1527621200884};\\\", \\\"{x:513,y:726,t:1527621200894};\\\", \\\"{x:511,y:730,t:1527621200910};\\\", \\\"{x:509,y:733,t:1527621200927};\\\", \\\"{x:509,y:734,t:1527621201182};\\\", \\\"{x:509,y:734,t:1527621201223};\\\", \\\"{x:507,y:734,t:1527621201277};\\\", \\\"{x:507,y:733,t:1527621201293};\\\", \\\"{x:507,y:732,t:1527621201332};\\\", \\\"{x:507,y:727,t:1527621201348};\\\", \\\"{x:508,y:720,t:1527621201361};\\\", \\\"{x:512,y:709,t:1527621201377};\\\", \\\"{x:516,y:696,t:1527621201394};\\\", \\\"{x:521,y:682,t:1527621201411};\\\", \\\"{x:524,y:672,t:1527621201427};\\\", \\\"{x:524,y:652,t:1527621201444};\\\", \\\"{x:522,y:631,t:1527621201461};\\\", \\\"{x:518,y:614,t:1527621201477};\\\", \\\"{x:514,y:601,t:1527621201494};\\\", \\\"{x:511,y:591,t:1527621201511};\\\", \\\"{x:509,y:588,t:1527621201527};\\\", \\\"{x:508,y:585,t:1527621201544};\\\", \\\"{x:506,y:583,t:1527621201562};\\\", \\\"{x:506,y:582,t:1527621201577};\\\", \\\"{x:506,y:580,t:1527621201594};\\\", \\\"{x:506,y:579,t:1527621201611};\\\", \\\"{x:504,y:578,t:1527621201627};\\\", \\\"{x:504,y:577,t:1527621201644};\\\", \\\"{x:504,y:574,t:1527621201661};\\\", \\\"{x:503,y:573,t:1527621201677};\\\", \\\"{x:503,y:571,t:1527621201695};\\\" ] }, { \\\"rt\\\": 50878, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 652261, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -J -M -M -X -X -X -X -02 PM-02 PM-C -G -G -G -I -I -E -F -F -F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:570,t:1527621202411};\\\", \\\"{x:499,y:565,t:1527621207829};\\\", \\\"{x:474,y:527,t:1527621207839};\\\", \\\"{x:454,y:479,t:1527621207851};\\\", \\\"{x:446,y:461,t:1527621207866};\\\", \\\"{x:445,y:460,t:1527621207933};\\\", \\\"{x:453,y:460,t:1527621207965};\\\", \\\"{x:458,y:455,t:1527621207972};\\\", \\\"{x:458,y:449,t:1527621207983};\\\", \\\"{x:465,y:442,t:1527621207999};\\\", \\\"{x:469,y:443,t:1527621208125};\\\", \\\"{x:473,y:449,t:1527621208132};\\\", \\\"{x:480,y:456,t:1527621208149};\\\", \\\"{x:496,y:467,t:1527621208166};\\\", \\\"{x:521,y:487,t:1527621208184};\\\", \\\"{x:540,y:502,t:1527621208199};\\\", \\\"{x:570,y:525,t:1527621208216};\\\", \\\"{x:596,y:559,t:1527621208232};\\\", \\\"{x:620,y:596,t:1527621208249};\\\", \\\"{x:640,y:627,t:1527621208267};\\\", \\\"{x:655,y:654,t:1527621208283};\\\", \\\"{x:655,y:655,t:1527621208299};\\\", \\\"{x:654,y:655,t:1527621208797};\\\", \\\"{x:651,y:655,t:1527621208805};\\\", \\\"{x:650,y:655,t:1527621208817};\\\", \\\"{x:644,y:653,t:1527621208834};\\\", \\\"{x:642,y:652,t:1527621208850};\\\", \\\"{x:640,y:652,t:1527621208867};\\\", \\\"{x:640,y:650,t:1527621208883};\\\", \\\"{x:640,y:648,t:1527621208926};\\\", \\\"{x:640,y:647,t:1527621208949};\\\", \\\"{x:645,y:644,t:1527621208965};\\\", \\\"{x:652,y:642,t:1527621208973};\\\", \\\"{x:660,y:640,t:1527621208984};\\\", \\\"{x:680,y:638,t:1527621209001};\\\", \\\"{x:705,y:636,t:1527621209018};\\\", \\\"{x:738,y:634,t:1527621209033};\\\", \\\"{x:811,y:634,t:1527621209051};\\\", \\\"{x:890,y:641,t:1527621209068};\\\", \\\"{x:976,y:652,t:1527621209084};\\\", \\\"{x:1068,y:675,t:1527621209102};\\\", \\\"{x:1127,y:694,t:1527621209118};\\\", \\\"{x:1192,y:709,t:1527621209134};\\\", \\\"{x:1232,y:730,t:1527621209151};\\\", \\\"{x:1266,y:745,t:1527621209168};\\\", \\\"{x:1309,y:758,t:1527621209185};\\\", \\\"{x:1333,y:769,t:1527621209201};\\\", \\\"{x:1355,y:772,t:1527621209218};\\\", \\\"{x:1366,y:777,t:1527621209237};\\\", \\\"{x:1372,y:781,t:1527621209251};\\\", \\\"{x:1375,y:784,t:1527621209268};\\\", \\\"{x:1378,y:784,t:1527621209284};\\\", \\\"{x:1379,y:784,t:1527621209750};\\\", \\\"{x:1379,y:785,t:1527621209757};\\\", \\\"{x:1377,y:785,t:1527621209768};\\\", \\\"{x:1371,y:785,t:1527621209785};\\\", \\\"{x:1355,y:783,t:1527621209802};\\\", \\\"{x:1340,y:782,t:1527621209818};\\\", \\\"{x:1337,y:781,t:1527621209835};\\\", \\\"{x:1336,y:781,t:1527621209869};\\\", \\\"{x:1337,y:779,t:1527621210070};\\\", \\\"{x:1340,y:778,t:1527621210086};\\\", \\\"{x:1344,y:775,t:1527621210102};\\\", \\\"{x:1347,y:775,t:1527621210119};\\\", \\\"{x:1348,y:774,t:1527621210135};\\\", \\\"{x:1350,y:774,t:1527621210152};\\\", \\\"{x:1350,y:773,t:1527621210169};\\\", \\\"{x:1351,y:773,t:1527621210185};\\\", \\\"{x:1353,y:771,t:1527621210398};\\\", \\\"{x:1353,y:769,t:1527621210413};\\\", \\\"{x:1354,y:767,t:1527621210422};\\\", \\\"{x:1354,y:766,t:1527621210437};\\\", \\\"{x:1354,y:765,t:1527621210453};\\\", \\\"{x:1354,y:763,t:1527621210470};\\\", \\\"{x:1354,y:762,t:1527621210486};\\\", \\\"{x:1354,y:761,t:1527621210502};\\\", \\\"{x:1354,y:760,t:1527621210718};\\\", \\\"{x:1354,y:759,t:1527621210737};\\\", \\\"{x:1351,y:759,t:1527621210755};\\\", \\\"{x:1350,y:759,t:1527621210981};\\\", \\\"{x:1349,y:759,t:1527621213045};\\\", \\\"{x:1349,y:757,t:1527621214175};\\\", \\\"{x:1351,y:751,t:1527621214190};\\\", \\\"{x:1351,y:744,t:1527621214206};\\\", \\\"{x:1352,y:740,t:1527621214223};\\\", \\\"{x:1353,y:736,t:1527621214239};\\\", \\\"{x:1353,y:735,t:1527621214256};\\\", \\\"{x:1353,y:734,t:1527621214272};\\\", \\\"{x:1353,y:733,t:1527621214292};\\\", \\\"{x:1353,y:732,t:1527621214373};\\\", \\\"{x:1354,y:731,t:1527621214412};\\\", \\\"{x:1354,y:730,t:1527621214429};\\\", \\\"{x:1354,y:729,t:1527621214439};\\\", \\\"{x:1354,y:727,t:1527621214456};\\\", \\\"{x:1356,y:723,t:1527621214472};\\\", \\\"{x:1358,y:718,t:1527621214489};\\\", \\\"{x:1359,y:715,t:1527621214506};\\\", \\\"{x:1360,y:713,t:1527621214522};\\\", \\\"{x:1361,y:710,t:1527621214539};\\\", \\\"{x:1361,y:709,t:1527621214598};\\\", \\\"{x:1361,y:708,t:1527621215428};\\\", \\\"{x:1361,y:707,t:1527621215630};\\\", \\\"{x:1361,y:706,t:1527621215641};\\\", \\\"{x:1360,y:705,t:1527621215658};\\\", \\\"{x:1359,y:705,t:1527621215673};\\\", \\\"{x:1358,y:705,t:1527621215693};\\\", \\\"{x:1357,y:705,t:1527621215709};\\\", \\\"{x:1356,y:705,t:1527621215725};\\\", \\\"{x:1355,y:704,t:1527621215757};\\\", \\\"{x:1354,y:704,t:1527621215838};\\\", \\\"{x:1353,y:704,t:1527621215845};\\\", \\\"{x:1352,y:704,t:1527621215860};\\\", \\\"{x:1352,y:707,t:1527621217022};\\\", \\\"{x:1352,y:711,t:1527621217029};\\\", \\\"{x:1352,y:714,t:1527621217042};\\\", \\\"{x:1348,y:719,t:1527621217058};\\\", \\\"{x:1344,y:726,t:1527621217075};\\\", \\\"{x:1343,y:727,t:1527621217092};\\\", \\\"{x:1342,y:731,t:1527621217108};\\\", \\\"{x:1338,y:737,t:1527621217125};\\\", \\\"{x:1336,y:741,t:1527621217142};\\\", \\\"{x:1333,y:748,t:1527621217159};\\\", \\\"{x:1329,y:753,t:1527621217175};\\\", \\\"{x:1325,y:756,t:1527621217191};\\\", \\\"{x:1316,y:767,t:1527621217208};\\\", \\\"{x:1309,y:777,t:1527621217226};\\\", \\\"{x:1300,y:787,t:1527621217242};\\\", \\\"{x:1291,y:794,t:1527621217258};\\\", \\\"{x:1286,y:799,t:1527621217275};\\\", \\\"{x:1279,y:805,t:1527621217292};\\\", \\\"{x:1274,y:808,t:1527621217308};\\\", \\\"{x:1264,y:815,t:1527621217324};\\\", \\\"{x:1261,y:819,t:1527621217341};\\\", \\\"{x:1254,y:824,t:1527621217358};\\\", \\\"{x:1249,y:827,t:1527621217375};\\\", \\\"{x:1246,y:830,t:1527621217392};\\\", \\\"{x:1244,y:831,t:1527621217408};\\\", \\\"{x:1242,y:832,t:1527621217425};\\\", \\\"{x:1240,y:833,t:1527621217444};\\\", \\\"{x:1239,y:833,t:1527621217469};\\\", \\\"{x:1238,y:834,t:1527621217476};\\\", \\\"{x:1237,y:835,t:1527621217492};\\\", \\\"{x:1232,y:836,t:1527621217508};\\\", \\\"{x:1224,y:837,t:1527621217524};\\\", \\\"{x:1219,y:839,t:1527621217542};\\\", \\\"{x:1211,y:839,t:1527621217558};\\\", \\\"{x:1204,y:840,t:1527621217575};\\\", \\\"{x:1199,y:840,t:1527621217592};\\\", \\\"{x:1197,y:840,t:1527621217609};\\\", \\\"{x:1196,y:839,t:1527621217624};\\\", \\\"{x:1195,y:839,t:1527621217701};\\\", \\\"{x:1194,y:839,t:1527621217782};\\\", \\\"{x:1194,y:837,t:1527621217793};\\\", \\\"{x:1194,y:836,t:1527621217810};\\\", \\\"{x:1194,y:832,t:1527621217825};\\\", \\\"{x:1195,y:830,t:1527621217843};\\\", \\\"{x:1197,y:828,t:1527621217860};\\\", \\\"{x:1198,y:827,t:1527621217875};\\\", \\\"{x:1198,y:826,t:1527621217892};\\\", \\\"{x:1199,y:826,t:1527621217974};\\\", \\\"{x:1200,y:826,t:1527621218278};\\\", \\\"{x:1201,y:826,t:1527621218292};\\\", \\\"{x:1202,y:826,t:1527621218358};\\\", \\\"{x:1203,y:827,t:1527621218365};\\\", \\\"{x:1205,y:828,t:1527621218380};\\\", \\\"{x:1206,y:828,t:1527621218393};\\\", \\\"{x:1209,y:829,t:1527621218408};\\\", \\\"{x:1215,y:830,t:1527621218426};\\\", \\\"{x:1217,y:830,t:1527621218442};\\\", \\\"{x:1226,y:834,t:1527621218459};\\\", \\\"{x:1236,y:839,t:1527621218476};\\\", \\\"{x:1251,y:844,t:1527621218492};\\\", \\\"{x:1266,y:850,t:1527621218508};\\\", \\\"{x:1280,y:855,t:1527621218525};\\\", \\\"{x:1298,y:863,t:1527621218543};\\\", \\\"{x:1314,y:868,t:1527621218559};\\\", \\\"{x:1329,y:875,t:1527621218575};\\\", \\\"{x:1337,y:879,t:1527621218593};\\\", \\\"{x:1342,y:880,t:1527621218609};\\\", \\\"{x:1346,y:882,t:1527621218625};\\\", \\\"{x:1348,y:882,t:1527621218643};\\\", \\\"{x:1349,y:883,t:1527621219134};\\\", \\\"{x:1349,y:884,t:1527621219261};\\\", \\\"{x:1349,y:885,t:1527621219277};\\\", \\\"{x:1349,y:886,t:1527621219293};\\\", \\\"{x:1352,y:888,t:1527621219310};\\\", \\\"{x:1353,y:889,t:1527621219328};\\\", \\\"{x:1355,y:891,t:1527621219344};\\\", \\\"{x:1356,y:892,t:1527621219373};\\\", \\\"{x:1357,y:893,t:1527621219405};\\\", \\\"{x:1358,y:893,t:1527621219429};\\\", \\\"{x:1360,y:896,t:1527621219443};\\\", \\\"{x:1366,y:900,t:1527621219461};\\\", \\\"{x:1380,y:905,t:1527621219477};\\\", \\\"{x:1390,y:908,t:1527621219495};\\\", \\\"{x:1398,y:912,t:1527621219510};\\\", \\\"{x:1394,y:912,t:1527621219821};\\\", \\\"{x:1392,y:911,t:1527621219829};\\\", \\\"{x:1391,y:909,t:1527621219844};\\\", \\\"{x:1386,y:905,t:1527621219860};\\\", \\\"{x:1383,y:899,t:1527621219877};\\\", \\\"{x:1379,y:893,t:1527621219893};\\\", \\\"{x:1378,y:890,t:1527621219911};\\\", \\\"{x:1377,y:888,t:1527621219927};\\\", \\\"{x:1376,y:887,t:1527621219944};\\\", \\\"{x:1376,y:886,t:1527621219972};\\\", \\\"{x:1377,y:884,t:1527621220294};\\\", \\\"{x:1387,y:879,t:1527621220311};\\\", \\\"{x:1396,y:877,t:1527621220329};\\\", \\\"{x:1403,y:872,t:1527621220345};\\\", \\\"{x:1408,y:870,t:1527621220361};\\\", \\\"{x:1411,y:868,t:1527621220378};\\\", \\\"{x:1412,y:867,t:1527621220405};\\\", \\\"{x:1414,y:866,t:1527621220429};\\\", \\\"{x:1418,y:863,t:1527621220445};\\\", \\\"{x:1427,y:859,t:1527621220461};\\\", \\\"{x:1435,y:856,t:1527621220478};\\\", \\\"{x:1442,y:852,t:1527621220495};\\\", \\\"{x:1447,y:848,t:1527621220512};\\\", \\\"{x:1453,y:848,t:1527621220528};\\\", \\\"{x:1456,y:845,t:1527621220544};\\\", \\\"{x:1457,y:845,t:1527621220562};\\\", \\\"{x:1458,y:844,t:1527621220662};\\\", \\\"{x:1459,y:843,t:1527621220679};\\\", \\\"{x:1461,y:841,t:1527621220696};\\\", \\\"{x:1464,y:839,t:1527621220711};\\\", \\\"{x:1467,y:837,t:1527621220728};\\\", \\\"{x:1470,y:834,t:1527621220745};\\\", \\\"{x:1474,y:831,t:1527621220762};\\\", \\\"{x:1477,y:827,t:1527621220779};\\\", \\\"{x:1482,y:824,t:1527621220796};\\\", \\\"{x:1486,y:820,t:1527621220812};\\\", \\\"{x:1490,y:817,t:1527621220829};\\\", \\\"{x:1492,y:816,t:1527621220845};\\\", \\\"{x:1491,y:816,t:1527621221054};\\\", \\\"{x:1490,y:816,t:1527621221062};\\\", \\\"{x:1487,y:817,t:1527621221078};\\\", \\\"{x:1486,y:818,t:1527621221100};\\\", \\\"{x:1485,y:819,t:1527621221286};\\\", \\\"{x:1483,y:821,t:1527621221334};\\\", \\\"{x:1483,y:822,t:1527621221346};\\\", \\\"{x:1481,y:828,t:1527621221363};\\\", \\\"{x:1481,y:829,t:1527621221379};\\\", \\\"{x:1481,y:830,t:1527621221397};\\\", \\\"{x:1481,y:831,t:1527621221421};\\\", \\\"{x:1481,y:832,t:1527621221453};\\\", \\\"{x:1481,y:833,t:1527621221469};\\\", \\\"{x:1482,y:835,t:1527621221613};\\\", \\\"{x:1482,y:836,t:1527621221629};\\\", \\\"{x:1482,y:840,t:1527621221645};\\\", \\\"{x:1483,y:844,t:1527621221662};\\\", \\\"{x:1483,y:850,t:1527621221678};\\\", \\\"{x:1484,y:860,t:1527621221695};\\\", \\\"{x:1486,y:874,t:1527621221711};\\\", \\\"{x:1492,y:888,t:1527621221729};\\\", \\\"{x:1492,y:904,t:1527621221745};\\\", \\\"{x:1494,y:922,t:1527621221762};\\\", \\\"{x:1494,y:936,t:1527621221779};\\\", \\\"{x:1494,y:954,t:1527621221796};\\\", \\\"{x:1498,y:969,t:1527621221812};\\\", \\\"{x:1499,y:985,t:1527621221829};\\\", \\\"{x:1499,y:988,t:1527621221846};\\\", \\\"{x:1500,y:990,t:1527621221862};\\\", \\\"{x:1501,y:990,t:1527621221917};\\\", \\\"{x:1500,y:984,t:1527621222734};\\\", \\\"{x:1500,y:977,t:1527621222746};\\\", \\\"{x:1500,y:966,t:1527621222764};\\\", \\\"{x:1500,y:957,t:1527621222781};\\\", \\\"{x:1500,y:949,t:1527621222797};\\\", \\\"{x:1501,y:944,t:1527621222814};\\\", \\\"{x:1501,y:935,t:1527621222830};\\\", \\\"{x:1501,y:929,t:1527621222846};\\\", \\\"{x:1501,y:925,t:1527621222863};\\\", \\\"{x:1501,y:922,t:1527621222880};\\\", \\\"{x:1501,y:916,t:1527621222897};\\\", \\\"{x:1502,y:910,t:1527621222912};\\\", \\\"{x:1502,y:904,t:1527621222930};\\\", \\\"{x:1503,y:896,t:1527621222947};\\\", \\\"{x:1503,y:871,t:1527621222963};\\\", \\\"{x:1503,y:850,t:1527621222980};\\\", \\\"{x:1500,y:833,t:1527621222996};\\\", \\\"{x:1498,y:818,t:1527621223013};\\\", \\\"{x:1494,y:797,t:1527621223030};\\\", \\\"{x:1490,y:778,t:1527621223047};\\\", \\\"{x:1485,y:762,t:1527621223063};\\\", \\\"{x:1484,y:756,t:1527621223080};\\\", \\\"{x:1484,y:754,t:1527621223096};\\\", \\\"{x:1484,y:753,t:1527621223113};\\\", \\\"{x:1484,y:736,t:1527621223701};\\\", \\\"{x:1480,y:725,t:1527621223714};\\\", \\\"{x:1477,y:712,t:1527621223732};\\\", \\\"{x:1475,y:699,t:1527621223748};\\\", \\\"{x:1468,y:683,t:1527621223765};\\\", \\\"{x:1465,y:661,t:1527621223781};\\\", \\\"{x:1465,y:654,t:1527621223798};\\\", \\\"{x:1465,y:644,t:1527621223815};\\\", \\\"{x:1465,y:630,t:1527621223832};\\\", \\\"{x:1466,y:626,t:1527621223848};\\\", \\\"{x:1466,y:622,t:1527621223864};\\\", \\\"{x:1464,y:619,t:1527621223882};\\\", \\\"{x:1461,y:615,t:1527621223897};\\\", \\\"{x:1458,y:612,t:1527621223914};\\\", \\\"{x:1458,y:611,t:1527621223931};\\\", \\\"{x:1457,y:611,t:1527621223998};\\\", \\\"{x:1455,y:611,t:1527621224015};\\\", \\\"{x:1452,y:611,t:1527621224031};\\\", \\\"{x:1451,y:611,t:1527621224049};\\\", \\\"{x:1449,y:610,t:1527621224142};\\\", \\\"{x:1448,y:604,t:1527621224149};\\\", \\\"{x:1442,y:595,t:1527621224165};\\\", \\\"{x:1436,y:583,t:1527621224181};\\\", \\\"{x:1432,y:573,t:1527621224199};\\\", \\\"{x:1428,y:568,t:1527621224215};\\\", \\\"{x:1426,y:566,t:1527621224231};\\\", \\\"{x:1424,y:563,t:1527621224249};\\\", \\\"{x:1413,y:561,t:1527621224265};\\\", \\\"{x:1402,y:558,t:1527621224283};\\\", \\\"{x:1399,y:557,t:1527621224299};\\\", \\\"{x:1398,y:557,t:1527621224315};\\\", \\\"{x:1398,y:555,t:1527621224598};\\\", \\\"{x:1406,y:555,t:1527621224616};\\\", \\\"{x:1407,y:555,t:1527621224878};\\\", \\\"{x:1409,y:555,t:1527621224893};\\\", \\\"{x:1410,y:555,t:1527621226068};\\\", \\\"{x:1410,y:556,t:1527621226082};\\\", \\\"{x:1410,y:558,t:1527621226100};\\\", \\\"{x:1410,y:564,t:1527621226117};\\\", \\\"{x:1409,y:569,t:1527621226132};\\\", \\\"{x:1409,y:570,t:1527621226149};\\\", \\\"{x:1408,y:571,t:1527621226166};\\\", \\\"{x:1407,y:572,t:1527621226183};\\\", \\\"{x:1407,y:574,t:1527621226199};\\\", \\\"{x:1407,y:575,t:1527621226261};\\\", \\\"{x:1408,y:575,t:1527621226605};\\\", \\\"{x:1409,y:574,t:1527621226617};\\\", \\\"{x:1409,y:572,t:1527621226634};\\\", \\\"{x:1411,y:570,t:1527621226650};\\\", \\\"{x:1411,y:569,t:1527621226666};\\\", \\\"{x:1403,y:569,t:1527621226926};\\\", \\\"{x:1391,y:569,t:1527621226933};\\\", \\\"{x:1370,y:571,t:1527621226950};\\\", \\\"{x:1351,y:578,t:1527621226967};\\\", \\\"{x:1324,y:587,t:1527621226984};\\\", \\\"{x:1301,y:597,t:1527621227000};\\\", \\\"{x:1280,y:602,t:1527621227017};\\\", \\\"{x:1269,y:605,t:1527621227033};\\\", \\\"{x:1256,y:612,t:1527621227050};\\\", \\\"{x:1246,y:618,t:1527621227068};\\\", \\\"{x:1240,y:623,t:1527621227083};\\\", \\\"{x:1230,y:639,t:1527621227100};\\\", \\\"{x:1226,y:650,t:1527621227117};\\\", \\\"{x:1222,y:663,t:1527621227134};\\\", \\\"{x:1217,y:679,t:1527621227151};\\\", \\\"{x:1212,y:688,t:1527621227167};\\\", \\\"{x:1207,y:702,t:1527621227184};\\\", \\\"{x:1200,y:712,t:1527621227201};\\\", \\\"{x:1190,y:725,t:1527621227217};\\\", \\\"{x:1181,y:734,t:1527621227235};\\\", \\\"{x:1174,y:742,t:1527621227251};\\\", \\\"{x:1170,y:749,t:1527621227267};\\\", \\\"{x:1167,y:755,t:1527621227285};\\\", \\\"{x:1166,y:758,t:1527621227301};\\\", \\\"{x:1165,y:758,t:1527621227317};\\\", \\\"{x:1164,y:761,t:1527621227335};\\\", \\\"{x:1164,y:766,t:1527621227351};\\\", \\\"{x:1163,y:771,t:1527621227367};\\\", \\\"{x:1163,y:775,t:1527621227385};\\\", \\\"{x:1163,y:779,t:1527621227401};\\\", \\\"{x:1163,y:780,t:1527621227493};\\\", \\\"{x:1164,y:781,t:1527621227509};\\\", \\\"{x:1167,y:783,t:1527621227518};\\\", \\\"{x:1171,y:783,t:1527621227535};\\\", \\\"{x:1181,y:783,t:1527621227552};\\\", \\\"{x:1182,y:782,t:1527621227568};\\\", \\\"{x:1183,y:780,t:1527621227949};\\\", \\\"{x:1183,y:774,t:1527621227957};\\\", \\\"{x:1183,y:769,t:1527621227969};\\\", \\\"{x:1183,y:767,t:1527621227985};\\\", \\\"{x:1185,y:764,t:1527621228002};\\\", \\\"{x:1185,y:763,t:1527621228018};\\\", \\\"{x:1185,y:761,t:1527621228037};\\\", \\\"{x:1185,y:760,t:1527621228052};\\\", \\\"{x:1185,y:759,t:1527621228069};\\\", \\\"{x:1185,y:758,t:1527621228143};\\\", \\\"{x:1184,y:758,t:1527621228261};\\\", \\\"{x:1181,y:759,t:1527621228269};\\\", \\\"{x:1180,y:759,t:1527621228285};\\\", \\\"{x:1178,y:760,t:1527621228317};\\\", \\\"{x:1187,y:759,t:1527621231093};\\\", \\\"{x:1192,y:756,t:1527621231104};\\\", \\\"{x:1204,y:747,t:1527621231120};\\\", \\\"{x:1227,y:716,t:1527621231137};\\\", \\\"{x:1248,y:679,t:1527621231155};\\\", \\\"{x:1262,y:653,t:1527621231170};\\\", \\\"{x:1269,y:633,t:1527621231187};\\\", \\\"{x:1275,y:621,t:1527621231204};\\\", \\\"{x:1276,y:618,t:1527621231220};\\\", \\\"{x:1276,y:616,t:1527621231237};\\\", \\\"{x:1279,y:610,t:1527621231254};\\\", \\\"{x:1282,y:601,t:1527621231271};\\\", \\\"{x:1285,y:590,t:1527621231287};\\\", \\\"{x:1292,y:577,t:1527621231304};\\\", \\\"{x:1298,y:568,t:1527621231321};\\\", \\\"{x:1304,y:553,t:1527621231338};\\\", \\\"{x:1308,y:541,t:1527621231354};\\\", \\\"{x:1313,y:533,t:1527621231371};\\\", \\\"{x:1314,y:530,t:1527621231388};\\\", \\\"{x:1313,y:530,t:1527621231565};\\\", \\\"{x:1312,y:532,t:1527621231573};\\\", \\\"{x:1312,y:533,t:1527621231588};\\\", \\\"{x:1307,y:537,t:1527621231605};\\\", \\\"{x:1307,y:539,t:1527621231724};\\\", \\\"{x:1306,y:540,t:1527621231738};\\\", \\\"{x:1305,y:541,t:1527621231754};\\\", \\\"{x:1303,y:542,t:1527621231772};\\\", \\\"{x:1297,y:546,t:1527621231788};\\\", \\\"{x:1296,y:547,t:1527621231805};\\\", \\\"{x:1293,y:548,t:1527621232837};\\\", \\\"{x:1289,y:551,t:1527621232845};\\\", \\\"{x:1284,y:552,t:1527621232856};\\\", \\\"{x:1281,y:553,t:1527621232873};\\\", \\\"{x:1278,y:553,t:1527621232890};\\\", \\\"{x:1275,y:555,t:1527621232907};\\\", \\\"{x:1274,y:556,t:1527621232923};\\\", \\\"{x:1270,y:559,t:1527621239598};\\\", \\\"{x:1265,y:561,t:1527621239612};\\\", \\\"{x:1263,y:575,t:1527621239628};\\\", \\\"{x:1286,y:594,t:1527621239647};\\\", \\\"{x:1306,y:616,t:1527621239662};\\\", \\\"{x:1318,y:632,t:1527621239679};\\\", \\\"{x:1321,y:637,t:1527621239696};\\\", \\\"{x:1323,y:639,t:1527621239712};\\\", \\\"{x:1324,y:640,t:1527621239730};\\\", \\\"{x:1324,y:642,t:1527621239747};\\\", \\\"{x:1326,y:644,t:1527621239762};\\\", \\\"{x:1327,y:647,t:1527621239779};\\\", \\\"{x:1331,y:651,t:1527621239796};\\\", \\\"{x:1335,y:662,t:1527621239813};\\\", \\\"{x:1341,y:670,t:1527621239829};\\\", \\\"{x:1345,y:676,t:1527621239847};\\\", \\\"{x:1346,y:677,t:1527621239862};\\\", \\\"{x:1346,y:678,t:1527621239878};\\\", \\\"{x:1346,y:679,t:1527621239896};\\\", \\\"{x:1346,y:682,t:1527621239912};\\\", \\\"{x:1346,y:689,t:1527621239929};\\\", \\\"{x:1346,y:696,t:1527621239946};\\\", \\\"{x:1346,y:701,t:1527621239962};\\\", \\\"{x:1346,y:708,t:1527621239980};\\\", \\\"{x:1346,y:711,t:1527621239995};\\\", \\\"{x:1346,y:712,t:1527621240013};\\\", \\\"{x:1346,y:711,t:1527621240301};\\\", \\\"{x:1346,y:710,t:1527621240325};\\\", \\\"{x:1346,y:709,t:1527621240469};\\\", \\\"{x:1346,y:708,t:1527621240485};\\\", \\\"{x:1346,y:707,t:1527621240501};\\\", \\\"{x:1346,y:706,t:1527621240541};\\\", \\\"{x:1346,y:705,t:1527621240565};\\\", \\\"{x:1346,y:703,t:1527621240580};\\\", \\\"{x:1346,y:702,t:1527621240598};\\\", \\\"{x:1346,y:703,t:1527621241238};\\\", \\\"{x:1346,y:706,t:1527621241248};\\\", \\\"{x:1344,y:709,t:1527621241264};\\\", \\\"{x:1344,y:715,t:1527621241281};\\\", \\\"{x:1344,y:721,t:1527621241297};\\\", \\\"{x:1344,y:725,t:1527621241314};\\\", \\\"{x:1344,y:731,t:1527621241330};\\\", \\\"{x:1344,y:737,t:1527621241347};\\\", \\\"{x:1344,y:740,t:1527621241364};\\\", \\\"{x:1344,y:745,t:1527621241381};\\\", \\\"{x:1344,y:751,t:1527621241397};\\\", \\\"{x:1345,y:755,t:1527621241414};\\\", \\\"{x:1346,y:759,t:1527621241431};\\\", \\\"{x:1346,y:763,t:1527621241447};\\\", \\\"{x:1347,y:766,t:1527621241464};\\\", \\\"{x:1347,y:767,t:1527621241485};\\\", \\\"{x:1347,y:769,t:1527621241526};\\\", \\\"{x:1348,y:769,t:1527621241997};\\\", \\\"{x:1349,y:768,t:1527621242015};\\\", \\\"{x:1348,y:768,t:1527621242821};\\\", \\\"{x:1347,y:767,t:1527621242832};\\\", \\\"{x:1347,y:766,t:1527621242848};\\\", \\\"{x:1347,y:765,t:1527621242885};\\\", \\\"{x:1342,y:764,t:1527621248789};\\\", \\\"{x:1256,y:757,t:1527621248805};\\\", \\\"{x:1115,y:738,t:1527621248820};\\\", \\\"{x:966,y:717,t:1527621248836};\\\", \\\"{x:819,y:695,t:1527621248854};\\\", \\\"{x:779,y:685,t:1527621248870};\\\", \\\"{x:779,y:684,t:1527621249268};\\\", \\\"{x:778,y:683,t:1527621249276};\\\", \\\"{x:773,y:681,t:1527621249288};\\\", \\\"{x:757,y:676,t:1527621249304};\\\", \\\"{x:744,y:673,t:1527621249321};\\\", \\\"{x:730,y:668,t:1527621249337};\\\", \\\"{x:719,y:664,t:1527621249354};\\\", \\\"{x:714,y:663,t:1527621249372};\\\", \\\"{x:687,y:658,t:1527621249387};\\\", \\\"{x:651,y:650,t:1527621249405};\\\", \\\"{x:595,y:642,t:1527621249421};\\\", \\\"{x:514,y:629,t:1527621249438};\\\", \\\"{x:435,y:615,t:1527621249454};\\\", \\\"{x:338,y:605,t:1527621249471};\\\", \\\"{x:244,y:593,t:1527621249484};\\\", \\\"{x:158,y:580,t:1527621249500};\\\", \\\"{x:73,y:563,t:1527621249517};\\\", \\\"{x:12,y:553,t:1527621249534};\\\", \\\"{x:0,y:548,t:1527621249550};\\\", \\\"{x:0,y:545,t:1527621249567};\\\", \\\"{x:0,y:544,t:1527621249732};\\\", \\\"{x:3,y:544,t:1527621249751};\\\", \\\"{x:15,y:540,t:1527621249767};\\\", \\\"{x:30,y:536,t:1527621249784};\\\", \\\"{x:56,y:535,t:1527621249802};\\\", \\\"{x:73,y:537,t:1527621249816};\\\", \\\"{x:97,y:542,t:1527621249834};\\\", \\\"{x:113,y:547,t:1527621249851};\\\", \\\"{x:114,y:552,t:1527621249867};\\\", \\\"{x:118,y:555,t:1527621249884};\\\", \\\"{x:121,y:555,t:1527621249901};\\\", \\\"{x:120,y:555,t:1527621250013};\\\", \\\"{x:119,y:555,t:1527621250029};\\\", \\\"{x:118,y:555,t:1527621250036};\\\", \\\"{x:116,y:554,t:1527621250061};\\\", \\\"{x:116,y:553,t:1527621250069};\\\", \\\"{x:118,y:548,t:1527621250084};\\\", \\\"{x:126,y:541,t:1527621250101};\\\", \\\"{x:137,y:534,t:1527621250118};\\\", \\\"{x:147,y:531,t:1527621250134};\\\", \\\"{x:150,y:529,t:1527621250152};\\\", \\\"{x:153,y:529,t:1527621250579};\\\", \\\"{x:164,y:529,t:1527621250588};\\\", \\\"{x:174,y:530,t:1527621250601};\\\", \\\"{x:203,y:532,t:1527621250618};\\\", \\\"{x:237,y:540,t:1527621250635};\\\", \\\"{x:277,y:550,t:1527621250652};\\\", \\\"{x:322,y:563,t:1527621250668};\\\", \\\"{x:365,y:572,t:1527621250684};\\\", \\\"{x:387,y:584,t:1527621250701};\\\", \\\"{x:418,y:593,t:1527621250718};\\\", \\\"{x:442,y:596,t:1527621250735};\\\", \\\"{x:473,y:605,t:1527621250751};\\\", \\\"{x:508,y:613,t:1527621250769};\\\", \\\"{x:547,y:618,t:1527621250785};\\\", \\\"{x:580,y:624,t:1527621250801};\\\", \\\"{x:619,y:628,t:1527621250818};\\\", \\\"{x:677,y:645,t:1527621250835};\\\", \\\"{x:728,y:659,t:1527621250851};\\\", \\\"{x:852,y:680,t:1527621250867};\\\", \\\"{x:917,y:692,t:1527621250885};\\\", \\\"{x:972,y:696,t:1527621250902};\\\", \\\"{x:1039,y:708,t:1527621250918};\\\", \\\"{x:1138,y:718,t:1527621250936};\\\", \\\"{x:1218,y:727,t:1527621250952};\\\", \\\"{x:1305,y:740,t:1527621250968};\\\", \\\"{x:1373,y:746,t:1527621250985};\\\", \\\"{x:1427,y:762,t:1527621251002};\\\", \\\"{x:1458,y:765,t:1527621251018};\\\", \\\"{x:1480,y:769,t:1527621251035};\\\", \\\"{x:1484,y:769,t:1527621251052};\\\", \\\"{x:1482,y:785,t:1527621251476};\\\", \\\"{x:1476,y:784,t:1527621251485};\\\", \\\"{x:1420,y:778,t:1527621251502};\\\", \\\"{x:1388,y:771,t:1527621251518};\\\", \\\"{x:1337,y:771,t:1527621251535};\\\", \\\"{x:1218,y:772,t:1527621251552};\\\", \\\"{x:1063,y:772,t:1527621251569};\\\", \\\"{x:916,y:772,t:1527621251585};\\\", \\\"{x:884,y:771,t:1527621251602};\\\", \\\"{x:881,y:771,t:1527621251619};\\\", \\\"{x:880,y:771,t:1527621251636};\\\", \\\"{x:878,y:771,t:1527621251692};\\\", \\\"{x:878,y:769,t:1527621251812};\\\", \\\"{x:876,y:767,t:1527621251837};\\\", \\\"{x:865,y:762,t:1527621251853};\\\", \\\"{x:857,y:757,t:1527621251869};\\\", \\\"{x:828,y:753,t:1527621251886};\\\", \\\"{x:774,y:748,t:1527621251902};\\\", \\\"{x:719,y:744,t:1527621251919};\\\", \\\"{x:638,y:731,t:1527621251935};\\\", \\\"{x:538,y:719,t:1527621251953};\\\", \\\"{x:461,y:712,t:1527621251970};\\\", \\\"{x:397,y:704,t:1527621251985};\\\", \\\"{x:367,y:701,t:1527621252002};\\\", \\\"{x:290,y:709,t:1527621252020};\\\", \\\"{x:203,y:717,t:1527621252035};\\\", \\\"{x:188,y:717,t:1527621252052};\\\", \\\"{x:185,y:717,t:1527621252070};\\\", \\\"{x:188,y:717,t:1527621252181};\\\", \\\"{x:211,y:717,t:1527621252188};\\\", \\\"{x:243,y:721,t:1527621252203};\\\", \\\"{x:356,y:733,t:1527621252220};\\\", \\\"{x:515,y:753,t:1527621252238};\\\", \\\"{x:587,y:771,t:1527621252252};\\\", \\\"{x:610,y:777,t:1527621252267};\\\", \\\"{x:629,y:781,t:1527621252284};\\\", \\\"{x:628,y:781,t:1527621252541};\\\", \\\"{x:626,y:781,t:1527621252551};\\\", \\\"{x:623,y:781,t:1527621252568};\\\", \\\"{x:618,y:780,t:1527621252585};\\\", \\\"{x:611,y:777,t:1527621252600};\\\", \\\"{x:608,y:775,t:1527621252617};\\\", \\\"{x:605,y:773,t:1527621252633};\\\", \\\"{x:601,y:769,t:1527621252650};\\\", \\\"{x:598,y:766,t:1527621252667};\\\", \\\"{x:592,y:766,t:1527621252684};\\\", \\\"{x:589,y:766,t:1527621252700};\\\", \\\"{x:587,y:766,t:1527621252718};\\\", \\\"{x:586,y:766,t:1527621252781};\\\", \\\"{x:584,y:766,t:1527621252829};\\\", \\\"{x:583,y:765,t:1527621252853};\\\", \\\"{x:582,y:765,t:1527621252868};\\\", \\\"{x:580,y:763,t:1527621252884};\\\", \\\"{x:576,y:761,t:1527621252900};\\\", \\\"{x:572,y:755,t:1527621252916};\\\", \\\"{x:568,y:752,t:1527621252933};\\\", \\\"{x:564,y:749,t:1527621252951};\\\", \\\"{x:561,y:746,t:1527621252968};\\\", \\\"{x:558,y:744,t:1527621252983};\\\", \\\"{x:556,y:744,t:1527621253003};\\\", \\\"{x:551,y:740,t:1527621253019};\\\", \\\"{x:549,y:739,t:1527621253037};\\\", \\\"{x:548,y:739,t:1527621253053};\\\", \\\"{x:543,y:738,t:1527621253070};\\\", \\\"{x:541,y:737,t:1527621253087};\\\", \\\"{x:538,y:737,t:1527621253103};\\\", \\\"{x:537,y:735,t:1527621253120};\\\", \\\"{x:535,y:735,t:1527621253137};\\\", \\\"{x:539,y:735,t:1527621253356};\\\", \\\"{x:562,y:735,t:1527621253370};\\\", \\\"{x:575,y:733,t:1527621253387};\\\", \\\"{x:622,y:736,t:1527621253403};\\\", \\\"{x:735,y:742,t:1527621253420};\\\", \\\"{x:763,y:741,t:1527621253437};\\\", \\\"{x:768,y:741,t:1527621253453};\\\", \\\"{x:773,y:741,t:1527621253470};\\\", \\\"{x:775,y:741,t:1527621253487};\\\", \\\"{x:775,y:742,t:1527621253532};\\\", \\\"{x:774,y:747,t:1527621254292};\\\", \\\"{x:773,y:753,t:1527621254313};\\\", \\\"{x:773,y:756,t:1527621254321};\\\", \\\"{x:772,y:765,t:1527621254337};\\\", \\\"{x:769,y:775,t:1527621254354};\\\", \\\"{x:768,y:783,t:1527621254371};\\\", \\\"{x:765,y:802,t:1527621254388};\\\" ] }, { \\\"rt\\\": 71543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 725010, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -B -B -F -12 PM-M -M -G -G -E -11 AM-11 AM-M -M -M -J -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:759,y:826,t:1527621254488};\\\", \\\"{x:761,y:820,t:1527621254845};\\\", \\\"{x:763,y:812,t:1527621254855};\\\", \\\"{x:765,y:801,t:1527621254871};\\\", \\\"{x:768,y:791,t:1527621254889};\\\", \\\"{x:776,y:745,t:1527621254986};\\\", \\\"{x:776,y:741,t:1527621254990};\\\", \\\"{x:776,y:740,t:1527621255005};\\\", \\\"{x:777,y:736,t:1527621255021};\\\", \\\"{x:777,y:733,t:1527621255038};\\\", \\\"{x:777,y:732,t:1527621255055};\\\", \\\"{x:777,y:729,t:1527621255071};\\\", \\\"{x:777,y:727,t:1527621255088};\\\", \\\"{x:777,y:726,t:1527621255177};\\\", \\\"{x:772,y:726,t:1527621255187};\\\", \\\"{x:764,y:727,t:1527621255205};\\\", \\\"{x:758,y:727,t:1527621255221};\\\", \\\"{x:755,y:729,t:1527621255239};\\\", \\\"{x:753,y:730,t:1527621255255};\\\", \\\"{x:750,y:730,t:1527621255271};\\\", \\\"{x:748,y:731,t:1527621255308};\\\", \\\"{x:747,y:731,t:1527621255321};\\\", \\\"{x:745,y:731,t:1527621255338};\\\", \\\"{x:744,y:731,t:1527621255364};\\\", \\\"{x:743,y:732,t:1527621255380};\\\", \\\"{x:743,y:733,t:1527621255412};\\\", \\\"{x:742,y:733,t:1527621255789};\\\", \\\"{x:740,y:733,t:1527621255805};\\\", \\\"{x:738,y:731,t:1527621255823};\\\", \\\"{x:737,y:731,t:1527621255839};\\\", \\\"{x:734,y:730,t:1527621255856};\\\", \\\"{x:733,y:730,t:1527621255873};\\\", \\\"{x:729,y:730,t:1527621255889};\\\", \\\"{x:728,y:730,t:1527621255905};\\\", \\\"{x:727,y:730,t:1527621255922};\\\", \\\"{x:725,y:730,t:1527621255941};\\\", \\\"{x:724,y:730,t:1527621255956};\\\", \\\"{x:717,y:730,t:1527621255973};\\\", \\\"{x:712,y:728,t:1527621255990};\\\", \\\"{x:704,y:724,t:1527621256005};\\\", \\\"{x:698,y:719,t:1527621256022};\\\", \\\"{x:695,y:712,t:1527621256039};\\\", \\\"{x:691,y:705,t:1527621256056};\\\", \\\"{x:690,y:695,t:1527621256073};\\\", \\\"{x:690,y:691,t:1527621256089};\\\", \\\"{x:690,y:684,t:1527621256106};\\\", \\\"{x:690,y:680,t:1527621256122};\\\", \\\"{x:691,y:676,t:1527621256139};\\\", \\\"{x:692,y:674,t:1527621256156};\\\", \\\"{x:694,y:669,t:1527621256172};\\\", \\\"{x:696,y:665,t:1527621256190};\\\", \\\"{x:699,y:663,t:1527621256205};\\\", \\\"{x:702,y:659,t:1527621256222};\\\", \\\"{x:704,y:658,t:1527621256240};\\\", \\\"{x:705,y:657,t:1527621256255};\\\", \\\"{x:707,y:657,t:1527621256273};\\\", \\\"{x:712,y:654,t:1527621256289};\\\", \\\"{x:718,y:653,t:1527621256306};\\\", \\\"{x:733,y:652,t:1527621256322};\\\", \\\"{x:752,y:649,t:1527621256340};\\\", \\\"{x:774,y:649,t:1527621256357};\\\", \\\"{x:797,y:648,t:1527621256372};\\\", \\\"{x:824,y:650,t:1527621256389};\\\", \\\"{x:841,y:651,t:1527621256406};\\\", \\\"{x:863,y:656,t:1527621256423};\\\", \\\"{x:881,y:657,t:1527621256440};\\\", \\\"{x:891,y:660,t:1527621256457};\\\", \\\"{x:894,y:660,t:1527621256473};\\\", \\\"{x:896,y:660,t:1527621256490};\\\", \\\"{x:897,y:660,t:1527621256507};\\\", \\\"{x:898,y:661,t:1527621256522};\\\", \\\"{x:899,y:661,t:1527621256556};\\\", \\\"{x:906,y:662,t:1527621256572};\\\", \\\"{x:914,y:662,t:1527621256590};\\\", \\\"{x:923,y:665,t:1527621256607};\\\", \\\"{x:927,y:666,t:1527621256622};\\\", \\\"{x:927,y:667,t:1527621256640};\\\", \\\"{x:928,y:668,t:1527621256656};\\\", \\\"{x:926,y:668,t:1527621257364};\\\", \\\"{x:925,y:669,t:1527621257374};\\\", \\\"{x:923,y:669,t:1527621257391};\\\", \\\"{x:922,y:671,t:1527621257407};\\\", \\\"{x:918,y:672,t:1527621257477};\\\", \\\"{x:915,y:672,t:1527621257491};\\\", \\\"{x:892,y:673,t:1527621257507};\\\", \\\"{x:870,y:673,t:1527621257523};\\\", \\\"{x:843,y:673,t:1527621257540};\\\", \\\"{x:833,y:673,t:1527621257557};\\\", \\\"{x:818,y:673,t:1527621257574};\\\", \\\"{x:810,y:673,t:1527621257590};\\\", \\\"{x:801,y:673,t:1527621257608};\\\", \\\"{x:793,y:674,t:1527621257623};\\\", \\\"{x:785,y:675,t:1527621257641};\\\", \\\"{x:776,y:675,t:1527621257658};\\\", \\\"{x:771,y:676,t:1527621257674};\\\", \\\"{x:770,y:676,t:1527621257691};\\\", \\\"{x:759,y:677,t:1527621257708};\\\", \\\"{x:752,y:677,t:1527621257723};\\\", \\\"{x:742,y:678,t:1527621257741};\\\", \\\"{x:730,y:678,t:1527621257758};\\\", \\\"{x:715,y:678,t:1527621257774};\\\", \\\"{x:703,y:676,t:1527621257791};\\\", \\\"{x:699,y:675,t:1527621257808};\\\", \\\"{x:697,y:674,t:1527621257824};\\\", \\\"{x:697,y:671,t:1527621257997};\\\", \\\"{x:697,y:670,t:1527621258013};\\\", \\\"{x:698,y:670,t:1527621258024};\\\", \\\"{x:701,y:665,t:1527621258040};\\\", \\\"{x:704,y:664,t:1527621258057};\\\", \\\"{x:708,y:662,t:1527621258073};\\\", \\\"{x:709,y:662,t:1527621258090};\\\", \\\"{x:710,y:662,t:1527621258141};\\\", \\\"{x:710,y:661,t:1527621258188};\\\", \\\"{x:711,y:661,t:1527621258213};\\\", \\\"{x:712,y:661,t:1527621258225};\\\", \\\"{x:713,y:661,t:1527621258241};\\\", \\\"{x:720,y:661,t:1527621258258};\\\", \\\"{x:729,y:659,t:1527621258275};\\\", \\\"{x:738,y:658,t:1527621258291};\\\", \\\"{x:743,y:657,t:1527621258308};\\\", \\\"{x:757,y:657,t:1527621258324};\\\", \\\"{x:769,y:657,t:1527621258340};\\\", \\\"{x:796,y:653,t:1527621258358};\\\", \\\"{x:815,y:653,t:1527621258375};\\\", \\\"{x:849,y:653,t:1527621258391};\\\", \\\"{x:885,y:655,t:1527621258407};\\\", \\\"{x:953,y:660,t:1527621258425};\\\", \\\"{x:1022,y:665,t:1527621258441};\\\", \\\"{x:1074,y:671,t:1527621258458};\\\", \\\"{x:1119,y:679,t:1527621258475};\\\", \\\"{x:1142,y:682,t:1527621258492};\\\", \\\"{x:1161,y:687,t:1527621258508};\\\", \\\"{x:1166,y:687,t:1527621258525};\\\", \\\"{x:1184,y:690,t:1527621258542};\\\", \\\"{x:1194,y:691,t:1527621258558};\\\", \\\"{x:1199,y:691,t:1527621258575};\\\", \\\"{x:1216,y:691,t:1527621258592};\\\", \\\"{x:1236,y:698,t:1527621258608};\\\", \\\"{x:1255,y:700,t:1527621258625};\\\", \\\"{x:1274,y:705,t:1527621258642};\\\", \\\"{x:1293,y:707,t:1527621258658};\\\", \\\"{x:1300,y:709,t:1527621258675};\\\", \\\"{x:1303,y:711,t:1527621258692};\\\", \\\"{x:1306,y:711,t:1527621258708};\\\", \\\"{x:1307,y:712,t:1527621258725};\\\", \\\"{x:1309,y:712,t:1527621258742};\\\", \\\"{x:1315,y:713,t:1527621258758};\\\", \\\"{x:1323,y:713,t:1527621258775};\\\", \\\"{x:1331,y:713,t:1527621258792};\\\", \\\"{x:1337,y:713,t:1527621258808};\\\", \\\"{x:1339,y:714,t:1527621258825};\\\", \\\"{x:1342,y:714,t:1527621258843};\\\", \\\"{x:1343,y:714,t:1527621258858};\\\", \\\"{x:1344,y:714,t:1527621258875};\\\", \\\"{x:1345,y:714,t:1527621258892};\\\", \\\"{x:1347,y:714,t:1527621258909};\\\", \\\"{x:1348,y:714,t:1527621258933};\\\", \\\"{x:1349,y:714,t:1527621258981};\\\", \\\"{x:1350,y:714,t:1527621258992};\\\", \\\"{x:1351,y:714,t:1527621259366};\\\", \\\"{x:1352,y:713,t:1527621259453};\\\", \\\"{x:1353,y:713,t:1527621259469};\\\", \\\"{x:1354,y:712,t:1527621259476};\\\", \\\"{x:1355,y:711,t:1527621259493};\\\", \\\"{x:1355,y:710,t:1527621259509};\\\", \\\"{x:1357,y:709,t:1527621259526};\\\", \\\"{x:1359,y:707,t:1527621259542};\\\", \\\"{x:1360,y:705,t:1527621259573};\\\", \\\"{x:1362,y:704,t:1527621259613};\\\", \\\"{x:1362,y:703,t:1527621259668};\\\", \\\"{x:1363,y:702,t:1527621260437};\\\", \\\"{x:1363,y:704,t:1527621263670};\\\", \\\"{x:1359,y:715,t:1527621263688};\\\", \\\"{x:1355,y:722,t:1527621263704};\\\", \\\"{x:1354,y:725,t:1527621263721};\\\", \\\"{x:1354,y:727,t:1527621263738};\\\", \\\"{x:1353,y:730,t:1527621263754};\\\", \\\"{x:1352,y:732,t:1527621263771};\\\", \\\"{x:1352,y:733,t:1527621263789};\\\", \\\"{x:1351,y:736,t:1527621263805};\\\", \\\"{x:1350,y:739,t:1527621263822};\\\", \\\"{x:1348,y:744,t:1527621263838};\\\", \\\"{x:1347,y:746,t:1527621263856};\\\", \\\"{x:1346,y:750,t:1527621263871};\\\", \\\"{x:1343,y:754,t:1527621263888};\\\", \\\"{x:1341,y:755,t:1527621263907};\\\", \\\"{x:1341,y:758,t:1527621263922};\\\", \\\"{x:1340,y:759,t:1527621263939};\\\", \\\"{x:1337,y:763,t:1527621263955};\\\", \\\"{x:1337,y:764,t:1527621263971};\\\", \\\"{x:1336,y:768,t:1527621263988};\\\", \\\"{x:1333,y:774,t:1527621264006};\\\", \\\"{x:1332,y:777,t:1527621264021};\\\", \\\"{x:1331,y:780,t:1527621264039};\\\", \\\"{x:1329,y:781,t:1527621264056};\\\", \\\"{x:1329,y:783,t:1527621264072};\\\", \\\"{x:1327,y:785,t:1527621264089};\\\", \\\"{x:1327,y:786,t:1527621264105};\\\", \\\"{x:1327,y:787,t:1527621264126};\\\", \\\"{x:1326,y:789,t:1527621264138};\\\", \\\"{x:1326,y:791,t:1527621264155};\\\", \\\"{x:1326,y:793,t:1527621264171};\\\", \\\"{x:1326,y:794,t:1527621264188};\\\", \\\"{x:1326,y:797,t:1527621264205};\\\", \\\"{x:1326,y:800,t:1527621264230};\\\", \\\"{x:1326,y:803,t:1527621264246};\\\", \\\"{x:1327,y:806,t:1527621264255};\\\", \\\"{x:1329,y:812,t:1527621264273};\\\", \\\"{x:1330,y:814,t:1527621264288};\\\", \\\"{x:1332,y:816,t:1527621264306};\\\", \\\"{x:1332,y:819,t:1527621264325};\\\", \\\"{x:1332,y:820,t:1527621264341};\\\", \\\"{x:1333,y:820,t:1527621264373};\\\", \\\"{x:1334,y:820,t:1527621264502};\\\", \\\"{x:1334,y:813,t:1527621264509};\\\", \\\"{x:1333,y:808,t:1527621264522};\\\", \\\"{x:1332,y:799,t:1527621264538};\\\", \\\"{x:1329,y:787,t:1527621264556};\\\", \\\"{x:1328,y:776,t:1527621264572};\\\", \\\"{x:1325,y:760,t:1527621264588};\\\", \\\"{x:1323,y:748,t:1527621264606};\\\", \\\"{x:1323,y:742,t:1527621264622};\\\", \\\"{x:1323,y:734,t:1527621264640};\\\", \\\"{x:1323,y:728,t:1527621264656};\\\", \\\"{x:1323,y:723,t:1527621264672};\\\", \\\"{x:1323,y:719,t:1527621264689};\\\", \\\"{x:1323,y:714,t:1527621264705};\\\", \\\"{x:1323,y:710,t:1527621264723};\\\", \\\"{x:1323,y:707,t:1527621264740};\\\", \\\"{x:1324,y:704,t:1527621264755};\\\", \\\"{x:1325,y:700,t:1527621264772};\\\", \\\"{x:1326,y:697,t:1527621264789};\\\", \\\"{x:1329,y:696,t:1527621264805};\\\", \\\"{x:1331,y:693,t:1527621264823};\\\", \\\"{x:1332,y:692,t:1527621264839};\\\", \\\"{x:1334,y:691,t:1527621264870};\\\", \\\"{x:1336,y:690,t:1527621264910};\\\", \\\"{x:1337,y:690,t:1527621264922};\\\", \\\"{x:1338,y:690,t:1527621264940};\\\", \\\"{x:1341,y:690,t:1527621264955};\\\", \\\"{x:1343,y:690,t:1527621264973};\\\", \\\"{x:1345,y:690,t:1527621264989};\\\", \\\"{x:1347,y:690,t:1527621265006};\\\", \\\"{x:1348,y:690,t:1527621265022};\\\", \\\"{x:1351,y:692,t:1527621265042};\\\", \\\"{x:1353,y:694,t:1527621265056};\\\", \\\"{x:1355,y:696,t:1527621265073};\\\", \\\"{x:1357,y:697,t:1527621265089};\\\", \\\"{x:1357,y:698,t:1527621265109};\\\", \\\"{x:1357,y:699,t:1527621265157};\\\", \\\"{x:1358,y:699,t:1527621265173};\\\", \\\"{x:1358,y:700,t:1527621265221};\\\", \\\"{x:1358,y:703,t:1527621265239};\\\", \\\"{x:1359,y:706,t:1527621265256};\\\", \\\"{x:1359,y:708,t:1527621265272};\\\", \\\"{x:1359,y:714,t:1527621265289};\\\", \\\"{x:1359,y:720,t:1527621265307};\\\", \\\"{x:1359,y:724,t:1527621265326};\\\", \\\"{x:1359,y:726,t:1527621265341};\\\", \\\"{x:1359,y:727,t:1527621265356};\\\", \\\"{x:1359,y:728,t:1527621265372};\\\", \\\"{x:1359,y:731,t:1527621265389};\\\", \\\"{x:1358,y:735,t:1527621265406};\\\", \\\"{x:1357,y:740,t:1527621265422};\\\", \\\"{x:1357,y:741,t:1527621265439};\\\", \\\"{x:1356,y:746,t:1527621265456};\\\", \\\"{x:1356,y:748,t:1527621265472};\\\", \\\"{x:1355,y:752,t:1527621265489};\\\", \\\"{x:1355,y:754,t:1527621265506};\\\", \\\"{x:1353,y:757,t:1527621265523};\\\", \\\"{x:1352,y:761,t:1527621265540};\\\", \\\"{x:1351,y:762,t:1527621265556};\\\", \\\"{x:1349,y:765,t:1527621265573};\\\", \\\"{x:1349,y:767,t:1527621265589};\\\", \\\"{x:1347,y:771,t:1527621265607};\\\", \\\"{x:1347,y:773,t:1527621265623};\\\", \\\"{x:1346,y:775,t:1527621265639};\\\", \\\"{x:1345,y:778,t:1527621265657};\\\", \\\"{x:1345,y:779,t:1527621265673};\\\", \\\"{x:1344,y:782,t:1527621265690};\\\", \\\"{x:1344,y:784,t:1527621265707};\\\", \\\"{x:1344,y:785,t:1527621265726};\\\", \\\"{x:1343,y:786,t:1527621265740};\\\", \\\"{x:1343,y:787,t:1527621265757};\\\", \\\"{x:1343,y:789,t:1527621265790};\\\", \\\"{x:1343,y:791,t:1527621265807};\\\", \\\"{x:1343,y:793,t:1527621265838};\\\", \\\"{x:1343,y:795,t:1527621265854};\\\", \\\"{x:1343,y:797,t:1527621265870};\\\", \\\"{x:1343,y:798,t:1527621265885};\\\", \\\"{x:1342,y:798,t:1527621265893};\\\", \\\"{x:1342,y:800,t:1527621265910};\\\", \\\"{x:1341,y:801,t:1527621265934};\\\", \\\"{x:1341,y:803,t:1527621266007};\\\", \\\"{x:1340,y:803,t:1527621266102};\\\", \\\"{x:1340,y:800,t:1527621266214};\\\", \\\"{x:1340,y:788,t:1527621266223};\\\", \\\"{x:1340,y:774,t:1527621266241};\\\", \\\"{x:1341,y:764,t:1527621266257};\\\", \\\"{x:1342,y:759,t:1527621266273};\\\", \\\"{x:1342,y:756,t:1527621266291};\\\", \\\"{x:1342,y:754,t:1527621266306};\\\", \\\"{x:1342,y:751,t:1527621266325};\\\", \\\"{x:1343,y:749,t:1527621266342};\\\", \\\"{x:1344,y:747,t:1527621266357};\\\", \\\"{x:1346,y:742,t:1527621266374};\\\", \\\"{x:1347,y:737,t:1527621266390};\\\", \\\"{x:1349,y:733,t:1527621266408};\\\", \\\"{x:1349,y:728,t:1527621266423};\\\", \\\"{x:1350,y:721,t:1527621266441};\\\", \\\"{x:1350,y:716,t:1527621266458};\\\", \\\"{x:1350,y:709,t:1527621266474};\\\", \\\"{x:1350,y:705,t:1527621266491};\\\", \\\"{x:1350,y:702,t:1527621266508};\\\", \\\"{x:1350,y:697,t:1527621266525};\\\", \\\"{x:1352,y:694,t:1527621266558};\\\", \\\"{x:1352,y:693,t:1527621266573};\\\", \\\"{x:1352,y:694,t:1527621266758};\\\", \\\"{x:1352,y:711,t:1527621266775};\\\", \\\"{x:1353,y:734,t:1527621266790};\\\", \\\"{x:1358,y:751,t:1527621266807};\\\", \\\"{x:1359,y:770,t:1527621266825};\\\", \\\"{x:1362,y:787,t:1527621266841};\\\", \\\"{x:1364,y:805,t:1527621266858};\\\", \\\"{x:1364,y:826,t:1527621266875};\\\", \\\"{x:1364,y:843,t:1527621266891};\\\", \\\"{x:1364,y:864,t:1527621266907};\\\", \\\"{x:1364,y:876,t:1527621266925};\\\", \\\"{x:1364,y:884,t:1527621266940};\\\", \\\"{x:1364,y:892,t:1527621266958};\\\", \\\"{x:1364,y:898,t:1527621266974};\\\", \\\"{x:1362,y:908,t:1527621266990};\\\", \\\"{x:1360,y:917,t:1527621267007};\\\", \\\"{x:1357,y:929,t:1527621267025};\\\", \\\"{x:1355,y:937,t:1527621267041};\\\", \\\"{x:1355,y:941,t:1527621267057};\\\", \\\"{x:1352,y:948,t:1527621267075};\\\", \\\"{x:1349,y:953,t:1527621267091};\\\", \\\"{x:1348,y:953,t:1527621267108};\\\", \\\"{x:1345,y:956,t:1527621267124};\\\", \\\"{x:1343,y:957,t:1527621267141};\\\", \\\"{x:1342,y:958,t:1527621267158};\\\", \\\"{x:1342,y:960,t:1527621267174};\\\", \\\"{x:1342,y:961,t:1527621267191};\\\", \\\"{x:1342,y:962,t:1527621267208};\\\", \\\"{x:1342,y:963,t:1527621267246};\\\", \\\"{x:1342,y:964,t:1527621267257};\\\", \\\"{x:1342,y:966,t:1527621267275};\\\", \\\"{x:1343,y:969,t:1527621267292};\\\", \\\"{x:1344,y:971,t:1527621267308};\\\", \\\"{x:1344,y:973,t:1527621267325};\\\", \\\"{x:1345,y:974,t:1527621267414};\\\", \\\"{x:1346,y:974,t:1527621267510};\\\", \\\"{x:1346,y:972,t:1527621267566};\\\", \\\"{x:1346,y:970,t:1527621267575};\\\", \\\"{x:1346,y:968,t:1527621267593};\\\", \\\"{x:1346,y:966,t:1527621267607};\\\", \\\"{x:1346,y:963,t:1527621267625};\\\", \\\"{x:1346,y:962,t:1527621267642};\\\", \\\"{x:1346,y:960,t:1527621267678};\\\", \\\"{x:1346,y:959,t:1527621267693};\\\", \\\"{x:1346,y:958,t:1527621267709};\\\", \\\"{x:1345,y:956,t:1527621267725};\\\", \\\"{x:1343,y:949,t:1527621267742};\\\", \\\"{x:1342,y:946,t:1527621267758};\\\", \\\"{x:1340,y:942,t:1527621267775};\\\", \\\"{x:1338,y:939,t:1527621267792};\\\", \\\"{x:1338,y:938,t:1527621267809};\\\", \\\"{x:1338,y:934,t:1527621267825};\\\", \\\"{x:1337,y:932,t:1527621267842};\\\", \\\"{x:1337,y:931,t:1527621267859};\\\", \\\"{x:1337,y:927,t:1527621267875};\\\", \\\"{x:1337,y:923,t:1527621267891};\\\", \\\"{x:1337,y:921,t:1527621267908};\\\", \\\"{x:1337,y:918,t:1527621267925};\\\", \\\"{x:1336,y:912,t:1527621267942};\\\", \\\"{x:1336,y:910,t:1527621267958};\\\", \\\"{x:1337,y:906,t:1527621267975};\\\", \\\"{x:1338,y:901,t:1527621267992};\\\", \\\"{x:1338,y:899,t:1527621268008};\\\", \\\"{x:1340,y:895,t:1527621268024};\\\", \\\"{x:1341,y:893,t:1527621268041};\\\", \\\"{x:1342,y:889,t:1527621268058};\\\", \\\"{x:1343,y:885,t:1527621268074};\\\", \\\"{x:1344,y:881,t:1527621268093};\\\", \\\"{x:1344,y:880,t:1527621268109};\\\", \\\"{x:1344,y:879,t:1527621268126};\\\", \\\"{x:1345,y:877,t:1527621268141};\\\", \\\"{x:1345,y:873,t:1527621268158};\\\", \\\"{x:1346,y:871,t:1527621268175};\\\", \\\"{x:1346,y:867,t:1527621268191};\\\", \\\"{x:1346,y:865,t:1527621268208};\\\", \\\"{x:1346,y:862,t:1527621268225};\\\", \\\"{x:1348,y:859,t:1527621268241};\\\", \\\"{x:1349,y:856,t:1527621268258};\\\", \\\"{x:1349,y:855,t:1527621268275};\\\", \\\"{x:1349,y:852,t:1527621268291};\\\", \\\"{x:1349,y:850,t:1527621268308};\\\", \\\"{x:1349,y:848,t:1527621268325};\\\", \\\"{x:1349,y:846,t:1527621268341};\\\", \\\"{x:1349,y:844,t:1527621268358};\\\", \\\"{x:1349,y:842,t:1527621268375};\\\", \\\"{x:1349,y:841,t:1527621268405};\\\", \\\"{x:1349,y:840,t:1527621268430};\\\", \\\"{x:1349,y:839,t:1527621268441};\\\", \\\"{x:1349,y:838,t:1527621268495};\\\", \\\"{x:1349,y:837,t:1527621268510};\\\", \\\"{x:1349,y:836,t:1527621268550};\\\", \\\"{x:1349,y:835,t:1527621268559};\\\", \\\"{x:1349,y:834,t:1527621268581};\\\", \\\"{x:1349,y:833,t:1527621268592};\\\", \\\"{x:1349,y:832,t:1527621268608};\\\", \\\"{x:1349,y:830,t:1527621268626};\\\", \\\"{x:1349,y:829,t:1527621268643};\\\", \\\"{x:1349,y:828,t:1527621268662};\\\", \\\"{x:1348,y:827,t:1527621268676};\\\", \\\"{x:1348,y:825,t:1527621268693};\\\", \\\"{x:1348,y:824,t:1527621268709};\\\", \\\"{x:1346,y:821,t:1527621268725};\\\", \\\"{x:1345,y:820,t:1527621268743};\\\", \\\"{x:1345,y:818,t:1527621268765};\\\", \\\"{x:1344,y:816,t:1527621268781};\\\", \\\"{x:1344,y:815,t:1527621268793};\\\", \\\"{x:1343,y:813,t:1527621268809};\\\", \\\"{x:1342,y:810,t:1527621268826};\\\", \\\"{x:1340,y:804,t:1527621268843};\\\", \\\"{x:1338,y:799,t:1527621268859};\\\", \\\"{x:1337,y:797,t:1527621268876};\\\", \\\"{x:1334,y:792,t:1527621268893};\\\", \\\"{x:1333,y:789,t:1527621268909};\\\", \\\"{x:1331,y:786,t:1527621268925};\\\", \\\"{x:1331,y:785,t:1527621268942};\\\", \\\"{x:1330,y:784,t:1527621268959};\\\", \\\"{x:1330,y:783,t:1527621268976};\\\", \\\"{x:1330,y:782,t:1527621268993};\\\", \\\"{x:1330,y:780,t:1527621269009};\\\", \\\"{x:1329,y:779,t:1527621269025};\\\", \\\"{x:1328,y:779,t:1527621269043};\\\", \\\"{x:1328,y:777,t:1527621269060};\\\", \\\"{x:1328,y:776,t:1527621269076};\\\", \\\"{x:1328,y:774,t:1527621269092};\\\", \\\"{x:1328,y:771,t:1527621269110};\\\", \\\"{x:1328,y:770,t:1527621269133};\\\", \\\"{x:1328,y:768,t:1527621269150};\\\", \\\"{x:1328,y:764,t:1527621269160};\\\", \\\"{x:1330,y:762,t:1527621269175};\\\", \\\"{x:1330,y:760,t:1527621269193};\\\", \\\"{x:1333,y:757,t:1527621269210};\\\", \\\"{x:1336,y:752,t:1527621269226};\\\", \\\"{x:1337,y:749,t:1527621269243};\\\", \\\"{x:1338,y:746,t:1527621269260};\\\", \\\"{x:1340,y:744,t:1527621269276};\\\", \\\"{x:1340,y:743,t:1527621269292};\\\", \\\"{x:1341,y:742,t:1527621269310};\\\", \\\"{x:1341,y:740,t:1527621269334};\\\", \\\"{x:1343,y:739,t:1527621269343};\\\", \\\"{x:1343,y:738,t:1527621269359};\\\", \\\"{x:1344,y:736,t:1527621269377};\\\", \\\"{x:1346,y:732,t:1527621269398};\\\", \\\"{x:1346,y:731,t:1527621269409};\\\", \\\"{x:1347,y:731,t:1527621269430};\\\", \\\"{x:1347,y:730,t:1527621269454};\\\", \\\"{x:1347,y:729,t:1527621269462};\\\", \\\"{x:1347,y:728,t:1527621269476};\\\", \\\"{x:1348,y:726,t:1527621269493};\\\", \\\"{x:1349,y:723,t:1527621269509};\\\", \\\"{x:1350,y:722,t:1527621269527};\\\", \\\"{x:1350,y:720,t:1527621269543};\\\", \\\"{x:1351,y:718,t:1527621269560};\\\", \\\"{x:1351,y:717,t:1527621269577};\\\", \\\"{x:1351,y:716,t:1527621269593};\\\", \\\"{x:1351,y:714,t:1527621269609};\\\", \\\"{x:1353,y:711,t:1527621269627};\\\", \\\"{x:1353,y:710,t:1527621269643};\\\", \\\"{x:1354,y:708,t:1527621269660};\\\", \\\"{x:1355,y:706,t:1527621269677};\\\", \\\"{x:1355,y:705,t:1527621269727};\\\", \\\"{x:1355,y:704,t:1527621273270};\\\", \\\"{x:1348,y:705,t:1527621273279};\\\", \\\"{x:1313,y:713,t:1527621273296};\\\", \\\"{x:1194,y:713,t:1527621273313};\\\", \\\"{x:1050,y:715,t:1527621273329};\\\", \\\"{x:914,y:714,t:1527621273346};\\\", \\\"{x:804,y:702,t:1527621273362};\\\", \\\"{x:678,y:693,t:1527621273379};\\\", \\\"{x:558,y:687,t:1527621273395};\\\", \\\"{x:440,y:681,t:1527621273414};\\\", \\\"{x:330,y:674,t:1527621273429};\\\", \\\"{x:315,y:673,t:1527621273446};\\\", \\\"{x:312,y:673,t:1527621273462};\\\", \\\"{x:312,y:672,t:1527621273517};\\\", \\\"{x:315,y:671,t:1527621273529};\\\", \\\"{x:320,y:664,t:1527621273546};\\\", \\\"{x:323,y:658,t:1527621273563};\\\", \\\"{x:324,y:653,t:1527621273580};\\\", \\\"{x:324,y:644,t:1527621273597};\\\", \\\"{x:324,y:636,t:1527621273612};\\\", \\\"{x:326,y:627,t:1527621273629};\\\", \\\"{x:327,y:620,t:1527621273646};\\\", \\\"{x:328,y:614,t:1527621273664};\\\", \\\"{x:330,y:608,t:1527621273679};\\\", \\\"{x:333,y:603,t:1527621273697};\\\", \\\"{x:337,y:595,t:1527621273713};\\\", \\\"{x:343,y:587,t:1527621273729};\\\", \\\"{x:350,y:580,t:1527621273746};\\\", \\\"{x:365,y:569,t:1527621273765};\\\", \\\"{x:375,y:564,t:1527621273780};\\\", \\\"{x:388,y:555,t:1527621273796};\\\", \\\"{x:410,y:544,t:1527621273813};\\\", \\\"{x:428,y:535,t:1527621273830};\\\", \\\"{x:445,y:530,t:1527621273848};\\\", \\\"{x:463,y:527,t:1527621273864};\\\", \\\"{x:480,y:523,t:1527621273879};\\\", \\\"{x:489,y:520,t:1527621273896};\\\", \\\"{x:498,y:515,t:1527621273912};\\\", \\\"{x:506,y:514,t:1527621273931};\\\", \\\"{x:511,y:514,t:1527621273946};\\\", \\\"{x:516,y:514,t:1527621273963};\\\", \\\"{x:520,y:514,t:1527621273980};\\\", \\\"{x:530,y:514,t:1527621273996};\\\", \\\"{x:545,y:514,t:1527621274013};\\\", \\\"{x:549,y:514,t:1527621274031};\\\", \\\"{x:562,y:515,t:1527621274046};\\\", \\\"{x:567,y:516,t:1527621274063};\\\", \\\"{x:572,y:516,t:1527621274080};\\\", \\\"{x:575,y:518,t:1527621274101};\\\", \\\"{x:581,y:518,t:1527621274113};\\\", \\\"{x:592,y:520,t:1527621274130};\\\", \\\"{x:597,y:520,t:1527621274147};\\\", \\\"{x:602,y:520,t:1527621274164};\\\", \\\"{x:620,y:520,t:1527621274180};\\\", \\\"{x:642,y:520,t:1527621274197};\\\", \\\"{x:666,y:520,t:1527621274214};\\\", \\\"{x:681,y:520,t:1527621274230};\\\", \\\"{x:697,y:520,t:1527621274246};\\\", \\\"{x:717,y:518,t:1527621274263};\\\", \\\"{x:729,y:517,t:1527621274281};\\\", \\\"{x:744,y:516,t:1527621274296};\\\", \\\"{x:756,y:515,t:1527621274313};\\\", \\\"{x:766,y:513,t:1527621274330};\\\", \\\"{x:771,y:512,t:1527621274346};\\\", \\\"{x:779,y:511,t:1527621274363};\\\", \\\"{x:781,y:511,t:1527621274380};\\\", \\\"{x:782,y:511,t:1527621274526};\\\", \\\"{x:785,y:511,t:1527621274534};\\\", \\\"{x:788,y:511,t:1527621274547};\\\", \\\"{x:794,y:512,t:1527621274563};\\\", \\\"{x:801,y:514,t:1527621274580};\\\", \\\"{x:805,y:516,t:1527621274596};\\\", \\\"{x:811,y:519,t:1527621274613};\\\", \\\"{x:814,y:520,t:1527621274631};\\\", \\\"{x:819,y:521,t:1527621274646};\\\", \\\"{x:823,y:522,t:1527621274664};\\\", \\\"{x:827,y:522,t:1527621274680};\\\", \\\"{x:830,y:522,t:1527621274697};\\\", \\\"{x:835,y:524,t:1527621274713};\\\", \\\"{x:836,y:524,t:1527621274730};\\\", \\\"{x:837,y:524,t:1527621274789};\\\", \\\"{x:827,y:532,t:1527621275279};\\\", \\\"{x:807,y:543,t:1527621275298};\\\", \\\"{x:781,y:557,t:1527621275314};\\\", \\\"{x:759,y:570,t:1527621275330};\\\", \\\"{x:742,y:580,t:1527621275348};\\\", \\\"{x:728,y:585,t:1527621275365};\\\", \\\"{x:717,y:594,t:1527621275381};\\\", \\\"{x:712,y:598,t:1527621275397};\\\", \\\"{x:709,y:599,t:1527621275415};\\\", \\\"{x:705,y:603,t:1527621275430};\\\", \\\"{x:696,y:606,t:1527621275447};\\\", \\\"{x:688,y:612,t:1527621275465};\\\", \\\"{x:683,y:615,t:1527621275481};\\\", \\\"{x:676,y:621,t:1527621275497};\\\", \\\"{x:663,y:630,t:1527621275515};\\\", \\\"{x:653,y:637,t:1527621275531};\\\", \\\"{x:642,y:644,t:1527621275549};\\\", \\\"{x:642,y:646,t:1527621275565};\\\", \\\"{x:636,y:654,t:1527621275581};\\\", \\\"{x:630,y:658,t:1527621275598};\\\", \\\"{x:623,y:661,t:1527621275614};\\\", \\\"{x:621,y:663,t:1527621275631};\\\", \\\"{x:620,y:664,t:1527621275647};\\\", \\\"{x:618,y:665,t:1527621275665};\\\", \\\"{x:617,y:667,t:1527621275682};\\\", \\\"{x:616,y:668,t:1527621275701};\\\", \\\"{x:615,y:670,t:1527621275714};\\\", \\\"{x:612,y:673,t:1527621275731};\\\", \\\"{x:609,y:677,t:1527621275748};\\\", \\\"{x:607,y:678,t:1527621275764};\\\", \\\"{x:602,y:682,t:1527621275781};\\\", \\\"{x:601,y:684,t:1527621275797};\\\", \\\"{x:598,y:684,t:1527621275815};\\\", \\\"{x:596,y:686,t:1527621275832};\\\", \\\"{x:592,y:690,t:1527621275848};\\\", \\\"{x:590,y:692,t:1527621275864};\\\", \\\"{x:587,y:695,t:1527621275881};\\\", \\\"{x:585,y:696,t:1527621275899};\\\", \\\"{x:583,y:698,t:1527621275915};\\\", \\\"{x:582,y:698,t:1527621275932};\\\", \\\"{x:580,y:699,t:1527621275949};\\\", \\\"{x:577,y:702,t:1527621275965};\\\", \\\"{x:564,y:710,t:1527621275982};\\\", \\\"{x:552,y:714,t:1527621275999};\\\", \\\"{x:538,y:717,t:1527621276015};\\\", \\\"{x:526,y:721,t:1527621276031};\\\", \\\"{x:515,y:725,t:1527621276048};\\\", \\\"{x:510,y:725,t:1527621276065};\\\", \\\"{x:504,y:726,t:1527621276081};\\\", \\\"{x:498,y:728,t:1527621276099};\\\", \\\"{x:492,y:728,t:1527621276116};\\\", \\\"{x:485,y:726,t:1527621276131};\\\", \\\"{x:475,y:726,t:1527621276148};\\\", \\\"{x:457,y:723,t:1527621276164};\\\", \\\"{x:449,y:722,t:1527621276182};\\\", \\\"{x:445,y:720,t:1527621276198};\\\", \\\"{x:441,y:719,t:1527621276216};\\\", \\\"{x:439,y:719,t:1527621276231};\\\", \\\"{x:438,y:719,t:1527621276248};\\\", \\\"{x:436,y:718,t:1527621276265};\\\", \\\"{x:431,y:715,t:1527621276281};\\\", \\\"{x:430,y:713,t:1527621276298};\\\", \\\"{x:425,y:709,t:1527621276316};\\\", \\\"{x:422,y:706,t:1527621276331};\\\", \\\"{x:418,y:703,t:1527621276348};\\\", \\\"{x:415,y:700,t:1527621276365};\\\", \\\"{x:413,y:697,t:1527621276381};\\\", \\\"{x:411,y:695,t:1527621276398};\\\", \\\"{x:411,y:694,t:1527621276415};\\\", \\\"{x:410,y:694,t:1527621276432};\\\", \\\"{x:409,y:693,t:1527621276449};\\\", \\\"{x:409,y:692,t:1527621276465};\\\", \\\"{x:408,y:690,t:1527621276493};\\\", \\\"{x:410,y:690,t:1527621276845};\\\", \\\"{x:425,y:689,t:1527621276853};\\\", \\\"{x:444,y:687,t:1527621276866};\\\", \\\"{x:511,y:687,t:1527621276882};\\\", \\\"{x:581,y:687,t:1527621276899};\\\", \\\"{x:621,y:687,t:1527621276916};\\\", \\\"{x:666,y:683,t:1527621276932};\\\", \\\"{x:702,y:687,t:1527621276948};\\\", \\\"{x:745,y:687,t:1527621276966};\\\", \\\"{x:775,y:687,t:1527621276982};\\\", \\\"{x:799,y:692,t:1527621276999};\\\", \\\"{x:816,y:698,t:1527621277016};\\\", \\\"{x:830,y:704,t:1527621277033};\\\", \\\"{x:851,y:710,t:1527621277050};\\\", \\\"{x:864,y:718,t:1527621277066};\\\", \\\"{x:892,y:725,t:1527621277083};\\\", \\\"{x:906,y:730,t:1527621277100};\\\", \\\"{x:927,y:739,t:1527621277115};\\\", \\\"{x:958,y:748,t:1527621277133};\\\", \\\"{x:996,y:764,t:1527621277150};\\\", \\\"{x:1026,y:775,t:1527621277166};\\\", \\\"{x:1059,y:787,t:1527621277183};\\\", \\\"{x:1082,y:799,t:1527621277201};\\\", \\\"{x:1103,y:808,t:1527621277216};\\\", \\\"{x:1119,y:813,t:1527621277233};\\\", \\\"{x:1132,y:818,t:1527621277250};\\\", \\\"{x:1142,y:822,t:1527621277266};\\\", \\\"{x:1148,y:825,t:1527621277283};\\\", \\\"{x:1154,y:826,t:1527621277300};\\\", \\\"{x:1163,y:830,t:1527621277317};\\\", \\\"{x:1174,y:833,t:1527621277333};\\\", \\\"{x:1189,y:839,t:1527621277350};\\\", \\\"{x:1202,y:845,t:1527621277367};\\\", \\\"{x:1213,y:849,t:1527621277383};\\\", \\\"{x:1219,y:853,t:1527621277400};\\\", \\\"{x:1223,y:854,t:1527621277416};\\\", \\\"{x:1225,y:856,t:1527621277432};\\\", \\\"{x:1227,y:856,t:1527621277451};\\\", \\\"{x:1233,y:856,t:1527621277467};\\\", \\\"{x:1238,y:858,t:1527621277482};\\\", \\\"{x:1241,y:859,t:1527621277500};\\\", \\\"{x:1248,y:866,t:1527621277516};\\\", \\\"{x:1261,y:869,t:1527621277533};\\\", \\\"{x:1269,y:874,t:1527621277550};\\\", \\\"{x:1275,y:881,t:1527621277567};\\\", \\\"{x:1281,y:885,t:1527621277583};\\\", \\\"{x:1286,y:886,t:1527621277600};\\\", \\\"{x:1287,y:886,t:1527621277637};\\\", \\\"{x:1288,y:886,t:1527621277662};\\\", \\\"{x:1291,y:886,t:1527621277669};\\\", \\\"{x:1293,y:886,t:1527621277683};\\\", \\\"{x:1296,y:886,t:1527621277700};\\\", \\\"{x:1297,y:886,t:1527621277725};\\\", \\\"{x:1299,y:886,t:1527621277733};\\\", \\\"{x:1303,y:887,t:1527621277750};\\\", \\\"{x:1305,y:888,t:1527621277767};\\\", \\\"{x:1306,y:888,t:1527621277784};\\\", \\\"{x:1309,y:888,t:1527621277800};\\\", \\\"{x:1311,y:887,t:1527621277818};\\\", \\\"{x:1313,y:887,t:1527621277833};\\\", \\\"{x:1315,y:885,t:1527621277850};\\\", \\\"{x:1318,y:884,t:1527621277867};\\\", \\\"{x:1321,y:883,t:1527621277884};\\\", \\\"{x:1323,y:882,t:1527621277901};\\\", \\\"{x:1328,y:882,t:1527621277917};\\\", \\\"{x:1329,y:882,t:1527621277934};\\\", \\\"{x:1332,y:882,t:1527621277950};\\\", \\\"{x:1336,y:882,t:1527621277967};\\\", \\\"{x:1337,y:882,t:1527621277984};\\\", \\\"{x:1341,y:881,t:1527621278000};\\\", \\\"{x:1342,y:881,t:1527621278017};\\\", \\\"{x:1343,y:881,t:1527621278094};\\\", \\\"{x:1345,y:882,t:1527621278150};\\\", \\\"{x:1347,y:882,t:1527621278168};\\\", \\\"{x:1353,y:883,t:1527621278184};\\\", \\\"{x:1356,y:884,t:1527621278201};\\\", \\\"{x:1360,y:885,t:1527621278218};\\\", \\\"{x:1361,y:885,t:1527621278234};\\\", \\\"{x:1363,y:886,t:1527621278250};\\\", \\\"{x:1364,y:887,t:1527621278267};\\\", \\\"{x:1365,y:887,t:1527621278285};\\\", \\\"{x:1367,y:888,t:1527621278301};\\\", \\\"{x:1368,y:888,t:1527621278317};\\\", \\\"{x:1370,y:889,t:1527621278334};\\\", \\\"{x:1372,y:889,t:1527621278351};\\\", \\\"{x:1373,y:889,t:1527621278368};\\\", \\\"{x:1373,y:890,t:1527621278384};\\\", \\\"{x:1374,y:890,t:1527621278413};\\\", \\\"{x:1375,y:890,t:1527621278421};\\\", \\\"{x:1376,y:891,t:1527621278454};\\\", \\\"{x:1377,y:892,t:1527621278494};\\\", \\\"{x:1379,y:892,t:1527621278517};\\\", \\\"{x:1379,y:893,t:1527621278550};\\\", \\\"{x:1381,y:894,t:1527621278668};\\\", \\\"{x:1381,y:895,t:1527621278701};\\\", \\\"{x:1382,y:895,t:1527621278733};\\\", \\\"{x:1384,y:895,t:1527621278757};\\\", \\\"{x:1385,y:896,t:1527621278781};\\\", \\\"{x:1386,y:897,t:1527621278982};\\\", \\\"{x:1386,y:898,t:1527621279030};\\\", \\\"{x:1386,y:900,t:1527621279038};\\\", \\\"{x:1386,y:902,t:1527621279051};\\\", \\\"{x:1386,y:908,t:1527621279068};\\\", \\\"{x:1386,y:914,t:1527621279085};\\\", \\\"{x:1386,y:919,t:1527621279101};\\\", \\\"{x:1386,y:921,t:1527621279118};\\\", \\\"{x:1386,y:922,t:1527621279135};\\\", \\\"{x:1386,y:923,t:1527621279151};\\\", \\\"{x:1386,y:924,t:1527621279167};\\\", \\\"{x:1386,y:926,t:1527621279184};\\\", \\\"{x:1386,y:930,t:1527621279200};\\\", \\\"{x:1386,y:936,t:1527621279218};\\\", \\\"{x:1386,y:939,t:1527621279235};\\\", \\\"{x:1385,y:944,t:1527621279251};\\\", \\\"{x:1383,y:948,t:1527621279268};\\\", \\\"{x:1381,y:951,t:1527621279284};\\\", \\\"{x:1380,y:953,t:1527621279301};\\\", \\\"{x:1380,y:954,t:1527621279318};\\\", \\\"{x:1380,y:955,t:1527621279335};\\\", \\\"{x:1379,y:958,t:1527621279358};\\\", \\\"{x:1379,y:960,t:1527621279373};\\\", \\\"{x:1377,y:961,t:1527621279389};\\\", \\\"{x:1376,y:963,t:1527621279406};\\\", \\\"{x:1376,y:964,t:1527621279438};\\\", \\\"{x:1375,y:965,t:1527621279453};\\\", \\\"{x:1375,y:967,t:1527621279478};\\\", \\\"{x:1375,y:968,t:1527621279501};\\\", \\\"{x:1374,y:969,t:1527621279534};\\\", \\\"{x:1374,y:970,t:1527621279566};\\\", \\\"{x:1383,y:940,t:1527621285694};\\\", \\\"{x:1400,y:884,t:1527621285708};\\\", \\\"{x:1410,y:807,t:1527621285725};\\\", \\\"{x:1406,y:758,t:1527621285741};\\\", \\\"{x:1405,y:692,t:1527621285758};\\\", \\\"{x:1405,y:673,t:1527621285774};\\\", \\\"{x:1407,y:656,t:1527621285790};\\\", \\\"{x:1409,y:642,t:1527621285807};\\\", \\\"{x:1409,y:629,t:1527621285824};\\\", \\\"{x:1410,y:617,t:1527621285841};\\\", \\\"{x:1408,y:608,t:1527621285857};\\\", \\\"{x:1407,y:601,t:1527621285875};\\\", \\\"{x:1406,y:595,t:1527621285890};\\\", \\\"{x:1403,y:589,t:1527621285907};\\\", \\\"{x:1403,y:582,t:1527621285925};\\\", \\\"{x:1403,y:576,t:1527621285940};\\\", \\\"{x:1403,y:568,t:1527621285957};\\\", \\\"{x:1403,y:564,t:1527621285974};\\\", \\\"{x:1403,y:558,t:1527621285991};\\\", \\\"{x:1403,y:557,t:1527621286007};\\\", \\\"{x:1403,y:554,t:1527621286025};\\\", \\\"{x:1404,y:554,t:1527621286334};\\\", \\\"{x:1405,y:554,t:1527621286341};\\\", \\\"{x:1406,y:556,t:1527621286358};\\\", \\\"{x:1407,y:556,t:1527621286374};\\\", \\\"{x:1407,y:557,t:1527621286392};\\\", \\\"{x:1409,y:557,t:1527621286413};\\\", \\\"{x:1410,y:557,t:1527621286425};\\\", \\\"{x:1411,y:557,t:1527621286441};\\\", \\\"{x:1412,y:558,t:1527621286470};\\\", \\\"{x:1412,y:559,t:1527621286492};\\\", \\\"{x:1412,y:560,t:1527621286507};\\\", \\\"{x:1414,y:563,t:1527621286525};\\\", \\\"{x:1414,y:564,t:1527621286541};\\\", \\\"{x:1416,y:565,t:1527621286557};\\\", \\\"{x:1417,y:565,t:1527621286575};\\\", \\\"{x:1417,y:566,t:1527621287542};\\\", \\\"{x:1417,y:567,t:1527621287677};\\\", \\\"{x:1416,y:568,t:1527621287693};\\\", \\\"{x:1415,y:568,t:1527621287765};\\\", \\\"{x:1413,y:569,t:1527621288103};\\\", \\\"{x:1411,y:569,t:1527621288117};\\\", \\\"{x:1409,y:570,t:1527621288133};\\\", \\\"{x:1408,y:571,t:1527621288157};\\\", \\\"{x:1407,y:571,t:1527621288174};\\\", \\\"{x:1406,y:571,t:1527621288181};\\\", \\\"{x:1404,y:572,t:1527621288192};\\\", \\\"{x:1394,y:577,t:1527621288210};\\\", \\\"{x:1377,y:581,t:1527621288225};\\\", \\\"{x:1359,y:584,t:1527621288243};\\\", \\\"{x:1342,y:587,t:1527621288260};\\\", \\\"{x:1323,y:589,t:1527621288275};\\\", \\\"{x:1302,y:594,t:1527621288292};\\\", \\\"{x:1288,y:595,t:1527621288310};\\\", \\\"{x:1277,y:597,t:1527621288326};\\\", \\\"{x:1269,y:599,t:1527621288341};\\\", \\\"{x:1261,y:601,t:1527621288359};\\\", \\\"{x:1253,y:602,t:1527621288375};\\\", \\\"{x:1251,y:602,t:1527621288392};\\\", \\\"{x:1250,y:602,t:1527621288408};\\\", \\\"{x:1248,y:603,t:1527621288426};\\\", \\\"{x:1254,y:599,t:1527621288566};\\\", \\\"{x:1266,y:592,t:1527621288577};\\\", \\\"{x:1278,y:589,t:1527621288593};\\\", \\\"{x:1278,y:588,t:1527621288610};\\\", \\\"{x:1279,y:588,t:1527621288645};\\\", \\\"{x:1280,y:588,t:1527621288678};\\\", \\\"{x:1281,y:588,t:1527621288692};\\\", \\\"{x:1281,y:587,t:1527621288846};\\\", \\\"{x:1281,y:586,t:1527621288859};\\\", \\\"{x:1281,y:584,t:1527621288876};\\\", \\\"{x:1281,y:581,t:1527621288893};\\\", \\\"{x:1281,y:580,t:1527621288910};\\\", \\\"{x:1281,y:578,t:1527621288927};\\\", \\\"{x:1281,y:576,t:1527621288943};\\\", \\\"{x:1280,y:575,t:1527621288960};\\\", \\\"{x:1280,y:573,t:1527621288977};\\\", \\\"{x:1280,y:571,t:1527621288993};\\\", \\\"{x:1280,y:569,t:1527621289030};\\\", \\\"{x:1280,y:568,t:1527621289044};\\\", \\\"{x:1280,y:567,t:1527621289076};\\\", \\\"{x:1280,y:566,t:1527621289109};\\\", \\\"{x:1280,y:564,t:1527621289166};\\\", \\\"{x:1280,y:562,t:1527621289181};\\\", \\\"{x:1280,y:561,t:1527621289205};\\\", \\\"{x:1280,y:559,t:1527621289301};\\\", \\\"{x:1279,y:559,t:1527621290846};\\\", \\\"{x:1278,y:562,t:1527621290861};\\\", \\\"{x:1278,y:563,t:1527621290893};\\\", \\\"{x:1278,y:564,t:1527621290909};\\\", \\\"{x:1278,y:565,t:1527621290933};\\\", \\\"{x:1278,y:566,t:1527621290958};\\\", \\\"{x:1278,y:567,t:1527621290965};\\\", \\\"{x:1277,y:568,t:1527621290980};\\\", \\\"{x:1276,y:571,t:1527621290994};\\\", \\\"{x:1276,y:574,t:1527621291012};\\\", \\\"{x:1276,y:576,t:1527621291029};\\\", \\\"{x:1275,y:579,t:1527621291044};\\\", \\\"{x:1274,y:585,t:1527621291061};\\\", \\\"{x:1273,y:588,t:1527621291078};\\\", \\\"{x:1272,y:596,t:1527621291095};\\\", \\\"{x:1271,y:602,t:1527621291112};\\\", \\\"{x:1270,y:611,t:1527621291129};\\\", \\\"{x:1269,y:622,t:1527621291145};\\\", \\\"{x:1268,y:631,t:1527621291161};\\\", \\\"{x:1265,y:646,t:1527621291179};\\\", \\\"{x:1263,y:667,t:1527621291195};\\\", \\\"{x:1258,y:690,t:1527621291212};\\\", \\\"{x:1254,y:713,t:1527621291229};\\\", \\\"{x:1249,y:750,t:1527621291246};\\\", \\\"{x:1248,y:769,t:1527621291261};\\\", \\\"{x:1249,y:780,t:1527621291279};\\\", \\\"{x:1252,y:793,t:1527621291296};\\\", \\\"{x:1255,y:797,t:1527621291312};\\\", \\\"{x:1255,y:800,t:1527621291329};\\\", \\\"{x:1255,y:802,t:1527621291346};\\\", \\\"{x:1256,y:806,t:1527621291362};\\\", \\\"{x:1257,y:811,t:1527621291379};\\\", \\\"{x:1257,y:816,t:1527621291395};\\\", \\\"{x:1259,y:830,t:1527621291412};\\\", \\\"{x:1261,y:844,t:1527621291429};\\\", \\\"{x:1264,y:865,t:1527621291446};\\\", \\\"{x:1268,y:882,t:1527621291461};\\\", \\\"{x:1273,y:894,t:1527621291479};\\\", \\\"{x:1274,y:904,t:1527621291495};\\\", \\\"{x:1274,y:909,t:1527621291511};\\\", \\\"{x:1276,y:915,t:1527621291529};\\\", \\\"{x:1276,y:922,t:1527621291546};\\\", \\\"{x:1276,y:933,t:1527621291562};\\\", \\\"{x:1278,y:945,t:1527621291579};\\\", \\\"{x:1281,y:953,t:1527621291596};\\\", \\\"{x:1282,y:958,t:1527621291613};\\\", \\\"{x:1285,y:963,t:1527621291629};\\\", \\\"{x:1287,y:967,t:1527621291646};\\\", \\\"{x:1287,y:968,t:1527621291669};\\\", \\\"{x:1287,y:969,t:1527621291679};\\\", \\\"{x:1287,y:970,t:1527621291701};\\\", \\\"{x:1287,y:971,t:1527621291712};\\\", \\\"{x:1288,y:975,t:1527621291728};\\\", \\\"{x:1289,y:977,t:1527621291745};\\\", \\\"{x:1289,y:978,t:1527621291773};\\\", \\\"{x:1290,y:978,t:1527621291812};\\\", \\\"{x:1291,y:978,t:1527621291829};\\\", \\\"{x:1294,y:979,t:1527621291845};\\\", \\\"{x:1298,y:979,t:1527621291862};\\\", \\\"{x:1299,y:979,t:1527621291878};\\\", \\\"{x:1301,y:979,t:1527621291895};\\\", \\\"{x:1304,y:979,t:1527621291912};\\\", \\\"{x:1309,y:978,t:1527621291928};\\\", \\\"{x:1312,y:976,t:1527621291945};\\\", \\\"{x:1312,y:974,t:1527621291962};\\\", \\\"{x:1313,y:973,t:1527621291978};\\\", \\\"{x:1314,y:973,t:1527621291995};\\\", \\\"{x:1314,y:972,t:1527621292012};\\\", \\\"{x:1314,y:971,t:1527621294876};\\\", \\\"{x:1312,y:971,t:1527621297029};\\\", \\\"{x:1299,y:970,t:1527621297036};\\\", \\\"{x:1281,y:957,t:1527621297050};\\\", \\\"{x:1256,y:939,t:1527621297066};\\\", \\\"{x:1256,y:938,t:1527621297084};\\\", \\\"{x:1254,y:938,t:1527621297221};\\\", \\\"{x:1249,y:937,t:1527621297245};\\\", \\\"{x:1247,y:937,t:1527621297253};\\\", \\\"{x:1246,y:935,t:1527621297269};\\\", \\\"{x:1245,y:935,t:1527621297438};\\\", \\\"{x:1234,y:934,t:1527621297451};\\\", \\\"{x:1224,y:935,t:1527621297467};\\\", \\\"{x:1221,y:936,t:1527621297484};\\\", \\\"{x:1220,y:936,t:1527621297501};\\\", \\\"{x:1218,y:936,t:1527621297518};\\\", \\\"{x:1215,y:936,t:1527621297566};\\\", \\\"{x:1209,y:932,t:1527621297573};\\\", \\\"{x:1198,y:924,t:1527621297584};\\\", \\\"{x:1169,y:909,t:1527621297601};\\\", \\\"{x:1149,y:899,t:1527621297617};\\\", \\\"{x:1133,y:888,t:1527621297633};\\\", \\\"{x:1104,y:877,t:1527621297651};\\\", \\\"{x:1051,y:863,t:1527621297666};\\\", \\\"{x:1007,y:851,t:1527621297683};\\\", \\\"{x:968,y:834,t:1527621297701};\\\", \\\"{x:943,y:824,t:1527621297716};\\\", \\\"{x:896,y:816,t:1527621297733};\\\", \\\"{x:871,y:811,t:1527621297751};\\\", \\\"{x:831,y:808,t:1527621297767};\\\", \\\"{x:804,y:800,t:1527621297784};\\\", \\\"{x:774,y:797,t:1527621297800};\\\", \\\"{x:751,y:794,t:1527621297818};\\\", \\\"{x:727,y:793,t:1527621297834};\\\", \\\"{x:710,y:792,t:1527621297850};\\\", \\\"{x:704,y:792,t:1527621297868};\\\", \\\"{x:700,y:792,t:1527621297883};\\\", \\\"{x:689,y:792,t:1527621297900};\\\", \\\"{x:681,y:788,t:1527621297917};\\\", \\\"{x:680,y:786,t:1527621297934};\\\", \\\"{x:680,y:785,t:1527621300181};\\\", \\\"{x:680,y:783,t:1527621300197};\\\", \\\"{x:684,y:781,t:1527621300205};\\\", \\\"{x:688,y:779,t:1527621300221};\\\", \\\"{x:690,y:776,t:1527621300236};\\\", \\\"{x:706,y:774,t:1527621300253};\\\", \\\"{x:714,y:772,t:1527621300269};\\\", \\\"{x:724,y:772,t:1527621300286};\\\", \\\"{x:746,y:772,t:1527621300303};\\\", \\\"{x:755,y:774,t:1527621300320};\\\", \\\"{x:795,y:786,t:1527621300335};\\\", \\\"{x:856,y:803,t:1527621300353};\\\", \\\"{x:938,y:808,t:1527621300370};\\\", \\\"{x:1023,y:827,t:1527621300385};\\\", \\\"{x:1104,y:842,t:1527621300402};\\\", \\\"{x:1172,y:867,t:1527621300419};\\\", \\\"{x:1261,y:878,t:1527621300435};\\\", \\\"{x:1355,y:901,t:1527621300452};\\\", \\\"{x:1414,y:912,t:1527621300469};\\\", \\\"{x:1496,y:929,t:1527621300486};\\\", \\\"{x:1524,y:932,t:1527621300503};\\\", \\\"{x:1541,y:938,t:1527621300519};\\\", \\\"{x:1556,y:941,t:1527621300535};\\\", \\\"{x:1560,y:941,t:1527621300552};\\\", \\\"{x:1562,y:941,t:1527621300570};\\\", \\\"{x:1558,y:939,t:1527621300596};\\\", \\\"{x:1554,y:934,t:1527621300604};\\\", \\\"{x:1545,y:929,t:1527621300620};\\\", \\\"{x:1522,y:919,t:1527621300637};\\\", \\\"{x:1501,y:914,t:1527621300652};\\\", \\\"{x:1482,y:909,t:1527621300670};\\\", \\\"{x:1456,y:903,t:1527621300686};\\\", \\\"{x:1431,y:898,t:1527621300703};\\\", \\\"{x:1410,y:894,t:1527621300719};\\\", \\\"{x:1389,y:889,t:1527621300736};\\\", \\\"{x:1364,y:880,t:1527621300752};\\\", \\\"{x:1345,y:872,t:1527621300770};\\\", \\\"{x:1333,y:865,t:1527621300786};\\\", \\\"{x:1325,y:861,t:1527621300803};\\\", \\\"{x:1318,y:858,t:1527621300819};\\\", \\\"{x:1309,y:856,t:1527621300837};\\\", \\\"{x:1303,y:854,t:1527621300852};\\\", \\\"{x:1299,y:853,t:1527621300870};\\\", \\\"{x:1298,y:852,t:1527621300887};\\\", \\\"{x:1297,y:852,t:1527621300903};\\\", \\\"{x:1297,y:851,t:1527621300949};\\\", \\\"{x:1297,y:850,t:1527621301078};\\\", \\\"{x:1301,y:849,t:1527621301087};\\\", \\\"{x:1306,y:849,t:1527621301103};\\\", \\\"{x:1312,y:849,t:1527621301120};\\\", \\\"{x:1321,y:850,t:1527621301137};\\\", \\\"{x:1328,y:854,t:1527621301154};\\\", \\\"{x:1335,y:859,t:1527621301170};\\\", \\\"{x:1344,y:864,t:1527621301187};\\\", \\\"{x:1353,y:869,t:1527621301204};\\\", \\\"{x:1361,y:873,t:1527621301220};\\\", \\\"{x:1367,y:875,t:1527621301237};\\\", \\\"{x:1371,y:876,t:1527621301253};\\\", \\\"{x:1374,y:878,t:1527621301270};\\\", \\\"{x:1379,y:880,t:1527621301287};\\\", \\\"{x:1381,y:880,t:1527621301304};\\\", \\\"{x:1391,y:884,t:1527621301321};\\\", \\\"{x:1403,y:888,t:1527621301336};\\\", \\\"{x:1411,y:889,t:1527621301354};\\\", \\\"{x:1414,y:889,t:1527621301370};\\\", \\\"{x:1416,y:891,t:1527621301386};\\\", \\\"{x:1417,y:891,t:1527621301534};\\\", \\\"{x:1417,y:892,t:1527621301582};\\\", \\\"{x:1416,y:893,t:1527621301606};\\\", \\\"{x:1412,y:893,t:1527621301621};\\\", \\\"{x:1409,y:893,t:1527621301638};\\\", \\\"{x:1408,y:894,t:1527621301654};\\\", \\\"{x:1407,y:894,t:1527621301672};\\\", \\\"{x:1406,y:894,t:1527621301701};\\\", \\\"{x:1405,y:894,t:1527621301853};\\\", \\\"{x:1402,y:894,t:1527621301870};\\\", \\\"{x:1399,y:896,t:1527621301888};\\\", \\\"{x:1396,y:896,t:1527621301903};\\\", \\\"{x:1393,y:897,t:1527621301921};\\\", \\\"{x:1389,y:897,t:1527621301938};\\\", \\\"{x:1383,y:898,t:1527621301954};\\\", \\\"{x:1376,y:898,t:1527621301971};\\\", \\\"{x:1372,y:898,t:1527621301989};\\\", \\\"{x:1366,y:898,t:1527621302004};\\\", \\\"{x:1362,y:898,t:1527621302021};\\\", \\\"{x:1361,y:898,t:1527621302086};\\\", \\\"{x:1362,y:897,t:1527621302669};\\\", \\\"{x:1363,y:896,t:1527621303038};\\\", \\\"{x:1364,y:896,t:1527621303550};\\\", \\\"{x:1365,y:896,t:1527621303573};\\\", \\\"{x:1365,y:895,t:1527621303590};\\\", \\\"{x:1366,y:894,t:1527621303605};\\\", \\\"{x:1367,y:894,t:1527621303662};\\\", \\\"{x:1368,y:894,t:1527621303702};\\\", \\\"{x:1369,y:893,t:1527621303710};\\\", \\\"{x:1370,y:893,t:1527621303757};\\\", \\\"{x:1371,y:893,t:1527621303853};\\\", \\\"{x:1372,y:893,t:1527621303861};\\\", \\\"{x:1373,y:893,t:1527621303878};\\\", \\\"{x:1374,y:893,t:1527621303965};\\\", \\\"{x:1374,y:894,t:1527621304045};\\\", \\\"{x:1375,y:895,t:1527621304057};\\\", \\\"{x:1376,y:896,t:1527621304078};\\\", \\\"{x:1376,y:897,t:1527621304117};\\\", \\\"{x:1376,y:898,t:1527621304124};\\\", \\\"{x:1377,y:900,t:1527621304157};\\\", \\\"{x:1378,y:900,t:1527621304197};\\\", \\\"{x:1379,y:901,t:1527621304293};\\\", \\\"{x:1374,y:901,t:1527621306551};\\\", \\\"{x:1360,y:898,t:1527621306558};\\\", \\\"{x:1340,y:886,t:1527621306575};\\\", \\\"{x:1319,y:878,t:1527621306591};\\\", \\\"{x:1300,y:868,t:1527621306608};\\\", \\\"{x:1286,y:867,t:1527621306625};\\\", \\\"{x:1277,y:863,t:1527621306641};\\\", \\\"{x:1269,y:860,t:1527621306658};\\\", \\\"{x:1265,y:859,t:1527621306676};\\\", \\\"{x:1263,y:857,t:1527621306691};\\\", \\\"{x:1262,y:857,t:1527621306709};\\\", \\\"{x:1257,y:855,t:1527621306725};\\\", \\\"{x:1256,y:855,t:1527621306756};\\\", \\\"{x:1255,y:854,t:1527621306781};\\\", \\\"{x:1252,y:853,t:1527621306796};\\\", \\\"{x:1249,y:852,t:1527621306808};\\\", \\\"{x:1243,y:851,t:1527621306824};\\\", \\\"{x:1239,y:846,t:1527621306842};\\\", \\\"{x:1232,y:844,t:1527621306858};\\\", \\\"{x:1224,y:842,t:1527621306875};\\\", \\\"{x:1223,y:841,t:1527621306892};\\\", \\\"{x:1222,y:841,t:1527621306908};\\\", \\\"{x:1221,y:841,t:1527621306957};\\\", \\\"{x:1220,y:841,t:1527621307030};\\\", \\\"{x:1218,y:840,t:1527621307174};\\\", \\\"{x:1216,y:838,t:1527621307478};\\\", \\\"{x:1216,y:837,t:1527621307510};\\\", \\\"{x:1216,y:836,t:1527621307606};\\\", \\\"{x:1215,y:835,t:1527621307614};\\\", \\\"{x:1214,y:834,t:1527621307677};\\\", \\\"{x:1213,y:834,t:1527621307701};\\\", \\\"{x:1212,y:833,t:1527621307733};\\\", \\\"{x:1212,y:832,t:1527621307765};\\\", \\\"{x:1211,y:832,t:1527621307776};\\\", \\\"{x:1211,y:831,t:1527621311430};\\\", \\\"{x:1208,y:814,t:1527621311447};\\\", \\\"{x:1203,y:803,t:1527621311463};\\\", \\\"{x:1203,y:800,t:1527621311480};\\\", \\\"{x:1199,y:795,t:1527621311495};\\\", \\\"{x:1197,y:792,t:1527621311512};\\\", \\\"{x:1196,y:791,t:1527621311533};\\\", \\\"{x:1195,y:791,t:1527621311589};\\\", \\\"{x:1194,y:791,t:1527621311605};\\\", \\\"{x:1194,y:790,t:1527621311613};\\\", \\\"{x:1193,y:788,t:1527621311629};\\\", \\\"{x:1190,y:785,t:1527621311647};\\\", \\\"{x:1187,y:782,t:1527621311663};\\\", \\\"{x:1184,y:778,t:1527621311680};\\\", \\\"{x:1182,y:775,t:1527621311696};\\\", \\\"{x:1179,y:772,t:1527621311712};\\\", \\\"{x:1176,y:770,t:1527621311729};\\\", \\\"{x:1174,y:768,t:1527621311746};\\\", \\\"{x:1174,y:767,t:1527621311764};\\\", \\\"{x:1172,y:765,t:1527621311779};\\\", \\\"{x:1172,y:764,t:1527621311795};\\\", \\\"{x:1172,y:763,t:1527621311812};\\\", \\\"{x:1171,y:761,t:1527621311829};\\\", \\\"{x:1171,y:760,t:1527621311885};\\\", \\\"{x:1171,y:759,t:1527621311908};\\\", \\\"{x:1171,y:758,t:1527621311916};\\\", \\\"{x:1171,y:757,t:1527621311965};\\\", \\\"{x:1171,y:755,t:1527621311989};\\\", \\\"{x:1171,y:753,t:1527621312020};\\\", \\\"{x:1171,y:752,t:1527621312029};\\\", \\\"{x:1177,y:743,t:1527621312853};\\\", \\\"{x:1184,y:738,t:1527621312863};\\\", \\\"{x:1195,y:732,t:1527621312880};\\\", \\\"{x:1205,y:725,t:1527621312898};\\\", \\\"{x:1219,y:711,t:1527621312914};\\\", \\\"{x:1243,y:681,t:1527621312931};\\\", \\\"{x:1270,y:637,t:1527621312948};\\\", \\\"{x:1288,y:614,t:1527621312964};\\\", \\\"{x:1306,y:590,t:1527621312981};\\\", \\\"{x:1316,y:574,t:1527621312997};\\\", \\\"{x:1325,y:554,t:1527621313014};\\\", \\\"{x:1331,y:535,t:1527621313031};\\\", \\\"{x:1331,y:523,t:1527621313048};\\\", \\\"{x:1332,y:515,t:1527621313064};\\\", \\\"{x:1335,y:510,t:1527621313080};\\\", \\\"{x:1335,y:509,t:1527621313097};\\\", \\\"{x:1334,y:509,t:1527621313285};\\\", \\\"{x:1333,y:511,t:1527621313298};\\\", \\\"{x:1330,y:514,t:1527621313315};\\\", \\\"{x:1327,y:518,t:1527621313330};\\\", \\\"{x:1325,y:519,t:1527621313347};\\\", \\\"{x:1323,y:521,t:1527621313365};\\\", \\\"{x:1323,y:522,t:1527621313381};\\\", \\\"{x:1322,y:522,t:1527621313397};\\\", \\\"{x:1321,y:524,t:1527621313415};\\\", \\\"{x:1319,y:525,t:1527621313430};\\\", \\\"{x:1315,y:529,t:1527621313448};\\\", \\\"{x:1308,y:533,t:1527621313465};\\\", \\\"{x:1297,y:539,t:1527621313481};\\\", \\\"{x:1284,y:543,t:1527621313498};\\\", \\\"{x:1274,y:545,t:1527621313514};\\\", \\\"{x:1269,y:548,t:1527621313531};\\\", \\\"{x:1266,y:548,t:1527621313548};\\\", \\\"{x:1265,y:549,t:1527621313564};\\\", \\\"{x:1264,y:549,t:1527621313589};\\\", \\\"{x:1264,y:550,t:1527621313606};\\\", \\\"{x:1263,y:551,t:1527621313614};\\\", \\\"{x:1262,y:552,t:1527621313645};\\\", \\\"{x:1262,y:553,t:1527621313661};\\\", \\\"{x:1261,y:554,t:1527621313669};\\\", \\\"{x:1262,y:557,t:1527621313854};\\\", \\\"{x:1268,y:561,t:1527621313864};\\\", \\\"{x:1280,y:568,t:1527621313882};\\\", \\\"{x:1286,y:572,t:1527621313899};\\\", \\\"{x:1288,y:573,t:1527621313914};\\\", \\\"{x:1289,y:574,t:1527621313933};\\\", \\\"{x:1290,y:575,t:1527621314062};\\\", \\\"{x:1289,y:575,t:1527621314253};\\\", \\\"{x:1287,y:575,t:1527621314264};\\\", \\\"{x:1287,y:574,t:1527621314573};\\\", \\\"{x:1287,y:572,t:1527621314582};\\\", \\\"{x:1286,y:569,t:1527621314598};\\\", \\\"{x:1285,y:568,t:1527621314629};\\\", \\\"{x:1284,y:568,t:1527621314701};\\\", \\\"{x:1283,y:567,t:1527621314805};\\\", \\\"{x:1283,y:566,t:1527621314829};\\\", \\\"{x:1282,y:566,t:1527621314837};\\\", \\\"{x:1280,y:566,t:1527621314877};\\\", \\\"{x:1279,y:566,t:1527621314901};\\\", \\\"{x:1279,y:565,t:1527621314917};\\\", \\\"{x:1278,y:565,t:1527621314949};\\\", \\\"{x:1277,y:565,t:1527621314965};\\\", \\\"{x:1276,y:565,t:1527621314983};\\\", \\\"{x:1275,y:565,t:1527621315102};\\\", \\\"{x:1269,y:565,t:1527621323645};\\\", \\\"{x:1241,y:568,t:1527621323652};\\\", \\\"{x:1172,y:568,t:1527621323664};\\\", \\\"{x:1038,y:563,t:1527621323681};\\\", \\\"{x:917,y:555,t:1527621323699};\\\", \\\"{x:801,y:543,t:1527621323713};\\\", \\\"{x:702,y:531,t:1527621323731};\\\", \\\"{x:587,y:523,t:1527621323746};\\\", \\\"{x:475,y:528,t:1527621323763};\\\", \\\"{x:404,y:531,t:1527621323778};\\\", \\\"{x:375,y:536,t:1527621323796};\\\", \\\"{x:358,y:542,t:1527621323813};\\\", \\\"{x:356,y:544,t:1527621323829};\\\", \\\"{x:355,y:545,t:1527621323845};\\\", \\\"{x:357,y:547,t:1527621323862};\\\", \\\"{x:360,y:547,t:1527621323878};\\\", \\\"{x:362,y:548,t:1527621323895};\\\", \\\"{x:373,y:552,t:1527621323913};\\\", \\\"{x:377,y:555,t:1527621323928};\\\", \\\"{x:378,y:555,t:1527621324205};\\\", \\\"{x:380,y:555,t:1527621324213};\\\", \\\"{x:388,y:555,t:1527621324230};\\\", \\\"{x:390,y:556,t:1527621324247};\\\", \\\"{x:396,y:553,t:1527621324264};\\\", \\\"{x:402,y:553,t:1527621324281};\\\", \\\"{x:416,y:556,t:1527621324296};\\\", \\\"{x:420,y:559,t:1527621324314};\\\", \\\"{x:426,y:560,t:1527621324330};\\\", \\\"{x:430,y:563,t:1527621324347};\\\", \\\"{x:432,y:564,t:1527621324362};\\\", \\\"{x:428,y:564,t:1527621324429};\\\", \\\"{x:426,y:562,t:1527621324437};\\\", \\\"{x:425,y:562,t:1527621324447};\\\", \\\"{x:424,y:559,t:1527621324462};\\\", \\\"{x:427,y:551,t:1527621324480};\\\", \\\"{x:450,y:538,t:1527621324497};\\\", \\\"{x:461,y:524,t:1527621324513};\\\", \\\"{x:477,y:514,t:1527621324529};\\\", \\\"{x:496,y:508,t:1527621324547};\\\", \\\"{x:513,y:504,t:1527621324563};\\\", \\\"{x:522,y:503,t:1527621324579};\\\", \\\"{x:525,y:503,t:1527621324597};\\\", \\\"{x:526,y:503,t:1527621324613};\\\", \\\"{x:526,y:504,t:1527621324692};\\\", \\\"{x:532,y:505,t:1527621324701};\\\", \\\"{x:537,y:505,t:1527621324713};\\\", \\\"{x:551,y:507,t:1527621324730};\\\", \\\"{x:562,y:509,t:1527621324747};\\\", \\\"{x:576,y:512,t:1527621324764};\\\", \\\"{x:587,y:513,t:1527621324779};\\\", \\\"{x:600,y:516,t:1527621324797};\\\", \\\"{x:604,y:516,t:1527621324813};\\\", \\\"{x:605,y:518,t:1527621324829};\\\", \\\"{x:608,y:518,t:1527621324846};\\\", \\\"{x:609,y:520,t:1527621324863};\\\", \\\"{x:610,y:520,t:1527621324879};\\\", \\\"{x:611,y:520,t:1527621324896};\\\", \\\"{x:612,y:520,t:1527621325036};\\\", \\\"{x:612,y:523,t:1527621325180};\\\", \\\"{x:598,y:545,t:1527621325197};\\\", \\\"{x:585,y:571,t:1527621325213};\\\", \\\"{x:563,y:606,t:1527621325230};\\\", \\\"{x:536,y:652,t:1527621325247};\\\", \\\"{x:514,y:679,t:1527621325263};\\\", \\\"{x:503,y:699,t:1527621325280};\\\", \\\"{x:497,y:718,t:1527621325298};\\\", \\\"{x:493,y:732,t:1527621325314};\\\", \\\"{x:491,y:741,t:1527621325332};\\\", \\\"{x:490,y:745,t:1527621325347};\\\", \\\"{x:490,y:747,t:1527621325364};\\\", \\\"{x:490,y:751,t:1527621325380};\\\", \\\"{x:490,y:752,t:1527621325397};\\\", \\\"{x:490,y:755,t:1527621325413};\\\", \\\"{x:490,y:757,t:1527621325431};\\\", \\\"{x:491,y:761,t:1527621325447};\\\", \\\"{x:492,y:765,t:1527621325463};\\\", \\\"{x:492,y:768,t:1527621325480};\\\", \\\"{x:494,y:773,t:1527621325497};\\\", \\\"{x:494,y:774,t:1527621325597};\\\", \\\"{x:494,y:769,t:1527621325757};\\\", \\\"{x:494,y:768,t:1527621325765};\\\", \\\"{x:493,y:768,t:1527621325780};\\\", \\\"{x:492,y:763,t:1527621325797};\\\", \\\"{x:492,y:761,t:1527621325813};\\\", \\\"{x:492,y:759,t:1527621325830};\\\", \\\"{x:500,y:764,t:1527621326155};\\\", \\\"{x:515,y:775,t:1527621326164};\\\", \\\"{x:540,y:788,t:1527621326180};\\\", \\\"{x:595,y:804,t:1527621326197};\\\", \\\"{x:613,y:806,t:1527621326215};\\\", \\\"{x:725,y:828,t:1527621326231};\\\", \\\"{x:818,y:850,t:1527621326247};\\\", \\\"{x:916,y:870,t:1527621326264};\\\", \\\"{x:965,y:887,t:1527621326280};\\\", \\\"{x:999,y:902,t:1527621326297};\\\", \\\"{x:1013,y:904,t:1527621326315};\\\", \\\"{x:1015,y:904,t:1527621326330};\\\", \\\"{x:1016,y:904,t:1527621326628};\\\", \\\"{x:1017,y:904,t:1527621327108};\\\", \\\"{x:1020,y:900,t:1527621327132};\\\", \\\"{x:1020,y:899,t:1527621327147};\\\", \\\"{x:1021,y:897,t:1527621327165};\\\", \\\"{x:1021,y:896,t:1527621327181};\\\", \\\"{x:1021,y:894,t:1527621327198};\\\", \\\"{x:1023,y:892,t:1527621327216};\\\", \\\"{x:1025,y:891,t:1527621327231};\\\", \\\"{x:1028,y:888,t:1527621327248};\\\", \\\"{x:1029,y:885,t:1527621327265};\\\", \\\"{x:1031,y:883,t:1527621327282};\\\", \\\"{x:1033,y:881,t:1527621327299};\\\", \\\"{x:1038,y:877,t:1527621327315};\\\", \\\"{x:1043,y:872,t:1527621327331};\\\", \\\"{x:1059,y:859,t:1527621327348};\\\", \\\"{x:1071,y:849,t:1527621327366};\\\" ] }, { \\\"rt\\\": 63423, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 789950, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The point where the letter is on the graph is the start time, the end time is determined by the y-axis/duration. So, go to the 12pm tick mark on the axis and go up.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7864, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"1998\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 798820, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14795, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 814630, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3378, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 819340, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"Y9NLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"Y9NLY\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 307, dom: 779, initialDom: 853",
  "javascriptErrors": []
}