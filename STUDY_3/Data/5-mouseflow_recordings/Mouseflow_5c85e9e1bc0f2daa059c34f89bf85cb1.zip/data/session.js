var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5c85e9e1bc0f2daa059c34f89bf85cb1",
  "created": "2018-05-25T10:15:30.4738133-07:00",
  "lastActivity": "2018-05-25T10:15:48.3129368-07:00",
  "pageViews": [
    {
      "id": "05253046ac23eac22ae01a9dfaf23a4368e260ad",
      "startTime": "2018-05-25T10:15:30.5029368-07:00",
      "endTime": "2018-05-25T10:15:48.3129368-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 17810,
      "engagementTime": 17688,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17810,
  "engagementTime": 17688,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5QCE3",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "63126d6361f0426e1ad1666f32a87202",
  "gdpr": false
}