var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0604364753669bde135b2ccb10820227f9bc2798"] = {
  "startTime": "2018-06-04T19:08:36.5841147Z",
  "websitePageUrl": "/",
  "visitTime": 240229,
  "engagementTime": 46670,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "e13c8fbac3be48423671a96b29794502",
    "created": "2018-06-04T19:08:36.4352827+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "96b570af5d2df3115dd3eb8694a201d1",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/e13c8fbac3be48423671a96b29794502/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 341,
      "e": 341,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10001,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 188611,
      "e": 5101,
      "ty": 2,
      "x": 390,
      "y": 111
    },
    {
      "t": 188711,
      "e": 5201,
      "ty": 2,
      "x": 979,
      "y": 783
    },
    {
      "t": 188763,
      "e": 5253,
      "ty": 41,
      "x": 37859,
      "y": 59579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 188811,
      "e": 5301,
      "ty": 2,
      "x": 1060,
      "y": 918
    },
    {
      "t": 188911,
      "e": 5401,
      "ty": 2,
      "x": 1027,
      "y": 1003
    },
    {
      "t": 189010,
      "e": 5500,
      "ty": 2,
      "x": 820,
      "y": 974
    },
    {
      "t": 189011,
      "e": 5501,
      "ty": 41,
      "x": 25904,
      "y": 65284,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 189110,
      "e": 5600,
      "ty": 2,
      "x": 646,
      "y": 765
    },
    {
      "t": 189211,
      "e": 5701,
      "ty": 2,
      "x": 646,
      "y": 764
    },
    {
      "t": 189261,
      "e": 5751,
      "ty": 41,
      "x": 18721,
      "y": 0,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 189310,
      "e": 5800,
      "ty": 2,
      "x": 844,
      "y": 867
    },
    {
      "t": 189411,
      "e": 5901,
      "ty": 2,
      "x": 925,
      "y": 909
    },
    {
      "t": 189511,
      "e": 6001,
      "ty": 2,
      "x": 906,
      "y": 912
    },
    {
      "t": 189511,
      "e": 6001,
      "ty": 41,
      "x": 30135,
      "y": 60568,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 189610,
      "e": 6100,
      "ty": 2,
      "x": 873,
      "y": 904
    },
    {
      "t": 189710,
      "e": 6200,
      "ty": 2,
      "x": 850,
      "y": 883
    },
    {
      "t": 189761,
      "e": 6251,
      "ty": 41,
      "x": 27232,
      "y": 58210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 189810,
      "e": 6300,
      "ty": 2,
      "x": 841,
      "y": 881
    },
    {
      "t": 189910,
      "e": 6400,
      "ty": 2,
      "x": 820,
      "y": 879
    },
    {
      "t": 190010,
      "e": 6500,
      "ty": 2,
      "x": 812,
      "y": 874
    },
    {
      "t": 190012,
      "e": 6502,
      "ty": 41,
      "x": 28057,
      "y": 52428,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 190096,
      "e": 6586,
      "ty": 3,
      "x": 812,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 190111,
      "e": 6601,
      "ty": 2,
      "x": 812,
      "y": 872
    },
    {
      "t": 190174,
      "e": 6664,
      "ty": 4,
      "x": 28057,
      "y": 45874,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 190175,
      "e": 6665,
      "ty": 5,
      "x": 812,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 190176,
      "e": 6666,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 190179,
      "e": 6669,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 190261,
      "e": 6751,
      "ty": 41,
      "x": 50994,
      "y": 49151,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 190310,
      "e": 6800,
      "ty": 2,
      "x": 850,
      "y": 904
    },
    {
      "t": 190411,
      "e": 6901,
      "ty": 2,
      "x": 930,
      "y": 963
    },
    {
      "t": 190510,
      "e": 7000,
      "ty": 2,
      "x": 950,
      "y": 980
    },
    {
      "t": 190511,
      "e": 7001,
      "ty": 41,
      "x": 22118,
      "y": 5210,
      "ta": "#start"
    },
    {
      "t": 190610,
      "e": 7100,
      "ty": 2,
      "x": 994,
      "y": 993
    },
    {
      "t": 190760,
      "e": 7250,
      "ty": 41,
      "x": 46147,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 192362,
      "e": 8852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "122"
    },
    {
      "t": 192411,
      "e": 8901,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 192411,
      "e": 8901,
      "ty": 2,
      "x": 994,
      "y": 1059
    },
    {
      "t": 192475,
      "e": 8965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 192511,
      "e": 9001,
      "ty": 41,
      "x": 34464,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 192910,
      "e": 9400,
      "ty": 2,
      "x": 952,
      "y": 1107
    },
    {
      "t": 193011,
      "e": 9501,
      "ty": 2,
      "x": 952,
      "y": 1115
    },
    {
      "t": 193011,
      "e": 9501,
      "ty": 41,
      "x": 29256,
      "y": 23440,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 193210,
      "e": 9700,
      "ty": 2,
      "x": 957,
      "y": 1106
    },
    {
      "t": 193261,
      "e": 9751,
      "ty": 41,
      "x": 25940,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 193611,
      "e": 10101,
      "ty": 2,
      "x": 959,
      "y": 1104
    },
    {
      "t": 193761,
      "e": 10251,
      "ty": 41,
      "x": 27033,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 194360,
      "e": 10850,
      "ty": 3,
      "x": 959,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 194361,
      "e": 10851,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 194362,
      "e": 10852,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 194502,
      "e": 10992,
      "ty": 4,
      "x": 27033,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 194504,
      "e": 10994,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 194505,
      "e": 10995,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 194505,
      "e": 10995,
      "ty": 5,
      "x": 959,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 195512,
      "e": 12002,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 196015,
      "e": 12505,
      "ty": 2,
      "x": 959,
      "y": 1023
    },
    {
      "t": 196015,
      "e": 12505,
      "ty": 41,
      "x": 32750,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 196096,
      "e": 12586,
      "ty": 6,
      "x": 919,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 196111,
      "e": 12601,
      "ty": 2,
      "x": 919,
      "y": 693
    },
    {
      "t": 196114,
      "e": 12604,
      "ty": 7,
      "x": 919,
      "y": 555,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 196210,
      "e": 12700,
      "ty": 2,
      "x": 919,
      "y": 334
    },
    {
      "t": 196261,
      "e": 12751,
      "ty": 41,
      "x": 31372,
      "y": 17782,
      "ta": "html > body"
    },
    {
      "t": 196310,
      "e": 12800,
      "ty": 2,
      "x": 917,
      "y": 329
    },
    {
      "t": 196410,
      "e": 12900,
      "ty": 2,
      "x": 901,
      "y": 547
    },
    {
      "t": 196446,
      "e": 12936,
      "ty": 6,
      "x": 901,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 196496,
      "e": 12986,
      "ty": 7,
      "x": 899,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 196510,
      "e": 13000,
      "ty": 2,
      "x": 899,
      "y": 608
    },
    {
      "t": 196511,
      "e": 13001,
      "ty": 41,
      "x": 19682,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 196610,
      "e": 13100,
      "ty": 2,
      "x": 896,
      "y": 613
    },
    {
      "t": 196710,
      "e": 13200,
      "ty": 2,
      "x": 892,
      "y": 613
    },
    {
      "t": 196746,
      "e": 13236,
      "ty": 6,
      "x": 887,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 196761,
      "e": 13251,
      "ty": 41,
      "x": 17086,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 196811,
      "e": 13301,
      "ty": 2,
      "x": 883,
      "y": 600
    },
    {
      "t": 196910,
      "e": 13400,
      "ty": 2,
      "x": 881,
      "y": 594
    },
    {
      "t": 197011,
      "e": 13501,
      "ty": 2,
      "x": 881,
      "y": 589
    },
    {
      "t": 197011,
      "e": 13501,
      "ty": 41,
      "x": 15788,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 197072,
      "e": 13562,
      "ty": 3,
      "x": 881,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 197073,
      "e": 13563,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 197111,
      "e": 13601,
      "ty": 2,
      "x": 881,
      "y": 588
    },
    {
      "t": 197247,
      "e": 13737,
      "ty": 4,
      "x": 15788,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 197248,
      "e": 13738,
      "ty": 5,
      "x": 881,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 197261,
      "e": 13751,
      "ty": 41,
      "x": 15788,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 198875,
      "e": 15365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 199171,
      "e": 15661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 199172,
      "e": 15662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199250,
      "e": 15740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Y"
    },
    {
      "t": 199395,
      "e": 15885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 199396,
      "e": 15886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199531,
      "e": 16021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YA"
    },
    {
      "t": 199587,
      "e": 16077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 199588,
      "e": 16078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199682,
      "e": 16172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YAN"
    },
    {
      "t": 199714,
      "e": 16204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 199714,
      "e": 16204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199816,
      "e": 16306,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANK"
    },
    {
      "t": 199843,
      "e": 16333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANK"
    },
    {
      "t": 200011,
      "e": 16501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 200130,
      "e": 16620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 200130,
      "e": 16620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200250,
      "e": 16740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 200387,
      "e": 16877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 200388,
      "e": 16878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200482,
      "e": 16972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 200515,
      "e": 17005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 200993,
      "e": 17483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 200994,
      "e": 17484,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANKEE"
    },
    {
      "t": 200994,
      "e": 17484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200995,
      "e": 17485,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 201082,
      "e": 17572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 203091,
      "e": 19581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 203091,
      "e": 19581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 203178,
      "e": 19668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 203267,
      "e": 19757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 203267,
      "e": 19757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 203331,
      "e": 19821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 203435,
      "e": 19925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 203436,
      "e": 19926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 203522,
      "e": 20012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 203987,
      "e": 20477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 203987,
      "e": 20477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 204114,
      "e": 20604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*\n"
    },
    {
      "t": 205563,
      "e": 22053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 205642,
      "e": 22132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 206211,
      "e": 22701,
      "ty": 2,
      "x": 890,
      "y": 587
    },
    {
      "t": 206240,
      "e": 22730,
      "ty": 7,
      "x": 968,
      "y": 632,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 206254,
      "e": 22744,
      "ty": 6,
      "x": 1024,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206261,
      "e": 22751,
      "ty": 41,
      "x": 46718,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206272,
      "e": 22762,
      "ty": 7,
      "x": 1053,
      "y": 712,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206311,
      "e": 22801,
      "ty": 2,
      "x": 1063,
      "y": 733
    },
    {
      "t": 206412,
      "e": 22902,
      "ty": 2,
      "x": 1061,
      "y": 733
    },
    {
      "t": 206488,
      "e": 22978,
      "ty": 6,
      "x": 1017,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 206505,
      "e": 22995,
      "ty": 7,
      "x": 1000,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 206511,
      "e": 23001,
      "ty": 2,
      "x": 1000,
      "y": 706
    },
    {
      "t": 206511,
      "e": 23001,
      "ty": 41,
      "x": 41527,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 206521,
      "e": 23011,
      "ty": 6,
      "x": 980,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206572,
      "e": 23062,
      "ty": 7,
      "x": 910,
      "y": 676,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206611,
      "e": 23101,
      "ty": 2,
      "x": 902,
      "y": 675
    },
    {
      "t": 206672,
      "e": 23162,
      "ty": 6,
      "x": 905,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206711,
      "e": 23201,
      "ty": 2,
      "x": 914,
      "y": 697
    },
    {
      "t": 206722,
      "e": 23212,
      "ty": 7,
      "x": 917,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206761,
      "e": 23251,
      "ty": 41,
      "x": 24873,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 206772,
      "e": 23262,
      "ty": 6,
      "x": 924,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 206811,
      "e": 23301,
      "ty": 2,
      "x": 926,
      "y": 713
    },
    {
      "t": 206911,
      "e": 23401,
      "ty": 2,
      "x": 926,
      "y": 718
    },
    {
      "t": 206959,
      "e": 23449,
      "ty": 3,
      "x": 926,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 206960,
      "e": 23450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 206961,
      "e": 23451,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 206962,
      "e": 23452,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 207011,
      "e": 23501,
      "ty": 41,
      "x": 15501,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 207062,
      "e": 23552,
      "ty": 4,
      "x": 15501,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 207063,
      "e": 23553,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 207064,
      "e": 23554,
      "ty": 5,
      "x": 926,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 207065,
      "e": 23555,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 207711,
      "e": 24201,
      "ty": 2,
      "x": 923,
      "y": 720
    },
    {
      "t": 207761,
      "e": 24251,
      "ty": 41,
      "x": 31131,
      "y": 41492,
      "ta": "html > body"
    },
    {
      "t": 207812,
      "e": 24302,
      "ty": 2,
      "x": 912,
      "y": 757
    },
    {
      "t": 208172,
      "e": 24662,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 208200,
      "e": 24690,
      "ty": 6,
      "x": 912,
      "y": 757,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 208615,
      "e": 25105,
      "ty": 7,
      "x": 891,
      "y": 743,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 208615,
      "e": 25105,
      "ty": 6,
      "x": 891,
      "y": 743,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 208623,
      "e": 25113,
      "ty": 7,
      "x": 852,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 208623,
      "e": 25113,
      "ty": 6,
      "x": 852,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 208639,
      "e": 25129,
      "ty": 7,
      "x": 785,
      "y": 688,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 208640,
      "e": 25130,
      "ty": 6,
      "x": 785,
      "y": 688,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 208657,
      "e": 25147,
      "ty": 7,
      "x": 723,
      "y": 654,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 208711,
      "e": 25201,
      "ty": 2,
      "x": 583,
      "y": 560
    },
    {
      "t": 208723,
      "e": 25213,
      "ty": 6,
      "x": 542,
      "y": 525,
      "ta": "#da1"
    },
    {
      "t": 208740,
      "e": 25230,
      "ty": 7,
      "x": 490,
      "y": 471,
      "ta": "#da1"
    },
    {
      "t": 208762,
      "e": 25252,
      "ty": 41,
      "x": 6766,
      "y": 9380,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 208811,
      "e": 25301,
      "ty": 2,
      "x": 265,
      "y": 137
    },
    {
      "t": 208911,
      "e": 25401,
      "ty": 2,
      "x": 189,
      "y": 0
    },
    {
      "t": 209011,
      "e": 25501,
      "ty": 2,
      "x": 196,
      "y": 42
    },
    {
      "t": 209012,
      "e": 25502,
      "ty": 41,
      "x": 6474,
      "y": 1883,
      "ta": "> div.masterdiv"
    },
    {
      "t": 209112,
      "e": 25602,
      "ty": 2,
      "x": 277,
      "y": 297
    },
    {
      "t": 209212,
      "e": 25702,
      "ty": 2,
      "x": 383,
      "y": 381
    },
    {
      "t": 209261,
      "e": 25751,
      "ty": 41,
      "x": 6766,
      "y": 19160,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209312,
      "e": 25802,
      "ty": 2,
      "x": 454,
      "y": 412
    },
    {
      "t": 209411,
      "e": 25901,
      "ty": 2,
      "x": 474,
      "y": 424
    },
    {
      "t": 209512,
      "e": 26002,
      "ty": 41,
      "x": 8882,
      "y": 21083,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 210011,
      "e": 26501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 217211,
      "e": 31002,
      "ty": 2,
      "x": 474,
      "y": 425
    },
    {
      "t": 217261,
      "e": 31052,
      "ty": 41,
      "x": 8882,
      "y": 22253,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 217411,
      "e": 31202,
      "ty": 2,
      "x": 467,
      "y": 448
    },
    {
      "t": 217511,
      "e": 31302,
      "ty": 2,
      "x": 436,
      "y": 510
    },
    {
      "t": 217511,
      "e": 31302,
      "ty": 41,
      "x": 11182,
      "y": 4717,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[2] > td"
    },
    {
      "t": 217515,
      "e": 31306,
      "ty": 6,
      "x": 434,
      "y": 512,
      "ta": "#da1"
    },
    {
      "t": 217610,
      "e": 31401,
      "ty": 2,
      "x": 434,
      "y": 513
    },
    {
      "t": 217761,
      "e": 31552,
      "ty": 41,
      "x": 10975,
      "y": 3327,
      "ta": "#da1"
    },
    {
      "t": 226511,
      "e": 36552,
      "ty": 7,
      "x": 432,
      "y": 507,
      "ta": "#da1"
    },
    {
      "t": 226512,
      "e": 36553,
      "ty": 2,
      "x": 432,
      "y": 507
    },
    {
      "t": 226513,
      "e": 36554,
      "ty": 41,
      "x": 10745,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 226611,
      "e": 36652,
      "ty": 2,
      "x": 374,
      "y": 352
    },
    {
      "t": 226762,
      "e": 36803,
      "ty": 41,
      "x": 3962,
      "y": 15629,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 226811,
      "e": 36852,
      "ty": 2,
      "x": 469,
      "y": 358
    },
    {
      "t": 226911,
      "e": 36952,
      "ty": 2,
      "x": 1368,
      "y": 663
    },
    {
      "t": 227011,
      "e": 37052,
      "ty": 2,
      "x": 1408,
      "y": 1128
    },
    {
      "t": 227011,
      "e": 37052,
      "ty": 41,
      "x": 48212,
      "y": 62044,
      "ta": "> div.masterdiv"
    },
    {
      "t": 227111,
      "e": 37152,
      "ty": 2,
      "x": 1350,
      "y": 1151
    },
    {
      "t": 227159,
      "e": 37200,
      "ty": 6,
      "x": 1026,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 227175,
      "e": 37216,
      "ty": 7,
      "x": 843,
      "y": 1034,
      "ta": "#start"
    },
    {
      "t": 227211,
      "e": 37252,
      "ty": 2,
      "x": 714,
      "y": 999
    },
    {
      "t": 227261,
      "e": 37302,
      "ty": 41,
      "x": 19410,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 227311,
      "e": 37352,
      "ty": 2,
      "x": 686,
      "y": 1002
    },
    {
      "t": 227411,
      "e": 37452,
      "ty": 2,
      "x": 806,
      "y": 1064
    },
    {
      "t": 227511,
      "e": 37552,
      "ty": 2,
      "x": 1026,
      "y": 1135
    },
    {
      "t": 227511,
      "e": 37552,
      "ty": 41,
      "x": 63896,
      "y": 34520,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 227706,
      "e": 37747,
      "ty": 6,
      "x": 985,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 227711,
      "e": 37752,
      "ty": 2,
      "x": 985,
      "y": 1106
    },
    {
      "t": 227761,
      "e": 37802,
      "ty": 41,
      "x": 35225,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 227812,
      "e": 37853,
      "ty": 2,
      "x": 971,
      "y": 1099
    },
    {
      "t": 227880,
      "e": 37921,
      "ty": 3,
      "x": 971,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 227881,
      "e": 37922,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 227959,
      "e": 38000,
      "ty": 4,
      "x": 33586,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 227961,
      "e": 38002,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 227962,
      "e": 38003,
      "ty": 5,
      "x": 971,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 227968,
      "e": 38009,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 228011,
      "e": 38052,
      "ty": 41,
      "x": 33163,
      "y": 60438,
      "ta": "html > body"
    },
    {
      "t": 228965,
      "e": 39006,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 230012,
      "e": 40053,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 236611,
      "e": 43052,
      "ty": 2,
      "x": 987,
      "y": 1057
    },
    {
      "t": 236711,
      "e": 43152,
      "ty": 2,
      "x": 1001,
      "y": 1033
    },
    {
      "t": 236762,
      "e": 43203,
      "ty": 41,
      "x": 47816,
      "y": 57343,
      "ta": "> p"
    },
    {
      "t": 236811,
      "e": 43252,
      "ty": 2,
      "x": 1002,
      "y": 1032
    },
    {
      "t": 237391,
      "e": 43832,
      "ty": 3,
      "x": 1002,
      "y": 1032,
      "ta": "> p"
    },
    {
      "t": 237550,
      "e": 43991,
      "ty": 4,
      "x": 47816,
      "y": 57343,
      "ta": "> p"
    },
    {
      "t": 237550,
      "e": 43991,
      "ty": 5,
      "x": 1002,
      "y": 1032,
      "ta": "> p"
    },
    {
      "t": 238010,
      "e": 44451,
      "ty": 2,
      "x": 994,
      "y": 1020
    },
    {
      "t": 238011,
      "e": 44452,
      "ty": 41,
      "x": 44984,
      "y": 29256,
      "ta": "> p"
    },
    {
      "t": 238111,
      "e": 44552,
      "ty": 2,
      "x": 988,
      "y": 1016
    },
    {
      "t": 238199,
      "e": 44640,
      "ty": 3,
      "x": 988,
      "y": 1016,
      "ta": "> p"
    },
    {
      "t": 238261,
      "e": 44702,
      "ty": 41,
      "x": 42860,
      "y": 19894,
      "ta": "> p"
    },
    {
      "t": 238334,
      "e": 44775,
      "ty": 4,
      "x": 42860,
      "y": 19894,
      "ta": "> p"
    },
    {
      "t": 238334,
      "e": 44775,
      "ty": 5,
      "x": 988,
      "y": 1016,
      "ta": "> p"
    },
    {
      "t": 239219,
      "e": 45660,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 240229,
      "e": 46670,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 199, dom: 654, initialDom: 682",
  "javascriptErrors": []
}