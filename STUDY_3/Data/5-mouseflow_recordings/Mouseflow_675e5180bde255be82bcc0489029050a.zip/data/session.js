var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "675e5180bde255be82bcc0489029050a",
  "created": "2018-05-22T14:09:27.8158375-07:00",
  "lastActivity": "2018-05-22T14:10:47.4810172-07:00",
  "pageViews": [
    {
      "id": "052228293a3dd84c7accf1643e910eb0f81764ad",
      "startTime": "2018-05-22T14:09:27.9050172-07:00",
      "endTime": "2018-05-22T14:10:47.4810172-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 79576,
      "engagementTime": 63418,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 79576,
  "engagementTime": 63418,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OZV09",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "377ff9d50746550c36811fee5b1fbe6e",
  "gdpr": false
}