var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525133302486a7094461e52a75337bc27744c77"] = {
  "startTime": "2018-05-25T17:18:13.4107035Z",
  "websitePageUrl": "/16",
  "visitTime": 67103,
  "engagementTime": 63075,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "cc4b36f9ba4a6ee4066985cc60a5750d",
    "created": "2018-05-25T17:18:13.4107035+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=AKYQ8",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6974e19c0580b1ebf5cc4a6eb7abdd08",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/cc4b36f9ba4a6ee4066985cc60a5750d/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 187,
      "e": 187,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 187,
      "e": 187,
      "ty": 2,
      "x": 361,
      "y": 738
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 29665,
      "y": 40440,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 361,
      "y": 737
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 361,
      "y": 735
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 29665,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 363,
      "y": 734
    },
    {
      "t": 803,
      "e": 803,
      "ty": 2,
      "x": 443,
      "y": 651
    },
    {
      "t": 803,
      "e": 803,
      "ty": 41,
      "x": 58235,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 473,
      "y": 615
    },
    {
      "t": 921,
      "e": 921,
      "ty": 6,
      "x": 486,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 504,
      "y": 558
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 45740,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1087,
      "e": 1087,
      "ty": 7,
      "x": 517,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1102,
      "e": 1102,
      "ty": 2,
      "x": 517,
      "y": 521
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 47201,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 2053,
      "e": 2053,
      "ty": 6,
      "x": 517,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2104,
      "e": 2104,
      "ty": 2,
      "x": 500,
      "y": 583
    },
    {
      "t": 2204,
      "e": 2204,
      "ty": 2,
      "x": 491,
      "y": 591
    },
    {
      "t": 2255,
      "e": 2255,
      "ty": 41,
      "x": 44278,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2404,
      "e": 2404,
      "ty": 2,
      "x": 489,
      "y": 591
    },
    {
      "t": 2505,
      "e": 2505,
      "ty": 2,
      "x": 481,
      "y": 559
    },
    {
      "t": 2505,
      "e": 2505,
      "ty": 41,
      "x": 43154,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2605,
      "e": 2605,
      "ty": 2,
      "x": 480,
      "y": 557
    },
    {
      "t": 2754,
      "e": 2754,
      "ty": 41,
      "x": 43042,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2885,
      "e": 2885,
      "ty": 3,
      "x": 480,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2888,
      "e": 2888,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2971,
      "e": 2971,
      "ty": 4,
      "x": 43042,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2971,
      "e": 2971,
      "ty": 5,
      "x": 480,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10004,
      "e": 7971,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10952,
      "e": 7971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 10952,
      "e": 7971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11024,
      "e": 8043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "c"
    },
    {
      "t": 11064,
      "e": 8083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11065,
      "e": 8084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11112,
      "e": 8131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ch"
    },
    {
      "t": 11177,
      "e": 8196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11178,
      "e": 8197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11232,
      "e": 8251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "che"
    },
    {
      "t": 11344,
      "e": 8363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11345,
      "e": 8364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11424,
      "e": 8443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "chec"
    },
    {
      "t": 11456,
      "e": 8475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 11457,
      "e": 8476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11567,
      "e": 8586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11568,
      "e": 8587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11593,
      "e": 8612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 11648,
      "e": 8667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11711,
      "e": 8730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11712,
      "e": 8731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11792,
      "e": 8811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11847,
      "e": 8866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11848,
      "e": 8867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11887,
      "e": 8906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11920,
      "e": 8939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11920,
      "e": 8939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12008,
      "e": 9027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12032,
      "e": 9051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12032,
      "e": 9051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12095,
      "e": 9114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12206,
      "e": 9225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the "
    },
    {
      "t": 13056,
      "e": 10075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13057,
      "e": 10076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13104,
      "e": 10123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13152,
      "e": 10171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13153,
      "e": 10172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13199,
      "e": 10218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13240,
      "e": 10259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13240,
      "e": 10259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13385,
      "e": 10404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13576,
      "e": 10595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13577,
      "e": 10596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13647,
      "e": 10666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13727,
      "e": 10746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13728,
      "e": 10747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13792,
      "e": 10811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13833,
      "e": 10852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13833,
      "e": 10852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13903,
      "e": 10922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14005,
      "e": 11024,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis"
    },
    {
      "t": 14095,
      "e": 11114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14096,
      "e": 11115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14167,
      "e": 11186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20004,
      "e": 16186,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20016,
      "e": 16186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20017,
      "e": 16187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20087,
      "e": 16257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20103,
      "e": 16273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20103,
      "e": 16273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20167,
      "e": 16337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20224,
      "e": 16394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20224,
      "e": 16394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20295,
      "e": 16465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20311,
      "e": 16481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20312,
      "e": 16482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20384,
      "e": 16554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21024,
      "e": 17194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21024,
      "e": 17194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21112,
      "e": 17282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21216,
      "e": 17386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21217,
      "e": 17387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21280,
      "e": 17450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21383,
      "e": 17553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21384,
      "e": 17554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21440,
      "e": 17610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21472,
      "e": 17642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21472,
      "e": 17642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21520,
      "e": 17690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22015,
      "e": 18185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22016,
      "e": 18186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22056,
      "e": 18226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22207,
      "e": 18377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see h"
    },
    {
      "t": 22376,
      "e": 18546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22447,
      "e": 18617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see "
    },
    {
      "t": 22528,
      "e": 18698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22528,
      "e": 18698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22600,
      "e": 18770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 22657,
      "e": 18827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22657,
      "e": 18827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22712,
      "e": 18882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22752,
      "e": 18922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22753,
      "e": 18923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22809,
      "e": 18979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22872,
      "e": 19042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22873,
      "e": 19043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22984,
      "e": 19154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22984,
      "e": 19154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22992,
      "e": 19162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 23087,
      "e": 19257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23801,
      "e": 19971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 23801,
      "e": 19971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23863,
      "e": 20033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23984,
      "e": 20154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23984,
      "e": 20154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24031,
      "e": 20201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24473,
      "e": 20643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24473,
      "e": 20643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24536,
      "e": 20706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24632,
      "e": 20802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24633,
      "e": 20803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24703,
      "e": 20873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24743,
      "e": 20913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24743,
      "e": 20913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24792,
      "e": 20962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24816,
      "e": 20986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24816,
      "e": 20986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24888,
      "e": 21058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25007,
      "e": 21177,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see what point "
    },
    {
      "t": 25152,
      "e": 21322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25208,
      "e": 21378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see what point"
    },
    {
      "t": 25271,
      "e": 21441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25272,
      "e": 21442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25312,
      "e": 21482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25328,
      "e": 21498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25328,
      "e": 21498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25407,
      "e": 21577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25857,
      "e": 22027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25858,
      "e": 22028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25928,
      "e": 22098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26032,
      "e": 22202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26032,
      "e": 22202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26088,
      "e": 22258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26129,
      "e": 22299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26130,
      "e": 22300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26192,
      "e": 22362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26192,
      "e": 22362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26207,
      "e": 22377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26279,
      "e": 22449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26361,
      "e": 22531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26362,
      "e": 22532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26448,
      "e": 22618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26552,
      "e": 22722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26552,
      "e": 22722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26616,
      "e": 22786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26617,
      "e": 22787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26640,
      "e": 22810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 26688,
      "e": 22858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26806,
      "e": 22976,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see what points lie on "
    },
    {
      "t": 26840,
      "e": 23010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26840,
      "e": 23010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26896,
      "e": 23066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26920,
      "e": 23090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26920,
      "e": 23090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26968,
      "e": 23138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27065,
      "e": 23235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27065,
      "e": 23235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27104,
      "e": 23274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27104,
      "e": 23274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27127,
      "e": 23297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 27143,
      "e": 23313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30005,
      "e": 26175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30232,
      "e": 26402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 30232,
      "e": 26402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30304,
      "e": 26474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 30304,
      "e": 26474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30319,
      "e": 26489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 30447,
      "e": 26617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30521,
      "e": 26691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30522,
      "e": 26692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30591,
      "e": 26761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 30712,
      "e": 26882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30713,
      "e": 26883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30800,
      "e": 26970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30800,
      "e": 26970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30847,
      "e": 27017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 30927,
      "e": 27097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31553,
      "e": 27723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 31554,
      "e": 27724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31615,
      "e": 27785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 32205,
      "e": 28375,
      "ty": 2,
      "x": 503,
      "y": 599
    },
    {
      "t": 32216,
      "e": 28386,
      "ty": 7,
      "x": 516,
      "y": 620,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32255,
      "e": 28425,
      "ty": 41,
      "x": 48438,
      "y": 35288,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32304,
      "e": 28474,
      "ty": 2,
      "x": 528,
      "y": 645
    },
    {
      "t": 32405,
      "e": 28575,
      "ty": 2,
      "x": 513,
      "y": 686
    },
    {
      "t": 32505,
      "e": 28675,
      "ty": 2,
      "x": 483,
      "y": 689
    },
    {
      "t": 32505,
      "e": 28675,
      "ty": 41,
      "x": 43379,
      "y": 37725,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32605,
      "e": 28775,
      "ty": 2,
      "x": 438,
      "y": 689
    },
    {
      "t": 32705,
      "e": 28875,
      "ty": 2,
      "x": 436,
      "y": 689
    },
    {
      "t": 32755,
      "e": 28925,
      "ty": 41,
      "x": 54958,
      "y": 44082,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32885,
      "e": 29055,
      "ty": 6,
      "x": 435,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 32905,
      "e": 29075,
      "ty": 2,
      "x": 437,
      "y": 679
    },
    {
      "t": 33004,
      "e": 29174,
      "ty": 2,
      "x": 440,
      "y": 668
    },
    {
      "t": 33005,
      "e": 29175,
      "ty": 41,
      "x": 55380,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 33052,
      "e": 29222,
      "ty": 3,
      "x": 440,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 33053,
      "e": 29223,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "check the x axis and see what points lie on the 12pm \n"
    },
    {
      "t": 33053,
      "e": 29223,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33054,
      "e": 29224,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33173,
      "e": 29343,
      "ty": 4,
      "x": 55380,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 33191,
      "e": 29361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33193,
      "e": 29363,
      "ty": 5,
      "x": 440,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 33199,
      "e": 29369,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 33505,
      "e": 29675,
      "ty": 2,
      "x": 457,
      "y": 689
    },
    {
      "t": 33505,
      "e": 29675,
      "ty": 41,
      "x": 15462,
      "y": 37725,
      "ta": "html > body"
    },
    {
      "t": 34200,
      "e": 30370,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 34208,
      "e": 30378,
      "ty": 2,
      "x": 1232,
      "y": 671
    },
    {
      "t": 34255,
      "e": 30425,
      "ty": 41,
      "x": 52173,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 34304,
      "e": 30474,
      "ty": 2,
      "x": 1778,
      "y": 645
    },
    {
      "t": 34405,
      "e": 30575,
      "ty": 2,
      "x": 1839,
      "y": 631
    },
    {
      "t": 34504,
      "e": 30674,
      "ty": 2,
      "x": 1815,
      "y": 605
    },
    {
      "t": 34505,
      "e": 30675,
      "ty": 41,
      "x": 62228,
      "y": 33072,
      "ta": "html > body"
    },
    {
      "t": 34605,
      "e": 30775,
      "ty": 2,
      "x": 1551,
      "y": 554
    },
    {
      "t": 34710,
      "e": 30880,
      "ty": 2,
      "x": 1235,
      "y": 581
    },
    {
      "t": 34755,
      "e": 30925,
      "ty": 41,
      "x": 40739,
      "y": 31798,
      "ta": "html > body"
    },
    {
      "t": 34805,
      "e": 30975,
      "ty": 2,
      "x": 1132,
      "y": 576
    },
    {
      "t": 34817,
      "e": 30987,
      "ty": 6,
      "x": 1101,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34851,
      "e": 31021,
      "ty": 7,
      "x": 1047,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34905,
      "e": 31075,
      "ty": 2,
      "x": 1034,
      "y": 543
    },
    {
      "t": 35005,
      "e": 31175,
      "ty": 41,
      "x": 48880,
      "y": 37347,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35068,
      "e": 31238,
      "ty": 3,
      "x": 1034,
      "y": 543,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35205,
      "e": 31375,
      "ty": 2,
      "x": 1034,
      "y": 546
    },
    {
      "t": 35220,
      "e": 31390,
      "ty": 4,
      "x": 48880,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35221,
      "e": 31391,
      "ty": 5,
      "x": 1034,
      "y": 549,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35255,
      "e": 31425,
      "ty": 41,
      "x": 48880,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35305,
      "e": 31475,
      "ty": 2,
      "x": 1034,
      "y": 551
    },
    {
      "t": 35428,
      "e": 31598,
      "ty": 3,
      "x": 1034,
      "y": 551,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35556,
      "e": 31726,
      "ty": 4,
      "x": 48880,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35556,
      "e": 31726,
      "ty": 5,
      "x": 1034,
      "y": 551,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35589,
      "e": 31759,
      "ty": 6,
      "x": 1034,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35605,
      "e": 31775,
      "ty": 2,
      "x": 1035,
      "y": 555
    },
    {
      "t": 35705,
      "e": 31875,
      "ty": 2,
      "x": 1037,
      "y": 563
    },
    {
      "t": 35756,
      "e": 31926,
      "ty": 41,
      "x": 49529,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35852,
      "e": 32022,
      "ty": 3,
      "x": 1037,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35853,
      "e": 32023,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35948,
      "e": 32118,
      "ty": 4,
      "x": 49529,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35948,
      "e": 32118,
      "ty": 5,
      "x": 1037,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36005,
      "e": 32175,
      "ty": 2,
      "x": 1038,
      "y": 564
    },
    {
      "t": 36005,
      "e": 32175,
      "ty": 41,
      "x": 49746,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36036,
      "e": 32206,
      "ty": 7,
      "x": 1058,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36105,
      "e": 32275,
      "ty": 2,
      "x": 1071,
      "y": 542
    },
    {
      "t": 36256,
      "e": 32426,
      "ty": 41,
      "x": 56883,
      "y": 36643,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 36585,
      "e": 32755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 36585,
      "e": 32755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36647,
      "e": 32817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 36648,
      "e": 32818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36735,
      "e": 32905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 36759,
      "e": 32929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 37172,
      "e": 33342,
      "ty": 6,
      "x": 945,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37204,
      "e": 33374,
      "ty": 7,
      "x": 929,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37205,
      "e": 33375,
      "ty": 2,
      "x": 929,
      "y": 589
    },
    {
      "t": 37237,
      "e": 33407,
      "ty": 6,
      "x": 927,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37255,
      "e": 33425,
      "ty": 41,
      "x": 25738,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37305,
      "e": 33475,
      "ty": 2,
      "x": 927,
      "y": 651
    },
    {
      "t": 37580,
      "e": 33750,
      "ty": 3,
      "x": 927,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37582,
      "e": 33752,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 37582,
      "e": 33752,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37582,
      "e": 33752,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37684,
      "e": 33854,
      "ty": 4,
      "x": 25738,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37685,
      "e": 33855,
      "ty": 5,
      "x": 927,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38551,
      "e": 34721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 38631,
      "e": 34801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 38655,
      "e": 34825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 38656,
      "e": 34826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38711,
      "e": 34881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 39089,
      "e": 35259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 39089,
      "e": 35259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39183,
      "e": 35353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 39183,
      "e": 35353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39255,
      "e": 35425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 39328,
      "e": 35498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 39539,
      "e": 35709,
      "ty": 7,
      "x": 917,
      "y": 645,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39584,
      "e": 35754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 39604,
      "e": 35774,
      "ty": 2,
      "x": 672,
      "y": 538
    },
    {
      "t": 39680,
      "e": 35850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 39705,
      "e": 35875,
      "ty": 2,
      "x": 672,
      "y": 536
    },
    {
      "t": 39754,
      "e": 35924,
      "ty": 41,
      "x": 23211,
      "y": 29859,
      "ta": "html > body"
    },
    {
      "t": 39804,
      "e": 35974,
      "ty": 2,
      "x": 777,
      "y": 588
    },
    {
      "t": 39904,
      "e": 36074,
      "ty": 2,
      "x": 1009,
      "y": 637
    },
    {
      "t": 39940,
      "e": 36110,
      "ty": 6,
      "x": 1009,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40004,
      "e": 36174,
      "ty": 2,
      "x": 1009,
      "y": 653
    },
    {
      "t": 40005,
      "e": 36175,
      "ty": 41,
      "x": 43473,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40005,
      "e": 36175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40072,
      "e": 36242,
      "ty": 7,
      "x": 1009,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40089,
      "e": 36259,
      "ty": 6,
      "x": 1009,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40104,
      "e": 36274,
      "ty": 2,
      "x": 1009,
      "y": 677
    },
    {
      "t": 40204,
      "e": 36374,
      "ty": 2,
      "x": 1007,
      "y": 687
    },
    {
      "t": 40254,
      "e": 36424,
      "ty": 41,
      "x": 57248,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40267,
      "e": 36437,
      "ty": 3,
      "x": 1007,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40269,
      "e": 36439,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 40269,
      "e": 36439,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40269,
      "e": 36439,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40339,
      "e": 36509,
      "ty": 4,
      "x": 57248,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40340,
      "e": 36510,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40341,
      "e": 36511,
      "ty": 5,
      "x": 1007,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40342,
      "e": 36512,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 40604,
      "e": 36774,
      "ty": 2,
      "x": 1001,
      "y": 698
    },
    {
      "t": 40704,
      "e": 36874,
      "ty": 2,
      "x": 954,
      "y": 746
    },
    {
      "t": 40754,
      "e": 36924,
      "ty": 41,
      "x": 32578,
      "y": 40883,
      "ta": "html > body"
    },
    {
      "t": 41357,
      "e": 37527,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 42104,
      "e": 38274,
      "ty": 2,
      "x": 960,
      "y": 710
    },
    {
      "t": 42204,
      "e": 38374,
      "ty": 2,
      "x": 1138,
      "y": 152
    },
    {
      "t": 42255,
      "e": 38425,
      "ty": 41,
      "x": 37399,
      "y": 2326,
      "ta": "html > body"
    },
    {
      "t": 42304,
      "e": 38474,
      "ty": 2,
      "x": 1038,
      "y": 29
    },
    {
      "t": 42404,
      "e": 38574,
      "ty": 2,
      "x": 928,
      "y": 88
    },
    {
      "t": 42504,
      "e": 38674,
      "ty": 2,
      "x": 900,
      "y": 182
    },
    {
      "t": 42504,
      "e": 38674,
      "ty": 41,
      "x": 18648,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 42604,
      "e": 38774,
      "ty": 2,
      "x": 899,
      "y": 197
    },
    {
      "t": 42705,
      "e": 38875,
      "ty": 2,
      "x": 860,
      "y": 252
    },
    {
      "t": 42754,
      "e": 38924,
      "ty": 41,
      "x": 8918,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 42804,
      "e": 38974,
      "ty": 2,
      "x": 857,
      "y": 253
    },
    {
      "t": 42892,
      "e": 39062,
      "ty": 6,
      "x": 837,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42904,
      "e": 39074,
      "ty": 2,
      "x": 837,
      "y": 239
    },
    {
      "t": 42925,
      "e": 39095,
      "ty": 7,
      "x": 830,
      "y": 231,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43004,
      "e": 39174,
      "ty": 2,
      "x": 828,
      "y": 229
    },
    {
      "t": 43005,
      "e": 39175,
      "ty": 41,
      "x": 5386,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 43205,
      "e": 39375,
      "ty": 2,
      "x": 828,
      "y": 231
    },
    {
      "t": 43212,
      "e": 39382,
      "ty": 6,
      "x": 828,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43255,
      "e": 39425,
      "ty": 41,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43304,
      "e": 39474,
      "ty": 2,
      "x": 829,
      "y": 236
    },
    {
      "t": 44348,
      "e": 40518,
      "ty": 3,
      "x": 829,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44348,
      "e": 40518,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44451,
      "e": 40621,
      "ty": 4,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44451,
      "e": 40621,
      "ty": 5,
      "x": 829,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44451,
      "e": 40621,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 44505,
      "e": 40675,
      "ty": 2,
      "x": 829,
      "y": 237
    },
    {
      "t": 44505,
      "e": 40675,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44693,
      "e": 40863,
      "ty": 7,
      "x": 830,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44705,
      "e": 40875,
      "ty": 2,
      "x": 830,
      "y": 246
    },
    {
      "t": 44754,
      "e": 40924,
      "ty": 41,
      "x": 7294,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 44804,
      "e": 40974,
      "ty": 2,
      "x": 832,
      "y": 259
    },
    {
      "t": 44915,
      "e": 41085,
      "ty": 3,
      "x": 832,
      "y": 259,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 44916,
      "e": 41086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45004,
      "e": 41174,
      "ty": 41,
      "x": 8056,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 45011,
      "e": 41181,
      "ty": 4,
      "x": 8056,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 45012,
      "e": 41182,
      "ty": 5,
      "x": 832,
      "y": 259,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 45012,
      "e": 41182,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 45013,
      "e": 41183,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 45158,
      "e": 41328,
      "ty": 6,
      "x": 832,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 45204,
      "e": 41374,
      "ty": 2,
      "x": 832,
      "y": 266
    },
    {
      "t": 45244,
      "e": 41414,
      "ty": 7,
      "x": 832,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 45254,
      "e": 41424,
      "ty": 41,
      "x": 8056,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 45304,
      "e": 41474,
      "ty": 2,
      "x": 832,
      "y": 287
    },
    {
      "t": 45309,
      "e": 41479,
      "ty": 6,
      "x": 832,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45344,
      "e": 41514,
      "ty": 7,
      "x": 832,
      "y": 308,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45361,
      "e": 41514,
      "ty": 6,
      "x": 831,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 45377,
      "e": 41530,
      "ty": 7,
      "x": 830,
      "y": 337,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 45404,
      "e": 41557,
      "ty": 2,
      "x": 828,
      "y": 358
    },
    {
      "t": 45504,
      "e": 41657,
      "ty": 2,
      "x": 827,
      "y": 395
    },
    {
      "t": 45504,
      "e": 41657,
      "ty": 41,
      "x": 1323,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 45604,
      "e": 41757,
      "ty": 2,
      "x": 824,
      "y": 409
    },
    {
      "t": 45705,
      "e": 41858,
      "ty": 2,
      "x": 824,
      "y": 416
    },
    {
      "t": 45755,
      "e": 41908,
      "ty": 41,
      "x": 849,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 45760,
      "e": 41913,
      "ty": 6,
      "x": 827,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 45794,
      "e": 41947,
      "ty": 7,
      "x": 833,
      "y": 459,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 45804,
      "e": 41957,
      "ty": 2,
      "x": 833,
      "y": 459
    },
    {
      "t": 45811,
      "e": 41964,
      "ty": 6,
      "x": 836,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 45827,
      "e": 41980,
      "ty": 7,
      "x": 837,
      "y": 482,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 45861,
      "e": 42014,
      "ty": 6,
      "x": 839,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45877,
      "e": 42030,
      "ty": 7,
      "x": 840,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45905,
      "e": 42058,
      "ty": 2,
      "x": 840,
      "y": 503
    },
    {
      "t": 46004,
      "e": 42157,
      "ty": 2,
      "x": 840,
      "y": 506
    },
    {
      "t": 46005,
      "e": 42158,
      "ty": 41,
      "x": 16674,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 46078,
      "e": 42231,
      "ty": 6,
      "x": 838,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46104,
      "e": 42257,
      "ty": 2,
      "x": 837,
      "y": 495
    },
    {
      "t": 46111,
      "e": 42264,
      "ty": 7,
      "x": 837,
      "y": 490,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46204,
      "e": 42357,
      "ty": 2,
      "x": 837,
      "y": 477
    },
    {
      "t": 46210,
      "e": 42363,
      "ty": 6,
      "x": 837,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46254,
      "e": 42407,
      "ty": 41,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46294,
      "e": 42447,
      "ty": 7,
      "x": 834,
      "y": 461,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46305,
      "e": 42458,
      "ty": 2,
      "x": 834,
      "y": 461
    },
    {
      "t": 46328,
      "e": 42481,
      "ty": 6,
      "x": 832,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 46344,
      "e": 42497,
      "ty": 7,
      "x": 828,
      "y": 428,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 46404,
      "e": 42557,
      "ty": 2,
      "x": 825,
      "y": 421
    },
    {
      "t": 46505,
      "e": 42658,
      "ty": 41,
      "x": 4188,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46612,
      "e": 42765,
      "ty": 6,
      "x": 826,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46679,
      "e": 42832,
      "ty": 7,
      "x": 841,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46704,
      "e": 42857,
      "ty": 2,
      "x": 842,
      "y": 409
    },
    {
      "t": 46754,
      "e": 42907,
      "ty": 41,
      "x": 26429,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46804,
      "e": 42957,
      "ty": 2,
      "x": 844,
      "y": 409
    },
    {
      "t": 46904,
      "e": 43057,
      "ty": 2,
      "x": 844,
      "y": 438
    },
    {
      "t": 47005,
      "e": 43158,
      "ty": 2,
      "x": 845,
      "y": 523
    },
    {
      "t": 47006,
      "e": 43159,
      "ty": 41,
      "x": 27592,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 47105,
      "e": 43258,
      "ty": 2,
      "x": 847,
      "y": 535
    },
    {
      "t": 47205,
      "e": 43259,
      "ty": 2,
      "x": 843,
      "y": 516
    },
    {
      "t": 47228,
      "e": 43282,
      "ty": 6,
      "x": 837,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47254,
      "e": 43308,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47261,
      "e": 43315,
      "ty": 7,
      "x": 836,
      "y": 491,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47304,
      "e": 43358,
      "ty": 2,
      "x": 836,
      "y": 489
    },
    {
      "t": 47404,
      "e": 43458,
      "ty": 2,
      "x": 834,
      "y": 482
    },
    {
      "t": 47504,
      "e": 43558,
      "ty": 2,
      "x": 834,
      "y": 478
    },
    {
      "t": 47505,
      "e": 43559,
      "ty": 41,
      "x": 13295,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 47780,
      "e": 43834,
      "ty": 6,
      "x": 833,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47804,
      "e": 43858,
      "ty": 2,
      "x": 833,
      "y": 475
    },
    {
      "t": 47905,
      "e": 43959,
      "ty": 2,
      "x": 833,
      "y": 473
    },
    {
      "t": 47916,
      "e": 43970,
      "ty": 3,
      "x": 833,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47917,
      "e": 43971,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 47918,
      "e": 43972,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48005,
      "e": 44059,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48020,
      "e": 44074,
      "ty": 4,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48021,
      "e": 44075,
      "ty": 5,
      "x": 833,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48021,
      "e": 44075,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 48164,
      "e": 44218,
      "ty": 7,
      "x": 833,
      "y": 481,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48179,
      "e": 44233,
      "ty": 6,
      "x": 836,
      "y": 495,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 48195,
      "e": 44249,
      "ty": 7,
      "x": 841,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 48204,
      "e": 44258,
      "ty": 2,
      "x": 841,
      "y": 527
    },
    {
      "t": 48254,
      "e": 44308,
      "ty": 41,
      "x": 5121,
      "y": 33477,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48304,
      "e": 44358,
      "ty": 2,
      "x": 843,
      "y": 673
    },
    {
      "t": 48363,
      "e": 44417,
      "ty": 6,
      "x": 833,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 48379,
      "e": 44433,
      "ty": 7,
      "x": 828,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 48405,
      "e": 44459,
      "ty": 2,
      "x": 820,
      "y": 763
    },
    {
      "t": 48504,
      "e": 44558,
      "ty": 2,
      "x": 817,
      "y": 768
    },
    {
      "t": 48505,
      "e": 44559,
      "ty": 41,
      "x": 27860,
      "y": 42101,
      "ta": "html > body"
    },
    {
      "t": 48605,
      "e": 44659,
      "ty": 2,
      "x": 823,
      "y": 760
    },
    {
      "t": 48705,
      "e": 44759,
      "ty": 2,
      "x": 824,
      "y": 757
    },
    {
      "t": 48754,
      "e": 44808,
      "ty": 41,
      "x": 1075,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 50045,
      "e": 46099,
      "ty": 6,
      "x": 827,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50062,
      "e": 46116,
      "ty": 7,
      "x": 831,
      "y": 751,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50104,
      "e": 46158,
      "ty": 2,
      "x": 835,
      "y": 748
    },
    {
      "t": 50204,
      "e": 46258,
      "ty": 2,
      "x": 837,
      "y": 744
    },
    {
      "t": 50255,
      "e": 46309,
      "ty": 41,
      "x": 3697,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 50305,
      "e": 46359,
      "ty": 2,
      "x": 837,
      "y": 742
    },
    {
      "t": 50404,
      "e": 46458,
      "ty": 6,
      "x": 836,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50404,
      "e": 46458,
      "ty": 2,
      "x": 836,
      "y": 735
    },
    {
      "t": 50482,
      "e": 46536,
      "ty": 7,
      "x": 828,
      "y": 718,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50504,
      "e": 46558,
      "ty": 2,
      "x": 823,
      "y": 709
    },
    {
      "t": 50505,
      "e": 46559,
      "ty": 41,
      "x": 397,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 50604,
      "e": 46658,
      "ty": 2,
      "x": 809,
      "y": 685
    },
    {
      "t": 50705,
      "e": 46759,
      "ty": 2,
      "x": 821,
      "y": 670
    },
    {
      "t": 50756,
      "e": 46810,
      "ty": 41,
      "x": 155,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 50805,
      "e": 46859,
      "ty": 2,
      "x": 822,
      "y": 670
    },
    {
      "t": 50905,
      "e": 46959,
      "ty": 2,
      "x": 823,
      "y": 686
    },
    {
      "t": 51005,
      "e": 47059,
      "ty": 2,
      "x": 823,
      "y": 694
    },
    {
      "t": 51005,
      "e": 47059,
      "ty": 41,
      "x": 397,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 51105,
      "e": 47159,
      "ty": 2,
      "x": 823,
      "y": 697
    },
    {
      "t": 51205,
      "e": 47259,
      "ty": 2,
      "x": 824,
      "y": 698
    },
    {
      "t": 51237,
      "e": 47259,
      "ty": 6,
      "x": 826,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51254,
      "e": 47276,
      "ty": 41,
      "x": 2914,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51265,
      "e": 47287,
      "ty": 7,
      "x": 829,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51304,
      "e": 47326,
      "ty": 2,
      "x": 830,
      "y": 691
    },
    {
      "t": 51382,
      "e": 47404,
      "ty": 6,
      "x": 833,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51405,
      "e": 47427,
      "ty": 2,
      "x": 833,
      "y": 680
    },
    {
      "t": 51505,
      "e": 47527,
      "ty": 2,
      "x": 833,
      "y": 679
    },
    {
      "t": 51505,
      "e": 47527,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51573,
      "e": 47595,
      "ty": 7,
      "x": 833,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51605,
      "e": 47627,
      "ty": 2,
      "x": 833,
      "y": 690
    },
    {
      "t": 51616,
      "e": 47638,
      "ty": 6,
      "x": 833,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51648,
      "e": 47670,
      "ty": 7,
      "x": 828,
      "y": 718,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51664,
      "e": 47686,
      "ty": 6,
      "x": 827,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 51704,
      "e": 47726,
      "ty": 2,
      "x": 826,
      "y": 736
    },
    {
      "t": 51715,
      "e": 47737,
      "ty": 7,
      "x": 826,
      "y": 741,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 51755,
      "e": 47777,
      "ty": 41,
      "x": 374,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 51805,
      "e": 47827,
      "ty": 2,
      "x": 823,
      "y": 757
    },
    {
      "t": 51905,
      "e": 47927,
      "ty": 2,
      "x": 822,
      "y": 765
    },
    {
      "t": 52004,
      "e": 48026,
      "ty": 2,
      "x": 822,
      "y": 802
    },
    {
      "t": 52004,
      "e": 48026,
      "ty": 41,
      "x": 137,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 52104,
      "e": 48126,
      "ty": 2,
      "x": 824,
      "y": 845
    },
    {
      "t": 52205,
      "e": 48227,
      "ty": 2,
      "x": 829,
      "y": 863
    },
    {
      "t": 52255,
      "e": 48277,
      "ty": 41,
      "x": 1798,
      "y": 52457,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52304,
      "e": 48326,
      "ty": 2,
      "x": 829,
      "y": 864
    },
    {
      "t": 52405,
      "e": 48427,
      "ty": 2,
      "x": 829,
      "y": 862
    },
    {
      "t": 52449,
      "e": 48471,
      "ty": 6,
      "x": 829,
      "y": 843,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 52499,
      "e": 48521,
      "ty": 7,
      "x": 829,
      "y": 833,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 52505,
      "e": 48527,
      "ty": 2,
      "x": 829,
      "y": 833
    },
    {
      "t": 52505,
      "e": 48527,
      "ty": 41,
      "x": 5339,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 52605,
      "e": 48627,
      "ty": 2,
      "x": 829,
      "y": 829
    },
    {
      "t": 52704,
      "e": 48726,
      "ty": 2,
      "x": 828,
      "y": 826
    },
    {
      "t": 52750,
      "e": 48772,
      "ty": 6,
      "x": 828,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 52755,
      "e": 48777,
      "ty": 41,
      "x": 7955,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 52804,
      "e": 48826,
      "ty": 2,
      "x": 828,
      "y": 810
    },
    {
      "t": 52817,
      "e": 48839,
      "ty": 7,
      "x": 828,
      "y": 807,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 52905,
      "e": 48927,
      "ty": 2,
      "x": 828,
      "y": 803
    },
    {
      "t": 53000,
      "e": 49022,
      "ty": 6,
      "x": 827,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53005,
      "e": 49027,
      "ty": 2,
      "x": 827,
      "y": 792
    },
    {
      "t": 53005,
      "e": 49027,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53105,
      "e": 49127,
      "ty": 2,
      "x": 827,
      "y": 786
    },
    {
      "t": 53204,
      "e": 49226,
      "ty": 2,
      "x": 827,
      "y": 782
    },
    {
      "t": 53251,
      "e": 49273,
      "ty": 7,
      "x": 827,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53255,
      "e": 49277,
      "ty": 41,
      "x": 3122,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 53304,
      "e": 49326,
      "ty": 2,
      "x": 827,
      "y": 775
    },
    {
      "t": 53400,
      "e": 49422,
      "ty": 6,
      "x": 827,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53405,
      "e": 49427,
      "ty": 2,
      "x": 827,
      "y": 763
    },
    {
      "t": 53505,
      "e": 49527,
      "ty": 2,
      "x": 827,
      "y": 752
    },
    {
      "t": 53505,
      "e": 49527,
      "ty": 41,
      "x": 2914,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53517,
      "e": 49539,
      "ty": 7,
      "x": 827,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53604,
      "e": 49626,
      "ty": 2,
      "x": 827,
      "y": 742
    },
    {
      "t": 53700,
      "e": 49722,
      "ty": 6,
      "x": 827,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 53705,
      "e": 49727,
      "ty": 2,
      "x": 827,
      "y": 736
    },
    {
      "t": 53755,
      "e": 49727,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 53968,
      "e": 49940,
      "ty": 7,
      "x": 827,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54004,
      "e": 49976,
      "ty": 2,
      "x": 827,
      "y": 719
    },
    {
      "t": 54004,
      "e": 49976,
      "ty": 41,
      "x": 1323,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 54104,
      "e": 50076,
      "ty": 2,
      "x": 825,
      "y": 716
    },
    {
      "t": 54255,
      "e": 50227,
      "ty": 41,
      "x": 1909,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 54284,
      "e": 50256,
      "ty": 6,
      "x": 838,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 54301,
      "e": 50273,
      "ty": 7,
      "x": 840,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 54304,
      "e": 50276,
      "ty": 2,
      "x": 840,
      "y": 706
    },
    {
      "t": 54405,
      "e": 50377,
      "ty": 2,
      "x": 852,
      "y": 698
    },
    {
      "t": 54504,
      "e": 50476,
      "ty": 2,
      "x": 856,
      "y": 695
    },
    {
      "t": 54505,
      "e": 50477,
      "ty": 41,
      "x": 8713,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 54704,
      "e": 50676,
      "ty": 2,
      "x": 855,
      "y": 693
    },
    {
      "t": 54755,
      "e": 50727,
      "ty": 41,
      "x": 7201,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 54805,
      "e": 50777,
      "ty": 2,
      "x": 847,
      "y": 692
    },
    {
      "t": 54905,
      "e": 50877,
      "ty": 2,
      "x": 842,
      "y": 687
    },
    {
      "t": 55004,
      "e": 50976,
      "ty": 2,
      "x": 841,
      "y": 687
    },
    {
      "t": 55005,
      "e": 50977,
      "ty": 41,
      "x": 4646,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 55404,
      "e": 51376,
      "ty": 2,
      "x": 839,
      "y": 694
    },
    {
      "t": 55418,
      "e": 51390,
      "ty": 6,
      "x": 839,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55505,
      "e": 51477,
      "ty": 2,
      "x": 839,
      "y": 696
    },
    {
      "t": 55505,
      "e": 51477,
      "ty": 41,
      "x": 63408,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55705,
      "e": 51677,
      "ty": 2,
      "x": 837,
      "y": 700
    },
    {
      "t": 55755,
      "e": 51727,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55805,
      "e": 51777,
      "ty": 2,
      "x": 834,
      "y": 705
    },
    {
      "t": 55835,
      "e": 51807,
      "ty": 7,
      "x": 834,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55905,
      "e": 51877,
      "ty": 2,
      "x": 833,
      "y": 712
    },
    {
      "t": 56005,
      "e": 51977,
      "ty": 41,
      "x": 2917,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56205,
      "e": 52177,
      "ty": 2,
      "x": 833,
      "y": 711
    },
    {
      "t": 56255,
      "e": 52227,
      "ty": 41,
      "x": 2917,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56292,
      "e": 52264,
      "ty": 6,
      "x": 833,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56305,
      "e": 52277,
      "ty": 2,
      "x": 833,
      "y": 708
    },
    {
      "t": 56405,
      "e": 52377,
      "ty": 2,
      "x": 833,
      "y": 705
    },
    {
      "t": 56505,
      "e": 52477,
      "ty": 2,
      "x": 833,
      "y": 704
    },
    {
      "t": 56505,
      "e": 52477,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56621,
      "e": 52593,
      "ty": 3,
      "x": 833,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56622,
      "e": 52594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56623,
      "e": 52595,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56715,
      "e": 52687,
      "ty": 4,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56715,
      "e": 52687,
      "ty": 5,
      "x": 833,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56717,
      "e": 52689,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 57076,
      "e": 53048,
      "ty": 7,
      "x": 838,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57104,
      "e": 53076,
      "ty": 2,
      "x": 848,
      "y": 730
    },
    {
      "t": 57205,
      "e": 53177,
      "ty": 2,
      "x": 979,
      "y": 906
    },
    {
      "t": 57255,
      "e": 53227,
      "ty": 41,
      "x": 41431,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 57305,
      "e": 53277,
      "ty": 2,
      "x": 999,
      "y": 963
    },
    {
      "t": 57405,
      "e": 53377,
      "ty": 2,
      "x": 959,
      "y": 994
    },
    {
      "t": 57504,
      "e": 53476,
      "ty": 2,
      "x": 867,
      "y": 1001
    },
    {
      "t": 57504,
      "e": 53476,
      "ty": 41,
      "x": 10816,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 57536,
      "e": 53508,
      "ty": 6,
      "x": 830,
      "y": 993,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 57553,
      "e": 53525,
      "ty": 7,
      "x": 819,
      "y": 989,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 57605,
      "e": 53577,
      "ty": 2,
      "x": 812,
      "y": 987
    },
    {
      "t": 57705,
      "e": 53677,
      "ty": 2,
      "x": 812,
      "y": 980
    },
    {
      "t": 57755,
      "e": 53727,
      "ty": 41,
      "x": 27722,
      "y": 52849,
      "ta": "html > body"
    },
    {
      "t": 57805,
      "e": 53777,
      "ty": 2,
      "x": 816,
      "y": 951
    },
    {
      "t": 57905,
      "e": 53877,
      "ty": 2,
      "x": 820,
      "y": 944
    },
    {
      "t": 58005,
      "e": 53977,
      "ty": 2,
      "x": 820,
      "y": 943
    },
    {
      "t": 58005,
      "e": 53977,
      "ty": 41,
      "x": 27963,
      "y": 51796,
      "ta": "html > body"
    },
    {
      "t": 58971,
      "e": 54943,
      "ty": 6,
      "x": 831,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 58988,
      "e": 54960,
      "ty": 7,
      "x": 842,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 59004,
      "e": 54976,
      "ty": 2,
      "x": 853,
      "y": 928
    },
    {
      "t": 59004,
      "e": 54976,
      "ty": 41,
      "x": 34491,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 59104,
      "e": 55076,
      "ty": 2,
      "x": 872,
      "y": 913
    },
    {
      "t": 59205,
      "e": 55177,
      "ty": 2,
      "x": 872,
      "y": 908
    },
    {
      "t": 59255,
      "e": 55227,
      "ty": 41,
      "x": 11291,
      "y": 16131,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 59289,
      "e": 55261,
      "ty": 6,
      "x": 836,
      "y": 932,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 59304,
      "e": 55276,
      "ty": 2,
      "x": 836,
      "y": 932
    },
    {
      "t": 59404,
      "e": 55376,
      "ty": 2,
      "x": 827,
      "y": 937
    },
    {
      "t": 59505,
      "e": 55477,
      "ty": 2,
      "x": 827,
      "y": 940
    },
    {
      "t": 59505,
      "e": 55477,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 59555,
      "e": 55527,
      "ty": 7,
      "x": 827,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 59605,
      "e": 55577,
      "ty": 2,
      "x": 835,
      "y": 948
    },
    {
      "t": 59705,
      "e": 55677,
      "ty": 2,
      "x": 842,
      "y": 955
    },
    {
      "t": 59755,
      "e": 55727,
      "ty": 41,
      "x": 16646,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59805,
      "e": 55777,
      "ty": 2,
      "x": 842,
      "y": 956
    },
    {
      "t": 59924,
      "e": 55896,
      "ty": 3,
      "x": 842,
      "y": 957,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59925,
      "e": 55897,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60003,
      "e": 55975,
      "ty": 4,
      "x": 16646,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 60004,
      "e": 55976,
      "ty": 5,
      "x": 842,
      "y": 957,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 60004,
      "e": 55976,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 60005,
      "e": 55977,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 60005,
      "e": 55977,
      "ty": 2,
      "x": 842,
      "y": 957
    },
    {
      "t": 60005,
      "e": 55977,
      "ty": 41,
      "x": 16646,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 60105,
      "e": 56077,
      "ty": 2,
      "x": 842,
      "y": 959
    },
    {
      "t": 60205,
      "e": 56177,
      "ty": 2,
      "x": 853,
      "y": 976
    },
    {
      "t": 60255,
      "e": 56227,
      "ty": 41,
      "x": 13427,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 60256,
      "e": 56228,
      "ty": 6,
      "x": 882,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60305,
      "e": 56277,
      "ty": 2,
      "x": 890,
      "y": 1022
    },
    {
      "t": 60404,
      "e": 56376,
      "ty": 2,
      "x": 893,
      "y": 1029
    },
    {
      "t": 60421,
      "e": 56393,
      "ty": 3,
      "x": 893,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60421,
      "e": 56393,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 60422,
      "e": 56394,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60483,
      "e": 56455,
      "ty": 4,
      "x": 32767,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60486,
      "e": 56458,
      "ty": 5,
      "x": 893,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60488,
      "e": 56460,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60488,
      "e": 56460,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 60489,
      "e": 56461,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 60505,
      "e": 56477,
      "ty": 41,
      "x": 30477,
      "y": 56560,
      "ta": "html > body"
    },
    {
      "t": 61405,
      "e": 57377,
      "ty": 2,
      "x": 893,
      "y": 1023
    },
    {
      "t": 61505,
      "e": 57477,
      "ty": 2,
      "x": 892,
      "y": 1021
    },
    {
      "t": 61506,
      "e": 57478,
      "ty": 41,
      "x": 30442,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 61605,
      "e": 57577,
      "ty": 2,
      "x": 890,
      "y": 1019
    },
    {
      "t": 61704,
      "e": 57676,
      "ty": 2,
      "x": 890,
      "y": 1016
    },
    {
      "t": 61755,
      "e": 57727,
      "ty": 41,
      "x": 30339,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 61810,
      "e": 57782,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 61817,
      "e": 57789,
      "ty": 2,
      "x": 889,
      "y": 1016
    },
    {
      "t": 61905,
      "e": 57877,
      "ty": 2,
      "x": 889,
      "y": 1015
    },
    {
      "t": 62004,
      "e": 57976,
      "ty": 41,
      "x": 29299,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62258,
      "e": 58230,
      "ty": 41,
      "x": 29299,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62308,
      "e": 58280,
      "ty": 2,
      "x": 897,
      "y": 969
    },
    {
      "t": 62409,
      "e": 58381,
      "ty": 2,
      "x": 996,
      "y": 826
    },
    {
      "t": 62508,
      "e": 58480,
      "ty": 2,
      "x": 1042,
      "y": 982
    },
    {
      "t": 62509,
      "e": 58481,
      "ty": 41,
      "x": 36826,
      "y": 59255,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62608,
      "e": 58580,
      "ty": 2,
      "x": 1071,
      "y": 1123
    },
    {
      "t": 62708,
      "e": 58680,
      "ty": 2,
      "x": 1029,
      "y": 1145
    },
    {
      "t": 62758,
      "e": 58730,
      "ty": 41,
      "x": 57343,
      "y": 32304,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 62796,
      "e": 58768,
      "ty": 6,
      "x": 987,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 62808,
      "e": 58780,
      "ty": 2,
      "x": 987,
      "y": 1099
    },
    {
      "t": 62908,
      "e": 58880,
      "ty": 2,
      "x": 978,
      "y": 1086
    },
    {
      "t": 63008,
      "e": 58980,
      "ty": 41,
      "x": 37409,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 63808,
      "e": 59780,
      "ty": 2,
      "x": 978,
      "y": 1084
    },
    {
      "t": 63984,
      "e": 59956,
      "ty": 3,
      "x": 978,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 63985,
      "e": 59957,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64007,
      "e": 59979,
      "ty": 41,
      "x": 37409,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 64054,
      "e": 60026,
      "ty": 4,
      "x": 37409,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 64055,
      "e": 60027,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64055,
      "e": 60027,
      "ty": 5,
      "x": 978,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 64056,
      "e": 60028,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 64108,
      "e": 60080,
      "ty": 2,
      "x": 980,
      "y": 1074
    },
    {
      "t": 64208,
      "e": 60180,
      "ty": 2,
      "x": 984,
      "y": 1070
    },
    {
      "t": 64258,
      "e": 60230,
      "ty": 41,
      "x": 33611,
      "y": 58831,
      "ta": "html > body"
    },
    {
      "t": 64408,
      "e": 60380,
      "ty": 2,
      "x": 1019,
      "y": 1036
    },
    {
      "t": 64508,
      "e": 60480,
      "ty": 2,
      "x": 1483,
      "y": 727
    },
    {
      "t": 64508,
      "e": 60480,
      "ty": 41,
      "x": 50795,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 64608,
      "e": 60580,
      "ty": 2,
      "x": 1582,
      "y": 703
    },
    {
      "t": 64708,
      "e": 60680,
      "ty": 2,
      "x": 1586,
      "y": 702
    },
    {
      "t": 64758,
      "e": 60730,
      "ty": 41,
      "x": 54342,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 65099,
      "e": 61071,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 67103,
      "e": 63075,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 80908, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 80912, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3325, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 85562, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 5796, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"mike\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 92362, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32815, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 126266, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10034, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 137302, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12966, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 151637, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1005,y:985,t:1527268118664};\\\", \\\"{x:1011,y:982,t:1527268118674};\\\", \\\"{x:1016,y:981,t:1527268118692};\\\", \\\"{x:1018,y:981,t:1527268118708};\\\", \\\"{x:1024,y:979,t:1527268118725};\\\", \\\"{x:1028,y:977,t:1527268118741};\\\", \\\"{x:1033,y:974,t:1527268118758};\\\", \\\"{x:1041,y:972,t:1527268118775};\\\", \\\"{x:1076,y:958,t:1527268118791};\\\", \\\"{x:1135,y:949,t:1527268118808};\\\", \\\"{x:1229,y:937,t:1527268118825};\\\", \\\"{x:1283,y:932,t:1527268118842};\\\", \\\"{x:1295,y:930,t:1527268118858};\\\", \\\"{x:1298,y:927,t:1527268118874};\\\", \\\"{x:1298,y:915,t:1527268118892};\\\", \\\"{x:1298,y:907,t:1527268118908};\\\", \\\"{x:1296,y:903,t:1527268118924};\\\", \\\"{x:1293,y:900,t:1527268118942};\\\", \\\"{x:1292,y:899,t:1527268118958};\\\", \\\"{x:1292,y:901,t:1527268119144};\\\", \\\"{x:1293,y:902,t:1527268119159};\\\", \\\"{x:1294,y:903,t:1527268119175};\\\", \\\"{x:1294,y:905,t:1527268119191};\\\", \\\"{x:1295,y:908,t:1527268119209};\\\", \\\"{x:1296,y:913,t:1527268119225};\\\", \\\"{x:1297,y:919,t:1527268119242};\\\", \\\"{x:1298,y:924,t:1527268119258};\\\", \\\"{x:1298,y:927,t:1527268119275};\\\", \\\"{x:1298,y:932,t:1527268119292};\\\", \\\"{x:1299,y:937,t:1527268119309};\\\", \\\"{x:1300,y:939,t:1527268119324};\\\", \\\"{x:1300,y:942,t:1527268119342};\\\", \\\"{x:1301,y:944,t:1527268119359};\\\", \\\"{x:1301,y:946,t:1527268119375};\\\", \\\"{x:1301,y:951,t:1527268119392};\\\", \\\"{x:1301,y:955,t:1527268119409};\\\", \\\"{x:1301,y:959,t:1527268119425};\\\", \\\"{x:1301,y:962,t:1527268119442};\\\", \\\"{x:1301,y:966,t:1527268119459};\\\", \\\"{x:1301,y:968,t:1527268119475};\\\", \\\"{x:1301,y:969,t:1527268119493};\\\", \\\"{x:1300,y:969,t:1527268119512};\\\", \\\"{x:1299,y:969,t:1527268119525};\\\", \\\"{x:1298,y:969,t:1527268119542};\\\", \\\"{x:1295,y:969,t:1527268119559};\\\", \\\"{x:1292,y:969,t:1527268119576};\\\", \\\"{x:1289,y:969,t:1527268119592};\\\", \\\"{x:1286,y:969,t:1527268119609};\\\", \\\"{x:1284,y:968,t:1527268119627};\\\", \\\"{x:1282,y:968,t:1527268119642};\\\", \\\"{x:1279,y:967,t:1527268119659};\\\", \\\"{x:1278,y:966,t:1527268119676};\\\", \\\"{x:1275,y:961,t:1527268119692};\\\", \\\"{x:1273,y:953,t:1527268119709};\\\", \\\"{x:1269,y:938,t:1527268119726};\\\", \\\"{x:1268,y:933,t:1527268119743};\\\", \\\"{x:1266,y:926,t:1527268119759};\\\", \\\"{x:1265,y:918,t:1527268119776};\\\", \\\"{x:1265,y:915,t:1527268119795};\\\", \\\"{x:1265,y:914,t:1527268119809};\\\", \\\"{x:1265,y:912,t:1527268119826};\\\", \\\"{x:1265,y:910,t:1527268119842};\\\", \\\"{x:1265,y:908,t:1527268119859};\\\", \\\"{x:1265,y:906,t:1527268119875};\\\", \\\"{x:1265,y:905,t:1527268119892};\\\", \\\"{x:1265,y:903,t:1527268119908};\\\", \\\"{x:1265,y:902,t:1527268119926};\\\", \\\"{x:1265,y:898,t:1527268119942};\\\", \\\"{x:1266,y:895,t:1527268119959};\\\", \\\"{x:1267,y:893,t:1527268119975};\\\", \\\"{x:1267,y:889,t:1527268119993};\\\", \\\"{x:1270,y:882,t:1527268120009};\\\", \\\"{x:1276,y:869,t:1527268120026};\\\", \\\"{x:1284,y:850,t:1527268120043};\\\", \\\"{x:1287,y:837,t:1527268120059};\\\", \\\"{x:1289,y:825,t:1527268120076};\\\", \\\"{x:1290,y:819,t:1527268120093};\\\", \\\"{x:1290,y:817,t:1527268120110};\\\", \\\"{x:1289,y:818,t:1527268120303};\\\", \\\"{x:1288,y:821,t:1527268120311};\\\", \\\"{x:1287,y:822,t:1527268120326};\\\", \\\"{x:1285,y:825,t:1527268120343};\\\", \\\"{x:1283,y:828,t:1527268120360};\\\", \\\"{x:1282,y:829,t:1527268120375};\\\", \\\"{x:1272,y:828,t:1527268121811};\\\", \\\"{x:1162,y:813,t:1527268121827};\\\", \\\"{x:1002,y:794,t:1527268121844};\\\", \\\"{x:814,y:769,t:1527268121859};\\\", \\\"{x:593,y:729,t:1527268121876};\\\", \\\"{x:384,y:680,t:1527268121894};\\\", \\\"{x:226,y:658,t:1527268121910};\\\", \\\"{x:107,y:640,t:1527268121927};\\\", \\\"{x:45,y:632,t:1527268121944};\\\", \\\"{x:37,y:631,t:1527268121960};\\\", \\\"{x:36,y:630,t:1527268122161};\\\", \\\"{x:52,y:622,t:1527268122179};\\\", \\\"{x:79,y:609,t:1527268122195};\\\", \\\"{x:109,y:597,t:1527268122210};\\\", \\\"{x:135,y:584,t:1527268122228};\\\", \\\"{x:151,y:575,t:1527268122245};\\\", \\\"{x:158,y:568,t:1527268122261};\\\", \\\"{x:159,y:566,t:1527268122278};\\\", \\\"{x:161,y:562,t:1527268122295};\\\", \\\"{x:161,y:560,t:1527268122311};\\\", \\\"{x:161,y:556,t:1527268122328};\\\", \\\"{x:161,y:555,t:1527268122351};\\\", \\\"{x:161,y:554,t:1527268122361};\\\", \\\"{x:161,y:553,t:1527268122378};\\\", \\\"{x:161,y:552,t:1527268122423};\\\", \\\"{x:164,y:549,t:1527268122431};\\\", \\\"{x:167,y:548,t:1527268122445};\\\", \\\"{x:181,y:540,t:1527268122462};\\\", \\\"{x:202,y:533,t:1527268122478};\\\", \\\"{x:233,y:523,t:1527268122495};\\\", \\\"{x:283,y:510,t:1527268122512};\\\", \\\"{x:301,y:504,t:1527268122528};\\\", \\\"{x:310,y:503,t:1527268122544};\\\", \\\"{x:313,y:501,t:1527268122561};\\\", \\\"{x:314,y:500,t:1527268122578};\\\", \\\"{x:316,y:500,t:1527268122595};\\\", \\\"{x:319,y:500,t:1527268122612};\\\", \\\"{x:324,y:499,t:1527268122628};\\\", \\\"{x:327,y:499,t:1527268122645};\\\", \\\"{x:332,y:499,t:1527268122662};\\\", \\\"{x:336,y:499,t:1527268122678};\\\", \\\"{x:340,y:501,t:1527268122695};\\\", \\\"{x:345,y:505,t:1527268122712};\\\", \\\"{x:348,y:508,t:1527268122729};\\\", \\\"{x:352,y:513,t:1527268122745};\\\", \\\"{x:356,y:517,t:1527268122761};\\\", \\\"{x:359,y:521,t:1527268122778};\\\", \\\"{x:361,y:522,t:1527268122794};\\\", \\\"{x:363,y:523,t:1527268122811};\\\", \\\"{x:364,y:523,t:1527268122831};\\\", \\\"{x:365,y:523,t:1527268122887};\\\", \\\"{x:366,y:523,t:1527268122911};\\\", \\\"{x:369,y:523,t:1527268122927};\\\", \\\"{x:371,y:521,t:1527268122943};\\\", \\\"{x:372,y:521,t:1527268122975};\\\", \\\"{x:374,y:521,t:1527268123431};\\\", \\\"{x:375,y:524,t:1527268123447};\\\", \\\"{x:375,y:525,t:1527268123472};\\\", \\\"{x:375,y:526,t:1527268123487};\\\", \\\"{x:376,y:527,t:1527268123623};\\\", \\\"{x:376,y:528,t:1527268123631};\\\", \\\"{x:377,y:528,t:1527268123645};\\\", \\\"{x:377,y:529,t:1527268123662};\\\", \\\"{x:377,y:530,t:1527268123679};\\\", \\\"{x:377,y:531,t:1527268123696};\\\", \\\"{x:377,y:532,t:1527268123712};\\\", \\\"{x:378,y:532,t:1527268123816};\\\", \\\"{x:379,y:532,t:1527268123832};\\\", \\\"{x:381,y:532,t:1527268123846};\\\", \\\"{x:382,y:529,t:1527268123862};\\\", \\\"{x:382,y:527,t:1527268123879};\\\", \\\"{x:383,y:524,t:1527268123896};\\\", \\\"{x:383,y:523,t:1527268123913};\\\", \\\"{x:383,y:522,t:1527268123943};\\\", \\\"{x:383,y:521,t:1527268123959};\\\", \\\"{x:383,y:520,t:1527268123967};\\\", \\\"{x:383,y:519,t:1527268123992};\\\", \\\"{x:383,y:518,t:1527268123999};\\\", \\\"{x:383,y:517,t:1527268124013};\\\", \\\"{x:383,y:516,t:1527268124032};\\\", \\\"{x:383,y:515,t:1527268124046};\\\", \\\"{x:383,y:514,t:1527268124063};\\\", \\\"{x:383,y:513,t:1527268124079};\\\", \\\"{x:383,y:512,t:1527268124096};\\\", \\\"{x:383,y:514,t:1527268124455};\\\", \\\"{x:382,y:516,t:1527268124463};\\\", \\\"{x:381,y:519,t:1527268124479};\\\", \\\"{x:380,y:523,t:1527268124496};\\\", \\\"{x:379,y:528,t:1527268124513};\\\", \\\"{x:377,y:531,t:1527268124530};\\\", \\\"{x:377,y:533,t:1527268124546};\\\", \\\"{x:376,y:539,t:1527268124563};\\\", \\\"{x:378,y:550,t:1527268124580};\\\", \\\"{x:389,y:571,t:1527268124595};\\\", \\\"{x:404,y:591,t:1527268124613};\\\", \\\"{x:426,y:616,t:1527268124630};\\\", \\\"{x:459,y:645,t:1527268124647};\\\", \\\"{x:481,y:664,t:1527268124664};\\\", \\\"{x:503,y:689,t:1527268124680};\\\", \\\"{x:514,y:702,t:1527268124696};\\\", \\\"{x:516,y:705,t:1527268124713};\\\", \\\"{x:518,y:706,t:1527268124730};\\\", \\\"{x:518,y:707,t:1527268124840};\\\", \\\"{x:518,y:709,t:1527268124847};\\\", \\\"{x:515,y:716,t:1527268124863};\\\", \\\"{x:513,y:728,t:1527268124880};\\\", \\\"{x:509,y:740,t:1527268124897};\\\", \\\"{x:508,y:752,t:1527268124914};\\\", \\\"{x:508,y:760,t:1527268124930};\\\", \\\"{x:508,y:761,t:1527268124947};\\\", \\\"{x:508,y:757,t:1527268125047};\\\", \\\"{x:508,y:752,t:1527268125063};\\\", \\\"{x:508,y:738,t:1527268125081};\\\", \\\"{x:508,y:730,t:1527268125098};\\\", \\\"{x:508,y:723,t:1527268125114};\\\", \\\"{x:509,y:721,t:1527268125131};\\\", \\\"{x:509,y:719,t:1527268125147};\\\", \\\"{x:509,y:718,t:1527268125164};\\\" ] }, { \\\"rt\\\": 19392, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 172415, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10-U -D -G -G -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:708,t:1527268131688};\\\", \\\"{x:501,y:678,t:1527268131704};\\\", \\\"{x:492,y:654,t:1527268131720};\\\", \\\"{x:485,y:634,t:1527268131736};\\\", \\\"{x:479,y:618,t:1527268131753};\\\", \\\"{x:474,y:608,t:1527268131769};\\\", \\\"{x:469,y:600,t:1527268131785};\\\", \\\"{x:466,y:595,t:1527268131802};\\\", \\\"{x:464,y:589,t:1527268131819};\\\", \\\"{x:463,y:587,t:1527268131835};\\\", \\\"{x:463,y:582,t:1527268131852};\\\", \\\"{x:461,y:576,t:1527268131870};\\\", \\\"{x:459,y:567,t:1527268131886};\\\", \\\"{x:457,y:553,t:1527268131902};\\\", \\\"{x:447,y:530,t:1527268131919};\\\", \\\"{x:437,y:517,t:1527268131935};\\\", \\\"{x:412,y:504,t:1527268131952};\\\", \\\"{x:378,y:497,t:1527268131969};\\\", \\\"{x:322,y:489,t:1527268131985};\\\", \\\"{x:260,y:487,t:1527268132002};\\\", \\\"{x:202,y:487,t:1527268132020};\\\", \\\"{x:148,y:484,t:1527268132036};\\\", \\\"{x:93,y:479,t:1527268132052};\\\", \\\"{x:68,y:475,t:1527268132069};\\\", \\\"{x:64,y:475,t:1527268132086};\\\", \\\"{x:65,y:475,t:1527268132128};\\\", \\\"{x:68,y:475,t:1527268132135};\\\", \\\"{x:83,y:476,t:1527268132152};\\\", \\\"{x:108,y:476,t:1527268132169};\\\", \\\"{x:157,y:476,t:1527268132186};\\\", \\\"{x:229,y:476,t:1527268132203};\\\", \\\"{x:302,y:476,t:1527268132218};\\\", \\\"{x:371,y:468,t:1527268132236};\\\", \\\"{x:433,y:456,t:1527268132252};\\\", \\\"{x:489,y:440,t:1527268132269};\\\", \\\"{x:548,y:423,t:1527268132286};\\\", \\\"{x:594,y:405,t:1527268132302};\\\", \\\"{x:664,y:383,t:1527268132319};\\\", \\\"{x:709,y:370,t:1527268132336};\\\", \\\"{x:759,y:357,t:1527268132352};\\\", \\\"{x:823,y:336,t:1527268132369};\\\", \\\"{x:890,y:317,t:1527268132386};\\\", \\\"{x:941,y:308,t:1527268132402};\\\", \\\"{x:981,y:302,t:1527268132420};\\\", \\\"{x:1001,y:300,t:1527268132436};\\\", \\\"{x:1015,y:298,t:1527268132452};\\\", \\\"{x:1020,y:297,t:1527268132469};\\\", \\\"{x:1021,y:297,t:1527268132486};\\\", \\\"{x:1022,y:297,t:1527268132502};\\\", \\\"{x:1023,y:297,t:1527268132623};\\\", \\\"{x:1025,y:297,t:1527268132636};\\\", \\\"{x:1031,y:297,t:1527268132654};\\\", \\\"{x:1039,y:297,t:1527268132669};\\\", \\\"{x:1049,y:298,t:1527268132686};\\\", \\\"{x:1075,y:298,t:1527268132703};\\\", \\\"{x:1113,y:291,t:1527268132719};\\\", \\\"{x:1160,y:278,t:1527268132737};\\\", \\\"{x:1223,y:270,t:1527268132753};\\\", \\\"{x:1283,y:267,t:1527268132770};\\\", \\\"{x:1323,y:267,t:1527268132786};\\\", \\\"{x:1351,y:267,t:1527268132803};\\\", \\\"{x:1377,y:275,t:1527268132819};\\\", \\\"{x:1401,y:290,t:1527268132836};\\\", \\\"{x:1430,y:310,t:1527268132853};\\\", \\\"{x:1453,y:326,t:1527268132869};\\\", \\\"{x:1469,y:334,t:1527268132886};\\\", \\\"{x:1484,y:342,t:1527268132903};\\\", \\\"{x:1487,y:343,t:1527268132919};\\\", \\\"{x:1488,y:343,t:1527268132936};\\\", \\\"{x:1488,y:344,t:1527268132983};\\\", \\\"{x:1488,y:352,t:1527268132991};\\\", \\\"{x:1485,y:375,t:1527268133003};\\\", \\\"{x:1474,y:429,t:1527268133019};\\\", \\\"{x:1457,y:481,t:1527268133036};\\\", \\\"{x:1447,y:505,t:1527268133053};\\\", \\\"{x:1443,y:516,t:1527268133070};\\\", \\\"{x:1442,y:523,t:1527268133086};\\\", \\\"{x:1439,y:531,t:1527268133103};\\\", \\\"{x:1439,y:535,t:1527268133120};\\\", \\\"{x:1438,y:543,t:1527268133136};\\\", \\\"{x:1437,y:560,t:1527268133154};\\\", \\\"{x:1433,y:581,t:1527268133170};\\\", \\\"{x:1440,y:602,t:1527268133186};\\\", \\\"{x:1453,y:626,t:1527268133203};\\\", \\\"{x:1464,y:644,t:1527268133220};\\\", \\\"{x:1473,y:657,t:1527268133237};\\\", \\\"{x:1479,y:668,t:1527268133253};\\\", \\\"{x:1485,y:683,t:1527268133271};\\\", \\\"{x:1492,y:701,t:1527268133286};\\\", \\\"{x:1508,y:737,t:1527268133303};\\\", \\\"{x:1517,y:758,t:1527268133320};\\\", \\\"{x:1530,y:781,t:1527268133337};\\\", \\\"{x:1542,y:804,t:1527268133353};\\\", \\\"{x:1554,y:826,t:1527268133371};\\\", \\\"{x:1564,y:855,t:1527268133386};\\\", \\\"{x:1575,y:882,t:1527268133403};\\\", \\\"{x:1586,y:906,t:1527268133420};\\\", \\\"{x:1591,y:923,t:1527268133437};\\\", \\\"{x:1591,y:933,t:1527268133453};\\\", \\\"{x:1591,y:942,t:1527268133470};\\\", \\\"{x:1589,y:950,t:1527268133487};\\\", \\\"{x:1587,y:952,t:1527268133503};\\\", \\\"{x:1581,y:952,t:1527268133521};\\\", \\\"{x:1569,y:952,t:1527268133537};\\\", \\\"{x:1555,y:946,t:1527268133553};\\\", \\\"{x:1538,y:940,t:1527268133571};\\\", \\\"{x:1516,y:930,t:1527268133587};\\\", \\\"{x:1490,y:925,t:1527268133603};\\\", \\\"{x:1466,y:917,t:1527268133620};\\\", \\\"{x:1449,y:911,t:1527268133637};\\\", \\\"{x:1438,y:905,t:1527268133653};\\\", \\\"{x:1434,y:902,t:1527268133671};\\\", \\\"{x:1432,y:899,t:1527268133687};\\\", \\\"{x:1431,y:897,t:1527268133703};\\\", \\\"{x:1431,y:894,t:1527268133721};\\\", \\\"{x:1431,y:891,t:1527268133737};\\\", \\\"{x:1431,y:889,t:1527268133753};\\\", \\\"{x:1431,y:887,t:1527268133770};\\\", \\\"{x:1431,y:882,t:1527268133788};\\\", \\\"{x:1431,y:874,t:1527268133803};\\\", \\\"{x:1432,y:860,t:1527268133821};\\\", \\\"{x:1434,y:847,t:1527268133837};\\\", \\\"{x:1435,y:837,t:1527268133854};\\\", \\\"{x:1438,y:828,t:1527268133871};\\\", \\\"{x:1448,y:806,t:1527268133887};\\\", \\\"{x:1455,y:784,t:1527268133904};\\\", \\\"{x:1465,y:761,t:1527268133920};\\\", \\\"{x:1481,y:736,t:1527268133937};\\\", \\\"{x:1496,y:708,t:1527268133954};\\\", \\\"{x:1525,y:661,t:1527268133970};\\\", \\\"{x:1552,y:607,t:1527268133987};\\\", \\\"{x:1573,y:555,t:1527268134005};\\\", \\\"{x:1592,y:516,t:1527268134020};\\\", \\\"{x:1605,y:483,t:1527268134037};\\\", \\\"{x:1617,y:457,t:1527268134054};\\\", \\\"{x:1638,y:410,t:1527268134070};\\\", \\\"{x:1652,y:367,t:1527268134087};\\\", \\\"{x:1658,y:346,t:1527268134105};\\\", \\\"{x:1660,y:330,t:1527268134120};\\\", \\\"{x:1664,y:317,t:1527268134137};\\\", \\\"{x:1666,y:305,t:1527268134155};\\\", \\\"{x:1667,y:293,t:1527268134171};\\\", \\\"{x:1667,y:279,t:1527268134188};\\\", \\\"{x:1667,y:271,t:1527268134205};\\\", \\\"{x:1667,y:269,t:1527268134221};\\\", \\\"{x:1665,y:265,t:1527268134238};\\\", \\\"{x:1659,y:258,t:1527268134254};\\\", \\\"{x:1649,y:251,t:1527268134270};\\\", \\\"{x:1630,y:243,t:1527268134288};\\\", \\\"{x:1614,y:236,t:1527268134305};\\\", \\\"{x:1598,y:232,t:1527268134321};\\\", \\\"{x:1589,y:229,t:1527268134338};\\\", \\\"{x:1583,y:227,t:1527268134355};\\\", \\\"{x:1579,y:226,t:1527268134372};\\\", \\\"{x:1576,y:225,t:1527268134387};\\\", \\\"{x:1574,y:224,t:1527268134405};\\\", \\\"{x:1573,y:224,t:1527268134480};\\\", \\\"{x:1573,y:226,t:1527268134487};\\\", \\\"{x:1572,y:237,t:1527268134505};\\\", \\\"{x:1572,y:259,t:1527268134522};\\\", \\\"{x:1573,y:277,t:1527268134538};\\\", \\\"{x:1576,y:287,t:1527268134555};\\\", \\\"{x:1584,y:302,t:1527268134571};\\\", \\\"{x:1595,y:320,t:1527268134588};\\\", \\\"{x:1609,y:344,t:1527268134605};\\\", \\\"{x:1627,y:376,t:1527268134621};\\\", \\\"{x:1645,y:406,t:1527268134637};\\\", \\\"{x:1668,y:449,t:1527268134655};\\\", \\\"{x:1704,y:509,t:1527268134672};\\\", \\\"{x:1719,y:529,t:1527268134688};\\\", \\\"{x:1730,y:549,t:1527268134704};\\\", \\\"{x:1743,y:571,t:1527268134723};\\\", \\\"{x:1753,y:595,t:1527268134737};\\\", \\\"{x:1763,y:617,t:1527268134754};\\\", \\\"{x:1770,y:639,t:1527268134771};\\\", \\\"{x:1779,y:660,t:1527268134788};\\\", \\\"{x:1787,y:678,t:1527268134804};\\\", \\\"{x:1792,y:692,t:1527268134822};\\\", \\\"{x:1796,y:701,t:1527268134839};\\\", \\\"{x:1801,y:717,t:1527268134854};\\\", \\\"{x:1807,y:738,t:1527268134871};\\\", \\\"{x:1807,y:745,t:1527268134889};\\\", \\\"{x:1810,y:754,t:1527268134905};\\\", \\\"{x:1810,y:759,t:1527268134922};\\\", \\\"{x:1811,y:765,t:1527268134939};\\\", \\\"{x:1812,y:770,t:1527268134954};\\\", \\\"{x:1813,y:776,t:1527268134972};\\\", \\\"{x:1814,y:781,t:1527268134988};\\\", \\\"{x:1815,y:787,t:1527268135005};\\\", \\\"{x:1816,y:795,t:1527268135022};\\\", \\\"{x:1817,y:802,t:1527268135038};\\\", \\\"{x:1818,y:807,t:1527268135054};\\\", \\\"{x:1819,y:814,t:1527268135071};\\\", \\\"{x:1819,y:818,t:1527268135089};\\\", \\\"{x:1819,y:821,t:1527268135105};\\\", \\\"{x:1819,y:824,t:1527268135122};\\\", \\\"{x:1819,y:828,t:1527268135139};\\\", \\\"{x:1819,y:829,t:1527268135160};\\\", \\\"{x:1819,y:831,t:1527268135176};\\\", \\\"{x:1818,y:832,t:1527268135192};\\\", \\\"{x:1817,y:833,t:1527268135206};\\\", \\\"{x:1817,y:835,t:1527268135224};\\\", \\\"{x:1816,y:835,t:1527268135240};\\\", \\\"{x:1816,y:836,t:1527268135256};\\\", \\\"{x:1815,y:836,t:1527268135272};\\\", \\\"{x:1815,y:837,t:1527268135289};\\\", \\\"{x:1814,y:838,t:1527268135306};\\\", \\\"{x:1814,y:839,t:1527268135328};\\\", \\\"{x:1812,y:840,t:1527268135339};\\\", \\\"{x:1812,y:841,t:1527268135360};\\\", \\\"{x:1811,y:841,t:1527268135383};\\\", \\\"{x:1811,y:842,t:1527268135392};\\\", \\\"{x:1810,y:842,t:1527268135405};\\\", \\\"{x:1808,y:844,t:1527268135422};\\\", \\\"{x:1806,y:844,t:1527268135438};\\\", \\\"{x:1803,y:847,t:1527268135456};\\\", \\\"{x:1799,y:849,t:1527268135472};\\\", \\\"{x:1798,y:850,t:1527268135488};\\\", \\\"{x:1793,y:853,t:1527268135506};\\\", \\\"{x:1786,y:857,t:1527268135521};\\\", \\\"{x:1776,y:861,t:1527268135538};\\\", \\\"{x:1764,y:865,t:1527268135555};\\\", \\\"{x:1754,y:869,t:1527268135571};\\\", \\\"{x:1745,y:873,t:1527268135589};\\\", \\\"{x:1737,y:877,t:1527268135605};\\\", \\\"{x:1728,y:880,t:1527268135622};\\\", \\\"{x:1720,y:884,t:1527268135639};\\\", \\\"{x:1703,y:892,t:1527268135655};\\\", \\\"{x:1683,y:900,t:1527268135672};\\\", \\\"{x:1665,y:908,t:1527268135688};\\\", \\\"{x:1649,y:915,t:1527268135706};\\\", \\\"{x:1633,y:920,t:1527268135722};\\\", \\\"{x:1616,y:925,t:1527268135738};\\\", \\\"{x:1608,y:928,t:1527268135755};\\\", \\\"{x:1603,y:929,t:1527268135773};\\\", \\\"{x:1600,y:930,t:1527268135788};\\\", \\\"{x:1598,y:931,t:1527268135806};\\\", \\\"{x:1597,y:931,t:1527268135822};\\\", \\\"{x:1596,y:932,t:1527268135839};\\\", \\\"{x:1593,y:933,t:1527268135855};\\\", \\\"{x:1591,y:933,t:1527268135872};\\\", \\\"{x:1589,y:935,t:1527268135889};\\\", \\\"{x:1586,y:936,t:1527268135906};\\\", \\\"{x:1582,y:936,t:1527268135922};\\\", \\\"{x:1580,y:938,t:1527268135938};\\\", \\\"{x:1576,y:938,t:1527268135956};\\\", \\\"{x:1573,y:938,t:1527268135973};\\\", \\\"{x:1565,y:938,t:1527268135989};\\\", \\\"{x:1555,y:934,t:1527268136006};\\\", \\\"{x:1544,y:929,t:1527268136023};\\\", \\\"{x:1533,y:923,t:1527268136038};\\\", \\\"{x:1515,y:914,t:1527268136055};\\\", \\\"{x:1506,y:908,t:1527268136073};\\\", \\\"{x:1501,y:905,t:1527268136089};\\\", \\\"{x:1496,y:902,t:1527268136105};\\\", \\\"{x:1493,y:898,t:1527268136122};\\\", \\\"{x:1490,y:893,t:1527268136139};\\\", \\\"{x:1486,y:886,t:1527268136156};\\\", \\\"{x:1481,y:874,t:1527268136173};\\\", \\\"{x:1474,y:856,t:1527268136189};\\\", \\\"{x:1463,y:830,t:1527268136206};\\\", \\\"{x:1453,y:802,t:1527268136223};\\\", \\\"{x:1422,y:736,t:1527268136239};\\\", \\\"{x:1404,y:699,t:1527268136255};\\\", \\\"{x:1380,y:651,t:1527268136273};\\\", \\\"{x:1361,y:621,t:1527268136289};\\\", \\\"{x:1349,y:600,t:1527268136305};\\\", \\\"{x:1338,y:583,t:1527268136322};\\\", \\\"{x:1330,y:569,t:1527268136340};\\\", \\\"{x:1324,y:557,t:1527268136355};\\\", \\\"{x:1317,y:541,t:1527268136373};\\\", \\\"{x:1313,y:532,t:1527268136389};\\\", \\\"{x:1309,y:524,t:1527268136405};\\\", \\\"{x:1306,y:518,t:1527268136422};\\\", \\\"{x:1304,y:513,t:1527268136440};\\\", \\\"{x:1304,y:512,t:1527268136463};\\\", \\\"{x:1304,y:511,t:1527268136543};\\\", \\\"{x:1304,y:510,t:1527268136559};\\\", \\\"{x:1306,y:508,t:1527268136573};\\\", \\\"{x:1308,y:507,t:1527268136589};\\\", \\\"{x:1315,y:504,t:1527268136606};\\\", \\\"{x:1320,y:503,t:1527268136623};\\\", \\\"{x:1327,y:499,t:1527268136639};\\\", \\\"{x:1331,y:498,t:1527268136657};\\\", \\\"{x:1333,y:497,t:1527268136673};\\\", \\\"{x:1336,y:497,t:1527268136689};\\\", \\\"{x:1339,y:497,t:1527268136707};\\\", \\\"{x:1345,y:498,t:1527268136722};\\\", \\\"{x:1355,y:506,t:1527268136739};\\\", \\\"{x:1369,y:518,t:1527268136756};\\\", \\\"{x:1386,y:538,t:1527268136773};\\\", \\\"{x:1400,y:556,t:1527268136790};\\\", \\\"{x:1414,y:574,t:1527268136806};\\\", \\\"{x:1428,y:595,t:1527268136823};\\\", \\\"{x:1447,y:621,t:1527268136840};\\\", \\\"{x:1453,y:633,t:1527268136857};\\\", \\\"{x:1458,y:643,t:1527268136873};\\\", \\\"{x:1463,y:657,t:1527268136889};\\\", \\\"{x:1468,y:670,t:1527268136906};\\\", \\\"{x:1471,y:683,t:1527268136924};\\\", \\\"{x:1473,y:693,t:1527268136939};\\\", \\\"{x:1476,y:709,t:1527268136956};\\\", \\\"{x:1477,y:720,t:1527268136973};\\\", \\\"{x:1478,y:733,t:1527268136990};\\\", \\\"{x:1479,y:745,t:1527268137007};\\\", \\\"{x:1479,y:756,t:1527268137023};\\\", \\\"{x:1479,y:773,t:1527268137039};\\\", \\\"{x:1479,y:784,t:1527268137056};\\\", \\\"{x:1479,y:796,t:1527268137073};\\\", \\\"{x:1479,y:806,t:1527268137089};\\\", \\\"{x:1478,y:816,t:1527268137106};\\\", \\\"{x:1475,y:824,t:1527268137123};\\\", \\\"{x:1469,y:834,t:1527268137140};\\\", \\\"{x:1464,y:843,t:1527268137156};\\\", \\\"{x:1458,y:851,t:1527268137173};\\\", \\\"{x:1455,y:854,t:1527268137189};\\\", \\\"{x:1451,y:857,t:1527268137206};\\\", \\\"{x:1448,y:860,t:1527268137224};\\\", \\\"{x:1445,y:860,t:1527268137239};\\\", \\\"{x:1444,y:860,t:1527268137256};\\\", \\\"{x:1443,y:860,t:1527268137273};\\\", \\\"{x:1443,y:859,t:1527268137290};\\\", \\\"{x:1440,y:846,t:1527268137306};\\\", \\\"{x:1440,y:828,t:1527268137324};\\\", \\\"{x:1440,y:804,t:1527268137339};\\\", \\\"{x:1440,y:778,t:1527268137357};\\\", \\\"{x:1442,y:749,t:1527268137374};\\\", \\\"{x:1442,y:723,t:1527268137389};\\\", \\\"{x:1442,y:701,t:1527268137407};\\\", \\\"{x:1442,y:667,t:1527268137423};\\\", \\\"{x:1442,y:652,t:1527268137440};\\\", \\\"{x:1442,y:641,t:1527268137456};\\\", \\\"{x:1442,y:633,t:1527268137474};\\\", \\\"{x:1445,y:622,t:1527268137490};\\\", \\\"{x:1445,y:616,t:1527268137507};\\\", \\\"{x:1446,y:610,t:1527268137524};\\\", \\\"{x:1447,y:604,t:1527268137540};\\\", \\\"{x:1450,y:595,t:1527268137557};\\\", \\\"{x:1453,y:585,t:1527268137573};\\\", \\\"{x:1455,y:574,t:1527268137591};\\\", \\\"{x:1459,y:566,t:1527268137606};\\\", \\\"{x:1460,y:556,t:1527268137624};\\\", \\\"{x:1460,y:546,t:1527268137641};\\\", \\\"{x:1463,y:533,t:1527268137657};\\\", \\\"{x:1466,y:515,t:1527268137674};\\\", \\\"{x:1469,y:496,t:1527268137691};\\\", \\\"{x:1471,y:483,t:1527268137707};\\\", \\\"{x:1473,y:466,t:1527268137724};\\\", \\\"{x:1475,y:448,t:1527268137740};\\\", \\\"{x:1476,y:432,t:1527268137756};\\\", \\\"{x:1479,y:413,t:1527268137773};\\\", \\\"{x:1480,y:401,t:1527268137791};\\\", \\\"{x:1480,y:387,t:1527268137807};\\\", \\\"{x:1480,y:368,t:1527268137824};\\\", \\\"{x:1480,y:362,t:1527268137841};\\\", \\\"{x:1481,y:357,t:1527268137858};\\\", \\\"{x:1483,y:353,t:1527268137874};\\\", \\\"{x:1483,y:348,t:1527268137891};\\\", \\\"{x:1483,y:345,t:1527268137908};\\\", \\\"{x:1483,y:342,t:1527268137924};\\\", \\\"{x:1483,y:339,t:1527268137941};\\\", \\\"{x:1484,y:335,t:1527268137958};\\\", \\\"{x:1486,y:331,t:1527268137974};\\\", \\\"{x:1487,y:326,t:1527268137990};\\\", \\\"{x:1490,y:320,t:1527268138007};\\\", \\\"{x:1491,y:317,t:1527268138023};\\\", \\\"{x:1493,y:313,t:1527268138040};\\\", \\\"{x:1495,y:309,t:1527268138057};\\\", \\\"{x:1496,y:304,t:1527268138074};\\\", \\\"{x:1499,y:299,t:1527268138090};\\\", \\\"{x:1499,y:297,t:1527268138108};\\\", \\\"{x:1501,y:294,t:1527268138123};\\\", \\\"{x:1503,y:290,t:1527268138140};\\\", \\\"{x:1504,y:287,t:1527268138157};\\\", \\\"{x:1505,y:285,t:1527268138174};\\\", \\\"{x:1507,y:281,t:1527268138190};\\\", \\\"{x:1510,y:278,t:1527268138207};\\\", \\\"{x:1511,y:276,t:1527268138224};\\\", \\\"{x:1512,y:276,t:1527268138241};\\\", \\\"{x:1512,y:275,t:1527268138258};\\\", \\\"{x:1514,y:275,t:1527268138295};\\\", \\\"{x:1518,y:277,t:1527268138307};\\\", \\\"{x:1528,y:289,t:1527268138324};\\\", \\\"{x:1543,y:308,t:1527268138340};\\\", \\\"{x:1568,y:345,t:1527268138357};\\\", \\\"{x:1590,y:376,t:1527268138374};\\\", \\\"{x:1610,y:409,t:1527268138390};\\\", \\\"{x:1621,y:429,t:1527268138406};\\\", \\\"{x:1622,y:432,t:1527268138425};\\\", \\\"{x:1622,y:433,t:1527268138736};\\\", \\\"{x:1621,y:435,t:1527268138799};\\\", \\\"{x:1621,y:437,t:1527268138807};\\\", \\\"{x:1620,y:442,t:1527268138825};\\\", \\\"{x:1620,y:446,t:1527268138841};\\\", \\\"{x:1620,y:448,t:1527268138858};\\\", \\\"{x:1620,y:451,t:1527268138875};\\\", \\\"{x:1620,y:453,t:1527268138968};\\\", \\\"{x:1620,y:454,t:1527268138991};\\\", \\\"{x:1620,y:456,t:1527268139014};\\\", \\\"{x:1620,y:457,t:1527268139038};\\\", \\\"{x:1620,y:459,t:1527268139079};\\\", \\\"{x:1620,y:457,t:1527268139344};\\\", \\\"{x:1620,y:456,t:1527268139360};\\\", \\\"{x:1620,y:454,t:1527268139375};\\\", \\\"{x:1620,y:450,t:1527268139392};\\\", \\\"{x:1620,y:448,t:1527268139409};\\\", \\\"{x:1619,y:446,t:1527268139425};\\\", \\\"{x:1619,y:445,t:1527268139442};\\\", \\\"{x:1619,y:444,t:1527268139459};\\\", \\\"{x:1619,y:443,t:1527268139475};\\\", \\\"{x:1619,y:442,t:1527268139491};\\\", \\\"{x:1619,y:441,t:1527268139509};\\\", \\\"{x:1619,y:440,t:1527268139525};\\\", \\\"{x:1619,y:439,t:1527268139592};\\\", \\\"{x:1619,y:438,t:1527268139609};\\\", \\\"{x:1619,y:437,t:1527268139626};\\\", \\\"{x:1619,y:436,t:1527268139642};\\\", \\\"{x:1619,y:434,t:1527268139659};\\\", \\\"{x:1619,y:433,t:1527268139682};\\\", \\\"{x:1619,y:431,t:1527268139709};\\\", \\\"{x:1619,y:430,t:1527268139744};\\\", \\\"{x:1618,y:428,t:1527268139768};\\\", \\\"{x:1618,y:427,t:1527268139816};\\\", \\\"{x:1618,y:426,t:1527268139826};\\\", \\\"{x:1618,y:429,t:1527268140143};\\\", \\\"{x:1618,y:432,t:1527268140158};\\\", \\\"{x:1618,y:435,t:1527268140176};\\\", \\\"{x:1618,y:437,t:1527268140192};\\\", \\\"{x:1619,y:440,t:1527268140208};\\\", \\\"{x:1619,y:444,t:1527268140226};\\\", \\\"{x:1620,y:448,t:1527268140243};\\\", \\\"{x:1621,y:453,t:1527268140259};\\\", \\\"{x:1621,y:456,t:1527268140276};\\\", \\\"{x:1622,y:461,t:1527268140293};\\\", \\\"{x:1623,y:466,t:1527268140309};\\\", \\\"{x:1624,y:475,t:1527268140326};\\\", \\\"{x:1625,y:486,t:1527268140343};\\\", \\\"{x:1626,y:492,t:1527268140358};\\\", \\\"{x:1629,y:505,t:1527268140376};\\\", \\\"{x:1630,y:511,t:1527268140393};\\\", \\\"{x:1630,y:518,t:1527268140409};\\\", \\\"{x:1630,y:527,t:1527268140426};\\\", \\\"{x:1630,y:537,t:1527268140443};\\\", \\\"{x:1633,y:550,t:1527268140459};\\\", \\\"{x:1634,y:564,t:1527268140476};\\\", \\\"{x:1636,y:578,t:1527268140493};\\\", \\\"{x:1638,y:587,t:1527268140509};\\\", \\\"{x:1639,y:591,t:1527268140525};\\\", \\\"{x:1639,y:594,t:1527268140542};\\\", \\\"{x:1640,y:600,t:1527268140559};\\\", \\\"{x:1641,y:603,t:1527268140575};\\\", \\\"{x:1641,y:605,t:1527268140592};\\\", \\\"{x:1641,y:607,t:1527268140610};\\\", \\\"{x:1641,y:608,t:1527268140626};\\\", \\\"{x:1641,y:611,t:1527268140643};\\\", \\\"{x:1641,y:614,t:1527268140660};\\\", \\\"{x:1641,y:619,t:1527268140675};\\\", \\\"{x:1641,y:623,t:1527268140693};\\\", \\\"{x:1641,y:627,t:1527268140710};\\\", \\\"{x:1641,y:631,t:1527268140726};\\\", \\\"{x:1641,y:635,t:1527268140742};\\\", \\\"{x:1641,y:639,t:1527268140759};\\\", \\\"{x:1641,y:643,t:1527268140776};\\\", \\\"{x:1641,y:648,t:1527268140793};\\\", \\\"{x:1641,y:652,t:1527268140809};\\\", \\\"{x:1641,y:657,t:1527268140826};\\\", \\\"{x:1642,y:663,t:1527268140843};\\\", \\\"{x:1643,y:669,t:1527268140859};\\\", \\\"{x:1644,y:676,t:1527268140876};\\\", \\\"{x:1645,y:682,t:1527268140893};\\\", \\\"{x:1646,y:686,t:1527268140910};\\\", \\\"{x:1646,y:691,t:1527268140927};\\\", \\\"{x:1647,y:695,t:1527268140942};\\\", \\\"{x:1648,y:701,t:1527268140959};\\\", \\\"{x:1648,y:704,t:1527268140976};\\\", \\\"{x:1648,y:706,t:1527268140993};\\\", \\\"{x:1648,y:708,t:1527268141010};\\\", \\\"{x:1648,y:711,t:1527268141027};\\\", \\\"{x:1648,y:713,t:1527268141043};\\\", \\\"{x:1648,y:716,t:1527268141060};\\\", \\\"{x:1648,y:721,t:1527268141076};\\\", \\\"{x:1648,y:726,t:1527268141093};\\\", \\\"{x:1648,y:732,t:1527268141110};\\\", \\\"{x:1648,y:741,t:1527268141127};\\\", \\\"{x:1648,y:748,t:1527268141143};\\\", \\\"{x:1648,y:753,t:1527268141159};\\\", \\\"{x:1648,y:760,t:1527268141177};\\\", \\\"{x:1648,y:767,t:1527268141192};\\\", \\\"{x:1648,y:774,t:1527268141210};\\\", \\\"{x:1648,y:781,t:1527268141226};\\\", \\\"{x:1647,y:787,t:1527268141243};\\\", \\\"{x:1647,y:793,t:1527268141260};\\\", \\\"{x:1646,y:797,t:1527268141277};\\\", \\\"{x:1645,y:802,t:1527268141292};\\\", \\\"{x:1644,y:807,t:1527268141310};\\\", \\\"{x:1644,y:811,t:1527268141327};\\\", \\\"{x:1643,y:818,t:1527268141343};\\\", \\\"{x:1642,y:822,t:1527268141359};\\\", \\\"{x:1641,y:826,t:1527268141376};\\\", \\\"{x:1641,y:829,t:1527268141393};\\\", \\\"{x:1641,y:832,t:1527268141409};\\\", \\\"{x:1641,y:836,t:1527268141427};\\\", \\\"{x:1641,y:839,t:1527268141444};\\\", \\\"{x:1641,y:843,t:1527268141460};\\\", \\\"{x:1641,y:846,t:1527268141477};\\\", \\\"{x:1641,y:849,t:1527268141494};\\\", \\\"{x:1641,y:853,t:1527268141510};\\\", \\\"{x:1641,y:857,t:1527268141527};\\\", \\\"{x:1643,y:862,t:1527268141543};\\\", \\\"{x:1643,y:865,t:1527268141560};\\\", \\\"{x:1643,y:868,t:1527268141578};\\\", \\\"{x:1643,y:870,t:1527268141594};\\\", \\\"{x:1643,y:874,t:1527268141610};\\\", \\\"{x:1643,y:875,t:1527268141627};\\\", \\\"{x:1643,y:877,t:1527268141644};\\\", \\\"{x:1643,y:879,t:1527268141660};\\\", \\\"{x:1643,y:881,t:1527268141677};\\\", \\\"{x:1643,y:884,t:1527268141694};\\\", \\\"{x:1643,y:887,t:1527268141710};\\\", \\\"{x:1643,y:890,t:1527268141727};\\\", \\\"{x:1643,y:894,t:1527268141743};\\\", \\\"{x:1643,y:896,t:1527268141760};\\\", \\\"{x:1643,y:899,t:1527268141777};\\\", \\\"{x:1643,y:901,t:1527268141794};\\\", \\\"{x:1643,y:906,t:1527268141810};\\\", \\\"{x:1643,y:909,t:1527268141827};\\\", \\\"{x:1643,y:913,t:1527268141844};\\\", \\\"{x:1643,y:918,t:1527268141861};\\\", \\\"{x:1643,y:924,t:1527268141877};\\\", \\\"{x:1643,y:933,t:1527268141894};\\\", \\\"{x:1641,y:944,t:1527268141911};\\\", \\\"{x:1640,y:957,t:1527268141927};\\\", \\\"{x:1640,y:970,t:1527268141943};\\\", \\\"{x:1640,y:975,t:1527268141961};\\\", \\\"{x:1640,y:980,t:1527268141977};\\\", \\\"{x:1640,y:983,t:1527268141994};\\\", \\\"{x:1640,y:986,t:1527268142011};\\\", \\\"{x:1640,y:988,t:1527268142027};\\\", \\\"{x:1640,y:989,t:1527268142044};\\\", \\\"{x:1640,y:990,t:1527268142061};\\\", \\\"{x:1639,y:991,t:1527268142672};\\\", \\\"{x:1638,y:991,t:1527268142680};\\\", \\\"{x:1637,y:991,t:1527268142695};\\\", \\\"{x:1632,y:991,t:1527268142712};\\\", \\\"{x:1628,y:991,t:1527268142727};\\\", \\\"{x:1627,y:991,t:1527268142744};\\\", \\\"{x:1627,y:989,t:1527268142920};\\\", \\\"{x:1627,y:988,t:1527268142927};\\\", \\\"{x:1625,y:982,t:1527268142945};\\\", \\\"{x:1625,y:978,t:1527268142961};\\\", \\\"{x:1624,y:974,t:1527268142978};\\\", \\\"{x:1624,y:970,t:1527268142995};\\\", \\\"{x:1624,y:968,t:1527268143011};\\\", \\\"{x:1624,y:966,t:1527268143028};\\\", \\\"{x:1623,y:964,t:1527268143045};\\\", \\\"{x:1623,y:963,t:1527268143060};\\\", \\\"{x:1623,y:961,t:1527268143078};\\\", \\\"{x:1623,y:960,t:1527268143095};\\\", \\\"{x:1623,y:958,t:1527268143135};\\\", \\\"{x:1623,y:957,t:1527268143191};\\\", \\\"{x:1623,y:955,t:1527268143215};\\\", \\\"{x:1622,y:955,t:1527268143228};\\\", \\\"{x:1622,y:954,t:1527268143245};\\\", \\\"{x:1622,y:953,t:1527268143262};\\\", \\\"{x:1621,y:951,t:1527268143278};\\\", \\\"{x:1620,y:947,t:1527268143294};\\\", \\\"{x:1620,y:941,t:1527268143311};\\\", \\\"{x:1618,y:930,t:1527268143328};\\\", \\\"{x:1616,y:921,t:1527268143345};\\\", \\\"{x:1612,y:912,t:1527268143362};\\\", \\\"{x:1611,y:906,t:1527268143378};\\\", \\\"{x:1609,y:899,t:1527268143395};\\\", \\\"{x:1607,y:892,t:1527268143412};\\\", \\\"{x:1607,y:884,t:1527268143428};\\\", \\\"{x:1606,y:875,t:1527268143444};\\\", \\\"{x:1604,y:863,t:1527268143462};\\\", \\\"{x:1604,y:848,t:1527268143478};\\\", \\\"{x:1603,y:831,t:1527268143495};\\\", \\\"{x:1603,y:819,t:1527268143512};\\\", \\\"{x:1603,y:809,t:1527268143528};\\\", \\\"{x:1603,y:801,t:1527268143544};\\\", \\\"{x:1603,y:794,t:1527268143562};\\\", \\\"{x:1603,y:788,t:1527268143579};\\\", \\\"{x:1603,y:783,t:1527268143594};\\\", \\\"{x:1603,y:781,t:1527268143612};\\\", \\\"{x:1603,y:778,t:1527268143629};\\\", \\\"{x:1603,y:775,t:1527268143645};\\\", \\\"{x:1603,y:773,t:1527268143662};\\\", \\\"{x:1603,y:768,t:1527268143679};\\\", \\\"{x:1603,y:764,t:1527268143695};\\\", \\\"{x:1603,y:756,t:1527268143712};\\\", \\\"{x:1603,y:749,t:1527268143729};\\\", \\\"{x:1603,y:739,t:1527268143745};\\\", \\\"{x:1603,y:726,t:1527268143762};\\\", \\\"{x:1603,y:705,t:1527268143779};\\\", \\\"{x:1599,y:684,t:1527268143795};\\\", \\\"{x:1597,y:666,t:1527268143811};\\\", \\\"{x:1593,y:649,t:1527268143828};\\\", \\\"{x:1587,y:634,t:1527268143845};\\\", \\\"{x:1582,y:615,t:1527268143862};\\\", \\\"{x:1569,y:588,t:1527268143878};\\\", \\\"{x:1554,y:567,t:1527268143895};\\\", \\\"{x:1539,y:551,t:1527268143912};\\\", \\\"{x:1515,y:535,t:1527268143928};\\\", \\\"{x:1491,y:526,t:1527268143945};\\\", \\\"{x:1448,y:512,t:1527268143961};\\\", \\\"{x:1384,y:495,t:1527268143979};\\\", \\\"{x:1305,y:480,t:1527268143996};\\\", \\\"{x:1225,y:469,t:1527268144011};\\\", \\\"{x:1137,y:462,t:1527268144028};\\\", \\\"{x:1041,y:454,t:1527268144046};\\\", \\\"{x:947,y:445,t:1527268144061};\\\", \\\"{x:792,y:443,t:1527268144079};\\\", \\\"{x:678,y:443,t:1527268144095};\\\", \\\"{x:578,y:443,t:1527268144111};\\\", \\\"{x:497,y:445,t:1527268144128};\\\", \\\"{x:441,y:453,t:1527268144146};\\\", \\\"{x:387,y:461,t:1527268144161};\\\", \\\"{x:342,y:474,t:1527268144179};\\\", \\\"{x:305,y:487,t:1527268144195};\\\", \\\"{x:269,y:504,t:1527268144211};\\\", \\\"{x:229,y:524,t:1527268144228};\\\", \\\"{x:202,y:539,t:1527268144246};\\\", \\\"{x:175,y:556,t:1527268144262};\\\", \\\"{x:134,y:583,t:1527268144279};\\\", \\\"{x:103,y:604,t:1527268144296};\\\", \\\"{x:70,y:625,t:1527268144313};\\\", \\\"{x:42,y:641,t:1527268144329};\\\", \\\"{x:17,y:661,t:1527268144346};\\\", \\\"{x:0,y:679,t:1527268144362};\\\", \\\"{x:0,y:695,t:1527268144378};\\\", \\\"{x:0,y:710,t:1527268144395};\\\", \\\"{x:0,y:720,t:1527268144411};\\\", \\\"{x:0,y:729,t:1527268144429};\\\", \\\"{x:0,y:736,t:1527268144446};\\\", \\\"{x:5,y:742,t:1527268144461};\\\", \\\"{x:17,y:747,t:1527268144479};\\\", \\\"{x:32,y:747,t:1527268144494};\\\", \\\"{x:49,y:747,t:1527268144512};\\\", \\\"{x:67,y:743,t:1527268144529};\\\", \\\"{x:96,y:732,t:1527268144544};\\\", \\\"{x:124,y:718,t:1527268144561};\\\", \\\"{x:149,y:699,t:1527268144578};\\\", \\\"{x:173,y:676,t:1527268144594};\\\", \\\"{x:192,y:655,t:1527268144612};\\\", \\\"{x:204,y:639,t:1527268144628};\\\", \\\"{x:210,y:623,t:1527268144645};\\\", \\\"{x:211,y:613,t:1527268144663};\\\", \\\"{x:211,y:605,t:1527268144679};\\\", \\\"{x:203,y:587,t:1527268144695};\\\", \\\"{x:192,y:576,t:1527268144714};\\\", \\\"{x:179,y:566,t:1527268144730};\\\", \\\"{x:161,y:557,t:1527268144746};\\\", \\\"{x:144,y:551,t:1527268144764};\\\", \\\"{x:127,y:547,t:1527268144780};\\\", \\\"{x:108,y:542,t:1527268144796};\\\", \\\"{x:92,y:540,t:1527268144813};\\\", \\\"{x:84,y:540,t:1527268144829};\\\", \\\"{x:82,y:540,t:1527268144846};\\\", \\\"{x:82,y:541,t:1527268144967};\\\", \\\"{x:85,y:543,t:1527268144980};\\\", \\\"{x:98,y:551,t:1527268144995};\\\", \\\"{x:109,y:556,t:1527268145013};\\\", \\\"{x:122,y:562,t:1527268145029};\\\", \\\"{x:140,y:572,t:1527268145046};\\\", \\\"{x:163,y:582,t:1527268145063};\\\", \\\"{x:175,y:584,t:1527268145079};\\\", \\\"{x:185,y:586,t:1527268145096};\\\", \\\"{x:190,y:586,t:1527268145112};\\\", \\\"{x:194,y:586,t:1527268145130};\\\", \\\"{x:197,y:586,t:1527268145146};\\\", \\\"{x:200,y:586,t:1527268145162};\\\", \\\"{x:202,y:586,t:1527268145180};\\\", \\\"{x:203,y:586,t:1527268145196};\\\", \\\"{x:204,y:586,t:1527268145214};\\\", \\\"{x:205,y:586,t:1527268145230};\\\", \\\"{x:210,y:585,t:1527268145247};\\\", \\\"{x:216,y:584,t:1527268145263};\\\", \\\"{x:224,y:581,t:1527268145280};\\\", \\\"{x:236,y:577,t:1527268145296};\\\", \\\"{x:253,y:573,t:1527268145313};\\\", \\\"{x:270,y:568,t:1527268145330};\\\", \\\"{x:285,y:564,t:1527268145347};\\\", \\\"{x:305,y:558,t:1527268145362};\\\", \\\"{x:321,y:554,t:1527268145379};\\\", \\\"{x:326,y:552,t:1527268145397};\\\", \\\"{x:328,y:551,t:1527268145413};\\\", \\\"{x:330,y:549,t:1527268145471};\\\", \\\"{x:332,y:549,t:1527268145479};\\\", \\\"{x:340,y:549,t:1527268145496};\\\", \\\"{x:352,y:549,t:1527268145512};\\\", \\\"{x:375,y:549,t:1527268145530};\\\", \\\"{x:407,y:549,t:1527268145547};\\\", \\\"{x:437,y:549,t:1527268145563};\\\", \\\"{x:459,y:549,t:1527268145579};\\\", \\\"{x:485,y:549,t:1527268145596};\\\", \\\"{x:520,y:558,t:1527268145615};\\\", \\\"{x:551,y:565,t:1527268145630};\\\", \\\"{x:590,y:577,t:1527268145647};\\\", \\\"{x:612,y:582,t:1527268145663};\\\", \\\"{x:636,y:586,t:1527268145680};\\\", \\\"{x:651,y:586,t:1527268145697};\\\", \\\"{x:654,y:586,t:1527268145713};\\\", \\\"{x:656,y:586,t:1527268145729};\\\", \\\"{x:657,y:586,t:1527268145750};\\\", \\\"{x:658,y:586,t:1527268145783};\\\", \\\"{x:659,y:586,t:1527268145796};\\\", \\\"{x:661,y:585,t:1527268145812};\\\", \\\"{x:673,y:580,t:1527268145830};\\\", \\\"{x:697,y:571,t:1527268145846};\\\", \\\"{x:711,y:568,t:1527268145864};\\\", \\\"{x:727,y:563,t:1527268145882};\\\", \\\"{x:741,y:559,t:1527268145897};\\\", \\\"{x:756,y:554,t:1527268145913};\\\", \\\"{x:768,y:549,t:1527268145931};\\\", \\\"{x:778,y:545,t:1527268145947};\\\", \\\"{x:782,y:544,t:1527268145964};\\\", \\\"{x:784,y:543,t:1527268145981};\\\", \\\"{x:782,y:543,t:1527268146031};\\\", \\\"{x:772,y:545,t:1527268146046};\\\", \\\"{x:756,y:552,t:1527268146064};\\\", \\\"{x:724,y:561,t:1527268146080};\\\", \\\"{x:666,y:575,t:1527268146097};\\\", \\\"{x:585,y:586,t:1527268146114};\\\", \\\"{x:499,y:600,t:1527268146130};\\\", \\\"{x:418,y:611,t:1527268146147};\\\", \\\"{x:348,y:621,t:1527268146165};\\\", \\\"{x:292,y:631,t:1527268146181};\\\", \\\"{x:266,y:640,t:1527268146198};\\\", \\\"{x:250,y:645,t:1527268146214};\\\", \\\"{x:247,y:647,t:1527268146231};\\\", \\\"{x:247,y:645,t:1527268146327};\\\", \\\"{x:247,y:642,t:1527268146335};\\\", \\\"{x:247,y:641,t:1527268146348};\\\", \\\"{x:246,y:633,t:1527268146364};\\\", \\\"{x:244,y:621,t:1527268146381};\\\", \\\"{x:235,y:608,t:1527268146399};\\\", \\\"{x:215,y:588,t:1527268146414};\\\", \\\"{x:203,y:583,t:1527268146431};\\\", \\\"{x:198,y:582,t:1527268146446};\\\", \\\"{x:196,y:582,t:1527268146463};\\\", \\\"{x:194,y:582,t:1527268146480};\\\", \\\"{x:188,y:583,t:1527268146497};\\\", \\\"{x:182,y:588,t:1527268146514};\\\", \\\"{x:174,y:594,t:1527268146530};\\\", \\\"{x:169,y:598,t:1527268146547};\\\", \\\"{x:162,y:602,t:1527268146564};\\\", \\\"{x:161,y:603,t:1527268146581};\\\", \\\"{x:164,y:603,t:1527268146688};\\\", \\\"{x:168,y:603,t:1527268146699};\\\", \\\"{x:185,y:598,t:1527268146714};\\\", \\\"{x:208,y:596,t:1527268146732};\\\", \\\"{x:237,y:594,t:1527268146748};\\\", \\\"{x:279,y:594,t:1527268146765};\\\", \\\"{x:324,y:594,t:1527268146781};\\\", \\\"{x:359,y:594,t:1527268146797};\\\", \\\"{x:384,y:594,t:1527268146814};\\\", \\\"{x:410,y:594,t:1527268146831};\\\", \\\"{x:418,y:594,t:1527268146848};\\\", \\\"{x:419,y:594,t:1527268146911};\\\", \\\"{x:419,y:595,t:1527268146934};\\\", \\\"{x:418,y:595,t:1527268146948};\\\", \\\"{x:414,y:599,t:1527268146964};\\\", \\\"{x:409,y:604,t:1527268146981};\\\", \\\"{x:403,y:610,t:1527268146998};\\\", \\\"{x:395,y:615,t:1527268147015};\\\", \\\"{x:389,y:619,t:1527268147031};\\\", \\\"{x:385,y:623,t:1527268147048};\\\", \\\"{x:383,y:624,t:1527268147065};\\\", \\\"{x:382,y:625,t:1527268147080};\\\", \\\"{x:380,y:626,t:1527268147098};\\\", \\\"{x:377,y:628,t:1527268147115};\\\", \\\"{x:373,y:629,t:1527268147130};\\\", \\\"{x:367,y:632,t:1527268147148};\\\", \\\"{x:364,y:632,t:1527268147164};\\\", \\\"{x:359,y:632,t:1527268147181};\\\", \\\"{x:350,y:632,t:1527268147198};\\\", \\\"{x:328,y:630,t:1527268147214};\\\", \\\"{x:301,y:623,t:1527268147232};\\\", \\\"{x:270,y:613,t:1527268147248};\\\", \\\"{x:237,y:607,t:1527268147265};\\\", \\\"{x:215,y:605,t:1527268147281};\\\", \\\"{x:198,y:605,t:1527268147298};\\\", \\\"{x:191,y:605,t:1527268147315};\\\", \\\"{x:188,y:607,t:1527268147332};\\\", \\\"{x:187,y:607,t:1527268147347};\\\", \\\"{x:187,y:610,t:1527268147365};\\\", \\\"{x:187,y:612,t:1527268147381};\\\", \\\"{x:186,y:614,t:1527268147398};\\\", \\\"{x:183,y:615,t:1527268147414};\\\", \\\"{x:180,y:618,t:1527268147431};\\\", \\\"{x:176,y:621,t:1527268147448};\\\", \\\"{x:173,y:625,t:1527268147465};\\\", \\\"{x:171,y:627,t:1527268147481};\\\", \\\"{x:170,y:629,t:1527268147497};\\\", \\\"{x:169,y:630,t:1527268147559};\\\", \\\"{x:168,y:631,t:1527268147575};\\\", \\\"{x:166,y:632,t:1527268147582};\\\", \\\"{x:165,y:633,t:1527268147598};\\\", \\\"{x:164,y:633,t:1527268147614};\\\", \\\"{x:163,y:634,t:1527268147631};\\\", \\\"{x:166,y:635,t:1527268147863};\\\", \\\"{x:174,y:638,t:1527268147871};\\\", \\\"{x:186,y:643,t:1527268147882};\\\", \\\"{x:218,y:651,t:1527268147899};\\\", \\\"{x:266,y:665,t:1527268147914};\\\", \\\"{x:298,y:673,t:1527268147931};\\\", \\\"{x:337,y:684,t:1527268147948};\\\", \\\"{x:368,y:692,t:1527268147965};\\\", \\\"{x:393,y:699,t:1527268147982};\\\", \\\"{x:423,y:707,t:1527268147998};\\\", \\\"{x:434,y:709,t:1527268148015};\\\", \\\"{x:442,y:710,t:1527268148032};\\\", \\\"{x:446,y:710,t:1527268148049};\\\", \\\"{x:447,y:710,t:1527268148071};\\\", \\\"{x:449,y:711,t:1527268148095};\\\", \\\"{x:451,y:712,t:1527268148103};\\\", \\\"{x:454,y:713,t:1527268148115};\\\", \\\"{x:464,y:717,t:1527268148132};\\\", \\\"{x:482,y:724,t:1527268148148};\\\", \\\"{x:509,y:734,t:1527268148165};\\\", \\\"{x:548,y:745,t:1527268148182};\\\", \\\"{x:588,y:755,t:1527268148199};\\\", \\\"{x:600,y:759,t:1527268148215};\\\", \\\"{x:603,y:759,t:1527268148232};\\\", \\\"{x:602,y:759,t:1527268148375};\\\", \\\"{x:598,y:759,t:1527268148383};\\\", \\\"{x:585,y:755,t:1527268148399};\\\", \\\"{x:564,y:749,t:1527268148416};\\\", \\\"{x:539,y:742,t:1527268148432};\\\", \\\"{x:515,y:734,t:1527268148450};\\\", \\\"{x:493,y:727,t:1527268148465};\\\", \\\"{x:477,y:722,t:1527268148481};\\\", \\\"{x:472,y:722,t:1527268148498};\\\", \\\"{x:471,y:721,t:1527268149582};\\\", \\\"{x:471,y:720,t:1527268149600};\\\", \\\"{x:472,y:719,t:1527268149615};\\\", \\\"{x:474,y:717,t:1527268149633};\\\", \\\"{x:478,y:716,t:1527268149650};\\\", \\\"{x:482,y:715,t:1527268149666};\\\", \\\"{x:485,y:713,t:1527268149683};\\\", \\\"{x:492,y:712,t:1527268149713};\\\", \\\"{x:495,y:711,t:1527268149719};\\\", \\\"{x:501,y:709,t:1527268149733};\\\", \\\"{x:515,y:708,t:1527268149750};\\\", \\\"{x:546,y:706,t:1527268149767};\\\", \\\"{x:564,y:706,t:1527268149782};\\\" ] }, { \\\"rt\\\": 37437, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 211166, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -F -08 PM-08 PM-09 AM-C -A -U -C -07 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:992,y:508,t:1527268149997};\\\", \\\"{x:1048,y:491,t:1527268150023};\\\", \\\"{x:1061,y:487,t:1527268150033};\\\", \\\"{x:1081,y:481,t:1527268150050};\\\", \\\"{x:1091,y:480,t:1527268150067};\\\", \\\"{x:1094,y:478,t:1527268150083};\\\", \\\"{x:1095,y:477,t:1527268150100};\\\", \\\"{x:1098,y:477,t:1527268150117};\\\", \\\"{x:1095,y:477,t:1527268150631};\\\", \\\"{x:1089,y:479,t:1527268150639};\\\", \\\"{x:1084,y:481,t:1527268150651};\\\", \\\"{x:1078,y:484,t:1527268150667};\\\", \\\"{x:1072,y:487,t:1527268150684};\\\", \\\"{x:1068,y:488,t:1527268150700};\\\", \\\"{x:1066,y:488,t:1527268150717};\\\", \\\"{x:1065,y:488,t:1527268150751};\\\", \\\"{x:1051,y:488,t:1527268150767};\\\", \\\"{x:996,y:488,t:1527268150784};\\\", \\\"{x:901,y:472,t:1527268150801};\\\", \\\"{x:826,y:460,t:1527268150817};\\\", \\\"{x:756,y:440,t:1527268150834};\\\", \\\"{x:692,y:419,t:1527268150851};\\\", \\\"{x:636,y:404,t:1527268150867};\\\", \\\"{x:582,y:395,t:1527268150884};\\\", \\\"{x:545,y:388,t:1527268150901};\\\", \\\"{x:520,y:380,t:1527268150917};\\\", \\\"{x:496,y:364,t:1527268150934};\\\", \\\"{x:468,y:346,t:1527268150951};\\\", \\\"{x:470,y:346,t:1527268151255};\\\", \\\"{x:475,y:346,t:1527268151267};\\\", \\\"{x:490,y:348,t:1527268151284};\\\", \\\"{x:502,y:349,t:1527268151301};\\\", \\\"{x:511,y:350,t:1527268151318};\\\", \\\"{x:527,y:353,t:1527268151334};\\\", \\\"{x:555,y:355,t:1527268151350};\\\", \\\"{x:576,y:356,t:1527268151368};\\\", \\\"{x:610,y:362,t:1527268151384};\\\", \\\"{x:642,y:362,t:1527268151401};\\\", \\\"{x:685,y:362,t:1527268151418};\\\", \\\"{x:727,y:362,t:1527268151434};\\\", \\\"{x:759,y:362,t:1527268151451};\\\", \\\"{x:790,y:356,t:1527268151468};\\\", \\\"{x:834,y:338,t:1527268151485};\\\", \\\"{x:873,y:321,t:1527268151501};\\\", \\\"{x:920,y:298,t:1527268151519};\\\", \\\"{x:1000,y:262,t:1527268151535};\\\", \\\"{x:1060,y:238,t:1527268151551};\\\", \\\"{x:1120,y:216,t:1527268151568};\\\", \\\"{x:1168,y:199,t:1527268151586};\\\", \\\"{x:1201,y:187,t:1527268151602};\\\", \\\"{x:1240,y:176,t:1527268151618};\\\", \\\"{x:1282,y:163,t:1527268151635};\\\", \\\"{x:1324,y:150,t:1527268151651};\\\", \\\"{x:1367,y:142,t:1527268151669};\\\", \\\"{x:1418,y:135,t:1527268151685};\\\", \\\"{x:1466,y:127,t:1527268151701};\\\", \\\"{x:1519,y:119,t:1527268151718};\\\", \\\"{x:1591,y:109,t:1527268151735};\\\", \\\"{x:1615,y:106,t:1527268151751};\\\", \\\"{x:1640,y:102,t:1527268151769};\\\", \\\"{x:1657,y:99,t:1527268151785};\\\", \\\"{x:1662,y:99,t:1527268151802};\\\", \\\"{x:1663,y:99,t:1527268151819};\\\", \\\"{x:1663,y:100,t:1527268152262};\\\", \\\"{x:1663,y:103,t:1527268152270};\\\", \\\"{x:1662,y:104,t:1527268152287};\\\", \\\"{x:1662,y:107,t:1527268152303};\\\", \\\"{x:1661,y:107,t:1527268152318};\\\", \\\"{x:1661,y:116,t:1527268152335};\\\", \\\"{x:1661,y:121,t:1527268152352};\\\", \\\"{x:1661,y:125,t:1527268152368};\\\", \\\"{x:1661,y:128,t:1527268152385};\\\", \\\"{x:1659,y:133,t:1527268152402};\\\", \\\"{x:1658,y:137,t:1527268152419};\\\", \\\"{x:1657,y:142,t:1527268152435};\\\", \\\"{x:1657,y:144,t:1527268152452};\\\", \\\"{x:1655,y:147,t:1527268152469};\\\", \\\"{x:1655,y:148,t:1527268152485};\\\", \\\"{x:1655,y:150,t:1527268152502};\\\", \\\"{x:1654,y:154,t:1527268152519};\\\", \\\"{x:1652,y:155,t:1527268152535};\\\", \\\"{x:1652,y:158,t:1527268152551};\\\", \\\"{x:1652,y:159,t:1527268152569};\\\", \\\"{x:1651,y:162,t:1527268152585};\\\", \\\"{x:1650,y:164,t:1527268152602};\\\", \\\"{x:1648,y:166,t:1527268152619};\\\", \\\"{x:1648,y:168,t:1527268152634};\\\", \\\"{x:1648,y:169,t:1527268152652};\\\", \\\"{x:1647,y:172,t:1527268152668};\\\", \\\"{x:1645,y:175,t:1527268152685};\\\", \\\"{x:1644,y:179,t:1527268152702};\\\", \\\"{x:1643,y:184,t:1527268152719};\\\", \\\"{x:1641,y:187,t:1527268152735};\\\", \\\"{x:1641,y:190,t:1527268152752};\\\", \\\"{x:1640,y:196,t:1527268152769};\\\", \\\"{x:1639,y:201,t:1527268152786};\\\", \\\"{x:1638,y:206,t:1527268152801};\\\", \\\"{x:1638,y:213,t:1527268152819};\\\", \\\"{x:1638,y:217,t:1527268152836};\\\", \\\"{x:1637,y:225,t:1527268152852};\\\", \\\"{x:1636,y:230,t:1527268152869};\\\", \\\"{x:1636,y:234,t:1527268152886};\\\", \\\"{x:1634,y:239,t:1527268152902};\\\", \\\"{x:1634,y:244,t:1527268152919};\\\", \\\"{x:1634,y:250,t:1527268152936};\\\", \\\"{x:1634,y:254,t:1527268152952};\\\", \\\"{x:1634,y:258,t:1527268152969};\\\", \\\"{x:1634,y:262,t:1527268152986};\\\", \\\"{x:1634,y:268,t:1527268153002};\\\", \\\"{x:1634,y:272,t:1527268153019};\\\", \\\"{x:1634,y:277,t:1527268153036};\\\", \\\"{x:1636,y:280,t:1527268153053};\\\", \\\"{x:1639,y:287,t:1527268153069};\\\", \\\"{x:1642,y:291,t:1527268153087};\\\", \\\"{x:1643,y:294,t:1527268153102};\\\", \\\"{x:1645,y:296,t:1527268153120};\\\", \\\"{x:1646,y:298,t:1527268153137};\\\", \\\"{x:1648,y:299,t:1527268153152};\\\", \\\"{x:1650,y:302,t:1527268153169};\\\", \\\"{x:1655,y:305,t:1527268153186};\\\", \\\"{x:1656,y:306,t:1527268153202};\\\", \\\"{x:1659,y:308,t:1527268153220};\\\", \\\"{x:1662,y:310,t:1527268153236};\\\", \\\"{x:1663,y:311,t:1527268153252};\\\", \\\"{x:1664,y:312,t:1527268153269};\\\", \\\"{x:1665,y:312,t:1527268153286};\\\", \\\"{x:1666,y:312,t:1527268153303};\\\", \\\"{x:1668,y:314,t:1527268153319};\\\", \\\"{x:1669,y:315,t:1527268153336};\\\", \\\"{x:1670,y:316,t:1527268153367};\\\", \\\"{x:1671,y:316,t:1527268156747};\\\", \\\"{x:1671,y:317,t:1527268156759};\\\", \\\"{x:1668,y:321,t:1527268156776};\\\", \\\"{x:1661,y:327,t:1527268156792};\\\", \\\"{x:1658,y:330,t:1527268156809};\\\", \\\"{x:1656,y:333,t:1527268156826};\\\", \\\"{x:1655,y:334,t:1527268156842};\\\", \\\"{x:1654,y:336,t:1527268156859};\\\", \\\"{x:1652,y:339,t:1527268156876};\\\", \\\"{x:1649,y:344,t:1527268156891};\\\", \\\"{x:1647,y:346,t:1527268156909};\\\", \\\"{x:1643,y:351,t:1527268156926};\\\", \\\"{x:1641,y:356,t:1527268156942};\\\", \\\"{x:1638,y:361,t:1527268156959};\\\", \\\"{x:1636,y:365,t:1527268156975};\\\", \\\"{x:1634,y:370,t:1527268156992};\\\", \\\"{x:1631,y:380,t:1527268157009};\\\", \\\"{x:1627,y:390,t:1527268157026};\\\", \\\"{x:1621,y:405,t:1527268157042};\\\", \\\"{x:1612,y:433,t:1527268157060};\\\", \\\"{x:1604,y:455,t:1527268157076};\\\", \\\"{x:1594,y:477,t:1527268157092};\\\", \\\"{x:1584,y:504,t:1527268157109};\\\", \\\"{x:1568,y:536,t:1527268157126};\\\", \\\"{x:1551,y:572,t:1527268157143};\\\", \\\"{x:1527,y:613,t:1527268157159};\\\", \\\"{x:1501,y:652,t:1527268157176};\\\", \\\"{x:1475,y:683,t:1527268157193};\\\", \\\"{x:1454,y:705,t:1527268157209};\\\", \\\"{x:1440,y:718,t:1527268157225};\\\", \\\"{x:1420,y:729,t:1527268157242};\\\", \\\"{x:1407,y:737,t:1527268157259};\\\", \\\"{x:1395,y:741,t:1527268157276};\\\", \\\"{x:1387,y:743,t:1527268157293};\\\", \\\"{x:1386,y:744,t:1527268157309};\\\", \\\"{x:1385,y:744,t:1527268157326};\\\", \\\"{x:1384,y:744,t:1527268157343};\\\", \\\"{x:1383,y:745,t:1527268157370};\\\", \\\"{x:1382,y:746,t:1527268157378};\\\", \\\"{x:1381,y:747,t:1527268157392};\\\", \\\"{x:1380,y:749,t:1527268157409};\\\", \\\"{x:1378,y:752,t:1527268157426};\\\", \\\"{x:1376,y:759,t:1527268157443};\\\", \\\"{x:1375,y:764,t:1527268157459};\\\", \\\"{x:1374,y:770,t:1527268157476};\\\", \\\"{x:1374,y:779,t:1527268157493};\\\", \\\"{x:1375,y:787,t:1527268157510};\\\", \\\"{x:1381,y:801,t:1527268157526};\\\", \\\"{x:1386,y:810,t:1527268157543};\\\", \\\"{x:1391,y:820,t:1527268157559};\\\", \\\"{x:1395,y:828,t:1527268157576};\\\", \\\"{x:1401,y:837,t:1527268157594};\\\", \\\"{x:1404,y:843,t:1527268157609};\\\", \\\"{x:1408,y:850,t:1527268157626};\\\", \\\"{x:1409,y:856,t:1527268157643};\\\", \\\"{x:1411,y:859,t:1527268157659};\\\", \\\"{x:1411,y:860,t:1527268157683};\\\", \\\"{x:1411,y:861,t:1527268157707};\\\", \\\"{x:1411,y:862,t:1527268157724};\\\", \\\"{x:1410,y:863,t:1527268157748};\\\", \\\"{x:1410,y:864,t:1527268157761};\\\", \\\"{x:1408,y:865,t:1527268157776};\\\", \\\"{x:1406,y:865,t:1527268157803};\\\", \\\"{x:1405,y:865,t:1527268157819};\\\", \\\"{x:1402,y:865,t:1527268157827};\\\", \\\"{x:1399,y:865,t:1527268157843};\\\", \\\"{x:1394,y:865,t:1527268157860};\\\", \\\"{x:1385,y:865,t:1527268157877};\\\", \\\"{x:1379,y:865,t:1527268157894};\\\", \\\"{x:1375,y:864,t:1527268157911};\\\", \\\"{x:1374,y:864,t:1527268157926};\\\", \\\"{x:1369,y:864,t:1527268157943};\\\", \\\"{x:1368,y:864,t:1527268157960};\\\", \\\"{x:1366,y:865,t:1527268158195};\\\", \\\"{x:1364,y:866,t:1527268158210};\\\", \\\"{x:1363,y:867,t:1527268158242};\\\", \\\"{x:1362,y:867,t:1527268158258};\\\", \\\"{x:1361,y:868,t:1527268158275};\\\", \\\"{x:1359,y:868,t:1527268158323};\\\", \\\"{x:1358,y:869,t:1527268158331};\\\", \\\"{x:1357,y:869,t:1527268158763};\\\", \\\"{x:1357,y:870,t:1527268158875};\\\", \\\"{x:1356,y:871,t:1527268158890};\\\", \\\"{x:1355,y:871,t:1527268158923};\\\", \\\"{x:1354,y:871,t:1527268158930};\\\", \\\"{x:1353,y:871,t:1527268158995};\\\", \\\"{x:1352,y:871,t:1527268159026};\\\", \\\"{x:1351,y:871,t:1527268159051};\\\", \\\"{x:1349,y:872,t:1527268159066};\\\", \\\"{x:1348,y:872,t:1527268159148};\\\", \\\"{x:1347,y:872,t:1527268159171};\\\", \\\"{x:1346,y:872,t:1527268159308};\\\", \\\"{x:1347,y:872,t:1527268160378};\\\", \\\"{x:1347,y:871,t:1527268160395};\\\", \\\"{x:1348,y:870,t:1527268160450};\\\", \\\"{x:1349,y:869,t:1527268160498};\\\", \\\"{x:1350,y:869,t:1527268160522};\\\", \\\"{x:1350,y:868,t:1527268160530};\\\", \\\"{x:1351,y:868,t:1527268160545};\\\", \\\"{x:1352,y:866,t:1527268160563};\\\", \\\"{x:1352,y:865,t:1527268160578};\\\", \\\"{x:1353,y:865,t:1527268160595};\\\", \\\"{x:1354,y:862,t:1527268160612};\\\", \\\"{x:1354,y:861,t:1527268160629};\\\", \\\"{x:1355,y:861,t:1527268160645};\\\", \\\"{x:1355,y:860,t:1527268160662};\\\", \\\"{x:1355,y:859,t:1527268160678};\\\", \\\"{x:1355,y:858,t:1527268160722};\\\", \\\"{x:1355,y:857,t:1527268160746};\\\", \\\"{x:1355,y:856,t:1527268160803};\\\", \\\"{x:1356,y:854,t:1527268160899};\\\", \\\"{x:1356,y:853,t:1527268161002};\\\", \\\"{x:1357,y:852,t:1527268161059};\\\", \\\"{x:1357,y:851,t:1527268161083};\\\", \\\"{x:1358,y:850,t:1527268161171};\\\", \\\"{x:1358,y:849,t:1527268161218};\\\", \\\"{x:1359,y:848,t:1527268161243};\\\", \\\"{x:1360,y:847,t:1527268161258};\\\", \\\"{x:1361,y:846,t:1527268161274};\\\", \\\"{x:1361,y:845,t:1527268161290};\\\", \\\"{x:1362,y:845,t:1527268161298};\\\", \\\"{x:1363,y:844,t:1527268161314};\\\", \\\"{x:1363,y:843,t:1527268161329};\\\", \\\"{x:1364,y:841,t:1527268161345};\\\", \\\"{x:1366,y:840,t:1527268161362};\\\", \\\"{x:1368,y:837,t:1527268161380};\\\", \\\"{x:1372,y:834,t:1527268161395};\\\", \\\"{x:1376,y:829,t:1527268161412};\\\", \\\"{x:1379,y:825,t:1527268161429};\\\", \\\"{x:1382,y:821,t:1527268161446};\\\", \\\"{x:1387,y:814,t:1527268161462};\\\", \\\"{x:1388,y:812,t:1527268161479};\\\", \\\"{x:1390,y:808,t:1527268161496};\\\", \\\"{x:1391,y:805,t:1527268161512};\\\", \\\"{x:1394,y:800,t:1527268161529};\\\", \\\"{x:1397,y:796,t:1527268161546};\\\", \\\"{x:1399,y:792,t:1527268161563};\\\", \\\"{x:1400,y:789,t:1527268161579};\\\", \\\"{x:1401,y:785,t:1527268161596};\\\", \\\"{x:1402,y:775,t:1527268161612};\\\", \\\"{x:1405,y:758,t:1527268161629};\\\", \\\"{x:1408,y:743,t:1527268161646};\\\", \\\"{x:1411,y:731,t:1527268161662};\\\", \\\"{x:1413,y:726,t:1527268161679};\\\", \\\"{x:1415,y:719,t:1527268161696};\\\", \\\"{x:1417,y:709,t:1527268161712};\\\", \\\"{x:1422,y:692,t:1527268161729};\\\", \\\"{x:1430,y:661,t:1527268161747};\\\", \\\"{x:1435,y:645,t:1527268161762};\\\", \\\"{x:1438,y:632,t:1527268161779};\\\", \\\"{x:1444,y:615,t:1527268161796};\\\", \\\"{x:1448,y:600,t:1527268161812};\\\", \\\"{x:1452,y:581,t:1527268161829};\\\", \\\"{x:1456,y:567,t:1527268161846};\\\", \\\"{x:1458,y:556,t:1527268161863};\\\", \\\"{x:1459,y:547,t:1527268161879};\\\", \\\"{x:1461,y:540,t:1527268161896};\\\", \\\"{x:1461,y:531,t:1527268161913};\\\", \\\"{x:1461,y:521,t:1527268161929};\\\", \\\"{x:1461,y:501,t:1527268161946};\\\", \\\"{x:1458,y:487,t:1527268161963};\\\", \\\"{x:1452,y:471,t:1527268161979};\\\", \\\"{x:1445,y:456,t:1527268161996};\\\", \\\"{x:1441,y:446,t:1527268162012};\\\", \\\"{x:1439,y:436,t:1527268162030};\\\", \\\"{x:1436,y:429,t:1527268162046};\\\", \\\"{x:1434,y:422,t:1527268162063};\\\", \\\"{x:1434,y:417,t:1527268162079};\\\", \\\"{x:1431,y:411,t:1527268162096};\\\", \\\"{x:1431,y:407,t:1527268162113};\\\", \\\"{x:1429,y:401,t:1527268162129};\\\", \\\"{x:1428,y:394,t:1527268162147};\\\", \\\"{x:1426,y:377,t:1527268162163};\\\", \\\"{x:1421,y:349,t:1527268162179};\\\", \\\"{x:1418,y:324,t:1527268162196};\\\", \\\"{x:1416,y:303,t:1527268162213};\\\", \\\"{x:1413,y:288,t:1527268162229};\\\", \\\"{x:1412,y:279,t:1527268162246};\\\", \\\"{x:1411,y:272,t:1527268162263};\\\", \\\"{x:1411,y:267,t:1527268162279};\\\", \\\"{x:1411,y:265,t:1527268162296};\\\", \\\"{x:1411,y:264,t:1527268162313};\\\", \\\"{x:1411,y:263,t:1527268162330};\\\", \\\"{x:1411,y:261,t:1527268162394};\\\", \\\"{x:1411,y:259,t:1527268162410};\\\", \\\"{x:1413,y:255,t:1527268162418};\\\", \\\"{x:1415,y:253,t:1527268162430};\\\", \\\"{x:1421,y:247,t:1527268162446};\\\", \\\"{x:1430,y:239,t:1527268162463};\\\", \\\"{x:1442,y:229,t:1527268162480};\\\", \\\"{x:1455,y:217,t:1527268162496};\\\", \\\"{x:1464,y:209,t:1527268162513};\\\", \\\"{x:1474,y:193,t:1527268162531};\\\", \\\"{x:1482,y:179,t:1527268162546};\\\", \\\"{x:1488,y:165,t:1527268162563};\\\", \\\"{x:1493,y:153,t:1527268162579};\\\", \\\"{x:1496,y:142,t:1527268162596};\\\", \\\"{x:1497,y:136,t:1527268162614};\\\", \\\"{x:1497,y:131,t:1527268162630};\\\", \\\"{x:1497,y:125,t:1527268162646};\\\", \\\"{x:1497,y:122,t:1527268162663};\\\", \\\"{x:1497,y:121,t:1527268162681};\\\", \\\"{x:1497,y:120,t:1527268162706};\\\", \\\"{x:1497,y:121,t:1527268162995};\\\", \\\"{x:1496,y:121,t:1527268163019};\\\", \\\"{x:1495,y:122,t:1527268163034};\\\", \\\"{x:1495,y:124,t:1527268163048};\\\", \\\"{x:1494,y:125,t:1527268163063};\\\", \\\"{x:1493,y:128,t:1527268163080};\\\", \\\"{x:1493,y:131,t:1527268163097};\\\", \\\"{x:1493,y:135,t:1527268163113};\\\", \\\"{x:1493,y:145,t:1527268163130};\\\", \\\"{x:1493,y:151,t:1527268163148};\\\", \\\"{x:1493,y:157,t:1527268163163};\\\", \\\"{x:1493,y:162,t:1527268163180};\\\", \\\"{x:1494,y:170,t:1527268163197};\\\", \\\"{x:1498,y:180,t:1527268163213};\\\", \\\"{x:1501,y:192,t:1527268163230};\\\", \\\"{x:1507,y:206,t:1527268163248};\\\", \\\"{x:1514,y:220,t:1527268163263};\\\", \\\"{x:1521,y:236,t:1527268163280};\\\", \\\"{x:1526,y:246,t:1527268163297};\\\", \\\"{x:1534,y:263,t:1527268163314};\\\", \\\"{x:1545,y:290,t:1527268163330};\\\", \\\"{x:1553,y:310,t:1527268163347};\\\", \\\"{x:1565,y:334,t:1527268163363};\\\", \\\"{x:1581,y:366,t:1527268163380};\\\", \\\"{x:1600,y:408,t:1527268163397};\\\", \\\"{x:1620,y:452,t:1527268163415};\\\", \\\"{x:1644,y:507,t:1527268163430};\\\", \\\"{x:1676,y:572,t:1527268163447};\\\", \\\"{x:1712,y:637,t:1527268163464};\\\", \\\"{x:1744,y:696,t:1527268163480};\\\", \\\"{x:1769,y:740,t:1527268163498};\\\", \\\"{x:1803,y:788,t:1527268163515};\\\", \\\"{x:1818,y:809,t:1527268163530};\\\", \\\"{x:1828,y:823,t:1527268163547};\\\", \\\"{x:1838,y:835,t:1527268163564};\\\", \\\"{x:1841,y:839,t:1527268163580};\\\", \\\"{x:1843,y:842,t:1527268163598};\\\", \\\"{x:1843,y:844,t:1527268163707};\\\", \\\"{x:1843,y:849,t:1527268163714};\\\", \\\"{x:1842,y:859,t:1527268163730};\\\", \\\"{x:1841,y:870,t:1527268163748};\\\", \\\"{x:1841,y:880,t:1527268163764};\\\", \\\"{x:1841,y:892,t:1527268163781};\\\", \\\"{x:1841,y:906,t:1527268163797};\\\", \\\"{x:1847,y:928,t:1527268163814};\\\", \\\"{x:1858,y:951,t:1527268163831};\\\", \\\"{x:1873,y:973,t:1527268163847};\\\", \\\"{x:1888,y:990,t:1527268163865};\\\", \\\"{x:1902,y:1004,t:1527268163880};\\\", \\\"{x:1913,y:1012,t:1527268163897};\\\", \\\"{x:1919,y:1019,t:1527268163914};\\\", \\\"{x:1919,y:1018,t:1527268164250};\\\", \\\"{x:1919,y:1016,t:1527268164265};\\\", \\\"{x:1914,y:1007,t:1527268164282};\\\", \\\"{x:1905,y:993,t:1527268164299};\\\", \\\"{x:1894,y:977,t:1527268164315};\\\", \\\"{x:1878,y:959,t:1527268164333};\\\", \\\"{x:1845,y:929,t:1527268164349};\\\", \\\"{x:1772,y:878,t:1527268164365};\\\", \\\"{x:1654,y:805,t:1527268164382};\\\", \\\"{x:1519,y:728,t:1527268164398};\\\", \\\"{x:1381,y:660,t:1527268164415};\\\", \\\"{x:1270,y:607,t:1527268164432};\\\", \\\"{x:1195,y:569,t:1527268164450};\\\", \\\"{x:1142,y:537,t:1527268164465};\\\", \\\"{x:1107,y:508,t:1527268164481};\\\", \\\"{x:1098,y:497,t:1527268164499};\\\", \\\"{x:1092,y:484,t:1527268164515};\\\", \\\"{x:1088,y:474,t:1527268164532};\\\", \\\"{x:1084,y:465,t:1527268164549};\\\", \\\"{x:1083,y:461,t:1527268164565};\\\", \\\"{x:1083,y:459,t:1527268164582};\\\", \\\"{x:1083,y:458,t:1527268164599};\\\", \\\"{x:1083,y:455,t:1527268164615};\\\", \\\"{x:1083,y:454,t:1527268164651};\\\", \\\"{x:1083,y:453,t:1527268164665};\\\", \\\"{x:1083,y:452,t:1527268164682};\\\", \\\"{x:1084,y:451,t:1527268164699};\\\", \\\"{x:1085,y:450,t:1527268164716};\\\", \\\"{x:1086,y:448,t:1527268164733};\\\", \\\"{x:1087,y:448,t:1527268164755};\\\", \\\"{x:1088,y:447,t:1527268164771};\\\", \\\"{x:1089,y:447,t:1527268164787};\\\", \\\"{x:1090,y:446,t:1527268164803};\\\", \\\"{x:1092,y:445,t:1527268164843};\\\", \\\"{x:1093,y:445,t:1527268164859};\\\", \\\"{x:1094,y:444,t:1527268164899};\\\", \\\"{x:1095,y:443,t:1527268164930};\\\", \\\"{x:1096,y:443,t:1527268164938};\\\", \\\"{x:1097,y:442,t:1527268165050};\\\", \\\"{x:1096,y:442,t:1527268166827};\\\", \\\"{x:1095,y:443,t:1527268166858};\\\", \\\"{x:1095,y:446,t:1527268167243};\\\", \\\"{x:1095,y:451,t:1527268167251};\\\", \\\"{x:1095,y:465,t:1527268167267};\\\", \\\"{x:1100,y:482,t:1527268167284};\\\", \\\"{x:1108,y:496,t:1527268167301};\\\", \\\"{x:1122,y:513,t:1527268167317};\\\", \\\"{x:1135,y:528,t:1527268167334};\\\", \\\"{x:1149,y:545,t:1527268167352};\\\", \\\"{x:1165,y:559,t:1527268167368};\\\", \\\"{x:1186,y:575,t:1527268167384};\\\", \\\"{x:1201,y:592,t:1527268167401};\\\", \\\"{x:1219,y:618,t:1527268167417};\\\", \\\"{x:1229,y:636,t:1527268167434};\\\", \\\"{x:1242,y:660,t:1527268167452};\\\", \\\"{x:1255,y:691,t:1527268167468};\\\", \\\"{x:1264,y:714,t:1527268167485};\\\", \\\"{x:1274,y:737,t:1527268167501};\\\", \\\"{x:1280,y:756,t:1527268167518};\\\", \\\"{x:1288,y:772,t:1527268167535};\\\", \\\"{x:1293,y:786,t:1527268167552};\\\", \\\"{x:1296,y:798,t:1527268167569};\\\", \\\"{x:1300,y:811,t:1527268167585};\\\", \\\"{x:1301,y:819,t:1527268167602};\\\", \\\"{x:1306,y:834,t:1527268167618};\\\", \\\"{x:1306,y:843,t:1527268167635};\\\", \\\"{x:1306,y:850,t:1527268167651};\\\", \\\"{x:1306,y:859,t:1527268167669};\\\", \\\"{x:1303,y:862,t:1527268167685};\\\", \\\"{x:1293,y:866,t:1527268167702};\\\", \\\"{x:1280,y:869,t:1527268167718};\\\", \\\"{x:1275,y:869,t:1527268167734};\\\", \\\"{x:1273,y:870,t:1527268167923};\\\", \\\"{x:1268,y:870,t:1527268167935};\\\", \\\"{x:1262,y:868,t:1527268167951};\\\", \\\"{x:1254,y:868,t:1527268167968};\\\", \\\"{x:1249,y:868,t:1527268167985};\\\", \\\"{x:1245,y:869,t:1527268168001};\\\", \\\"{x:1242,y:870,t:1527268168019};\\\", \\\"{x:1237,y:873,t:1527268168036};\\\", \\\"{x:1226,y:881,t:1527268168051};\\\", \\\"{x:1213,y:894,t:1527268168068};\\\", \\\"{x:1195,y:910,t:1527268168085};\\\", \\\"{x:1175,y:927,t:1527268168102};\\\", \\\"{x:1157,y:943,t:1527268168119};\\\", \\\"{x:1143,y:954,t:1527268168135};\\\", \\\"{x:1133,y:963,t:1527268168151};\\\", \\\"{x:1126,y:971,t:1527268168169};\\\", \\\"{x:1119,y:978,t:1527268168186};\\\", \\\"{x:1116,y:982,t:1527268168202};\\\", \\\"{x:1111,y:989,t:1527268168219};\\\", \\\"{x:1108,y:993,t:1527268168235};\\\", \\\"{x:1106,y:995,t:1527268168251};\\\", \\\"{x:1106,y:996,t:1527268168269};\\\", \\\"{x:1105,y:998,t:1527268168286};\\\", \\\"{x:1107,y:998,t:1527268168403};\\\", \\\"{x:1110,y:998,t:1527268168420};\\\", \\\"{x:1114,y:998,t:1527268168436};\\\", \\\"{x:1118,y:997,t:1527268168453};\\\", \\\"{x:1121,y:995,t:1527268168469};\\\", \\\"{x:1125,y:994,t:1527268168486};\\\", \\\"{x:1128,y:992,t:1527268168503};\\\", \\\"{x:1132,y:990,t:1527268168519};\\\", \\\"{x:1136,y:987,t:1527268168536};\\\", \\\"{x:1140,y:985,t:1527268168553};\\\", \\\"{x:1143,y:984,t:1527268168569};\\\", \\\"{x:1146,y:982,t:1527268168586};\\\", \\\"{x:1148,y:980,t:1527268168602};\\\", \\\"{x:1149,y:980,t:1527268168619};\\\", \\\"{x:1150,y:978,t:1527268168635};\\\", \\\"{x:1152,y:977,t:1527268168652};\\\", \\\"{x:1153,y:976,t:1527268168674};\\\", \\\"{x:1153,y:975,t:1527268168686};\\\", \\\"{x:1154,y:974,t:1527268168702};\\\", \\\"{x:1155,y:972,t:1527268168719};\\\", \\\"{x:1156,y:971,t:1527268168738};\\\", \\\"{x:1156,y:970,t:1527268168778};\\\", \\\"{x:1157,y:969,t:1527268168787};\\\", \\\"{x:1158,y:969,t:1527268168811};\\\", \\\"{x:1158,y:968,t:1527268168819};\\\", \\\"{x:1158,y:966,t:1527268168836};\\\", \\\"{x:1159,y:966,t:1527268168852};\\\", \\\"{x:1160,y:964,t:1527268168869};\\\", \\\"{x:1161,y:963,t:1527268168886};\\\", \\\"{x:1162,y:962,t:1527268168903};\\\", \\\"{x:1163,y:960,t:1527268168920};\\\", \\\"{x:1164,y:958,t:1527268168935};\\\", \\\"{x:1166,y:957,t:1527268168952};\\\", \\\"{x:1166,y:956,t:1527268168969};\\\", \\\"{x:1166,y:955,t:1527268168985};\\\", \\\"{x:1167,y:954,t:1527268169003};\\\", \\\"{x:1167,y:953,t:1527268169019};\\\", \\\"{x:1168,y:951,t:1527268169036};\\\", \\\"{x:1169,y:950,t:1527268169052};\\\", \\\"{x:1170,y:948,t:1527268169069};\\\", \\\"{x:1171,y:946,t:1527268169085};\\\", \\\"{x:1172,y:945,t:1527268169103};\\\", \\\"{x:1172,y:944,t:1527268169119};\\\", \\\"{x:1173,y:943,t:1527268169135};\\\", \\\"{x:1173,y:942,t:1527268169153};\\\", \\\"{x:1174,y:940,t:1527268169169};\\\", \\\"{x:1175,y:939,t:1527268169185};\\\", \\\"{x:1176,y:938,t:1527268169219};\\\", \\\"{x:1176,y:937,t:1527268169234};\\\", \\\"{x:1176,y:936,t:1527268169259};\\\", \\\"{x:1177,y:935,t:1527268169275};\\\", \\\"{x:1177,y:934,t:1527268169290};\\\", \\\"{x:1178,y:933,t:1527268169322};\\\", \\\"{x:1178,y:932,t:1527268169338};\\\", \\\"{x:1178,y:931,t:1527268169354};\\\", \\\"{x:1179,y:930,t:1527268169370};\\\", \\\"{x:1179,y:928,t:1527268169387};\\\", \\\"{x:1180,y:925,t:1527268169402};\\\", \\\"{x:1182,y:924,t:1527268169419};\\\", \\\"{x:1182,y:921,t:1527268169436};\\\", \\\"{x:1184,y:918,t:1527268169452};\\\", \\\"{x:1184,y:917,t:1527268169470};\\\", \\\"{x:1186,y:914,t:1527268169487};\\\", \\\"{x:1186,y:912,t:1527268169503};\\\", \\\"{x:1186,y:910,t:1527268169520};\\\", \\\"{x:1187,y:907,t:1527268169537};\\\", \\\"{x:1188,y:905,t:1527268169552};\\\", \\\"{x:1188,y:904,t:1527268169569};\\\", \\\"{x:1189,y:902,t:1527268169587};\\\", \\\"{x:1189,y:899,t:1527268169603};\\\", \\\"{x:1189,y:898,t:1527268169620};\\\", \\\"{x:1190,y:895,t:1527268169636};\\\", \\\"{x:1190,y:894,t:1527268169653};\\\", \\\"{x:1192,y:891,t:1527268169670};\\\", \\\"{x:1192,y:889,t:1527268169690};\\\", \\\"{x:1192,y:888,t:1527268169714};\\\", \\\"{x:1193,y:888,t:1527268169722};\\\", \\\"{x:1193,y:886,t:1527268169738};\\\", \\\"{x:1193,y:885,t:1527268169754};\\\", \\\"{x:1193,y:884,t:1527268169769};\\\", \\\"{x:1193,y:883,t:1527268169786};\\\", \\\"{x:1194,y:882,t:1527268169804};\\\", \\\"{x:1195,y:881,t:1527268169820};\\\", \\\"{x:1195,y:880,t:1527268169836};\\\", \\\"{x:1195,y:879,t:1527268169859};\\\", \\\"{x:1196,y:879,t:1527268169869};\\\", \\\"{x:1196,y:877,t:1527268169887};\\\", \\\"{x:1197,y:875,t:1527268169914};\\\", \\\"{x:1198,y:875,t:1527268169931};\\\", \\\"{x:1198,y:874,t:1527268169947};\\\", \\\"{x:1198,y:873,t:1527268169994};\\\", \\\"{x:1198,y:871,t:1527268170034};\\\", \\\"{x:1199,y:870,t:1527268170059};\\\", \\\"{x:1199,y:869,t:1527268170091};\\\", \\\"{x:1200,y:867,t:1527268170107};\\\", \\\"{x:1201,y:867,t:1527268170120};\\\", \\\"{x:1201,y:866,t:1527268170146};\\\", \\\"{x:1202,y:864,t:1527268170162};\\\", \\\"{x:1202,y:863,t:1527268170203};\\\", \\\"{x:1202,y:862,t:1527268170235};\\\", \\\"{x:1202,y:861,t:1527268170242};\\\", \\\"{x:1202,y:860,t:1527268170258};\\\", \\\"{x:1203,y:859,t:1527268170282};\\\", \\\"{x:1203,y:858,t:1527268170298};\\\", \\\"{x:1203,y:857,t:1527268170315};\\\", \\\"{x:1203,y:856,t:1527268170338};\\\", \\\"{x:1204,y:856,t:1527268170353};\\\", \\\"{x:1205,y:854,t:1527268170370};\\\", \\\"{x:1205,y:853,t:1527268170395};\\\", \\\"{x:1205,y:852,t:1527268170403};\\\", \\\"{x:1205,y:851,t:1527268170427};\\\", \\\"{x:1205,y:850,t:1527268170436};\\\", \\\"{x:1205,y:848,t:1527268170454};\\\", \\\"{x:1205,y:846,t:1527268170491};\\\", \\\"{x:1206,y:845,t:1527268170539};\\\", \\\"{x:1207,y:843,t:1527268170636};\\\", \\\"{x:1208,y:843,t:1527268170827};\\\", \\\"{x:1208,y:842,t:1527268170842};\\\", \\\"{x:1209,y:842,t:1527268170994};\\\", \\\"{x:1210,y:841,t:1527268171019};\\\", \\\"{x:1211,y:841,t:1527268171050};\\\", \\\"{x:1211,y:840,t:1527268171066};\\\", \\\"{x:1212,y:839,t:1527268171122};\\\", \\\"{x:1213,y:838,t:1527268171171};\\\", \\\"{x:1214,y:838,t:1527268171227};\\\", \\\"{x:1215,y:837,t:1527268171267};\\\", \\\"{x:1215,y:836,t:1527268171315};\\\", \\\"{x:1216,y:836,t:1527268171458};\\\", \\\"{x:1217,y:835,t:1527268171602};\\\", \\\"{x:1217,y:834,t:1527268171674};\\\", \\\"{x:1218,y:834,t:1527268171779};\\\", \\\"{x:1219,y:833,t:1527268171867};\\\", \\\"{x:1220,y:832,t:1527268171989};\\\", \\\"{x:1222,y:832,t:1527268172059};\\\", \\\"{x:1223,y:831,t:1527268172091};\\\", \\\"{x:1225,y:830,t:1527268172180};\\\", \\\"{x:1226,y:830,t:1527268172211};\\\", \\\"{x:1227,y:829,t:1527268172244};\\\", \\\"{x:1228,y:829,t:1527268172283};\\\", \\\"{x:1229,y:829,t:1527268172347};\\\", \\\"{x:1231,y:829,t:1527268172362};\\\", \\\"{x:1232,y:829,t:1527268172372};\\\", \\\"{x:1235,y:829,t:1527268172389};\\\", \\\"{x:1238,y:829,t:1527268172406};\\\", \\\"{x:1243,y:829,t:1527268172422};\\\", \\\"{x:1249,y:829,t:1527268172438};\\\", \\\"{x:1253,y:829,t:1527268172455};\\\", \\\"{x:1257,y:829,t:1527268172471};\\\", \\\"{x:1259,y:829,t:1527268172488};\\\", \\\"{x:1264,y:830,t:1527268172506};\\\", \\\"{x:1267,y:830,t:1527268172521};\\\", \\\"{x:1274,y:830,t:1527268172539};\\\", \\\"{x:1279,y:830,t:1527268172556};\\\", \\\"{x:1286,y:831,t:1527268172571};\\\", \\\"{x:1294,y:833,t:1527268172589};\\\", \\\"{x:1302,y:835,t:1527268172605};\\\", \\\"{x:1313,y:836,t:1527268172622};\\\", \\\"{x:1320,y:836,t:1527268172639};\\\", \\\"{x:1327,y:837,t:1527268172656};\\\", \\\"{x:1333,y:837,t:1527268172671};\\\", \\\"{x:1338,y:837,t:1527268172688};\\\", \\\"{x:1342,y:837,t:1527268172705};\\\", \\\"{x:1346,y:837,t:1527268172722};\\\", \\\"{x:1347,y:837,t:1527268172739};\\\", \\\"{x:1351,y:839,t:1527268172756};\\\", \\\"{x:1354,y:839,t:1527268172773};\\\", \\\"{x:1356,y:839,t:1527268172788};\\\", \\\"{x:1361,y:840,t:1527268172806};\\\", \\\"{x:1363,y:840,t:1527268172822};\\\", \\\"{x:1367,y:840,t:1527268172838};\\\", \\\"{x:1370,y:841,t:1527268172855};\\\", \\\"{x:1373,y:842,t:1527268172872};\\\", \\\"{x:1375,y:842,t:1527268172889};\\\", \\\"{x:1378,y:842,t:1527268172906};\\\", \\\"{x:1384,y:842,t:1527268172923};\\\", \\\"{x:1387,y:843,t:1527268172939};\\\", \\\"{x:1391,y:843,t:1527268172955};\\\", \\\"{x:1393,y:843,t:1527268172973};\\\", \\\"{x:1396,y:844,t:1527268172988};\\\", \\\"{x:1399,y:844,t:1527268173005};\\\", \\\"{x:1402,y:844,t:1527268173022};\\\", \\\"{x:1405,y:844,t:1527268173039};\\\", \\\"{x:1406,y:844,t:1527268173056};\\\", \\\"{x:1409,y:844,t:1527268173073};\\\", \\\"{x:1411,y:844,t:1527268173090};\\\", \\\"{x:1412,y:844,t:1527268173115};\\\", \\\"{x:1414,y:844,t:1527268173138};\\\", \\\"{x:1415,y:844,t:1527268173147};\\\", \\\"{x:1416,y:844,t:1527268173156};\\\", \\\"{x:1418,y:844,t:1527268173172};\\\", \\\"{x:1422,y:843,t:1527268173189};\\\", \\\"{x:1426,y:843,t:1527268173205};\\\", \\\"{x:1430,y:842,t:1527268173222};\\\", \\\"{x:1432,y:841,t:1527268173240};\\\", \\\"{x:1436,y:841,t:1527268173255};\\\", \\\"{x:1439,y:840,t:1527268173273};\\\", \\\"{x:1441,y:840,t:1527268173289};\\\", \\\"{x:1443,y:839,t:1527268173306};\\\", \\\"{x:1446,y:839,t:1527268173323};\\\", \\\"{x:1448,y:839,t:1527268173340};\\\", \\\"{x:1449,y:839,t:1527268173356};\\\", \\\"{x:1452,y:839,t:1527268173373};\\\", \\\"{x:1455,y:839,t:1527268173390};\\\", \\\"{x:1459,y:838,t:1527268173406};\\\", \\\"{x:1461,y:837,t:1527268173423};\\\", \\\"{x:1462,y:837,t:1527268173440};\\\", \\\"{x:1463,y:837,t:1527268173459};\\\", \\\"{x:1464,y:837,t:1527268173473};\\\", \\\"{x:1465,y:836,t:1527268173490};\\\", \\\"{x:1466,y:835,t:1527268173506};\\\", \\\"{x:1469,y:835,t:1527268173523};\\\", \\\"{x:1472,y:835,t:1527268173540};\\\", \\\"{x:1477,y:835,t:1527268173556};\\\", \\\"{x:1480,y:833,t:1527268173573};\\\", \\\"{x:1484,y:833,t:1527268173589};\\\", \\\"{x:1486,y:833,t:1527268173607};\\\", \\\"{x:1491,y:832,t:1527268173623};\\\", \\\"{x:1497,y:831,t:1527268173640};\\\", \\\"{x:1502,y:829,t:1527268173657};\\\", \\\"{x:1511,y:829,t:1527268173673};\\\", \\\"{x:1519,y:828,t:1527268173690};\\\", \\\"{x:1535,y:825,t:1527268173707};\\\", \\\"{x:1546,y:823,t:1527268173722};\\\", \\\"{x:1555,y:823,t:1527268173739};\\\", \\\"{x:1563,y:822,t:1527268173757};\\\", \\\"{x:1569,y:822,t:1527268173773};\\\", \\\"{x:1571,y:821,t:1527268173790};\\\", \\\"{x:1574,y:820,t:1527268173807};\\\", \\\"{x:1575,y:820,t:1527268173822};\\\", \\\"{x:1576,y:820,t:1527268173840};\\\", \\\"{x:1578,y:819,t:1527268173857};\\\", \\\"{x:1580,y:819,t:1527268173873};\\\", \\\"{x:1583,y:819,t:1527268173890};\\\", \\\"{x:1588,y:819,t:1527268173906};\\\", \\\"{x:1592,y:818,t:1527268173923};\\\", \\\"{x:1594,y:817,t:1527268173940};\\\", \\\"{x:1596,y:817,t:1527268173957};\\\", \\\"{x:1598,y:817,t:1527268173973};\\\", \\\"{x:1601,y:817,t:1527268173990};\\\", \\\"{x:1605,y:816,t:1527268174007};\\\", \\\"{x:1611,y:815,t:1527268174023};\\\", \\\"{x:1616,y:813,t:1527268174040};\\\", \\\"{x:1623,y:811,t:1527268174056};\\\", \\\"{x:1626,y:810,t:1527268174074};\\\", \\\"{x:1630,y:809,t:1527268174090};\\\", \\\"{x:1634,y:808,t:1527268174107};\\\", \\\"{x:1637,y:806,t:1527268174124};\\\", \\\"{x:1643,y:805,t:1527268174140};\\\", \\\"{x:1648,y:804,t:1527268174156};\\\", \\\"{x:1652,y:802,t:1527268174174};\\\", \\\"{x:1654,y:802,t:1527268174189};\\\", \\\"{x:1655,y:802,t:1527268174207};\\\", \\\"{x:1656,y:801,t:1527268174224};\\\", \\\"{x:1656,y:802,t:1527268174404};\\\", \\\"{x:1656,y:803,t:1527268174411};\\\", \\\"{x:1655,y:803,t:1527268174424};\\\", \\\"{x:1651,y:806,t:1527268174440};\\\", \\\"{x:1647,y:810,t:1527268174457};\\\", \\\"{x:1644,y:813,t:1527268174474};\\\", \\\"{x:1641,y:817,t:1527268174490};\\\", \\\"{x:1637,y:823,t:1527268174507};\\\", \\\"{x:1633,y:827,t:1527268174524};\\\", \\\"{x:1630,y:831,t:1527268174541};\\\", \\\"{x:1626,y:836,t:1527268174557};\\\", \\\"{x:1622,y:841,t:1527268174574};\\\", \\\"{x:1618,y:845,t:1527268174591};\\\", \\\"{x:1610,y:855,t:1527268174607};\\\", \\\"{x:1601,y:863,t:1527268174624};\\\", \\\"{x:1590,y:870,t:1527268174641};\\\", \\\"{x:1582,y:876,t:1527268174656};\\\", \\\"{x:1571,y:882,t:1527268174674};\\\", \\\"{x:1553,y:893,t:1527268174690};\\\", \\\"{x:1543,y:896,t:1527268174707};\\\", \\\"{x:1531,y:902,t:1527268174724};\\\", \\\"{x:1521,y:907,t:1527268174741};\\\", \\\"{x:1511,y:909,t:1527268174757};\\\", \\\"{x:1496,y:914,t:1527268174774};\\\", \\\"{x:1485,y:916,t:1527268174791};\\\", \\\"{x:1465,y:919,t:1527268174807};\\\", \\\"{x:1454,y:920,t:1527268174824};\\\", \\\"{x:1440,y:920,t:1527268174841};\\\", \\\"{x:1425,y:920,t:1527268174857};\\\", \\\"{x:1406,y:920,t:1527268174874};\\\", \\\"{x:1377,y:916,t:1527268174890};\\\", \\\"{x:1364,y:915,t:1527268174907};\\\", \\\"{x:1353,y:912,t:1527268174924};\\\", \\\"{x:1340,y:911,t:1527268174941};\\\", \\\"{x:1324,y:907,t:1527268174958};\\\", \\\"{x:1311,y:901,t:1527268174974};\\\", \\\"{x:1298,y:895,t:1527268174990};\\\", \\\"{x:1287,y:891,t:1527268175008};\\\", \\\"{x:1273,y:889,t:1527268175024};\\\", \\\"{x:1258,y:881,t:1527268175041};\\\", \\\"{x:1244,y:875,t:1527268175058};\\\", \\\"{x:1237,y:874,t:1527268175074};\\\", \\\"{x:1229,y:870,t:1527268175091};\\\", \\\"{x:1226,y:867,t:1527268175108};\\\", \\\"{x:1225,y:866,t:1527268175131};\\\", \\\"{x:1222,y:865,t:1527268175141};\\\", \\\"{x:1218,y:860,t:1527268175158};\\\", \\\"{x:1212,y:855,t:1527268175174};\\\", \\\"{x:1209,y:851,t:1527268175191};\\\", \\\"{x:1209,y:850,t:1527268175210};\\\", \\\"{x:1209,y:849,t:1527268175224};\\\", \\\"{x:1209,y:848,t:1527268175240};\\\", \\\"{x:1209,y:846,t:1527268175258};\\\", \\\"{x:1209,y:843,t:1527268175274};\\\", \\\"{x:1210,y:840,t:1527268175291};\\\", \\\"{x:1211,y:839,t:1527268175308};\\\", \\\"{x:1214,y:836,t:1527268175323};\\\", \\\"{x:1215,y:834,t:1527268175341};\\\", \\\"{x:1216,y:832,t:1527268175358};\\\", \\\"{x:1218,y:830,t:1527268175374};\\\", \\\"{x:1220,y:828,t:1527268175390};\\\", \\\"{x:1221,y:827,t:1527268175419};\\\", \\\"{x:1221,y:826,t:1527268175435};\\\", \\\"{x:1221,y:825,t:1527268175442};\\\", \\\"{x:1222,y:825,t:1527268175458};\\\", \\\"{x:1222,y:824,t:1527268175475};\\\", \\\"{x:1222,y:822,t:1527268175491};\\\", \\\"{x:1223,y:821,t:1527268175508};\\\", \\\"{x:1224,y:819,t:1527268175525};\\\", \\\"{x:1224,y:817,t:1527268175541};\\\", \\\"{x:1224,y:816,t:1527268175562};\\\", \\\"{x:1224,y:815,t:1527268175575};\\\", \\\"{x:1224,y:814,t:1527268175591};\\\", \\\"{x:1225,y:812,t:1527268175610};\\\", \\\"{x:1226,y:812,t:1527268175643};\\\", \\\"{x:1226,y:811,t:1527268175658};\\\", \\\"{x:1227,y:809,t:1527268175674};\\\", \\\"{x:1227,y:807,t:1527268175692};\\\", \\\"{x:1230,y:804,t:1527268175708};\\\", \\\"{x:1230,y:802,t:1527268175725};\\\", \\\"{x:1232,y:799,t:1527268175741};\\\", \\\"{x:1233,y:797,t:1527268175758};\\\", \\\"{x:1235,y:795,t:1527268175775};\\\", \\\"{x:1238,y:791,t:1527268175791};\\\", \\\"{x:1240,y:787,t:1527268175807};\\\", \\\"{x:1241,y:786,t:1527268175825};\\\", \\\"{x:1242,y:785,t:1527268175842};\\\", \\\"{x:1243,y:784,t:1527268175858};\\\", \\\"{x:1244,y:784,t:1527268175875};\\\", \\\"{x:1246,y:781,t:1527268175892};\\\", \\\"{x:1247,y:780,t:1527268175908};\\\", \\\"{x:1248,y:778,t:1527268175925};\\\", \\\"{x:1250,y:776,t:1527268175942};\\\", \\\"{x:1251,y:775,t:1527268175971};\\\", \\\"{x:1252,y:774,t:1527268175986};\\\", \\\"{x:1253,y:773,t:1527268175994};\\\", \\\"{x:1254,y:772,t:1527268176026};\\\", \\\"{x:1255,y:771,t:1527268176058};\\\", \\\"{x:1256,y:770,t:1527268176075};\\\", \\\"{x:1257,y:770,t:1527268176099};\\\", \\\"{x:1259,y:768,t:1527268176130};\\\", \\\"{x:1260,y:767,t:1527268176146};\\\", \\\"{x:1262,y:766,t:1527268176162};\\\", \\\"{x:1263,y:765,t:1527268176179};\\\", \\\"{x:1263,y:764,t:1527268176192};\\\", \\\"{x:1264,y:763,t:1527268176208};\\\", \\\"{x:1267,y:760,t:1527268176225};\\\", \\\"{x:1270,y:756,t:1527268176242};\\\", \\\"{x:1275,y:751,t:1527268176258};\\\", \\\"{x:1277,y:747,t:1527268176275};\\\", \\\"{x:1278,y:746,t:1527268176292};\\\", \\\"{x:1281,y:742,t:1527268176309};\\\", \\\"{x:1282,y:739,t:1527268176325};\\\", \\\"{x:1284,y:735,t:1527268176342};\\\", \\\"{x:1285,y:734,t:1527268176359};\\\", \\\"{x:1287,y:731,t:1527268176374};\\\", \\\"{x:1288,y:729,t:1527268176392};\\\", \\\"{x:1288,y:727,t:1527268176409};\\\", \\\"{x:1290,y:726,t:1527268176425};\\\", \\\"{x:1290,y:725,t:1527268176459};\\\", \\\"{x:1291,y:724,t:1527268176476};\\\", \\\"{x:1291,y:723,t:1527268176492};\\\", \\\"{x:1293,y:721,t:1527268176509};\\\", \\\"{x:1293,y:719,t:1527268176525};\\\", \\\"{x:1294,y:716,t:1527268176542};\\\", \\\"{x:1295,y:715,t:1527268176562};\\\", \\\"{x:1295,y:714,t:1527268176575};\\\", \\\"{x:1297,y:712,t:1527268176592};\\\", \\\"{x:1297,y:711,t:1527268176609};\\\", \\\"{x:1298,y:709,t:1527268176625};\\\", \\\"{x:1300,y:706,t:1527268176642};\\\", \\\"{x:1301,y:703,t:1527268176658};\\\", \\\"{x:1304,y:697,t:1527268176675};\\\", \\\"{x:1307,y:691,t:1527268176692};\\\", \\\"{x:1308,y:686,t:1527268176709};\\\", \\\"{x:1309,y:683,t:1527268176726};\\\", \\\"{x:1312,y:677,t:1527268176742};\\\", \\\"{x:1313,y:670,t:1527268176759};\\\", \\\"{x:1316,y:659,t:1527268176776};\\\", \\\"{x:1320,y:646,t:1527268176792};\\\", \\\"{x:1323,y:636,t:1527268176809};\\\", \\\"{x:1327,y:629,t:1527268176826};\\\", \\\"{x:1327,y:623,t:1527268176842};\\\", \\\"{x:1332,y:610,t:1527268176859};\\\", \\\"{x:1334,y:606,t:1527268176876};\\\", \\\"{x:1335,y:601,t:1527268176893};\\\", \\\"{x:1338,y:593,t:1527268176909};\\\", \\\"{x:1338,y:587,t:1527268176926};\\\", \\\"{x:1340,y:582,t:1527268176943};\\\", \\\"{x:1340,y:580,t:1527268176959};\\\", \\\"{x:1341,y:578,t:1527268176976};\\\", \\\"{x:1342,y:576,t:1527268176992};\\\", \\\"{x:1342,y:573,t:1527268177009};\\\", \\\"{x:1343,y:569,t:1527268177026};\\\", \\\"{x:1343,y:567,t:1527268177042};\\\", \\\"{x:1343,y:564,t:1527268177059};\\\", \\\"{x:1343,y:563,t:1527268177077};\\\", \\\"{x:1343,y:562,t:1527268177093};\\\", \\\"{x:1343,y:561,t:1527268177123};\\\", \\\"{x:1343,y:560,t:1527268177131};\\\", \\\"{x:1343,y:559,t:1527268177155};\\\", \\\"{x:1345,y:558,t:1527268177178};\\\", \\\"{x:1345,y:557,t:1527268177355};\\\", \\\"{x:1345,y:556,t:1527268177372};\\\", \\\"{x:1345,y:555,t:1527268177404};\\\", \\\"{x:1345,y:554,t:1527268177435};\\\", \\\"{x:1345,y:552,t:1527268177634};\\\", \\\"{x:1348,y:551,t:1527268177643};\\\", \\\"{x:1353,y:547,t:1527268177660};\\\", \\\"{x:1359,y:543,t:1527268177676};\\\", \\\"{x:1364,y:539,t:1527268177693};\\\", \\\"{x:1369,y:535,t:1527268177709};\\\", \\\"{x:1375,y:529,t:1527268177726};\\\", \\\"{x:1379,y:524,t:1527268177743};\\\", \\\"{x:1383,y:515,t:1527268177759};\\\", \\\"{x:1384,y:507,t:1527268177776};\\\", \\\"{x:1386,y:502,t:1527268177793};\\\", \\\"{x:1388,y:484,t:1527268177810};\\\", \\\"{x:1391,y:462,t:1527268177825};\\\", \\\"{x:1393,y:446,t:1527268177843};\\\", \\\"{x:1394,y:444,t:1527268177860};\\\", \\\"{x:1396,y:440,t:1527268177875};\\\", \\\"{x:1397,y:437,t:1527268177893};\\\", \\\"{x:1397,y:436,t:1527268177910};\\\", \\\"{x:1399,y:431,t:1527268177926};\\\", \\\"{x:1399,y:429,t:1527268177943};\\\", \\\"{x:1400,y:426,t:1527268177960};\\\", \\\"{x:1400,y:423,t:1527268177976};\\\", \\\"{x:1401,y:419,t:1527268177993};\\\", \\\"{x:1403,y:413,t:1527268178010};\\\", \\\"{x:1404,y:409,t:1527268178026};\\\", \\\"{x:1405,y:407,t:1527268178043};\\\", \\\"{x:1406,y:403,t:1527268178060};\\\", \\\"{x:1408,y:400,t:1527268178077};\\\", \\\"{x:1410,y:397,t:1527268178093};\\\", \\\"{x:1412,y:394,t:1527268178110};\\\", \\\"{x:1415,y:388,t:1527268178127};\\\", \\\"{x:1420,y:381,t:1527268178143};\\\", \\\"{x:1424,y:378,t:1527268178160};\\\", \\\"{x:1428,y:373,t:1527268178177};\\\", \\\"{x:1432,y:367,t:1527268178193};\\\", \\\"{x:1436,y:362,t:1527268178210};\\\", \\\"{x:1438,y:359,t:1527268178227};\\\", \\\"{x:1439,y:356,t:1527268178243};\\\", \\\"{x:1439,y:355,t:1527268178260};\\\", \\\"{x:1440,y:353,t:1527268178277};\\\", \\\"{x:1440,y:352,t:1527268178293};\\\", \\\"{x:1441,y:350,t:1527268178311};\\\", \\\"{x:1441,y:348,t:1527268178327};\\\", \\\"{x:1442,y:346,t:1527268178343};\\\", \\\"{x:1442,y:344,t:1527268178360};\\\", \\\"{x:1442,y:342,t:1527268178377};\\\", \\\"{x:1444,y:339,t:1527268178393};\\\", \\\"{x:1445,y:338,t:1527268178410};\\\", \\\"{x:1448,y:335,t:1527268178428};\\\", \\\"{x:1452,y:333,t:1527268178445};\\\", \\\"{x:1454,y:331,t:1527268178461};\\\", \\\"{x:1458,y:328,t:1527268178477};\\\", \\\"{x:1462,y:325,t:1527268178494};\\\", \\\"{x:1464,y:325,t:1527268178510};\\\", \\\"{x:1466,y:324,t:1527268178527};\\\", \\\"{x:1467,y:323,t:1527268178544};\\\", \\\"{x:1468,y:323,t:1527268178620};\\\", \\\"{x:1471,y:324,t:1527268178643};\\\", \\\"{x:1478,y:333,t:1527268178661};\\\", \\\"{x:1484,y:341,t:1527268178678};\\\", \\\"{x:1494,y:354,t:1527268178694};\\\", \\\"{x:1499,y:362,t:1527268178710};\\\", \\\"{x:1507,y:372,t:1527268178728};\\\", \\\"{x:1511,y:377,t:1527268178745};\\\", \\\"{x:1514,y:383,t:1527268178760};\\\", \\\"{x:1520,y:391,t:1527268178777};\\\", \\\"{x:1525,y:400,t:1527268178794};\\\", \\\"{x:1534,y:416,t:1527268178810};\\\", \\\"{x:1542,y:431,t:1527268178827};\\\", \\\"{x:1550,y:445,t:1527268178844};\\\", \\\"{x:1556,y:461,t:1527268178860};\\\", \\\"{x:1563,y:479,t:1527268178877};\\\", \\\"{x:1573,y:501,t:1527268178894};\\\", \\\"{x:1582,y:520,t:1527268178911};\\\", \\\"{x:1591,y:542,t:1527268178927};\\\", \\\"{x:1600,y:563,t:1527268178944};\\\", \\\"{x:1607,y:580,t:1527268178961};\\\", \\\"{x:1616,y:599,t:1527268178977};\\\", \\\"{x:1628,y:625,t:1527268178994};\\\", \\\"{x:1638,y:641,t:1527268179011};\\\", \\\"{x:1645,y:655,t:1527268179027};\\\", \\\"{x:1655,y:672,t:1527268179044};\\\", \\\"{x:1666,y:689,t:1527268179061};\\\", \\\"{x:1676,y:705,t:1527268179077};\\\", \\\"{x:1689,y:721,t:1527268179095};\\\", \\\"{x:1702,y:740,t:1527268179111};\\\", \\\"{x:1712,y:757,t:1527268179127};\\\", \\\"{x:1721,y:770,t:1527268179144};\\\", \\\"{x:1732,y:788,t:1527268179161};\\\", \\\"{x:1747,y:804,t:1527268179177};\\\", \\\"{x:1754,y:817,t:1527268179194};\\\", \\\"{x:1767,y:834,t:1527268179210};\\\", \\\"{x:1772,y:842,t:1527268179227};\\\", \\\"{x:1777,y:853,t:1527268179244};\\\", \\\"{x:1781,y:864,t:1527268179261};\\\", \\\"{x:1785,y:873,t:1527268179278};\\\", \\\"{x:1790,y:885,t:1527268179294};\\\", \\\"{x:1795,y:897,t:1527268179311};\\\", \\\"{x:1800,y:907,t:1527268179328};\\\", \\\"{x:1803,y:919,t:1527268179344};\\\", \\\"{x:1810,y:934,t:1527268179361};\\\", \\\"{x:1814,y:942,t:1527268179378};\\\", \\\"{x:1816,y:948,t:1527268179394};\\\", \\\"{x:1821,y:958,t:1527268179411};\\\", \\\"{x:1824,y:965,t:1527268179429};\\\", \\\"{x:1826,y:970,t:1527268179445};\\\", \\\"{x:1827,y:973,t:1527268179461};\\\", \\\"{x:1828,y:974,t:1527268179478};\\\", \\\"{x:1829,y:976,t:1527268179494};\\\", \\\"{x:1829,y:977,t:1527268179511};\\\", \\\"{x:1829,y:979,t:1527268179528};\\\", \\\"{x:1830,y:980,t:1527268179544};\\\", \\\"{x:1831,y:982,t:1527268179561};\\\", \\\"{x:1832,y:983,t:1527268179578};\\\", \\\"{x:1832,y:982,t:1527268179714};\\\", \\\"{x:1832,y:976,t:1527268179728};\\\", \\\"{x:1826,y:963,t:1527268179745};\\\", \\\"{x:1818,y:947,t:1527268179761};\\\", \\\"{x:1807,y:920,t:1527268179778};\\\", \\\"{x:1797,y:900,t:1527268179794};\\\", \\\"{x:1789,y:880,t:1527268179811};\\\", \\\"{x:1778,y:857,t:1527268179828};\\\", \\\"{x:1766,y:834,t:1527268179845};\\\", \\\"{x:1750,y:808,t:1527268179861};\\\", \\\"{x:1727,y:778,t:1527268179878};\\\", \\\"{x:1711,y:763,t:1527268179895};\\\", \\\"{x:1699,y:751,t:1527268179912};\\\", \\\"{x:1693,y:745,t:1527268179928};\\\", \\\"{x:1687,y:741,t:1527268179945};\\\", \\\"{x:1684,y:738,t:1527268179961};\\\", \\\"{x:1681,y:733,t:1527268179978};\\\", \\\"{x:1678,y:729,t:1527268179994};\\\", \\\"{x:1674,y:723,t:1527268180011};\\\", \\\"{x:1669,y:715,t:1527268180028};\\\", \\\"{x:1659,y:703,t:1527268180045};\\\", \\\"{x:1649,y:692,t:1527268180061};\\\", \\\"{x:1643,y:684,t:1527268180078};\\\", \\\"{x:1634,y:674,t:1527268180095};\\\", \\\"{x:1628,y:666,t:1527268180111};\\\", \\\"{x:1622,y:655,t:1527268180129};\\\", \\\"{x:1618,y:645,t:1527268180145};\\\", \\\"{x:1611,y:635,t:1527268180161};\\\", \\\"{x:1605,y:624,t:1527268180178};\\\", \\\"{x:1596,y:607,t:1527268180194};\\\", \\\"{x:1590,y:596,t:1527268180212};\\\", \\\"{x:1586,y:590,t:1527268180229};\\\", \\\"{x:1585,y:585,t:1527268180246};\\\", \\\"{x:1580,y:576,t:1527268180262};\\\", \\\"{x:1575,y:566,t:1527268180278};\\\", \\\"{x:1570,y:559,t:1527268180295};\\\", \\\"{x:1568,y:555,t:1527268180312};\\\", \\\"{x:1567,y:554,t:1527268180328};\\\", \\\"{x:1567,y:553,t:1527268180345};\\\", \\\"{x:1566,y:550,t:1527268180363};\\\", \\\"{x:1565,y:550,t:1527268180378};\\\", \\\"{x:1565,y:549,t:1527268180402};\\\", \\\"{x:1565,y:548,t:1527268180412};\\\", \\\"{x:1564,y:547,t:1527268180428};\\\", \\\"{x:1565,y:548,t:1527268180650};\\\", \\\"{x:1566,y:549,t:1527268180674};\\\", \\\"{x:1566,y:550,t:1527268180716};\\\", \\\"{x:1568,y:551,t:1527268180754};\\\", \\\"{x:1571,y:551,t:1527268180770};\\\", \\\"{x:1572,y:553,t:1527268180778};\\\", \\\"{x:1576,y:555,t:1527268180796};\\\", \\\"{x:1580,y:557,t:1527268180812};\\\", \\\"{x:1582,y:558,t:1527268180829};\\\", \\\"{x:1584,y:561,t:1527268180845};\\\", \\\"{x:1585,y:561,t:1527268180862};\\\", \\\"{x:1587,y:562,t:1527268180880};\\\", \\\"{x:1587,y:563,t:1527268180940};\\\", \\\"{x:1588,y:563,t:1527268180963};\\\", \\\"{x:1590,y:564,t:1527268180979};\\\", \\\"{x:1590,y:565,t:1527268180996};\\\", \\\"{x:1591,y:566,t:1527268181012};\\\", \\\"{x:1592,y:566,t:1527268181035};\\\", \\\"{x:1593,y:567,t:1527268181083};\\\", \\\"{x:1595,y:568,t:1527268181115};\\\", \\\"{x:1596,y:569,t:1527268181139};\\\", \\\"{x:1597,y:569,t:1527268181155};\\\", \\\"{x:1598,y:569,t:1527268181179};\\\", \\\"{x:1599,y:570,t:1527268181197};\\\", \\\"{x:1601,y:571,t:1527268181244};\\\", \\\"{x:1602,y:571,t:1527268181276};\\\", \\\"{x:1604,y:571,t:1527268181291};\\\", \\\"{x:1605,y:572,t:1527268181307};\\\", \\\"{x:1606,y:573,t:1527268181331};\\\", \\\"{x:1607,y:573,t:1527268181346};\\\", \\\"{x:1608,y:574,t:1527268181418};\\\", \\\"{x:1608,y:576,t:1527268181434};\\\", \\\"{x:1608,y:578,t:1527268181450};\\\", \\\"{x:1608,y:580,t:1527268181462};\\\", \\\"{x:1608,y:582,t:1527268181479};\\\", \\\"{x:1608,y:584,t:1527268181496};\\\", \\\"{x:1609,y:588,t:1527268181514};\\\", \\\"{x:1609,y:591,t:1527268181529};\\\", \\\"{x:1610,y:597,t:1527268181546};\\\", \\\"{x:1611,y:600,t:1527268181562};\\\", \\\"{x:1612,y:605,t:1527268181579};\\\", \\\"{x:1613,y:609,t:1527268181596};\\\", \\\"{x:1615,y:613,t:1527268181613};\\\", \\\"{x:1617,y:616,t:1527268181629};\\\", \\\"{x:1617,y:619,t:1527268181646};\\\", \\\"{x:1617,y:620,t:1527268181663};\\\", \\\"{x:1618,y:622,t:1527268181679};\\\", \\\"{x:1619,y:624,t:1527268181696};\\\", \\\"{x:1620,y:626,t:1527268181714};\\\", \\\"{x:1622,y:630,t:1527268181729};\\\", \\\"{x:1624,y:636,t:1527268181746};\\\", \\\"{x:1627,y:642,t:1527268181763};\\\", \\\"{x:1631,y:647,t:1527268181779};\\\", \\\"{x:1633,y:652,t:1527268181796};\\\", \\\"{x:1635,y:656,t:1527268181813};\\\", \\\"{x:1636,y:658,t:1527268181829};\\\", \\\"{x:1638,y:663,t:1527268181846};\\\", \\\"{x:1641,y:668,t:1527268181863};\\\", \\\"{x:1643,y:672,t:1527268181879};\\\", \\\"{x:1646,y:676,t:1527268181896};\\\", \\\"{x:1651,y:683,t:1527268181913};\\\", \\\"{x:1658,y:690,t:1527268181929};\\\", \\\"{x:1667,y:700,t:1527268181946};\\\", \\\"{x:1671,y:702,t:1527268181963};\\\", \\\"{x:1672,y:702,t:1527268181979};\\\", \\\"{x:1677,y:706,t:1527268181996};\\\", \\\"{x:1683,y:711,t:1527268182013};\\\", \\\"{x:1686,y:714,t:1527268182030};\\\", \\\"{x:1688,y:715,t:1527268182051};\\\", \\\"{x:1688,y:716,t:1527268182066};\\\", \\\"{x:1689,y:717,t:1527268182082};\\\", \\\"{x:1690,y:718,t:1527268182096};\\\", \\\"{x:1691,y:719,t:1527268182114};\\\", \\\"{x:1691,y:720,t:1527268182131};\\\", \\\"{x:1691,y:721,t:1527268182147};\\\", \\\"{x:1691,y:723,t:1527268182163};\\\", \\\"{x:1692,y:725,t:1527268182181};\\\", \\\"{x:1693,y:726,t:1527268182197};\\\", \\\"{x:1693,y:730,t:1527268182213};\\\", \\\"{x:1693,y:735,t:1527268182231};\\\", \\\"{x:1693,y:737,t:1527268182247};\\\", \\\"{x:1694,y:743,t:1527268182264};\\\", \\\"{x:1695,y:746,t:1527268182281};\\\", \\\"{x:1695,y:750,t:1527268182296};\\\", \\\"{x:1695,y:754,t:1527268182313};\\\", \\\"{x:1695,y:761,t:1527268182331};\\\", \\\"{x:1697,y:766,t:1527268182347};\\\", \\\"{x:1697,y:774,t:1527268182363};\\\", \\\"{x:1699,y:780,t:1527268182380};\\\", \\\"{x:1701,y:785,t:1527268182397};\\\", \\\"{x:1701,y:791,t:1527268182413};\\\", \\\"{x:1701,y:796,t:1527268182431};\\\", \\\"{x:1702,y:799,t:1527268182448};\\\", \\\"{x:1703,y:803,t:1527268182464};\\\", \\\"{x:1703,y:806,t:1527268182481};\\\", \\\"{x:1705,y:811,t:1527268182498};\\\", \\\"{x:1706,y:815,t:1527268182514};\\\", \\\"{x:1708,y:823,t:1527268182531};\\\", \\\"{x:1709,y:827,t:1527268182546};\\\", \\\"{x:1710,y:832,t:1527268182563};\\\", \\\"{x:1712,y:836,t:1527268182581};\\\", \\\"{x:1714,y:841,t:1527268182597};\\\", \\\"{x:1714,y:845,t:1527268182613};\\\", \\\"{x:1716,y:849,t:1527268182630};\\\", \\\"{x:1717,y:853,t:1527268182648};\\\", \\\"{x:1717,y:854,t:1527268182663};\\\", \\\"{x:1717,y:856,t:1527268182681};\\\", \\\"{x:1718,y:858,t:1527268182697};\\\", \\\"{x:1718,y:859,t:1527268182732};\\\", \\\"{x:1716,y:855,t:1527268182868};\\\", \\\"{x:1714,y:853,t:1527268182881};\\\", \\\"{x:1702,y:841,t:1527268182898};\\\", \\\"{x:1669,y:815,t:1527268182915};\\\", \\\"{x:1637,y:790,t:1527268182930};\\\", \\\"{x:1595,y:763,t:1527268182948};\\\", \\\"{x:1543,y:733,t:1527268182964};\\\", \\\"{x:1484,y:703,t:1527268182980};\\\", \\\"{x:1415,y:674,t:1527268182998};\\\", \\\"{x:1363,y:651,t:1527268183015};\\\", \\\"{x:1322,y:635,t:1527268183031};\\\", \\\"{x:1283,y:620,t:1527268183047};\\\", \\\"{x:1244,y:602,t:1527268183064};\\\", \\\"{x:1217,y:593,t:1527268183081};\\\", \\\"{x:1199,y:588,t:1527268183098};\\\", \\\"{x:1190,y:588,t:1527268183115};\\\", \\\"{x:1187,y:588,t:1527268183131};\\\", \\\"{x:1185,y:589,t:1527268183148};\\\", \\\"{x:1184,y:589,t:1527268183165};\\\", \\\"{x:1182,y:589,t:1527268183180};\\\", \\\"{x:1181,y:589,t:1527268183203};\\\", \\\"{x:1180,y:590,t:1527268183219};\\\", \\\"{x:1179,y:590,t:1527268183243};\\\", \\\"{x:1178,y:590,t:1527268183251};\\\", \\\"{x:1176,y:592,t:1527268183265};\\\", \\\"{x:1172,y:593,t:1527268183281};\\\", \\\"{x:1166,y:596,t:1527268183297};\\\", \\\"{x:1156,y:600,t:1527268183315};\\\", \\\"{x:1152,y:602,t:1527268183332};\\\", \\\"{x:1148,y:602,t:1527268183347};\\\", \\\"{x:1143,y:604,t:1527268183364};\\\", \\\"{x:1134,y:605,t:1527268183382};\\\", \\\"{x:1123,y:606,t:1527268183398};\\\", \\\"{x:1099,y:609,t:1527268183414};\\\", \\\"{x:1066,y:609,t:1527268183431};\\\", \\\"{x:1035,y:609,t:1527268183447};\\\", \\\"{x:998,y:600,t:1527268183464};\\\", \\\"{x:948,y:586,t:1527268183482};\\\", \\\"{x:891,y:566,t:1527268183498};\\\", \\\"{x:776,y:529,t:1527268183514};\\\", \\\"{x:565,y:447,t:1527268183548};\\\", \\\"{x:451,y:410,t:1527268183564};\\\", \\\"{x:340,y:377,t:1527268183581};\\\", \\\"{x:249,y:350,t:1527268183598};\\\", \\\"{x:163,y:327,t:1527268183614};\\\", \\\"{x:96,y:306,t:1527268183631};\\\", \\\"{x:49,y:295,t:1527268183648};\\\", \\\"{x:26,y:290,t:1527268183664};\\\", \\\"{x:17,y:289,t:1527268183681};\\\", \\\"{x:15,y:289,t:1527268183698};\\\", \\\"{x:14,y:289,t:1527268183826};\\\", \\\"{x:14,y:291,t:1527268183833};\\\", \\\"{x:14,y:294,t:1527268183848};\\\", \\\"{x:16,y:302,t:1527268183864};\\\", \\\"{x:19,y:307,t:1527268183881};\\\", \\\"{x:23,y:318,t:1527268183898};\\\", \\\"{x:26,y:324,t:1527268183915};\\\", \\\"{x:29,y:330,t:1527268183931};\\\", \\\"{x:32,y:335,t:1527268183948};\\\", \\\"{x:37,y:344,t:1527268183965};\\\", \\\"{x:48,y:356,t:1527268183981};\\\", \\\"{x:60,y:370,t:1527268183998};\\\", \\\"{x:72,y:383,t:1527268184015};\\\", \\\"{x:98,y:404,t:1527268184031};\\\", \\\"{x:140,y:430,t:1527268184048};\\\", \\\"{x:183,y:454,t:1527268184065};\\\", \\\"{x:229,y:480,t:1527268184081};\\\", \\\"{x:266,y:502,t:1527268184098};\\\", \\\"{x:277,y:508,t:1527268184116};\\\", \\\"{x:284,y:513,t:1527268184131};\\\", \\\"{x:285,y:513,t:1527268184147};\\\", \\\"{x:287,y:514,t:1527268184164};\\\", \\\"{x:289,y:516,t:1527268184181};\\\", \\\"{x:291,y:517,t:1527268184197};\\\", \\\"{x:293,y:519,t:1527268184214};\\\", \\\"{x:296,y:520,t:1527268184231};\\\", \\\"{x:302,y:522,t:1527268184248};\\\", \\\"{x:313,y:524,t:1527268184264};\\\", \\\"{x:331,y:532,t:1527268184281};\\\", \\\"{x:351,y:539,t:1527268184297};\\\", \\\"{x:403,y:557,t:1527268184315};\\\", \\\"{x:436,y:566,t:1527268184331};\\\", \\\"{x:468,y:574,t:1527268184348};\\\", \\\"{x:488,y:577,t:1527268184366};\\\", \\\"{x:498,y:578,t:1527268184382};\\\", \\\"{x:499,y:578,t:1527268184398};\\\", \\\"{x:498,y:572,t:1527268184443};\\\", \\\"{x:492,y:566,t:1527268184449};\\\", \\\"{x:486,y:562,t:1527268184465};\\\", \\\"{x:449,y:554,t:1527268184482};\\\", \\\"{x:412,y:549,t:1527268184498};\\\", \\\"{x:370,y:543,t:1527268184515};\\\", \\\"{x:334,y:538,t:1527268184532};\\\", \\\"{x:307,y:538,t:1527268184548};\\\", \\\"{x:285,y:539,t:1527268184565};\\\", \\\"{x:266,y:550,t:1527268184583};\\\", \\\"{x:260,y:560,t:1527268184598};\\\", \\\"{x:258,y:567,t:1527268184615};\\\", \\\"{x:257,y:573,t:1527268184632};\\\", \\\"{x:257,y:577,t:1527268184649};\\\", \\\"{x:257,y:579,t:1527268184664};\\\", \\\"{x:256,y:585,t:1527268184682};\\\", \\\"{x:254,y:591,t:1527268184698};\\\", \\\"{x:249,y:596,t:1527268184715};\\\", \\\"{x:245,y:599,t:1527268184732};\\\", \\\"{x:240,y:602,t:1527268184748};\\\", \\\"{x:234,y:604,t:1527268184765};\\\", \\\"{x:228,y:606,t:1527268184782};\\\", \\\"{x:224,y:607,t:1527268184798};\\\", \\\"{x:218,y:609,t:1527268184816};\\\", \\\"{x:212,y:612,t:1527268184832};\\\", \\\"{x:206,y:617,t:1527268184849};\\\", \\\"{x:203,y:627,t:1527268184865};\\\", \\\"{x:203,y:650,t:1527268184882};\\\", \\\"{x:203,y:662,t:1527268184900};\\\", \\\"{x:206,y:672,t:1527268184916};\\\", \\\"{x:206,y:674,t:1527268184932};\\\", \\\"{x:206,y:675,t:1527268184978};\\\", \\\"{x:205,y:676,t:1527268184994};\\\", \\\"{x:203,y:677,t:1527268185002};\\\", \\\"{x:200,y:677,t:1527268185015};\\\", \\\"{x:192,y:677,t:1527268185032};\\\", \\\"{x:182,y:677,t:1527268185048};\\\", \\\"{x:177,y:677,t:1527268185065};\\\", \\\"{x:170,y:674,t:1527268185082};\\\", \\\"{x:168,y:673,t:1527268185098};\\\", \\\"{x:166,y:672,t:1527268185116};\\\", \\\"{x:165,y:671,t:1527268185155};\\\", \\\"{x:165,y:670,t:1527268185178};\\\", \\\"{x:165,y:668,t:1527268185187};\\\", \\\"{x:165,y:667,t:1527268185198};\\\", \\\"{x:165,y:663,t:1527268185215};\\\", \\\"{x:165,y:657,t:1527268185232};\\\", \\\"{x:165,y:654,t:1527268185249};\\\", \\\"{x:167,y:650,t:1527268185266};\\\", \\\"{x:167,y:647,t:1527268185282};\\\", \\\"{x:170,y:642,t:1527268185300};\\\", \\\"{x:171,y:641,t:1527268185330};\\\", \\\"{x:173,y:641,t:1527268185578};\\\", \\\"{x:179,y:641,t:1527268185586};\\\", \\\"{x:189,y:641,t:1527268185599};\\\", \\\"{x:219,y:650,t:1527268185616};\\\", \\\"{x:254,y:661,t:1527268185633};\\\", \\\"{x:307,y:676,t:1527268185649};\\\", \\\"{x:393,y:701,t:1527268185666};\\\", \\\"{x:432,y:712,t:1527268185683};\\\", \\\"{x:457,y:718,t:1527268185700};\\\", \\\"{x:474,y:720,t:1527268185718};\\\", \\\"{x:483,y:720,t:1527268185733};\\\", \\\"{x:487,y:720,t:1527268185749};\\\", \\\"{x:488,y:720,t:1527268185766};\\\", \\\"{x:492,y:721,t:1527268185835};\\\", \\\"{x:492,y:722,t:1527268185849};\\\", \\\"{x:499,y:726,t:1527268185867};\\\", \\\"{x:502,y:727,t:1527268185883};\\\", \\\"{x:507,y:728,t:1527268185899};\\\", \\\"{x:508,y:728,t:1527268185917};\\\", \\\"{x:509,y:728,t:1527268186922};\\\", \\\"{x:513,y:728,t:1527268186934};\\\", \\\"{x:517,y:724,t:1527268186950};\\\", \\\"{x:520,y:720,t:1527268186967};\\\", \\\"{x:523,y:716,t:1527268186984};\\\", \\\"{x:525,y:714,t:1527268187000};\\\", \\\"{x:525,y:711,t:1527268187017};\\\", \\\"{x:526,y:710,t:1527268187034};\\\" ] }, { \\\"rt\\\": 73858, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 286266, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -A -J -05 PM-05 PM-04 PM-04 PM-E -E -D -E -04 PM-11-1-2-5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:709,t:1527268188722};\\\", \\\"{x:528,y:709,t:1527268188734};\\\", \\\"{x:531,y:708,t:1527268188768};\\\", \\\"{x:532,y:707,t:1527268188784};\\\", \\\"{x:533,y:707,t:1527268188858};\\\", \\\"{x:534,y:707,t:1527268188898};\\\", \\\"{x:534,y:706,t:1527268188906};\\\", \\\"{x:536,y:705,t:1527268188930};\\\", \\\"{x:537,y:704,t:1527268188938};\\\", \\\"{x:538,y:704,t:1527268188954};\\\", \\\"{x:539,y:704,t:1527268188978};\\\", \\\"{x:544,y:700,t:1527268189128};\\\", \\\"{x:546,y:700,t:1527268189138};\\\", \\\"{x:547,y:700,t:1527268189154};\\\", \\\"{x:547,y:699,t:1527268189169};\\\", \\\"{x:548,y:699,t:1527268189185};\\\", \\\"{x:549,y:698,t:1527268189202};\\\", \\\"{x:552,y:697,t:1527268189219};\\\", \\\"{x:557,y:695,t:1527268189235};\\\", \\\"{x:567,y:694,t:1527268189252};\\\", \\\"{x:581,y:693,t:1527268189269};\\\", \\\"{x:608,y:692,t:1527268189285};\\\", \\\"{x:643,y:686,t:1527268189303};\\\", \\\"{x:672,y:682,t:1527268189319};\\\", \\\"{x:701,y:681,t:1527268189335};\\\", \\\"{x:728,y:680,t:1527268189352};\\\", \\\"{x:750,y:675,t:1527268189369};\\\", \\\"{x:772,y:672,t:1527268189385};\\\", \\\"{x:807,y:669,t:1527268189402};\\\", \\\"{x:830,y:669,t:1527268189420};\\\", \\\"{x:850,y:667,t:1527268189436};\\\", \\\"{x:871,y:665,t:1527268189452};\\\", \\\"{x:890,y:665,t:1527268189469};\\\", \\\"{x:906,y:663,t:1527268189486};\\\", \\\"{x:915,y:661,t:1527268189502};\\\", \\\"{x:924,y:661,t:1527268189519};\\\", \\\"{x:934,y:661,t:1527268189536};\\\", \\\"{x:943,y:659,t:1527268189553};\\\", \\\"{x:958,y:657,t:1527268189569};\\\", \\\"{x:984,y:657,t:1527268189586};\\\", \\\"{x:1001,y:657,t:1527268189602};\\\", \\\"{x:1013,y:657,t:1527268189620};\\\", \\\"{x:1028,y:657,t:1527268189636};\\\", \\\"{x:1039,y:655,t:1527268189652};\\\", \\\"{x:1048,y:652,t:1527268189670};\\\", \\\"{x:1054,y:651,t:1527268189687};\\\", \\\"{x:1058,y:650,t:1527268189703};\\\", \\\"{x:1060,y:649,t:1527268189719};\\\", \\\"{x:1063,y:648,t:1527268189737};\\\", \\\"{x:1070,y:646,t:1527268189753};\\\", \\\"{x:1075,y:644,t:1527268189769};\\\", \\\"{x:1088,y:642,t:1527268189786};\\\", \\\"{x:1102,y:638,t:1527268189803};\\\", \\\"{x:1116,y:635,t:1527268189820};\\\", \\\"{x:1132,y:633,t:1527268189836};\\\", \\\"{x:1149,y:628,t:1527268189853};\\\", \\\"{x:1164,y:624,t:1527268189870};\\\", \\\"{x:1177,y:623,t:1527268189887};\\\", \\\"{x:1188,y:623,t:1527268189904};\\\", \\\"{x:1199,y:620,t:1527268189920};\\\", \\\"{x:1207,y:619,t:1527268189936};\\\", \\\"{x:1215,y:619,t:1527268189954};\\\", \\\"{x:1224,y:619,t:1527268189970};\\\", \\\"{x:1237,y:620,t:1527268189987};\\\", \\\"{x:1248,y:622,t:1527268190004};\\\", \\\"{x:1249,y:622,t:1527268190020};\\\", \\\"{x:1251,y:624,t:1527268190652};\\\", \\\"{x:1253,y:625,t:1527268190667};\\\", \\\"{x:1254,y:625,t:1527268190675};\\\", \\\"{x:1255,y:627,t:1527268190688};\\\", \\\"{x:1258,y:627,t:1527268190704};\\\", \\\"{x:1260,y:629,t:1527268190721};\\\", \\\"{x:1261,y:629,t:1527268190739};\\\", \\\"{x:1264,y:629,t:1527268190754};\\\", \\\"{x:1266,y:631,t:1527268190771};\\\", \\\"{x:1272,y:631,t:1527268190788};\\\", \\\"{x:1279,y:631,t:1527268190804};\\\", \\\"{x:1290,y:634,t:1527268190821};\\\", \\\"{x:1305,y:636,t:1527268190838};\\\", \\\"{x:1324,y:641,t:1527268190854};\\\", \\\"{x:1345,y:646,t:1527268190871};\\\", \\\"{x:1371,y:653,t:1527268190888};\\\", \\\"{x:1394,y:659,t:1527268190904};\\\", \\\"{x:1424,y:667,t:1527268190921};\\\", \\\"{x:1448,y:676,t:1527268190937};\\\", \\\"{x:1469,y:683,t:1527268190953};\\\", \\\"{x:1494,y:695,t:1527268190971};\\\", \\\"{x:1504,y:699,t:1527268190987};\\\", \\\"{x:1506,y:699,t:1527268191004};\\\", \\\"{x:1506,y:700,t:1527268192403};\\\", \\\"{x:1506,y:702,t:1527268192410};\\\", \\\"{x:1507,y:702,t:1527268192422};\\\", \\\"{x:1516,y:706,t:1527268192438};\\\", \\\"{x:1532,y:712,t:1527268192455};\\\", \\\"{x:1540,y:715,t:1527268192473};\\\", \\\"{x:1541,y:716,t:1527268192489};\\\", \\\"{x:1541,y:717,t:1527268192570};\\\", \\\"{x:1542,y:719,t:1527268192594};\\\", \\\"{x:1543,y:719,t:1527268192605};\\\", \\\"{x:1549,y:723,t:1527268192622};\\\", \\\"{x:1558,y:732,t:1527268192638};\\\", \\\"{x:1568,y:743,t:1527268192655};\\\", \\\"{x:1578,y:757,t:1527268192673};\\\", \\\"{x:1588,y:771,t:1527268192689};\\\", \\\"{x:1595,y:782,t:1527268192706};\\\", \\\"{x:1603,y:799,t:1527268192722};\\\", \\\"{x:1605,y:807,t:1527268192739};\\\", \\\"{x:1605,y:815,t:1527268192755};\\\", \\\"{x:1602,y:821,t:1527268192773};\\\", \\\"{x:1596,y:827,t:1527268192788};\\\", \\\"{x:1589,y:831,t:1527268192806};\\\", \\\"{x:1582,y:835,t:1527268192822};\\\", \\\"{x:1571,y:843,t:1527268192840};\\\", \\\"{x:1558,y:853,t:1527268192856};\\\", \\\"{x:1545,y:862,t:1527268192873};\\\", \\\"{x:1529,y:869,t:1527268192890};\\\", \\\"{x:1518,y:874,t:1527268192906};\\\", \\\"{x:1510,y:876,t:1527268192922};\\\", \\\"{x:1506,y:876,t:1527268192939};\\\", \\\"{x:1503,y:876,t:1527268192955};\\\", \\\"{x:1497,y:876,t:1527268192973};\\\", \\\"{x:1488,y:877,t:1527268192990};\\\", \\\"{x:1479,y:878,t:1527268193005};\\\", \\\"{x:1467,y:881,t:1527268193022};\\\", \\\"{x:1458,y:882,t:1527268193040};\\\", \\\"{x:1446,y:884,t:1527268193055};\\\", \\\"{x:1434,y:888,t:1527268193072};\\\", \\\"{x:1428,y:889,t:1527268193089};\\\", \\\"{x:1416,y:892,t:1527268193106};\\\", \\\"{x:1394,y:895,t:1527268193122};\\\", \\\"{x:1387,y:895,t:1527268193140};\\\", \\\"{x:1381,y:899,t:1527268193155};\\\", \\\"{x:1378,y:901,t:1527268193172};\\\", \\\"{x:1377,y:901,t:1527268193266};\\\", \\\"{x:1374,y:901,t:1527268193274};\\\", \\\"{x:1370,y:901,t:1527268193289};\\\", \\\"{x:1356,y:899,t:1527268193306};\\\", \\\"{x:1343,y:898,t:1527268193324};\\\", \\\"{x:1336,y:895,t:1527268193340};\\\", \\\"{x:1331,y:895,t:1527268193357};\\\", \\\"{x:1328,y:893,t:1527268193373};\\\", \\\"{x:1326,y:893,t:1527268193390};\\\", \\\"{x:1324,y:893,t:1527268193406};\\\", \\\"{x:1322,y:892,t:1527268193423};\\\", \\\"{x:1319,y:891,t:1527268193440};\\\", \\\"{x:1315,y:888,t:1527268193457};\\\", \\\"{x:1313,y:887,t:1527268193473};\\\", \\\"{x:1309,y:884,t:1527268193490};\\\", \\\"{x:1302,y:879,t:1527268193506};\\\", \\\"{x:1293,y:872,t:1527268193523};\\\", \\\"{x:1288,y:870,t:1527268193540};\\\", \\\"{x:1284,y:867,t:1527268193557};\\\", \\\"{x:1280,y:863,t:1527268193573};\\\", \\\"{x:1277,y:861,t:1527268193590};\\\", \\\"{x:1277,y:859,t:1527268193610};\\\", \\\"{x:1277,y:855,t:1527268193624};\\\", \\\"{x:1283,y:835,t:1527268193640};\\\", \\\"{x:1293,y:810,t:1527268193657};\\\", \\\"{x:1305,y:782,t:1527268193673};\\\", \\\"{x:1317,y:755,t:1527268193689};\\\", \\\"{x:1341,y:703,t:1527268193707};\\\", \\\"{x:1358,y:662,t:1527268193724};\\\", \\\"{x:1378,y:615,t:1527268193739};\\\", \\\"{x:1389,y:561,t:1527268193757};\\\", \\\"{x:1400,y:480,t:1527268193773};\\\", \\\"{x:1412,y:418,t:1527268193790};\\\", \\\"{x:1415,y:396,t:1527268193807};\\\", \\\"{x:1420,y:387,t:1527268193823};\\\", \\\"{x:1421,y:385,t:1527268193840};\\\", \\\"{x:1421,y:386,t:1527268193914};\\\", \\\"{x:1428,y:401,t:1527268193924};\\\", \\\"{x:1451,y:451,t:1527268193939};\\\", \\\"{x:1480,y:507,t:1527268193957};\\\", \\\"{x:1512,y:562,t:1527268193974};\\\", \\\"{x:1546,y:612,t:1527268193990};\\\", \\\"{x:1581,y:663,t:1527268194007};\\\", \\\"{x:1625,y:724,t:1527268194023};\\\", \\\"{x:1656,y:781,t:1527268194040};\\\", \\\"{x:1672,y:822,t:1527268194057};\\\", \\\"{x:1680,y:852,t:1527268194073};\\\", \\\"{x:1690,y:886,t:1527268194089};\\\", \\\"{x:1692,y:907,t:1527268194107};\\\", \\\"{x:1695,y:924,t:1527268194124};\\\", \\\"{x:1695,y:938,t:1527268194140};\\\", \\\"{x:1695,y:943,t:1527268194157};\\\", \\\"{x:1694,y:948,t:1527268194174};\\\", \\\"{x:1693,y:954,t:1527268194191};\\\", \\\"{x:1693,y:957,t:1527268194206};\\\", \\\"{x:1690,y:961,t:1527268194223};\\\", \\\"{x:1687,y:966,t:1527268194241};\\\", \\\"{x:1686,y:971,t:1527268194257};\\\", \\\"{x:1683,y:977,t:1527268194274};\\\", \\\"{x:1682,y:980,t:1527268194290};\\\", \\\"{x:1680,y:984,t:1527268194307};\\\", \\\"{x:1678,y:986,t:1527268194324};\\\", \\\"{x:1678,y:990,t:1527268194340};\\\", \\\"{x:1676,y:993,t:1527268194356};\\\", \\\"{x:1675,y:997,t:1527268194373};\\\", \\\"{x:1674,y:1000,t:1527268194390};\\\", \\\"{x:1673,y:1003,t:1527268194408};\\\", \\\"{x:1673,y:1004,t:1527268194426};\\\", \\\"{x:1673,y:1001,t:1527268194603};\\\", \\\"{x:1673,y:1000,t:1527268194611};\\\", \\\"{x:1673,y:998,t:1527268194624};\\\", \\\"{x:1674,y:994,t:1527268194641};\\\", \\\"{x:1675,y:993,t:1527268194658};\\\", \\\"{x:1675,y:991,t:1527268194674};\\\", \\\"{x:1675,y:990,t:1527268194691};\\\", \\\"{x:1675,y:988,t:1527268194754};\\\", \\\"{x:1673,y:987,t:1527268194770};\\\", \\\"{x:1672,y:986,t:1527268194786};\\\", \\\"{x:1671,y:986,t:1527268194794};\\\", \\\"{x:1670,y:986,t:1527268194807};\\\", \\\"{x:1667,y:986,t:1527268194824};\\\", \\\"{x:1663,y:983,t:1527268194841};\\\", \\\"{x:1657,y:982,t:1527268194858};\\\", \\\"{x:1632,y:981,t:1527268194874};\\\", \\\"{x:1617,y:978,t:1527268194890};\\\", \\\"{x:1604,y:977,t:1527268194908};\\\", \\\"{x:1599,y:976,t:1527268194924};\\\", \\\"{x:1598,y:975,t:1527268195010};\\\", \\\"{x:1598,y:972,t:1527268195025};\\\", \\\"{x:1598,y:968,t:1527268195040};\\\", \\\"{x:1598,y:962,t:1527268195058};\\\", \\\"{x:1598,y:955,t:1527268195074};\\\", \\\"{x:1599,y:954,t:1527268195091};\\\", \\\"{x:1600,y:953,t:1527268195107};\\\", \\\"{x:1601,y:951,t:1527268195130};\\\", \\\"{x:1602,y:951,t:1527268195146};\\\", \\\"{x:1603,y:950,t:1527268195162};\\\", \\\"{x:1605,y:950,t:1527268195174};\\\", \\\"{x:1612,y:950,t:1527268195192};\\\", \\\"{x:1623,y:951,t:1527268195208};\\\", \\\"{x:1630,y:954,t:1527268195224};\\\", \\\"{x:1636,y:956,t:1527268195241};\\\", \\\"{x:1639,y:956,t:1527268195258};\\\", \\\"{x:1641,y:958,t:1527268195275};\\\", \\\"{x:1644,y:959,t:1527268195292};\\\", \\\"{x:1645,y:961,t:1527268195610};\\\", \\\"{x:1645,y:964,t:1527268195625};\\\", \\\"{x:1645,y:965,t:1527268195642};\\\", \\\"{x:1645,y:967,t:1527268195659};\\\", \\\"{x:1645,y:968,t:1527268195674};\\\", \\\"{x:1645,y:969,t:1527268195810};\\\", \\\"{x:1644,y:969,t:1527268195825};\\\", \\\"{x:1642,y:969,t:1527268195842};\\\", \\\"{x:1639,y:969,t:1527268195858};\\\", \\\"{x:1638,y:969,t:1527268195881};\\\", \\\"{x:1636,y:969,t:1527268195892};\\\", \\\"{x:1635,y:969,t:1527268195909};\\\", \\\"{x:1633,y:969,t:1527268195930};\\\", \\\"{x:1632,y:968,t:1527268195946};\\\", \\\"{x:1631,y:967,t:1527268195958};\\\", \\\"{x:1629,y:965,t:1527268195976};\\\", \\\"{x:1628,y:963,t:1527268195992};\\\", \\\"{x:1628,y:961,t:1527268196009};\\\", \\\"{x:1627,y:959,t:1527268196025};\\\", \\\"{x:1626,y:958,t:1527268196042};\\\", \\\"{x:1625,y:952,t:1527268196059};\\\", \\\"{x:1622,y:946,t:1527268196076};\\\", \\\"{x:1620,y:941,t:1527268196091};\\\", \\\"{x:1617,y:935,t:1527268196109};\\\", \\\"{x:1614,y:932,t:1527268196126};\\\", \\\"{x:1611,y:927,t:1527268196142};\\\", \\\"{x:1609,y:924,t:1527268196159};\\\", \\\"{x:1607,y:922,t:1527268196176};\\\", \\\"{x:1606,y:920,t:1527268196192};\\\", \\\"{x:1605,y:918,t:1527268196209};\\\", \\\"{x:1604,y:916,t:1527268196226};\\\", \\\"{x:1603,y:915,t:1527268196242};\\\", \\\"{x:1603,y:913,t:1527268196259};\\\", \\\"{x:1602,y:913,t:1527268196276};\\\", \\\"{x:1602,y:912,t:1527268196292};\\\", \\\"{x:1602,y:911,t:1527268196331};\\\", \\\"{x:1602,y:909,t:1527268196355};\\\", \\\"{x:1602,y:907,t:1527268196371};\\\", \\\"{x:1602,y:905,t:1527268196378};\\\", \\\"{x:1603,y:902,t:1527268196395};\\\", \\\"{x:1603,y:901,t:1527268196409};\\\", \\\"{x:1605,y:897,t:1527268196426};\\\", \\\"{x:1607,y:889,t:1527268196442};\\\", \\\"{x:1608,y:884,t:1527268196459};\\\", \\\"{x:1609,y:879,t:1527268196476};\\\", \\\"{x:1609,y:876,t:1527268196493};\\\", \\\"{x:1610,y:873,t:1527268196509};\\\", \\\"{x:1610,y:872,t:1527268196526};\\\", \\\"{x:1611,y:866,t:1527268196543};\\\", \\\"{x:1611,y:863,t:1527268196558};\\\", \\\"{x:1611,y:858,t:1527268196576};\\\", \\\"{x:1612,y:854,t:1527268196593};\\\", \\\"{x:1613,y:849,t:1527268196609};\\\", \\\"{x:1613,y:846,t:1527268196626};\\\", \\\"{x:1613,y:843,t:1527268196642};\\\", \\\"{x:1614,y:842,t:1527268196660};\\\", \\\"{x:1614,y:840,t:1527268196676};\\\", \\\"{x:1614,y:839,t:1527268196721};\\\", \\\"{x:1614,y:838,t:1527268196746};\\\", \\\"{x:1614,y:837,t:1527268196786};\\\", \\\"{x:1614,y:836,t:1527268196834};\\\", \\\"{x:1614,y:835,t:1527268196843};\\\", \\\"{x:1614,y:834,t:1527268196860};\\\", \\\"{x:1614,y:832,t:1527268196876};\\\", \\\"{x:1614,y:828,t:1527268196893};\\\", \\\"{x:1614,y:827,t:1527268196910};\\\", \\\"{x:1614,y:825,t:1527268196925};\\\", \\\"{x:1614,y:822,t:1527268196942};\\\", \\\"{x:1613,y:818,t:1527268196960};\\\", \\\"{x:1611,y:815,t:1527268196976};\\\", \\\"{x:1611,y:812,t:1527268196992};\\\", \\\"{x:1611,y:808,t:1527268197010};\\\", \\\"{x:1611,y:805,t:1527268197026};\\\", \\\"{x:1610,y:801,t:1527268197043};\\\", \\\"{x:1610,y:799,t:1527268197060};\\\", \\\"{x:1609,y:797,t:1527268197075};\\\", \\\"{x:1609,y:795,t:1527268197092};\\\", \\\"{x:1608,y:791,t:1527268197109};\\\", \\\"{x:1608,y:789,t:1527268197126};\\\", \\\"{x:1608,y:788,t:1527268197143};\\\", \\\"{x:1608,y:786,t:1527268197160};\\\", \\\"{x:1608,y:785,t:1527268197177};\\\", \\\"{x:1608,y:783,t:1527268197193};\\\", \\\"{x:1608,y:781,t:1527268197210};\\\", \\\"{x:1608,y:779,t:1527268197227};\\\", \\\"{x:1608,y:776,t:1527268197243};\\\", \\\"{x:1608,y:774,t:1527268197260};\\\", \\\"{x:1608,y:772,t:1527268197277};\\\", \\\"{x:1608,y:770,t:1527268197293};\\\", \\\"{x:1608,y:769,t:1527268197310};\\\", \\\"{x:1608,y:767,t:1527268197327};\\\", \\\"{x:1608,y:766,t:1527268197343};\\\", \\\"{x:1608,y:763,t:1527268197360};\\\", \\\"{x:1607,y:759,t:1527268197377};\\\", \\\"{x:1605,y:751,t:1527268197393};\\\", \\\"{x:1605,y:746,t:1527268197410};\\\", \\\"{x:1604,y:743,t:1527268197427};\\\", \\\"{x:1604,y:740,t:1527268197444};\\\", \\\"{x:1603,y:738,t:1527268197459};\\\", \\\"{x:1603,y:736,t:1527268197477};\\\", \\\"{x:1603,y:733,t:1527268197494};\\\", \\\"{x:1603,y:731,t:1527268197510};\\\", \\\"{x:1603,y:728,t:1527268197527};\\\", \\\"{x:1603,y:726,t:1527268197544};\\\", \\\"{x:1603,y:724,t:1527268197560};\\\", \\\"{x:1603,y:723,t:1527268197578};\\\", \\\"{x:1603,y:722,t:1527268197594};\\\", \\\"{x:1603,y:721,t:1527268197610};\\\", \\\"{x:1603,y:720,t:1527268197642};\\\", \\\"{x:1603,y:719,t:1527268197651};\\\", \\\"{x:1603,y:718,t:1527268197660};\\\", \\\"{x:1603,y:717,t:1527268197683};\\\", \\\"{x:1603,y:716,t:1527268197707};\\\", \\\"{x:1603,y:715,t:1527268197714};\\\", \\\"{x:1603,y:714,t:1527268197738};\\\", \\\"{x:1603,y:713,t:1527268197754};\\\", \\\"{x:1603,y:712,t:1527268197762};\\\", \\\"{x:1603,y:710,t:1527268197778};\\\", \\\"{x:1603,y:708,t:1527268197794};\\\", \\\"{x:1603,y:706,t:1527268197811};\\\", \\\"{x:1603,y:705,t:1527268197827};\\\", \\\"{x:1604,y:701,t:1527268197843};\\\", \\\"{x:1604,y:698,t:1527268197861};\\\", \\\"{x:1604,y:696,t:1527268197877};\\\", \\\"{x:1605,y:693,t:1527268197894};\\\", \\\"{x:1605,y:689,t:1527268197911};\\\", \\\"{x:1606,y:685,t:1527268197927};\\\", \\\"{x:1606,y:682,t:1527268197944};\\\", \\\"{x:1607,y:679,t:1527268197960};\\\", \\\"{x:1607,y:676,t:1527268197977};\\\", \\\"{x:1607,y:671,t:1527268197994};\\\", \\\"{x:1607,y:667,t:1527268198010};\\\", \\\"{x:1608,y:665,t:1527268198026};\\\", \\\"{x:1608,y:664,t:1527268198058};\\\", \\\"{x:1608,y:662,t:1527268198098};\\\", \\\"{x:1608,y:661,t:1527268198130};\\\", \\\"{x:1608,y:659,t:1527268198146};\\\", \\\"{x:1608,y:658,t:1527268198162};\\\", \\\"{x:1608,y:656,t:1527268198185};\\\", \\\"{x:1608,y:655,t:1527268198194};\\\", \\\"{x:1608,y:653,t:1527268198210};\\\", \\\"{x:1608,y:652,t:1527268198227};\\\", \\\"{x:1608,y:649,t:1527268198244};\\\", \\\"{x:1608,y:646,t:1527268198261};\\\", \\\"{x:1608,y:644,t:1527268198278};\\\", \\\"{x:1608,y:643,t:1527268198293};\\\", \\\"{x:1608,y:642,t:1527268198314};\\\", \\\"{x:1608,y:641,t:1527268198330};\\\", \\\"{x:1608,y:640,t:1527268198344};\\\", \\\"{x:1608,y:636,t:1527268198361};\\\", \\\"{x:1608,y:633,t:1527268198378};\\\", \\\"{x:1608,y:630,t:1527268198394};\\\", \\\"{x:1608,y:628,t:1527268198411};\\\", \\\"{x:1608,y:626,t:1527268198428};\\\", \\\"{x:1610,y:622,t:1527268198444};\\\", \\\"{x:1610,y:621,t:1527268198461};\\\", \\\"{x:1610,y:618,t:1527268198478};\\\", \\\"{x:1611,y:614,t:1527268198494};\\\", \\\"{x:1611,y:611,t:1527268198511};\\\", \\\"{x:1611,y:609,t:1527268198527};\\\", \\\"{x:1611,y:607,t:1527268198544};\\\", \\\"{x:1611,y:605,t:1527268198561};\\\", \\\"{x:1611,y:602,t:1527268198578};\\\", \\\"{x:1611,y:600,t:1527268198594};\\\", \\\"{x:1611,y:599,t:1527268198611};\\\", \\\"{x:1611,y:597,t:1527268198628};\\\", \\\"{x:1611,y:593,t:1527268198645};\\\", \\\"{x:1611,y:590,t:1527268198661};\\\", \\\"{x:1611,y:586,t:1527268198678};\\\", \\\"{x:1611,y:583,t:1527268198695};\\\", \\\"{x:1611,y:580,t:1527268198711};\\\", \\\"{x:1611,y:577,t:1527268198728};\\\", \\\"{x:1611,y:572,t:1527268198745};\\\", \\\"{x:1611,y:566,t:1527268198761};\\\", \\\"{x:1611,y:560,t:1527268198778};\\\", \\\"{x:1611,y:556,t:1527268198794};\\\", \\\"{x:1611,y:553,t:1527268198810};\\\", \\\"{x:1611,y:551,t:1527268198828};\\\", \\\"{x:1611,y:548,t:1527268198844};\\\", \\\"{x:1611,y:545,t:1527268198861};\\\", \\\"{x:1611,y:542,t:1527268198878};\\\", \\\"{x:1611,y:539,t:1527268198895};\\\", \\\"{x:1611,y:538,t:1527268198912};\\\", \\\"{x:1611,y:536,t:1527268198928};\\\", \\\"{x:1611,y:535,t:1527268198945};\\\", \\\"{x:1611,y:533,t:1527268198962};\\\", \\\"{x:1611,y:532,t:1527268198978};\\\", \\\"{x:1611,y:530,t:1527268198995};\\\", \\\"{x:1611,y:529,t:1527268199017};\\\", \\\"{x:1611,y:527,t:1527268199042};\\\", \\\"{x:1610,y:526,t:1527268199050};\\\", \\\"{x:1610,y:525,t:1527268199082};\\\", \\\"{x:1610,y:524,t:1527268199095};\\\", \\\"{x:1610,y:523,t:1527268199112};\\\", \\\"{x:1609,y:520,t:1527268199127};\\\", \\\"{x:1609,y:517,t:1527268199145};\\\", \\\"{x:1609,y:513,t:1527268199162};\\\", \\\"{x:1609,y:511,t:1527268199178};\\\", \\\"{x:1609,y:509,t:1527268199194};\\\", \\\"{x:1608,y:509,t:1527268199211};\\\", \\\"{x:1608,y:507,t:1527268199228};\\\", \\\"{x:1608,y:506,t:1527268199245};\\\", \\\"{x:1607,y:504,t:1527268199262};\\\", \\\"{x:1606,y:502,t:1527268199278};\\\", \\\"{x:1604,y:501,t:1527268199295};\\\", \\\"{x:1604,y:498,t:1527268199312};\\\", \\\"{x:1603,y:495,t:1527268199329};\\\", \\\"{x:1603,y:493,t:1527268199345};\\\", \\\"{x:1602,y:489,t:1527268199362};\\\", \\\"{x:1602,y:488,t:1527268199379};\\\", \\\"{x:1601,y:486,t:1527268199395};\\\", \\\"{x:1601,y:485,t:1527268199412};\\\", \\\"{x:1601,y:483,t:1527268199429};\\\", \\\"{x:1601,y:482,t:1527268199445};\\\", \\\"{x:1601,y:481,t:1527268199462};\\\", \\\"{x:1600,y:478,t:1527268199479};\\\", \\\"{x:1600,y:476,t:1527268199495};\\\", \\\"{x:1600,y:475,t:1527268199512};\\\", \\\"{x:1600,y:472,t:1527268199529};\\\", \\\"{x:1600,y:470,t:1527268199810};\\\", \\\"{x:1600,y:469,t:1527268199818};\\\", \\\"{x:1601,y:467,t:1527268199828};\\\", \\\"{x:1603,y:465,t:1527268199846};\\\", \\\"{x:1605,y:463,t:1527268199862};\\\", \\\"{x:1607,y:461,t:1527268199879};\\\", \\\"{x:1610,y:460,t:1527268199896};\\\", \\\"{x:1612,y:458,t:1527268199912};\\\", \\\"{x:1613,y:457,t:1527268199929};\\\", \\\"{x:1615,y:456,t:1527268199945};\\\", \\\"{x:1617,y:455,t:1527268199962};\\\", \\\"{x:1618,y:454,t:1527268199978};\\\", \\\"{x:1619,y:454,t:1527268200018};\\\", \\\"{x:1620,y:453,t:1527268200059};\\\", \\\"{x:1620,y:452,t:1527268200156};\\\", \\\"{x:1620,y:451,t:1527268200227};\\\", \\\"{x:1620,y:450,t:1527268200259};\\\", \\\"{x:1620,y:449,t:1527268200379};\\\", \\\"{x:1619,y:448,t:1527268200397};\\\", \\\"{x:1619,y:447,t:1527268200419};\\\", \\\"{x:1618,y:447,t:1527268200443};\\\", \\\"{x:1617,y:447,t:1527268200451};\\\", \\\"{x:1617,y:446,t:1527268200483};\\\", \\\"{x:1616,y:446,t:1527268200495};\\\", \\\"{x:1616,y:445,t:1527268200513};\\\", \\\"{x:1615,y:445,t:1527268200530};\\\", \\\"{x:1614,y:444,t:1527268200546};\\\", \\\"{x:1613,y:444,t:1527268200594};\\\", \\\"{x:1613,y:443,t:1527268200659};\\\", \\\"{x:1614,y:443,t:1527268204827};\\\", \\\"{x:1615,y:443,t:1527268204859};\\\", \\\"{x:1616,y:443,t:1527268204923};\\\", \\\"{x:1617,y:442,t:1527268204955};\\\", \\\"{x:1617,y:441,t:1527268204979};\\\", \\\"{x:1618,y:441,t:1527268205019};\\\", \\\"{x:1618,y:440,t:1527268205043};\\\", \\\"{x:1620,y:440,t:1527268205067};\\\", \\\"{x:1620,y:439,t:1527268205086};\\\", \\\"{x:1621,y:438,t:1527268205107};\\\", \\\"{x:1621,y:437,t:1527268205123};\\\", \\\"{x:1621,y:436,t:1527268205139};\\\", \\\"{x:1621,y:435,t:1527268205151};\\\", \\\"{x:1623,y:434,t:1527268205168};\\\", \\\"{x:1623,y:433,t:1527268205267};\\\", \\\"{x:1623,y:432,t:1527268205417};\\\", \\\"{x:1623,y:431,t:1527268205473};\\\", \\\"{x:1622,y:431,t:1527268205522};\\\", \\\"{x:1621,y:431,t:1527268205553};\\\", \\\"{x:1620,y:431,t:1527268205610};\\\", \\\"{x:1620,y:430,t:1527268205634};\\\", \\\"{x:1619,y:429,t:1527268205707};\\\", \\\"{x:1618,y:429,t:1527268205722};\\\", \\\"{x:1617,y:429,t:1527268205762};\\\", \\\"{x:1614,y:430,t:1527268210298};\\\", \\\"{x:1613,y:432,t:1527268210313};\\\", \\\"{x:1611,y:433,t:1527268210322};\\\", \\\"{x:1608,y:436,t:1527268210339};\\\", \\\"{x:1607,y:439,t:1527268210355};\\\", \\\"{x:1606,y:441,t:1527268210372};\\\", \\\"{x:1603,y:447,t:1527268210388};\\\", \\\"{x:1602,y:452,t:1527268210405};\\\", \\\"{x:1602,y:464,t:1527268210422};\\\", \\\"{x:1602,y:479,t:1527268210438};\\\", \\\"{x:1606,y:497,t:1527268210456};\\\", \\\"{x:1618,y:524,t:1527268210472};\\\", \\\"{x:1631,y:554,t:1527268210488};\\\", \\\"{x:1655,y:599,t:1527268210506};\\\", \\\"{x:1665,y:620,t:1527268210522};\\\", \\\"{x:1672,y:629,t:1527268210538};\\\", \\\"{x:1675,y:636,t:1527268210555};\\\", \\\"{x:1676,y:637,t:1527268210572};\\\", \\\"{x:1676,y:638,t:1527268210588};\\\", \\\"{x:1676,y:635,t:1527268210682};\\\", \\\"{x:1676,y:632,t:1527268210690};\\\", \\\"{x:1676,y:629,t:1527268210705};\\\", \\\"{x:1670,y:614,t:1527268210722};\\\", \\\"{x:1665,y:608,t:1527268210738};\\\", \\\"{x:1658,y:601,t:1527268210755};\\\", \\\"{x:1651,y:596,t:1527268210773};\\\", \\\"{x:1648,y:594,t:1527268210789};\\\", \\\"{x:1646,y:593,t:1527268210806};\\\", \\\"{x:1645,y:593,t:1527268210858};\\\", \\\"{x:1644,y:592,t:1527268210873};\\\", \\\"{x:1641,y:591,t:1527268210890};\\\", \\\"{x:1639,y:590,t:1527268210906};\\\", \\\"{x:1636,y:589,t:1527268210922};\\\", \\\"{x:1633,y:588,t:1527268210939};\\\", \\\"{x:1632,y:588,t:1527268210956};\\\", \\\"{x:1629,y:586,t:1527268210973};\\\", \\\"{x:1626,y:586,t:1527268210990};\\\", \\\"{x:1623,y:583,t:1527268211006};\\\", \\\"{x:1618,y:580,t:1527268211023};\\\", \\\"{x:1616,y:579,t:1527268211039};\\\", \\\"{x:1613,y:577,t:1527268211055};\\\", \\\"{x:1611,y:576,t:1527268211072};\\\", \\\"{x:1610,y:575,t:1527268211090};\\\", \\\"{x:1610,y:574,t:1527268211105};\\\", \\\"{x:1608,y:573,t:1527268211123};\\\", \\\"{x:1607,y:572,t:1527268211147};\\\", \\\"{x:1607,y:571,t:1527268211163};\\\", \\\"{x:1606,y:571,t:1527268211173};\\\", \\\"{x:1606,y:570,t:1527268211314};\\\", \\\"{x:1606,y:569,t:1527268211322};\\\", \\\"{x:1607,y:569,t:1527268211339};\\\", \\\"{x:1608,y:569,t:1527268211401};\\\", \\\"{x:1610,y:569,t:1527268211433};\\\", \\\"{x:1611,y:569,t:1527268211441};\\\", \\\"{x:1612,y:569,t:1527268211456};\\\", \\\"{x:1613,y:569,t:1527268211473};\\\", \\\"{x:1614,y:569,t:1527268211498};\\\", \\\"{x:1615,y:568,t:1527268211810};\\\", \\\"{x:1615,y:567,t:1527268212770};\\\", \\\"{x:1615,y:565,t:1527268212793};\\\", \\\"{x:1615,y:564,t:1527268212818};\\\", \\\"{x:1614,y:564,t:1527268212825};\\\", \\\"{x:1610,y:567,t:1527268221413};\\\", \\\"{x:1605,y:575,t:1527268221422};\\\", \\\"{x:1602,y:581,t:1527268221435};\\\", \\\"{x:1597,y:593,t:1527268221452};\\\", \\\"{x:1597,y:607,t:1527268221468};\\\", \\\"{x:1597,y:618,t:1527268221485};\\\", \\\"{x:1597,y:630,t:1527268221502};\\\", \\\"{x:1599,y:646,t:1527268221519};\\\", \\\"{x:1601,y:664,t:1527268221535};\\\", \\\"{x:1607,y:689,t:1527268221552};\\\", \\\"{x:1613,y:714,t:1527268221569};\\\", \\\"{x:1617,y:745,t:1527268221585};\\\", \\\"{x:1619,y:773,t:1527268221602};\\\", \\\"{x:1619,y:800,t:1527268221619};\\\", \\\"{x:1616,y:823,t:1527268221635};\\\", \\\"{x:1615,y:840,t:1527268221652};\\\", \\\"{x:1612,y:866,t:1527268221669};\\\", \\\"{x:1612,y:881,t:1527268221685};\\\", \\\"{x:1611,y:895,t:1527268221702};\\\", \\\"{x:1610,y:908,t:1527268221719};\\\", \\\"{x:1609,y:914,t:1527268221736};\\\", \\\"{x:1606,y:922,t:1527268221752};\\\", \\\"{x:1603,y:929,t:1527268221769};\\\", \\\"{x:1599,y:935,t:1527268221786};\\\", \\\"{x:1595,y:941,t:1527268221802};\\\", \\\"{x:1593,y:946,t:1527268221819};\\\", \\\"{x:1591,y:951,t:1527268221836};\\\", \\\"{x:1588,y:962,t:1527268221852};\\\", \\\"{x:1586,y:973,t:1527268221868};\\\", \\\"{x:1586,y:979,t:1527268221885};\\\", \\\"{x:1586,y:984,t:1527268221902};\\\", \\\"{x:1587,y:989,t:1527268221919};\\\", \\\"{x:1590,y:992,t:1527268221936};\\\", \\\"{x:1594,y:995,t:1527268221951};\\\", \\\"{x:1595,y:996,t:1527268221969};\\\", \\\"{x:1597,y:997,t:1527268221986};\\\", \\\"{x:1599,y:998,t:1527268222002};\\\", \\\"{x:1601,y:999,t:1527268222019};\\\", \\\"{x:1604,y:999,t:1527268222036};\\\", \\\"{x:1606,y:999,t:1527268222051};\\\", \\\"{x:1607,y:999,t:1527268222077};\\\", \\\"{x:1607,y:998,t:1527268222093};\\\", \\\"{x:1607,y:995,t:1527268222102};\\\", \\\"{x:1607,y:991,t:1527268222119};\\\", \\\"{x:1607,y:985,t:1527268222136};\\\", \\\"{x:1607,y:980,t:1527268222153};\\\", \\\"{x:1607,y:976,t:1527268222169};\\\", \\\"{x:1607,y:972,t:1527268222186};\\\", \\\"{x:1605,y:969,t:1527268222203};\\\", \\\"{x:1605,y:967,t:1527268222219};\\\", \\\"{x:1603,y:966,t:1527268222236};\\\", \\\"{x:1603,y:964,t:1527268222253};\\\", \\\"{x:1602,y:962,t:1527268222269};\\\", \\\"{x:1602,y:961,t:1527268222286};\\\", \\\"{x:1601,y:960,t:1527268222303};\\\", \\\"{x:1601,y:958,t:1527268222319};\\\", \\\"{x:1601,y:957,t:1527268222336};\\\", \\\"{x:1600,y:957,t:1527268222353};\\\", \\\"{x:1600,y:954,t:1527268222369};\\\", \\\"{x:1600,y:953,t:1527268222386};\\\", \\\"{x:1600,y:950,t:1527268222404};\\\", \\\"{x:1600,y:947,t:1527268222420};\\\", \\\"{x:1600,y:943,t:1527268222437};\\\", \\\"{x:1600,y:937,t:1527268222454};\\\", \\\"{x:1600,y:932,t:1527268222469};\\\", \\\"{x:1601,y:927,t:1527268222486};\\\", \\\"{x:1602,y:921,t:1527268222504};\\\", \\\"{x:1604,y:917,t:1527268222521};\\\", \\\"{x:1605,y:914,t:1527268222537};\\\", \\\"{x:1605,y:911,t:1527268222553};\\\", \\\"{x:1605,y:910,t:1527268222570};\\\", \\\"{x:1605,y:908,t:1527268222587};\\\", \\\"{x:1607,y:906,t:1527268222604};\\\", \\\"{x:1607,y:905,t:1527268222620};\\\", \\\"{x:1608,y:903,t:1527268222636};\\\", \\\"{x:1610,y:899,t:1527268222653};\\\", \\\"{x:1610,y:897,t:1527268222670};\\\", \\\"{x:1611,y:895,t:1527268222686};\\\", \\\"{x:1611,y:893,t:1527268222703};\\\", \\\"{x:1611,y:892,t:1527268222720};\\\", \\\"{x:1611,y:891,t:1527268222773};\\\", \\\"{x:1611,y:890,t:1527268222813};\\\", \\\"{x:1611,y:889,t:1527268222853};\\\", \\\"{x:1611,y:888,t:1527268222885};\\\", \\\"{x:1611,y:887,t:1527268222901};\\\", \\\"{x:1611,y:886,t:1527268222908};\\\", \\\"{x:1611,y:885,t:1527268222933};\\\", \\\"{x:1611,y:884,t:1527268222948};\\\", \\\"{x:1611,y:883,t:1527268222980};\\\", \\\"{x:1611,y:882,t:1527268223061};\\\", \\\"{x:1611,y:880,t:1527268223173};\\\", \\\"{x:1611,y:879,t:1527268223253};\\\", \\\"{x:1611,y:878,t:1527268223277};\\\", \\\"{x:1611,y:877,t:1527268223287};\\\", \\\"{x:1611,y:876,t:1527268223317};\\\", \\\"{x:1610,y:874,t:1527268223605};\\\", \\\"{x:1610,y:873,t:1527268223668};\\\", \\\"{x:1610,y:872,t:1527268223733};\\\", \\\"{x:1603,y:872,t:1527268226589};\\\", \\\"{x:1590,y:872,t:1527268226597};\\\", \\\"{x:1571,y:872,t:1527268226606};\\\", \\\"{x:1532,y:872,t:1527268226623};\\\", \\\"{x:1453,y:866,t:1527268226641};\\\", \\\"{x:1343,y:841,t:1527268226657};\\\", \\\"{x:1227,y:812,t:1527268226673};\\\", \\\"{x:1123,y:786,t:1527268226690};\\\", \\\"{x:1013,y:760,t:1527268226706};\\\", \\\"{x:913,y:730,t:1527268226724};\\\", \\\"{x:829,y:703,t:1527268226740};\\\", \\\"{x:720,y:639,t:1527268226758};\\\", \\\"{x:650,y:592,t:1527268226774};\\\", \\\"{x:597,y:556,t:1527268226791};\\\", \\\"{x:548,y:520,t:1527268226818};\\\", \\\"{x:524,y:501,t:1527268226834};\\\", \\\"{x:501,y:479,t:1527268226852};\\\", \\\"{x:484,y:457,t:1527268226869};\\\", \\\"{x:482,y:454,t:1527268226886};\\\", \\\"{x:483,y:453,t:1527268226965};\\\", \\\"{x:485,y:452,t:1527268226972};\\\", \\\"{x:485,y:451,t:1527268226985};\\\", \\\"{x:486,y:451,t:1527268227002};\\\", \\\"{x:488,y:449,t:1527268227019};\\\", \\\"{x:493,y:444,t:1527268227035};\\\", \\\"{x:500,y:438,t:1527268227052};\\\", \\\"{x:514,y:428,t:1527268227068};\\\", \\\"{x:526,y:420,t:1527268227085};\\\", \\\"{x:541,y:413,t:1527268227102};\\\", \\\"{x:554,y:405,t:1527268227119};\\\", \\\"{x:562,y:401,t:1527268227135};\\\", \\\"{x:570,y:398,t:1527268227152};\\\", \\\"{x:577,y:396,t:1527268227169};\\\", \\\"{x:581,y:396,t:1527268227185};\\\", \\\"{x:586,y:395,t:1527268227202};\\\", \\\"{x:593,y:395,t:1527268227218};\\\", \\\"{x:602,y:395,t:1527268227235};\\\", \\\"{x:611,y:395,t:1527268227252};\\\", \\\"{x:626,y:395,t:1527268227268};\\\", \\\"{x:652,y:395,t:1527268227284};\\\", \\\"{x:674,y:395,t:1527268227302};\\\", \\\"{x:687,y:395,t:1527268227318};\\\", \\\"{x:690,y:395,t:1527268227335};\\\", \\\"{x:691,y:395,t:1527268227351};\\\", \\\"{x:694,y:395,t:1527268227369};\\\", \\\"{x:695,y:395,t:1527268227385};\\\", \\\"{x:696,y:395,t:1527268227401};\\\", \\\"{x:698,y:394,t:1527268227418};\\\", \\\"{x:699,y:394,t:1527268227436};\\\", \\\"{x:703,y:394,t:1527268227451};\\\", \\\"{x:705,y:392,t:1527268227469};\\\", \\\"{x:710,y:392,t:1527268227485};\\\", \\\"{x:715,y:389,t:1527268227501};\\\", \\\"{x:720,y:387,t:1527268227519};\\\", \\\"{x:727,y:384,t:1527268227535};\\\", \\\"{x:737,y:379,t:1527268227551};\\\", \\\"{x:746,y:375,t:1527268227568};\\\", \\\"{x:756,y:371,t:1527268227584};\\\", \\\"{x:761,y:369,t:1527268227601};\\\", \\\"{x:765,y:367,t:1527268227618};\\\", \\\"{x:768,y:366,t:1527268227634};\\\", \\\"{x:769,y:366,t:1527268227651};\\\", \\\"{x:772,y:364,t:1527268227668};\\\", \\\"{x:773,y:364,t:1527268227684};\\\", \\\"{x:778,y:361,t:1527268227700};\\\", \\\"{x:780,y:361,t:1527268227718};\\\", \\\"{x:781,y:360,t:1527268227734};\\\", \\\"{x:783,y:360,t:1527268227751};\\\", \\\"{x:785,y:359,t:1527268227767};\\\", \\\"{x:789,y:357,t:1527268227784};\\\", \\\"{x:792,y:356,t:1527268227801};\\\", \\\"{x:797,y:354,t:1527268227817};\\\", \\\"{x:806,y:349,t:1527268227834};\\\", \\\"{x:815,y:345,t:1527268227852};\\\", \\\"{x:830,y:341,t:1527268227867};\\\", \\\"{x:844,y:337,t:1527268227884};\\\", \\\"{x:864,y:336,t:1527268227901};\\\", \\\"{x:879,y:336,t:1527268227917};\\\", \\\"{x:889,y:336,t:1527268227935};\\\", \\\"{x:902,y:336,t:1527268227951};\\\", \\\"{x:913,y:336,t:1527268227967};\\\", \\\"{x:929,y:334,t:1527268227984};\\\", \\\"{x:943,y:334,t:1527268228001};\\\", \\\"{x:955,y:333,t:1527268228018};\\\", \\\"{x:965,y:331,t:1527268228034};\\\", \\\"{x:974,y:330,t:1527268228050};\\\", \\\"{x:988,y:328,t:1527268228068};\\\", \\\"{x:1001,y:324,t:1527268228085};\\\", \\\"{x:1010,y:323,t:1527268228101};\\\", \\\"{x:1027,y:317,t:1527268228117};\\\", \\\"{x:1032,y:314,t:1527268228134};\\\", \\\"{x:1035,y:313,t:1527268228150};\\\", \\\"{x:1037,y:312,t:1527268228167};\\\", \\\"{x:1038,y:312,t:1527268228206};\\\", \\\"{x:1039,y:312,t:1527268228253};\\\", \\\"{x:1041,y:312,t:1527268228267};\\\", \\\"{x:1044,y:312,t:1527268228283};\\\", \\\"{x:1050,y:312,t:1527268228300};\\\", \\\"{x:1056,y:313,t:1527268228316};\\\", \\\"{x:1063,y:316,t:1527268228333};\\\", \\\"{x:1065,y:317,t:1527268228351};\\\", \\\"{x:1067,y:319,t:1527268228366};\\\", \\\"{x:1068,y:319,t:1527268228384};\\\", \\\"{x:1072,y:321,t:1527268228400};\\\", \\\"{x:1075,y:323,t:1527268228416};\\\", \\\"{x:1077,y:324,t:1527268228433};\\\", \\\"{x:1078,y:324,t:1527268228451};\\\", \\\"{x:1079,y:325,t:1527268228467};\\\", \\\"{x:1080,y:326,t:1527268228508};\\\", \\\"{x:1081,y:326,t:1527268228596};\\\", \\\"{x:1081,y:322,t:1527268228604};\\\", \\\"{x:1081,y:317,t:1527268228616};\\\", \\\"{x:1080,y:305,t:1527268228634};\\\", \\\"{x:1078,y:292,t:1527268228649};\\\", \\\"{x:1074,y:283,t:1527268228666};\\\", \\\"{x:1069,y:273,t:1527268228683};\\\", \\\"{x:1065,y:264,t:1527268228700};\\\", \\\"{x:1060,y:255,t:1527268228716};\\\", \\\"{x:1057,y:250,t:1527268228732};\\\", \\\"{x:1056,y:245,t:1527268228749};\\\", \\\"{x:1054,y:241,t:1527268228766};\\\", \\\"{x:1054,y:239,t:1527268228783};\\\", \\\"{x:1054,y:236,t:1527268228799};\\\", \\\"{x:1054,y:235,t:1527268228821};\\\", \\\"{x:1054,y:234,t:1527268228837};\\\", \\\"{x:1054,y:236,t:1527268228974};\\\", \\\"{x:1054,y:239,t:1527268228983};\\\", \\\"{x:1054,y:244,t:1527268228999};\\\", \\\"{x:1053,y:248,t:1527268229015};\\\", \\\"{x:1052,y:253,t:1527268229033};\\\", \\\"{x:1050,y:259,t:1527268229049};\\\", \\\"{x:1048,y:265,t:1527268229065};\\\", \\\"{x:1046,y:271,t:1527268229082};\\\", \\\"{x:1046,y:276,t:1527268229098};\\\", \\\"{x:1044,y:282,t:1527268229116};\\\", \\\"{x:1043,y:287,t:1527268229132};\\\", \\\"{x:1042,y:293,t:1527268229148};\\\", \\\"{x:1042,y:301,t:1527268229166};\\\", \\\"{x:1042,y:306,t:1527268229183};\\\", \\\"{x:1042,y:313,t:1527268229198};\\\", \\\"{x:1043,y:319,t:1527268229215};\\\", \\\"{x:1045,y:324,t:1527268229232};\\\", \\\"{x:1047,y:326,t:1527268229248};\\\", \\\"{x:1048,y:329,t:1527268229265};\\\", \\\"{x:1050,y:333,t:1527268229282};\\\", \\\"{x:1052,y:337,t:1527268229298};\\\", \\\"{x:1054,y:340,t:1527268229315};\\\", \\\"{x:1056,y:342,t:1527268229331};\\\", \\\"{x:1057,y:344,t:1527268229348};\\\", \\\"{x:1060,y:346,t:1527268229365};\\\", \\\"{x:1062,y:347,t:1527268229389};\\\", \\\"{x:1064,y:348,t:1527268229398};\\\", \\\"{x:1065,y:349,t:1527268229416};\\\", \\\"{x:1066,y:349,t:1527268229431};\\\", \\\"{x:1068,y:350,t:1527268229448};\\\", \\\"{x:1070,y:350,t:1527268229465};\\\", \\\"{x:1072,y:351,t:1527268229481};\\\", \\\"{x:1074,y:352,t:1527268229498};\\\", \\\"{x:1075,y:354,t:1527268229514};\\\", \\\"{x:1077,y:355,t:1527268229531};\\\", \\\"{x:1080,y:357,t:1527268229548};\\\", \\\"{x:1081,y:359,t:1527268229564};\\\", \\\"{x:1082,y:360,t:1527268229581};\\\", \\\"{x:1083,y:362,t:1527268229599};\\\", \\\"{x:1083,y:363,t:1527268229621};\\\", \\\"{x:1083,y:364,t:1527268229632};\\\", \\\"{x:1083,y:365,t:1527268229649};\\\", \\\"{x:1083,y:366,t:1527268230006};\\\", \\\"{x:1083,y:368,t:1527268230015};\\\", \\\"{x:1082,y:370,t:1527268230031};\\\", \\\"{x:1081,y:371,t:1527268230053};\\\", \\\"{x:1080,y:372,t:1527268235348};\\\", \\\"{x:1079,y:372,t:1527268235381};\\\", \\\"{x:1078,y:372,t:1527268235389};\\\", \\\"{x:1078,y:373,t:1527268235405};\\\", \\\"{x:1077,y:373,t:1527268235421};\\\", \\\"{x:1076,y:373,t:1527268235461};\\\", \\\"{x:1076,y:374,t:1527268235476};\\\", \\\"{x:1074,y:374,t:1527268235541};\\\", \\\"{x:1073,y:374,t:1527268235580};\\\", \\\"{x:1072,y:375,t:1527268235588};\\\", \\\"{x:1072,y:376,t:1527268235613};\\\", \\\"{x:1071,y:377,t:1527268236381};\\\", \\\"{x:1067,y:377,t:1527268236388};\\\", \\\"{x:1055,y:382,t:1527268236404};\\\", \\\"{x:1035,y:395,t:1527268236419};\\\", \\\"{x:1017,y:404,t:1527268236436};\\\", \\\"{x:1009,y:407,t:1527268236453};\\\", \\\"{x:1004,y:410,t:1527268236469};\\\", \\\"{x:1001,y:413,t:1527268236486};\\\", \\\"{x:995,y:417,t:1527268236504};\\\", \\\"{x:991,y:422,t:1527268236520};\\\", \\\"{x:985,y:430,t:1527268236536};\\\", \\\"{x:973,y:443,t:1527268236553};\\\", \\\"{x:948,y:459,t:1527268236569};\\\", \\\"{x:911,y:501,t:1527268236587};\\\", \\\"{x:875,y:556,t:1527268236603};\\\", \\\"{x:844,y:611,t:1527268236620};\\\", \\\"{x:803,y:682,t:1527268236637};\\\", \\\"{x:787,y:697,t:1527268236660};\\\", \\\"{x:774,y:712,t:1527268236676};\\\", \\\"{x:770,y:720,t:1527268236694};\\\", \\\"{x:768,y:723,t:1527268236709};\\\", \\\"{x:768,y:727,t:1527268236727};\\\", \\\"{x:768,y:729,t:1527268236743};\\\", \\\"{x:768,y:734,t:1527268236759};\\\", \\\"{x:768,y:739,t:1527268236777};\\\", \\\"{x:768,y:743,t:1527268236794};\\\", \\\"{x:768,y:747,t:1527268236809};\\\", \\\"{x:768,y:750,t:1527268236827};\\\", \\\"{x:768,y:751,t:1527268236845};\\\", \\\"{x:768,y:752,t:1527268236860};\\\", \\\"{x:766,y:756,t:1527268236877};\\\", \\\"{x:765,y:757,t:1527268236894};\\\", \\\"{x:762,y:759,t:1527268236909};\\\", \\\"{x:760,y:760,t:1527268236927};\\\", \\\"{x:759,y:761,t:1527268236944};\\\", \\\"{x:757,y:762,t:1527268236959};\\\", \\\"{x:755,y:762,t:1527268236977};\\\", \\\"{x:754,y:763,t:1527268236994};\\\", \\\"{x:754,y:764,t:1527268237325};\\\", \\\"{x:754,y:768,t:1527268237334};\\\", \\\"{x:756,y:777,t:1527268237344};\\\", \\\"{x:779,y:817,t:1527268237361};\\\", \\\"{x:819,y:868,t:1527268237377};\\\", \\\"{x:864,y:920,t:1527268237395};\\\", \\\"{x:912,y:973,t:1527268237411};\\\", \\\"{x:978,y:1032,t:1527268237428};\\\", \\\"{x:1045,y:1080,t:1527268237444};\\\", \\\"{x:1104,y:1130,t:1527268237461};\\\", \\\"{x:1132,y:1145,t:1527268237478};\\\", \\\"{x:1143,y:1150,t:1527268237493};\\\", \\\"{x:1140,y:1150,t:1527268237540};\\\", \\\"{x:1132,y:1144,t:1527268237548};\\\", \\\"{x:1127,y:1137,t:1527268237561};\\\", \\\"{x:1119,y:1125,t:1527268237578};\\\", \\\"{x:1108,y:1110,t:1527268237594};\\\", \\\"{x:1103,y:1097,t:1527268237610};\\\", \\\"{x:1100,y:1087,t:1527268237628};\\\", \\\"{x:1096,y:1074,t:1527268237644};\\\", \\\"{x:1091,y:1052,t:1527268237661};\\\", \\\"{x:1085,y:1035,t:1527268237678};\\\", \\\"{x:1077,y:1013,t:1527268237694};\\\", \\\"{x:1068,y:991,t:1527268237711};\\\", \\\"{x:1058,y:971,t:1527268237727};\\\", \\\"{x:1050,y:957,t:1527268237745};\\\", \\\"{x:1048,y:950,t:1527268237761};\\\", \\\"{x:1045,y:945,t:1527268237778};\\\", \\\"{x:1043,y:942,t:1527268237794};\\\", \\\"{x:1041,y:938,t:1527268237811};\\\", \\\"{x:1040,y:936,t:1527268237828};\\\", \\\"{x:1040,y:935,t:1527268237869};\\\", \\\"{x:1040,y:933,t:1527268237893};\\\", \\\"{x:1040,y:932,t:1527268237901};\\\", \\\"{x:1040,y:930,t:1527268237911};\\\", \\\"{x:1040,y:929,t:1527268237928};\\\", \\\"{x:1040,y:927,t:1527268237944};\\\", \\\"{x:1040,y:925,t:1527268237961};\\\", \\\"{x:1040,y:924,t:1527268237978};\\\", \\\"{x:1040,y:923,t:1527268237995};\\\", \\\"{x:1040,y:922,t:1527268238029};\\\", \\\"{x:1043,y:919,t:1527268238045};\\\", \\\"{x:1046,y:916,t:1527268238061};\\\", \\\"{x:1052,y:911,t:1527268238078};\\\", \\\"{x:1057,y:907,t:1527268238094};\\\", \\\"{x:1062,y:904,t:1527268238111};\\\", \\\"{x:1065,y:902,t:1527268238128};\\\", \\\"{x:1066,y:901,t:1527268238145};\\\", \\\"{x:1067,y:900,t:1527268238161};\\\", \\\"{x:1068,y:900,t:1527268238177};\\\", \\\"{x:1070,y:900,t:1527268238204};\\\", \\\"{x:1071,y:900,t:1527268238261};\\\", \\\"{x:1074,y:899,t:1527268238501};\\\", \\\"{x:1075,y:898,t:1527268238524};\\\", \\\"{x:1075,y:897,t:1527268238541};\\\", \\\"{x:1076,y:897,t:1527268238549};\\\", \\\"{x:1077,y:897,t:1527268238562};\\\", \\\"{x:1077,y:896,t:1527268238578};\\\", \\\"{x:1078,y:895,t:1527268238595};\\\", \\\"{x:1079,y:894,t:1527268238637};\\\", \\\"{x:1080,y:894,t:1527268238709};\\\", \\\"{x:1080,y:893,t:1527268238852};\\\", \\\"{x:1080,y:892,t:1527268238876};\\\", \\\"{x:1080,y:891,t:1527268238997};\\\", \\\"{x:1079,y:891,t:1527268239013};\\\", \\\"{x:1066,y:893,t:1527268239028};\\\", \\\"{x:1053,y:893,t:1527268239045};\\\", \\\"{x:1043,y:893,t:1527268239062};\\\", \\\"{x:1037,y:892,t:1527268239079};\\\", \\\"{x:1036,y:891,t:1527268239095};\\\", \\\"{x:1034,y:890,t:1527268239112};\\\", \\\"{x:1032,y:886,t:1527268239129};\\\", \\\"{x:1031,y:880,t:1527268239144};\\\", \\\"{x:1029,y:871,t:1527268239162};\\\", \\\"{x:1028,y:862,t:1527268239179};\\\", \\\"{x:1028,y:857,t:1527268239195};\\\", \\\"{x:1028,y:851,t:1527268239212};\\\", \\\"{x:1035,y:839,t:1527268239229};\\\", \\\"{x:1041,y:833,t:1527268239244};\\\", \\\"{x:1045,y:829,t:1527268239262};\\\", \\\"{x:1049,y:826,t:1527268239279};\\\", \\\"{x:1050,y:825,t:1527268239295};\\\", \\\"{x:1052,y:825,t:1527268239312};\\\", \\\"{x:1053,y:824,t:1527268239329};\\\", \\\"{x:1054,y:824,t:1527268239382};\\\", \\\"{x:1055,y:824,t:1527268239454};\\\", \\\"{x:1056,y:824,t:1527268239478};\\\", \\\"{x:1057,y:824,t:1527268239653};\\\", \\\"{x:1057,y:822,t:1527268239662};\\\", \\\"{x:1055,y:817,t:1527268239679};\\\", \\\"{x:1053,y:811,t:1527268239696};\\\", \\\"{x:1052,y:807,t:1527268239712};\\\", \\\"{x:1051,y:803,t:1527268239729};\\\", \\\"{x:1051,y:798,t:1527268239746};\\\", \\\"{x:1051,y:795,t:1527268239762};\\\", \\\"{x:1051,y:792,t:1527268239779};\\\", \\\"{x:1052,y:789,t:1527268239796};\\\", \\\"{x:1053,y:786,t:1527268239812};\\\", \\\"{x:1054,y:783,t:1527268239829};\\\", \\\"{x:1055,y:781,t:1527268239846};\\\", \\\"{x:1056,y:780,t:1527268239863};\\\", \\\"{x:1057,y:779,t:1527268239879};\\\", \\\"{x:1058,y:778,t:1527268239896};\\\", \\\"{x:1060,y:776,t:1527268239914};\\\", \\\"{x:1061,y:775,t:1527268239929};\\\", \\\"{x:1063,y:773,t:1527268239947};\\\", \\\"{x:1064,y:772,t:1527268239963};\\\", \\\"{x:1066,y:770,t:1527268239979};\\\", \\\"{x:1068,y:769,t:1527268239996};\\\", \\\"{x:1069,y:768,t:1527268240014};\\\", \\\"{x:1069,y:767,t:1527268240038};\\\", \\\"{x:1070,y:767,t:1527268240206};\\\", \\\"{x:1070,y:765,t:1527268240214};\\\", \\\"{x:1070,y:758,t:1527268240229};\\\", \\\"{x:1064,y:746,t:1527268240246};\\\", \\\"{x:1059,y:729,t:1527268240264};\\\", \\\"{x:1052,y:714,t:1527268240279};\\\", \\\"{x:1047,y:701,t:1527268240296};\\\", \\\"{x:1044,y:694,t:1527268240314};\\\", \\\"{x:1040,y:686,t:1527268240329};\\\", \\\"{x:1040,y:684,t:1527268240346};\\\", \\\"{x:1039,y:683,t:1527268240364};\\\", \\\"{x:1039,y:681,t:1527268240380};\\\", \\\"{x:1039,y:680,t:1527268240422};\\\", \\\"{x:1039,y:678,t:1527268240445};\\\", \\\"{x:1039,y:677,t:1527268240463};\\\", \\\"{x:1040,y:677,t:1527268240480};\\\", \\\"{x:1043,y:677,t:1527268240495};\\\", \\\"{x:1045,y:676,t:1527268240513};\\\", \\\"{x:1046,y:676,t:1527268240541};\\\", \\\"{x:1047,y:676,t:1527268240548};\\\", \\\"{x:1049,y:676,t:1527268240563};\\\", \\\"{x:1054,y:676,t:1527268240580};\\\", \\\"{x:1060,y:678,t:1527268240595};\\\", \\\"{x:1068,y:682,t:1527268240612};\\\", \\\"{x:1072,y:685,t:1527268240630};\\\", \\\"{x:1075,y:687,t:1527268240645};\\\", \\\"{x:1078,y:689,t:1527268240663};\\\", \\\"{x:1079,y:690,t:1527268240692};\\\", \\\"{x:1079,y:688,t:1527268240813};\\\", \\\"{x:1079,y:685,t:1527268240829};\\\", \\\"{x:1078,y:679,t:1527268240847};\\\", \\\"{x:1074,y:671,t:1527268240862};\\\", \\\"{x:1070,y:661,t:1527268240880};\\\", \\\"{x:1065,y:650,t:1527268240897};\\\", \\\"{x:1061,y:641,t:1527268240913};\\\", \\\"{x:1059,y:635,t:1527268240929};\\\", \\\"{x:1057,y:631,t:1527268240947};\\\", \\\"{x:1057,y:629,t:1527268241044};\\\", \\\"{x:1057,y:628,t:1527268241052};\\\", \\\"{x:1059,y:627,t:1527268241063};\\\", \\\"{x:1060,y:626,t:1527268241080};\\\", \\\"{x:1060,y:625,t:1527268241097};\\\", \\\"{x:1061,y:625,t:1527268241381};\\\", \\\"{x:1064,y:616,t:1527268241396};\\\", \\\"{x:1068,y:602,t:1527268241414};\\\", \\\"{x:1072,y:588,t:1527268241430};\\\", \\\"{x:1074,y:577,t:1527268241447};\\\", \\\"{x:1075,y:570,t:1527268241464};\\\", \\\"{x:1075,y:566,t:1527268241480};\\\", \\\"{x:1075,y:564,t:1527268241497};\\\", \\\"{x:1075,y:562,t:1527268241514};\\\", \\\"{x:1075,y:561,t:1527268241530};\\\", \\\"{x:1075,y:560,t:1527268241546};\\\", \\\"{x:1075,y:556,t:1527268243029};\\\", \\\"{x:1075,y:551,t:1527268243036};\\\", \\\"{x:1075,y:550,t:1527268243048};\\\", \\\"{x:1075,y:544,t:1527268243064};\\\", \\\"{x:1075,y:539,t:1527268243081};\\\", \\\"{x:1074,y:533,t:1527268243098};\\\", \\\"{x:1072,y:528,t:1527268243115};\\\", \\\"{x:1071,y:525,t:1527268243131};\\\", \\\"{x:1070,y:521,t:1527268243148};\\\", \\\"{x:1070,y:518,t:1527268243165};\\\", \\\"{x:1070,y:517,t:1527268243182};\\\", \\\"{x:1070,y:516,t:1527268243198};\\\", \\\"{x:1070,y:515,t:1527268243215};\\\", \\\"{x:1070,y:514,t:1527268243310};\\\", \\\"{x:1070,y:512,t:1527268243318};\\\", \\\"{x:1070,y:511,t:1527268243333};\\\", \\\"{x:1070,y:510,t:1527268243348};\\\", \\\"{x:1070,y:508,t:1527268243366};\\\", \\\"{x:1070,y:506,t:1527268243382};\\\", \\\"{x:1071,y:504,t:1527268243398};\\\", \\\"{x:1071,y:503,t:1527268243415};\\\", \\\"{x:1072,y:501,t:1527268243433};\\\", \\\"{x:1073,y:499,t:1527268243449};\\\", \\\"{x:1074,y:499,t:1527268243466};\\\", \\\"{x:1075,y:497,t:1527268243482};\\\", \\\"{x:1076,y:496,t:1527268243501};\\\", \\\"{x:1075,y:496,t:1527268243844};\\\", \\\"{x:1074,y:497,t:1527268243885};\\\", \\\"{x:1073,y:497,t:1527268243925};\\\", \\\"{x:1072,y:497,t:1527268243932};\\\", \\\"{x:1071,y:495,t:1527268244509};\\\", \\\"{x:1068,y:486,t:1527268244516};\\\", \\\"{x:1066,y:479,t:1527268244532};\\\", \\\"{x:1061,y:460,t:1527268244549};\\\", \\\"{x:1058,y:446,t:1527268244567};\\\", \\\"{x:1056,y:438,t:1527268244582};\\\", \\\"{x:1054,y:434,t:1527268244599};\\\", \\\"{x:1054,y:431,t:1527268244616};\\\", \\\"{x:1054,y:427,t:1527268244633};\\\", \\\"{x:1053,y:420,t:1527268244649};\\\", \\\"{x:1053,y:414,t:1527268244668};\\\", \\\"{x:1053,y:410,t:1527268244684};\\\", \\\"{x:1053,y:408,t:1527268244699};\\\", \\\"{x:1053,y:407,t:1527268244717};\\\", \\\"{x:1053,y:406,t:1527268244734};\\\", \\\"{x:1053,y:405,t:1527268244749};\\\", \\\"{x:1053,y:404,t:1527268244773};\\\", \\\"{x:1053,y:403,t:1527268244798};\\\", \\\"{x:1053,y:402,t:1527268244877};\\\", \\\"{x:1054,y:402,t:1527268244893};\\\", \\\"{x:1056,y:402,t:1527268244910};\\\", \\\"{x:1058,y:402,t:1527268244918};\\\", \\\"{x:1064,y:407,t:1527268244934};\\\", \\\"{x:1065,y:409,t:1527268244949};\\\", \\\"{x:1066,y:412,t:1527268244966};\\\", \\\"{x:1069,y:417,t:1527268244984};\\\", \\\"{x:1072,y:421,t:1527268245000};\\\", \\\"{x:1074,y:424,t:1527268245016};\\\", \\\"{x:1076,y:426,t:1527268245033};\\\", \\\"{x:1076,y:427,t:1527268245062};\\\", \\\"{x:1076,y:428,t:1527268245102};\\\", \\\"{x:1077,y:428,t:1527268245116};\\\", \\\"{x:1078,y:428,t:1527268245188};\\\", \\\"{x:1079,y:428,t:1527268245199};\\\", \\\"{x:1081,y:428,t:1527268245215};\\\", \\\"{x:1085,y:428,t:1527268245232};\\\", \\\"{x:1093,y:428,t:1527268245250};\\\", \\\"{x:1109,y:426,t:1527268245266};\\\", \\\"{x:1130,y:424,t:1527268245283};\\\", \\\"{x:1157,y:423,t:1527268245300};\\\", \\\"{x:1187,y:423,t:1527268245315};\\\", \\\"{x:1226,y:423,t:1527268245333};\\\", \\\"{x:1261,y:420,t:1527268245350};\\\", \\\"{x:1293,y:418,t:1527268245366};\\\", \\\"{x:1327,y:413,t:1527268245383};\\\", \\\"{x:1361,y:408,t:1527268245400};\\\", \\\"{x:1403,y:408,t:1527268245416};\\\", \\\"{x:1443,y:408,t:1527268245433};\\\", \\\"{x:1485,y:408,t:1527268245450};\\\", \\\"{x:1527,y:406,t:1527268245467};\\\", \\\"{x:1561,y:401,t:1527268245483};\\\", \\\"{x:1590,y:398,t:1527268245500};\\\", \\\"{x:1612,y:393,t:1527268245516};\\\", \\\"{x:1628,y:392,t:1527268245533};\\\", \\\"{x:1630,y:391,t:1527268245551};\\\", \\\"{x:1631,y:391,t:1527268245566};\\\", \\\"{x:1632,y:391,t:1527268245605};\\\", \\\"{x:1633,y:390,t:1527268245621};\\\", \\\"{x:1634,y:390,t:1527268245733};\\\", \\\"{x:1621,y:396,t:1527268245750};\\\", \\\"{x:1576,y:412,t:1527268245767};\\\", \\\"{x:1504,y:432,t:1527268245783};\\\", \\\"{x:1390,y:448,t:1527268245800};\\\", \\\"{x:1238,y:470,t:1527268245817};\\\", \\\"{x:1025,y:502,t:1527268245832};\\\", \\\"{x:792,y:514,t:1527268245850};\\\", \\\"{x:533,y:545,t:1527268245867};\\\", \\\"{x:299,y:573,t:1527268245884};\\\", \\\"{x:16,y:611,t:1527268245902};\\\", \\\"{x:0,y:640,t:1527268245918};\\\", \\\"{x:0,y:666,t:1527268245935};\\\", \\\"{x:0,y:686,t:1527268245951};\\\", \\\"{x:0,y:704,t:1527268245968};\\\", \\\"{x:0,y:724,t:1527268245985};\\\", \\\"{x:0,y:742,t:1527268246001};\\\", \\\"{x:0,y:754,t:1527268246018};\\\", \\\"{x:0,y:759,t:1527268246035};\\\", \\\"{x:0,y:760,t:1527268246076};\\\", \\\"{x:2,y:760,t:1527268246084};\\\", \\\"{x:10,y:758,t:1527268246102};\\\", \\\"{x:23,y:751,t:1527268246117};\\\", \\\"{x:57,y:725,t:1527268246135};\\\", \\\"{x:112,y:679,t:1527268246151};\\\", \\\"{x:170,y:615,t:1527268246168};\\\", \\\"{x:237,y:565,t:1527268246185};\\\", \\\"{x:290,y:533,t:1527268246203};\\\", \\\"{x:322,y:514,t:1527268246217};\\\", \\\"{x:341,y:504,t:1527268246235};\\\", \\\"{x:350,y:499,t:1527268246252};\\\", \\\"{x:353,y:498,t:1527268246268};\\\", \\\"{x:355,y:497,t:1527268246285};\\\", \\\"{x:357,y:495,t:1527268246302};\\\", \\\"{x:361,y:494,t:1527268246318};\\\", \\\"{x:362,y:493,t:1527268246335};\\\", \\\"{x:367,y:491,t:1527268246352};\\\", \\\"{x:370,y:491,t:1527268246368};\\\", \\\"{x:372,y:491,t:1527268246385};\\\", \\\"{x:374,y:491,t:1527268246401};\\\", \\\"{x:379,y:491,t:1527268246418};\\\", \\\"{x:390,y:505,t:1527268246435};\\\", \\\"{x:413,y:531,t:1527268246452};\\\", \\\"{x:445,y:565,t:1527268246468};\\\", \\\"{x:491,y:600,t:1527268246486};\\\", \\\"{x:507,y:609,t:1527268246503};\\\", \\\"{x:512,y:613,t:1527268246519};\\\", \\\"{x:513,y:613,t:1527268246534};\\\", \\\"{x:513,y:614,t:1527268246636};\\\", \\\"{x:512,y:616,t:1527268246652};\\\", \\\"{x:487,y:619,t:1527268246668};\\\", \\\"{x:463,y:622,t:1527268246686};\\\", \\\"{x:438,y:623,t:1527268246702};\\\", \\\"{x:409,y:623,t:1527268246719};\\\", \\\"{x:391,y:623,t:1527268246735};\\\", \\\"{x:380,y:623,t:1527268246752};\\\", \\\"{x:374,y:623,t:1527268246769};\\\", \\\"{x:372,y:623,t:1527268246785};\\\", \\\"{x:368,y:623,t:1527268246801};\\\", \\\"{x:363,y:623,t:1527268246819};\\\", \\\"{x:350,y:623,t:1527268246836};\\\", \\\"{x:335,y:623,t:1527268246852};\\\", \\\"{x:315,y:621,t:1527268246868};\\\", \\\"{x:297,y:619,t:1527268246886};\\\", \\\"{x:274,y:616,t:1527268246902};\\\", \\\"{x:250,y:610,t:1527268246919};\\\", \\\"{x:233,y:606,t:1527268246936};\\\", \\\"{x:227,y:604,t:1527268246952};\\\", \\\"{x:223,y:603,t:1527268246969};\\\", \\\"{x:222,y:602,t:1527268246985};\\\", \\\"{x:221,y:601,t:1527268247002};\\\", \\\"{x:220,y:601,t:1527268247019};\\\", \\\"{x:218,y:601,t:1527268247036};\\\", \\\"{x:215,y:601,t:1527268247052};\\\", \\\"{x:211,y:601,t:1527268247069};\\\", \\\"{x:207,y:601,t:1527268247086};\\\", \\\"{x:201,y:603,t:1527268247102};\\\", \\\"{x:194,y:606,t:1527268247119};\\\", \\\"{x:189,y:608,t:1527268247136};\\\", \\\"{x:184,y:610,t:1527268247152};\\\", \\\"{x:178,y:612,t:1527268247169};\\\", \\\"{x:172,y:614,t:1527268247186};\\\", \\\"{x:168,y:615,t:1527268247202};\\\", \\\"{x:164,y:615,t:1527268247219};\\\", \\\"{x:160,y:617,t:1527268247236};\\\", \\\"{x:156,y:618,t:1527268247252};\\\", \\\"{x:153,y:618,t:1527268247269};\\\", \\\"{x:151,y:618,t:1527268247286};\\\", \\\"{x:150,y:618,t:1527268247333};\\\", \\\"{x:149,y:618,t:1527268247340};\\\", \\\"{x:149,y:615,t:1527268247353};\\\", \\\"{x:150,y:610,t:1527268247369};\\\", \\\"{x:159,y:605,t:1527268247386};\\\", \\\"{x:171,y:598,t:1527268247403};\\\", \\\"{x:191,y:593,t:1527268247419};\\\", \\\"{x:215,y:587,t:1527268247436};\\\", \\\"{x:255,y:582,t:1527268247452};\\\", \\\"{x:276,y:582,t:1527268247469};\\\", \\\"{x:300,y:582,t:1527268247486};\\\", \\\"{x:326,y:582,t:1527268247502};\\\", \\\"{x:350,y:582,t:1527268247519};\\\", \\\"{x:375,y:582,t:1527268247536};\\\", \\\"{x:391,y:584,t:1527268247553};\\\", \\\"{x:400,y:584,t:1527268247569};\\\", \\\"{x:403,y:584,t:1527268247586};\\\", \\\"{x:404,y:584,t:1527268247685};\\\", \\\"{x:405,y:584,t:1527268247700};\\\", \\\"{x:406,y:584,t:1527268247708};\\\", \\\"{x:407,y:584,t:1527268247719};\\\", \\\"{x:409,y:584,t:1527268247736};\\\", \\\"{x:413,y:584,t:1527268247753};\\\", \\\"{x:417,y:584,t:1527268247769};\\\", \\\"{x:423,y:584,t:1527268247786};\\\", \\\"{x:434,y:584,t:1527268247803};\\\", \\\"{x:452,y:584,t:1527268247819};\\\", \\\"{x:478,y:584,t:1527268247836};\\\", \\\"{x:536,y:581,t:1527268247854};\\\", \\\"{x:594,y:574,t:1527268247870};\\\", \\\"{x:636,y:569,t:1527268247887};\\\", \\\"{x:668,y:565,t:1527268247903};\\\", \\\"{x:689,y:562,t:1527268247920};\\\", \\\"{x:700,y:558,t:1527268247936};\\\", \\\"{x:708,y:554,t:1527268247953};\\\", \\\"{x:710,y:552,t:1527268247970};\\\", \\\"{x:714,y:550,t:1527268247986};\\\", \\\"{x:720,y:547,t:1527268248003};\\\", \\\"{x:726,y:544,t:1527268248022};\\\", \\\"{x:732,y:541,t:1527268248037};\\\", \\\"{x:739,y:539,t:1527268248053};\\\", \\\"{x:740,y:538,t:1527268248071};\\\", \\\"{x:741,y:538,t:1527268248088};\\\", \\\"{x:742,y:538,t:1527268248103};\\\", \\\"{x:743,y:538,t:1527268248181};\\\", \\\"{x:744,y:538,t:1527268248189};\\\", \\\"{x:745,y:538,t:1527268248203};\\\", \\\"{x:746,y:540,t:1527268248220};\\\", \\\"{x:749,y:544,t:1527268248238};\\\", \\\"{x:752,y:547,t:1527268248254};\\\", \\\"{x:752,y:549,t:1527268248270};\\\", \\\"{x:753,y:551,t:1527268248287};\\\", \\\"{x:754,y:552,t:1527268248304};\\\", \\\"{x:754,y:553,t:1527268248320};\\\", \\\"{x:754,y:554,t:1527268248337};\\\", \\\"{x:754,y:555,t:1527268248354};\\\", \\\"{x:754,y:556,t:1527268248370};\\\", \\\"{x:755,y:558,t:1527268248387};\\\", \\\"{x:755,y:560,t:1527268248404};\\\", \\\"{x:755,y:561,t:1527268248421};\\\", \\\"{x:755,y:562,t:1527268248437};\\\", \\\"{x:755,y:563,t:1527268248455};\\\", \\\"{x:755,y:564,t:1527268248472};\\\", \\\"{x:754,y:565,t:1527268248487};\\\", \\\"{x:753,y:566,t:1527268248525};\\\", \\\"{x:752,y:567,t:1527268248542};\\\", \\\"{x:751,y:568,t:1527268248574};\\\", \\\"{x:751,y:569,t:1527268248589};\\\", \\\"{x:750,y:570,t:1527268248604};\\\", \\\"{x:749,y:570,t:1527268248628};\\\", \\\"{x:749,y:571,t:1527268248661};\\\", \\\"{x:748,y:572,t:1527268248693};\\\", \\\"{x:748,y:573,t:1527268248757};\\\", \\\"{x:746,y:573,t:1527268248868};\\\", \\\"{x:746,y:574,t:1527268248933};\\\", \\\"{x:745,y:574,t:1527268248956};\\\", \\\"{x:744,y:574,t:1527268248980};\\\", \\\"{x:743,y:575,t:1527268248989};\\\", \\\"{x:743,y:576,t:1527268249061};\\\", \\\"{x:740,y:577,t:1527268250572};\\\", \\\"{x:727,y:581,t:1527268250588};\\\", \\\"{x:709,y:582,t:1527268250605};\\\", \\\"{x:689,y:582,t:1527268250622};\\\", \\\"{x:666,y:582,t:1527268250637};\\\", \\\"{x:646,y:582,t:1527268250655};\\\", \\\"{x:637,y:582,t:1527268250673};\\\", \\\"{x:633,y:582,t:1527268250688};\\\", \\\"{x:632,y:582,t:1527268250705};\\\", \\\"{x:631,y:582,t:1527268250722};\\\", \\\"{x:630,y:582,t:1527268250738};\\\", \\\"{x:629,y:582,t:1527268250755};\\\", \\\"{x:628,y:582,t:1527268250789};\\\", \\\"{x:627,y:582,t:1527268250893};\\\", \\\"{x:626,y:582,t:1527268250909};\\\", \\\"{x:626,y:581,t:1527268250922};\\\", \\\"{x:624,y:580,t:1527268250940};\\\", \\\"{x:623,y:579,t:1527268250955};\\\", \\\"{x:621,y:578,t:1527268250972};\\\", \\\"{x:620,y:578,t:1527268250989};\\\", \\\"{x:620,y:577,t:1527268251006};\\\", \\\"{x:619,y:576,t:1527268251038};\\\", \\\"{x:619,y:575,t:1527268251045};\\\", \\\"{x:618,y:573,t:1527268251062};\\\", \\\"{x:618,y:572,t:1527268251072};\\\", \\\"{x:617,y:569,t:1527268251089};\\\", \\\"{x:617,y:567,t:1527268251105};\\\", \\\"{x:617,y:566,t:1527268251122};\\\", \\\"{x:617,y:564,t:1527268251140};\\\", \\\"{x:617,y:562,t:1527268251155};\\\", \\\"{x:617,y:560,t:1527268251172};\\\", \\\"{x:617,y:559,t:1527268251190};\\\", \\\"{x:617,y:558,t:1527268251205};\\\", \\\"{x:617,y:557,t:1527268251223};\\\", \\\"{x:617,y:556,t:1527268251239};\\\", \\\"{x:617,y:555,t:1527268251277};\\\", \\\"{x:617,y:554,t:1527268251317};\\\", \\\"{x:617,y:553,t:1527268251396};\\\", \\\"{x:617,y:552,t:1527268251484};\\\", \\\"{x:617,y:551,t:1527268251515};\\\", \\\"{x:616,y:551,t:1527268257756};\\\", \\\"{x:615,y:551,t:1527268257764};\\\", \\\"{x:609,y:554,t:1527268257778};\\\", \\\"{x:599,y:564,t:1527268257795};\\\", \\\"{x:588,y:571,t:1527268257812};\\\", \\\"{x:574,y:580,t:1527268257830};\\\", \\\"{x:567,y:582,t:1527268257845};\\\", \\\"{x:566,y:584,t:1527268257859};\\\", \\\"{x:564,y:584,t:1527268257876};\\\", \\\"{x:550,y:588,t:1527268257892};\\\", \\\"{x:532,y:590,t:1527268257909};\\\", \\\"{x:500,y:592,t:1527268257925};\\\", \\\"{x:464,y:594,t:1527268257943};\\\", \\\"{x:420,y:594,t:1527268257959};\\\", \\\"{x:374,y:595,t:1527268257977};\\\", \\\"{x:346,y:595,t:1527268257994};\\\", \\\"{x:324,y:594,t:1527268258011};\\\", \\\"{x:314,y:594,t:1527268258027};\\\", \\\"{x:311,y:594,t:1527268258044};\\\", \\\"{x:310,y:594,t:1527268258062};\\\", \\\"{x:309,y:593,t:1527268258141};\\\", \\\"{x:310,y:589,t:1527268258157};\\\", \\\"{x:315,y:585,t:1527268258164};\\\", \\\"{x:322,y:581,t:1527268258179};\\\", \\\"{x:336,y:574,t:1527268258195};\\\", \\\"{x:352,y:565,t:1527268258212};\\\", \\\"{x:364,y:560,t:1527268258228};\\\", \\\"{x:371,y:558,t:1527268258244};\\\", \\\"{x:374,y:555,t:1527268258261};\\\", \\\"{x:377,y:555,t:1527268258278};\\\", \\\"{x:381,y:554,t:1527268258295};\\\", \\\"{x:387,y:554,t:1527268258311};\\\", \\\"{x:397,y:554,t:1527268258329};\\\", \\\"{x:410,y:554,t:1527268258344};\\\", \\\"{x:425,y:554,t:1527268258361};\\\", \\\"{x:445,y:554,t:1527268258378};\\\", \\\"{x:477,y:554,t:1527268258394};\\\", \\\"{x:527,y:554,t:1527268258412};\\\", \\\"{x:608,y:554,t:1527268258428};\\\", \\\"{x:650,y:554,t:1527268258445};\\\", \\\"{x:676,y:554,t:1527268258461};\\\", \\\"{x:688,y:552,t:1527268258478};\\\", \\\"{x:687,y:552,t:1527268258532};\\\", \\\"{x:684,y:552,t:1527268258545};\\\", \\\"{x:677,y:553,t:1527268258562};\\\", \\\"{x:668,y:556,t:1527268258579};\\\", \\\"{x:663,y:557,t:1527268258594};\\\", \\\"{x:661,y:557,t:1527268258612};\\\", \\\"{x:657,y:559,t:1527268258629};\\\", \\\"{x:653,y:561,t:1527268258644};\\\", \\\"{x:647,y:564,t:1527268258662};\\\", \\\"{x:639,y:568,t:1527268258679};\\\", \\\"{x:632,y:570,t:1527268258694};\\\", \\\"{x:621,y:574,t:1527268258711};\\\", \\\"{x:612,y:579,t:1527268258728};\\\", \\\"{x:606,y:581,t:1527268258745};\\\", \\\"{x:598,y:584,t:1527268258762};\\\", \\\"{x:585,y:591,t:1527268258779};\\\", \\\"{x:563,y:599,t:1527268258795};\\\", \\\"{x:536,y:606,t:1527268258812};\\\", \\\"{x:495,y:615,t:1527268258830};\\\", \\\"{x:467,y:617,t:1527268258846};\\\", \\\"{x:450,y:620,t:1527268258862};\\\", \\\"{x:431,y:622,t:1527268258878};\\\", \\\"{x:416,y:625,t:1527268258895};\\\", \\\"{x:410,y:625,t:1527268258911};\\\", \\\"{x:408,y:625,t:1527268258928};\\\", \\\"{x:407,y:625,t:1527268258957};\\\", \\\"{x:404,y:625,t:1527268258988};\\\", \\\"{x:402,y:625,t:1527268259012};\\\", \\\"{x:398,y:625,t:1527268259028};\\\", \\\"{x:395,y:624,t:1527268259046};\\\", \\\"{x:389,y:622,t:1527268259062};\\\", \\\"{x:382,y:622,t:1527268259079};\\\", \\\"{x:371,y:622,t:1527268259095};\\\", \\\"{x:361,y:622,t:1527268259112};\\\", \\\"{x:353,y:622,t:1527268259128};\\\", \\\"{x:348,y:622,t:1527268259145};\\\", \\\"{x:345,y:622,t:1527268259162};\\\", \\\"{x:343,y:621,t:1527268259179};\\\", \\\"{x:342,y:620,t:1527268259195};\\\", \\\"{x:336,y:618,t:1527268259213};\\\", \\\"{x:330,y:617,t:1527268259229};\\\", \\\"{x:320,y:613,t:1527268259246};\\\", \\\"{x:303,y:612,t:1527268259263};\\\", \\\"{x:282,y:610,t:1527268259279};\\\", \\\"{x:260,y:607,t:1527268259296};\\\", \\\"{x:238,y:604,t:1527268259313};\\\", \\\"{x:220,y:603,t:1527268259328};\\\", \\\"{x:207,y:603,t:1527268259346};\\\", \\\"{x:199,y:603,t:1527268259362};\\\", \\\"{x:197,y:602,t:1527268259379};\\\", \\\"{x:196,y:602,t:1527268259421};\\\", \\\"{x:197,y:600,t:1527268259429};\\\", \\\"{x:213,y:594,t:1527268259446};\\\", \\\"{x:240,y:590,t:1527268259463};\\\", \\\"{x:285,y:586,t:1527268259479};\\\", \\\"{x:359,y:581,t:1527268259496};\\\", \\\"{x:440,y:581,t:1527268259512};\\\", \\\"{x:526,y:581,t:1527268259530};\\\", \\\"{x:604,y:581,t:1527268259546};\\\", \\\"{x:638,y:581,t:1527268259563};\\\", \\\"{x:659,y:576,t:1527268259580};\\\", \\\"{x:666,y:575,t:1527268259595};\\\", \\\"{x:669,y:573,t:1527268259613};\\\", \\\"{x:669,y:572,t:1527268259637};\\\", \\\"{x:669,y:570,t:1527268259668};\\\", \\\"{x:669,y:569,t:1527268259700};\\\", \\\"{x:669,y:566,t:1527268259712};\\\", \\\"{x:671,y:563,t:1527268259729};\\\", \\\"{x:674,y:561,t:1527268259746};\\\", \\\"{x:676,y:558,t:1527268259763};\\\", \\\"{x:678,y:556,t:1527268259780};\\\", \\\"{x:679,y:553,t:1527268259796};\\\", \\\"{x:684,y:547,t:1527268259812};\\\", \\\"{x:688,y:543,t:1527268259831};\\\", \\\"{x:692,y:538,t:1527268259846};\\\", \\\"{x:699,y:534,t:1527268259863};\\\", \\\"{x:708,y:527,t:1527268259880};\\\", \\\"{x:719,y:521,t:1527268259895};\\\", \\\"{x:734,y:516,t:1527268259913};\\\", \\\"{x:745,y:514,t:1527268259929};\\\", \\\"{x:759,y:511,t:1527268259945};\\\", \\\"{x:771,y:510,t:1527268259962};\\\", \\\"{x:778,y:509,t:1527268259980};\\\", \\\"{x:784,y:509,t:1527268259996};\\\", \\\"{x:787,y:509,t:1527268260012};\\\", \\\"{x:792,y:509,t:1527268260029};\\\", \\\"{x:795,y:509,t:1527268260046};\\\", \\\"{x:796,y:509,t:1527268260062};\\\", \\\"{x:799,y:509,t:1527268260079};\\\", \\\"{x:802,y:509,t:1527268260097};\\\", \\\"{x:807,y:510,t:1527268260113};\\\", \\\"{x:810,y:511,t:1527268260129};\\\", \\\"{x:813,y:512,t:1527268260147};\\\", \\\"{x:815,y:514,t:1527268260162};\\\", \\\"{x:817,y:516,t:1527268260180};\\\", \\\"{x:818,y:524,t:1527268260197};\\\", \\\"{x:821,y:531,t:1527268260212};\\\", \\\"{x:821,y:539,t:1527268260230};\\\", \\\"{x:821,y:542,t:1527268260246};\\\", \\\"{x:821,y:546,t:1527268260263};\\\", \\\"{x:822,y:548,t:1527268260279};\\\", \\\"{x:822,y:549,t:1527268260297};\\\", \\\"{x:823,y:550,t:1527268260509};\\\", \\\"{x:825,y:551,t:1527268260524};\\\", \\\"{x:825,y:552,t:1527268260532};\\\", \\\"{x:826,y:552,t:1527268260541};\\\", \\\"{x:827,y:552,t:1527268260573};\\\", \\\"{x:827,y:552,t:1527268260621};\\\", \\\"{x:828,y:553,t:1527268260636};\\\", \\\"{x:828,y:555,t:1527268260653};\\\", \\\"{x:828,y:558,t:1527268260663};\\\", \\\"{x:828,y:569,t:1527268260679};\\\", \\\"{x:828,y:581,t:1527268260696};\\\", \\\"{x:830,y:587,t:1527268260714};\\\", \\\"{x:832,y:594,t:1527268260730};\\\", \\\"{x:834,y:599,t:1527268260747};\\\", \\\"{x:835,y:604,t:1527268260763};\\\", \\\"{x:836,y:608,t:1527268260779};\\\", \\\"{x:838,y:614,t:1527268260797};\\\", \\\"{x:838,y:615,t:1527268260814};\\\", \\\"{x:839,y:616,t:1527268260830};\\\", \\\"{x:839,y:612,t:1527268260927};\\\", \\\"{x:843,y:605,t:1527268260947};\\\", \\\"{x:844,y:601,t:1527268260963};\\\", \\\"{x:844,y:600,t:1527268260981};\\\", \\\"{x:845,y:600,t:1527268261045};\\\", \\\"{x:846,y:599,t:1527268261444};\\\", \\\"{x:846,y:598,t:1527268261452};\\\", \\\"{x:846,y:596,t:1527268261463};\\\", \\\"{x:845,y:591,t:1527268261480};\\\", \\\"{x:843,y:584,t:1527268261498};\\\", \\\"{x:841,y:581,t:1527268261514};\\\", \\\"{x:838,y:575,t:1527268261530};\\\", \\\"{x:837,y:570,t:1527268261549};\\\", \\\"{x:837,y:569,t:1527268261564};\\\", \\\"{x:835,y:564,t:1527268261580};\\\", \\\"{x:835,y:563,t:1527268261597};\\\", \\\"{x:835,y:562,t:1527268261629};\\\", \\\"{x:832,y:563,t:1527268261860};\\\", \\\"{x:825,y:574,t:1527268261868};\\\", \\\"{x:815,y:588,t:1527268261881};\\\", \\\"{x:791,y:615,t:1527268261898};\\\", \\\"{x:755,y:657,t:1527268261914};\\\", \\\"{x:719,y:686,t:1527268261930};\\\", \\\"{x:679,y:715,t:1527268261948};\\\", \\\"{x:627,y:748,t:1527268261964};\\\", \\\"{x:604,y:762,t:1527268261981};\\\", \\\"{x:588,y:775,t:1527268261997};\\\", \\\"{x:567,y:785,t:1527268262014};\\\", \\\"{x:552,y:788,t:1527268262031};\\\", \\\"{x:543,y:790,t:1527268262048};\\\", \\\"{x:538,y:790,t:1527268262065};\\\", \\\"{x:531,y:789,t:1527268262080};\\\", \\\"{x:525,y:785,t:1527268262098};\\\", \\\"{x:517,y:778,t:1527268262115};\\\", \\\"{x:507,y:771,t:1527268262131};\\\", \\\"{x:497,y:764,t:1527268262148};\\\", \\\"{x:484,y:755,t:1527268262165};\\\", \\\"{x:475,y:751,t:1527268262181};\\\", \\\"{x:468,y:748,t:1527268262198};\\\", \\\"{x:464,y:746,t:1527268262215};\\\", \\\"{x:463,y:746,t:1527268262261};\\\", \\\"{x:463,y:745,t:1527268262269};\\\", \\\"{x:463,y:743,t:1527268262281};\\\", \\\"{x:463,y:739,t:1527268262298};\\\", \\\"{x:463,y:734,t:1527268262316};\\\", \\\"{x:464,y:730,t:1527268262330};\\\", \\\"{x:466,y:725,t:1527268262348};\\\", \\\"{x:468,y:720,t:1527268262365};\\\", \\\"{x:470,y:718,t:1527268262388};\\\", \\\"{x:471,y:717,t:1527268262436};\\\" ] }, { \\\"rt\\\": 24254, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 312109, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:472,y:710,t:1527268265215};\\\", \\\"{x:475,y:687,t:1527268265233};\\\", \\\"{x:477,y:667,t:1527268265250};\\\", \\\"{x:483,y:649,t:1527268265267};\\\", \\\"{x:490,y:634,t:1527268265284};\\\", \\\"{x:501,y:618,t:1527268265300};\\\", \\\"{x:509,y:607,t:1527268265316};\\\", \\\"{x:517,y:599,t:1527268265334};\\\", \\\"{x:523,y:594,t:1527268265351};\\\", \\\"{x:533,y:585,t:1527268265367};\\\", \\\"{x:544,y:579,t:1527268265384};\\\", \\\"{x:554,y:572,t:1527268265401};\\\", \\\"{x:561,y:566,t:1527268265417};\\\", \\\"{x:569,y:562,t:1527268265433};\\\", \\\"{x:575,y:560,t:1527268265450};\\\", \\\"{x:579,y:556,t:1527268265468};\\\", \\\"{x:583,y:554,t:1527268265484};\\\", \\\"{x:591,y:549,t:1527268265501};\\\", \\\"{x:599,y:547,t:1527268265516};\\\", \\\"{x:606,y:544,t:1527268265534};\\\", \\\"{x:617,y:540,t:1527268265550};\\\", \\\"{x:627,y:536,t:1527268265567};\\\", \\\"{x:644,y:532,t:1527268265584};\\\", \\\"{x:663,y:527,t:1527268265600};\\\", \\\"{x:682,y:521,t:1527268265617};\\\", \\\"{x:703,y:516,t:1527268265634};\\\", \\\"{x:724,y:513,t:1527268265651};\\\", \\\"{x:741,y:510,t:1527268265668};\\\", \\\"{x:756,y:508,t:1527268265684};\\\", \\\"{x:777,y:502,t:1527268265700};\\\", \\\"{x:790,y:497,t:1527268265718};\\\", \\\"{x:803,y:491,t:1527268265734};\\\", \\\"{x:819,y:485,t:1527268265765};\\\", \\\"{x:822,y:485,t:1527268265772};\\\", \\\"{x:824,y:485,t:1527268265783};\\\", \\\"{x:831,y:485,t:1527268265800};\\\", \\\"{x:837,y:487,t:1527268265818};\\\", \\\"{x:843,y:489,t:1527268265834};\\\", \\\"{x:848,y:490,t:1527268265851};\\\", \\\"{x:851,y:491,t:1527268265868};\\\", \\\"{x:852,y:492,t:1527268265884};\\\", \\\"{x:853,y:493,t:1527268265900};\\\", \\\"{x:855,y:495,t:1527268265917};\\\", \\\"{x:855,y:498,t:1527268265934};\\\", \\\"{x:859,y:504,t:1527268265951};\\\", \\\"{x:864,y:514,t:1527268265968};\\\", \\\"{x:868,y:522,t:1527268265984};\\\", \\\"{x:873,y:534,t:1527268266000};\\\", \\\"{x:879,y:546,t:1527268266018};\\\", \\\"{x:884,y:561,t:1527268266034};\\\", \\\"{x:889,y:573,t:1527268266050};\\\", \\\"{x:893,y:586,t:1527268266067};\\\", \\\"{x:896,y:599,t:1527268266084};\\\", \\\"{x:903,y:620,t:1527268266101};\\\", \\\"{x:904,y:631,t:1527268266119};\\\", \\\"{x:902,y:644,t:1527268266135};\\\", \\\"{x:897,y:657,t:1527268266151};\\\", \\\"{x:891,y:672,t:1527268266168};\\\", \\\"{x:886,y:685,t:1527268266185};\\\", \\\"{x:881,y:696,t:1527268266201};\\\", \\\"{x:879,y:705,t:1527268266218};\\\", \\\"{x:875,y:713,t:1527268266235};\\\", \\\"{x:870,y:720,t:1527268266251};\\\", \\\"{x:862,y:737,t:1527268266268};\\\", \\\"{x:853,y:750,t:1527268266284};\\\", \\\"{x:847,y:765,t:1527268266301};\\\", \\\"{x:842,y:778,t:1527268266318};\\\", \\\"{x:835,y:794,t:1527268266335};\\\", \\\"{x:829,y:807,t:1527268266351};\\\", \\\"{x:825,y:817,t:1527268266368};\\\", \\\"{x:822,y:825,t:1527268266385};\\\", \\\"{x:818,y:832,t:1527268266401};\\\", \\\"{x:818,y:835,t:1527268266418};\\\", \\\"{x:816,y:841,t:1527268266435};\\\", \\\"{x:813,y:847,t:1527268266452};\\\", \\\"{x:812,y:852,t:1527268266468};\\\", \\\"{x:812,y:853,t:1527268266484};\\\", \\\"{x:811,y:855,t:1527268266502};\\\", \\\"{x:810,y:857,t:1527268266518};\\\", \\\"{x:809,y:859,t:1527268266535};\\\", \\\"{x:808,y:860,t:1527268266596};\\\", \\\"{x:807,y:862,t:1527268268677};\\\", \\\"{x:805,y:863,t:1527268268687};\\\", \\\"{x:798,y:865,t:1527268268702};\\\", \\\"{x:795,y:866,t:1527268268720};\\\", \\\"{x:791,y:866,t:1527268268737};\\\", \\\"{x:790,y:866,t:1527268268754};\\\", \\\"{x:789,y:866,t:1527268268771};\\\", \\\"{x:788,y:866,t:1527268268788};\\\", \\\"{x:787,y:866,t:1527268270437};\\\", \\\"{x:784,y:865,t:1527268270455};\\\", \\\"{x:782,y:862,t:1527268270473};\\\", \\\"{x:782,y:861,t:1527268270488};\\\", \\\"{x:781,y:861,t:1527268270505};\\\", \\\"{x:781,y:860,t:1527268270522};\\\", \\\"{x:780,y:859,t:1527268270538};\\\", \\\"{x:780,y:858,t:1527268270933};\\\", \\\"{x:780,y:857,t:1527268270989};\\\", \\\"{x:780,y:856,t:1527268271006};\\\", \\\"{x:780,y:855,t:1527268271037};\\\", \\\"{x:780,y:854,t:1527268271092};\\\", \\\"{x:780,y:853,t:1527268271228};\\\", \\\"{x:780,y:852,t:1527268271252};\\\", \\\"{x:780,y:850,t:1527268271260};\\\", \\\"{x:780,y:848,t:1527268271276};\\\", \\\"{x:780,y:846,t:1527268271289};\\\", \\\"{x:782,y:840,t:1527268271306};\\\", \\\"{x:783,y:830,t:1527268271322};\\\", \\\"{x:784,y:820,t:1527268271339};\\\", \\\"{x:788,y:807,t:1527268271356};\\\", \\\"{x:789,y:798,t:1527268271372};\\\", \\\"{x:790,y:793,t:1527268271389};\\\", \\\"{x:791,y:788,t:1527268271406};\\\", \\\"{x:792,y:784,t:1527268271422};\\\", \\\"{x:796,y:777,t:1527268271439};\\\", \\\"{x:798,y:771,t:1527268271456};\\\", \\\"{x:803,y:763,t:1527268271473};\\\", \\\"{x:808,y:755,t:1527268271489};\\\", \\\"{x:817,y:746,t:1527268271506};\\\", \\\"{x:831,y:734,t:1527268271522};\\\", \\\"{x:845,y:715,t:1527268271539};\\\", \\\"{x:871,y:681,t:1527268271555};\\\", \\\"{x:896,y:665,t:1527268271573};\\\", \\\"{x:923,y:647,t:1527268271589};\\\", \\\"{x:956,y:628,t:1527268271606};\\\", \\\"{x:982,y:614,t:1527268271623};\\\", \\\"{x:1005,y:603,t:1527268271639};\\\", \\\"{x:1032,y:593,t:1527268271656};\\\", \\\"{x:1063,y:585,t:1527268271672};\\\", \\\"{x:1091,y:581,t:1527268271689};\\\", \\\"{x:1120,y:580,t:1527268271706};\\\", \\\"{x:1143,y:580,t:1527268271722};\\\", \\\"{x:1164,y:579,t:1527268271740};\\\", \\\"{x:1176,y:579,t:1527268271756};\\\", \\\"{x:1182,y:577,t:1527268271773};\\\", \\\"{x:1184,y:576,t:1527268271790};\\\", \\\"{x:1185,y:576,t:1527268271806};\\\", \\\"{x:1187,y:575,t:1527268271823};\\\", \\\"{x:1204,y:570,t:1527268271840};\\\", \\\"{x:1236,y:553,t:1527268271856};\\\", \\\"{x:1272,y:528,t:1527268271873};\\\", \\\"{x:1285,y:515,t:1527268271890};\\\", \\\"{x:1297,y:503,t:1527268271906};\\\", \\\"{x:1301,y:494,t:1527268271924};\\\", \\\"{x:1304,y:487,t:1527268271940};\\\", \\\"{x:1304,y:484,t:1527268271956};\\\", \\\"{x:1304,y:482,t:1527268271973};\\\", \\\"{x:1305,y:477,t:1527268271991};\\\", \\\"{x:1308,y:466,t:1527268272006};\\\", \\\"{x:1314,y:456,t:1527268272024};\\\", \\\"{x:1316,y:450,t:1527268272040};\\\", \\\"{x:1318,y:447,t:1527268272056};\\\", \\\"{x:1318,y:449,t:1527268272173};\\\", \\\"{x:1318,y:453,t:1527268272190};\\\", \\\"{x:1317,y:459,t:1527268272207};\\\", \\\"{x:1316,y:465,t:1527268272223};\\\", \\\"{x:1316,y:469,t:1527268272240};\\\", \\\"{x:1312,y:476,t:1527268272257};\\\", \\\"{x:1311,y:480,t:1527268272273};\\\", \\\"{x:1309,y:484,t:1527268272291};\\\", \\\"{x:1308,y:489,t:1527268272307};\\\", \\\"{x:1307,y:492,t:1527268272323};\\\", \\\"{x:1305,y:496,t:1527268272340};\\\", \\\"{x:1305,y:497,t:1527268272357};\\\", \\\"{x:1304,y:498,t:1527268272373};\\\", \\\"{x:1304,y:499,t:1527268272396};\\\", \\\"{x:1304,y:500,t:1527268272407};\\\", \\\"{x:1304,y:502,t:1527268272423};\\\", \\\"{x:1304,y:501,t:1527268272765};\\\", \\\"{x:1306,y:500,t:1527268272788};\\\", \\\"{x:1306,y:499,t:1527268272797};\\\", \\\"{x:1308,y:498,t:1527268272807};\\\", \\\"{x:1310,y:495,t:1527268272825};\\\", \\\"{x:1312,y:495,t:1527268272840};\\\", \\\"{x:1313,y:494,t:1527268272857};\\\", \\\"{x:1314,y:494,t:1527268283431};\\\", \\\"{x:1314,y:497,t:1527268283448};\\\", \\\"{x:1314,y:500,t:1527268283455};\\\", \\\"{x:1314,y:502,t:1527268283470};\\\", \\\"{x:1314,y:505,t:1527268283488};\\\", \\\"{x:1314,y:509,t:1527268283504};\\\", \\\"{x:1314,y:511,t:1527268283520};\\\", \\\"{x:1314,y:512,t:1527268283537};\\\", \\\"{x:1314,y:513,t:1527268283568};\\\", \\\"{x:1314,y:514,t:1527268283583};\\\", \\\"{x:1314,y:515,t:1527268283600};\\\", \\\"{x:1314,y:516,t:1527268283615};\\\", \\\"{x:1314,y:517,t:1527268283631};\\\", \\\"{x:1314,y:518,t:1527268283639};\\\", \\\"{x:1314,y:519,t:1527268283663};\\\", \\\"{x:1314,y:520,t:1527268283680};\\\", \\\"{x:1314,y:521,t:1527268283696};\\\", \\\"{x:1314,y:522,t:1527268283720};\\\", \\\"{x:1315,y:524,t:1527268283743};\\\", \\\"{x:1315,y:525,t:1527268283792};\\\", \\\"{x:1315,y:526,t:1527268283804};\\\", \\\"{x:1315,y:527,t:1527268283821};\\\", \\\"{x:1315,y:528,t:1527268283837};\\\", \\\"{x:1315,y:530,t:1527268283855};\\\", \\\"{x:1315,y:531,t:1527268283871};\\\", \\\"{x:1315,y:533,t:1527268283887};\\\", \\\"{x:1315,y:536,t:1527268283904};\\\", \\\"{x:1316,y:539,t:1527268283921};\\\", \\\"{x:1317,y:541,t:1527268283937};\\\", \\\"{x:1318,y:543,t:1527268283954};\\\", \\\"{x:1319,y:546,t:1527268283971};\\\", \\\"{x:1319,y:548,t:1527268283988};\\\", \\\"{x:1321,y:550,t:1527268284004};\\\", \\\"{x:1322,y:553,t:1527268284021};\\\", \\\"{x:1324,y:556,t:1527268284038};\\\", \\\"{x:1326,y:560,t:1527268284054};\\\", \\\"{x:1327,y:562,t:1527268284071};\\\", \\\"{x:1329,y:566,t:1527268284087};\\\", \\\"{x:1331,y:568,t:1527268284104};\\\", \\\"{x:1332,y:570,t:1527268284121};\\\", \\\"{x:1333,y:571,t:1527268284139};\\\", \\\"{x:1334,y:572,t:1527268284154};\\\", \\\"{x:1335,y:573,t:1527268284172};\\\", \\\"{x:1335,y:574,t:1527268284189};\\\", \\\"{x:1336,y:575,t:1527268284232};\\\", \\\"{x:1336,y:576,t:1527268284272};\\\", \\\"{x:1337,y:577,t:1527268284329};\\\", \\\"{x:1337,y:578,t:1527268284433};\\\", \\\"{x:1338,y:579,t:1527268284441};\\\", \\\"{x:1338,y:580,t:1527268284480};\\\", \\\"{x:1338,y:581,t:1527268284496};\\\", \\\"{x:1338,y:582,t:1527268284506};\\\", \\\"{x:1338,y:583,t:1527268284522};\\\", \\\"{x:1338,y:584,t:1527268284539};\\\", \\\"{x:1338,y:585,t:1527268284556};\\\", \\\"{x:1338,y:587,t:1527268284572};\\\", \\\"{x:1338,y:588,t:1527268284589};\\\", \\\"{x:1338,y:589,t:1527268284609};\\\", \\\"{x:1338,y:590,t:1527268284625};\\\", \\\"{x:1338,y:591,t:1527268284640};\\\", \\\"{x:1338,y:592,t:1527268284673};\\\", \\\"{x:1338,y:593,t:1527268284696};\\\", \\\"{x:1338,y:594,t:1527268284712};\\\", \\\"{x:1338,y:595,t:1527268284744};\\\", \\\"{x:1338,y:596,t:1527268284761};\\\", \\\"{x:1338,y:597,t:1527268284809};\\\", \\\"{x:1338,y:598,t:1527268284824};\\\", \\\"{x:1338,y:599,t:1527268284849};\\\", \\\"{x:1337,y:601,t:1527268284864};\\\", \\\"{x:1337,y:603,t:1527268284896};\\\", \\\"{x:1336,y:605,t:1527268284929};\\\", \\\"{x:1336,y:606,t:1527268284953};\\\", \\\"{x:1336,y:607,t:1527268284969};\\\", \\\"{x:1335,y:608,t:1527268284976};\\\", \\\"{x:1335,y:609,t:1527268285008};\\\", \\\"{x:1334,y:610,t:1527268285032};\\\", \\\"{x:1334,y:611,t:1527268285057};\\\", \\\"{x:1333,y:612,t:1527268285072};\\\", \\\"{x:1333,y:613,t:1527268285089};\\\", \\\"{x:1333,y:614,t:1527268285106};\\\", \\\"{x:1332,y:616,t:1527268285122};\\\", \\\"{x:1330,y:620,t:1527268285139};\\\", \\\"{x:1329,y:623,t:1527268285156};\\\", \\\"{x:1327,y:625,t:1527268285173};\\\", \\\"{x:1327,y:626,t:1527268285189};\\\", \\\"{x:1327,y:627,t:1527268285205};\\\", \\\"{x:1327,y:628,t:1527268285223};\\\", \\\"{x:1327,y:629,t:1527268285239};\\\", \\\"{x:1327,y:630,t:1527268285256};\\\", \\\"{x:1327,y:632,t:1527268285272};\\\", \\\"{x:1326,y:632,t:1527268285289};\\\", \\\"{x:1326,y:634,t:1527268285305};\\\", \\\"{x:1326,y:635,t:1527268285323};\\\", \\\"{x:1326,y:637,t:1527268285339};\\\", \\\"{x:1325,y:639,t:1527268285356};\\\", \\\"{x:1325,y:640,t:1527268285375};\\\", \\\"{x:1325,y:641,t:1527268285391};\\\", \\\"{x:1325,y:642,t:1527268285407};\\\", \\\"{x:1324,y:643,t:1527268285431};\\\", \\\"{x:1324,y:644,t:1527268285448};\\\", \\\"{x:1324,y:645,t:1527268285456};\\\", \\\"{x:1324,y:646,t:1527268285472};\\\", \\\"{x:1323,y:648,t:1527268285489};\\\", \\\"{x:1323,y:650,t:1527268285506};\\\", \\\"{x:1323,y:653,t:1527268285522};\\\", \\\"{x:1321,y:654,t:1527268285540};\\\", \\\"{x:1321,y:656,t:1527268285556};\\\", \\\"{x:1321,y:658,t:1527268285584};\\\", \\\"{x:1321,y:659,t:1527268285616};\\\", \\\"{x:1321,y:661,t:1527268285624};\\\", \\\"{x:1321,y:662,t:1527268285639};\\\", \\\"{x:1321,y:675,t:1527268285656};\\\", \\\"{x:1321,y:683,t:1527268285672};\\\", \\\"{x:1321,y:692,t:1527268285689};\\\", \\\"{x:1321,y:701,t:1527268285706};\\\", \\\"{x:1321,y:709,t:1527268285723};\\\", \\\"{x:1321,y:710,t:1527268285739};\\\", \\\"{x:1321,y:712,t:1527268285756};\\\", \\\"{x:1321,y:714,t:1527268285773};\\\", \\\"{x:1321,y:715,t:1527268285789};\\\", \\\"{x:1321,y:717,t:1527268285807};\\\", \\\"{x:1320,y:718,t:1527268285823};\\\", \\\"{x:1309,y:725,t:1527268285840};\\\", \\\"{x:1298,y:728,t:1527268285856};\\\", \\\"{x:1276,y:733,t:1527268285873};\\\", \\\"{x:1239,y:738,t:1527268285890};\\\", \\\"{x:1188,y:739,t:1527268285907};\\\", \\\"{x:1110,y:739,t:1527268285923};\\\", \\\"{x:1029,y:739,t:1527268285939};\\\", \\\"{x:932,y:727,t:1527268285956};\\\", \\\"{x:827,y:713,t:1527268285974};\\\", \\\"{x:738,y:697,t:1527268285989};\\\", \\\"{x:657,y:687,t:1527268286006};\\\", \\\"{x:569,y:675,t:1527268286024};\\\", \\\"{x:534,y:670,t:1527268286039};\\\", \\\"{x:515,y:667,t:1527268286056};\\\", \\\"{x:506,y:666,t:1527268286073};\\\", \\\"{x:504,y:665,t:1527268286089};\\\", \\\"{x:503,y:665,t:1527268286106};\\\", \\\"{x:503,y:664,t:1527268286124};\\\", \\\"{x:505,y:654,t:1527268286139};\\\", \\\"{x:520,y:634,t:1527268286156};\\\", \\\"{x:538,y:613,t:1527268286172};\\\", \\\"{x:574,y:586,t:1527268286188};\\\", \\\"{x:619,y:563,t:1527268286205};\\\", \\\"{x:676,y:545,t:1527268286222};\\\", \\\"{x:719,y:536,t:1527268286237};\\\", \\\"{x:757,y:532,t:1527268286254};\\\", \\\"{x:807,y:532,t:1527268286271};\\\", \\\"{x:842,y:535,t:1527268286287};\\\", \\\"{x:878,y:540,t:1527268286304};\\\", \\\"{x:908,y:546,t:1527268286321};\\\", \\\"{x:936,y:551,t:1527268286337};\\\", \\\"{x:957,y:556,t:1527268286354};\\\", \\\"{x:967,y:557,t:1527268286371};\\\", \\\"{x:969,y:557,t:1527268286387};\\\", \\\"{x:966,y:560,t:1527268286456};\\\", \\\"{x:962,y:561,t:1527268286471};\\\", \\\"{x:956,y:562,t:1527268286488};\\\", \\\"{x:943,y:564,t:1527268286505};\\\", \\\"{x:928,y:564,t:1527268286521};\\\", \\\"{x:911,y:564,t:1527268286537};\\\", \\\"{x:900,y:564,t:1527268286554};\\\", \\\"{x:886,y:563,t:1527268286572};\\\", \\\"{x:873,y:562,t:1527268286587};\\\", \\\"{x:862,y:559,t:1527268286604};\\\", \\\"{x:856,y:558,t:1527268286622};\\\", \\\"{x:854,y:557,t:1527268286638};\\\", \\\"{x:850,y:556,t:1527268286654};\\\", \\\"{x:847,y:555,t:1527268286672};\\\", \\\"{x:845,y:554,t:1527268286689};\\\", \\\"{x:840,y:551,t:1527268286704};\\\", \\\"{x:836,y:549,t:1527268286722};\\\", \\\"{x:833,y:546,t:1527268286738};\\\", \\\"{x:831,y:545,t:1527268286754};\\\", \\\"{x:829,y:543,t:1527268286771};\\\", \\\"{x:829,y:542,t:1527268286788};\\\", \\\"{x:829,y:540,t:1527268286804};\\\", \\\"{x:829,y:539,t:1527268286821};\\\", \\\"{x:829,y:538,t:1527268286838};\\\", \\\"{x:829,y:537,t:1527268286855};\\\", \\\"{x:829,y:536,t:1527268286871};\\\", \\\"{x:830,y:535,t:1527268286921};\\\", \\\"{x:835,y:535,t:1527268286938};\\\", \\\"{x:837,y:535,t:1527268286955};\\\", \\\"{x:837,y:535,t:1527268287003};\\\", \\\"{x:834,y:537,t:1527268287144};\\\", \\\"{x:831,y:539,t:1527268287156};\\\", \\\"{x:817,y:551,t:1527268287172};\\\", \\\"{x:801,y:562,t:1527268287189};\\\", \\\"{x:781,y:576,t:1527268287206};\\\", \\\"{x:746,y:599,t:1527268287222};\\\", \\\"{x:701,y:620,t:1527268287239};\\\", \\\"{x:619,y:659,t:1527268287256};\\\", \\\"{x:537,y:704,t:1527268287272};\\\", \\\"{x:453,y:747,t:1527268287289};\\\", \\\"{x:390,y:775,t:1527268287306};\\\", \\\"{x:340,y:796,t:1527268287322};\\\", \\\"{x:307,y:805,t:1527268287338};\\\", \\\"{x:287,y:808,t:1527268287356};\\\", \\\"{x:279,y:808,t:1527268287372};\\\", \\\"{x:278,y:808,t:1527268287391};\\\", \\\"{x:278,y:805,t:1527268287407};\\\", \\\"{x:278,y:802,t:1527268287421};\\\", \\\"{x:278,y:794,t:1527268287438};\\\", \\\"{x:278,y:787,t:1527268287456};\\\", \\\"{x:278,y:786,t:1527268287473};\\\", \\\"{x:278,y:784,t:1527268287489};\\\", \\\"{x:280,y:780,t:1527268287505};\\\", \\\"{x:281,y:777,t:1527268287523};\\\", \\\"{x:285,y:774,t:1527268287538};\\\", \\\"{x:289,y:772,t:1527268287555};\\\", \\\"{x:298,y:770,t:1527268287573};\\\", \\\"{x:316,y:767,t:1527268287589};\\\", \\\"{x:346,y:766,t:1527268287605};\\\", \\\"{x:394,y:766,t:1527268287623};\\\", \\\"{x:444,y:766,t:1527268287638};\\\", \\\"{x:503,y:766,t:1527268287656};\\\", \\\"{x:525,y:766,t:1527268287671};\\\", \\\"{x:533,y:766,t:1527268287689};\\\", \\\"{x:535,y:766,t:1527268287706};\\\", \\\"{x:536,y:766,t:1527268287723};\\\", \\\"{x:536,y:764,t:1527268287824};\\\", \\\"{x:536,y:763,t:1527268287838};\\\", \\\"{x:535,y:760,t:1527268287856};\\\", \\\"{x:532,y:756,t:1527268287872};\\\", \\\"{x:529,y:749,t:1527268287890};\\\", \\\"{x:521,y:737,t:1527268287906};\\\", \\\"{x:512,y:730,t:1527268287923};\\\", \\\"{x:506,y:725,t:1527268287940};\\\", \\\"{x:500,y:724,t:1527268287957};\\\", \\\"{x:499,y:724,t:1527268287972};\\\", \\\"{x:499,y:723,t:1527268288432};\\\", \\\"{x:499,y:722,t:1527268288439};\\\", \\\"{x:500,y:721,t:1527268288455};\\\", \\\"{x:500,y:720,t:1527268288472};\\\" ] }, { \\\"rt\\\": 7326, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 320796, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:719,t:1527268290994};\\\", \\\"{x:521,y:707,t:1527268291010};\\\", \\\"{x:575,y:666,t:1527268291024};\\\", \\\"{x:666,y:609,t:1527268291042};\\\", \\\"{x:810,y:505,t:1527268291059};\\\", \\\"{x:899,y:452,t:1527268291074};\\\", \\\"{x:925,y:434,t:1527268291092};\\\", \\\"{x:939,y:425,t:1527268291109};\\\", \\\"{x:954,y:419,t:1527268291124};\\\", \\\"{x:961,y:416,t:1527268291141};\\\", \\\"{x:963,y:415,t:1527268291159};\\\", \\\"{x:966,y:408,t:1527268291175};\\\", \\\"{x:969,y:400,t:1527268291191};\\\", \\\"{x:969,y:398,t:1527268291208};\\\", \\\"{x:969,y:397,t:1527268291224};\\\", \\\"{x:969,y:396,t:1527268291241};\\\", \\\"{x:969,y:395,t:1527268291263};\\\", \\\"{x:969,y:394,t:1527268291295};\\\", \\\"{x:969,y:391,t:1527268291309};\\\", \\\"{x:963,y:382,t:1527268291325};\\\", \\\"{x:953,y:371,t:1527268291342};\\\", \\\"{x:940,y:360,t:1527268291359};\\\", \\\"{x:921,y:348,t:1527268291376};\\\", \\\"{x:902,y:338,t:1527268291391};\\\", \\\"{x:881,y:329,t:1527268291408};\\\", \\\"{x:856,y:321,t:1527268291425};\\\", \\\"{x:825,y:314,t:1527268291442};\\\", \\\"{x:787,y:300,t:1527268291459};\\\", \\\"{x:761,y:294,t:1527268291476};\\\", \\\"{x:732,y:290,t:1527268291491};\\\", \\\"{x:700,y:286,t:1527268291509};\\\", \\\"{x:666,y:280,t:1527268291525};\\\", \\\"{x:616,y:280,t:1527268291541};\\\", \\\"{x:560,y:280,t:1527268291558};\\\", \\\"{x:460,y:288,t:1527268291576};\\\", \\\"{x:402,y:296,t:1527268291591};\\\", \\\"{x:348,y:304,t:1527268291609};\\\", \\\"{x:303,y:311,t:1527268291625};\\\", \\\"{x:279,y:318,t:1527268291641};\\\", \\\"{x:262,y:325,t:1527268291658};\\\", \\\"{x:250,y:332,t:1527268291676};\\\", \\\"{x:244,y:339,t:1527268291691};\\\", \\\"{x:239,y:345,t:1527268291709};\\\", \\\"{x:236,y:355,t:1527268291726};\\\", \\\"{x:233,y:369,t:1527268291741};\\\", \\\"{x:231,y:383,t:1527268291758};\\\", \\\"{x:231,y:400,t:1527268291776};\\\", \\\"{x:231,y:412,t:1527268291793};\\\", \\\"{x:237,y:424,t:1527268291809};\\\", \\\"{x:243,y:434,t:1527268291826};\\\", \\\"{x:255,y:447,t:1527268291842};\\\", \\\"{x:272,y:460,t:1527268291859};\\\", \\\"{x:295,y:473,t:1527268291876};\\\", \\\"{x:323,y:487,t:1527268291894};\\\", \\\"{x:367,y:506,t:1527268291909};\\\", \\\"{x:416,y:523,t:1527268291925};\\\", \\\"{x:474,y:541,t:1527268291941};\\\", \\\"{x:546,y:559,t:1527268291959};\\\", \\\"{x:662,y:576,t:1527268291976};\\\", \\\"{x:739,y:586,t:1527268291994};\\\", \\\"{x:818,y:588,t:1527268292009};\\\", \\\"{x:907,y:588,t:1527268292026};\\\", \\\"{x:976,y:588,t:1527268292043};\\\", \\\"{x:1052,y:575,t:1527268292058};\\\", \\\"{x:1140,y:542,t:1527268292076};\\\", \\\"{x:1234,y:493,t:1527268292092};\\\", \\\"{x:1339,y:428,t:1527268292109};\\\", \\\"{x:1424,y:381,t:1527268292126};\\\", \\\"{x:1477,y:353,t:1527268292141};\\\", \\\"{x:1507,y:334,t:1527268292159};\\\", \\\"{x:1521,y:324,t:1527268292176};\\\", \\\"{x:1522,y:323,t:1527268292192};\\\", \\\"{x:1522,y:322,t:1527268292209};\\\", \\\"{x:1522,y:321,t:1527268292225};\\\", \\\"{x:1522,y:320,t:1527268292242};\\\", \\\"{x:1518,y:317,t:1527268292258};\\\", \\\"{x:1501,y:312,t:1527268292275};\\\", \\\"{x:1474,y:311,t:1527268292292};\\\", \\\"{x:1444,y:311,t:1527268292308};\\\", \\\"{x:1419,y:319,t:1527268292325};\\\", \\\"{x:1393,y:331,t:1527268292342};\\\", \\\"{x:1359,y:350,t:1527268292358};\\\", \\\"{x:1320,y:376,t:1527268292375};\\\", \\\"{x:1253,y:435,t:1527268292392};\\\", \\\"{x:1222,y:473,t:1527268292409};\\\", \\\"{x:1199,y:509,t:1527268292425};\\\", \\\"{x:1189,y:530,t:1527268292441};\\\", \\\"{x:1187,y:535,t:1527268292457};\\\", \\\"{x:1187,y:536,t:1527268292475};\\\", \\\"{x:1187,y:537,t:1527268292640};\\\", \\\"{x:1193,y:541,t:1527268292658};\\\", \\\"{x:1207,y:548,t:1527268292674};\\\", \\\"{x:1231,y:553,t:1527268292691};\\\", \\\"{x:1261,y:559,t:1527268292707};\\\", \\\"{x:1290,y:564,t:1527268292723};\\\", \\\"{x:1321,y:564,t:1527268292741};\\\", \\\"{x:1351,y:564,t:1527268292757};\\\", \\\"{x:1370,y:564,t:1527268292774};\\\", \\\"{x:1377,y:564,t:1527268292791};\\\", \\\"{x:1383,y:563,t:1527268292808};\\\", \\\"{x:1385,y:563,t:1527268292824};\\\", \\\"{x:1390,y:561,t:1527268292840};\\\", \\\"{x:1395,y:557,t:1527268292856};\\\", \\\"{x:1407,y:550,t:1527268292874};\\\", \\\"{x:1422,y:544,t:1527268292890};\\\", \\\"{x:1438,y:539,t:1527268292907};\\\", \\\"{x:1451,y:534,t:1527268292923};\\\", \\\"{x:1460,y:530,t:1527268292940};\\\", \\\"{x:1466,y:529,t:1527268292957};\\\", \\\"{x:1471,y:528,t:1527268292973};\\\", \\\"{x:1477,y:527,t:1527268292990};\\\", \\\"{x:1490,y:527,t:1527268293008};\\\", \\\"{x:1495,y:527,t:1527268293023};\\\", \\\"{x:1515,y:527,t:1527268293039};\\\", \\\"{x:1533,y:527,t:1527268293056};\\\", \\\"{x:1553,y:527,t:1527268293073};\\\", \\\"{x:1575,y:527,t:1527268293090};\\\", \\\"{x:1597,y:527,t:1527268293105};\\\", \\\"{x:1620,y:529,t:1527268293123};\\\", \\\"{x:1642,y:534,t:1527268293140};\\\", \\\"{x:1658,y:537,t:1527268293156};\\\", \\\"{x:1665,y:537,t:1527268293173};\\\", \\\"{x:1666,y:537,t:1527268293189};\\\", \\\"{x:1666,y:538,t:1527268293240};\\\", \\\"{x:1656,y:542,t:1527268293256};\\\", \\\"{x:1638,y:549,t:1527268293272};\\\", \\\"{x:1601,y:555,t:1527268293289};\\\", \\\"{x:1543,y:561,t:1527268293306};\\\", \\\"{x:1454,y:563,t:1527268293322};\\\", \\\"{x:1331,y:569,t:1527268293339};\\\", \\\"{x:1190,y:569,t:1527268293356};\\\", \\\"{x:1040,y:569,t:1527268293372};\\\", \\\"{x:875,y:569,t:1527268293390};\\\", \\\"{x:720,y:569,t:1527268293407};\\\", \\\"{x:524,y:577,t:1527268293427};\\\", \\\"{x:428,y:587,t:1527268293444};\\\", \\\"{x:398,y:595,t:1527268293460};\\\", \\\"{x:384,y:600,t:1527268293476};\\\", \\\"{x:381,y:602,t:1527268293494};\\\", \\\"{x:380,y:603,t:1527268293510};\\\", \\\"{x:379,y:603,t:1527268293526};\\\", \\\"{x:376,y:603,t:1527268293639};\\\", \\\"{x:371,y:593,t:1527268293648};\\\", \\\"{x:368,y:582,t:1527268293660};\\\", \\\"{x:365,y:563,t:1527268293676};\\\", \\\"{x:365,y:550,t:1527268293694};\\\", \\\"{x:365,y:537,t:1527268293710};\\\", \\\"{x:365,y:531,t:1527268293727};\\\", \\\"{x:365,y:529,t:1527268293744};\\\", \\\"{x:365,y:528,t:1527268293784};\\\", \\\"{x:366,y:528,t:1527268293840};\\\", \\\"{x:367,y:529,t:1527268293848};\\\", \\\"{x:368,y:532,t:1527268293861};\\\", \\\"{x:374,y:540,t:1527268293876};\\\", \\\"{x:382,y:552,t:1527268293893};\\\", \\\"{x:391,y:563,t:1527268293911};\\\", \\\"{x:397,y:569,t:1527268293927};\\\", \\\"{x:400,y:573,t:1527268293943};\\\", \\\"{x:401,y:574,t:1527268293960};\\\", \\\"{x:401,y:575,t:1527268294104};\\\", \\\"{x:401,y:577,t:1527268294112};\\\", \\\"{x:394,y:579,t:1527268294128};\\\", \\\"{x:386,y:583,t:1527268294145};\\\", \\\"{x:377,y:586,t:1527268294160};\\\", \\\"{x:369,y:590,t:1527268294178};\\\", \\\"{x:363,y:591,t:1527268294195};\\\", \\\"{x:361,y:591,t:1527268294210};\\\", \\\"{x:356,y:591,t:1527268294228};\\\", \\\"{x:343,y:584,t:1527268294245};\\\", \\\"{x:320,y:570,t:1527268294261};\\\", \\\"{x:289,y:557,t:1527268294278};\\\", \\\"{x:243,y:539,t:1527268294295};\\\", \\\"{x:196,y:518,t:1527268294311};\\\", \\\"{x:130,y:496,t:1527268294327};\\\", \\\"{x:103,y:486,t:1527268294344};\\\", \\\"{x:92,y:484,t:1527268294360};\\\", \\\"{x:86,y:484,t:1527268294377};\\\", \\\"{x:84,y:484,t:1527268294394};\\\", \\\"{x:80,y:485,t:1527268294410};\\\", \\\"{x:74,y:490,t:1527268294428};\\\", \\\"{x:68,y:495,t:1527268294444};\\\", \\\"{x:67,y:498,t:1527268294460};\\\", \\\"{x:67,y:502,t:1527268294478};\\\", \\\"{x:67,y:507,t:1527268294495};\\\", \\\"{x:67,y:511,t:1527268294510};\\\", \\\"{x:68,y:515,t:1527268294527};\\\", \\\"{x:71,y:519,t:1527268294546};\\\", \\\"{x:76,y:523,t:1527268294561};\\\", \\\"{x:83,y:529,t:1527268294578};\\\", \\\"{x:93,y:536,t:1527268294594};\\\", \\\"{x:104,y:542,t:1527268294611};\\\", \\\"{x:117,y:549,t:1527268294628};\\\", \\\"{x:142,y:557,t:1527268294645};\\\", \\\"{x:174,y:564,t:1527268294661};\\\", \\\"{x:227,y:572,t:1527268294677};\\\", \\\"{x:297,y:582,t:1527268294695};\\\", \\\"{x:375,y:582,t:1527268294711};\\\", \\\"{x:494,y:582,t:1527268294728};\\\", \\\"{x:557,y:579,t:1527268294746};\\\", \\\"{x:605,y:565,t:1527268294760};\\\", \\\"{x:635,y:557,t:1527268294778};\\\", \\\"{x:648,y:551,t:1527268294795};\\\", \\\"{x:654,y:548,t:1527268294811};\\\", \\\"{x:656,y:546,t:1527268294828};\\\", \\\"{x:659,y:543,t:1527268294845};\\\", \\\"{x:661,y:540,t:1527268294861};\\\", \\\"{x:663,y:537,t:1527268294877};\\\", \\\"{x:665,y:534,t:1527268294894};\\\", \\\"{x:666,y:531,t:1527268294911};\\\", \\\"{x:667,y:527,t:1527268294928};\\\", \\\"{x:667,y:523,t:1527268294945};\\\", \\\"{x:667,y:520,t:1527268294961};\\\", \\\"{x:667,y:516,t:1527268294979};\\\", \\\"{x:664,y:508,t:1527268294994};\\\", \\\"{x:655,y:498,t:1527268295012};\\\", \\\"{x:640,y:492,t:1527268295028};\\\", \\\"{x:625,y:487,t:1527268295045};\\\", \\\"{x:616,y:487,t:1527268295062};\\\", \\\"{x:613,y:487,t:1527268295078};\\\", \\\"{x:612,y:487,t:1527268295094};\\\", \\\"{x:611,y:487,t:1527268295161};\\\", \\\"{x:611,y:488,t:1527268295192};\\\", \\\"{x:611,y:490,t:1527268295200};\\\", \\\"{x:611,y:491,t:1527268295212};\\\", \\\"{x:611,y:495,t:1527268295228};\\\", \\\"{x:611,y:500,t:1527268295244};\\\", \\\"{x:611,y:504,t:1527268295262};\\\", \\\"{x:611,y:505,t:1527268295351};\\\", \\\"{x:610,y:506,t:1527268295584};\\\", \\\"{x:605,y:511,t:1527268295594};\\\", \\\"{x:587,y:532,t:1527268295612};\\\", \\\"{x:564,y:558,t:1527268295629};\\\", \\\"{x:543,y:582,t:1527268295645};\\\", \\\"{x:512,y:610,t:1527268295662};\\\", \\\"{x:485,y:634,t:1527268295679};\\\", \\\"{x:455,y:650,t:1527268295695};\\\", \\\"{x:420,y:664,t:1527268295711};\\\", \\\"{x:398,y:666,t:1527268295728};\\\", \\\"{x:371,y:666,t:1527268295745};\\\", \\\"{x:349,y:666,t:1527268295761};\\\", \\\"{x:335,y:666,t:1527268295778};\\\", \\\"{x:334,y:666,t:1527268295796};\\\", \\\"{x:333,y:663,t:1527268295831};\\\", \\\"{x:341,y:657,t:1527268295845};\\\", \\\"{x:365,y:642,t:1527268295862};\\\", \\\"{x:403,y:625,t:1527268295880};\\\", \\\"{x:538,y:591,t:1527268295896};\\\", \\\"{x:644,y:577,t:1527268295912};\\\", \\\"{x:741,y:561,t:1527268295930};\\\", \\\"{x:807,y:555,t:1527268295946};\\\", \\\"{x:835,y:551,t:1527268295963};\\\", \\\"{x:843,y:549,t:1527268295978};\\\", \\\"{x:844,y:547,t:1527268296104};\\\", \\\"{x:844,y:546,t:1527268296112};\\\", \\\"{x:847,y:543,t:1527268296129};\\\", \\\"{x:847,y:541,t:1527268296146};\\\", \\\"{x:845,y:541,t:1527268296448};\\\", \\\"{x:842,y:544,t:1527268296463};\\\", \\\"{x:832,y:553,t:1527268296480};\\\", \\\"{x:823,y:562,t:1527268296496};\\\", \\\"{x:813,y:572,t:1527268296513};\\\", \\\"{x:805,y:582,t:1527268296528};\\\", \\\"{x:795,y:595,t:1527268296546};\\\", \\\"{x:788,y:605,t:1527268296563};\\\", \\\"{x:784,y:611,t:1527268296580};\\\", \\\"{x:781,y:615,t:1527268296595};\\\", \\\"{x:772,y:627,t:1527268296612};\\\", \\\"{x:762,y:639,t:1527268296630};\\\", \\\"{x:752,y:649,t:1527268296645};\\\", \\\"{x:735,y:660,t:1527268296663};\\\", \\\"{x:694,y:680,t:1527268296679};\\\", \\\"{x:654,y:694,t:1527268296696};\\\", \\\"{x:608,y:709,t:1527268296713};\\\", \\\"{x:576,y:726,t:1527268296730};\\\", \\\"{x:555,y:735,t:1527268296747};\\\", \\\"{x:539,y:738,t:1527268296763};\\\", \\\"{x:536,y:738,t:1527268296780};\\\", \\\"{x:534,y:738,t:1527268296796};\\\", \\\"{x:533,y:738,t:1527268296816};\\\", \\\"{x:532,y:737,t:1527268296832};\\\", \\\"{x:530,y:735,t:1527268296846};\\\", \\\"{x:525,y:735,t:1527268296863};\\\", \\\"{x:512,y:735,t:1527268296880};\\\", \\\"{x:507,y:735,t:1527268296896};\\\", \\\"{x:506,y:735,t:1527268296913};\\\", \\\"{x:505,y:735,t:1527268297328};\\\", \\\"{x:507,y:730,t:1527268297343};\\\", \\\"{x:514,y:720,t:1527268297352};\\\", \\\"{x:522,y:710,t:1527268297363};\\\", \\\"{x:541,y:682,t:1527268297380};\\\", \\\"{x:566,y:646,t:1527268297397};\\\", \\\"{x:584,y:616,t:1527268297413};\\\", \\\"{x:600,y:582,t:1527268297430};\\\", \\\"{x:615,y:555,t:1527268297447};\\\", \\\"{x:624,y:534,t:1527268297463};\\\", \\\"{x:641,y:505,t:1527268297480};\\\", \\\"{x:653,y:488,t:1527268297496};\\\", \\\"{x:662,y:475,t:1527268297514};\\\", \\\"{x:672,y:462,t:1527268297530};\\\", \\\"{x:682,y:452,t:1527268297546};\\\", \\\"{x:691,y:444,t:1527268297563};\\\", \\\"{x:696,y:439,t:1527268297580};\\\", \\\"{x:700,y:436,t:1527268297597};\\\", \\\"{x:703,y:432,t:1527268297614};\\\", \\\"{x:705,y:430,t:1527268297630};\\\", \\\"{x:705,y:429,t:1527268297646};\\\", \\\"{x:706,y:429,t:1527268297664};\\\" ] }, { \\\"rt\\\": 32231, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 354403, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-C -H -C -C -X -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:706,y:428,t:1527268299473};\\\", \\\"{x:706,y:426,t:1527268299760};\\\", \\\"{x:706,y:422,t:1527268299776};\\\", \\\"{x:707,y:418,t:1527268299783};\\\", \\\"{x:707,y:415,t:1527268299798};\\\", \\\"{x:709,y:412,t:1527268299815};\\\", \\\"{x:709,y:410,t:1527268299832};\\\", \\\"{x:709,y:409,t:1527268299849};\\\", \\\"{x:709,y:408,t:1527268299865};\\\", \\\"{x:709,y:407,t:1527268299882};\\\", \\\"{x:709,y:406,t:1527268299911};\\\", \\\"{x:709,y:405,t:1527268299928};\\\", \\\"{x:709,y:404,t:1527268299944};\\\", \\\"{x:709,y:403,t:1527268299985};\\\", \\\"{x:709,y:402,t:1527268300017};\\\", \\\"{x:709,y:401,t:1527268300032};\\\", \\\"{x:709,y:400,t:1527268300096};\\\", \\\"{x:709,y:399,t:1527268300184};\\\", \\\"{x:709,y:398,t:1527268300553};\\\", \\\"{x:709,y:397,t:1527268301321};\\\", \\\"{x:709,y:395,t:1527268301336};\\\", \\\"{x:709,y:393,t:1527268301360};\\\", \\\"{x:709,y:392,t:1527268301368};\\\", \\\"{x:709,y:391,t:1527268301400};\\\", \\\"{x:709,y:390,t:1527268301432};\\\", \\\"{x:708,y:390,t:1527268301439};\\\", \\\"{x:709,y:388,t:1527268304719};\\\", \\\"{x:721,y:381,t:1527268304735};\\\", \\\"{x:730,y:376,t:1527268304752};\\\", \\\"{x:733,y:375,t:1527268304769};\\\", \\\"{x:735,y:374,t:1527268304785};\\\", \\\"{x:737,y:373,t:1527268304802};\\\", \\\"{x:739,y:372,t:1527268304819};\\\", \\\"{x:740,y:372,t:1527268304839};\\\", \\\"{x:741,y:372,t:1527268304852};\\\", \\\"{x:742,y:372,t:1527268304868};\\\", \\\"{x:743,y:372,t:1527268304944};\\\", \\\"{x:745,y:372,t:1527268304952};\\\", \\\"{x:770,y:380,t:1527268304969};\\\", \\\"{x:833,y:409,t:1527268304985};\\\", \\\"{x:934,y:460,t:1527268305002};\\\", \\\"{x:1038,y:518,t:1527268305020};\\\", \\\"{x:1127,y:564,t:1527268305036};\\\", \\\"{x:1196,y:595,t:1527268305053};\\\", \\\"{x:1249,y:611,t:1527268305069};\\\", \\\"{x:1277,y:619,t:1527268305086};\\\", \\\"{x:1292,y:622,t:1527268305102};\\\", \\\"{x:1296,y:622,t:1527268305119};\\\", \\\"{x:1295,y:621,t:1527268305305};\\\", \\\"{x:1288,y:619,t:1527268305320};\\\", \\\"{x:1279,y:614,t:1527268305336};\\\", \\\"{x:1270,y:612,t:1527268305352};\\\", \\\"{x:1262,y:610,t:1527268305369};\\\", \\\"{x:1257,y:609,t:1527268305386};\\\", \\\"{x:1251,y:608,t:1527268305403};\\\", \\\"{x:1239,y:606,t:1527268305419};\\\", \\\"{x:1225,y:601,t:1527268305436};\\\", \\\"{x:1214,y:599,t:1527268305452};\\\", \\\"{x:1206,y:598,t:1527268305469};\\\", \\\"{x:1200,y:597,t:1527268305486};\\\", \\\"{x:1189,y:595,t:1527268305502};\\\", \\\"{x:1168,y:590,t:1527268305519};\\\", \\\"{x:1155,y:589,t:1527268305536};\\\", \\\"{x:1137,y:586,t:1527268305552};\\\", \\\"{x:1127,y:584,t:1527268305569};\\\", \\\"{x:1123,y:583,t:1527268305586};\\\", \\\"{x:1118,y:582,t:1527268305603};\\\", \\\"{x:1113,y:580,t:1527268305619};\\\", \\\"{x:1106,y:576,t:1527268305636};\\\", \\\"{x:1102,y:575,t:1527268305653};\\\", \\\"{x:1101,y:574,t:1527268306551};\\\", \\\"{x:1100,y:574,t:1527268306567};\\\", \\\"{x:1100,y:573,t:1527268306575};\\\", \\\"{x:1099,y:573,t:1527268306587};\\\", \\\"{x:1096,y:572,t:1527268306603};\\\", \\\"{x:1093,y:570,t:1527268306620};\\\", \\\"{x:1091,y:570,t:1527268306637};\\\", \\\"{x:1090,y:570,t:1527268306671};\\\", \\\"{x:1089,y:569,t:1527268306687};\\\", \\\"{x:1087,y:568,t:1527268306769};\\\", \\\"{x:1086,y:568,t:1527268306832};\\\", \\\"{x:1086,y:567,t:1527268306840};\\\", \\\"{x:1085,y:567,t:1527268306887};\\\", \\\"{x:1084,y:567,t:1527268307343};\\\", \\\"{x:1083,y:567,t:1527268307383};\\\", \\\"{x:1083,y:566,t:1527268307391};\\\", \\\"{x:1082,y:566,t:1527268307404};\\\", \\\"{x:1080,y:566,t:1527268307421};\\\", \\\"{x:1077,y:565,t:1527268307437};\\\", \\\"{x:1070,y:563,t:1527268307454};\\\", \\\"{x:1061,y:560,t:1527268307471};\\\", \\\"{x:1052,y:558,t:1527268307487};\\\", \\\"{x:1042,y:557,t:1527268307504};\\\", \\\"{x:1034,y:554,t:1527268307521};\\\", \\\"{x:1030,y:554,t:1527268307537};\\\", \\\"{x:1025,y:553,t:1527268307554};\\\", \\\"{x:1024,y:553,t:1527268307571};\\\", \\\"{x:1023,y:553,t:1527268307587};\\\", \\\"{x:1025,y:555,t:1527268307839};\\\", \\\"{x:1025,y:556,t:1527268307855};\\\", \\\"{x:1027,y:561,t:1527268307871};\\\", \\\"{x:1029,y:565,t:1527268307887};\\\", \\\"{x:1030,y:568,t:1527268307905};\\\", \\\"{x:1032,y:571,t:1527268307921};\\\", \\\"{x:1032,y:574,t:1527268307938};\\\", \\\"{x:1032,y:583,t:1527268307954};\\\", \\\"{x:1032,y:600,t:1527268307971};\\\", \\\"{x:1032,y:623,t:1527268307988};\\\", \\\"{x:1035,y:642,t:1527268308004};\\\", \\\"{x:1037,y:653,t:1527268308021};\\\", \\\"{x:1039,y:658,t:1527268308038};\\\", \\\"{x:1040,y:660,t:1527268308054};\\\", \\\"{x:1041,y:661,t:1527268308144};\\\", \\\"{x:1042,y:661,t:1527268308159};\\\", \\\"{x:1045,y:661,t:1527268308175};\\\", \\\"{x:1047,y:660,t:1527268308188};\\\", \\\"{x:1055,y:658,t:1527268308205};\\\", \\\"{x:1063,y:654,t:1527268308222};\\\", \\\"{x:1073,y:648,t:1527268308238};\\\", \\\"{x:1084,y:641,t:1527268308255};\\\", \\\"{x:1097,y:631,t:1527268308271};\\\", \\\"{x:1101,y:627,t:1527268308288};\\\", \\\"{x:1102,y:626,t:1527268308520};\\\", \\\"{x:1103,y:626,t:1527268308539};\\\", \\\"{x:1104,y:626,t:1527268308556};\\\", \\\"{x:1105,y:626,t:1527268308572};\\\", \\\"{x:1106,y:626,t:1527268308664};\\\", \\\"{x:1106,y:627,t:1527268308681};\\\", \\\"{x:1106,y:630,t:1527268308689};\\\", \\\"{x:1106,y:631,t:1527268308712};\\\", \\\"{x:1106,y:633,t:1527268308721};\\\", \\\"{x:1105,y:635,t:1527268308739};\\\", \\\"{x:1103,y:638,t:1527268308756};\\\", \\\"{x:1100,y:641,t:1527268308772};\\\", \\\"{x:1099,y:641,t:1527268308789};\\\", \\\"{x:1097,y:643,t:1527268308806};\\\", \\\"{x:1095,y:644,t:1527268308822};\\\", \\\"{x:1094,y:644,t:1527268308839};\\\", \\\"{x:1093,y:645,t:1527268308856};\\\", \\\"{x:1092,y:645,t:1527268309040};\\\", \\\"{x:1089,y:644,t:1527268309055};\\\", \\\"{x:1087,y:643,t:1527268309072};\\\", \\\"{x:1084,y:643,t:1527268309089};\\\", \\\"{x:1080,y:641,t:1527268309106};\\\", \\\"{x:1078,y:640,t:1527268309122};\\\", \\\"{x:1076,y:639,t:1527268309138};\\\", \\\"{x:1074,y:639,t:1527268309155};\\\", \\\"{x:1073,y:638,t:1527268309172};\\\", \\\"{x:1072,y:636,t:1527268309189};\\\", \\\"{x:1071,y:634,t:1527268309206};\\\", \\\"{x:1070,y:633,t:1527268309222};\\\", \\\"{x:1069,y:632,t:1527268309238};\\\", \\\"{x:1068,y:631,t:1527268309255};\\\", \\\"{x:1068,y:630,t:1527268310655};\\\", \\\"{x:1068,y:629,t:1527268310664};\\\", \\\"{x:1069,y:629,t:1527268310687};\\\", \\\"{x:1070,y:629,t:1527268310695};\\\", \\\"{x:1070,y:628,t:1527268310711};\\\", \\\"{x:1071,y:628,t:1527268310807};\\\", \\\"{x:1072,y:628,t:1527268310847};\\\", \\\"{x:1073,y:628,t:1527268310871};\\\", \\\"{x:1074,y:628,t:1527268310895};\\\", \\\"{x:1075,y:627,t:1527268311288};\\\", \\\"{x:1077,y:626,t:1527268311295};\\\", \\\"{x:1078,y:626,t:1527268311307};\\\", \\\"{x:1080,y:624,t:1527268311324};\\\", \\\"{x:1082,y:624,t:1527268311341};\\\", \\\"{x:1083,y:624,t:1527268311357};\\\", \\\"{x:1084,y:623,t:1527268311448};\\\", \\\"{x:1085,y:623,t:1527268311488};\\\", \\\"{x:1086,y:622,t:1527268311504};\\\", \\\"{x:1087,y:622,t:1527268311544};\\\", \\\"{x:1088,y:622,t:1527268311592};\\\", \\\"{x:1089,y:622,t:1527268311616};\\\", \\\"{x:1089,y:621,t:1527268311624};\\\", \\\"{x:1090,y:621,t:1527268311656};\\\", \\\"{x:1091,y:621,t:1527268311664};\\\", \\\"{x:1092,y:621,t:1527268311679};\\\", \\\"{x:1093,y:621,t:1527268311703};\\\", \\\"{x:1094,y:621,t:1527268311720};\\\", \\\"{x:1094,y:620,t:1527268311727};\\\", \\\"{x:1095,y:620,t:1527268311751};\\\", \\\"{x:1096,y:620,t:1527268311783};\\\", \\\"{x:1096,y:619,t:1527268311791};\\\", \\\"{x:1098,y:619,t:1527268311815};\\\", \\\"{x:1099,y:619,t:1527268311839};\\\", \\\"{x:1101,y:619,t:1527268311863};\\\", \\\"{x:1102,y:619,t:1527268311887};\\\", \\\"{x:1104,y:619,t:1527268311903};\\\", \\\"{x:1105,y:619,t:1527268311935};\\\", \\\"{x:1107,y:619,t:1527268311968};\\\", \\\"{x:1109,y:619,t:1527268312000};\\\", \\\"{x:1110,y:619,t:1527268312031};\\\", \\\"{x:1112,y:620,t:1527268312055};\\\", \\\"{x:1113,y:620,t:1527268312095};\\\", \\\"{x:1114,y:620,t:1527268312216};\\\", \\\"{x:1114,y:621,t:1527268313535};\\\", \\\"{x:1116,y:621,t:1527268313543};\\\", \\\"{x:1118,y:622,t:1527268313558};\\\", \\\"{x:1135,y:629,t:1527268313575};\\\", \\\"{x:1151,y:634,t:1527268313592};\\\", \\\"{x:1165,y:639,t:1527268313609};\\\", \\\"{x:1178,y:642,t:1527268313626};\\\", \\\"{x:1184,y:644,t:1527268313641};\\\", \\\"{x:1185,y:644,t:1527268313659};\\\", \\\"{x:1186,y:644,t:1527268313808};\\\", \\\"{x:1188,y:644,t:1527268313825};\\\", \\\"{x:1190,y:644,t:1527268313843};\\\", \\\"{x:1192,y:644,t:1527268313858};\\\", \\\"{x:1197,y:642,t:1527268313876};\\\", \\\"{x:1200,y:641,t:1527268313892};\\\", \\\"{x:1204,y:639,t:1527268313908};\\\", \\\"{x:1207,y:638,t:1527268313925};\\\", \\\"{x:1211,y:637,t:1527268313942};\\\", \\\"{x:1213,y:637,t:1527268313958};\\\", \\\"{x:1218,y:635,t:1527268313975};\\\", \\\"{x:1221,y:635,t:1527268313993};\\\", \\\"{x:1224,y:634,t:1527268314009};\\\", \\\"{x:1230,y:633,t:1527268314026};\\\", \\\"{x:1235,y:633,t:1527268314042};\\\", \\\"{x:1242,y:633,t:1527268314059};\\\", \\\"{x:1248,y:633,t:1527268314076};\\\", \\\"{x:1255,y:633,t:1527268314092};\\\", \\\"{x:1261,y:633,t:1527268314108};\\\", \\\"{x:1268,y:633,t:1527268314126};\\\", \\\"{x:1272,y:633,t:1527268314143};\\\", \\\"{x:1280,y:633,t:1527268314159};\\\", \\\"{x:1285,y:632,t:1527268314176};\\\", \\\"{x:1288,y:632,t:1527268314192};\\\", \\\"{x:1293,y:631,t:1527268314210};\\\", \\\"{x:1298,y:630,t:1527268314226};\\\", \\\"{x:1303,y:630,t:1527268314243};\\\", \\\"{x:1308,y:629,t:1527268314260};\\\", \\\"{x:1315,y:629,t:1527268314276};\\\", \\\"{x:1321,y:629,t:1527268314293};\\\", \\\"{x:1326,y:629,t:1527268314310};\\\", \\\"{x:1330,y:629,t:1527268314326};\\\", \\\"{x:1333,y:629,t:1527268314342};\\\", \\\"{x:1337,y:629,t:1527268314359};\\\", \\\"{x:1338,y:629,t:1527268314376};\\\", \\\"{x:1340,y:629,t:1527268314392};\\\", \\\"{x:1343,y:629,t:1527268314410};\\\", \\\"{x:1347,y:629,t:1527268314425};\\\", \\\"{x:1350,y:629,t:1527268314442};\\\", \\\"{x:1357,y:629,t:1527268314459};\\\", \\\"{x:1359,y:628,t:1527268314475};\\\", \\\"{x:1364,y:628,t:1527268314492};\\\", \\\"{x:1365,y:628,t:1527268314509};\\\", \\\"{x:1368,y:628,t:1527268314526};\\\", \\\"{x:1370,y:628,t:1527268314542};\\\", \\\"{x:1371,y:628,t:1527268314560};\\\", \\\"{x:1373,y:628,t:1527268314576};\\\", \\\"{x:1376,y:628,t:1527268314592};\\\", \\\"{x:1377,y:628,t:1527268314609};\\\", \\\"{x:1383,y:628,t:1527268314626};\\\", \\\"{x:1387,y:628,t:1527268314642};\\\", \\\"{x:1391,y:628,t:1527268314659};\\\", \\\"{x:1394,y:628,t:1527268314676};\\\", \\\"{x:1396,y:628,t:1527268314692};\\\", \\\"{x:1400,y:628,t:1527268314709};\\\", \\\"{x:1401,y:627,t:1527268314726};\\\", \\\"{x:1403,y:627,t:1527268314742};\\\", \\\"{x:1404,y:627,t:1527268314760};\\\", \\\"{x:1405,y:627,t:1527268314776};\\\", \\\"{x:1406,y:627,t:1527268314792};\\\", \\\"{x:1408,y:627,t:1527268314810};\\\", \\\"{x:1410,y:627,t:1527268314826};\\\", \\\"{x:1411,y:627,t:1527268314847};\\\", \\\"{x:1413,y:627,t:1527268314859};\\\", \\\"{x:1418,y:627,t:1527268314876};\\\", \\\"{x:1423,y:627,t:1527268314892};\\\", \\\"{x:1428,y:627,t:1527268314909};\\\", \\\"{x:1432,y:627,t:1527268314927};\\\", \\\"{x:1436,y:627,t:1527268314942};\\\", \\\"{x:1442,y:627,t:1527268314959};\\\", \\\"{x:1445,y:627,t:1527268314977};\\\", \\\"{x:1447,y:627,t:1527268314992};\\\", \\\"{x:1450,y:627,t:1527268315010};\\\", \\\"{x:1453,y:627,t:1527268315026};\\\", \\\"{x:1459,y:627,t:1527268315042};\\\", \\\"{x:1463,y:627,t:1527268315059};\\\", \\\"{x:1466,y:627,t:1527268315077};\\\", \\\"{x:1470,y:627,t:1527268315093};\\\", \\\"{x:1474,y:628,t:1527268315110};\\\", \\\"{x:1477,y:629,t:1527268315126};\\\", \\\"{x:1482,y:629,t:1527268315143};\\\", \\\"{x:1486,y:629,t:1527268315160};\\\", \\\"{x:1487,y:629,t:1527268315177};\\\", \\\"{x:1489,y:629,t:1527268315194};\\\", \\\"{x:1490,y:629,t:1527268315209};\\\", \\\"{x:1491,y:629,t:1527268315226};\\\", \\\"{x:1492,y:629,t:1527268315244};\\\", \\\"{x:1493,y:629,t:1527268315259};\\\", \\\"{x:1494,y:629,t:1527268315288};\\\", \\\"{x:1495,y:629,t:1527268315311};\\\", \\\"{x:1496,y:629,t:1527268315327};\\\", \\\"{x:1499,y:629,t:1527268315344};\\\", \\\"{x:1502,y:629,t:1527268315360};\\\", \\\"{x:1506,y:629,t:1527268315377};\\\", \\\"{x:1511,y:629,t:1527268315394};\\\", \\\"{x:1517,y:628,t:1527268315410};\\\", \\\"{x:1521,y:627,t:1527268315427};\\\", \\\"{x:1526,y:626,t:1527268315444};\\\", \\\"{x:1529,y:626,t:1527268315459};\\\", \\\"{x:1530,y:626,t:1527268315478};\\\", \\\"{x:1531,y:626,t:1527268315496};\\\", \\\"{x:1533,y:625,t:1527268315545};\\\", \\\"{x:1534,y:624,t:1527268315561};\\\", \\\"{x:1535,y:624,t:1527268315577};\\\", \\\"{x:1536,y:623,t:1527268315594};\\\", \\\"{x:1537,y:623,t:1527268315624};\\\", \\\"{x:1538,y:623,t:1527268315640};\\\", \\\"{x:1539,y:623,t:1527268315664};\\\", \\\"{x:1540,y:621,t:1527268315677};\\\", \\\"{x:1542,y:621,t:1527268315694};\\\", \\\"{x:1545,y:620,t:1527268315711};\\\", \\\"{x:1550,y:619,t:1527268315728};\\\", \\\"{x:1556,y:619,t:1527268315744};\\\", \\\"{x:1562,y:619,t:1527268315761};\\\", \\\"{x:1569,y:619,t:1527268315777};\\\", \\\"{x:1578,y:619,t:1527268315794};\\\", \\\"{x:1592,y:619,t:1527268315812};\\\", \\\"{x:1605,y:617,t:1527268315828};\\\", \\\"{x:1614,y:615,t:1527268315843};\\\", \\\"{x:1624,y:612,t:1527268315860};\\\", \\\"{x:1633,y:610,t:1527268315876};\\\", \\\"{x:1639,y:606,t:1527268315894};\\\", \\\"{x:1650,y:602,t:1527268315911};\\\", \\\"{x:1661,y:597,t:1527268315927};\\\", \\\"{x:1673,y:591,t:1527268315944};\\\", \\\"{x:1678,y:589,t:1527268315960};\\\", \\\"{x:1681,y:588,t:1527268315976};\\\", \\\"{x:1685,y:587,t:1527268315994};\\\", \\\"{x:1686,y:586,t:1527268316010};\\\", \\\"{x:1688,y:586,t:1527268316104};\\\", \\\"{x:1689,y:586,t:1527268316110};\\\", \\\"{x:1693,y:586,t:1527268316127};\\\", \\\"{x:1706,y:586,t:1527268316144};\\\", \\\"{x:1714,y:586,t:1527268316161};\\\", \\\"{x:1719,y:588,t:1527268316178};\\\", \\\"{x:1724,y:591,t:1527268316193};\\\", \\\"{x:1730,y:594,t:1527268316210};\\\", \\\"{x:1736,y:596,t:1527268316227};\\\", \\\"{x:1741,y:599,t:1527268316243};\\\", \\\"{x:1746,y:602,t:1527268316261};\\\", \\\"{x:1751,y:606,t:1527268316278};\\\", \\\"{x:1752,y:607,t:1527268316293};\\\", \\\"{x:1754,y:607,t:1527268316311};\\\", \\\"{x:1755,y:610,t:1527268316327};\\\", \\\"{x:1756,y:611,t:1527268316344};\\\", \\\"{x:1756,y:612,t:1527268316367};\\\", \\\"{x:1757,y:613,t:1527268316384};\\\", \\\"{x:1757,y:615,t:1527268316407};\\\", \\\"{x:1758,y:615,t:1527268316416};\\\", \\\"{x:1758,y:616,t:1527268316428};\\\", \\\"{x:1759,y:618,t:1527268316447};\\\", \\\"{x:1760,y:620,t:1527268316461};\\\", \\\"{x:1761,y:621,t:1527268316477};\\\", \\\"{x:1761,y:622,t:1527268316493};\\\", \\\"{x:1761,y:625,t:1527268316511};\\\", \\\"{x:1761,y:628,t:1527268316527};\\\", \\\"{x:1761,y:630,t:1527268316545};\\\", \\\"{x:1761,y:632,t:1527268316560};\\\", \\\"{x:1762,y:634,t:1527268316578};\\\", \\\"{x:1762,y:637,t:1527268316595};\\\", \\\"{x:1763,y:639,t:1527268316611};\\\", \\\"{x:1764,y:641,t:1527268316627};\\\", \\\"{x:1764,y:642,t:1527268316645};\\\", \\\"{x:1764,y:644,t:1527268316661};\\\", \\\"{x:1764,y:645,t:1527268316677};\\\", \\\"{x:1765,y:647,t:1527268316694};\\\", \\\"{x:1765,y:648,t:1527268316710};\\\", \\\"{x:1766,y:650,t:1527268316727};\\\", \\\"{x:1766,y:651,t:1527268316745};\\\", \\\"{x:1767,y:656,t:1527268316761};\\\", \\\"{x:1767,y:658,t:1527268316778};\\\", \\\"{x:1768,y:664,t:1527268316795};\\\", \\\"{x:1769,y:669,t:1527268316811};\\\", \\\"{x:1770,y:675,t:1527268316828};\\\", \\\"{x:1770,y:676,t:1527268316845};\\\", \\\"{x:1770,y:679,t:1527268316860};\\\", \\\"{x:1770,y:680,t:1527268316877};\\\", \\\"{x:1770,y:685,t:1527268316894};\\\", \\\"{x:1770,y:691,t:1527268316910};\\\", \\\"{x:1770,y:698,t:1527268316928};\\\", \\\"{x:1770,y:702,t:1527268316944};\\\", \\\"{x:1770,y:703,t:1527268316960};\\\", \\\"{x:1770,y:705,t:1527268316977};\\\", \\\"{x:1770,y:706,t:1527268316995};\\\", \\\"{x:1770,y:707,t:1527268317011};\\\", \\\"{x:1770,y:708,t:1527268317028};\\\", \\\"{x:1770,y:709,t:1527268317087};\\\", \\\"{x:1770,y:710,t:1527268317376};\\\", \\\"{x:1768,y:710,t:1527268317383};\\\", \\\"{x:1763,y:710,t:1527268317394};\\\", \\\"{x:1758,y:709,t:1527268317412};\\\", \\\"{x:1752,y:705,t:1527268317428};\\\", \\\"{x:1746,y:703,t:1527268317445};\\\", \\\"{x:1741,y:701,t:1527268317462};\\\", \\\"{x:1738,y:700,t:1527268317477};\\\", \\\"{x:1736,y:699,t:1527268317495};\\\", \\\"{x:1735,y:699,t:1527268317511};\\\", \\\"{x:1733,y:698,t:1527268317575};\\\", \\\"{x:1732,y:697,t:1527268317591};\\\", \\\"{x:1731,y:697,t:1527268317599};\\\", \\\"{x:1729,y:696,t:1527268317611};\\\", \\\"{x:1729,y:695,t:1527268317629};\\\", \\\"{x:1728,y:695,t:1527268317644};\\\", \\\"{x:1727,y:695,t:1527268317662};\\\", \\\"{x:1726,y:695,t:1527268317679};\\\", \\\"{x:1724,y:695,t:1527268317727};\\\", \\\"{x:1723,y:695,t:1527268317768};\\\", \\\"{x:1721,y:695,t:1527268318304};\\\", \\\"{x:1720,y:695,t:1527268318319};\\\", \\\"{x:1718,y:695,t:1527268318368};\\\", \\\"{x:1717,y:695,t:1527268318425};\\\", \\\"{x:1713,y:695,t:1527268318632};\\\", \\\"{x:1707,y:695,t:1527268318647};\\\", \\\"{x:1692,y:690,t:1527268318663};\\\", \\\"{x:1669,y:684,t:1527268318680};\\\", \\\"{x:1633,y:673,t:1527268318696};\\\", \\\"{x:1603,y:666,t:1527268318713};\\\", \\\"{x:1568,y:654,t:1527268318729};\\\", \\\"{x:1533,y:646,t:1527268318747};\\\", \\\"{x:1499,y:639,t:1527268318763};\\\", \\\"{x:1474,y:634,t:1527268318779};\\\", \\\"{x:1454,y:630,t:1527268318797};\\\", \\\"{x:1444,y:629,t:1527268318814};\\\", \\\"{x:1438,y:628,t:1527268318830};\\\", \\\"{x:1436,y:628,t:1527268318846};\\\", \\\"{x:1435,y:628,t:1527268318863};\\\", \\\"{x:1434,y:628,t:1527268318880};\\\", \\\"{x:1433,y:628,t:1527268318895};\\\", \\\"{x:1430,y:628,t:1527268318912};\\\", \\\"{x:1425,y:628,t:1527268318929};\\\", \\\"{x:1413,y:632,t:1527268318945};\\\", \\\"{x:1398,y:636,t:1527268318962};\\\", \\\"{x:1375,y:643,t:1527268318979};\\\", \\\"{x:1352,y:649,t:1527268318995};\\\", \\\"{x:1334,y:654,t:1527268319012};\\\", \\\"{x:1319,y:655,t:1527268319030};\\\", \\\"{x:1305,y:657,t:1527268319045};\\\", \\\"{x:1290,y:658,t:1527268319063};\\\", \\\"{x:1277,y:658,t:1527268319079};\\\", \\\"{x:1270,y:658,t:1527268319096};\\\", \\\"{x:1264,y:658,t:1527268319113};\\\", \\\"{x:1258,y:658,t:1527268319130};\\\", \\\"{x:1255,y:658,t:1527268319146};\\\", \\\"{x:1247,y:656,t:1527268319163};\\\", \\\"{x:1242,y:656,t:1527268319180};\\\", \\\"{x:1237,y:653,t:1527268319196};\\\", \\\"{x:1233,y:648,t:1527268319213};\\\", \\\"{x:1225,y:640,t:1527268319230};\\\", \\\"{x:1223,y:636,t:1527268319246};\\\", \\\"{x:1222,y:635,t:1527268319264};\\\", \\\"{x:1222,y:634,t:1527268319400};\\\", \\\"{x:1223,y:634,t:1527268319413};\\\", \\\"{x:1225,y:633,t:1527268319430};\\\", \\\"{x:1228,y:633,t:1527268319447};\\\", \\\"{x:1238,y:633,t:1527268319463};\\\", \\\"{x:1259,y:633,t:1527268319480};\\\", \\\"{x:1270,y:633,t:1527268319498};\\\", \\\"{x:1280,y:633,t:1527268319513};\\\", \\\"{x:1289,y:633,t:1527268319530};\\\", \\\"{x:1298,y:633,t:1527268319547};\\\", \\\"{x:1303,y:633,t:1527268319563};\\\", \\\"{x:1310,y:633,t:1527268319580};\\\", \\\"{x:1313,y:633,t:1527268319597};\\\", \\\"{x:1314,y:632,t:1527268319614};\\\", \\\"{x:1315,y:632,t:1527268319630};\\\", \\\"{x:1316,y:632,t:1527268319713};\\\", \\\"{x:1318,y:630,t:1527268319731};\\\", \\\"{x:1320,y:629,t:1527268319747};\\\", \\\"{x:1322,y:629,t:1527268319763};\\\", \\\"{x:1326,y:629,t:1527268319781};\\\", \\\"{x:1332,y:629,t:1527268319797};\\\", \\\"{x:1336,y:629,t:1527268319814};\\\", \\\"{x:1342,y:629,t:1527268319830};\\\", \\\"{x:1347,y:629,t:1527268319848};\\\", \\\"{x:1351,y:629,t:1527268319864};\\\", \\\"{x:1355,y:627,t:1527268319880};\\\", \\\"{x:1359,y:624,t:1527268319897};\\\", \\\"{x:1365,y:621,t:1527268319913};\\\", \\\"{x:1371,y:618,t:1527268319930};\\\", \\\"{x:1377,y:617,t:1527268319947};\\\", \\\"{x:1388,y:617,t:1527268319965};\\\", \\\"{x:1398,y:617,t:1527268319980};\\\", \\\"{x:1405,y:617,t:1527268319997};\\\", \\\"{x:1412,y:617,t:1527268320014};\\\", \\\"{x:1417,y:617,t:1527268320030};\\\", \\\"{x:1433,y:618,t:1527268320048};\\\", \\\"{x:1450,y:622,t:1527268320064};\\\", \\\"{x:1463,y:626,t:1527268320080};\\\", \\\"{x:1472,y:627,t:1527268320097};\\\", \\\"{x:1482,y:630,t:1527268320114};\\\", \\\"{x:1494,y:634,t:1527268320130};\\\", \\\"{x:1497,y:634,t:1527268320147};\\\", \\\"{x:1498,y:634,t:1527268320164};\\\", \\\"{x:1500,y:634,t:1527268320179};\\\", \\\"{x:1500,y:635,t:1527268320223};\\\", \\\"{x:1501,y:635,t:1527268320375};\\\", \\\"{x:1503,y:635,t:1527268320391};\\\", \\\"{x:1505,y:635,t:1527268320399};\\\", \\\"{x:1507,y:635,t:1527268320413};\\\", \\\"{x:1516,y:635,t:1527268320431};\\\", \\\"{x:1524,y:635,t:1527268320447};\\\", \\\"{x:1533,y:635,t:1527268320463};\\\", \\\"{x:1541,y:635,t:1527268320481};\\\", \\\"{x:1547,y:635,t:1527268320497};\\\", \\\"{x:1551,y:635,t:1527268320514};\\\", \\\"{x:1556,y:636,t:1527268320531};\\\", \\\"{x:1559,y:637,t:1527268320547};\\\", \\\"{x:1561,y:638,t:1527268320564};\\\", \\\"{x:1563,y:638,t:1527268320581};\\\", \\\"{x:1566,y:638,t:1527268320597};\\\", \\\"{x:1569,y:638,t:1527268320614};\\\", \\\"{x:1575,y:638,t:1527268320631};\\\", \\\"{x:1580,y:638,t:1527268320647};\\\", \\\"{x:1588,y:639,t:1527268320664};\\\", \\\"{x:1592,y:639,t:1527268320682};\\\", \\\"{x:1594,y:639,t:1527268320697};\\\", \\\"{x:1595,y:639,t:1527268320714};\\\", \\\"{x:1596,y:639,t:1527268320731};\\\", \\\"{x:1597,y:639,t:1527268320747};\\\", \\\"{x:1599,y:639,t:1527268320768};\\\", \\\"{x:1601,y:638,t:1527268320783};\\\", \\\"{x:1602,y:638,t:1527268320799};\\\", \\\"{x:1604,y:637,t:1527268320814};\\\", \\\"{x:1606,y:636,t:1527268320831};\\\", \\\"{x:1611,y:634,t:1527268320847};\\\", \\\"{x:1614,y:634,t:1527268320864};\\\", \\\"{x:1616,y:634,t:1527268320881};\\\", \\\"{x:1617,y:634,t:1527268320960};\\\", \\\"{x:1618,y:634,t:1527268320968};\\\", \\\"{x:1619,y:634,t:1527268320984};\\\", \\\"{x:1620,y:634,t:1527268321000};\\\", \\\"{x:1621,y:633,t:1527268321015};\\\", \\\"{x:1622,y:632,t:1527268321032};\\\", \\\"{x:1623,y:632,t:1527268321048};\\\", \\\"{x:1624,y:632,t:1527268321064};\\\", \\\"{x:1622,y:633,t:1527268321367};\\\", \\\"{x:1621,y:633,t:1527268321383};\\\", \\\"{x:1620,y:634,t:1527268321397};\\\", \\\"{x:1619,y:635,t:1527268321414};\\\", \\\"{x:1618,y:636,t:1527268321431};\\\", \\\"{x:1617,y:637,t:1527268321448};\\\", \\\"{x:1616,y:638,t:1527268321465};\\\", \\\"{x:1614,y:641,t:1527268321480};\\\", \\\"{x:1613,y:642,t:1527268321497};\\\", \\\"{x:1611,y:645,t:1527268321514};\\\", \\\"{x:1610,y:647,t:1527268321531};\\\", \\\"{x:1608,y:650,t:1527268321548};\\\", \\\"{x:1607,y:652,t:1527268321565};\\\", \\\"{x:1605,y:654,t:1527268321581};\\\", \\\"{x:1605,y:657,t:1527268321598};\\\", \\\"{x:1602,y:663,t:1527268321615};\\\", \\\"{x:1601,y:666,t:1527268321631};\\\", \\\"{x:1598,y:671,t:1527268321648};\\\", \\\"{x:1595,y:677,t:1527268321665};\\\", \\\"{x:1593,y:683,t:1527268321681};\\\", \\\"{x:1590,y:690,t:1527268321698};\\\", \\\"{x:1585,y:702,t:1527268321715};\\\", \\\"{x:1579,y:715,t:1527268321731};\\\", \\\"{x:1574,y:729,t:1527268321747};\\\", \\\"{x:1567,y:743,t:1527268321765};\\\", \\\"{x:1562,y:755,t:1527268321781};\\\", \\\"{x:1558,y:764,t:1527268321798};\\\", \\\"{x:1554,y:778,t:1527268321815};\\\", \\\"{x:1551,y:786,t:1527268321831};\\\", \\\"{x:1549,y:790,t:1527268321848};\\\", \\\"{x:1546,y:793,t:1527268321865};\\\", \\\"{x:1543,y:798,t:1527268321882};\\\", \\\"{x:1539,y:802,t:1527268321898};\\\", \\\"{x:1537,y:805,t:1527268321915};\\\", \\\"{x:1534,y:807,t:1527268321932};\\\", \\\"{x:1528,y:810,t:1527268321948};\\\", \\\"{x:1523,y:813,t:1527268321965};\\\", \\\"{x:1518,y:815,t:1527268321982};\\\", \\\"{x:1514,y:818,t:1527268321998};\\\", \\\"{x:1509,y:819,t:1527268322016};\\\", \\\"{x:1506,y:822,t:1527268322031};\\\", \\\"{x:1505,y:822,t:1527268322048};\\\", \\\"{x:1504,y:822,t:1527268322065};\\\", \\\"{x:1501,y:824,t:1527268322082};\\\", \\\"{x:1498,y:825,t:1527268322098};\\\", \\\"{x:1494,y:826,t:1527268322115};\\\", \\\"{x:1491,y:826,t:1527268322132};\\\", \\\"{x:1487,y:827,t:1527268322148};\\\", \\\"{x:1482,y:828,t:1527268322166};\\\", \\\"{x:1478,y:828,t:1527268322182};\\\", \\\"{x:1473,y:828,t:1527268322200};\\\", \\\"{x:1466,y:828,t:1527268322216};\\\", \\\"{x:1462,y:828,t:1527268322232};\\\", \\\"{x:1459,y:829,t:1527268322250};\\\", \\\"{x:1456,y:829,t:1527268322266};\\\", \\\"{x:1453,y:830,t:1527268322283};\\\", \\\"{x:1449,y:831,t:1527268322300};\\\", \\\"{x:1448,y:831,t:1527268322316};\\\", \\\"{x:1446,y:831,t:1527268322332};\\\", \\\"{x:1444,y:832,t:1527268322349};\\\", \\\"{x:1443,y:832,t:1527268322365};\\\", \\\"{x:1442,y:832,t:1527268322384};\\\", \\\"{x:1439,y:832,t:1527268322400};\\\", \\\"{x:1438,y:832,t:1527268322440};\\\", \\\"{x:1436,y:832,t:1527268322455};\\\", \\\"{x:1433,y:831,t:1527268322472};\\\", \\\"{x:1430,y:830,t:1527268322482};\\\", \\\"{x:1423,y:828,t:1527268322499};\\\", \\\"{x:1421,y:827,t:1527268322514};\\\", \\\"{x:1413,y:824,t:1527268322532};\\\", \\\"{x:1406,y:823,t:1527268322549};\\\", \\\"{x:1400,y:819,t:1527268322565};\\\", \\\"{x:1394,y:818,t:1527268322582};\\\", \\\"{x:1388,y:814,t:1527268322598};\\\", \\\"{x:1386,y:814,t:1527268322615};\\\", \\\"{x:1384,y:814,t:1527268322631};\\\", \\\"{x:1383,y:813,t:1527268322649};\\\", \\\"{x:1383,y:811,t:1527268322672};\\\", \\\"{x:1381,y:811,t:1527268322688};\\\", \\\"{x:1380,y:809,t:1527268322699};\\\", \\\"{x:1377,y:808,t:1527268322716};\\\", \\\"{x:1376,y:807,t:1527268322733};\\\", \\\"{x:1374,y:805,t:1527268322749};\\\", \\\"{x:1373,y:805,t:1527268322766};\\\", \\\"{x:1372,y:804,t:1527268322782};\\\", \\\"{x:1370,y:800,t:1527268322799};\\\", \\\"{x:1367,y:796,t:1527268322815};\\\", \\\"{x:1363,y:789,t:1527268322832};\\\", \\\"{x:1361,y:781,t:1527268322849};\\\", \\\"{x:1353,y:771,t:1527268322866};\\\", \\\"{x:1347,y:763,t:1527268322882};\\\", \\\"{x:1343,y:755,t:1527268322900};\\\", \\\"{x:1342,y:752,t:1527268322916};\\\", \\\"{x:1340,y:749,t:1527268322932};\\\", \\\"{x:1340,y:747,t:1527268322949};\\\", \\\"{x:1339,y:743,t:1527268322966};\\\", \\\"{x:1339,y:738,t:1527268322982};\\\", \\\"{x:1338,y:732,t:1527268322999};\\\", \\\"{x:1337,y:726,t:1527268323016};\\\", \\\"{x:1336,y:720,t:1527268323033};\\\", \\\"{x:1335,y:714,t:1527268323049};\\\", \\\"{x:1335,y:710,t:1527268323066};\\\", \\\"{x:1335,y:703,t:1527268323082};\\\", \\\"{x:1335,y:699,t:1527268323099};\\\", \\\"{x:1335,y:697,t:1527268323116};\\\", \\\"{x:1335,y:695,t:1527268323132};\\\", \\\"{x:1335,y:693,t:1527268323149};\\\", \\\"{x:1335,y:690,t:1527268323166};\\\", \\\"{x:1335,y:689,t:1527268323182};\\\", \\\"{x:1336,y:686,t:1527268323199};\\\", \\\"{x:1337,y:684,t:1527268323216};\\\", \\\"{x:1337,y:683,t:1527268323232};\\\", \\\"{x:1337,y:682,t:1527268323250};\\\", \\\"{x:1338,y:682,t:1527268323266};\\\", \\\"{x:1339,y:682,t:1527268323283};\\\", \\\"{x:1340,y:684,t:1527268323384};\\\", \\\"{x:1344,y:697,t:1527268323400};\\\", \\\"{x:1349,y:711,t:1527268323417};\\\", \\\"{x:1354,y:723,t:1527268323433};\\\", \\\"{x:1358,y:730,t:1527268323449};\\\", \\\"{x:1362,y:737,t:1527268323466};\\\", \\\"{x:1364,y:743,t:1527268323483};\\\", \\\"{x:1368,y:752,t:1527268323500};\\\", \\\"{x:1371,y:759,t:1527268323516};\\\", \\\"{x:1372,y:766,t:1527268323533};\\\", \\\"{x:1375,y:771,t:1527268323549};\\\", \\\"{x:1376,y:774,t:1527268323566};\\\", \\\"{x:1377,y:780,t:1527268323584};\\\", \\\"{x:1377,y:783,t:1527268323599};\\\", \\\"{x:1377,y:784,t:1527268323616};\\\", \\\"{x:1377,y:786,t:1527268323633};\\\", \\\"{x:1377,y:787,t:1527268323649};\\\", \\\"{x:1377,y:788,t:1527268323667};\\\", \\\"{x:1376,y:789,t:1527268323683};\\\", \\\"{x:1375,y:791,t:1527268323700};\\\", \\\"{x:1374,y:793,t:1527268323717};\\\", \\\"{x:1373,y:794,t:1527268323733};\\\", \\\"{x:1372,y:796,t:1527268323751};\\\", \\\"{x:1371,y:796,t:1527268323766};\\\", \\\"{x:1370,y:798,t:1527268323783};\\\", \\\"{x:1369,y:799,t:1527268323799};\\\", \\\"{x:1368,y:800,t:1527268323816};\\\", \\\"{x:1367,y:801,t:1527268323833};\\\", \\\"{x:1365,y:801,t:1527268323850};\\\", \\\"{x:1362,y:803,t:1527268323866};\\\", \\\"{x:1361,y:804,t:1527268323883};\\\", \\\"{x:1359,y:805,t:1527268323900};\\\", \\\"{x:1358,y:805,t:1527268323916};\\\", \\\"{x:1357,y:806,t:1527268323933};\\\", \\\"{x:1356,y:807,t:1527268323950};\\\", \\\"{x:1355,y:807,t:1527268323967};\\\", \\\"{x:1352,y:807,t:1527268323983};\\\", \\\"{x:1347,y:807,t:1527268324000};\\\", \\\"{x:1336,y:806,t:1527268324016};\\\", \\\"{x:1316,y:798,t:1527268324034};\\\", \\\"{x:1289,y:786,t:1527268324050};\\\", \\\"{x:1232,y:755,t:1527268324066};\\\", \\\"{x:1160,y:724,t:1527268324083};\\\", \\\"{x:1069,y:684,t:1527268324101};\\\", \\\"{x:974,y:633,t:1527268324116};\\\", \\\"{x:867,y:570,t:1527268324134};\\\", \\\"{x:759,y:518,t:1527268324150};\\\", \\\"{x:600,y:451,t:1527268324166};\\\", \\\"{x:547,y:428,t:1527268324180};\\\", \\\"{x:459,y:391,t:1527268324195};\\\", \\\"{x:379,y:358,t:1527268324213};\\\", \\\"{x:312,y:328,t:1527268324229};\\\", \\\"{x:245,y:301,t:1527268324247};\\\", \\\"{x:200,y:285,t:1527268324263};\\\", \\\"{x:170,y:277,t:1527268324280};\\\", \\\"{x:136,y:268,t:1527268324297};\\\", \\\"{x:106,y:262,t:1527268324313};\\\", \\\"{x:80,y:259,t:1527268324330};\\\", \\\"{x:51,y:255,t:1527268324347};\\\", \\\"{x:28,y:253,t:1527268324363};\\\", \\\"{x:7,y:253,t:1527268324380};\\\", \\\"{x:0,y:253,t:1527268324397};\\\", \\\"{x:0,y:257,t:1527268324413};\\\", \\\"{x:0,y:267,t:1527268324430};\\\", \\\"{x:1,y:306,t:1527268324447};\\\", \\\"{x:33,y:368,t:1527268324464};\\\", \\\"{x:99,y:450,t:1527268324481};\\\", \\\"{x:191,y:531,t:1527268324498};\\\", \\\"{x:283,y:596,t:1527268324515};\\\", \\\"{x:403,y:685,t:1527268324535};\\\", \\\"{x:463,y:719,t:1527268324552};\\\", \\\"{x:491,y:731,t:1527268324570};\\\", \\\"{x:502,y:732,t:1527268324585};\\\", \\\"{x:503,y:732,t:1527268324602};\\\", \\\"{x:504,y:731,t:1527268324619};\\\", \\\"{x:504,y:722,t:1527268324634};\\\", \\\"{x:504,y:712,t:1527268324653};\\\", \\\"{x:507,y:691,t:1527268324669};\\\", \\\"{x:508,y:655,t:1527268324685};\\\", \\\"{x:508,y:624,t:1527268324703};\\\", \\\"{x:505,y:608,t:1527268324718};\\\", \\\"{x:496,y:597,t:1527268324735};\\\", \\\"{x:476,y:586,t:1527268324752};\\\", \\\"{x:452,y:577,t:1527268324769};\\\", \\\"{x:421,y:572,t:1527268324785};\\\", \\\"{x:379,y:565,t:1527268324802};\\\", \\\"{x:328,y:557,t:1527268324819};\\\", \\\"{x:274,y:548,t:1527268324835};\\\", \\\"{x:251,y:546,t:1527268324852};\\\", \\\"{x:243,y:544,t:1527268324869};\\\", \\\"{x:243,y:543,t:1527268325048};\\\", \\\"{x:248,y:540,t:1527268325055};\\\", \\\"{x:258,y:538,t:1527268325069};\\\", \\\"{x:285,y:533,t:1527268325087};\\\", \\\"{x:332,y:532,t:1527268325101};\\\", \\\"{x:424,y:532,t:1527268325118};\\\", \\\"{x:468,y:532,t:1527268325135};\\\", \\\"{x:508,y:532,t:1527268325154};\\\", \\\"{x:529,y:532,t:1527268325169};\\\", \\\"{x:538,y:532,t:1527268325186};\\\", \\\"{x:539,y:532,t:1527268325201};\\\", \\\"{x:541,y:532,t:1527268325288};\\\", \\\"{x:544,y:532,t:1527268325303};\\\", \\\"{x:557,y:532,t:1527268325319};\\\", \\\"{x:571,y:532,t:1527268325336};\\\", \\\"{x:581,y:532,t:1527268325353};\\\", \\\"{x:585,y:532,t:1527268325369};\\\", \\\"{x:588,y:532,t:1527268325386};\\\", \\\"{x:589,y:532,t:1527268325403};\\\", \\\"{x:590,y:532,t:1527268325419};\\\", \\\"{x:588,y:535,t:1527268325480};\\\", \\\"{x:585,y:541,t:1527268325488};\\\", \\\"{x:575,y:554,t:1527268325503};\\\", \\\"{x:562,y:564,t:1527268325524};\\\", \\\"{x:542,y:571,t:1527268325536};\\\", \\\"{x:512,y:574,t:1527268325553};\\\", \\\"{x:459,y:574,t:1527268325569};\\\", \\\"{x:400,y:574,t:1527268325586};\\\", \\\"{x:353,y:574,t:1527268325603};\\\", \\\"{x:327,y:574,t:1527268325619};\\\", \\\"{x:312,y:575,t:1527268325635};\\\", \\\"{x:302,y:579,t:1527268325652};\\\", \\\"{x:298,y:582,t:1527268325669};\\\", \\\"{x:294,y:588,t:1527268325686};\\\", \\\"{x:284,y:597,t:1527268325703};\\\", \\\"{x:278,y:603,t:1527268325719};\\\", \\\"{x:267,y:608,t:1527268325736};\\\", \\\"{x:252,y:610,t:1527268325752};\\\", \\\"{x:233,y:610,t:1527268325768};\\\", \\\"{x:218,y:610,t:1527268325785};\\\", \\\"{x:210,y:610,t:1527268325802};\\\", \\\"{x:209,y:610,t:1527268325820};\\\", \\\"{x:208,y:610,t:1527268325879};\\\", \\\"{x:209,y:608,t:1527268325887};\\\", \\\"{x:220,y:608,t:1527268325903};\\\", \\\"{x:246,y:608,t:1527268325920};\\\", \\\"{x:288,y:608,t:1527268325937};\\\", \\\"{x:338,y:613,t:1527268325953};\\\", \\\"{x:394,y:621,t:1527268325970};\\\", \\\"{x:444,y:629,t:1527268325986};\\\", \\\"{x:495,y:631,t:1527268326003};\\\", \\\"{x:532,y:631,t:1527268326021};\\\", \\\"{x:565,y:626,t:1527268326036};\\\", \\\"{x:597,y:616,t:1527268326053};\\\", \\\"{x:638,y:600,t:1527268326070};\\\", \\\"{x:693,y:567,t:1527268326087};\\\", \\\"{x:730,y:546,t:1527268326104};\\\", \\\"{x:761,y:530,t:1527268326120};\\\", \\\"{x:776,y:521,t:1527268326136};\\\", \\\"{x:783,y:517,t:1527268326153};\\\", \\\"{x:787,y:513,t:1527268326169};\\\", \\\"{x:792,y:511,t:1527268326186};\\\", \\\"{x:797,y:508,t:1527268326203};\\\", \\\"{x:804,y:505,t:1527268326220};\\\", \\\"{x:806,y:504,t:1527268326236};\\\", \\\"{x:808,y:503,t:1527268326253};\\\", \\\"{x:809,y:503,t:1527268326270};\\\", \\\"{x:810,y:503,t:1527268326286};\\\", \\\"{x:811,y:502,t:1527268326303};\\\", \\\"{x:813,y:502,t:1527268326319};\\\", \\\"{x:814,y:501,t:1527268326336};\\\", \\\"{x:815,y:500,t:1527268326400};\\\", \\\"{x:816,y:500,t:1527268326408};\\\", \\\"{x:817,y:500,t:1527268326419};\\\", \\\"{x:821,y:497,t:1527268326436};\\\", \\\"{x:823,y:497,t:1527268326453};\\\", \\\"{x:825,y:496,t:1527268326470};\\\", \\\"{x:827,y:496,t:1527268326569};\\\", \\\"{x:828,y:496,t:1527268326586};\\\", \\\"{x:829,y:496,t:1527268326603};\\\", \\\"{x:829,y:496,t:1527268326646};\\\", \\\"{x:829,y:497,t:1527268326718};\\\", \\\"{x:829,y:498,t:1527268326727};\\\", \\\"{x:827,y:498,t:1527268326736};\\\", \\\"{x:821,y:501,t:1527268326753};\\\", \\\"{x:811,y:510,t:1527268326770};\\\", \\\"{x:797,y:523,t:1527268326787};\\\", \\\"{x:778,y:539,t:1527268326804};\\\", \\\"{x:751,y:557,t:1527268326820};\\\", \\\"{x:712,y:574,t:1527268326838};\\\", \\\"{x:653,y:586,t:1527268326853};\\\", \\\"{x:576,y:593,t:1527268326869};\\\", \\\"{x:466,y:596,t:1527268326887};\\\", \\\"{x:388,y:596,t:1527268326903};\\\", \\\"{x:305,y:596,t:1527268326919};\\\", \\\"{x:219,y:596,t:1527268326936};\\\", \\\"{x:144,y:596,t:1527268326953};\\\", \\\"{x:80,y:596,t:1527268326971};\\\", \\\"{x:24,y:596,t:1527268326987};\\\", \\\"{x:0,y:596,t:1527268327004};\\\", \\\"{x:0,y:599,t:1527268327023};\\\", \\\"{x:0,y:601,t:1527268327037};\\\", \\\"{x:0,y:605,t:1527268327054};\\\", \\\"{x:0,y:613,t:1527268327071};\\\", \\\"{x:0,y:619,t:1527268327087};\\\", \\\"{x:0,y:623,t:1527268327104};\\\", \\\"{x:2,y:631,t:1527268327121};\\\", \\\"{x:6,y:637,t:1527268327138};\\\", \\\"{x:13,y:646,t:1527268327154};\\\", \\\"{x:25,y:654,t:1527268327171};\\\", \\\"{x:45,y:661,t:1527268327188};\\\", \\\"{x:67,y:663,t:1527268327207};\\\", \\\"{x:91,y:665,t:1527268327220};\\\", \\\"{x:114,y:665,t:1527268327237};\\\", \\\"{x:132,y:664,t:1527268327254};\\\", \\\"{x:145,y:657,t:1527268327270};\\\", \\\"{x:149,y:648,t:1527268327287};\\\", \\\"{x:153,y:642,t:1527268327304};\\\", \\\"{x:154,y:637,t:1527268327321};\\\", \\\"{x:156,y:632,t:1527268327337};\\\", \\\"{x:156,y:627,t:1527268327354};\\\", \\\"{x:156,y:625,t:1527268327371};\\\", \\\"{x:156,y:624,t:1527268327387};\\\", \\\"{x:156,y:623,t:1527268327455};\\\", \\\"{x:156,y:622,t:1527268327535};\\\", \\\"{x:159,y:620,t:1527268327543};\\\", \\\"{x:162,y:619,t:1527268327554};\\\", \\\"{x:168,y:617,t:1527268327570};\\\", \\\"{x:189,y:617,t:1527268327588};\\\", \\\"{x:226,y:621,t:1527268327604};\\\", \\\"{x:279,y:636,t:1527268327621};\\\", \\\"{x:334,y:650,t:1527268327638};\\\", \\\"{x:375,y:659,t:1527268327654};\\\", \\\"{x:419,y:669,t:1527268327671};\\\", \\\"{x:427,y:669,t:1527268327687};\\\", \\\"{x:428,y:669,t:1527268327704};\\\", \\\"{x:429,y:669,t:1527268327742};\\\", \\\"{x:430,y:669,t:1527268327767};\\\", \\\"{x:430,y:667,t:1527268327783};\\\", \\\"{x:430,y:666,t:1527268327799};\\\", \\\"{x:430,y:664,t:1527268327815};\\\", \\\"{x:430,y:663,t:1527268327831};\\\", \\\"{x:430,y:660,t:1527268327848};\\\", \\\"{x:430,y:658,t:1527268327856};\\\", \\\"{x:432,y:654,t:1527268327870};\\\", \\\"{x:453,y:634,t:1527268327889};\\\", \\\"{x:486,y:612,t:1527268327904};\\\", \\\"{x:538,y:582,t:1527268327922};\\\", \\\"{x:609,y:552,t:1527268327939};\\\", \\\"{x:688,y:526,t:1527268327955};\\\", \\\"{x:765,y:506,t:1527268327972};\\\", \\\"{x:808,y:493,t:1527268327988};\\\", \\\"{x:827,y:487,t:1527268328005};\\\", \\\"{x:829,y:487,t:1527268328021};\\\", \\\"{x:827,y:487,t:1527268328216};\\\", \\\"{x:825,y:490,t:1527268328223};\\\", \\\"{x:822,y:501,t:1527268328240};\\\", \\\"{x:821,y:508,t:1527268328255};\\\", \\\"{x:821,y:514,t:1527268328272};\\\", \\\"{x:821,y:515,t:1527268328376};\\\", \\\"{x:824,y:515,t:1527268328389};\\\", \\\"{x:831,y:512,t:1527268328407};\\\", \\\"{x:840,y:508,t:1527268328423};\\\", \\\"{x:842,y:507,t:1527268328438};\\\", \\\"{x:844,y:505,t:1527268328453};\\\", \\\"{x:845,y:505,t:1527268328471};\\\", \\\"{x:845,y:506,t:1527268328553};\\\", \\\"{x:844,y:506,t:1527268328572};\\\", \\\"{x:844,y:506,t:1527268328647};\\\", \\\"{x:842,y:508,t:1527268328880};\\\", \\\"{x:839,y:509,t:1527268328888};\\\", \\\"{x:834,y:511,t:1527268328905};\\\", \\\"{x:824,y:516,t:1527268328923};\\\", \\\"{x:811,y:521,t:1527268328939};\\\", \\\"{x:789,y:524,t:1527268328955};\\\", \\\"{x:745,y:531,t:1527268328972};\\\", \\\"{x:670,y:531,t:1527268328989};\\\", \\\"{x:562,y:531,t:1527268329005};\\\", \\\"{x:420,y:531,t:1527268329022};\\\", \\\"{x:201,y:536,t:1527268329039};\\\", \\\"{x:74,y:536,t:1527268329055};\\\", \\\"{x:0,y:536,t:1527268329072};\\\", \\\"{x:0,y:537,t:1527268329102};\\\", \\\"{x:0,y:538,t:1527268329118};\\\", \\\"{x:1,y:539,t:1527268329158};\\\", \\\"{x:4,y:540,t:1527268329172};\\\", \\\"{x:11,y:541,t:1527268329189};\\\", \\\"{x:23,y:541,t:1527268329206};\\\", \\\"{x:56,y:541,t:1527268329223};\\\", \\\"{x:85,y:541,t:1527268329239};\\\", \\\"{x:117,y:541,t:1527268329254};\\\", \\\"{x:144,y:541,t:1527268329271};\\\", \\\"{x:167,y:541,t:1527268329289};\\\", \\\"{x:183,y:541,t:1527268329305};\\\", \\\"{x:197,y:541,t:1527268329322};\\\", \\\"{x:211,y:541,t:1527268329339};\\\", \\\"{x:222,y:540,t:1527268329356};\\\", \\\"{x:238,y:539,t:1527268329372};\\\", \\\"{x:246,y:538,t:1527268329389};\\\", \\\"{x:253,y:537,t:1527268329406};\\\", \\\"{x:255,y:536,t:1527268329421};\\\", \\\"{x:254,y:536,t:1527268329503};\\\", \\\"{x:253,y:537,t:1527268329511};\\\", \\\"{x:250,y:537,t:1527268329522};\\\", \\\"{x:240,y:543,t:1527268329539};\\\", \\\"{x:230,y:550,t:1527268329556};\\\", \\\"{x:213,y:562,t:1527268329572};\\\", \\\"{x:200,y:572,t:1527268329590};\\\", \\\"{x:191,y:582,t:1527268329606};\\\", \\\"{x:181,y:597,t:1527268329623};\\\", \\\"{x:177,y:603,t:1527268329640};\\\", \\\"{x:175,y:604,t:1527268329656};\\\", \\\"{x:173,y:603,t:1527268329694};\\\", \\\"{x:173,y:599,t:1527268329706};\\\", \\\"{x:171,y:590,t:1527268329723};\\\", \\\"{x:167,y:578,t:1527268329739};\\\", \\\"{x:165,y:567,t:1527268329756};\\\", \\\"{x:161,y:559,t:1527268329774};\\\", \\\"{x:161,y:555,t:1527268329789};\\\", \\\"{x:161,y:554,t:1527268329805};\\\", \\\"{x:161,y:553,t:1527268329822};\\\", \\\"{x:161,y:552,t:1527268329838};\\\", \\\"{x:161,y:551,t:1527268329856};\\\", \\\"{x:161,y:550,t:1527268330095};\\\", \\\"{x:162,y:549,t:1527268330106};\\\", \\\"{x:165,y:548,t:1527268330123};\\\", \\\"{x:166,y:548,t:1527268330139};\\\", \\\"{x:172,y:548,t:1527268330156};\\\", \\\"{x:191,y:560,t:1527268330173};\\\", \\\"{x:220,y:580,t:1527268330190};\\\", \\\"{x:272,y:608,t:1527268330206};\\\", \\\"{x:359,y:659,t:1527268330223};\\\", \\\"{x:411,y:689,t:1527268330241};\\\", \\\"{x:447,y:706,t:1527268330256};\\\", \\\"{x:472,y:722,t:1527268330273};\\\", \\\"{x:481,y:728,t:1527268330289};\\\", \\\"{x:483,y:728,t:1527268330306};\\\", \\\"{x:483,y:729,t:1527268330335};\\\", \\\"{x:483,y:730,t:1527268330350};\\\", \\\"{x:483,y:731,t:1527268330359};\\\", \\\"{x:483,y:733,t:1527268330373};\\\", \\\"{x:484,y:736,t:1527268330389};\\\", \\\"{x:485,y:738,t:1527268330406};\\\", \\\"{x:485,y:739,t:1527268330630};\\\", \\\"{x:486,y:739,t:1527268330640};\\\", \\\"{x:486,y:737,t:1527268330691};\\\", \\\"{x:486,y:735,t:1527268330707};\\\", \\\"{x:486,y:734,t:1527268330723};\\\", \\\"{x:486,y:733,t:1527268330759};\\\", \\\"{x:487,y:731,t:1527268330976};\\\", \\\"{x:490,y:729,t:1527268330990};\\\", \\\"{x:509,y:722,t:1527268331008};\\\", \\\"{x:533,y:715,t:1527268331023};\\\", \\\"{x:563,y:707,t:1527268331041};\\\", \\\"{x:605,y:701,t:1527268331058};\\\", \\\"{x:650,y:689,t:1527268331074};\\\", \\\"{x:706,y:682,t:1527268331090};\\\", \\\"{x:767,y:671,t:1527268331107};\\\", \\\"{x:818,y:665,t:1527268331124};\\\", \\\"{x:856,y:656,t:1527268331140};\\\", \\\"{x:882,y:650,t:1527268331157};\\\", \\\"{x:908,y:645,t:1527268331174};\\\", \\\"{x:924,y:640,t:1527268331190};\\\", \\\"{x:943,y:635,t:1527268331208};\\\", \\\"{x:953,y:634,t:1527268331224};\\\", \\\"{x:962,y:631,t:1527268331240};\\\", \\\"{x:972,y:630,t:1527268331257};\\\", \\\"{x:981,y:629,t:1527268331275};\\\", \\\"{x:995,y:625,t:1527268331290};\\\", \\\"{x:1005,y:621,t:1527268331307};\\\", \\\"{x:1015,y:616,t:1527268331324};\\\", \\\"{x:1019,y:614,t:1527268331340};\\\", \\\"{x:1023,y:612,t:1527268331358};\\\", \\\"{x:1026,y:612,t:1527268331374};\\\", \\\"{x:1027,y:611,t:1527268331391};\\\", \\\"{x:1028,y:611,t:1527268331407};\\\", \\\"{x:1029,y:611,t:1527268331439};\\\", \\\"{x:1030,y:610,t:1527268331447};\\\" ] }, { \\\"rt\\\": 61215, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 416862, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-G -I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1035,y:654,t:1527268332524};\\\", \\\"{x:1035,y:657,t:1527268332536};\\\", \\\"{x:1035,y:658,t:1527268332543};\\\", \\\"{x:1034,y:658,t:1527268332559};\\\", \\\"{x:1033,y:660,t:1527268332575};\\\", \\\"{x:1031,y:662,t:1527268332591};\\\", \\\"{x:1026,y:663,t:1527268332608};\\\", \\\"{x:1025,y:664,t:1527268332625};\\\", \\\"{x:1024,y:664,t:1527268332687};\\\", \\\"{x:1022,y:664,t:1527268332695};\\\", \\\"{x:1015,y:664,t:1527268332708};\\\", \\\"{x:993,y:658,t:1527268332725};\\\", \\\"{x:958,y:643,t:1527268332741};\\\", \\\"{x:891,y:620,t:1527268332758};\\\", \\\"{x:779,y:598,t:1527268332774};\\\", \\\"{x:723,y:590,t:1527268332793};\\\", \\\"{x:678,y:581,t:1527268332808};\\\", \\\"{x:630,y:566,t:1527268332826};\\\", \\\"{x:594,y:556,t:1527268332842};\\\", \\\"{x:566,y:548,t:1527268332859};\\\", \\\"{x:541,y:539,t:1527268332875};\\\", \\\"{x:515,y:532,t:1527268332892};\\\", \\\"{x:483,y:518,t:1527268332908};\\\", \\\"{x:455,y:506,t:1527268332926};\\\", \\\"{x:429,y:495,t:1527268332942};\\\", \\\"{x:407,y:482,t:1527268332958};\\\", \\\"{x:382,y:466,t:1527268332975};\\\", \\\"{x:375,y:459,t:1527268332992};\\\", \\\"{x:372,y:457,t:1527268333008};\\\", \\\"{x:371,y:456,t:1527268333025};\\\", \\\"{x:371,y:455,t:1527268333119};\\\", \\\"{x:370,y:454,t:1527268333135};\\\", \\\"{x:369,y:453,t:1527268333143};\\\", \\\"{x:369,y:452,t:1527268333176};\\\", \\\"{x:369,y:451,t:1527268333663};\\\", \\\"{x:371,y:449,t:1527268333676};\\\", \\\"{x:374,y:447,t:1527268333692};\\\", \\\"{x:380,y:447,t:1527268333710};\\\", \\\"{x:384,y:444,t:1527268333727};\\\", \\\"{x:389,y:444,t:1527268333743};\\\", \\\"{x:400,y:444,t:1527268333759};\\\", \\\"{x:411,y:444,t:1527268333777};\\\", \\\"{x:425,y:444,t:1527268333792};\\\", \\\"{x:442,y:444,t:1527268333809};\\\", \\\"{x:462,y:447,t:1527268333827};\\\", \\\"{x:487,y:450,t:1527268333842};\\\", \\\"{x:510,y:452,t:1527268333859};\\\", \\\"{x:538,y:457,t:1527268333876};\\\", \\\"{x:565,y:457,t:1527268333893};\\\", \\\"{x:594,y:461,t:1527268333909};\\\", \\\"{x:620,y:464,t:1527268333927};\\\", \\\"{x:656,y:464,t:1527268333942};\\\", \\\"{x:678,y:464,t:1527268333959};\\\", \\\"{x:699,y:464,t:1527268333976};\\\", \\\"{x:722,y:464,t:1527268333993};\\\", \\\"{x:745,y:464,t:1527268334009};\\\", \\\"{x:768,y:464,t:1527268334026};\\\", \\\"{x:791,y:464,t:1527268334043};\\\", \\\"{x:818,y:464,t:1527268334060};\\\", \\\"{x:841,y:464,t:1527268334076};\\\", \\\"{x:868,y:464,t:1527268334094};\\\", \\\"{x:900,y:464,t:1527268334110};\\\", \\\"{x:927,y:464,t:1527268334127};\\\", \\\"{x:967,y:464,t:1527268334143};\\\", \\\"{x:993,y:464,t:1527268334159};\\\", \\\"{x:1018,y:464,t:1527268334176};\\\", \\\"{x:1044,y:467,t:1527268334193};\\\", \\\"{x:1068,y:469,t:1527268334210};\\\", \\\"{x:1090,y:474,t:1527268334226};\\\", \\\"{x:1112,y:476,t:1527268334244};\\\", \\\"{x:1135,y:479,t:1527268334259};\\\", \\\"{x:1153,y:482,t:1527268334276};\\\", \\\"{x:1169,y:485,t:1527268334293};\\\", \\\"{x:1185,y:487,t:1527268334310};\\\", \\\"{x:1202,y:491,t:1527268334326};\\\", \\\"{x:1232,y:498,t:1527268334343};\\\", \\\"{x:1255,y:505,t:1527268334360};\\\", \\\"{x:1272,y:508,t:1527268334376};\\\", \\\"{x:1286,y:513,t:1527268334394};\\\", \\\"{x:1303,y:517,t:1527268334410};\\\", \\\"{x:1313,y:519,t:1527268334427};\\\", \\\"{x:1323,y:523,t:1527268334443};\\\", \\\"{x:1331,y:526,t:1527268334460};\\\", \\\"{x:1332,y:527,t:1527268334476};\\\", \\\"{x:1333,y:528,t:1527268334503};\\\", \\\"{x:1334,y:528,t:1527268334852};\\\", \\\"{x:1333,y:534,t:1527268334865};\\\", \\\"{x:1325,y:543,t:1527268334881};\\\", \\\"{x:1318,y:551,t:1527268334898};\\\", \\\"{x:1311,y:559,t:1527268334915};\\\", \\\"{x:1304,y:565,t:1527268334932};\\\", \\\"{x:1300,y:569,t:1527268334947};\\\", \\\"{x:1298,y:572,t:1527268334964};\\\", \\\"{x:1295,y:575,t:1527268334982};\\\", \\\"{x:1291,y:579,t:1527268334997};\\\", \\\"{x:1285,y:584,t:1527268335015};\\\", \\\"{x:1276,y:590,t:1527268335031};\\\", \\\"{x:1268,y:594,t:1527268335048};\\\", \\\"{x:1259,y:599,t:1527268335064};\\\", \\\"{x:1250,y:603,t:1527268335082};\\\", \\\"{x:1238,y:605,t:1527268335097};\\\", \\\"{x:1232,y:607,t:1527268335115};\\\", \\\"{x:1219,y:610,t:1527268335132};\\\", \\\"{x:1212,y:612,t:1527268335149};\\\", \\\"{x:1203,y:613,t:1527268335165};\\\", \\\"{x:1196,y:613,t:1527268335182};\\\", \\\"{x:1189,y:613,t:1527268335199};\\\", \\\"{x:1181,y:613,t:1527268335215};\\\", \\\"{x:1174,y:612,t:1527268335231};\\\", \\\"{x:1165,y:612,t:1527268335249};\\\", \\\"{x:1153,y:612,t:1527268335265};\\\", \\\"{x:1141,y:614,t:1527268335282};\\\", \\\"{x:1135,y:614,t:1527268335299};\\\", \\\"{x:1130,y:616,t:1527268335315};\\\", \\\"{x:1127,y:616,t:1527268335331};\\\", \\\"{x:1126,y:616,t:1527268335349};\\\", \\\"{x:1125,y:616,t:1527268335365};\\\", \\\"{x:1124,y:616,t:1527268335420};\\\", \\\"{x:1123,y:616,t:1527268335432};\\\", \\\"{x:1117,y:616,t:1527268335449};\\\", \\\"{x:1112,y:612,t:1527268335465};\\\", \\\"{x:1103,y:606,t:1527268335482};\\\", \\\"{x:1091,y:597,t:1527268335498};\\\", \\\"{x:1081,y:589,t:1527268335515};\\\", \\\"{x:1069,y:582,t:1527268335531};\\\", \\\"{x:1061,y:574,t:1527268335548};\\\", \\\"{x:1056,y:571,t:1527268335566};\\\", \\\"{x:1052,y:567,t:1527268335581};\\\", \\\"{x:1045,y:560,t:1527268335598};\\\", \\\"{x:1037,y:549,t:1527268335615};\\\", \\\"{x:1035,y:543,t:1527268335631};\\\", \\\"{x:1033,y:542,t:1527268335648};\\\", \\\"{x:1033,y:541,t:1527268335665};\\\", \\\"{x:1033,y:540,t:1527268335681};\\\", \\\"{x:1033,y:539,t:1527268335730};\\\", \\\"{x:1035,y:536,t:1527268335748};\\\", \\\"{x:1041,y:533,t:1527268335765};\\\", \\\"{x:1044,y:531,t:1527268335781};\\\", \\\"{x:1048,y:529,t:1527268335799};\\\", \\\"{x:1051,y:528,t:1527268335816};\\\", \\\"{x:1052,y:527,t:1527268335831};\\\", \\\"{x:1055,y:526,t:1527268335849};\\\", \\\"{x:1056,y:525,t:1527268335865};\\\", \\\"{x:1058,y:525,t:1527268335881};\\\", \\\"{x:1061,y:524,t:1527268335898};\\\", \\\"{x:1065,y:524,t:1527268335914};\\\", \\\"{x:1068,y:524,t:1527268335931};\\\", \\\"{x:1071,y:524,t:1527268335948};\\\", \\\"{x:1073,y:524,t:1527268335965};\\\", \\\"{x:1075,y:524,t:1527268335982};\\\", \\\"{x:1076,y:524,t:1527268336002};\\\", \\\"{x:1077,y:524,t:1527268336015};\\\", \\\"{x:1078,y:524,t:1527268336033};\\\", \\\"{x:1079,y:524,t:1527268336050};\\\", \\\"{x:1080,y:524,t:1527268336065};\\\", \\\"{x:1081,y:524,t:1527268336082};\\\", \\\"{x:1082,y:524,t:1527268336098};\\\", \\\"{x:1083,y:524,t:1527268336115};\\\", \\\"{x:1084,y:524,t:1527268336132};\\\", \\\"{x:1086,y:524,t:1527268336148};\\\", \\\"{x:1088,y:525,t:1527268336165};\\\", \\\"{x:1089,y:525,t:1527268336182};\\\", \\\"{x:1090,y:525,t:1527268336199};\\\", \\\"{x:1091,y:525,t:1527268336218};\\\", \\\"{x:1091,y:526,t:1527268336555};\\\", \\\"{x:1093,y:527,t:1527268336566};\\\", \\\"{x:1094,y:527,t:1527268336582};\\\", \\\"{x:1097,y:529,t:1527268336599};\\\", \\\"{x:1100,y:529,t:1527268336615};\\\", \\\"{x:1104,y:530,t:1527268336632};\\\", \\\"{x:1107,y:531,t:1527268336649};\\\", \\\"{x:1111,y:532,t:1527268336666};\\\", \\\"{x:1112,y:532,t:1527268336691};\\\", \\\"{x:1114,y:531,t:1527268337179};\\\", \\\"{x:1114,y:528,t:1527268337188};\\\", \\\"{x:1114,y:525,t:1527268337200};\\\", \\\"{x:1114,y:521,t:1527268337217};\\\", \\\"{x:1114,y:518,t:1527268337234};\\\", \\\"{x:1114,y:517,t:1527268337249};\\\", \\\"{x:1114,y:515,t:1527268337267};\\\", \\\"{x:1114,y:514,t:1527268338610};\\\", \\\"{x:1114,y:515,t:1527268339170};\\\", \\\"{x:1113,y:515,t:1527268339184};\\\", \\\"{x:1109,y:518,t:1527268339201};\\\", \\\"{x:1104,y:518,t:1527268339218};\\\", \\\"{x:1094,y:518,t:1527268339235};\\\", \\\"{x:1086,y:518,t:1527268339251};\\\", \\\"{x:1079,y:517,t:1527268339268};\\\", \\\"{x:1073,y:514,t:1527268339284};\\\", \\\"{x:1070,y:514,t:1527268339301};\\\", \\\"{x:1064,y:513,t:1527268339318};\\\", \\\"{x:1056,y:513,t:1527268339334};\\\", \\\"{x:1051,y:513,t:1527268339351};\\\", \\\"{x:1045,y:513,t:1527268339369};\\\", \\\"{x:1043,y:513,t:1527268339384};\\\", \\\"{x:1039,y:514,t:1527268339402};\\\", \\\"{x:1038,y:526,t:1527268339418};\\\", \\\"{x:1038,y:536,t:1527268339434};\\\", \\\"{x:1038,y:542,t:1527268339451};\\\", \\\"{x:1046,y:551,t:1527268339469};\\\", \\\"{x:1057,y:559,t:1527268339485};\\\", \\\"{x:1076,y:569,t:1527268339502};\\\", \\\"{x:1093,y:577,t:1527268339519};\\\", \\\"{x:1104,y:584,t:1527268339535};\\\", \\\"{x:1113,y:588,t:1527268339551};\\\", \\\"{x:1118,y:589,t:1527268339568};\\\", \\\"{x:1118,y:586,t:1527268339635};\\\", \\\"{x:1118,y:582,t:1527268339651};\\\", \\\"{x:1117,y:574,t:1527268339668};\\\", \\\"{x:1116,y:563,t:1527268339685};\\\", \\\"{x:1115,y:556,t:1527268339702};\\\", \\\"{x:1111,y:548,t:1527268339718};\\\", \\\"{x:1108,y:539,t:1527268339736};\\\", \\\"{x:1103,y:533,t:1527268339751};\\\", \\\"{x:1102,y:529,t:1527268339768};\\\", \\\"{x:1101,y:527,t:1527268339786};\\\", \\\"{x:1101,y:521,t:1527268339802};\\\", \\\"{x:1101,y:508,t:1527268339818};\\\", \\\"{x:1101,y:503,t:1527268339835};\\\", \\\"{x:1101,y:500,t:1527268339851};\\\", \\\"{x:1100,y:496,t:1527268339869};\\\", \\\"{x:1098,y:493,t:1527268339885};\\\", \\\"{x:1097,y:492,t:1527268340012};\\\", \\\"{x:1096,y:492,t:1527268340019};\\\", \\\"{x:1092,y:493,t:1527268340035};\\\", \\\"{x:1089,y:496,t:1527268340051};\\\", \\\"{x:1088,y:504,t:1527268340069};\\\", \\\"{x:1088,y:514,t:1527268340086};\\\", \\\"{x:1088,y:526,t:1527268340102};\\\", \\\"{x:1088,y:537,t:1527268340119};\\\", \\\"{x:1092,y:545,t:1527268340136};\\\", \\\"{x:1096,y:551,t:1527268340153};\\\", \\\"{x:1100,y:556,t:1527268340168};\\\", \\\"{x:1104,y:560,t:1527268340186};\\\", \\\"{x:1107,y:562,t:1527268340202};\\\", \\\"{x:1112,y:563,t:1527268340219};\\\", \\\"{x:1117,y:563,t:1527268340235};\\\", \\\"{x:1124,y:564,t:1527268340253};\\\", \\\"{x:1132,y:564,t:1527268340269};\\\", \\\"{x:1142,y:564,t:1527268340286};\\\", \\\"{x:1151,y:564,t:1527268340303};\\\", \\\"{x:1159,y:564,t:1527268340319};\\\", \\\"{x:1168,y:564,t:1527268340336};\\\", \\\"{x:1175,y:564,t:1527268340353};\\\", \\\"{x:1186,y:566,t:1527268340369};\\\", \\\"{x:1195,y:566,t:1527268340386};\\\", \\\"{x:1207,y:567,t:1527268340403};\\\", \\\"{x:1222,y:569,t:1527268340419};\\\", \\\"{x:1232,y:572,t:1527268340436};\\\", \\\"{x:1243,y:572,t:1527268340453};\\\", \\\"{x:1252,y:572,t:1527268340470};\\\", \\\"{x:1257,y:572,t:1527268340486};\\\", \\\"{x:1261,y:572,t:1527268340503};\\\", \\\"{x:1266,y:572,t:1527268340520};\\\", \\\"{x:1270,y:572,t:1527268340536};\\\", \\\"{x:1275,y:572,t:1527268340553};\\\", \\\"{x:1280,y:572,t:1527268340570};\\\", \\\"{x:1287,y:572,t:1527268340586};\\\", \\\"{x:1294,y:573,t:1527268340603};\\\", \\\"{x:1309,y:576,t:1527268340619};\\\", \\\"{x:1319,y:576,t:1527268340635};\\\", \\\"{x:1327,y:577,t:1527268340652};\\\", \\\"{x:1337,y:578,t:1527268340669};\\\", \\\"{x:1345,y:578,t:1527268340685};\\\", \\\"{x:1351,y:578,t:1527268340702};\\\", \\\"{x:1355,y:578,t:1527268340720};\\\", \\\"{x:1358,y:578,t:1527268340735};\\\", \\\"{x:1361,y:578,t:1527268340752};\\\", \\\"{x:1365,y:576,t:1527268340769};\\\", \\\"{x:1369,y:575,t:1527268340785};\\\", \\\"{x:1378,y:572,t:1527268340802};\\\", \\\"{x:1385,y:569,t:1527268340819};\\\", \\\"{x:1387,y:569,t:1527268340835};\\\", \\\"{x:1391,y:568,t:1527268340852};\\\", \\\"{x:1395,y:567,t:1527268340869};\\\", \\\"{x:1399,y:566,t:1527268340887};\\\", \\\"{x:1403,y:564,t:1527268340903};\\\", \\\"{x:1406,y:563,t:1527268340919};\\\", \\\"{x:1410,y:562,t:1527268340937};\\\", \\\"{x:1412,y:561,t:1527268340953};\\\", \\\"{x:1413,y:561,t:1527268340970};\\\", \\\"{x:1417,y:561,t:1527268340986};\\\", \\\"{x:1419,y:561,t:1527268341002};\\\", \\\"{x:1420,y:560,t:1527268341019};\\\", \\\"{x:1422,y:560,t:1527268341037};\\\", \\\"{x:1425,y:560,t:1527268341052};\\\", \\\"{x:1426,y:560,t:1527268341070};\\\", \\\"{x:1429,y:560,t:1527268341086};\\\", \\\"{x:1432,y:560,t:1527268341102};\\\", \\\"{x:1436,y:560,t:1527268341119};\\\", \\\"{x:1439,y:560,t:1527268341136};\\\", \\\"{x:1444,y:560,t:1527268341152};\\\", \\\"{x:1451,y:560,t:1527268341169};\\\", \\\"{x:1463,y:560,t:1527268341186};\\\", \\\"{x:1473,y:560,t:1527268341202};\\\", \\\"{x:1482,y:560,t:1527268341219};\\\", \\\"{x:1495,y:560,t:1527268341236};\\\", \\\"{x:1509,y:560,t:1527268341252};\\\", \\\"{x:1520,y:560,t:1527268341270};\\\", \\\"{x:1530,y:560,t:1527268341286};\\\", \\\"{x:1537,y:560,t:1527268341303};\\\", \\\"{x:1543,y:560,t:1527268341319};\\\", \\\"{x:1548,y:560,t:1527268341337};\\\", \\\"{x:1553,y:560,t:1527268341354};\\\", \\\"{x:1560,y:560,t:1527268341370};\\\", \\\"{x:1578,y:560,t:1527268341386};\\\", \\\"{x:1592,y:560,t:1527268341403};\\\", \\\"{x:1607,y:560,t:1527268341419};\\\", \\\"{x:1618,y:560,t:1527268341437};\\\", \\\"{x:1624,y:560,t:1527268341453};\\\", \\\"{x:1627,y:560,t:1527268341470};\\\", \\\"{x:1631,y:560,t:1527268341487};\\\", \\\"{x:1635,y:560,t:1527268341503};\\\", \\\"{x:1640,y:562,t:1527268341520};\\\", \\\"{x:1644,y:564,t:1527268341537};\\\", \\\"{x:1648,y:567,t:1527268341553};\\\", \\\"{x:1652,y:570,t:1527268341569};\\\", \\\"{x:1657,y:573,t:1527268341587};\\\", \\\"{x:1658,y:574,t:1527268341603};\\\", \\\"{x:1659,y:575,t:1527268341620};\\\", \\\"{x:1660,y:576,t:1527268341637};\\\", \\\"{x:1661,y:577,t:1527268341654};\\\", \\\"{x:1662,y:578,t:1527268341670};\\\", \\\"{x:1665,y:580,t:1527268341686};\\\", \\\"{x:1662,y:581,t:1527268344804};\\\", \\\"{x:1658,y:581,t:1527268344811};\\\", \\\"{x:1652,y:581,t:1527268344823};\\\", \\\"{x:1640,y:581,t:1527268344841};\\\", \\\"{x:1627,y:581,t:1527268344857};\\\", \\\"{x:1615,y:581,t:1527268344873};\\\", \\\"{x:1610,y:581,t:1527268344890};\\\", \\\"{x:1609,y:581,t:1527268344906};\\\", \\\"{x:1608,y:581,t:1527268344923};\\\", \\\"{x:1607,y:582,t:1527268345020};\\\", \\\"{x:1607,y:583,t:1527268345036};\\\", \\\"{x:1606,y:583,t:1527268345043};\\\", \\\"{x:1605,y:584,t:1527268345058};\\\", \\\"{x:1604,y:584,t:1527268345073};\\\", \\\"{x:1603,y:585,t:1527268345090};\\\", \\\"{x:1602,y:586,t:1527268345107};\\\", \\\"{x:1601,y:586,t:1527268345122};\\\", \\\"{x:1601,y:587,t:1527268345139};\\\", \\\"{x:1599,y:587,t:1527268345162};\\\", \\\"{x:1599,y:589,t:1527268345173};\\\", \\\"{x:1597,y:590,t:1527268345189};\\\", \\\"{x:1595,y:592,t:1527268345210};\\\", \\\"{x:1594,y:592,t:1527268345235};\\\", \\\"{x:1593,y:592,t:1527268345251};\\\", \\\"{x:1593,y:593,t:1527268345258};\\\", \\\"{x:1592,y:593,t:1527268345272};\\\", \\\"{x:1590,y:594,t:1527268345290};\\\", \\\"{x:1589,y:595,t:1527268345306};\\\", \\\"{x:1587,y:596,t:1527268345323};\\\", \\\"{x:1584,y:598,t:1527268345339};\\\", \\\"{x:1582,y:599,t:1527268345357};\\\", \\\"{x:1581,y:600,t:1527268345374};\\\", \\\"{x:1577,y:602,t:1527268345390};\\\", \\\"{x:1573,y:606,t:1527268345407};\\\", \\\"{x:1568,y:609,t:1527268345424};\\\", \\\"{x:1562,y:616,t:1527268345439};\\\", \\\"{x:1556,y:624,t:1527268345456};\\\", \\\"{x:1549,y:639,t:1527268345474};\\\", \\\"{x:1545,y:652,t:1527268345490};\\\", \\\"{x:1540,y:667,t:1527268345506};\\\", \\\"{x:1540,y:674,t:1527268345523};\\\", \\\"{x:1540,y:680,t:1527268345539};\\\", \\\"{x:1540,y:686,t:1527268345556};\\\", \\\"{x:1540,y:690,t:1527268345574};\\\", \\\"{x:1540,y:695,t:1527268345590};\\\", \\\"{x:1540,y:701,t:1527268345607};\\\", \\\"{x:1541,y:706,t:1527268345624};\\\", \\\"{x:1541,y:710,t:1527268345640};\\\", \\\"{x:1542,y:715,t:1527268345657};\\\", \\\"{x:1543,y:721,t:1527268345674};\\\", \\\"{x:1543,y:730,t:1527268345690};\\\", \\\"{x:1546,y:743,t:1527268345707};\\\", \\\"{x:1547,y:751,t:1527268345724};\\\", \\\"{x:1549,y:764,t:1527268345741};\\\", \\\"{x:1556,y:780,t:1527268345757};\\\", \\\"{x:1562,y:795,t:1527268345774};\\\", \\\"{x:1567,y:806,t:1527268345790};\\\", \\\"{x:1572,y:815,t:1527268345807};\\\", \\\"{x:1577,y:823,t:1527268345824};\\\", \\\"{x:1578,y:828,t:1527268345841};\\\", \\\"{x:1580,y:832,t:1527268345856};\\\", \\\"{x:1580,y:836,t:1527268345874};\\\", \\\"{x:1579,y:839,t:1527268345891};\\\", \\\"{x:1578,y:840,t:1527268345915};\\\", \\\"{x:1577,y:841,t:1527268345939};\\\", \\\"{x:1576,y:842,t:1527268345954};\\\", \\\"{x:1575,y:843,t:1527268345962};\\\", \\\"{x:1574,y:844,t:1527268345978};\\\", \\\"{x:1573,y:845,t:1527268345990};\\\", \\\"{x:1571,y:847,t:1527268346006};\\\", \\\"{x:1566,y:851,t:1527268346024};\\\", \\\"{x:1555,y:855,t:1527268346041};\\\", \\\"{x:1539,y:858,t:1527268346057};\\\", \\\"{x:1524,y:860,t:1527268346073};\\\", \\\"{x:1503,y:860,t:1527268346090};\\\", \\\"{x:1492,y:860,t:1527268346106};\\\", \\\"{x:1480,y:860,t:1527268346124};\\\", \\\"{x:1470,y:860,t:1527268346141};\\\", \\\"{x:1461,y:860,t:1527268346157};\\\", \\\"{x:1455,y:860,t:1527268346174};\\\", \\\"{x:1451,y:860,t:1527268346191};\\\", \\\"{x:1446,y:860,t:1527268346208};\\\", \\\"{x:1444,y:860,t:1527268346224};\\\", \\\"{x:1443,y:860,t:1527268346241};\\\", \\\"{x:1441,y:860,t:1527268346258};\\\", \\\"{x:1438,y:860,t:1527268346276};\\\", \\\"{x:1436,y:860,t:1527268346291};\\\", \\\"{x:1433,y:860,t:1527268346308};\\\", \\\"{x:1429,y:860,t:1527268346325};\\\", \\\"{x:1425,y:859,t:1527268346341};\\\", \\\"{x:1419,y:857,t:1527268346359};\\\", \\\"{x:1410,y:854,t:1527268346374};\\\", \\\"{x:1399,y:850,t:1527268346391};\\\", \\\"{x:1385,y:847,t:1527268346408};\\\", \\\"{x:1374,y:841,t:1527268346424};\\\", \\\"{x:1360,y:835,t:1527268346442};\\\", \\\"{x:1349,y:828,t:1527268346458};\\\", \\\"{x:1337,y:821,t:1527268346474};\\\", \\\"{x:1320,y:807,t:1527268346490};\\\", \\\"{x:1313,y:797,t:1527268346508};\\\", \\\"{x:1309,y:790,t:1527268346524};\\\", \\\"{x:1307,y:785,t:1527268346540};\\\", \\\"{x:1306,y:780,t:1527268346557};\\\", \\\"{x:1306,y:778,t:1527268346574};\\\", \\\"{x:1306,y:773,t:1527268346591};\\\", \\\"{x:1306,y:772,t:1527268346607};\\\", \\\"{x:1306,y:770,t:1527268346624};\\\", \\\"{x:1306,y:768,t:1527268346641};\\\", \\\"{x:1308,y:764,t:1527268346658};\\\", \\\"{x:1310,y:759,t:1527268346675};\\\", \\\"{x:1313,y:754,t:1527268346691};\\\", \\\"{x:1314,y:750,t:1527268346708};\\\", \\\"{x:1315,y:748,t:1527268346725};\\\", \\\"{x:1316,y:747,t:1527268346740};\\\", \\\"{x:1317,y:747,t:1527268346757};\\\", \\\"{x:1317,y:746,t:1527268346778};\\\", \\\"{x:1317,y:745,t:1527268346791};\\\", \\\"{x:1318,y:745,t:1527268346819};\\\", \\\"{x:1319,y:744,t:1527268346860};\\\", \\\"{x:1320,y:744,t:1527268346883};\\\", \\\"{x:1321,y:744,t:1527268346891};\\\", \\\"{x:1322,y:743,t:1527268346915};\\\", \\\"{x:1323,y:743,t:1527268346955};\\\", \\\"{x:1324,y:742,t:1527268346963};\\\", \\\"{x:1325,y:741,t:1527268346987};\\\", \\\"{x:1328,y:741,t:1527268347019};\\\", \\\"{x:1328,y:740,t:1527268347051};\\\", \\\"{x:1329,y:740,t:1527268347067};\\\", \\\"{x:1331,y:739,t:1527268347092};\\\", \\\"{x:1327,y:739,t:1527268347435};\\\", \\\"{x:1324,y:739,t:1527268347442};\\\", \\\"{x:1314,y:738,t:1527268347458};\\\", \\\"{x:1304,y:737,t:1527268347474};\\\", \\\"{x:1297,y:736,t:1527268347492};\\\", \\\"{x:1289,y:735,t:1527268347508};\\\", \\\"{x:1288,y:735,t:1527268347524};\\\", \\\"{x:1287,y:735,t:1527268347542};\\\", \\\"{x:1286,y:734,t:1527268347559};\\\", \\\"{x:1284,y:734,t:1527268347634};\\\", \\\"{x:1283,y:734,t:1527268347643};\\\", \\\"{x:1280,y:735,t:1527268347658};\\\", \\\"{x:1278,y:736,t:1527268347674};\\\", \\\"{x:1273,y:737,t:1527268347691};\\\", \\\"{x:1267,y:738,t:1527268347709};\\\", \\\"{x:1262,y:739,t:1527268347725};\\\", \\\"{x:1258,y:739,t:1527268347742};\\\", \\\"{x:1256,y:739,t:1527268347758};\\\", \\\"{x:1253,y:739,t:1527268347775};\\\", \\\"{x:1252,y:739,t:1527268347791};\\\", \\\"{x:1250,y:741,t:1527268347809};\\\", \\\"{x:1246,y:742,t:1527268347826};\\\", \\\"{x:1242,y:742,t:1527268347842};\\\", \\\"{x:1232,y:742,t:1527268347858};\\\", \\\"{x:1224,y:742,t:1527268347875};\\\", \\\"{x:1216,y:742,t:1527268347891};\\\", \\\"{x:1206,y:742,t:1527268347908};\\\", \\\"{x:1193,y:742,t:1527268347925};\\\", \\\"{x:1182,y:742,t:1527268347942};\\\", \\\"{x:1170,y:742,t:1527268347958};\\\", \\\"{x:1160,y:742,t:1527268347976};\\\", \\\"{x:1149,y:742,t:1527268347992};\\\", \\\"{x:1140,y:742,t:1527268348009};\\\", \\\"{x:1134,y:742,t:1527268348026};\\\", \\\"{x:1133,y:742,t:1527268348041};\\\", \\\"{x:1132,y:742,t:1527268349194};\\\", \\\"{x:1133,y:743,t:1527268349210};\\\", \\\"{x:1135,y:745,t:1527268349225};\\\", \\\"{x:1136,y:747,t:1527268349243};\\\", \\\"{x:1138,y:749,t:1527268349259};\\\", \\\"{x:1140,y:749,t:1527268349277};\\\", \\\"{x:1141,y:750,t:1527268349299};\\\", \\\"{x:1142,y:750,t:1527268349322};\\\", \\\"{x:1143,y:751,t:1527268349330};\\\", \\\"{x:1144,y:752,t:1527268349411};\\\", \\\"{x:1145,y:752,t:1527268349427};\\\", \\\"{x:1146,y:752,t:1527268349444};\\\", \\\"{x:1148,y:752,t:1527268349460};\\\", \\\"{x:1149,y:752,t:1527268349476};\\\", \\\"{x:1153,y:752,t:1527268349493};\\\", \\\"{x:1159,y:752,t:1527268349509};\\\", \\\"{x:1164,y:754,t:1527268349526};\\\", \\\"{x:1170,y:755,t:1527268349543};\\\", \\\"{x:1177,y:756,t:1527268349560};\\\", \\\"{x:1184,y:756,t:1527268349577};\\\", \\\"{x:1190,y:756,t:1527268349594};\\\", \\\"{x:1195,y:756,t:1527268349610};\\\", \\\"{x:1199,y:756,t:1527268349626};\\\", \\\"{x:1202,y:756,t:1527268349644};\\\", \\\"{x:1205,y:756,t:1527268349660};\\\", \\\"{x:1207,y:755,t:1527268349677};\\\", \\\"{x:1208,y:755,t:1527268349694};\\\", \\\"{x:1210,y:754,t:1527268349710};\\\", \\\"{x:1212,y:753,t:1527268349727};\\\", \\\"{x:1216,y:751,t:1527268349744};\\\", \\\"{x:1219,y:750,t:1527268349760};\\\", \\\"{x:1220,y:750,t:1527268349777};\\\", \\\"{x:1222,y:748,t:1527268349793};\\\", \\\"{x:1223,y:748,t:1527268349810};\\\", \\\"{x:1224,y:747,t:1527268349826};\\\", \\\"{x:1226,y:747,t:1527268349843};\\\", \\\"{x:1229,y:745,t:1527268349861};\\\", \\\"{x:1230,y:743,t:1527268349876};\\\", \\\"{x:1232,y:742,t:1527268349893};\\\", \\\"{x:1233,y:741,t:1527268349910};\\\", \\\"{x:1235,y:740,t:1527268349927};\\\", \\\"{x:1237,y:738,t:1527268349944};\\\", \\\"{x:1239,y:735,t:1527268349961};\\\", \\\"{x:1242,y:729,t:1527268349977};\\\", \\\"{x:1243,y:723,t:1527268349993};\\\", \\\"{x:1246,y:716,t:1527268350010};\\\", \\\"{x:1247,y:712,t:1527268350027};\\\", \\\"{x:1247,y:707,t:1527268350043};\\\", \\\"{x:1249,y:700,t:1527268350060};\\\", \\\"{x:1249,y:691,t:1527268350077};\\\", \\\"{x:1250,y:683,t:1527268350094};\\\", \\\"{x:1250,y:670,t:1527268350111};\\\", \\\"{x:1248,y:659,t:1527268350127};\\\", \\\"{x:1246,y:652,t:1527268350144};\\\", \\\"{x:1243,y:645,t:1527268350160};\\\", \\\"{x:1241,y:639,t:1527268350176};\\\", \\\"{x:1237,y:633,t:1527268350194};\\\", \\\"{x:1234,y:627,t:1527268350211};\\\", \\\"{x:1233,y:624,t:1527268350227};\\\", \\\"{x:1232,y:622,t:1527268350244};\\\", \\\"{x:1232,y:621,t:1527268350261};\\\", \\\"{x:1231,y:619,t:1527268350278};\\\", \\\"{x:1231,y:617,t:1527268350294};\\\", \\\"{x:1231,y:616,t:1527268350311};\\\", \\\"{x:1231,y:614,t:1527268350328};\\\", \\\"{x:1231,y:612,t:1527268350344};\\\", \\\"{x:1231,y:610,t:1527268350361};\\\", \\\"{x:1231,y:606,t:1527268350378};\\\", \\\"{x:1231,y:604,t:1527268350394};\\\", \\\"{x:1232,y:599,t:1527268350410};\\\", \\\"{x:1234,y:597,t:1527268350428};\\\", \\\"{x:1235,y:595,t:1527268350444};\\\", \\\"{x:1238,y:591,t:1527268350461};\\\", \\\"{x:1239,y:589,t:1527268350478};\\\", \\\"{x:1241,y:586,t:1527268350494};\\\", \\\"{x:1243,y:582,t:1527268350511};\\\", \\\"{x:1245,y:579,t:1527268350528};\\\", \\\"{x:1248,y:575,t:1527268350544};\\\", \\\"{x:1249,y:573,t:1527268350560};\\\", \\\"{x:1252,y:570,t:1527268350578};\\\", \\\"{x:1253,y:566,t:1527268350593};\\\", \\\"{x:1256,y:561,t:1527268350610};\\\", \\\"{x:1258,y:558,t:1527268350628};\\\", \\\"{x:1259,y:556,t:1527268350644};\\\", \\\"{x:1260,y:554,t:1527268350661};\\\", \\\"{x:1261,y:553,t:1527268350678};\\\", \\\"{x:1262,y:552,t:1527268350695};\\\", \\\"{x:1263,y:552,t:1527268350923};\\\", \\\"{x:1264,y:554,t:1527268350947};\\\", \\\"{x:1265,y:555,t:1527268350961};\\\", \\\"{x:1266,y:556,t:1527268350978};\\\", \\\"{x:1266,y:558,t:1527268350996};\\\", \\\"{x:1266,y:559,t:1527268351043};\\\", \\\"{x:1268,y:560,t:1527268351059};\\\", \\\"{x:1268,y:561,t:1527268351075};\\\", \\\"{x:1268,y:562,t:1527268351099};\\\", \\\"{x:1268,y:564,t:1527268351139};\\\", \\\"{x:1269,y:564,t:1527268351147};\\\", \\\"{x:1269,y:565,t:1527268351163};\\\", \\\"{x:1269,y:567,t:1527268351178};\\\", \\\"{x:1271,y:568,t:1527268351194};\\\", \\\"{x:1271,y:569,t:1527268351227};\\\", \\\"{x:1271,y:570,t:1527268351275};\\\", \\\"{x:1272,y:570,t:1527268351283};\\\", \\\"{x:1272,y:571,t:1527268351323};\\\", \\\"{x:1273,y:572,t:1527268351467};\\\", \\\"{x:1275,y:572,t:1527268351482};\\\", \\\"{x:1276,y:572,t:1527268351495};\\\", \\\"{x:1278,y:572,t:1527268351512};\\\", \\\"{x:1280,y:571,t:1527268351528};\\\", \\\"{x:1282,y:570,t:1527268351545};\\\", \\\"{x:1284,y:569,t:1527268351562};\\\", \\\"{x:1289,y:566,t:1527268351579};\\\", \\\"{x:1291,y:564,t:1527268351594};\\\", \\\"{x:1292,y:563,t:1527268351626};\\\", \\\"{x:1291,y:563,t:1527268351842};\\\", \\\"{x:1289,y:564,t:1527268351858};\\\", \\\"{x:1287,y:564,t:1527268351875};\\\", \\\"{x:1286,y:566,t:1527268351890};\\\", \\\"{x:1285,y:568,t:1527268351912};\\\", \\\"{x:1284,y:570,t:1527268351929};\\\", \\\"{x:1284,y:572,t:1527268351945};\\\", \\\"{x:1283,y:574,t:1527268351962};\\\", \\\"{x:1282,y:577,t:1527268351978};\\\", \\\"{x:1281,y:579,t:1527268351996};\\\", \\\"{x:1281,y:582,t:1527268352013};\\\", \\\"{x:1281,y:584,t:1527268352029};\\\", \\\"{x:1281,y:586,t:1527268352046};\\\", \\\"{x:1281,y:587,t:1527268352062};\\\", \\\"{x:1281,y:589,t:1527268352079};\\\", \\\"{x:1281,y:593,t:1527268352096};\\\", \\\"{x:1281,y:596,t:1527268352111};\\\", \\\"{x:1281,y:599,t:1527268352129};\\\", \\\"{x:1281,y:603,t:1527268352146};\\\", \\\"{x:1281,y:607,t:1527268352162};\\\", \\\"{x:1281,y:613,t:1527268352179};\\\", \\\"{x:1281,y:616,t:1527268352196};\\\", \\\"{x:1281,y:618,t:1527268352211};\\\", \\\"{x:1281,y:620,t:1527268352228};\\\", \\\"{x:1281,y:623,t:1527268352246};\\\", \\\"{x:1282,y:626,t:1527268352263};\\\", \\\"{x:1282,y:630,t:1527268352279};\\\", \\\"{x:1283,y:634,t:1527268352296};\\\", \\\"{x:1284,y:638,t:1527268352313};\\\", \\\"{x:1285,y:640,t:1527268352329};\\\", \\\"{x:1285,y:643,t:1527268352346};\\\", \\\"{x:1287,y:646,t:1527268352361};\\\", \\\"{x:1287,y:647,t:1527268352378};\\\", \\\"{x:1288,y:650,t:1527268352396};\\\", \\\"{x:1289,y:653,t:1527268352412};\\\", \\\"{x:1289,y:656,t:1527268352429};\\\", \\\"{x:1290,y:658,t:1527268352445};\\\", \\\"{x:1291,y:661,t:1527268352463};\\\", \\\"{x:1292,y:661,t:1527268352479};\\\", \\\"{x:1293,y:662,t:1527268352496};\\\", \\\"{x:1293,y:663,t:1527268352513};\\\", \\\"{x:1293,y:664,t:1527268352528};\\\", \\\"{x:1293,y:665,t:1527268352545};\\\", \\\"{x:1295,y:669,t:1527268352564};\\\", \\\"{x:1295,y:670,t:1527268352578};\\\", \\\"{x:1295,y:671,t:1527268352596};\\\", \\\"{x:1295,y:673,t:1527268352613};\\\", \\\"{x:1295,y:674,t:1527268352628};\\\", \\\"{x:1296,y:676,t:1527268352646};\\\", \\\"{x:1296,y:678,t:1527268352666};\\\", \\\"{x:1296,y:679,t:1527268352679};\\\", \\\"{x:1296,y:680,t:1527268352698};\\\", \\\"{x:1296,y:681,t:1527268352722};\\\", \\\"{x:1296,y:682,t:1527268352770};\\\", \\\"{x:1296,y:683,t:1527268352786};\\\", \\\"{x:1296,y:684,t:1527268352796};\\\", \\\"{x:1296,y:685,t:1527268352813};\\\", \\\"{x:1296,y:687,t:1527268352830};\\\", \\\"{x:1296,y:689,t:1527268352845};\\\", \\\"{x:1296,y:691,t:1527268352863};\\\", \\\"{x:1296,y:692,t:1527268352879};\\\", \\\"{x:1296,y:694,t:1527268352896};\\\", \\\"{x:1296,y:695,t:1527268352913};\\\", \\\"{x:1296,y:697,t:1527268352930};\\\", \\\"{x:1296,y:698,t:1527268352946};\\\", \\\"{x:1297,y:700,t:1527268352963};\\\", \\\"{x:1298,y:700,t:1527268352980};\\\", \\\"{x:1298,y:702,t:1527268353002};\\\", \\\"{x:1299,y:703,t:1527268353013};\\\", \\\"{x:1299,y:706,t:1527268353030};\\\", \\\"{x:1300,y:709,t:1527268353045};\\\", \\\"{x:1301,y:712,t:1527268353063};\\\", \\\"{x:1301,y:715,t:1527268353080};\\\", \\\"{x:1301,y:717,t:1527268353097};\\\", \\\"{x:1301,y:719,t:1527268353112};\\\", \\\"{x:1301,y:720,t:1527268353130};\\\", \\\"{x:1301,y:722,t:1527268353146};\\\", \\\"{x:1301,y:723,t:1527268353163};\\\", \\\"{x:1301,y:724,t:1527268353235};\\\", \\\"{x:1301,y:726,t:1527268353251};\\\", \\\"{x:1300,y:726,t:1527268353267};\\\", \\\"{x:1300,y:727,t:1527268353281};\\\", \\\"{x:1299,y:729,t:1527268353297};\\\", \\\"{x:1298,y:729,t:1527268353313};\\\", \\\"{x:1298,y:730,t:1527268353330};\\\", \\\"{x:1297,y:731,t:1527268353427};\\\", \\\"{x:1296,y:731,t:1527268353450};\\\", \\\"{x:1295,y:732,t:1527268353463};\\\", \\\"{x:1294,y:732,t:1527268353499};\\\", \\\"{x:1292,y:733,t:1527268353604};\\\", \\\"{x:1292,y:734,t:1527268353614};\\\", \\\"{x:1289,y:737,t:1527268353630};\\\", \\\"{x:1289,y:740,t:1527268353648};\\\", \\\"{x:1287,y:744,t:1527268353664};\\\", \\\"{x:1287,y:745,t:1527268353681};\\\", \\\"{x:1286,y:746,t:1527268353698};\\\", \\\"{x:1285,y:747,t:1527268353715};\\\", \\\"{x:1285,y:748,t:1527268353730};\\\", \\\"{x:1284,y:751,t:1527268353747};\\\", \\\"{x:1283,y:753,t:1527268353764};\\\", \\\"{x:1281,y:757,t:1527268353780};\\\", \\\"{x:1279,y:760,t:1527268353798};\\\", \\\"{x:1278,y:764,t:1527268353815};\\\", \\\"{x:1277,y:766,t:1527268353830};\\\", \\\"{x:1275,y:770,t:1527268353847};\\\", \\\"{x:1275,y:771,t:1527268353864};\\\", \\\"{x:1273,y:775,t:1527268353880};\\\", \\\"{x:1273,y:777,t:1527268353897};\\\", \\\"{x:1273,y:782,t:1527268353913};\\\", \\\"{x:1273,y:792,t:1527268353930};\\\", \\\"{x:1273,y:797,t:1527268353947};\\\", \\\"{x:1273,y:800,t:1527268353964};\\\", \\\"{x:1273,y:802,t:1527268353981};\\\", \\\"{x:1273,y:805,t:1527268353997};\\\", \\\"{x:1273,y:806,t:1527268354014};\\\", \\\"{x:1273,y:809,t:1527268354031};\\\", \\\"{x:1273,y:810,t:1527268354047};\\\", \\\"{x:1273,y:812,t:1527268354065};\\\", \\\"{x:1273,y:813,t:1527268354083};\\\", \\\"{x:1273,y:814,t:1527268354107};\\\", \\\"{x:1273,y:815,t:1527268354140};\\\", \\\"{x:1272,y:816,t:1527268354163};\\\", \\\"{x:1271,y:816,t:1527268354203};\\\", \\\"{x:1270,y:818,t:1527268354227};\\\", \\\"{x:1269,y:818,t:1527268354243};\\\", \\\"{x:1268,y:818,t:1527268354267};\\\", \\\"{x:1269,y:818,t:1527268355932};\\\", \\\"{x:1271,y:818,t:1527268355950};\\\", \\\"{x:1272,y:818,t:1527268355965};\\\", \\\"{x:1274,y:818,t:1527268355982};\\\", \\\"{x:1276,y:818,t:1527268356000};\\\", \\\"{x:1277,y:818,t:1527268356016};\\\", \\\"{x:1278,y:819,t:1527268356034};\\\", \\\"{x:1279,y:819,t:1527268356050};\\\", \\\"{x:1280,y:819,t:1527268356066};\\\", \\\"{x:1282,y:821,t:1527268356090};\\\", \\\"{x:1283,y:821,t:1527268356114};\\\", \\\"{x:1284,y:821,t:1527268356131};\\\", \\\"{x:1285,y:821,t:1527268357074};\\\", \\\"{x:1285,y:822,t:1527268357098};\\\", \\\"{x:1284,y:822,t:1527268357114};\\\", \\\"{x:1284,y:823,t:1527268357146};\\\", \\\"{x:1284,y:824,t:1527268357210};\\\", \\\"{x:1283,y:824,t:1527268357226};\\\", \\\"{x:1283,y:825,t:1527268357250};\\\", \\\"{x:1282,y:825,t:1527268357267};\\\", \\\"{x:1281,y:825,t:1527268357306};\\\", \\\"{x:1281,y:826,t:1527268357371};\\\", \\\"{x:1281,y:827,t:1527268357394};\\\", \\\"{x:1280,y:828,t:1527268357426};\\\", \\\"{x:1280,y:829,t:1527268357611};\\\", \\\"{x:1280,y:830,t:1527268357644};\\\", \\\"{x:1281,y:831,t:1527268357748};\\\", \\\"{x:1280,y:830,t:1527268358187};\\\", \\\"{x:1279,y:830,t:1527268358201};\\\", \\\"{x:1278,y:829,t:1527268358250};\\\", \\\"{x:1286,y:799,t:1527268387962};\\\", \\\"{x:1286,y:798,t:1527268387976};\\\", \\\"{x:1281,y:798,t:1527268389282};\\\", \\\"{x:1268,y:792,t:1527268389294};\\\", \\\"{x:1239,y:783,t:1527268389310};\\\", \\\"{x:1221,y:776,t:1527268389328};\\\", \\\"{x:1202,y:769,t:1527268389345};\\\", \\\"{x:1174,y:750,t:1527268389361};\\\", \\\"{x:1120,y:708,t:1527268389377};\\\", \\\"{x:956,y:611,t:1527268389394};\\\", \\\"{x:810,y:549,t:1527268389412};\\\", \\\"{x:664,y:489,t:1527268389428};\\\", \\\"{x:523,y:448,t:1527268389444};\\\", \\\"{x:295,y:356,t:1527268389475};\\\", \\\"{x:232,y:332,t:1527268389491};\\\", \\\"{x:197,y:324,t:1527268389508};\\\", \\\"{x:176,y:322,t:1527268389524};\\\", \\\"{x:168,y:319,t:1527268389541};\\\", \\\"{x:166,y:319,t:1527268389557};\\\", \\\"{x:165,y:319,t:1527268389649};\\\", \\\"{x:163,y:319,t:1527268389657};\\\", \\\"{x:162,y:323,t:1527268389675};\\\", \\\"{x:161,y:328,t:1527268389691};\\\", \\\"{x:161,y:331,t:1527268389707};\\\", \\\"{x:162,y:338,t:1527268389724};\\\", \\\"{x:165,y:345,t:1527268389741};\\\", \\\"{x:171,y:352,t:1527268389757};\\\", \\\"{x:177,y:358,t:1527268389775};\\\", \\\"{x:191,y:365,t:1527268389791};\\\", \\\"{x:211,y:372,t:1527268389808};\\\", \\\"{x:238,y:382,t:1527268389824};\\\", \\\"{x:279,y:392,t:1527268389841};\\\", \\\"{x:347,y:407,t:1527268389858};\\\", \\\"{x:389,y:412,t:1527268389874};\\\", \\\"{x:423,y:419,t:1527268389891};\\\", \\\"{x:449,y:423,t:1527268389908};\\\", \\\"{x:468,y:425,t:1527268389925};\\\", \\\"{x:480,y:429,t:1527268389942};\\\", \\\"{x:484,y:430,t:1527268389958};\\\", \\\"{x:487,y:431,t:1527268389975};\\\", \\\"{x:489,y:432,t:1527268389991};\\\", \\\"{x:490,y:433,t:1527268390008};\\\", \\\"{x:491,y:433,t:1527268390026};\\\", \\\"{x:492,y:435,t:1527268390075};\\\", \\\"{x:493,y:440,t:1527268390092};\\\", \\\"{x:494,y:450,t:1527268390109};\\\", \\\"{x:496,y:464,t:1527268390125};\\\", \\\"{x:501,y:479,t:1527268390141};\\\", \\\"{x:503,y:494,t:1527268390158};\\\", \\\"{x:504,y:498,t:1527268390174};\\\", \\\"{x:504,y:502,t:1527268390191};\\\", \\\"{x:504,y:503,t:1527268390210};\\\", \\\"{x:504,y:504,t:1527268390234};\\\", \\\"{x:504,y:505,t:1527268390250};\\\", \\\"{x:503,y:506,t:1527268390273};\\\", \\\"{x:504,y:507,t:1527268390426};\\\", \\\"{x:527,y:511,t:1527268390442};\\\", \\\"{x:575,y:518,t:1527268390459};\\\", \\\"{x:644,y:525,t:1527268390475};\\\", \\\"{x:709,y:527,t:1527268390492};\\\", \\\"{x:742,y:527,t:1527268390508};\\\", \\\"{x:757,y:527,t:1527268390525};\\\", \\\"{x:758,y:527,t:1527268390545};\\\", \\\"{x:758,y:528,t:1527268390633};\\\", \\\"{x:757,y:528,t:1527268390642};\\\", \\\"{x:753,y:528,t:1527268390659};\\\", \\\"{x:746,y:528,t:1527268390675};\\\", \\\"{x:728,y:528,t:1527268390692};\\\", \\\"{x:702,y:526,t:1527268390710};\\\", \\\"{x:668,y:521,t:1527268390725};\\\", \\\"{x:623,y:513,t:1527268390742};\\\", \\\"{x:596,y:510,t:1527268390759};\\\", \\\"{x:580,y:507,t:1527268390776};\\\", \\\"{x:574,y:505,t:1527268390792};\\\", \\\"{x:574,y:504,t:1527268390810};\\\", \\\"{x:574,y:502,t:1527268390874};\\\", \\\"{x:574,y:500,t:1527268390882};\\\", \\\"{x:576,y:498,t:1527268390892};\\\", \\\"{x:577,y:497,t:1527268390910};\\\", \\\"{x:579,y:496,t:1527268390925};\\\", \\\"{x:581,y:496,t:1527268390942};\\\", \\\"{x:581,y:495,t:1527268390960};\\\", \\\"{x:584,y:494,t:1527268390976};\\\", \\\"{x:592,y:494,t:1527268390992};\\\", \\\"{x:607,y:491,t:1527268391010};\\\", \\\"{x:621,y:491,t:1527268391025};\\\", \\\"{x:624,y:491,t:1527268391043};\\\", \\\"{x:626,y:491,t:1527268391059};\\\", \\\"{x:627,y:491,t:1527268391114};\\\", \\\"{x:627,y:492,t:1527268391126};\\\", \\\"{x:627,y:493,t:1527268391143};\\\", \\\"{x:627,y:494,t:1527268391159};\\\", \\\"{x:627,y:495,t:1527268391176};\\\", \\\"{x:627,y:496,t:1527268391242};\\\", \\\"{x:626,y:497,t:1527268391258};\\\", \\\"{x:623,y:498,t:1527268391274};\\\", \\\"{x:623,y:499,t:1527268391281};\\\", \\\"{x:622,y:500,t:1527268391298};\\\", \\\"{x:621,y:500,t:1527268391310};\\\", \\\"{x:620,y:500,t:1527268391326};\\\", \\\"{x:618,y:501,t:1527268391343};\\\", \\\"{x:617,y:501,t:1527268391360};\\\", \\\"{x:615,y:503,t:1527268391376};\\\", \\\"{x:613,y:503,t:1527268391393};\\\", \\\"{x:611,y:503,t:1527268391426};\\\", \\\"{x:610,y:503,t:1527268391466};\\\", \\\"{x:609,y:504,t:1527268392082};\\\", \\\"{x:604,y:515,t:1527268392094};\\\", \\\"{x:585,y:548,t:1527268392111};\\\", \\\"{x:553,y:593,t:1527268392128};\\\", \\\"{x:522,y:641,t:1527268392144};\\\", \\\"{x:512,y:646,t:1527268392161};\\\", \\\"{x:511,y:647,t:1527268392176};\\\", \\\"{x:511,y:652,t:1527268392193};\\\", \\\"{x:511,y:654,t:1527268392402};\\\", \\\"{x:511,y:664,t:1527268392410};\\\", \\\"{x:507,y:692,t:1527268392427};\\\", \\\"{x:500,y:737,t:1527268392444};\\\", \\\"{x:493,y:801,t:1527268392461};\\\", \\\"{x:490,y:855,t:1527268392477};\\\", \\\"{x:490,y:894,t:1527268392493};\\\", \\\"{x:490,y:915,t:1527268392510};\\\", \\\"{x:490,y:923,t:1527268392527};\\\", \\\"{x:491,y:924,t:1527268392561};\\\", \\\"{x:492,y:924,t:1527268392585};\\\", \\\"{x:493,y:921,t:1527268392594};\\\", \\\"{x:493,y:911,t:1527268392611};\\\", \\\"{x:493,y:897,t:1527268392627};\\\", \\\"{x:493,y:879,t:1527268392643};\\\", \\\"{x:493,y:854,t:1527268392661};\\\", \\\"{x:493,y:829,t:1527268392677};\\\", \\\"{x:493,y:805,t:1527268392694};\\\", \\\"{x:493,y:788,t:1527268392710};\\\", \\\"{x:493,y:775,t:1527268392727};\\\", \\\"{x:493,y:762,t:1527268392744};\\\", \\\"{x:493,y:757,t:1527268392760};\\\", \\\"{x:493,y:755,t:1527268392866};\\\", \\\"{x:493,y:752,t:1527268392877};\\\", \\\"{x:497,y:747,t:1527268392894};\\\", \\\"{x:500,y:743,t:1527268392911};\\\", \\\"{x:504,y:737,t:1527268392927};\\\", \\\"{x:506,y:735,t:1527268392944};\\\", \\\"{x:506,y:734,t:1527268392961};\\\", \\\"{x:506,y:738,t:1527268393043};\\\", \\\"{x:506,y:743,t:1527268393060};\\\", \\\"{x:506,y:746,t:1527268393077};\\\", \\\"{x:505,y:747,t:1527268393094};\\\", \\\"{x:505,y:747,t:1527268393149};\\\", \\\"{x:507,y:747,t:1527268394057};\\\", \\\"{x:516,y:744,t:1527268394066};\\\", \\\"{x:539,y:737,t:1527268394078};\\\", \\\"{x:602,y:720,t:1527268394095};\\\", \\\"{x:649,y:709,t:1527268394112};\\\", \\\"{x:704,y:709,t:1527268394128};\\\", \\\"{x:838,y:710,t:1527268394173};\\\", \\\"{x:863,y:710,t:1527268394193};\\\", \\\"{x:875,y:709,t:1527268394194};\\\", \\\"{x:898,y:706,t:1527268394211};\\\", \\\"{x:916,y:704,t:1527268394228};\\\", \\\"{x:929,y:702,t:1527268394245};\\\", \\\"{x:937,y:701,t:1527268394261};\\\", \\\"{x:945,y:699,t:1527268394278};\\\", \\\"{x:957,y:693,t:1527268394295};\\\", \\\"{x:969,y:687,t:1527268394312};\\\", \\\"{x:978,y:681,t:1527268394328};\\\", \\\"{x:978,y:680,t:1527268394344};\\\", \\\"{x:978,y:678,t:1527268394361};\\\", \\\"{x:978,y:677,t:1527268394378};\\\", \\\"{x:978,y:675,t:1527268394396};\\\", \\\"{x:978,y:674,t:1527268394411};\\\", \\\"{x:976,y:669,t:1527268394428};\\\", \\\"{x:961,y:659,t:1527268394445};\\\", \\\"{x:940,y:650,t:1527268394461};\\\", \\\"{x:916,y:642,t:1527268394478};\\\" ] }, { \\\"rt\\\": 16495, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 434906, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:742,y:602,t:1527268394679};\\\", \\\"{x:741,y:602,t:1527268395116};\\\", \\\"{x:735,y:599,t:1527268395133};\\\", \\\"{x:725,y:594,t:1527268395149};\\\", \\\"{x:713,y:589,t:1527268395166};\\\", \\\"{x:697,y:586,t:1527268395182};\\\", \\\"{x:687,y:582,t:1527268395199};\\\", \\\"{x:675,y:578,t:1527268395215};\\\", \\\"{x:659,y:573,t:1527268395232};\\\", \\\"{x:635,y:566,t:1527268395249};\\\", \\\"{x:590,y:552,t:1527268395266};\\\", \\\"{x:549,y:542,t:1527268395283};\\\", \\\"{x:528,y:535,t:1527268395298};\\\", \\\"{x:520,y:533,t:1527268395315};\\\", \\\"{x:508,y:528,t:1527268395332};\\\", \\\"{x:506,y:526,t:1527268395348};\\\", \\\"{x:501,y:526,t:1527268395365};\\\", \\\"{x:494,y:521,t:1527268395383};\\\", \\\"{x:477,y:512,t:1527268395400};\\\", \\\"{x:460,y:505,t:1527268395415};\\\", \\\"{x:444,y:500,t:1527268395433};\\\", \\\"{x:424,y:496,t:1527268395449};\\\", \\\"{x:405,y:494,t:1527268395466};\\\", \\\"{x:395,y:494,t:1527268395483};\\\", \\\"{x:388,y:493,t:1527268395499};\\\", \\\"{x:385,y:493,t:1527268395516};\\\", \\\"{x:384,y:492,t:1527268395645};\\\", \\\"{x:384,y:489,t:1527268395653};\\\", \\\"{x:386,y:483,t:1527268395667};\\\", \\\"{x:397,y:467,t:1527268395682};\\\", \\\"{x:408,y:452,t:1527268395700};\\\", \\\"{x:416,y:444,t:1527268395715};\\\", \\\"{x:425,y:439,t:1527268395732};\\\", \\\"{x:427,y:436,t:1527268395748};\\\", \\\"{x:428,y:436,t:1527268395765};\\\", \\\"{x:429,y:435,t:1527268395783};\\\", \\\"{x:431,y:435,t:1527268395869};\\\", \\\"{x:432,y:435,t:1527268395883};\\\", \\\"{x:441,y:442,t:1527268395900};\\\", \\\"{x:449,y:447,t:1527268395916};\\\", \\\"{x:459,y:452,t:1527268395933};\\\", \\\"{x:466,y:455,t:1527268395949};\\\", \\\"{x:473,y:456,t:1527268395966};\\\", \\\"{x:480,y:459,t:1527268395983};\\\", \\\"{x:486,y:459,t:1527268395999};\\\", \\\"{x:491,y:459,t:1527268396016};\\\", \\\"{x:495,y:459,t:1527268396032};\\\", \\\"{x:502,y:459,t:1527268396048};\\\", \\\"{x:510,y:459,t:1527268396066};\\\", \\\"{x:516,y:459,t:1527268396082};\\\", \\\"{x:525,y:459,t:1527268396098};\\\", \\\"{x:528,y:459,t:1527268396116};\\\", \\\"{x:530,y:459,t:1527268396133};\\\", \\\"{x:531,y:459,t:1527268396148};\\\", \\\"{x:532,y:459,t:1527268396166};\\\", \\\"{x:534,y:459,t:1527268396197};\\\", \\\"{x:536,y:459,t:1527268396205};\\\", \\\"{x:538,y:459,t:1527268396215};\\\", \\\"{x:543,y:459,t:1527268396233};\\\", \\\"{x:548,y:458,t:1527268396248};\\\", \\\"{x:551,y:458,t:1527268396266};\\\", \\\"{x:554,y:458,t:1527268396283};\\\", \\\"{x:557,y:456,t:1527268396299};\\\", \\\"{x:558,y:456,t:1527268396316};\\\", \\\"{x:563,y:456,t:1527268396332};\\\", \\\"{x:567,y:456,t:1527268396348};\\\", \\\"{x:574,y:455,t:1527268396365};\\\", \\\"{x:583,y:455,t:1527268396382};\\\", \\\"{x:595,y:455,t:1527268396399};\\\", \\\"{x:609,y:455,t:1527268396416};\\\", \\\"{x:630,y:455,t:1527268396432};\\\", \\\"{x:657,y:455,t:1527268396449};\\\", \\\"{x:681,y:455,t:1527268396466};\\\", \\\"{x:697,y:455,t:1527268396483};\\\", \\\"{x:720,y:452,t:1527268396498};\\\", \\\"{x:753,y:449,t:1527268396516};\\\", \\\"{x:844,y:434,t:1527268396533};\\\", \\\"{x:928,y:432,t:1527268396548};\\\", \\\"{x:996,y:427,t:1527268396566};\\\", \\\"{x:1053,y:424,t:1527268396583};\\\", \\\"{x:1094,y:424,t:1527268396599};\\\", \\\"{x:1119,y:423,t:1527268396615};\\\", \\\"{x:1138,y:419,t:1527268396633};\\\", \\\"{x:1146,y:416,t:1527268396649};\\\", \\\"{x:1148,y:415,t:1527268396805};\\\", \\\"{x:1154,y:412,t:1527268396816};\\\", \\\"{x:1173,y:404,t:1527268396833};\\\", \\\"{x:1196,y:399,t:1527268396849};\\\", \\\"{x:1221,y:397,t:1527268396865};\\\", \\\"{x:1238,y:395,t:1527268396883};\\\", \\\"{x:1250,y:394,t:1527268396899};\\\", \\\"{x:1257,y:393,t:1527268396915};\\\", \\\"{x:1261,y:392,t:1527268396933};\\\", \\\"{x:1262,y:392,t:1527268399189};\\\", \\\"{x:1264,y:392,t:1527268399198};\\\", \\\"{x:1272,y:390,t:1527268399215};\\\", \\\"{x:1276,y:388,t:1527268399232};\\\", \\\"{x:1284,y:384,t:1527268399249};\\\", \\\"{x:1288,y:382,t:1527268399266};\\\", \\\"{x:1291,y:379,t:1527268399282};\\\", \\\"{x:1293,y:378,t:1527268399298};\\\", \\\"{x:1295,y:377,t:1527268399316};\\\", \\\"{x:1298,y:375,t:1527268399332};\\\", \\\"{x:1299,y:375,t:1527268399349};\\\", \\\"{x:1300,y:374,t:1527268399366};\\\", \\\"{x:1301,y:374,t:1527268399397};\\\", \\\"{x:1302,y:374,t:1527268399413};\\\", \\\"{x:1303,y:372,t:1527268399420};\\\", \\\"{x:1305,y:372,t:1527268399573};\\\", \\\"{x:1312,y:373,t:1527268399582};\\\", \\\"{x:1332,y:384,t:1527268399599};\\\", \\\"{x:1371,y:404,t:1527268399616};\\\", \\\"{x:1421,y:426,t:1527268399632};\\\", \\\"{x:1471,y:447,t:1527268399649};\\\", \\\"{x:1507,y:462,t:1527268399666};\\\", \\\"{x:1530,y:472,t:1527268399682};\\\", \\\"{x:1538,y:476,t:1527268399699};\\\", \\\"{x:1539,y:477,t:1527268399716};\\\", \\\"{x:1540,y:477,t:1527268399732};\\\", \\\"{x:1541,y:478,t:1527268399836};\\\", \\\"{x:1541,y:481,t:1527268399849};\\\", \\\"{x:1540,y:491,t:1527268399866};\\\", \\\"{x:1537,y:503,t:1527268399882};\\\", \\\"{x:1535,y:518,t:1527268399899};\\\", \\\"{x:1534,y:536,t:1527268399916};\\\", \\\"{x:1534,y:557,t:1527268399933};\\\", \\\"{x:1534,y:592,t:1527268399949};\\\", \\\"{x:1534,y:614,t:1527268399966};\\\", \\\"{x:1536,y:633,t:1527268399982};\\\", \\\"{x:1539,y:654,t:1527268399999};\\\", \\\"{x:1542,y:675,t:1527268400016};\\\", \\\"{x:1544,y:690,t:1527268400032};\\\", \\\"{x:1545,y:699,t:1527268400049};\\\", \\\"{x:1546,y:704,t:1527268400066};\\\", \\\"{x:1546,y:708,t:1527268400082};\\\", \\\"{x:1547,y:711,t:1527268400099};\\\", \\\"{x:1547,y:714,t:1527268400116};\\\", \\\"{x:1547,y:716,t:1527268400132};\\\", \\\"{x:1547,y:720,t:1527268400149};\\\", \\\"{x:1546,y:722,t:1527268400165};\\\", \\\"{x:1546,y:724,t:1527268400182};\\\", \\\"{x:1546,y:722,t:1527268400276};\\\", \\\"{x:1546,y:716,t:1527268400284};\\\", \\\"{x:1548,y:707,t:1527268400298};\\\", \\\"{x:1553,y:689,t:1527268400316};\\\", \\\"{x:1554,y:671,t:1527268400332};\\\", \\\"{x:1556,y:646,t:1527268400348};\\\", \\\"{x:1559,y:628,t:1527268400365};\\\", \\\"{x:1561,y:605,t:1527268400382};\\\", \\\"{x:1561,y:586,t:1527268400398};\\\", \\\"{x:1561,y:563,t:1527268400416};\\\", \\\"{x:1561,y:541,t:1527268400432};\\\", \\\"{x:1559,y:522,t:1527268400449};\\\", \\\"{x:1557,y:505,t:1527268400466};\\\", \\\"{x:1553,y:492,t:1527268400482};\\\", \\\"{x:1548,y:479,t:1527268400499};\\\", \\\"{x:1544,y:466,t:1527268400516};\\\", \\\"{x:1540,y:450,t:1527268400532};\\\", \\\"{x:1534,y:436,t:1527268400548};\\\", \\\"{x:1532,y:431,t:1527268400565};\\\", \\\"{x:1531,y:429,t:1527268400581};\\\", \\\"{x:1530,y:428,t:1527268400599};\\\", \\\"{x:1529,y:428,t:1527268400709};\\\", \\\"{x:1523,y:428,t:1527268400717};\\\", \\\"{x:1510,y:435,t:1527268400732};\\\", \\\"{x:1444,y:487,t:1527268400749};\\\", \\\"{x:1373,y:575,t:1527268400765};\\\", \\\"{x:1311,y:674,t:1527268400782};\\\", \\\"{x:1271,y:768,t:1527268400799};\\\", \\\"{x:1252,y:850,t:1527268400815};\\\", \\\"{x:1252,y:908,t:1527268400832};\\\", \\\"{x:1261,y:938,t:1527268400849};\\\", \\\"{x:1269,y:954,t:1527268400866};\\\", \\\"{x:1278,y:963,t:1527268400882};\\\", \\\"{x:1286,y:965,t:1527268400898};\\\", \\\"{x:1288,y:965,t:1527268400915};\\\", \\\"{x:1290,y:963,t:1527268400932};\\\", \\\"{x:1291,y:945,t:1527268400948};\\\", \\\"{x:1291,y:915,t:1527268400965};\\\", \\\"{x:1291,y:883,t:1527268400982};\\\", \\\"{x:1280,y:856,t:1527268400998};\\\", \\\"{x:1268,y:833,t:1527268401014};\\\", \\\"{x:1254,y:823,t:1527268401031};\\\", \\\"{x:1238,y:818,t:1527268401049};\\\", \\\"{x:1221,y:815,t:1527268401065};\\\", \\\"{x:1207,y:813,t:1527268401082};\\\", \\\"{x:1201,y:813,t:1527268401099};\\\", \\\"{x:1194,y:818,t:1527268401115};\\\", \\\"{x:1189,y:826,t:1527268401132};\\\", \\\"{x:1186,y:834,t:1527268401148};\\\", \\\"{x:1185,y:837,t:1527268401165};\\\", \\\"{x:1184,y:839,t:1527268401182};\\\", \\\"{x:1185,y:839,t:1527268401437};\\\", \\\"{x:1186,y:839,t:1527268401449};\\\", \\\"{x:1188,y:839,t:1527268401468};\\\", \\\"{x:1189,y:839,t:1527268401484};\\\", \\\"{x:1190,y:839,t:1527268401501};\\\", \\\"{x:1191,y:839,t:1527268401517};\\\", \\\"{x:1192,y:839,t:1527268401532};\\\", \\\"{x:1199,y:839,t:1527268401548};\\\", \\\"{x:1208,y:839,t:1527268401565};\\\", \\\"{x:1212,y:839,t:1527268401582};\\\", \\\"{x:1215,y:839,t:1527268401599};\\\", \\\"{x:1216,y:839,t:1527268401813};\\\", \\\"{x:1216,y:838,t:1527268401820};\\\", \\\"{x:1216,y:835,t:1527268401837};\\\", \\\"{x:1216,y:832,t:1527268401864};\\\", \\\"{x:1215,y:831,t:1527268401882};\\\", \\\"{x:1214,y:828,t:1527268401899};\\\", \\\"{x:1212,y:827,t:1527268401914};\\\", \\\"{x:1211,y:824,t:1527268401932};\\\", \\\"{x:1205,y:815,t:1527268401948};\\\", \\\"{x:1197,y:806,t:1527268401965};\\\", \\\"{x:1189,y:797,t:1527268401982};\\\", \\\"{x:1182,y:792,t:1527268401999};\\\", \\\"{x:1177,y:789,t:1527268402015};\\\", \\\"{x:1168,y:785,t:1527268402032};\\\", \\\"{x:1153,y:782,t:1527268402050};\\\", \\\"{x:1137,y:775,t:1527268402065};\\\", \\\"{x:1128,y:772,t:1527268402082};\\\", \\\"{x:1121,y:768,t:1527268402099};\\\", \\\"{x:1113,y:764,t:1527268402115};\\\", \\\"{x:1110,y:763,t:1527268402133};\\\", \\\"{x:1108,y:762,t:1527268402149};\\\", \\\"{x:1105,y:761,t:1527268402165};\\\", \\\"{x:1101,y:760,t:1527268402182};\\\", \\\"{x:1091,y:758,t:1527268402199};\\\", \\\"{x:1078,y:756,t:1527268402215};\\\", \\\"{x:1061,y:755,t:1527268402232};\\\", \\\"{x:1039,y:751,t:1527268402250};\\\", \\\"{x:1013,y:747,t:1527268402265};\\\", \\\"{x:962,y:738,t:1527268402282};\\\", \\\"{x:895,y:720,t:1527268402299};\\\", \\\"{x:831,y:701,t:1527268402314};\\\", \\\"{x:776,y:678,t:1527268402331};\\\", \\\"{x:687,y:642,t:1527268402348};\\\", \\\"{x:620,y:609,t:1527268402366};\\\", \\\"{x:554,y:580,t:1527268402382};\\\", \\\"{x:496,y:557,t:1527268402399};\\\", \\\"{x:420,y:533,t:1527268402422};\\\", \\\"{x:384,y:524,t:1527268402438};\\\", \\\"{x:353,y:520,t:1527268402454};\\\", \\\"{x:322,y:514,t:1527268402472};\\\", \\\"{x:294,y:510,t:1527268402488};\\\", \\\"{x:266,y:505,t:1527268402505};\\\", \\\"{x:232,y:496,t:1527268402522};\\\", \\\"{x:201,y:487,t:1527268402538};\\\", \\\"{x:169,y:477,t:1527268402555};\\\", \\\"{x:128,y:467,t:1527268402573};\\\", \\\"{x:101,y:460,t:1527268402588};\\\", \\\"{x:79,y:453,t:1527268402605};\\\", \\\"{x:66,y:450,t:1527268402622};\\\", \\\"{x:60,y:447,t:1527268402638};\\\", \\\"{x:57,y:447,t:1527268402655};\\\", \\\"{x:55,y:447,t:1527268402672};\\\", \\\"{x:47,y:447,t:1527268402687};\\\", \\\"{x:36,y:447,t:1527268402705};\\\", \\\"{x:27,y:447,t:1527268402722};\\\", \\\"{x:22,y:447,t:1527268402738};\\\", \\\"{x:19,y:447,t:1527268402755};\\\", \\\"{x:18,y:447,t:1527268402821};\\\", \\\"{x:20,y:451,t:1527268402829};\\\", \\\"{x:24,y:455,t:1527268402839};\\\", \\\"{x:34,y:462,t:1527268402854};\\\", \\\"{x:50,y:471,t:1527268402872};\\\", \\\"{x:67,y:481,t:1527268402889};\\\", \\\"{x:81,y:487,t:1527268402905};\\\", \\\"{x:95,y:492,t:1527268402922};\\\", \\\"{x:105,y:494,t:1527268402939};\\\", \\\"{x:117,y:498,t:1527268402955};\\\", \\\"{x:135,y:503,t:1527268402972};\\\", \\\"{x:166,y:511,t:1527268402989};\\\", \\\"{x:188,y:516,t:1527268403006};\\\", \\\"{x:213,y:520,t:1527268403022};\\\", \\\"{x:234,y:522,t:1527268403039};\\\", \\\"{x:253,y:526,t:1527268403055};\\\", \\\"{x:266,y:526,t:1527268403072};\\\", \\\"{x:278,y:526,t:1527268403090};\\\", \\\"{x:292,y:528,t:1527268403105};\\\", \\\"{x:305,y:528,t:1527268403121};\\\", \\\"{x:319,y:528,t:1527268403139};\\\", \\\"{x:331,y:528,t:1527268403155};\\\", \\\"{x:341,y:528,t:1527268403171};\\\", \\\"{x:357,y:528,t:1527268403188};\\\", \\\"{x:369,y:528,t:1527268403205};\\\", \\\"{x:381,y:528,t:1527268403222};\\\", \\\"{x:389,y:528,t:1527268403238};\\\", \\\"{x:393,y:528,t:1527268403256};\\\", \\\"{x:396,y:528,t:1527268403271};\\\", \\\"{x:397,y:528,t:1527268403292};\\\", \\\"{x:399,y:528,t:1527268403356};\\\", \\\"{x:401,y:528,t:1527268403613};\\\", \\\"{x:407,y:532,t:1527268403622};\\\", \\\"{x:422,y:545,t:1527268403640};\\\", \\\"{x:440,y:559,t:1527268403657};\\\", \\\"{x:457,y:571,t:1527268403673};\\\", \\\"{x:472,y:579,t:1527268403688};\\\", \\\"{x:483,y:585,t:1527268403705};\\\", \\\"{x:488,y:588,t:1527268403723};\\\", \\\"{x:494,y:588,t:1527268403739};\\\", \\\"{x:498,y:588,t:1527268403756};\\\", \\\"{x:506,y:588,t:1527268403773};\\\", \\\"{x:517,y:588,t:1527268403789};\\\", \\\"{x:536,y:588,t:1527268403806};\\\", \\\"{x:557,y:587,t:1527268403822};\\\", \\\"{x:571,y:580,t:1527268403840};\\\", \\\"{x:575,y:578,t:1527268403855};\\\", \\\"{x:577,y:576,t:1527268403872};\\\", \\\"{x:577,y:571,t:1527268403889};\\\", \\\"{x:571,y:558,t:1527268403906};\\\", \\\"{x:557,y:544,t:1527268403923};\\\", \\\"{x:544,y:533,t:1527268403939};\\\", \\\"{x:527,y:524,t:1527268403956};\\\", \\\"{x:494,y:518,t:1527268403972};\\\", \\\"{x:458,y:511,t:1527268403989};\\\", \\\"{x:423,y:506,t:1527268404006};\\\", \\\"{x:375,y:499,t:1527268404023};\\\", \\\"{x:329,y:494,t:1527268404039};\\\", \\\"{x:261,y:482,t:1527268404057};\\\", \\\"{x:186,y:473,t:1527268404073};\\\", \\\"{x:119,y:463,t:1527268404090};\\\", \\\"{x:63,y:455,t:1527268404106};\\\", \\\"{x:24,y:449,t:1527268404123};\\\", \\\"{x:1,y:444,t:1527268404140};\\\", \\\"{x:0,y:443,t:1527268404156};\\\", \\\"{x:0,y:442,t:1527268404229};\\\", \\\"{x:1,y:442,t:1527268404245};\\\", \\\"{x:6,y:442,t:1527268404256};\\\", \\\"{x:26,y:445,t:1527268404273};\\\", \\\"{x:47,y:455,t:1527268404290};\\\", \\\"{x:68,y:464,t:1527268404306};\\\", \\\"{x:80,y:469,t:1527268404322};\\\", \\\"{x:89,y:475,t:1527268404340};\\\", \\\"{x:91,y:477,t:1527268404356};\\\", \\\"{x:91,y:478,t:1527268404389};\\\", \\\"{x:91,y:479,t:1527268404397};\\\", \\\"{x:92,y:482,t:1527268404413};\\\", \\\"{x:94,y:485,t:1527268404423};\\\", \\\"{x:95,y:492,t:1527268404440};\\\", \\\"{x:99,y:500,t:1527268404456};\\\", \\\"{x:103,y:505,t:1527268404473};\\\", \\\"{x:106,y:509,t:1527268404489};\\\", \\\"{x:108,y:511,t:1527268404505};\\\", \\\"{x:109,y:512,t:1527268404523};\\\", \\\"{x:110,y:512,t:1527268404540};\\\", \\\"{x:113,y:512,t:1527268404556};\\\", \\\"{x:122,y:512,t:1527268404572};\\\", \\\"{x:134,y:512,t:1527268404590};\\\", \\\"{x:149,y:512,t:1527268404606};\\\", \\\"{x:163,y:512,t:1527268404623};\\\", \\\"{x:173,y:512,t:1527268404640};\\\", \\\"{x:177,y:512,t:1527268404657};\\\", \\\"{x:179,y:512,t:1527268404673};\\\", \\\"{x:179,y:511,t:1527268404700};\\\", \\\"{x:179,y:510,t:1527268404708};\\\", \\\"{x:179,y:508,t:1527268404722};\\\", \\\"{x:179,y:505,t:1527268404740};\\\", \\\"{x:177,y:503,t:1527268404756};\\\", \\\"{x:172,y:499,t:1527268404773};\\\", \\\"{x:165,y:495,t:1527268404790};\\\", \\\"{x:161,y:494,t:1527268404806};\\\", \\\"{x:154,y:493,t:1527268404823};\\\", \\\"{x:148,y:493,t:1527268404841};\\\", \\\"{x:147,y:493,t:1527268404857};\\\", \\\"{x:146,y:493,t:1527268404873};\\\", \\\"{x:145,y:493,t:1527268405092};\\\", \\\"{x:145,y:494,t:1527268405107};\\\", \\\"{x:145,y:495,t:1527268405124};\\\", \\\"{x:145,y:496,t:1527268405139};\\\", \\\"{x:145,y:498,t:1527268405156};\\\", \\\"{x:144,y:498,t:1527268405245};\\\", \\\"{x:144,y:499,t:1527268405333};\\\", \\\"{x:146,y:500,t:1527268405349};\\\", \\\"{x:147,y:500,t:1527268405357};\\\", \\\"{x:150,y:500,t:1527268405374};\\\", \\\"{x:152,y:500,t:1527268405391};\\\", \\\"{x:153,y:500,t:1527268405413};\\\", \\\"{x:155,y:500,t:1527268405460};\\\", \\\"{x:156,y:500,t:1527268405500};\\\", \\\"{x:158,y:500,t:1527268405608};\\\", \\\"{x:158,y:500,t:1527268405681};\\\", \\\"{x:159,y:500,t:1527268406748};\\\", \\\"{x:176,y:510,t:1527268406759};\\\", \\\"{x:249,y:550,t:1527268406776};\\\", \\\"{x:346,y:596,t:1527268406793};\\\", \\\"{x:441,y:647,t:1527268406809};\\\", \\\"{x:520,y:689,t:1527268406826};\\\", \\\"{x:564,y:715,t:1527268406842};\\\", \\\"{x:574,y:721,t:1527268406858};\\\", \\\"{x:576,y:725,t:1527268406875};\\\", \\\"{x:579,y:737,t:1527268406892};\\\", \\\"{x:579,y:760,t:1527268406908};\\\", \\\"{x:579,y:811,t:1527268406925};\\\", \\\"{x:574,y:838,t:1527268406942};\\\", \\\"{x:569,y:856,t:1527268406957};\\\", \\\"{x:564,y:868,t:1527268406975};\\\", \\\"{x:561,y:872,t:1527268406992};\\\", \\\"{x:559,y:875,t:1527268407008};\\\", \\\"{x:556,y:876,t:1527268407025};\\\", \\\"{x:548,y:877,t:1527268407043};\\\", \\\"{x:540,y:877,t:1527268407058};\\\", \\\"{x:529,y:876,t:1527268407075};\\\", \\\"{x:513,y:868,t:1527268407092};\\\", \\\"{x:495,y:855,t:1527268407108};\\\", \\\"{x:475,y:833,t:1527268407124};\\\", \\\"{x:471,y:826,t:1527268407142};\\\", \\\"{x:470,y:825,t:1527268407159};\\\", \\\"{x:470,y:820,t:1527268407175};\\\", \\\"{x:470,y:814,t:1527268407192};\\\", \\\"{x:470,y:806,t:1527268407209};\\\", \\\"{x:473,y:797,t:1527268407225};\\\", \\\"{x:476,y:791,t:1527268407242};\\\", \\\"{x:481,y:779,t:1527268407259};\\\", \\\"{x:488,y:766,t:1527268407276};\\\", \\\"{x:497,y:755,t:1527268407293};\\\", \\\"{x:510,y:740,t:1527268407309};\\\", \\\"{x:520,y:729,t:1527268407325};\\\", \\\"{x:526,y:721,t:1527268407341};\\\", \\\"{x:528,y:717,t:1527268407358};\\\", \\\"{x:529,y:716,t:1527268407375};\\\", \\\"{x:526,y:716,t:1527268407628};\\\", \\\"{x:521,y:719,t:1527268407642};\\\", \\\"{x:516,y:723,t:1527268407660};\\\", \\\"{x:514,y:724,t:1527268407676};\\\", \\\"{x:512,y:725,t:1527268407692};\\\" ] }, { \\\"rt\\\": 127528, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 563686, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -F -B -B -12 PM-Z -04 PM-07 PM-04 PM-04 PM-I -I -B -B -I -J -I -I -09 AM-I -I -B -B -O -O -O -O -F -Z -Z -Z -Z -E -G -E -G -G -A -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:725,t:1527268413246};\\\", \\\"{x:539,y:718,t:1527268413255};\\\", \\\"{x:565,y:709,t:1527268413265};\\\", \\\"{x:626,y:693,t:1527268413281};\\\", \\\"{x:688,y:683,t:1527268413297};\\\", \\\"{x:754,y:677,t:1527268413313};\\\", \\\"{x:831,y:668,t:1527268413331};\\\", \\\"{x:911,y:647,t:1527268413347};\\\", \\\"{x:1015,y:606,t:1527268413364};\\\", \\\"{x:1185,y:533,t:1527268413381};\\\", \\\"{x:1297,y:472,t:1527268413397};\\\", \\\"{x:1412,y:408,t:1527268413413};\\\", \\\"{x:1543,y:329,t:1527268413430};\\\", \\\"{x:1668,y:239,t:1527268413448};\\\", \\\"{x:1762,y:156,t:1527268413464};\\\", \\\"{x:1829,y:95,t:1527268413480};\\\", \\\"{x:1865,y:45,t:1527268413498};\\\", \\\"{x:1874,y:11,t:1527268413514};\\\", \\\"{x:1871,y:0,t:1527268413531};\\\", \\\"{x:1855,y:0,t:1527268413548};\\\", \\\"{x:1825,y:0,t:1527268413564};\\\", \\\"{x:1701,y:0,t:1527268413580};\\\", \\\"{x:1567,y:0,t:1527268413598};\\\", \\\"{x:1444,y:0,t:1527268413614};\\\", \\\"{x:1314,y:0,t:1527268413631};\\\", \\\"{x:1184,y:0,t:1527268413647};\\\", \\\"{x:1056,y:22,t:1527268413665};\\\", \\\"{x:951,y:85,t:1527268413681};\\\", \\\"{x:860,y:146,t:1527268413697};\\\", \\\"{x:789,y:185,t:1527268413715};\\\", \\\"{x:738,y:211,t:1527268413730};\\\", \\\"{x:717,y:222,t:1527268413748};\\\", \\\"{x:700,y:233,t:1527268413764};\\\", \\\"{x:690,y:240,t:1527268413780};\\\", \\\"{x:682,y:247,t:1527268413798};\\\", \\\"{x:671,y:254,t:1527268413815};\\\", \\\"{x:663,y:260,t:1527268413830};\\\", \\\"{x:655,y:269,t:1527268413848};\\\", \\\"{x:650,y:277,t:1527268413864};\\\", \\\"{x:646,y:284,t:1527268413881};\\\", \\\"{x:641,y:292,t:1527268413897};\\\", \\\"{x:636,y:303,t:1527268413915};\\\", \\\"{x:631,y:317,t:1527268413931};\\\", \\\"{x:620,y:334,t:1527268413948};\\\", \\\"{x:598,y:364,t:1527268413965};\\\", \\\"{x:586,y:388,t:1527268413981};\\\", \\\"{x:567,y:418,t:1527268413997};\\\", \\\"{x:545,y:445,t:1527268414014};\\\", \\\"{x:526,y:461,t:1527268414031};\\\", \\\"{x:516,y:466,t:1527268414047};\\\", \\\"{x:515,y:466,t:1527268414064};\\\", \\\"{x:515,y:467,t:1527268414080};\\\", \\\"{x:514,y:468,t:1527268414097};\\\", \\\"{x:515,y:466,t:1527268414453};\\\", \\\"{x:517,y:466,t:1527268414464};\\\", \\\"{x:521,y:464,t:1527268414482};\\\", \\\"{x:524,y:462,t:1527268414497};\\\", \\\"{x:528,y:460,t:1527268414515};\\\", \\\"{x:529,y:459,t:1527268414532};\\\", \\\"{x:531,y:458,t:1527268414916};\\\", \\\"{x:535,y:456,t:1527268414931};\\\", \\\"{x:551,y:447,t:1527268414948};\\\", \\\"{x:554,y:447,t:1527268415341};\\\", \\\"{x:557,y:447,t:1527268415348};\\\", \\\"{x:563,y:448,t:1527268415365};\\\", \\\"{x:578,y:451,t:1527268415382};\\\", \\\"{x:592,y:455,t:1527268415398};\\\", \\\"{x:604,y:458,t:1527268415416};\\\", \\\"{x:615,y:460,t:1527268415432};\\\", \\\"{x:622,y:461,t:1527268415449};\\\", \\\"{x:625,y:461,t:1527268415466};\\\", \\\"{x:627,y:462,t:1527268415483};\\\", \\\"{x:628,y:462,t:1527268415499};\\\", \\\"{x:631,y:462,t:1527268415515};\\\", \\\"{x:637,y:462,t:1527268415532};\\\", \\\"{x:643,y:461,t:1527268415548};\\\", \\\"{x:654,y:457,t:1527268415565};\\\", \\\"{x:664,y:456,t:1527268415582};\\\", \\\"{x:669,y:454,t:1527268415599};\\\", \\\"{x:673,y:453,t:1527268415616};\\\", \\\"{x:676,y:452,t:1527268415633};\\\", \\\"{x:677,y:452,t:1527268415648};\\\", \\\"{x:679,y:450,t:1527268415666};\\\", \\\"{x:680,y:450,t:1527268415683};\\\", \\\"{x:683,y:450,t:1527268415698};\\\", \\\"{x:684,y:449,t:1527268415716};\\\", \\\"{x:691,y:447,t:1527268415733};\\\", \\\"{x:701,y:445,t:1527268415749};\\\", \\\"{x:718,y:440,t:1527268415766};\\\", \\\"{x:743,y:435,t:1527268415783};\\\", \\\"{x:781,y:430,t:1527268415800};\\\", \\\"{x:823,y:426,t:1527268415816};\\\", \\\"{x:866,y:423,t:1527268415832};\\\", \\\"{x:913,y:423,t:1527268415849};\\\", \\\"{x:961,y:423,t:1527268415866};\\\", \\\"{x:1011,y:423,t:1527268415883};\\\", \\\"{x:1067,y:423,t:1527268415900};\\\", \\\"{x:1148,y:423,t:1527268415915};\\\", \\\"{x:1154,y:422,t:1527268415933};\\\", \\\"{x:1164,y:420,t:1527268416726};\\\", \\\"{x:1180,y:415,t:1527268416734};\\\", \\\"{x:1204,y:406,t:1527268416750};\\\", \\\"{x:1222,y:400,t:1527268416768};\\\", \\\"{x:1234,y:397,t:1527268416784};\\\", \\\"{x:1243,y:395,t:1527268416801};\\\", \\\"{x:1249,y:392,t:1527268416817};\\\", \\\"{x:1257,y:388,t:1527268416835};\\\", \\\"{x:1264,y:385,t:1527268416850};\\\", \\\"{x:1271,y:380,t:1527268416867};\\\", \\\"{x:1281,y:374,t:1527268416884};\\\", \\\"{x:1292,y:366,t:1527268416900};\\\", \\\"{x:1308,y:351,t:1527268416918};\\\", \\\"{x:1317,y:343,t:1527268416933};\\\", \\\"{x:1323,y:336,t:1527268416950};\\\", \\\"{x:1331,y:329,t:1527268416967};\\\", \\\"{x:1332,y:328,t:1527268416983};\\\", \\\"{x:1333,y:326,t:1527268416999};\\\", \\\"{x:1333,y:324,t:1527268417077};\\\", \\\"{x:1334,y:323,t:1527268417085};\\\", \\\"{x:1334,y:321,t:1527268417100};\\\", \\\"{x:1336,y:316,t:1527268417117};\\\", \\\"{x:1336,y:315,t:1527268417134};\\\", \\\"{x:1337,y:312,t:1527268417149};\\\", \\\"{x:1337,y:310,t:1527268417167};\\\", \\\"{x:1338,y:308,t:1527268417184};\\\", \\\"{x:1337,y:308,t:1527268417390};\\\", \\\"{x:1336,y:308,t:1527268417405};\\\", \\\"{x:1335,y:308,t:1527268417417};\\\", \\\"{x:1332,y:308,t:1527268417434};\\\", \\\"{x:1328,y:310,t:1527268417451};\\\", \\\"{x:1327,y:310,t:1527268417466};\\\", \\\"{x:1326,y:311,t:1527268417484};\\\", \\\"{x:1326,y:315,t:1527268417500};\\\", \\\"{x:1326,y:317,t:1527268417516};\\\", \\\"{x:1326,y:318,t:1527268417533};\\\", \\\"{x:1326,y:320,t:1527268417551};\\\", \\\"{x:1327,y:322,t:1527268417567};\\\", \\\"{x:1328,y:325,t:1527268417583};\\\", \\\"{x:1331,y:327,t:1527268417600};\\\", \\\"{x:1336,y:330,t:1527268417618};\\\", \\\"{x:1348,y:336,t:1527268417633};\\\", \\\"{x:1362,y:344,t:1527268417651};\\\", \\\"{x:1372,y:349,t:1527268417667};\\\", \\\"{x:1384,y:355,t:1527268417684};\\\", \\\"{x:1399,y:363,t:1527268417700};\\\", \\\"{x:1401,y:363,t:1527268417718};\\\", \\\"{x:1403,y:363,t:1527268417733};\\\", \\\"{x:1404,y:363,t:1527268417844};\\\", \\\"{x:1405,y:362,t:1527268417852};\\\", \\\"{x:1405,y:361,t:1527268417868};\\\", \\\"{x:1406,y:360,t:1527268417884};\\\", \\\"{x:1411,y:357,t:1527268417901};\\\", \\\"{x:1413,y:356,t:1527268417918};\\\", \\\"{x:1415,y:355,t:1527268417934};\\\", \\\"{x:1417,y:354,t:1527268417950};\\\", \\\"{x:1418,y:353,t:1527268417967};\\\", \\\"{x:1424,y:350,t:1527268417984};\\\", \\\"{x:1427,y:349,t:1527268418001};\\\", \\\"{x:1431,y:346,t:1527268418017};\\\", \\\"{x:1435,y:343,t:1527268418035};\\\", \\\"{x:1438,y:341,t:1527268418051};\\\", \\\"{x:1443,y:337,t:1527268418067};\\\", \\\"{x:1448,y:330,t:1527268418084};\\\", \\\"{x:1454,y:323,t:1527268418101};\\\", \\\"{x:1461,y:313,t:1527268418117};\\\", \\\"{x:1467,y:305,t:1527268418135};\\\", \\\"{x:1474,y:297,t:1527268418151};\\\", \\\"{x:1477,y:291,t:1527268418167};\\\", \\\"{x:1479,y:287,t:1527268418185};\\\", \\\"{x:1481,y:282,t:1527268418200};\\\", \\\"{x:1483,y:279,t:1527268418218};\\\", \\\"{x:1486,y:274,t:1527268418235};\\\", \\\"{x:1489,y:269,t:1527268418250};\\\", \\\"{x:1490,y:267,t:1527268418267};\\\", \\\"{x:1494,y:263,t:1527268418284};\\\", \\\"{x:1497,y:261,t:1527268418301};\\\", \\\"{x:1500,y:260,t:1527268418317};\\\", \\\"{x:1506,y:257,t:1527268418335};\\\", \\\"{x:1508,y:256,t:1527268418350};\\\", \\\"{x:1511,y:255,t:1527268418367};\\\", \\\"{x:1515,y:254,t:1527268418384};\\\", \\\"{x:1519,y:254,t:1527268418401};\\\", \\\"{x:1526,y:254,t:1527268418417};\\\", \\\"{x:1534,y:254,t:1527268418435};\\\", \\\"{x:1542,y:254,t:1527268418451};\\\", \\\"{x:1551,y:258,t:1527268418468};\\\", \\\"{x:1565,y:265,t:1527268418485};\\\", \\\"{x:1574,y:271,t:1527268418501};\\\", \\\"{x:1579,y:275,t:1527268418518};\\\", \\\"{x:1587,y:281,t:1527268418534};\\\", \\\"{x:1592,y:285,t:1527268418552};\\\", \\\"{x:1596,y:287,t:1527268418568};\\\", \\\"{x:1597,y:288,t:1527268418585};\\\", \\\"{x:1598,y:289,t:1527268418602};\\\", \\\"{x:1599,y:289,t:1527268418717};\\\", \\\"{x:1598,y:295,t:1527268422182};\\\", \\\"{x:1598,y:307,t:1527268422189};\\\", \\\"{x:1598,y:319,t:1527268422205};\\\", \\\"{x:1607,y:373,t:1527268422221};\\\", \\\"{x:1619,y:436,t:1527268422238};\\\", \\\"{x:1624,y:490,t:1527268422253};\\\", \\\"{x:1630,y:546,t:1527268422271};\\\", \\\"{x:1630,y:602,t:1527268422287};\\\", \\\"{x:1630,y:657,t:1527268422304};\\\", \\\"{x:1630,y:708,t:1527268422321};\\\", \\\"{x:1621,y:749,t:1527268422338};\\\", \\\"{x:1612,y:774,t:1527268422353};\\\", \\\"{x:1604,y:791,t:1527268422371};\\\", \\\"{x:1591,y:809,t:1527268422388};\\\", \\\"{x:1571,y:819,t:1527268422404};\\\", \\\"{x:1539,y:828,t:1527268422421};\\\", \\\"{x:1517,y:828,t:1527268422438};\\\", \\\"{x:1497,y:829,t:1527268422455};\\\", \\\"{x:1483,y:836,t:1527268422471};\\\", \\\"{x:1467,y:840,t:1527268422488};\\\", \\\"{x:1447,y:844,t:1527268422505};\\\", \\\"{x:1429,y:844,t:1527268422521};\\\", \\\"{x:1400,y:843,t:1527268422538};\\\", \\\"{x:1369,y:826,t:1527268422554};\\\", \\\"{x:1348,y:810,t:1527268422571};\\\", \\\"{x:1327,y:792,t:1527268422588};\\\", \\\"{x:1313,y:768,t:1527268422604};\\\", \\\"{x:1309,y:754,t:1527268422621};\\\", \\\"{x:1309,y:736,t:1527268422638};\\\", \\\"{x:1309,y:716,t:1527268422655};\\\", \\\"{x:1311,y:702,t:1527268422670};\\\", \\\"{x:1314,y:687,t:1527268422688};\\\", \\\"{x:1315,y:682,t:1527268422705};\\\", \\\"{x:1315,y:681,t:1527268422721};\\\", \\\"{x:1316,y:685,t:1527268422869};\\\", \\\"{x:1319,y:688,t:1527268422876};\\\", \\\"{x:1321,y:693,t:1527268422888};\\\", \\\"{x:1324,y:697,t:1527268422905};\\\", \\\"{x:1325,y:699,t:1527268422922};\\\", \\\"{x:1326,y:699,t:1527268422938};\\\", \\\"{x:1327,y:700,t:1527268422955};\\\", \\\"{x:1328,y:700,t:1527268423012};\\\", \\\"{x:1329,y:700,t:1527268423028};\\\", \\\"{x:1331,y:700,t:1527268423038};\\\", \\\"{x:1335,y:699,t:1527268423055};\\\", \\\"{x:1337,y:697,t:1527268423072};\\\", \\\"{x:1339,y:696,t:1527268423088};\\\", \\\"{x:1340,y:696,t:1527268423105};\\\", \\\"{x:1342,y:695,t:1527268423123};\\\", \\\"{x:1344,y:694,t:1527268423138};\\\", \\\"{x:1346,y:693,t:1527268423155};\\\", \\\"{x:1347,y:693,t:1527268423171};\\\", \\\"{x:1348,y:692,t:1527268423188};\\\", \\\"{x:1349,y:692,t:1527268423205};\\\", \\\"{x:1350,y:691,t:1527268423222};\\\", \\\"{x:1350,y:693,t:1527268423652};\\\", \\\"{x:1350,y:694,t:1527268423676};\\\", \\\"{x:1350,y:696,t:1527268423716};\\\", \\\"{x:1350,y:697,t:1527268423748};\\\", \\\"{x:1350,y:699,t:1527268423764};\\\", \\\"{x:1350,y:700,t:1527268423780};\\\", \\\"{x:1349,y:702,t:1527268423796};\\\", \\\"{x:1349,y:703,t:1527268423813};\\\", \\\"{x:1349,y:704,t:1527268423829};\\\", \\\"{x:1349,y:705,t:1527268423839};\\\", \\\"{x:1348,y:706,t:1527268423856};\\\", \\\"{x:1348,y:708,t:1527268423872};\\\", \\\"{x:1348,y:709,t:1527268423889};\\\", \\\"{x:1348,y:711,t:1527268423906};\\\", \\\"{x:1347,y:712,t:1527268423922};\\\", \\\"{x:1347,y:713,t:1527268423939};\\\", \\\"{x:1347,y:714,t:1527268423956};\\\", \\\"{x:1346,y:715,t:1527268423972};\\\", \\\"{x:1346,y:717,t:1527268423989};\\\", \\\"{x:1345,y:718,t:1527268424006};\\\", \\\"{x:1345,y:719,t:1527268424022};\\\", \\\"{x:1345,y:720,t:1527268424039};\\\", \\\"{x:1345,y:721,t:1527268424056};\\\", \\\"{x:1344,y:723,t:1527268424072};\\\", \\\"{x:1344,y:724,t:1527268424092};\\\", \\\"{x:1344,y:725,t:1527268424109};\\\", \\\"{x:1344,y:727,t:1527268424122};\\\", \\\"{x:1344,y:728,t:1527268424140};\\\", \\\"{x:1344,y:731,t:1527268424157};\\\", \\\"{x:1344,y:733,t:1527268424173};\\\", \\\"{x:1344,y:740,t:1527268424190};\\\", \\\"{x:1344,y:743,t:1527268424206};\\\", \\\"{x:1344,y:747,t:1527268424224};\\\", \\\"{x:1344,y:751,t:1527268424240};\\\", \\\"{x:1344,y:754,t:1527268424256};\\\", \\\"{x:1344,y:757,t:1527268424273};\\\", \\\"{x:1344,y:759,t:1527268424290};\\\", \\\"{x:1344,y:762,t:1527268424306};\\\", \\\"{x:1344,y:764,t:1527268424323};\\\", \\\"{x:1344,y:767,t:1527268424339};\\\", \\\"{x:1344,y:770,t:1527268424356};\\\", \\\"{x:1344,y:774,t:1527268424372};\\\", \\\"{x:1344,y:776,t:1527268424388};\\\", \\\"{x:1344,y:778,t:1527268424406};\\\", \\\"{x:1344,y:781,t:1527268424422};\\\", \\\"{x:1344,y:782,t:1527268424439};\\\", \\\"{x:1344,y:784,t:1527268424456};\\\", \\\"{x:1344,y:786,t:1527268424473};\\\", \\\"{x:1344,y:788,t:1527268424489};\\\", \\\"{x:1344,y:792,t:1527268424506};\\\", \\\"{x:1344,y:794,t:1527268424523};\\\", \\\"{x:1344,y:796,t:1527268424539};\\\", \\\"{x:1344,y:797,t:1527268424556};\\\", \\\"{x:1344,y:798,t:1527268424573};\\\", \\\"{x:1344,y:799,t:1527268424589};\\\", \\\"{x:1344,y:801,t:1527268424605};\\\", \\\"{x:1344,y:804,t:1527268424623};\\\", \\\"{x:1344,y:808,t:1527268424639};\\\", \\\"{x:1344,y:816,t:1527268424656};\\\", \\\"{x:1344,y:827,t:1527268424673};\\\", \\\"{x:1345,y:839,t:1527268424690};\\\", \\\"{x:1345,y:849,t:1527268424705};\\\", \\\"{x:1347,y:859,t:1527268424723};\\\", \\\"{x:1348,y:866,t:1527268424740};\\\", \\\"{x:1348,y:871,t:1527268424755};\\\", \\\"{x:1350,y:875,t:1527268424773};\\\", \\\"{x:1350,y:876,t:1527268424790};\\\", \\\"{x:1350,y:879,t:1527268424806};\\\", \\\"{x:1352,y:882,t:1527268424823};\\\", \\\"{x:1352,y:885,t:1527268424840};\\\", \\\"{x:1352,y:888,t:1527268424856};\\\", \\\"{x:1353,y:890,t:1527268424873};\\\", \\\"{x:1353,y:893,t:1527268424890};\\\", \\\"{x:1353,y:897,t:1527268424906};\\\", \\\"{x:1354,y:900,t:1527268424923};\\\", \\\"{x:1355,y:905,t:1527268424940};\\\", \\\"{x:1355,y:910,t:1527268424956};\\\", \\\"{x:1355,y:915,t:1527268424973};\\\", \\\"{x:1357,y:918,t:1527268424991};\\\", \\\"{x:1357,y:921,t:1527268425007};\\\", \\\"{x:1357,y:923,t:1527268425023};\\\", \\\"{x:1357,y:925,t:1527268425040};\\\", \\\"{x:1357,y:928,t:1527268425056};\\\", \\\"{x:1357,y:931,t:1527268425073};\\\", \\\"{x:1357,y:932,t:1527268425090};\\\", \\\"{x:1357,y:935,t:1527268425106};\\\", \\\"{x:1357,y:937,t:1527268425123};\\\", \\\"{x:1357,y:938,t:1527268425140};\\\", \\\"{x:1358,y:939,t:1527268425158};\\\", \\\"{x:1358,y:940,t:1527268425174};\\\", \\\"{x:1358,y:941,t:1527268425191};\\\", \\\"{x:1358,y:942,t:1527268425213};\\\", \\\"{x:1358,y:943,t:1527268425223};\\\", \\\"{x:1358,y:944,t:1527268425240};\\\", \\\"{x:1359,y:947,t:1527268425257};\\\", \\\"{x:1359,y:949,t:1527268425273};\\\", \\\"{x:1359,y:951,t:1527268425290};\\\", \\\"{x:1360,y:954,t:1527268425307};\\\", \\\"{x:1361,y:957,t:1527268425323};\\\", \\\"{x:1362,y:960,t:1527268425340};\\\", \\\"{x:1362,y:966,t:1527268425356};\\\", \\\"{x:1362,y:968,t:1527268425373};\\\", \\\"{x:1362,y:971,t:1527268425390};\\\", \\\"{x:1362,y:973,t:1527268425407};\\\", \\\"{x:1362,y:974,t:1527268425423};\\\", \\\"{x:1362,y:976,t:1527268425452};\\\", \\\"{x:1362,y:977,t:1527268425508};\\\", \\\"{x:1362,y:978,t:1527268425605};\\\", \\\"{x:1361,y:978,t:1527268425620};\\\", \\\"{x:1359,y:978,t:1527268425644};\\\", \\\"{x:1358,y:978,t:1527268425656};\\\", \\\"{x:1355,y:978,t:1527268425674};\\\", \\\"{x:1351,y:974,t:1527268425689};\\\", \\\"{x:1349,y:971,t:1527268425707};\\\", \\\"{x:1346,y:968,t:1527268425724};\\\", \\\"{x:1345,y:965,t:1527268425739};\\\", \\\"{x:1344,y:963,t:1527268425757};\\\", \\\"{x:1344,y:962,t:1527268425774};\\\", \\\"{x:1344,y:961,t:1527268425796};\\\", \\\"{x:1344,y:960,t:1527268425837};\\\", \\\"{x:1344,y:959,t:1527268425901};\\\", \\\"{x:1345,y:958,t:1527268425925};\\\", \\\"{x:1345,y:956,t:1527268425941};\\\", \\\"{x:1348,y:951,t:1527268425958};\\\", \\\"{x:1352,y:943,t:1527268425974};\\\", \\\"{x:1362,y:925,t:1527268425991};\\\", \\\"{x:1370,y:898,t:1527268426007};\\\", \\\"{x:1376,y:869,t:1527268426023};\\\", \\\"{x:1381,y:828,t:1527268426040};\\\", \\\"{x:1389,y:782,t:1527268426057};\\\", \\\"{x:1389,y:724,t:1527268426074};\\\", \\\"{x:1389,y:686,t:1527268426091};\\\", \\\"{x:1391,y:666,t:1527268426107};\\\", \\\"{x:1393,y:654,t:1527268426124};\\\", \\\"{x:1393,y:652,t:1527268426141};\\\", \\\"{x:1392,y:652,t:1527268426269};\\\", \\\"{x:1390,y:654,t:1527268426276};\\\", \\\"{x:1385,y:660,t:1527268426291};\\\", \\\"{x:1376,y:673,t:1527268426307};\\\", \\\"{x:1369,y:681,t:1527268426323};\\\", \\\"{x:1368,y:684,t:1527268426341};\\\", \\\"{x:1367,y:686,t:1527268426357};\\\", \\\"{x:1366,y:687,t:1527268426374};\\\", \\\"{x:1366,y:688,t:1527268426412};\\\", \\\"{x:1365,y:690,t:1527268426437};\\\", \\\"{x:1364,y:692,t:1527268426452};\\\", \\\"{x:1363,y:694,t:1527268426468};\\\", \\\"{x:1363,y:695,t:1527268426509};\\\", \\\"{x:1362,y:695,t:1527268426524};\\\", \\\"{x:1362,y:696,t:1527268426541};\\\", \\\"{x:1360,y:697,t:1527268426558};\\\", \\\"{x:1359,y:698,t:1527268426581};\\\", \\\"{x:1358,y:698,t:1527268426773};\\\", \\\"{x:1357,y:698,t:1527268426805};\\\", \\\"{x:1356,y:698,t:1527268426893};\\\", \\\"{x:1355,y:698,t:1527268426972};\\\", \\\"{x:1357,y:696,t:1527268427198};\\\", \\\"{x:1362,y:693,t:1527268427209};\\\", \\\"{x:1370,y:690,t:1527268427226};\\\", \\\"{x:1376,y:688,t:1527268427242};\\\", \\\"{x:1377,y:687,t:1527268427268};\\\", \\\"{x:1379,y:687,t:1527268427300};\\\", \\\"{x:1381,y:687,t:1527268427308};\\\", \\\"{x:1384,y:690,t:1527268427325};\\\", \\\"{x:1387,y:691,t:1527268427342};\\\", \\\"{x:1391,y:693,t:1527268427358};\\\", \\\"{x:1393,y:694,t:1527268427375};\\\", \\\"{x:1396,y:695,t:1527268427392};\\\", \\\"{x:1397,y:696,t:1527268427408};\\\", \\\"{x:1399,y:697,t:1527268427425};\\\", \\\"{x:1401,y:699,t:1527268427442};\\\", \\\"{x:1403,y:699,t:1527268427458};\\\", \\\"{x:1404,y:700,t:1527268427475};\\\", \\\"{x:1405,y:700,t:1527268427565};\\\", \\\"{x:1406,y:700,t:1527268427575};\\\", \\\"{x:1408,y:700,t:1527268427592};\\\", \\\"{x:1409,y:700,t:1527268427608};\\\", \\\"{x:1411,y:699,t:1527268427625};\\\", \\\"{x:1412,y:698,t:1527268427642};\\\", \\\"{x:1412,y:697,t:1527268427660};\\\", \\\"{x:1412,y:696,t:1527268427700};\\\", \\\"{x:1412,y:693,t:1527268427948};\\\", \\\"{x:1416,y:687,t:1527268427959};\\\", \\\"{x:1422,y:681,t:1527268427975};\\\", \\\"{x:1428,y:677,t:1527268427992};\\\", \\\"{x:1430,y:675,t:1527268428009};\\\", \\\"{x:1431,y:675,t:1527268428024};\\\", \\\"{x:1432,y:675,t:1527268428042};\\\", \\\"{x:1433,y:675,t:1527268428076};\\\", \\\"{x:1438,y:675,t:1527268428092};\\\", \\\"{x:1443,y:675,t:1527268428109};\\\", \\\"{x:1450,y:675,t:1527268428126};\\\", \\\"{x:1454,y:675,t:1527268428142};\\\", \\\"{x:1458,y:675,t:1527268428159};\\\", \\\"{x:1463,y:676,t:1527268428176};\\\", \\\"{x:1465,y:677,t:1527268428191};\\\", \\\"{x:1468,y:678,t:1527268428209};\\\", \\\"{x:1471,y:680,t:1527268428226};\\\", \\\"{x:1474,y:681,t:1527268428242};\\\", \\\"{x:1477,y:683,t:1527268428259};\\\", \\\"{x:1478,y:685,t:1527268428276};\\\", \\\"{x:1479,y:685,t:1527268428292};\\\", \\\"{x:1480,y:687,t:1527268428309};\\\", \\\"{x:1480,y:688,t:1527268428356};\\\", \\\"{x:1480,y:689,t:1527268428364};\\\", \\\"{x:1480,y:690,t:1527268428381};\\\", \\\"{x:1480,y:691,t:1527268428397};\\\", \\\"{x:1480,y:692,t:1527268428413};\\\", \\\"{x:1480,y:693,t:1527268428426};\\\", \\\"{x:1480,y:695,t:1527268428460};\\\", \\\"{x:1480,y:696,t:1527268428493};\\\", \\\"{x:1479,y:697,t:1527268428510};\\\", \\\"{x:1479,y:698,t:1527268428541};\\\", \\\"{x:1480,y:697,t:1527268428774};\\\", \\\"{x:1482,y:696,t:1527268428782};\\\", \\\"{x:1483,y:695,t:1527268428794};\\\", \\\"{x:1487,y:692,t:1527268428809};\\\", \\\"{x:1489,y:690,t:1527268428827};\\\", \\\"{x:1492,y:688,t:1527268428844};\\\", \\\"{x:1493,y:687,t:1527268428861};\\\", \\\"{x:1495,y:686,t:1527268428877};\\\", \\\"{x:1498,y:684,t:1527268428893};\\\", \\\"{x:1500,y:683,t:1527268428910};\\\", \\\"{x:1501,y:682,t:1527268428926};\\\", \\\"{x:1502,y:681,t:1527268428943};\\\", \\\"{x:1503,y:681,t:1527268428973};\\\", \\\"{x:1504,y:681,t:1527268429020};\\\", \\\"{x:1505,y:681,t:1527268429044};\\\", \\\"{x:1507,y:681,t:1527268429117};\\\", \\\"{x:1508,y:681,t:1527268429132};\\\", \\\"{x:1510,y:681,t:1527268429143};\\\", \\\"{x:1513,y:682,t:1527268429160};\\\", \\\"{x:1516,y:684,t:1527268429176};\\\", \\\"{x:1519,y:687,t:1527268429194};\\\", \\\"{x:1522,y:690,t:1527268429210};\\\", \\\"{x:1526,y:692,t:1527268429226};\\\", \\\"{x:1526,y:693,t:1527268429243};\\\", \\\"{x:1529,y:695,t:1527268429260};\\\", \\\"{x:1530,y:696,t:1527268429284};\\\", \\\"{x:1530,y:697,t:1527268429292};\\\", \\\"{x:1531,y:697,t:1527268429310};\\\", \\\"{x:1533,y:699,t:1527268429326};\\\", \\\"{x:1535,y:700,t:1527268429344};\\\", \\\"{x:1536,y:701,t:1527268429360};\\\", \\\"{x:1537,y:701,t:1527268429461};\\\", \\\"{x:1539,y:701,t:1527268429476};\\\", \\\"{x:1540,y:701,t:1527268429493};\\\", \\\"{x:1542,y:700,t:1527268429510};\\\", \\\"{x:1544,y:698,t:1527268429527};\\\", \\\"{x:1545,y:697,t:1527268429544};\\\", \\\"{x:1546,y:696,t:1527268429561};\\\", \\\"{x:1547,y:695,t:1527268429577};\\\", \\\"{x:1548,y:695,t:1527268429593};\\\", \\\"{x:1549,y:693,t:1527268429611};\\\", \\\"{x:1551,y:692,t:1527268429628};\\\", \\\"{x:1554,y:690,t:1527268429644};\\\", \\\"{x:1557,y:688,t:1527268429661};\\\", \\\"{x:1558,y:688,t:1527268429677};\\\", \\\"{x:1558,y:687,t:1527268429693};\\\", \\\"{x:1559,y:687,t:1527268429710};\\\", \\\"{x:1560,y:687,t:1527268429750};\\\", \\\"{x:1561,y:687,t:1527268429765};\\\", \\\"{x:1562,y:687,t:1527268429814};\\\", \\\"{x:1563,y:687,t:1527268429853};\\\", \\\"{x:1564,y:687,t:1527268429861};\\\", \\\"{x:1565,y:687,t:1527268429878};\\\", \\\"{x:1570,y:687,t:1527268429894};\\\", \\\"{x:1574,y:688,t:1527268429910};\\\", \\\"{x:1580,y:690,t:1527268429927};\\\", \\\"{x:1584,y:692,t:1527268429944};\\\", \\\"{x:1589,y:693,t:1527268429960};\\\", \\\"{x:1592,y:694,t:1527268429978};\\\", \\\"{x:1596,y:695,t:1527268429995};\\\", \\\"{x:1600,y:695,t:1527268430010};\\\", \\\"{x:1603,y:695,t:1527268430027};\\\", \\\"{x:1609,y:696,t:1527268430044};\\\", \\\"{x:1612,y:698,t:1527268430060};\\\", \\\"{x:1616,y:698,t:1527268430077};\\\", \\\"{x:1617,y:699,t:1527268430094};\\\", \\\"{x:1619,y:699,t:1527268430110};\\\", \\\"{x:1619,y:701,t:1527268437092};\\\", \\\"{x:1619,y:705,t:1527268437100};\\\", \\\"{x:1616,y:715,t:1527268437116};\\\", \\\"{x:1614,y:725,t:1527268437132};\\\", \\\"{x:1613,y:739,t:1527268437150};\\\", \\\"{x:1613,y:753,t:1527268437166};\\\", \\\"{x:1613,y:764,t:1527268437182};\\\", \\\"{x:1611,y:777,t:1527268437200};\\\", \\\"{x:1611,y:785,t:1527268437217};\\\", \\\"{x:1611,y:794,t:1527268437232};\\\", \\\"{x:1611,y:801,t:1527268437249};\\\", \\\"{x:1611,y:806,t:1527268437266};\\\", \\\"{x:1612,y:811,t:1527268437283};\\\", \\\"{x:1613,y:819,t:1527268437299};\\\", \\\"{x:1616,y:836,t:1527268437316};\\\", \\\"{x:1621,y:854,t:1527268437333};\\\", \\\"{x:1626,y:873,t:1527268437350};\\\", \\\"{x:1630,y:891,t:1527268437366};\\\", \\\"{x:1634,y:907,t:1527268437383};\\\", \\\"{x:1638,y:927,t:1527268437399};\\\", \\\"{x:1643,y:944,t:1527268437417};\\\", \\\"{x:1649,y:960,t:1527268437433};\\\", \\\"{x:1654,y:974,t:1527268437449};\\\", \\\"{x:1658,y:991,t:1527268437466};\\\", \\\"{x:1662,y:1002,t:1527268437483};\\\", \\\"{x:1664,y:1010,t:1527268437499};\\\", \\\"{x:1666,y:1019,t:1527268437516};\\\", \\\"{x:1668,y:1023,t:1527268437533};\\\", \\\"{x:1668,y:1026,t:1527268437549};\\\", \\\"{x:1668,y:1027,t:1527268437566};\\\", \\\"{x:1668,y:1028,t:1527268437584};\\\", \\\"{x:1668,y:1029,t:1527268437599};\\\", \\\"{x:1667,y:1029,t:1527268437644};\\\", \\\"{x:1666,y:1029,t:1527268437684};\\\", \\\"{x:1664,y:1030,t:1527268437699};\\\", \\\"{x:1663,y:1030,t:1527268437717};\\\", \\\"{x:1661,y:1030,t:1527268437734};\\\", \\\"{x:1657,y:1030,t:1527268437749};\\\", \\\"{x:1656,y:1029,t:1527268437767};\\\", \\\"{x:1654,y:1027,t:1527268437784};\\\", \\\"{x:1654,y:1026,t:1527268437800};\\\", \\\"{x:1653,y:1025,t:1527268437816};\\\", \\\"{x:1652,y:1025,t:1527268439694};\\\", \\\"{x:1651,y:1024,t:1527268439861};\\\", \\\"{x:1651,y:1023,t:1527268439886};\\\", \\\"{x:1650,y:1023,t:1527268439949};\\\", \\\"{x:1649,y:1022,t:1527268440045};\\\", \\\"{x:1648,y:1021,t:1527268440052};\\\", \\\"{x:1645,y:1018,t:1527268440068};\\\", \\\"{x:1642,y:1013,t:1527268440086};\\\", \\\"{x:1634,y:1004,t:1527268440103};\\\", \\\"{x:1624,y:990,t:1527268440119};\\\", \\\"{x:1603,y:974,t:1527268440136};\\\", \\\"{x:1582,y:963,t:1527268440151};\\\", \\\"{x:1556,y:951,t:1527268440168};\\\", \\\"{x:1523,y:938,t:1527268440185};\\\", \\\"{x:1492,y:929,t:1527268440202};\\\", \\\"{x:1458,y:919,t:1527268440218};\\\", \\\"{x:1430,y:915,t:1527268440236};\\\", \\\"{x:1410,y:912,t:1527268440251};\\\", \\\"{x:1381,y:909,t:1527268440268};\\\", \\\"{x:1367,y:907,t:1527268440286};\\\", \\\"{x:1354,y:905,t:1527268440301};\\\", \\\"{x:1343,y:902,t:1527268440319};\\\", \\\"{x:1330,y:897,t:1527268440335};\\\", \\\"{x:1315,y:885,t:1527268440351};\\\", \\\"{x:1298,y:869,t:1527268440368};\\\", \\\"{x:1287,y:850,t:1527268440385};\\\", \\\"{x:1280,y:833,t:1527268440401};\\\", \\\"{x:1279,y:827,t:1527268440419};\\\", \\\"{x:1279,y:821,t:1527268440435};\\\", \\\"{x:1279,y:818,t:1527268440452};\\\", \\\"{x:1283,y:813,t:1527268440469};\\\", \\\"{x:1288,y:811,t:1527268440485};\\\", \\\"{x:1292,y:808,t:1527268440503};\\\", \\\"{x:1295,y:807,t:1527268440518};\\\", \\\"{x:1301,y:807,t:1527268440535};\\\", \\\"{x:1311,y:807,t:1527268440552};\\\", \\\"{x:1323,y:807,t:1527268440568};\\\", \\\"{x:1332,y:807,t:1527268440586};\\\", \\\"{x:1337,y:809,t:1527268440602};\\\", \\\"{x:1342,y:809,t:1527268440618};\\\", \\\"{x:1345,y:810,t:1527268440636};\\\", \\\"{x:1348,y:811,t:1527268440652};\\\", \\\"{x:1349,y:812,t:1527268440668};\\\", \\\"{x:1350,y:812,t:1527268440692};\\\", \\\"{x:1351,y:813,t:1527268440702};\\\", \\\"{x:1353,y:814,t:1527268440718};\\\", \\\"{x:1355,y:816,t:1527268440735};\\\", \\\"{x:1357,y:818,t:1527268440752};\\\", \\\"{x:1358,y:820,t:1527268440768};\\\", \\\"{x:1359,y:822,t:1527268440785};\\\", \\\"{x:1359,y:823,t:1527268440802};\\\", \\\"{x:1359,y:824,t:1527268440819};\\\", \\\"{x:1359,y:826,t:1527268440836};\\\", \\\"{x:1359,y:827,t:1527268440876};\\\", \\\"{x:1359,y:828,t:1527268441028};\\\", \\\"{x:1354,y:828,t:1527268441035};\\\", \\\"{x:1333,y:824,t:1527268441052};\\\", \\\"{x:1308,y:817,t:1527268441069};\\\", \\\"{x:1268,y:807,t:1527268441085};\\\", \\\"{x:1224,y:795,t:1527268441103};\\\", \\\"{x:1190,y:787,t:1527268441120};\\\", \\\"{x:1171,y:783,t:1527268441136};\\\", \\\"{x:1161,y:779,t:1527268441152};\\\", \\\"{x:1160,y:779,t:1527268441172};\\\", \\\"{x:1160,y:778,t:1527268441292};\\\", \\\"{x:1161,y:776,t:1527268441303};\\\", \\\"{x:1162,y:776,t:1527268441320};\\\", \\\"{x:1164,y:774,t:1527268441335};\\\", \\\"{x:1166,y:773,t:1527268441352};\\\", \\\"{x:1168,y:772,t:1527268441369};\\\", \\\"{x:1169,y:772,t:1527268441387};\\\", \\\"{x:1169,y:771,t:1527268441403};\\\", \\\"{x:1171,y:770,t:1527268441420};\\\", \\\"{x:1171,y:769,t:1527268441436};\\\", \\\"{x:1171,y:767,t:1527268441476};\\\", \\\"{x:1171,y:766,t:1527268441524};\\\", \\\"{x:1173,y:765,t:1527268441548};\\\", \\\"{x:1173,y:764,t:1527268441556};\\\", \\\"{x:1173,y:763,t:1527268441572};\\\", \\\"{x:1173,y:761,t:1527268441597};\\\", \\\"{x:1173,y:760,t:1527268441604};\\\", \\\"{x:1173,y:759,t:1527268441620};\\\", \\\"{x:1173,y:757,t:1527268441636};\\\", \\\"{x:1173,y:755,t:1527268441653};\\\", \\\"{x:1174,y:754,t:1527268441669};\\\", \\\"{x:1174,y:752,t:1527268441687};\\\", \\\"{x:1174,y:750,t:1527268441703};\\\", \\\"{x:1175,y:747,t:1527268441720};\\\", \\\"{x:1176,y:743,t:1527268441737};\\\", \\\"{x:1177,y:740,t:1527268441753};\\\", \\\"{x:1178,y:737,t:1527268441770};\\\", \\\"{x:1179,y:734,t:1527268441786};\\\", \\\"{x:1181,y:731,t:1527268441803};\\\", \\\"{x:1182,y:729,t:1527268441820};\\\", \\\"{x:1185,y:728,t:1527268441836};\\\", \\\"{x:1187,y:726,t:1527268441854};\\\", \\\"{x:1191,y:724,t:1527268441870};\\\", \\\"{x:1197,y:722,t:1527268441887};\\\", \\\"{x:1203,y:719,t:1527268441904};\\\", \\\"{x:1210,y:718,t:1527268441919};\\\", \\\"{x:1223,y:717,t:1527268441936};\\\", \\\"{x:1236,y:714,t:1527268441954};\\\", \\\"{x:1249,y:713,t:1527268441969};\\\", \\\"{x:1260,y:710,t:1527268441987};\\\", \\\"{x:1270,y:708,t:1527268442004};\\\", \\\"{x:1278,y:706,t:1527268442019};\\\", \\\"{x:1284,y:703,t:1527268442037};\\\", \\\"{x:1286,y:702,t:1527268442054};\\\", \\\"{x:1288,y:701,t:1527268442091};\\\", \\\"{x:1292,y:699,t:1527268442108};\\\", \\\"{x:1294,y:698,t:1527268442119};\\\", \\\"{x:1300,y:694,t:1527268442137};\\\", \\\"{x:1306,y:690,t:1527268442153};\\\", \\\"{x:1308,y:690,t:1527268442170};\\\", \\\"{x:1309,y:689,t:1527268442187};\\\", \\\"{x:1309,y:688,t:1527268442227};\\\", \\\"{x:1310,y:687,t:1527268442243};\\\", \\\"{x:1311,y:686,t:1527268442259};\\\", \\\"{x:1311,y:683,t:1527268442270};\\\", \\\"{x:1312,y:680,t:1527268442286};\\\", \\\"{x:1312,y:679,t:1527268442303};\\\", \\\"{x:1312,y:677,t:1527268442320};\\\", \\\"{x:1313,y:676,t:1527268442421};\\\", \\\"{x:1314,y:676,t:1527268442437};\\\", \\\"{x:1314,y:675,t:1527268442460};\\\", \\\"{x:1315,y:675,t:1527268442471};\\\", \\\"{x:1317,y:674,t:1527268442486};\\\", \\\"{x:1319,y:673,t:1527268442503};\\\", \\\"{x:1322,y:671,t:1527268442521};\\\", \\\"{x:1325,y:669,t:1527268442537};\\\", \\\"{x:1327,y:669,t:1527268442554};\\\", \\\"{x:1329,y:666,t:1527268442571};\\\", \\\"{x:1331,y:666,t:1527268442587};\\\", \\\"{x:1333,y:665,t:1527268442603};\\\", \\\"{x:1334,y:664,t:1527268442621};\\\", \\\"{x:1335,y:663,t:1527268442637};\\\", \\\"{x:1337,y:662,t:1527268442654};\\\", \\\"{x:1339,y:661,t:1527268442671};\\\", \\\"{x:1342,y:659,t:1527268442687};\\\", \\\"{x:1345,y:657,t:1527268442704};\\\", \\\"{x:1347,y:656,t:1527268442721};\\\", \\\"{x:1350,y:655,t:1527268442737};\\\", \\\"{x:1354,y:653,t:1527268442754};\\\", \\\"{x:1355,y:652,t:1527268442771};\\\", \\\"{x:1357,y:650,t:1527268442787};\\\", \\\"{x:1360,y:649,t:1527268442803};\\\", \\\"{x:1361,y:648,t:1527268442821};\\\", \\\"{x:1363,y:647,t:1527268442843};\\\", \\\"{x:1364,y:647,t:1527268442876};\\\", \\\"{x:1365,y:646,t:1527268442892};\\\", \\\"{x:1366,y:646,t:1527268442948};\\\", \\\"{x:1368,y:645,t:1527268442964};\\\", \\\"{x:1371,y:644,t:1527268442972};\\\", \\\"{x:1373,y:643,t:1527268442987};\\\", \\\"{x:1375,y:642,t:1527268443004};\\\", \\\"{x:1381,y:639,t:1527268443021};\\\", \\\"{x:1385,y:638,t:1527268443037};\\\", \\\"{x:1387,y:636,t:1527268443324};\\\", \\\"{x:1392,y:635,t:1527268443337};\\\", \\\"{x:1399,y:631,t:1527268443354};\\\", \\\"{x:1407,y:626,t:1527268443370};\\\", \\\"{x:1412,y:622,t:1527268443388};\\\", \\\"{x:1417,y:618,t:1527268443404};\\\", \\\"{x:1420,y:617,t:1527268443420};\\\", \\\"{x:1421,y:616,t:1527268443437};\\\", \\\"{x:1422,y:615,t:1527268443644};\\\", \\\"{x:1423,y:615,t:1527268444620};\\\", \\\"{x:1426,y:612,t:1527268445221};\\\", \\\"{x:1440,y:606,t:1527268445228};\\\", \\\"{x:1450,y:600,t:1527268445239};\\\", \\\"{x:1457,y:596,t:1527268445256};\\\", \\\"{x:1460,y:595,t:1527268445273};\\\", \\\"{x:1467,y:593,t:1527268445289};\\\", \\\"{x:1472,y:591,t:1527268445305};\\\", \\\"{x:1473,y:591,t:1527268445323};\\\", \\\"{x:1474,y:591,t:1527268445340};\\\", \\\"{x:1478,y:589,t:1527268445356};\\\", \\\"{x:1484,y:588,t:1527268445373};\\\", \\\"{x:1490,y:588,t:1527268445390};\\\", \\\"{x:1495,y:588,t:1527268445405};\\\", \\\"{x:1504,y:588,t:1527268445422};\\\", \\\"{x:1513,y:588,t:1527268445440};\\\", \\\"{x:1526,y:588,t:1527268445456};\\\", \\\"{x:1540,y:588,t:1527268445473};\\\", \\\"{x:1555,y:588,t:1527268445490};\\\", \\\"{x:1570,y:588,t:1527268445505};\\\", \\\"{x:1584,y:588,t:1527268445522};\\\", \\\"{x:1602,y:588,t:1527268445540};\\\", \\\"{x:1608,y:588,t:1527268445556};\\\", \\\"{x:1611,y:588,t:1527268445572};\\\", \\\"{x:1612,y:588,t:1527268445590};\\\", \\\"{x:1614,y:588,t:1527268445606};\\\", \\\"{x:1615,y:588,t:1527268445623};\\\", \\\"{x:1616,y:588,t:1527268445640};\\\", \\\"{x:1618,y:588,t:1527268445655};\\\", \\\"{x:1621,y:589,t:1527268445673};\\\", \\\"{x:1623,y:589,t:1527268445690};\\\", \\\"{x:1624,y:589,t:1527268445708};\\\", \\\"{x:1626,y:589,t:1527268446005};\\\", \\\"{x:1627,y:589,t:1527268446013};\\\", \\\"{x:1628,y:590,t:1527268466423};\\\", \\\"{x:1642,y:607,t:1527268466431};\\\", \\\"{x:1683,y:653,t:1527268466443};\\\", \\\"{x:1822,y:782,t:1527268466460};\\\", \\\"{x:1919,y:889,t:1527268466476};\\\", \\\"{x:1919,y:975,t:1527268466493};\\\", \\\"{x:1919,y:1027,t:1527268466510};\\\", \\\"{x:1919,y:1058,t:1527268466526};\\\", \\\"{x:1919,y:1063,t:1527268466543};\\\", \\\"{x:1919,y:1058,t:1527268466567};\\\", \\\"{x:1919,y:1051,t:1527268466576};\\\", \\\"{x:1919,y:1039,t:1527268466593};\\\", \\\"{x:1919,y:1027,t:1527268466611};\\\", \\\"{x:1919,y:1024,t:1527268466626};\\\", \\\"{x:1919,y:1023,t:1527268466919};\\\", \\\"{x:1917,y:1023,t:1527268466927};\\\", \\\"{x:1914,y:1023,t:1527268466943};\\\", \\\"{x:1912,y:1023,t:1527268466960};\\\", \\\"{x:1910,y:1023,t:1527268466977};\\\", \\\"{x:1909,y:1024,t:1527268466993};\\\", \\\"{x:1907,y:1024,t:1527268467010};\\\", \\\"{x:1906,y:1024,t:1527268467027};\\\", \\\"{x:1906,y:1025,t:1527268467043};\\\", \\\"{x:1905,y:1026,t:1527268467060};\\\", \\\"{x:1904,y:1026,t:1527268467079};\\\", \\\"{x:1903,y:1026,t:1527268467095};\\\", \\\"{x:1900,y:1026,t:1527268467110};\\\", \\\"{x:1886,y:1021,t:1527268467127};\\\", \\\"{x:1871,y:1014,t:1527268467144};\\\", \\\"{x:1857,y:1008,t:1527268467160};\\\", \\\"{x:1846,y:1003,t:1527268467177};\\\", \\\"{x:1835,y:998,t:1527268467194};\\\", \\\"{x:1830,y:996,t:1527268467212};\\\", \\\"{x:1828,y:995,t:1527268467227};\\\", \\\"{x:1827,y:995,t:1527268467244};\\\", \\\"{x:1825,y:993,t:1527268467261};\\\", \\\"{x:1818,y:987,t:1527268467277};\\\", \\\"{x:1801,y:972,t:1527268467294};\\\", \\\"{x:1776,y:952,t:1527268467311};\\\", \\\"{x:1761,y:941,t:1527268467327};\\\", \\\"{x:1752,y:933,t:1527268467345};\\\", \\\"{x:1741,y:924,t:1527268467361};\\\", \\\"{x:1731,y:915,t:1527268467377};\\\", \\\"{x:1727,y:913,t:1527268467394};\\\", \\\"{x:1726,y:912,t:1527268467411};\\\", \\\"{x:1721,y:907,t:1527268467427};\\\", \\\"{x:1716,y:902,t:1527268467445};\\\", \\\"{x:1710,y:898,t:1527268467461};\\\", \\\"{x:1703,y:893,t:1527268467477};\\\", \\\"{x:1693,y:887,t:1527268467494};\\\", \\\"{x:1680,y:881,t:1527268467511};\\\", \\\"{x:1674,y:880,t:1527268467528};\\\", \\\"{x:1672,y:880,t:1527268467544};\\\", \\\"{x:1671,y:879,t:1527268467562};\\\", \\\"{x:1670,y:879,t:1527268467848};\\\", \\\"{x:1669,y:879,t:1527268467863};\\\", \\\"{x:1667,y:877,t:1527268467879};\\\", \\\"{x:1665,y:875,t:1527268467895};\\\", \\\"{x:1663,y:872,t:1527268467911};\\\", \\\"{x:1659,y:869,t:1527268467929};\\\", \\\"{x:1652,y:862,t:1527268467944};\\\", \\\"{x:1648,y:859,t:1527268467961};\\\", \\\"{x:1643,y:855,t:1527268467979};\\\", \\\"{x:1637,y:853,t:1527268467994};\\\", \\\"{x:1633,y:851,t:1527268468012};\\\", \\\"{x:1629,y:850,t:1527268468028};\\\", \\\"{x:1627,y:850,t:1527268468044};\\\", \\\"{x:1622,y:846,t:1527268468061};\\\", \\\"{x:1619,y:843,t:1527268468078};\\\", \\\"{x:1616,y:841,t:1527268468094};\\\", \\\"{x:1615,y:840,t:1527268468112};\\\", \\\"{x:1614,y:839,t:1527268468128};\\\", \\\"{x:1614,y:837,t:1527268468209};\\\", \\\"{x:1613,y:835,t:1527268468232};\\\", \\\"{x:1612,y:833,t:1527268468272};\\\", \\\"{x:1612,y:832,t:1527268468361};\\\", \\\"{x:1612,y:831,t:1527268468379};\\\", \\\"{x:1612,y:830,t:1527268468396};\\\", \\\"{x:1613,y:829,t:1527268468729};\\\", \\\"{x:1613,y:828,t:1527268468746};\\\", \\\"{x:1613,y:829,t:1527268468857};\\\", \\\"{x:1613,y:836,t:1527268468864};\\\", \\\"{x:1613,y:847,t:1527268468879};\\\", \\\"{x:1614,y:883,t:1527268468897};\\\", \\\"{x:1619,y:909,t:1527268468913};\\\", \\\"{x:1619,y:935,t:1527268468929};\\\", \\\"{x:1620,y:960,t:1527268468945};\\\", \\\"{x:1620,y:974,t:1527268468963};\\\", \\\"{x:1620,y:980,t:1527268468979};\\\", \\\"{x:1620,y:982,t:1527268468996};\\\", \\\"{x:1620,y:984,t:1527268469012};\\\", \\\"{x:1619,y:985,t:1527268469063};\\\", \\\"{x:1615,y:985,t:1527268469087};\\\", \\\"{x:1607,y:981,t:1527268469095};\\\", \\\"{x:1593,y:971,t:1527268469113};\\\", \\\"{x:1567,y:951,t:1527268469130};\\\", \\\"{x:1480,y:886,t:1527268469145};\\\", \\\"{x:1353,y:808,t:1527268469163};\\\", \\\"{x:1184,y:726,t:1527268469180};\\\", \\\"{x:1007,y:671,t:1527268469196};\\\", \\\"{x:833,y:647,t:1527268469213};\\\", \\\"{x:672,y:623,t:1527268469231};\\\", \\\"{x:534,y:604,t:1527268469246};\\\", \\\"{x:420,y:585,t:1527268469262};\\\", \\\"{x:278,y:556,t:1527268469279};\\\", \\\"{x:208,y:543,t:1527268469296};\\\", \\\"{x:177,y:540,t:1527268469313};\\\", \\\"{x:154,y:540,t:1527268469330};\\\", \\\"{x:133,y:539,t:1527268469345};\\\", \\\"{x:114,y:539,t:1527268469362};\\\", \\\"{x:98,y:538,t:1527268469379};\\\", \\\"{x:82,y:535,t:1527268469396};\\\", \\\"{x:72,y:534,t:1527268469413};\\\", \\\"{x:61,y:533,t:1527268469429};\\\", \\\"{x:51,y:530,t:1527268469445};\\\", \\\"{x:45,y:529,t:1527268469463};\\\", \\\"{x:39,y:528,t:1527268469479};\\\", \\\"{x:38,y:528,t:1527268469496};\\\", \\\"{x:36,y:528,t:1527268469519};\\\", \\\"{x:35,y:528,t:1527268469530};\\\", \\\"{x:32,y:527,t:1527268469546};\\\", \\\"{x:27,y:525,t:1527268469563};\\\", \\\"{x:20,y:523,t:1527268469580};\\\", \\\"{x:18,y:523,t:1527268469597};\\\", \\\"{x:16,y:523,t:1527268469612};\\\", \\\"{x:12,y:522,t:1527268469630};\\\", \\\"{x:6,y:522,t:1527268469647};\\\", \\\"{x:0,y:522,t:1527268469663};\\\", \\\"{x:0,y:521,t:1527268469688};\\\", \\\"{x:0,y:518,t:1527268469697};\\\", \\\"{x:0,y:515,t:1527268469714};\\\", \\\"{x:0,y:507,t:1527268469730};\\\", \\\"{x:0,y:502,t:1527268469747};\\\", \\\"{x:0,y:500,t:1527268469764};\\\", \\\"{x:0,y:499,t:1527268469823};\\\", \\\"{x:0,y:498,t:1527268469832};\\\", \\\"{x:2,y:495,t:1527268469847};\\\", \\\"{x:12,y:490,t:1527268469864};\\\", \\\"{x:17,y:489,t:1527268469879};\\\", \\\"{x:24,y:488,t:1527268469897};\\\", \\\"{x:29,y:488,t:1527268469913};\\\", \\\"{x:35,y:488,t:1527268469930};\\\", \\\"{x:49,y:488,t:1527268469948};\\\", \\\"{x:70,y:494,t:1527268469963};\\\", \\\"{x:94,y:502,t:1527268469979};\\\", \\\"{x:122,y:509,t:1527268469996};\\\", \\\"{x:146,y:515,t:1527268470012};\\\", \\\"{x:162,y:516,t:1527268470029};\\\", \\\"{x:167,y:516,t:1527268470046};\\\", \\\"{x:172,y:519,t:1527268470063};\\\", \\\"{x:177,y:521,t:1527268470079};\\\", \\\"{x:183,y:527,t:1527268470096};\\\", \\\"{x:191,y:534,t:1527268470113};\\\", \\\"{x:203,y:542,t:1527268470130};\\\", \\\"{x:217,y:548,t:1527268470146};\\\", \\\"{x:225,y:552,t:1527268470163};\\\", \\\"{x:229,y:552,t:1527268470181};\\\", \\\"{x:232,y:552,t:1527268470197};\\\", \\\"{x:234,y:552,t:1527268470214};\\\", \\\"{x:239,y:552,t:1527268470230};\\\", \\\"{x:256,y:552,t:1527268470246};\\\", \\\"{x:319,y:541,t:1527268470264};\\\", \\\"{x:413,y:528,t:1527268470280};\\\", \\\"{x:533,y:509,t:1527268470297};\\\", \\\"{x:665,y:492,t:1527268470314};\\\", \\\"{x:796,y:486,t:1527268470331};\\\", \\\"{x:893,y:486,t:1527268470346};\\\", \\\"{x:943,y:486,t:1527268470364};\\\", \\\"{x:962,y:495,t:1527268470379};\\\", \\\"{x:966,y:512,t:1527268470397};\\\", \\\"{x:967,y:542,t:1527268470414};\\\", \\\"{x:964,y:580,t:1527268470430};\\\", \\\"{x:948,y:614,t:1527268470448};\\\", \\\"{x:929,y:635,t:1527268470464};\\\", \\\"{x:916,y:637,t:1527268470480};\\\", \\\"{x:906,y:637,t:1527268470497};\\\", \\\"{x:891,y:631,t:1527268470515};\\\", \\\"{x:868,y:615,t:1527268470530};\\\", \\\"{x:831,y:588,t:1527268470548};\\\", \\\"{x:792,y:561,t:1527268470563};\\\", \\\"{x:754,y:541,t:1527268470581};\\\", \\\"{x:732,y:534,t:1527268470597};\\\", \\\"{x:716,y:532,t:1527268470614};\\\", \\\"{x:710,y:532,t:1527268470631};\\\", \\\"{x:706,y:532,t:1527268470646};\\\", \\\"{x:700,y:538,t:1527268470663};\\\", \\\"{x:694,y:547,t:1527268470681};\\\", \\\"{x:687,y:557,t:1527268470697};\\\", \\\"{x:680,y:566,t:1527268470714};\\\", \\\"{x:673,y:574,t:1527268470730};\\\", \\\"{x:670,y:577,t:1527268470747};\\\", \\\"{x:663,y:582,t:1527268470763};\\\", \\\"{x:661,y:582,t:1527268470780};\\\", \\\"{x:660,y:582,t:1527268470797};\\\", \\\"{x:658,y:582,t:1527268470813};\\\", \\\"{x:655,y:582,t:1527268470830};\\\", \\\"{x:643,y:582,t:1527268470847};\\\", \\\"{x:634,y:579,t:1527268470864};\\\", \\\"{x:625,y:578,t:1527268470880};\\\", \\\"{x:613,y:576,t:1527268470897};\\\", \\\"{x:599,y:575,t:1527268470914};\\\", \\\"{x:592,y:574,t:1527268470929};\\\", \\\"{x:588,y:574,t:1527268470947};\\\", \\\"{x:590,y:574,t:1527268471120};\\\", \\\"{x:595,y:574,t:1527268471131};\\\", \\\"{x:601,y:574,t:1527268471149};\\\", \\\"{x:603,y:574,t:1527268471164};\\\", \\\"{x:604,y:574,t:1527268471180};\\\", \\\"{x:605,y:573,t:1527268471391};\\\", \\\"{x:605,y:572,t:1527268471399};\\\", \\\"{x:605,y:571,t:1527268471415};\\\", \\\"{x:605,y:570,t:1527268471430};\\\", \\\"{x:608,y:568,t:1527268471447};\\\", \\\"{x:609,y:567,t:1527268471464};\\\", \\\"{x:611,y:566,t:1527268471480};\\\", \\\"{x:612,y:565,t:1527268471498};\\\", \\\"{x:614,y:564,t:1527268471514};\\\", \\\"{x:624,y:564,t:1527268471530};\\\", \\\"{x:658,y:564,t:1527268471548};\\\", \\\"{x:752,y:564,t:1527268471565};\\\", \\\"{x:915,y:564,t:1527268471582};\\\", \\\"{x:1128,y:564,t:1527268471598};\\\", \\\"{x:1366,y:562,t:1527268471614};\\\", \\\"{x:1724,y:562,t:1527268471631};\\\", \\\"{x:1919,y:562,t:1527268471647};\\\", \\\"{x:1919,y:563,t:1527268471703};\\\", \\\"{x:1919,y:567,t:1527268471715};\\\", \\\"{x:1919,y:570,t:1527268471732};\\\", \\\"{x:1919,y:574,t:1527268471747};\\\", \\\"{x:1919,y:583,t:1527268471765};\\\", \\\"{x:1916,y:594,t:1527268471782};\\\", \\\"{x:1906,y:609,t:1527268471797};\\\", \\\"{x:1895,y:621,t:1527268471814};\\\", \\\"{x:1885,y:627,t:1527268471831};\\\", \\\"{x:1881,y:628,t:1527268471848};\\\", \\\"{x:1878,y:629,t:1527268471865};\\\", \\\"{x:1876,y:630,t:1527268471896};\\\", \\\"{x:1872,y:631,t:1527268471904};\\\", \\\"{x:1869,y:632,t:1527268471915};\\\", \\\"{x:1858,y:636,t:1527268471932};\\\", \\\"{x:1843,y:644,t:1527268471949};\\\", \\\"{x:1824,y:651,t:1527268471965};\\\", \\\"{x:1800,y:664,t:1527268471982};\\\", \\\"{x:1767,y:683,t:1527268471999};\\\", \\\"{x:1729,y:705,t:1527268472015};\\\", \\\"{x:1681,y:739,t:1527268472032};\\\", \\\"{x:1650,y:767,t:1527268472049};\\\", \\\"{x:1631,y:788,t:1527268472066};\\\", \\\"{x:1619,y:804,t:1527268472082};\\\", \\\"{x:1611,y:819,t:1527268472100};\\\", \\\"{x:1604,y:830,t:1527268472116};\\\", \\\"{x:1599,y:840,t:1527268472132};\\\", \\\"{x:1592,y:852,t:1527268472149};\\\", \\\"{x:1581,y:863,t:1527268472166};\\\", \\\"{x:1567,y:873,t:1527268472182};\\\", \\\"{x:1552,y:879,t:1527268472199};\\\", \\\"{x:1534,y:883,t:1527268472215};\\\", \\\"{x:1527,y:884,t:1527268472232};\\\", \\\"{x:1524,y:884,t:1527268472249};\\\", \\\"{x:1522,y:884,t:1527268472266};\\\", \\\"{x:1520,y:882,t:1527268472281};\\\", \\\"{x:1517,y:876,t:1527268472299};\\\", \\\"{x:1513,y:869,t:1527268472316};\\\", \\\"{x:1509,y:858,t:1527268472332};\\\", \\\"{x:1506,y:845,t:1527268472349};\\\", \\\"{x:1505,y:829,t:1527268472365};\\\", \\\"{x:1504,y:812,t:1527268472382};\\\", \\\"{x:1504,y:807,t:1527268472399};\\\", \\\"{x:1505,y:805,t:1527268472415};\\\", \\\"{x:1507,y:805,t:1527268472496};\\\", \\\"{x:1512,y:805,t:1527268472504};\\\", \\\"{x:1517,y:805,t:1527268472516};\\\", \\\"{x:1534,y:805,t:1527268472533};\\\", \\\"{x:1553,y:803,t:1527268472549};\\\", \\\"{x:1571,y:801,t:1527268472566};\\\", \\\"{x:1590,y:798,t:1527268472583};\\\", \\\"{x:1609,y:795,t:1527268472599};\\\", \\\"{x:1629,y:786,t:1527268472616};\\\", \\\"{x:1637,y:782,t:1527268472633};\\\", \\\"{x:1646,y:778,t:1527268472649};\\\", \\\"{x:1657,y:774,t:1527268472666};\\\", \\\"{x:1673,y:767,t:1527268472683};\\\", \\\"{x:1682,y:763,t:1527268472700};\\\", \\\"{x:1688,y:762,t:1527268472717};\\\", \\\"{x:1693,y:762,t:1527268472733};\\\", \\\"{x:1696,y:762,t:1527268472749};\\\", \\\"{x:1700,y:762,t:1527268472766};\\\", \\\"{x:1702,y:762,t:1527268472783};\\\", \\\"{x:1710,y:765,t:1527268472799};\\\", \\\"{x:1717,y:772,t:1527268472815};\\\", \\\"{x:1725,y:779,t:1527268472833};\\\", \\\"{x:1732,y:787,t:1527268472850};\\\", \\\"{x:1739,y:795,t:1527268472866};\\\", \\\"{x:1745,y:804,t:1527268472882};\\\", \\\"{x:1747,y:805,t:1527268472899};\\\", \\\"{x:1748,y:805,t:1527268473433};\\\", \\\"{x:1750,y:805,t:1527268473440};\\\", \\\"{x:1753,y:805,t:1527268473450};\\\", \\\"{x:1760,y:805,t:1527268473467};\\\", \\\"{x:1763,y:805,t:1527268473485};\\\", \\\"{x:1766,y:805,t:1527268473500};\\\", \\\"{x:1768,y:805,t:1527268473517};\\\", \\\"{x:1769,y:807,t:1527268473569};\\\", \\\"{x:1771,y:807,t:1527268473584};\\\", \\\"{x:1772,y:807,t:1527268473600};\\\", \\\"{x:1774,y:808,t:1527268473617};\\\", \\\"{x:1776,y:809,t:1527268473634};\\\", \\\"{x:1780,y:810,t:1527268473651};\\\", \\\"{x:1781,y:810,t:1527268473667};\\\", \\\"{x:1782,y:811,t:1527268473777};\\\", \\\"{x:1783,y:811,t:1527268473969};\\\", \\\"{x:1784,y:812,t:1527268473984};\\\", \\\"{x:1785,y:813,t:1527268474001};\\\", \\\"{x:1786,y:814,t:1527268474017};\\\", \\\"{x:1786,y:816,t:1527268474034};\\\", \\\"{x:1787,y:817,t:1527268474064};\\\", \\\"{x:1788,y:818,t:1527268474569};\\\", \\\"{x:1790,y:820,t:1527268474585};\\\", \\\"{x:1791,y:820,t:1527268474602};\\\", \\\"{x:1794,y:823,t:1527268474619};\\\", \\\"{x:1795,y:823,t:1527268474635};\\\", \\\"{x:1796,y:823,t:1527268474652};\\\", \\\"{x:1798,y:824,t:1527268474668};\\\", \\\"{x:1800,y:825,t:1527268474685};\\\", \\\"{x:1802,y:825,t:1527268474703};\\\", \\\"{x:1802,y:826,t:1527268474719};\\\", \\\"{x:1803,y:826,t:1527268474735};\\\", \\\"{x:1804,y:827,t:1527268474753};\\\", \\\"{x:1805,y:828,t:1527268474784};\\\", \\\"{x:1811,y:828,t:1527268475033};\\\", \\\"{x:1819,y:828,t:1527268475040};\\\", \\\"{x:1831,y:828,t:1527268475053};\\\", \\\"{x:1857,y:828,t:1527268475069};\\\", \\\"{x:1884,y:828,t:1527268475086};\\\", \\\"{x:1901,y:828,t:1527268475103};\\\", \\\"{x:1912,y:828,t:1527268475120};\\\", \\\"{x:1913,y:828,t:1527268475136};\\\", \\\"{x:1914,y:830,t:1527268475264};\\\", \\\"{x:1914,y:832,t:1527268475279};\\\", \\\"{x:1914,y:833,t:1527268475287};\\\", \\\"{x:1914,y:835,t:1527268475300};\\\", \\\"{x:1914,y:836,t:1527268475317};\\\", \\\"{x:1914,y:837,t:1527268475336};\\\", \\\"{x:1912,y:837,t:1527268475400};\\\", \\\"{x:1904,y:837,t:1527268475417};\\\", \\\"{x:1889,y:837,t:1527268475434};\\\", \\\"{x:1876,y:837,t:1527268475451};\\\", \\\"{x:1867,y:837,t:1527268475469};\\\", \\\"{x:1861,y:837,t:1527268475486};\\\", \\\"{x:1857,y:837,t:1527268475501};\\\", \\\"{x:1856,y:837,t:1527268475518};\\\", \\\"{x:1853,y:837,t:1527268475879};\\\", \\\"{x:1849,y:837,t:1527268475887};\\\", \\\"{x:1839,y:837,t:1527268475900};\\\", \\\"{x:1815,y:837,t:1527268475918};\\\", \\\"{x:1761,y:830,t:1527268475934};\\\", \\\"{x:1613,y:810,t:1527268475951};\\\", \\\"{x:1463,y:788,t:1527268475967};\\\", \\\"{x:1295,y:766,t:1527268475985};\\\", \\\"{x:1118,y:739,t:1527268476002};\\\", \\\"{x:946,y:717,t:1527268476018};\\\", \\\"{x:801,y:706,t:1527268476035};\\\", \\\"{x:690,y:704,t:1527268476051};\\\", \\\"{x:637,y:704,t:1527268476068};\\\", \\\"{x:616,y:706,t:1527268476084};\\\", \\\"{x:613,y:706,t:1527268476102};\\\", \\\"{x:612,y:707,t:1527268476118};\\\", \\\"{x:612,y:708,t:1527268476135};\\\", \\\"{x:612,y:714,t:1527268476151};\\\", \\\"{x:615,y:719,t:1527268476168};\\\", \\\"{x:619,y:722,t:1527268476185};\\\", \\\"{x:626,y:725,t:1527268476202};\\\", \\\"{x:642,y:728,t:1527268476218};\\\", \\\"{x:658,y:733,t:1527268476234};\\\", \\\"{x:683,y:739,t:1527268476252};\\\", \\\"{x:713,y:741,t:1527268476268};\\\", \\\"{x:747,y:746,t:1527268476285};\\\", \\\"{x:784,y:749,t:1527268476302};\\\", \\\"{x:825,y:752,t:1527268476318};\\\", \\\"{x:855,y:752,t:1527268476335};\\\", \\\"{x:886,y:752,t:1527268476351};\\\", \\\"{x:903,y:752,t:1527268476369};\\\", \\\"{x:915,y:752,t:1527268476385};\\\", \\\"{x:925,y:751,t:1527268476402};\\\", \\\"{x:933,y:749,t:1527268476419};\\\", \\\"{x:939,y:746,t:1527268476435};\\\", \\\"{x:945,y:742,t:1527268476452};\\\", \\\"{x:956,y:738,t:1527268476469};\\\", \\\"{x:966,y:734,t:1527268476485};\\\", \\\"{x:982,y:734,t:1527268476503};\\\", \\\"{x:997,y:732,t:1527268476520};\\\", \\\"{x:1004,y:729,t:1527268476536};\\\", \\\"{x:1009,y:728,t:1527268476552};\\\", \\\"{x:1010,y:728,t:1527268476569};\\\", \\\"{x:1012,y:726,t:1527268476586};\\\", \\\"{x:1014,y:726,t:1527268476602};\\\", \\\"{x:1016,y:726,t:1527268477320};\\\", \\\"{x:1017,y:726,t:1527268477336};\\\", \\\"{x:1018,y:726,t:1527268477368};\\\", \\\"{x:1021,y:728,t:1527268478208};\\\", \\\"{x:1023,y:733,t:1527268478220};\\\", \\\"{x:1028,y:743,t:1527268478237};\\\", \\\"{x:1033,y:750,t:1527268478253};\\\", \\\"{x:1035,y:752,t:1527268478271};\\\", \\\"{x:1036,y:753,t:1527268478287};\\\", \\\"{x:1037,y:753,t:1527268478336};\\\", \\\"{x:1042,y:753,t:1527268478353};\\\", \\\"{x:1056,y:753,t:1527268478371};\\\", \\\"{x:1072,y:753,t:1527268478387};\\\", \\\"{x:1093,y:756,t:1527268478404};\\\", \\\"{x:1118,y:756,t:1527268478420};\\\", \\\"{x:1138,y:756,t:1527268478438};\\\", \\\"{x:1151,y:756,t:1527268478453};\\\", \\\"{x:1159,y:756,t:1527268478470};\\\", \\\"{x:1162,y:755,t:1527268478488};\\\", \\\"{x:1164,y:753,t:1527268478503};\\\", \\\"{x:1167,y:752,t:1527268478520};\\\", \\\"{x:1169,y:751,t:1527268478538};\\\", \\\"{x:1172,y:750,t:1527268478553};\\\", \\\"{x:1173,y:749,t:1527268478584};\\\", \\\"{x:1174,y:749,t:1527268478624};\\\", \\\"{x:1175,y:749,t:1527268478657};\\\", \\\"{x:1176,y:748,t:1527268478680};\\\", \\\"{x:1178,y:747,t:1527268478777};\\\", \\\"{x:1178,y:746,t:1527268479257};\\\", \\\"{x:1177,y:745,t:1527268479271};\\\", \\\"{x:1177,y:743,t:1527268479288};\\\", \\\"{x:1179,y:741,t:1527268479304};\\\", \\\"{x:1181,y:739,t:1527268479322};\\\", \\\"{x:1182,y:739,t:1527268479337};\\\", \\\"{x:1183,y:738,t:1527268479355};\\\", \\\"{x:1185,y:736,t:1527268479372};\\\", \\\"{x:1186,y:735,t:1527268479408};\\\", \\\"{x:1186,y:736,t:1527268479584};\\\", \\\"{x:1186,y:737,t:1527268479592};\\\", \\\"{x:1186,y:739,t:1527268479608};\\\", \\\"{x:1186,y:740,t:1527268479622};\\\", \\\"{x:1186,y:742,t:1527268479638};\\\", \\\"{x:1186,y:743,t:1527268479656};\\\", \\\"{x:1186,y:745,t:1527268479671};\\\", \\\"{x:1186,y:746,t:1527268479712};\\\", \\\"{x:1185,y:747,t:1527268479721};\\\", \\\"{x:1184,y:748,t:1527268479738};\\\", \\\"{x:1182,y:751,t:1527268479755};\\\", \\\"{x:1181,y:753,t:1527268479772};\\\", \\\"{x:1180,y:757,t:1527268479788};\\\", \\\"{x:1180,y:760,t:1527268479805};\\\", \\\"{x:1180,y:763,t:1527268479821};\\\", \\\"{x:1180,y:765,t:1527268479838};\\\", \\\"{x:1180,y:766,t:1527268479928};\\\", \\\"{x:1182,y:766,t:1527268480256};\\\", \\\"{x:1195,y:766,t:1527268480271};\\\", \\\"{x:1211,y:766,t:1527268480288};\\\", \\\"{x:1234,y:766,t:1527268480304};\\\", \\\"{x:1268,y:766,t:1527268480321};\\\", \\\"{x:1307,y:766,t:1527268480337};\\\", \\\"{x:1340,y:764,t:1527268480355};\\\", \\\"{x:1368,y:755,t:1527268480372};\\\", \\\"{x:1379,y:752,t:1527268480388};\\\", \\\"{x:1380,y:752,t:1527268480405};\\\", \\\"{x:1380,y:753,t:1527268480487};\\\", \\\"{x:1380,y:754,t:1527268480505};\\\", \\\"{x:1378,y:756,t:1527268480522};\\\", \\\"{x:1378,y:757,t:1527268480537};\\\", \\\"{x:1377,y:759,t:1527268480556};\\\", \\\"{x:1375,y:760,t:1527268480572};\\\", \\\"{x:1371,y:763,t:1527268480588};\\\", \\\"{x:1368,y:764,t:1527268480605};\\\", \\\"{x:1362,y:766,t:1527268480622};\\\", \\\"{x:1356,y:766,t:1527268480638};\\\", \\\"{x:1353,y:767,t:1527268480655};\\\", \\\"{x:1352,y:767,t:1527268480673};\\\", \\\"{x:1355,y:765,t:1527268480857};\\\", \\\"{x:1361,y:763,t:1527268480872};\\\", \\\"{x:1364,y:762,t:1527268480889};\\\", \\\"{x:1371,y:762,t:1527268480905};\\\", \\\"{x:1374,y:761,t:1527268480922};\\\", \\\"{x:1375,y:761,t:1527268480938};\\\", \\\"{x:1377,y:761,t:1527268480959};\\\", \\\"{x:1378,y:761,t:1527268480992};\\\", \\\"{x:1379,y:761,t:1527268481064};\\\", \\\"{x:1380,y:761,t:1527268481080};\\\", \\\"{x:1381,y:761,t:1527268481121};\\\", \\\"{x:1381,y:762,t:1527268481233};\\\", \\\"{x:1380,y:763,t:1527268481280};\\\", \\\"{x:1379,y:763,t:1527268481744};\\\", \\\"{x:1378,y:763,t:1527268481756};\\\", \\\"{x:1377,y:763,t:1527268481783};\\\", \\\"{x:1376,y:764,t:1527268481800};\\\", \\\"{x:1375,y:764,t:1527268481865};\\\", \\\"{x:1373,y:764,t:1527268481896};\\\", \\\"{x:1372,y:764,t:1527268481906};\\\", \\\"{x:1369,y:764,t:1527268481923};\\\", \\\"{x:1367,y:764,t:1527268481940};\\\", \\\"{x:1362,y:763,t:1527268481957};\\\", \\\"{x:1358,y:761,t:1527268481974};\\\", \\\"{x:1353,y:760,t:1527268481990};\\\", \\\"{x:1350,y:760,t:1527268482007};\\\", \\\"{x:1347,y:758,t:1527268482024};\\\", \\\"{x:1346,y:758,t:1527268482072};\\\", \\\"{x:1345,y:758,t:1527268482080};\\\", \\\"{x:1344,y:758,t:1527268482091};\\\", \\\"{x:1343,y:758,t:1527268482107};\\\", \\\"{x:1340,y:758,t:1527268482123};\\\", \\\"{x:1336,y:757,t:1527268482141};\\\", \\\"{x:1333,y:757,t:1527268482157};\\\", \\\"{x:1331,y:757,t:1527268482174};\\\", \\\"{x:1327,y:757,t:1527268482191};\\\", \\\"{x:1326,y:757,t:1527268482207};\\\", \\\"{x:1320,y:756,t:1527268482223};\\\", \\\"{x:1313,y:756,t:1527268482240};\\\", \\\"{x:1307,y:755,t:1527268482256};\\\", \\\"{x:1300,y:754,t:1527268482273};\\\", \\\"{x:1292,y:753,t:1527268482290};\\\", \\\"{x:1283,y:752,t:1527268482306};\\\", \\\"{x:1276,y:750,t:1527268482323};\\\", \\\"{x:1268,y:750,t:1527268482339};\\\", \\\"{x:1261,y:749,t:1527268482356};\\\", \\\"{x:1255,y:748,t:1527268482373};\\\", \\\"{x:1251,y:748,t:1527268482390};\\\", \\\"{x:1250,y:748,t:1527268482406};\\\", \\\"{x:1247,y:748,t:1527268482423};\\\", \\\"{x:1244,y:746,t:1527268482440};\\\", \\\"{x:1239,y:746,t:1527268482456};\\\", \\\"{x:1234,y:746,t:1527268482473};\\\", \\\"{x:1229,y:746,t:1527268482489};\\\", \\\"{x:1223,y:746,t:1527268482507};\\\", \\\"{x:1218,y:746,t:1527268482523};\\\", \\\"{x:1211,y:746,t:1527268482540};\\\", \\\"{x:1210,y:746,t:1527268482557};\\\", \\\"{x:1207,y:746,t:1527268482573};\\\", \\\"{x:1205,y:746,t:1527268482590};\\\", \\\"{x:1203,y:746,t:1527268482608};\\\", \\\"{x:1202,y:746,t:1527268482623};\\\", \\\"{x:1200,y:746,t:1527268482640};\\\", \\\"{x:1199,y:746,t:1527268482657};\\\", \\\"{x:1197,y:746,t:1527268482673};\\\", \\\"{x:1196,y:746,t:1527268482690};\\\", \\\"{x:1195,y:746,t:1527268482752};\\\", \\\"{x:1194,y:746,t:1527268483136};\\\", \\\"{x:1189,y:747,t:1527268483656};\\\", \\\"{x:1172,y:751,t:1527268483675};\\\", \\\"{x:1156,y:753,t:1527268483691};\\\", \\\"{x:1141,y:756,t:1527268483708};\\\", \\\"{x:1127,y:758,t:1527268483725};\\\", \\\"{x:1120,y:760,t:1527268483742};\\\", \\\"{x:1119,y:760,t:1527268483758};\\\", \\\"{x:1118,y:760,t:1527268483775};\\\", \\\"{x:1119,y:760,t:1527268484039};\\\", \\\"{x:1120,y:760,t:1527268484047};\\\", \\\"{x:1121,y:760,t:1527268484058};\\\", \\\"{x:1125,y:759,t:1527268484074};\\\", \\\"{x:1128,y:759,t:1527268484091};\\\", \\\"{x:1130,y:759,t:1527268484108};\\\", \\\"{x:1131,y:759,t:1527268484123};\\\", \\\"{x:1133,y:759,t:1527268484141};\\\", \\\"{x:1137,y:759,t:1527268484158};\\\", \\\"{x:1140,y:757,t:1527268484174};\\\", \\\"{x:1148,y:757,t:1527268484191};\\\", \\\"{x:1154,y:757,t:1527268484207};\\\", \\\"{x:1160,y:757,t:1527268484225};\\\", \\\"{x:1164,y:757,t:1527268484241};\\\", \\\"{x:1166,y:757,t:1527268484258};\\\", \\\"{x:1167,y:757,t:1527268484275};\\\", \\\"{x:1168,y:757,t:1527268484320};\\\", \\\"{x:1169,y:757,t:1527268484360};\\\", \\\"{x:1170,y:757,t:1527268484375};\\\", \\\"{x:1171,y:757,t:1527268485007};\\\", \\\"{x:1172,y:758,t:1527268486689};\\\", \\\"{x:1172,y:759,t:1527268486712};\\\", \\\"{x:1172,y:760,t:1527268486800};\\\", \\\"{x:1172,y:761,t:1527268486936};\\\", \\\"{x:1172,y:763,t:1527268487881};\\\", \\\"{x:1172,y:766,t:1527268487895};\\\", \\\"{x:1172,y:773,t:1527268487912};\\\", \\\"{x:1173,y:779,t:1527268487928};\\\", \\\"{x:1174,y:782,t:1527268487945};\\\", \\\"{x:1175,y:786,t:1527268487962};\\\", \\\"{x:1176,y:790,t:1527268487977};\\\", \\\"{x:1177,y:794,t:1527268487994};\\\", \\\"{x:1180,y:799,t:1527268488011};\\\", \\\"{x:1181,y:804,t:1527268488027};\\\", \\\"{x:1183,y:809,t:1527268488044};\\\", \\\"{x:1183,y:815,t:1527268488061};\\\", \\\"{x:1186,y:820,t:1527268488077};\\\", \\\"{x:1187,y:826,t:1527268488094};\\\", \\\"{x:1189,y:831,t:1527268488111};\\\", \\\"{x:1189,y:834,t:1527268488128};\\\", \\\"{x:1190,y:837,t:1527268488144};\\\", \\\"{x:1190,y:841,t:1527268488161};\\\", \\\"{x:1190,y:846,t:1527268488177};\\\", \\\"{x:1190,y:852,t:1527268488194};\\\", \\\"{x:1190,y:857,t:1527268488211};\\\", \\\"{x:1190,y:861,t:1527268488228};\\\", \\\"{x:1190,y:864,t:1527268488244};\\\", \\\"{x:1190,y:867,t:1527268488261};\\\", \\\"{x:1190,y:871,t:1527268488279};\\\", \\\"{x:1190,y:874,t:1527268488295};\\\", \\\"{x:1190,y:878,t:1527268488312};\\\", \\\"{x:1190,y:884,t:1527268488329};\\\", \\\"{x:1190,y:892,t:1527268488344};\\\", \\\"{x:1190,y:905,t:1527268488362};\\\", \\\"{x:1190,y:916,t:1527268488379};\\\", \\\"{x:1189,y:922,t:1527268488395};\\\", \\\"{x:1189,y:928,t:1527268488411};\\\", \\\"{x:1189,y:932,t:1527268488428};\\\", \\\"{x:1189,y:936,t:1527268488445};\\\", \\\"{x:1188,y:940,t:1527268488461};\\\", \\\"{x:1188,y:945,t:1527268488479};\\\", \\\"{x:1188,y:951,t:1527268488494};\\\", \\\"{x:1187,y:958,t:1527268488511};\\\", \\\"{x:1187,y:959,t:1527268488528};\\\", \\\"{x:1187,y:960,t:1527268488545};\\\", \\\"{x:1186,y:962,t:1527268488561};\\\", \\\"{x:1186,y:964,t:1527268488600};\\\", \\\"{x:1186,y:965,t:1527268488624};\\\", \\\"{x:1185,y:965,t:1527268488632};\\\", \\\"{x:1185,y:967,t:1527268488647};\\\", \\\"{x:1185,y:968,t:1527268488680};\\\", \\\"{x:1185,y:963,t:1527268488921};\\\", \\\"{x:1185,y:953,t:1527268488929};\\\", \\\"{x:1186,y:935,t:1527268488945};\\\", \\\"{x:1186,y:922,t:1527268488962};\\\", \\\"{x:1186,y:908,t:1527268488978};\\\", \\\"{x:1186,y:899,t:1527268488995};\\\", \\\"{x:1186,y:889,t:1527268489011};\\\", \\\"{x:1186,y:881,t:1527268489028};\\\", \\\"{x:1186,y:873,t:1527268489045};\\\", \\\"{x:1186,y:859,t:1527268489061};\\\", \\\"{x:1186,y:849,t:1527268489079};\\\", \\\"{x:1186,y:831,t:1527268489096};\\\", \\\"{x:1186,y:821,t:1527268489111};\\\", \\\"{x:1186,y:813,t:1527268489129};\\\", \\\"{x:1186,y:804,t:1527268489146};\\\", \\\"{x:1186,y:800,t:1527268489163};\\\", \\\"{x:1186,y:794,t:1527268489179};\\\", \\\"{x:1186,y:787,t:1527268489196};\\\", \\\"{x:1186,y:779,t:1527268489213};\\\", \\\"{x:1187,y:775,t:1527268489229};\\\", \\\"{x:1187,y:771,t:1527268489245};\\\", \\\"{x:1187,y:770,t:1527268489263};\\\", \\\"{x:1187,y:766,t:1527268489279};\\\", \\\"{x:1187,y:762,t:1527268489296};\\\", \\\"{x:1187,y:760,t:1527268489313};\\\", \\\"{x:1187,y:759,t:1527268489336};\\\", \\\"{x:1187,y:758,t:1527268489352};\\\", \\\"{x:1187,y:757,t:1527268489363};\\\", \\\"{x:1187,y:756,t:1527268489379};\\\", \\\"{x:1187,y:755,t:1527268489396};\\\", \\\"{x:1187,y:754,t:1527268489413};\\\", \\\"{x:1187,y:753,t:1527268489428};\\\", \\\"{x:1187,y:752,t:1527268489446};\\\", \\\"{x:1187,y:751,t:1527268489462};\\\", \\\"{x:1187,y:750,t:1527268489520};\\\", \\\"{x:1187,y:749,t:1527268489530};\\\", \\\"{x:1187,y:751,t:1527268489881};\\\", \\\"{x:1185,y:759,t:1527268489896};\\\", \\\"{x:1184,y:769,t:1527268489914};\\\", \\\"{x:1182,y:780,t:1527268489930};\\\", \\\"{x:1182,y:789,t:1527268489946};\\\", \\\"{x:1182,y:800,t:1527268489963};\\\", \\\"{x:1182,y:806,t:1527268489980};\\\", \\\"{x:1183,y:814,t:1527268489997};\\\", \\\"{x:1183,y:820,t:1527268490013};\\\", \\\"{x:1184,y:824,t:1527268490030};\\\", \\\"{x:1185,y:827,t:1527268490047};\\\", \\\"{x:1186,y:829,t:1527268490063};\\\", \\\"{x:1187,y:833,t:1527268490080};\\\", \\\"{x:1189,y:835,t:1527268490096};\\\", \\\"{x:1189,y:836,t:1527268490112};\\\", \\\"{x:1190,y:837,t:1527268490130};\\\", \\\"{x:1190,y:838,t:1527268490147};\\\", \\\"{x:1192,y:839,t:1527268490168};\\\", \\\"{x:1193,y:839,t:1527268490264};\\\", \\\"{x:1195,y:839,t:1527268490280};\\\", \\\"{x:1199,y:839,t:1527268490297};\\\", \\\"{x:1202,y:838,t:1527268490313};\\\", \\\"{x:1207,y:837,t:1527268490330};\\\", \\\"{x:1212,y:837,t:1527268490347};\\\", \\\"{x:1216,y:836,t:1527268490363};\\\", \\\"{x:1217,y:836,t:1527268490379};\\\", \\\"{x:1219,y:835,t:1527268490397};\\\", \\\"{x:1222,y:834,t:1527268490414};\\\", \\\"{x:1224,y:834,t:1527268490430};\\\", \\\"{x:1226,y:833,t:1527268490447};\\\", \\\"{x:1228,y:831,t:1527268490480};\\\", \\\"{x:1229,y:831,t:1527268490504};\\\", \\\"{x:1230,y:830,t:1527268490520};\\\", \\\"{x:1229,y:829,t:1527268490777};\\\", \\\"{x:1228,y:828,t:1527268490783};\\\", \\\"{x:1227,y:827,t:1527268490797};\\\", \\\"{x:1225,y:826,t:1527268490814};\\\", \\\"{x:1223,y:824,t:1527268490830};\\\", \\\"{x:1222,y:827,t:1527268491104};\\\", \\\"{x:1219,y:833,t:1527268491114};\\\", \\\"{x:1217,y:842,t:1527268491132};\\\", \\\"{x:1217,y:853,t:1527268491147};\\\", \\\"{x:1217,y:863,t:1527268491164};\\\", \\\"{x:1217,y:870,t:1527268491181};\\\", \\\"{x:1219,y:878,t:1527268491197};\\\", \\\"{x:1220,y:885,t:1527268491213};\\\", \\\"{x:1224,y:896,t:1527268491231};\\\", \\\"{x:1225,y:909,t:1527268491246};\\\", \\\"{x:1228,y:923,t:1527268491263};\\\", \\\"{x:1229,y:934,t:1527268491280};\\\", \\\"{x:1230,y:943,t:1527268491298};\\\", \\\"{x:1232,y:949,t:1527268491313};\\\", \\\"{x:1232,y:951,t:1527268491331};\\\", \\\"{x:1232,y:953,t:1527268491347};\\\", \\\"{x:1232,y:954,t:1527268491363};\\\", \\\"{x:1232,y:955,t:1527268491381};\\\", \\\"{x:1232,y:956,t:1527268491399};\\\", \\\"{x:1230,y:957,t:1527268491472};\\\", \\\"{x:1229,y:957,t:1527268491512};\\\", \\\"{x:1226,y:957,t:1527268491519};\\\", \\\"{x:1224,y:957,t:1527268491531};\\\", \\\"{x:1221,y:949,t:1527268491548};\\\", \\\"{x:1216,y:937,t:1527268491564};\\\", \\\"{x:1212,y:927,t:1527268491581};\\\", \\\"{x:1209,y:918,t:1527268491598};\\\", \\\"{x:1206,y:907,t:1527268491614};\\\", \\\"{x:1204,y:901,t:1527268491631};\\\", \\\"{x:1203,y:893,t:1527268491647};\\\", \\\"{x:1201,y:888,t:1527268491663};\\\", \\\"{x:1201,y:882,t:1527268491680};\\\", \\\"{x:1200,y:875,t:1527268491698};\\\", \\\"{x:1199,y:869,t:1527268491713};\\\", \\\"{x:1198,y:863,t:1527268491731};\\\", \\\"{x:1197,y:860,t:1527268491749};\\\", \\\"{x:1197,y:856,t:1527268491765};\\\", \\\"{x:1195,y:854,t:1527268491781};\\\", \\\"{x:1194,y:848,t:1527268491798};\\\", \\\"{x:1193,y:845,t:1527268491815};\\\", \\\"{x:1190,y:839,t:1527268491831};\\\", \\\"{x:1189,y:833,t:1527268491848};\\\", \\\"{x:1189,y:831,t:1527268491864};\\\", \\\"{x:1187,y:829,t:1527268491881};\\\", \\\"{x:1187,y:827,t:1527268491898};\\\", \\\"{x:1187,y:824,t:1527268491915};\\\", \\\"{x:1185,y:822,t:1527268491931};\\\", \\\"{x:1184,y:819,t:1527268491948};\\\", \\\"{x:1183,y:816,t:1527268491965};\\\", \\\"{x:1183,y:813,t:1527268491981};\\\", \\\"{x:1182,y:811,t:1527268491998};\\\", \\\"{x:1181,y:809,t:1527268492015};\\\", \\\"{x:1181,y:807,t:1527268492031};\\\", \\\"{x:1179,y:802,t:1527268492047};\\\", \\\"{x:1177,y:798,t:1527268492064};\\\", \\\"{x:1175,y:792,t:1527268492081};\\\", \\\"{x:1173,y:788,t:1527268492098};\\\", \\\"{x:1172,y:785,t:1527268492115};\\\", \\\"{x:1170,y:782,t:1527268492131};\\\", \\\"{x:1170,y:781,t:1527268492148};\\\", \\\"{x:1169,y:779,t:1527268492165};\\\", \\\"{x:1169,y:778,t:1527268492184};\\\", \\\"{x:1168,y:777,t:1527268492208};\\\", \\\"{x:1168,y:776,t:1527268492223};\\\", \\\"{x:1168,y:775,t:1527268492239};\\\", \\\"{x:1167,y:775,t:1527268492247};\\\", \\\"{x:1167,y:774,t:1527268492319};\\\", \\\"{x:1167,y:773,t:1527268492335};\\\", \\\"{x:1167,y:772,t:1527268492347};\\\", \\\"{x:1167,y:771,t:1527268492367};\\\", \\\"{x:1167,y:770,t:1527268492560};\\\", \\\"{x:1165,y:771,t:1527268492568};\\\", \\\"{x:1165,y:773,t:1527268492582};\\\", \\\"{x:1164,y:779,t:1527268492598};\\\", \\\"{x:1162,y:784,t:1527268492615};\\\", \\\"{x:1161,y:797,t:1527268492632};\\\", \\\"{x:1161,y:808,t:1527268492647};\\\", \\\"{x:1161,y:821,t:1527268492665};\\\", \\\"{x:1161,y:832,t:1527268492682};\\\", \\\"{x:1161,y:850,t:1527268492699};\\\", \\\"{x:1161,y:869,t:1527268492715};\\\", \\\"{x:1165,y:887,t:1527268492731};\\\", \\\"{x:1167,y:906,t:1527268492749};\\\", \\\"{x:1170,y:928,t:1527268492765};\\\", \\\"{x:1172,y:950,t:1527268492782};\\\", \\\"{x:1175,y:966,t:1527268492799};\\\", \\\"{x:1177,y:981,t:1527268492815};\\\", \\\"{x:1180,y:992,t:1527268492832};\\\", \\\"{x:1182,y:999,t:1527268492849};\\\", \\\"{x:1183,y:1003,t:1527268492865};\\\", \\\"{x:1184,y:1006,t:1527268492882};\\\", \\\"{x:1185,y:1007,t:1527268492899};\\\", \\\"{x:1185,y:1008,t:1527268493064};\\\", \\\"{x:1184,y:1007,t:1527268493072};\\\", \\\"{x:1184,y:1002,t:1527268493082};\\\", \\\"{x:1184,y:989,t:1527268493099};\\\", \\\"{x:1184,y:977,t:1527268493116};\\\", \\\"{x:1184,y:959,t:1527268493132};\\\", \\\"{x:1184,y:940,t:1527268493149};\\\", \\\"{x:1184,y:914,t:1527268493166};\\\", \\\"{x:1184,y:890,t:1527268493182};\\\", \\\"{x:1184,y:864,t:1527268493200};\\\", \\\"{x:1183,y:822,t:1527268493215};\\\", \\\"{x:1183,y:798,t:1527268493232};\\\", \\\"{x:1181,y:778,t:1527268493249};\\\", \\\"{x:1178,y:760,t:1527268493267};\\\", \\\"{x:1177,y:749,t:1527268493282};\\\", \\\"{x:1176,y:740,t:1527268493299};\\\", \\\"{x:1175,y:734,t:1527268493316};\\\", \\\"{x:1174,y:727,t:1527268493332};\\\", \\\"{x:1173,y:722,t:1527268493349};\\\", \\\"{x:1172,y:718,t:1527268493366};\\\", \\\"{x:1171,y:717,t:1527268493382};\\\", \\\"{x:1171,y:716,t:1527268493399};\\\", \\\"{x:1170,y:716,t:1527268493680};\\\", \\\"{x:1166,y:718,t:1527268493687};\\\", \\\"{x:1164,y:721,t:1527268493699};\\\", \\\"{x:1155,y:730,t:1527268493716};\\\", \\\"{x:1150,y:740,t:1527268493733};\\\", \\\"{x:1143,y:754,t:1527268493749};\\\", \\\"{x:1142,y:766,t:1527268493766};\\\", \\\"{x:1142,y:778,t:1527268493783};\\\", \\\"{x:1142,y:789,t:1527268493799};\\\", \\\"{x:1142,y:809,t:1527268493815};\\\", \\\"{x:1142,y:826,t:1527268493833};\\\", \\\"{x:1142,y:843,t:1527268493849};\\\", \\\"{x:1142,y:863,t:1527268493865};\\\", \\\"{x:1144,y:882,t:1527268493882};\\\", \\\"{x:1148,y:904,t:1527268493899};\\\", \\\"{x:1150,y:925,t:1527268493916};\\\", \\\"{x:1153,y:940,t:1527268493933};\\\", \\\"{x:1154,y:950,t:1527268493949};\\\", \\\"{x:1155,y:958,t:1527268493965};\\\", \\\"{x:1156,y:964,t:1527268493982};\\\", \\\"{x:1157,y:972,t:1527268493999};\\\", \\\"{x:1158,y:976,t:1527268494015};\\\", \\\"{x:1158,y:977,t:1527268494032};\\\", \\\"{x:1159,y:977,t:1527268494088};\\\", \\\"{x:1162,y:974,t:1527268494103};\\\", \\\"{x:1166,y:962,t:1527268494116};\\\", \\\"{x:1172,y:931,t:1527268494133};\\\", \\\"{x:1175,y:893,t:1527268494150};\\\", \\\"{x:1179,y:854,t:1527268494166};\\\", \\\"{x:1182,y:822,t:1527268494183};\\\", \\\"{x:1186,y:793,t:1527268494199};\\\", \\\"{x:1188,y:786,t:1527268494216};\\\", \\\"{x:1190,y:779,t:1527268494233};\\\", \\\"{x:1193,y:774,t:1527268494250};\\\", \\\"{x:1195,y:771,t:1527268494265};\\\", \\\"{x:1198,y:767,t:1527268494283};\\\", \\\"{x:1199,y:765,t:1527268494303};\\\", \\\"{x:1197,y:765,t:1527268494536};\\\", \\\"{x:1193,y:765,t:1527268494550};\\\", \\\"{x:1186,y:768,t:1527268494567};\\\", \\\"{x:1181,y:769,t:1527268494583};\\\", \\\"{x:1172,y:772,t:1527268494600};\\\", \\\"{x:1170,y:772,t:1527268494616};\\\", \\\"{x:1168,y:772,t:1527268494633};\\\", \\\"{x:1164,y:766,t:1527268494649};\\\", \\\"{x:1159,y:758,t:1527268494666};\\\", \\\"{x:1155,y:751,t:1527268494682};\\\", \\\"{x:1153,y:747,t:1527268494699};\\\", \\\"{x:1152,y:746,t:1527268494717};\\\", \\\"{x:1152,y:744,t:1527268494735};\\\", \\\"{x:1153,y:744,t:1527268494953};\\\", \\\"{x:1156,y:744,t:1527268494967};\\\", \\\"{x:1163,y:751,t:1527268494984};\\\", \\\"{x:1165,y:753,t:1527268495000};\\\", \\\"{x:1168,y:757,t:1527268495017};\\\", \\\"{x:1168,y:759,t:1527268495034};\\\", \\\"{x:1169,y:761,t:1527268495050};\\\", \\\"{x:1169,y:762,t:1527268495067};\\\", \\\"{x:1169,y:764,t:1527268495088};\\\", \\\"{x:1169,y:765,t:1527268495100};\\\", \\\"{x:1168,y:768,t:1527268495117};\\\", \\\"{x:1167,y:771,t:1527268495134};\\\", \\\"{x:1164,y:774,t:1527268495150};\\\", \\\"{x:1164,y:778,t:1527268495167};\\\", \\\"{x:1161,y:785,t:1527268495183};\\\", \\\"{x:1160,y:791,t:1527268495200};\\\", \\\"{x:1159,y:794,t:1527268495216};\\\", \\\"{x:1158,y:798,t:1527268495234};\\\", \\\"{x:1157,y:800,t:1527268495251};\\\", \\\"{x:1156,y:803,t:1527268495267};\\\", \\\"{x:1156,y:804,t:1527268495283};\\\", \\\"{x:1156,y:805,t:1527268495327};\\\", \\\"{x:1156,y:803,t:1527268495463};\\\", \\\"{x:1155,y:799,t:1527268495470};\\\", \\\"{x:1153,y:793,t:1527268495483};\\\", \\\"{x:1152,y:784,t:1527268495500};\\\", \\\"{x:1149,y:772,t:1527268495517};\\\", \\\"{x:1146,y:762,t:1527268495533};\\\", \\\"{x:1143,y:753,t:1527268495550};\\\", \\\"{x:1141,y:747,t:1527268495567};\\\", \\\"{x:1140,y:742,t:1527268495584};\\\", \\\"{x:1140,y:739,t:1527268495601};\\\", \\\"{x:1139,y:736,t:1527268495616};\\\", \\\"{x:1139,y:733,t:1527268495633};\\\", \\\"{x:1139,y:732,t:1527268495650};\\\", \\\"{x:1139,y:730,t:1527268495671};\\\", \\\"{x:1139,y:729,t:1527268495695};\\\", \\\"{x:1138,y:728,t:1527268495735};\\\", \\\"{x:1138,y:727,t:1527268495760};\\\", \\\"{x:1138,y:726,t:1527268495984};\\\", \\\"{x:1139,y:726,t:1527268496048};\\\", \\\"{x:1142,y:726,t:1527268496071};\\\", \\\"{x:1143,y:726,t:1527268496084};\\\", \\\"{x:1151,y:726,t:1527268496102};\\\", \\\"{x:1163,y:727,t:1527268496118};\\\", \\\"{x:1176,y:729,t:1527268496136};\\\", \\\"{x:1185,y:729,t:1527268496151};\\\", \\\"{x:1194,y:729,t:1527268496167};\\\", \\\"{x:1196,y:729,t:1527268496185};\\\", \\\"{x:1197,y:729,t:1527268496200};\\\", \\\"{x:1198,y:729,t:1527268496223};\\\", \\\"{x:1199,y:729,t:1527268496720};\\\", \\\"{x:1204,y:729,t:1527268496735};\\\", \\\"{x:1224,y:719,t:1527268496752};\\\", \\\"{x:1236,y:712,t:1527268496768};\\\", \\\"{x:1238,y:712,t:1527268496786};\\\", \\\"{x:1238,y:716,t:1527268497008};\\\", \\\"{x:1237,y:722,t:1527268497018};\\\", \\\"{x:1236,y:728,t:1527268497035};\\\", \\\"{x:1233,y:734,t:1527268497053};\\\", \\\"{x:1232,y:738,t:1527268497069};\\\", \\\"{x:1230,y:742,t:1527268497085};\\\", \\\"{x:1229,y:743,t:1527268497102};\\\", \\\"{x:1228,y:745,t:1527268497119};\\\", \\\"{x:1226,y:745,t:1527268497135};\\\", \\\"{x:1222,y:747,t:1527268497152};\\\", \\\"{x:1218,y:748,t:1527268497169};\\\", \\\"{x:1213,y:752,t:1527268497185};\\\", \\\"{x:1209,y:753,t:1527268497203};\\\", \\\"{x:1205,y:755,t:1527268497219};\\\", \\\"{x:1203,y:757,t:1527268497234};\\\", \\\"{x:1199,y:760,t:1527268497251};\\\", \\\"{x:1197,y:760,t:1527268497269};\\\", \\\"{x:1194,y:762,t:1527268497285};\\\", \\\"{x:1191,y:762,t:1527268497301};\\\", \\\"{x:1190,y:763,t:1527268497319};\\\", \\\"{x:1188,y:763,t:1527268497496};\\\", \\\"{x:1187,y:764,t:1527268497528};\\\", \\\"{x:1187,y:765,t:1527268497640};\\\", \\\"{x:1185,y:765,t:1527268497808};\\\", \\\"{x:1184,y:765,t:1527268497835};\\\", \\\"{x:1182,y:765,t:1527268497927};\\\", \\\"{x:1182,y:764,t:1527268499280};\\\", \\\"{x:1184,y:764,t:1527268499287};\\\", \\\"{x:1188,y:761,t:1527268499305};\\\", \\\"{x:1190,y:761,t:1527268499320};\\\", \\\"{x:1193,y:759,t:1527268499337};\\\", \\\"{x:1196,y:758,t:1527268499354};\\\", \\\"{x:1200,y:758,t:1527268499371};\\\", \\\"{x:1205,y:757,t:1527268499387};\\\", \\\"{x:1209,y:756,t:1527268499405};\\\", \\\"{x:1214,y:756,t:1527268499421};\\\", \\\"{x:1218,y:755,t:1527268499437};\\\", \\\"{x:1221,y:754,t:1527268499454};\\\", \\\"{x:1225,y:754,t:1527268499470};\\\", \\\"{x:1229,y:754,t:1527268499487};\\\", \\\"{x:1232,y:754,t:1527268499504};\\\", \\\"{x:1233,y:754,t:1527268499520};\\\", \\\"{x:1234,y:754,t:1527268499537};\\\", \\\"{x:1235,y:754,t:1527268499555};\\\", \\\"{x:1237,y:754,t:1527268499571};\\\", \\\"{x:1238,y:754,t:1527268499588};\\\", \\\"{x:1241,y:754,t:1527268499604};\\\", \\\"{x:1243,y:754,t:1527268499620};\\\", \\\"{x:1244,y:754,t:1527268499638};\\\", \\\"{x:1246,y:754,t:1527268499655};\\\", \\\"{x:1250,y:756,t:1527268499671};\\\", \\\"{x:1252,y:757,t:1527268499688};\\\", \\\"{x:1253,y:758,t:1527268499704};\\\", \\\"{x:1254,y:758,t:1527268499728};\\\", \\\"{x:1255,y:758,t:1527268499744};\\\", \\\"{x:1256,y:759,t:1527268499856};\\\", \\\"{x:1256,y:760,t:1527268499871};\\\", \\\"{x:1256,y:761,t:1527268499887};\\\", \\\"{x:1255,y:762,t:1527268499920};\\\", \\\"{x:1254,y:763,t:1527268499937};\\\", \\\"{x:1253,y:764,t:1527268499954};\\\", \\\"{x:1251,y:764,t:1527268500200};\\\", \\\"{x:1250,y:764,t:1527268500344};\\\", \\\"{x:1248,y:764,t:1527268500424};\\\", \\\"{x:1247,y:764,t:1527268500497};\\\", \\\"{x:1246,y:764,t:1527268500512};\\\", \\\"{x:1245,y:764,t:1527268500528};\\\", \\\"{x:1244,y:764,t:1527268500648};\\\", \\\"{x:1244,y:763,t:1527268500728};\\\", \\\"{x:1245,y:763,t:1527268500848};\\\", \\\"{x:1247,y:762,t:1527268500855};\\\", \\\"{x:1252,y:759,t:1527268500872};\\\", \\\"{x:1255,y:759,t:1527268500889};\\\", \\\"{x:1258,y:757,t:1527268500905};\\\", \\\"{x:1260,y:757,t:1527268500921};\\\", \\\"{x:1262,y:756,t:1527268500938};\\\", \\\"{x:1263,y:756,t:1527268500955};\\\", \\\"{x:1265,y:756,t:1527268500973};\\\", \\\"{x:1267,y:755,t:1527268500988};\\\", \\\"{x:1271,y:755,t:1527268501005};\\\", \\\"{x:1274,y:754,t:1527268501022};\\\", \\\"{x:1278,y:754,t:1527268501038};\\\", \\\"{x:1279,y:754,t:1527268501055};\\\", \\\"{x:1280,y:754,t:1527268501072};\\\", \\\"{x:1281,y:754,t:1527268501104};\\\", \\\"{x:1282,y:754,t:1527268501120};\\\", \\\"{x:1283,y:754,t:1527268501136};\\\", \\\"{x:1285,y:754,t:1527268501143};\\\", \\\"{x:1286,y:754,t:1527268501160};\\\", \\\"{x:1288,y:755,t:1527268501172};\\\", \\\"{x:1290,y:756,t:1527268501188};\\\", \\\"{x:1292,y:757,t:1527268501205};\\\", \\\"{x:1294,y:758,t:1527268501221};\\\", \\\"{x:1296,y:759,t:1527268501238};\\\", \\\"{x:1302,y:761,t:1527268501254};\\\", \\\"{x:1310,y:764,t:1527268501271};\\\", \\\"{x:1315,y:765,t:1527268501288};\\\", \\\"{x:1318,y:766,t:1527268501305};\\\", \\\"{x:1319,y:766,t:1527268501321};\\\", \\\"{x:1318,y:766,t:1527268501496};\\\", \\\"{x:1317,y:766,t:1527268501505};\\\", \\\"{x:1315,y:764,t:1527268501522};\\\", \\\"{x:1312,y:763,t:1527268501540};\\\", \\\"{x:1311,y:762,t:1527268501556};\\\", \\\"{x:1310,y:761,t:1527268501584};\\\", \\\"{x:1312,y:758,t:1527268502024};\\\", \\\"{x:1316,y:757,t:1527268502038};\\\", \\\"{x:1325,y:753,t:1527268502056};\\\", \\\"{x:1332,y:751,t:1527268502072};\\\", \\\"{x:1338,y:749,t:1527268502089};\\\", \\\"{x:1342,y:748,t:1527268502106};\\\", \\\"{x:1345,y:748,t:1527268502122};\\\", \\\"{x:1347,y:747,t:1527268502138};\\\", \\\"{x:1348,y:747,t:1527268502155};\\\", \\\"{x:1352,y:747,t:1527268502172};\\\", \\\"{x:1357,y:747,t:1527268502188};\\\", \\\"{x:1361,y:747,t:1527268502206};\\\", \\\"{x:1366,y:747,t:1527268502222};\\\", \\\"{x:1370,y:747,t:1527268502239};\\\", \\\"{x:1372,y:749,t:1527268502255};\\\", \\\"{x:1373,y:749,t:1527268502272};\\\", \\\"{x:1374,y:750,t:1527268502289};\\\", \\\"{x:1377,y:752,t:1527268502306};\\\", \\\"{x:1378,y:753,t:1527268502323};\\\", \\\"{x:1378,y:755,t:1527268502339};\\\", \\\"{x:1379,y:755,t:1527268502356};\\\", \\\"{x:1380,y:756,t:1527268502373};\\\", \\\"{x:1380,y:757,t:1527268502389};\\\", \\\"{x:1380,y:758,t:1527268502407};\\\", \\\"{x:1381,y:759,t:1527268502423};\\\", \\\"{x:1381,y:760,t:1527268502488};\\\", \\\"{x:1381,y:761,t:1527268502506};\\\", \\\"{x:1381,y:762,t:1527268502808};\\\", \\\"{x:1381,y:763,t:1527268502831};\\\", \\\"{x:1381,y:764,t:1527268502856};\\\", \\\"{x:1381,y:765,t:1527268502920};\\\", \\\"{x:1381,y:770,t:1527268504160};\\\", \\\"{x:1363,y:780,t:1527268504174};\\\", \\\"{x:1363,y:781,t:1527268504664};\\\", \\\"{x:1362,y:781,t:1527268504674};\\\", \\\"{x:1362,y:778,t:1527268504692};\\\", \\\"{x:1362,y:777,t:1527268504728};\\\", \\\"{x:1362,y:776,t:1527268504744};\\\", \\\"{x:1362,y:775,t:1527268504824};\\\", \\\"{x:1361,y:775,t:1527268504841};\\\", \\\"{x:1360,y:774,t:1527268504858};\\\", \\\"{x:1359,y:773,t:1527268504879};\\\", \\\"{x:1358,y:773,t:1527268504904};\\\", \\\"{x:1356,y:772,t:1527268504927};\\\", \\\"{x:1355,y:771,t:1527268504943};\\\", \\\"{x:1354,y:771,t:1527268504959};\\\", \\\"{x:1353,y:770,t:1527268504976};\\\", \\\"{x:1352,y:770,t:1527268504992};\\\", \\\"{x:1351,y:770,t:1527268505008};\\\", \\\"{x:1351,y:769,t:1527268505025};\\\", \\\"{x:1350,y:769,t:1527268505041};\\\", \\\"{x:1349,y:769,t:1527268505059};\\\", \\\"{x:1348,y:769,t:1527268505076};\\\", \\\"{x:1348,y:768,t:1527268505096};\\\", \\\"{x:1347,y:768,t:1527268505125};\\\", \\\"{x:1346,y:767,t:1527268505344};\\\", \\\"{x:1345,y:767,t:1527268505392};\\\", \\\"{x:1345,y:765,t:1527268505448};\\\", \\\"{x:1345,y:764,t:1527268505480};\\\", \\\"{x:1345,y:762,t:1527268505504};\\\", \\\"{x:1345,y:761,t:1527268505512};\\\", \\\"{x:1345,y:760,t:1527268505526};\\\", \\\"{x:1346,y:759,t:1527268505542};\\\", \\\"{x:1348,y:758,t:1527268505559};\\\", \\\"{x:1353,y:756,t:1527268505576};\\\", \\\"{x:1356,y:754,t:1527268505592};\\\", \\\"{x:1358,y:754,t:1527268505608};\\\", \\\"{x:1359,y:754,t:1527268505625};\\\", \\\"{x:1361,y:754,t:1527268505643};\\\", \\\"{x:1362,y:754,t:1527268505658};\\\", \\\"{x:1364,y:754,t:1527268505680};\\\", \\\"{x:1366,y:754,t:1527268505704};\\\", \\\"{x:1367,y:754,t:1527268505712};\\\", \\\"{x:1368,y:754,t:1527268505727};\\\", \\\"{x:1370,y:754,t:1527268505742};\\\", \\\"{x:1372,y:754,t:1527268505758};\\\", \\\"{x:1375,y:755,t:1527268505775};\\\", \\\"{x:1378,y:755,t:1527268505791};\\\", \\\"{x:1380,y:755,t:1527268505809};\\\", \\\"{x:1384,y:755,t:1527268505825};\\\", \\\"{x:1387,y:755,t:1527268505842};\\\", \\\"{x:1388,y:755,t:1527268505859};\\\", \\\"{x:1390,y:755,t:1527268505875};\\\", \\\"{x:1391,y:755,t:1527268505892};\\\", \\\"{x:1393,y:755,t:1527268506024};\\\", \\\"{x:1394,y:756,t:1527268506042};\\\", \\\"{x:1397,y:756,t:1527268506060};\\\", \\\"{x:1399,y:757,t:1527268506076};\\\", \\\"{x:1400,y:757,t:1527268506144};\\\", \\\"{x:1401,y:758,t:1527268506192};\\\", \\\"{x:1402,y:758,t:1527268506216};\\\", \\\"{x:1403,y:759,t:1527268506226};\\\", \\\"{x:1404,y:759,t:1527268506242};\\\", \\\"{x:1405,y:759,t:1527268506260};\\\", \\\"{x:1407,y:760,t:1527268506277};\\\", \\\"{x:1408,y:760,t:1527268506320};\\\", \\\"{x:1409,y:760,t:1527268506327};\\\", \\\"{x:1409,y:761,t:1527268506342};\\\", \\\"{x:1410,y:761,t:1527268506360};\\\", \\\"{x:1411,y:762,t:1527268506376};\\\", \\\"{x:1412,y:762,t:1527268506393};\\\", \\\"{x:1416,y:762,t:1527268506800};\\\", \\\"{x:1419,y:762,t:1527268506810};\\\", \\\"{x:1428,y:759,t:1527268506826};\\\", \\\"{x:1431,y:758,t:1527268506843};\\\", \\\"{x:1432,y:758,t:1527268506860};\\\", \\\"{x:1434,y:758,t:1527268506877};\\\", \\\"{x:1435,y:758,t:1527268506893};\\\", \\\"{x:1436,y:758,t:1527268506909};\\\", \\\"{x:1438,y:758,t:1527268506927};\\\", \\\"{x:1442,y:758,t:1527268506944};\\\", \\\"{x:1445,y:758,t:1527268506960};\\\", \\\"{x:1448,y:758,t:1527268506977};\\\", \\\"{x:1450,y:758,t:1527268506993};\\\", \\\"{x:1451,y:758,t:1527268507010};\\\", \\\"{x:1454,y:758,t:1527268507026};\\\", \\\"{x:1457,y:758,t:1527268507044};\\\", \\\"{x:1461,y:758,t:1527268507060};\\\", \\\"{x:1464,y:758,t:1527268507077};\\\", \\\"{x:1470,y:758,t:1527268507093};\\\", \\\"{x:1478,y:758,t:1527268507110};\\\", \\\"{x:1484,y:758,t:1527268507126};\\\", \\\"{x:1489,y:759,t:1527268507144};\\\", \\\"{x:1490,y:760,t:1527268507161};\\\", \\\"{x:1491,y:761,t:1527268507288};\\\", \\\"{x:1492,y:762,t:1527268507311};\\\", \\\"{x:1492,y:763,t:1527268507336};\\\", \\\"{x:1492,y:765,t:1527268507368};\\\", \\\"{x:1494,y:765,t:1527268507616};\\\", \\\"{x:1495,y:765,t:1527268507631};\\\", \\\"{x:1497,y:764,t:1527268507656};\\\", \\\"{x:1498,y:764,t:1527268507680};\\\", \\\"{x:1498,y:763,t:1527268507694};\\\", \\\"{x:1500,y:762,t:1527268507711};\\\", \\\"{x:1501,y:762,t:1527268507728};\\\", \\\"{x:1503,y:761,t:1527268507744};\\\", \\\"{x:1505,y:761,t:1527268507761};\\\", \\\"{x:1508,y:759,t:1527268507778};\\\", \\\"{x:1514,y:758,t:1527268507794};\\\", \\\"{x:1517,y:758,t:1527268507811};\\\", \\\"{x:1521,y:758,t:1527268507828};\\\", \\\"{x:1522,y:758,t:1527268507843};\\\", \\\"{x:1524,y:758,t:1527268507860};\\\", \\\"{x:1527,y:758,t:1527268507877};\\\", \\\"{x:1528,y:758,t:1527268507892};\\\", \\\"{x:1531,y:758,t:1527268507910};\\\", \\\"{x:1534,y:756,t:1527268507927};\\\", \\\"{x:1536,y:756,t:1527268507943};\\\", \\\"{x:1537,y:756,t:1527268507960};\\\", \\\"{x:1538,y:756,t:1527268507977};\\\", \\\"{x:1539,y:756,t:1527268507999};\\\", \\\"{x:1540,y:756,t:1527268508022};\\\", \\\"{x:1541,y:756,t:1527268508424};\\\", \\\"{x:1541,y:757,t:1527268508528};\\\", \\\"{x:1541,y:758,t:1527268508592};\\\", \\\"{x:1542,y:759,t:1527268508648};\\\", \\\"{x:1542,y:760,t:1527268508800};\\\", \\\"{x:1542,y:762,t:1527268511712};\\\", \\\"{x:1541,y:762,t:1527268511734};\\\", \\\"{x:1540,y:762,t:1527268511840};\\\", \\\"{x:1539,y:763,t:1527268511902};\\\", \\\"{x:1538,y:763,t:1527268511913};\\\", \\\"{x:1537,y:763,t:1527268511934};\\\", \\\"{x:1536,y:763,t:1527268511975};\\\", \\\"{x:1535,y:763,t:1527268511983};\\\", \\\"{x:1534,y:763,t:1527268511998};\\\", \\\"{x:1532,y:763,t:1527268512014};\\\", \\\"{x:1531,y:763,t:1527268512030};\\\", \\\"{x:1529,y:764,t:1527268512047};\\\", \\\"{x:1528,y:765,t:1527268512064};\\\", \\\"{x:1527,y:765,t:1527268512087};\\\", \\\"{x:1526,y:765,t:1527268512098};\\\", \\\"{x:1524,y:765,t:1527268512113};\\\", \\\"{x:1522,y:765,t:1527268512131};\\\", \\\"{x:1519,y:765,t:1527268512148};\\\", \\\"{x:1517,y:765,t:1527268512163};\\\", \\\"{x:1515,y:765,t:1527268512181};\\\", \\\"{x:1509,y:765,t:1527268512197};\\\", \\\"{x:1506,y:765,t:1527268512213};\\\", \\\"{x:1505,y:765,t:1527268512230};\\\", \\\"{x:1504,y:765,t:1527268512247};\\\", \\\"{x:1503,y:764,t:1527268512271};\\\", \\\"{x:1502,y:764,t:1527268512576};\\\", \\\"{x:1502,y:763,t:1527268512617};\\\", \\\"{x:1503,y:762,t:1527268512632};\\\", \\\"{x:1504,y:762,t:1527268512648};\\\", \\\"{x:1505,y:762,t:1527268512665};\\\", \\\"{x:1507,y:762,t:1527268512681};\\\", \\\"{x:1508,y:762,t:1527268512698};\\\", \\\"{x:1510,y:762,t:1527268512716};\\\", \\\"{x:1511,y:762,t:1527268512730};\\\", \\\"{x:1513,y:762,t:1527268512748};\\\", \\\"{x:1515,y:762,t:1527268512764};\\\", \\\"{x:1519,y:762,t:1527268512781};\\\", \\\"{x:1524,y:762,t:1527268512798};\\\", \\\"{x:1529,y:762,t:1527268512815};\\\", \\\"{x:1532,y:762,t:1527268512831};\\\", \\\"{x:1533,y:762,t:1527268512848};\\\", \\\"{x:1538,y:762,t:1527268512864};\\\", \\\"{x:1543,y:763,t:1527268512882};\\\", \\\"{x:1557,y:763,t:1527268512898};\\\", \\\"{x:1585,y:763,t:1527268512915};\\\", \\\"{x:1621,y:763,t:1527268512932};\\\", \\\"{x:1654,y:763,t:1527268512947};\\\", \\\"{x:1680,y:763,t:1527268512965};\\\", \\\"{x:1693,y:763,t:1527268512982};\\\", \\\"{x:1696,y:764,t:1527268512998};\\\", \\\"{x:1697,y:764,t:1527268513015};\\\", \\\"{x:1698,y:764,t:1527268513040};\\\", \\\"{x:1700,y:764,t:1527268513047};\\\", \\\"{x:1704,y:764,t:1527268513065};\\\", \\\"{x:1707,y:764,t:1527268513081};\\\", \\\"{x:1709,y:765,t:1527268513098};\\\", \\\"{x:1711,y:765,t:1527268513115};\\\", \\\"{x:1712,y:765,t:1527268513132};\\\", \\\"{x:1713,y:766,t:1527268513149};\\\", \\\"{x:1712,y:766,t:1527268514361};\\\", \\\"{x:1702,y:766,t:1527268514368};\\\", \\\"{x:1685,y:766,t:1527268514383};\\\", \\\"{x:1654,y:766,t:1527268514399};\\\", \\\"{x:1590,y:757,t:1527268514415};\\\", \\\"{x:1557,y:752,t:1527268514433};\\\", \\\"{x:1537,y:750,t:1527268514449};\\\", \\\"{x:1521,y:748,t:1527268514466};\\\", \\\"{x:1512,y:746,t:1527268514483};\\\", \\\"{x:1504,y:745,t:1527268514499};\\\", \\\"{x:1491,y:742,t:1527268514516};\\\", \\\"{x:1480,y:742,t:1527268514533};\\\", \\\"{x:1466,y:740,t:1527268514549};\\\", \\\"{x:1452,y:740,t:1527268514566};\\\", \\\"{x:1439,y:740,t:1527268514583};\\\", \\\"{x:1424,y:740,t:1527268514600};\\\", \\\"{x:1420,y:740,t:1527268514615};\\\", \\\"{x:1419,y:740,t:1527268514633};\\\", \\\"{x:1414,y:740,t:1527268514650};\\\", \\\"{x:1407,y:739,t:1527268514666};\\\", \\\"{x:1399,y:737,t:1527268514683};\\\", \\\"{x:1389,y:731,t:1527268514700};\\\", \\\"{x:1372,y:722,t:1527268514716};\\\", \\\"{x:1354,y:714,t:1527268514733};\\\", \\\"{x:1338,y:705,t:1527268514750};\\\", \\\"{x:1327,y:700,t:1527268514766};\\\", \\\"{x:1319,y:696,t:1527268514783};\\\", \\\"{x:1318,y:695,t:1527268514801};\\\", \\\"{x:1320,y:695,t:1527268515036};\\\", \\\"{x:1322,y:695,t:1527268515054};\\\", \\\"{x:1327,y:695,t:1527268515069};\\\", \\\"{x:1330,y:696,t:1527268515087};\\\", \\\"{x:1332,y:696,t:1527268515103};\\\", \\\"{x:1333,y:696,t:1527268515120};\\\", \\\"{x:1335,y:696,t:1527268515136};\\\", \\\"{x:1337,y:696,t:1527268515153};\\\", \\\"{x:1338,y:696,t:1527268515171};\\\", \\\"{x:1340,y:696,t:1527268515211};\\\", \\\"{x:1341,y:696,t:1527268515251};\\\", \\\"{x:1342,y:695,t:1527268515267};\\\", \\\"{x:1343,y:695,t:1527268515287};\\\", \\\"{x:1344,y:695,t:1527268515303};\\\", \\\"{x:1346,y:694,t:1527268515320};\\\", \\\"{x:1347,y:693,t:1527268515336};\\\", \\\"{x:1349,y:692,t:1527268515353};\\\", \\\"{x:1353,y:689,t:1527268515372};\\\", \\\"{x:1354,y:689,t:1527268515394};\\\", \\\"{x:1354,y:688,t:1527268515410};\\\", \\\"{x:1356,y:688,t:1527268515435};\\\", \\\"{x:1357,y:687,t:1527268515500};\\\", \\\"{x:1355,y:687,t:1527268515660};\\\", \\\"{x:1354,y:687,t:1527268515683};\\\", \\\"{x:1354,y:688,t:1527268515707};\\\", \\\"{x:1353,y:688,t:1527268515747};\\\", \\\"{x:1353,y:689,t:1527268515811};\\\", \\\"{x:1353,y:690,t:1527268516195};\\\", \\\"{x:1354,y:690,t:1527268516243};\\\", \\\"{x:1356,y:690,t:1527268516254};\\\", \\\"{x:1367,y:690,t:1527268516270};\\\", \\\"{x:1389,y:691,t:1527268516287};\\\", \\\"{x:1416,y:691,t:1527268516304};\\\", \\\"{x:1443,y:691,t:1527268516321};\\\", \\\"{x:1468,y:691,t:1527268516337};\\\", \\\"{x:1489,y:691,t:1527268516354};\\\", \\\"{x:1506,y:691,t:1527268516371};\\\", \\\"{x:1509,y:691,t:1527268516388};\\\", \\\"{x:1513,y:691,t:1527268516405};\\\", \\\"{x:1518,y:691,t:1527268516422};\\\", \\\"{x:1524,y:689,t:1527268516437};\\\", \\\"{x:1533,y:688,t:1527268516454};\\\", \\\"{x:1542,y:686,t:1527268516472};\\\", \\\"{x:1546,y:685,t:1527268516488};\\\", \\\"{x:1549,y:685,t:1527268516504};\\\", \\\"{x:1551,y:684,t:1527268516521};\\\", \\\"{x:1552,y:684,t:1527268516537};\\\", \\\"{x:1554,y:684,t:1527268516555};\\\", \\\"{x:1559,y:684,t:1527268516571};\\\", \\\"{x:1564,y:684,t:1527268516587};\\\", \\\"{x:1568,y:684,t:1527268516604};\\\", \\\"{x:1573,y:684,t:1527268516621};\\\", \\\"{x:1574,y:684,t:1527268516637};\\\", \\\"{x:1577,y:684,t:1527268516654};\\\", \\\"{x:1579,y:684,t:1527268516672};\\\", \\\"{x:1581,y:684,t:1527268516687};\\\", \\\"{x:1583,y:684,t:1527268516705};\\\", \\\"{x:1584,y:684,t:1527268516721};\\\", \\\"{x:1586,y:684,t:1527268516737};\\\", \\\"{x:1590,y:684,t:1527268516755};\\\", \\\"{x:1592,y:685,t:1527268516771};\\\", \\\"{x:1593,y:685,t:1527268516788};\\\", \\\"{x:1594,y:685,t:1527268516805};\\\", \\\"{x:1595,y:685,t:1527268516843};\\\", \\\"{x:1596,y:686,t:1527268516855};\\\", \\\"{x:1597,y:686,t:1527268516883};\\\", \\\"{x:1598,y:686,t:1527268516923};\\\", \\\"{x:1599,y:686,t:1527268516938};\\\", \\\"{x:1601,y:688,t:1527268516954};\\\", \\\"{x:1602,y:688,t:1527268516979};\\\", \\\"{x:1603,y:689,t:1527268517010};\\\", \\\"{x:1604,y:690,t:1527268517091};\\\", \\\"{x:1605,y:690,t:1527268517267};\\\", \\\"{x:1606,y:690,t:1527268517323};\\\", \\\"{x:1607,y:690,t:1527268517339};\\\", \\\"{x:1608,y:691,t:1527268517355};\\\", \\\"{x:1609,y:691,t:1527268517371};\\\", \\\"{x:1611,y:691,t:1527268517403};\\\", \\\"{x:1611,y:692,t:1527268517411};\\\", \\\"{x:1612,y:693,t:1527268517437};\\\", \\\"{x:1613,y:695,t:1527268517454};\\\", \\\"{x:1614,y:699,t:1527268517471};\\\", \\\"{x:1615,y:702,t:1527268517488};\\\", \\\"{x:1616,y:706,t:1527268517505};\\\", \\\"{x:1617,y:709,t:1527268517520};\\\", \\\"{x:1618,y:713,t:1527268517538};\\\", \\\"{x:1618,y:715,t:1527268517555};\\\", \\\"{x:1618,y:716,t:1527268517578};\\\", \\\"{x:1618,y:717,t:1527268517602};\\\", \\\"{x:1618,y:718,t:1527268517610};\\\", \\\"{x:1618,y:720,t:1527268517634};\\\", \\\"{x:1618,y:722,t:1527268517643};\\\", \\\"{x:1618,y:724,t:1527268517659};\\\", \\\"{x:1618,y:726,t:1527268517672};\\\", \\\"{x:1618,y:728,t:1527268517688};\\\", \\\"{x:1617,y:732,t:1527268517705};\\\", \\\"{x:1616,y:738,t:1527268517722};\\\", \\\"{x:1615,y:743,t:1527268517738};\\\", \\\"{x:1613,y:749,t:1527268517755};\\\", \\\"{x:1612,y:754,t:1527268517773};\\\", \\\"{x:1611,y:761,t:1527268517789};\\\", \\\"{x:1611,y:769,t:1527268517805};\\\", \\\"{x:1610,y:775,t:1527268517822};\\\", \\\"{x:1610,y:780,t:1527268517839};\\\", \\\"{x:1610,y:784,t:1527268517855};\\\", \\\"{x:1610,y:790,t:1527268517872};\\\", \\\"{x:1609,y:794,t:1527268517889};\\\", \\\"{x:1607,y:803,t:1527268517905};\\\", \\\"{x:1603,y:819,t:1527268517922};\\\", \\\"{x:1601,y:826,t:1527268517939};\\\", \\\"{x:1601,y:831,t:1527268517955};\\\", \\\"{x:1598,y:837,t:1527268517972};\\\", \\\"{x:1598,y:843,t:1527268517989};\\\", \\\"{x:1597,y:849,t:1527268518005};\\\", \\\"{x:1595,y:856,t:1527268518022};\\\", \\\"{x:1594,y:864,t:1527268518039};\\\", \\\"{x:1592,y:875,t:1527268518055};\\\", \\\"{x:1590,y:887,t:1527268518073};\\\", \\\"{x:1590,y:898,t:1527268518088};\\\", \\\"{x:1587,y:914,t:1527268518105};\\\", \\\"{x:1585,y:929,t:1527268518122};\\\", \\\"{x:1585,y:947,t:1527268518139};\\\", \\\"{x:1585,y:954,t:1527268518155};\\\", \\\"{x:1585,y:960,t:1527268518172};\\\", \\\"{x:1585,y:963,t:1527268518190};\\\", \\\"{x:1585,y:966,t:1527268518207};\\\", \\\"{x:1585,y:967,t:1527268518222};\\\", \\\"{x:1585,y:970,t:1527268518238};\\\", \\\"{x:1585,y:974,t:1527268518255};\\\", \\\"{x:1587,y:982,t:1527268518272};\\\", \\\"{x:1587,y:995,t:1527268518288};\\\", \\\"{x:1587,y:1000,t:1527268518305};\\\", \\\"{x:1586,y:1004,t:1527268518322};\\\", \\\"{x:1585,y:1005,t:1527268518339};\\\", \\\"{x:1585,y:1004,t:1527268518403};\\\", \\\"{x:1585,y:997,t:1527268518411};\\\", \\\"{x:1585,y:982,t:1527268518422};\\\", \\\"{x:1585,y:936,t:1527268518440};\\\", \\\"{x:1585,y:889,t:1527268518456};\\\", \\\"{x:1585,y:854,t:1527268518472};\\\", \\\"{x:1587,y:819,t:1527268518489};\\\", \\\"{x:1590,y:790,t:1527268518505};\\\", \\\"{x:1598,y:747,t:1527268518522};\\\", \\\"{x:1600,y:730,t:1527268518539};\\\", \\\"{x:1600,y:719,t:1527268518556};\\\", \\\"{x:1600,y:710,t:1527268518573};\\\", \\\"{x:1600,y:706,t:1527268518589};\\\", \\\"{x:1600,y:704,t:1527268518606};\\\", \\\"{x:1600,y:702,t:1527268518622};\\\", \\\"{x:1600,y:701,t:1527268518640};\\\", \\\"{x:1600,y:700,t:1527268518675};\\\", \\\"{x:1600,y:699,t:1527268518690};\\\", \\\"{x:1602,y:695,t:1527268518706};\\\", \\\"{x:1603,y:694,t:1527268518723};\\\", \\\"{x:1605,y:692,t:1527268518739};\\\", \\\"{x:1606,y:691,t:1527268518757};\\\", \\\"{x:1608,y:691,t:1527268518772};\\\", \\\"{x:1609,y:691,t:1527268518790};\\\", \\\"{x:1611,y:691,t:1527268518819};\\\", \\\"{x:1612,y:691,t:1527268518826};\\\", \\\"{x:1614,y:691,t:1527268518842};\\\", \\\"{x:1615,y:691,t:1527268518856};\\\", \\\"{x:1618,y:691,t:1527268518872};\\\", \\\"{x:1621,y:692,t:1527268518889};\\\", \\\"{x:1628,y:692,t:1527268518906};\\\", \\\"{x:1638,y:692,t:1527268518922};\\\", \\\"{x:1657,y:692,t:1527268518938};\\\", \\\"{x:1681,y:692,t:1527268518956};\\\", \\\"{x:1704,y:692,t:1527268518972};\\\", \\\"{x:1725,y:692,t:1527268518988};\\\", \\\"{x:1745,y:692,t:1527268519006};\\\", \\\"{x:1762,y:692,t:1527268519023};\\\", \\\"{x:1773,y:689,t:1527268519038};\\\", \\\"{x:1783,y:685,t:1527268519055};\\\", \\\"{x:1791,y:680,t:1527268519073};\\\", \\\"{x:1802,y:675,t:1527268519089};\\\", \\\"{x:1816,y:667,t:1527268519105};\\\", \\\"{x:1825,y:663,t:1527268519122};\\\", \\\"{x:1831,y:660,t:1527268519139};\\\", \\\"{x:1841,y:657,t:1527268519156};\\\", \\\"{x:1852,y:654,t:1527268519173};\\\", \\\"{x:1866,y:654,t:1527268519189};\\\", \\\"{x:1879,y:654,t:1527268519206};\\\", \\\"{x:1890,y:654,t:1527268519223};\\\", \\\"{x:1903,y:654,t:1527268519240};\\\", \\\"{x:1914,y:655,t:1527268519256};\\\", \\\"{x:1919,y:657,t:1527268519273};\\\", \\\"{x:1919,y:658,t:1527268519289};\\\", \\\"{x:1919,y:659,t:1527268519306};\\\", \\\"{x:1919,y:663,t:1527268519323};\\\", \\\"{x:1919,y:666,t:1527268519339};\\\", \\\"{x:1919,y:676,t:1527268519357};\\\", \\\"{x:1919,y:688,t:1527268519373};\\\", \\\"{x:1919,y:699,t:1527268519390};\\\", \\\"{x:1919,y:714,t:1527268519408};\\\", \\\"{x:1919,y:727,t:1527268519424};\\\", \\\"{x:1919,y:740,t:1527268519440};\\\", \\\"{x:1919,y:748,t:1527268519456};\\\", \\\"{x:1919,y:752,t:1527268519473};\\\", \\\"{x:1919,y:756,t:1527268519490};\\\", \\\"{x:1919,y:758,t:1527268519506};\\\", \\\"{x:1912,y:753,t:1527268519675};\\\", \\\"{x:1883,y:736,t:1527268519691};\\\", \\\"{x:1856,y:721,t:1527268519707};\\\", \\\"{x:1836,y:710,t:1527268519723};\\\", \\\"{x:1825,y:702,t:1527268519740};\\\", \\\"{x:1819,y:697,t:1527268519757};\\\", \\\"{x:1817,y:695,t:1527268519774};\\\", \\\"{x:1816,y:695,t:1527268519979};\\\", \\\"{x:1815,y:695,t:1527268520003};\\\", \\\"{x:1812,y:694,t:1527268520020};\\\", \\\"{x:1808,y:694,t:1527268520026};\\\", \\\"{x:1805,y:693,t:1527268520040};\\\", \\\"{x:1791,y:692,t:1527268520058};\\\", \\\"{x:1769,y:690,t:1527268520075};\\\", \\\"{x:1760,y:690,t:1527268520090};\\\", \\\"{x:1737,y:690,t:1527268520107};\\\", \\\"{x:1726,y:690,t:1527268520125};\\\", \\\"{x:1719,y:690,t:1527268520141};\\\", \\\"{x:1713,y:690,t:1527268520158};\\\", \\\"{x:1711,y:690,t:1527268520174};\\\", \\\"{x:1709,y:690,t:1527268520191};\\\", \\\"{x:1706,y:690,t:1527268520207};\\\", \\\"{x:1703,y:689,t:1527268520224};\\\", \\\"{x:1699,y:689,t:1527268520240};\\\", \\\"{x:1693,y:688,t:1527268520257};\\\", \\\"{x:1688,y:687,t:1527268520275};\\\", \\\"{x:1679,y:686,t:1527268520290};\\\", \\\"{x:1665,y:686,t:1527268520307};\\\", \\\"{x:1652,y:686,t:1527268520324};\\\", \\\"{x:1632,y:686,t:1527268520342};\\\", \\\"{x:1613,y:686,t:1527268520358};\\\", \\\"{x:1598,y:685,t:1527268520375};\\\", \\\"{x:1588,y:684,t:1527268520392};\\\", \\\"{x:1582,y:682,t:1527268520407};\\\", \\\"{x:1578,y:681,t:1527268520425};\\\", \\\"{x:1576,y:681,t:1527268520441};\\\", \\\"{x:1574,y:680,t:1527268520457};\\\", \\\"{x:1563,y:675,t:1527268520475};\\\", \\\"{x:1553,y:671,t:1527268520491};\\\", \\\"{x:1537,y:668,t:1527268520507};\\\", \\\"{x:1515,y:666,t:1527268520525};\\\", \\\"{x:1492,y:661,t:1527268520542};\\\", \\\"{x:1464,y:659,t:1527268520557};\\\", \\\"{x:1449,y:657,t:1527268520575};\\\", \\\"{x:1436,y:655,t:1527268520592};\\\", \\\"{x:1431,y:654,t:1527268520608};\\\", \\\"{x:1429,y:653,t:1527268520625};\\\", \\\"{x:1428,y:653,t:1527268520643};\\\", \\\"{x:1428,y:652,t:1527268520683};\\\", \\\"{x:1427,y:652,t:1527268520707};\\\", \\\"{x:1427,y:651,t:1527268520725};\\\", \\\"{x:1427,y:650,t:1527268520747};\\\", \\\"{x:1427,y:649,t:1527268520763};\\\", \\\"{x:1427,y:648,t:1527268520774};\\\", \\\"{x:1428,y:648,t:1527268520791};\\\", \\\"{x:1428,y:647,t:1527268520808};\\\", \\\"{x:1430,y:647,t:1527268520824};\\\", \\\"{x:1435,y:644,t:1527268520841};\\\", \\\"{x:1443,y:639,t:1527268520858};\\\", \\\"{x:1447,y:637,t:1527268520875};\\\", \\\"{x:1451,y:635,t:1527268520891};\\\", \\\"{x:1455,y:633,t:1527268520909};\\\", \\\"{x:1458,y:631,t:1527268520925};\\\", \\\"{x:1462,y:628,t:1527268520941};\\\", \\\"{x:1468,y:625,t:1527268520959};\\\", \\\"{x:1471,y:624,t:1527268520975};\\\", \\\"{x:1476,y:622,t:1527268520992};\\\", \\\"{x:1485,y:619,t:1527268521008};\\\", \\\"{x:1496,y:616,t:1527268521025};\\\", \\\"{x:1516,y:615,t:1527268521042};\\\", \\\"{x:1563,y:615,t:1527268521059};\\\", \\\"{x:1602,y:615,t:1527268521074};\\\", \\\"{x:1649,y:615,t:1527268521092};\\\", \\\"{x:1705,y:615,t:1527268521108};\\\", \\\"{x:1764,y:615,t:1527268521124};\\\", \\\"{x:1817,y:615,t:1527268521141};\\\", \\\"{x:1853,y:615,t:1527268521159};\\\", \\\"{x:1880,y:615,t:1527268521175};\\\", \\\"{x:1900,y:615,t:1527268521191};\\\", \\\"{x:1912,y:615,t:1527268521208};\\\", \\\"{x:1919,y:614,t:1527268521225};\\\", \\\"{x:1918,y:614,t:1527268521402};\\\", \\\"{x:1912,y:614,t:1527268521409};\\\", \\\"{x:1901,y:612,t:1527268521425};\\\", \\\"{x:1864,y:607,t:1527268521442};\\\", \\\"{x:1825,y:602,t:1527268521458};\\\", \\\"{x:1772,y:594,t:1527268521476};\\\", \\\"{x:1722,y:588,t:1527268521491};\\\", \\\"{x:1675,y:582,t:1527268521508};\\\", \\\"{x:1638,y:577,t:1527268521525};\\\", \\\"{x:1607,y:576,t:1527268521541};\\\", \\\"{x:1583,y:576,t:1527268521558};\\\", \\\"{x:1556,y:576,t:1527268521575};\\\", \\\"{x:1530,y:576,t:1527268521591};\\\", \\\"{x:1508,y:576,t:1527268521608};\\\", \\\"{x:1488,y:576,t:1527268521626};\\\", \\\"{x:1464,y:576,t:1527268521643};\\\", \\\"{x:1451,y:576,t:1527268521658};\\\", \\\"{x:1443,y:576,t:1527268521675};\\\", \\\"{x:1436,y:576,t:1527268521693};\\\", \\\"{x:1430,y:578,t:1527268521709};\\\", \\\"{x:1424,y:580,t:1527268521726};\\\", \\\"{x:1420,y:581,t:1527268521742};\\\", \\\"{x:1414,y:584,t:1527268521758};\\\", \\\"{x:1402,y:589,t:1527268521776};\\\", \\\"{x:1391,y:591,t:1527268521792};\\\", \\\"{x:1376,y:596,t:1527268521808};\\\", \\\"{x:1359,y:599,t:1527268521825};\\\", \\\"{x:1322,y:602,t:1527268521842};\\\", \\\"{x:1297,y:602,t:1527268521858};\\\", \\\"{x:1269,y:602,t:1527268521875};\\\", \\\"{x:1246,y:602,t:1527268521893};\\\", \\\"{x:1231,y:602,t:1527268521908};\\\", \\\"{x:1219,y:602,t:1527268521926};\\\", \\\"{x:1213,y:601,t:1527268521943};\\\", \\\"{x:1211,y:601,t:1527268521959};\\\", \\\"{x:1210,y:601,t:1527268521975};\\\", \\\"{x:1209,y:601,t:1527268522027};\\\", \\\"{x:1208,y:600,t:1527268522043};\\\", \\\"{x:1208,y:599,t:1527268522763};\\\", \\\"{x:1211,y:597,t:1527268522777};\\\", \\\"{x:1219,y:593,t:1527268522792};\\\", \\\"{x:1228,y:590,t:1527268522810};\\\", \\\"{x:1238,y:585,t:1527268522827};\\\", \\\"{x:1243,y:582,t:1527268522843};\\\", \\\"{x:1245,y:581,t:1527268522859};\\\", \\\"{x:1246,y:581,t:1527268522877};\\\", \\\"{x:1246,y:580,t:1527268522893};\\\", \\\"{x:1246,y:579,t:1527268522910};\\\", \\\"{x:1247,y:577,t:1527268522927};\\\", \\\"{x:1249,y:574,t:1527268522943};\\\", \\\"{x:1251,y:573,t:1527268522960};\\\", \\\"{x:1252,y:572,t:1527268522977};\\\", \\\"{x:1253,y:571,t:1527268522992};\\\", \\\"{x:1254,y:570,t:1527268523009};\\\", \\\"{x:1256,y:569,t:1527268523034};\\\", \\\"{x:1257,y:568,t:1527268523043};\\\", \\\"{x:1258,y:567,t:1527268523059};\\\", \\\"{x:1262,y:566,t:1527268523075};\\\", \\\"{x:1265,y:563,t:1527268523093};\\\", \\\"{x:1270,y:559,t:1527268523109};\\\", \\\"{x:1273,y:558,t:1527268523125};\\\", \\\"{x:1281,y:554,t:1527268523143};\\\", \\\"{x:1294,y:546,t:1527268523159};\\\", \\\"{x:1310,y:540,t:1527268523176};\\\", \\\"{x:1326,y:536,t:1527268523193};\\\", \\\"{x:1347,y:532,t:1527268523208};\\\", \\\"{x:1366,y:529,t:1527268523226};\\\", \\\"{x:1373,y:529,t:1527268523243};\\\", \\\"{x:1377,y:529,t:1527268523259};\\\", \\\"{x:1382,y:529,t:1527268523276};\\\", \\\"{x:1394,y:528,t:1527268523293};\\\", \\\"{x:1409,y:526,t:1527268523309};\\\", \\\"{x:1426,y:526,t:1527268523326};\\\", \\\"{x:1443,y:524,t:1527268523343};\\\", \\\"{x:1457,y:524,t:1527268523359};\\\", \\\"{x:1465,y:523,t:1527268523376};\\\", \\\"{x:1470,y:523,t:1527268523393};\\\", \\\"{x:1475,y:523,t:1527268523409};\\\", \\\"{x:1483,y:523,t:1527268523426};\\\", \\\"{x:1490,y:523,t:1527268523443};\\\", \\\"{x:1495,y:523,t:1527268523459};\\\", \\\"{x:1499,y:523,t:1527268523476};\\\", \\\"{x:1501,y:523,t:1527268523494};\\\", \\\"{x:1503,y:523,t:1527268523509};\\\", \\\"{x:1504,y:524,t:1527268523635};\\\", \\\"{x:1502,y:526,t:1527268523644};\\\", \\\"{x:1492,y:530,t:1527268523661};\\\", \\\"{x:1477,y:534,t:1527268523677};\\\", \\\"{x:1459,y:536,t:1527268523693};\\\", \\\"{x:1440,y:540,t:1527268523711};\\\", \\\"{x:1429,y:541,t:1527268523727};\\\", \\\"{x:1419,y:543,t:1527268523743};\\\", \\\"{x:1415,y:545,t:1527268523760};\\\", \\\"{x:1413,y:546,t:1527268523776};\\\", \\\"{x:1409,y:548,t:1527268523794};\\\", \\\"{x:1406,y:549,t:1527268523810};\\\", \\\"{x:1403,y:552,t:1527268523827};\\\", \\\"{x:1400,y:554,t:1527268523843};\\\", \\\"{x:1396,y:556,t:1527268523861};\\\", \\\"{x:1392,y:560,t:1527268523877};\\\", \\\"{x:1386,y:564,t:1527268523894};\\\", \\\"{x:1376,y:570,t:1527268523911};\\\", \\\"{x:1364,y:576,t:1527268523927};\\\", \\\"{x:1354,y:579,t:1527268523944};\\\", \\\"{x:1344,y:582,t:1527268523961};\\\", \\\"{x:1335,y:585,t:1527268523976};\\\", \\\"{x:1331,y:586,t:1527268523993};\\\", \\\"{x:1329,y:586,t:1527268524011};\\\", \\\"{x:1328,y:587,t:1527268524122};\\\", \\\"{x:1326,y:587,t:1527268524138};\\\", \\\"{x:1325,y:587,t:1527268524154};\\\", \\\"{x:1324,y:587,t:1527268524170};\\\", \\\"{x:1323,y:587,t:1527268524186};\\\", \\\"{x:1322,y:587,t:1527268524210};\\\", \\\"{x:1321,y:587,t:1527268524267};\\\", \\\"{x:1320,y:587,t:1527268524278};\\\", \\\"{x:1319,y:587,t:1527268524294};\\\", \\\"{x:1317,y:586,t:1527268524311};\\\", \\\"{x:1316,y:584,t:1527268524328};\\\", \\\"{x:1315,y:583,t:1527268524343};\\\", \\\"{x:1315,y:582,t:1527268524371};\\\", \\\"{x:1315,y:581,t:1527268524411};\\\", \\\"{x:1314,y:580,t:1527268524435};\\\", \\\"{x:1313,y:579,t:1527268524458};\\\", \\\"{x:1312,y:578,t:1527268524475};\\\", \\\"{x:1312,y:577,t:1527268524483};\\\", \\\"{x:1309,y:576,t:1527268524495};\\\", \\\"{x:1304,y:575,t:1527268524511};\\\", \\\"{x:1298,y:573,t:1527268524528};\\\", \\\"{x:1294,y:572,t:1527268524544};\\\", \\\"{x:1291,y:571,t:1527268524561};\\\", \\\"{x:1288,y:569,t:1527268524577};\\\", \\\"{x:1286,y:568,t:1527268524595};\\\", \\\"{x:1284,y:567,t:1527268524611};\\\", \\\"{x:1284,y:566,t:1527268524731};\\\", \\\"{x:1284,y:565,t:1527268524763};\\\", \\\"{x:1284,y:564,t:1527268524778};\\\", \\\"{x:1284,y:563,t:1527268524795};\\\", \\\"{x:1285,y:563,t:1527268525035};\\\", \\\"{x:1286,y:563,t:1527268525045};\\\", \\\"{x:1287,y:563,t:1527268525066};\\\", \\\"{x:1289,y:563,t:1527268525078};\\\", \\\"{x:1292,y:563,t:1527268525094};\\\", \\\"{x:1296,y:563,t:1527268525111};\\\", \\\"{x:1304,y:563,t:1527268525128};\\\", \\\"{x:1309,y:563,t:1527268525145};\\\", \\\"{x:1312,y:564,t:1527268525162};\\\", \\\"{x:1314,y:564,t:1527268525178};\\\", \\\"{x:1316,y:564,t:1527268525194};\\\", \\\"{x:1317,y:564,t:1527268525226};\\\", \\\"{x:1318,y:564,t:1527268525245};\\\", \\\"{x:1319,y:564,t:1527268525261};\\\", \\\"{x:1321,y:564,t:1527268525278};\\\", \\\"{x:1324,y:564,t:1527268525294};\\\", \\\"{x:1329,y:564,t:1527268525312};\\\", \\\"{x:1332,y:564,t:1527268525328};\\\", \\\"{x:1335,y:564,t:1527268525345};\\\", \\\"{x:1339,y:564,t:1527268525362};\\\", \\\"{x:1342,y:564,t:1527268525378};\\\", \\\"{x:1349,y:564,t:1527268525395};\\\", \\\"{x:1353,y:564,t:1527268525412};\\\", \\\"{x:1358,y:564,t:1527268525428};\\\", \\\"{x:1361,y:564,t:1527268525445};\\\", \\\"{x:1366,y:564,t:1527268525462};\\\", \\\"{x:1372,y:563,t:1527268525478};\\\", \\\"{x:1376,y:563,t:1527268525495};\\\", \\\"{x:1382,y:563,t:1527268525511};\\\", \\\"{x:1385,y:563,t:1527268525529};\\\", \\\"{x:1387,y:563,t:1527268525545};\\\", \\\"{x:1388,y:563,t:1527268525562};\\\", \\\"{x:1390,y:563,t:1527268525579};\\\", \\\"{x:1391,y:563,t:1527268525594};\\\", \\\"{x:1392,y:562,t:1527268525612};\\\", \\\"{x:1394,y:562,t:1527268525629};\\\", \\\"{x:1396,y:561,t:1527268525645};\\\", \\\"{x:1398,y:561,t:1527268525662};\\\", \\\"{x:1399,y:561,t:1527268525678};\\\", \\\"{x:1401,y:561,t:1527268525698};\\\", \\\"{x:1403,y:561,t:1527268525711};\\\", \\\"{x:1405,y:561,t:1527268525729};\\\", \\\"{x:1408,y:561,t:1527268525744};\\\", \\\"{x:1410,y:561,t:1527268525761};\\\", \\\"{x:1412,y:561,t:1527268525777};\\\", \\\"{x:1413,y:561,t:1527268525809};\\\", \\\"{x:1414,y:561,t:1527268525818};\\\", \\\"{x:1415,y:561,t:1527268525827};\\\", \\\"{x:1416,y:561,t:1527268525874};\\\", \\\"{x:1417,y:561,t:1527268525898};\\\", \\\"{x:1418,y:561,t:1527268525930};\\\", \\\"{x:1419,y:561,t:1527268525994};\\\", \\\"{x:1420,y:561,t:1527268526035};\\\", \\\"{x:1421,y:561,t:1527268526067};\\\", \\\"{x:1423,y:561,t:1527268526099};\\\", \\\"{x:1424,y:561,t:1527268526122};\\\", \\\"{x:1425,y:561,t:1527268526218};\\\", \\\"{x:1426,y:561,t:1527268526723};\\\", \\\"{x:1426,y:562,t:1527268526731};\\\", \\\"{x:1424,y:562,t:1527268526931};\\\", \\\"{x:1424,y:563,t:1527268527003};\\\", \\\"{x:1423,y:563,t:1527268527195};\\\", \\\"{x:1423,y:564,t:1527268527219};\\\", \\\"{x:1421,y:564,t:1527268527307};\\\", \\\"{x:1420,y:564,t:1527268527708};\\\", \\\"{x:1418,y:564,t:1527268529227};\\\", \\\"{x:1417,y:563,t:1527268529266};\\\", \\\"{x:1415,y:563,t:1527268529419};\\\", \\\"{x:1415,y:562,t:1527268529523};\\\", \\\"{x:1415,y:561,t:1527268530059};\\\", \\\"{x:1416,y:561,t:1527268530083};\\\", \\\"{x:1418,y:561,t:1527268530098};\\\", \\\"{x:1425,y:561,t:1527268530116};\\\", \\\"{x:1432,y:561,t:1527268530132};\\\", \\\"{x:1442,y:561,t:1527268530148};\\\", \\\"{x:1449,y:561,t:1527268530165};\\\", \\\"{x:1456,y:561,t:1527268530182};\\\", \\\"{x:1460,y:561,t:1527268530199};\\\", \\\"{x:1462,y:561,t:1527268530215};\\\", \\\"{x:1463,y:561,t:1527268530231};\\\", \\\"{x:1465,y:561,t:1527268530248};\\\", \\\"{x:1468,y:561,t:1527268530264};\\\", \\\"{x:1472,y:561,t:1527268530281};\\\", \\\"{x:1478,y:561,t:1527268530297};\\\", \\\"{x:1485,y:560,t:1527268530314};\\\", \\\"{x:1487,y:560,t:1527268530332};\\\", \\\"{x:1490,y:559,t:1527268530349};\\\", \\\"{x:1493,y:559,t:1527268530364};\\\", \\\"{x:1497,y:558,t:1527268530382};\\\", \\\"{x:1502,y:556,t:1527268530399};\\\", \\\"{x:1503,y:556,t:1527268530415};\\\", \\\"{x:1506,y:556,t:1527268530432};\\\", \\\"{x:1510,y:556,t:1527268530448};\\\", \\\"{x:1514,y:556,t:1527268530465};\\\", \\\"{x:1527,y:556,t:1527268530483};\\\", \\\"{x:1537,y:556,t:1527268530498};\\\", \\\"{x:1542,y:557,t:1527268530514};\\\", \\\"{x:1547,y:559,t:1527268530532};\\\", \\\"{x:1549,y:560,t:1527268530555};\\\", \\\"{x:1551,y:560,t:1527268530595};\\\", \\\"{x:1552,y:560,t:1527268530619};\\\", \\\"{x:1553,y:560,t:1527268530632};\\\", \\\"{x:1554,y:561,t:1527268530649};\\\", \\\"{x:1555,y:562,t:1527268530666};\\\", \\\"{x:1556,y:562,t:1527268530779};\\\", \\\"{x:1557,y:562,t:1527268530923};\\\", \\\"{x:1558,y:562,t:1527268530939};\\\", \\\"{x:1559,y:562,t:1527268530955};\\\", \\\"{x:1560,y:562,t:1527268530966};\\\", \\\"{x:1562,y:562,t:1527268530987};\\\", \\\"{x:1565,y:562,t:1527268530999};\\\", \\\"{x:1571,y:562,t:1527268531016};\\\", \\\"{x:1580,y:562,t:1527268531032};\\\", \\\"{x:1593,y:562,t:1527268531049};\\\", \\\"{x:1603,y:562,t:1527268531066};\\\", \\\"{x:1610,y:562,t:1527268531082};\\\", \\\"{x:1612,y:562,t:1527268531099};\\\", \\\"{x:1613,y:562,t:1527268531116};\\\", \\\"{x:1614,y:562,t:1527268531132};\\\", \\\"{x:1616,y:562,t:1527268531155};\\\", \\\"{x:1617,y:562,t:1527268531166};\\\", \\\"{x:1623,y:562,t:1527268531183};\\\", \\\"{x:1626,y:562,t:1527268531199};\\\", \\\"{x:1631,y:562,t:1527268531216};\\\", \\\"{x:1635,y:562,t:1527268531232};\\\", \\\"{x:1638,y:562,t:1527268531249};\\\", \\\"{x:1639,y:562,t:1527268531266};\\\", \\\"{x:1642,y:562,t:1527268531282};\\\", \\\"{x:1644,y:562,t:1527268531299};\\\", \\\"{x:1645,y:562,t:1527268531316};\\\", \\\"{x:1647,y:561,t:1527268531333};\\\", \\\"{x:1648,y:561,t:1527268531355};\\\", \\\"{x:1649,y:561,t:1527268531366};\\\", \\\"{x:1650,y:561,t:1527268531383};\\\", \\\"{x:1651,y:561,t:1527268531399};\\\", \\\"{x:1653,y:561,t:1527268531417};\\\", \\\"{x:1654,y:561,t:1527268531433};\\\", \\\"{x:1657,y:561,t:1527268531449};\\\", \\\"{x:1659,y:561,t:1527268531466};\\\", \\\"{x:1663,y:561,t:1527268531483};\\\", \\\"{x:1666,y:560,t:1527268531499};\\\", \\\"{x:1667,y:560,t:1527268531516};\\\", \\\"{x:1668,y:560,t:1527268531533};\\\", \\\"{x:1669,y:560,t:1527268531549};\\\", \\\"{x:1671,y:559,t:1527268531565};\\\", \\\"{x:1673,y:559,t:1527268531583};\\\", \\\"{x:1677,y:559,t:1527268531599};\\\", \\\"{x:1682,y:559,t:1527268531616};\\\", \\\"{x:1683,y:559,t:1527268531633};\\\", \\\"{x:1682,y:559,t:1527268531923};\\\", \\\"{x:1681,y:560,t:1527268532354};\\\", \\\"{x:1681,y:561,t:1527268532659};\\\", \\\"{x:1681,y:562,t:1527268532667};\\\", \\\"{x:1681,y:563,t:1527268532684};\\\", \\\"{x:1680,y:563,t:1527268532700};\\\", \\\"{x:1679,y:564,t:1527268532787};\\\", \\\"{x:1679,y:565,t:1527268532811};\\\", \\\"{x:1678,y:566,t:1527268532827};\\\", \\\"{x:1678,y:568,t:1527268532851};\\\", \\\"{x:1678,y:571,t:1527268532867};\\\", \\\"{x:1677,y:572,t:1527268532884};\\\", \\\"{x:1677,y:575,t:1527268532900};\\\", \\\"{x:1677,y:576,t:1527268532917};\\\", \\\"{x:1676,y:578,t:1527268532934};\\\", \\\"{x:1676,y:580,t:1527268532950};\\\", \\\"{x:1676,y:581,t:1527268532967};\\\", \\\"{x:1676,y:582,t:1527268532984};\\\", \\\"{x:1676,y:585,t:1527268533000};\\\", \\\"{x:1676,y:591,t:1527268533017};\\\", \\\"{x:1676,y:596,t:1527268533034};\\\", \\\"{x:1676,y:604,t:1527268533050};\\\", \\\"{x:1676,y:609,t:1527268533067};\\\", \\\"{x:1676,y:615,t:1527268533084};\\\", \\\"{x:1677,y:617,t:1527268533101};\\\", \\\"{x:1678,y:620,t:1527268533118};\\\", \\\"{x:1678,y:622,t:1527268533134};\\\", \\\"{x:1679,y:625,t:1527268533151};\\\", \\\"{x:1681,y:629,t:1527268533167};\\\", \\\"{x:1682,y:633,t:1527268533184};\\\", \\\"{x:1683,y:636,t:1527268533201};\\\", \\\"{x:1684,y:642,t:1527268533216};\\\", \\\"{x:1685,y:647,t:1527268533234};\\\", \\\"{x:1686,y:660,t:1527268533250};\\\", \\\"{x:1687,y:670,t:1527268533267};\\\", \\\"{x:1690,y:683,t:1527268533284};\\\", \\\"{x:1691,y:690,t:1527268533301};\\\", \\\"{x:1691,y:697,t:1527268533317};\\\", \\\"{x:1691,y:700,t:1527268533334};\\\", \\\"{x:1691,y:702,t:1527268533351};\\\", \\\"{x:1691,y:703,t:1527268533367};\\\", \\\"{x:1691,y:704,t:1527268533419};\\\", \\\"{x:1690,y:702,t:1527268533571};\\\", \\\"{x:1689,y:696,t:1527268533584};\\\", \\\"{x:1683,y:679,t:1527268533601};\\\", \\\"{x:1676,y:660,t:1527268533618};\\\", \\\"{x:1659,y:625,t:1527268533634};\\\", \\\"{x:1644,y:602,t:1527268533651};\\\", \\\"{x:1627,y:580,t:1527268533668};\\\", \\\"{x:1605,y:554,t:1527268533684};\\\", \\\"{x:1591,y:537,t:1527268533701};\\\", \\\"{x:1577,y:519,t:1527268533718};\\\", \\\"{x:1563,y:505,t:1527268533734};\\\", \\\"{x:1551,y:493,t:1527268533751};\\\", \\\"{x:1538,y:482,t:1527268533768};\\\", \\\"{x:1528,y:476,t:1527268533784};\\\", \\\"{x:1515,y:470,t:1527268533801};\\\", \\\"{x:1506,y:466,t:1527268533818};\\\", \\\"{x:1503,y:465,t:1527268533834};\\\", \\\"{x:1500,y:464,t:1527268533851};\\\", \\\"{x:1499,y:463,t:1527268533875};\\\", \\\"{x:1497,y:462,t:1527268533884};\\\", \\\"{x:1496,y:462,t:1527268533901};\\\", \\\"{x:1493,y:462,t:1527268533918};\\\", \\\"{x:1491,y:462,t:1527268533934};\\\", \\\"{x:1489,y:460,t:1527268533951};\\\", \\\"{x:1487,y:460,t:1527268533968};\\\", \\\"{x:1482,y:458,t:1527268533984};\\\", \\\"{x:1474,y:455,t:1527268534001};\\\", \\\"{x:1464,y:452,t:1527268534019};\\\", \\\"{x:1453,y:447,t:1527268534034};\\\", \\\"{x:1445,y:443,t:1527268534051};\\\", \\\"{x:1438,y:441,t:1527268534067};\\\", \\\"{x:1431,y:438,t:1527268534085};\\\", \\\"{x:1425,y:435,t:1527268534100};\\\", \\\"{x:1420,y:433,t:1527268534117};\\\", \\\"{x:1417,y:431,t:1527268534134};\\\", \\\"{x:1417,y:430,t:1527268534150};\\\", \\\"{x:1415,y:429,t:1527268534167};\\\", \\\"{x:1414,y:428,t:1527268534747};\\\", \\\"{x:1414,y:427,t:1527268534763};\\\", \\\"{x:1413,y:427,t:1527268534771};\\\", \\\"{x:1412,y:426,t:1527268534851};\\\", \\\"{x:1413,y:425,t:1527268535035};\\\", \\\"{x:1415,y:424,t:1527268535053};\\\", \\\"{x:1421,y:421,t:1527268535069};\\\", \\\"{x:1426,y:420,t:1527268535085};\\\", \\\"{x:1432,y:420,t:1527268535102};\\\", \\\"{x:1440,y:419,t:1527268535119};\\\", \\\"{x:1454,y:416,t:1527268535136};\\\", \\\"{x:1470,y:414,t:1527268535152};\\\", \\\"{x:1485,y:414,t:1527268535170};\\\", \\\"{x:1507,y:412,t:1527268535185};\\\", \\\"{x:1554,y:412,t:1527268535203};\\\", \\\"{x:1599,y:412,t:1527268535218};\\\", \\\"{x:1649,y:412,t:1527268535235};\\\", \\\"{x:1691,y:412,t:1527268535253};\\\", \\\"{x:1730,y:412,t:1527268535269};\\\", \\\"{x:1757,y:412,t:1527268535285};\\\", \\\"{x:1776,y:412,t:1527268535303};\\\", \\\"{x:1786,y:412,t:1527268535319};\\\", \\\"{x:1790,y:412,t:1527268535335};\\\", \\\"{x:1792,y:412,t:1527268535352};\\\", \\\"{x:1793,y:412,t:1527268535369};\\\", \\\"{x:1794,y:412,t:1527268535385};\\\", \\\"{x:1794,y:413,t:1527268536675};\\\", \\\"{x:1792,y:414,t:1527268536686};\\\", \\\"{x:1765,y:414,t:1527268536703};\\\", \\\"{x:1734,y:414,t:1527268536720};\\\", \\\"{x:1687,y:414,t:1527268536736};\\\", \\\"{x:1641,y:412,t:1527268536753};\\\", \\\"{x:1593,y:405,t:1527268536771};\\\", \\\"{x:1588,y:405,t:1527268536787};\\\", \\\"{x:1587,y:403,t:1527268536804};\\\", \\\"{x:1585,y:403,t:1527268536827};\\\", \\\"{x:1585,y:402,t:1527268536858};\\\", \\\"{x:1585,y:401,t:1527268536871};\\\", \\\"{x:1585,y:400,t:1527268536887};\\\", \\\"{x:1585,y:398,t:1527268536903};\\\", \\\"{x:1585,y:397,t:1527268536921};\\\", \\\"{x:1585,y:395,t:1527268536937};\\\", \\\"{x:1585,y:393,t:1527268536953};\\\", \\\"{x:1585,y:390,t:1527268536971};\\\", \\\"{x:1585,y:389,t:1527268536986};\\\", \\\"{x:1584,y:388,t:1527268537004};\\\", \\\"{x:1584,y:387,t:1527268537021};\\\", \\\"{x:1583,y:387,t:1527268537042};\\\", \\\"{x:1583,y:386,t:1527268537053};\\\", \\\"{x:1580,y:385,t:1527268537071};\\\", \\\"{x:1577,y:384,t:1527268537087};\\\", \\\"{x:1571,y:383,t:1527268537104};\\\", \\\"{x:1562,y:382,t:1527268537121};\\\", \\\"{x:1553,y:380,t:1527268537138};\\\", \\\"{x:1545,y:379,t:1527268537153};\\\", \\\"{x:1530,y:373,t:1527268537171};\\\", \\\"{x:1522,y:370,t:1527268537187};\\\", \\\"{x:1516,y:368,t:1527268537203};\\\", \\\"{x:1514,y:367,t:1527268537221};\\\", \\\"{x:1510,y:365,t:1527268537237};\\\", \\\"{x:1509,y:365,t:1527268537258};\\\", \\\"{x:1508,y:365,t:1527268537271};\\\", \\\"{x:1507,y:364,t:1527268537287};\\\", \\\"{x:1507,y:363,t:1527268537304};\\\", \\\"{x:1506,y:363,t:1527268537331};\\\", \\\"{x:1505,y:363,t:1527268537395};\\\", \\\"{x:1504,y:363,t:1527268537459};\\\", \\\"{x:1503,y:363,t:1527268537470};\\\", \\\"{x:1502,y:363,t:1527268537487};\\\", \\\"{x:1501,y:363,t:1527268537504};\\\", \\\"{x:1500,y:363,t:1527268537520};\\\", \\\"{x:1496,y:363,t:1527268537538};\\\", \\\"{x:1485,y:363,t:1527268537555};\\\", \\\"{x:1465,y:369,t:1527268537571};\\\", \\\"{x:1444,y:371,t:1527268537587};\\\", \\\"{x:1410,y:378,t:1527268537604};\\\", \\\"{x:1367,y:386,t:1527268537620};\\\", \\\"{x:1320,y:401,t:1527268537637};\\\", \\\"{x:1253,y:418,t:1527268537654};\\\", \\\"{x:1184,y:429,t:1527268537670};\\\", \\\"{x:1126,y:442,t:1527268537687};\\\", \\\"{x:1086,y:449,t:1527268537705};\\\", \\\"{x:1059,y:451,t:1527268537720};\\\", \\\"{x:1037,y:454,t:1527268537737};\\\", \\\"{x:1009,y:462,t:1527268537755};\\\", \\\"{x:990,y:467,t:1527268537770};\\\", \\\"{x:972,y:473,t:1527268537788};\\\", \\\"{x:949,y:480,t:1527268537804};\\\", \\\"{x:925,y:488,t:1527268537822};\\\", \\\"{x:900,y:495,t:1527268537836};\\\", \\\"{x:871,y:501,t:1527268537853};\\\", \\\"{x:844,y:511,t:1527268537872};\\\", \\\"{x:813,y:518,t:1527268537887};\\\", \\\"{x:782,y:528,t:1527268537905};\\\", \\\"{x:729,y:541,t:1527268537921};\\\", \\\"{x:682,y:553,t:1527268537938};\\\", \\\"{x:640,y:567,t:1527268537955};\\\", \\\"{x:592,y:580,t:1527268537972};\\\", \\\"{x:547,y:594,t:1527268537987};\\\", \\\"{x:511,y:603,t:1527268538005};\\\", \\\"{x:472,y:616,t:1527268538022};\\\", \\\"{x:433,y:625,t:1527268538038};\\\", \\\"{x:383,y:640,t:1527268538055};\\\", \\\"{x:321,y:658,t:1527268538072};\\\", \\\"{x:266,y:673,t:1527268538088};\\\", \\\"{x:197,y:693,t:1527268538105};\\\", \\\"{x:116,y:715,t:1527268538122};\\\", \\\"{x:71,y:729,t:1527268538138};\\\", \\\"{x:40,y:743,t:1527268538155};\\\", \\\"{x:15,y:756,t:1527268538172};\\\", \\\"{x:0,y:766,t:1527268538189};\\\", \\\"{x:0,y:778,t:1527268538205};\\\", \\\"{x:0,y:786,t:1527268538222};\\\", \\\"{x:0,y:793,t:1527268538239};\\\", \\\"{x:0,y:799,t:1527268538255};\\\", \\\"{x:0,y:804,t:1527268538271};\\\", \\\"{x:0,y:810,t:1527268538288};\\\", \\\"{x:0,y:815,t:1527268538304};\\\", \\\"{x:0,y:824,t:1527268538322};\\\", \\\"{x:0,y:827,t:1527268538338};\\\", \\\"{x:0,y:829,t:1527268538355};\\\", \\\"{x:0,y:833,t:1527268538372};\\\", \\\"{x:0,y:835,t:1527268538389};\\\", \\\"{x:0,y:839,t:1527268538404};\\\", \\\"{x:0,y:842,t:1527268538422};\\\", \\\"{x:0,y:844,t:1527268538439};\\\", \\\"{x:0,y:845,t:1527268538455};\\\", \\\"{x:0,y:846,t:1527268538507};\\\", \\\"{x:3,y:844,t:1527268538698};\\\", \\\"{x:20,y:835,t:1527268538706};\\\", \\\"{x:114,y:797,t:1527268538722};\\\", \\\"{x:256,y:742,t:1527268538738};\\\", \\\"{x:400,y:681,t:1527268538756};\\\", \\\"{x:531,y:636,t:1527268538772};\\\", \\\"{x:661,y:593,t:1527268538790};\\\", \\\"{x:787,y:548,t:1527268538809};\\\", \\\"{x:864,y:514,t:1527268538821};\\\", \\\"{x:906,y:496,t:1527268538838};\\\", \\\"{x:915,y:491,t:1527268538855};\\\", \\\"{x:916,y:486,t:1527268538873};\\\", \\\"{x:916,y:484,t:1527268538889};\\\", \\\"{x:912,y:476,t:1527268538905};\\\", \\\"{x:902,y:471,t:1527268538922};\\\", \\\"{x:888,y:462,t:1527268538939};\\\", \\\"{x:859,y:452,t:1527268538956};\\\", \\\"{x:813,y:443,t:1527268538973};\\\", \\\"{x:765,y:437,t:1527268538989};\\\", \\\"{x:697,y:433,t:1527268539007};\\\", \\\"{x:625,y:433,t:1527268539022};\\\", \\\"{x:547,y:433,t:1527268539038};\\\", \\\"{x:466,y:445,t:1527268539056};\\\", \\\"{x:399,y:456,t:1527268539073};\\\", \\\"{x:342,y:469,t:1527268539089};\\\", \\\"{x:289,y:488,t:1527268539107};\\\", \\\"{x:270,y:502,t:1527268539122};\\\", \\\"{x:263,y:516,t:1527268539138};\\\", \\\"{x:261,y:532,t:1527268539156};\\\", \\\"{x:264,y:559,t:1527268539172};\\\", \\\"{x:285,y:611,t:1527268539188};\\\", \\\"{x:319,y:666,t:1527268539206};\\\", \\\"{x:353,y:716,t:1527268539223};\\\", \\\"{x:374,y:748,t:1527268539238};\\\", \\\"{x:389,y:767,t:1527268539255};\\\", \\\"{x:397,y:779,t:1527268539273};\\\", \\\"{x:401,y:785,t:1527268539290};\\\", \\\"{x:402,y:786,t:1527268539305};\\\", \\\"{x:403,y:786,t:1527268539354};\\\", \\\"{x:404,y:785,t:1527268539362};\\\", \\\"{x:405,y:783,t:1527268539419};\\\", \\\"{x:407,y:782,t:1527268539426};\\\", \\\"{x:412,y:777,t:1527268539440};\\\", \\\"{x:430,y:764,t:1527268539457};\\\", \\\"{x:452,y:747,t:1527268539474};\\\", \\\"{x:485,y:722,t:1527268539489};\\\", \\\"{x:505,y:716,t:1527268539506};\\\", \\\"{x:516,y:714,t:1527268539523};\\\", \\\"{x:520,y:714,t:1527268539540};\\\", \\\"{x:521,y:714,t:1527268539595};\\\", \\\"{x:522,y:714,t:1527268539643};\\\", \\\"{x:522,y:715,t:1527268539698};\\\", \\\"{x:522,y:716,t:1527268539705};\\\", \\\"{x:522,y:718,t:1527268539723};\\\", \\\"{x:521,y:720,t:1527268539740};\\\", \\\"{x:519,y:724,t:1527268539756};\\\", \\\"{x:517,y:726,t:1527268539773};\\\", \\\"{x:515,y:728,t:1527268539789};\\\", \\\"{x:513,y:731,t:1527268539807};\\\", \\\"{x:512,y:732,t:1527268539823};\\\", \\\"{x:512,y:727,t:1527268539975};\\\", \\\"{x:512,y:726,t:1527268539991};\\\", \\\"{x:513,y:724,t:1527268540307};\\\", \\\"{x:517,y:721,t:1527268540324};\\\", \\\"{x:521,y:718,t:1527268540340};\\\", \\\"{x:523,y:718,t:1527268540357};\\\", \\\"{x:525,y:716,t:1527268540374};\\\", \\\"{x:527,y:715,t:1527268540390};\\\", \\\"{x:529,y:714,t:1527268540407};\\\", \\\"{x:532,y:712,t:1527268540424};\\\", \\\"{x:537,y:709,t:1527268540440};\\\", \\\"{x:542,y:707,t:1527268540457};\\\", \\\"{x:557,y:698,t:1527268540474};\\\", \\\"{x:570,y:690,t:1527268540490};\\\", \\\"{x:584,y:683,t:1527268540507};\\\", \\\"{x:597,y:676,t:1527268540524};\\\", \\\"{x:608,y:672,t:1527268540540};\\\", \\\"{x:618,y:668,t:1527268540557};\\\", \\\"{x:636,y:663,t:1527268540574};\\\", \\\"{x:662,y:661,t:1527268540590};\\\", \\\"{x:705,y:657,t:1527268540607};\\\", \\\"{x:755,y:651,t:1527268540624};\\\", \\\"{x:804,y:646,t:1527268540640};\\\", \\\"{x:849,y:646,t:1527268540657};\\\", \\\"{x:908,y:641,t:1527268540674};\\\", \\\"{x:947,y:635,t:1527268540690};\\\", \\\"{x:976,y:630,t:1527268540707};\\\", \\\"{x:1008,y:627,t:1527268540724};\\\", \\\"{x:1038,y:622,t:1527268540740};\\\", \\\"{x:1061,y:620,t:1527268540757};\\\", \\\"{x:1079,y:616,t:1527268540774};\\\", \\\"{x:1092,y:612,t:1527268540791};\\\", \\\"{x:1101,y:611,t:1527268540807};\\\", \\\"{x:1107,y:611,t:1527268540823};\\\", \\\"{x:1109,y:611,t:1527268540841};\\\" ] }, { \\\"rt\\\": 7037, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 572269, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1102,y:608,t:1527268542227};\\\", \\\"{x:1075,y:602,t:1527268542242};\\\", \\\"{x:1033,y:589,t:1527268542259};\\\", \\\"{x:968,y:570,t:1527268542275};\\\", \\\"{x:895,y:554,t:1527268542293};\\\", \\\"{x:827,y:544,t:1527268542308};\\\", \\\"{x:774,y:536,t:1527268542325};\\\", \\\"{x:716,y:528,t:1527268542341};\\\", \\\"{x:673,y:520,t:1527268542358};\\\", \\\"{x:639,y:520,t:1527268542375};\\\", \\\"{x:607,y:519,t:1527268542391};\\\", \\\"{x:581,y:516,t:1527268542409};\\\", \\\"{x:578,y:515,t:1527268542425};\\\", \\\"{x:566,y:514,t:1527268542441};\\\", \\\"{x:559,y:512,t:1527268542459};\\\", \\\"{x:555,y:510,t:1527268542475};\\\", \\\"{x:552,y:510,t:1527268542492};\\\", \\\"{x:551,y:508,t:1527268542509};\\\", \\\"{x:552,y:507,t:1527268542642};\\\", \\\"{x:563,y:502,t:1527268542659};\\\", \\\"{x:581,y:495,t:1527268542675};\\\", \\\"{x:608,y:490,t:1527268542693};\\\", \\\"{x:645,y:484,t:1527268542709};\\\", \\\"{x:688,y:483,t:1527268542725};\\\", \\\"{x:743,y:483,t:1527268542742};\\\", \\\"{x:785,y:483,t:1527268542759};\\\", \\\"{x:825,y:483,t:1527268542775};\\\", \\\"{x:859,y:483,t:1527268542791};\\\", \\\"{x:897,y:481,t:1527268542809};\\\", \\\"{x:913,y:481,t:1527268542825};\\\", \\\"{x:926,y:481,t:1527268542842};\\\", \\\"{x:935,y:481,t:1527268542858};\\\", \\\"{x:945,y:481,t:1527268542875};\\\", \\\"{x:958,y:481,t:1527268542891};\\\", \\\"{x:969,y:481,t:1527268542909};\\\", \\\"{x:977,y:481,t:1527268542926};\\\", \\\"{x:990,y:481,t:1527268542943};\\\", \\\"{x:998,y:481,t:1527268542959};\\\", \\\"{x:1005,y:481,t:1527268542976};\\\", \\\"{x:1012,y:481,t:1527268542992};\\\", \\\"{x:1030,y:482,t:1527268543010};\\\", \\\"{x:1045,y:485,t:1527268543026};\\\", \\\"{x:1057,y:486,t:1527268543042};\\\", \\\"{x:1068,y:488,t:1527268543059};\\\", \\\"{x:1074,y:488,t:1527268543076};\\\", \\\"{x:1077,y:488,t:1527268543092};\\\", \\\"{x:1079,y:488,t:1527268543110};\\\", \\\"{x:1080,y:488,t:1527268543154};\\\", \\\"{x:1080,y:489,t:1527268543571};\\\", \\\"{x:1080,y:490,t:1527268543611};\\\", \\\"{x:1080,y:491,t:1527268543626};\\\", \\\"{x:1080,y:492,t:1527268543675};\\\", \\\"{x:1079,y:494,t:1527268543731};\\\", \\\"{x:1079,y:495,t:1527268543744};\\\", \\\"{x:1078,y:497,t:1527268543761};\\\", \\\"{x:1077,y:499,t:1527268543776};\\\", \\\"{x:1075,y:503,t:1527268543794};\\\", \\\"{x:1075,y:509,t:1527268543811};\\\", \\\"{x:1075,y:513,t:1527268543827};\\\", \\\"{x:1075,y:520,t:1527268543844};\\\", \\\"{x:1075,y:532,t:1527268543861};\\\", \\\"{x:1078,y:552,t:1527268543876};\\\", \\\"{x:1090,y:578,t:1527268543893};\\\", \\\"{x:1126,y:631,t:1527268543911};\\\", \\\"{x:1167,y:682,t:1527268543926};\\\", \\\"{x:1207,y:729,t:1527268543943};\\\", \\\"{x:1237,y:759,t:1527268543960};\\\", \\\"{x:1283,y:795,t:1527268543976};\\\", \\\"{x:1331,y:830,t:1527268543994};\\\", \\\"{x:1372,y:856,t:1527268544011};\\\", \\\"{x:1394,y:869,t:1527268544026};\\\", \\\"{x:1414,y:880,t:1527268544044};\\\", \\\"{x:1432,y:889,t:1527268544060};\\\", \\\"{x:1445,y:894,t:1527268544076};\\\", \\\"{x:1455,y:898,t:1527268544094};\\\", \\\"{x:1467,y:900,t:1527268544110};\\\", \\\"{x:1479,y:901,t:1527268544126};\\\", \\\"{x:1488,y:902,t:1527268544144};\\\", \\\"{x:1493,y:903,t:1527268544161};\\\", \\\"{x:1494,y:903,t:1527268544177};\\\", \\\"{x:1495,y:904,t:1527268544307};\\\", \\\"{x:1493,y:906,t:1527268544314};\\\", \\\"{x:1489,y:907,t:1527268544328};\\\", \\\"{x:1476,y:910,t:1527268544344};\\\", \\\"{x:1464,y:912,t:1527268544360};\\\", \\\"{x:1449,y:914,t:1527268544378};\\\", \\\"{x:1436,y:915,t:1527268544393};\\\", \\\"{x:1432,y:917,t:1527268544411};\\\", \\\"{x:1431,y:917,t:1527268544435};\\\", \\\"{x:1430,y:918,t:1527268544458};\\\", \\\"{x:1429,y:920,t:1527268544474};\\\", \\\"{x:1428,y:920,t:1527268544490};\\\", \\\"{x:1427,y:921,t:1527268544506};\\\", \\\"{x:1426,y:921,t:1527268544522};\\\", \\\"{x:1425,y:921,t:1527268544530};\\\", \\\"{x:1423,y:922,t:1527268544543};\\\", \\\"{x:1422,y:923,t:1527268544561};\\\", \\\"{x:1420,y:923,t:1527268544577};\\\", \\\"{x:1417,y:924,t:1527268544594};\\\", \\\"{x:1413,y:924,t:1527268544611};\\\", \\\"{x:1408,y:924,t:1527268544627};\\\", \\\"{x:1406,y:924,t:1527268544644};\\\", \\\"{x:1403,y:924,t:1527268544660};\\\", \\\"{x:1401,y:924,t:1527268544678};\\\", \\\"{x:1397,y:923,t:1527268544694};\\\", \\\"{x:1392,y:919,t:1527268544711};\\\", \\\"{x:1386,y:914,t:1527268544728};\\\", \\\"{x:1379,y:908,t:1527268544745};\\\", \\\"{x:1375,y:905,t:1527268544761};\\\", \\\"{x:1371,y:902,t:1527268544778};\\\", \\\"{x:1368,y:900,t:1527268544795};\\\", \\\"{x:1367,y:896,t:1527268544811};\\\", \\\"{x:1363,y:892,t:1527268544827};\\\", \\\"{x:1358,y:885,t:1527268544844};\\\", \\\"{x:1354,y:878,t:1527268544859};\\\", \\\"{x:1348,y:867,t:1527268544876};\\\", \\\"{x:1343,y:859,t:1527268544894};\\\", \\\"{x:1340,y:852,t:1527268544909};\\\", \\\"{x:1339,y:848,t:1527268544927};\\\", \\\"{x:1339,y:846,t:1527268544944};\\\", \\\"{x:1338,y:844,t:1527268544960};\\\", \\\"{x:1338,y:842,t:1527268544977};\\\", \\\"{x:1338,y:838,t:1527268544994};\\\", \\\"{x:1338,y:834,t:1527268545010};\\\", \\\"{x:1338,y:831,t:1527268545028};\\\", \\\"{x:1338,y:827,t:1527268545044};\\\", \\\"{x:1338,y:824,t:1527268545060};\\\", \\\"{x:1338,y:821,t:1527268545077};\\\", \\\"{x:1338,y:820,t:1527268545094};\\\", \\\"{x:1338,y:818,t:1527268545110};\\\", \\\"{x:1338,y:816,t:1527268545127};\\\", \\\"{x:1338,y:815,t:1527268545144};\\\", \\\"{x:1338,y:812,t:1527268545162};\\\", \\\"{x:1338,y:809,t:1527268545177};\\\", \\\"{x:1337,y:807,t:1527268545195};\\\", \\\"{x:1337,y:805,t:1527268545212};\\\", \\\"{x:1337,y:804,t:1527268545227};\\\", \\\"{x:1337,y:803,t:1527268545323};\\\", \\\"{x:1337,y:802,t:1527268545507};\\\", \\\"{x:1337,y:801,t:1527268545579};\\\", \\\"{x:1337,y:800,t:1527268545731};\\\", \\\"{x:1337,y:799,t:1527268545795};\\\", \\\"{x:1337,y:798,t:1527268545955};\\\", \\\"{x:1337,y:797,t:1527268545995};\\\", \\\"{x:1337,y:796,t:1527268546011};\\\", \\\"{x:1337,y:795,t:1527268546029};\\\", \\\"{x:1337,y:794,t:1527268546045};\\\", \\\"{x:1337,y:793,t:1527268546061};\\\", \\\"{x:1337,y:792,t:1527268546078};\\\", \\\"{x:1337,y:791,t:1527268546095};\\\", \\\"{x:1338,y:790,t:1527268546112};\\\", \\\"{x:1338,y:789,t:1527268546130};\\\", \\\"{x:1338,y:787,t:1527268546146};\\\", \\\"{x:1338,y:786,t:1527268546187};\\\", \\\"{x:1338,y:785,t:1527268546227};\\\", \\\"{x:1338,y:784,t:1527268546243};\\\", \\\"{x:1338,y:783,t:1527268546250};\\\", \\\"{x:1338,y:782,t:1527268546291};\\\", \\\"{x:1338,y:781,t:1527268546298};\\\", \\\"{x:1338,y:780,t:1527268546312};\\\", \\\"{x:1338,y:778,t:1527268546328};\\\", \\\"{x:1338,y:773,t:1527268546346};\\\", \\\"{x:1338,y:766,t:1527268546362};\\\", \\\"{x:1323,y:730,t:1527268546379};\\\", \\\"{x:1296,y:693,t:1527268546396};\\\", \\\"{x:1250,y:648,t:1527268546413};\\\", \\\"{x:1187,y:596,t:1527268546429};\\\", \\\"{x:1096,y:552,t:1527268546446};\\\", \\\"{x:977,y:521,t:1527268546463};\\\", \\\"{x:827,y:495,t:1527268546480};\\\", \\\"{x:688,y:493,t:1527268546495};\\\", \\\"{x:567,y:493,t:1527268546512};\\\", \\\"{x:461,y:493,t:1527268546528};\\\", \\\"{x:386,y:493,t:1527268546546};\\\", \\\"{x:313,y:505,t:1527268546562};\\\", \\\"{x:292,y:513,t:1527268546577};\\\", \\\"{x:277,y:520,t:1527268546595};\\\", \\\"{x:266,y:525,t:1527268546612};\\\", \\\"{x:256,y:532,t:1527268546628};\\\", \\\"{x:247,y:546,t:1527268546645};\\\", \\\"{x:241,y:566,t:1527268546663};\\\", \\\"{x:241,y:589,t:1527268546677};\\\", \\\"{x:256,y:620,t:1527268546695};\\\", \\\"{x:282,y:648,t:1527268546713};\\\", \\\"{x:306,y:660,t:1527268546728};\\\", \\\"{x:326,y:662,t:1527268546744};\\\", \\\"{x:346,y:665,t:1527268546761};\\\", \\\"{x:350,y:665,t:1527268546778};\\\", \\\"{x:351,y:665,t:1527268546794};\\\", \\\"{x:352,y:664,t:1527268546818};\\\", \\\"{x:352,y:658,t:1527268546829};\\\", \\\"{x:355,y:638,t:1527268546845};\\\", \\\"{x:357,y:620,t:1527268546863};\\\", \\\"{x:361,y:601,t:1527268546877};\\\", \\\"{x:361,y:592,t:1527268546895};\\\", \\\"{x:361,y:587,t:1527268546912};\\\", \\\"{x:361,y:585,t:1527268546928};\\\", \\\"{x:361,y:583,t:1527268546945};\\\", \\\"{x:361,y:582,t:1527268546962};\\\", \\\"{x:360,y:581,t:1527268546979};\\\", \\\"{x:360,y:580,t:1527268546996};\\\", \\\"{x:360,y:576,t:1527268547057};\\\", \\\"{x:362,y:574,t:1527268547065};\\\", \\\"{x:366,y:569,t:1527268547079};\\\", \\\"{x:376,y:559,t:1527268547096};\\\", \\\"{x:386,y:550,t:1527268547113};\\\", \\\"{x:392,y:545,t:1527268547128};\\\", \\\"{x:395,y:543,t:1527268547145};\\\", \\\"{x:395,y:542,t:1527268547162};\\\", \\\"{x:395,y:541,t:1527268547178};\\\", \\\"{x:396,y:540,t:1527268547195};\\\", \\\"{x:396,y:539,t:1527268547212};\\\", \\\"{x:396,y:538,t:1527268547228};\\\", \\\"{x:396,y:537,t:1527268547245};\\\", \\\"{x:397,y:537,t:1527268547466};\\\", \\\"{x:398,y:541,t:1527268547479};\\\", \\\"{x:400,y:557,t:1527268547497};\\\", \\\"{x:400,y:567,t:1527268547513};\\\", \\\"{x:400,y:573,t:1527268547529};\\\", \\\"{x:400,y:580,t:1527268547545};\\\", \\\"{x:400,y:584,t:1527268547561};\\\", \\\"{x:400,y:589,t:1527268547581};\\\", \\\"{x:400,y:593,t:1527268547596};\\\", \\\"{x:401,y:598,t:1527268547613};\\\", \\\"{x:404,y:604,t:1527268547630};\\\", \\\"{x:408,y:612,t:1527268547646};\\\", \\\"{x:411,y:620,t:1527268547662};\\\", \\\"{x:422,y:638,t:1527268547679};\\\", \\\"{x:436,y:662,t:1527268547696};\\\", \\\"{x:463,y:699,t:1527268547713};\\\", \\\"{x:499,y:744,t:1527268547729};\\\", \\\"{x:540,y:787,t:1527268547746};\\\", \\\"{x:547,y:792,t:1527268547763};\\\", \\\"{x:548,y:792,t:1527268547793};\\\", \\\"{x:549,y:792,t:1527268547801};\\\", \\\"{x:549,y:791,t:1527268547825};\\\", \\\"{x:550,y:791,t:1527268547834};\\\", \\\"{x:550,y:790,t:1527268547846};\\\", \\\"{x:550,y:786,t:1527268547862};\\\", \\\"{x:550,y:785,t:1527268547879};\\\", \\\"{x:550,y:782,t:1527268547896};\\\", \\\"{x:550,y:780,t:1527268547922};\\\", \\\"{x:550,y:779,t:1527268547938};\\\", \\\"{x:550,y:776,t:1527268547945};\\\", \\\"{x:550,y:772,t:1527268547962};\\\", \\\"{x:550,y:763,t:1527268547979};\\\", \\\"{x:544,y:748,t:1527268547996};\\\", \\\"{x:539,y:737,t:1527268548012};\\\", \\\"{x:538,y:732,t:1527268548030};\\\", \\\"{x:537,y:730,t:1527268548046};\\\", \\\"{x:536,y:730,t:1527268548073};\\\", \\\"{x:536,y:729,t:1527268549498};\\\", \\\"{x:550,y:725,t:1527268549514};\\\", \\\"{x:569,y:725,t:1527268549532};\\\", \\\"{x:598,y:725,t:1527268549547};\\\", \\\"{x:626,y:727,t:1527268549566};\\\", \\\"{x:672,y:732,t:1527268549581};\\\", \\\"{x:729,y:735,t:1527268549597};\\\", \\\"{x:812,y:735,t:1527268549614};\\\", \\\"{x:944,y:702,t:1527268549631};\\\" ] }, { \\\"rt\\\": 5945, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 579465, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1497,y:514,t:1527268549787};\\\", \\\"{x:1496,y:515,t:1527268550306};\\\", \\\"{x:1493,y:516,t:1527268550314};\\\", \\\"{x:1482,y:520,t:1527268550331};\\\", \\\"{x:1458,y:524,t:1527268550348};\\\", \\\"{x:1425,y:525,t:1527268550364};\\\", \\\"{x:1358,y:525,t:1527268550381};\\\", \\\"{x:1261,y:525,t:1527268550398};\\\", \\\"{x:1214,y:525,t:1527268550415};\\\", \\\"{x:1213,y:525,t:1527268551818};\\\", \\\"{x:1213,y:526,t:1527268551833};\\\", \\\"{x:1213,y:525,t:1527268552450};\\\", \\\"{x:1212,y:524,t:1527268552474};\\\", \\\"{x:1211,y:524,t:1527268552484};\\\", \\\"{x:1211,y:523,t:1527268552619};\\\", \\\"{x:1211,y:522,t:1527268552634};\\\", \\\"{x:1211,y:521,t:1527268552650};\\\", \\\"{x:1211,y:520,t:1527268552666};\\\", \\\"{x:1210,y:519,t:1527268552690};\\\", \\\"{x:1210,y:522,t:1527268552979};\\\", \\\"{x:1210,y:527,t:1527268552986};\\\", \\\"{x:1210,y:533,t:1527268553001};\\\", \\\"{x:1210,y:540,t:1527268553017};\\\", \\\"{x:1210,y:543,t:1527268553034};\\\", \\\"{x:1210,y:545,t:1527268553051};\\\", \\\"{x:1210,y:546,t:1527268553067};\\\", \\\"{x:1210,y:548,t:1527268553084};\\\", \\\"{x:1210,y:550,t:1527268553100};\\\", \\\"{x:1210,y:551,t:1527268553131};\\\", \\\"{x:1210,y:550,t:1527268553355};\\\", \\\"{x:1209,y:549,t:1527268553368};\\\", \\\"{x:1208,y:549,t:1527268553384};\\\", \\\"{x:1205,y:549,t:1527268553401};\\\", \\\"{x:1200,y:549,t:1527268553418};\\\", \\\"{x:1195,y:549,t:1527268553434};\\\", \\\"{x:1194,y:548,t:1527268553451};\\\", \\\"{x:1192,y:546,t:1527268553468};\\\", \\\"{x:1191,y:546,t:1527268553484};\\\", \\\"{x:1190,y:545,t:1527268553501};\\\", \\\"{x:1189,y:545,t:1527268553522};\\\", \\\"{x:1188,y:545,t:1527268553538};\\\", \\\"{x:1186,y:544,t:1527268553562};\\\", \\\"{x:1186,y:543,t:1527268553570};\\\", \\\"{x:1185,y:543,t:1527268553586};\\\", \\\"{x:1184,y:543,t:1527268553601};\\\", \\\"{x:1182,y:542,t:1527268553618};\\\", \\\"{x:1181,y:542,t:1527268553634};\\\", \\\"{x:1178,y:542,t:1527268553650};\\\", \\\"{x:1174,y:545,t:1527268553668};\\\", \\\"{x:1169,y:552,t:1527268553684};\\\", \\\"{x:1162,y:564,t:1527268553701};\\\", \\\"{x:1152,y:579,t:1527268553718};\\\", \\\"{x:1142,y:598,t:1527268553735};\\\", \\\"{x:1132,y:619,t:1527268553751};\\\", \\\"{x:1118,y:645,t:1527268553769};\\\", \\\"{x:1093,y:676,t:1527268553785};\\\", \\\"{x:1057,y:707,t:1527268553801};\\\", \\\"{x:1003,y:735,t:1527268553818};\\\", \\\"{x:914,y:762,t:1527268553834};\\\", \\\"{x:871,y:769,t:1527268553851};\\\", \\\"{x:829,y:775,t:1527268553868};\\\", \\\"{x:801,y:773,t:1527268553884};\\\", \\\"{x:759,y:757,t:1527268553901};\\\", \\\"{x:710,y:731,t:1527268553918};\\\", \\\"{x:661,y:702,t:1527268553935};\\\", \\\"{x:618,y:679,t:1527268553951};\\\", \\\"{x:599,y:668,t:1527268553968};\\\", \\\"{x:586,y:659,t:1527268553985};\\\", \\\"{x:576,y:652,t:1527268554001};\\\", \\\"{x:566,y:645,t:1527268554018};\\\", \\\"{x:549,y:632,t:1527268554034};\\\", \\\"{x:539,y:628,t:1527268554052};\\\", \\\"{x:524,y:624,t:1527268554067};\\\", \\\"{x:497,y:624,t:1527268554085};\\\", \\\"{x:470,y:624,t:1527268554101};\\\", \\\"{x:457,y:624,t:1527268554118};\\\", \\\"{x:452,y:624,t:1527268554134};\\\", \\\"{x:445,y:624,t:1527268554151};\\\", \\\"{x:434,y:618,t:1527268554168};\\\", \\\"{x:412,y:600,t:1527268554185};\\\", \\\"{x:333,y:555,t:1527268554201};\\\", \\\"{x:275,y:529,t:1527268554218};\\\", \\\"{x:224,y:513,t:1527268554235};\\\", \\\"{x:206,y:507,t:1527268554252};\\\", \\\"{x:203,y:506,t:1527268554268};\\\", \\\"{x:202,y:506,t:1527268554284};\\\", \\\"{x:194,y:502,t:1527268554301};\\\", \\\"{x:182,y:496,t:1527268554319};\\\", \\\"{x:159,y:489,t:1527268554335};\\\", \\\"{x:135,y:484,t:1527268554352};\\\", \\\"{x:112,y:482,t:1527268554368};\\\", \\\"{x:102,y:482,t:1527268554384};\\\", \\\"{x:94,y:484,t:1527268554401};\\\", \\\"{x:91,y:487,t:1527268554418};\\\", \\\"{x:88,y:494,t:1527268554434};\\\", \\\"{x:85,y:500,t:1527268554451};\\\", \\\"{x:85,y:507,t:1527268554468};\\\", \\\"{x:85,y:509,t:1527268554485};\\\", \\\"{x:87,y:511,t:1527268554501};\\\", \\\"{x:90,y:516,t:1527268554518};\\\", \\\"{x:95,y:522,t:1527268554536};\\\", \\\"{x:101,y:528,t:1527268554552};\\\", \\\"{x:104,y:529,t:1527268554573};\\\", \\\"{x:105,y:530,t:1527268554584};\\\", \\\"{x:106,y:530,t:1527268554601};\\\", \\\"{x:111,y:530,t:1527268554618};\\\", \\\"{x:115,y:530,t:1527268554635};\\\", \\\"{x:119,y:529,t:1527268554651};\\\", \\\"{x:127,y:526,t:1527268554669};\\\", \\\"{x:138,y:525,t:1527268554685};\\\", \\\"{x:150,y:523,t:1527268554701};\\\", \\\"{x:156,y:522,t:1527268554718};\\\", \\\"{x:158,y:522,t:1527268554735};\\\", \\\"{x:160,y:522,t:1527268554752};\\\", \\\"{x:162,y:523,t:1527268554768};\\\", \\\"{x:166,y:527,t:1527268554786};\\\", \\\"{x:166,y:529,t:1527268554803};\\\", \\\"{x:167,y:530,t:1527268554818};\\\", \\\"{x:167,y:532,t:1527268554835};\\\", \\\"{x:167,y:533,t:1527268554851};\\\", \\\"{x:170,y:535,t:1527268555097};\\\", \\\"{x:171,y:537,t:1527268555105};\\\", \\\"{x:174,y:539,t:1527268555118};\\\", \\\"{x:183,y:545,t:1527268555135};\\\", \\\"{x:220,y:569,t:1527268555153};\\\", \\\"{x:311,y:609,t:1527268555168};\\\", \\\"{x:480,y:675,t:1527268555185};\\\", \\\"{x:579,y:697,t:1527268555203};\\\", \\\"{x:610,y:702,t:1527268555218};\\\", \\\"{x:615,y:702,t:1527268555235};\\\", \\\"{x:616,y:702,t:1527268555252};\\\", \\\"{x:614,y:702,t:1527268555434};\\\", \\\"{x:612,y:703,t:1527268555450};\\\", \\\"{x:606,y:706,t:1527268555458};\\\", \\\"{x:599,y:708,t:1527268555469};\\\", \\\"{x:581,y:713,t:1527268555485};\\\", \\\"{x:565,y:721,t:1527268555503};\\\", \\\"{x:547,y:732,t:1527268555521};\\\", \\\"{x:537,y:738,t:1527268555535};\\\", \\\"{x:529,y:744,t:1527268555552};\\\", \\\"{x:528,y:745,t:1527268555569};\\\", \\\"{x:528,y:742,t:1527268555749};\\\", \\\"{x:528,y:740,t:1527268555769};\\\", \\\"{x:528,y:739,t:1527268555985};\\\", \\\"{x:532,y:739,t:1527268556097};\\\", \\\"{x:540,y:737,t:1527268556105};\\\", \\\"{x:541,y:737,t:1527268556119};\\\", \\\"{x:541,y:735,t:1527268556578};\\\", \\\"{x:534,y:682,t:1527268556586};\\\", \\\"{x:527,y:515,t:1527268556604};\\\", \\\"{x:525,y:371,t:1527268556619};\\\", \\\"{x:522,y:242,t:1527268556636};\\\", \\\"{x:517,y:92,t:1527268556654};\\\", \\\"{x:538,y:0,t:1527268556670};\\\", \\\"{x:582,y:0,t:1527268556687};\\\", \\\"{x:628,y:0,t:1527268556703};\\\", \\\"{x:692,y:0,t:1527268556721};\\\", \\\"{x:753,y:0,t:1527268556736};\\\", \\\"{x:854,y:0,t:1527268556765};\\\", \\\"{x:874,y:0,t:1527268556770};\\\", \\\"{x:921,y:0,t:1527268556786};\\\", \\\"{x:957,y:0,t:1527268556803};\\\", \\\"{x:988,y:0,t:1527268556820};\\\", \\\"{x:1019,y:0,t:1527268556836};\\\" ] }, { \\\"rt\\\": 37704, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 618392, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11-J -N -Z -Z -03 PM-04 PM-N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1059,y:3,t:1527268556957};\\\", \\\"{x:1066,y:9,t:1527268556971};\\\", \\\"{x:1074,y:20,t:1527268556986};\\\", \\\"{x:1081,y:28,t:1527268557003};\\\", \\\"{x:1086,y:38,t:1527268557020};\\\", \\\"{x:1092,y:49,t:1527268557037};\\\", \\\"{x:1103,y:59,t:1527268557066};\\\", \\\"{x:1104,y:60,t:1527268557073};\\\", \\\"{x:1104,y:61,t:1527268557457};\\\", \\\"{x:1104,y:66,t:1527268557470};\\\", \\\"{x:1104,y:94,t:1527268557487};\\\", \\\"{x:1101,y:116,t:1527268557503};\\\", \\\"{x:1098,y:131,t:1527268557521};\\\", \\\"{x:1092,y:162,t:1527268557538};\\\", \\\"{x:1080,y:193,t:1527268557553};\\\", \\\"{x:1053,y:232,t:1527268557570};\\\", \\\"{x:1017,y:263,t:1527268557588};\\\", \\\"{x:955,y:297,t:1527268557603};\\\", \\\"{x:869,y:336,t:1527268557621};\\\", \\\"{x:775,y:376,t:1527268557637};\\\", \\\"{x:662,y:424,t:1527268557654};\\\", \\\"{x:550,y:470,t:1527268557671};\\\", \\\"{x:447,y:500,t:1527268557689};\\\", \\\"{x:386,y:528,t:1527268557705};\\\", \\\"{x:360,y:543,t:1527268557720};\\\", \\\"{x:349,y:565,t:1527268557759};\\\", \\\"{x:370,y:576,t:1527268557770};\\\", \\\"{x:427,y:577,t:1527268557787};\\\", \\\"{x:524,y:577,t:1527268557804};\\\", \\\"{x:629,y:577,t:1527268557820};\\\", \\\"{x:745,y:577,t:1527268557838};\\\", \\\"{x:837,y:577,t:1527268557855};\\\", \\\"{x:898,y:577,t:1527268557870};\\\", \\\"{x:930,y:581,t:1527268557887};\\\", \\\"{x:937,y:581,t:1527268557904};\\\", \\\"{x:938,y:581,t:1527268557953};\\\", \\\"{x:938,y:582,t:1527268557977};\\\", \\\"{x:936,y:582,t:1527268557993};\\\", \\\"{x:935,y:582,t:1527268558009};\\\", \\\"{x:933,y:582,t:1527268558033};\\\", \\\"{x:932,y:582,t:1527268558041};\\\", \\\"{x:929,y:582,t:1527268558055};\\\", \\\"{x:922,y:582,t:1527268558072};\\\", \\\"{x:914,y:582,t:1527268558087};\\\", \\\"{x:897,y:582,t:1527268558105};\\\", \\\"{x:858,y:577,t:1527268558122};\\\", \\\"{x:824,y:572,t:1527268558138};\\\", \\\"{x:785,y:566,t:1527268558155};\\\", \\\"{x:743,y:559,t:1527268558171};\\\", \\\"{x:705,y:556,t:1527268558187};\\\", \\\"{x:668,y:551,t:1527268558205};\\\", \\\"{x:630,y:545,t:1527268558221};\\\", \\\"{x:591,y:539,t:1527268558237};\\\", \\\"{x:552,y:534,t:1527268558254};\\\", \\\"{x:527,y:530,t:1527268558271};\\\", \\\"{x:516,y:528,t:1527268558287};\\\", \\\"{x:512,y:527,t:1527268558304};\\\", \\\"{x:511,y:527,t:1527268558322};\\\", \\\"{x:510,y:527,t:1527268558410};\\\", \\\"{x:510,y:526,t:1527268558421};\\\", \\\"{x:504,y:521,t:1527268558439};\\\", \\\"{x:498,y:518,t:1527268558454};\\\", \\\"{x:482,y:516,t:1527268558471};\\\", \\\"{x:461,y:516,t:1527268558487};\\\", \\\"{x:447,y:515,t:1527268558505};\\\", \\\"{x:414,y:512,t:1527268558522};\\\", \\\"{x:380,y:506,t:1527268558538};\\\", \\\"{x:353,y:499,t:1527268558555};\\\", \\\"{x:335,y:493,t:1527268558572};\\\", \\\"{x:325,y:490,t:1527268558588};\\\", \\\"{x:321,y:490,t:1527268558604};\\\", \\\"{x:320,y:489,t:1527268558621};\\\", \\\"{x:321,y:485,t:1527268558819};\\\", \\\"{x:342,y:475,t:1527268558838};\\\", \\\"{x:367,y:465,t:1527268558855};\\\", \\\"{x:387,y:457,t:1527268558871};\\\", \\\"{x:399,y:452,t:1527268558887};\\\", \\\"{x:401,y:450,t:1527268558904};\\\", \\\"{x:403,y:450,t:1527268558921};\\\", \\\"{x:404,y:449,t:1527268559114};\\\", \\\"{x:406,y:448,t:1527268559122};\\\", \\\"{x:412,y:447,t:1527268559137};\\\", \\\"{x:422,y:444,t:1527268559154};\\\", \\\"{x:435,y:443,t:1527268559170};\\\", \\\"{x:450,y:440,t:1527268559188};\\\", \\\"{x:464,y:440,t:1527268559205};\\\", \\\"{x:475,y:440,t:1527268559221};\\\", \\\"{x:489,y:440,t:1527268559237};\\\", \\\"{x:504,y:440,t:1527268559255};\\\", \\\"{x:519,y:440,t:1527268559270};\\\", \\\"{x:533,y:440,t:1527268559288};\\\", \\\"{x:544,y:439,t:1527268559304};\\\", \\\"{x:551,y:439,t:1527268559321};\\\", \\\"{x:560,y:438,t:1527268559337};\\\", \\\"{x:566,y:438,t:1527268559355};\\\", \\\"{x:574,y:438,t:1527268559371};\\\", \\\"{x:582,y:438,t:1527268559388};\\\", \\\"{x:590,y:437,t:1527268559405};\\\", \\\"{x:596,y:437,t:1527268559421};\\\", \\\"{x:602,y:437,t:1527268559438};\\\", \\\"{x:605,y:437,t:1527268559455};\\\", \\\"{x:610,y:437,t:1527268559471};\\\", \\\"{x:612,y:437,t:1527268559490};\\\", \\\"{x:613,y:437,t:1527268559505};\\\", \\\"{x:618,y:439,t:1527268559810};\\\", \\\"{x:637,y:449,t:1527268559821};\\\", \\\"{x:690,y:463,t:1527268559838};\\\", \\\"{x:796,y:481,t:1527268559854};\\\", \\\"{x:959,y:503,t:1527268559871};\\\", \\\"{x:1162,y:524,t:1527268559888};\\\", \\\"{x:1341,y:535,t:1527268559904};\\\", \\\"{x:1498,y:553,t:1527268559921};\\\", \\\"{x:1696,y:582,t:1527268559937};\\\", \\\"{x:1807,y:598,t:1527268559954};\\\", \\\"{x:1882,y:607,t:1527268559971};\\\", \\\"{x:1909,y:607,t:1527268559988};\\\", \\\"{x:1919,y:607,t:1527268560004};\\\", \\\"{x:1919,y:606,t:1527268560025};\\\", \\\"{x:1919,y:605,t:1527268560050};\\\", \\\"{x:1919,y:603,t:1527268560131};\\\", \\\"{x:1919,y:600,t:1527268560140};\\\", \\\"{x:1919,y:588,t:1527268560157};\\\", \\\"{x:1915,y:571,t:1527268560173};\\\", \\\"{x:1902,y:551,t:1527268560190};\\\", \\\"{x:1887,y:531,t:1527268560206};\\\", \\\"{x:1872,y:515,t:1527268560223};\\\", \\\"{x:1858,y:499,t:1527268560240};\\\", \\\"{x:1841,y:486,t:1527268560257};\\\", \\\"{x:1829,y:480,t:1527268560273};\\\", \\\"{x:1815,y:469,t:1527268560290};\\\", \\\"{x:1809,y:465,t:1527268560307};\\\", \\\"{x:1801,y:463,t:1527268560323};\\\", \\\"{x:1797,y:462,t:1527268560340};\\\", \\\"{x:1788,y:459,t:1527268560356};\\\", \\\"{x:1779,y:458,t:1527268560373};\\\", \\\"{x:1770,y:454,t:1527268560390};\\\", \\\"{x:1761,y:452,t:1527268560407};\\\", \\\"{x:1753,y:449,t:1527268560423};\\\", \\\"{x:1750,y:449,t:1527268560440};\\\", \\\"{x:1748,y:448,t:1527268560457};\\\", \\\"{x:1747,y:448,t:1527268560546};\\\", \\\"{x:1747,y:447,t:1527268560603};\\\", \\\"{x:1747,y:446,t:1527268560610};\\\", \\\"{x:1750,y:445,t:1527268560624};\\\", \\\"{x:1753,y:445,t:1527268560640};\\\", \\\"{x:1756,y:445,t:1527268560723};\\\", \\\"{x:1757,y:445,t:1527268560730};\\\", \\\"{x:1760,y:443,t:1527268560740};\\\", \\\"{x:1763,y:442,t:1527268560757};\\\", \\\"{x:1764,y:442,t:1527268560774};\\\", \\\"{x:1766,y:441,t:1527268560835};\\\", \\\"{x:1769,y:440,t:1527268560842};\\\", \\\"{x:1771,y:439,t:1527268560857};\\\", \\\"{x:1772,y:438,t:1527268560874};\\\", \\\"{x:1769,y:439,t:1527268561107};\\\", \\\"{x:1763,y:440,t:1527268561124};\\\", \\\"{x:1758,y:444,t:1527268561141};\\\", \\\"{x:1753,y:444,t:1527268561157};\\\", \\\"{x:1749,y:445,t:1527268561175};\\\", \\\"{x:1745,y:447,t:1527268561191};\\\", \\\"{x:1742,y:447,t:1527268561206};\\\", \\\"{x:1738,y:448,t:1527268561223};\\\", \\\"{x:1737,y:449,t:1527268561240};\\\", \\\"{x:1735,y:449,t:1527268561256};\\\", \\\"{x:1734,y:449,t:1527268561273};\\\", \\\"{x:1732,y:449,t:1527268561290};\\\", \\\"{x:1730,y:450,t:1527268561307};\\\", \\\"{x:1729,y:450,t:1527268561323};\\\", \\\"{x:1728,y:450,t:1527268561341};\\\", \\\"{x:1727,y:450,t:1527268561356};\\\", \\\"{x:1726,y:450,t:1527268561373};\\\", \\\"{x:1725,y:451,t:1527268561635};\\\", \\\"{x:1722,y:451,t:1527268561642};\\\", \\\"{x:1721,y:452,t:1527268561657};\\\", \\\"{x:1719,y:453,t:1527268561673};\\\", \\\"{x:1718,y:453,t:1527268561691};\\\", \\\"{x:1716,y:454,t:1527268561708};\\\", \\\"{x:1715,y:454,t:1527268561730};\\\", \\\"{x:1714,y:454,t:1527268561754};\\\", \\\"{x:1713,y:455,t:1527268561762};\\\", \\\"{x:1711,y:456,t:1527268561795};\\\", \\\"{x:1710,y:456,t:1527268561810};\\\", \\\"{x:1709,y:457,t:1527268561824};\\\", \\\"{x:1707,y:457,t:1527268561841};\\\", \\\"{x:1701,y:460,t:1527268561857};\\\", \\\"{x:1699,y:461,t:1527268561873};\\\", \\\"{x:1697,y:462,t:1527268561890};\\\", \\\"{x:1695,y:463,t:1527268561908};\\\", \\\"{x:1691,y:465,t:1527268561925};\\\", \\\"{x:1688,y:467,t:1527268561941};\\\", \\\"{x:1680,y:472,t:1527268561958};\\\", \\\"{x:1670,y:477,t:1527268561975};\\\", \\\"{x:1663,y:480,t:1527268561991};\\\", \\\"{x:1657,y:483,t:1527268562008};\\\", \\\"{x:1649,y:487,t:1527268562025};\\\", \\\"{x:1640,y:495,t:1527268562041};\\\", \\\"{x:1634,y:503,t:1527268562058};\\\", \\\"{x:1626,y:514,t:1527268562075};\\\", \\\"{x:1619,y:525,t:1527268562091};\\\", \\\"{x:1609,y:539,t:1527268562108};\\\", \\\"{x:1600,y:551,t:1527268562125};\\\", \\\"{x:1594,y:558,t:1527268562141};\\\", \\\"{x:1589,y:564,t:1527268562157};\\\", \\\"{x:1586,y:567,t:1527268562175};\\\", \\\"{x:1583,y:570,t:1527268562191};\\\", \\\"{x:1577,y:570,t:1527268562208};\\\", \\\"{x:1573,y:571,t:1527268562225};\\\", \\\"{x:1568,y:571,t:1527268562241};\\\", \\\"{x:1551,y:571,t:1527268562258};\\\", \\\"{x:1540,y:569,t:1527268562275};\\\", \\\"{x:1525,y:565,t:1527268562291};\\\", \\\"{x:1511,y:559,t:1527268562309};\\\", \\\"{x:1495,y:552,t:1527268562325};\\\", \\\"{x:1483,y:544,t:1527268562341};\\\", \\\"{x:1473,y:538,t:1527268562358};\\\", \\\"{x:1468,y:533,t:1527268562376};\\\", \\\"{x:1462,y:524,t:1527268562391};\\\", \\\"{x:1459,y:517,t:1527268562409};\\\", \\\"{x:1457,y:510,t:1527268562425};\\\", \\\"{x:1457,y:505,t:1527268562441};\\\", \\\"{x:1456,y:500,t:1527268562458};\\\", \\\"{x:1456,y:498,t:1527268562475};\\\", \\\"{x:1456,y:495,t:1527268562491};\\\", \\\"{x:1456,y:492,t:1527268562508};\\\", \\\"{x:1456,y:489,t:1527268562526};\\\", \\\"{x:1457,y:485,t:1527268562542};\\\", \\\"{x:1457,y:480,t:1527268562558};\\\", \\\"{x:1458,y:477,t:1527268562576};\\\", \\\"{x:1459,y:475,t:1527268562593};\\\", \\\"{x:1460,y:472,t:1527268562609};\\\", \\\"{x:1461,y:468,t:1527268562626};\\\", \\\"{x:1461,y:459,t:1527268562643};\\\", \\\"{x:1461,y:455,t:1527268562658};\\\", \\\"{x:1461,y:452,t:1527268562675};\\\", \\\"{x:1461,y:450,t:1527268562692};\\\", \\\"{x:1461,y:449,t:1527268562708};\\\", \\\"{x:1461,y:448,t:1527268562738};\\\", \\\"{x:1461,y:446,t:1527268562762};\\\", \\\"{x:1461,y:445,t:1527268562778};\\\", \\\"{x:1461,y:443,t:1527268562794};\\\", \\\"{x:1461,y:442,t:1527268562810};\\\", \\\"{x:1461,y:441,t:1527268562825};\\\", \\\"{x:1461,y:439,t:1527268562843};\\\", \\\"{x:1461,y:437,t:1527268562859};\\\", \\\"{x:1461,y:434,t:1527268562875};\\\", \\\"{x:1462,y:430,t:1527268562892};\\\", \\\"{x:1465,y:427,t:1527268562909};\\\", \\\"{x:1469,y:423,t:1527268562925};\\\", \\\"{x:1475,y:420,t:1527268562943};\\\", \\\"{x:1480,y:416,t:1527268562959};\\\", \\\"{x:1487,y:413,t:1527268562976};\\\", \\\"{x:1498,y:408,t:1527268562992};\\\", \\\"{x:1510,y:403,t:1527268563010};\\\", \\\"{x:1518,y:401,t:1527268563025};\\\", \\\"{x:1526,y:401,t:1527268563042};\\\", \\\"{x:1530,y:398,t:1527268563059};\\\", \\\"{x:1538,y:395,t:1527268563076};\\\", \\\"{x:1541,y:394,t:1527268563092};\\\", \\\"{x:1545,y:393,t:1527268563109};\\\", \\\"{x:1546,y:393,t:1527268563125};\\\", \\\"{x:1547,y:392,t:1527268563142};\\\", \\\"{x:1549,y:392,t:1527268563282};\\\", \\\"{x:1550,y:393,t:1527268563293};\\\", \\\"{x:1555,y:396,t:1527268563309};\\\", \\\"{x:1558,y:396,t:1527268563325};\\\", \\\"{x:1562,y:396,t:1527268563342};\\\", \\\"{x:1564,y:397,t:1527268563359};\\\", \\\"{x:1566,y:397,t:1527268563377};\\\", \\\"{x:1567,y:398,t:1527268563392};\\\", \\\"{x:1571,y:400,t:1527268564162};\\\", \\\"{x:1579,y:408,t:1527268564176};\\\", \\\"{x:1587,y:418,t:1527268564193};\\\", \\\"{x:1593,y:430,t:1527268564210};\\\", \\\"{x:1605,y:460,t:1527268564227};\\\", \\\"{x:1618,y:503,t:1527268564243};\\\", \\\"{x:1628,y:542,t:1527268564261};\\\", \\\"{x:1638,y:573,t:1527268564277};\\\", \\\"{x:1648,y:605,t:1527268564294};\\\", \\\"{x:1661,y:647,t:1527268564310};\\\", \\\"{x:1679,y:704,t:1527268564327};\\\", \\\"{x:1695,y:752,t:1527268564343};\\\", \\\"{x:1707,y:796,t:1527268564360};\\\", \\\"{x:1715,y:837,t:1527268564376};\\\", \\\"{x:1718,y:859,t:1527268564394};\\\", \\\"{x:1718,y:878,t:1527268564410};\\\", \\\"{x:1717,y:885,t:1527268564426};\\\", \\\"{x:1706,y:889,t:1527268564443};\\\", \\\"{x:1684,y:895,t:1527268564461};\\\", \\\"{x:1657,y:906,t:1527268564476};\\\", \\\"{x:1621,y:919,t:1527268564494};\\\", \\\"{x:1600,y:928,t:1527268564511};\\\", \\\"{x:1588,y:933,t:1527268564527};\\\", \\\"{x:1583,y:935,t:1527268564543};\\\", \\\"{x:1578,y:938,t:1527268564560};\\\", \\\"{x:1577,y:938,t:1527268564576};\\\", \\\"{x:1575,y:939,t:1527268564593};\\\", \\\"{x:1568,y:942,t:1527268564611};\\\", \\\"{x:1560,y:943,t:1527268564627};\\\", \\\"{x:1550,y:945,t:1527268564643};\\\", \\\"{x:1536,y:946,t:1527268564660};\\\", \\\"{x:1520,y:946,t:1527268564677};\\\", \\\"{x:1500,y:946,t:1527268564694};\\\", \\\"{x:1472,y:942,t:1527268564710};\\\", \\\"{x:1441,y:932,t:1527268564727};\\\", \\\"{x:1393,y:918,t:1527268564744};\\\", \\\"{x:1346,y:906,t:1527268564760};\\\", \\\"{x:1301,y:892,t:1527268564776};\\\", \\\"{x:1267,y:882,t:1527268564794};\\\", \\\"{x:1232,y:870,t:1527268564810};\\\", \\\"{x:1221,y:862,t:1527268564827};\\\", \\\"{x:1218,y:856,t:1527268564843};\\\", \\\"{x:1216,y:852,t:1527268564860};\\\", \\\"{x:1216,y:845,t:1527268564877};\\\", \\\"{x:1217,y:839,t:1527268564893};\\\", \\\"{x:1220,y:832,t:1527268564910};\\\", \\\"{x:1223,y:826,t:1527268564927};\\\", \\\"{x:1228,y:819,t:1527268564944};\\\", \\\"{x:1232,y:813,t:1527268564961};\\\", \\\"{x:1236,y:810,t:1527268564978};\\\", \\\"{x:1237,y:808,t:1527268564993};\\\", \\\"{x:1239,y:804,t:1527268565010};\\\", \\\"{x:1243,y:802,t:1527268565027};\\\", \\\"{x:1251,y:796,t:1527268565044};\\\", \\\"{x:1263,y:791,t:1527268565060};\\\", \\\"{x:1283,y:785,t:1527268565077};\\\", \\\"{x:1300,y:780,t:1527268565093};\\\", \\\"{x:1314,y:776,t:1527268565110};\\\", \\\"{x:1331,y:775,t:1527268565127};\\\", \\\"{x:1345,y:774,t:1527268565144};\\\", \\\"{x:1361,y:774,t:1527268565161};\\\", \\\"{x:1376,y:774,t:1527268565177};\\\", \\\"{x:1391,y:774,t:1527268565194};\\\", \\\"{x:1394,y:774,t:1527268565210};\\\", \\\"{x:1395,y:774,t:1527268565227};\\\", \\\"{x:1397,y:774,t:1527268565244};\\\", \\\"{x:1397,y:777,t:1527268565261};\\\", \\\"{x:1396,y:783,t:1527268565278};\\\", \\\"{x:1384,y:795,t:1527268565294};\\\", \\\"{x:1371,y:804,t:1527268565311};\\\", \\\"{x:1354,y:810,t:1527268565327};\\\", \\\"{x:1334,y:817,t:1527268565344};\\\", \\\"{x:1309,y:819,t:1527268565360};\\\", \\\"{x:1263,y:819,t:1527268565377};\\\", \\\"{x:1214,y:819,t:1527268565395};\\\", \\\"{x:1189,y:814,t:1527268565411};\\\", \\\"{x:1162,y:811,t:1527268565427};\\\", \\\"{x:1141,y:806,t:1527268565444};\\\", \\\"{x:1129,y:802,t:1527268565460};\\\", \\\"{x:1125,y:799,t:1527268565478};\\\", \\\"{x:1125,y:795,t:1527268565495};\\\", \\\"{x:1128,y:783,t:1527268565510};\\\", \\\"{x:1144,y:767,t:1527268565528};\\\", \\\"{x:1174,y:746,t:1527268565544};\\\", \\\"{x:1216,y:720,t:1527268565561};\\\", \\\"{x:1275,y:690,t:1527268565577};\\\", \\\"{x:1419,y:645,t:1527268565594};\\\", \\\"{x:1523,y:627,t:1527268565612};\\\", \\\"{x:1642,y:610,t:1527268565628};\\\", \\\"{x:1750,y:610,t:1527268565644};\\\", \\\"{x:1850,y:610,t:1527268565661};\\\", \\\"{x:1919,y:619,t:1527268565677};\\\", \\\"{x:1919,y:638,t:1527268565694};\\\", \\\"{x:1919,y:661,t:1527268565710};\\\", \\\"{x:1919,y:687,t:1527268565726};\\\", \\\"{x:1919,y:711,t:1527268565744};\\\", \\\"{x:1919,y:734,t:1527268565761};\\\", \\\"{x:1919,y:756,t:1527268565777};\\\", \\\"{x:1919,y:787,t:1527268565794};\\\", \\\"{x:1919,y:802,t:1527268565810};\\\", \\\"{x:1915,y:815,t:1527268565826};\\\", \\\"{x:1903,y:832,t:1527268565844};\\\", \\\"{x:1889,y:843,t:1527268565861};\\\", \\\"{x:1872,y:853,t:1527268565877};\\\", \\\"{x:1852,y:864,t:1527268565894};\\\", \\\"{x:1829,y:875,t:1527268565911};\\\", \\\"{x:1804,y:885,t:1527268565927};\\\", \\\"{x:1784,y:891,t:1527268565944};\\\", \\\"{x:1768,y:894,t:1527268565961};\\\", \\\"{x:1759,y:897,t:1527268565977};\\\", \\\"{x:1752,y:900,t:1527268565993};\\\", \\\"{x:1751,y:900,t:1527268566011};\\\", \\\"{x:1749,y:901,t:1527268566026};\\\", \\\"{x:1745,y:902,t:1527268566044};\\\", \\\"{x:1742,y:902,t:1527268566060};\\\", \\\"{x:1738,y:896,t:1527268566077};\\\", \\\"{x:1735,y:888,t:1527268566094};\\\", \\\"{x:1731,y:875,t:1527268566111};\\\", \\\"{x:1727,y:856,t:1527268566128};\\\", \\\"{x:1725,y:832,t:1527268566143};\\\", \\\"{x:1720,y:804,t:1527268566161};\\\", \\\"{x:1713,y:754,t:1527268566178};\\\", \\\"{x:1707,y:714,t:1527268566194};\\\", \\\"{x:1691,y:664,t:1527268566211};\\\", \\\"{x:1667,y:606,t:1527268566228};\\\", \\\"{x:1637,y:552,t:1527268566244};\\\", \\\"{x:1605,y:502,t:1527268566261};\\\", \\\"{x:1573,y:454,t:1527268566278};\\\", \\\"{x:1538,y:413,t:1527268566294};\\\", \\\"{x:1517,y:389,t:1527268566311};\\\", \\\"{x:1497,y:366,t:1527268566328};\\\", \\\"{x:1480,y:345,t:1527268566344};\\\", \\\"{x:1467,y:329,t:1527268566362};\\\", \\\"{x:1466,y:326,t:1527268566378};\\\", \\\"{x:1463,y:320,t:1527268566395};\\\", \\\"{x:1462,y:315,t:1527268566411};\\\", \\\"{x:1462,y:311,t:1527268566428};\\\", \\\"{x:1465,y:304,t:1527268566444};\\\", \\\"{x:1474,y:293,t:1527268566461};\\\", \\\"{x:1486,y:279,t:1527268566479};\\\", \\\"{x:1496,y:270,t:1527268566494};\\\", \\\"{x:1506,y:260,t:1527268566512};\\\", \\\"{x:1516,y:254,t:1527268566528};\\\", \\\"{x:1530,y:244,t:1527268566545};\\\", \\\"{x:1538,y:239,t:1527268566562};\\\", \\\"{x:1548,y:235,t:1527268566578};\\\", \\\"{x:1552,y:234,t:1527268566596};\\\", \\\"{x:1555,y:234,t:1527268566611};\\\", \\\"{x:1556,y:233,t:1527268566628};\\\", \\\"{x:1558,y:233,t:1527268566658};\\\", \\\"{x:1559,y:233,t:1527268566674};\\\", \\\"{x:1560,y:235,t:1527268566682};\\\", \\\"{x:1562,y:236,t:1527268566696};\\\", \\\"{x:1568,y:244,t:1527268566711};\\\", \\\"{x:1572,y:250,t:1527268566728};\\\", \\\"{x:1575,y:252,t:1527268566745};\\\", \\\"{x:1577,y:254,t:1527268566761};\\\", \\\"{x:1579,y:259,t:1527268566778};\\\", \\\"{x:1581,y:263,t:1527268566796};\\\", \\\"{x:1582,y:268,t:1527268566812};\\\", \\\"{x:1582,y:271,t:1527268566828};\\\", \\\"{x:1582,y:273,t:1527268566845};\\\", \\\"{x:1582,y:275,t:1527268566862};\\\", \\\"{x:1582,y:277,t:1527268566879};\\\", \\\"{x:1582,y:279,t:1527268566895};\\\", \\\"{x:1582,y:280,t:1527268566913};\\\", \\\"{x:1582,y:281,t:1527268566928};\\\", \\\"{x:1582,y:282,t:1527268566945};\\\", \\\"{x:1582,y:283,t:1527268567017};\\\", \\\"{x:1582,y:284,t:1527268567033};\\\", \\\"{x:1581,y:285,t:1527268567066};\\\", \\\"{x:1580,y:285,t:1527268567082};\\\", \\\"{x:1580,y:286,t:1527268567095};\\\", \\\"{x:1579,y:287,t:1527268567112};\\\", \\\"{x:1578,y:288,t:1527268567128};\\\", \\\"{x:1578,y:294,t:1527268567145};\\\", \\\"{x:1578,y:316,t:1527268567161};\\\", \\\"{x:1585,y:332,t:1527268567178};\\\", \\\"{x:1592,y:348,t:1527268567195};\\\", \\\"{x:1598,y:365,t:1527268567213};\\\", \\\"{x:1606,y:381,t:1527268567229};\\\", \\\"{x:1612,y:397,t:1527268567246};\\\", \\\"{x:1620,y:412,t:1527268567263};\\\", \\\"{x:1625,y:428,t:1527268567278};\\\", \\\"{x:1634,y:447,t:1527268567295};\\\", \\\"{x:1642,y:466,t:1527268567313};\\\", \\\"{x:1650,y:485,t:1527268567328};\\\", \\\"{x:1656,y:498,t:1527268567346};\\\", \\\"{x:1661,y:511,t:1527268567362};\\\", \\\"{x:1664,y:521,t:1527268567379};\\\", \\\"{x:1667,y:532,t:1527268567395};\\\", \\\"{x:1671,y:546,t:1527268567412};\\\", \\\"{x:1675,y:562,t:1527268567428};\\\", \\\"{x:1676,y:580,t:1527268567445};\\\", \\\"{x:1679,y:595,t:1527268567462};\\\", \\\"{x:1681,y:615,t:1527268567479};\\\", \\\"{x:1684,y:631,t:1527268567495};\\\", \\\"{x:1686,y:648,t:1527268567512};\\\", \\\"{x:1687,y:662,t:1527268567529};\\\", \\\"{x:1687,y:677,t:1527268567545};\\\", \\\"{x:1687,y:708,t:1527268567562};\\\", \\\"{x:1687,y:726,t:1527268567578};\\\", \\\"{x:1687,y:745,t:1527268567594};\\\", \\\"{x:1685,y:761,t:1527268567612};\\\", \\\"{x:1683,y:778,t:1527268567629};\\\", \\\"{x:1680,y:797,t:1527268567645};\\\", \\\"{x:1678,y:814,t:1527268567662};\\\", \\\"{x:1675,y:831,t:1527268567679};\\\", \\\"{x:1673,y:846,t:1527268567694};\\\", \\\"{x:1672,y:855,t:1527268567712};\\\", \\\"{x:1672,y:863,t:1527268567729};\\\", \\\"{x:1670,y:871,t:1527268567745};\\\", \\\"{x:1669,y:877,t:1527268567762};\\\", \\\"{x:1669,y:878,t:1527268567779};\\\", \\\"{x:1669,y:879,t:1527268567802};\\\", \\\"{x:1669,y:880,t:1527268567818};\\\", \\\"{x:1669,y:881,t:1527268567899};\\\", \\\"{x:1670,y:881,t:1527268568162};\\\", \\\"{x:1670,y:879,t:1527268568179};\\\", \\\"{x:1671,y:877,t:1527268568196};\\\", \\\"{x:1671,y:874,t:1527268568212};\\\", \\\"{x:1671,y:870,t:1527268568229};\\\", \\\"{x:1671,y:867,t:1527268568246};\\\", \\\"{x:1671,y:862,t:1527268568262};\\\", \\\"{x:1671,y:858,t:1527268568279};\\\", \\\"{x:1669,y:854,t:1527268568296};\\\", \\\"{x:1666,y:851,t:1527268568313};\\\", \\\"{x:1661,y:845,t:1527268568330};\\\", \\\"{x:1658,y:842,t:1527268568346};\\\", \\\"{x:1654,y:838,t:1527268568363};\\\", \\\"{x:1649,y:833,t:1527268568379};\\\", \\\"{x:1641,y:827,t:1527268568396};\\\", \\\"{x:1636,y:824,t:1527268568413};\\\", \\\"{x:1628,y:819,t:1527268568428};\\\", \\\"{x:1624,y:816,t:1527268568446};\\\", \\\"{x:1616,y:813,t:1527268568463};\\\", \\\"{x:1607,y:808,t:1527268568479};\\\", \\\"{x:1603,y:807,t:1527268568496};\\\", \\\"{x:1602,y:807,t:1527268568513};\\\", \\\"{x:1601,y:806,t:1527268568745};\\\", \\\"{x:1599,y:803,t:1527268568763};\\\", \\\"{x:1597,y:800,t:1527268568779};\\\", \\\"{x:1595,y:798,t:1527268568796};\\\", \\\"{x:1595,y:795,t:1527268568813};\\\", \\\"{x:1593,y:793,t:1527268568829};\\\", \\\"{x:1592,y:792,t:1527268568846};\\\", \\\"{x:1591,y:791,t:1527268568863};\\\", \\\"{x:1590,y:788,t:1527268568879};\\\", \\\"{x:1589,y:786,t:1527268568897};\\\", \\\"{x:1588,y:785,t:1527268568913};\\\", \\\"{x:1586,y:783,t:1527268568930};\\\", \\\"{x:1586,y:782,t:1527268568946};\\\", \\\"{x:1585,y:782,t:1527268568971};\\\", \\\"{x:1585,y:780,t:1527268568986};\\\", \\\"{x:1584,y:779,t:1527268568997};\\\", \\\"{x:1584,y:778,t:1527268569014};\\\", \\\"{x:1583,y:776,t:1527268569030};\\\", \\\"{x:1582,y:775,t:1527268569046};\\\", \\\"{x:1581,y:773,t:1527268569063};\\\", \\\"{x:1580,y:772,t:1527268569080};\\\", \\\"{x:1580,y:770,t:1527268569097};\\\", \\\"{x:1579,y:770,t:1527268569113};\\\", \\\"{x:1578,y:768,t:1527268569130};\\\", \\\"{x:1578,y:767,t:1527268569170};\\\", \\\"{x:1577,y:767,t:1527268569283};\\\", \\\"{x:1577,y:765,t:1527268569955};\\\", \\\"{x:1577,y:763,t:1527268569964};\\\", \\\"{x:1577,y:755,t:1527268569980};\\\", \\\"{x:1577,y:742,t:1527268569997};\\\", \\\"{x:1577,y:731,t:1527268570015};\\\", \\\"{x:1577,y:720,t:1527268570031};\\\", \\\"{x:1577,y:716,t:1527268570047};\\\", \\\"{x:1577,y:713,t:1527268570065};\\\", \\\"{x:1578,y:711,t:1527268570081};\\\", \\\"{x:1578,y:709,t:1527268570097};\\\", \\\"{x:1579,y:706,t:1527268570114};\\\", \\\"{x:1579,y:705,t:1527268570130};\\\", \\\"{x:1580,y:704,t:1527268570147};\\\", \\\"{x:1581,y:704,t:1527268570186};\\\", \\\"{x:1581,y:703,t:1527268570198};\\\", \\\"{x:1582,y:703,t:1527268570215};\\\", \\\"{x:1583,y:702,t:1527268570230};\\\", \\\"{x:1585,y:701,t:1527268570248};\\\", \\\"{x:1586,y:701,t:1527268570265};\\\", \\\"{x:1587,y:701,t:1527268570281};\\\", \\\"{x:1589,y:699,t:1527268570298};\\\", \\\"{x:1591,y:699,t:1527268570314};\\\", \\\"{x:1593,y:699,t:1527268570338};\\\", \\\"{x:1594,y:698,t:1527268570348};\\\", \\\"{x:1595,y:698,t:1527268570403};\\\", \\\"{x:1596,y:698,t:1527268570414};\\\", \\\"{x:1600,y:695,t:1527268570432};\\\", \\\"{x:1605,y:692,t:1527268570447};\\\", \\\"{x:1609,y:690,t:1527268570465};\\\", \\\"{x:1612,y:688,t:1527268570482};\\\", \\\"{x:1616,y:684,t:1527268570498};\\\", \\\"{x:1617,y:684,t:1527268570659};\\\", \\\"{x:1618,y:684,t:1527268570674};\\\", \\\"{x:1620,y:684,t:1527268570706};\\\", \\\"{x:1620,y:685,t:1527268570714};\\\", \\\"{x:1621,y:686,t:1527268570732};\\\", \\\"{x:1621,y:690,t:1527268570748};\\\", \\\"{x:1621,y:693,t:1527268570765};\\\", \\\"{x:1621,y:695,t:1527268570782};\\\", \\\"{x:1621,y:698,t:1527268570798};\\\", \\\"{x:1621,y:700,t:1527268570834};\\\", \\\"{x:1621,y:699,t:1527268571113};\\\", \\\"{x:1621,y:698,t:1527268571153};\\\", \\\"{x:1619,y:698,t:1527268571322};\\\", \\\"{x:1619,y:697,t:1527268571348};\\\", \\\"{x:1615,y:696,t:1527268571366};\\\", \\\"{x:1614,y:695,t:1527268571381};\\\", \\\"{x:1612,y:694,t:1527268571397};\\\", \\\"{x:1611,y:693,t:1527268571415};\\\", \\\"{x:1610,y:693,t:1527268571431};\\\", \\\"{x:1610,y:692,t:1527268571449};\\\", \\\"{x:1609,y:691,t:1527268571465};\\\", \\\"{x:1608,y:691,t:1527268571482};\\\", \\\"{x:1607,y:690,t:1527268571499};\\\", \\\"{x:1606,y:690,t:1527268571515};\\\", \\\"{x:1606,y:691,t:1527268571810};\\\", \\\"{x:1606,y:692,t:1527268571818};\\\", \\\"{x:1606,y:694,t:1527268571833};\\\", \\\"{x:1606,y:698,t:1527268571849};\\\", \\\"{x:1606,y:701,t:1527268571865};\\\", \\\"{x:1606,y:705,t:1527268571881};\\\", \\\"{x:1606,y:706,t:1527268571905};\\\", \\\"{x:1606,y:707,t:1527268571937};\\\", \\\"{x:1606,y:708,t:1527268571953};\\\", \\\"{x:1606,y:709,t:1527268571977};\\\", \\\"{x:1606,y:710,t:1527268571993};\\\", \\\"{x:1606,y:711,t:1527268572001};\\\", \\\"{x:1606,y:712,t:1527268572015};\\\", \\\"{x:1606,y:713,t:1527268572032};\\\", \\\"{x:1606,y:717,t:1527268572048};\\\", \\\"{x:1610,y:727,t:1527268572065};\\\", \\\"{x:1610,y:735,t:1527268572082};\\\", \\\"{x:1611,y:742,t:1527268572098};\\\", \\\"{x:1612,y:746,t:1527268572115};\\\", \\\"{x:1614,y:752,t:1527268572132};\\\", \\\"{x:1616,y:758,t:1527268572148};\\\", \\\"{x:1617,y:763,t:1527268572166};\\\", \\\"{x:1619,y:769,t:1527268572183};\\\", \\\"{x:1622,y:775,t:1527268572198};\\\", \\\"{x:1624,y:784,t:1527268572215};\\\", \\\"{x:1625,y:795,t:1527268572233};\\\", \\\"{x:1627,y:807,t:1527268572249};\\\", \\\"{x:1628,y:820,t:1527268572266};\\\", \\\"{x:1628,y:831,t:1527268572282};\\\", \\\"{x:1628,y:839,t:1527268572299};\\\", \\\"{x:1631,y:845,t:1527268572316};\\\", \\\"{x:1631,y:847,t:1527268572379};\\\", \\\"{x:1632,y:848,t:1527268572393};\\\", \\\"{x:1633,y:850,t:1527268572402};\\\", \\\"{x:1633,y:852,t:1527268572416};\\\", \\\"{x:1635,y:857,t:1527268572432};\\\", \\\"{x:1636,y:864,t:1527268572449};\\\", \\\"{x:1639,y:879,t:1527268572466};\\\", \\\"{x:1639,y:884,t:1527268572483};\\\", \\\"{x:1639,y:889,t:1527268572500};\\\", \\\"{x:1639,y:893,t:1527268572515};\\\", \\\"{x:1639,y:898,t:1527268572533};\\\", \\\"{x:1639,y:903,t:1527268572550};\\\", \\\"{x:1639,y:905,t:1527268572567};\\\", \\\"{x:1639,y:908,t:1527268572583};\\\", \\\"{x:1639,y:911,t:1527268572600};\\\", \\\"{x:1638,y:913,t:1527268572615};\\\", \\\"{x:1638,y:914,t:1527268572633};\\\", \\\"{x:1638,y:915,t:1527268572650};\\\", \\\"{x:1638,y:916,t:1527268572666};\\\", \\\"{x:1637,y:917,t:1527268572683};\\\", \\\"{x:1637,y:918,t:1527268572714};\\\", \\\"{x:1636,y:918,t:1527268572819};\\\", \\\"{x:1634,y:915,t:1527268572833};\\\", \\\"{x:1630,y:901,t:1527268572850};\\\", \\\"{x:1628,y:891,t:1527268572866};\\\", \\\"{x:1627,y:875,t:1527268572883};\\\", \\\"{x:1625,y:861,t:1527268572900};\\\", \\\"{x:1625,y:838,t:1527268572916};\\\", \\\"{x:1625,y:810,t:1527268572933};\\\", \\\"{x:1623,y:793,t:1527268572950};\\\", \\\"{x:1623,y:785,t:1527268572967};\\\", \\\"{x:1623,y:780,t:1527268572983};\\\", \\\"{x:1623,y:778,t:1527268573000};\\\", \\\"{x:1623,y:777,t:1527268573017};\\\", \\\"{x:1621,y:779,t:1527268573210};\\\", \\\"{x:1621,y:783,t:1527268573218};\\\", \\\"{x:1618,y:791,t:1527268573234};\\\", \\\"{x:1618,y:799,t:1527268573250};\\\", \\\"{x:1618,y:814,t:1527268573266};\\\", \\\"{x:1618,y:831,t:1527268573284};\\\", \\\"{x:1618,y:851,t:1527268573300};\\\", \\\"{x:1618,y:866,t:1527268573317};\\\", \\\"{x:1618,y:880,t:1527268573334};\\\", \\\"{x:1618,y:890,t:1527268573350};\\\", \\\"{x:1618,y:897,t:1527268573366};\\\", \\\"{x:1618,y:902,t:1527268573383};\\\", \\\"{x:1617,y:908,t:1527268573400};\\\", \\\"{x:1616,y:911,t:1527268573417};\\\", \\\"{x:1615,y:915,t:1527268573434};\\\", \\\"{x:1613,y:920,t:1527268573450};\\\", \\\"{x:1611,y:923,t:1527268573466};\\\", \\\"{x:1609,y:928,t:1527268573484};\\\", \\\"{x:1606,y:935,t:1527268573500};\\\", \\\"{x:1606,y:940,t:1527268573517};\\\", \\\"{x:1605,y:943,t:1527268573534};\\\", \\\"{x:1601,y:949,t:1527268573550};\\\", \\\"{x:1599,y:953,t:1527268573567};\\\", \\\"{x:1597,y:955,t:1527268573584};\\\", \\\"{x:1596,y:958,t:1527268573600};\\\", \\\"{x:1594,y:962,t:1527268573617};\\\", \\\"{x:1587,y:968,t:1527268573634};\\\", \\\"{x:1583,y:970,t:1527268573649};\\\", \\\"{x:1573,y:977,t:1527268573666};\\\", \\\"{x:1561,y:984,t:1527268573683};\\\", \\\"{x:1558,y:987,t:1527268573701};\\\", \\\"{x:1557,y:989,t:1527268573717};\\\", \\\"{x:1557,y:990,t:1527268573734};\\\", \\\"{x:1556,y:998,t:1527268573751};\\\", \\\"{x:1555,y:1003,t:1527268573767};\\\", \\\"{x:1559,y:1004,t:1527268576836};\\\", \\\"{x:1574,y:997,t:1527268576844};\\\", \\\"{x:1593,y:986,t:1527268576856};\\\", \\\"{x:1612,y:974,t:1527268576872};\\\", \\\"{x:1618,y:970,t:1527268576889};\\\", \\\"{x:1637,y:965,t:1527268576906};\\\", \\\"{x:1660,y:960,t:1527268576922};\\\", \\\"{x:1667,y:959,t:1527268576939};\\\", \\\"{x:1669,y:958,t:1527268576956};\\\", \\\"{x:1667,y:960,t:1527268577150};\\\", \\\"{x:1663,y:965,t:1527268577157};\\\", \\\"{x:1653,y:973,t:1527268577174};\\\", \\\"{x:1646,y:978,t:1527268577189};\\\", \\\"{x:1641,y:981,t:1527268577207};\\\", \\\"{x:1639,y:982,t:1527268577224};\\\", \\\"{x:1638,y:982,t:1527268577261};\\\", \\\"{x:1636,y:977,t:1527268577277};\\\", \\\"{x:1633,y:966,t:1527268577290};\\\", \\\"{x:1628,y:937,t:1527268577306};\\\", \\\"{x:1624,y:908,t:1527268577324};\\\", \\\"{x:1622,y:894,t:1527268577339};\\\", \\\"{x:1621,y:889,t:1527268577357};\\\", \\\"{x:1621,y:887,t:1527268577373};\\\", \\\"{x:1620,y:886,t:1527268577421};\\\", \\\"{x:1618,y:886,t:1527268577437};\\\", \\\"{x:1613,y:892,t:1527268577446};\\\", \\\"{x:1607,y:898,t:1527268577456};\\\", \\\"{x:1599,y:909,t:1527268577473};\\\", \\\"{x:1592,y:921,t:1527268577490};\\\", \\\"{x:1588,y:926,t:1527268577507};\\\", \\\"{x:1572,y:941,t:1527268577523};\\\", \\\"{x:1564,y:947,t:1527268577540};\\\", \\\"{x:1566,y:947,t:1527268577686};\\\", \\\"{x:1569,y:949,t:1527268577693};\\\", \\\"{x:1572,y:950,t:1527268577706};\\\", \\\"{x:1583,y:951,t:1527268577723};\\\", \\\"{x:1595,y:954,t:1527268577741};\\\", \\\"{x:1607,y:955,t:1527268577757};\\\", \\\"{x:1622,y:956,t:1527268577774};\\\", \\\"{x:1625,y:956,t:1527268577789};\\\", \\\"{x:1626,y:956,t:1527268577806};\\\", \\\"{x:1625,y:959,t:1527268577958};\\\", \\\"{x:1622,y:963,t:1527268577973};\\\", \\\"{x:1621,y:964,t:1527268577990};\\\", \\\"{x:1621,y:965,t:1527268578008};\\\", \\\"{x:1620,y:965,t:1527268578029};\\\", \\\"{x:1619,y:966,t:1527268578040};\\\", \\\"{x:1618,y:966,t:1527268578597};\\\", \\\"{x:1617,y:966,t:1527268578613};\\\", \\\"{x:1616,y:966,t:1527268578645};\\\", \\\"{x:1615,y:966,t:1527268578669};\\\", \\\"{x:1615,y:962,t:1527268579566};\\\", \\\"{x:1617,y:946,t:1527268579591};\\\", \\\"{x:1617,y:932,t:1527268579608};\\\", \\\"{x:1617,y:916,t:1527268579624};\\\", \\\"{x:1618,y:899,t:1527268579642};\\\", \\\"{x:1618,y:885,t:1527268579659};\\\", \\\"{x:1618,y:874,t:1527268579674};\\\", \\\"{x:1619,y:860,t:1527268579692};\\\", \\\"{x:1619,y:844,t:1527268579708};\\\", \\\"{x:1619,y:831,t:1527268579725};\\\", \\\"{x:1622,y:822,t:1527268579742};\\\", \\\"{x:1622,y:816,t:1527268579759};\\\", \\\"{x:1622,y:810,t:1527268579775};\\\", \\\"{x:1622,y:805,t:1527268579792};\\\", \\\"{x:1622,y:802,t:1527268579809};\\\", \\\"{x:1622,y:799,t:1527268579825};\\\", \\\"{x:1622,y:797,t:1527268579842};\\\", \\\"{x:1622,y:792,t:1527268579859};\\\", \\\"{x:1622,y:784,t:1527268579876};\\\", \\\"{x:1622,y:774,t:1527268579892};\\\", \\\"{x:1622,y:762,t:1527268579909};\\\", \\\"{x:1622,y:753,t:1527268579926};\\\", \\\"{x:1622,y:745,t:1527268579942};\\\", \\\"{x:1622,y:740,t:1527268579958};\\\", \\\"{x:1622,y:737,t:1527268579977};\\\", \\\"{x:1622,y:734,t:1527268579992};\\\", \\\"{x:1622,y:733,t:1527268580012};\\\", \\\"{x:1622,y:733,t:1527268580061};\\\", \\\"{x:1622,y:728,t:1527268581158};\\\", \\\"{x:1622,y:717,t:1527268581165};\\\", \\\"{x:1623,y:698,t:1527268581177};\\\", \\\"{x:1625,y:669,t:1527268581193};\\\", \\\"{x:1628,y:651,t:1527268581211};\\\", \\\"{x:1629,y:639,t:1527268581227};\\\", \\\"{x:1629,y:630,t:1527268581244};\\\", \\\"{x:1629,y:627,t:1527268581261};\\\", \\\"{x:1629,y:624,t:1527268581277};\\\", \\\"{x:1629,y:623,t:1527268581293};\\\", \\\"{x:1623,y:624,t:1527268582190};\\\", \\\"{x:1602,y:631,t:1527268582197};\\\", \\\"{x:1561,y:645,t:1527268582211};\\\", \\\"{x:1441,y:667,t:1527268582228};\\\", \\\"{x:1306,y:678,t:1527268582245};\\\", \\\"{x:1057,y:678,t:1527268582261};\\\", \\\"{x:846,y:660,t:1527268582278};\\\", \\\"{x:679,y:652,t:1527268582295};\\\", \\\"{x:565,y:652,t:1527268582311};\\\", \\\"{x:485,y:652,t:1527268582328};\\\", \\\"{x:453,y:652,t:1527268582344};\\\", \\\"{x:446,y:652,t:1527268582361};\\\", \\\"{x:445,y:649,t:1527268582541};\\\", \\\"{x:445,y:644,t:1527268582549};\\\", \\\"{x:445,y:637,t:1527268582562};\\\", \\\"{x:443,y:627,t:1527268582578};\\\", \\\"{x:441,y:620,t:1527268582594};\\\", \\\"{x:439,y:615,t:1527268582611};\\\", \\\"{x:436,y:610,t:1527268582628};\\\", \\\"{x:432,y:603,t:1527268582644};\\\", \\\"{x:427,y:591,t:1527268582662};\\\", \\\"{x:423,y:581,t:1527268582679};\\\", \\\"{x:421,y:576,t:1527268582695};\\\", \\\"{x:417,y:569,t:1527268582712};\\\", \\\"{x:412,y:559,t:1527268582729};\\\", \\\"{x:407,y:553,t:1527268582745};\\\", \\\"{x:405,y:551,t:1527268582761};\\\", \\\"{x:401,y:545,t:1527268582779};\\\", \\\"{x:396,y:539,t:1527268582794};\\\", \\\"{x:393,y:536,t:1527268582811};\\\", \\\"{x:390,y:531,t:1527268582828};\\\", \\\"{x:389,y:529,t:1527268582845};\\\", \\\"{x:388,y:526,t:1527268582862};\\\", \\\"{x:388,y:525,t:1527268582878};\\\", \\\"{x:388,y:524,t:1527268582896};\\\", \\\"{x:388,y:521,t:1527268582911};\\\", \\\"{x:395,y:516,t:1527268582928};\\\", \\\"{x:411,y:508,t:1527268582945};\\\", \\\"{x:435,y:500,t:1527268582961};\\\", \\\"{x:465,y:494,t:1527268582978};\\\", \\\"{x:493,y:490,t:1527268582995};\\\", \\\"{x:524,y:485,t:1527268583011};\\\", \\\"{x:545,y:483,t:1527268583028};\\\", \\\"{x:572,y:482,t:1527268583044};\\\", \\\"{x:594,y:482,t:1527268583061};\\\", \\\"{x:609,y:482,t:1527268583078};\\\", \\\"{x:617,y:482,t:1527268583095};\\\", \\\"{x:619,y:482,t:1527268583111};\\\", \\\"{x:620,y:482,t:1527268583132};\\\", \\\"{x:622,y:482,t:1527268583148};\\\", \\\"{x:623,y:482,t:1527268583161};\\\", \\\"{x:634,y:482,t:1527268583178};\\\", \\\"{x:652,y:482,t:1527268583195};\\\", \\\"{x:668,y:482,t:1527268583211};\\\", \\\"{x:697,y:482,t:1527268583228};\\\", \\\"{x:764,y:482,t:1527268583245};\\\", \\\"{x:796,y:482,t:1527268583261};\\\", \\\"{x:818,y:482,t:1527268583278};\\\", \\\"{x:823,y:482,t:1527268583295};\\\", \\\"{x:827,y:482,t:1527268583311};\\\", \\\"{x:829,y:481,t:1527268583328};\\\", \\\"{x:830,y:481,t:1527268583428};\\\", \\\"{x:832,y:485,t:1527268583444};\\\", \\\"{x:834,y:488,t:1527268583462};\\\", \\\"{x:836,y:492,t:1527268583478};\\\", \\\"{x:837,y:494,t:1527268583495};\\\", \\\"{x:837,y:496,t:1527268583511};\\\", \\\"{x:837,y:498,t:1527268583527};\\\", \\\"{x:837,y:500,t:1527268583545};\\\", \\\"{x:838,y:501,t:1527268583561};\\\", \\\"{x:838,y:503,t:1527268583578};\\\", \\\"{x:838,y:504,t:1527268583711};\\\", \\\"{x:843,y:503,t:1527268583728};\\\", \\\"{x:844,y:503,t:1527268583745};\\\", \\\"{x:846,y:502,t:1527268583761};\\\", \\\"{x:847,y:501,t:1527268583779};\\\", \\\"{x:848,y:501,t:1527268583795};\\\", \\\"{x:848,y:500,t:1527268583812};\\\", \\\"{x:848,y:499,t:1527268583869};\\\", \\\"{x:851,y:496,t:1527268583879};\\\", \\\"{x:858,y:494,t:1527268583895};\\\", \\\"{x:867,y:488,t:1527268583912};\\\", \\\"{x:882,y:485,t:1527268583930};\\\", \\\"{x:901,y:479,t:1527268583945};\\\", \\\"{x:943,y:473,t:1527268583962};\\\", \\\"{x:1032,y:473,t:1527268583979};\\\", \\\"{x:1134,y:473,t:1527268583995};\\\", \\\"{x:1251,y:473,t:1527268584012};\\\", \\\"{x:1439,y:473,t:1527268584029};\\\", \\\"{x:1561,y:473,t:1527268584045};\\\", \\\"{x:1675,y:474,t:1527268584062};\\\", \\\"{x:1764,y:487,t:1527268584080};\\\", \\\"{x:1826,y:499,t:1527268584095};\\\", \\\"{x:1871,y:513,t:1527268584113};\\\", \\\"{x:1898,y:520,t:1527268584129};\\\", \\\"{x:1915,y:529,t:1527268584146};\\\", \\\"{x:1919,y:533,t:1527268584162};\\\", \\\"{x:1919,y:536,t:1527268584179};\\\", \\\"{x:1919,y:548,t:1527268584197};\\\", \\\"{x:1919,y:563,t:1527268584212};\\\", \\\"{x:1919,y:591,t:1527268584229};\\\", \\\"{x:1919,y:617,t:1527268584247};\\\", \\\"{x:1919,y:637,t:1527268584263};\\\", \\\"{x:1919,y:650,t:1527268584280};\\\", \\\"{x:1916,y:666,t:1527268584296};\\\", \\\"{x:1909,y:680,t:1527268584312};\\\", \\\"{x:1902,y:691,t:1527268584330};\\\", \\\"{x:1892,y:702,t:1527268584346};\\\", \\\"{x:1886,y:709,t:1527268584362};\\\", \\\"{x:1882,y:715,t:1527268584379};\\\", \\\"{x:1879,y:719,t:1527268584396};\\\", \\\"{x:1874,y:725,t:1527268584412};\\\", \\\"{x:1865,y:736,t:1527268584429};\\\", \\\"{x:1856,y:748,t:1527268584446};\\\", \\\"{x:1853,y:755,t:1527268584462};\\\", \\\"{x:1851,y:763,t:1527268584480};\\\", \\\"{x:1846,y:772,t:1527268584497};\\\", \\\"{x:1844,y:778,t:1527268584512};\\\", \\\"{x:1841,y:783,t:1527268584530};\\\", \\\"{x:1838,y:786,t:1527268584547};\\\", \\\"{x:1836,y:788,t:1527268584563};\\\", \\\"{x:1832,y:791,t:1527268584579};\\\", \\\"{x:1827,y:793,t:1527268584596};\\\", \\\"{x:1819,y:797,t:1527268584613};\\\", \\\"{x:1808,y:802,t:1527268584629};\\\", \\\"{x:1791,y:805,t:1527268584646};\\\", \\\"{x:1771,y:805,t:1527268584663};\\\", \\\"{x:1750,y:805,t:1527268584679};\\\", \\\"{x:1732,y:805,t:1527268584696};\\\", \\\"{x:1717,y:804,t:1527268584713};\\\", \\\"{x:1705,y:800,t:1527268584729};\\\", \\\"{x:1700,y:798,t:1527268584747};\\\", \\\"{x:1695,y:795,t:1527268584763};\\\", \\\"{x:1692,y:793,t:1527268584779};\\\", \\\"{x:1687,y:789,t:1527268584796};\\\", \\\"{x:1682,y:783,t:1527268584813};\\\", \\\"{x:1679,y:781,t:1527268584830};\\\", \\\"{x:1677,y:779,t:1527268584846};\\\", \\\"{x:1673,y:776,t:1527268584864};\\\", \\\"{x:1670,y:772,t:1527268584879};\\\", \\\"{x:1666,y:769,t:1527268584897};\\\", \\\"{x:1662,y:766,t:1527268584914};\\\", \\\"{x:1661,y:764,t:1527268584930};\\\", \\\"{x:1660,y:764,t:1527268584947};\\\", \\\"{x:1659,y:763,t:1527268584964};\\\", \\\"{x:1658,y:762,t:1527268584981};\\\", \\\"{x:1657,y:761,t:1527268584996};\\\", \\\"{x:1653,y:756,t:1527268585013};\\\", \\\"{x:1651,y:753,t:1527268585030};\\\", \\\"{x:1649,y:751,t:1527268585047};\\\", \\\"{x:1648,y:749,t:1527268585064};\\\", \\\"{x:1647,y:746,t:1527268585080};\\\", \\\"{x:1646,y:746,t:1527268585096};\\\", \\\"{x:1646,y:745,t:1527268585246};\\\", \\\"{x:1645,y:745,t:1527268589926};\\\", \\\"{x:1642,y:745,t:1527268589933};\\\", \\\"{x:1639,y:747,t:1527268589951};\\\", \\\"{x:1637,y:747,t:1527268589968};\\\", \\\"{x:1636,y:747,t:1527268589989};\\\", \\\"{x:1635,y:749,t:1527268590165};\\\", \\\"{x:1632,y:750,t:1527268590173};\\\", \\\"{x:1630,y:753,t:1527268590184};\\\", \\\"{x:1621,y:758,t:1527268590201};\\\", \\\"{x:1605,y:772,t:1527268590218};\\\", \\\"{x:1590,y:780,t:1527268590234};\\\", \\\"{x:1580,y:786,t:1527268590251};\\\", \\\"{x:1575,y:787,t:1527268590268};\\\", \\\"{x:1573,y:789,t:1527268590284};\\\", \\\"{x:1572,y:789,t:1527268590301};\\\", \\\"{x:1569,y:791,t:1527268590317};\\\", \\\"{x:1565,y:795,t:1527268590334};\\\", \\\"{x:1559,y:800,t:1527268590352};\\\", \\\"{x:1551,y:807,t:1527268590368};\\\", \\\"{x:1547,y:814,t:1527268590385};\\\", \\\"{x:1543,y:821,t:1527268590401};\\\", \\\"{x:1538,y:830,t:1527268590418};\\\", \\\"{x:1535,y:836,t:1527268590435};\\\", \\\"{x:1532,y:840,t:1527268590451};\\\", \\\"{x:1532,y:841,t:1527268590468};\\\", \\\"{x:1531,y:843,t:1527268590485};\\\", \\\"{x:1529,y:843,t:1527268590501};\\\", \\\"{x:1525,y:846,t:1527268590518};\\\", \\\"{x:1519,y:847,t:1527268590535};\\\", \\\"{x:1514,y:847,t:1527268590551};\\\", \\\"{x:1508,y:847,t:1527268590568};\\\", \\\"{x:1503,y:847,t:1527268590585};\\\", \\\"{x:1500,y:847,t:1527268590601};\\\", \\\"{x:1495,y:847,t:1527268590618};\\\", \\\"{x:1492,y:847,t:1527268590635};\\\", \\\"{x:1486,y:845,t:1527268590651};\\\", \\\"{x:1480,y:842,t:1527268590668};\\\", \\\"{x:1465,y:837,t:1527268590685};\\\", \\\"{x:1448,y:831,t:1527268590701};\\\", \\\"{x:1433,y:828,t:1527268590718};\\\", \\\"{x:1423,y:824,t:1527268590735};\\\", \\\"{x:1410,y:819,t:1527268590751};\\\", \\\"{x:1395,y:812,t:1527268590769};\\\", \\\"{x:1378,y:804,t:1527268590785};\\\", \\\"{x:1360,y:799,t:1527268590802};\\\", \\\"{x:1345,y:795,t:1527268590818};\\\", \\\"{x:1329,y:789,t:1527268590835};\\\", \\\"{x:1318,y:788,t:1527268590852};\\\", \\\"{x:1311,y:785,t:1527268590868};\\\", \\\"{x:1300,y:782,t:1527268590886};\\\", \\\"{x:1291,y:781,t:1527268590902};\\\", \\\"{x:1284,y:780,t:1527268590918};\\\", \\\"{x:1273,y:779,t:1527268590935};\\\", \\\"{x:1261,y:776,t:1527268590952};\\\", \\\"{x:1250,y:775,t:1527268590968};\\\", \\\"{x:1238,y:771,t:1527268590985};\\\", \\\"{x:1229,y:771,t:1527268591002};\\\", \\\"{x:1222,y:770,t:1527268591019};\\\", \\\"{x:1219,y:770,t:1527268591035};\\\", \\\"{x:1218,y:770,t:1527268591052};\\\", \\\"{x:1217,y:770,t:1527268591086};\\\", \\\"{x:1217,y:771,t:1527268591118};\\\", \\\"{x:1217,y:774,t:1527268591135};\\\", \\\"{x:1229,y:779,t:1527268591152};\\\", \\\"{x:1253,y:785,t:1527268591168};\\\", \\\"{x:1284,y:790,t:1527268591184};\\\", \\\"{x:1327,y:800,t:1527268591202};\\\", \\\"{x:1371,y:809,t:1527268591218};\\\", \\\"{x:1407,y:814,t:1527268591235};\\\", \\\"{x:1442,y:821,t:1527268591251};\\\", \\\"{x:1475,y:827,t:1527268591268};\\\", \\\"{x:1488,y:827,t:1527268591284};\\\", \\\"{x:1492,y:827,t:1527268591301};\\\", \\\"{x:1495,y:827,t:1527268591318};\\\", \\\"{x:1496,y:827,t:1527268591372};\\\", \\\"{x:1497,y:827,t:1527268591470};\\\", \\\"{x:1498,y:827,t:1527268591485};\\\", \\\"{x:1502,y:827,t:1527268591502};\\\", \\\"{x:1506,y:829,t:1527268591518};\\\", \\\"{x:1510,y:830,t:1527268591535};\\\", \\\"{x:1513,y:831,t:1527268591552};\\\", \\\"{x:1515,y:831,t:1527268591569};\\\", \\\"{x:1516,y:831,t:1527268591584};\\\", \\\"{x:1517,y:831,t:1527268591602};\\\", \\\"{x:1518,y:831,t:1527268591637};\\\", \\\"{x:1518,y:832,t:1527268591678};\\\", \\\"{x:1518,y:833,t:1527268591749};\\\", \\\"{x:1516,y:834,t:1527268591765};\\\", \\\"{x:1515,y:836,t:1527268591789};\\\", \\\"{x:1512,y:836,t:1527268591814};\\\", \\\"{x:1512,y:837,t:1527268591886};\\\", \\\"{x:1511,y:837,t:1527268591909};\\\", \\\"{x:1510,y:837,t:1527268591925};\\\", \\\"{x:1509,y:837,t:1527268591941};\\\", \\\"{x:1508,y:838,t:1527268591965};\\\", \\\"{x:1507,y:838,t:1527268591989};\\\", \\\"{x:1506,y:838,t:1527268592002};\\\", \\\"{x:1505,y:839,t:1527268592019};\\\", \\\"{x:1504,y:839,t:1527268592036};\\\", \\\"{x:1503,y:840,t:1527268592052};\\\", \\\"{x:1502,y:840,t:1527268592086};\\\", \\\"{x:1501,y:840,t:1527268592310};\\\", \\\"{x:1499,y:840,t:1527268592334};\\\", \\\"{x:1499,y:839,t:1527268592397};\\\", \\\"{x:1499,y:837,t:1527268592469};\\\", \\\"{x:1500,y:835,t:1527268592486};\\\", \\\"{x:1509,y:831,t:1527268592503};\\\", \\\"{x:1522,y:827,t:1527268592520};\\\", \\\"{x:1537,y:825,t:1527268592536};\\\", \\\"{x:1553,y:824,t:1527268592553};\\\", \\\"{x:1569,y:824,t:1527268592570};\\\", \\\"{x:1587,y:822,t:1527268592587};\\\", \\\"{x:1610,y:822,t:1527268592603};\\\", \\\"{x:1636,y:822,t:1527268592621};\\\", \\\"{x:1659,y:822,t:1527268592637};\\\", \\\"{x:1689,y:822,t:1527268592654};\\\", \\\"{x:1692,y:822,t:1527268592670};\\\", \\\"{x:1693,y:821,t:1527268592702};\\\", \\\"{x:1691,y:818,t:1527268592709};\\\", \\\"{x:1680,y:815,t:1527268592720};\\\", \\\"{x:1618,y:803,t:1527268592737};\\\", \\\"{x:1489,y:788,t:1527268592754};\\\", \\\"{x:1301,y:761,t:1527268592772};\\\", \\\"{x:1066,y:730,t:1527268592785};\\\", \\\"{x:815,y:700,t:1527268592803};\\\", \\\"{x:578,y:664,t:1527268592819};\\\", \\\"{x:401,y:640,t:1527268592836};\\\", \\\"{x:238,y:614,t:1527268592853};\\\", \\\"{x:206,y:605,t:1527268592869};\\\", \\\"{x:201,y:602,t:1527268592885};\\\", \\\"{x:201,y:600,t:1527268592909};\\\", \\\"{x:204,y:600,t:1527268592919};\\\", \\\"{x:211,y:597,t:1527268592935};\\\", \\\"{x:221,y:592,t:1527268592953};\\\", \\\"{x:231,y:587,t:1527268592969};\\\", \\\"{x:245,y:583,t:1527268592986};\\\", \\\"{x:251,y:581,t:1527268593002};\\\", \\\"{x:254,y:579,t:1527268593019};\\\", \\\"{x:264,y:575,t:1527268593036};\\\", \\\"{x:279,y:573,t:1527268593053};\\\", \\\"{x:314,y:573,t:1527268593069};\\\", \\\"{x:378,y:582,t:1527268593086};\\\", \\\"{x:466,y:605,t:1527268593103};\\\", \\\"{x:557,y:625,t:1527268593121};\\\", \\\"{x:648,y:638,t:1527268593137};\\\", \\\"{x:715,y:646,t:1527268593152};\\\", \\\"{x:758,y:654,t:1527268593169};\\\", \\\"{x:772,y:655,t:1527268593186};\\\", \\\"{x:771,y:655,t:1527268593254};\\\", \\\"{x:765,y:651,t:1527268593270};\\\", \\\"{x:748,y:641,t:1527268593286};\\\", \\\"{x:723,y:630,t:1527268593304};\\\", \\\"{x:683,y:615,t:1527268593319};\\\", \\\"{x:645,y:607,t:1527268593335};\\\", \\\"{x:620,y:602,t:1527268593352};\\\", \\\"{x:612,y:602,t:1527268593369};\\\", \\\"{x:611,y:602,t:1527268593404};\\\", \\\"{x:613,y:600,t:1527268593421};\\\", \\\"{x:614,y:599,t:1527268593436};\\\", \\\"{x:616,y:598,t:1527268593460};\\\", \\\"{x:616,y:596,t:1527268593542};\\\", \\\"{x:616,y:593,t:1527268593554};\\\", \\\"{x:616,y:588,t:1527268593569};\\\", \\\"{x:615,y:584,t:1527268593586};\\\", \\\"{x:614,y:581,t:1527268593603};\\\", \\\"{x:614,y:580,t:1527268593628};\\\", \\\"{x:613,y:579,t:1527268593884};\\\", \\\"{x:609,y:583,t:1527268593892};\\\", \\\"{x:602,y:595,t:1527268593904};\\\", \\\"{x:588,y:618,t:1527268593921};\\\", \\\"{x:573,y:646,t:1527268593937};\\\", \\\"{x:558,y:670,t:1527268593953};\\\", \\\"{x:548,y:693,t:1527268593971};\\\", \\\"{x:537,y:711,t:1527268593987};\\\", \\\"{x:530,y:723,t:1527268594004};\\\", \\\"{x:524,y:742,t:1527268594020};\\\", \\\"{x:521,y:751,t:1527268594036};\\\", \\\"{x:516,y:763,t:1527268594053};\\\", \\\"{x:511,y:773,t:1527268594070};\\\", \\\"{x:508,y:780,t:1527268594086};\\\", \\\"{x:507,y:784,t:1527268594103};\\\", \\\"{x:506,y:785,t:1527268594120};\\\", \\\"{x:507,y:783,t:1527268594276};\\\", \\\"{x:507,y:781,t:1527268594286};\\\", \\\"{x:509,y:776,t:1527268594303};\\\", \\\"{x:512,y:769,t:1527268594320};\\\", \\\"{x:515,y:763,t:1527268594337};\\\", \\\"{x:519,y:756,t:1527268594353};\\\", \\\"{x:520,y:755,t:1527268594371};\\\", \\\"{x:521,y:754,t:1527268594387};\\\", \\\"{x:521,y:753,t:1527268594420};\\\", \\\"{x:521,y:752,t:1527268594437};\\\", \\\"{x:522,y:752,t:1527268594460};\\\", \\\"{x:522,y:748,t:1527268595253};\\\", \\\"{x:522,y:744,t:1527268595260};\\\", \\\"{x:522,y:736,t:1527268595272};\\\", \\\"{x:509,y:718,t:1527268595288};\\\", \\\"{x:488,y:700,t:1527268595305};\\\", \\\"{x:443,y:667,t:1527268595322};\\\", \\\"{x:368,y:612,t:1527268595337};\\\" ] }, { \\\"rt\\\": 49431, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 669046, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -05 PM-03 PM-D -N -F -Z -Z -H -C -C -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:370,y:613,t:1527268595973};\\\", \\\"{x:372,y:616,t:1527268595988};\\\", \\\"{x:374,y:616,t:1527268596020};\\\", \\\"{x:375,y:616,t:1527268596029};\\\", \\\"{x:376,y:616,t:1527268596038};\\\", \\\"{x:380,y:616,t:1527268596065};\\\", \\\"{x:381,y:616,t:1527268596072};\\\", \\\"{x:387,y:617,t:1527268596088};\\\", \\\"{x:394,y:618,t:1527268596105};\\\", \\\"{x:401,y:618,t:1527268596122};\\\", \\\"{x:410,y:618,t:1527268596138};\\\", \\\"{x:421,y:618,t:1527268596156};\\\", \\\"{x:433,y:618,t:1527268596171};\\\", \\\"{x:456,y:618,t:1527268596188};\\\", \\\"{x:472,y:618,t:1527268596205};\\\", \\\"{x:487,y:618,t:1527268596223};\\\", \\\"{x:505,y:618,t:1527268596239};\\\", \\\"{x:519,y:616,t:1527268596256};\\\", \\\"{x:616,y:616,t:1527268596358};\\\", \\\"{x:663,y:606,t:1527268596376};\\\", \\\"{x:773,y:563,t:1527268596389};\\\", \\\"{x:932,y:505,t:1527268596406};\\\", \\\"{x:1113,y:466,t:1527268596423};\\\", \\\"{x:1278,y:460,t:1527268596438};\\\", \\\"{x:1370,y:456,t:1527268596455};\\\", \\\"{x:1371,y:457,t:1527268596572};\\\", \\\"{x:1378,y:461,t:1527268596588};\\\", \\\"{x:1383,y:463,t:1527268596606};\\\", \\\"{x:1388,y:463,t:1527268596623};\\\", \\\"{x:1393,y:464,t:1527268596640};\\\", \\\"{x:1394,y:465,t:1527268596655};\\\", \\\"{x:1395,y:465,t:1527268596672};\\\", \\\"{x:1396,y:466,t:1527268596690};\\\", \\\"{x:1397,y:467,t:1527268596705};\\\", \\\"{x:1400,y:468,t:1527268596723};\\\", \\\"{x:1407,y:472,t:1527268596740};\\\", \\\"{x:1411,y:472,t:1527268596756};\\\", \\\"{x:1411,y:475,t:1527268597533};\\\", \\\"{x:1410,y:475,t:1527268598422};\\\", \\\"{x:1410,y:477,t:1527268598429};\\\", \\\"{x:1410,y:479,t:1527268598444};\\\", \\\"{x:1410,y:486,t:1527268598460};\\\", \\\"{x:1410,y:500,t:1527268598476};\\\", \\\"{x:1411,y:521,t:1527268598495};\\\", \\\"{x:1412,y:541,t:1527268598510};\\\", \\\"{x:1417,y:570,t:1527268598527};\\\", \\\"{x:1432,y:613,t:1527268598544};\\\", \\\"{x:1462,y:665,t:1527268598561};\\\", \\\"{x:1503,y:708,t:1527268598577};\\\", \\\"{x:1543,y:737,t:1527268598594};\\\", \\\"{x:1582,y:754,t:1527268598611};\\\", \\\"{x:1620,y:774,t:1527268598626};\\\", \\\"{x:1642,y:786,t:1527268598644};\\\", \\\"{x:1646,y:790,t:1527268598660};\\\", \\\"{x:1648,y:790,t:1527268598677};\\\", \\\"{x:1649,y:790,t:1527268598694};\\\", \\\"{x:1662,y:790,t:1527268598758};\\\", \\\"{x:1673,y:796,t:1527268598765};\\\", \\\"{x:1676,y:797,t:1527268598777};\\\", \\\"{x:1678,y:797,t:1527268598793};\\\", \\\"{x:1679,y:798,t:1527268598810};\\\", \\\"{x:1681,y:800,t:1527268598827};\\\", \\\"{x:1683,y:804,t:1527268598843};\\\", \\\"{x:1684,y:815,t:1527268598861};\\\", \\\"{x:1687,y:835,t:1527268598878};\\\", \\\"{x:1687,y:846,t:1527268598894};\\\", \\\"{x:1684,y:862,t:1527268598911};\\\", \\\"{x:1681,y:887,t:1527268598927};\\\", \\\"{x:1679,y:910,t:1527268598944};\\\", \\\"{x:1674,y:929,t:1527268598960};\\\", \\\"{x:1672,y:943,t:1527268598978};\\\", \\\"{x:1672,y:951,t:1527268598995};\\\", \\\"{x:1672,y:957,t:1527268599010};\\\", \\\"{x:1672,y:962,t:1527268599027};\\\", \\\"{x:1672,y:965,t:1527268599044};\\\", \\\"{x:1672,y:967,t:1527268599061};\\\", \\\"{x:1672,y:968,t:1527268599077};\\\", \\\"{x:1672,y:969,t:1527268599117};\\\", \\\"{x:1671,y:969,t:1527268599140};\\\", \\\"{x:1673,y:969,t:1527268599253};\\\", \\\"{x:1675,y:968,t:1527268599279};\\\", \\\"{x:1676,y:968,t:1527268599301};\\\", \\\"{x:1676,y:967,t:1527268599311};\\\", \\\"{x:1677,y:966,t:1527268599328};\\\", \\\"{x:1678,y:965,t:1527268599344};\\\", \\\"{x:1678,y:963,t:1527268599362};\\\", \\\"{x:1680,y:960,t:1527268599378};\\\", \\\"{x:1680,y:958,t:1527268599395};\\\", \\\"{x:1681,y:955,t:1527268599411};\\\", \\\"{x:1681,y:952,t:1527268599428};\\\", \\\"{x:1682,y:950,t:1527268599444};\\\", \\\"{x:1682,y:949,t:1527268599461};\\\", \\\"{x:1682,y:947,t:1527268599478};\\\", \\\"{x:1682,y:945,t:1527268599495};\\\", \\\"{x:1679,y:942,t:1527268599511};\\\", \\\"{x:1678,y:942,t:1527268599528};\\\", \\\"{x:1676,y:941,t:1527268599546};\\\", \\\"{x:1675,y:940,t:1527268599562};\\\", \\\"{x:1680,y:938,t:1527268599613};\\\", \\\"{x:1688,y:933,t:1527268599629};\\\", \\\"{x:1716,y:922,t:1527268599645};\\\", \\\"{x:1730,y:921,t:1527268599663};\\\", \\\"{x:1736,y:921,t:1527268599679};\\\", \\\"{x:1741,y:921,t:1527268599696};\\\", \\\"{x:1744,y:923,t:1527268599712};\\\", \\\"{x:1745,y:924,t:1527268599729};\\\", \\\"{x:1745,y:926,t:1527268599926};\\\", \\\"{x:1745,y:937,t:1527268599934};\\\", \\\"{x:1742,y:959,t:1527268599946};\\\", \\\"{x:1714,y:1043,t:1527268599962};\\\", \\\"{x:1683,y:1125,t:1527268599979};\\\", \\\"{x:1670,y:1170,t:1527268599995};\\\", \\\"{x:1669,y:1178,t:1527268600012};\\\", \\\"{x:1669,y:1181,t:1527268600029};\\\", \\\"{x:1668,y:1182,t:1527268600157};\\\", \\\"{x:1666,y:1181,t:1527268600181};\\\", \\\"{x:1665,y:1179,t:1527268600196};\\\", \\\"{x:1659,y:1170,t:1527268600212};\\\", \\\"{x:1642,y:1147,t:1527268600229};\\\", \\\"{x:1630,y:1134,t:1527268600246};\\\", \\\"{x:1624,y:1126,t:1527268600264};\\\", \\\"{x:1616,y:1111,t:1527268600279};\\\", \\\"{x:1614,y:1096,t:1527268600296};\\\", \\\"{x:1613,y:1074,t:1527268600313};\\\", \\\"{x:1613,y:1048,t:1527268600330};\\\", \\\"{x:1613,y:1030,t:1527268600347};\\\", \\\"{x:1613,y:1021,t:1527268600364};\\\", \\\"{x:1613,y:1018,t:1527268600380};\\\", \\\"{x:1613,y:1017,t:1527268600422};\\\", \\\"{x:1613,y:1016,t:1527268600445};\\\", \\\"{x:1613,y:1009,t:1527268600463};\\\", \\\"{x:1611,y:1001,t:1527268600480};\\\", \\\"{x:1604,y:994,t:1527268600496};\\\", \\\"{x:1591,y:983,t:1527268600513};\\\", \\\"{x:1577,y:977,t:1527268600530};\\\", \\\"{x:1563,y:971,t:1527268600546};\\\", \\\"{x:1550,y:966,t:1527268600564};\\\", \\\"{x:1535,y:958,t:1527268600580};\\\", \\\"{x:1508,y:950,t:1527268600597};\\\", \\\"{x:1503,y:947,t:1527268600613};\\\", \\\"{x:1502,y:946,t:1527268600631};\\\", \\\"{x:1500,y:946,t:1527268600647};\\\", \\\"{x:1501,y:944,t:1527268600949};\\\", \\\"{x:1502,y:944,t:1527268600965};\\\", \\\"{x:1503,y:944,t:1527268600981};\\\", \\\"{x:1505,y:944,t:1527268600997};\\\", \\\"{x:1508,y:945,t:1527268601014};\\\", \\\"{x:1513,y:947,t:1527268601031};\\\", \\\"{x:1519,y:949,t:1527268601048};\\\", \\\"{x:1528,y:949,t:1527268601064};\\\", \\\"{x:1537,y:951,t:1527268601082};\\\", \\\"{x:1545,y:952,t:1527268601097};\\\", \\\"{x:1555,y:954,t:1527268601114};\\\", \\\"{x:1561,y:956,t:1527268601131};\\\", \\\"{x:1563,y:956,t:1527268601148};\\\", \\\"{x:1564,y:956,t:1527268601164};\\\", \\\"{x:1565,y:956,t:1527268601524};\\\", \\\"{x:1565,y:957,t:1527268601701};\\\", \\\"{x:1564,y:957,t:1527268601717};\\\", \\\"{x:1562,y:959,t:1527268601733};\\\", \\\"{x:1558,y:959,t:1527268601749};\\\", \\\"{x:1556,y:960,t:1527268601765};\\\", \\\"{x:1553,y:961,t:1527268601782};\\\", \\\"{x:1547,y:963,t:1527268601799};\\\", \\\"{x:1546,y:964,t:1527268601815};\\\", \\\"{x:1545,y:964,t:1527268601833};\\\", \\\"{x:1545,y:963,t:1527268602877};\\\", \\\"{x:1545,y:961,t:1527268602894};\\\", \\\"{x:1545,y:960,t:1527268602925};\\\", \\\"{x:1543,y:959,t:1527268602934};\\\", \\\"{x:1543,y:958,t:1527268602952};\\\", \\\"{x:1543,y:957,t:1527268602989};\\\", \\\"{x:1543,y:956,t:1527268603001};\\\", \\\"{x:1543,y:955,t:1527268603019};\\\", \\\"{x:1542,y:954,t:1527268603037};\\\", \\\"{x:1542,y:953,t:1527268603157};\\\", \\\"{x:1542,y:952,t:1527268603374};\\\", \\\"{x:1542,y:951,t:1527268603501};\\\", \\\"{x:1542,y:950,t:1527268603541};\\\", \\\"{x:1542,y:949,t:1527268603552};\\\", \\\"{x:1542,y:945,t:1527268603569};\\\", \\\"{x:1542,y:942,t:1527268603585};\\\", \\\"{x:1542,y:938,t:1527268603603};\\\", \\\"{x:1542,y:934,t:1527268603619};\\\", \\\"{x:1541,y:930,t:1527268603636};\\\", \\\"{x:1540,y:926,t:1527268603653};\\\", \\\"{x:1539,y:918,t:1527268603669};\\\", \\\"{x:1538,y:911,t:1527268603686};\\\", \\\"{x:1537,y:906,t:1527268603703};\\\", \\\"{x:1537,y:902,t:1527268603720};\\\", \\\"{x:1536,y:897,t:1527268603735};\\\", \\\"{x:1535,y:895,t:1527268603752};\\\", \\\"{x:1535,y:893,t:1527268603769};\\\", \\\"{x:1534,y:893,t:1527268603787};\\\", \\\"{x:1534,y:892,t:1527268603805};\\\", \\\"{x:1534,y:891,t:1527268603821};\\\", \\\"{x:1534,y:890,t:1527268603836};\\\", \\\"{x:1534,y:889,t:1527268603853};\\\", \\\"{x:1534,y:887,t:1527268603869};\\\", \\\"{x:1534,y:885,t:1527268603887};\\\", \\\"{x:1534,y:884,t:1527268603903};\\\", \\\"{x:1534,y:881,t:1527268603919};\\\", \\\"{x:1534,y:880,t:1527268603937};\\\", \\\"{x:1534,y:878,t:1527268603953};\\\", \\\"{x:1534,y:877,t:1527268603973};\\\", \\\"{x:1534,y:876,t:1527268603986};\\\", \\\"{x:1534,y:875,t:1527268604003};\\\", \\\"{x:1534,y:874,t:1527268604045};\\\", \\\"{x:1534,y:873,t:1527268604053};\\\", \\\"{x:1534,y:871,t:1527268604070};\\\", \\\"{x:1534,y:869,t:1527268604087};\\\", \\\"{x:1534,y:868,t:1527268604103};\\\", \\\"{x:1534,y:866,t:1527268604119};\\\", \\\"{x:1534,y:863,t:1527268604135};\\\", \\\"{x:1534,y:861,t:1527268604153};\\\", \\\"{x:1534,y:859,t:1527268604170};\\\", \\\"{x:1534,y:857,t:1527268604186};\\\", \\\"{x:1534,y:855,t:1527268604203};\\\", \\\"{x:1534,y:853,t:1527268604220};\\\", \\\"{x:1534,y:852,t:1527268604236};\\\", \\\"{x:1534,y:849,t:1527268604253};\\\", \\\"{x:1535,y:848,t:1527268604271};\\\", \\\"{x:1535,y:847,t:1527268604286};\\\", \\\"{x:1535,y:844,t:1527268604303};\\\", \\\"{x:1535,y:843,t:1527268604320};\\\", \\\"{x:1535,y:841,t:1527268604336};\\\", \\\"{x:1536,y:839,t:1527268604353};\\\", \\\"{x:1536,y:838,t:1527268604370};\\\", \\\"{x:1536,y:837,t:1527268604580};\\\", \\\"{x:1538,y:836,t:1527268604588};\\\", \\\"{x:1539,y:834,t:1527268604604};\\\", \\\"{x:1541,y:833,t:1527268604620};\\\", \\\"{x:1543,y:831,t:1527268604638};\\\", \\\"{x:1545,y:830,t:1527268604655};\\\", \\\"{x:1547,y:828,t:1527268604670};\\\", \\\"{x:1549,y:827,t:1527268604687};\\\", \\\"{x:1550,y:825,t:1527268604704};\\\", \\\"{x:1551,y:824,t:1527268604721};\\\", \\\"{x:1552,y:822,t:1527268604740};\\\", \\\"{x:1552,y:821,t:1527268604757};\\\", \\\"{x:1553,y:821,t:1527268604771};\\\", \\\"{x:1553,y:820,t:1527268605454};\\\", \\\"{x:1552,y:820,t:1527268605469};\\\", \\\"{x:1551,y:820,t:1527268605495};\\\", \\\"{x:1550,y:820,t:1527268605613};\\\", \\\"{x:1549,y:820,t:1527268605645};\\\", \\\"{x:1548,y:820,t:1527268605709};\\\", \\\"{x:1548,y:821,t:1527268606957};\\\", \\\"{x:1544,y:831,t:1527268606975};\\\", \\\"{x:1544,y:839,t:1527268606992};\\\", \\\"{x:1544,y:850,t:1527268607009};\\\", \\\"{x:1544,y:855,t:1527268607025};\\\", \\\"{x:1544,y:858,t:1527268607042};\\\", \\\"{x:1545,y:850,t:1527268607173};\\\", \\\"{x:1546,y:845,t:1527268607181};\\\", \\\"{x:1547,y:840,t:1527268607193};\\\", \\\"{x:1547,y:834,t:1527268607208};\\\", \\\"{x:1547,y:830,t:1527268607226};\\\", \\\"{x:1547,y:827,t:1527268607243};\\\", \\\"{x:1547,y:826,t:1527268607261};\\\", \\\"{x:1547,y:825,t:1527268609486};\\\", \\\"{x:1547,y:823,t:1527268626238};\\\", \\\"{x:1535,y:812,t:1527268626245};\\\", \\\"{x:1487,y:775,t:1527268626261};\\\", \\\"{x:1398,y:717,t:1527268626277};\\\", \\\"{x:1291,y:652,t:1527268626294};\\\", \\\"{x:1144,y:571,t:1527268626311};\\\", \\\"{x:964,y:491,t:1527268626327};\\\", \\\"{x:768,y:400,t:1527268626344};\\\", \\\"{x:589,y:322,t:1527268626360};\\\", \\\"{x:428,y:268,t:1527268626377};\\\", \\\"{x:327,y:248,t:1527268626393};\\\", \\\"{x:279,y:241,t:1527268626410};\\\", \\\"{x:253,y:237,t:1527268626428};\\\", \\\"{x:244,y:235,t:1527268626443};\\\", \\\"{x:239,y:233,t:1527268626460};\\\", \\\"{x:238,y:233,t:1527268626485};\\\", \\\"{x:237,y:233,t:1527268626517};\\\", \\\"{x:235,y:233,t:1527268626527};\\\", \\\"{x:231,y:233,t:1527268626544};\\\", \\\"{x:223,y:233,t:1527268626560};\\\", \\\"{x:218,y:235,t:1527268626577};\\\", \\\"{x:211,y:235,t:1527268626595};\\\", \\\"{x:197,y:235,t:1527268626610};\\\", \\\"{x:196,y:235,t:1527268626627};\\\", \\\"{x:195,y:235,t:1527268626644};\\\", \\\"{x:194,y:236,t:1527268627101};\\\", \\\"{x:187,y:241,t:1527268627111};\\\", \\\"{x:156,y:259,t:1527268627129};\\\", \\\"{x:131,y:276,t:1527268627145};\\\", \\\"{x:113,y:288,t:1527268627161};\\\", \\\"{x:102,y:296,t:1527268627179};\\\", \\\"{x:93,y:303,t:1527268627195};\\\", \\\"{x:87,y:307,t:1527268627212};\\\", \\\"{x:78,y:315,t:1527268627229};\\\", \\\"{x:75,y:320,t:1527268627245};\\\", \\\"{x:73,y:325,t:1527268627262};\\\", \\\"{x:73,y:331,t:1527268627278};\\\", \\\"{x:73,y:340,t:1527268627295};\\\", \\\"{x:76,y:350,t:1527268627313};\\\", \\\"{x:85,y:365,t:1527268627328};\\\", \\\"{x:98,y:383,t:1527268627346};\\\", \\\"{x:114,y:405,t:1527268627362};\\\", \\\"{x:131,y:430,t:1527268627378};\\\", \\\"{x:145,y:456,t:1527268627396};\\\", \\\"{x:156,y:486,t:1527268627413};\\\", \\\"{x:168,y:508,t:1527268627430};\\\", \\\"{x:169,y:517,t:1527268627445};\\\", \\\"{x:169,y:521,t:1527268627479};\\\", \\\"{x:169,y:522,t:1527268627500};\\\", \\\"{x:168,y:523,t:1527268627572};\\\", \\\"{x:168,y:524,t:1527268627596};\\\", \\\"{x:167,y:524,t:1527268627612};\\\", \\\"{x:167,y:527,t:1527268627734};\\\", \\\"{x:167,y:530,t:1527268627747};\\\", \\\"{x:165,y:538,t:1527268627764};\\\", \\\"{x:165,y:540,t:1527268627780};\\\", \\\"{x:164,y:542,t:1527268627796};\\\", \\\"{x:164,y:543,t:1527268627843};\\\", \\\"{x:163,y:543,t:1527268627868};\\\", \\\"{x:164,y:542,t:1527268628043};\\\", \\\"{x:165,y:542,t:1527268628060};\\\", \\\"{x:166,y:542,t:1527268628068};\\\", \\\"{x:169,y:541,t:1527268628080};\\\", \\\"{x:188,y:537,t:1527268628098};\\\", \\\"{x:207,y:534,t:1527268628114};\\\", \\\"{x:244,y:530,t:1527268628131};\\\", \\\"{x:384,y:522,t:1527268628148};\\\", \\\"{x:528,y:522,t:1527268628164};\\\", \\\"{x:741,y:522,t:1527268628181};\\\", \\\"{x:973,y:520,t:1527268628197};\\\", \\\"{x:1216,y:520,t:1527268628215};\\\", \\\"{x:1454,y:524,t:1527268628231};\\\", \\\"{x:1675,y:528,t:1527268628248};\\\", \\\"{x:1899,y:535,t:1527268628265};\\\", \\\"{x:1919,y:563,t:1527268628281};\\\", \\\"{x:1919,y:587,t:1527268628298};\\\", \\\"{x:1919,y:615,t:1527268628315};\\\", \\\"{x:1919,y:639,t:1527268628331};\\\", \\\"{x:1919,y:658,t:1527268628348};\\\", \\\"{x:1919,y:664,t:1527268628364};\\\", \\\"{x:1919,y:665,t:1527268628381};\\\", \\\"{x:1919,y:669,t:1527268628398};\\\", \\\"{x:1919,y:678,t:1527268628415};\\\", \\\"{x:1908,y:693,t:1527268628432};\\\", \\\"{x:1894,y:708,t:1527268628448};\\\", \\\"{x:1874,y:727,t:1527268628465};\\\", \\\"{x:1847,y:749,t:1527268628481};\\\", \\\"{x:1824,y:768,t:1527268628498};\\\", \\\"{x:1802,y:784,t:1527268628515};\\\", \\\"{x:1783,y:798,t:1527268628531};\\\", \\\"{x:1764,y:811,t:1527268628548};\\\", \\\"{x:1757,y:815,t:1527268628565};\\\", \\\"{x:1750,y:816,t:1527268628582};\\\", \\\"{x:1743,y:818,t:1527268628599};\\\", \\\"{x:1729,y:819,t:1527268628616};\\\", \\\"{x:1709,y:820,t:1527268628631};\\\", \\\"{x:1684,y:820,t:1527268628649};\\\", \\\"{x:1643,y:816,t:1527268628666};\\\", \\\"{x:1585,y:800,t:1527268628683};\\\", \\\"{x:1513,y:778,t:1527268628698};\\\", \\\"{x:1428,y:749,t:1527268628716};\\\", \\\"{x:1319,y:699,t:1527268628732};\\\", \\\"{x:1255,y:669,t:1527268628749};\\\", \\\"{x:1213,y:641,t:1527268628765};\\\", \\\"{x:1178,y:615,t:1527268628782};\\\", \\\"{x:1162,y:600,t:1527268628798};\\\", \\\"{x:1153,y:583,t:1527268628815};\\\", \\\"{x:1151,y:574,t:1527268628833};\\\", \\\"{x:1151,y:572,t:1527268628848};\\\", \\\"{x:1151,y:570,t:1527268628866};\\\", \\\"{x:1151,y:569,t:1527268628883};\\\", \\\"{x:1151,y:567,t:1527268628898};\\\", \\\"{x:1151,y:566,t:1527268628915};\\\", \\\"{x:1159,y:565,t:1527268628933};\\\", \\\"{x:1167,y:565,t:1527268628949};\\\", \\\"{x:1184,y:567,t:1527268628966};\\\", \\\"{x:1204,y:575,t:1527268628982};\\\", \\\"{x:1231,y:587,t:1527268628999};\\\", \\\"{x:1279,y:609,t:1527268629015};\\\", \\\"{x:1335,y:627,t:1527268629033};\\\", \\\"{x:1389,y:647,t:1527268629049};\\\", \\\"{x:1423,y:658,t:1527268629066};\\\", \\\"{x:1445,y:667,t:1527268629083};\\\", \\\"{x:1455,y:671,t:1527268629098};\\\", \\\"{x:1460,y:674,t:1527268629115};\\\", \\\"{x:1463,y:678,t:1527268629133};\\\", \\\"{x:1464,y:680,t:1527268629149};\\\", \\\"{x:1464,y:682,t:1527268629165};\\\", \\\"{x:1465,y:684,t:1527268629183};\\\", \\\"{x:1466,y:685,t:1527268629204};\\\", \\\"{x:1466,y:686,t:1527268629215};\\\", \\\"{x:1466,y:687,t:1527268629233};\\\", \\\"{x:1467,y:688,t:1527268629250};\\\", \\\"{x:1467,y:689,t:1527268629269};\\\", \\\"{x:1467,y:690,t:1527268629283};\\\", \\\"{x:1467,y:691,t:1527268629300};\\\", \\\"{x:1466,y:692,t:1527268629316};\\\", \\\"{x:1458,y:695,t:1527268629332};\\\", \\\"{x:1448,y:696,t:1527268629349};\\\", \\\"{x:1440,y:696,t:1527268629366};\\\", \\\"{x:1430,y:693,t:1527268629383};\\\", \\\"{x:1417,y:685,t:1527268629400};\\\", \\\"{x:1406,y:675,t:1527268629416};\\\", \\\"{x:1399,y:669,t:1527268629433};\\\", \\\"{x:1393,y:669,t:1527268629449};\\\", \\\"{x:1387,y:674,t:1527268629466};\\\", \\\"{x:1384,y:676,t:1527268629482};\\\", \\\"{x:1384,y:677,t:1527268629500};\\\", \\\"{x:1383,y:677,t:1527268629517};\\\", \\\"{x:1378,y:687,t:1527268629533};\\\", \\\"{x:1371,y:703,t:1527268629549};\\\", \\\"{x:1367,y:716,t:1527268629566};\\\", \\\"{x:1366,y:722,t:1527268629582};\\\", \\\"{x:1364,y:730,t:1527268629599};\\\", \\\"{x:1363,y:736,t:1527268629617};\\\", \\\"{x:1360,y:740,t:1527268629632};\\\", \\\"{x:1356,y:741,t:1527268629650};\\\", \\\"{x:1352,y:741,t:1527268629666};\\\", \\\"{x:1345,y:741,t:1527268629682};\\\", \\\"{x:1337,y:739,t:1527268629700};\\\", \\\"{x:1332,y:736,t:1527268629717};\\\", \\\"{x:1331,y:735,t:1527268629733};\\\", \\\"{x:1330,y:731,t:1527268629750};\\\", \\\"{x:1330,y:728,t:1527268629766};\\\", \\\"{x:1330,y:726,t:1527268629783};\\\", \\\"{x:1330,y:725,t:1527268629799};\\\", \\\"{x:1330,y:724,t:1527268629820};\\\", \\\"{x:1330,y:723,t:1527268629853};\\\", \\\"{x:1331,y:723,t:1527268629867};\\\", \\\"{x:1332,y:723,t:1527268629882};\\\", \\\"{x:1333,y:723,t:1527268629899};\\\", \\\"{x:1335,y:721,t:1527268629917};\\\", \\\"{x:1336,y:721,t:1527268629973};\\\", \\\"{x:1336,y:720,t:1527268629997};\\\", \\\"{x:1337,y:720,t:1527268630021};\\\", \\\"{x:1338,y:720,t:1527268630032};\\\", \\\"{x:1339,y:720,t:1527268630050};\\\", \\\"{x:1339,y:719,t:1527268630066};\\\", \\\"{x:1340,y:719,t:1527268630084};\\\", \\\"{x:1341,y:718,t:1527268630100};\\\", \\\"{x:1343,y:715,t:1527268630117};\\\", \\\"{x:1344,y:713,t:1527268630133};\\\", \\\"{x:1344,y:712,t:1527268630150};\\\", \\\"{x:1344,y:711,t:1527268630270};\\\", \\\"{x:1346,y:708,t:1527268630285};\\\", \\\"{x:1346,y:706,t:1527268630309};\\\", \\\"{x:1346,y:705,t:1527268630333};\\\", \\\"{x:1347,y:704,t:1527268630349};\\\", \\\"{x:1347,y:703,t:1527268630367};\\\", \\\"{x:1347,y:702,t:1527268630391};\\\", \\\"{x:1348,y:701,t:1527268630416};\\\", \\\"{x:1348,y:700,t:1527268630436};\\\", \\\"{x:1347,y:699,t:1527268630524};\\\", \\\"{x:1346,y:699,t:1527268630533};\\\", \\\"{x:1344,y:698,t:1527268630550};\\\", \\\"{x:1343,y:697,t:1527268630676};\\\", \\\"{x:1344,y:697,t:1527268631389};\\\", \\\"{x:1345,y:697,t:1527268631401};\\\", \\\"{x:1346,y:697,t:1527268631417};\\\", \\\"{x:1347,y:697,t:1527268631434};\\\", \\\"{x:1349,y:697,t:1527268631450};\\\", \\\"{x:1352,y:697,t:1527268631468};\\\", \\\"{x:1357,y:697,t:1527268631486};\\\", \\\"{x:1362,y:697,t:1527268631500};\\\", \\\"{x:1367,y:697,t:1527268631517};\\\", \\\"{x:1372,y:697,t:1527268631535};\\\", \\\"{x:1380,y:701,t:1527268631551};\\\", \\\"{x:1388,y:702,t:1527268631568};\\\", \\\"{x:1398,y:706,t:1527268631585};\\\", \\\"{x:1408,y:707,t:1527268631601};\\\", \\\"{x:1411,y:707,t:1527268631618};\\\", \\\"{x:1415,y:709,t:1527268631634};\\\", \\\"{x:1418,y:709,t:1527268631650};\\\", \\\"{x:1419,y:709,t:1527268631666};\\\", \\\"{x:1423,y:709,t:1527268631683};\\\", \\\"{x:1427,y:709,t:1527268631699};\\\", \\\"{x:1432,y:709,t:1527268631717};\\\", \\\"{x:1439,y:709,t:1527268631734};\\\", \\\"{x:1448,y:709,t:1527268631750};\\\", \\\"{x:1461,y:709,t:1527268631766};\\\", \\\"{x:1476,y:709,t:1527268631784};\\\", \\\"{x:1490,y:709,t:1527268631800};\\\", \\\"{x:1503,y:709,t:1527268631817};\\\", \\\"{x:1515,y:709,t:1527268631834};\\\", \\\"{x:1524,y:709,t:1527268631851};\\\", \\\"{x:1534,y:709,t:1527268631867};\\\", \\\"{x:1559,y:709,t:1527268631884};\\\", \\\"{x:1574,y:709,t:1527268631900};\\\", \\\"{x:1588,y:709,t:1527268631917};\\\", \\\"{x:1596,y:709,t:1527268631934};\\\", \\\"{x:1602,y:709,t:1527268631950};\\\", \\\"{x:1605,y:709,t:1527268631967};\\\", \\\"{x:1609,y:709,t:1527268631984};\\\", \\\"{x:1611,y:709,t:1527268632001};\\\", \\\"{x:1612,y:709,t:1527268632018};\\\", \\\"{x:1614,y:709,t:1527268632035};\\\", \\\"{x:1615,y:709,t:1527268632052};\\\", \\\"{x:1617,y:709,t:1527268632067};\\\", \\\"{x:1618,y:708,t:1527268632084};\\\", \\\"{x:1620,y:707,t:1527268632108};\\\", \\\"{x:1620,y:706,t:1527268632413};\\\", \\\"{x:1620,y:704,t:1527268632509};\\\", \\\"{x:1620,y:703,t:1527268632533};\\\", \\\"{x:1620,y:701,t:1527268632645};\\\", \\\"{x:1620,y:700,t:1527268632653};\\\", \\\"{x:1620,y:698,t:1527268632670};\\\", \\\"{x:1620,y:697,t:1527268632701};\\\", \\\"{x:1620,y:696,t:1527268632719};\\\", \\\"{x:1620,y:695,t:1527268632734};\\\", \\\"{x:1620,y:694,t:1527268632758};\\\", \\\"{x:1620,y:693,t:1527268632769};\\\", \\\"{x:1620,y:692,t:1527268632785};\\\", \\\"{x:1620,y:691,t:1527268632802};\\\", \\\"{x:1620,y:690,t:1527268632819};\\\", \\\"{x:1620,y:689,t:1527268632835};\\\", \\\"{x:1620,y:688,t:1527268632909};\\\", \\\"{x:1619,y:688,t:1527268633902};\\\", \\\"{x:1618,y:690,t:1527268633909};\\\", \\\"{x:1618,y:691,t:1527268633925};\\\", \\\"{x:1618,y:692,t:1527268633941};\\\", \\\"{x:1618,y:693,t:1527268633996};\\\", \\\"{x:1617,y:694,t:1527268634101};\\\", \\\"{x:1617,y:695,t:1527268634139};\\\", \\\"{x:1617,y:696,t:1527268634179};\\\", \\\"{x:1617,y:697,t:1527268634187};\\\", \\\"{x:1617,y:698,t:1527268634202};\\\", \\\"{x:1616,y:698,t:1527268634219};\\\", \\\"{x:1616,y:699,t:1527268634235};\\\", \\\"{x:1616,y:700,t:1527268634252};\\\", \\\"{x:1616,y:701,t:1527268634269};\\\", \\\"{x:1616,y:702,t:1527268634286};\\\", \\\"{x:1616,y:703,t:1527268634325};\\\", \\\"{x:1615,y:705,t:1527268635149};\\\", \\\"{x:1615,y:708,t:1527268635157};\\\", \\\"{x:1615,y:712,t:1527268635170};\\\", \\\"{x:1615,y:722,t:1527268635190};\\\", \\\"{x:1615,y:731,t:1527268635207};\\\", \\\"{x:1615,y:737,t:1527268635224};\\\", \\\"{x:1615,y:741,t:1527268635241};\\\", \\\"{x:1615,y:743,t:1527268635258};\\\", \\\"{x:1615,y:744,t:1527268635274};\\\", \\\"{x:1615,y:745,t:1527268635291};\\\", \\\"{x:1615,y:747,t:1527268635308};\\\", \\\"{x:1615,y:749,t:1527268635323};\\\", \\\"{x:1615,y:750,t:1527268635341};\\\", \\\"{x:1616,y:752,t:1527268635357};\\\", \\\"{x:1616,y:753,t:1527268635376};\\\", \\\"{x:1616,y:755,t:1527268635399};\\\", \\\"{x:1616,y:753,t:1527268635680};\\\", \\\"{x:1616,y:751,t:1527268635691};\\\", \\\"{x:1616,y:746,t:1527268635708};\\\", \\\"{x:1616,y:742,t:1527268635724};\\\", \\\"{x:1616,y:738,t:1527268635741};\\\", \\\"{x:1617,y:734,t:1527268635757};\\\", \\\"{x:1617,y:727,t:1527268635774};\\\", \\\"{x:1617,y:722,t:1527268635791};\\\", \\\"{x:1617,y:714,t:1527268635808};\\\", \\\"{x:1626,y:682,t:1527268635824};\\\", \\\"{x:1630,y:658,t:1527268635841};\\\", \\\"{x:1634,y:639,t:1527268635858};\\\", \\\"{x:1634,y:629,t:1527268635875};\\\", \\\"{x:1634,y:619,t:1527268635892};\\\", \\\"{x:1634,y:615,t:1527268635908};\\\", \\\"{x:1634,y:612,t:1527268635925};\\\", \\\"{x:1634,y:610,t:1527268635942};\\\", \\\"{x:1633,y:608,t:1527268635958};\\\", \\\"{x:1633,y:606,t:1527268635975};\\\", \\\"{x:1631,y:605,t:1527268635992};\\\", \\\"{x:1630,y:604,t:1527268636008};\\\", \\\"{x:1628,y:603,t:1527268636025};\\\", \\\"{x:1626,y:603,t:1527268636042};\\\", \\\"{x:1623,y:603,t:1527268636058};\\\", \\\"{x:1618,y:603,t:1527268636075};\\\", \\\"{x:1609,y:603,t:1527268636092};\\\", \\\"{x:1593,y:611,t:1527268636108};\\\", \\\"{x:1577,y:621,t:1527268636125};\\\", \\\"{x:1559,y:631,t:1527268636143};\\\", \\\"{x:1547,y:638,t:1527268636158};\\\", \\\"{x:1540,y:641,t:1527268636175};\\\", \\\"{x:1537,y:642,t:1527268636192};\\\", \\\"{x:1535,y:643,t:1527268636207};\\\", \\\"{x:1529,y:644,t:1527268636225};\\\", \\\"{x:1524,y:645,t:1527268636241};\\\", \\\"{x:1518,y:645,t:1527268636257};\\\", \\\"{x:1511,y:645,t:1527268636275};\\\", \\\"{x:1503,y:645,t:1527268636292};\\\", \\\"{x:1499,y:645,t:1527268636309};\\\", \\\"{x:1495,y:644,t:1527268636325};\\\", \\\"{x:1492,y:643,t:1527268636341};\\\", \\\"{x:1489,y:641,t:1527268636359};\\\", \\\"{x:1484,y:638,t:1527268636375};\\\", \\\"{x:1480,y:635,t:1527268636392};\\\", \\\"{x:1470,y:629,t:1527268636409};\\\", \\\"{x:1465,y:628,t:1527268636425};\\\", \\\"{x:1460,y:626,t:1527268636442};\\\", \\\"{x:1458,y:626,t:1527268636593};\\\", \\\"{x:1454,y:626,t:1527268636609};\\\", \\\"{x:1452,y:628,t:1527268636625};\\\", \\\"{x:1449,y:630,t:1527268636642};\\\", \\\"{x:1446,y:632,t:1527268636659};\\\", \\\"{x:1445,y:632,t:1527268636689};\\\", \\\"{x:1444,y:633,t:1527268636703};\\\", \\\"{x:1443,y:633,t:1527268636719};\\\", \\\"{x:1443,y:634,t:1527268636736};\\\", \\\"{x:1442,y:635,t:1527268636759};\\\", \\\"{x:1440,y:635,t:1527268636775};\\\", \\\"{x:1439,y:638,t:1527268636792};\\\", \\\"{x:1437,y:638,t:1527268636808};\\\", \\\"{x:1437,y:639,t:1527268636832};\\\", \\\"{x:1437,y:638,t:1527268637840};\\\", \\\"{x:1437,y:636,t:1527268637903};\\\", \\\"{x:1438,y:636,t:1527268637911};\\\", \\\"{x:1439,y:634,t:1527268637927};\\\", \\\"{x:1440,y:634,t:1527268637943};\\\", \\\"{x:1442,y:633,t:1527268637959};\\\", \\\"{x:1444,y:632,t:1527268637975};\\\", \\\"{x:1444,y:631,t:1527268637992};\\\", \\\"{x:1445,y:631,t:1527268638009};\\\", \\\"{x:1447,y:631,t:1527268638025};\\\", \\\"{x:1448,y:629,t:1527268638042};\\\", \\\"{x:1449,y:629,t:1527268638059};\\\", \\\"{x:1450,y:628,t:1527268638080};\\\", \\\"{x:1452,y:627,t:1527268638112};\\\", \\\"{x:1453,y:626,t:1527268638126};\\\", \\\"{x:1455,y:626,t:1527268638145};\\\", \\\"{x:1455,y:625,t:1527268638160};\\\", \\\"{x:1456,y:625,t:1527268638785};\\\", \\\"{x:1460,y:624,t:1527268638794};\\\", \\\"{x:1473,y:621,t:1527268638810};\\\", \\\"{x:1490,y:619,t:1527268638827};\\\", \\\"{x:1513,y:619,t:1527268638844};\\\", \\\"{x:1554,y:619,t:1527268638860};\\\", \\\"{x:1612,y:619,t:1527268638877};\\\", \\\"{x:1711,y:624,t:1527268638894};\\\", \\\"{x:1816,y:638,t:1527268638910};\\\", \\\"{x:1917,y:646,t:1527268638927};\\\", \\\"{x:1919,y:648,t:1527268638944};\\\", \\\"{x:1918,y:650,t:1527268639073};\\\", \\\"{x:1908,y:650,t:1527268639080};\\\", \\\"{x:1894,y:650,t:1527268639095};\\\", \\\"{x:1839,y:650,t:1527268639110};\\\", \\\"{x:1742,y:650,t:1527268639127};\\\", \\\"{x:1540,y:650,t:1527268639143};\\\", \\\"{x:1382,y:650,t:1527268639160};\\\", \\\"{x:1208,y:649,t:1527268639177};\\\", \\\"{x:1050,y:625,t:1527268639194};\\\", \\\"{x:922,y:606,t:1527268639211};\\\", \\\"{x:839,y:595,t:1527268639228};\\\", \\\"{x:810,y:590,t:1527268639244};\\\", \\\"{x:807,y:590,t:1527268639260};\\\", \\\"{x:806,y:590,t:1527268639336};\\\", \\\"{x:808,y:587,t:1527268639351};\\\", \\\"{x:815,y:585,t:1527268639360};\\\", \\\"{x:831,y:581,t:1527268639378};\\\", \\\"{x:848,y:578,t:1527268639395};\\\", \\\"{x:868,y:575,t:1527268639410};\\\", \\\"{x:895,y:568,t:1527268639427};\\\", \\\"{x:955,y:553,t:1527268639445};\\\", \\\"{x:1043,y:534,t:1527268639461};\\\", \\\"{x:1127,y:521,t:1527268639478};\\\", \\\"{x:1208,y:508,t:1527268639494};\\\", \\\"{x:1258,y:500,t:1527268639511};\\\", \\\"{x:1282,y:497,t:1527268639527};\\\", \\\"{x:1291,y:495,t:1527268639544};\\\", \\\"{x:1291,y:497,t:1527268639657};\\\", \\\"{x:1291,y:498,t:1527268639664};\\\", \\\"{x:1291,y:500,t:1527268639678};\\\", \\\"{x:1292,y:502,t:1527268639695};\\\", \\\"{x:1294,y:508,t:1527268639712};\\\", \\\"{x:1297,y:517,t:1527268639728};\\\", \\\"{x:1300,y:524,t:1527268639744};\\\", \\\"{x:1304,y:530,t:1527268639762};\\\", \\\"{x:1307,y:533,t:1527268639779};\\\", \\\"{x:1308,y:534,t:1527268639795};\\\", \\\"{x:1308,y:535,t:1527268639945};\\\", \\\"{x:1308,y:537,t:1527268639962};\\\", \\\"{x:1307,y:541,t:1527268639979};\\\", \\\"{x:1304,y:543,t:1527268639996};\\\", \\\"{x:1301,y:547,t:1527268640012};\\\", \\\"{x:1296,y:550,t:1527268640029};\\\", \\\"{x:1291,y:553,t:1527268640046};\\\", \\\"{x:1288,y:555,t:1527268640062};\\\", \\\"{x:1287,y:556,t:1527268640079};\\\", \\\"{x:1286,y:557,t:1527268640096};\\\", \\\"{x:1284,y:559,t:1527268640113};\\\", \\\"{x:1283,y:560,t:1527268640128};\\\", \\\"{x:1282,y:561,t:1527268640192};\\\", \\\"{x:1284,y:561,t:1527268640561};\\\", \\\"{x:1288,y:561,t:1527268640569};\\\", \\\"{x:1292,y:561,t:1527268640580};\\\", \\\"{x:1305,y:561,t:1527268640596};\\\", \\\"{x:1322,y:561,t:1527268640613};\\\", \\\"{x:1336,y:561,t:1527268640630};\\\", \\\"{x:1343,y:561,t:1527268640646};\\\", \\\"{x:1349,y:561,t:1527268640663};\\\", \\\"{x:1352,y:561,t:1527268640680};\\\", \\\"{x:1359,y:561,t:1527268640696};\\\", \\\"{x:1375,y:561,t:1527268640713};\\\", \\\"{x:1394,y:561,t:1527268640730};\\\", \\\"{x:1413,y:561,t:1527268640746};\\\", \\\"{x:1431,y:561,t:1527268640764};\\\", \\\"{x:1439,y:561,t:1527268640780};\\\", \\\"{x:1441,y:561,t:1527268640796};\\\", \\\"{x:1443,y:561,t:1527268640833};\\\", \\\"{x:1444,y:561,t:1527268640856};\\\", \\\"{x:1446,y:561,t:1527268640864};\\\", \\\"{x:1448,y:561,t:1527268640880};\\\", \\\"{x:1460,y:561,t:1527268640897};\\\", \\\"{x:1470,y:561,t:1527268640913};\\\", \\\"{x:1482,y:560,t:1527268640930};\\\", \\\"{x:1493,y:560,t:1527268640947};\\\", \\\"{x:1501,y:560,t:1527268640963};\\\", \\\"{x:1505,y:560,t:1527268640980};\\\", \\\"{x:1508,y:560,t:1527268640997};\\\", \\\"{x:1514,y:560,t:1527268641013};\\\", \\\"{x:1520,y:560,t:1527268641030};\\\", \\\"{x:1528,y:560,t:1527268641047};\\\", \\\"{x:1540,y:560,t:1527268641063};\\\", \\\"{x:1549,y:560,t:1527268641080};\\\", \\\"{x:1559,y:560,t:1527268641097};\\\", \\\"{x:1561,y:560,t:1527268641114};\\\", \\\"{x:1562,y:560,t:1527268641130};\\\", \\\"{x:1563,y:560,t:1527268641160};\\\", \\\"{x:1564,y:560,t:1527268641169};\\\", \\\"{x:1565,y:559,t:1527268641180};\\\", \\\"{x:1568,y:559,t:1527268641198};\\\", \\\"{x:1572,y:557,t:1527268641214};\\\", \\\"{x:1574,y:556,t:1527268641233};\\\", \\\"{x:1575,y:556,t:1527268641247};\\\", \\\"{x:1581,y:555,t:1527268641264};\\\", \\\"{x:1583,y:554,t:1527268641281};\\\", \\\"{x:1588,y:553,t:1527268641298};\\\", \\\"{x:1591,y:553,t:1527268641314};\\\", \\\"{x:1595,y:552,t:1527268641330};\\\", \\\"{x:1598,y:552,t:1527268641347};\\\", \\\"{x:1600,y:552,t:1527268641364};\\\", \\\"{x:1606,y:552,t:1527268641381};\\\", \\\"{x:1611,y:552,t:1527268641397};\\\", \\\"{x:1617,y:552,t:1527268641414};\\\", \\\"{x:1625,y:552,t:1527268641431};\\\", \\\"{x:1629,y:552,t:1527268641447};\\\", \\\"{x:1633,y:552,t:1527268641465};\\\", \\\"{x:1639,y:552,t:1527268641480};\\\", \\\"{x:1644,y:554,t:1527268641498};\\\", \\\"{x:1650,y:554,t:1527268641514};\\\", \\\"{x:1657,y:554,t:1527268641531};\\\", \\\"{x:1663,y:555,t:1527268641547};\\\", \\\"{x:1669,y:557,t:1527268641564};\\\", \\\"{x:1672,y:557,t:1527268641581};\\\", \\\"{x:1675,y:557,t:1527268641597};\\\", \\\"{x:1677,y:557,t:1527268641616};\\\", \\\"{x:1678,y:557,t:1527268641682};\\\", \\\"{x:1680,y:557,t:1527268641729};\\\", \\\"{x:1681,y:558,t:1527268641993};\\\", \\\"{x:1681,y:559,t:1527268642009};\\\", \\\"{x:1679,y:560,t:1527268642024};\\\", \\\"{x:1677,y:561,t:1527268642049};\\\", \\\"{x:1676,y:561,t:1527268642089};\\\", \\\"{x:1675,y:561,t:1527268642105};\\\", \\\"{x:1674,y:561,t:1527268642115};\\\", \\\"{x:1670,y:561,t:1527268642132};\\\", \\\"{x:1667,y:561,t:1527268642148};\\\", \\\"{x:1663,y:561,t:1527268642165};\\\", \\\"{x:1660,y:561,t:1527268642182};\\\", \\\"{x:1655,y:561,t:1527268642198};\\\", \\\"{x:1650,y:561,t:1527268642215};\\\", \\\"{x:1640,y:558,t:1527268642232};\\\", \\\"{x:1631,y:555,t:1527268642249};\\\", \\\"{x:1622,y:550,t:1527268642265};\\\", \\\"{x:1608,y:539,t:1527268642283};\\\", \\\"{x:1595,y:528,t:1527268642298};\\\", \\\"{x:1575,y:512,t:1527268642315};\\\", \\\"{x:1560,y:501,t:1527268642332};\\\", \\\"{x:1541,y:485,t:1527268642348};\\\", \\\"{x:1524,y:468,t:1527268642365};\\\", \\\"{x:1506,y:455,t:1527268642383};\\\", \\\"{x:1492,y:446,t:1527268642398};\\\", \\\"{x:1486,y:442,t:1527268642416};\\\", \\\"{x:1485,y:442,t:1527268642489};\\\", \\\"{x:1484,y:442,t:1527268642499};\\\", \\\"{x:1481,y:442,t:1527268642515};\\\", \\\"{x:1480,y:442,t:1527268642532};\\\", \\\"{x:1477,y:442,t:1527268642549};\\\", \\\"{x:1473,y:442,t:1527268642565};\\\", \\\"{x:1469,y:443,t:1527268642581};\\\", \\\"{x:1458,y:443,t:1527268642599};\\\", \\\"{x:1442,y:443,t:1527268642614};\\\", \\\"{x:1422,y:442,t:1527268642631};\\\", \\\"{x:1414,y:441,t:1527268642648};\\\", \\\"{x:1411,y:440,t:1527268642665};\\\", \\\"{x:1409,y:439,t:1527268642681};\\\", \\\"{x:1408,y:438,t:1527268642699};\\\", \\\"{x:1407,y:437,t:1527268642760};\\\", \\\"{x:1407,y:436,t:1527268643049};\\\", \\\"{x:1407,y:435,t:1527268643065};\\\", \\\"{x:1407,y:433,t:1527268643082};\\\", \\\"{x:1407,y:432,t:1527268643099};\\\", \\\"{x:1407,y:430,t:1527268643115};\\\", \\\"{x:1407,y:429,t:1527268643132};\\\", \\\"{x:1407,y:428,t:1527268643148};\\\", \\\"{x:1407,y:427,t:1527268643166};\\\", \\\"{x:1406,y:426,t:1527268643183};\\\", \\\"{x:1406,y:425,t:1527268643200};\\\", \\\"{x:1404,y:422,t:1527268643216};\\\", \\\"{x:1396,y:416,t:1527268643232};\\\", \\\"{x:1370,y:405,t:1527268643250};\\\", \\\"{x:1310,y:396,t:1527268643266};\\\", \\\"{x:1186,y:379,t:1527268643283};\\\", \\\"{x:1010,y:363,t:1527268643300};\\\", \\\"{x:791,y:352,t:1527268643316};\\\", \\\"{x:564,y:345,t:1527268643333};\\\", \\\"{x:365,y:343,t:1527268643349};\\\", \\\"{x:210,y:340,t:1527268643365};\\\", \\\"{x:110,y:340,t:1527268643383};\\\", \\\"{x:54,y:351,t:1527268643400};\\\", \\\"{x:43,y:360,t:1527268643416};\\\", \\\"{x:39,y:371,t:1527268643433};\\\", \\\"{x:39,y:381,t:1527268643450};\\\", \\\"{x:43,y:393,t:1527268643465};\\\", \\\"{x:48,y:401,t:1527268643483};\\\", \\\"{x:52,y:409,t:1527268643499};\\\", \\\"{x:58,y:419,t:1527268643516};\\\", \\\"{x:65,y:432,t:1527268643532};\\\", \\\"{x:74,y:446,t:1527268643550};\\\", \\\"{x:81,y:462,t:1527268643567};\\\", \\\"{x:90,y:487,t:1527268643584};\\\", \\\"{x:102,y:532,t:1527268643601};\\\", \\\"{x:104,y:554,t:1527268643617};\\\", \\\"{x:107,y:566,t:1527268643630};\\\", \\\"{x:109,y:586,t:1527268643646};\\\", \\\"{x:113,y:598,t:1527268643664};\\\", \\\"{x:114,y:601,t:1527268643681};\\\", \\\"{x:115,y:602,t:1527268643751};\\\", \\\"{x:116,y:602,t:1527268643764};\\\", \\\"{x:122,y:602,t:1527268643782};\\\", \\\"{x:129,y:601,t:1527268643797};\\\", \\\"{x:137,y:596,t:1527268643815};\\\", \\\"{x:150,y:588,t:1527268643832};\\\", \\\"{x:156,y:584,t:1527268643847};\\\", \\\"{x:161,y:580,t:1527268643865};\\\", \\\"{x:165,y:579,t:1527268643881};\\\", \\\"{x:168,y:577,t:1527268643897};\\\", \\\"{x:170,y:576,t:1527268643915};\\\", \\\"{x:171,y:575,t:1527268643931};\\\", \\\"{x:174,y:573,t:1527268643949};\\\", \\\"{x:179,y:571,t:1527268643964};\\\", \\\"{x:184,y:568,t:1527268643982};\\\", \\\"{x:193,y:564,t:1527268643998};\\\", \\\"{x:221,y:559,t:1527268644016};\\\", \\\"{x:255,y:559,t:1527268644032};\\\", \\\"{x:308,y:559,t:1527268644048};\\\", \\\"{x:377,y:576,t:1527268644066};\\\", \\\"{x:446,y:609,t:1527268644082};\\\", \\\"{x:510,y:653,t:1527268644098};\\\", \\\"{x:562,y:704,t:1527268644115};\\\", \\\"{x:600,y:758,t:1527268644132};\\\", \\\"{x:621,y:793,t:1527268644148};\\\", \\\"{x:631,y:812,t:1527268644165};\\\", \\\"{x:636,y:821,t:1527268644181};\\\", \\\"{x:637,y:823,t:1527268644197};\\\", \\\"{x:637,y:821,t:1527268644240};\\\", \\\"{x:637,y:816,t:1527268644248};\\\", \\\"{x:636,y:809,t:1527268644265};\\\", \\\"{x:630,y:797,t:1527268644282};\\\", \\\"{x:623,y:784,t:1527268644297};\\\", \\\"{x:613,y:771,t:1527268644315};\\\", \\\"{x:601,y:756,t:1527268644331};\\\", \\\"{x:585,y:744,t:1527268644349};\\\", \\\"{x:574,y:738,t:1527268644365};\\\", \\\"{x:567,y:735,t:1527268644381};\\\", \\\"{x:561,y:734,t:1527268644400};\\\", \\\"{x:557,y:734,t:1527268644414};\\\", \\\"{x:554,y:734,t:1527268644431};\\\", \\\"{x:551,y:734,t:1527268644448};\\\", \\\"{x:547,y:734,t:1527268644464};\\\", \\\"{x:544,y:738,t:1527268644481};\\\", \\\"{x:542,y:740,t:1527268644498};\\\", \\\"{x:538,y:746,t:1527268644515};\\\", \\\"{x:535,y:749,t:1527268644531};\\\", \\\"{x:535,y:750,t:1527268644548};\\\", \\\"{x:535,y:753,t:1527268644565};\\\", \\\"{x:535,y:754,t:1527268644581};\\\", \\\"{x:535,y:755,t:1527268644599};\\\", \\\"{x:535,y:756,t:1527268644615};\\\", \\\"{x:535,y:754,t:1527268645034};\\\", \\\"{x:535,y:750,t:1527268645049};\\\", \\\"{x:535,y:748,t:1527268645065};\\\", \\\"{x:535,y:747,t:1527268645081};\\\", \\\"{x:535,y:744,t:1527268645098};\\\", \\\"{x:535,y:743,t:1527268645119};\\\", \\\"{x:530,y:739,t:1527268646241};\\\", \\\"{x:520,y:737,t:1527268646250};\\\", \\\"{x:490,y:728,t:1527268646266};\\\", \\\"{x:454,y:719,t:1527268646283};\\\" ] }, { \\\"rt\\\": 45703, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 716003, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 PM-04 PM-J -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:453,y:719,t:1527268646975};\\\", \\\"{x:451,y:717,t:1527268646983};\\\", \\\"{x:447,y:713,t:1527268647000};\\\", \\\"{x:447,y:712,t:1527268647016};\\\", \\\"{x:447,y:708,t:1527268647033};\\\", \\\"{x:451,y:703,t:1527268647050};\\\", \\\"{x:456,y:699,t:1527268647066};\\\", \\\"{x:504,y:660,t:1527268647153};\\\", \\\"{x:526,y:647,t:1527268647169};\\\", \\\"{x:543,y:632,t:1527268647183};\\\", \\\"{x:565,y:618,t:1527268647201};\\\", \\\"{x:599,y:602,t:1527268647217};\\\", \\\"{x:646,y:582,t:1527268647234};\\\", \\\"{x:690,y:564,t:1527268647251};\\\", \\\"{x:731,y:548,t:1527268647267};\\\", \\\"{x:768,y:535,t:1527268647284};\\\", \\\"{x:800,y:525,t:1527268647301};\\\", \\\"{x:821,y:520,t:1527268647317};\\\", \\\"{x:840,y:514,t:1527268647334};\\\", \\\"{x:862,y:511,t:1527268647351};\\\", \\\"{x:885,y:511,t:1527268647367};\\\", \\\"{x:921,y:511,t:1527268647384};\\\", \\\"{x:942,y:514,t:1527268647401};\\\", \\\"{x:960,y:520,t:1527268647417};\\\", \\\"{x:979,y:531,t:1527268647433};\\\", \\\"{x:995,y:538,t:1527268647451};\\\", \\\"{x:1009,y:547,t:1527268647468};\\\", \\\"{x:1019,y:553,t:1527268647483};\\\", \\\"{x:1028,y:558,t:1527268647501};\\\", \\\"{x:1034,y:562,t:1527268647518};\\\", \\\"{x:1036,y:563,t:1527268647535};\\\", \\\"{x:1036,y:564,t:1527268647550};\\\", \\\"{x:1038,y:565,t:1527268647567};\\\", \\\"{x:1039,y:565,t:1527268647632};\\\", \\\"{x:1039,y:566,t:1527268647687};\\\", \\\"{x:1039,y:567,t:1527268647719};\\\", \\\"{x:1039,y:568,t:1527268647776};\\\", \\\"{x:1039,y:571,t:1527268648529};\\\", \\\"{x:1037,y:571,t:1527268648537};\\\", \\\"{x:1033,y:574,t:1527268648553};\\\", \\\"{x:1030,y:575,t:1527268648570};\\\", \\\"{x:1026,y:577,t:1527268648587};\\\", \\\"{x:1019,y:578,t:1527268648603};\\\", \\\"{x:1011,y:579,t:1527268648620};\\\", \\\"{x:992,y:579,t:1527268648638};\\\", \\\"{x:968,y:579,t:1527268648654};\\\", \\\"{x:950,y:582,t:1527268648671};\\\", \\\"{x:947,y:582,t:1527268648686};\\\", \\\"{x:947,y:583,t:1527268649504};\\\", \\\"{x:947,y:584,t:1527268650233};\\\", \\\"{x:947,y:585,t:1527268650272};\\\", \\\"{x:946,y:586,t:1527268650288};\\\", \\\"{x:946,y:585,t:1527268654264};\\\", \\\"{x:946,y:583,t:1527268654312};\\\", \\\"{x:947,y:582,t:1527268654328};\\\", \\\"{x:947,y:581,t:1527268654368};\\\", \\\"{x:947,y:580,t:1527268654384};\\\", \\\"{x:948,y:579,t:1527268654657};\\\", \\\"{x:949,y:577,t:1527268656848};\\\", \\\"{x:956,y:574,t:1527268656861};\\\", \\\"{x:987,y:573,t:1527268656875};\\\", \\\"{x:1055,y:577,t:1527268656892};\\\", \\\"{x:1141,y:591,t:1527268656908};\\\", \\\"{x:1237,y:612,t:1527268656925};\\\", \\\"{x:1334,y:638,t:1527268656941};\\\", \\\"{x:1422,y:661,t:1527268656958};\\\", \\\"{x:1503,y:685,t:1527268656975};\\\", \\\"{x:1631,y:727,t:1527268656991};\\\", \\\"{x:1736,y:773,t:1527268657008};\\\", \\\"{x:1830,y:813,t:1527268657025};\\\", \\\"{x:1871,y:837,t:1527268657042};\\\", \\\"{x:1894,y:853,t:1527268657058};\\\", \\\"{x:1904,y:863,t:1527268657075};\\\", \\\"{x:1912,y:876,t:1527268657092};\\\", \\\"{x:1916,y:891,t:1527268657108};\\\", \\\"{x:1919,y:906,t:1527268657125};\\\", \\\"{x:1919,y:920,t:1527268657142};\\\", \\\"{x:1915,y:936,t:1527268657158};\\\", \\\"{x:1909,y:950,t:1527268657176};\\\", \\\"{x:1897,y:965,t:1527268657192};\\\", \\\"{x:1890,y:971,t:1527268657208};\\\", \\\"{x:1875,y:979,t:1527268657225};\\\", \\\"{x:1860,y:986,t:1527268657243};\\\", \\\"{x:1839,y:992,t:1527268657258};\\\", \\\"{x:1817,y:994,t:1527268657275};\\\", \\\"{x:1784,y:999,t:1527268657292};\\\", \\\"{x:1739,y:999,t:1527268657308};\\\", \\\"{x:1696,y:997,t:1527268657325};\\\", \\\"{x:1653,y:990,t:1527268657343};\\\", \\\"{x:1620,y:981,t:1527268657360};\\\", \\\"{x:1591,y:972,t:1527268657376};\\\", \\\"{x:1550,y:962,t:1527268657392};\\\", \\\"{x:1532,y:954,t:1527268657409};\\\", \\\"{x:1524,y:952,t:1527268657426};\\\", \\\"{x:1521,y:950,t:1527268657443};\\\", \\\"{x:1520,y:950,t:1527268657520};\\\", \\\"{x:1519,y:950,t:1527268657536};\\\", \\\"{x:1518,y:950,t:1527268657544};\\\", \\\"{x:1517,y:950,t:1527268657560};\\\", \\\"{x:1514,y:950,t:1527268657575};\\\", \\\"{x:1509,y:950,t:1527268657593};\\\", \\\"{x:1505,y:950,t:1527268657610};\\\", \\\"{x:1505,y:951,t:1527268657626};\\\", \\\"{x:1504,y:951,t:1527268657643};\\\", \\\"{x:1503,y:952,t:1527268657660};\\\", \\\"{x:1502,y:953,t:1527268657677};\\\", \\\"{x:1500,y:956,t:1527268657693};\\\", \\\"{x:1498,y:957,t:1527268657709};\\\", \\\"{x:1497,y:958,t:1527268657726};\\\", \\\"{x:1496,y:959,t:1527268657752};\\\", \\\"{x:1495,y:959,t:1527268657792};\\\", \\\"{x:1494,y:960,t:1527268657809};\\\", \\\"{x:1492,y:962,t:1527268657827};\\\", \\\"{x:1491,y:963,t:1527268657843};\\\", \\\"{x:1490,y:963,t:1527268657859};\\\", \\\"{x:1488,y:964,t:1527268657876};\\\", \\\"{x:1487,y:964,t:1527268657895};\\\", \\\"{x:1486,y:965,t:1527268657919};\\\", \\\"{x:1485,y:965,t:1527268657960};\\\", \\\"{x:1484,y:966,t:1527268657975};\\\", \\\"{x:1483,y:966,t:1527268658008};\\\", \\\"{x:1482,y:966,t:1527268658705};\\\", \\\"{x:1481,y:966,t:1527268658720};\\\", \\\"{x:1480,y:967,t:1527268658737};\\\", \\\"{x:1479,y:968,t:1527268658793};\\\", \\\"{x:1479,y:965,t:1527268663585};\\\", \\\"{x:1479,y:964,t:1527268663598};\\\", \\\"{x:1479,y:962,t:1527268663615};\\\", \\\"{x:1479,y:961,t:1527268663665};\\\", \\\"{x:1480,y:961,t:1527268664289};\\\", \\\"{x:1481,y:960,t:1527268665257};\\\", \\\"{x:1481,y:959,t:1527268665266};\\\", \\\"{x:1481,y:955,t:1527268665283};\\\", \\\"{x:1481,y:953,t:1527268665299};\\\", \\\"{x:1481,y:949,t:1527268665316};\\\", \\\"{x:1481,y:945,t:1527268665334};\\\", \\\"{x:1481,y:942,t:1527268665349};\\\", \\\"{x:1481,y:940,t:1527268665366};\\\", \\\"{x:1481,y:938,t:1527268665383};\\\", \\\"{x:1481,y:937,t:1527268665513};\\\", \\\"{x:1481,y:935,t:1527268665521};\\\", \\\"{x:1481,y:934,t:1527268665533};\\\", \\\"{x:1481,y:931,t:1527268665550};\\\", \\\"{x:1481,y:929,t:1527268665566};\\\", \\\"{x:1481,y:925,t:1527268665584};\\\", \\\"{x:1481,y:921,t:1527268665600};\\\", \\\"{x:1481,y:919,t:1527268665616};\\\", \\\"{x:1481,y:918,t:1527268667961};\\\", \\\"{x:1481,y:917,t:1527268667984};\\\", \\\"{x:1481,y:916,t:1527268669320};\\\", \\\"{x:1484,y:910,t:1527268669336};\\\", \\\"{x:1485,y:908,t:1527268669353};\\\", \\\"{x:1485,y:906,t:1527268669369};\\\", \\\"{x:1487,y:904,t:1527268669386};\\\", \\\"{x:1485,y:904,t:1527268672553};\\\", \\\"{x:1484,y:904,t:1527268672560};\\\", \\\"{x:1483,y:904,t:1527268672572};\\\", \\\"{x:1484,y:903,t:1527268672904};\\\", \\\"{x:1485,y:903,t:1527268672912};\\\", \\\"{x:1486,y:902,t:1527268672922};\\\", \\\"{x:1487,y:902,t:1527268672939};\\\", \\\"{x:1488,y:901,t:1527268672957};\\\", \\\"{x:1489,y:901,t:1527268672972};\\\", \\\"{x:1490,y:900,t:1527268673465};\\\", \\\"{x:1490,y:899,t:1527268673488};\\\", \\\"{x:1490,y:897,t:1527268673506};\\\", \\\"{x:1490,y:896,t:1527268673524};\\\", \\\"{x:1490,y:895,t:1527268673552};\\\", \\\"{x:1490,y:894,t:1527268673568};\\\", \\\"{x:1490,y:893,t:1527268673576};\\\", \\\"{x:1490,y:892,t:1527268673592};\\\", \\\"{x:1490,y:891,t:1527268673607};\\\", \\\"{x:1490,y:890,t:1527268673624};\\\", \\\"{x:1489,y:890,t:1527268673808};\\\", \\\"{x:1488,y:892,t:1527268673824};\\\", \\\"{x:1487,y:892,t:1527268673841};\\\", \\\"{x:1486,y:895,t:1527268673856};\\\", \\\"{x:1484,y:897,t:1527268673873};\\\", \\\"{x:1484,y:898,t:1527268673895};\\\", \\\"{x:1483,y:898,t:1527268673936};\\\", \\\"{x:1480,y:900,t:1527268675320};\\\", \\\"{x:1475,y:903,t:1527268675328};\\\", \\\"{x:1470,y:904,t:1527268675342};\\\", \\\"{x:1462,y:904,t:1527268675358};\\\", \\\"{x:1451,y:904,t:1527268675374};\\\", \\\"{x:1441,y:904,t:1527268675391};\\\", \\\"{x:1433,y:904,t:1527268675407};\\\", \\\"{x:1432,y:905,t:1527268675423};\\\", \\\"{x:1431,y:905,t:1527268675441};\\\", \\\"{x:1429,y:906,t:1527268675458};\\\", \\\"{x:1427,y:908,t:1527268675474};\\\", \\\"{x:1426,y:908,t:1527268675491};\\\", \\\"{x:1421,y:910,t:1527268675508};\\\", \\\"{x:1416,y:910,t:1527268675524};\\\", \\\"{x:1411,y:910,t:1527268675541};\\\", \\\"{x:1407,y:910,t:1527268675558};\\\", \\\"{x:1404,y:910,t:1527268675574};\\\", \\\"{x:1404,y:908,t:1527268675721};\\\", \\\"{x:1404,y:907,t:1527268675736};\\\", \\\"{x:1405,y:907,t:1527268675744};\\\", \\\"{x:1406,y:906,t:1527268675760};\\\", \\\"{x:1408,y:905,t:1527268675897};\\\", \\\"{x:1409,y:905,t:1527268675912};\\\", \\\"{x:1411,y:905,t:1527268675928};\\\", \\\"{x:1413,y:905,t:1527268675942};\\\", \\\"{x:1418,y:905,t:1527268675958};\\\", \\\"{x:1426,y:905,t:1527268675976};\\\", \\\"{x:1436,y:905,t:1527268675992};\\\", \\\"{x:1439,y:904,t:1527268676008};\\\", \\\"{x:1443,y:903,t:1527268676026};\\\", \\\"{x:1445,y:903,t:1527268676042};\\\", \\\"{x:1446,y:901,t:1527268676059};\\\", \\\"{x:1448,y:901,t:1527268676075};\\\", \\\"{x:1448,y:900,t:1527268676120};\\\", \\\"{x:1449,y:900,t:1527268676136};\\\", \\\"{x:1450,y:899,t:1527268676144};\\\", \\\"{x:1443,y:897,t:1527268676984};\\\", \\\"{x:1431,y:896,t:1527268676993};\\\", \\\"{x:1400,y:890,t:1527268677010};\\\", \\\"{x:1347,y:875,t:1527268677026};\\\", \\\"{x:1294,y:861,t:1527268677043};\\\", \\\"{x:1252,y:849,t:1527268677060};\\\", \\\"{x:1218,y:837,t:1527268677076};\\\", \\\"{x:1203,y:831,t:1527268677091};\\\", \\\"{x:1196,y:827,t:1527268677109};\\\", \\\"{x:1193,y:824,t:1527268677125};\\\", \\\"{x:1193,y:822,t:1527268677167};\\\", \\\"{x:1192,y:821,t:1527268677191};\\\", \\\"{x:1191,y:820,t:1527268677206};\\\", \\\"{x:1194,y:820,t:1527268677481};\\\", \\\"{x:1201,y:819,t:1527268677494};\\\", \\\"{x:1213,y:819,t:1527268677510};\\\", \\\"{x:1224,y:819,t:1527268677527};\\\", \\\"{x:1241,y:818,t:1527268677544};\\\", \\\"{x:1250,y:818,t:1527268677560};\\\", \\\"{x:1255,y:818,t:1527268677576};\\\", \\\"{x:1260,y:818,t:1527268677594};\\\", \\\"{x:1265,y:818,t:1527268677609};\\\", \\\"{x:1273,y:818,t:1527268677627};\\\", \\\"{x:1280,y:818,t:1527268677644};\\\", \\\"{x:1287,y:818,t:1527268677659};\\\", \\\"{x:1294,y:818,t:1527268677677};\\\", \\\"{x:1296,y:818,t:1527268677693};\\\", \\\"{x:1297,y:818,t:1527268677710};\\\", \\\"{x:1298,y:818,t:1527268677728};\\\", \\\"{x:1299,y:818,t:1527268677760};\\\", \\\"{x:1304,y:818,t:1527268677777};\\\", \\\"{x:1308,y:818,t:1527268677794};\\\", \\\"{x:1311,y:818,t:1527268677810};\\\", \\\"{x:1313,y:817,t:1527268677827};\\\", \\\"{x:1314,y:817,t:1527268677864};\\\", \\\"{x:1315,y:817,t:1527268677880};\\\", \\\"{x:1316,y:817,t:1527268677896};\\\", \\\"{x:1317,y:817,t:1527268677911};\\\", \\\"{x:1320,y:817,t:1527268677927};\\\", \\\"{x:1326,y:819,t:1527268677944};\\\", \\\"{x:1329,y:820,t:1527268677960};\\\", \\\"{x:1331,y:820,t:1527268677976};\\\", \\\"{x:1332,y:821,t:1527268678000};\\\", \\\"{x:1333,y:821,t:1527268678010};\\\", \\\"{x:1335,y:821,t:1527268678027};\\\", \\\"{x:1337,y:821,t:1527268678043};\\\", \\\"{x:1339,y:821,t:1527268678060};\\\", \\\"{x:1340,y:821,t:1527268678076};\\\", \\\"{x:1341,y:821,t:1527268678144};\\\", \\\"{x:1343,y:821,t:1527268678167};\\\", \\\"{x:1346,y:822,t:1527268678183};\\\", \\\"{x:1348,y:823,t:1527268678193};\\\", \\\"{x:1352,y:826,t:1527268678210};\\\", \\\"{x:1355,y:829,t:1527268678227};\\\", \\\"{x:1358,y:831,t:1527268678243};\\\", \\\"{x:1359,y:831,t:1527268678260};\\\", \\\"{x:1358,y:831,t:1527268678856};\\\", \\\"{x:1356,y:831,t:1527268678864};\\\", \\\"{x:1355,y:831,t:1527268678877};\\\", \\\"{x:1354,y:832,t:1527268678895};\\\", \\\"{x:1352,y:832,t:1527268678910};\\\", \\\"{x:1351,y:833,t:1527268678927};\\\", \\\"{x:1352,y:833,t:1527268680616};\\\", \\\"{x:1353,y:831,t:1527268680632};\\\", \\\"{x:1354,y:830,t:1527268680648};\\\", \\\"{x:1355,y:829,t:1527268680663};\\\", \\\"{x:1355,y:828,t:1527268680680};\\\", \\\"{x:1356,y:827,t:1527268680696};\\\", \\\"{x:1357,y:826,t:1527268680712};\\\", \\\"{x:1358,y:824,t:1527268680729};\\\", \\\"{x:1359,y:823,t:1527268680760};\\\", \\\"{x:1360,y:823,t:1527268680768};\\\", \\\"{x:1361,y:821,t:1527268680791};\\\", \\\"{x:1362,y:821,t:1527268680824};\\\", \\\"{x:1363,y:821,t:1527268680840};\\\", \\\"{x:1365,y:820,t:1527268680848};\\\", \\\"{x:1367,y:819,t:1527268680872};\\\", \\\"{x:1368,y:818,t:1527268680888};\\\", \\\"{x:1372,y:817,t:1527268680896};\\\", \\\"{x:1378,y:817,t:1527268680913};\\\", \\\"{x:1391,y:815,t:1527268680930};\\\", \\\"{x:1407,y:815,t:1527268680946};\\\", \\\"{x:1425,y:815,t:1527268680963};\\\", \\\"{x:1442,y:815,t:1527268680980};\\\", \\\"{x:1462,y:815,t:1527268680996};\\\", \\\"{x:1477,y:815,t:1527268681013};\\\", \\\"{x:1486,y:815,t:1527268681030};\\\", \\\"{x:1496,y:815,t:1527268681047};\\\", \\\"{x:1509,y:815,t:1527268681062};\\\", \\\"{x:1522,y:815,t:1527268681080};\\\", \\\"{x:1527,y:816,t:1527268681096};\\\", \\\"{x:1530,y:816,t:1527268681113};\\\", \\\"{x:1531,y:816,t:1527268681129};\\\", \\\"{x:1532,y:816,t:1527268681147};\\\", \\\"{x:1533,y:817,t:1527268681163};\\\", \\\"{x:1528,y:817,t:1527268682072};\\\", \\\"{x:1514,y:817,t:1527268682080};\\\", \\\"{x:1464,y:813,t:1527268682097};\\\", \\\"{x:1350,y:797,t:1527268682114};\\\", \\\"{x:1207,y:755,t:1527268682131};\\\", \\\"{x:1046,y:702,t:1527268682146};\\\", \\\"{x:867,y:633,t:1527268682165};\\\", \\\"{x:703,y:542,t:1527268682181};\\\", \\\"{x:562,y:448,t:1527268682197};\\\", \\\"{x:385,y:348,t:1527268682229};\\\", \\\"{x:338,y:328,t:1527268682245};\\\", \\\"{x:327,y:322,t:1527268682262};\\\", \\\"{x:323,y:320,t:1527268682279};\\\", \\\"{x:324,y:320,t:1527268682415};\\\", \\\"{x:332,y:320,t:1527268682430};\\\", \\\"{x:357,y:326,t:1527268682447};\\\", \\\"{x:390,y:337,t:1527268682463};\\\", \\\"{x:452,y:358,t:1527268682479};\\\", \\\"{x:489,y:375,t:1527268682496};\\\", \\\"{x:521,y:394,t:1527268682512};\\\", \\\"{x:544,y:409,t:1527268682529};\\\", \\\"{x:559,y:421,t:1527268682546};\\\", \\\"{x:567,y:428,t:1527268682562};\\\", \\\"{x:574,y:438,t:1527268682579};\\\", \\\"{x:575,y:445,t:1527268682596};\\\", \\\"{x:580,y:460,t:1527268682612};\\\", \\\"{x:580,y:473,t:1527268682629};\\\", \\\"{x:580,y:485,t:1527268682646};\\\", \\\"{x:580,y:500,t:1527268682662};\\\", \\\"{x:569,y:527,t:1527268682680};\\\", \\\"{x:561,y:538,t:1527268682698};\\\", \\\"{x:554,y:550,t:1527268682713};\\\", \\\"{x:549,y:560,t:1527268682729};\\\", \\\"{x:547,y:564,t:1527268682746};\\\", \\\"{x:547,y:566,t:1527268682762};\\\", \\\"{x:547,y:567,t:1527268682780};\\\", \\\"{x:548,y:567,t:1527268682848};\\\", \\\"{x:552,y:567,t:1527268682862};\\\", \\\"{x:575,y:567,t:1527268682879};\\\", \\\"{x:593,y:567,t:1527268682896};\\\", \\\"{x:605,y:568,t:1527268682913};\\\", \\\"{x:609,y:570,t:1527268682931};\\\", \\\"{x:610,y:570,t:1527268682946};\\\", \\\"{x:611,y:572,t:1527268683184};\\\", \\\"{x:612,y:576,t:1527268683196};\\\", \\\"{x:612,y:579,t:1527268683214};\\\", \\\"{x:612,y:582,t:1527268683230};\\\", \\\"{x:612,y:585,t:1527268683247};\\\", \\\"{x:612,y:586,t:1527268683263};\\\", \\\"{x:612,y:585,t:1527268683470};\\\", \\\"{x:612,y:583,t:1527268683487};\\\", \\\"{x:612,y:582,t:1527268683496};\\\", \\\"{x:612,y:580,t:1527268683513};\\\", \\\"{x:612,y:579,t:1527268683543};\\\", \\\"{x:613,y:579,t:1527268683551};\\\", \\\"{x:614,y:578,t:1527268683575};\\\", \\\"{x:617,y:576,t:1527268683599};\\\", \\\"{x:619,y:575,t:1527268683613};\\\", \\\"{x:629,y:570,t:1527268683630};\\\", \\\"{x:646,y:561,t:1527268683647};\\\", \\\"{x:685,y:545,t:1527268683663};\\\", \\\"{x:729,y:533,t:1527268683681};\\\", \\\"{x:774,y:519,t:1527268683696};\\\", \\\"{x:822,y:512,t:1527268683713};\\\", \\\"{x:868,y:503,t:1527268683730};\\\", \\\"{x:902,y:498,t:1527268683747};\\\", \\\"{x:924,y:494,t:1527268683763};\\\", \\\"{x:938,y:492,t:1527268683780};\\\", \\\"{x:948,y:491,t:1527268683797};\\\", \\\"{x:952,y:490,t:1527268683813};\\\", \\\"{x:954,y:490,t:1527268683830};\\\", \\\"{x:956,y:490,t:1527268683952};\\\", \\\"{x:956,y:493,t:1527268683964};\\\", \\\"{x:957,y:499,t:1527268683981};\\\", \\\"{x:957,y:503,t:1527268683997};\\\", \\\"{x:957,y:508,t:1527268684013};\\\", \\\"{x:957,y:512,t:1527268684031};\\\", \\\"{x:957,y:520,t:1527268684048};\\\", \\\"{x:954,y:525,t:1527268684064};\\\", \\\"{x:953,y:529,t:1527268684080};\\\", \\\"{x:952,y:531,t:1527268684098};\\\", \\\"{x:951,y:535,t:1527268684114};\\\", \\\"{x:951,y:537,t:1527268684131};\\\", \\\"{x:951,y:540,t:1527268684148};\\\", \\\"{x:950,y:541,t:1527268684164};\\\", \\\"{x:950,y:544,t:1527268684180};\\\", \\\"{x:950,y:545,t:1527268684197};\\\", \\\"{x:950,y:547,t:1527268684214};\\\", \\\"{x:950,y:550,t:1527268684230};\\\", \\\"{x:950,y:552,t:1527268684246};\\\", \\\"{x:951,y:553,t:1527268684264};\\\", \\\"{x:951,y:554,t:1527268684295};\\\", \\\"{x:952,y:555,t:1527268684319};\\\", \\\"{x:953,y:555,t:1527268684343};\\\", \\\"{x:954,y:555,t:1527268684351};\\\", \\\"{x:955,y:556,t:1527268684364};\\\", \\\"{x:957,y:556,t:1527268684380};\\\", \\\"{x:961,y:557,t:1527268684397};\\\", \\\"{x:967,y:558,t:1527268684413};\\\", \\\"{x:972,y:558,t:1527268684430};\\\", \\\"{x:978,y:558,t:1527268684447};\\\", \\\"{x:981,y:558,t:1527268684464};\\\", \\\"{x:985,y:558,t:1527268684480};\\\", \\\"{x:988,y:558,t:1527268684498};\\\", \\\"{x:996,y:558,t:1527268684514};\\\", \\\"{x:1005,y:560,t:1527268684531};\\\", \\\"{x:1019,y:562,t:1527268684547};\\\", \\\"{x:1036,y:567,t:1527268684565};\\\", \\\"{x:1055,y:571,t:1527268684580};\\\", \\\"{x:1074,y:572,t:1527268684598};\\\", \\\"{x:1092,y:575,t:1527268684615};\\\", \\\"{x:1118,y:579,t:1527268684630};\\\", \\\"{x:1169,y:581,t:1527268684648};\\\", \\\"{x:1211,y:581,t:1527268684665};\\\", \\\"{x:1256,y:582,t:1527268684680};\\\", \\\"{x:1301,y:582,t:1527268684698};\\\", \\\"{x:1355,y:584,t:1527268684715};\\\", \\\"{x:1400,y:585,t:1527268684731};\\\", \\\"{x:1435,y:588,t:1527268684748};\\\", \\\"{x:1465,y:588,t:1527268684765};\\\", \\\"{x:1490,y:588,t:1527268684781};\\\", \\\"{x:1510,y:588,t:1527268684797};\\\", \\\"{x:1528,y:588,t:1527268684815};\\\", \\\"{x:1548,y:586,t:1527268684832};\\\", \\\"{x:1558,y:583,t:1527268684848};\\\", \\\"{x:1566,y:583,t:1527268684866};\\\", \\\"{x:1570,y:583,t:1527268684881};\\\", \\\"{x:1573,y:582,t:1527268684897};\\\", \\\"{x:1574,y:582,t:1527268684915};\\\", \\\"{x:1568,y:579,t:1527268685056};\\\", \\\"{x:1557,y:579,t:1527268685064};\\\", \\\"{x:1536,y:574,t:1527268685082};\\\", \\\"{x:1512,y:571,t:1527268685097};\\\", \\\"{x:1488,y:569,t:1527268685115};\\\", \\\"{x:1454,y:569,t:1527268685132};\\\", \\\"{x:1379,y:569,t:1527268685148};\\\", \\\"{x:1269,y:578,t:1527268685165};\\\", \\\"{x:1139,y:582,t:1527268685182};\\\", \\\"{x:1007,y:591,t:1527268685198};\\\", \\\"{x:871,y:610,t:1527268685215};\\\", \\\"{x:696,y:634,t:1527268685233};\\\", \\\"{x:614,y:649,t:1527268685247};\\\", \\\"{x:573,y:653,t:1527268685264};\\\", \\\"{x:552,y:658,t:1527268685281};\\\", \\\"{x:543,y:662,t:1527268685298};\\\", \\\"{x:539,y:662,t:1527268685315};\\\", \\\"{x:538,y:663,t:1527268685331};\\\", \\\"{x:534,y:663,t:1527268685349};\\\", \\\"{x:522,y:659,t:1527268685364};\\\", \\\"{x:503,y:648,t:1527268685381};\\\", \\\"{x:478,y:633,t:1527268685399};\\\", \\\"{x:444,y:608,t:1527268685415};\\\", \\\"{x:376,y:571,t:1527268685431};\\\", \\\"{x:354,y:557,t:1527268685449};\\\", \\\"{x:350,y:554,t:1527268685464};\\\", \\\"{x:350,y:552,t:1527268685487};\\\", \\\"{x:350,y:550,t:1527268685498};\\\", \\\"{x:350,y:549,t:1527268685516};\\\", \\\"{x:350,y:548,t:1527268685532};\\\", \\\"{x:350,y:547,t:1527268685549};\\\", \\\"{x:351,y:547,t:1527268685565};\\\", \\\"{x:351,y:546,t:1527268685591};\\\", \\\"{x:351,y:544,t:1527268685600};\\\", \\\"{x:351,y:542,t:1527268685615};\\\", \\\"{x:352,y:540,t:1527268685633};\\\", \\\"{x:357,y:530,t:1527268685654};\\\", \\\"{x:363,y:520,t:1527268685665};\\\", \\\"{x:371,y:512,t:1527268685681};\\\", \\\"{x:379,y:506,t:1527268685698};\\\", \\\"{x:389,y:502,t:1527268685715};\\\", \\\"{x:399,y:498,t:1527268685731};\\\", \\\"{x:409,y:496,t:1527268685748};\\\", \\\"{x:416,y:496,t:1527268685765};\\\", \\\"{x:417,y:496,t:1527268685781};\\\", \\\"{x:419,y:497,t:1527268685798};\\\", \\\"{x:419,y:503,t:1527268685815};\\\", \\\"{x:416,y:512,t:1527268685831};\\\", \\\"{x:410,y:522,t:1527268685848};\\\", \\\"{x:406,y:530,t:1527268685866};\\\", \\\"{x:404,y:533,t:1527268685882};\\\", \\\"{x:404,y:534,t:1527268685898};\\\", \\\"{x:404,y:536,t:1527268685984};\\\", \\\"{x:404,y:537,t:1527268685999};\\\", \\\"{x:406,y:539,t:1527268686016};\\\", \\\"{x:418,y:539,t:1527268686032};\\\", \\\"{x:449,y:539,t:1527268686048};\\\", \\\"{x:510,y:539,t:1527268686066};\\\", \\\"{x:580,y:539,t:1527268686082};\\\", \\\"{x:628,y:539,t:1527268686098};\\\", \\\"{x:652,y:539,t:1527268686115};\\\", \\\"{x:660,y:539,t:1527268686132};\\\", \\\"{x:661,y:539,t:1527268686149};\\\", \\\"{x:661,y:536,t:1527268686176};\\\", \\\"{x:659,y:535,t:1527268686183};\\\", \\\"{x:656,y:535,t:1527268686198};\\\", \\\"{x:642,y:528,t:1527268686215};\\\", \\\"{x:628,y:525,t:1527268686233};\\\", \\\"{x:611,y:523,t:1527268686249};\\\", \\\"{x:593,y:521,t:1527268686265};\\\", \\\"{x:577,y:520,t:1527268686282};\\\", \\\"{x:561,y:520,t:1527268686298};\\\", \\\"{x:549,y:520,t:1527268686315};\\\", \\\"{x:535,y:520,t:1527268686332};\\\", \\\"{x:521,y:520,t:1527268686348};\\\", \\\"{x:506,y:520,t:1527268686366};\\\", \\\"{x:492,y:523,t:1527268686384};\\\", \\\"{x:459,y:527,t:1527268686399};\\\", \\\"{x:433,y:528,t:1527268686415};\\\", \\\"{x:411,y:529,t:1527268686433};\\\", \\\"{x:396,y:529,t:1527268686448};\\\", \\\"{x:393,y:529,t:1527268686466};\\\", \\\"{x:391,y:529,t:1527268686482};\\\", \\\"{x:390,y:529,t:1527268686543};\\\", \\\"{x:388,y:529,t:1527268686552};\\\", \\\"{x:387,y:529,t:1527268686567};\\\", \\\"{x:386,y:529,t:1527268686583};\\\", \\\"{x:384,y:530,t:1527268686599};\\\", \\\"{x:381,y:530,t:1527268686616};\\\", \\\"{x:376,y:532,t:1527268686633};\\\", \\\"{x:375,y:532,t:1527268686655};\\\", \\\"{x:374,y:533,t:1527268686752};\\\", \\\"{x:373,y:534,t:1527268686766};\\\", \\\"{x:369,y:535,t:1527268686783};\\\", \\\"{x:367,y:536,t:1527268686800};\\\", \\\"{x:362,y:538,t:1527268686815};\\\", \\\"{x:359,y:539,t:1527268686834};\\\", \\\"{x:353,y:541,t:1527268686849};\\\", \\\"{x:343,y:545,t:1527268686866};\\\", \\\"{x:328,y:548,t:1527268686883};\\\", \\\"{x:309,y:550,t:1527268686899};\\\", \\\"{x:290,y:550,t:1527268686917};\\\", \\\"{x:268,y:550,t:1527268686932};\\\", \\\"{x:257,y:550,t:1527268686949};\\\", \\\"{x:250,y:549,t:1527268686967};\\\", \\\"{x:245,y:548,t:1527268686983};\\\", \\\"{x:239,y:547,t:1527268686999};\\\", \\\"{x:235,y:547,t:1527268687017};\\\", \\\"{x:232,y:547,t:1527268687032};\\\", \\\"{x:226,y:547,t:1527268687049};\\\", \\\"{x:222,y:547,t:1527268687066};\\\", \\\"{x:220,y:547,t:1527268687083};\\\", \\\"{x:217,y:548,t:1527268687099};\\\", \\\"{x:215,y:549,t:1527268687116};\\\", \\\"{x:213,y:551,t:1527268687133};\\\", \\\"{x:213,y:555,t:1527268687149};\\\", \\\"{x:213,y:559,t:1527268687167};\\\", \\\"{x:213,y:562,t:1527268687183};\\\", \\\"{x:213,y:570,t:1527268687201};\\\", \\\"{x:213,y:577,t:1527268687217};\\\", \\\"{x:213,y:584,t:1527268687232};\\\", \\\"{x:211,y:591,t:1527268687249};\\\", \\\"{x:205,y:599,t:1527268687266};\\\", \\\"{x:199,y:605,t:1527268687282};\\\", \\\"{x:190,y:613,t:1527268687299};\\\", \\\"{x:181,y:617,t:1527268687317};\\\", \\\"{x:172,y:619,t:1527268687334};\\\", \\\"{x:166,y:619,t:1527268687349};\\\", \\\"{x:163,y:619,t:1527268687366};\\\", \\\"{x:160,y:619,t:1527268687383};\\\", \\\"{x:159,y:619,t:1527268687399};\\\", \\\"{x:158,y:619,t:1527268687431};\\\", \\\"{x:157,y:619,t:1527268687439};\\\", \\\"{x:156,y:619,t:1527268687450};\\\", \\\"{x:155,y:619,t:1527268687466};\\\", \\\"{x:154,y:617,t:1527268687484};\\\", \\\"{x:154,y:614,t:1527268687500};\\\", \\\"{x:154,y:612,t:1527268687516};\\\", \\\"{x:156,y:607,t:1527268687534};\\\", \\\"{x:158,y:606,t:1527268687549};\\\", \\\"{x:161,y:604,t:1527268687566};\\\", \\\"{x:163,y:603,t:1527268687583};\\\", \\\"{x:164,y:603,t:1527268687599};\\\", \\\"{x:166,y:601,t:1527268687616};\\\", \\\"{x:167,y:601,t:1527268687633};\\\", \\\"{x:167,y:600,t:1527268687651};\\\", \\\"{x:168,y:600,t:1527268687667};\\\", \\\"{x:170,y:598,t:1527268687684};\\\", \\\"{x:171,y:598,t:1527268687701};\\\", \\\"{x:172,y:597,t:1527268687728};\\\", \\\"{x:173,y:597,t:1527268687832};\\\", \\\"{x:174,y:595,t:1527268687847};\\\", \\\"{x:175,y:595,t:1527268687872};\\\", \\\"{x:176,y:595,t:1527268687895};\\\", \\\"{x:178,y:593,t:1527268688511};\\\", \\\"{x:180,y:592,t:1527268688519};\\\", \\\"{x:182,y:590,t:1527268688535};\\\", \\\"{x:183,y:590,t:1527268688551};\\\", \\\"{x:184,y:589,t:1527268688568};\\\", \\\"{x:185,y:588,t:1527268688591};\\\", \\\"{x:186,y:587,t:1527268688622};\\\", \\\"{x:187,y:587,t:1527268689832};\\\", \\\"{x:190,y:581,t:1527268689839};\\\", \\\"{x:194,y:574,t:1527268689856};\\\", \\\"{x:204,y:557,t:1527268689872};\\\", \\\"{x:206,y:545,t:1527268689889};\\\", \\\"{x:208,y:541,t:1527268689901};\\\", \\\"{x:209,y:536,t:1527268689918};\\\", \\\"{x:213,y:529,t:1527268689934};\\\", \\\"{x:219,y:521,t:1527268689951};\\\", \\\"{x:230,y:514,t:1527268689969};\\\", \\\"{x:243,y:505,t:1527268689985};\\\", \\\"{x:263,y:497,t:1527268690002};\\\", \\\"{x:291,y:488,t:1527268690019};\\\", \\\"{x:330,y:482,t:1527268690035};\\\", \\\"{x:392,y:481,t:1527268690051};\\\", \\\"{x:467,y:481,t:1527268690068};\\\", \\\"{x:542,y:481,t:1527268690086};\\\", \\\"{x:620,y:481,t:1527268690101};\\\", \\\"{x:660,y:482,t:1527268690118};\\\", \\\"{x:686,y:488,t:1527268690135};\\\", \\\"{x:687,y:489,t:1527268690152};\\\", \\\"{x:687,y:491,t:1527268690191};\\\", \\\"{x:687,y:495,t:1527268690201};\\\", \\\"{x:685,y:506,t:1527268690219};\\\", \\\"{x:679,y:517,t:1527268690235};\\\", \\\"{x:672,y:528,t:1527268690252};\\\", \\\"{x:665,y:537,t:1527268690270};\\\", \\\"{x:651,y:547,t:1527268690286};\\\", \\\"{x:634,y:554,t:1527268690302};\\\", \\\"{x:609,y:557,t:1527268690319};\\\", \\\"{x:560,y:557,t:1527268690335};\\\", \\\"{x:508,y:551,t:1527268690351};\\\", \\\"{x:457,y:537,t:1527268690368};\\\", \\\"{x:410,y:524,t:1527268690385};\\\", \\\"{x:379,y:514,t:1527268690403};\\\", \\\"{x:363,y:505,t:1527268690419};\\\", \\\"{x:361,y:504,t:1527268690435};\\\", \\\"{x:360,y:503,t:1527268690453};\\\", \\\"{x:360,y:502,t:1527268690468};\\\", \\\"{x:360,y:501,t:1527268690551};\\\", \\\"{x:361,y:502,t:1527268690558};\\\", \\\"{x:363,y:505,t:1527268690568};\\\", \\\"{x:365,y:513,t:1527268690585};\\\", \\\"{x:377,y:525,t:1527268690603};\\\", \\\"{x:407,y:539,t:1527268690619};\\\", \\\"{x:477,y:542,t:1527268690636};\\\", \\\"{x:575,y:542,t:1527268690652};\\\", \\\"{x:672,y:542,t:1527268690668};\\\", \\\"{x:758,y:542,t:1527268690686};\\\", \\\"{x:822,y:542,t:1527268690703};\\\", \\\"{x:861,y:538,t:1527268690719};\\\", \\\"{x:882,y:533,t:1527268690736};\\\", \\\"{x:884,y:532,t:1527268690752};\\\", \\\"{x:886,y:532,t:1527268690808};\\\", \\\"{x:888,y:530,t:1527268690824};\\\", \\\"{x:889,y:529,t:1527268690836};\\\", \\\"{x:891,y:529,t:1527268690852};\\\", \\\"{x:892,y:529,t:1527268690870};\\\", \\\"{x:892,y:528,t:1527268690983};\\\", \\\"{x:888,y:528,t:1527268690991};\\\", \\\"{x:883,y:526,t:1527268691002};\\\", \\\"{x:873,y:526,t:1527268691018};\\\", \\\"{x:867,y:526,t:1527268691036};\\\", \\\"{x:863,y:525,t:1527268691052};\\\", \\\"{x:861,y:525,t:1527268691069};\\\", \\\"{x:859,y:525,t:1527268691374};\\\", \\\"{x:857,y:525,t:1527268691386};\\\", \\\"{x:853,y:525,t:1527268691402};\\\", \\\"{x:846,y:525,t:1527268691420};\\\", \\\"{x:837,y:525,t:1527268691436};\\\", \\\"{x:829,y:525,t:1527268691452};\\\", \\\"{x:819,y:525,t:1527268691469};\\\", \\\"{x:816,y:524,t:1527268691487};\\\", \\\"{x:815,y:524,t:1527268691502};\\\", \\\"{x:811,y:524,t:1527268691672};\\\", \\\"{x:807,y:524,t:1527268691687};\\\", \\\"{x:786,y:539,t:1527268691705};\\\", \\\"{x:712,y:583,t:1527268691720};\\\", \\\"{x:628,y:630,t:1527268691737};\\\", \\\"{x:559,y:671,t:1527268691754};\\\", \\\"{x:501,y:708,t:1527268691770};\\\", \\\"{x:459,y:740,t:1527268691787};\\\", \\\"{x:438,y:755,t:1527268691803};\\\", \\\"{x:427,y:767,t:1527268691819};\\\", \\\"{x:424,y:771,t:1527268691836};\\\", \\\"{x:424,y:775,t:1527268691854};\\\", \\\"{x:425,y:776,t:1527268692032};\\\", \\\"{x:428,y:776,t:1527268692039};\\\", \\\"{x:433,y:773,t:1527268692054};\\\", \\\"{x:442,y:768,t:1527268692070};\\\", \\\"{x:450,y:764,t:1527268692088};\\\", \\\"{x:454,y:761,t:1527268692103};\\\", \\\"{x:455,y:761,t:1527268692174};\\\", \\\"{x:456,y:761,t:1527268692187};\\\", \\\"{x:458,y:761,t:1527268692203};\\\", \\\"{x:460,y:761,t:1527268692220};\\\", \\\"{x:460,y:761,t:1527268692292};\\\", \\\"{x:461,y:761,t:1527268692775};\\\", \\\"{x:461,y:760,t:1527268692791};\\\", \\\"{x:454,y:757,t:1527268692804};\\\", \\\"{x:430,y:752,t:1527268692820};\\\", \\\"{x:411,y:750,t:1527268692837};\\\", \\\"{x:389,y:746,t:1527268692854};\\\", \\\"{x:375,y:744,t:1527268692869};\\\", \\\"{x:364,y:740,t:1527268692887};\\\", \\\"{x:362,y:740,t:1527268692903};\\\", \\\"{x:361,y:739,t:1527268693184};\\\", \\\"{x:361,y:738,t:1527268693399};\\\" ] }, { \\\"rt\\\": 32990, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 750249, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"check the x axis and see what points lie on the 12pm \\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6142, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 757396, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19133, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 777544, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 2250, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 781111, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"AKYQ8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"AKYQ8\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 344, dom: 875, initialDom: 929",
  "javascriptErrors": []
}