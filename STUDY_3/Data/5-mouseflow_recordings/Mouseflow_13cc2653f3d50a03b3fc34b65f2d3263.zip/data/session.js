var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "13cc2653f3d50a03b3fc34b65f2d3263",
  "created": "2018-05-25T09:56:56.7785839-07:00",
  "lastActivity": "2018-05-25T09:57:07.5275839-07:00",
  "pageViews": [
    {
      "id": "05255648f59ef3dbe3de428d9615547c5b52b5d1",
      "startTime": "2018-05-25T09:56:56.7785839-07:00",
      "endTime": "2018-05-25T09:57:07.5275839-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 10749,
      "engagementTime": 10597,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10749,
  "engagementTime": 10597,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=3H1U8",
    "CONDITION=115-late",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "98bf3c70b2f595c2bf239da643fabb8f",
  "gdpr": false
}