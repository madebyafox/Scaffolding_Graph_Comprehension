var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "48b042a4d8db297c87cc9fd214c9b343",
  "created": "2018-05-22T14:08:00.6992571-07:00",
  "lastActivity": "2018-05-22T14:08:49.3042624-07:00",
  "pageViews": [
    {
      "id": "05220081e579cb22b17580345eb3d087d78ade78",
      "startTime": "2018-05-22T14:08:00.7602624-07:00",
      "endTime": "2018-05-22T14:08:49.3042624-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 48544,
      "engagementTime": 48330,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48544,
  "engagementTime": 48330,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G443Q",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "10a2c0bc62a01fe31b231a6390842138",
  "gdpr": false
}