var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060436725a27dfdb8521f7122b27b09fcac7a06e"] = {
  "startTime": "2018-06-04T19:18:36.2560574Z",
  "websitePageUrl": "/16",
  "visitTime": 143200,
  "engagementTime": 129097,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "07d14b58a586a05717cf227dd6c14da4",
    "created": "2018-06-04T19:18:36.0964318+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=6GNVQ",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f3ee2625d6cd46797c665bf5d0fbe293",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/07d14b58a586a05717cf227dd6c14da4/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 242,
      "e": 242,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 242,
      "e": 242,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 532,
      "y": 757
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 556,
      "y": 586
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 562,
      "y": 461
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 52260,
      "y": 25094,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 556,
      "y": 461
    },
    {
      "t": 853,
      "e": 853,
      "ty": 41,
      "x": 51585,
      "y": 25094,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 874,
      "e": 874,
      "ty": 6,
      "x": 529,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 525,
      "y": 532
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 521,
      "y": 544
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 47651,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1103,
      "e": 1103,
      "ty": 2,
      "x": 519,
      "y": 550
    },
    {
      "t": 1203,
      "e": 1203,
      "ty": 2,
      "x": 519,
      "y": 552
    },
    {
      "t": 1254,
      "e": 1254,
      "ty": 41,
      "x": 47426,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2754,
      "e": 2754,
      "ty": 41,
      "x": 47426,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2804,
      "e": 2804,
      "ty": 2,
      "x": 520,
      "y": 556
    },
    {
      "t": 2904,
      "e": 2904,
      "ty": 2,
      "x": 522,
      "y": 561
    },
    {
      "t": 3003,
      "e": 3003,
      "ty": 2,
      "x": 523,
      "y": 564
    },
    {
      "t": 3004,
      "e": 3004,
      "ty": 41,
      "x": 47876,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4277,
      "e": 4277,
      "ty": 3,
      "x": 523,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4279,
      "e": 4279,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4363,
      "e": 4363,
      "ty": 4,
      "x": 47876,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4363,
      "e": 4363,
      "ty": 5,
      "x": 523,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10003,
      "e": 9363,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13929,
      "e": 9363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14088,
      "e": 9522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14089,
      "e": 9523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14205,
      "e": 9639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 14207,
      "e": 9641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 14223,
      "e": 9657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 14263,
      "e": 9697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14263,
      "e": 9697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14352,
      "e": 9786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Gi"
    },
    {
      "t": 14352,
      "e": 9786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14352,
      "e": 9786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14424,
      "e": 9858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Gir"
    },
    {
      "t": 14447,
      "e": 9881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14449,
      "e": 9883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14527,
      "e": 9961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14527,
      "e": 9961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14559,
      "e": 9993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Girst"
    },
    {
      "t": 14639,
      "e": 10073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14696,
      "e": 10130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 14696,
      "e": 10130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14775,
      "e": 10209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 14839,
      "e": 10273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14840,
      "e": 10274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14919,
      "e": 10353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15039,
      "e": 10473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15205,
      "e": 10639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Girst,"
    },
    {
      "t": 15539,
      "e": 10973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15572,
      "e": 11006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15605,
      "e": 11039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15637,
      "e": 11071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15671,
      "e": 11105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15704,
      "e": 11138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15736,
      "e": 11170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15769,
      "e": 11203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15803,
      "e": 11237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15832,
      "e": 11266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15839,
      "e": 11273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 15936,
      "e": 11370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15937,
      "e": 11371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15991,
      "e": 11425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16015,
      "e": 11449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16024,
      "e": 11458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16024,
      "e": 11458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16104,
      "e": 11538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 16112,
      "e": 11546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16112,
      "e": 11546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16184,
      "e": 11618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 16216,
      "e": 11650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16217,
      "e": 11651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16295,
      "e": 11729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16295,
      "e": 11729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16335,
      "e": 11769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First"
    },
    {
      "t": 16367,
      "e": 11801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16368,
      "e": 11802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16399,
      "e": 11833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16464,
      "e": 11898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16464,
      "e": 11898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 16464,
      "e": 11898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16527,
      "e": 11961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 16583,
      "e": 12017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16583,
      "e": 12017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16656,
      "e": 12090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 16656,
      "e": 12090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16663,
      "e": 12097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16664,
      "e": 12098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16671,
      "e": 12105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou "
    },
    {
      "t": 16727,
      "e": 12161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16760,
      "e": 12194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16760,
      "e": 12194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16775,
      "e": 12209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 16823,
      "e": 12257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16824,
      "e": 12258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16879,
      "e": 12313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16887,
      "e": 12321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16952,
      "e": 12386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16953,
      "e": 12387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17039,
      "e": 12473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17048,
      "e": 12482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17048,
      "e": 12482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17135,
      "e": 12569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 17168,
      "e": 12602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17169,
      "e": 12603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17223,
      "e": 12657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17224,
      "e": 12658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17231,
      "e": 12665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 17343,
      "e": 12777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17346,
      "e": 12780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17360,
      "e": 12794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17415,
      "e": 12849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18000,
      "e": 13434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18063,
      "e": 13497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find a"
    },
    {
      "t": 18143,
      "e": 13577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18207,
      "e": 13641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find "
    },
    {
      "t": 18280,
      "e": 13714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18360,
      "e": 13794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find"
    },
    {
      "t": 18583,
      "e": 14017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18583,
      "e": 14017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18712,
      "e": 14146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18776,
      "e": 14210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18776,
      "e": 14210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18855,
      "e": 14289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18855,
      "e": 14289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18919,
      "e": 14353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 18975,
      "e": 14409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19935,
      "e": 15369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20003,
      "e": 15437,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20095,
      "e": 15529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20095,
      "e": 15529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20159,
      "e": 15593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 20352,
      "e": 15786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20448,
      "e": 15882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20479,
      "e": 15913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12"
    },
    {
      "t": 20567,
      "e": 16001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20567,
      "e": 16001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20648,
      "e": 16082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20727,
      "e": 16161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20728,
      "e": 16162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20824,
      "e": 16258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 20856,
      "e": 16290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20856,
      "e": 16290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20959,
      "e": 16393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21007,
      "e": 16441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21007,
      "e": 16441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21095,
      "e": 16529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21095,
      "e": 16529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21127,
      "e": 16561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 21151,
      "e": 16585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21232,
      "e": 16666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21232,
      "e": 16666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21287,
      "e": 16721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21351,
      "e": 16785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21351,
      "e": 16785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21439,
      "e": 16873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21439,
      "e": 16873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 21441,
      "e": 16875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21520,
      "e": 16954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 21568,
      "e": 17002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21568,
      "e": 17002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21639,
      "e": 17073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21655,
      "e": 17089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21655,
      "e": 17089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21727,
      "e": 17161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21727,
      "e": 17161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21728,
      "e": 17162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21784,
      "e": 17218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21791,
      "e": 17225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21792,
      "e": 17226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21880,
      "e": 17314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21880,
      "e": 17314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21903,
      "e": 17337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 21967,
      "e": 17401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22487,
      "e": 17921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 22744,
      "e": 18178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 22745,
      "e": 18179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22815,
      "e": 18249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 22856,
      "e": 18290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22928,
      "e": 18362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22928,
      "e": 18362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23007,
      "e": 18441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23007,
      "e": 18441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23047,
      "e": 18481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 23119,
      "e": 18553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23312,
      "e": 18746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 23313,
      "e": 18747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23431,
      "e": 18865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 23504,
      "e": 18938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23504,
      "e": 18938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23584,
      "e": 19018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23728,
      "e": 19162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23728,
      "e": 19162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23816,
      "e": 19250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24009,
      "e": 19443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24063,
      "e": 19497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axe"
    },
    {
      "t": 24152,
      "e": 19586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24216,
      "e": 19650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X ax"
    },
    {
      "t": 24304,
      "e": 19738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24304,
      "e": 19738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24405,
      "e": 19839,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axi"
    },
    {
      "t": 24407,
      "e": 19841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24552,
      "e": 19986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24553,
      "e": 19987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24655,
      "e": 20089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 24696,
      "e": 20130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 24697,
      "e": 20131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24791,
      "e": 20225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 24839,
      "e": 20273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24839,
      "e": 20273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24919,
      "e": 20353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 24919,
      "e": 20353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24943,
      "e": 20377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| w"
    },
    {
      "t": 25023,
      "e": 20457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25031,
      "e": 20465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25032,
      "e": 20466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25111,
      "e": 20545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25127,
      "e": 20561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 25128,
      "e": 20562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25160,
      "e": 20594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25160,
      "e": 20594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25224,
      "e": 20658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ci"
    },
    {
      "t": 25272,
      "e": 20706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25280,
      "e": 20714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25282,
      "e": 20716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25351,
      "e": 20785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25455,
      "e": 20889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25456,
      "e": 20890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25519,
      "e": 20953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25519,
      "e": 20953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25551,
      "e": 20985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 25583,
      "e": 21017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25584,
      "e": 21018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25607,
      "e": 21041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25688,
      "e": 21122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25824,
      "e": 21258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25887,
      "e": 21321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, whcih r"
    },
    {
      "t": 25983,
      "e": 21417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26048,
      "e": 21418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, whcih "
    },
    {
      "t": 26128,
      "e": 21498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26192,
      "e": 21562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, whcih"
    },
    {
      "t": 26280,
      "e": 21650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26343,
      "e": 21713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, whci"
    },
    {
      "t": 26439,
      "e": 21809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26495,
      "e": 21865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, whc"
    },
    {
      "t": 26576,
      "e": 21946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26641,
      "e": 22011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X axis, wh"
    },
    {
      "t": 27352,
      "e": 22722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27352,
      "e": 22722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27439,
      "e": 22809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27728,
      "e": 23098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28227,
      "e": 23597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28259,
      "e": 23629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28292,
      "e": 23662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28325,
      "e": 23695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28359,
      "e": 23729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28391,
      "e": 23761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28425,
      "e": 23795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28458,
      "e": 23828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28463,
      "e": 23833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X "
    },
    {
      "t": 28600,
      "e": 23970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28679,
      "e": 24049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the X"
    },
    {
      "t": 28768,
      "e": 24138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28831,
      "e": 24201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the "
    },
    {
      "t": 29328,
      "e": 24698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29329,
      "e": 24699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29423,
      "e": 24793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29672,
      "e": 25042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 29673,
      "e": 25043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29767,
      "e": 25137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 29799,
      "e": 25169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29799,
      "e": 25169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29880,
      "e": 25250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29887,
      "e": 25257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29888,
      "e": 25258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30005,
      "e": 25375,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis"
    },
    {
      "t": 30023,
      "e": 25393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30031,
      "e": 25401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30032,
      "e": 25402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30135,
      "e": 25505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31047,
      "e": 26417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31049,
      "e": 26419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31088,
      "e": 26458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31088,
      "e": 26458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31119,
      "e": 26489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 31175,
      "e": 26545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31191,
      "e": 26561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31191,
      "e": 26561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31280,
      "e": 26650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31280,
      "e": 26650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31295,
      "e": 26665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pr"
    },
    {
      "t": 31352,
      "e": 26722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31354,
      "e": 26724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31383,
      "e": 26753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31447,
      "e": 26817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31487,
      "e": 26857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31488,
      "e": 26858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31575,
      "e": 26945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31577,
      "e": 26947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31623,
      "e": 26993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 31679,
      "e": 27049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31687,
      "e": 27057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31688,
      "e": 27058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31767,
      "e": 27137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31783,
      "e": 27153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31784,
      "e": 27154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31879,
      "e": 27249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31888,
      "e": 27258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31889,
      "e": 27259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31895,
      "e": 27265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31896,
      "e": 27266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31927,
      "e": 27297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 31975,
      "e": 27345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32064,
      "e": 27434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32064,
      "e": 27434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32136,
      "e": 27506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33071,
      "e": 28441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33072,
      "e": 28442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33136,
      "e": 28506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33136,
      "e": 28506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33175,
      "e": 28545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 33199,
      "e": 28569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33263,
      "e": 28633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33264,
      "e": 28634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33287,
      "e": 28657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33288,
      "e": 28658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33328,
      "e": 28659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 33351,
      "e": 28682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33351,
      "e": 28682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33407,
      "e": 28738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33431,
      "e": 28762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33431,
      "e": 28762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33455,
      "e": 28786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33487,
      "e": 28818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33560,
      "e": 28891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33561,
      "e": 28892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33575,
      "e": 28906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33575,
      "e": 28906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33623,
      "e": 28954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 33695,
      "e": 29026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33719,
      "e": 29050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33719,
      "e": 29050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33815,
      "e": 29146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33848,
      "e": 29179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33849,
      "e": 29180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33911,
      "e": 29242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33911,
      "e": 29242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33935,
      "e": 29266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 33936,
      "e": 29267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33958,
      "e": 29289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||day"
    },
    {
      "t": 34031,
      "e": 29362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34047,
      "e": 29378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34897,
      "e": 30228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35005,
      "e": 30336,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represening times of da"
    },
    {
      "t": 35395,
      "e": 30726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35427,
      "e": 30758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35460,
      "e": 30791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35494,
      "e": 30825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35526,
      "e": 30857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35560,
      "e": 30891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35593,
      "e": 30924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35626,
      "e": 30957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35658,
      "e": 30989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35687,
      "e": 31018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represening ti"
    },
    {
      "t": 35799,
      "e": 31130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35880,
      "e": 31211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represening t"
    },
    {
      "t": 35959,
      "e": 31290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36023,
      "e": 31354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represening "
    },
    {
      "t": 36103,
      "e": 31434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36176,
      "e": 31507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represening"
    },
    {
      "t": 36256,
      "e": 31587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36319,
      "e": 31650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represenin"
    },
    {
      "t": 36391,
      "e": 31722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36463,
      "e": 31794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represeni"
    },
    {
      "t": 36543,
      "e": 31874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36615,
      "e": 31946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis represen"
    },
    {
      "t": 36736,
      "e": 32067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36736,
      "e": 32067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36791,
      "e": 32122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36791,
      "e": 32122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36847,
      "e": 32178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 36848,
      "e": 32179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36911,
      "e": 32242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36912,
      "e": 32243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36975,
      "e": 32306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36983,
      "e": 32314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36983,
      "e": 32314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37047,
      "e": 32378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 37071,
      "e": 32402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37072,
      "e": 32403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37135,
      "e": 32466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37183,
      "e": 32514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37185,
      "e": 32516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37223,
      "e": 32554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37223,
      "e": 32554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37271,
      "e": 32602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 37287,
      "e": 32618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37303,
      "e": 32634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37304,
      "e": 32635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37351,
      "e": 32682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 37391,
      "e": 32722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37392,
      "e": 32723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37455,
      "e": 32786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37456,
      "e": 32787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37463,
      "e": 32794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37464,
      "e": 32795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37520,
      "e": 32851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es "
    },
    {
      "t": 37527,
      "e": 32858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37544,
      "e": 32859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37608,
      "e": 32923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37608,
      "e": 32923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37679,
      "e": 32994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37703,
      "e": 33018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37703,
      "e": 33018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37775,
      "e": 33090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37775,
      "e": 33090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37799,
      "e": 33114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 37863,
      "e": 33178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37920,
      "e": 33235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37920,
      "e": 33235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37975,
      "e": 33290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37975,
      "e": 33290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37998,
      "e": 33313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 37999,
      "e": 33314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38031,
      "e": 33346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||day"
    },
    {
      "t": 38095,
      "e": 33410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38127,
      "e": 33442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38240,
      "e": 33555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 38240,
      "e": 33555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38311,
      "e": 33626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 38439,
      "e": 33754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38440,
      "e": 33755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38567,
      "e": 33882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38663,
      "e": 33978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38665,
      "e": 33980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38727,
      "e": 34042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38727,
      "e": 34042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38743,
      "e": 34058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 38815,
      "e": 34130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38815,
      "e": 34130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38815,
      "e": 34130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38911,
      "e": 34226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38936,
      "e": 34251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38936,
      "e": 34251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39040,
      "e": 34355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39055,
      "e": 34370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39056,
      "e": 34371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39152,
      "e": 34467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 39199,
      "e": 34514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39200,
      "e": 34515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39311,
      "e": 34626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39311,
      "e": 34626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39311,
      "e": 34626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39415,
      "e": 34730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39991,
      "e": 35306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39991,
      "e": 35306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40080,
      "e": 35395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 40096,
      "e": 35411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40096,
      "e": 35411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40183,
      "e": 35498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40223,
      "e": 35538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40223,
      "e": 35538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40312,
      "e": 35627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40480,
      "e": 35795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 40481,
      "e": 35796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40575,
      "e": 35890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 43816,
      "e": 39131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43817,
      "e": 39132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43920,
      "e": 39235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43927,
      "e": 39242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43999,
      "e": 39314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43999,
      "e": 39314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44063,
      "e": 39378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 44087,
      "e": 39402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44159,
      "e": 39474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44160,
      "e": 39475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44239,
      "e": 39554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44240,
      "e": 39555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44263,
      "e": 39578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 44319,
      "e": 39634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44327,
      "e": 39642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44327,
      "e": 39642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44399,
      "e": 39714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44399,
      "e": 39714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44440,
      "e": 39755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 44504,
      "e": 39819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44519,
      "e": 39834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44520,
      "e": 39835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44558,
      "e": 39873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44559,
      "e": 39874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44607,
      "e": 39922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 44638,
      "e": 39953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44639,
      "e": 39954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44671,
      "e": 39986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44703,
      "e": 40018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44704,
      "e": 40019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44743,
      "e": 40058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44792,
      "e": 40107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44793,
      "e": 40108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44815,
      "e": 40130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44839,
      "e": 40154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44870,
      "e": 40185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44871,
      "e": 40186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44951,
      "e": 40266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 44951,
      "e": 40266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44991,
      "e": 40306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tw"
    },
    {
      "t": 45031,
      "e": 40346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45031,
      "e": 40346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45079,
      "e": 40394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45103,
      "e": 40418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45144,
      "e": 40459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45144,
      "e": 40459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45295,
      "e": 40610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45392,
      "e": 40707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45392,
      "e": 40707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45471,
      "e": 40786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45559,
      "e": 40874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45559,
      "e": 40874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45615,
      "e": 40930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45696,
      "e": 41011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45696,
      "e": 41011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45791,
      "e": 41106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45791,
      "e": 41106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45799,
      "e": 41114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 45855,
      "e": 41170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45855,
      "e": 41170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45911,
      "e": 41226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 45951,
      "e": 41266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45984,
      "e": 41299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45984,
      "e": 41299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46031,
      "e": 41346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49192,
      "e": 44507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49192,
      "e": 44507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49255,
      "e": 44570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49257,
      "e": 44572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49263,
      "e": 44578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 49336,
      "e": 44651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49336,
      "e": 44651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49351,
      "e": 44666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49375,
      "e": 44690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49375,
      "e": 44690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49415,
      "e": 44690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49479,
      "e": 44754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50448,
      "e": 45723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50448,
      "e": 45723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50543,
      "e": 45818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50543,
      "e": 45818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50550,
      "e": 45825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 50591,
      "e": 45866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50680,
      "e": 45955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50680,
      "e": 45955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50711,
      "e": 45986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50712,
      "e": 45987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50767,
      "e": 46042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 50783,
      "e": 46058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50808,
      "e": 46083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50809,
      "e": 46084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50871,
      "e": 46146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50871,
      "e": 46146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50927,
      "e": 46202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 50982,
      "e": 46257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51184,
      "e": 46459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51184,
      "e": 46459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51271,
      "e": 46546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51271,
      "e": 46546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51327,
      "e": 46602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 51399,
      "e": 46674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51480,
      "e": 46755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 51480,
      "e": 46755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51574,
      "e": 46849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 51687,
      "e": 46962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51688,
      "e": 46963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51760,
      "e": 47035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51815,
      "e": 47090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51816,
      "e": 47091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51871,
      "e": 47146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51879,
      "e": 47154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51879,
      "e": 47154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51934,
      "e": 47209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51935,
      "e": 47210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51943,
      "e": 47218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 51966,
      "e": 47241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51967,
      "e": 47242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51983,
      "e": 47258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52039,
      "e": 47314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52040,
      "e": 47315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52071,
      "e": 47346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52111,
      "e": 47386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52279,
      "e": 47554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52343,
      "e": 47618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect tha"
    },
    {
      "t": 52431,
      "e": 47706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52487,
      "e": 47762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect th"
    },
    {
      "t": 52560,
      "e": 47835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52630,
      "e": 47905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect t"
    },
    {
      "t": 52703,
      "e": 47978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52791,
      "e": 48066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect "
    },
    {
      "t": 52814,
      "e": 48089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52815,
      "e": 48090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52855,
      "e": 48130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52855,
      "e": 48130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52887,
      "e": 48162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 52919,
      "e": 48194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52983,
      "e": 48258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52984,
      "e": 48259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53015,
      "e": 48290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53015,
      "e": 48290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53047,
      "e": 48322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 53094,
      "e": 48369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53095,
      "e": 48370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53103,
      "e": 48378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 53167,
      "e": 48442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53175,
      "e": 48450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53175,
      "e": 48450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53215,
      "e": 48490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53216,
      "e": 48491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53255,
      "e": 48530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 53279,
      "e": 48530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53280,
      "e": 48531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53319,
      "e": 48570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53351,
      "e": 48602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53495,
      "e": 48746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53495,
      "e": 48746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53559,
      "e": 48810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53559,
      "e": 48810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53591,
      "e": 48842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 53622,
      "e": 48873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53703,
      "e": 48954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53703,
      "e": 48954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53766,
      "e": 49017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 53876,
      "e": 49127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53877,
      "e": 49128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53959,
      "e": 49210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53975,
      "e": 49226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53975,
      "e": 49226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54039,
      "e": 49290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54079,
      "e": 49330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 54079,
      "e": 49330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54169,
      "e": 49420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 54247,
      "e": 49498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54247,
      "e": 49498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54327,
      "e": 49578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54327,
      "e": 49578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54359,
      "e": 49610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 54407,
      "e": 49658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54407,
      "e": 49658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54415,
      "e": 49666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 54471,
      "e": 49722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54471,
      "e": 49722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54520,
      "e": 49771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54607,
      "e": 49858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54608,
      "e": 49859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54623,
      "e": 49874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54703,
      "e": 49954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54805,
      "e": 50056,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. the "
    },
    {
      "t": 57592,
      "e": 52843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57654,
      "e": 52905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. the"
    },
    {
      "t": 57743,
      "e": 52994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57791,
      "e": 53042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. th"
    },
    {
      "t": 57871,
      "e": 53122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57935,
      "e": 53186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. t"
    },
    {
      "t": 58007,
      "e": 53258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58071,
      "e": 53322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58095,
      "e": 53346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. "
    },
    {
      "t": 58150,
      "e": 53401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58151,
      "e": 53402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58224,
      "e": 53403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 58247,
      "e": 53426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58263,
      "e": 53442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58264,
      "e": 53443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58351,
      "e": 53530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58367,
      "e": 53546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58367,
      "e": 53546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58447,
      "e": 53626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58487,
      "e": 53666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58487,
      "e": 53666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58543,
      "e": 53722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 58543,
      "e": 53722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58566,
      "e": 53745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 58615,
      "e": 53794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58639,
      "e": 53818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58639,
      "e": 53818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58711,
      "e": 53890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 58711,
      "e": 53890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58718,
      "e": 53897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 58783,
      "e": 53962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58807,
      "e": 53986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58808,
      "e": 53987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58878,
      "e": 54057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58879,
      "e": 54058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58927,
      "e": 54106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 58967,
      "e": 54146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59359,
      "e": 54538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59360,
      "e": 54539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59439,
      "e": 54618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59558,
      "e": 54737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59559,
      "e": 54738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59615,
      "e": 54794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 59704,
      "e": 54883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59704,
      "e": 54883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59782,
      "e": 54961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 59791,
      "e": 54970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59791,
      "e": 54970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59887,
      "e": 55066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 59919,
      "e": 55098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59920,
      "e": 55099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60023,
      "e": 55202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66075,
      "e": 60202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66075,
      "e": 60202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66137,
      "e": 60264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66137,
      "e": 60264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66177,
      "e": 60304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 66258,
      "e": 60385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66338,
      "e": 60465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 66338,
      "e": 60465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66450,
      "e": 60577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66450,
      "e": 60577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66457,
      "e": 60584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pr"
    },
    {
      "t": 66489,
      "e": 60616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66489,
      "e": 60616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66521,
      "e": 60648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66554,
      "e": 60681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66578,
      "e": 60705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 66579,
      "e": 60706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66682,
      "e": 60809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66683,
      "e": 60810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66737,
      "e": 60864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 66801,
      "e": 60928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66826,
      "e": 60953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66826,
      "e": 60953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66922,
      "e": 61049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 66930,
      "e": 61057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66931,
      "e": 61058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67002,
      "e": 61129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67002,
      "e": 61129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67042,
      "e": 61169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 67114,
      "e": 61241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67130,
      "e": 61257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67132,
      "e": 61259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67177,
      "e": 61304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67434,
      "e": 61561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67609,
      "e": 61736,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents"
    },
    {
      "t": 67613,
      "e": 61740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents"
    },
    {
      "t": 67826,
      "e": 61953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67827,
      "e": 61954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67930,
      "e": 62057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67930,
      "e": 62057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68010,
      "e": 62137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 68042,
      "e": 62169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68042,
      "e": 62169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68049,
      "e": 62176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68122,
      "e": 62249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68137,
      "e": 62264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68138,
      "e": 62265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68217,
      "e": 62344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 68218,
      "e": 62345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68249,
      "e": 62376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 68282,
      "e": 62409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68362,
      "e": 62489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68362,
      "e": 62489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68442,
      "e": 62489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68490,
      "e": 62537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68490,
      "e": 62537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68537,
      "e": 62584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68538,
      "e": 62585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68554,
      "e": 62601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 68618,
      "e": 62665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68618,
      "e": 62665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68633,
      "e": 62680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 68681,
      "e": 62728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68705,
      "e": 62752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 68706,
      "e": 62753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68737,
      "e": 62784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68737,
      "e": 62784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68762,
      "e": 62809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 68858,
      "e": 62905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68874,
      "e": 62921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68875,
      "e": 62922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68921,
      "e": 62968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68921,
      "e": 62968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68930,
      "e": 62977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 69018,
      "e": 63065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69187,
      "e": 63234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 69249,
      "e": 63296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time "
    },
    {
      "t": 69289,
      "e": 63336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 69290,
      "e": 63337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69369,
      "e": 63416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69370,
      "e": 63417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69394,
      "e": 63441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 69442,
      "e": 63489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69491,
      "e": 63538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69491,
      "e": 63538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69529,
      "e": 63576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69666,
      "e": 63713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 69666,
      "e": 63713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69745,
      "e": 63792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 69777,
      "e": 63824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69778,
      "e": 63825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69866,
      "e": 63913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69874,
      "e": 63921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69874,
      "e": 63921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69929,
      "e": 63976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69929,
      "e": 63976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69954,
      "e": 64001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 69977,
      "e": 64024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69978,
      "e": 64025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70026,
      "e": 64073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70026,
      "e": 64073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70033,
      "e": 64080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 70041,
      "e": 64088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70121,
      "e": 64168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70123,
      "e": 64170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70137,
      "e": 64184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70217,
      "e": 64264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70922,
      "e": 64969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 70923,
      "e": 64970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70985,
      "e": 65032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70985,
      "e": 65032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71018,
      "e": 65065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 71090,
      "e": 65137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 71090,
      "e": 65137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71122,
      "e": 65169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 71178,
      "e": 65225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71258,
      "e": 65305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71258,
      "e": 65305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71322,
      "e": 65369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71450,
      "e": 65497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71450,
      "e": 65497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71537,
      "e": 65584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80006,
      "e": 70584,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 83515,
      "e": 70584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 83516,
      "e": 70585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83593,
      "e": 70662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 83593,
      "e": 70662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83617,
      "e": 70686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 83657,
      "e": 70726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83730,
      "e": 70799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 83730,
      "e": 70799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83778,
      "e": 70847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 83778,
      "e": 70847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83826,
      "e": 70895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 83857,
      "e": 70926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83954,
      "e": 71023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 83955,
      "e": 71024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84075,
      "e": 71144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84075,
      "e": 71144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84082,
      "e": 71151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 84170,
      "e": 71239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85250,
      "e": 72319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 85251,
      "e": 72320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85345,
      "e": 72414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 85353,
      "e": 72422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 85354,
      "e": 72423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85417,
      "e": 72486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 85434,
      "e": 72503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 85434,
      "e": 72503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85530,
      "e": 72599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 85538,
      "e": 72607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85539,
      "e": 72608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85609,
      "e": 72678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85609,
      "e": 72678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85633,
      "e": 72702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 85681,
      "e": 72750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 85681,
      "e": 72750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85689,
      "e": 72758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85745,
      "e": 72814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85778,
      "e": 72847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 85778,
      "e": 72847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85818,
      "e": 72887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 85818,
      "e": 72887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85857,
      "e": 72926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 85938,
      "e": 73007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85986,
      "e": 73055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 85987,
      "e": 73056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86066,
      "e": 73135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 86218,
      "e": 73287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86219,
      "e": 73288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86282,
      "e": 73351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 86330,
      "e": 73399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 86378,
      "e": 73447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 86379,
      "e": 73448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86458,
      "e": 73527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 86498,
      "e": 73567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86530,
      "e": 73599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 86530,
      "e": 73599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86618,
      "e": 73687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86619,
      "e": 73688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86634,
      "e": 73703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 86745,
      "e": 73814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87554,
      "e": 74623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87554,
      "e": 74623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87642,
      "e": 74711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 87650,
      "e": 74719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 87651,
      "e": 74720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87689,
      "e": 74758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 87809,
      "e": 74878,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to"
    },
    {
      "t": 87809,
      "e": 74878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87810,
      "e": 74879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87866,
      "e": 74935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 87866,
      "e": 74935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87874,
      "e": 74943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 87962,
      "e": 75031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87963,
      "e": 75032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87993,
      "e": 75062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 88017,
      "e": 75086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88042,
      "e": 75111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 88042,
      "e": 75111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88137,
      "e": 75206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 88154,
      "e": 75223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 88154,
      "e": 75223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88250,
      "e": 75319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 88274,
      "e": 75343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88275,
      "e": 75344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88362,
      "e": 75431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89458,
      "e": 76527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 89459,
      "e": 76528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89578,
      "e": 76647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 89594,
      "e": 76663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89595,
      "e": 76664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89690,
      "e": 76759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 89691,
      "e": 76760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89698,
      "e": 76767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 89753,
      "e": 76822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89754,
      "e": 76823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89801,
      "e": 76870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89833,
      "e": 76902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89873,
      "e": 76942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89874,
      "e": 76943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89946,
      "e": 77015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 89946,
      "e": 77015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89977,
      "e": 77046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 90006,
      "e": 77075,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90025,
      "e": 77094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90025,
      "e": 77094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90041,
      "e": 77110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90105,
      "e": 77174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90113,
      "e": 77182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 90113,
      "e": 77182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90202,
      "e": 77271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 90202,
      "e": 77271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90241,
      "e": 77310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 90258,
      "e": 77327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90314,
      "e": 77383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90314,
      "e": 77383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90402,
      "e": 77471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90403,
      "e": 77472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90409,
      "e": 77478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 90514,
      "e": 77583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90522,
      "e": 77591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90522,
      "e": 77591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90602,
      "e": 77671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90609,
      "e": 77678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 90609,
      "e": 77678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90642,
      "e": 77711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90642,
      "e": 77711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90689,
      "e": 77758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 90729,
      "e": 77798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90729,
      "e": 77798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90737,
      "e": 77806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90818,
      "e": 77887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90898,
      "e": 77967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 90898,
      "e": 77967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90970,
      "e": 78039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 90970,
      "e": 78039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90977,
      "e": 78046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "51"
    },
    {
      "t": 90977,
      "e": 78046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91017,
      "e": 78086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||123"
    },
    {
      "t": 91049,
      "e": 78118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91073,
      "e": 78142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91089,
      "e": 78158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 91089,
      "e": 78158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91169,
      "e": 78238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 91466,
      "e": 78535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91521,
      "e": 78590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 123"
    },
    {
      "t": 91601,
      "e": 78670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91673,
      "e": 78742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12"
    },
    {
      "t": 91898,
      "e": 78967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 91899,
      "e": 78968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92002,
      "e": 79071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 92057,
      "e": 79126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92057,
      "e": 79126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92145,
      "e": 79214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 92146,
      "e": 79215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92186,
      "e": 79255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| w"
    },
    {
      "t": 92218,
      "e": 79287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 92219,
      "e": 79288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92274,
      "e": 79343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 92362,
      "e": 79431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92394,
      "e": 79463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92394,
      "e": 79463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92465,
      "e": 79534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92953,
      "e": 80022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93010,
      "e": 80023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12, we"
    },
    {
      "t": 93097,
      "e": 80110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93145,
      "e": 80158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12, w"
    },
    {
      "t": 93226,
      "e": 80239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93297,
      "e": 80310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12, "
    },
    {
      "t": 93370,
      "e": 80383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93441,
      "e": 80454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12,"
    },
    {
      "t": 93546,
      "e": 80559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93602,
      "e": 80560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12"
    },
    {
      "t": 93699,
      "e": 80657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 93699,
      "e": 80657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93777,
      "e": 80735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 93874,
      "e": 80832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 93874,
      "e": 80832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93961,
      "e": 80919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 94049,
      "e": 81007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 94050,
      "e": 81008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94121,
      "e": 81079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 94145,
      "e": 81103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94147,
      "e": 81105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94273,
      "e": 81231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 94273,
      "e": 81231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94289,
      "e": 81247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 94354,
      "e": 81312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 94354,
      "e": 81312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94402,
      "e": 81360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 94425,
      "e": 81383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94514,
      "e": 81472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 94514,
      "e": 81472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94561,
      "e": 81519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 94642,
      "e": 81600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 94643,
      "e": 81601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94690,
      "e": 81648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 94777,
      "e": 81735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 94778,
      "e": 81736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94834,
      "e": 81792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 94834,
      "e": 81792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94865,
      "e": 81823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 94913,
      "e": 81871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94913,
      "e": 81871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94953,
      "e": 81911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95041,
      "e": 81999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95042,
      "e": 82000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95065,
      "e": 82023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95089,
      "e": 82047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 95089,
      "e": 82047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95121,
      "e": 82079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 95185,
      "e": 82143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95202,
      "e": 82160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95202,
      "e": 82160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95322,
      "e": 82280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 95338,
      "e": 82296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95339,
      "e": 82297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95402,
      "e": 82360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95729,
      "e": 82687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 95729,
      "e": 82687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95785,
      "e": 82743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 95793,
      "e": 82751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 95794,
      "e": 82752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95873,
      "e": 82831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 95881,
      "e": 82839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 95882,
      "e": 82840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95929,
      "e": 82887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 95954,
      "e": 82912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 95954,
      "e": 82912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96009,
      "e": 82967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96010,
      "e": 82968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96018,
      "e": 82976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 96082,
      "e": 83040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 96209,
      "e": 83167,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the right"
    },
    {
      "t": 96250,
      "e": 83208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 96250,
      "e": 83208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96314,
      "e": 83272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 96402,
      "e": 83360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 96402,
      "e": 83360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96458,
      "e": 83416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 96506,
      "e": 83464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 96507,
      "e": 83465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96577,
      "e": 83535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 96578,
      "e": 83536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96585,
      "e": 83536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 96697,
      "e": 83648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 96866,
      "e": 83817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 96929,
      "e": 83880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the rightlin"
    },
    {
      "t": 97017,
      "e": 83968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 97074,
      "e": 84025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the rightli"
    },
    {
      "t": 97145,
      "e": 84096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 97225,
      "e": 84176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the rightl"
    },
    {
      "t": 97290,
      "e": 84241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 97369,
      "e": 84241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the right"
    },
    {
      "t": 97426,
      "e": 84298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97426,
      "e": 84298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97506,
      "e": 84378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 97506,
      "e": 84378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97529,
      "e": 84401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| l"
    },
    {
      "t": 97569,
      "e": 84441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97665,
      "e": 84537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 97665,
      "e": 84537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97713,
      "e": 84585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 97778,
      "e": 84650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 97779,
      "e": 84651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97866,
      "e": 84738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97866,
      "e": 84738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97881,
      "e": 84753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 97978,
      "e": 84850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98066,
      "e": 84938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 98067,
      "e": 84939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98170,
      "e": 85042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 98458,
      "e": 85330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98459,
      "e": 85331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98577,
      "e": 85449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 98577,
      "e": 85449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 98698,
      "e": 85570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 98698,
      "e": 85570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98778,
      "e": 85650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 98794,
      "e": 85666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98858,
      "e": 85730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 98859,
      "e": 85731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98921,
      "e": 85793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 99002,
      "e": 85874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 99002,
      "e": 85874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99073,
      "e": 85945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 99186,
      "e": 86058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99187,
      "e": 86059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99297,
      "e": 86169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99802,
      "e": 86674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 99803,
      "e": 86675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99873,
      "e": 86745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 99938,
      "e": 86810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 99938,
      "e": 86810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100034,
      "e": 86906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 100058,
      "e": 86930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 100058,
      "e": 86930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100169,
      "e": 87041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 100169,
      "e": 87041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100177,
      "e": 87049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 100233,
      "e": 87105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 100233,
      "e": 87105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100257,
      "e": 87129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 100314,
      "e": 87186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 100314,
      "e": 87186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100337,
      "e": 87209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 100426,
      "e": 87298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 100426,
      "e": 87298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100433,
      "e": 87305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 100490,
      "e": 87362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100609,
      "e": 87481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the right line. All events "
    },
    {
      "t": 101033,
      "e": 87905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 101034,
      "e": 87906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101097,
      "e": 87969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 101186,
      "e": 88058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 101186,
      "e": 88058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101257,
      "e": 88129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 101354,
      "e": 88226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101354,
      "e": 88226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101450,
      "e": 88227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 101457,
      "e": 88234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 101458,
      "e": 88235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101521,
      "e": 88298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 101521,
      "e": 88298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101553,
      "e": 88330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 101577,
      "e": 88354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 101577,
      "e": 88354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101602,
      "e": 88379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 101657,
      "e": 88434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 101658,
      "e": 88435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101689,
      "e": 88466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 101722,
      "e": 88499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101722,
      "e": 88499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101777,
      "e": 88554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 101785,
      "e": 88562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101897,
      "e": 88674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 101898,
      "e": 88675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101953,
      "e": 88730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 102049,
      "e": 88826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 102049,
      "e": 88826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102098,
      "e": 88875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 102146,
      "e": 88923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 102146,
      "e": 88923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102218,
      "e": 88995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 102218,
      "e": 88995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102233,
      "e": 89010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 102322,
      "e": 89099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 102338,
      "e": 89115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102338,
      "e": 89115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102433,
      "e": 89210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 102433,
      "e": 89210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102457,
      "e": 89234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 102513,
      "e": 89290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 102514,
      "e": 89291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102529,
      "e": 89306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 102602,
      "e": 89379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 102602,
      "e": 89379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 102603,
      "e": 89380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102674,
      "e": 89451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 102674,
      "e": 89451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102713,
      "e": 89490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 102746,
      "e": 89523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 102818,
      "e": 89595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 102818,
      "e": 89595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102913,
      "e": 89690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 102945,
      "e": 89722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102946,
      "e": 89723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103033,
      "e": 89810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103090,
      "e": 89867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 103091,
      "e": 89868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103153,
      "e": 89930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 103153,
      "e": 89930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103185,
      "e": 89962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 103249,
      "e": 90026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103250,
      "e": 90027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103258,
      "e": 90035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103329,
      "e": 90106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 104562,
      "e": 91339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 104563,
      "e": 91340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104625,
      "e": 91402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 104626,
      "e": 91403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104673,
      "e": 91450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 104762,
      "e": 91539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 104826,
      "e": 91603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 104827,
      "e": 91604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104897,
      "e": 91674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 104978,
      "e": 91755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 104978,
      "e": 91755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105057,
      "e": 91834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 105154,
      "e": 91931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 105154,
      "e": 91931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105241,
      "e": 92018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 106006,
      "e": 92783,
      "ty": 2,
      "x": 523,
      "y": 571
    },
    {
      "t": 106007,
      "e": 92784,
      "ty": 41,
      "x": 47876,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106066,
      "e": 92843,
      "ty": 7,
      "x": 499,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106107,
      "e": 92884,
      "ty": 2,
      "x": 491,
      "y": 619
    },
    {
      "t": 106206,
      "e": 92983,
      "ty": 2,
      "x": 456,
      "y": 766
    },
    {
      "t": 106257,
      "e": 93034,
      "ty": 41,
      "x": 40344,
      "y": 41326,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 106307,
      "e": 93084,
      "ty": 2,
      "x": 454,
      "y": 747
    },
    {
      "t": 106406,
      "e": 93183,
      "ty": 2,
      "x": 453,
      "y": 716
    },
    {
      "t": 106507,
      "e": 93284,
      "ty": 2,
      "x": 456,
      "y": 698
    },
    {
      "t": 106507,
      "e": 93284,
      "ty": 41,
      "x": 64320,
      "y": 49980,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 106606,
      "e": 93383,
      "ty": 2,
      "x": 449,
      "y": 689
    },
    {
      "t": 106617,
      "e": 93394,
      "ty": 6,
      "x": 445,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 106706,
      "e": 93483,
      "ty": 2,
      "x": 440,
      "y": 685
    },
    {
      "t": 106757,
      "e": 93534,
      "ty": 41,
      "x": 53742,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 106766,
      "e": 93543,
      "ty": 3,
      "x": 437,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 106766,
      "e": 93543,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the right line. All events on that line start at 12pm."
    },
    {
      "t": 106767,
      "e": 93544,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106767,
      "e": 93544,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 106806,
      "e": 93583,
      "ty": 2,
      "x": 437,
      "y": 678
    },
    {
      "t": 106894,
      "e": 93671,
      "ty": 4,
      "x": 53742,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 106910,
      "e": 93687,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 106912,
      "e": 93689,
      "ty": 5,
      "x": 437,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 106922,
      "e": 93699,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 107706,
      "e": 94483,
      "ty": 2,
      "x": 433,
      "y": 654
    },
    {
      "t": 107757,
      "e": 94534,
      "ty": 41,
      "x": 15531,
      "y": 35066,
      "ta": "html > body"
    },
    {
      "t": 107807,
      "e": 94584,
      "ty": 2,
      "x": 459,
      "y": 641
    },
    {
      "t": 107907,
      "e": 94684,
      "ty": 2,
      "x": 602,
      "y": 826
    },
    {
      "t": 107921,
      "e": 94698,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 108007,
      "e": 94784,
      "ty": 41,
      "x": 20456,
      "y": 45314,
      "ta": "html > body"
    },
    {
      "t": 108606,
      "e": 95383,
      "ty": 2,
      "x": 684,
      "y": 790
    },
    {
      "t": 108707,
      "e": 95484,
      "ty": 2,
      "x": 810,
      "y": 686
    },
    {
      "t": 108734,
      "e": 95511,
      "ty": 6,
      "x": 839,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108751,
      "e": 95528,
      "ty": 7,
      "x": 846,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108757,
      "e": 95534,
      "ty": 41,
      "x": 8218,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 108806,
      "e": 95583,
      "ty": 2,
      "x": 873,
      "y": 598
    },
    {
      "t": 108902,
      "e": 95679,
      "ty": 6,
      "x": 890,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108906,
      "e": 95683,
      "ty": 2,
      "x": 890,
      "y": 574
    },
    {
      "t": 109007,
      "e": 95784,
      "ty": 2,
      "x": 902,
      "y": 564
    },
    {
      "t": 109007,
      "e": 95784,
      "ty": 41,
      "x": 20330,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109107,
      "e": 95884,
      "ty": 2,
      "x": 904,
      "y": 560
    },
    {
      "t": 109110,
      "e": 95887,
      "ty": 3,
      "x": 904,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109112,
      "e": 95889,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109190,
      "e": 95967,
      "ty": 4,
      "x": 20763,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109191,
      "e": 95968,
      "ty": 5,
      "x": 904,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109257,
      "e": 96034,
      "ty": 41,
      "x": 20763,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110186,
      "e": 96963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 110186,
      "e": 96963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110273,
      "e": 97050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "99"
    },
    {
      "t": 110273,
      "e": 97050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110330,
      "e": 97107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 110386,
      "e": 97163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 110610,
      "e": 97387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 110611,
      "e": 97388,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 110611,
      "e": 97388,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110612,
      "e": 97389,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110729,
      "e": 97506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 111426,
      "e": 98203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 111641,
      "e": 98418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 111641,
      "e": 98418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 111690,
      "e": 98467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 111690,
      "e": 98467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 111713,
      "e": 98490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 111786,
      "e": 98563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 111809,
      "e": 98586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 112405,
      "e": 99182,
      "ty": 7,
      "x": 912,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112407,
      "e": 99184,
      "ty": 2,
      "x": 912,
      "y": 577
    },
    {
      "t": 112507,
      "e": 99284,
      "ty": 2,
      "x": 912,
      "y": 602
    },
    {
      "t": 112507,
      "e": 99284,
      "ty": 41,
      "x": 22493,
      "y": 2340,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 112607,
      "e": 99384,
      "ty": 2,
      "x": 906,
      "y": 641
    },
    {
      "t": 112622,
      "e": 99399,
      "ty": 6,
      "x": 905,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 112655,
      "e": 99432,
      "ty": 7,
      "x": 901,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 112655,
      "e": 99432,
      "ty": 6,
      "x": 901,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 112707,
      "e": 99484,
      "ty": 2,
      "x": 901,
      "y": 685
    },
    {
      "t": 112757,
      "e": 99534,
      "ty": 41,
      "x": 2617,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 112907,
      "e": 99684,
      "ty": 2,
      "x": 901,
      "y": 683
    },
    {
      "t": 112939,
      "e": 99716,
      "ty": 7,
      "x": 909,
      "y": 671,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 112955,
      "e": 99732,
      "ty": 6,
      "x": 915,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 113005,
      "e": 99782,
      "ty": 7,
      "x": 919,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 113006,
      "e": 99783,
      "ty": 2,
      "x": 919,
      "y": 646
    },
    {
      "t": 113006,
      "e": 99783,
      "ty": 41,
      "x": 24007,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 113107,
      "e": 99884,
      "ty": 2,
      "x": 923,
      "y": 640
    },
    {
      "t": 113257,
      "e": 100034,
      "ty": 41,
      "x": 24873,
      "y": 40166,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 113434,
      "e": 100211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 113530,
      "e": 100307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 113690,
      "e": 100467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 113690,
      "e": 100467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 113777,
      "e": 100554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 113857,
      "e": 100634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 113857,
      "e": 100634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 113929,
      "e": 100706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 113931,
      "e": 100708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 113945,
      "e": 100722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 113985,
      "e": 100762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 113986,
      "e": 100763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114017,
      "e": 100794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 114065,
      "e": 100842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 114306,
      "e": 101083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 114307,
      "e": 101084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114417,
      "e": 101194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 114441,
      "e": 101218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 114442,
      "e": 101219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114489,
      "e": 101266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 114545,
      "e": 101322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 114579,
      "e": 101356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 114579,
      "e": 101356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114641,
      "e": 101418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 114673,
      "e": 101450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 114738,
      "e": 101515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 114738,
      "e": 101515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114802,
      "e": 101579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 114802,
      "e": 101579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114810,
      "e": 101587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 114906,
      "e": 101683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 114906,
      "e": 101683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 114930,
      "e": 101707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 114993,
      "e": 101770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 114993,
      "e": 101770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115017,
      "e": 101794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 115057,
      "e": 101834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 115058,
      "e": 101835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115138,
      "e": 101915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 115138,
      "e": 101915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115145,
      "e": 101922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s "
    },
    {
      "t": 115185,
      "e": 101962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 115250,
      "e": 102027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 115282,
      "e": 102059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 115283,
      "e": 102060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115338,
      "e": 102115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 115339,
      "e": 102116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115369,
      "e": 102146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||of"
    },
    {
      "t": 115457,
      "e": 102234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 115465,
      "e": 102242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 115465,
      "e": 102242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115553,
      "e": 102330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 116954,
      "e": 103731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 117453,
      "e": 104230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 117481,
      "e": 104258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States o"
    },
    {
      "t": 117607,
      "e": 104384,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States o"
    },
    {
      "t": 117642,
      "e": 104384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 117729,
      "e": 104471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States "
    },
    {
      "t": 117849,
      "e": 104591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 117913,
      "e": 104655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 118010,
      "e": 104752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 118065,
      "e": 104807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United State"
    },
    {
      "t": 118207,
      "e": 104949,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United State"
    },
    {
      "t": 118474,
      "e": 105216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 118578,
      "e": 105320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 118578,
      "e": 105320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118665,
      "e": 105407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 118705,
      "e": 105447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 118806,
      "e": 105548,
      "ty": 2,
      "x": 927,
      "y": 646
    },
    {
      "t": 118810,
      "e": 105552,
      "ty": 6,
      "x": 929,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118860,
      "e": 105602,
      "ty": 7,
      "x": 938,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118906,
      "e": 105648,
      "ty": 2,
      "x": 942,
      "y": 674
    },
    {
      "t": 118928,
      "e": 105670,
      "ty": 6,
      "x": 945,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119006,
      "e": 105748,
      "ty": 2,
      "x": 947,
      "y": 682
    },
    {
      "t": 119007,
      "e": 105749,
      "ty": 41,
      "x": 26325,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119106,
      "e": 105848,
      "ty": 2,
      "x": 943,
      "y": 700
    },
    {
      "t": 119119,
      "e": 105861,
      "ty": 3,
      "x": 943,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119119,
      "e": 105861,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United StateS"
    },
    {
      "t": 119120,
      "e": 105862,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119120,
      "e": 105862,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119213,
      "e": 105955,
      "ty": 4,
      "x": 24263,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119214,
      "e": 105956,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119214,
      "e": 105956,
      "ty": 5,
      "x": 943,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119215,
      "e": 105957,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 119256,
      "e": 105998,
      "ty": 41,
      "x": 32199,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 119706,
      "e": 106448,
      "ty": 2,
      "x": 949,
      "y": 713
    },
    {
      "t": 119756,
      "e": 106498,
      "ty": 41,
      "x": 33025,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 119806,
      "e": 106548,
      "ty": 2,
      "x": 967,
      "y": 738
    },
    {
      "t": 120206,
      "e": 106948,
      "ty": 2,
      "x": 968,
      "y": 738
    },
    {
      "t": 120234,
      "e": 106976,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 120256,
      "e": 106998,
      "ty": 41,
      "x": 38295,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 120306,
      "e": 107048,
      "ty": 2,
      "x": 989,
      "y": 700
    },
    {
      "t": 120406,
      "e": 107148,
      "ty": 2,
      "x": 990,
      "y": 697
    },
    {
      "t": 120507,
      "e": 107249,
      "ty": 41,
      "x": 42478,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 121006,
      "e": 107748,
      "ty": 2,
      "x": 993,
      "y": 617
    },
    {
      "t": 121006,
      "e": 107748,
      "ty": 41,
      "x": 40719,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 121106,
      "e": 107848,
      "ty": 2,
      "x": 992,
      "y": 309
    },
    {
      "t": 121206,
      "e": 107948,
      "ty": 2,
      "x": 986,
      "y": 271
    },
    {
      "t": 121260,
      "e": 108002,
      "ty": 41,
      "x": 38821,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 121310,
      "e": 108052,
      "ty": 2,
      "x": 968,
      "y": 272
    },
    {
      "t": 121409,
      "e": 108151,
      "ty": 2,
      "x": 941,
      "y": 265
    },
    {
      "t": 121509,
      "e": 108251,
      "ty": 2,
      "x": 917,
      "y": 252
    },
    {
      "t": 121510,
      "e": 108252,
      "ty": 41,
      "x": 22683,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 121610,
      "e": 108352,
      "ty": 2,
      "x": 898,
      "y": 249
    },
    {
      "t": 121710,
      "e": 108452,
      "ty": 2,
      "x": 884,
      "y": 244
    },
    {
      "t": 121760,
      "e": 108502,
      "ty": 41,
      "x": 47148,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 121770,
      "e": 108512,
      "ty": 3,
      "x": 879,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 121810,
      "e": 108552,
      "ty": 2,
      "x": 879,
      "y": 240
    },
    {
      "t": 121889,
      "e": 108631,
      "ty": 4,
      "x": 47148,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 121889,
      "e": 108631,
      "ty": 5,
      "x": 879,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 121890,
      "e": 108632,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 121890,
      "e": 108632,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 122310,
      "e": 109052,
      "ty": 2,
      "x": 876,
      "y": 252
    },
    {
      "t": 122410,
      "e": 109152,
      "ty": 2,
      "x": 869,
      "y": 296
    },
    {
      "t": 122509,
      "e": 109251,
      "ty": 2,
      "x": 864,
      "y": 326
    },
    {
      "t": 122510,
      "e": 109252,
      "ty": 41,
      "x": 42268,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 122611,
      "e": 109254,
      "ty": 2,
      "x": 862,
      "y": 350
    },
    {
      "t": 122710,
      "e": 109353,
      "ty": 2,
      "x": 862,
      "y": 381
    },
    {
      "t": 122760,
      "e": 109403,
      "ty": 41,
      "x": 46329,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 122810,
      "e": 109453,
      "ty": 2,
      "x": 861,
      "y": 437
    },
    {
      "t": 122910,
      "e": 109553,
      "ty": 2,
      "x": 859,
      "y": 498
    },
    {
      "t": 123010,
      "e": 109653,
      "ty": 2,
      "x": 859,
      "y": 523
    },
    {
      "t": 123010,
      "e": 109653,
      "ty": 41,
      "x": 43976,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 123110,
      "e": 109753,
      "ty": 2,
      "x": 862,
      "y": 542
    },
    {
      "t": 123210,
      "e": 109853,
      "ty": 2,
      "x": 863,
      "y": 551
    },
    {
      "t": 123260,
      "e": 109903,
      "ty": 41,
      "x": 29052,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 123310,
      "e": 109953,
      "ty": 2,
      "x": 864,
      "y": 554
    },
    {
      "t": 123710,
      "e": 110353,
      "ty": 2,
      "x": 870,
      "y": 541
    },
    {
      "t": 123760,
      "e": 110403,
      "ty": 41,
      "x": 11528,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 123810,
      "e": 110453,
      "ty": 2,
      "x": 871,
      "y": 534
    },
    {
      "t": 123909,
      "e": 110552,
      "ty": 2,
      "x": 869,
      "y": 527
    },
    {
      "t": 124010,
      "e": 110653,
      "ty": 2,
      "x": 868,
      "y": 525
    },
    {
      "t": 124010,
      "e": 110653,
      "ty": 41,
      "x": 54508,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 124057,
      "e": 110700,
      "ty": 3,
      "x": 868,
      "y": 525,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 124059,
      "e": 110702,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 124162,
      "e": 110805,
      "ty": 4,
      "x": 54508,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 124162,
      "e": 110805,
      "ty": 5,
      "x": 868,
      "y": 525,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 124163,
      "e": 110806,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 124164,
      "e": 110807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 124611,
      "e": 111254,
      "ty": 2,
      "x": 868,
      "y": 527
    },
    {
      "t": 124710,
      "e": 111353,
      "ty": 2,
      "x": 868,
      "y": 546
    },
    {
      "t": 124761,
      "e": 111404,
      "ty": 41,
      "x": 31781,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 124810,
      "e": 111453,
      "ty": 2,
      "x": 868,
      "y": 574
    },
    {
      "t": 124910,
      "e": 111553,
      "ty": 2,
      "x": 868,
      "y": 592
    },
    {
      "t": 125010,
      "e": 111653,
      "ty": 2,
      "x": 869,
      "y": 620
    },
    {
      "t": 125010,
      "e": 111653,
      "ty": 41,
      "x": 11291,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 125110,
      "e": 111753,
      "ty": 2,
      "x": 871,
      "y": 633
    },
    {
      "t": 125210,
      "e": 111853,
      "ty": 2,
      "x": 874,
      "y": 649
    },
    {
      "t": 125260,
      "e": 111903,
      "ty": 41,
      "x": 12715,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 125310,
      "e": 111953,
      "ty": 2,
      "x": 876,
      "y": 665
    },
    {
      "t": 125410,
      "e": 112053,
      "ty": 2,
      "x": 877,
      "y": 673
    },
    {
      "t": 125510,
      "e": 112153,
      "ty": 2,
      "x": 878,
      "y": 680
    },
    {
      "t": 125510,
      "e": 112153,
      "ty": 41,
      "x": 15191,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 125610,
      "e": 112253,
      "ty": 2,
      "x": 878,
      "y": 690
    },
    {
      "t": 125710,
      "e": 112353,
      "ty": 2,
      "x": 880,
      "y": 699
    },
    {
      "t": 125760,
      "e": 112403,
      "ty": 41,
      "x": 14760,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 125810,
      "e": 112453,
      "ty": 2,
      "x": 880,
      "y": 706
    },
    {
      "t": 125909,
      "e": 112552,
      "ty": 2,
      "x": 880,
      "y": 708
    },
    {
      "t": 126010,
      "e": 112653,
      "ty": 2,
      "x": 880,
      "y": 716
    },
    {
      "t": 126010,
      "e": 112653,
      "ty": 41,
      "x": 13902,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 126110,
      "e": 112753,
      "ty": 2,
      "x": 881,
      "y": 723
    },
    {
      "t": 126210,
      "e": 112853,
      "ty": 2,
      "x": 881,
      "y": 730
    },
    {
      "t": 126260,
      "e": 112903,
      "ty": 41,
      "x": 14953,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 126310,
      "e": 112953,
      "ty": 2,
      "x": 882,
      "y": 737
    },
    {
      "t": 126410,
      "e": 113053,
      "ty": 2,
      "x": 882,
      "y": 743
    },
    {
      "t": 126510,
      "e": 113153,
      "ty": 2,
      "x": 882,
      "y": 746
    },
    {
      "t": 126511,
      "e": 113154,
      "ty": 41,
      "x": 14376,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 126610,
      "e": 113253,
      "ty": 2,
      "x": 882,
      "y": 751
    },
    {
      "t": 126710,
      "e": 113353,
      "ty": 2,
      "x": 882,
      "y": 764
    },
    {
      "t": 126761,
      "e": 113404,
      "ty": 41,
      "x": 25276,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 126810,
      "e": 113453,
      "ty": 2,
      "x": 881,
      "y": 778
    },
    {
      "t": 126910,
      "e": 113453,
      "ty": 2,
      "x": 881,
      "y": 797
    },
    {
      "t": 127010,
      "e": 113553,
      "ty": 2,
      "x": 880,
      "y": 817
    },
    {
      "t": 127011,
      "e": 113554,
      "ty": 41,
      "x": 34575,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 127110,
      "e": 113653,
      "ty": 2,
      "x": 879,
      "y": 834
    },
    {
      "t": 127210,
      "e": 113753,
      "ty": 2,
      "x": 880,
      "y": 827
    },
    {
      "t": 127261,
      "e": 113804,
      "ty": 41,
      "x": 43430,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 127310,
      "e": 113853,
      "ty": 2,
      "x": 919,
      "y": 749
    },
    {
      "t": 127410,
      "e": 113953,
      "ty": 2,
      "x": 944,
      "y": 692
    },
    {
      "t": 127510,
      "e": 114053,
      "ty": 2,
      "x": 954,
      "y": 678
    },
    {
      "t": 127510,
      "e": 114053,
      "ty": 41,
      "x": 35597,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 127610,
      "e": 114153,
      "ty": 2,
      "x": 960,
      "y": 664
    },
    {
      "t": 127760,
      "e": 114303,
      "ty": 41,
      "x": 32888,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 127910,
      "e": 114453,
      "ty": 2,
      "x": 959,
      "y": 673
    },
    {
      "t": 128010,
      "e": 114553,
      "ty": 2,
      "x": 955,
      "y": 708
    },
    {
      "t": 128010,
      "e": 114553,
      "ty": 41,
      "x": 33659,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 128111,
      "e": 114654,
      "ty": 2,
      "x": 955,
      "y": 712
    },
    {
      "t": 128260,
      "e": 114803,
      "ty": 41,
      "x": 33659,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 128710,
      "e": 115253,
      "ty": 2,
      "x": 956,
      "y": 722
    },
    {
      "t": 128761,
      "e": 115304,
      "ty": 41,
      "x": 34028,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 128810,
      "e": 115353,
      "ty": 2,
      "x": 958,
      "y": 729
    },
    {
      "t": 128911,
      "e": 115454,
      "ty": 2,
      "x": 959,
      "y": 731
    },
    {
      "t": 129011,
      "e": 115554,
      "ty": 41,
      "x": 34530,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 129111,
      "e": 115654,
      "ty": 2,
      "x": 960,
      "y": 735
    },
    {
      "t": 129260,
      "e": 115803,
      "ty": 41,
      "x": 34781,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 129410,
      "e": 115953,
      "ty": 2,
      "x": 967,
      "y": 725
    },
    {
      "t": 129511,
      "e": 116054,
      "ty": 2,
      "x": 974,
      "y": 712
    },
    {
      "t": 129511,
      "e": 116054,
      "ty": 41,
      "x": 38446,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 129710,
      "e": 116253,
      "ty": 2,
      "x": 977,
      "y": 711
    },
    {
      "t": 129761,
      "e": 116304,
      "ty": 41,
      "x": 40714,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 129810,
      "e": 116353,
      "ty": 2,
      "x": 983,
      "y": 702
    },
    {
      "t": 129826,
      "e": 116369,
      "ty": 3,
      "x": 983,
      "y": 702,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 129827,
      "e": 116370,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 129954,
      "e": 116497,
      "ty": 4,
      "x": 40714,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 129954,
      "e": 116497,
      "ty": 5,
      "x": 983,
      "y": 702,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 129955,
      "e": 116498,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 129956,
      "e": 116499,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 130510,
      "e": 117053,
      "ty": 2,
      "x": 968,
      "y": 732
    },
    {
      "t": 130510,
      "e": 117053,
      "ty": 41,
      "x": 36789,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 130610,
      "e": 117153,
      "ty": 2,
      "x": 951,
      "y": 764
    },
    {
      "t": 130710,
      "e": 117253,
      "ty": 2,
      "x": 940,
      "y": 799
    },
    {
      "t": 130760,
      "e": 117303,
      "ty": 41,
      "x": 25056,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 130810,
      "e": 117353,
      "ty": 2,
      "x": 909,
      "y": 890
    },
    {
      "t": 130910,
      "e": 117453,
      "ty": 2,
      "x": 908,
      "y": 890
    },
    {
      "t": 131011,
      "e": 117554,
      "ty": 41,
      "x": 20547,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 131310,
      "e": 117853,
      "ty": 2,
      "x": 897,
      "y": 904
    },
    {
      "t": 131410,
      "e": 117953,
      "ty": 2,
      "x": 874,
      "y": 930
    },
    {
      "t": 131510,
      "e": 118053,
      "ty": 2,
      "x": 868,
      "y": 935
    },
    {
      "t": 131510,
      "e": 118053,
      "ty": 41,
      "x": 50874,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 131610,
      "e": 118153,
      "ty": 2,
      "x": 865,
      "y": 937
    },
    {
      "t": 131617,
      "e": 118160,
      "ty": 3,
      "x": 865,
      "y": 937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 131617,
      "e": 118160,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 131705,
      "e": 118248,
      "ty": 4,
      "x": 47598,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 131706,
      "e": 118249,
      "ty": 5,
      "x": 865,
      "y": 937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 131707,
      "e": 118250,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 131708,
      "e": 118251,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 131760,
      "e": 118303,
      "ty": 41,
      "x": 47598,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 131810,
      "e": 118353,
      "ty": 2,
      "x": 865,
      "y": 940
    },
    {
      "t": 131911,
      "e": 118454,
      "ty": 2,
      "x": 893,
      "y": 1001
    },
    {
      "t": 131960,
      "e": 118456,
      "ty": 6,
      "x": 894,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132010,
      "e": 118506,
      "ty": 2,
      "x": 896,
      "y": 1020
    },
    {
      "t": 132011,
      "e": 118507,
      "ty": 41,
      "x": 34313,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132370,
      "e": 118866,
      "ty": 3,
      "x": 896,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132371,
      "e": 118867,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 132372,
      "e": 118868,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132649,
      "e": 119145,
      "ty": 4,
      "x": 34313,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132650,
      "e": 119146,
      "ty": 5,
      "x": 896,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132655,
      "e": 119151,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132656,
      "e": 119152,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 132659,
      "e": 119155,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 133997,
      "e": 120493,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 134709,
      "e": 121205,
      "ty": 6,
      "x": 928,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 134711,
      "e": 121207,
      "ty": 2,
      "x": 928,
      "y": 1075
    },
    {
      "t": 134760,
      "e": 121256,
      "ty": 41,
      "x": 14472,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 134809,
      "e": 121305,
      "ty": 7,
      "x": 954,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 134809,
      "e": 121305,
      "ty": 2,
      "x": 954,
      "y": 1108
    },
    {
      "t": 134910,
      "e": 121406,
      "ty": 2,
      "x": 956,
      "y": 1109
    },
    {
      "t": 134927,
      "e": 121423,
      "ty": 6,
      "x": 961,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 135011,
      "e": 121507,
      "ty": 2,
      "x": 964,
      "y": 1100
    },
    {
      "t": 135011,
      "e": 121507,
      "ty": 41,
      "x": 29763,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 140010,
      "e": 126506,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140610,
      "e": 126507,
      "ty": 2,
      "x": 964,
      "y": 1097
    },
    {
      "t": 140710,
      "e": 126607,
      "ty": 2,
      "x": 975,
      "y": 1084
    },
    {
      "t": 140760,
      "e": 126657,
      "ty": 41,
      "x": 35771,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 140874,
      "e": 126771,
      "ty": 3,
      "x": 975,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 140875,
      "e": 126772,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 140969,
      "e": 126866,
      "ty": 4,
      "x": 35771,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 140969,
      "e": 126866,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 140970,
      "e": 126867,
      "ty": 5,
      "x": 975,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 140970,
      "e": 126867,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 142008,
      "e": 127905,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 143200,
      "e": 129097,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 191703, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 191709, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3852, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 196891, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 58693, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 256593, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 21893, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 279821, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9121, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 289945, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 35430, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 326748, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -A -10 AM-11 AM-F -F -10 AM-F -F -F -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1127,y:871,t:1528139550540};\\\", \\\"{x:1127,y:869,t:1528139550549};\\\", \\\"{x:1117,y:865,t:1528139550907};\\\", \\\"{x:1102,y:861,t:1528139550914};\\\", \\\"{x:1040,y:829,t:1528139550931};\\\", \\\"{x:959,y:793,t:1528139550948};\\\", \\\"{x:910,y:772,t:1528139550965};\\\", \\\"{x:887,y:758,t:1528139550981};\\\", \\\"{x:865,y:750,t:1528139550998};\\\", \\\"{x:845,y:745,t:1528139551015};\\\", \\\"{x:833,y:741,t:1528139551031};\\\", \\\"{x:825,y:739,t:1528139551048};\\\", \\\"{x:824,y:738,t:1528139551065};\\\", \\\"{x:825,y:738,t:1528139552107};\\\", \\\"{x:829,y:738,t:1528139552115};\\\", \\\"{x:839,y:738,t:1528139552132};\\\", \\\"{x:855,y:738,t:1528139552149};\\\", \\\"{x:875,y:739,t:1528139552166};\\\", \\\"{x:908,y:743,t:1528139552181};\\\", \\\"{x:942,y:746,t:1528139552199};\\\", \\\"{x:1001,y:755,t:1528139552216};\\\", \\\"{x:1051,y:762,t:1528139552233};\\\", \\\"{x:1075,y:768,t:1528139552249};\\\", \\\"{x:1089,y:771,t:1528139552266};\\\", \\\"{x:1096,y:771,t:1528139552282};\\\", \\\"{x:1102,y:772,t:1528139552299};\\\", \\\"{x:1106,y:772,t:1528139552316};\\\", \\\"{x:1109,y:772,t:1528139552332};\\\", \\\"{x:1110,y:772,t:1528139552411};\\\", \\\"{x:1110,y:773,t:1528139552659};\\\", \\\"{x:1110,y:774,t:1528139552691};\\\", \\\"{x:1110,y:773,t:1528139553033};\\\", \\\"{x:1106,y:759,t:1528139553050};\\\", \\\"{x:1104,y:749,t:1528139553065};\\\", \\\"{x:1101,y:740,t:1528139553083};\\\", \\\"{x:1098,y:731,t:1528139553100};\\\", \\\"{x:1096,y:723,t:1528139553116};\\\", \\\"{x:1092,y:714,t:1528139553132};\\\", \\\"{x:1089,y:708,t:1528139553149};\\\", \\\"{x:1087,y:701,t:1528139553165};\\\", \\\"{x:1086,y:697,t:1528139553183};\\\", \\\"{x:1086,y:696,t:1528139553200};\\\", \\\"{x:1086,y:695,t:1528139553216};\\\", \\\"{x:1085,y:695,t:1528139553274};\\\", \\\"{x:1084,y:696,t:1528139553283};\\\", \\\"{x:1081,y:706,t:1528139553300};\\\", \\\"{x:1078,y:717,t:1528139553317};\\\", \\\"{x:1076,y:727,t:1528139553333};\\\", \\\"{x:1075,y:738,t:1528139553350};\\\", \\\"{x:1075,y:745,t:1528139553367};\\\", \\\"{x:1075,y:752,t:1528139553383};\\\", \\\"{x:1075,y:757,t:1528139553401};\\\", \\\"{x:1075,y:760,t:1528139553416};\\\", \\\"{x:1074,y:764,t:1528139553434};\\\", \\\"{x:1073,y:767,t:1528139553450};\\\", \\\"{x:1072,y:771,t:1528139553466};\\\", \\\"{x:1070,y:777,t:1528139553483};\\\", \\\"{x:1070,y:785,t:1528139553500};\\\", \\\"{x:1070,y:795,t:1528139553518};\\\", \\\"{x:1070,y:803,t:1528139553534};\\\", \\\"{x:1070,y:811,t:1528139553550};\\\", \\\"{x:1070,y:819,t:1528139553567};\\\", \\\"{x:1070,y:834,t:1528139553583};\\\", \\\"{x:1072,y:851,t:1528139553601};\\\", \\\"{x:1076,y:872,t:1528139553617};\\\", \\\"{x:1077,y:888,t:1528139553633};\\\", \\\"{x:1078,y:901,t:1528139553651};\\\", \\\"{x:1081,y:914,t:1528139553667};\\\", \\\"{x:1085,y:926,t:1528139553683};\\\", \\\"{x:1087,y:933,t:1528139553700};\\\", \\\"{x:1090,y:937,t:1528139553718};\\\", \\\"{x:1090,y:941,t:1528139553734};\\\", \\\"{x:1092,y:945,t:1528139553750};\\\", \\\"{x:1095,y:950,t:1528139553768};\\\", \\\"{x:1097,y:952,t:1528139553784};\\\", \\\"{x:1101,y:959,t:1528139553802};\\\", \\\"{x:1107,y:969,t:1528139553817};\\\", \\\"{x:1116,y:980,t:1528139553833};\\\", \\\"{x:1126,y:991,t:1528139553850};\\\", \\\"{x:1131,y:993,t:1528139553866};\\\", \\\"{x:1136,y:996,t:1528139553884};\\\", \\\"{x:1142,y:997,t:1528139553901};\\\", \\\"{x:1151,y:1000,t:1528139553917};\\\", \\\"{x:1164,y:1003,t:1528139553933};\\\", \\\"{x:1175,y:1004,t:1528139553950};\\\", \\\"{x:1190,y:1004,t:1528139553967};\\\", \\\"{x:1208,y:1004,t:1528139553985};\\\", \\\"{x:1218,y:1004,t:1528139554001};\\\", \\\"{x:1226,y:1004,t:1528139554017};\\\", \\\"{x:1241,y:1001,t:1528139554034};\\\", \\\"{x:1251,y:999,t:1528139554050};\\\", \\\"{x:1260,y:997,t:1528139554067};\\\", \\\"{x:1265,y:995,t:1528139554084};\\\", \\\"{x:1268,y:993,t:1528139554100};\\\", \\\"{x:1271,y:991,t:1528139554117};\\\", \\\"{x:1272,y:991,t:1528139554133};\\\", \\\"{x:1274,y:990,t:1528139554149};\\\", \\\"{x:1275,y:988,t:1528139554166};\\\", \\\"{x:1275,y:987,t:1528139554201};\\\", \\\"{x:1275,y:985,t:1528139554217};\\\", \\\"{x:1275,y:983,t:1528139554234};\\\", \\\"{x:1275,y:980,t:1528139554250};\\\", \\\"{x:1275,y:978,t:1528139554267};\\\", \\\"{x:1275,y:976,t:1528139554284};\\\", \\\"{x:1276,y:973,t:1528139554300};\\\", \\\"{x:1276,y:972,t:1528139554317};\\\", \\\"{x:1277,y:971,t:1528139554334};\\\", \\\"{x:1278,y:971,t:1528139554354};\\\", \\\"{x:1278,y:969,t:1528139554367};\\\", \\\"{x:1278,y:968,t:1528139554386};\\\", \\\"{x:1280,y:967,t:1528139554402};\\\", \\\"{x:1282,y:965,t:1528139554418};\\\", \\\"{x:1285,y:963,t:1528139554434};\\\", \\\"{x:1285,y:962,t:1528139554531};\\\", \\\"{x:1287,y:961,t:1528139554555};\\\", \\\"{x:1287,y:959,t:1528139554611};\\\", \\\"{x:1288,y:957,t:1528139554619};\\\", \\\"{x:1289,y:952,t:1528139554634};\\\", \\\"{x:1291,y:946,t:1528139554651};\\\", \\\"{x:1291,y:940,t:1528139554668};\\\", \\\"{x:1292,y:929,t:1528139554685};\\\", \\\"{x:1293,y:919,t:1528139554701};\\\", \\\"{x:1296,y:905,t:1528139554717};\\\", \\\"{x:1297,y:891,t:1528139554734};\\\", \\\"{x:1298,y:881,t:1528139554751};\\\", \\\"{x:1298,y:874,t:1528139554767};\\\", \\\"{x:1298,y:870,t:1528139554784};\\\", \\\"{x:1298,y:868,t:1528139554801};\\\", \\\"{x:1298,y:866,t:1528139554817};\\\", \\\"{x:1298,y:859,t:1528139554834};\\\", \\\"{x:1298,y:854,t:1528139554851};\\\", \\\"{x:1295,y:847,t:1528139554868};\\\", \\\"{x:1295,y:845,t:1528139554885};\\\", \\\"{x:1293,y:843,t:1528139554901};\\\", \\\"{x:1293,y:841,t:1528139554918};\\\", \\\"{x:1292,y:840,t:1528139554938};\\\", \\\"{x:1291,y:837,t:1528139554954};\\\", \\\"{x:1291,y:835,t:1528139554970};\\\", \\\"{x:1291,y:834,t:1528139554984};\\\", \\\"{x:1290,y:833,t:1528139555002};\\\", \\\"{x:1289,y:832,t:1528139555019};\\\", \\\"{x:1289,y:830,t:1528139555042};\\\", \\\"{x:1288,y:830,t:1528139555067};\\\", \\\"{x:1288,y:829,t:1528139555082};\\\", \\\"{x:1287,y:827,t:1528139555099};\\\", \\\"{x:1286,y:825,t:1528139555155};\\\", \\\"{x:1286,y:824,t:1528139555171};\\\", \\\"{x:1285,y:823,t:1528139555202};\\\", \\\"{x:1284,y:823,t:1528139555387};\\\", \\\"{x:1283,y:823,t:1528139555411};\\\", \\\"{x:1281,y:823,t:1528139555418};\\\", \\\"{x:1280,y:823,t:1528139555434};\\\", \\\"{x:1279,y:824,t:1528139555451};\\\", \\\"{x:1278,y:824,t:1528139555468};\\\", \\\"{x:1277,y:825,t:1528139555486};\\\", \\\"{x:1276,y:826,t:1528139555523};\\\", \\\"{x:1276,y:827,t:1528139556051};\\\", \\\"{x:1277,y:827,t:1528139556084};\\\", \\\"{x:1278,y:827,t:1528139556122};\\\", \\\"{x:1278,y:828,t:1528139556135};\\\", \\\"{x:1279,y:828,t:1528139556151};\\\", \\\"{x:1281,y:829,t:1528139557485};\\\", \\\"{x:1282,y:829,t:1528139557526};\\\", \\\"{x:1283,y:829,t:1528139557549};\\\", \\\"{x:1283,y:834,t:1528139565382};\\\", \\\"{x:1282,y:852,t:1528139565413};\\\", \\\"{x:1282,y:860,t:1528139565429};\\\", \\\"{x:1282,y:868,t:1528139565446};\\\", \\\"{x:1282,y:877,t:1528139565462};\\\", \\\"{x:1282,y:885,t:1528139565479};\\\", \\\"{x:1282,y:891,t:1528139565496};\\\", \\\"{x:1282,y:897,t:1528139565512};\\\", \\\"{x:1282,y:901,t:1528139565529};\\\", \\\"{x:1282,y:903,t:1528139565546};\\\", \\\"{x:1282,y:906,t:1528139565562};\\\", \\\"{x:1282,y:908,t:1528139565580};\\\", \\\"{x:1282,y:910,t:1528139565597};\\\", \\\"{x:1282,y:908,t:1528139565758};\\\", \\\"{x:1282,y:907,t:1528139565766};\\\", \\\"{x:1282,y:904,t:1528139565780};\\\", \\\"{x:1282,y:898,t:1528139565797};\\\", \\\"{x:1283,y:890,t:1528139565813};\\\", \\\"{x:1284,y:883,t:1528139565830};\\\", \\\"{x:1285,y:875,t:1528139565847};\\\", \\\"{x:1286,y:869,t:1528139565863};\\\", \\\"{x:1286,y:865,t:1528139565880};\\\", \\\"{x:1288,y:859,t:1528139565897};\\\", \\\"{x:1288,y:853,t:1528139565914};\\\", \\\"{x:1288,y:849,t:1528139565929};\\\", \\\"{x:1289,y:846,t:1528139565947};\\\", \\\"{x:1290,y:842,t:1528139565964};\\\", \\\"{x:1291,y:837,t:1528139565980};\\\", \\\"{x:1291,y:833,t:1528139565997};\\\", \\\"{x:1291,y:830,t:1528139566014};\\\", \\\"{x:1291,y:829,t:1528139566062};\\\", \\\"{x:1291,y:828,t:1528139566084};\\\", \\\"{x:1291,y:827,t:1528139566188};\\\", \\\"{x:1290,y:827,t:1528139566204};\\\", \\\"{x:1289,y:827,t:1528139566213};\\\", \\\"{x:1287,y:827,t:1528139566231};\\\", \\\"{x:1284,y:827,t:1528139566250};\\\", \\\"{x:1283,y:827,t:1528139566280};\\\", \\\"{x:1282,y:827,t:1528139566381};\\\", \\\"{x:1281,y:828,t:1528139569262};\\\", \\\"{x:1264,y:860,t:1528139569283};\\\", \\\"{x:1248,y:893,t:1528139569299};\\\", \\\"{x:1228,y:928,t:1528139569316};\\\", \\\"{x:1209,y:955,t:1528139569332};\\\", \\\"{x:1201,y:965,t:1528139569349};\\\", \\\"{x:1197,y:978,t:1528139569365};\\\", \\\"{x:1197,y:991,t:1528139569382};\\\", \\\"{x:1197,y:1006,t:1528139569399};\\\", \\\"{x:1195,y:1017,t:1528139569415};\\\", \\\"{x:1193,y:1021,t:1528139569433};\\\", \\\"{x:1193,y:1020,t:1528139569550};\\\", \\\"{x:1193,y:1018,t:1528139569566};\\\", \\\"{x:1193,y:1015,t:1528139569583};\\\", \\\"{x:1193,y:1013,t:1528139569646};\\\", \\\"{x:1195,y:1010,t:1528139569653};\\\", \\\"{x:1197,y:1009,t:1528139569666};\\\", \\\"{x:1205,y:1004,t:1528139569683};\\\", \\\"{x:1214,y:1002,t:1528139569701};\\\", \\\"{x:1229,y:997,t:1528139569717};\\\", \\\"{x:1233,y:994,t:1528139569733};\\\", \\\"{x:1241,y:990,t:1528139569750};\\\", \\\"{x:1246,y:987,t:1528139569767};\\\", \\\"{x:1248,y:986,t:1528139569783};\\\", \\\"{x:1253,y:983,t:1528139569800};\\\", \\\"{x:1258,y:980,t:1528139569817};\\\", \\\"{x:1261,y:977,t:1528139569833};\\\", \\\"{x:1265,y:975,t:1528139569851};\\\", \\\"{x:1266,y:974,t:1528139569867};\\\", \\\"{x:1267,y:973,t:1528139569883};\\\", \\\"{x:1268,y:972,t:1528139569900};\\\", \\\"{x:1271,y:970,t:1528139569917};\\\", \\\"{x:1272,y:968,t:1528139569934};\\\", \\\"{x:1273,y:966,t:1528139569949};\\\", \\\"{x:1274,y:965,t:1528139570013};\\\", \\\"{x:1274,y:963,t:1528139570037};\\\", \\\"{x:1277,y:963,t:1528139570050};\\\", \\\"{x:1277,y:962,t:1528139570067};\\\", \\\"{x:1279,y:961,t:1528139570083};\\\", \\\"{x:1280,y:961,t:1528139570101};\\\", \\\"{x:1281,y:960,t:1528139570118};\\\", \\\"{x:1283,y:960,t:1528139570134};\\\", \\\"{x:1284,y:959,t:1528139570150};\\\", \\\"{x:1284,y:958,t:1528139570168};\\\", \\\"{x:1286,y:958,t:1528139570184};\\\", \\\"{x:1287,y:957,t:1528139570200};\\\", \\\"{x:1288,y:955,t:1528139570217};\\\", \\\"{x:1289,y:952,t:1528139570234};\\\", \\\"{x:1290,y:951,t:1528139570250};\\\", \\\"{x:1290,y:950,t:1528139570267};\\\", \\\"{x:1290,y:949,t:1528139570286};\\\", \\\"{x:1291,y:948,t:1528139570300};\\\", \\\"{x:1295,y:941,t:1528139570317};\\\", \\\"{x:1302,y:933,t:1528139570333};\\\", \\\"{x:1310,y:919,t:1528139570350};\\\", \\\"{x:1331,y:895,t:1528139570367};\\\", \\\"{x:1344,y:871,t:1528139570384};\\\", \\\"{x:1346,y:869,t:1528139570401};\\\", \\\"{x:1347,y:868,t:1528139570718};\\\", \\\"{x:1352,y:859,t:1528139570734};\\\", \\\"{x:1356,y:849,t:1528139570751};\\\", \\\"{x:1360,y:838,t:1528139570767};\\\", \\\"{x:1366,y:827,t:1528139570783};\\\", \\\"{x:1370,y:815,t:1528139570801};\\\", \\\"{x:1372,y:811,t:1528139570817};\\\", \\\"{x:1375,y:804,t:1528139570833};\\\", \\\"{x:1377,y:800,t:1528139570850};\\\", \\\"{x:1379,y:797,t:1528139570866};\\\", \\\"{x:1382,y:793,t:1528139570883};\\\", \\\"{x:1388,y:783,t:1528139570900};\\\", \\\"{x:1390,y:779,t:1528139570917};\\\", \\\"{x:1393,y:775,t:1528139570933};\\\", \\\"{x:1394,y:772,t:1528139570950};\\\", \\\"{x:1398,y:768,t:1528139570967};\\\", \\\"{x:1403,y:763,t:1528139570984};\\\", \\\"{x:1409,y:755,t:1528139571000};\\\", \\\"{x:1415,y:748,t:1528139571017};\\\", \\\"{x:1423,y:737,t:1528139571034};\\\", \\\"{x:1429,y:730,t:1528139571052};\\\", \\\"{x:1433,y:724,t:1528139571068};\\\", \\\"{x:1439,y:717,t:1528139571084};\\\", \\\"{x:1448,y:699,t:1528139571101};\\\", \\\"{x:1453,y:683,t:1528139571117};\\\", \\\"{x:1455,y:674,t:1528139571134};\\\", \\\"{x:1458,y:665,t:1528139571151};\\\", \\\"{x:1459,y:658,t:1528139571168};\\\", \\\"{x:1459,y:656,t:1528139571184};\\\", \\\"{x:1459,y:655,t:1528139571201};\\\", \\\"{x:1453,y:658,t:1528139571254};\\\", \\\"{x:1446,y:664,t:1528139571268};\\\", \\\"{x:1430,y:682,t:1528139571284};\\\", \\\"{x:1412,y:700,t:1528139571302};\\\", \\\"{x:1389,y:725,t:1528139571318};\\\", \\\"{x:1380,y:737,t:1528139571334};\\\", \\\"{x:1376,y:744,t:1528139571351};\\\", \\\"{x:1373,y:749,t:1528139571369};\\\", \\\"{x:1370,y:753,t:1528139571384};\\\", \\\"{x:1368,y:757,t:1528139571401};\\\", \\\"{x:1362,y:766,t:1528139571418};\\\", \\\"{x:1359,y:778,t:1528139571435};\\\", \\\"{x:1358,y:779,t:1528139571451};\\\", \\\"{x:1358,y:780,t:1528139571526};\\\", \\\"{x:1363,y:779,t:1528139571535};\\\", \\\"{x:1375,y:771,t:1528139571551};\\\", \\\"{x:1383,y:766,t:1528139571572};\\\", \\\"{x:1386,y:763,t:1528139571584};\\\", \\\"{x:1384,y:763,t:1528139572598};\\\", \\\"{x:1377,y:763,t:1528139572606};\\\", \\\"{x:1366,y:763,t:1528139572621};\\\", \\\"{x:1332,y:759,t:1528139572635};\\\", \\\"{x:1243,y:745,t:1528139572652};\\\", \\\"{x:1024,y:715,t:1528139572668};\\\", \\\"{x:811,y:683,t:1528139572686};\\\", \\\"{x:570,y:647,t:1528139572702};\\\", \\\"{x:338,y:612,t:1528139572719};\\\", \\\"{x:127,y:573,t:1528139572735};\\\", \\\"{x:0,y:542,t:1528139572751};\\\", \\\"{x:0,y:531,t:1528139572769};\\\", \\\"{x:0,y:528,t:1528139572786};\\\", \\\"{x:0,y:530,t:1528139572885};\\\", \\\"{x:2,y:536,t:1528139572902};\\\", \\\"{x:7,y:542,t:1528139572919};\\\", \\\"{x:15,y:549,t:1528139572936};\\\", \\\"{x:27,y:554,t:1528139572952};\\\", \\\"{x:51,y:560,t:1528139572971};\\\", \\\"{x:72,y:566,t:1528139572986};\\\", \\\"{x:94,y:571,t:1528139573002};\\\", \\\"{x:110,y:572,t:1528139573018};\\\", \\\"{x:123,y:572,t:1528139573035};\\\", \\\"{x:133,y:570,t:1528139573052};\\\", \\\"{x:137,y:569,t:1528139573068};\\\", \\\"{x:138,y:569,t:1528139573085};\\\", \\\"{x:139,y:567,t:1528139573102};\\\", \\\"{x:141,y:567,t:1528139573120};\\\", \\\"{x:146,y:563,t:1528139573135};\\\", \\\"{x:153,y:561,t:1528139573153};\\\", \\\"{x:162,y:558,t:1528139573169};\\\", \\\"{x:171,y:558,t:1528139573186};\\\", \\\"{x:191,y:558,t:1528139573203};\\\", \\\"{x:223,y:558,t:1528139573220};\\\", \\\"{x:256,y:558,t:1528139573236};\\\", \\\"{x:294,y:561,t:1528139573254};\\\", \\\"{x:310,y:566,t:1528139573269};\\\", \\\"{x:317,y:570,t:1528139573285};\\\", \\\"{x:319,y:572,t:1528139573302};\\\", \\\"{x:319,y:573,t:1528139573325};\\\", \\\"{x:320,y:573,t:1528139573335};\\\", \\\"{x:321,y:575,t:1528139573353};\\\", \\\"{x:322,y:576,t:1528139573368};\\\", \\\"{x:323,y:577,t:1528139573385};\\\", \\\"{x:325,y:579,t:1528139573404};\\\", \\\"{x:328,y:582,t:1528139573419};\\\", \\\"{x:332,y:582,t:1528139573436};\\\", \\\"{x:341,y:582,t:1528139573452};\\\", \\\"{x:346,y:582,t:1528139573469};\\\", \\\"{x:354,y:582,t:1528139573486};\\\", \\\"{x:363,y:582,t:1528139573503};\\\", \\\"{x:377,y:582,t:1528139573519};\\\", \\\"{x:387,y:584,t:1528139573537};\\\", \\\"{x:393,y:586,t:1528139573553};\\\", \\\"{x:395,y:587,t:1528139573569};\\\", \\\"{x:397,y:591,t:1528139573586};\\\", \\\"{x:398,y:592,t:1528139573604};\\\", \\\"{x:399,y:593,t:1528139573619};\\\", \\\"{x:399,y:594,t:1528139573635};\\\", \\\"{x:399,y:596,t:1528139573652};\\\", \\\"{x:399,y:597,t:1528139573756};\\\", \\\"{x:398,y:597,t:1528139573781};\\\", \\\"{x:397,y:597,t:1528139573805};\\\", \\\"{x:396,y:597,t:1528139573819};\\\", \\\"{x:406,y:598,t:1528139574181};\\\", \\\"{x:432,y:602,t:1528139574190};\\\", \\\"{x:463,y:605,t:1528139574204};\\\", \\\"{x:550,y:619,t:1528139574222};\\\", \\\"{x:676,y:633,t:1528139574236};\\\", \\\"{x:759,y:646,t:1528139574253};\\\", \\\"{x:856,y:672,t:1528139574269};\\\", \\\"{x:958,y:700,t:1528139574286};\\\", \\\"{x:1039,y:727,t:1528139574302};\\\", \\\"{x:1081,y:744,t:1528139574319};\\\", \\\"{x:1119,y:762,t:1528139574337};\\\", \\\"{x:1141,y:771,t:1528139574353};\\\", \\\"{x:1151,y:779,t:1528139574370};\\\", \\\"{x:1154,y:783,t:1528139574387};\\\", \\\"{x:1162,y:800,t:1528139574403};\\\", \\\"{x:1175,y:820,t:1528139574419};\\\", \\\"{x:1190,y:837,t:1528139574437};\\\", \\\"{x:1193,y:840,t:1528139574453};\\\", \\\"{x:1194,y:841,t:1528139574470};\\\", \\\"{x:1195,y:844,t:1528139574487};\\\", \\\"{x:1199,y:853,t:1528139574503};\\\", \\\"{x:1205,y:868,t:1528139574520};\\\", \\\"{x:1210,y:878,t:1528139574537};\\\", \\\"{x:1213,y:885,t:1528139574553};\\\", \\\"{x:1216,y:895,t:1528139574570};\\\", \\\"{x:1219,y:905,t:1528139574587};\\\", \\\"{x:1224,y:920,t:1528139574604};\\\", \\\"{x:1227,y:936,t:1528139574620};\\\", \\\"{x:1230,y:950,t:1528139574637};\\\", \\\"{x:1230,y:953,t:1528139574654};\\\", \\\"{x:1230,y:954,t:1528139574686};\\\", \\\"{x:1230,y:956,t:1528139574693};\\\", \\\"{x:1230,y:957,t:1528139574705};\\\", \\\"{x:1230,y:961,t:1528139574720};\\\", \\\"{x:1228,y:963,t:1528139574738};\\\", \\\"{x:1226,y:964,t:1528139574754};\\\", \\\"{x:1222,y:965,t:1528139574771};\\\", \\\"{x:1217,y:970,t:1528139574788};\\\", \\\"{x:1214,y:975,t:1528139574805};\\\", \\\"{x:1214,y:977,t:1528139574820};\\\", \\\"{x:1213,y:978,t:1528139574838};\\\", \\\"{x:1213,y:976,t:1528139575076};\\\", \\\"{x:1216,y:974,t:1528139575086};\\\", \\\"{x:1220,y:972,t:1528139575103};\\\", \\\"{x:1223,y:970,t:1528139575120};\\\", \\\"{x:1227,y:969,t:1528139575136};\\\", \\\"{x:1231,y:968,t:1528139575154};\\\", \\\"{x:1233,y:967,t:1528139575170};\\\", \\\"{x:1236,y:967,t:1528139575186};\\\", \\\"{x:1243,y:967,t:1528139575203};\\\", \\\"{x:1249,y:967,t:1528139575221};\\\", \\\"{x:1252,y:967,t:1528139575237};\\\", \\\"{x:1254,y:966,t:1528139575261};\\\", \\\"{x:1256,y:965,t:1528139575310};\\\", \\\"{x:1257,y:964,t:1528139575326};\\\", \\\"{x:1258,y:964,t:1528139575338};\\\", \\\"{x:1262,y:963,t:1528139575354};\\\", \\\"{x:1264,y:963,t:1528139575371};\\\", \\\"{x:1266,y:963,t:1528139575387};\\\", \\\"{x:1267,y:961,t:1528139575404};\\\", \\\"{x:1273,y:959,t:1528139575421};\\\", \\\"{x:1275,y:958,t:1528139575438};\\\", \\\"{x:1277,y:957,t:1528139575455};\\\", \\\"{x:1278,y:957,t:1528139575526};\\\", \\\"{x:1279,y:957,t:1528139575679};\\\", \\\"{x:1280,y:957,t:1528139575718};\\\", \\\"{x:1281,y:957,t:1528139575774};\\\", \\\"{x:1281,y:958,t:1528139575934};\\\", \\\"{x:1282,y:958,t:1528139576150};\\\", \\\"{x:1282,y:956,t:1528139576158};\\\", \\\"{x:1284,y:952,t:1528139576171};\\\", \\\"{x:1287,y:948,t:1528139576189};\\\", \\\"{x:1291,y:943,t:1528139576205};\\\", \\\"{x:1296,y:932,t:1528139576221};\\\", \\\"{x:1299,y:928,t:1528139576238};\\\", \\\"{x:1306,y:920,t:1528139576254};\\\", \\\"{x:1311,y:909,t:1528139576271};\\\", \\\"{x:1321,y:894,t:1528139576288};\\\", \\\"{x:1327,y:883,t:1528139576304};\\\", \\\"{x:1334,y:871,t:1528139576322};\\\", \\\"{x:1341,y:861,t:1528139576338};\\\", \\\"{x:1347,y:850,t:1528139576355};\\\", \\\"{x:1351,y:842,t:1528139576371};\\\", \\\"{x:1361,y:826,t:1528139576388};\\\", \\\"{x:1368,y:810,t:1528139576405};\\\", \\\"{x:1372,y:795,t:1528139576421};\\\", \\\"{x:1374,y:788,t:1528139576439};\\\", \\\"{x:1376,y:784,t:1528139576455};\\\", \\\"{x:1377,y:782,t:1528139576472};\\\", \\\"{x:1377,y:781,t:1528139576489};\\\", \\\"{x:1380,y:777,t:1528139576504};\\\", \\\"{x:1381,y:772,t:1528139576521};\\\", \\\"{x:1384,y:768,t:1528139576544};\\\", \\\"{x:1385,y:764,t:1528139576554};\\\", \\\"{x:1387,y:763,t:1528139576570};\\\", \\\"{x:1388,y:762,t:1528139576588};\\\", \\\"{x:1388,y:761,t:1528139576628};\\\", \\\"{x:1389,y:760,t:1528139576645};\\\", \\\"{x:1389,y:759,t:1528139576668};\\\", \\\"{x:1387,y:759,t:1528139576934};\\\", \\\"{x:1386,y:759,t:1528139577060};\\\", \\\"{x:1384,y:759,t:1528139577073};\\\", \\\"{x:1382,y:759,t:1528139577088};\\\", \\\"{x:1381,y:759,t:1528139577105};\\\", \\\"{x:1380,y:759,t:1528139577121};\\\", \\\"{x:1380,y:760,t:1528139577139};\\\", \\\"{x:1379,y:760,t:1528139577172};\\\", \\\"{x:1376,y:761,t:1528139577188};\\\", \\\"{x:1376,y:762,t:1528139577302};\\\", \\\"{x:1377,y:761,t:1528139579582};\\\", \\\"{x:1381,y:756,t:1528139579593};\\\", \\\"{x:1387,y:746,t:1528139579607};\\\", \\\"{x:1394,y:736,t:1528139579624};\\\", \\\"{x:1398,y:732,t:1528139579641};\\\", \\\"{x:1401,y:726,t:1528139579656};\\\", \\\"{x:1404,y:721,t:1528139579674};\\\", \\\"{x:1406,y:714,t:1528139579691};\\\", \\\"{x:1410,y:706,t:1528139579707};\\\", \\\"{x:1413,y:699,t:1528139579724};\\\", \\\"{x:1421,y:686,t:1528139579740};\\\", \\\"{x:1426,y:677,t:1528139579757};\\\", \\\"{x:1431,y:667,t:1528139579774};\\\", \\\"{x:1434,y:661,t:1528139579791};\\\", \\\"{x:1436,y:658,t:1528139579807};\\\", \\\"{x:1438,y:653,t:1528139579824};\\\", \\\"{x:1442,y:646,t:1528139579841};\\\", \\\"{x:1447,y:632,t:1528139579858};\\\", \\\"{x:1454,y:618,t:1528139579874};\\\", \\\"{x:1460,y:603,t:1528139579891};\\\", \\\"{x:1464,y:596,t:1528139579908};\\\", \\\"{x:1469,y:589,t:1528139579924};\\\", \\\"{x:1474,y:577,t:1528139579942};\\\", \\\"{x:1477,y:564,t:1528139579958};\\\", \\\"{x:1483,y:548,t:1528139579974};\\\", \\\"{x:1490,y:532,t:1528139579991};\\\", \\\"{x:1495,y:521,t:1528139580008};\\\", \\\"{x:1500,y:513,t:1528139580025};\\\", \\\"{x:1503,y:507,t:1528139580042};\\\", \\\"{x:1508,y:497,t:1528139580058};\\\", \\\"{x:1512,y:487,t:1528139580075};\\\", \\\"{x:1521,y:474,t:1528139580092};\\\", \\\"{x:1532,y:461,t:1528139580108};\\\", \\\"{x:1544,y:449,t:1528139580125};\\\", \\\"{x:1565,y:430,t:1528139580141};\\\", \\\"{x:1576,y:417,t:1528139580159};\\\", \\\"{x:1584,y:406,t:1528139580174};\\\", \\\"{x:1589,y:400,t:1528139580191};\\\", \\\"{x:1590,y:397,t:1528139580209};\\\", \\\"{x:1592,y:394,t:1528139580224};\\\", \\\"{x:1594,y:393,t:1528139580241};\\\", \\\"{x:1597,y:387,t:1528139580258};\\\", \\\"{x:1599,y:381,t:1528139580275};\\\", \\\"{x:1600,y:378,t:1528139580291};\\\", \\\"{x:1601,y:375,t:1528139580309};\\\", \\\"{x:1602,y:374,t:1528139580325};\\\", \\\"{x:1602,y:373,t:1528139580342};\\\", \\\"{x:1600,y:376,t:1528139580598};\\\", \\\"{x:1599,y:377,t:1528139580609};\\\", \\\"{x:1597,y:382,t:1528139580626};\\\", \\\"{x:1594,y:385,t:1528139580642};\\\", \\\"{x:1587,y:391,t:1528139580659};\\\", \\\"{x:1577,y:404,t:1528139580675};\\\", \\\"{x:1555,y:431,t:1528139580692};\\\", \\\"{x:1536,y:455,t:1528139580709};\\\", \\\"{x:1518,y:475,t:1528139580725};\\\", \\\"{x:1510,y:485,t:1528139580742};\\\", \\\"{x:1501,y:499,t:1528139580758};\\\", \\\"{x:1490,y:511,t:1528139580776};\\\", \\\"{x:1473,y:529,t:1528139580793};\\\", \\\"{x:1462,y:544,t:1528139580808};\\\", \\\"{x:1448,y:562,t:1528139580825};\\\", \\\"{x:1437,y:578,t:1528139580843};\\\", \\\"{x:1427,y:593,t:1528139580859};\\\", \\\"{x:1419,y:607,t:1528139580876};\\\", \\\"{x:1411,y:626,t:1528139580893};\\\", \\\"{x:1403,y:643,t:1528139580909};\\\", \\\"{x:1387,y:674,t:1528139580925};\\\", \\\"{x:1379,y:696,t:1528139580943};\\\", \\\"{x:1371,y:714,t:1528139580959};\\\", \\\"{x:1360,y:736,t:1528139580976};\\\", \\\"{x:1353,y:755,t:1528139580993};\\\", \\\"{x:1344,y:774,t:1528139581008};\\\", \\\"{x:1338,y:789,t:1528139581026};\\\", \\\"{x:1331,y:803,t:1528139581043};\\\", \\\"{x:1325,y:819,t:1528139581059};\\\", \\\"{x:1321,y:830,t:1528139581076};\\\", \\\"{x:1317,y:842,t:1528139581093};\\\", \\\"{x:1312,y:852,t:1528139581108};\\\", \\\"{x:1308,y:867,t:1528139581125};\\\", \\\"{x:1304,y:876,t:1528139581142};\\\", \\\"{x:1301,y:883,t:1528139581158};\\\", \\\"{x:1299,y:891,t:1528139581175};\\\", \\\"{x:1292,y:906,t:1528139581192};\\\", \\\"{x:1287,y:919,t:1528139581208};\\\", \\\"{x:1281,y:935,t:1528139581224};\\\", \\\"{x:1276,y:945,t:1528139581242};\\\", \\\"{x:1273,y:952,t:1528139581258};\\\", \\\"{x:1271,y:955,t:1528139581275};\\\", \\\"{x:1271,y:956,t:1528139581292};\\\", \\\"{x:1270,y:959,t:1528139581309};\\\", \\\"{x:1269,y:960,t:1528139581325};\\\", \\\"{x:1269,y:962,t:1528139581343};\\\", \\\"{x:1269,y:963,t:1528139581359};\\\", \\\"{x:1269,y:958,t:1528139581494};\\\", \\\"{x:1269,y:954,t:1528139581510};\\\", \\\"{x:1269,y:949,t:1528139581526};\\\", \\\"{x:1269,y:946,t:1528139581543};\\\", \\\"{x:1269,y:942,t:1528139581560};\\\", \\\"{x:1269,y:938,t:1528139581576};\\\", \\\"{x:1269,y:934,t:1528139581593};\\\", \\\"{x:1269,y:930,t:1528139581609};\\\", \\\"{x:1269,y:923,t:1528139581625};\\\", \\\"{x:1269,y:914,t:1528139581642};\\\", \\\"{x:1269,y:903,t:1528139581659};\\\", \\\"{x:1269,y:895,t:1528139581675};\\\", \\\"{x:1269,y:886,t:1528139581692};\\\", \\\"{x:1269,y:875,t:1528139581708};\\\", \\\"{x:1269,y:869,t:1528139581725};\\\", \\\"{x:1269,y:865,t:1528139581742};\\\", \\\"{x:1269,y:862,t:1528139581759};\\\", \\\"{x:1269,y:858,t:1528139581776};\\\", \\\"{x:1269,y:852,t:1528139581792};\\\", \\\"{x:1269,y:849,t:1528139581810};\\\", \\\"{x:1269,y:843,t:1528139581827};\\\", \\\"{x:1269,y:838,t:1528139581842};\\\", \\\"{x:1270,y:836,t:1528139581859};\\\", \\\"{x:1270,y:835,t:1528139581876};\\\", \\\"{x:1270,y:834,t:1528139581917};\\\", \\\"{x:1272,y:833,t:1528139581934};\\\", \\\"{x:1273,y:832,t:1528139581943};\\\", \\\"{x:1275,y:829,t:1528139581960};\\\", \\\"{x:1277,y:827,t:1528139581981};\\\", \\\"{x:1278,y:826,t:1528139582044};\\\", \\\"{x:1279,y:825,t:1528139582060};\\\", \\\"{x:1279,y:824,t:1528139582077};\\\", \\\"{x:1280,y:824,t:1528139582165};\\\", \\\"{x:1281,y:824,t:1528139582421};\\\", \\\"{x:1281,y:825,t:1528139582442};\\\", \\\"{x:1281,y:826,t:1528139582459};\\\", \\\"{x:1280,y:827,t:1528139582476};\\\", \\\"{x:1279,y:828,t:1528139583684};\\\", \\\"{x:1263,y:834,t:1528139583695};\\\", \\\"{x:1157,y:854,t:1528139583711};\\\", \\\"{x:1041,y:866,t:1528139583726};\\\", \\\"{x:903,y:883,t:1528139583744};\\\", \\\"{x:742,y:888,t:1528139583761};\\\", \\\"{x:620,y:884,t:1528139583777};\\\", \\\"{x:554,y:880,t:1528139583794};\\\", \\\"{x:521,y:868,t:1528139583811};\\\", \\\"{x:505,y:862,t:1528139583827};\\\", \\\"{x:499,y:858,t:1528139583844};\\\", \\\"{x:498,y:857,t:1528139583861};\\\", \\\"{x:496,y:854,t:1528139583877};\\\", \\\"{x:495,y:847,t:1528139583894};\\\", \\\"{x:495,y:818,t:1528139583911};\\\", \\\"{x:498,y:791,t:1528139583927};\\\", \\\"{x:499,y:777,t:1528139583944};\\\", \\\"{x:502,y:768,t:1528139583962};\\\", \\\"{x:507,y:758,t:1528139583977};\\\", \\\"{x:513,y:752,t:1528139583993};\\\", \\\"{x:517,y:748,t:1528139584010};\\\", \\\"{x:520,y:745,t:1528139584028};\\\", \\\"{x:521,y:743,t:1528139584044};\\\", \\\"{x:522,y:742,t:1528139584060};\\\", \\\"{x:522,y:743,t:1528139584133};\\\", \\\"{x:523,y:744,t:1528139584757};\\\", \\\"{x:525,y:744,t:1528139584765};\\\", \\\"{x:527,y:744,t:1528139584778};\\\" ] }, { \\\"rt\\\": 10523, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 338481, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:743,t:1528139585596};\\\", \\\"{x:527,y:742,t:1528139585628};\\\", \\\"{x:526,y:741,t:1528139585645};\\\", \\\"{x:526,y:740,t:1528139585661};\\\", \\\"{x:526,y:739,t:1528139585688};\\\", \\\"{x:526,y:738,t:1528139585694};\\\", \\\"{x:526,y:736,t:1528139585712};\\\", \\\"{x:526,y:735,t:1528139585813};\\\", \\\"{x:526,y:734,t:1528139585829};\\\", \\\"{x:526,y:733,t:1528139585846};\\\", \\\"{x:525,y:733,t:1528139585869};\\\", \\\"{x:525,y:732,t:1528139585957};\\\", \\\"{x:525,y:731,t:1528139586132};\\\", \\\"{x:525,y:730,t:1528139586373};\\\", \\\"{x:528,y:722,t:1528139586381};\\\", \\\"{x:534,y:698,t:1528139586397};\\\", \\\"{x:538,y:667,t:1528139586415};\\\", \\\"{x:539,y:627,t:1528139586430};\\\", \\\"{x:543,y:589,t:1528139586447};\\\", \\\"{x:552,y:555,t:1528139586463};\\\", \\\"{x:558,y:526,t:1528139586479};\\\", \\\"{x:563,y:504,t:1528139586496};\\\", \\\"{x:563,y:490,t:1528139586513};\\\", \\\"{x:563,y:477,t:1528139586530};\\\", \\\"{x:563,y:467,t:1528139586545};\\\", \\\"{x:562,y:459,t:1528139586563};\\\", \\\"{x:560,y:454,t:1528139586580};\\\", \\\"{x:560,y:453,t:1528139586612};\\\", \\\"{x:559,y:452,t:1528139586645};\\\", \\\"{x:558,y:450,t:1528139586652};\\\", \\\"{x:557,y:445,t:1528139586663};\\\", \\\"{x:547,y:430,t:1528139586680};\\\", \\\"{x:533,y:414,t:1528139586696};\\\", \\\"{x:523,y:408,t:1528139586713};\\\", \\\"{x:514,y:404,t:1528139586731};\\\", \\\"{x:510,y:403,t:1528139586748};\\\", \\\"{x:506,y:402,t:1528139586764};\\\", \\\"{x:505,y:402,t:1528139587021};\\\", \\\"{x:504,y:402,t:1528139587031};\\\", \\\"{x:503,y:402,t:1528139587053};\\\", \\\"{x:502,y:403,t:1528139587069};\\\", \\\"{x:502,y:404,t:1528139587081};\\\", \\\"{x:500,y:404,t:1528139587097};\\\", \\\"{x:500,y:405,t:1528139587114};\\\", \\\"{x:497,y:408,t:1528139587132};\\\", \\\"{x:496,y:409,t:1528139587147};\\\", \\\"{x:494,y:411,t:1528139587165};\\\", \\\"{x:493,y:412,t:1528139587181};\\\", \\\"{x:492,y:414,t:1528139587198};\\\", \\\"{x:490,y:417,t:1528139587215};\\\", \\\"{x:490,y:418,t:1528139587231};\\\", \\\"{x:489,y:421,t:1528139587247};\\\", \\\"{x:488,y:424,t:1528139587265};\\\", \\\"{x:488,y:425,t:1528139587282};\\\", \\\"{x:486,y:429,t:1528139587298};\\\", \\\"{x:485,y:433,t:1528139587315};\\\", \\\"{x:482,y:438,t:1528139587332};\\\", \\\"{x:479,y:442,t:1528139587349};\\\", \\\"{x:477,y:446,t:1528139587365};\\\", \\\"{x:475,y:450,t:1528139587381};\\\", \\\"{x:473,y:458,t:1528139587399};\\\", \\\"{x:471,y:466,t:1528139587415};\\\", \\\"{x:470,y:470,t:1528139587432};\\\", \\\"{x:470,y:474,t:1528139587448};\\\", \\\"{x:470,y:480,t:1528139587466};\\\", \\\"{x:470,y:485,t:1528139587482};\\\", \\\"{x:470,y:490,t:1528139587499};\\\", \\\"{x:470,y:496,t:1528139587516};\\\", \\\"{x:470,y:502,t:1528139587531};\\\", \\\"{x:471,y:510,t:1528139587549};\\\", \\\"{x:472,y:513,t:1528139587565};\\\", \\\"{x:472,y:514,t:1528139587582};\\\", \\\"{x:479,y:521,t:1528139588412};\\\", \\\"{x:512,y:537,t:1528139588421};\\\", \\\"{x:566,y:557,t:1528139588434};\\\", \\\"{x:690,y:593,t:1528139588451};\\\", \\\"{x:832,y:637,t:1528139588465};\\\", \\\"{x:958,y:668,t:1528139588481};\\\", \\\"{x:1086,y:711,t:1528139588498};\\\", \\\"{x:1213,y:760,t:1528139588514};\\\", \\\"{x:1313,y:816,t:1528139588531};\\\", \\\"{x:1399,y:901,t:1528139588548};\\\", \\\"{x:1430,y:948,t:1528139588564};\\\", \\\"{x:1447,y:980,t:1528139588582};\\\", \\\"{x:1469,y:1015,t:1528139588598};\\\", \\\"{x:1492,y:1042,t:1528139588614};\\\", \\\"{x:1519,y:1061,t:1528139588632};\\\", \\\"{x:1521,y:1062,t:1528139588647};\\\", \\\"{x:1521,y:1063,t:1528139588989};\\\", \\\"{x:1519,y:1063,t:1528139588998};\\\", \\\"{x:1515,y:1062,t:1528139589015};\\\", \\\"{x:1511,y:1060,t:1528139589032};\\\", \\\"{x:1510,y:1059,t:1528139589047};\\\", \\\"{x:1510,y:1058,t:1528139589077};\\\", \\\"{x:1509,y:1057,t:1528139589085};\\\", \\\"{x:1508,y:1056,t:1528139589181};\\\", \\\"{x:1518,y:1042,t:1528139590495};\\\", \\\"{x:1546,y:1021,t:1528139590502};\\\", \\\"{x:1578,y:991,t:1528139590514};\\\", \\\"{x:1659,y:880,t:1528139590531};\\\", \\\"{x:1703,y:765,t:1528139590547};\\\", \\\"{x:1745,y:620,t:1528139590565};\\\", \\\"{x:1753,y:591,t:1528139590581};\\\", \\\"{x:1756,y:577,t:1528139590598};\\\", \\\"{x:1756,y:567,t:1528139590615};\\\", \\\"{x:1748,y:554,t:1528139590631};\\\", \\\"{x:1732,y:543,t:1528139590648};\\\", \\\"{x:1705,y:543,t:1528139590665};\\\", \\\"{x:1676,y:543,t:1528139590681};\\\", \\\"{x:1664,y:542,t:1528139590698};\\\", \\\"{x:1662,y:540,t:1528139590715};\\\", \\\"{x:1659,y:538,t:1528139590731};\\\", \\\"{x:1655,y:535,t:1528139590748};\\\", \\\"{x:1650,y:535,t:1528139590765};\\\", \\\"{x:1647,y:533,t:1528139590781};\\\", \\\"{x:1642,y:522,t:1528139590798};\\\", \\\"{x:1637,y:503,t:1528139590815};\\\", \\\"{x:1630,y:484,t:1528139590831};\\\", \\\"{x:1626,y:473,t:1528139590847};\\\", \\\"{x:1623,y:464,t:1528139590864};\\\", \\\"{x:1622,y:450,t:1528139590881};\\\", \\\"{x:1621,y:436,t:1528139590898};\\\", \\\"{x:1618,y:428,t:1528139590924};\\\", \\\"{x:1618,y:426,t:1528139590930};\\\", \\\"{x:1618,y:425,t:1528139590948};\\\", \\\"{x:1618,y:424,t:1528139591054};\\\", \\\"{x:1618,y:423,t:1528139591157};\\\", \\\"{x:1617,y:423,t:1528139591181};\\\", \\\"{x:1616,y:423,t:1528139591557};\\\", \\\"{x:1615,y:423,t:1528139591596};\\\", \\\"{x:1614,y:424,t:1528139591613};\\\", \\\"{x:1613,y:425,t:1528139591754};\\\", \\\"{x:1613,y:426,t:1528139591812};\\\", \\\"{x:1613,y:428,t:1528139591820};\\\", \\\"{x:1613,y:429,t:1528139591917};\\\", \\\"{x:1611,y:430,t:1528139594388};\\\", \\\"{x:1598,y:430,t:1528139594403};\\\", \\\"{x:1542,y:430,t:1528139594419};\\\", \\\"{x:1380,y:421,t:1528139594436};\\\", \\\"{x:1220,y:408,t:1528139594452};\\\", \\\"{x:1050,y:390,t:1528139594470};\\\", \\\"{x:877,y:379,t:1528139594486};\\\", \\\"{x:700,y:379,t:1528139594502};\\\", \\\"{x:534,y:379,t:1528139594520};\\\", \\\"{x:361,y:394,t:1528139594537};\\\", \\\"{x:241,y:416,t:1528139594553};\\\", \\\"{x:157,y:443,t:1528139594569};\\\", \\\"{x:120,y:461,t:1528139594587};\\\", \\\"{x:104,y:475,t:1528139594603};\\\", \\\"{x:95,y:497,t:1528139594619};\\\", \\\"{x:90,y:539,t:1528139594636};\\\", \\\"{x:90,y:555,t:1528139594652};\\\", \\\"{x:94,y:572,t:1528139594670};\\\", \\\"{x:101,y:591,t:1528139594688};\\\", \\\"{x:109,y:608,t:1528139594702};\\\", \\\"{x:126,y:630,t:1528139594720};\\\", \\\"{x:167,y:665,t:1528139594737};\\\", \\\"{x:203,y:686,t:1528139594752};\\\", \\\"{x:229,y:698,t:1528139594769};\\\", \\\"{x:240,y:701,t:1528139594786};\\\", \\\"{x:241,y:701,t:1528139594803};\\\", \\\"{x:245,y:701,t:1528139594819};\\\", \\\"{x:253,y:693,t:1528139594836};\\\", \\\"{x:264,y:682,t:1528139594854};\\\", \\\"{x:278,y:675,t:1528139594869};\\\", \\\"{x:290,y:668,t:1528139594886};\\\", \\\"{x:300,y:663,t:1528139594902};\\\", \\\"{x:308,y:656,t:1528139594919};\\\", \\\"{x:317,y:650,t:1528139594937};\\\", \\\"{x:323,y:644,t:1528139594953};\\\", \\\"{x:330,y:638,t:1528139594969};\\\", \\\"{x:338,y:634,t:1528139594986};\\\", \\\"{x:345,y:631,t:1528139595003};\\\", \\\"{x:348,y:628,t:1528139595019};\\\", \\\"{x:349,y:628,t:1528139595036};\\\", \\\"{x:350,y:628,t:1528139595067};\\\", \\\"{x:352,y:628,t:1528139595108};\\\", \\\"{x:353,y:628,t:1528139595119};\\\", \\\"{x:356,y:629,t:1528139595136};\\\", \\\"{x:361,y:630,t:1528139595153};\\\", \\\"{x:366,y:630,t:1528139595169};\\\", \\\"{x:370,y:631,t:1528139595186};\\\", \\\"{x:373,y:634,t:1528139595203};\\\", \\\"{x:375,y:637,t:1528139595219};\\\", \\\"{x:377,y:639,t:1528139595236};\\\", \\\"{x:378,y:639,t:1528139595253};\\\", \\\"{x:382,y:639,t:1528139595269};\\\", \\\"{x:385,y:637,t:1528139595286};\\\", \\\"{x:386,y:636,t:1528139595303};\\\", \\\"{x:391,y:642,t:1528139595532};\\\", \\\"{x:395,y:647,t:1528139595540};\\\", \\\"{x:400,y:654,t:1528139595554};\\\", \\\"{x:406,y:664,t:1528139595571};\\\", \\\"{x:415,y:678,t:1528139595587};\\\", \\\"{x:426,y:689,t:1528139595604};\\\", \\\"{x:436,y:705,t:1528139595620};\\\", \\\"{x:442,y:713,t:1528139595636};\\\", \\\"{x:444,y:718,t:1528139595653};\\\", \\\"{x:447,y:723,t:1528139595671};\\\", \\\"{x:448,y:724,t:1528139595686};\\\", \\\"{x:449,y:725,t:1528139595704};\\\", \\\"{x:450,y:725,t:1528139595732};\\\", \\\"{x:451,y:727,t:1528139595740};\\\", \\\"{x:452,y:727,t:1528139595753};\\\", \\\"{x:454,y:729,t:1528139595770};\\\", \\\"{x:456,y:729,t:1528139595787};\\\", \\\"{x:461,y:729,t:1528139595804};\\\", \\\"{x:463,y:727,t:1528139595820};\\\", \\\"{x:465,y:728,t:1528139595860};\\\", \\\"{x:466,y:731,t:1528139595871};\\\", \\\"{x:468,y:737,t:1528139595888};\\\", \\\"{x:469,y:743,t:1528139595904};\\\", \\\"{x:471,y:750,t:1528139595921};\\\", \\\"{x:471,y:756,t:1528139595936};\\\", \\\"{x:472,y:757,t:1528139595953};\\\", \\\"{x:473,y:757,t:1528139595970};\\\" ] }, { \\\"rt\\\": 12428, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 352108, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -Z -F -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:472,y:757,t:1528139597340};\\\", \\\"{x:472,y:756,t:1528139597980};\\\", \\\"{x:472,y:750,t:1528139597990};\\\", \\\"{x:472,y:748,t:1528139598006};\\\", \\\"{x:472,y:747,t:1528139598428};\\\", \\\"{x:471,y:740,t:1528139598441};\\\", \\\"{x:468,y:719,t:1528139598458};\\\", \\\"{x:465,y:702,t:1528139598474};\\\", \\\"{x:463,y:684,t:1528139598492};\\\", \\\"{x:462,y:669,t:1528139598505};\\\", \\\"{x:460,y:655,t:1528139598522};\\\", \\\"{x:457,y:641,t:1528139598539};\\\", \\\"{x:453,y:629,t:1528139598556};\\\", \\\"{x:451,y:617,t:1528139598572};\\\", \\\"{x:451,y:608,t:1528139598590};\\\", \\\"{x:451,y:603,t:1528139598605};\\\", \\\"{x:452,y:598,t:1528139598622};\\\", \\\"{x:457,y:592,t:1528139598640};\\\", \\\"{x:461,y:584,t:1528139598655};\\\", \\\"{x:466,y:577,t:1528139598673};\\\", \\\"{x:472,y:567,t:1528139598690};\\\", \\\"{x:475,y:562,t:1528139598705};\\\", \\\"{x:479,y:557,t:1528139598722};\\\", \\\"{x:482,y:554,t:1528139598739};\\\", \\\"{x:487,y:551,t:1528139598756};\\\", \\\"{x:492,y:549,t:1528139598772};\\\", \\\"{x:495,y:546,t:1528139598789};\\\", \\\"{x:497,y:543,t:1528139598805};\\\", \\\"{x:499,y:542,t:1528139598823};\\\", \\\"{x:499,y:541,t:1528139598839};\\\", \\\"{x:502,y:538,t:1528139599068};\\\", \\\"{x:505,y:534,t:1528139599076};\\\", \\\"{x:510,y:529,t:1528139599090};\\\", \\\"{x:521,y:519,t:1528139599106};\\\", \\\"{x:532,y:505,t:1528139599122};\\\", \\\"{x:546,y:499,t:1528139599140};\\\", \\\"{x:555,y:494,t:1528139599156};\\\", \\\"{x:557,y:494,t:1528139599173};\\\", \\\"{x:558,y:494,t:1528139599292};\\\", \\\"{x:559,y:494,t:1528139599324};\\\", \\\"{x:560,y:494,t:1528139599356};\\\", \\\"{x:561,y:494,t:1528139599380};\\\", \\\"{x:562,y:494,t:1528139599396};\\\", \\\"{x:564,y:494,t:1528139599406};\\\", \\\"{x:573,y:494,t:1528139599424};\\\", \\\"{x:592,y:494,t:1528139599439};\\\", \\\"{x:618,y:494,t:1528139599456};\\\", \\\"{x:658,y:498,t:1528139599474};\\\", \\\"{x:736,y:507,t:1528139599489};\\\", \\\"{x:833,y:519,t:1528139599507};\\\", \\\"{x:949,y:537,t:1528139599523};\\\", \\\"{x:1088,y:556,t:1528139599539};\\\", \\\"{x:1330,y:589,t:1528139599556};\\\", \\\"{x:1466,y:611,t:1528139599574};\\\", \\\"{x:1563,y:624,t:1528139599589};\\\", \\\"{x:1638,y:633,t:1528139599607};\\\", \\\"{x:1699,y:642,t:1528139599624};\\\", \\\"{x:1729,y:646,t:1528139599639};\\\", \\\"{x:1730,y:646,t:1528139599940};\\\", \\\"{x:1732,y:646,t:1528139599956};\\\", \\\"{x:1730,y:647,t:1528139600020};\\\", \\\"{x:1724,y:649,t:1528139600028};\\\", \\\"{x:1719,y:651,t:1528139600041};\\\", \\\"{x:1682,y:659,t:1528139600056};\\\", \\\"{x:1614,y:671,t:1528139600073};\\\", \\\"{x:1528,y:671,t:1528139600091};\\\", \\\"{x:1445,y:671,t:1528139600107};\\\", \\\"{x:1367,y:671,t:1528139600124};\\\", \\\"{x:1283,y:671,t:1528139600141};\\\", \\\"{x:1254,y:671,t:1528139600158};\\\", \\\"{x:1247,y:671,t:1528139600174};\\\", \\\"{x:1245,y:672,t:1528139600190};\\\", \\\"{x:1245,y:673,t:1528139600228};\\\", \\\"{x:1245,y:674,t:1528139600241};\\\", \\\"{x:1245,y:675,t:1528139600257};\\\", \\\"{x:1245,y:680,t:1528139600274};\\\", \\\"{x:1245,y:683,t:1528139600290};\\\", \\\"{x:1246,y:690,t:1528139600308};\\\", \\\"{x:1249,y:698,t:1528139600324};\\\", \\\"{x:1255,y:714,t:1528139600341};\\\", \\\"{x:1262,y:732,t:1528139600358};\\\", \\\"{x:1270,y:751,t:1528139600373};\\\", \\\"{x:1281,y:779,t:1528139600391};\\\", \\\"{x:1290,y:800,t:1528139600408};\\\", \\\"{x:1294,y:812,t:1528139600423};\\\", \\\"{x:1297,y:818,t:1528139600441};\\\", \\\"{x:1297,y:823,t:1528139600457};\\\", \\\"{x:1298,y:832,t:1528139600474};\\\", \\\"{x:1303,y:847,t:1528139600491};\\\", \\\"{x:1307,y:861,t:1528139600508};\\\", \\\"{x:1313,y:876,t:1528139600524};\\\", \\\"{x:1314,y:882,t:1528139600540};\\\", \\\"{x:1316,y:885,t:1528139600558};\\\", \\\"{x:1316,y:890,t:1528139600574};\\\", \\\"{x:1316,y:896,t:1528139600590};\\\", \\\"{x:1316,y:899,t:1528139600607};\\\", \\\"{x:1316,y:903,t:1528139600624};\\\", \\\"{x:1316,y:904,t:1528139600677};\\\", \\\"{x:1312,y:906,t:1528139600692};\\\", \\\"{x:1310,y:907,t:1528139600708};\\\", \\\"{x:1305,y:909,t:1528139600724};\\\", \\\"{x:1303,y:910,t:1528139600741};\\\", \\\"{x:1302,y:910,t:1528139600764};\\\", \\\"{x:1300,y:910,t:1528139600780};\\\", \\\"{x:1299,y:910,t:1528139600790};\\\", \\\"{x:1291,y:904,t:1528139600808};\\\", \\\"{x:1280,y:895,t:1528139600825};\\\", \\\"{x:1268,y:884,t:1528139600840};\\\", \\\"{x:1258,y:875,t:1528139600858};\\\", \\\"{x:1249,y:869,t:1528139600875};\\\", \\\"{x:1244,y:864,t:1528139600890};\\\", \\\"{x:1239,y:856,t:1528139600908};\\\", \\\"{x:1229,y:843,t:1528139600924};\\\", \\\"{x:1221,y:838,t:1528139600941};\\\", \\\"{x:1215,y:835,t:1528139600965};\\\", \\\"{x:1206,y:833,t:1528139600976};\\\", \\\"{x:1203,y:831,t:1528139601007};\\\", \\\"{x:1201,y:830,t:1528139601036};\\\", \\\"{x:1200,y:830,t:1528139601076};\\\", \\\"{x:1199,y:830,t:1528139601092};\\\", \\\"{x:1200,y:830,t:1528139601204};\\\", \\\"{x:1202,y:830,t:1528139601212};\\\", \\\"{x:1203,y:830,t:1528139601236};\\\", \\\"{x:1204,y:830,t:1528139601244};\\\", \\\"{x:1205,y:830,t:1528139601268};\\\", \\\"{x:1206,y:830,t:1528139601316};\\\", \\\"{x:1207,y:830,t:1528139601348};\\\", \\\"{x:1208,y:829,t:1528139601372};\\\", \\\"{x:1209,y:829,t:1528139601413};\\\", \\\"{x:1211,y:828,t:1528139601452};\\\", \\\"{x:1212,y:828,t:1528139601540};\\\", \\\"{x:1213,y:828,t:1528139601604};\\\", \\\"{x:1214,y:828,t:1528139602028};\\\", \\\"{x:1214,y:829,t:1528139602044};\\\", \\\"{x:1215,y:831,t:1528139602057};\\\", \\\"{x:1215,y:832,t:1528139602072};\\\", \\\"{x:1216,y:834,t:1528139602089};\\\", \\\"{x:1218,y:836,t:1528139602108};\\\", \\\"{x:1218,y:837,t:1528139602123};\\\", \\\"{x:1218,y:840,t:1528139602142};\\\", \\\"{x:1219,y:844,t:1528139602159};\\\", \\\"{x:1222,y:853,t:1528139602175};\\\", \\\"{x:1226,y:864,t:1528139602192};\\\", \\\"{x:1229,y:881,t:1528139602209};\\\", \\\"{x:1234,y:897,t:1528139602225};\\\", \\\"{x:1242,y:913,t:1528139602241};\\\", \\\"{x:1248,y:923,t:1528139602259};\\\", \\\"{x:1250,y:930,t:1528139602276};\\\", \\\"{x:1252,y:934,t:1528139602291};\\\", \\\"{x:1253,y:936,t:1528139602309};\\\", \\\"{x:1253,y:939,t:1528139602326};\\\", \\\"{x:1253,y:940,t:1528139602342};\\\", \\\"{x:1253,y:941,t:1528139602359};\\\", \\\"{x:1253,y:943,t:1528139602376};\\\", \\\"{x:1255,y:948,t:1528139602393};\\\", \\\"{x:1255,y:949,t:1528139602409};\\\", \\\"{x:1256,y:950,t:1528139602426};\\\", \\\"{x:1258,y:951,t:1528139602459};\\\", \\\"{x:1261,y:956,t:1528139602475};\\\", \\\"{x:1263,y:959,t:1528139602492};\\\", \\\"{x:1266,y:961,t:1528139602509};\\\", \\\"{x:1267,y:962,t:1528139602532};\\\", \\\"{x:1269,y:962,t:1528139602548};\\\", \\\"{x:1271,y:962,t:1528139602558};\\\", \\\"{x:1279,y:957,t:1528139602576};\\\", \\\"{x:1295,y:944,t:1528139602593};\\\", \\\"{x:1316,y:925,t:1528139602609};\\\", \\\"{x:1332,y:900,t:1528139602626};\\\", \\\"{x:1347,y:878,t:1528139602643};\\\", \\\"{x:1363,y:860,t:1528139602659};\\\", \\\"{x:1379,y:845,t:1528139602676};\\\", \\\"{x:1390,y:834,t:1528139602693};\\\", \\\"{x:1396,y:823,t:1528139602709};\\\", \\\"{x:1404,y:811,t:1528139602726};\\\", \\\"{x:1405,y:807,t:1528139602743};\\\", \\\"{x:1407,y:804,t:1528139602759};\\\", \\\"{x:1408,y:804,t:1528139602775};\\\", \\\"{x:1408,y:802,t:1528139602792};\\\", \\\"{x:1410,y:799,t:1528139602810};\\\", \\\"{x:1410,y:798,t:1528139602825};\\\", \\\"{x:1410,y:796,t:1528139602843};\\\", \\\"{x:1410,y:794,t:1528139602859};\\\", \\\"{x:1410,y:793,t:1528139602875};\\\", \\\"{x:1410,y:789,t:1528139602893};\\\", \\\"{x:1408,y:787,t:1528139602910};\\\", \\\"{x:1406,y:786,t:1528139602926};\\\", \\\"{x:1406,y:784,t:1528139602943};\\\", \\\"{x:1405,y:781,t:1528139602960};\\\", \\\"{x:1404,y:778,t:1528139602976};\\\", \\\"{x:1403,y:777,t:1528139602993};\\\", \\\"{x:1402,y:776,t:1528139603010};\\\", \\\"{x:1401,y:775,t:1528139603025};\\\", \\\"{x:1398,y:773,t:1528139603042};\\\", \\\"{x:1396,y:772,t:1528139603060};\\\", \\\"{x:1396,y:771,t:1528139603076};\\\", \\\"{x:1395,y:771,t:1528139603092};\\\", \\\"{x:1393,y:770,t:1528139603110};\\\", \\\"{x:1392,y:769,t:1528139603126};\\\", \\\"{x:1391,y:768,t:1528139603143};\\\", \\\"{x:1389,y:768,t:1528139603160};\\\", \\\"{x:1388,y:768,t:1528139603176};\\\", \\\"{x:1385,y:768,t:1528139603193};\\\", \\\"{x:1384,y:767,t:1528139603212};\\\", \\\"{x:1383,y:766,t:1528139603227};\\\", \\\"{x:1382,y:766,t:1528139603242};\\\", \\\"{x:1381,y:765,t:1528139603260};\\\", \\\"{x:1371,y:765,t:1528139605336};\\\", \\\"{x:1345,y:775,t:1528139605345};\\\", \\\"{x:1237,y:785,t:1528139605362};\\\", \\\"{x:1113,y:785,t:1528139605378};\\\", \\\"{x:966,y:785,t:1528139605395};\\\", \\\"{x:811,y:782,t:1528139605411};\\\", \\\"{x:599,y:773,t:1528139605427};\\\", \\\"{x:497,y:763,t:1528139605446};\\\", \\\"{x:412,y:754,t:1528139605463};\\\", \\\"{x:372,y:747,t:1528139605478};\\\", \\\"{x:355,y:745,t:1528139605494};\\\", \\\"{x:353,y:745,t:1528139605512};\\\", \\\"{x:352,y:744,t:1528139605541};\\\", \\\"{x:351,y:744,t:1528139605549};\\\", \\\"{x:349,y:742,t:1528139605562};\\\", \\\"{x:345,y:738,t:1528139605578};\\\", \\\"{x:343,y:731,t:1528139605595};\\\", \\\"{x:343,y:716,t:1528139605613};\\\", \\\"{x:343,y:705,t:1528139605629};\\\", \\\"{x:346,y:696,t:1528139605645};\\\", \\\"{x:352,y:686,t:1528139605664};\\\", \\\"{x:361,y:674,t:1528139605677};\\\", \\\"{x:367,y:664,t:1528139605695};\\\", \\\"{x:368,y:656,t:1528139605712};\\\", \\\"{x:369,y:652,t:1528139605730};\\\", \\\"{x:370,y:647,t:1528139605745};\\\", \\\"{x:370,y:642,t:1528139605762};\\\", \\\"{x:372,y:635,t:1528139605778};\\\", \\\"{x:375,y:627,t:1528139605795};\\\", \\\"{x:379,y:615,t:1528139605813};\\\", \\\"{x:380,y:612,t:1528139605828};\\\", \\\"{x:380,y:610,t:1528139605845};\\\", \\\"{x:380,y:609,t:1528139605925};\\\", \\\"{x:380,y:608,t:1528139605957};\\\", \\\"{x:380,y:607,t:1528139606005};\\\", \\\"{x:380,y:606,t:1528139606014};\\\", \\\"{x:380,y:604,t:1528139606037};\\\", \\\"{x:380,y:607,t:1528139606261};\\\", \\\"{x:385,y:622,t:1528139606278};\\\", \\\"{x:388,y:636,t:1528139606295};\\\", \\\"{x:392,y:649,t:1528139606313};\\\", \\\"{x:399,y:664,t:1528139606329};\\\", \\\"{x:406,y:677,t:1528139606346};\\\", \\\"{x:415,y:690,t:1528139606363};\\\", \\\"{x:423,y:701,t:1528139606379};\\\", \\\"{x:433,y:711,t:1528139606396};\\\", \\\"{x:441,y:718,t:1528139606411};\\\", \\\"{x:453,y:727,t:1528139606429};\\\", \\\"{x:460,y:733,t:1528139606446};\\\", \\\"{x:466,y:736,t:1528139606462};\\\", \\\"{x:472,y:737,t:1528139606480};\\\", \\\"{x:475,y:737,t:1528139606496};\\\", \\\"{x:479,y:737,t:1528139606512};\\\", \\\"{x:484,y:735,t:1528139606530};\\\", \\\"{x:487,y:732,t:1528139606546};\\\", \\\"{x:488,y:732,t:1528139606562};\\\", \\\"{x:488,y:736,t:1528139606644};\\\", \\\"{x:491,y:743,t:1528139606653};\\\", \\\"{x:492,y:746,t:1528139606663};\\\", \\\"{x:495,y:754,t:1528139606679};\\\", \\\"{x:497,y:756,t:1528139606696};\\\", \\\"{x:504,y:756,t:1528139607405};\\\", \\\"{x:514,y:756,t:1528139607413};\\\", \\\"{x:582,y:763,t:1528139607432};\\\", \\\"{x:668,y:763,t:1528139607445};\\\", \\\"{x:757,y:763,t:1528139607462};\\\", \\\"{x:827,y:763,t:1528139607480};\\\", \\\"{x:872,y:763,t:1528139607497};\\\", \\\"{x:900,y:763,t:1528139607513};\\\", \\\"{x:923,y:763,t:1528139607530};\\\", \\\"{x:948,y:760,t:1528139607547};\\\", \\\"{x:966,y:756,t:1528139607563};\\\", \\\"{x:975,y:755,t:1528139607580};\\\", \\\"{x:976,y:754,t:1528139607596};\\\", \\\"{x:980,y:754,t:1528139607613};\\\", \\\"{x:985,y:754,t:1528139607630};\\\", \\\"{x:994,y:754,t:1528139607647};\\\", \\\"{x:1011,y:754,t:1528139607664};\\\", \\\"{x:1028,y:759,t:1528139607681};\\\", \\\"{x:1043,y:767,t:1528139607697};\\\", \\\"{x:1078,y:782,t:1528139607713};\\\", \\\"{x:1135,y:804,t:1528139607731};\\\", \\\"{x:1191,y:829,t:1528139607747};\\\", \\\"{x:1237,y:840,t:1528139607763};\\\", \\\"{x:1288,y:855,t:1528139607781};\\\", \\\"{x:1301,y:859,t:1528139607798};\\\", \\\"{x:1302,y:859,t:1528139607829};\\\", \\\"{x:1302,y:857,t:1528139607965};\\\", \\\"{x:1295,y:853,t:1528139607981};\\\", \\\"{x:1287,y:851,t:1528139607997};\\\", \\\"{x:1279,y:850,t:1528139608015};\\\", \\\"{x:1267,y:850,t:1528139608030};\\\", \\\"{x:1256,y:850,t:1528139608047};\\\", \\\"{x:1245,y:850,t:1528139608064};\\\", \\\"{x:1239,y:850,t:1528139608081};\\\", \\\"{x:1238,y:850,t:1528139608117};\\\", \\\"{x:1237,y:850,t:1528139608141};\\\", \\\"{x:1236,y:849,t:1528139608166};\\\", \\\"{x:1235,y:847,t:1528139608181};\\\", \\\"{x:1233,y:843,t:1528139608198};\\\", \\\"{x:1231,y:839,t:1528139608215};\\\", \\\"{x:1229,y:834,t:1528139608230};\\\", \\\"{x:1227,y:831,t:1528139608248};\\\", \\\"{x:1227,y:830,t:1528139608265};\\\", \\\"{x:1226,y:828,t:1528139608281};\\\", \\\"{x:1225,y:827,t:1528139608325};\\\", \\\"{x:1224,y:826,t:1528139608333};\\\", \\\"{x:1223,y:825,t:1528139608364};\\\", \\\"{x:1222,y:825,t:1528139608388};\\\", \\\"{x:1221,y:825,t:1528139608397};\\\", \\\"{x:1219,y:825,t:1528139608420};\\\", \\\"{x:1218,y:825,t:1528139608433};\\\", \\\"{x:1216,y:825,t:1528139608447};\\\", \\\"{x:1215,y:825,t:1528139608464};\\\", \\\"{x:1214,y:825,t:1528139608481};\\\", \\\"{x:1212,y:826,t:1528139608497};\\\", \\\"{x:1211,y:826,t:1528139608516};\\\", \\\"{x:1209,y:826,t:1528139608688};\\\", \\\"{x:1200,y:826,t:1528139608697};\\\", \\\"{x:1167,y:826,t:1528139608714};\\\", \\\"{x:1092,y:826,t:1528139608731};\\\", \\\"{x:998,y:826,t:1528139608747};\\\", \\\"{x:820,y:826,t:1528139608764};\\\", \\\"{x:704,y:826,t:1528139608781};\\\", \\\"{x:596,y:826,t:1528139608797};\\\", \\\"{x:502,y:826,t:1528139608814};\\\", \\\"{x:437,y:826,t:1528139608831};\\\", \\\"{x:406,y:826,t:1528139608847};\\\", \\\"{x:394,y:828,t:1528139608864};\\\", \\\"{x:392,y:829,t:1528139608881};\\\", \\\"{x:391,y:829,t:1528139608908};\\\", \\\"{x:391,y:830,t:1528139608917};\\\", \\\"{x:391,y:831,t:1528139608957};\\\", \\\"{x:394,y:830,t:1528139608980};\\\", \\\"{x:408,y:821,t:1528139608998};\\\", \\\"{x:425,y:812,t:1528139609015};\\\", \\\"{x:451,y:793,t:1528139609032};\\\", \\\"{x:473,y:780,t:1528139609048};\\\", \\\"{x:495,y:767,t:1528139609066};\\\", \\\"{x:508,y:757,t:1528139609081};\\\", \\\"{x:514,y:754,t:1528139609098};\\\", \\\"{x:517,y:753,t:1528139609114};\\\", \\\"{x:515,y:753,t:1528139610213};\\\", \\\"{x:506,y:750,t:1528139610221};\\\", \\\"{x:503,y:746,t:1528139610232};\\\" ] }, { \\\"rt\\\": 16970, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 370286, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-05 PM-H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:745,t:1528139610999};\\\", \\\"{x:501,y:744,t:1528139611020};\\\", \\\"{x:501,y:742,t:1528139611869};\\\", \\\"{x:504,y:740,t:1528139611884};\\\", \\\"{x:521,y:717,t:1528139611901};\\\", \\\"{x:533,y:692,t:1528139611917};\\\", \\\"{x:545,y:656,t:1528139611934};\\\", \\\"{x:551,y:606,t:1528139611951};\\\", \\\"{x:554,y:551,t:1528139611968};\\\", \\\"{x:551,y:516,t:1528139611983};\\\", \\\"{x:545,y:493,t:1528139612001};\\\", \\\"{x:540,y:480,t:1528139612017};\\\", \\\"{x:536,y:472,t:1528139612033};\\\", \\\"{x:534,y:469,t:1528139612050};\\\", \\\"{x:533,y:468,t:1528139612067};\\\", \\\"{x:532,y:468,t:1528139612085};\\\", \\\"{x:531,y:468,t:1528139612101};\\\", \\\"{x:530,y:468,t:1528139612118};\\\", \\\"{x:529,y:468,t:1528139612135};\\\", \\\"{x:529,y:469,t:1528139616037};\\\", \\\"{x:529,y:470,t:1528139616051};\\\", \\\"{x:529,y:473,t:1528139616067};\\\", \\\"{x:529,y:476,t:1528139616084};\\\", \\\"{x:529,y:479,t:1528139616101};\\\", \\\"{x:529,y:481,t:1528139616118};\\\", \\\"{x:529,y:482,t:1528139616134};\\\", \\\"{x:529,y:484,t:1528139616151};\\\", \\\"{x:529,y:485,t:1528139616168};\\\", \\\"{x:529,y:489,t:1528139616185};\\\", \\\"{x:529,y:491,t:1528139616201};\\\", \\\"{x:529,y:493,t:1528139616218};\\\", \\\"{x:529,y:494,t:1528139616234};\\\", \\\"{x:529,y:498,t:1528139616251};\\\", \\\"{x:529,y:500,t:1528139616268};\\\", \\\"{x:529,y:502,t:1528139616285};\\\", \\\"{x:529,y:503,t:1528139616308};\\\", \\\"{x:529,y:504,t:1528139616318};\\\", \\\"{x:529,y:505,t:1528139616334};\\\", \\\"{x:529,y:508,t:1528139616352};\\\", \\\"{x:529,y:510,t:1528139616369};\\\", \\\"{x:529,y:511,t:1528139616385};\\\", \\\"{x:529,y:513,t:1528139616402};\\\", \\\"{x:529,y:516,t:1528139616419};\\\", \\\"{x:529,y:517,t:1528139616437};\\\", \\\"{x:529,y:518,t:1528139616517};\\\", \\\"{x:529,y:519,t:1528139616548};\\\", \\\"{x:529,y:520,t:1528139616565};\\\", \\\"{x:529,y:522,t:1528139616573};\\\", \\\"{x:529,y:526,t:1528139616586};\\\", \\\"{x:535,y:541,t:1528139616603};\\\", \\\"{x:548,y:561,t:1528139616620};\\\", \\\"{x:572,y:595,t:1528139616636};\\\", \\\"{x:613,y:638,t:1528139616649};\\\", \\\"{x:678,y:688,t:1528139616665};\\\", \\\"{x:779,y:746,t:1528139616682};\\\", \\\"{x:813,y:758,t:1528139616703};\\\", \\\"{x:816,y:762,t:1528139618512};\\\", \\\"{x:820,y:765,t:1528139618525};\\\", \\\"{x:835,y:778,t:1528139618542};\\\", \\\"{x:869,y:803,t:1528139618560};\\\", \\\"{x:940,y:845,t:1528139618575};\\\", \\\"{x:1071,y:903,t:1528139618593};\\\", \\\"{x:1141,y:927,t:1528139618609};\\\", \\\"{x:1190,y:938,t:1528139618626};\\\", \\\"{x:1222,y:944,t:1528139618642};\\\", \\\"{x:1240,y:946,t:1528139618659};\\\", \\\"{x:1256,y:946,t:1528139618677};\\\", \\\"{x:1279,y:948,t:1528139618692};\\\", \\\"{x:1309,y:955,t:1528139618709};\\\", \\\"{x:1346,y:966,t:1528139618726};\\\", \\\"{x:1370,y:973,t:1528139618742};\\\", \\\"{x:1408,y:983,t:1528139618761};\\\", \\\"{x:1443,y:993,t:1528139618777};\\\", \\\"{x:1486,y:1000,t:1528139618792};\\\", \\\"{x:1517,y:1004,t:1528139618810};\\\", \\\"{x:1528,y:1005,t:1528139618826};\\\", \\\"{x:1530,y:1005,t:1528139618842};\\\", \\\"{x:1531,y:1005,t:1528139619313};\\\", \\\"{x:1531,y:1007,t:1528139619336};\\\", \\\"{x:1530,y:1008,t:1528139619344};\\\", \\\"{x:1530,y:1009,t:1528139619359};\\\", \\\"{x:1527,y:1015,t:1528139619376};\\\", \\\"{x:1527,y:1016,t:1528139619394};\\\", \\\"{x:1530,y:1016,t:1528139619480};\\\", \\\"{x:1534,y:1016,t:1528139619493};\\\", \\\"{x:1545,y:1013,t:1528139619510};\\\", \\\"{x:1551,y:1012,t:1528139619526};\\\", \\\"{x:1556,y:1010,t:1528139619543};\\\", \\\"{x:1565,y:1008,t:1528139619560};\\\", \\\"{x:1572,y:1008,t:1528139619576};\\\", \\\"{x:1582,y:1007,t:1528139619593};\\\", \\\"{x:1591,y:1005,t:1528139619610};\\\", \\\"{x:1596,y:1005,t:1528139619626};\\\", \\\"{x:1599,y:1005,t:1528139619643};\\\", \\\"{x:1603,y:1005,t:1528139619660};\\\", \\\"{x:1615,y:1007,t:1528139619676};\\\", \\\"{x:1633,y:1008,t:1528139619693};\\\", \\\"{x:1648,y:1010,t:1528139619710};\\\", \\\"{x:1661,y:1010,t:1528139619726};\\\", \\\"{x:1667,y:1010,t:1528139619743};\\\", \\\"{x:1676,y:1010,t:1528139619760};\\\", \\\"{x:1685,y:1008,t:1528139619776};\\\", \\\"{x:1693,y:1006,t:1528139619794};\\\", \\\"{x:1698,y:1004,t:1528139619811};\\\", \\\"{x:1702,y:1002,t:1528139619826};\\\", \\\"{x:1703,y:1001,t:1528139619848};\\\", \\\"{x:1703,y:1000,t:1528139619992};\\\", \\\"{x:1703,y:999,t:1528139620010};\\\", \\\"{x:1703,y:997,t:1528139620027};\\\", \\\"{x:1703,y:996,t:1528139620043};\\\", \\\"{x:1699,y:994,t:1528139620060};\\\", \\\"{x:1694,y:992,t:1528139620077};\\\", \\\"{x:1689,y:991,t:1528139620093};\\\", \\\"{x:1685,y:989,t:1528139620110};\\\", \\\"{x:1682,y:988,t:1528139620127};\\\", \\\"{x:1682,y:987,t:1528139620143};\\\", \\\"{x:1676,y:985,t:1528139620161};\\\", \\\"{x:1670,y:983,t:1528139620178};\\\", \\\"{x:1666,y:980,t:1528139620193};\\\", \\\"{x:1661,y:980,t:1528139620211};\\\", \\\"{x:1659,y:978,t:1528139620228};\\\", \\\"{x:1658,y:978,t:1528139620243};\\\", \\\"{x:1656,y:977,t:1528139620260};\\\", \\\"{x:1654,y:977,t:1528139620278};\\\", \\\"{x:1650,y:975,t:1528139620293};\\\", \\\"{x:1644,y:973,t:1528139620310};\\\", \\\"{x:1640,y:970,t:1528139620327};\\\", \\\"{x:1634,y:968,t:1528139620344};\\\", \\\"{x:1631,y:968,t:1528139620360};\\\", \\\"{x:1629,y:966,t:1528139620377};\\\", \\\"{x:1626,y:963,t:1528139620394};\\\", \\\"{x:1622,y:961,t:1528139620411};\\\", \\\"{x:1621,y:960,t:1528139620428};\\\", \\\"{x:1619,y:958,t:1528139620445};\\\", \\\"{x:1618,y:957,t:1528139620460};\\\", \\\"{x:1618,y:956,t:1528139620477};\\\", \\\"{x:1617,y:955,t:1528139620496};\\\", \\\"{x:1616,y:953,t:1528139620510};\\\", \\\"{x:1614,y:949,t:1528139620527};\\\", \\\"{x:1613,y:944,t:1528139620544};\\\", \\\"{x:1609,y:937,t:1528139620561};\\\", \\\"{x:1603,y:924,t:1528139620577};\\\", \\\"{x:1594,y:909,t:1528139620594};\\\", \\\"{x:1587,y:897,t:1528139620610};\\\", \\\"{x:1582,y:887,t:1528139620627};\\\", \\\"{x:1579,y:882,t:1528139620644};\\\", \\\"{x:1574,y:873,t:1528139620661};\\\", \\\"{x:1569,y:860,t:1528139620677};\\\", \\\"{x:1565,y:852,t:1528139620694};\\\", \\\"{x:1559,y:842,t:1528139620711};\\\", \\\"{x:1556,y:838,t:1528139620728};\\\", \\\"{x:1553,y:830,t:1528139620744};\\\", \\\"{x:1549,y:825,t:1528139620762};\\\", \\\"{x:1548,y:823,t:1528139620777};\\\", \\\"{x:1545,y:818,t:1528139620794};\\\", \\\"{x:1540,y:809,t:1528139620810};\\\", \\\"{x:1530,y:794,t:1528139620826};\\\", \\\"{x:1523,y:783,t:1528139620844};\\\", \\\"{x:1515,y:770,t:1528139620861};\\\", \\\"{x:1511,y:764,t:1528139620877};\\\", \\\"{x:1509,y:761,t:1528139620894};\\\", \\\"{x:1507,y:757,t:1528139620911};\\\", \\\"{x:1506,y:756,t:1528139620927};\\\", \\\"{x:1505,y:725,t:1528139620944};\\\", \\\"{x:1498,y:677,t:1528139620961};\\\", \\\"{x:1483,y:629,t:1528139620977};\\\", \\\"{x:1471,y:597,t:1528139620995};\\\", \\\"{x:1463,y:577,t:1528139621012};\\\", \\\"{x:1451,y:550,t:1528139621027};\\\", \\\"{x:1441,y:533,t:1528139621044};\\\", \\\"{x:1439,y:529,t:1528139621062};\\\", \\\"{x:1438,y:528,t:1528139621077};\\\", \\\"{x:1438,y:527,t:1528139621160};\\\", \\\"{x:1430,y:529,t:1528139621178};\\\", \\\"{x:1426,y:534,t:1528139621195};\\\", \\\"{x:1421,y:542,t:1528139621211};\\\", \\\"{x:1413,y:555,t:1528139621228};\\\", \\\"{x:1408,y:567,t:1528139621245};\\\", \\\"{x:1406,y:572,t:1528139621261};\\\", \\\"{x:1406,y:574,t:1528139621278};\\\", \\\"{x:1406,y:576,t:1528139621295};\\\", \\\"{x:1406,y:575,t:1528139621424};\\\", \\\"{x:1406,y:573,t:1528139621432};\\\", \\\"{x:1406,y:572,t:1528139621444};\\\", \\\"{x:1406,y:569,t:1528139621461};\\\", \\\"{x:1406,y:568,t:1528139621478};\\\", \\\"{x:1407,y:568,t:1528139621593};\\\", \\\"{x:1408,y:568,t:1528139621600};\\\", \\\"{x:1409,y:568,t:1528139621611};\\\", \\\"{x:1411,y:568,t:1528139621632};\\\", \\\"{x:1413,y:568,t:1528139621654};\\\", \\\"{x:1416,y:568,t:1528139621677};\\\", \\\"{x:1417,y:567,t:1528139621719};\\\", \\\"{x:1412,y:566,t:1528139626112};\\\", \\\"{x:1387,y:566,t:1528139626122};\\\", \\\"{x:1351,y:566,t:1528139626132};\\\", \\\"{x:1257,y:566,t:1528139626149};\\\", \\\"{x:1146,y:566,t:1528139626165};\\\", \\\"{x:1046,y:567,t:1528139626181};\\\", \\\"{x:965,y:578,t:1528139626198};\\\", \\\"{x:893,y:590,t:1528139626215};\\\", \\\"{x:860,y:594,t:1528139626231};\\\", \\\"{x:834,y:594,t:1528139626248};\\\", \\\"{x:817,y:597,t:1528139626266};\\\", \\\"{x:801,y:598,t:1528139626282};\\\", \\\"{x:782,y:598,t:1528139626298};\\\", \\\"{x:760,y:599,t:1528139626315};\\\", \\\"{x:738,y:603,t:1528139626332};\\\", \\\"{x:718,y:605,t:1528139626349};\\\", \\\"{x:697,y:608,t:1528139626365};\\\", \\\"{x:678,y:609,t:1528139626382};\\\", \\\"{x:645,y:613,t:1528139626398};\\\", \\\"{x:607,y:614,t:1528139626415};\\\", \\\"{x:585,y:614,t:1528139626432};\\\", \\\"{x:562,y:613,t:1528139626448};\\\", \\\"{x:539,y:612,t:1528139626465};\\\", \\\"{x:522,y:609,t:1528139626483};\\\", \\\"{x:508,y:608,t:1528139626498};\\\", \\\"{x:487,y:607,t:1528139626516};\\\", \\\"{x:468,y:607,t:1528139626532};\\\", \\\"{x:453,y:607,t:1528139626548};\\\", \\\"{x:445,y:607,t:1528139626565};\\\", \\\"{x:441,y:607,t:1528139626582};\\\", \\\"{x:439,y:607,t:1528139626599};\\\", \\\"{x:439,y:608,t:1528139626615};\\\", \\\"{x:441,y:609,t:1528139626671};\\\", \\\"{x:447,y:609,t:1528139626682};\\\", \\\"{x:467,y:609,t:1528139626699};\\\", \\\"{x:507,y:608,t:1528139626716};\\\", \\\"{x:566,y:597,t:1528139626732};\\\", \\\"{x:612,y:582,t:1528139626749};\\\", \\\"{x:637,y:575,t:1528139626766};\\\", \\\"{x:654,y:570,t:1528139626783};\\\", \\\"{x:683,y:560,t:1528139626799};\\\", \\\"{x:690,y:558,t:1528139626815};\\\", \\\"{x:695,y:556,t:1528139626832};\\\", \\\"{x:696,y:556,t:1528139626871};\\\", \\\"{x:694,y:559,t:1528139626882};\\\", \\\"{x:689,y:566,t:1528139626899};\\\", \\\"{x:684,y:572,t:1528139626915};\\\", \\\"{x:677,y:577,t:1528139626933};\\\", \\\"{x:668,y:581,t:1528139626949};\\\", \\\"{x:652,y:589,t:1528139626966};\\\", \\\"{x:644,y:592,t:1528139626982};\\\", \\\"{x:641,y:593,t:1528139626999};\\\", \\\"{x:640,y:593,t:1528139627031};\\\", \\\"{x:639,y:593,t:1528139627038};\\\", \\\"{x:638,y:593,t:1528139627055};\\\", \\\"{x:636,y:593,t:1528139627066};\\\", \\\"{x:633,y:593,t:1528139627082};\\\", \\\"{x:629,y:592,t:1528139627099};\\\", \\\"{x:628,y:592,t:1528139627116};\\\", \\\"{x:626,y:592,t:1528139627132};\\\", \\\"{x:624,y:592,t:1528139627351};\\\", \\\"{x:618,y:599,t:1528139627366};\\\", \\\"{x:603,y:620,t:1528139627383};\\\", \\\"{x:587,y:642,t:1528139627399};\\\", \\\"{x:577,y:655,t:1528139627416};\\\", \\\"{x:569,y:666,t:1528139627432};\\\", \\\"{x:561,y:682,t:1528139627449};\\\", \\\"{x:554,y:696,t:1528139627467};\\\", \\\"{x:553,y:704,t:1528139627482};\\\", \\\"{x:551,y:711,t:1528139627499};\\\", \\\"{x:549,y:718,t:1528139627516};\\\", \\\"{x:545,y:728,t:1528139627533};\\\", \\\"{x:544,y:730,t:1528139627549};\\\", \\\"{x:544,y:732,t:1528139627567};\\\", \\\"{x:543,y:734,t:1528139627584};\\\", \\\"{x:543,y:735,t:1528139627599};\\\", \\\"{x:542,y:739,t:1528139627618};\\\", \\\"{x:541,y:742,t:1528139627633};\\\", \\\"{x:540,y:745,t:1528139627649};\\\", \\\"{x:539,y:749,t:1528139627666};\\\" ] }, { \\\"rt\\\": 15459, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 386981, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -11 AM-O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:734,t:1528139630152};\\\", \\\"{x:536,y:705,t:1528139630172};\\\", \\\"{x:526,y:666,t:1528139630184};\\\", \\\"{x:518,y:638,t:1528139630202};\\\", \\\"{x:516,y:625,t:1528139630218};\\\", \\\"{x:509,y:605,t:1528139630236};\\\", \\\"{x:504,y:592,t:1528139630251};\\\", \\\"{x:502,y:587,t:1528139630269};\\\", \\\"{x:501,y:581,t:1528139630286};\\\", \\\"{x:499,y:575,t:1528139630301};\\\", \\\"{x:498,y:573,t:1528139630318};\\\", \\\"{x:498,y:572,t:1528139630334};\\\", \\\"{x:498,y:571,t:1528139630351};\\\", \\\"{x:497,y:569,t:1528139630369};\\\", \\\"{x:497,y:563,t:1528139630386};\\\", \\\"{x:497,y:555,t:1528139630402};\\\", \\\"{x:496,y:544,t:1528139630418};\\\", \\\"{x:494,y:536,t:1528139630435};\\\", \\\"{x:492,y:534,t:1528139630451};\\\", \\\"{x:491,y:527,t:1528139630468};\\\", \\\"{x:490,y:516,t:1528139630485};\\\", \\\"{x:488,y:504,t:1528139630501};\\\", \\\"{x:486,y:496,t:1528139630519};\\\", \\\"{x:485,y:493,t:1528139630535};\\\", \\\"{x:485,y:491,t:1528139630552};\\\", \\\"{x:485,y:490,t:1528139630576};\\\", \\\"{x:485,y:488,t:1528139630608};\\\", \\\"{x:485,y:487,t:1528139630631};\\\", \\\"{x:486,y:488,t:1528139631296};\\\", \\\"{x:486,y:490,t:1528139631304};\\\", \\\"{x:487,y:493,t:1528139631318};\\\", \\\"{x:488,y:495,t:1528139631335};\\\", \\\"{x:489,y:496,t:1528139631351};\\\", \\\"{x:490,y:500,t:1528139631367};\\\", \\\"{x:490,y:503,t:1528139631386};\\\", \\\"{x:490,y:505,t:1528139631402};\\\", \\\"{x:490,y:507,t:1528139631420};\\\", \\\"{x:490,y:508,t:1528139631439};\\\", \\\"{x:490,y:510,t:1528139631453};\\\", \\\"{x:490,y:511,t:1528139631471};\\\", \\\"{x:490,y:512,t:1528139631485};\\\", \\\"{x:490,y:513,t:1528139631502};\\\", \\\"{x:490,y:514,t:1528139631519};\\\", \\\"{x:490,y:515,t:1528139631608};\\\", \\\"{x:490,y:517,t:1528139631620};\\\", \\\"{x:490,y:518,t:1528139631647};\\\", \\\"{x:490,y:518,t:1528139632105};\\\", \\\"{x:490,y:530,t:1528139632248};\\\", \\\"{x:499,y:551,t:1528139632256};\\\", \\\"{x:516,y:578,t:1528139632271};\\\", \\\"{x:562,y:650,t:1528139632287};\\\", \\\"{x:650,y:768,t:1528139632304};\\\", \\\"{x:717,y:843,t:1528139632321};\\\", \\\"{x:774,y:909,t:1528139632336};\\\", \\\"{x:821,y:968,t:1528139632353};\\\", \\\"{x:855,y:1014,t:1528139632370};\\\", \\\"{x:874,y:1039,t:1528139632387};\\\", \\\"{x:881,y:1051,t:1528139632403};\\\", \\\"{x:882,y:1054,t:1528139632419};\\\", \\\"{x:885,y:1054,t:1528139635408};\\\", \\\"{x:895,y:1054,t:1528139635420};\\\", \\\"{x:922,y:1055,t:1528139635437};\\\", \\\"{x:953,y:1060,t:1528139635454};\\\", \\\"{x:992,y:1064,t:1528139635470};\\\", \\\"{x:1042,y:1072,t:1528139635487};\\\", \\\"{x:1114,y:1082,t:1528139635503};\\\", \\\"{x:1160,y:1085,t:1528139635519};\\\", \\\"{x:1224,y:1095,t:1528139635537};\\\", \\\"{x:1262,y:1095,t:1528139635553};\\\", \\\"{x:1264,y:1097,t:1528139636040};\\\", \\\"{x:1267,y:1098,t:1528139636053};\\\", \\\"{x:1271,y:1098,t:1528139636070};\\\", \\\"{x:1276,y:1097,t:1528139636087};\\\", \\\"{x:1282,y:1094,t:1528139636103};\\\", \\\"{x:1287,y:1090,t:1528139636119};\\\", \\\"{x:1293,y:1086,t:1528139636137};\\\", \\\"{x:1295,y:1084,t:1528139636153};\\\", \\\"{x:1299,y:1081,t:1528139636170};\\\", \\\"{x:1301,y:1079,t:1528139636187};\\\", \\\"{x:1302,y:1076,t:1528139636203};\\\", \\\"{x:1302,y:1072,t:1528139636220};\\\", \\\"{x:1302,y:1068,t:1528139636237};\\\", \\\"{x:1302,y:1066,t:1528139636252};\\\", \\\"{x:1302,y:1065,t:1528139636288};\\\", \\\"{x:1302,y:1060,t:1528139636304};\\\", \\\"{x:1294,y:1035,t:1528139636320};\\\", \\\"{x:1285,y:1015,t:1528139636337};\\\", \\\"{x:1272,y:990,t:1528139636353};\\\", \\\"{x:1256,y:969,t:1528139636370};\\\", \\\"{x:1244,y:956,t:1528139636387};\\\", \\\"{x:1238,y:943,t:1528139636403};\\\", \\\"{x:1228,y:923,t:1528139636420};\\\", \\\"{x:1226,y:902,t:1528139636437};\\\", \\\"{x:1226,y:873,t:1528139636453};\\\", \\\"{x:1226,y:849,t:1528139636470};\\\", \\\"{x:1226,y:828,t:1528139636487};\\\", \\\"{x:1226,y:804,t:1528139636504};\\\", \\\"{x:1228,y:772,t:1528139636520};\\\", \\\"{x:1237,y:753,t:1528139636538};\\\", \\\"{x:1251,y:732,t:1528139636553};\\\", \\\"{x:1262,y:712,t:1528139636570};\\\", \\\"{x:1270,y:696,t:1528139636587};\\\", \\\"{x:1280,y:678,t:1528139636604};\\\", \\\"{x:1289,y:663,t:1528139636620};\\\", \\\"{x:1295,y:647,t:1528139636636};\\\", \\\"{x:1299,y:633,t:1528139636652};\\\", \\\"{x:1304,y:622,t:1528139636670};\\\", \\\"{x:1305,y:614,t:1528139636687};\\\", \\\"{x:1307,y:606,t:1528139636703};\\\", \\\"{x:1310,y:596,t:1528139636720};\\\", \\\"{x:1311,y:590,t:1528139636737};\\\", \\\"{x:1311,y:585,t:1528139636753};\\\", \\\"{x:1311,y:577,t:1528139636770};\\\", \\\"{x:1313,y:571,t:1528139636787};\\\", \\\"{x:1315,y:564,t:1528139636803};\\\", \\\"{x:1315,y:557,t:1528139636820};\\\", \\\"{x:1315,y:551,t:1528139636837};\\\", \\\"{x:1315,y:545,t:1528139636853};\\\", \\\"{x:1315,y:538,t:1528139636870};\\\", \\\"{x:1315,y:534,t:1528139636887};\\\", \\\"{x:1315,y:530,t:1528139636903};\\\", \\\"{x:1315,y:525,t:1528139636920};\\\", \\\"{x:1314,y:523,t:1528139636937};\\\", \\\"{x:1312,y:520,t:1528139636954};\\\", \\\"{x:1312,y:517,t:1528139636970};\\\", \\\"{x:1312,y:515,t:1528139636987};\\\", \\\"{x:1312,y:513,t:1528139637003};\\\", \\\"{x:1312,y:512,t:1528139637064};\\\", \\\"{x:1312,y:511,t:1528139637080};\\\", \\\"{x:1312,y:509,t:1528139637104};\\\", \\\"{x:1312,y:507,t:1528139637120};\\\", \\\"{x:1312,y:506,t:1528139637168};\\\", \\\"{x:1312,y:505,t:1528139637176};\\\", \\\"{x:1312,y:504,t:1528139637187};\\\", \\\"{x:1312,y:503,t:1528139637208};\\\", \\\"{x:1312,y:502,t:1528139637221};\\\", \\\"{x:1312,y:501,t:1528139637271};\\\", \\\"{x:1313,y:500,t:1528139637286};\\\", \\\"{x:1313,y:499,t:1528139637367};\\\", \\\"{x:1313,y:498,t:1528139637407};\\\", \\\"{x:1313,y:501,t:1528139638128};\\\", \\\"{x:1303,y:527,t:1528139638158};\\\", \\\"{x:1296,y:556,t:1528139638175};\\\", \\\"{x:1294,y:574,t:1528139638190};\\\", \\\"{x:1292,y:587,t:1528139638207};\\\", \\\"{x:1291,y:596,t:1528139638225};\\\", \\\"{x:1291,y:599,t:1528139638242};\\\", \\\"{x:1290,y:605,t:1528139638258};\\\", \\\"{x:1290,y:611,t:1528139638275};\\\", \\\"{x:1290,y:615,t:1528139638291};\\\", \\\"{x:1290,y:620,t:1528139638307};\\\", \\\"{x:1290,y:621,t:1528139638325};\\\", \\\"{x:1290,y:622,t:1528139638342};\\\", \\\"{x:1290,y:623,t:1528139638358};\\\", \\\"{x:1292,y:624,t:1528139638375};\\\", \\\"{x:1299,y:628,t:1528139638391};\\\", \\\"{x:1300,y:629,t:1528139638408};\\\", \\\"{x:1302,y:629,t:1528139638426};\\\", \\\"{x:1303,y:630,t:1528139638443};\\\", \\\"{x:1304,y:630,t:1528139638458};\\\", \\\"{x:1308,y:630,t:1528139638475};\\\", \\\"{x:1309,y:630,t:1528139638496};\\\", \\\"{x:1311,y:630,t:1528139638524};\\\", \\\"{x:1312,y:630,t:1528139638541};\\\", \\\"{x:1314,y:629,t:1528139638559};\\\", \\\"{x:1316,y:629,t:1528139638574};\\\", \\\"{x:1316,y:628,t:1528139639216};\\\", \\\"{x:1316,y:629,t:1528139639407};\\\", \\\"{x:1316,y:632,t:1528139639415};\\\", \\\"{x:1316,y:633,t:1528139639426};\\\", \\\"{x:1315,y:637,t:1528139639445};\\\", \\\"{x:1314,y:643,t:1528139639458};\\\", \\\"{x:1314,y:646,t:1528139639476};\\\", \\\"{x:1314,y:649,t:1528139639492};\\\", \\\"{x:1314,y:655,t:1528139639508};\\\", \\\"{x:1314,y:659,t:1528139639525};\\\", \\\"{x:1314,y:664,t:1528139639542};\\\", \\\"{x:1314,y:668,t:1528139639559};\\\", \\\"{x:1315,y:669,t:1528139639575};\\\", \\\"{x:1315,y:671,t:1528139639592};\\\", \\\"{x:1315,y:672,t:1528139639608};\\\", \\\"{x:1315,y:675,t:1528139639626};\\\", \\\"{x:1316,y:676,t:1528139639655};\\\", \\\"{x:1316,y:677,t:1528139639663};\\\", \\\"{x:1316,y:678,t:1528139639679};\\\", \\\"{x:1316,y:679,t:1528139639704};\\\", \\\"{x:1316,y:681,t:1528139639712};\\\", \\\"{x:1317,y:682,t:1528139639726};\\\", \\\"{x:1317,y:684,t:1528139639743};\\\", \\\"{x:1317,y:685,t:1528139639759};\\\", \\\"{x:1317,y:687,t:1528139639776};\\\", \\\"{x:1318,y:691,t:1528139639793};\\\", \\\"{x:1319,y:695,t:1528139639809};\\\", \\\"{x:1319,y:699,t:1528139639827};\\\", \\\"{x:1319,y:702,t:1528139639843};\\\", \\\"{x:1319,y:705,t:1528139639859};\\\", \\\"{x:1319,y:708,t:1528139639877};\\\", \\\"{x:1319,y:711,t:1528139639894};\\\", \\\"{x:1319,y:718,t:1528139639910};\\\", \\\"{x:1319,y:724,t:1528139639927};\\\", \\\"{x:1319,y:732,t:1528139639944};\\\", \\\"{x:1319,y:737,t:1528139639960};\\\", \\\"{x:1319,y:741,t:1528139639976};\\\", \\\"{x:1319,y:743,t:1528139639993};\\\", \\\"{x:1319,y:746,t:1528139640010};\\\", \\\"{x:1319,y:753,t:1528139640026};\\\", \\\"{x:1319,y:762,t:1528139640044};\\\", \\\"{x:1321,y:772,t:1528139640060};\\\", \\\"{x:1321,y:777,t:1528139640076};\\\", \\\"{x:1321,y:782,t:1528139640094};\\\", \\\"{x:1321,y:786,t:1528139640110};\\\", \\\"{x:1322,y:792,t:1528139640126};\\\", \\\"{x:1322,y:800,t:1528139640143};\\\", \\\"{x:1322,y:801,t:1528139640160};\\\", \\\"{x:1322,y:805,t:1528139640176};\\\", \\\"{x:1322,y:808,t:1528139640194};\\\", \\\"{x:1321,y:814,t:1528139640211};\\\", \\\"{x:1318,y:822,t:1528139640227};\\\", \\\"{x:1317,y:832,t:1528139640244};\\\", \\\"{x:1315,y:840,t:1528139640261};\\\", \\\"{x:1312,y:847,t:1528139640277};\\\", \\\"{x:1311,y:858,t:1528139640293};\\\", \\\"{x:1307,y:867,t:1528139640311};\\\", \\\"{x:1303,y:877,t:1528139640326};\\\", \\\"{x:1299,y:890,t:1528139640343};\\\", \\\"{x:1296,y:906,t:1528139640360};\\\", \\\"{x:1293,y:912,t:1528139640377};\\\", \\\"{x:1293,y:920,t:1528139640394};\\\", \\\"{x:1293,y:927,t:1528139640411};\\\", \\\"{x:1293,y:934,t:1528139640426};\\\", \\\"{x:1293,y:940,t:1528139640443};\\\", \\\"{x:1293,y:948,t:1528139640461};\\\", \\\"{x:1293,y:956,t:1528139640476};\\\", \\\"{x:1293,y:963,t:1528139640493};\\\", \\\"{x:1294,y:968,t:1528139640510};\\\", \\\"{x:1295,y:971,t:1528139640527};\\\", \\\"{x:1297,y:981,t:1528139640543};\\\", \\\"{x:1298,y:984,t:1528139640560};\\\", \\\"{x:1299,y:987,t:1528139640577};\\\", \\\"{x:1299,y:989,t:1528139640593};\\\", \\\"{x:1299,y:992,t:1528139640611};\\\", \\\"{x:1301,y:995,t:1528139640627};\\\", \\\"{x:1301,y:996,t:1528139640648};\\\", \\\"{x:1301,y:993,t:1528139640729};\\\", \\\"{x:1301,y:985,t:1528139640744};\\\", \\\"{x:1303,y:975,t:1528139640760};\\\", \\\"{x:1308,y:953,t:1528139640777};\\\", \\\"{x:1314,y:920,t:1528139640793};\\\", \\\"{x:1320,y:878,t:1528139640810};\\\", \\\"{x:1323,y:837,t:1528139640828};\\\", \\\"{x:1329,y:809,t:1528139640844};\\\", \\\"{x:1333,y:787,t:1528139640861};\\\", \\\"{x:1336,y:765,t:1528139640877};\\\", \\\"{x:1339,y:742,t:1528139640894};\\\", \\\"{x:1340,y:721,t:1528139640910};\\\", \\\"{x:1340,y:697,t:1528139640928};\\\", \\\"{x:1340,y:682,t:1528139640943};\\\", \\\"{x:1340,y:674,t:1528139640960};\\\", \\\"{x:1338,y:671,t:1528139640977};\\\", \\\"{x:1338,y:669,t:1528139640993};\\\", \\\"{x:1337,y:668,t:1528139641009};\\\", \\\"{x:1337,y:667,t:1528139641027};\\\", \\\"{x:1336,y:666,t:1528139641047};\\\", \\\"{x:1336,y:664,t:1528139641071};\\\", \\\"{x:1336,y:661,t:1528139641079};\\\", \\\"{x:1336,y:657,t:1528139641093};\\\", \\\"{x:1334,y:652,t:1528139641110};\\\", \\\"{x:1333,y:643,t:1528139641127};\\\", \\\"{x:1331,y:640,t:1528139641143};\\\", \\\"{x:1331,y:636,t:1528139641160};\\\", \\\"{x:1331,y:634,t:1528139641177};\\\", \\\"{x:1330,y:632,t:1528139641193};\\\", \\\"{x:1330,y:629,t:1528139641210};\\\", \\\"{x:1329,y:627,t:1528139641231};\\\", \\\"{x:1328,y:627,t:1528139641263};\\\", \\\"{x:1328,y:626,t:1528139641276};\\\", \\\"{x:1327,y:626,t:1528139641294};\\\", \\\"{x:1324,y:626,t:1528139641310};\\\", \\\"{x:1318,y:626,t:1528139641328};\\\", \\\"{x:1314,y:626,t:1528139641342};\\\", \\\"{x:1311,y:627,t:1528139641360};\\\", \\\"{x:1310,y:627,t:1528139641376};\\\", \\\"{x:1309,y:627,t:1528139641415};\\\", \\\"{x:1308,y:629,t:1528139641455};\\\", \\\"{x:1308,y:631,t:1528139641462};\\\", \\\"{x:1301,y:639,t:1528139641477};\\\", \\\"{x:1272,y:654,t:1528139641494};\\\", \\\"{x:1181,y:687,t:1528139641511};\\\", \\\"{x:1075,y:707,t:1528139641527};\\\", \\\"{x:947,y:725,t:1528139641543};\\\", \\\"{x:809,y:740,t:1528139641561};\\\", \\\"{x:674,y:757,t:1528139641578};\\\", \\\"{x:557,y:780,t:1528139641595};\\\", \\\"{x:463,y:801,t:1528139641611};\\\", \\\"{x:401,y:824,t:1528139641628};\\\", \\\"{x:381,y:828,t:1528139641644};\\\", \\\"{x:379,y:829,t:1528139641660};\\\", \\\"{x:380,y:825,t:1528139641736};\\\", \\\"{x:387,y:814,t:1528139641744};\\\", \\\"{x:399,y:791,t:1528139641761};\\\", \\\"{x:420,y:755,t:1528139641778};\\\", \\\"{x:435,y:730,t:1528139641794};\\\", \\\"{x:449,y:707,t:1528139641811};\\\", \\\"{x:466,y:689,t:1528139641828};\\\", \\\"{x:483,y:677,t:1528139641844};\\\", \\\"{x:499,y:667,t:1528139641862};\\\", \\\"{x:508,y:662,t:1528139641879};\\\", \\\"{x:513,y:659,t:1528139641894};\\\", \\\"{x:520,y:656,t:1528139641911};\\\", \\\"{x:529,y:655,t:1528139641928};\\\", \\\"{x:541,y:650,t:1528139641944};\\\", \\\"{x:554,y:646,t:1528139641961};\\\", \\\"{x:574,y:640,t:1528139641978};\\\", \\\"{x:597,y:632,t:1528139641995};\\\", \\\"{x:620,y:623,t:1528139642013};\\\", \\\"{x:649,y:612,t:1528139642028};\\\", \\\"{x:685,y:603,t:1528139642045};\\\", \\\"{x:711,y:595,t:1528139642061};\\\", \\\"{x:727,y:588,t:1528139642079};\\\", \\\"{x:739,y:586,t:1528139642095};\\\", \\\"{x:746,y:583,t:1528139642110};\\\", \\\"{x:749,y:582,t:1528139642127};\\\", \\\"{x:753,y:580,t:1528139642145};\\\", \\\"{x:759,y:578,t:1528139642161};\\\", \\\"{x:769,y:575,t:1528139642178};\\\", \\\"{x:778,y:570,t:1528139642195};\\\", \\\"{x:786,y:568,t:1528139642211};\\\", \\\"{x:788,y:568,t:1528139642228};\\\", \\\"{x:790,y:568,t:1528139642247};\\\", \\\"{x:792,y:568,t:1528139642271};\\\", \\\"{x:793,y:568,t:1528139642287};\\\", \\\"{x:794,y:568,t:1528139642295};\\\", \\\"{x:795,y:568,t:1528139642310};\\\", \\\"{x:796,y:568,t:1528139642343};\\\", \\\"{x:797,y:568,t:1528139642352};\\\", \\\"{x:799,y:568,t:1528139642361};\\\", \\\"{x:801,y:568,t:1528139642378};\\\", \\\"{x:804,y:569,t:1528139642395};\\\", \\\"{x:806,y:570,t:1528139642411};\\\", \\\"{x:808,y:571,t:1528139642428};\\\", \\\"{x:813,y:571,t:1528139642445};\\\", \\\"{x:816,y:571,t:1528139642461};\\\", \\\"{x:818,y:570,t:1528139642696};\\\", \\\"{x:811,y:575,t:1528139642712};\\\", \\\"{x:784,y:597,t:1528139642730};\\\", \\\"{x:741,y:627,t:1528139642745};\\\", \\\"{x:710,y:648,t:1528139642762};\\\", \\\"{x:693,y:661,t:1528139642779};\\\", \\\"{x:676,y:671,t:1528139642795};\\\", \\\"{x:660,y:686,t:1528139642812};\\\", \\\"{x:626,y:712,t:1528139642828};\\\", \\\"{x:593,y:733,t:1528139642844};\\\", \\\"{x:574,y:741,t:1528139642862};\\\", \\\"{x:569,y:742,t:1528139642879};\\\", \\\"{x:567,y:742,t:1528139642911};\\\", \\\"{x:566,y:742,t:1528139642919};\\\", \\\"{x:567,y:738,t:1528139642967};\\\", \\\"{x:575,y:728,t:1528139642979};\\\", \\\"{x:595,y:705,t:1528139642994};\\\", \\\"{x:613,y:686,t:1528139643012};\\\", \\\"{x:648,y:667,t:1528139643030};\\\", \\\"{x:690,y:645,t:1528139643045};\\\", \\\"{x:724,y:629,t:1528139643062};\\\", \\\"{x:745,y:619,t:1528139643079};\\\", \\\"{x:751,y:617,t:1528139643094};\\\", \\\"{x:753,y:616,t:1528139643111};\\\", \\\"{x:755,y:613,t:1528139643129};\\\", \\\"{x:761,y:611,t:1528139643145};\\\", \\\"{x:767,y:608,t:1528139643162};\\\", \\\"{x:772,y:604,t:1528139643179};\\\", \\\"{x:778,y:601,t:1528139643195};\\\", \\\"{x:784,y:595,t:1528139643212};\\\", \\\"{x:795,y:589,t:1528139643228};\\\", \\\"{x:802,y:584,t:1528139643246};\\\", \\\"{x:809,y:579,t:1528139643262};\\\", \\\"{x:812,y:575,t:1528139643279};\\\", \\\"{x:813,y:572,t:1528139643295};\\\", \\\"{x:816,y:570,t:1528139643312};\\\", \\\"{x:820,y:566,t:1528139643329};\\\", \\\"{x:824,y:563,t:1528139643347};\\\", \\\"{x:827,y:561,t:1528139643363};\\\", \\\"{x:828,y:560,t:1528139643379};\\\", \\\"{x:829,y:560,t:1528139643487};\\\", \\\"{x:828,y:561,t:1528139643743};\\\", \\\"{x:823,y:563,t:1528139643752};\\\", \\\"{x:817,y:568,t:1528139643763};\\\", \\\"{x:800,y:582,t:1528139643779};\\\", \\\"{x:783,y:602,t:1528139643797};\\\", \\\"{x:765,y:622,t:1528139643813};\\\", \\\"{x:738,y:650,t:1528139643829};\\\", \\\"{x:709,y:679,t:1528139643847};\\\", \\\"{x:663,y:703,t:1528139643864};\\\", \\\"{x:645,y:711,t:1528139643879};\\\", \\\"{x:629,y:716,t:1528139643895};\\\", \\\"{x:621,y:720,t:1528139643913};\\\", \\\"{x:617,y:723,t:1528139643929};\\\", \\\"{x:613,y:726,t:1528139643946};\\\", \\\"{x:611,y:726,t:1528139643963};\\\", \\\"{x:608,y:728,t:1528139643979};\\\", \\\"{x:607,y:728,t:1528139643996};\\\", \\\"{x:607,y:727,t:1528139644040};\\\", \\\"{x:616,y:720,t:1528139644047};\\\", \\\"{x:636,y:708,t:1528139644064};\\\", \\\"{x:641,y:704,t:1528139644079};\\\", \\\"{x:642,y:704,t:1528139644096};\\\", \\\"{x:637,y:705,t:1528139644127};\\\", \\\"{x:629,y:710,t:1528139644136};\\\", \\\"{x:622,y:715,t:1528139644147};\\\", \\\"{x:604,y:723,t:1528139644164};\\\", \\\"{x:570,y:739,t:1528139644179};\\\", \\\"{x:532,y:753,t:1528139644198};\\\", \\\"{x:500,y:760,t:1528139644212};\\\", \\\"{x:479,y:763,t:1528139644230};\\\", \\\"{x:471,y:765,t:1528139644246};\\\", \\\"{x:461,y:770,t:1528139644262};\\\", \\\"{x:458,y:771,t:1528139644280};\\\", \\\"{x:457,y:771,t:1528139644351};\\\", \\\"{x:456,y:771,t:1528139645016};\\\" ] }, { \\\"rt\\\": 13076, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 401318, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -E -E -E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:457,y:771,t:1528139646143};\\\", \\\"{x:457,y:774,t:1528139648936};\\\", \\\"{x:460,y:781,t:1528139648949};\\\", \\\"{x:461,y:790,t:1528139648967};\\\", \\\"{x:472,y:811,t:1528139648983};\\\", \\\"{x:480,y:823,t:1528139649000};\\\", \\\"{x:494,y:840,t:1528139649016};\\\", \\\"{x:512,y:854,t:1528139649033};\\\", \\\"{x:537,y:874,t:1528139649050};\\\", \\\"{x:553,y:888,t:1528139649066};\\\", \\\"{x:578,y:906,t:1528139649083};\\\", \\\"{x:608,y:925,t:1528139649100};\\\", \\\"{x:653,y:949,t:1528139649116};\\\", \\\"{x:694,y:971,t:1528139649133};\\\", \\\"{x:762,y:998,t:1528139649150};\\\", \\\"{x:825,y:1023,t:1528139649166};\\\", \\\"{x:919,y:1048,t:1528139649183};\\\", \\\"{x:969,y:1061,t:1528139649200};\\\", \\\"{x:1022,y:1077,t:1528139649217};\\\", \\\"{x:1078,y:1093,t:1528139649234};\\\", \\\"{x:1114,y:1102,t:1528139649250};\\\", \\\"{x:1136,y:1107,t:1528139649267};\\\", \\\"{x:1160,y:1111,t:1528139649284};\\\", \\\"{x:1179,y:1115,t:1528139649301};\\\", \\\"{x:1194,y:1120,t:1528139649317};\\\", \\\"{x:1207,y:1123,t:1528139649333};\\\", \\\"{x:1212,y:1123,t:1528139649350};\\\", \\\"{x:1216,y:1124,t:1528139649367};\\\", \\\"{x:1217,y:1124,t:1528139649704};\\\", \\\"{x:1217,y:1123,t:1528139649720};\\\", \\\"{x:1218,y:1121,t:1528139649733};\\\", \\\"{x:1219,y:1115,t:1528139649750};\\\", \\\"{x:1220,y:1108,t:1528139649768};\\\", \\\"{x:1220,y:1102,t:1528139649783};\\\", \\\"{x:1220,y:1098,t:1528139649800};\\\", \\\"{x:1220,y:1096,t:1528139649817};\\\", \\\"{x:1220,y:1094,t:1528139649833};\\\", \\\"{x:1220,y:1093,t:1528139649851};\\\", \\\"{x:1220,y:1092,t:1528139649871};\\\", \\\"{x:1220,y:1089,t:1528139650288};\\\", \\\"{x:1220,y:1088,t:1528139650300};\\\", \\\"{x:1216,y:1080,t:1528139650317};\\\", \\\"{x:1209,y:1065,t:1528139650335};\\\", \\\"{x:1199,y:1032,t:1528139650351};\\\", \\\"{x:1191,y:977,t:1528139650368};\\\", \\\"{x:1191,y:905,t:1528139650385};\\\", \\\"{x:1187,y:853,t:1528139650402};\\\", \\\"{x:1187,y:831,t:1528139650418};\\\", \\\"{x:1187,y:808,t:1528139650435};\\\", \\\"{x:1187,y:786,t:1528139650452};\\\", \\\"{x:1185,y:774,t:1528139650468};\\\", \\\"{x:1185,y:762,t:1528139650487};\\\", \\\"{x:1185,y:746,t:1528139650502};\\\", \\\"{x:1183,y:731,t:1528139650518};\\\", \\\"{x:1179,y:714,t:1528139650534};\\\", \\\"{x:1174,y:696,t:1528139650551};\\\", \\\"{x:1172,y:677,t:1528139650567};\\\", \\\"{x:1168,y:663,t:1528139650584};\\\", \\\"{x:1166,y:645,t:1528139650602};\\\", \\\"{x:1163,y:624,t:1528139650618};\\\", \\\"{x:1159,y:612,t:1528139650634};\\\", \\\"{x:1158,y:601,t:1528139650651};\\\", \\\"{x:1157,y:589,t:1528139650667};\\\", \\\"{x:1156,y:577,t:1528139650684};\\\", \\\"{x:1156,y:564,t:1528139650702};\\\", \\\"{x:1156,y:551,t:1528139650717};\\\", \\\"{x:1156,y:543,t:1528139650735};\\\", \\\"{x:1156,y:538,t:1528139650752};\\\", \\\"{x:1156,y:536,t:1528139650768};\\\", \\\"{x:1155,y:535,t:1528139651016};\\\", \\\"{x:1153,y:535,t:1528139651024};\\\", \\\"{x:1153,y:539,t:1528139651035};\\\", \\\"{x:1151,y:546,t:1528139651052};\\\", \\\"{x:1150,y:549,t:1528139651069};\\\", \\\"{x:1150,y:550,t:1528139651087};\\\", \\\"{x:1150,y:551,t:1528139651102};\\\", \\\"{x:1150,y:554,t:1528139651119};\\\", \\\"{x:1150,y:555,t:1528139651135};\\\", \\\"{x:1151,y:561,t:1528139651151};\\\", \\\"{x:1152,y:562,t:1528139651169};\\\", \\\"{x:1155,y:563,t:1528139651186};\\\", \\\"{x:1162,y:563,t:1528139651201};\\\", \\\"{x:1180,y:563,t:1528139651219};\\\", \\\"{x:1200,y:563,t:1528139651235};\\\", \\\"{x:1224,y:566,t:1528139651252};\\\", \\\"{x:1248,y:569,t:1528139651269};\\\", \\\"{x:1270,y:569,t:1528139651285};\\\", \\\"{x:1280,y:569,t:1528139651302};\\\", \\\"{x:1285,y:566,t:1528139651319};\\\", \\\"{x:1287,y:566,t:1528139651336};\\\", \\\"{x:1288,y:566,t:1528139651352};\\\", \\\"{x:1290,y:565,t:1528139651369};\\\", \\\"{x:1291,y:563,t:1528139651386};\\\", \\\"{x:1292,y:563,t:1528139651402};\\\", \\\"{x:1293,y:563,t:1528139651419};\\\", \\\"{x:1294,y:562,t:1528139651437};\\\", \\\"{x:1295,y:562,t:1528139651776};\\\", \\\"{x:1295,y:560,t:1528139651786};\\\", \\\"{x:1291,y:560,t:1528139651802};\\\", \\\"{x:1287,y:559,t:1528139651819};\\\", \\\"{x:1284,y:558,t:1528139651837};\\\", \\\"{x:1283,y:557,t:1528139651854};\\\", \\\"{x:1281,y:556,t:1528139651869};\\\", \\\"{x:1280,y:556,t:1528139651887};\\\", \\\"{x:1278,y:556,t:1528139651984};\\\", \\\"{x:1277,y:556,t:1528139652007};\\\", \\\"{x:1276,y:556,t:1528139652023};\\\", \\\"{x:1276,y:557,t:1528139652064};\\\", \\\"{x:1276,y:558,t:1528139652072};\\\", \\\"{x:1276,y:560,t:1528139652087};\\\", \\\"{x:1277,y:560,t:1528139652143};\\\", \\\"{x:1279,y:560,t:1528139652160};\\\", \\\"{x:1280,y:560,t:1528139652169};\\\", \\\"{x:1284,y:560,t:1528139652186};\\\", \\\"{x:1293,y:560,t:1528139652204};\\\", \\\"{x:1304,y:560,t:1528139652219};\\\", \\\"{x:1314,y:560,t:1528139652237};\\\", \\\"{x:1325,y:558,t:1528139652252};\\\", \\\"{x:1337,y:558,t:1528139652269};\\\", \\\"{x:1342,y:558,t:1528139652285};\\\", \\\"{x:1345,y:558,t:1528139652303};\\\", \\\"{x:1352,y:558,t:1528139652319};\\\", \\\"{x:1360,y:559,t:1528139652335};\\\", \\\"{x:1364,y:559,t:1528139652353};\\\", \\\"{x:1365,y:559,t:1528139652370};\\\", \\\"{x:1367,y:559,t:1528139652407};\\\", \\\"{x:1368,y:559,t:1528139652420};\\\", \\\"{x:1376,y:561,t:1528139652437};\\\", \\\"{x:1385,y:563,t:1528139652453};\\\", \\\"{x:1394,y:563,t:1528139652470};\\\", \\\"{x:1400,y:564,t:1528139652486};\\\", \\\"{x:1405,y:565,t:1528139652503};\\\", \\\"{x:1407,y:565,t:1528139652520};\\\", \\\"{x:1409,y:565,t:1528139652537};\\\", \\\"{x:1415,y:563,t:1528139652552};\\\", \\\"{x:1417,y:563,t:1528139652569};\\\", \\\"{x:1418,y:563,t:1528139652585};\\\", \\\"{x:1419,y:563,t:1528139652602};\\\", \\\"{x:1420,y:563,t:1528139652623};\\\", \\\"{x:1419,y:563,t:1528139653191};\\\", \\\"{x:1418,y:563,t:1528139653207};\\\", \\\"{x:1417,y:563,t:1528139653220};\\\", \\\"{x:1416,y:563,t:1528139653237};\\\", \\\"{x:1414,y:563,t:1528139653253};\\\", \\\"{x:1413,y:563,t:1528139653272};\\\", \\\"{x:1406,y:563,t:1528139653649};\\\", \\\"{x:1396,y:565,t:1528139653656};\\\", \\\"{x:1387,y:565,t:1528139653670};\\\", \\\"{x:1359,y:565,t:1528139653687};\\\", \\\"{x:1336,y:565,t:1528139653703};\\\", \\\"{x:1334,y:565,t:1528139653721};\\\", \\\"{x:1331,y:564,t:1528139653737};\\\", \\\"{x:1330,y:563,t:1528139653754};\\\", \\\"{x:1329,y:561,t:1528139653771};\\\", \\\"{x:1328,y:561,t:1528139653787};\\\", \\\"{x:1328,y:560,t:1528139653804};\\\", \\\"{x:1328,y:559,t:1528139653821};\\\", \\\"{x:1327,y:558,t:1528139654000};\\\", \\\"{x:1325,y:558,t:1528139654008};\\\", \\\"{x:1322,y:558,t:1528139654021};\\\", \\\"{x:1322,y:559,t:1528139654038};\\\", \\\"{x:1316,y:561,t:1528139654054};\\\", \\\"{x:1314,y:562,t:1528139654071};\\\", \\\"{x:1308,y:563,t:1528139654087};\\\", \\\"{x:1304,y:563,t:1528139654104};\\\", \\\"{x:1303,y:563,t:1528139654121};\\\", \\\"{x:1302,y:563,t:1528139654137};\\\", \\\"{x:1301,y:563,t:1528139654168};\\\", \\\"{x:1300,y:563,t:1528139654183};\\\", \\\"{x:1299,y:563,t:1528139654224};\\\", \\\"{x:1298,y:563,t:1528139654239};\\\", \\\"{x:1297,y:563,t:1528139654255};\\\", \\\"{x:1296,y:563,t:1528139654271};\\\", \\\"{x:1292,y:563,t:1528139654287};\\\", \\\"{x:1291,y:563,t:1528139654304};\\\", \\\"{x:1289,y:563,t:1528139654328};\\\", \\\"{x:1295,y:563,t:1528139654432};\\\", \\\"{x:1302,y:563,t:1528139654439};\\\", \\\"{x:1312,y:563,t:1528139654454};\\\", \\\"{x:1331,y:563,t:1528139654471};\\\", \\\"{x:1358,y:563,t:1528139654488};\\\", \\\"{x:1369,y:563,t:1528139654504};\\\", \\\"{x:1378,y:563,t:1528139654521};\\\", \\\"{x:1386,y:564,t:1528139654539};\\\", \\\"{x:1394,y:566,t:1528139654554};\\\", \\\"{x:1398,y:567,t:1528139654571};\\\", \\\"{x:1400,y:567,t:1528139654588};\\\", \\\"{x:1401,y:567,t:1528139654656};\\\", \\\"{x:1402,y:567,t:1528139654672};\\\", \\\"{x:1406,y:567,t:1528139654687};\\\", \\\"{x:1407,y:567,t:1528139654720};\\\", \\\"{x:1404,y:567,t:1528139654840};\\\", \\\"{x:1401,y:567,t:1528139654855};\\\", \\\"{x:1390,y:567,t:1528139654871};\\\", \\\"{x:1356,y:567,t:1528139654888};\\\", \\\"{x:1312,y:567,t:1528139654905};\\\", \\\"{x:1226,y:567,t:1528139654921};\\\", \\\"{x:1129,y:567,t:1528139654939};\\\", \\\"{x:1023,y:567,t:1528139654955};\\\", \\\"{x:918,y:567,t:1528139654972};\\\", \\\"{x:843,y:567,t:1528139654988};\\\", \\\"{x:766,y:559,t:1528139655005};\\\", \\\"{x:708,y:544,t:1528139655020};\\\", \\\"{x:632,y:530,t:1528139655038};\\\", \\\"{x:613,y:526,t:1528139655054};\\\", \\\"{x:584,y:520,t:1528139655071};\\\", \\\"{x:581,y:519,t:1528139655089};\\\", \\\"{x:580,y:518,t:1528139655104};\\\", \\\"{x:580,y:517,t:1528139655143};\\\", \\\"{x:580,y:516,t:1528139655154};\\\", \\\"{x:581,y:514,t:1528139655172};\\\", \\\"{x:584,y:511,t:1528139655189};\\\", \\\"{x:586,y:508,t:1528139655205};\\\", \\\"{x:588,y:505,t:1528139655221};\\\", \\\"{x:588,y:504,t:1528139655238};\\\", \\\"{x:594,y:501,t:1528139655255};\\\", \\\"{x:601,y:499,t:1528139655272};\\\", \\\"{x:604,y:498,t:1528139655288};\\\", \\\"{x:605,y:497,t:1528139655311};\\\", \\\"{x:609,y:496,t:1528139655654};\\\", \\\"{x:619,y:496,t:1528139655673};\\\", \\\"{x:640,y:499,t:1528139655688};\\\", \\\"{x:662,y:504,t:1528139655706};\\\", \\\"{x:686,y:511,t:1528139655723};\\\", \\\"{x:709,y:515,t:1528139655739};\\\", \\\"{x:728,y:522,t:1528139655756};\\\", \\\"{x:745,y:526,t:1528139655773};\\\", \\\"{x:759,y:530,t:1528139655789};\\\", \\\"{x:769,y:531,t:1528139655806};\\\", \\\"{x:775,y:532,t:1528139655822};\\\", \\\"{x:781,y:532,t:1528139655839};\\\", \\\"{x:791,y:532,t:1528139655855};\\\", \\\"{x:796,y:532,t:1528139655872};\\\", \\\"{x:799,y:532,t:1528139655889};\\\", \\\"{x:800,y:532,t:1528139655944};\\\", \\\"{x:802,y:532,t:1528139655960};\\\", \\\"{x:803,y:532,t:1528139655973};\\\", \\\"{x:806,y:532,t:1528139655989};\\\", \\\"{x:810,y:532,t:1528139656006};\\\", \\\"{x:812,y:532,t:1528139656023};\\\", \\\"{x:819,y:532,t:1528139656040};\\\", \\\"{x:824,y:532,t:1528139656056};\\\", \\\"{x:828,y:531,t:1528139656073};\\\", \\\"{x:832,y:531,t:1528139656088};\\\", \\\"{x:834,y:531,t:1528139656105};\\\", \\\"{x:835,y:531,t:1528139656123};\\\", \\\"{x:836,y:531,t:1528139656343};\\\", \\\"{x:832,y:535,t:1528139656357};\\\", \\\"{x:818,y:544,t:1528139656373};\\\", \\\"{x:790,y:560,t:1528139656390};\\\", \\\"{x:720,y:605,t:1528139656407};\\\", \\\"{x:667,y:632,t:1528139656423};\\\", \\\"{x:616,y:658,t:1528139656440};\\\", \\\"{x:558,y:682,t:1528139656456};\\\", \\\"{x:516,y:702,t:1528139656472};\\\", \\\"{x:493,y:713,t:1528139656489};\\\", \\\"{x:477,y:720,t:1528139656507};\\\", \\\"{x:471,y:724,t:1528139656523};\\\", \\\"{x:470,y:725,t:1528139656540};\\\", \\\"{x:469,y:725,t:1528139656575};\\\", \\\"{x:469,y:726,t:1528139656647};\\\", \\\"{x:470,y:729,t:1528139656657};\\\", \\\"{x:478,y:731,t:1528139656672};\\\", \\\"{x:484,y:732,t:1528139656690};\\\", \\\"{x:488,y:732,t:1528139656706};\\\", \\\"{x:489,y:732,t:1528139656723};\\\", \\\"{x:490,y:732,t:1528139656739};\\\", \\\"{x:492,y:734,t:1528139656757};\\\", \\\"{x:493,y:735,t:1528139656773};\\\", \\\"{x:494,y:737,t:1528139656790};\\\", \\\"{x:495,y:737,t:1528139656815};\\\" ] }, { \\\"rt\\\": 28114, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 430711, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-C -C -B -B -C -C -X -H -O -O -X -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:740,t:1528139663280};\\\", \\\"{x:517,y:753,t:1528139663298};\\\", \\\"{x:543,y:765,t:1528139663312};\\\", \\\"{x:577,y:773,t:1528139663328};\\\", \\\"{x:607,y:782,t:1528139663345};\\\", \\\"{x:636,y:785,t:1528139663361};\\\", \\\"{x:665,y:791,t:1528139663378};\\\", \\\"{x:696,y:796,t:1528139663395};\\\", \\\"{x:729,y:800,t:1528139663412};\\\", \\\"{x:766,y:800,t:1528139663429};\\\", \\\"{x:787,y:800,t:1528139663445};\\\", \\\"{x:788,y:800,t:1528139663462};\\\", \\\"{x:789,y:800,t:1528139664760};\\\", \\\"{x:790,y:800,t:1528139664767};\\\", \\\"{x:793,y:800,t:1528139664781};\\\", \\\"{x:801,y:799,t:1528139664796};\\\", \\\"{x:817,y:799,t:1528139664813};\\\", \\\"{x:840,y:797,t:1528139664830};\\\", \\\"{x:862,y:796,t:1528139664846};\\\", \\\"{x:894,y:794,t:1528139664863};\\\", \\\"{x:920,y:791,t:1528139664880};\\\", \\\"{x:946,y:791,t:1528139664897};\\\", \\\"{x:968,y:789,t:1528139664914};\\\", \\\"{x:986,y:786,t:1528139664930};\\\", \\\"{x:1001,y:785,t:1528139664946};\\\", \\\"{x:1016,y:780,t:1528139664964};\\\", \\\"{x:1028,y:777,t:1528139664980};\\\", \\\"{x:1039,y:774,t:1528139664996};\\\", \\\"{x:1049,y:770,t:1528139665014};\\\", \\\"{x:1058,y:768,t:1528139665031};\\\", \\\"{x:1065,y:764,t:1528139665047};\\\", \\\"{x:1075,y:761,t:1528139665063};\\\", \\\"{x:1083,y:758,t:1528139665080};\\\", \\\"{x:1092,y:755,t:1528139665097};\\\", \\\"{x:1103,y:748,t:1528139665114};\\\", \\\"{x:1113,y:742,t:1528139665131};\\\", \\\"{x:1121,y:738,t:1528139665147};\\\", \\\"{x:1127,y:735,t:1528139665163};\\\", \\\"{x:1130,y:733,t:1528139665180};\\\", \\\"{x:1133,y:731,t:1528139665197};\\\", \\\"{x:1136,y:729,t:1528139665214};\\\", \\\"{x:1139,y:726,t:1528139665230};\\\", \\\"{x:1141,y:722,t:1528139665248};\\\", \\\"{x:1142,y:719,t:1528139665263};\\\", \\\"{x:1144,y:715,t:1528139665280};\\\", \\\"{x:1146,y:712,t:1528139665298};\\\", \\\"{x:1148,y:709,t:1528139665314};\\\", \\\"{x:1148,y:707,t:1528139665330};\\\", \\\"{x:1150,y:704,t:1528139665347};\\\", \\\"{x:1152,y:701,t:1528139665364};\\\", \\\"{x:1152,y:697,t:1528139665381};\\\", \\\"{x:1154,y:693,t:1528139665398};\\\", \\\"{x:1155,y:690,t:1528139665414};\\\", \\\"{x:1155,y:685,t:1528139665431};\\\", \\\"{x:1157,y:675,t:1528139665447};\\\", \\\"{x:1157,y:672,t:1528139665464};\\\", \\\"{x:1157,y:671,t:1528139665487};\\\", \\\"{x:1157,y:666,t:1528139665640};\\\", \\\"{x:1159,y:664,t:1528139665648};\\\", \\\"{x:1167,y:655,t:1528139665664};\\\", \\\"{x:1176,y:645,t:1528139665680};\\\", \\\"{x:1188,y:634,t:1528139665698};\\\", \\\"{x:1199,y:625,t:1528139665714};\\\", \\\"{x:1205,y:620,t:1528139665730};\\\", \\\"{x:1208,y:617,t:1528139665747};\\\", \\\"{x:1210,y:616,t:1528139665764};\\\", \\\"{x:1213,y:613,t:1528139665780};\\\", \\\"{x:1216,y:613,t:1528139665797};\\\", \\\"{x:1218,y:611,t:1528139665814};\\\", \\\"{x:1222,y:610,t:1528139665829};\\\", \\\"{x:1227,y:609,t:1528139665847};\\\", \\\"{x:1234,y:609,t:1528139665864};\\\", \\\"{x:1242,y:609,t:1528139665880};\\\", \\\"{x:1254,y:606,t:1528139665897};\\\", \\\"{x:1269,y:606,t:1528139665914};\\\", \\\"{x:1288,y:606,t:1528139665930};\\\", \\\"{x:1309,y:606,t:1528139665947};\\\", \\\"{x:1329,y:606,t:1528139665965};\\\", \\\"{x:1349,y:606,t:1528139665980};\\\", \\\"{x:1367,y:606,t:1528139665997};\\\", \\\"{x:1381,y:606,t:1528139666014};\\\", \\\"{x:1392,y:606,t:1528139666030};\\\", \\\"{x:1401,y:606,t:1528139666047};\\\", \\\"{x:1403,y:606,t:1528139666065};\\\", \\\"{x:1405,y:606,t:1528139666081};\\\", \\\"{x:1407,y:606,t:1528139666098};\\\", \\\"{x:1410,y:605,t:1528139666115};\\\", \\\"{x:1414,y:605,t:1528139666131};\\\", \\\"{x:1415,y:605,t:1528139666148};\\\", \\\"{x:1417,y:604,t:1528139666164};\\\", \\\"{x:1418,y:604,t:1528139666199};\\\", \\\"{x:1422,y:604,t:1528139666215};\\\", \\\"{x:1429,y:606,t:1528139666231};\\\", \\\"{x:1433,y:608,t:1528139666248};\\\", \\\"{x:1436,y:611,t:1528139666265};\\\", \\\"{x:1438,y:612,t:1528139666282};\\\", \\\"{x:1441,y:615,t:1528139666298};\\\", \\\"{x:1443,y:617,t:1528139666315};\\\", \\\"{x:1444,y:617,t:1528139666332};\\\", \\\"{x:1445,y:619,t:1528139666348};\\\", \\\"{x:1447,y:620,t:1528139666365};\\\", \\\"{x:1448,y:622,t:1528139666382};\\\", \\\"{x:1449,y:624,t:1528139666398};\\\", \\\"{x:1450,y:625,t:1528139666417};\\\", \\\"{x:1451,y:625,t:1528139666447};\\\", \\\"{x:1451,y:627,t:1528139666551};\\\", \\\"{x:1451,y:629,t:1528139666576};\\\", \\\"{x:1451,y:630,t:1528139666590};\\\", \\\"{x:1450,y:630,t:1528139667064};\\\", \\\"{x:1448,y:630,t:1528139667200};\\\", \\\"{x:1442,y:634,t:1528139667217};\\\", \\\"{x:1439,y:635,t:1528139667231};\\\", \\\"{x:1435,y:637,t:1528139667249};\\\", \\\"{x:1431,y:642,t:1528139667266};\\\", \\\"{x:1424,y:646,t:1528139667282};\\\", \\\"{x:1416,y:653,t:1528139667298};\\\", \\\"{x:1410,y:659,t:1528139667315};\\\", \\\"{x:1401,y:667,t:1528139667331};\\\", \\\"{x:1394,y:674,t:1528139667349};\\\", \\\"{x:1387,y:682,t:1528139667366};\\\", \\\"{x:1382,y:685,t:1528139667382};\\\", \\\"{x:1377,y:689,t:1528139667399};\\\", \\\"{x:1374,y:693,t:1528139667415};\\\", \\\"{x:1371,y:695,t:1528139667432};\\\", \\\"{x:1362,y:701,t:1528139667449};\\\", \\\"{x:1341,y:709,t:1528139667465};\\\", \\\"{x:1306,y:718,t:1528139667483};\\\", \\\"{x:1277,y:723,t:1528139667498};\\\", \\\"{x:1254,y:728,t:1528139667516};\\\", \\\"{x:1236,y:729,t:1528139667533};\\\", \\\"{x:1227,y:729,t:1528139667549};\\\", \\\"{x:1224,y:729,t:1528139667566};\\\", \\\"{x:1223,y:729,t:1528139667616};\\\", \\\"{x:1223,y:718,t:1528139667632};\\\", \\\"{x:1227,y:707,t:1528139667648};\\\", \\\"{x:1233,y:695,t:1528139667666};\\\", \\\"{x:1240,y:681,t:1528139667683};\\\", \\\"{x:1251,y:665,t:1528139667699};\\\", \\\"{x:1259,y:654,t:1528139667716};\\\", \\\"{x:1269,y:646,t:1528139667733};\\\", \\\"{x:1277,y:640,t:1528139667749};\\\", \\\"{x:1280,y:633,t:1528139667766};\\\", \\\"{x:1283,y:628,t:1528139667782};\\\", \\\"{x:1283,y:625,t:1528139667799};\\\", \\\"{x:1283,y:623,t:1528139667815};\\\", \\\"{x:1285,y:622,t:1528139667833};\\\", \\\"{x:1283,y:622,t:1528139667896};\\\", \\\"{x:1281,y:622,t:1528139667903};\\\", \\\"{x:1278,y:624,t:1528139667916};\\\", \\\"{x:1267,y:633,t:1528139667932};\\\", \\\"{x:1257,y:646,t:1528139667949};\\\", \\\"{x:1239,y:675,t:1528139667966};\\\", \\\"{x:1209,y:718,t:1528139667983};\\\", \\\"{x:1171,y:768,t:1528139667999};\\\", \\\"{x:1151,y:788,t:1528139668016};\\\", \\\"{x:1133,y:805,t:1528139668033};\\\", \\\"{x:1111,y:829,t:1528139668050};\\\", \\\"{x:1094,y:853,t:1528139668066};\\\", \\\"{x:1079,y:871,t:1528139668083};\\\", \\\"{x:1074,y:875,t:1528139668099};\\\", \\\"{x:1079,y:873,t:1528139668192};\\\", \\\"{x:1091,y:866,t:1528139668199};\\\", \\\"{x:1118,y:849,t:1528139668216};\\\", \\\"{x:1163,y:814,t:1528139668233};\\\", \\\"{x:1206,y:783,t:1528139668250};\\\", \\\"{x:1234,y:757,t:1528139668266};\\\", \\\"{x:1254,y:740,t:1528139668283};\\\", \\\"{x:1271,y:721,t:1528139668299};\\\", \\\"{x:1289,y:700,t:1528139668316};\\\", \\\"{x:1299,y:685,t:1528139668332};\\\", \\\"{x:1303,y:678,t:1528139668350};\\\", \\\"{x:1305,y:675,t:1528139668367};\\\", \\\"{x:1306,y:673,t:1528139668383};\\\", \\\"{x:1307,y:667,t:1528139668399};\\\", \\\"{x:1307,y:666,t:1528139668416};\\\", \\\"{x:1307,y:667,t:1528139668543};\\\", \\\"{x:1304,y:671,t:1528139668552};\\\", \\\"{x:1301,y:676,t:1528139668567};\\\", \\\"{x:1294,y:691,t:1528139668583};\\\", \\\"{x:1284,y:722,t:1528139668599};\\\", \\\"{x:1276,y:752,t:1528139668617};\\\", \\\"{x:1266,y:779,t:1528139668632};\\\", \\\"{x:1245,y:823,t:1528139668650};\\\", \\\"{x:1225,y:856,t:1528139668667};\\\", \\\"{x:1209,y:874,t:1528139668682};\\\", \\\"{x:1196,y:893,t:1528139668700};\\\", \\\"{x:1189,y:912,t:1528139668717};\\\", \\\"{x:1184,y:926,t:1528139668733};\\\", \\\"{x:1179,y:936,t:1528139668749};\\\", \\\"{x:1178,y:938,t:1528139668767};\\\", \\\"{x:1177,y:938,t:1528139668784};\\\", \\\"{x:1179,y:935,t:1528139668840};\\\", \\\"{x:1182,y:933,t:1528139668850};\\\", \\\"{x:1194,y:919,t:1528139668866};\\\", \\\"{x:1214,y:896,t:1528139668884};\\\", \\\"{x:1239,y:868,t:1528139668900};\\\", \\\"{x:1267,y:836,t:1528139668925};\\\", \\\"{x:1315,y:786,t:1528139668973};\\\", \\\"{x:1328,y:771,t:1528139668982};\\\", \\\"{x:1337,y:760,t:1528139668998};\\\", \\\"{x:1345,y:746,t:1528139669016};\\\", \\\"{x:1352,y:734,t:1528139669032};\\\", \\\"{x:1359,y:719,t:1528139669049};\\\", \\\"{x:1366,y:707,t:1528139669066};\\\", \\\"{x:1368,y:699,t:1528139669083};\\\", \\\"{x:1371,y:696,t:1528139669099};\\\", \\\"{x:1371,y:694,t:1528139669116};\\\", \\\"{x:1371,y:693,t:1528139669135};\\\", \\\"{x:1374,y:691,t:1528139669149};\\\", \\\"{x:1375,y:687,t:1528139669166};\\\", \\\"{x:1381,y:680,t:1528139669183};\\\", \\\"{x:1383,y:677,t:1528139669201};\\\", \\\"{x:1384,y:675,t:1528139669216};\\\", \\\"{x:1385,y:674,t:1528139669234};\\\", \\\"{x:1386,y:672,t:1528139669250};\\\", \\\"{x:1388,y:669,t:1528139669266};\\\", \\\"{x:1390,y:666,t:1528139669283};\\\", \\\"{x:1390,y:665,t:1528139669300};\\\", \\\"{x:1390,y:664,t:1528139669424};\\\", \\\"{x:1387,y:665,t:1528139669434};\\\", \\\"{x:1379,y:671,t:1528139669451};\\\", \\\"{x:1369,y:685,t:1528139669466};\\\", \\\"{x:1361,y:694,t:1528139669484};\\\", \\\"{x:1358,y:699,t:1528139669500};\\\", \\\"{x:1356,y:701,t:1528139669517};\\\", \\\"{x:1354,y:705,t:1528139669534};\\\", \\\"{x:1348,y:712,t:1528139669550};\\\", \\\"{x:1337,y:728,t:1528139669571};\\\", \\\"{x:1328,y:746,t:1528139669606};\\\", \\\"{x:1327,y:749,t:1528139669616};\\\", \\\"{x:1326,y:750,t:1528139669633};\\\", \\\"{x:1325,y:753,t:1528139669650};\\\", \\\"{x:1324,y:754,t:1528139669667};\\\", \\\"{x:1321,y:758,t:1528139669683};\\\", \\\"{x:1320,y:762,t:1528139669700};\\\", \\\"{x:1318,y:764,t:1528139669718};\\\", \\\"{x:1317,y:765,t:1528139669733};\\\", \\\"{x:1314,y:768,t:1528139669750};\\\", \\\"{x:1313,y:770,t:1528139669767};\\\", \\\"{x:1311,y:772,t:1528139669783};\\\", \\\"{x:1309,y:776,t:1528139669800};\\\", \\\"{x:1307,y:781,t:1528139669817};\\\", \\\"{x:1305,y:783,t:1528139669833};\\\", \\\"{x:1302,y:786,t:1528139669851};\\\", \\\"{x:1302,y:788,t:1528139669868};\\\", \\\"{x:1300,y:790,t:1528139669884};\\\", \\\"{x:1299,y:793,t:1528139669901};\\\", \\\"{x:1298,y:796,t:1528139669918};\\\", \\\"{x:1296,y:799,t:1528139669934};\\\", \\\"{x:1291,y:806,t:1528139669951};\\\", \\\"{x:1287,y:811,t:1528139669967};\\\", \\\"{x:1285,y:815,t:1528139669983};\\\", \\\"{x:1283,y:817,t:1528139670000};\\\", \\\"{x:1281,y:820,t:1528139670017};\\\", \\\"{x:1279,y:823,t:1528139670033};\\\", \\\"{x:1275,y:831,t:1528139670050};\\\", \\\"{x:1268,y:842,t:1528139670067};\\\", \\\"{x:1262,y:852,t:1528139670083};\\\", \\\"{x:1258,y:857,t:1528139670100};\\\", \\\"{x:1254,y:862,t:1528139670117};\\\", \\\"{x:1250,y:869,t:1528139670134};\\\", \\\"{x:1243,y:882,t:1528139670151};\\\", \\\"{x:1229,y:900,t:1528139670167};\\\", \\\"{x:1224,y:908,t:1528139670185};\\\", \\\"{x:1220,y:916,t:1528139670201};\\\", \\\"{x:1214,y:921,t:1528139670217};\\\", \\\"{x:1213,y:924,t:1528139670234};\\\", \\\"{x:1216,y:922,t:1528139670304};\\\", \\\"{x:1223,y:918,t:1528139670318};\\\", \\\"{x:1238,y:906,t:1528139670334};\\\", \\\"{x:1260,y:890,t:1528139670351};\\\", \\\"{x:1290,y:865,t:1528139670367};\\\", \\\"{x:1311,y:846,t:1528139670384};\\\", \\\"{x:1329,y:825,t:1528139670401};\\\", \\\"{x:1342,y:810,t:1528139670417};\\\", \\\"{x:1350,y:798,t:1528139670435};\\\", \\\"{x:1352,y:793,t:1528139670451};\\\", \\\"{x:1356,y:788,t:1528139670467};\\\", \\\"{x:1359,y:783,t:1528139670485};\\\", \\\"{x:1360,y:776,t:1528139670501};\\\", \\\"{x:1363,y:772,t:1528139670518};\\\", \\\"{x:1366,y:764,t:1528139670534};\\\", \\\"{x:1371,y:752,t:1528139670551};\\\", \\\"{x:1373,y:745,t:1528139670568};\\\", \\\"{x:1375,y:742,t:1528139670585};\\\", \\\"{x:1377,y:737,t:1528139670602};\\\", \\\"{x:1379,y:732,t:1528139670618};\\\", \\\"{x:1380,y:729,t:1528139670635};\\\", \\\"{x:1383,y:721,t:1528139670652};\\\", \\\"{x:1384,y:716,t:1528139670668};\\\", \\\"{x:1385,y:715,t:1528139670685};\\\", \\\"{x:1385,y:714,t:1528139670702};\\\", \\\"{x:1385,y:713,t:1528139670848};\\\", \\\"{x:1384,y:714,t:1528139670863};\\\", \\\"{x:1383,y:714,t:1528139670871};\\\", \\\"{x:1383,y:716,t:1528139670884};\\\", \\\"{x:1378,y:719,t:1528139670902};\\\", \\\"{x:1374,y:724,t:1528139670918};\\\", \\\"{x:1370,y:729,t:1528139670935};\\\", \\\"{x:1366,y:734,t:1528139670952};\\\", \\\"{x:1364,y:738,t:1528139670968};\\\", \\\"{x:1361,y:741,t:1528139670984};\\\", \\\"{x:1360,y:743,t:1528139671002};\\\", \\\"{x:1360,y:745,t:1528139671019};\\\", \\\"{x:1359,y:746,t:1528139671035};\\\", \\\"{x:1358,y:747,t:1528139671052};\\\", \\\"{x:1357,y:750,t:1528139671069};\\\", \\\"{x:1356,y:752,t:1528139671085};\\\", \\\"{x:1354,y:754,t:1528139671102};\\\", \\\"{x:1353,y:756,t:1528139671119};\\\", \\\"{x:1352,y:758,t:1528139671135};\\\", \\\"{x:1352,y:759,t:1528139671193};\\\", \\\"{x:1351,y:759,t:1528139671218};\\\", \\\"{x:1349,y:761,t:1528139671234};\\\", \\\"{x:1347,y:763,t:1528139671251};\\\", \\\"{x:1347,y:764,t:1528139671268};\\\", \\\"{x:1346,y:764,t:1528139671302};\\\", \\\"{x:1347,y:763,t:1528139671568};\\\", \\\"{x:1351,y:759,t:1528139671586};\\\", \\\"{x:1357,y:752,t:1528139671603};\\\", \\\"{x:1362,y:746,t:1528139671619};\\\", \\\"{x:1366,y:739,t:1528139671636};\\\", \\\"{x:1369,y:731,t:1528139671652};\\\", \\\"{x:1374,y:721,t:1528139671668};\\\", \\\"{x:1381,y:713,t:1528139671685};\\\", \\\"{x:1387,y:704,t:1528139671701};\\\", \\\"{x:1392,y:696,t:1528139671718};\\\", \\\"{x:1396,y:688,t:1528139671735};\\\", \\\"{x:1400,y:681,t:1528139671752};\\\", \\\"{x:1404,y:676,t:1528139671768};\\\", \\\"{x:1407,y:673,t:1528139671785};\\\", \\\"{x:1412,y:667,t:1528139671801};\\\", \\\"{x:1417,y:662,t:1528139671818};\\\", \\\"{x:1421,y:657,t:1528139671835};\\\", \\\"{x:1424,y:655,t:1528139671853};\\\", \\\"{x:1427,y:653,t:1528139671869};\\\", \\\"{x:1432,y:649,t:1528139671886};\\\", \\\"{x:1436,y:646,t:1528139671903};\\\", \\\"{x:1442,y:642,t:1528139671919};\\\", \\\"{x:1444,y:641,t:1528139671936};\\\", \\\"{x:1446,y:639,t:1528139671952};\\\", \\\"{x:1447,y:638,t:1528139671969};\\\", \\\"{x:1448,y:637,t:1528139671986};\\\", \\\"{x:1450,y:636,t:1528139672003};\\\", \\\"{x:1450,y:635,t:1528139672019};\\\", \\\"{x:1452,y:633,t:1528139672036};\\\", \\\"{x:1453,y:632,t:1528139672056};\\\", \\\"{x:1453,y:631,t:1528139672088};\\\", \\\"{x:1454,y:631,t:1528139672113};\\\", \\\"{x:1453,y:631,t:1528139672264};\\\", \\\"{x:1452,y:631,t:1528139672285};\\\", \\\"{x:1450,y:631,t:1528139672302};\\\", \\\"{x:1445,y:636,t:1528139672321};\\\", \\\"{x:1444,y:639,t:1528139672336};\\\", \\\"{x:1442,y:644,t:1528139672353};\\\", \\\"{x:1440,y:649,t:1528139672370};\\\", \\\"{x:1439,y:652,t:1528139672386};\\\", \\\"{x:1437,y:656,t:1528139672403};\\\", \\\"{x:1436,y:660,t:1528139672420};\\\", \\\"{x:1433,y:668,t:1528139672436};\\\", \\\"{x:1427,y:678,t:1528139672453};\\\", \\\"{x:1424,y:687,t:1528139672470};\\\", \\\"{x:1421,y:694,t:1528139672486};\\\", \\\"{x:1420,y:698,t:1528139672503};\\\", \\\"{x:1415,y:707,t:1528139672519};\\\", \\\"{x:1411,y:716,t:1528139672536};\\\", \\\"{x:1405,y:727,t:1528139672553};\\\", \\\"{x:1400,y:739,t:1528139672570};\\\", \\\"{x:1396,y:750,t:1528139672585};\\\", \\\"{x:1390,y:764,t:1528139672602};\\\", \\\"{x:1381,y:783,t:1528139672619};\\\", \\\"{x:1373,y:804,t:1528139672635};\\\", \\\"{x:1360,y:826,t:1528139672652};\\\", \\\"{x:1351,y:839,t:1528139672670};\\\", \\\"{x:1347,y:849,t:1528139672686};\\\", \\\"{x:1345,y:854,t:1528139672702};\\\", \\\"{x:1344,y:859,t:1528139672720};\\\", \\\"{x:1344,y:860,t:1528139672736};\\\", \\\"{x:1344,y:861,t:1528139672759};\\\", \\\"{x:1347,y:861,t:1528139672800};\\\", \\\"{x:1354,y:856,t:1528139672808};\\\", \\\"{x:1365,y:846,t:1528139672819};\\\", \\\"{x:1390,y:825,t:1528139672837};\\\", \\\"{x:1423,y:796,t:1528139672852};\\\", \\\"{x:1456,y:765,t:1528139672870};\\\", \\\"{x:1488,y:734,t:1528139672887};\\\", \\\"{x:1513,y:713,t:1528139672903};\\\", \\\"{x:1535,y:690,t:1528139672919};\\\", \\\"{x:1548,y:675,t:1528139672936};\\\", \\\"{x:1552,y:664,t:1528139672953};\\\", \\\"{x:1554,y:659,t:1528139672970};\\\", \\\"{x:1556,y:656,t:1528139672986};\\\", \\\"{x:1556,y:655,t:1528139673002};\\\", \\\"{x:1557,y:653,t:1528139673020};\\\", \\\"{x:1555,y:654,t:1528139673080};\\\", \\\"{x:1551,y:660,t:1528139673088};\\\", \\\"{x:1542,y:674,t:1528139673102};\\\", \\\"{x:1536,y:692,t:1528139673120};\\\", \\\"{x:1529,y:716,t:1528139673136};\\\", \\\"{x:1519,y:745,t:1528139673152};\\\", \\\"{x:1502,y:784,t:1528139673169};\\\", \\\"{x:1482,y:831,t:1528139673186};\\\", \\\"{x:1466,y:876,t:1528139673204};\\\", \\\"{x:1456,y:910,t:1528139673219};\\\", \\\"{x:1450,y:931,t:1528139673236};\\\", \\\"{x:1447,y:939,t:1528139673254};\\\", \\\"{x:1446,y:940,t:1528139673270};\\\", \\\"{x:1450,y:939,t:1528139673335};\\\", \\\"{x:1475,y:904,t:1528139673353};\\\", \\\"{x:1528,y:846,t:1528139673370};\\\", \\\"{x:1585,y:780,t:1528139673387};\\\", \\\"{x:1633,y:718,t:1528139673403};\\\", \\\"{x:1657,y:680,t:1528139673420};\\\", \\\"{x:1668,y:657,t:1528139673437};\\\", \\\"{x:1671,y:649,t:1528139673454};\\\", \\\"{x:1672,y:644,t:1528139673470};\\\", \\\"{x:1673,y:640,t:1528139673487};\\\", \\\"{x:1673,y:638,t:1528139673503};\\\", \\\"{x:1673,y:634,t:1528139673520};\\\", \\\"{x:1673,y:630,t:1528139673537};\\\", \\\"{x:1673,y:624,t:1528139673554};\\\", \\\"{x:1673,y:619,t:1528139673570};\\\", \\\"{x:1673,y:618,t:1528139673599};\\\", \\\"{x:1672,y:618,t:1528139673608};\\\", \\\"{x:1671,y:618,t:1528139673620};\\\", \\\"{x:1668,y:618,t:1528139673637};\\\", \\\"{x:1666,y:618,t:1528139673654};\\\", \\\"{x:1665,y:618,t:1528139673671};\\\", \\\"{x:1664,y:618,t:1528139673687};\\\", \\\"{x:1659,y:618,t:1528139673703};\\\", \\\"{x:1653,y:620,t:1528139673721};\\\", \\\"{x:1645,y:624,t:1528139673737};\\\", \\\"{x:1638,y:628,t:1528139673755};\\\", \\\"{x:1634,y:629,t:1528139673771};\\\", \\\"{x:1628,y:630,t:1528139673787};\\\", \\\"{x:1625,y:632,t:1528139673804};\\\", \\\"{x:1622,y:633,t:1528139673821};\\\", \\\"{x:1618,y:634,t:1528139673837};\\\", \\\"{x:1615,y:636,t:1528139673854};\\\", \\\"{x:1610,y:638,t:1528139673871};\\\", \\\"{x:1604,y:640,t:1528139673887};\\\", \\\"{x:1598,y:642,t:1528139673904};\\\", \\\"{x:1596,y:642,t:1528139673960};\\\", \\\"{x:1594,y:642,t:1528139673977};\\\", \\\"{x:1593,y:642,t:1528139673992};\\\", \\\"{x:1592,y:642,t:1528139674119};\\\", \\\"{x:1590,y:642,t:1528139674126};\\\", \\\"{x:1588,y:641,t:1528139674137};\\\", \\\"{x:1588,y:640,t:1528139674153};\\\", \\\"{x:1585,y:639,t:1528139674171};\\\", \\\"{x:1583,y:639,t:1528139674199};\\\", \\\"{x:1582,y:639,t:1528139674223};\\\", \\\"{x:1580,y:639,t:1528139674279};\\\", \\\"{x:1579,y:639,t:1528139674303};\\\", \\\"{x:1579,y:638,t:1528139674648};\\\", \\\"{x:1579,y:637,t:1528139674656};\\\", \\\"{x:1579,y:636,t:1528139674670};\\\", \\\"{x:1580,y:633,t:1528139674688};\\\", \\\"{x:1581,y:632,t:1528139674704};\\\", \\\"{x:1580,y:633,t:1528139674840};\\\", \\\"{x:1578,y:637,t:1528139674857};\\\", \\\"{x:1575,y:640,t:1528139674871};\\\", \\\"{x:1571,y:647,t:1528139674887};\\\", \\\"{x:1570,y:650,t:1528139674905};\\\", \\\"{x:1567,y:655,t:1528139674921};\\\", \\\"{x:1564,y:660,t:1528139674938};\\\", \\\"{x:1560,y:666,t:1528139674955};\\\", \\\"{x:1556,y:672,t:1528139674971};\\\", \\\"{x:1551,y:679,t:1528139674987};\\\", \\\"{x:1549,y:683,t:1528139675004};\\\", \\\"{x:1545,y:690,t:1528139675021};\\\", \\\"{x:1543,y:695,t:1528139675038};\\\", \\\"{x:1537,y:704,t:1528139675055};\\\", \\\"{x:1534,y:710,t:1528139675071};\\\", \\\"{x:1530,y:715,t:1528139675087};\\\", \\\"{x:1526,y:721,t:1528139675105};\\\", \\\"{x:1521,y:730,t:1528139675121};\\\", \\\"{x:1517,y:737,t:1528139675137};\\\", \\\"{x:1514,y:742,t:1528139675154};\\\", \\\"{x:1514,y:743,t:1528139675172};\\\", \\\"{x:1514,y:744,t:1528139675188};\\\", \\\"{x:1513,y:746,t:1528139675205};\\\", \\\"{x:1511,y:751,t:1528139675222};\\\", \\\"{x:1509,y:759,t:1528139675239};\\\", \\\"{x:1509,y:761,t:1528139675256};\\\", \\\"{x:1509,y:764,t:1528139675271};\\\", \\\"{x:1508,y:766,t:1528139675289};\\\", \\\"{x:1508,y:768,t:1528139675312};\\\", \\\"{x:1508,y:769,t:1528139675343};\\\", \\\"{x:1508,y:772,t:1528139676048};\\\", \\\"{x:1508,y:773,t:1528139676055};\\\", \\\"{x:1507,y:776,t:1528139676072};\\\", \\\"{x:1507,y:778,t:1528139676089};\\\", \\\"{x:1506,y:780,t:1528139676106};\\\", \\\"{x:1505,y:783,t:1528139676123};\\\", \\\"{x:1503,y:788,t:1528139676139};\\\", \\\"{x:1501,y:797,t:1528139676156};\\\", \\\"{x:1498,y:806,t:1528139676173};\\\", \\\"{x:1497,y:813,t:1528139676189};\\\", \\\"{x:1494,y:819,t:1528139676206};\\\", \\\"{x:1493,y:823,t:1528139676222};\\\", \\\"{x:1491,y:827,t:1528139676240};\\\", \\\"{x:1490,y:828,t:1528139676264};\\\", \\\"{x:1489,y:828,t:1528139676552};\\\", \\\"{x:1483,y:830,t:1528139676560};\\\", \\\"{x:1478,y:830,t:1528139676573};\\\", \\\"{x:1453,y:830,t:1528139676590};\\\", \\\"{x:1397,y:830,t:1528139676606};\\\", \\\"{x:1335,y:830,t:1528139676624};\\\", \\\"{x:1297,y:820,t:1528139676639};\\\", \\\"{x:1250,y:791,t:1528139676656};\\\", \\\"{x:1176,y:745,t:1528139676672};\\\", \\\"{x:1105,y:705,t:1528139676688};\\\", \\\"{x:1044,y:667,t:1528139676706};\\\", \\\"{x:1005,y:642,t:1528139676722};\\\", \\\"{x:959,y:617,t:1528139676740};\\\", \\\"{x:926,y:598,t:1528139676755};\\\", \\\"{x:906,y:585,t:1528139676773};\\\", \\\"{x:886,y:575,t:1528139676789};\\\", \\\"{x:875,y:569,t:1528139676805};\\\", \\\"{x:870,y:568,t:1528139676823};\\\", \\\"{x:868,y:567,t:1528139676839};\\\", \\\"{x:862,y:567,t:1528139676855};\\\", \\\"{x:850,y:567,t:1528139676873};\\\", \\\"{x:828,y:571,t:1528139676890};\\\", \\\"{x:811,y:571,t:1528139676905};\\\", \\\"{x:810,y:571,t:1528139676922};\\\", \\\"{x:810,y:572,t:1528139676991};\\\", \\\"{x:813,y:574,t:1528139677006};\\\", \\\"{x:819,y:576,t:1528139677023};\\\", \\\"{x:822,y:578,t:1528139677040};\\\", \\\"{x:822,y:579,t:1528139677057};\\\", \\\"{x:823,y:580,t:1528139677171};\\\", \\\"{x:824,y:580,t:1528139677235};\\\", \\\"{x:825,y:578,t:1528139677250};\\\", \\\"{x:826,y:578,t:1528139677260};\\\", \\\"{x:827,y:577,t:1528139677276};\\\", \\\"{x:828,y:576,t:1528139677293};\\\", \\\"{x:827,y:576,t:1528139677457};\\\", \\\"{x:822,y:576,t:1528139677466};\\\", \\\"{x:818,y:577,t:1528139677477};\\\", \\\"{x:802,y:581,t:1528139677493};\\\", \\\"{x:788,y:585,t:1528139677509};\\\", \\\"{x:776,y:587,t:1528139677526};\\\", \\\"{x:764,y:591,t:1528139677542};\\\", \\\"{x:751,y:594,t:1528139677560};\\\", \\\"{x:734,y:600,t:1528139677577};\\\", \\\"{x:712,y:606,t:1528139677594};\\\", \\\"{x:676,y:613,t:1528139677609};\\\", \\\"{x:647,y:615,t:1528139677626};\\\", \\\"{x:616,y:621,t:1528139677643};\\\", \\\"{x:592,y:626,t:1528139677660};\\\", \\\"{x:577,y:631,t:1528139677677};\\\", \\\"{x:558,y:635,t:1528139677694};\\\", \\\"{x:543,y:639,t:1528139677710};\\\", \\\"{x:534,y:640,t:1528139677727};\\\", \\\"{x:527,y:643,t:1528139677743};\\\", \\\"{x:524,y:644,t:1528139677760};\\\", \\\"{x:515,y:645,t:1528139677777};\\\", \\\"{x:496,y:645,t:1528139677794};\\\", \\\"{x:458,y:645,t:1528139677810};\\\", \\\"{x:431,y:645,t:1528139677826};\\\", \\\"{x:403,y:642,t:1528139677844};\\\", \\\"{x:377,y:638,t:1528139677860};\\\", \\\"{x:343,y:632,t:1528139677877};\\\", \\\"{x:313,y:631,t:1528139677894};\\\", \\\"{x:298,y:631,t:1528139677909};\\\", \\\"{x:286,y:633,t:1528139677927};\\\", \\\"{x:276,y:636,t:1528139677943};\\\", \\\"{x:271,y:636,t:1528139677959};\\\", \\\"{x:262,y:637,t:1528139677977};\\\", \\\"{x:250,y:642,t:1528139677995};\\\", \\\"{x:237,y:645,t:1528139678009};\\\", \\\"{x:220,y:645,t:1528139678027};\\\", \\\"{x:210,y:645,t:1528139678044};\\\", \\\"{x:209,y:645,t:1528139678066};\\\", \\\"{x:208,y:645,t:1528139678099};\\\", \\\"{x:208,y:643,t:1528139678110};\\\", \\\"{x:210,y:641,t:1528139678127};\\\", \\\"{x:213,y:638,t:1528139678146};\\\", \\\"{x:218,y:634,t:1528139678160};\\\", \\\"{x:229,y:628,t:1528139678177};\\\", \\\"{x:251,y:619,t:1528139678193};\\\", \\\"{x:272,y:615,t:1528139678209};\\\", \\\"{x:298,y:612,t:1528139678227};\\\", \\\"{x:343,y:605,t:1528139678244};\\\", \\\"{x:377,y:600,t:1528139678260};\\\", \\\"{x:406,y:599,t:1528139678277};\\\", \\\"{x:433,y:599,t:1528139678294};\\\", \\\"{x:455,y:599,t:1528139678310};\\\", \\\"{x:473,y:597,t:1528139678326};\\\", \\\"{x:492,y:597,t:1528139678344};\\\", \\\"{x:507,y:597,t:1528139678361};\\\", \\\"{x:515,y:599,t:1528139678377};\\\", \\\"{x:530,y:603,t:1528139678395};\\\", \\\"{x:538,y:607,t:1528139678411};\\\", \\\"{x:540,y:607,t:1528139678427};\\\", \\\"{x:541,y:607,t:1528139678762};\\\", \\\"{x:543,y:607,t:1528139678782};\\\", \\\"{x:546,y:605,t:1528139678794};\\\", \\\"{x:549,y:602,t:1528139678811};\\\", \\\"{x:554,y:598,t:1528139678830};\\\", \\\"{x:560,y:594,t:1528139678845};\\\", \\\"{x:563,y:590,t:1528139678861};\\\", \\\"{x:567,y:587,t:1528139678878};\\\", \\\"{x:571,y:583,t:1528139678893};\\\", \\\"{x:576,y:578,t:1528139678910};\\\", \\\"{x:585,y:570,t:1528139678928};\\\", \\\"{x:590,y:561,t:1528139678944};\\\", \\\"{x:595,y:555,t:1528139678962};\\\", \\\"{x:597,y:553,t:1528139678978};\\\", \\\"{x:599,y:550,t:1528139678994};\\\", \\\"{x:602,y:547,t:1528139679011};\\\", \\\"{x:603,y:543,t:1528139679027};\\\", \\\"{x:604,y:541,t:1528139679044};\\\", \\\"{x:605,y:538,t:1528139679061};\\\", \\\"{x:608,y:531,t:1528139679077};\\\", \\\"{x:609,y:528,t:1528139679096};\\\", \\\"{x:609,y:527,t:1528139679111};\\\", \\\"{x:610,y:527,t:1528139679128};\\\", \\\"{x:610,y:525,t:1528139679145};\\\", \\\"{x:610,y:526,t:1528139679210};\\\", \\\"{x:610,y:533,t:1528139679229};\\\", \\\"{x:613,y:546,t:1528139679245};\\\", \\\"{x:618,y:563,t:1528139679263};\\\", \\\"{x:621,y:572,t:1528139679278};\\\", \\\"{x:623,y:577,t:1528139679294};\\\", \\\"{x:623,y:580,t:1528139679310};\\\", \\\"{x:623,y:585,t:1528139679327};\\\", \\\"{x:623,y:587,t:1528139679344};\\\", \\\"{x:623,y:590,t:1528139679361};\\\", \\\"{x:623,y:589,t:1528139679514};\\\", \\\"{x:623,y:588,t:1528139679538};\\\", \\\"{x:618,y:592,t:1528139679811};\\\", \\\"{x:604,y:604,t:1528139679828};\\\", \\\"{x:591,y:617,t:1528139679843};\\\", \\\"{x:582,y:628,t:1528139679862};\\\", \\\"{x:576,y:636,t:1528139679878};\\\", \\\"{x:572,y:640,t:1528139679895};\\\", \\\"{x:569,y:645,t:1528139679912};\\\", \\\"{x:566,y:653,t:1528139679928};\\\", \\\"{x:564,y:656,t:1528139679945};\\\", \\\"{x:561,y:663,t:1528139679962};\\\", \\\"{x:556,y:669,t:1528139679979};\\\", \\\"{x:549,y:678,t:1528139679994};\\\", \\\"{x:541,y:687,t:1528139680011};\\\", \\\"{x:534,y:693,t:1528139680029};\\\", \\\"{x:531,y:697,t:1528139680045};\\\", \\\"{x:529,y:699,t:1528139680061};\\\", \\\"{x:531,y:697,t:1528139680121};\\\", \\\"{x:538,y:689,t:1528139680129};\\\", \\\"{x:550,y:671,t:1528139680145};\\\", \\\"{x:604,y:609,t:1528139680162};\\\", \\\"{x:627,y:577,t:1528139680180};\\\", \\\"{x:640,y:557,t:1528139680195};\\\", \\\"{x:653,y:540,t:1528139680212};\\\", \\\"{x:662,y:523,t:1528139680230};\\\", \\\"{x:665,y:515,t:1528139680245};\\\", \\\"{x:666,y:513,t:1528139680262};\\\", \\\"{x:667,y:511,t:1528139680279};\\\", \\\"{x:665,y:511,t:1528139680330};\\\", \\\"{x:654,y:519,t:1528139680347};\\\", \\\"{x:644,y:533,t:1528139680363};\\\", \\\"{x:638,y:542,t:1528139680380};\\\", \\\"{x:634,y:550,t:1528139680395};\\\", \\\"{x:632,y:554,t:1528139680413};\\\", \\\"{x:630,y:562,t:1528139680429};\\\", \\\"{x:625,y:571,t:1528139680446};\\\", \\\"{x:622,y:577,t:1528139680462};\\\", \\\"{x:621,y:579,t:1528139680478};\\\", \\\"{x:620,y:579,t:1528139680581};\\\", \\\"{x:619,y:579,t:1528139680597};\\\", \\\"{x:618,y:579,t:1528139680659};\\\", \\\"{x:617,y:578,t:1528139680690};\\\", \\\"{x:617,y:578,t:1528139680777};\\\", \\\"{x:617,y:579,t:1528139684547};\\\", \\\"{x:615,y:581,t:1528139684556};\\\", \\\"{x:615,y:583,t:1528139684572};\\\", \\\"{x:615,y:584,t:1528139684589};\\\", \\\"{x:614,y:586,t:1528139684605};\\\", \\\"{x:613,y:588,t:1528139684658};\\\", \\\"{x:612,y:590,t:1528139684675};\\\", \\\"{x:611,y:590,t:1528139684690};\\\", \\\"{x:609,y:595,t:1528139684707};\\\", \\\"{x:606,y:602,t:1528139684723};\\\", \\\"{x:604,y:606,t:1528139684739};\\\", \\\"{x:601,y:609,t:1528139684755};\\\", \\\"{x:599,y:614,t:1528139684772};\\\", \\\"{x:595,y:619,t:1528139684782};\\\", \\\"{x:592,y:628,t:1528139684798};\\\", \\\"{x:586,y:641,t:1528139684816};\\\", \\\"{x:580,y:651,t:1528139684832};\\\", \\\"{x:575,y:662,t:1528139684849};\\\", \\\"{x:566,y:676,t:1528139684865};\\\", \\\"{x:563,y:683,t:1528139684882};\\\", \\\"{x:559,y:688,t:1528139684899};\\\", \\\"{x:557,y:692,t:1528139684916};\\\", \\\"{x:554,y:698,t:1528139684932};\\\", \\\"{x:548,y:705,t:1528139684949};\\\", \\\"{x:545,y:709,t:1528139684967};\\\", \\\"{x:542,y:714,t:1528139684983};\\\", \\\"{x:540,y:717,t:1528139684999};\\\", \\\"{x:538,y:719,t:1528139685017};\\\", \\\"{x:538,y:723,t:1528139685034};\\\", \\\"{x:534,y:727,t:1528139685049};\\\", \\\"{x:531,y:735,t:1528139685066};\\\", \\\"{x:530,y:735,t:1528139685082};\\\" ] }, { \\\"rt\\\": 95873, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 527893, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -G -B -B -B -B -F -F -F -09 AM-10 AM-B -B -B -B -B -F -F -G -C -C -B -B -G -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:736,t:1528139691082};\\\", \\\"{x:534,y:712,t:1528139691107};\\\", \\\"{x:534,y:697,t:1528139691120};\\\", \\\"{x:537,y:679,t:1528139691137};\\\", \\\"{x:539,y:660,t:1528139691154};\\\", \\\"{x:542,y:650,t:1528139691172};\\\", \\\"{x:542,y:641,t:1528139691187};\\\", \\\"{x:542,y:635,t:1528139691204};\\\", \\\"{x:542,y:631,t:1528139691222};\\\", \\\"{x:542,y:628,t:1528139691237};\\\", \\\"{x:542,y:625,t:1528139691254};\\\", \\\"{x:543,y:624,t:1528139691270};\\\", \\\"{x:545,y:621,t:1528139691288};\\\", \\\"{x:547,y:614,t:1528139691304};\\\", \\\"{x:550,y:607,t:1528139691321};\\\", \\\"{x:551,y:605,t:1528139691595};\\\", \\\"{x:552,y:600,t:1528139691606};\\\", \\\"{x:552,y:582,t:1528139691621};\\\", \\\"{x:552,y:560,t:1528139691638};\\\", \\\"{x:552,y:540,t:1528139691655};\\\", \\\"{x:552,y:526,t:1528139691671};\\\", \\\"{x:552,y:519,t:1528139691688};\\\", \\\"{x:552,y:512,t:1528139691705};\\\", \\\"{x:552,y:503,t:1528139691721};\\\", \\\"{x:554,y:499,t:1528139691737};\\\", \\\"{x:557,y:494,t:1528139691755};\\\", \\\"{x:562,y:486,t:1528139691772};\\\", \\\"{x:564,y:479,t:1528139691788};\\\", \\\"{x:571,y:473,t:1528139691804};\\\", \\\"{x:576,y:466,t:1528139691821};\\\", \\\"{x:579,y:462,t:1528139691838};\\\", \\\"{x:581,y:460,t:1528139691854};\\\", \\\"{x:583,y:458,t:1528139691872};\\\", \\\"{x:584,y:457,t:1528139691887};\\\", \\\"{x:584,y:456,t:1528139691906};\\\", \\\"{x:586,y:456,t:1528139691922};\\\", \\\"{x:586,y:455,t:1528139691937};\\\", \\\"{x:586,y:454,t:1528139692643};\\\", \\\"{x:591,y:453,t:1528139692654};\\\", \\\"{x:616,y:452,t:1528139692671};\\\", \\\"{x:661,y:452,t:1528139692688};\\\", \\\"{x:736,y:452,t:1528139692705};\\\", \\\"{x:803,y:452,t:1528139692721};\\\", \\\"{x:928,y:466,t:1528139692738};\\\", \\\"{x:1025,y:475,t:1528139692755};\\\", \\\"{x:1119,y:477,t:1528139692771};\\\", \\\"{x:1214,y:477,t:1528139692788};\\\", \\\"{x:1289,y:477,t:1528139692805};\\\", \\\"{x:1353,y:477,t:1528139692822};\\\", \\\"{x:1417,y:477,t:1528139692838};\\\", \\\"{x:1457,y:477,t:1528139692855};\\\", \\\"{x:1485,y:477,t:1528139692872};\\\", \\\"{x:1502,y:477,t:1528139692888};\\\", \\\"{x:1503,y:477,t:1528139692905};\\\", \\\"{x:1504,y:477,t:1528139692921};\\\", \\\"{x:1504,y:473,t:1528139693339};\\\", \\\"{x:1500,y:465,t:1528139693354};\\\", \\\"{x:1496,y:457,t:1528139693370};\\\", \\\"{x:1492,y:450,t:1528139693388};\\\", \\\"{x:1488,y:442,t:1528139693403};\\\", \\\"{x:1483,y:435,t:1528139693421};\\\", \\\"{x:1478,y:428,t:1528139693438};\\\", \\\"{x:1473,y:421,t:1528139693454};\\\", \\\"{x:1464,y:415,t:1528139693471};\\\", \\\"{x:1455,y:410,t:1528139693487};\\\", \\\"{x:1447,y:406,t:1528139693503};\\\", \\\"{x:1443,y:404,t:1528139693521};\\\", \\\"{x:1433,y:400,t:1528139693537};\\\", \\\"{x:1424,y:399,t:1528139693554};\\\", \\\"{x:1413,y:397,t:1528139693571};\\\", \\\"{x:1400,y:395,t:1528139693588};\\\", \\\"{x:1388,y:395,t:1528139693605};\\\", \\\"{x:1378,y:396,t:1528139693621};\\\", \\\"{x:1368,y:396,t:1528139693638};\\\", \\\"{x:1356,y:398,t:1528139693654};\\\", \\\"{x:1341,y:399,t:1528139693672};\\\", \\\"{x:1325,y:402,t:1528139693688};\\\", \\\"{x:1309,y:404,t:1528139693705};\\\", \\\"{x:1297,y:408,t:1528139693721};\\\", \\\"{x:1283,y:413,t:1528139693738};\\\", \\\"{x:1276,y:416,t:1528139693755};\\\", \\\"{x:1272,y:417,t:1528139693771};\\\", \\\"{x:1268,y:418,t:1528139693788};\\\", \\\"{x:1264,y:420,t:1528139693804};\\\", \\\"{x:1258,y:422,t:1528139693822};\\\", \\\"{x:1252,y:424,t:1528139693838};\\\", \\\"{x:1246,y:425,t:1528139693855};\\\", \\\"{x:1242,y:426,t:1528139693871};\\\", \\\"{x:1238,y:426,t:1528139693888};\\\", \\\"{x:1233,y:426,t:1528139693904};\\\", \\\"{x:1232,y:426,t:1528139693921};\\\", \\\"{x:1231,y:426,t:1528139693938};\\\", \\\"{x:1230,y:426,t:1528139693955};\\\", \\\"{x:1228,y:426,t:1528139693972};\\\", \\\"{x:1226,y:426,t:1528139693988};\\\", \\\"{x:1225,y:426,t:1528139694004};\\\", \\\"{x:1224,y:426,t:1528139694021};\\\", \\\"{x:1222,y:424,t:1528139694038};\\\", \\\"{x:1222,y:422,t:1528139694059};\\\", \\\"{x:1221,y:421,t:1528139694071};\\\", \\\"{x:1220,y:418,t:1528139694087};\\\", \\\"{x:1219,y:417,t:1528139694104};\\\", \\\"{x:1219,y:415,t:1528139694121};\\\", \\\"{x:1218,y:415,t:1528139694235};\\\", \\\"{x:1215,y:415,t:1528139694243};\\\", \\\"{x:1212,y:415,t:1528139694255};\\\", \\\"{x:1207,y:418,t:1528139694271};\\\", \\\"{x:1201,y:421,t:1528139694288};\\\", \\\"{x:1197,y:424,t:1528139694304};\\\", \\\"{x:1191,y:428,t:1528139694322};\\\", \\\"{x:1188,y:432,t:1528139694337};\\\", \\\"{x:1183,y:437,t:1528139694354};\\\", \\\"{x:1182,y:441,t:1528139694370};\\\", \\\"{x:1181,y:446,t:1528139694387};\\\", \\\"{x:1180,y:452,t:1528139694404};\\\", \\\"{x:1180,y:457,t:1528139694420};\\\", \\\"{x:1180,y:462,t:1528139694437};\\\", \\\"{x:1179,y:465,t:1528139694454};\\\", \\\"{x:1179,y:467,t:1528139694471};\\\", \\\"{x:1179,y:468,t:1528139694487};\\\", \\\"{x:1179,y:471,t:1528139694504};\\\", \\\"{x:1179,y:472,t:1528139694521};\\\", \\\"{x:1179,y:474,t:1528139694537};\\\", \\\"{x:1179,y:477,t:1528139694555};\\\", \\\"{x:1179,y:478,t:1528139696627};\\\", \\\"{x:1179,y:480,t:1528139696636};\\\", \\\"{x:1179,y:483,t:1528139696653};\\\", \\\"{x:1179,y:485,t:1528139696670};\\\", \\\"{x:1180,y:486,t:1528139696687};\\\", \\\"{x:1181,y:487,t:1528139696702};\\\", \\\"{x:1182,y:488,t:1528139696720};\\\", \\\"{x:1183,y:488,t:1528139696735};\\\", \\\"{x:1184,y:488,t:1528139696752};\\\", \\\"{x:1186,y:495,t:1528139696770};\\\", \\\"{x:1187,y:498,t:1528139696785};\\\", \\\"{x:1187,y:499,t:1528139696803};\\\", \\\"{x:1188,y:500,t:1528139696866};\\\", \\\"{x:1189,y:500,t:1528139696891};\\\", \\\"{x:1192,y:500,t:1528139696903};\\\", \\\"{x:1201,y:497,t:1528139696920};\\\", \\\"{x:1209,y:495,t:1528139696936};\\\", \\\"{x:1217,y:493,t:1528139696953};\\\", \\\"{x:1232,y:492,t:1528139696970};\\\", \\\"{x:1245,y:492,t:1528139696986};\\\", \\\"{x:1267,y:492,t:1528139697003};\\\", \\\"{x:1289,y:493,t:1528139697020};\\\", \\\"{x:1309,y:495,t:1528139697036};\\\", \\\"{x:1333,y:499,t:1528139697053};\\\", \\\"{x:1348,y:501,t:1528139697070};\\\", \\\"{x:1362,y:504,t:1528139697087};\\\", \\\"{x:1371,y:505,t:1528139697103};\\\", \\\"{x:1384,y:505,t:1528139697120};\\\", \\\"{x:1397,y:505,t:1528139697137};\\\", \\\"{x:1407,y:505,t:1528139697154};\\\", \\\"{x:1416,y:506,t:1528139697170};\\\", \\\"{x:1421,y:508,t:1528139697186};\\\", \\\"{x:1427,y:509,t:1528139697203};\\\", \\\"{x:1431,y:509,t:1528139697221};\\\", \\\"{x:1436,y:509,t:1528139697237};\\\", \\\"{x:1441,y:509,t:1528139697254};\\\", \\\"{x:1444,y:509,t:1528139697270};\\\", \\\"{x:1448,y:509,t:1528139697286};\\\", \\\"{x:1450,y:509,t:1528139697303};\\\", \\\"{x:1451,y:509,t:1528139697322};\\\", \\\"{x:1452,y:509,t:1528139697339};\\\", \\\"{x:1454,y:509,t:1528139697355};\\\", \\\"{x:1459,y:509,t:1528139697371};\\\", \\\"{x:1464,y:508,t:1528139697386};\\\", \\\"{x:1470,y:507,t:1528139697403};\\\", \\\"{x:1475,y:506,t:1528139697421};\\\", \\\"{x:1481,y:506,t:1528139697436};\\\", \\\"{x:1487,y:504,t:1528139697453};\\\", \\\"{x:1500,y:501,t:1528139697471};\\\", \\\"{x:1515,y:499,t:1528139697487};\\\", \\\"{x:1531,y:498,t:1528139697503};\\\", \\\"{x:1546,y:498,t:1528139697519};\\\", \\\"{x:1554,y:498,t:1528139697537};\\\", \\\"{x:1562,y:498,t:1528139697553};\\\", \\\"{x:1566,y:498,t:1528139697569};\\\", \\\"{x:1574,y:498,t:1528139697586};\\\", \\\"{x:1579,y:498,t:1528139697605};\\\", \\\"{x:1580,y:498,t:1528139697619};\\\", \\\"{x:1578,y:499,t:1528139697722};\\\", \\\"{x:1576,y:501,t:1528139697737};\\\", \\\"{x:1568,y:503,t:1528139697753};\\\", \\\"{x:1559,y:507,t:1528139697769};\\\", \\\"{x:1545,y:511,t:1528139697786};\\\", \\\"{x:1539,y:512,t:1528139697803};\\\", \\\"{x:1528,y:516,t:1528139697819};\\\", \\\"{x:1518,y:518,t:1528139697836};\\\", \\\"{x:1507,y:521,t:1528139697854};\\\", \\\"{x:1495,y:524,t:1528139697869};\\\", \\\"{x:1486,y:526,t:1528139697886};\\\", \\\"{x:1477,y:529,t:1528139697902};\\\", \\\"{x:1468,y:532,t:1528139697919};\\\", \\\"{x:1457,y:537,t:1528139697936};\\\", \\\"{x:1447,y:542,t:1528139697953};\\\", \\\"{x:1441,y:543,t:1528139697969};\\\", \\\"{x:1434,y:544,t:1528139697986};\\\", \\\"{x:1430,y:544,t:1528139698003};\\\", \\\"{x:1427,y:544,t:1528139698020};\\\", \\\"{x:1422,y:544,t:1528139698036};\\\", \\\"{x:1418,y:544,t:1528139698053};\\\", \\\"{x:1414,y:544,t:1528139698069};\\\", \\\"{x:1409,y:542,t:1528139698087};\\\", \\\"{x:1403,y:538,t:1528139698104};\\\", \\\"{x:1396,y:535,t:1528139698119};\\\", \\\"{x:1391,y:532,t:1528139698136};\\\", \\\"{x:1388,y:532,t:1528139698153};\\\", \\\"{x:1387,y:532,t:1528139698169};\\\", \\\"{x:1389,y:530,t:1528139706761};\\\", \\\"{x:1396,y:528,t:1528139706770};\\\", \\\"{x:1398,y:528,t:1528139706783};\\\", \\\"{x:1409,y:528,t:1528139706799};\\\", \\\"{x:1419,y:527,t:1528139706816};\\\", \\\"{x:1429,y:527,t:1528139706834};\\\", \\\"{x:1440,y:527,t:1528139706850};\\\", \\\"{x:1457,y:527,t:1528139706866};\\\", \\\"{x:1471,y:527,t:1528139706883};\\\", \\\"{x:1480,y:527,t:1528139706900};\\\", \\\"{x:1487,y:527,t:1528139706916};\\\", \\\"{x:1491,y:527,t:1528139706932};\\\", \\\"{x:1493,y:527,t:1528139706950};\\\", \\\"{x:1494,y:527,t:1528139706967};\\\", \\\"{x:1497,y:526,t:1528139706984};\\\", \\\"{x:1500,y:525,t:1528139707000};\\\", \\\"{x:1501,y:525,t:1528139707017};\\\", \\\"{x:1505,y:525,t:1528139707033};\\\", \\\"{x:1508,y:524,t:1528139707050};\\\", \\\"{x:1515,y:523,t:1528139707067};\\\", \\\"{x:1519,y:523,t:1528139707083};\\\", \\\"{x:1520,y:523,t:1528139707099};\\\", \\\"{x:1522,y:523,t:1528139707117};\\\", \\\"{x:1524,y:523,t:1528139707132};\\\", \\\"{x:1527,y:523,t:1528139707149};\\\", \\\"{x:1531,y:523,t:1528139707166};\\\", \\\"{x:1534,y:523,t:1528139707182};\\\", \\\"{x:1535,y:523,t:1528139707242};\\\", \\\"{x:1536,y:523,t:1528139707451};\\\", \\\"{x:1538,y:526,t:1528139707467};\\\", \\\"{x:1540,y:530,t:1528139707483};\\\", \\\"{x:1541,y:533,t:1528139707500};\\\", \\\"{x:1543,y:537,t:1528139707517};\\\", \\\"{x:1545,y:539,t:1528139707532};\\\", \\\"{x:1547,y:542,t:1528139707550};\\\", \\\"{x:1548,y:543,t:1528139707570};\\\", \\\"{x:1548,y:544,t:1528139707587};\\\", \\\"{x:1549,y:545,t:1528139707611};\\\", \\\"{x:1549,y:547,t:1528139707626};\\\", \\\"{x:1549,y:548,t:1528139707650};\\\", \\\"{x:1550,y:548,t:1528139707667};\\\", \\\"{x:1550,y:549,t:1528139707690};\\\", \\\"{x:1550,y:550,t:1528139707706};\\\", \\\"{x:1550,y:551,t:1528139707722};\\\", \\\"{x:1550,y:552,t:1528139707787};\\\", \\\"{x:1551,y:552,t:1528139707800};\\\", \\\"{x:1551,y:553,t:1528139707817};\\\", \\\"{x:1551,y:554,t:1528139707833};\\\", \\\"{x:1551,y:555,t:1528139707850};\\\", \\\"{x:1551,y:556,t:1528139707866};\\\", \\\"{x:1551,y:557,t:1528139707947};\\\", \\\"{x:1550,y:561,t:1528139708523};\\\", \\\"{x:1546,y:566,t:1528139708533};\\\", \\\"{x:1538,y:578,t:1528139708550};\\\", \\\"{x:1527,y:590,t:1528139708566};\\\", \\\"{x:1517,y:603,t:1528139708583};\\\", \\\"{x:1507,y:618,t:1528139708601};\\\", \\\"{x:1497,y:633,t:1528139708616};\\\", \\\"{x:1476,y:650,t:1528139708633};\\\", \\\"{x:1455,y:668,t:1528139708650};\\\", \\\"{x:1436,y:684,t:1528139708666};\\\", \\\"{x:1417,y:700,t:1528139708683};\\\", \\\"{x:1412,y:704,t:1528139708700};\\\", \\\"{x:1411,y:705,t:1528139708715};\\\", \\\"{x:1409,y:706,t:1528139708733};\\\", \\\"{x:1406,y:708,t:1528139708749};\\\", \\\"{x:1399,y:713,t:1528139708766};\\\", \\\"{x:1391,y:717,t:1528139708783};\\\", \\\"{x:1386,y:720,t:1528139708799};\\\", \\\"{x:1383,y:722,t:1528139708816};\\\", \\\"{x:1383,y:723,t:1528139708851};\\\", \\\"{x:1382,y:724,t:1528139708866};\\\", \\\"{x:1378,y:728,t:1528139708883};\\\", \\\"{x:1374,y:733,t:1528139708899};\\\", \\\"{x:1372,y:736,t:1528139708916};\\\", \\\"{x:1370,y:739,t:1528139708933};\\\", \\\"{x:1368,y:743,t:1528139708949};\\\", \\\"{x:1368,y:746,t:1528139708966};\\\", \\\"{x:1365,y:749,t:1528139708983};\\\", \\\"{x:1363,y:752,t:1528139708999};\\\", \\\"{x:1359,y:757,t:1528139709016};\\\", \\\"{x:1356,y:761,t:1528139709033};\\\", \\\"{x:1354,y:763,t:1528139709049};\\\", \\\"{x:1352,y:766,t:1528139709067};\\\", \\\"{x:1351,y:767,t:1528139709083};\\\", \\\"{x:1351,y:768,t:1528139709116};\\\", \\\"{x:1350,y:768,t:1528139709179};\\\", \\\"{x:1349,y:768,t:1528139709218};\\\", \\\"{x:1348,y:768,t:1528139709233};\\\", \\\"{x:1346,y:768,t:1528139709248};\\\", \\\"{x:1345,y:768,t:1528139709265};\\\", \\\"{x:1343,y:768,t:1528139709282};\\\", \\\"{x:1343,y:767,t:1528139709305};\\\", \\\"{x:1343,y:766,t:1528139709362};\\\", \\\"{x:1343,y:765,t:1528139709394};\\\", \\\"{x:1343,y:764,t:1528139709410};\\\", \\\"{x:1343,y:762,t:1528139709491};\\\", \\\"{x:1343,y:761,t:1528139709506};\\\", \\\"{x:1344,y:760,t:1528139709554};\\\", \\\"{x:1345,y:760,t:1528139709566};\\\", \\\"{x:1346,y:760,t:1528139709581};\\\", \\\"{x:1348,y:760,t:1528139709598};\\\", \\\"{x:1349,y:760,t:1528139709615};\\\", \\\"{x:1350,y:757,t:1528139710068};\\\", \\\"{x:1352,y:751,t:1528139710082};\\\", \\\"{x:1354,y:735,t:1528139710098};\\\", \\\"{x:1356,y:728,t:1528139710116};\\\", \\\"{x:1358,y:722,t:1528139710132};\\\", \\\"{x:1359,y:717,t:1528139710150};\\\", \\\"{x:1360,y:714,t:1528139710166};\\\", \\\"{x:1361,y:709,t:1528139710182};\\\", \\\"{x:1361,y:707,t:1528139710199};\\\", \\\"{x:1361,y:704,t:1528139710216};\\\", \\\"{x:1361,y:702,t:1528139710232};\\\", \\\"{x:1361,y:699,t:1528139710249};\\\", \\\"{x:1361,y:697,t:1528139710265};\\\", \\\"{x:1361,y:696,t:1528139710283};\\\", \\\"{x:1361,y:694,t:1528139710300};\\\", \\\"{x:1361,y:692,t:1528139710330};\\\", \\\"{x:1360,y:692,t:1528139710347};\\\", \\\"{x:1359,y:691,t:1528139710362};\\\", \\\"{x:1357,y:690,t:1528139710371};\\\", \\\"{x:1356,y:689,t:1528139710382};\\\", \\\"{x:1355,y:688,t:1528139710400};\\\", \\\"{x:1354,y:688,t:1528139710416};\\\", \\\"{x:1353,y:688,t:1528139710432};\\\", \\\"{x:1352,y:688,t:1528139710449};\\\", \\\"{x:1351,y:688,t:1528139710465};\\\", \\\"{x:1350,y:688,t:1528139710498};\\\", \\\"{x:1349,y:688,t:1528139710547};\\\", \\\"{x:1349,y:689,t:1528139710650};\\\", \\\"{x:1349,y:690,t:1528139710674};\\\", \\\"{x:1348,y:691,t:1528139710682};\\\", \\\"{x:1348,y:692,t:1528139710699};\\\", \\\"{x:1348,y:693,t:1528139710731};\\\", \\\"{x:1348,y:694,t:1528139711043};\\\", \\\"{x:1348,y:695,t:1528139711051};\\\", \\\"{x:1347,y:698,t:1528139711065};\\\", \\\"{x:1348,y:693,t:1528139712659};\\\", \\\"{x:1350,y:692,t:1528139712673};\\\", \\\"{x:1355,y:687,t:1528139712690};\\\", \\\"{x:1357,y:685,t:1528139712707};\\\", \\\"{x:1356,y:685,t:1528139712891};\\\", \\\"{x:1354,y:688,t:1528139712907};\\\", \\\"{x:1351,y:693,t:1528139712924};\\\", \\\"{x:1347,y:699,t:1528139712940};\\\", \\\"{x:1344,y:708,t:1528139712957};\\\", \\\"{x:1339,y:721,t:1528139712973};\\\", \\\"{x:1333,y:733,t:1528139712990};\\\", \\\"{x:1328,y:743,t:1528139713006};\\\", \\\"{x:1320,y:755,t:1528139713023};\\\", \\\"{x:1309,y:768,t:1528139713040};\\\", \\\"{x:1302,y:776,t:1528139713056};\\\", \\\"{x:1292,y:788,t:1528139713073};\\\", \\\"{x:1280,y:805,t:1528139713090};\\\", \\\"{x:1269,y:813,t:1528139713107};\\\", \\\"{x:1261,y:821,t:1528139713124};\\\", \\\"{x:1254,y:831,t:1528139713140};\\\", \\\"{x:1247,y:843,t:1528139713157};\\\", \\\"{x:1238,y:853,t:1528139713173};\\\", \\\"{x:1229,y:862,t:1528139713190};\\\", \\\"{x:1221,y:868,t:1528139713207};\\\", \\\"{x:1215,y:876,t:1528139713223};\\\", \\\"{x:1213,y:880,t:1528139713240};\\\", \\\"{x:1210,y:884,t:1528139713257};\\\", \\\"{x:1207,y:889,t:1528139713274};\\\", \\\"{x:1203,y:897,t:1528139713290};\\\", \\\"{x:1202,y:902,t:1528139713307};\\\", \\\"{x:1197,y:906,t:1528139713324};\\\", \\\"{x:1195,y:910,t:1528139713340};\\\", \\\"{x:1192,y:913,t:1528139713358};\\\", \\\"{x:1192,y:916,t:1528139713374};\\\", \\\"{x:1188,y:923,t:1528139713390};\\\", \\\"{x:1184,y:932,t:1528139713407};\\\", \\\"{x:1177,y:949,t:1528139713424};\\\", \\\"{x:1169,y:971,t:1528139713441};\\\", \\\"{x:1164,y:984,t:1528139713457};\\\", \\\"{x:1161,y:989,t:1528139713475};\\\", \\\"{x:1160,y:991,t:1528139713490};\\\", \\\"{x:1162,y:991,t:1528139713594};\\\", \\\"{x:1166,y:988,t:1528139713608};\\\", \\\"{x:1172,y:984,t:1528139713624};\\\", \\\"{x:1181,y:978,t:1528139713641};\\\", \\\"{x:1195,y:969,t:1528139713658};\\\", \\\"{x:1216,y:951,t:1528139713676};\\\", \\\"{x:1228,y:940,t:1528139713690};\\\", \\\"{x:1241,y:925,t:1528139713707};\\\", \\\"{x:1251,y:912,t:1528139713724};\\\", \\\"{x:1260,y:901,t:1528139713741};\\\", \\\"{x:1267,y:894,t:1528139713759};\\\", \\\"{x:1272,y:889,t:1528139713774};\\\", \\\"{x:1278,y:882,t:1528139713791};\\\", \\\"{x:1290,y:869,t:1528139713809};\\\", \\\"{x:1300,y:850,t:1528139713824};\\\", \\\"{x:1310,y:838,t:1528139713841};\\\", \\\"{x:1326,y:819,t:1528139713859};\\\", \\\"{x:1332,y:814,t:1528139713874};\\\", \\\"{x:1339,y:806,t:1528139713891};\\\", \\\"{x:1346,y:797,t:1528139713908};\\\", \\\"{x:1348,y:791,t:1528139713924};\\\", \\\"{x:1351,y:788,t:1528139713941};\\\", \\\"{x:1351,y:784,t:1528139713958};\\\", \\\"{x:1352,y:783,t:1528139713978};\\\", \\\"{x:1353,y:780,t:1528139713991};\\\", \\\"{x:1354,y:779,t:1528139714009};\\\", \\\"{x:1357,y:776,t:1528139714025};\\\", \\\"{x:1359,y:773,t:1528139714041};\\\", \\\"{x:1361,y:769,t:1528139714058};\\\", \\\"{x:1361,y:768,t:1528139714683};\\\", \\\"{x:1361,y:767,t:1528139714692};\\\", \\\"{x:1361,y:766,t:1528139714709};\\\", \\\"{x:1360,y:764,t:1528139714727};\\\", \\\"{x:1360,y:763,t:1528139714743};\\\", \\\"{x:1360,y:762,t:1528139714759};\\\", \\\"{x:1360,y:761,t:1528139715003};\\\", \\\"{x:1357,y:761,t:1528139715018};\\\", \\\"{x:1356,y:761,t:1528139715027};\\\", \\\"{x:1353,y:765,t:1528139715044};\\\", \\\"{x:1352,y:767,t:1528139715060};\\\", \\\"{x:1351,y:768,t:1528139715077};\\\", \\\"{x:1350,y:768,t:1528139715093};\\\", \\\"{x:1350,y:769,t:1528139715126};\\\", \\\"{x:1349,y:769,t:1528139715435};\\\", \\\"{x:1348,y:769,t:1528139715546};\\\", \\\"{x:1347,y:768,t:1528139715835};\\\", \\\"{x:1346,y:770,t:1528139715862};\\\", \\\"{x:1343,y:774,t:1528139715877};\\\", \\\"{x:1340,y:778,t:1528139715894};\\\", \\\"{x:1336,y:784,t:1528139715911};\\\", \\\"{x:1331,y:792,t:1528139715927};\\\", \\\"{x:1324,y:798,t:1528139715944};\\\", \\\"{x:1321,y:804,t:1528139715961};\\\", \\\"{x:1313,y:815,t:1528139715978};\\\", \\\"{x:1307,y:826,t:1528139715995};\\\", \\\"{x:1301,y:833,t:1528139716012};\\\", \\\"{x:1296,y:840,t:1528139716028};\\\", \\\"{x:1292,y:850,t:1528139716044};\\\", \\\"{x:1289,y:857,t:1528139716061};\\\", \\\"{x:1286,y:863,t:1528139716079};\\\", \\\"{x:1284,y:870,t:1528139716094};\\\", \\\"{x:1282,y:878,t:1528139716111};\\\", \\\"{x:1277,y:892,t:1528139716128};\\\", \\\"{x:1269,y:909,t:1528139716145};\\\", \\\"{x:1265,y:921,t:1528139716162};\\\", \\\"{x:1261,y:926,t:1528139716179};\\\", \\\"{x:1259,y:930,t:1528139716195};\\\", \\\"{x:1259,y:932,t:1528139716315};\\\", \\\"{x:1257,y:933,t:1528139716328};\\\", \\\"{x:1255,y:936,t:1528139716345};\\\", \\\"{x:1254,y:936,t:1528139716362};\\\", \\\"{x:1253,y:936,t:1528139716411};\\\", \\\"{x:1253,y:933,t:1528139716434};\\\", \\\"{x:1253,y:930,t:1528139716445};\\\", \\\"{x:1255,y:919,t:1528139716462};\\\", \\\"{x:1265,y:903,t:1528139716478};\\\", \\\"{x:1279,y:879,t:1528139716495};\\\", \\\"{x:1290,y:858,t:1528139716512};\\\", \\\"{x:1301,y:841,t:1528139716529};\\\", \\\"{x:1306,y:830,t:1528139716546};\\\", \\\"{x:1314,y:811,t:1528139716563};\\\", \\\"{x:1318,y:800,t:1528139716578};\\\", \\\"{x:1322,y:794,t:1528139716595};\\\", \\\"{x:1322,y:791,t:1528139716612};\\\", \\\"{x:1323,y:789,t:1528139716629};\\\", \\\"{x:1324,y:787,t:1528139716645};\\\", \\\"{x:1325,y:786,t:1528139716667};\\\", \\\"{x:1325,y:785,t:1528139716679};\\\", \\\"{x:1328,y:781,t:1528139716696};\\\", \\\"{x:1332,y:777,t:1528139716712};\\\", \\\"{x:1333,y:776,t:1528139716729};\\\", \\\"{x:1336,y:773,t:1528139716745};\\\", \\\"{x:1340,y:768,t:1528139716761};\\\", \\\"{x:1342,y:765,t:1528139716779};\\\", \\\"{x:1343,y:764,t:1528139716796};\\\", \\\"{x:1346,y:761,t:1528139716811};\\\", \\\"{x:1346,y:760,t:1528139716829};\\\", \\\"{x:1347,y:759,t:1528139716846};\\\", \\\"{x:1348,y:759,t:1528139716881};\\\", \\\"{x:1349,y:759,t:1528139717035};\\\", \\\"{x:1350,y:762,t:1528139717046};\\\", \\\"{x:1351,y:767,t:1528139717063};\\\", \\\"{x:1353,y:774,t:1528139717081};\\\", \\\"{x:1357,y:780,t:1528139717097};\\\", \\\"{x:1359,y:787,t:1528139717114};\\\", \\\"{x:1361,y:790,t:1528139717129};\\\", \\\"{x:1363,y:795,t:1528139717147};\\\", \\\"{x:1365,y:799,t:1528139717163};\\\", \\\"{x:1368,y:807,t:1528139717179};\\\", \\\"{x:1369,y:811,t:1528139717197};\\\", \\\"{x:1371,y:819,t:1528139717214};\\\", \\\"{x:1374,y:825,t:1528139717231};\\\", \\\"{x:1378,y:833,t:1528139717247};\\\", \\\"{x:1380,y:840,t:1528139717264};\\\", \\\"{x:1385,y:850,t:1528139717280};\\\", \\\"{x:1389,y:857,t:1528139717297};\\\", \\\"{x:1394,y:869,t:1528139717313};\\\", \\\"{x:1404,y:892,t:1528139717331};\\\", \\\"{x:1412,y:902,t:1528139717346};\\\", \\\"{x:1416,y:908,t:1528139717363};\\\", \\\"{x:1420,y:912,t:1528139717381};\\\", \\\"{x:1421,y:914,t:1528139717396};\\\", \\\"{x:1423,y:916,t:1528139717413};\\\", \\\"{x:1424,y:918,t:1528139717430};\\\", \\\"{x:1427,y:922,t:1528139717447};\\\", \\\"{x:1431,y:927,t:1528139717463};\\\", \\\"{x:1435,y:931,t:1528139717480};\\\", \\\"{x:1436,y:932,t:1528139717497};\\\", \\\"{x:1438,y:935,t:1528139717513};\\\", \\\"{x:1442,y:941,t:1528139717530};\\\", \\\"{x:1443,y:943,t:1528139717547};\\\", \\\"{x:1443,y:944,t:1528139717563};\\\", \\\"{x:1444,y:945,t:1528139717580};\\\", \\\"{x:1445,y:946,t:1528139717619};\\\", \\\"{x:1445,y:947,t:1528139717635};\\\", \\\"{x:1446,y:947,t:1528139717647};\\\", \\\"{x:1446,y:948,t:1528139717667};\\\", \\\"{x:1446,y:949,t:1528139717681};\\\", \\\"{x:1446,y:950,t:1528139717698};\\\", \\\"{x:1446,y:954,t:1528139717714};\\\", \\\"{x:1446,y:955,t:1528139717803};\\\", \\\"{x:1446,y:956,t:1528139717978};\\\", \\\"{x:1445,y:956,t:1528139719619};\\\", \\\"{x:1445,y:954,t:1528139720459};\\\", \\\"{x:1445,y:952,t:1528139720469};\\\", \\\"{x:1445,y:944,t:1528139720485};\\\", \\\"{x:1444,y:925,t:1528139720501};\\\", \\\"{x:1438,y:898,t:1528139720518};\\\", \\\"{x:1431,y:874,t:1528139720535};\\\", \\\"{x:1427,y:858,t:1528139720552};\\\", \\\"{x:1426,y:850,t:1528139720569};\\\", \\\"{x:1426,y:843,t:1528139720586};\\\", \\\"{x:1426,y:831,t:1528139720601};\\\", \\\"{x:1426,y:817,t:1528139720618};\\\", \\\"{x:1426,y:809,t:1528139720635};\\\", \\\"{x:1424,y:802,t:1528139720651};\\\", \\\"{x:1420,y:794,t:1528139720669};\\\", \\\"{x:1419,y:791,t:1528139720686};\\\", \\\"{x:1418,y:790,t:1528139720701};\\\", \\\"{x:1417,y:789,t:1528139720722};\\\", \\\"{x:1416,y:789,t:1528139720739};\\\", \\\"{x:1413,y:789,t:1528139720752};\\\", \\\"{x:1403,y:787,t:1528139720769};\\\", \\\"{x:1389,y:782,t:1528139720786};\\\", \\\"{x:1367,y:777,t:1528139720803};\\\", \\\"{x:1352,y:776,t:1528139720819};\\\", \\\"{x:1343,y:773,t:1528139720836};\\\", \\\"{x:1340,y:773,t:1528139720852};\\\", \\\"{x:1340,y:772,t:1528139720875};\\\", \\\"{x:1339,y:770,t:1528139720891};\\\", \\\"{x:1338,y:770,t:1528139720906};\\\", \\\"{x:1338,y:768,t:1528139720919};\\\", \\\"{x:1337,y:767,t:1528139720936};\\\", \\\"{x:1337,y:766,t:1528139721067};\\\", \\\"{x:1337,y:765,t:1528139721075};\\\", \\\"{x:1337,y:764,t:1528139721090};\\\", \\\"{x:1339,y:763,t:1528139721131};\\\", \\\"{x:1340,y:763,t:1528139721155};\\\", \\\"{x:1342,y:762,t:1528139721187};\\\", \\\"{x:1344,y:762,t:1528139721219};\\\", \\\"{x:1344,y:761,t:1528139721282};\\\", \\\"{x:1345,y:761,t:1528139721363};\\\", \\\"{x:1346,y:760,t:1528139721554};\\\", \\\"{x:1348,y:759,t:1528139721578};\\\", \\\"{x:1349,y:759,t:1528139721618};\\\", \\\"{x:1350,y:759,t:1528139721642};\\\", \\\"{x:1350,y:760,t:1528139721938};\\\", \\\"{x:1350,y:763,t:1528139721953};\\\", \\\"{x:1348,y:771,t:1528139721971};\\\", \\\"{x:1347,y:775,t:1528139721987};\\\", \\\"{x:1344,y:780,t:1528139722004};\\\", \\\"{x:1341,y:786,t:1528139722020};\\\", \\\"{x:1336,y:792,t:1528139722038};\\\", \\\"{x:1331,y:801,t:1528139722055};\\\", \\\"{x:1328,y:811,t:1528139722070};\\\", \\\"{x:1325,y:818,t:1528139722088};\\\", \\\"{x:1322,y:825,t:1528139722104};\\\", \\\"{x:1319,y:830,t:1528139722121};\\\", \\\"{x:1316,y:833,t:1528139722138};\\\", \\\"{x:1312,y:841,t:1528139722154};\\\", \\\"{x:1308,y:848,t:1528139722171};\\\", \\\"{x:1305,y:855,t:1528139722187};\\\", \\\"{x:1301,y:863,t:1528139722205};\\\", \\\"{x:1298,y:870,t:1528139722221};\\\", \\\"{x:1293,y:877,t:1528139722237};\\\", \\\"{x:1288,y:883,t:1528139722254};\\\", \\\"{x:1281,y:892,t:1528139722272};\\\", \\\"{x:1275,y:901,t:1528139722288};\\\", \\\"{x:1271,y:909,t:1528139722305};\\\", \\\"{x:1270,y:915,t:1528139722322};\\\", \\\"{x:1267,y:918,t:1528139722338};\\\", \\\"{x:1265,y:925,t:1528139722354};\\\", \\\"{x:1262,y:930,t:1528139722372};\\\", \\\"{x:1260,y:936,t:1528139722387};\\\", \\\"{x:1259,y:939,t:1528139722404};\\\", \\\"{x:1259,y:941,t:1528139722421};\\\", \\\"{x:1259,y:943,t:1528139722436};\\\", \\\"{x:1259,y:945,t:1528139722453};\\\", \\\"{x:1259,y:947,t:1528139722471};\\\", \\\"{x:1259,y:948,t:1528139722488};\\\", \\\"{x:1259,y:949,t:1528139722503};\\\", \\\"{x:1259,y:950,t:1528139722521};\\\", \\\"{x:1259,y:951,t:1528139722554};\\\", \\\"{x:1258,y:953,t:1528139722577};\\\", \\\"{x:1257,y:954,t:1528139722588};\\\", \\\"{x:1254,y:961,t:1528139722604};\\\", \\\"{x:1251,y:968,t:1528139722621};\\\", \\\"{x:1251,y:970,t:1528139722638};\\\", \\\"{x:1250,y:972,t:1528139722655};\\\", \\\"{x:1249,y:973,t:1528139722672};\\\", \\\"{x:1249,y:972,t:1528139722891};\\\", \\\"{x:1249,y:971,t:1528139722905};\\\", \\\"{x:1249,y:969,t:1528139722923};\\\", \\\"{x:1249,y:968,t:1528139722978};\\\", \\\"{x:1249,y:967,t:1528139722989};\\\", \\\"{x:1249,y:966,t:1528139723010};\\\", \\\"{x:1250,y:965,t:1528139723051};\\\", \\\"{x:1250,y:964,t:1528139723075};\\\", \\\"{x:1250,y:963,t:1528139765902};\\\", \\\"{x:1257,y:955,t:1528139765910};\\\", \\\"{x:1313,y:922,t:1528139765926};\\\", \\\"{x:1345,y:906,t:1528139765942};\\\", \\\"{x:1367,y:896,t:1528139765960};\\\", \\\"{x:1400,y:885,t:1528139765977};\\\", \\\"{x:1443,y:870,t:1528139765992};\\\", \\\"{x:1477,y:854,t:1528139766009};\\\", \\\"{x:1506,y:839,t:1528139766027};\\\", \\\"{x:1526,y:830,t:1528139766044};\\\", \\\"{x:1543,y:821,t:1528139766059};\\\", \\\"{x:1569,y:806,t:1528139766078};\\\", \\\"{x:1587,y:790,t:1528139766093};\\\", \\\"{x:1599,y:765,t:1528139766109};\\\", \\\"{x:1604,y:748,t:1528139766126};\\\", \\\"{x:1604,y:734,t:1528139766143};\\\", \\\"{x:1604,y:723,t:1528139766160};\\\", \\\"{x:1601,y:720,t:1528139766177};\\\", \\\"{x:1600,y:720,t:1528139766197};\\\", \\\"{x:1597,y:720,t:1528139766210};\\\", \\\"{x:1592,y:723,t:1528139766227};\\\", \\\"{x:1587,y:726,t:1528139766244};\\\", \\\"{x:1566,y:734,t:1528139766261};\\\", \\\"{x:1548,y:737,t:1528139766277};\\\", \\\"{x:1532,y:741,t:1528139766293};\\\", \\\"{x:1516,y:742,t:1528139766311};\\\", \\\"{x:1503,y:746,t:1528139766326};\\\", \\\"{x:1489,y:746,t:1528139766344};\\\", \\\"{x:1481,y:744,t:1528139766361};\\\", \\\"{x:1475,y:741,t:1528139766376};\\\", \\\"{x:1470,y:739,t:1528139766394};\\\", \\\"{x:1465,y:736,t:1528139766411};\\\", \\\"{x:1458,y:733,t:1528139766427};\\\", \\\"{x:1448,y:730,t:1528139766443};\\\", \\\"{x:1440,y:724,t:1528139766460};\\\", \\\"{x:1439,y:723,t:1528139766477};\\\", \\\"{x:1438,y:721,t:1528139766494};\\\", \\\"{x:1437,y:720,t:1528139766510};\\\", \\\"{x:1432,y:717,t:1528139766528};\\\", \\\"{x:1428,y:716,t:1528139766544};\\\", \\\"{x:1423,y:712,t:1528139766561};\\\", \\\"{x:1418,y:709,t:1528139766578};\\\", \\\"{x:1416,y:708,t:1528139766594};\\\", \\\"{x:1415,y:708,t:1528139766610};\\\", \\\"{x:1413,y:706,t:1528139766628};\\\", \\\"{x:1403,y:706,t:1528139766644};\\\", \\\"{x:1376,y:704,t:1528139766661};\\\", \\\"{x:1360,y:702,t:1528139766677};\\\", \\\"{x:1349,y:700,t:1528139766695};\\\", \\\"{x:1338,y:700,t:1528139766711};\\\", \\\"{x:1335,y:700,t:1528139766727};\\\", \\\"{x:1333,y:700,t:1528139766744};\\\", \\\"{x:1332,y:700,t:1528139766761};\\\", \\\"{x:1331,y:700,t:1528139766805};\\\", \\\"{x:1330,y:699,t:1528139766862};\\\", \\\"{x:1330,y:698,t:1528139766878};\\\", \\\"{x:1330,y:696,t:1528139766895};\\\", \\\"{x:1331,y:695,t:1528139766911};\\\", \\\"{x:1331,y:694,t:1528139766927};\\\", \\\"{x:1333,y:694,t:1528139766945};\\\", \\\"{x:1334,y:694,t:1528139766973};\\\", \\\"{x:1336,y:694,t:1528139766981};\\\", \\\"{x:1337,y:694,t:1528139766997};\\\", \\\"{x:1339,y:694,t:1528139767021};\\\", \\\"{x:1340,y:694,t:1528139767037};\\\", \\\"{x:1342,y:694,t:1528139767061};\\\", \\\"{x:1343,y:694,t:1528139767677};\\\", \\\"{x:1345,y:694,t:1528139767695};\\\", \\\"{x:1346,y:694,t:1528139767717};\\\", \\\"{x:1347,y:694,t:1528139767733};\\\", \\\"{x:1347,y:695,t:1528139767782};\\\", \\\"{x:1348,y:695,t:1528139767795};\\\", \\\"{x:1349,y:695,t:1528139768085};\\\", \\\"{x:1350,y:695,t:1528139768096};\\\", \\\"{x:1354,y:691,t:1528139768114};\\\", \\\"{x:1357,y:687,t:1528139768129};\\\", \\\"{x:1360,y:683,t:1528139768147};\\\", \\\"{x:1368,y:672,t:1528139768163};\\\", \\\"{x:1378,y:659,t:1528139768180};\\\", \\\"{x:1391,y:638,t:1528139768196};\\\", \\\"{x:1399,y:625,t:1528139768212};\\\", \\\"{x:1406,y:612,t:1528139768230};\\\", \\\"{x:1411,y:599,t:1528139768247};\\\", \\\"{x:1412,y:596,t:1528139768263};\\\", \\\"{x:1416,y:591,t:1528139768280};\\\", \\\"{x:1417,y:588,t:1528139768297};\\\", \\\"{x:1420,y:583,t:1528139768314};\\\", \\\"{x:1422,y:577,t:1528139768330};\\\", \\\"{x:1423,y:572,t:1528139768347};\\\", \\\"{x:1424,y:567,t:1528139768363};\\\", \\\"{x:1427,y:562,t:1528139768380};\\\", \\\"{x:1428,y:559,t:1528139768397};\\\", \\\"{x:1428,y:558,t:1528139768414};\\\", \\\"{x:1428,y:557,t:1528139768501};\\\", \\\"{x:1428,y:556,t:1528139768565};\\\", \\\"{x:1427,y:556,t:1528139768605};\\\", \\\"{x:1425,y:556,t:1528139768645};\\\", \\\"{x:1424,y:556,t:1528139768717};\\\", \\\"{x:1423,y:556,t:1528139768749};\\\", \\\"{x:1423,y:557,t:1528139768773};\\\", \\\"{x:1422,y:557,t:1528139768781};\\\", \\\"{x:1421,y:558,t:1528139768798};\\\", \\\"{x:1420,y:558,t:1528139768821};\\\", \\\"{x:1420,y:559,t:1528139768837};\\\", \\\"{x:1419,y:559,t:1528139768847};\\\", \\\"{x:1418,y:559,t:1528139768918};\\\", \\\"{x:1415,y:560,t:1528139769805};\\\", \\\"{x:1414,y:561,t:1528139769815};\\\", \\\"{x:1413,y:561,t:1528139769833};\\\", \\\"{x:1411,y:562,t:1528139769876};\\\", \\\"{x:1409,y:562,t:1528139769884};\\\", \\\"{x:1408,y:563,t:1528139769899};\\\", \\\"{x:1399,y:566,t:1528139769916};\\\", \\\"{x:1315,y:563,t:1528139769933};\\\", \\\"{x:1256,y:555,t:1528139769949};\\\", \\\"{x:1209,y:549,t:1528139769966};\\\", \\\"{x:1147,y:539,t:1528139769983};\\\", \\\"{x:1069,y:528,t:1528139769999};\\\", \\\"{x:986,y:519,t:1528139770016};\\\", \\\"{x:921,y:507,t:1528139770035};\\\", \\\"{x:877,y:502,t:1528139770049};\\\", \\\"{x:853,y:500,t:1528139770065};\\\", \\\"{x:836,y:500,t:1528139770087};\\\", \\\"{x:831,y:500,t:1528139770104};\\\", \\\"{x:826,y:502,t:1528139770121};\\\", \\\"{x:819,y:509,t:1528139770137};\\\", \\\"{x:806,y:519,t:1528139770155};\\\", \\\"{x:794,y:527,t:1528139770171};\\\", \\\"{x:775,y:534,t:1528139770188};\\\", \\\"{x:755,y:539,t:1528139770204};\\\", \\\"{x:731,y:545,t:1528139770221};\\\", \\\"{x:707,y:556,t:1528139770239};\\\", \\\"{x:679,y:564,t:1528139770255};\\\", \\\"{x:646,y:570,t:1528139770271};\\\", \\\"{x:618,y:577,t:1528139770287};\\\", \\\"{x:583,y:580,t:1528139770305};\\\", \\\"{x:538,y:580,t:1528139770321};\\\", \\\"{x:510,y:580,t:1528139770337};\\\", \\\"{x:488,y:577,t:1528139770356};\\\", \\\"{x:472,y:573,t:1528139770371};\\\", \\\"{x:461,y:570,t:1528139770387};\\\", \\\"{x:447,y:567,t:1528139770404};\\\", \\\"{x:445,y:567,t:1528139770421};\\\", \\\"{x:444,y:567,t:1528139770517};\\\", \\\"{x:441,y:567,t:1528139770565};\\\", \\\"{x:437,y:567,t:1528139770581};\\\", \\\"{x:430,y:567,t:1528139770589};\\\", \\\"{x:412,y:563,t:1528139770604};\\\", \\\"{x:392,y:558,t:1528139770622};\\\", \\\"{x:372,y:551,t:1528139770637};\\\", \\\"{x:355,y:543,t:1528139770655};\\\", \\\"{x:340,y:538,t:1528139770671};\\\", \\\"{x:336,y:536,t:1528139770688};\\\", \\\"{x:333,y:533,t:1528139770705};\\\", \\\"{x:331,y:531,t:1528139770721};\\\", \\\"{x:329,y:528,t:1528139770738};\\\", \\\"{x:327,y:525,t:1528139770755};\\\", \\\"{x:325,y:524,t:1528139770771};\\\", \\\"{x:323,y:524,t:1528139770796};\\\", \\\"{x:320,y:524,t:1528139770805};\\\", \\\"{x:311,y:524,t:1528139770823};\\\", \\\"{x:296,y:524,t:1528139770838};\\\", \\\"{x:284,y:524,t:1528139770856};\\\", \\\"{x:266,y:529,t:1528139770875};\\\", \\\"{x:252,y:532,t:1528139770889};\\\", \\\"{x:232,y:540,t:1528139770905};\\\", \\\"{x:211,y:548,t:1528139770922};\\\", \\\"{x:193,y:556,t:1528139770939};\\\", \\\"{x:182,y:564,t:1528139770955};\\\", \\\"{x:169,y:582,t:1528139770972};\\\", \\\"{x:166,y:592,t:1528139770988};\\\", \\\"{x:166,y:603,t:1528139771005};\\\", \\\"{x:166,y:609,t:1528139771022};\\\", \\\"{x:168,y:612,t:1528139771037};\\\", \\\"{x:168,y:614,t:1528139771055};\\\", \\\"{x:169,y:614,t:1528139771072};\\\", \\\"{x:170,y:614,t:1528139771100};\\\", \\\"{x:170,y:615,t:1528139771108};\\\", \\\"{x:171,y:615,t:1528139771122};\\\", \\\"{x:172,y:616,t:1528139771138};\\\", \\\"{x:178,y:621,t:1528139771155};\\\", \\\"{x:204,y:631,t:1528139771172};\\\", \\\"{x:233,y:636,t:1528139771189};\\\", \\\"{x:262,y:641,t:1528139771206};\\\", \\\"{x:305,y:643,t:1528139771223};\\\", \\\"{x:360,y:650,t:1528139771239};\\\", \\\"{x:421,y:656,t:1528139771254};\\\", \\\"{x:480,y:665,t:1528139771272};\\\", \\\"{x:533,y:665,t:1528139771289};\\\", \\\"{x:575,y:665,t:1528139771305};\\\", \\\"{x:603,y:665,t:1528139771322};\\\", \\\"{x:627,y:662,t:1528139771339};\\\", \\\"{x:649,y:659,t:1528139771355};\\\", \\\"{x:670,y:654,t:1528139771372};\\\", \\\"{x:678,y:651,t:1528139771390};\\\", \\\"{x:689,y:648,t:1528139771407};\\\", \\\"{x:698,y:644,t:1528139771422};\\\", \\\"{x:711,y:641,t:1528139771439};\\\", \\\"{x:721,y:639,t:1528139771456};\\\", \\\"{x:727,y:636,t:1528139771472};\\\", \\\"{x:735,y:630,t:1528139771493};\\\", \\\"{x:744,y:624,t:1528139771506};\\\", \\\"{x:755,y:616,t:1528139771522};\\\", \\\"{x:773,y:610,t:1528139771539};\\\", \\\"{x:801,y:600,t:1528139771556};\\\", \\\"{x:813,y:596,t:1528139771572};\\\", \\\"{x:821,y:593,t:1528139771590};\\\", \\\"{x:832,y:587,t:1528139771605};\\\", \\\"{x:838,y:582,t:1528139771622};\\\", \\\"{x:843,y:578,t:1528139771639};\\\", \\\"{x:848,y:572,t:1528139771656};\\\", \\\"{x:852,y:569,t:1528139771672};\\\", \\\"{x:853,y:566,t:1528139771689};\\\", \\\"{x:854,y:565,t:1528139771706};\\\", \\\"{x:855,y:562,t:1528139771722};\\\", \\\"{x:855,y:555,t:1528139771739};\\\", \\\"{x:855,y:547,t:1528139771756};\\\", \\\"{x:855,y:546,t:1528139771772};\\\", \\\"{x:855,y:545,t:1528139771812};\\\", \\\"{x:855,y:543,t:1528139771835};\\\", \\\"{x:855,y:542,t:1528139771852};\\\", \\\"{x:855,y:541,t:1528139771892};\\\", \\\"{x:854,y:540,t:1528139771924};\\\", \\\"{x:853,y:540,t:1528139771957};\\\", \\\"{x:852,y:540,t:1528139771973};\\\", \\\"{x:851,y:540,t:1528139771989};\\\", \\\"{x:850,y:540,t:1528139772007};\\\", \\\"{x:849,y:540,t:1528139772023};\\\", \\\"{x:848,y:540,t:1528139772053};\\\", \\\"{x:847,y:540,t:1528139772069};\\\", \\\"{x:846,y:540,t:1528139772077};\\\", \\\"{x:845,y:540,t:1528139772092};\\\", \\\"{x:844,y:540,t:1528139772106};\\\", \\\"{x:842,y:538,t:1528139772122};\\\", \\\"{x:840,y:538,t:1528139772139};\\\", \\\"{x:839,y:538,t:1528139772157};\\\", \\\"{x:840,y:538,t:1528139772597};\\\", \\\"{x:866,y:544,t:1528139772607};\\\", \\\"{x:949,y:553,t:1528139772623};\\\", \\\"{x:1027,y:562,t:1528139772641};\\\", \\\"{x:1112,y:572,t:1528139772656};\\\", \\\"{x:1207,y:585,t:1528139772673};\\\", \\\"{x:1284,y:596,t:1528139772690};\\\", \\\"{x:1343,y:615,t:1528139772706};\\\", \\\"{x:1392,y:632,t:1528139772723};\\\", \\\"{x:1441,y:648,t:1528139772740};\\\", \\\"{x:1457,y:652,t:1528139772757};\\\", \\\"{x:1464,y:656,t:1528139772773};\\\", \\\"{x:1468,y:658,t:1528139772790};\\\", \\\"{x:1469,y:659,t:1528139772820};\\\", \\\"{x:1469,y:661,t:1528139772836};\\\", \\\"{x:1469,y:663,t:1528139772844};\\\", \\\"{x:1469,y:666,t:1528139772856};\\\", \\\"{x:1469,y:670,t:1528139772874};\\\", \\\"{x:1469,y:674,t:1528139772891};\\\", \\\"{x:1464,y:680,t:1528139772907};\\\", \\\"{x:1454,y:684,t:1528139772923};\\\", \\\"{x:1445,y:691,t:1528139772940};\\\", \\\"{x:1441,y:692,t:1528139772957};\\\", \\\"{x:1438,y:693,t:1528139772974};\\\", \\\"{x:1437,y:694,t:1528139772990};\\\", \\\"{x:1436,y:694,t:1528139773007};\\\", \\\"{x:1432,y:694,t:1528139773024};\\\", \\\"{x:1418,y:695,t:1528139773041};\\\", \\\"{x:1400,y:697,t:1528139773057};\\\", \\\"{x:1385,y:699,t:1528139773073};\\\", \\\"{x:1375,y:700,t:1528139773090};\\\", \\\"{x:1367,y:700,t:1528139773107};\\\", \\\"{x:1363,y:701,t:1528139773123};\\\", \\\"{x:1360,y:701,t:1528139773141};\\\", \\\"{x:1358,y:701,t:1528139773165};\\\", \\\"{x:1357,y:701,t:1528139773245};\\\", \\\"{x:1355,y:701,t:1528139773269};\\\", \\\"{x:1354,y:701,t:1528139773285};\\\", \\\"{x:1354,y:700,t:1528139773301};\\\", \\\"{x:1354,y:699,t:1528139773309};\\\", \\\"{x:1354,y:697,t:1528139773324};\\\", \\\"{x:1354,y:694,t:1528139773341};\\\", \\\"{x:1354,y:692,t:1528139773358};\\\", \\\"{x:1354,y:693,t:1528139773542};\\\", \\\"{x:1354,y:700,t:1528139773558};\\\", \\\"{x:1354,y:705,t:1528139773575};\\\", \\\"{x:1354,y:709,t:1528139773591};\\\", \\\"{x:1354,y:713,t:1528139773608};\\\", \\\"{x:1355,y:720,t:1528139773625};\\\", \\\"{x:1359,y:734,t:1528139773641};\\\", \\\"{x:1365,y:755,t:1528139773658};\\\", \\\"{x:1376,y:778,t:1528139773675};\\\", \\\"{x:1382,y:795,t:1528139773691};\\\", \\\"{x:1389,y:809,t:1528139773708};\\\", \\\"{x:1401,y:827,t:1528139773725};\\\", \\\"{x:1405,y:831,t:1528139773741};\\\", \\\"{x:1410,y:836,t:1528139773758};\\\", \\\"{x:1414,y:844,t:1528139773775};\\\", \\\"{x:1423,y:865,t:1528139773791};\\\", \\\"{x:1437,y:894,t:1528139773808};\\\", \\\"{x:1444,y:919,t:1528139773825};\\\", \\\"{x:1449,y:940,t:1528139773841};\\\", \\\"{x:1451,y:950,t:1528139773858};\\\", \\\"{x:1453,y:960,t:1528139773875};\\\", \\\"{x:1454,y:963,t:1528139773892};\\\", \\\"{x:1454,y:964,t:1528139773981};\\\", \\\"{x:1453,y:961,t:1528139773997};\\\", \\\"{x:1452,y:953,t:1528139774008};\\\", \\\"{x:1450,y:931,t:1528139774025};\\\", \\\"{x:1450,y:907,t:1528139774042};\\\", \\\"{x:1450,y:887,t:1528139774058};\\\", \\\"{x:1449,y:871,t:1528139774075};\\\", \\\"{x:1444,y:850,t:1528139774092};\\\", \\\"{x:1441,y:831,t:1528139774107};\\\", \\\"{x:1433,y:806,t:1528139774124};\\\", \\\"{x:1432,y:800,t:1528139774141};\\\", \\\"{x:1429,y:795,t:1528139774157};\\\", \\\"{x:1428,y:790,t:1528139774175};\\\", \\\"{x:1427,y:785,t:1528139774191};\\\", \\\"{x:1426,y:780,t:1528139774207};\\\", \\\"{x:1423,y:771,t:1528139774225};\\\", \\\"{x:1420,y:763,t:1528139774241};\\\", \\\"{x:1419,y:757,t:1528139774258};\\\", \\\"{x:1419,y:750,t:1528139774274};\\\", \\\"{x:1419,y:746,t:1528139774292};\\\", \\\"{x:1419,y:734,t:1528139774309};\\\", \\\"{x:1419,y:724,t:1528139774325};\\\", \\\"{x:1421,y:715,t:1528139774342};\\\", \\\"{x:1422,y:709,t:1528139774358};\\\", \\\"{x:1425,y:700,t:1528139774375};\\\", \\\"{x:1425,y:686,t:1528139774392};\\\", \\\"{x:1426,y:675,t:1528139774409};\\\", \\\"{x:1428,y:659,t:1528139774424};\\\", \\\"{x:1436,y:642,t:1528139774442};\\\", \\\"{x:1439,y:627,t:1528139774459};\\\", \\\"{x:1442,y:617,t:1528139774475};\\\", \\\"{x:1442,y:610,t:1528139774492};\\\", \\\"{x:1443,y:602,t:1528139774508};\\\", \\\"{x:1446,y:598,t:1528139774525};\\\", \\\"{x:1446,y:596,t:1528139774542};\\\", \\\"{x:1446,y:595,t:1528139774559};\\\", \\\"{x:1446,y:597,t:1528139774702};\\\", \\\"{x:1446,y:599,t:1528139774709};\\\", \\\"{x:1447,y:606,t:1528139774725};\\\", \\\"{x:1447,y:609,t:1528139774742};\\\", \\\"{x:1449,y:612,t:1528139774759};\\\", \\\"{x:1449,y:614,t:1528139774775};\\\", \\\"{x:1450,y:618,t:1528139774792};\\\", \\\"{x:1450,y:624,t:1528139774809};\\\", \\\"{x:1450,y:628,t:1528139774826};\\\", \\\"{x:1450,y:630,t:1528139774841};\\\", \\\"{x:1450,y:632,t:1528139774858};\\\", \\\"{x:1450,y:634,t:1528139774876};\\\", \\\"{x:1450,y:632,t:1528139775180};\\\", \\\"{x:1450,y:630,t:1528139775389};\\\", \\\"{x:1450,y:628,t:1528139775404};\\\", \\\"{x:1450,y:627,t:1528139775589};\\\", \\\"{x:1449,y:627,t:1528139775596};\\\", \\\"{x:1447,y:627,t:1528139775609};\\\", \\\"{x:1444,y:628,t:1528139775626};\\\", \\\"{x:1442,y:628,t:1528139775643};\\\", \\\"{x:1440,y:629,t:1528139775661};\\\", \\\"{x:1438,y:631,t:1528139775676};\\\", \\\"{x:1431,y:636,t:1528139775693};\\\", \\\"{x:1427,y:640,t:1528139775710};\\\", \\\"{x:1422,y:645,t:1528139775726};\\\", \\\"{x:1416,y:649,t:1528139775743};\\\", \\\"{x:1411,y:652,t:1528139775760};\\\", \\\"{x:1404,y:656,t:1528139775776};\\\", \\\"{x:1402,y:659,t:1528139775793};\\\", \\\"{x:1398,y:662,t:1528139775810};\\\", \\\"{x:1395,y:665,t:1528139775826};\\\", \\\"{x:1389,y:669,t:1528139775843};\\\", \\\"{x:1384,y:676,t:1528139775860};\\\", \\\"{x:1380,y:681,t:1528139775876};\\\", \\\"{x:1374,y:688,t:1528139775893};\\\", \\\"{x:1371,y:691,t:1528139775911};\\\", \\\"{x:1370,y:695,t:1528139775926};\\\", \\\"{x:1366,y:699,t:1528139775943};\\\", \\\"{x:1363,y:704,t:1528139775960};\\\", \\\"{x:1360,y:711,t:1528139775976};\\\", \\\"{x:1356,y:716,t:1528139775993};\\\", \\\"{x:1350,y:726,t:1528139776010};\\\", \\\"{x:1347,y:730,t:1528139776026};\\\", \\\"{x:1347,y:731,t:1528139776043};\\\", \\\"{x:1346,y:732,t:1528139776060};\\\", \\\"{x:1345,y:737,t:1528139776076};\\\", \\\"{x:1342,y:743,t:1528139776093};\\\", \\\"{x:1342,y:744,t:1528139776110};\\\", \\\"{x:1340,y:747,t:1528139776127};\\\", \\\"{x:1340,y:749,t:1528139776149};\\\", \\\"{x:1339,y:749,t:1528139776160};\\\", \\\"{x:1339,y:754,t:1528139776177};\\\", \\\"{x:1336,y:764,t:1528139776193};\\\", \\\"{x:1336,y:770,t:1528139776210};\\\", \\\"{x:1336,y:773,t:1528139776228};\\\", \\\"{x:1336,y:774,t:1528139776243};\\\", \\\"{x:1336,y:776,t:1528139776260};\\\", \\\"{x:1336,y:777,t:1528139776277};\\\", \\\"{x:1337,y:777,t:1528139776325};\\\", \\\"{x:1338,y:777,t:1528139776349};\\\", \\\"{x:1339,y:777,t:1528139776421};\\\", \\\"{x:1340,y:777,t:1528139776429};\\\", \\\"{x:1341,y:777,t:1528139776443};\\\", \\\"{x:1342,y:776,t:1528139776460};\\\", \\\"{x:1344,y:775,t:1528139776477};\\\", \\\"{x:1345,y:774,t:1528139776493};\\\", \\\"{x:1347,y:773,t:1528139776510};\\\", \\\"{x:1350,y:770,t:1528139776527};\\\", \\\"{x:1351,y:769,t:1528139776557};\\\", \\\"{x:1352,y:767,t:1528139776589};\\\", \\\"{x:1352,y:766,t:1528139776637};\\\", \\\"{x:1352,y:765,t:1528139776653};\\\", \\\"{x:1352,y:764,t:1528139776669};\\\", \\\"{x:1352,y:763,t:1528139776685};\\\", \\\"{x:1352,y:762,t:1528139776700};\\\", \\\"{x:1352,y:761,t:1528139776710};\\\", \\\"{x:1352,y:760,t:1528139776948};\\\", \\\"{x:1351,y:760,t:1528139776997};\\\", \\\"{x:1350,y:760,t:1528139777020};\\\", \\\"{x:1349,y:760,t:1528139777045};\\\", \\\"{x:1348,y:760,t:1528139777060};\\\", \\\"{x:1348,y:758,t:1528139777541};\\\", \\\"{x:1349,y:757,t:1528139777550};\\\", \\\"{x:1350,y:755,t:1528139777561};\\\", \\\"{x:1353,y:751,t:1528139777579};\\\", \\\"{x:1354,y:747,t:1528139777594};\\\", \\\"{x:1357,y:742,t:1528139777611};\\\", \\\"{x:1361,y:736,t:1528139777628};\\\", \\\"{x:1365,y:729,t:1528139777644};\\\", \\\"{x:1370,y:718,t:1528139777661};\\\", \\\"{x:1374,y:709,t:1528139777678};\\\", \\\"{x:1380,y:697,t:1528139777694};\\\", \\\"{x:1385,y:683,t:1528139777711};\\\", \\\"{x:1390,y:671,t:1528139777728};\\\", \\\"{x:1395,y:660,t:1528139777744};\\\", \\\"{x:1401,y:646,t:1528139777761};\\\", \\\"{x:1405,y:637,t:1528139777778};\\\", \\\"{x:1409,y:628,t:1528139777794};\\\", \\\"{x:1411,y:621,t:1528139777811};\\\", \\\"{x:1414,y:618,t:1528139777828};\\\", \\\"{x:1416,y:614,t:1528139777845};\\\", \\\"{x:1421,y:606,t:1528139777861};\\\", \\\"{x:1424,y:601,t:1528139777878};\\\", \\\"{x:1426,y:597,t:1528139777895};\\\", \\\"{x:1430,y:590,t:1528139777911};\\\", \\\"{x:1433,y:587,t:1528139777928};\\\", \\\"{x:1438,y:582,t:1528139777945};\\\", \\\"{x:1443,y:579,t:1528139777961};\\\", \\\"{x:1448,y:574,t:1528139777978};\\\", \\\"{x:1452,y:569,t:1528139777995};\\\", \\\"{x:1455,y:562,t:1528139778011};\\\", \\\"{x:1460,y:555,t:1528139778029};\\\", \\\"{x:1466,y:549,t:1528139778045};\\\", \\\"{x:1469,y:545,t:1528139778061};\\\", \\\"{x:1471,y:540,t:1528139778078};\\\", \\\"{x:1473,y:536,t:1528139778095};\\\", \\\"{x:1476,y:533,t:1528139778111};\\\", \\\"{x:1476,y:530,t:1528139778128};\\\", \\\"{x:1477,y:527,t:1528139778145};\\\", \\\"{x:1478,y:525,t:1528139778162};\\\", \\\"{x:1479,y:522,t:1528139778178};\\\", \\\"{x:1479,y:521,t:1528139778197};\\\", \\\"{x:1476,y:523,t:1528139778405};\\\", \\\"{x:1473,y:525,t:1528139778413};\\\", \\\"{x:1471,y:526,t:1528139778428};\\\", \\\"{x:1463,y:533,t:1528139778445};\\\", \\\"{x:1461,y:536,t:1528139778461};\\\", \\\"{x:1458,y:539,t:1528139778477};\\\", \\\"{x:1456,y:541,t:1528139778495};\\\", \\\"{x:1452,y:544,t:1528139778511};\\\", \\\"{x:1448,y:551,t:1528139778528};\\\", \\\"{x:1446,y:556,t:1528139778544};\\\", \\\"{x:1443,y:560,t:1528139778561};\\\", \\\"{x:1442,y:563,t:1528139778578};\\\", \\\"{x:1441,y:564,t:1528139778595};\\\", \\\"{x:1441,y:566,t:1528139778612};\\\", \\\"{x:1440,y:568,t:1528139778629};\\\", \\\"{x:1439,y:570,t:1528139778645};\\\", \\\"{x:1437,y:572,t:1528139778661};\\\", \\\"{x:1437,y:573,t:1528139778685};\\\", \\\"{x:1437,y:574,t:1528139778709};\\\", \\\"{x:1439,y:574,t:1528139778869};\\\", \\\"{x:1443,y:571,t:1528139778880};\\\", \\\"{x:1448,y:566,t:1528139778895};\\\", \\\"{x:1454,y:561,t:1528139778912};\\\", \\\"{x:1457,y:559,t:1528139778929};\\\", \\\"{x:1459,y:555,t:1528139778945};\\\", \\\"{x:1462,y:551,t:1528139778962};\\\", \\\"{x:1463,y:550,t:1528139778979};\\\", \\\"{x:1465,y:547,t:1528139778995};\\\", \\\"{x:1467,y:544,t:1528139779012};\\\", \\\"{x:1469,y:540,t:1528139779028};\\\", \\\"{x:1470,y:538,t:1528139779045};\\\", \\\"{x:1472,y:535,t:1528139779062};\\\", \\\"{x:1475,y:531,t:1528139779079};\\\", \\\"{x:1477,y:528,t:1528139779095};\\\", \\\"{x:1477,y:526,t:1528139779112};\\\", \\\"{x:1480,y:521,t:1528139779129};\\\", \\\"{x:1480,y:519,t:1528139779145};\\\", \\\"{x:1481,y:517,t:1528139779162};\\\", \\\"{x:1482,y:513,t:1528139779180};\\\", \\\"{x:1485,y:508,t:1528139779195};\\\", \\\"{x:1487,y:505,t:1528139779213};\\\", \\\"{x:1488,y:499,t:1528139779229};\\\", \\\"{x:1490,y:496,t:1528139779246};\\\", \\\"{x:1491,y:495,t:1528139779263};\\\", \\\"{x:1492,y:494,t:1528139779279};\\\", \\\"{x:1493,y:492,t:1528139779296};\\\", \\\"{x:1493,y:491,t:1528139779317};\\\", \\\"{x:1492,y:492,t:1528139779437};\\\", \\\"{x:1488,y:494,t:1528139779446};\\\", \\\"{x:1479,y:500,t:1528139779462};\\\", \\\"{x:1469,y:508,t:1528139779480};\\\", \\\"{x:1462,y:516,t:1528139779496};\\\", \\\"{x:1456,y:524,t:1528139779512};\\\", \\\"{x:1454,y:529,t:1528139779529};\\\", \\\"{x:1451,y:532,t:1528139779546};\\\", \\\"{x:1449,y:536,t:1528139779563};\\\", \\\"{x:1448,y:539,t:1528139779579};\\\", \\\"{x:1446,y:543,t:1528139779596};\\\", \\\"{x:1442,y:550,t:1528139779613};\\\", \\\"{x:1439,y:556,t:1528139779629};\\\", \\\"{x:1438,y:561,t:1528139779646};\\\", \\\"{x:1436,y:563,t:1528139779663};\\\", \\\"{x:1434,y:568,t:1528139779680};\\\", \\\"{x:1433,y:572,t:1528139779697};\\\", \\\"{x:1431,y:577,t:1528139779713};\\\", \\\"{x:1430,y:580,t:1528139779729};\\\", \\\"{x:1429,y:583,t:1528139779746};\\\", \\\"{x:1426,y:587,t:1528139779763};\\\", \\\"{x:1425,y:588,t:1528139779780};\\\", \\\"{x:1422,y:593,t:1528139779796};\\\", \\\"{x:1418,y:598,t:1528139779813};\\\", \\\"{x:1415,y:603,t:1528139779829};\\\", \\\"{x:1414,y:606,t:1528139779846};\\\", \\\"{x:1412,y:607,t:1528139779863};\\\", \\\"{x:1412,y:608,t:1528139779885};\\\", \\\"{x:1412,y:606,t:1528139780029};\\\", \\\"{x:1413,y:602,t:1528139780046};\\\", \\\"{x:1416,y:596,t:1528139780063};\\\", \\\"{x:1423,y:589,t:1528139780080};\\\", \\\"{x:1426,y:584,t:1528139780096};\\\", \\\"{x:1427,y:580,t:1528139780114};\\\", \\\"{x:1430,y:577,t:1528139780131};\\\", \\\"{x:1431,y:574,t:1528139780146};\\\", \\\"{x:1432,y:571,t:1528139780163};\\\", \\\"{x:1433,y:570,t:1528139780180};\\\", \\\"{x:1434,y:567,t:1528139780205};\\\", \\\"{x:1433,y:567,t:1528139780365};\\\", \\\"{x:1432,y:567,t:1528139780380};\\\", \\\"{x:1431,y:567,t:1528139780396};\\\", \\\"{x:1429,y:568,t:1528139780413};\\\", \\\"{x:1427,y:568,t:1528139780430};\\\", \\\"{x:1426,y:568,t:1528139780468};\\\", \\\"{x:1425,y:568,t:1528139780485};\\\", \\\"{x:1424,y:568,t:1528139780501};\\\", \\\"{x:1424,y:569,t:1528139780517};\\\", \\\"{x:1423,y:569,t:1528139780530};\\\", \\\"{x:1423,y:568,t:1528139780829};\\\", \\\"{x:1423,y:567,t:1528139780847};\\\", \\\"{x:1423,y:566,t:1528139781238};\\\", \\\"{x:1421,y:566,t:1528139781247};\\\", \\\"{x:1416,y:567,t:1528139781264};\\\", \\\"{x:1413,y:568,t:1528139781280};\\\", \\\"{x:1408,y:569,t:1528139781298};\\\", \\\"{x:1402,y:572,t:1528139781314};\\\", \\\"{x:1397,y:575,t:1528139781330};\\\", \\\"{x:1390,y:579,t:1528139781348};\\\", \\\"{x:1383,y:585,t:1528139781364};\\\", \\\"{x:1378,y:589,t:1528139781381};\\\", \\\"{x:1374,y:596,t:1528139781397};\\\", \\\"{x:1373,y:599,t:1528139781414};\\\", \\\"{x:1372,y:602,t:1528139781432};\\\", \\\"{x:1369,y:606,t:1528139781447};\\\", \\\"{x:1368,y:611,t:1528139781465};\\\", \\\"{x:1366,y:618,t:1528139781482};\\\", \\\"{x:1365,y:626,t:1528139781497};\\\", \\\"{x:1362,y:632,t:1528139781514};\\\", \\\"{x:1362,y:635,t:1528139781532};\\\", \\\"{x:1362,y:638,t:1528139781547};\\\", \\\"{x:1362,y:641,t:1528139781565};\\\", \\\"{x:1362,y:644,t:1528139781581};\\\", \\\"{x:1362,y:647,t:1528139781597};\\\", \\\"{x:1361,y:657,t:1528139781613};\\\", \\\"{x:1361,y:672,t:1528139781631};\\\", \\\"{x:1361,y:680,t:1528139781647};\\\", \\\"{x:1361,y:683,t:1528139781664};\\\", \\\"{x:1361,y:684,t:1528139781680};\\\", \\\"{x:1361,y:685,t:1528139781696};\\\", \\\"{x:1361,y:689,t:1528139781714};\\\", \\\"{x:1362,y:696,t:1528139781731};\\\", \\\"{x:1363,y:708,t:1528139781747};\\\", \\\"{x:1366,y:717,t:1528139781764};\\\", \\\"{x:1366,y:721,t:1528139781780};\\\", \\\"{x:1367,y:724,t:1528139781797};\\\", \\\"{x:1367,y:727,t:1528139781814};\\\", \\\"{x:1367,y:728,t:1528139781831};\\\", \\\"{x:1369,y:726,t:1528139782014};\\\", \\\"{x:1370,y:723,t:1528139782031};\\\", \\\"{x:1375,y:714,t:1528139782049};\\\", \\\"{x:1377,y:706,t:1528139782064};\\\", \\\"{x:1383,y:697,t:1528139782081};\\\", \\\"{x:1388,y:688,t:1528139782098};\\\", \\\"{x:1391,y:683,t:1528139782114};\\\", \\\"{x:1394,y:680,t:1528139782131};\\\", \\\"{x:1397,y:676,t:1528139782148};\\\", \\\"{x:1400,y:673,t:1528139782164};\\\", \\\"{x:1403,y:670,t:1528139782181};\\\", \\\"{x:1404,y:667,t:1528139782198};\\\", \\\"{x:1406,y:665,t:1528139782214};\\\", \\\"{x:1407,y:664,t:1528139782232};\\\", \\\"{x:1407,y:662,t:1528139782248};\\\", \\\"{x:1407,y:660,t:1528139782265};\\\", \\\"{x:1408,y:658,t:1528139782281};\\\", \\\"{x:1409,y:657,t:1528139782298};\\\", \\\"{x:1409,y:656,t:1528139782596};\\\", \\\"{x:1409,y:657,t:1528139782604};\\\", \\\"{x:1409,y:659,t:1528139782619};\\\", \\\"{x:1409,y:661,t:1528139782631};\\\", \\\"{x:1405,y:665,t:1528139782648};\\\", \\\"{x:1400,y:674,t:1528139782665};\\\", \\\"{x:1394,y:682,t:1528139782681};\\\", \\\"{x:1387,y:692,t:1528139782698};\\\", \\\"{x:1385,y:699,t:1528139782715};\\\", \\\"{x:1383,y:703,t:1528139782731};\\\", \\\"{x:1378,y:712,t:1528139782748};\\\", \\\"{x:1374,y:716,t:1528139782765};\\\", \\\"{x:1370,y:720,t:1528139782782};\\\", \\\"{x:1365,y:727,t:1528139782799};\\\", \\\"{x:1359,y:736,t:1528139782816};\\\", \\\"{x:1356,y:745,t:1528139782832};\\\", \\\"{x:1352,y:749,t:1528139782848};\\\", \\\"{x:1351,y:751,t:1528139782866};\\\", \\\"{x:1351,y:752,t:1528139782882};\\\", \\\"{x:1349,y:754,t:1528139782898};\\\", \\\"{x:1349,y:755,t:1528139782915};\\\", \\\"{x:1348,y:757,t:1528139782932};\\\", \\\"{x:1347,y:757,t:1528139784740};\\\", \\\"{x:1339,y:760,t:1528139784751};\\\", \\\"{x:1293,y:770,t:1528139784766};\\\", \\\"{x:1197,y:778,t:1528139784783};\\\", \\\"{x:1097,y:793,t:1528139784801};\\\", \\\"{x:986,y:807,t:1528139784816};\\\", \\\"{x:865,y:818,t:1528139784833};\\\", \\\"{x:760,y:818,t:1528139784851};\\\", \\\"{x:674,y:818,t:1528139784866};\\\", \\\"{x:606,y:807,t:1528139784883};\\\", \\\"{x:573,y:795,t:1528139784901};\\\", \\\"{x:562,y:791,t:1528139784917};\\\", \\\"{x:558,y:787,t:1528139784934};\\\", \\\"{x:558,y:782,t:1528139784950};\\\", \\\"{x:558,y:774,t:1528139784967};\\\", \\\"{x:561,y:758,t:1528139784983};\\\", \\\"{x:567,y:746,t:1528139785001};\\\", \\\"{x:577,y:731,t:1528139785017};\\\", \\\"{x:580,y:721,t:1528139785033};\\\", \\\"{x:581,y:718,t:1528139785050};\\\", \\\"{x:580,y:719,t:1528139785084};\\\", \\\"{x:575,y:723,t:1528139785100};\\\", \\\"{x:569,y:727,t:1528139785116};\\\", \\\"{x:557,y:732,t:1528139785135};\\\", \\\"{x:538,y:739,t:1528139785149};\\\", \\\"{x:526,y:744,t:1528139785167};\\\", \\\"{x:517,y:747,t:1528139785182};\\\", \\\"{x:513,y:747,t:1528139785200};\\\", \\\"{x:511,y:747,t:1528139785217};\\\", \\\"{x:510,y:747,t:1528139785284};\\\", \\\"{x:509,y:746,t:1528139785299};\\\" ] }, { \\\"rt\\\": 38010, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 567467, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M -J -J -I -I -I -J -J -J -J -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:744,t:1528139787692};\\\", \\\"{x:511,y:741,t:1528139787703};\\\", \\\"{x:515,y:735,t:1528139787719};\\\", \\\"{x:522,y:728,t:1528139787736};\\\", \\\"{x:531,y:723,t:1528139787752};\\\", \\\"{x:537,y:721,t:1528139787770};\\\", \\\"{x:548,y:716,t:1528139787787};\\\", \\\"{x:568,y:708,t:1528139787802};\\\", \\\"{x:593,y:701,t:1528139787817};\\\", \\\"{x:624,y:696,t:1528139787835};\\\", \\\"{x:664,y:693,t:1528139787851};\\\", \\\"{x:686,y:691,t:1528139787867};\\\", \\\"{x:694,y:689,t:1528139787885};\\\", \\\"{x:695,y:689,t:1528139787908};\\\", \\\"{x:697,y:698,t:1528139788029};\\\", \\\"{x:704,y:711,t:1528139788036};\\\", \\\"{x:727,y:736,t:1528139788053};\\\", \\\"{x:752,y:754,t:1528139788068};\\\", \\\"{x:781,y:771,t:1528139788086};\\\", \\\"{x:804,y:787,t:1528139788102};\\\", \\\"{x:805,y:789,t:1528139792252};\\\", \\\"{x:805,y:790,t:1528139792268};\\\", \\\"{x:805,y:795,t:1528139792284};\\\", \\\"{x:806,y:797,t:1528139792301};\\\", \\\"{x:807,y:800,t:1528139792318};\\\", \\\"{x:808,y:802,t:1528139792334};\\\", \\\"{x:809,y:807,t:1528139792351};\\\", \\\"{x:811,y:810,t:1528139792369};\\\", \\\"{x:812,y:814,t:1528139792385};\\\", \\\"{x:814,y:817,t:1528139792402};\\\", \\\"{x:818,y:824,t:1528139792418};\\\", \\\"{x:822,y:832,t:1528139792435};\\\", \\\"{x:828,y:840,t:1528139792451};\\\", \\\"{x:835,y:851,t:1528139792468};\\\", \\\"{x:842,y:858,t:1528139792485};\\\", \\\"{x:847,y:864,t:1528139792502};\\\", \\\"{x:855,y:869,t:1528139792518};\\\", \\\"{x:868,y:878,t:1528139792535};\\\", \\\"{x:884,y:891,t:1528139792551};\\\", \\\"{x:907,y:903,t:1528139792569};\\\", \\\"{x:938,y:920,t:1528139792584};\\\", \\\"{x:969,y:934,t:1528139792601};\\\", \\\"{x:998,y:951,t:1528139792619};\\\", \\\"{x:1043,y:971,t:1528139792634};\\\", \\\"{x:1082,y:988,t:1528139792652};\\\", \\\"{x:1134,y:1013,t:1528139792668};\\\", \\\"{x:1184,y:1035,t:1528139792684};\\\", \\\"{x:1227,y:1052,t:1528139792702};\\\", \\\"{x:1250,y:1063,t:1528139792718};\\\", \\\"{x:1271,y:1072,t:1528139792734};\\\", \\\"{x:1287,y:1077,t:1528139792752};\\\", \\\"{x:1295,y:1079,t:1528139792768};\\\", \\\"{x:1299,y:1081,t:1528139792785};\\\", \\\"{x:1300,y:1081,t:1528139792813};\\\", \\\"{x:1302,y:1080,t:1528139794221};\\\", \\\"{x:1304,y:1077,t:1528139794235};\\\", \\\"{x:1304,y:1073,t:1528139794251};\\\", \\\"{x:1306,y:1067,t:1528139794268};\\\", \\\"{x:1311,y:1058,t:1528139794285};\\\", \\\"{x:1316,y:1050,t:1528139794302};\\\", \\\"{x:1321,y:1041,t:1528139794318};\\\", \\\"{x:1327,y:1028,t:1528139794335};\\\", \\\"{x:1329,y:1014,t:1528139794352};\\\", \\\"{x:1332,y:994,t:1528139794368};\\\", \\\"{x:1334,y:979,t:1528139794385};\\\", \\\"{x:1338,y:962,t:1528139794403};\\\", \\\"{x:1342,y:951,t:1528139794418};\\\", \\\"{x:1348,y:932,t:1528139794435};\\\", \\\"{x:1352,y:914,t:1528139794452};\\\", \\\"{x:1353,y:901,t:1528139794468};\\\", \\\"{x:1358,y:889,t:1528139794484};\\\", \\\"{x:1359,y:883,t:1528139794502};\\\", \\\"{x:1360,y:878,t:1528139794518};\\\", \\\"{x:1361,y:872,t:1528139794535};\\\", \\\"{x:1362,y:867,t:1528139794552};\\\", \\\"{x:1362,y:861,t:1528139794568};\\\", \\\"{x:1363,y:854,t:1528139794584};\\\", \\\"{x:1365,y:847,t:1528139794602};\\\", \\\"{x:1365,y:843,t:1528139794618};\\\", \\\"{x:1366,y:839,t:1528139794635};\\\", \\\"{x:1367,y:835,t:1528139794652};\\\", \\\"{x:1368,y:830,t:1528139794668};\\\", \\\"{x:1370,y:824,t:1528139794685};\\\", \\\"{x:1372,y:818,t:1528139794702};\\\", \\\"{x:1374,y:810,t:1528139794718};\\\", \\\"{x:1375,y:804,t:1528139794734};\\\", \\\"{x:1375,y:800,t:1528139794752};\\\", \\\"{x:1376,y:795,t:1528139794768};\\\", \\\"{x:1377,y:789,t:1528139794785};\\\", \\\"{x:1377,y:787,t:1528139794802};\\\", \\\"{x:1377,y:783,t:1528139794818};\\\", \\\"{x:1377,y:782,t:1528139794835};\\\", \\\"{x:1377,y:779,t:1528139794851};\\\", \\\"{x:1377,y:777,t:1528139794868};\\\", \\\"{x:1376,y:774,t:1528139794885};\\\", \\\"{x:1374,y:771,t:1528139794902};\\\", \\\"{x:1371,y:769,t:1528139794918};\\\", \\\"{x:1370,y:768,t:1528139794935};\\\", \\\"{x:1368,y:768,t:1528139794952};\\\", \\\"{x:1367,y:768,t:1528139794968};\\\", \\\"{x:1365,y:768,t:1528139795005};\\\", \\\"{x:1364,y:769,t:1528139795018};\\\", \\\"{x:1363,y:773,t:1528139795035};\\\", \\\"{x:1359,y:782,t:1528139795052};\\\", \\\"{x:1354,y:790,t:1528139795068};\\\", \\\"{x:1349,y:799,t:1528139795084};\\\", \\\"{x:1346,y:805,t:1528139795101};\\\", \\\"{x:1343,y:810,t:1528139795117};\\\", \\\"{x:1340,y:817,t:1528139795134};\\\", \\\"{x:1338,y:825,t:1528139795150};\\\", \\\"{x:1335,y:840,t:1528139795167};\\\", \\\"{x:1335,y:853,t:1528139795184};\\\", \\\"{x:1335,y:865,t:1528139795201};\\\", \\\"{x:1336,y:872,t:1528139795218};\\\", \\\"{x:1338,y:876,t:1528139795234};\\\", \\\"{x:1338,y:880,t:1528139795251};\\\", \\\"{x:1339,y:886,t:1528139795267};\\\", \\\"{x:1342,y:894,t:1528139795284};\\\", \\\"{x:1343,y:898,t:1528139795300};\\\", \\\"{x:1344,y:902,t:1528139795318};\\\", \\\"{x:1344,y:905,t:1528139795335};\\\", \\\"{x:1345,y:911,t:1528139795351};\\\", \\\"{x:1345,y:912,t:1528139795368};\\\", \\\"{x:1345,y:914,t:1528139795385};\\\", \\\"{x:1345,y:917,t:1528139795401};\\\", \\\"{x:1345,y:921,t:1528139795418};\\\", \\\"{x:1345,y:924,t:1528139795434};\\\", \\\"{x:1344,y:926,t:1528139795451};\\\", \\\"{x:1341,y:928,t:1528139795467};\\\", \\\"{x:1334,y:932,t:1528139795485};\\\", \\\"{x:1329,y:935,t:1528139795501};\\\", \\\"{x:1323,y:939,t:1528139795518};\\\", \\\"{x:1315,y:945,t:1528139795535};\\\", \\\"{x:1311,y:947,t:1528139795551};\\\", \\\"{x:1303,y:949,t:1528139795568};\\\", \\\"{x:1293,y:951,t:1528139795585};\\\", \\\"{x:1285,y:951,t:1528139795601};\\\", \\\"{x:1278,y:951,t:1528139795618};\\\", \\\"{x:1272,y:951,t:1528139795635};\\\", \\\"{x:1266,y:951,t:1528139795651};\\\", \\\"{x:1265,y:951,t:1528139795668};\\\", \\\"{x:1264,y:951,t:1528139795797};\\\", \\\"{x:1264,y:950,t:1528139795812};\\\", \\\"{x:1266,y:950,t:1528139795821};\\\", \\\"{x:1269,y:950,t:1528139795835};\\\", \\\"{x:1282,y:948,t:1528139795851};\\\", \\\"{x:1294,y:946,t:1528139795868};\\\", \\\"{x:1315,y:943,t:1528139795884};\\\", \\\"{x:1332,y:942,t:1528139795901};\\\", \\\"{x:1351,y:942,t:1528139795918};\\\", \\\"{x:1370,y:942,t:1528139795935};\\\", \\\"{x:1386,y:942,t:1528139795951};\\\", \\\"{x:1400,y:942,t:1528139795968};\\\", \\\"{x:1411,y:942,t:1528139795985};\\\", \\\"{x:1419,y:940,t:1528139796001};\\\", \\\"{x:1422,y:940,t:1528139796018};\\\", \\\"{x:1425,y:940,t:1528139796035};\\\", \\\"{x:1426,y:940,t:1528139796051};\\\", \\\"{x:1427,y:940,t:1528139796069};\\\", \\\"{x:1428,y:940,t:1528139796085};\\\", \\\"{x:1426,y:940,t:1528139796213};\\\", \\\"{x:1424,y:940,t:1528139796221};\\\", \\\"{x:1420,y:942,t:1528139796235};\\\", \\\"{x:1415,y:943,t:1528139796251};\\\", \\\"{x:1409,y:944,t:1528139796268};\\\", \\\"{x:1395,y:946,t:1528139796284};\\\", \\\"{x:1383,y:948,t:1528139796301};\\\", \\\"{x:1367,y:949,t:1528139796318};\\\", \\\"{x:1345,y:949,t:1528139796334};\\\", \\\"{x:1329,y:949,t:1528139796350};\\\", \\\"{x:1316,y:949,t:1528139796368};\\\", \\\"{x:1306,y:949,t:1528139796385};\\\", \\\"{x:1299,y:949,t:1528139796401};\\\", \\\"{x:1298,y:949,t:1528139796418};\\\", \\\"{x:1297,y:949,t:1528139796453};\\\", \\\"{x:1299,y:949,t:1528139796591};\\\", \\\"{x:1302,y:948,t:1528139796600};\\\", \\\"{x:1309,y:947,t:1528139796617};\\\", \\\"{x:1320,y:947,t:1528139796634};\\\", \\\"{x:1335,y:947,t:1528139796650};\\\", \\\"{x:1354,y:947,t:1528139796667};\\\", \\\"{x:1372,y:947,t:1528139796683};\\\", \\\"{x:1379,y:947,t:1528139796700};\\\", \\\"{x:1386,y:947,t:1528139796717};\\\", \\\"{x:1390,y:947,t:1528139796735};\\\", \\\"{x:1393,y:947,t:1528139796750};\\\", \\\"{x:1395,y:947,t:1528139796768};\\\", \\\"{x:1396,y:947,t:1528139796785};\\\", \\\"{x:1397,y:946,t:1528139796801};\\\", \\\"{x:1399,y:946,t:1528139796818};\\\", \\\"{x:1400,y:946,t:1528139796837};\\\", \\\"{x:1403,y:946,t:1528139797313};\\\", \\\"{x:1404,y:946,t:1528139797322};\\\", \\\"{x:1406,y:946,t:1528139797339};\\\", \\\"{x:1410,y:946,t:1528139797355};\\\", \\\"{x:1412,y:946,t:1528139797372};\\\", \\\"{x:1414,y:946,t:1528139797389};\\\", \\\"{x:1417,y:944,t:1528139797405};\\\", \\\"{x:1419,y:944,t:1528139797425};\\\", \\\"{x:1422,y:943,t:1528139797440};\\\", \\\"{x:1423,y:943,t:1528139797473};\\\", \\\"{x:1424,y:942,t:1528139797487};\\\", \\\"{x:1425,y:942,t:1528139797561};\\\", \\\"{x:1426,y:942,t:1528139797572};\\\", \\\"{x:1427,y:941,t:1528139797588};\\\", \\\"{x:1429,y:940,t:1528139797641};\\\", \\\"{x:1430,y:940,t:1528139797656};\\\", \\\"{x:1431,y:940,t:1528139797673};\\\", \\\"{x:1432,y:940,t:1528139797688};\\\", \\\"{x:1433,y:940,t:1528139797736};\\\", \\\"{x:1432,y:940,t:1528139798560};\\\", \\\"{x:1430,y:940,t:1528139798624};\\\", \\\"{x:1429,y:940,t:1528139798641};\\\", \\\"{x:1429,y:941,t:1528139798680};\\\", \\\"{x:1427,y:941,t:1528139798704};\\\", \\\"{x:1425,y:942,t:1528139798729};\\\", \\\"{x:1424,y:942,t:1528139798745};\\\", \\\"{x:1423,y:943,t:1528139798755};\\\", \\\"{x:1422,y:944,t:1528139798772};\\\", \\\"{x:1421,y:944,t:1528139798788};\\\", \\\"{x:1420,y:944,t:1528139798805};\\\", \\\"{x:1418,y:944,t:1528139798822};\\\", \\\"{x:1417,y:944,t:1528139798838};\\\", \\\"{x:1414,y:945,t:1528139798855};\\\", \\\"{x:1412,y:945,t:1528139798872};\\\", \\\"{x:1407,y:945,t:1528139798888};\\\", \\\"{x:1399,y:945,t:1528139798905};\\\", \\\"{x:1393,y:945,t:1528139798922};\\\", \\\"{x:1387,y:945,t:1528139798938};\\\", \\\"{x:1385,y:944,t:1528139798955};\\\", \\\"{x:1380,y:942,t:1528139798972};\\\", \\\"{x:1377,y:939,t:1528139798988};\\\", \\\"{x:1376,y:939,t:1528139799008};\\\", \\\"{x:1376,y:938,t:1528139799025};\\\", \\\"{x:1376,y:937,t:1528139799037};\\\", \\\"{x:1376,y:934,t:1528139799055};\\\", \\\"{x:1376,y:931,t:1528139799073};\\\", \\\"{x:1376,y:929,t:1528139799088};\\\", \\\"{x:1381,y:922,t:1528139799104};\\\", \\\"{x:1386,y:916,t:1528139799122};\\\", \\\"{x:1388,y:913,t:1528139799138};\\\", \\\"{x:1389,y:912,t:1528139799155};\\\", \\\"{x:1389,y:911,t:1528139799172};\\\", \\\"{x:1390,y:909,t:1528139799188};\\\", \\\"{x:1391,y:908,t:1528139799205};\\\", \\\"{x:1392,y:906,t:1528139799225};\\\", \\\"{x:1392,y:905,t:1528139799257};\\\", \\\"{x:1392,y:904,t:1528139799289};\\\", \\\"{x:1392,y:903,t:1528139799305};\\\", \\\"{x:1392,y:902,t:1528139799322};\\\", \\\"{x:1392,y:901,t:1528139799338};\\\", \\\"{x:1392,y:899,t:1528139799354};\\\", \\\"{x:1392,y:898,t:1528139799372};\\\", \\\"{x:1392,y:897,t:1528139800537};\\\", \\\"{x:1391,y:896,t:1528139800561};\\\", \\\"{x:1391,y:895,t:1528139800571};\\\", \\\"{x:1390,y:895,t:1528139800588};\\\", \\\"{x:1389,y:894,t:1528139800605};\\\", \\\"{x:1388,y:892,t:1528139800621};\\\", \\\"{x:1387,y:891,t:1528139800721};\\\", \\\"{x:1387,y:890,t:1528139800768};\\\", \\\"{x:1386,y:890,t:1528139801264};\\\", \\\"{x:1385,y:890,t:1528139801272};\\\", \\\"{x:1379,y:890,t:1528139801288};\\\", \\\"{x:1369,y:890,t:1528139801305};\\\", \\\"{x:1348,y:889,t:1528139801321};\\\", \\\"{x:1320,y:881,t:1528139801338};\\\", \\\"{x:1293,y:873,t:1528139801355};\\\", \\\"{x:1264,y:863,t:1528139801372};\\\", \\\"{x:1233,y:853,t:1528139801388};\\\", \\\"{x:1206,y:844,t:1528139801405};\\\", \\\"{x:1185,y:839,t:1528139801421};\\\", \\\"{x:1172,y:834,t:1528139801438};\\\", \\\"{x:1168,y:832,t:1528139801455};\\\", \\\"{x:1167,y:832,t:1528139801471};\\\", \\\"{x:1167,y:831,t:1528139801577};\\\", \\\"{x:1167,y:830,t:1528139801588};\\\", \\\"{x:1171,y:828,t:1528139801605};\\\", \\\"{x:1174,y:826,t:1528139801621};\\\", \\\"{x:1175,y:826,t:1528139801638};\\\", \\\"{x:1177,y:825,t:1528139801655};\\\", \\\"{x:1177,y:824,t:1528139801670};\\\", \\\"{x:1178,y:824,t:1528139801688};\\\", \\\"{x:1180,y:823,t:1528139801704};\\\", \\\"{x:1181,y:823,t:1528139801753};\\\", \\\"{x:1182,y:823,t:1528139801760};\\\", \\\"{x:1183,y:823,t:1528139801771};\\\", \\\"{x:1185,y:823,t:1528139801788};\\\", \\\"{x:1188,y:823,t:1528139801805};\\\", \\\"{x:1190,y:825,t:1528139801821};\\\", \\\"{x:1191,y:826,t:1528139801837};\\\", \\\"{x:1192,y:826,t:1528139801854};\\\", \\\"{x:1193,y:826,t:1528139801871};\\\", \\\"{x:1196,y:826,t:1528139801887};\\\", \\\"{x:1198,y:826,t:1528139801903};\\\", \\\"{x:1200,y:826,t:1528139801920};\\\", \\\"{x:1202,y:826,t:1528139801937};\\\", \\\"{x:1203,y:826,t:1528139801954};\\\", \\\"{x:1204,y:826,t:1528139801970};\\\", \\\"{x:1205,y:826,t:1528139801992};\\\", \\\"{x:1206,y:826,t:1528139802033};\\\", \\\"{x:1207,y:826,t:1528139802088};\\\", \\\"{x:1208,y:826,t:1528139802145};\\\", \\\"{x:1209,y:826,t:1528139802154};\\\", \\\"{x:1209,y:827,t:1528139802174};\\\", \\\"{x:1210,y:828,t:1528139802188};\\\", \\\"{x:1211,y:829,t:1528139802204};\\\", \\\"{x:1211,y:831,t:1528139802220};\\\", \\\"{x:1212,y:831,t:1528139802256};\\\", \\\"{x:1212,y:830,t:1528139802440};\\\", \\\"{x:1212,y:829,t:1528139802454};\\\", \\\"{x:1212,y:826,t:1528139802471};\\\", \\\"{x:1210,y:821,t:1528139802490};\\\", \\\"{x:1208,y:819,t:1528139802504};\\\", \\\"{x:1206,y:815,t:1528139802521};\\\", \\\"{x:1205,y:811,t:1528139802538};\\\", \\\"{x:1204,y:808,t:1528139802554};\\\", \\\"{x:1202,y:806,t:1528139802571};\\\", \\\"{x:1201,y:802,t:1528139802588};\\\", \\\"{x:1201,y:800,t:1528139802604};\\\", \\\"{x:1199,y:798,t:1528139802621};\\\", \\\"{x:1198,y:796,t:1528139802638};\\\", \\\"{x:1198,y:793,t:1528139802655};\\\", \\\"{x:1198,y:791,t:1528139802671};\\\", \\\"{x:1198,y:787,t:1528139802688};\\\", \\\"{x:1198,y:784,t:1528139802703};\\\", \\\"{x:1198,y:782,t:1528139802720};\\\", \\\"{x:1198,y:779,t:1528139802737};\\\", \\\"{x:1198,y:776,t:1528139802754};\\\", \\\"{x:1198,y:773,t:1528139802771};\\\", \\\"{x:1198,y:772,t:1528139802787};\\\", \\\"{x:1198,y:769,t:1528139802804};\\\", \\\"{x:1198,y:766,t:1528139802820};\\\", \\\"{x:1197,y:764,t:1528139802838};\\\", \\\"{x:1196,y:763,t:1528139802854};\\\", \\\"{x:1195,y:763,t:1528139802870};\\\", \\\"{x:1190,y:763,t:1528139802888};\\\", \\\"{x:1185,y:763,t:1528139802904};\\\", \\\"{x:1182,y:763,t:1528139802920};\\\", \\\"{x:1177,y:765,t:1528139802938};\\\", \\\"{x:1168,y:769,t:1528139802955};\\\", \\\"{x:1158,y:778,t:1528139802971};\\\", \\\"{x:1148,y:791,t:1528139802988};\\\", \\\"{x:1140,y:803,t:1528139803004};\\\", \\\"{x:1132,y:815,t:1528139803021};\\\", \\\"{x:1127,y:831,t:1528139803038};\\\", \\\"{x:1121,y:841,t:1528139803054};\\\", \\\"{x:1116,y:856,t:1528139803071};\\\", \\\"{x:1112,y:885,t:1528139803088};\\\", \\\"{x:1107,y:904,t:1528139803104};\\\", \\\"{x:1104,y:922,t:1528139803121};\\\", \\\"{x:1096,y:935,t:1528139803138};\\\", \\\"{x:1094,y:939,t:1528139803155};\\\", \\\"{x:1092,y:943,t:1528139803171};\\\", \\\"{x:1091,y:943,t:1528139803188};\\\", \\\"{x:1094,y:940,t:1528139803289};\\\", \\\"{x:1105,y:925,t:1528139803305};\\\", \\\"{x:1116,y:904,t:1528139803321};\\\", \\\"{x:1126,y:884,t:1528139803338};\\\", \\\"{x:1136,y:868,t:1528139803355};\\\", \\\"{x:1142,y:856,t:1528139803371};\\\", \\\"{x:1148,y:840,t:1528139803388};\\\", \\\"{x:1156,y:821,t:1528139803404};\\\", \\\"{x:1159,y:808,t:1528139803421};\\\", \\\"{x:1163,y:794,t:1528139803438};\\\", \\\"{x:1168,y:778,t:1528139803454};\\\", \\\"{x:1171,y:770,t:1528139803471};\\\", \\\"{x:1173,y:763,t:1528139803488};\\\", \\\"{x:1175,y:759,t:1528139803504};\\\", \\\"{x:1175,y:756,t:1528139803522};\\\", \\\"{x:1175,y:754,t:1528139803538};\\\", \\\"{x:1175,y:752,t:1528139803554};\\\", \\\"{x:1175,y:751,t:1528139803571};\\\", \\\"{x:1175,y:749,t:1528139803588};\\\", \\\"{x:1175,y:748,t:1528139803604};\\\", \\\"{x:1175,y:747,t:1528139803621};\\\", \\\"{x:1175,y:746,t:1528139803638};\\\", \\\"{x:1174,y:745,t:1528139803654};\\\", \\\"{x:1173,y:744,t:1528139803671};\\\", \\\"{x:1172,y:744,t:1528139803721};\\\", \\\"{x:1172,y:745,t:1528139803833};\\\", \\\"{x:1173,y:746,t:1528139803841};\\\", \\\"{x:1173,y:748,t:1528139803856};\\\", \\\"{x:1174,y:749,t:1528139803871};\\\", \\\"{x:1176,y:752,t:1528139803891};\\\", \\\"{x:1176,y:754,t:1528139803903};\\\", \\\"{x:1177,y:756,t:1528139803920};\\\", \\\"{x:1177,y:757,t:1528139803938};\\\", \\\"{x:1178,y:758,t:1528139803953};\\\", \\\"{x:1178,y:759,t:1528139803970};\\\", \\\"{x:1179,y:759,t:1528139803988};\\\", \\\"{x:1179,y:760,t:1528139804003};\\\", \\\"{x:1179,y:761,t:1528139804021};\\\", \\\"{x:1181,y:765,t:1528139804037};\\\", \\\"{x:1182,y:767,t:1528139804053};\\\", \\\"{x:1183,y:767,t:1528139804071};\\\", \\\"{x:1183,y:768,t:1528139804087};\\\", \\\"{x:1185,y:770,t:1528139804105};\\\", \\\"{x:1186,y:772,t:1528139804120};\\\", \\\"{x:1188,y:776,t:1528139804137};\\\", \\\"{x:1190,y:781,t:1528139804154};\\\", \\\"{x:1193,y:785,t:1528139804171};\\\", \\\"{x:1195,y:787,t:1528139804188};\\\", \\\"{x:1197,y:791,t:1528139804204};\\\", \\\"{x:1198,y:793,t:1528139804221};\\\", \\\"{x:1200,y:796,t:1528139804237};\\\", \\\"{x:1201,y:799,t:1528139804254};\\\", \\\"{x:1202,y:802,t:1528139804271};\\\", \\\"{x:1203,y:806,t:1528139804287};\\\", \\\"{x:1204,y:809,t:1528139804304};\\\", \\\"{x:1206,y:812,t:1528139804321};\\\", \\\"{x:1206,y:813,t:1528139804337};\\\", \\\"{x:1207,y:815,t:1528139804354};\\\", \\\"{x:1207,y:816,t:1528139804371};\\\", \\\"{x:1209,y:820,t:1528139804387};\\\", \\\"{x:1210,y:823,t:1528139804404};\\\", \\\"{x:1211,y:826,t:1528139804421};\\\", \\\"{x:1213,y:830,t:1528139804437};\\\", \\\"{x:1214,y:831,t:1528139804457};\\\", \\\"{x:1214,y:832,t:1528139804471};\\\", \\\"{x:1215,y:835,t:1528139804486};\\\", \\\"{x:1218,y:840,t:1528139804505};\\\", \\\"{x:1219,y:843,t:1528139804520};\\\", \\\"{x:1221,y:845,t:1528139804537};\\\", \\\"{x:1221,y:847,t:1528139804554};\\\", \\\"{x:1221,y:848,t:1528139804571};\\\", \\\"{x:1222,y:850,t:1528139804587};\\\", \\\"{x:1223,y:851,t:1528139804604};\\\", \\\"{x:1224,y:854,t:1528139804621};\\\", \\\"{x:1224,y:856,t:1528139804641};\\\", \\\"{x:1224,y:857,t:1528139804656};\\\", \\\"{x:1225,y:859,t:1528139804671};\\\", \\\"{x:1226,y:861,t:1528139804687};\\\", \\\"{x:1226,y:862,t:1528139804704};\\\", \\\"{x:1227,y:863,t:1528139804721};\\\", \\\"{x:1228,y:864,t:1528139804737};\\\", \\\"{x:1228,y:866,t:1528139804755};\\\", \\\"{x:1229,y:867,t:1528139804777};\\\", \\\"{x:1229,y:869,t:1528139804792};\\\", \\\"{x:1230,y:870,t:1528139804804};\\\", \\\"{x:1231,y:873,t:1528139804821};\\\", \\\"{x:1233,y:877,t:1528139804837};\\\", \\\"{x:1234,y:880,t:1528139804854};\\\", \\\"{x:1235,y:883,t:1528139804871};\\\", \\\"{x:1237,y:885,t:1528139804887};\\\", \\\"{x:1238,y:887,t:1528139804905};\\\", \\\"{x:1240,y:889,t:1528139804921};\\\", \\\"{x:1240,y:890,t:1528139804937};\\\", \\\"{x:1242,y:894,t:1528139804954};\\\", \\\"{x:1245,y:896,t:1528139804971};\\\", \\\"{x:1245,y:897,t:1528139804988};\\\", \\\"{x:1245,y:898,t:1528139805004};\\\", \\\"{x:1246,y:899,t:1528139805020};\\\", \\\"{x:1247,y:900,t:1528139805036};\\\", \\\"{x:1248,y:901,t:1528139805055};\\\", \\\"{x:1248,y:902,t:1528139805070};\\\", \\\"{x:1248,y:903,t:1528139805086};\\\", \\\"{x:1250,y:907,t:1528139805103};\\\", \\\"{x:1251,y:909,t:1528139805127};\\\", \\\"{x:1252,y:911,t:1528139805136};\\\", \\\"{x:1254,y:912,t:1528139805154};\\\", \\\"{x:1254,y:913,t:1528139805171};\\\", \\\"{x:1255,y:915,t:1528139805187};\\\", \\\"{x:1257,y:917,t:1528139805204};\\\", \\\"{x:1258,y:919,t:1528139805221};\\\", \\\"{x:1258,y:921,t:1528139805237};\\\", \\\"{x:1260,y:924,t:1528139805254};\\\", \\\"{x:1260,y:925,t:1528139805273};\\\", \\\"{x:1260,y:927,t:1528139805287};\\\", \\\"{x:1264,y:935,t:1528139805304};\\\", \\\"{x:1265,y:937,t:1528139805320};\\\", \\\"{x:1265,y:942,t:1528139805337};\\\", \\\"{x:1268,y:943,t:1528139805354};\\\", \\\"{x:1268,y:944,t:1528139805371};\\\", \\\"{x:1269,y:946,t:1528139805387};\\\", \\\"{x:1271,y:948,t:1528139805404};\\\", \\\"{x:1271,y:951,t:1528139805421};\\\", \\\"{x:1272,y:953,t:1528139805438};\\\", \\\"{x:1273,y:955,t:1528139805455};\\\", \\\"{x:1274,y:956,t:1528139805471};\\\", \\\"{x:1274,y:957,t:1528139805487};\\\", \\\"{x:1276,y:959,t:1528139805505};\\\", \\\"{x:1276,y:960,t:1528139805521};\\\", \\\"{x:1277,y:960,t:1528139805538};\\\", \\\"{x:1277,y:961,t:1528139805568};\\\", \\\"{x:1277,y:962,t:1528139805576};\\\", \\\"{x:1279,y:964,t:1528139805592};\\\", \\\"{x:1280,y:965,t:1528139805737};\\\", \\\"{x:1281,y:965,t:1528139805754};\\\", \\\"{x:1282,y:967,t:1528139805771};\\\", \\\"{x:1282,y:965,t:1528139806145};\\\", \\\"{x:1278,y:963,t:1528139806154};\\\", \\\"{x:1241,y:944,t:1528139806171};\\\", \\\"{x:1167,y:913,t:1528139806187};\\\", \\\"{x:1046,y:881,t:1528139806204};\\\", \\\"{x:920,y:839,t:1528139806221};\\\", \\\"{x:850,y:804,t:1528139806237};\\\", \\\"{x:812,y:770,t:1528139806254};\\\", \\\"{x:766,y:736,t:1528139806271};\\\", \\\"{x:742,y:720,t:1528139806287};\\\", \\\"{x:716,y:708,t:1528139806304};\\\", \\\"{x:715,y:707,t:1528139806320};\\\", \\\"{x:714,y:705,t:1528139806361};\\\", \\\"{x:711,y:702,t:1528139806370};\\\", \\\"{x:703,y:694,t:1528139806387};\\\", \\\"{x:695,y:683,t:1528139806405};\\\", \\\"{x:683,y:672,t:1528139806421};\\\", \\\"{x:661,y:658,t:1528139806437};\\\", \\\"{x:631,y:640,t:1528139806454};\\\", \\\"{x:593,y:626,t:1528139806472};\\\", \\\"{x:570,y:615,t:1528139806486};\\\", \\\"{x:539,y:604,t:1528139806503};\\\", \\\"{x:526,y:600,t:1528139806521};\\\", \\\"{x:504,y:598,t:1528139806537};\\\", \\\"{x:460,y:591,t:1528139806555};\\\", \\\"{x:427,y:587,t:1528139806572};\\\", \\\"{x:391,y:580,t:1528139806588};\\\", \\\"{x:360,y:572,t:1528139806605};\\\", \\\"{x:313,y:558,t:1528139806622};\\\", \\\"{x:285,y:546,t:1528139806638};\\\", \\\"{x:269,y:542,t:1528139806656};\\\", \\\"{x:265,y:539,t:1528139806671};\\\", \\\"{x:264,y:538,t:1528139806688};\\\", \\\"{x:264,y:536,t:1528139806705};\\\", \\\"{x:263,y:532,t:1528139806722};\\\", \\\"{x:263,y:530,t:1528139806738};\\\", \\\"{x:263,y:529,t:1528139806754};\\\", \\\"{x:264,y:527,t:1528139806771};\\\", \\\"{x:264,y:526,t:1528139806787};\\\", \\\"{x:264,y:524,t:1528139806805};\\\", \\\"{x:264,y:521,t:1528139806821};\\\", \\\"{x:263,y:518,t:1528139806838};\\\", \\\"{x:257,y:516,t:1528139806855};\\\", \\\"{x:248,y:514,t:1528139806872};\\\", \\\"{x:234,y:513,t:1528139806887};\\\", \\\"{x:213,y:512,t:1528139806905};\\\", \\\"{x:196,y:512,t:1528139806922};\\\", \\\"{x:177,y:512,t:1528139806939};\\\", \\\"{x:158,y:507,t:1528139806955};\\\", \\\"{x:143,y:503,t:1528139806972};\\\", \\\"{x:133,y:500,t:1528139806989};\\\", \\\"{x:130,y:498,t:1528139807005};\\\", \\\"{x:130,y:497,t:1528139807022};\\\", \\\"{x:129,y:497,t:1528139807135};\\\", \\\"{x:129,y:496,t:1528139807175};\\\", \\\"{x:131,y:496,t:1528139807189};\\\", \\\"{x:138,y:497,t:1528139807206};\\\", \\\"{x:143,y:498,t:1528139807222};\\\", \\\"{x:145,y:499,t:1528139807223};\\\", \\\"{x:147,y:500,t:1528139807238};\\\", \\\"{x:149,y:501,t:1528139807255};\\\", \\\"{x:150,y:501,t:1528139807985};\\\", \\\"{x:152,y:501,t:1528139807993};\\\", \\\"{x:153,y:501,t:1528139808008};\\\", \\\"{x:155,y:501,t:1528139808023};\\\", \\\"{x:156,y:501,t:1528139808055};\\\", \\\"{x:157,y:501,t:1528139808144};\\\", \\\"{x:158,y:501,t:1528139808159};\\\", \\\"{x:158,y:500,t:1528139808248};\\\", \\\"{x:158,y:500,t:1528139808344};\\\", \\\"{x:159,y:501,t:1528139808721};\\\", \\\"{x:170,y:511,t:1528139808738};\\\", \\\"{x:186,y:526,t:1528139808757};\\\", \\\"{x:209,y:546,t:1528139808771};\\\", \\\"{x:248,y:568,t:1528139808790};\\\", \\\"{x:300,y:589,t:1528139808807};\\\", \\\"{x:337,y:603,t:1528139808823};\\\", \\\"{x:378,y:615,t:1528139808839};\\\", \\\"{x:386,y:615,t:1528139808857};\\\", \\\"{x:388,y:615,t:1528139809000};\\\", \\\"{x:390,y:615,t:1528139809007};\\\", \\\"{x:391,y:614,t:1528139809022};\\\", \\\"{x:395,y:613,t:1528139809200};\\\", \\\"{x:397,y:611,t:1528139809208};\\\", \\\"{x:404,y:607,t:1528139809223};\\\", \\\"{x:427,y:592,t:1528139809243};\\\", \\\"{x:440,y:583,t:1528139809257};\\\", \\\"{x:462,y:575,t:1528139809273};\\\", \\\"{x:497,y:560,t:1528139809290};\\\", \\\"{x:536,y:543,t:1528139809307};\\\", \\\"{x:568,y:529,t:1528139809324};\\\", \\\"{x:590,y:521,t:1528139809340};\\\", \\\"{x:612,y:514,t:1528139809357};\\\", \\\"{x:628,y:509,t:1528139809374};\\\", \\\"{x:641,y:506,t:1528139809390};\\\", \\\"{x:651,y:505,t:1528139809407};\\\", \\\"{x:660,y:503,t:1528139809423};\\\", \\\"{x:662,y:502,t:1528139809440};\\\", \\\"{x:665,y:501,t:1528139809456};\\\", \\\"{x:666,y:501,t:1528139809473};\\\", \\\"{x:667,y:501,t:1528139809491};\\\", \\\"{x:668,y:501,t:1528139809519};\\\", \\\"{x:669,y:501,t:1528139809536};\\\", \\\"{x:669,y:500,t:1528139809544};\\\", \\\"{x:674,y:500,t:1528139809937};\\\", \\\"{x:685,y:500,t:1528139809944};\\\", \\\"{x:700,y:500,t:1528139809958};\\\", \\\"{x:733,y:506,t:1528139809977};\\\", \\\"{x:813,y:527,t:1528139809993};\\\", \\\"{x:879,y:545,t:1528139810007};\\\", \\\"{x:937,y:560,t:1528139810024};\\\", \\\"{x:987,y:572,t:1528139810040};\\\", \\\"{x:1022,y:584,t:1528139810057};\\\", \\\"{x:1040,y:592,t:1528139810074};\\\", \\\"{x:1058,y:599,t:1528139810090};\\\", \\\"{x:1073,y:605,t:1528139810107};\\\", \\\"{x:1088,y:612,t:1528139810124};\\\", \\\"{x:1101,y:616,t:1528139810139};\\\", \\\"{x:1110,y:618,t:1528139810157};\\\", \\\"{x:1118,y:621,t:1528139810174};\\\", \\\"{x:1123,y:624,t:1528139810191};\\\", \\\"{x:1127,y:627,t:1528139810208};\\\", \\\"{x:1136,y:636,t:1528139810223};\\\", \\\"{x:1160,y:657,t:1528139810240};\\\", \\\"{x:1172,y:667,t:1528139810257};\\\", \\\"{x:1178,y:673,t:1528139810273};\\\", \\\"{x:1181,y:678,t:1528139810291};\\\", \\\"{x:1184,y:684,t:1528139810308};\\\", \\\"{x:1185,y:690,t:1528139810324};\\\", \\\"{x:1188,y:699,t:1528139810340};\\\", \\\"{x:1189,y:705,t:1528139810356};\\\", \\\"{x:1189,y:710,t:1528139810374};\\\", \\\"{x:1189,y:714,t:1528139810393};\\\", \\\"{x:1189,y:715,t:1528139810405};\\\", \\\"{x:1190,y:719,t:1528139810423};\\\", \\\"{x:1192,y:725,t:1528139810439};\\\", \\\"{x:1193,y:739,t:1528139810456};\\\", \\\"{x:1194,y:745,t:1528139810473};\\\", \\\"{x:1196,y:752,t:1528139810489};\\\", \\\"{x:1197,y:757,t:1528139810506};\\\", \\\"{x:1198,y:764,t:1528139810523};\\\", \\\"{x:1201,y:770,t:1528139810539};\\\", \\\"{x:1202,y:776,t:1528139810556};\\\", \\\"{x:1204,y:782,t:1528139810572};\\\", \\\"{x:1205,y:787,t:1528139810590};\\\", \\\"{x:1206,y:793,t:1528139810607};\\\", \\\"{x:1208,y:799,t:1528139810622};\\\", \\\"{x:1209,y:804,t:1528139810640};\\\", \\\"{x:1210,y:805,t:1528139810655};\\\", \\\"{x:1210,y:808,t:1528139810672};\\\", \\\"{x:1212,y:810,t:1528139810689};\\\", \\\"{x:1212,y:812,t:1528139810705};\\\", \\\"{x:1212,y:813,t:1528139810722};\\\", \\\"{x:1213,y:814,t:1528139810739};\\\", \\\"{x:1213,y:816,t:1528139810776};\\\", \\\"{x:1213,y:817,t:1528139810808};\\\", \\\"{x:1213,y:818,t:1528139810865};\\\", \\\"{x:1213,y:820,t:1528139810872};\\\", \\\"{x:1213,y:824,t:1528139810888};\\\", \\\"{x:1213,y:828,t:1528139810906};\\\", \\\"{x:1213,y:829,t:1528139810921};\\\", \\\"{x:1213,y:830,t:1528139810938};\\\", \\\"{x:1213,y:832,t:1528139811368};\\\", \\\"{x:1212,y:834,t:1528139811384};\\\", \\\"{x:1212,y:835,t:1528139811392};\\\", \\\"{x:1210,y:837,t:1528139811404};\\\", \\\"{x:1207,y:841,t:1528139811421};\\\", \\\"{x:1203,y:849,t:1528139811437};\\\", \\\"{x:1198,y:858,t:1528139811454};\\\", \\\"{x:1195,y:864,t:1528139811471};\\\", \\\"{x:1191,y:874,t:1528139811487};\\\", \\\"{x:1190,y:879,t:1528139811504};\\\", \\\"{x:1187,y:887,t:1528139811520};\\\", \\\"{x:1184,y:897,t:1528139811536};\\\", \\\"{x:1180,y:907,t:1528139811553};\\\", \\\"{x:1174,y:920,t:1528139811569};\\\", \\\"{x:1169,y:932,t:1528139811587};\\\", \\\"{x:1165,y:941,t:1528139811603};\\\", \\\"{x:1162,y:948,t:1528139811620};\\\", \\\"{x:1161,y:950,t:1528139811636};\\\", \\\"{x:1160,y:953,t:1528139811652};\\\", \\\"{x:1158,y:957,t:1528139811670};\\\", \\\"{x:1157,y:959,t:1528139811686};\\\", \\\"{x:1157,y:961,t:1528139811702};\\\", \\\"{x:1156,y:962,t:1528139811720};\\\", \\\"{x:1155,y:963,t:1528139811736};\\\", \\\"{x:1153,y:966,t:1528139811753};\\\", \\\"{x:1152,y:966,t:1528139811777};\\\", \\\"{x:1152,y:967,t:1528139811935};\\\", \\\"{x:1154,y:965,t:1528139818257};\\\", \\\"{x:1164,y:951,t:1528139818266};\\\", \\\"{x:1183,y:925,t:1528139818282};\\\", \\\"{x:1209,y:886,t:1528139818299};\\\", \\\"{x:1236,y:840,t:1528139818316};\\\", \\\"{x:1252,y:806,t:1528139818333};\\\", \\\"{x:1266,y:768,t:1528139818349};\\\", \\\"{x:1273,y:738,t:1528139818366};\\\", \\\"{x:1281,y:717,t:1528139818382};\\\", \\\"{x:1284,y:697,t:1528139818398};\\\", \\\"{x:1288,y:674,t:1528139818415};\\\", \\\"{x:1288,y:667,t:1528139818431};\\\", \\\"{x:1288,y:662,t:1528139818448};\\\", \\\"{x:1288,y:659,t:1528139818465};\\\", \\\"{x:1291,y:656,t:1528139818481};\\\", \\\"{x:1295,y:650,t:1528139818499};\\\", \\\"{x:1296,y:648,t:1528139818514};\\\", \\\"{x:1296,y:645,t:1528139818531};\\\", \\\"{x:1296,y:644,t:1528139818548};\\\", \\\"{x:1296,y:643,t:1528139818568};\\\", \\\"{x:1298,y:640,t:1528139818581};\\\", \\\"{x:1299,y:633,t:1528139818598};\\\", \\\"{x:1299,y:622,t:1528139818614};\\\", \\\"{x:1299,y:609,t:1528139818632};\\\", \\\"{x:1299,y:606,t:1528139818648};\\\", \\\"{x:1299,y:604,t:1528139818664};\\\", \\\"{x:1299,y:602,t:1528139818682};\\\", \\\"{x:1299,y:599,t:1528139818698};\\\", \\\"{x:1299,y:595,t:1528139818715};\\\", \\\"{x:1299,y:589,t:1528139818730};\\\", \\\"{x:1299,y:585,t:1528139818748};\\\", \\\"{x:1299,y:582,t:1528139818765};\\\", \\\"{x:1301,y:579,t:1528139818780};\\\", \\\"{x:1302,y:577,t:1528139818797};\\\", \\\"{x:1302,y:576,t:1528139818815};\\\", \\\"{x:1303,y:574,t:1528139818831};\\\", \\\"{x:1304,y:575,t:1528139819023};\\\", \\\"{x:1305,y:576,t:1528139819031};\\\", \\\"{x:1305,y:579,t:1528139819046};\\\", \\\"{x:1309,y:589,t:1528139819063};\\\", \\\"{x:1310,y:594,t:1528139819079};\\\", \\\"{x:1311,y:602,t:1528139819096};\\\", \\\"{x:1313,y:607,t:1528139819113};\\\", \\\"{x:1314,y:611,t:1528139819129};\\\", \\\"{x:1314,y:614,t:1528139819146};\\\", \\\"{x:1315,y:618,t:1528139819163};\\\", \\\"{x:1315,y:624,t:1528139819179};\\\", \\\"{x:1317,y:632,t:1528139819197};\\\", \\\"{x:1319,y:636,t:1528139819213};\\\", \\\"{x:1319,y:642,t:1528139819230};\\\", \\\"{x:1320,y:646,t:1528139819247};\\\", \\\"{x:1322,y:648,t:1528139819262};\\\", \\\"{x:1322,y:655,t:1528139819280};\\\", \\\"{x:1325,y:659,t:1528139819297};\\\", \\\"{x:1325,y:662,t:1528139819312};\\\", \\\"{x:1326,y:666,t:1528139819330};\\\", \\\"{x:1328,y:670,t:1528139819346};\\\", \\\"{x:1329,y:673,t:1528139819363};\\\", \\\"{x:1329,y:674,t:1528139819378};\\\", \\\"{x:1330,y:676,t:1528139819396};\\\", \\\"{x:1332,y:680,t:1528139819413};\\\", \\\"{x:1333,y:682,t:1528139819428};\\\", \\\"{x:1334,y:684,t:1528139819446};\\\", \\\"{x:1334,y:687,t:1528139819462};\\\", \\\"{x:1337,y:691,t:1528139819478};\\\", \\\"{x:1339,y:696,t:1528139819495};\\\", \\\"{x:1339,y:698,t:1528139819511};\\\", \\\"{x:1340,y:700,t:1528139819528};\\\", \\\"{x:1343,y:706,t:1528139819545};\\\", \\\"{x:1343,y:710,t:1528139819562};\\\", \\\"{x:1347,y:715,t:1528139819579};\\\", \\\"{x:1349,y:717,t:1528139819594};\\\", \\\"{x:1349,y:719,t:1528139819611};\\\", \\\"{x:1349,y:720,t:1528139819629};\\\", \\\"{x:1351,y:725,t:1528139819645};\\\", \\\"{x:1352,y:731,t:1528139819661};\\\", \\\"{x:1357,y:736,t:1528139819679};\\\", \\\"{x:1358,y:740,t:1528139819694};\\\", \\\"{x:1360,y:743,t:1528139819711};\\\", \\\"{x:1360,y:746,t:1528139819727};\\\", \\\"{x:1362,y:749,t:1528139819744};\\\", \\\"{x:1364,y:755,t:1528139819762};\\\", \\\"{x:1366,y:757,t:1528139819778};\\\", \\\"{x:1366,y:760,t:1528139819795};\\\", \\\"{x:1367,y:761,t:1528139819816};\\\", \\\"{x:1367,y:762,t:1528139819828};\\\", \\\"{x:1369,y:764,t:1528139819844};\\\", \\\"{x:1369,y:765,t:1528139819861};\\\", \\\"{x:1370,y:766,t:1528139819878};\\\", \\\"{x:1370,y:769,t:1528139819895};\\\", \\\"{x:1372,y:771,t:1528139819911};\\\", \\\"{x:1375,y:779,t:1528139819928};\\\", \\\"{x:1378,y:783,t:1528139819945};\\\", \\\"{x:1380,y:787,t:1528139819961};\\\", \\\"{x:1381,y:788,t:1528139819978};\\\", \\\"{x:1383,y:792,t:1528139819994};\\\", \\\"{x:1384,y:796,t:1528139820011};\\\", \\\"{x:1387,y:800,t:1528139820026};\\\", \\\"{x:1388,y:803,t:1528139820044};\\\", \\\"{x:1391,y:808,t:1528139820061};\\\", \\\"{x:1394,y:814,t:1528139820077};\\\", \\\"{x:1400,y:819,t:1528139820094};\\\", \\\"{x:1405,y:827,t:1528139820110};\\\", \\\"{x:1412,y:839,t:1528139820127};\\\", \\\"{x:1426,y:858,t:1528139820144};\\\", \\\"{x:1437,y:870,t:1528139820160};\\\", \\\"{x:1450,y:880,t:1528139820176};\\\", \\\"{x:1460,y:889,t:1528139820194};\\\", \\\"{x:1470,y:896,t:1528139820210};\\\", \\\"{x:1474,y:901,t:1528139820228};\\\", \\\"{x:1477,y:904,t:1528139820243};\\\", \\\"{x:1479,y:909,t:1528139820260};\\\", \\\"{x:1484,y:918,t:1528139820277};\\\", \\\"{x:1492,y:926,t:1528139820293};\\\", \\\"{x:1497,y:932,t:1528139820310};\\\", \\\"{x:1499,y:936,t:1528139820327};\\\", \\\"{x:1501,y:938,t:1528139820343};\\\", \\\"{x:1505,y:945,t:1528139820360};\\\", \\\"{x:1508,y:951,t:1528139820376};\\\", \\\"{x:1511,y:957,t:1528139820393};\\\", \\\"{x:1511,y:959,t:1528139820410};\\\", \\\"{x:1512,y:960,t:1528139820426};\\\", \\\"{x:1512,y:961,t:1528139820443};\\\", \\\"{x:1514,y:963,t:1528139820459};\\\", \\\"{x:1514,y:964,t:1528139820476};\\\", \\\"{x:1514,y:965,t:1528139820601};\\\", \\\"{x:1514,y:966,t:1528139820608};\\\", \\\"{x:1511,y:966,t:1528139820626};\\\", \\\"{x:1510,y:967,t:1528139820642};\\\", \\\"{x:1509,y:968,t:1528139820659};\\\", \\\"{x:1508,y:969,t:1528139820680};\\\", \\\"{x:1507,y:969,t:1528139820696};\\\", \\\"{x:1505,y:969,t:1528139820709};\\\", \\\"{x:1502,y:969,t:1528139820725};\\\", \\\"{x:1498,y:969,t:1528139820742};\\\", \\\"{x:1495,y:969,t:1528139820758};\\\", \\\"{x:1488,y:969,t:1528139820775};\\\", \\\"{x:1484,y:968,t:1528139820792};\\\", \\\"{x:1480,y:965,t:1528139820808};\\\", \\\"{x:1479,y:965,t:1528139820825};\\\", \\\"{x:1479,y:964,t:1528139820842};\\\", \\\"{x:1479,y:962,t:1528139820858};\\\", \\\"{x:1478,y:962,t:1528139820888};\\\", \\\"{x:1478,y:961,t:1528139820920};\\\", \\\"{x:1478,y:959,t:1528139820961};\\\", \\\"{x:1477,y:958,t:1528139821257};\\\", \\\"{x:1476,y:956,t:1528139821274};\\\", \\\"{x:1476,y:955,t:1528139821290};\\\", \\\"{x:1475,y:954,t:1528139821312};\\\", \\\"{x:1474,y:953,t:1528139821352};\\\", \\\"{x:1473,y:952,t:1528139821360};\\\", \\\"{x:1472,y:952,t:1528139821377};\\\", \\\"{x:1471,y:952,t:1528139821392};\\\", \\\"{x:1471,y:951,t:1528139821407};\\\", \\\"{x:1470,y:951,t:1528139821441};\\\", \\\"{x:1469,y:951,t:1528139821529};\\\", \\\"{x:1468,y:951,t:1528139821585};\\\", \\\"{x:1467,y:951,t:1528139821600};\\\", \\\"{x:1465,y:951,t:1528139821608};\\\", \\\"{x:1464,y:951,t:1528139821625};\\\", \\\"{x:1463,y:952,t:1528139821639};\\\", \\\"{x:1456,y:956,t:1528139821656};\\\", \\\"{x:1449,y:958,t:1528139821672};\\\", \\\"{x:1444,y:960,t:1528139821689};\\\", \\\"{x:1442,y:961,t:1528139821706};\\\", \\\"{x:1440,y:961,t:1528139824321};\\\", \\\"{x:1434,y:960,t:1528139824331};\\\", \\\"{x:1409,y:947,t:1528139824347};\\\", \\\"{x:1355,y:928,t:1528139824364};\\\", \\\"{x:1276,y:900,t:1528139824381};\\\", \\\"{x:1170,y:865,t:1528139824397};\\\", \\\"{x:1040,y:829,t:1528139824414};\\\", \\\"{x:889,y:789,t:1528139824430};\\\", \\\"{x:735,y:754,t:1528139824447};\\\", \\\"{x:520,y:722,t:1528139824465};\\\", \\\"{x:407,y:710,t:1528139824481};\\\", \\\"{x:271,y:693,t:1528139824514};\\\", \\\"{x:253,y:690,t:1528139824529};\\\", \\\"{x:252,y:690,t:1528139824546};\\\", \\\"{x:251,y:690,t:1528139824639};\\\", \\\"{x:251,y:691,t:1528139824655};\\\", \\\"{x:251,y:693,t:1528139824663};\\\", \\\"{x:258,y:696,t:1528139824679};\\\", \\\"{x:275,y:698,t:1528139824697};\\\", \\\"{x:303,y:703,t:1528139824713};\\\", \\\"{x:338,y:709,t:1528139824730};\\\", \\\"{x:380,y:715,t:1528139824747};\\\", \\\"{x:415,y:721,t:1528139824764};\\\", \\\"{x:441,y:723,t:1528139824780};\\\", \\\"{x:457,y:727,t:1528139824798};\\\", \\\"{x:465,y:728,t:1528139824813};\\\", \\\"{x:467,y:728,t:1528139824837};\\\", \\\"{x:468,y:728,t:1528139824879};\\\", \\\"{x:469,y:728,t:1528139824912};\\\", \\\"{x:470,y:728,t:1528139824927};\\\", \\\"{x:471,y:728,t:1528139824944};\\\", \\\"{x:472,y:728,t:1528139824954};\\\" ] }, { \\\"rt\\\": 9704, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 578389, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -02 PM-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:732,t:1528139827377};\\\", \\\"{x:508,y:741,t:1528139827389};\\\", \\\"{x:567,y:768,t:1528139827422};\\\", \\\"{x:645,y:790,t:1528139827440};\\\", \\\"{x:680,y:799,t:1528139827454};\\\", \\\"{x:770,y:817,t:1528139827471};\\\", \\\"{x:808,y:823,t:1528139827487};\\\", \\\"{x:826,y:825,t:1528139827504};\\\", \\\"{x:827,y:825,t:1528139827522};\\\", \\\"{x:828,y:825,t:1528139827960};\\\", \\\"{x:829,y:825,t:1528139827984};\\\", \\\"{x:833,y:825,t:1528139828304};\\\", \\\"{x:837,y:825,t:1528139828312};\\\", \\\"{x:847,y:825,t:1528139828322};\\\", \\\"{x:863,y:825,t:1528139828338};\\\", \\\"{x:895,y:825,t:1528139828356};\\\", \\\"{x:937,y:826,t:1528139828372};\\\", \\\"{x:980,y:833,t:1528139828389};\\\", \\\"{x:1033,y:841,t:1528139828406};\\\", \\\"{x:1062,y:849,t:1528139828422};\\\", \\\"{x:1090,y:856,t:1528139828439};\\\", \\\"{x:1114,y:859,t:1528139828456};\\\", \\\"{x:1128,y:863,t:1528139828472};\\\", \\\"{x:1139,y:864,t:1528139828489};\\\", \\\"{x:1150,y:866,t:1528139828506};\\\", \\\"{x:1160,y:866,t:1528139828522};\\\", \\\"{x:1171,y:866,t:1528139828539};\\\", \\\"{x:1185,y:866,t:1528139828556};\\\", \\\"{x:1192,y:866,t:1528139828573};\\\", \\\"{x:1196,y:866,t:1528139828589};\\\", \\\"{x:1199,y:866,t:1528139828606};\\\", \\\"{x:1204,y:865,t:1528139828624};\\\", \\\"{x:1206,y:863,t:1528139828639};\\\", \\\"{x:1218,y:861,t:1528139828656};\\\", \\\"{x:1227,y:858,t:1528139828673};\\\", \\\"{x:1237,y:854,t:1528139828689};\\\", \\\"{x:1244,y:852,t:1528139828706};\\\", \\\"{x:1254,y:845,t:1528139828723};\\\", \\\"{x:1265,y:834,t:1528139828739};\\\", \\\"{x:1273,y:827,t:1528139828756};\\\", \\\"{x:1279,y:819,t:1528139828773};\\\", \\\"{x:1288,y:809,t:1528139828789};\\\", \\\"{x:1293,y:802,t:1528139828806};\\\", \\\"{x:1301,y:794,t:1528139828823};\\\", \\\"{x:1309,y:786,t:1528139828840};\\\", \\\"{x:1315,y:778,t:1528139828856};\\\", \\\"{x:1323,y:764,t:1528139828874};\\\", \\\"{x:1328,y:757,t:1528139828889};\\\", \\\"{x:1329,y:751,t:1528139828906};\\\", \\\"{x:1333,y:745,t:1528139828923};\\\", \\\"{x:1336,y:742,t:1528139828939};\\\", \\\"{x:1340,y:737,t:1528139828956};\\\", \\\"{x:1344,y:730,t:1528139828973};\\\", \\\"{x:1345,y:724,t:1528139828990};\\\", \\\"{x:1345,y:718,t:1528139829006};\\\", \\\"{x:1346,y:714,t:1528139829023};\\\", \\\"{x:1348,y:709,t:1528139829039};\\\", \\\"{x:1348,y:708,t:1528139829056};\\\", \\\"{x:1348,y:707,t:1528139829073};\\\", \\\"{x:1348,y:706,t:1528139829090};\\\", \\\"{x:1349,y:704,t:1528139829106};\\\", \\\"{x:1351,y:701,t:1528139829127};\\\", \\\"{x:1352,y:699,t:1528139829140};\\\", \\\"{x:1353,y:698,t:1528139829207};\\\", \\\"{x:1355,y:697,t:1528139829232};\\\", \\\"{x:1355,y:698,t:1528139829385};\\\", \\\"{x:1355,y:701,t:1528139829392};\\\", \\\"{x:1356,y:703,t:1528139829406};\\\", \\\"{x:1358,y:712,t:1528139829423};\\\", \\\"{x:1362,y:724,t:1528139829440};\\\", \\\"{x:1367,y:733,t:1528139829458};\\\", \\\"{x:1370,y:741,t:1528139829473};\\\", \\\"{x:1372,y:746,t:1528139829491};\\\", \\\"{x:1373,y:750,t:1528139829508};\\\", \\\"{x:1375,y:755,t:1528139829524};\\\", \\\"{x:1376,y:761,t:1528139829541};\\\", \\\"{x:1377,y:763,t:1528139829557};\\\", \\\"{x:1379,y:768,t:1528139829573};\\\", \\\"{x:1379,y:772,t:1528139829590};\\\", \\\"{x:1380,y:775,t:1528139829607};\\\", \\\"{x:1383,y:781,t:1528139829624};\\\", \\\"{x:1384,y:785,t:1528139829640};\\\", \\\"{x:1386,y:791,t:1528139829658};\\\", \\\"{x:1388,y:797,t:1528139829674};\\\", \\\"{x:1390,y:801,t:1528139829690};\\\", \\\"{x:1391,y:803,t:1528139829707};\\\", \\\"{x:1392,y:808,t:1528139829723};\\\", \\\"{x:1395,y:813,t:1528139829740};\\\", \\\"{x:1398,y:819,t:1528139829757};\\\", \\\"{x:1402,y:827,t:1528139829773};\\\", \\\"{x:1405,y:835,t:1528139829791};\\\", \\\"{x:1410,y:844,t:1528139829807};\\\", \\\"{x:1416,y:856,t:1528139829823};\\\", \\\"{x:1425,y:876,t:1528139829840};\\\", \\\"{x:1435,y:891,t:1528139829858};\\\", \\\"{x:1442,y:906,t:1528139829874};\\\", \\\"{x:1450,y:918,t:1528139829891};\\\", \\\"{x:1456,y:932,t:1528139829907};\\\", \\\"{x:1460,y:941,t:1528139829925};\\\", \\\"{x:1463,y:949,t:1528139829940};\\\", \\\"{x:1466,y:959,t:1528139829958};\\\", \\\"{x:1470,y:968,t:1528139829974};\\\", \\\"{x:1474,y:974,t:1528139829991};\\\", \\\"{x:1474,y:977,t:1528139830007};\\\", \\\"{x:1475,y:977,t:1528139830032};\\\", \\\"{x:1475,y:975,t:1528139830129};\\\", \\\"{x:1475,y:968,t:1528139830141};\\\", \\\"{x:1474,y:954,t:1528139830157};\\\", \\\"{x:1472,y:937,t:1528139830174};\\\", \\\"{x:1468,y:913,t:1528139830190};\\\", \\\"{x:1466,y:893,t:1528139830207};\\\", \\\"{x:1459,y:859,t:1528139830224};\\\", \\\"{x:1452,y:841,t:1528139830241};\\\", \\\"{x:1446,y:828,t:1528139830257};\\\", \\\"{x:1443,y:823,t:1528139830274};\\\", \\\"{x:1434,y:811,t:1528139830290};\\\", \\\"{x:1425,y:799,t:1528139830307};\\\", \\\"{x:1414,y:784,t:1528139830325};\\\", \\\"{x:1401,y:767,t:1528139830341};\\\", \\\"{x:1390,y:754,t:1528139830357};\\\", \\\"{x:1380,y:741,t:1528139830374};\\\", \\\"{x:1373,y:729,t:1528139830391};\\\", \\\"{x:1368,y:720,t:1528139830408};\\\", \\\"{x:1366,y:715,t:1528139830424};\\\", \\\"{x:1366,y:714,t:1528139830448};\\\", \\\"{x:1366,y:713,t:1528139830497};\\\", \\\"{x:1364,y:712,t:1528139830520};\\\", \\\"{x:1364,y:711,t:1528139830528};\\\", \\\"{x:1364,y:709,t:1528139830541};\\\", \\\"{x:1360,y:702,t:1528139830558};\\\", \\\"{x:1358,y:698,t:1528139830574};\\\", \\\"{x:1355,y:695,t:1528139830591};\\\", \\\"{x:1354,y:694,t:1528139830607};\\\", \\\"{x:1352,y:686,t:1528139830624};\\\", \\\"{x:1350,y:671,t:1528139830642};\\\", \\\"{x:1343,y:647,t:1528139830658};\\\", \\\"{x:1337,y:628,t:1528139830674};\\\", \\\"{x:1336,y:615,t:1528139830692};\\\", \\\"{x:1334,y:605,t:1528139830708};\\\", \\\"{x:1334,y:596,t:1528139830725};\\\", \\\"{x:1331,y:586,t:1528139830742};\\\", \\\"{x:1330,y:580,t:1528139830758};\\\", \\\"{x:1326,y:574,t:1528139830775};\\\", \\\"{x:1324,y:572,t:1528139830791};\\\", \\\"{x:1324,y:571,t:1528139830888};\\\", \\\"{x:1323,y:571,t:1528139830896};\\\", \\\"{x:1322,y:571,t:1528139830908};\\\", \\\"{x:1320,y:570,t:1528139830925};\\\", \\\"{x:1318,y:570,t:1528139830942};\\\", \\\"{x:1316,y:569,t:1528139830959};\\\", \\\"{x:1314,y:569,t:1528139830974};\\\", \\\"{x:1311,y:569,t:1528139830992};\\\", \\\"{x:1308,y:567,t:1528139831007};\\\", \\\"{x:1301,y:567,t:1528139831024};\\\", \\\"{x:1297,y:565,t:1528139831042};\\\", \\\"{x:1293,y:564,t:1528139831058};\\\", \\\"{x:1289,y:563,t:1528139831074};\\\", \\\"{x:1286,y:562,t:1528139831092};\\\", \\\"{x:1285,y:561,t:1528139831109};\\\", \\\"{x:1283,y:561,t:1528139831125};\\\", \\\"{x:1282,y:561,t:1528139831142};\\\", \\\"{x:1280,y:560,t:1528139831159};\\\", \\\"{x:1279,y:560,t:1528139831176};\\\", \\\"{x:1275,y:560,t:1528139833042};\\\", \\\"{x:1254,y:561,t:1528139833059};\\\", \\\"{x:1209,y:565,t:1528139833076};\\\", \\\"{x:1145,y:574,t:1528139833092};\\\", \\\"{x:1061,y:587,t:1528139833108};\\\", \\\"{x:965,y:597,t:1528139833125};\\\", \\\"{x:867,y:599,t:1528139833141};\\\", \\\"{x:798,y:599,t:1528139833158};\\\", \\\"{x:711,y:599,t:1528139833175};\\\", \\\"{x:671,y:599,t:1528139833191};\\\", \\\"{x:647,y:599,t:1528139833208};\\\", \\\"{x:630,y:598,t:1528139833226};\\\", \\\"{x:623,y:598,t:1528139833242};\\\", \\\"{x:619,y:598,t:1528139833259};\\\", \\\"{x:614,y:598,t:1528139833276};\\\", \\\"{x:611,y:598,t:1528139833292};\\\", \\\"{x:610,y:598,t:1528139833309};\\\", \\\"{x:608,y:598,t:1528139833326};\\\", \\\"{x:605,y:598,t:1528139833343};\\\", \\\"{x:584,y:596,t:1528139833360};\\\", \\\"{x:564,y:593,t:1528139833378};\\\", \\\"{x:548,y:591,t:1528139833392};\\\", \\\"{x:538,y:588,t:1528139833409};\\\", \\\"{x:518,y:581,t:1528139833425};\\\", \\\"{x:496,y:579,t:1528139833443};\\\", \\\"{x:465,y:574,t:1528139833459};\\\", \\\"{x:426,y:571,t:1528139833476};\\\", \\\"{x:396,y:564,t:1528139833493};\\\", \\\"{x:375,y:561,t:1528139833510};\\\", \\\"{x:353,y:557,t:1528139833526};\\\", \\\"{x:311,y:552,t:1528139833543};\\\", \\\"{x:292,y:551,t:1528139833560};\\\", \\\"{x:281,y:550,t:1528139833577};\\\", \\\"{x:278,y:548,t:1528139833593};\\\", \\\"{x:276,y:547,t:1528139833609};\\\", \\\"{x:275,y:547,t:1528139833639};\\\", \\\"{x:275,y:545,t:1528139833647};\\\", \\\"{x:275,y:544,t:1528139833663};\\\", \\\"{x:275,y:543,t:1528139833677};\\\", \\\"{x:282,y:538,t:1528139833693};\\\", \\\"{x:296,y:531,t:1528139833709};\\\", \\\"{x:318,y:525,t:1528139833726};\\\", \\\"{x:404,y:504,t:1528139833744};\\\", \\\"{x:482,y:493,t:1528139833761};\\\", \\\"{x:555,y:490,t:1528139833778};\\\", \\\"{x:624,y:483,t:1528139833793};\\\", \\\"{x:669,y:483,t:1528139833809};\\\", \\\"{x:703,y:483,t:1528139833827};\\\", \\\"{x:724,y:483,t:1528139833843};\\\", \\\"{x:734,y:483,t:1528139833860};\\\", \\\"{x:735,y:483,t:1528139833877};\\\", \\\"{x:735,y:485,t:1528139833960};\\\", \\\"{x:729,y:488,t:1528139833979};\\\", \\\"{x:719,y:493,t:1528139833993};\\\", \\\"{x:710,y:494,t:1528139834010};\\\", \\\"{x:697,y:498,t:1528139834027};\\\", \\\"{x:688,y:501,t:1528139834044};\\\", \\\"{x:682,y:503,t:1528139834060};\\\", \\\"{x:677,y:504,t:1528139834077};\\\", \\\"{x:674,y:505,t:1528139834094};\\\", \\\"{x:672,y:505,t:1528139834110};\\\", \\\"{x:670,y:505,t:1528139834126};\\\", \\\"{x:669,y:505,t:1528139834160};\\\", \\\"{x:666,y:506,t:1528139834177};\\\", \\\"{x:663,y:506,t:1528139834194};\\\", \\\"{x:657,y:505,t:1528139834210};\\\", \\\"{x:654,y:504,t:1528139834228};\\\", \\\"{x:650,y:502,t:1528139834245};\\\", \\\"{x:647,y:501,t:1528139834260};\\\", \\\"{x:644,y:500,t:1528139834277};\\\", \\\"{x:644,y:499,t:1528139834294};\\\", \\\"{x:642,y:499,t:1528139834473};\\\", \\\"{x:641,y:499,t:1528139834480};\\\", \\\"{x:638,y:500,t:1528139834494};\\\", \\\"{x:630,y:519,t:1528139834512};\\\", \\\"{x:612,y:543,t:1528139834528};\\\", \\\"{x:587,y:573,t:1528139834543};\\\", \\\"{x:570,y:592,t:1528139834560};\\\", \\\"{x:561,y:602,t:1528139834578};\\\", \\\"{x:560,y:604,t:1528139834639};\\\", \\\"{x:560,y:605,t:1528139834655};\\\", \\\"{x:558,y:609,t:1528139834663};\\\", \\\"{x:558,y:611,t:1528139834679};\\\", \\\"{x:558,y:613,t:1528139834694};\\\", \\\"{x:558,y:615,t:1528139834711};\\\", \\\"{x:561,y:613,t:1528139834776};\\\", \\\"{x:564,y:608,t:1528139834783};\\\", \\\"{x:571,y:599,t:1528139834796};\\\", \\\"{x:582,y:582,t:1528139834812};\\\", \\\"{x:591,y:563,t:1528139834826};\\\", \\\"{x:603,y:538,t:1528139834844};\\\", \\\"{x:613,y:520,t:1528139834862};\\\", \\\"{x:624,y:505,t:1528139834877};\\\", \\\"{x:628,y:497,t:1528139834894};\\\", \\\"{x:628,y:494,t:1528139834911};\\\", \\\"{x:629,y:493,t:1528139834927};\\\", \\\"{x:629,y:492,t:1528139835031};\\\", \\\"{x:629,y:491,t:1528139835044};\\\", \\\"{x:627,y:491,t:1528139835072};\\\", \\\"{x:624,y:491,t:1528139835088};\\\", \\\"{x:623,y:491,t:1528139835095};\\\", \\\"{x:619,y:492,t:1528139835111};\\\", \\\"{x:617,y:492,t:1528139835128};\\\", \\\"{x:615,y:494,t:1528139835144};\\\", \\\"{x:612,y:495,t:1528139835162};\\\", \\\"{x:611,y:495,t:1528139835178};\\\", \\\"{x:611,y:496,t:1528139835463};\\\", \\\"{x:610,y:498,t:1528139835478};\\\", \\\"{x:607,y:510,t:1528139835495};\\\", \\\"{x:598,y:530,t:1528139835513};\\\", \\\"{x:587,y:556,t:1528139835528};\\\", \\\"{x:568,y:595,t:1528139835545};\\\", \\\"{x:554,y:625,t:1528139835561};\\\", \\\"{x:548,y:642,t:1528139835578};\\\", \\\"{x:541,y:658,t:1528139835595};\\\", \\\"{x:535,y:674,t:1528139835610};\\\", \\\"{x:530,y:688,t:1528139835627};\\\", \\\"{x:527,y:700,t:1528139835645};\\\", \\\"{x:527,y:701,t:1528139835662};\\\", \\\"{x:526,y:704,t:1528139835678};\\\", \\\"{x:525,y:709,t:1528139835695};\\\", \\\"{x:525,y:713,t:1528139835711};\\\", \\\"{x:525,y:717,t:1528139835728};\\\", \\\"{x:525,y:719,t:1528139835745};\\\", \\\"{x:524,y:723,t:1528139835762};\\\", \\\"{x:523,y:727,t:1528139835779};\\\", \\\"{x:523,y:731,t:1528139835795};\\\", \\\"{x:522,y:735,t:1528139835811};\\\", \\\"{x:522,y:737,t:1528139835828};\\\", \\\"{x:521,y:741,t:1528139835845};\\\", \\\"{x:520,y:748,t:1528139835862};\\\", \\\"{x:520,y:751,t:1528139835878};\\\", \\\"{x:520,y:752,t:1528139835896};\\\" ] }, { \\\"rt\\\": 13755, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 593348, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M -M -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:752,t:1528139838135};\\\", \\\"{x:531,y:746,t:1528139838153};\\\", \\\"{x:534,y:746,t:1528139840473};\\\", \\\"{x:543,y:746,t:1528139840486};\\\", \\\"{x:588,y:748,t:1528139840505};\\\", \\\"{x:631,y:751,t:1528139840520};\\\", \\\"{x:681,y:755,t:1528139840536};\\\", \\\"{x:744,y:760,t:1528139840553};\\\", \\\"{x:782,y:767,t:1528139840565};\\\", \\\"{x:867,y:775,t:1528139840582};\\\", \\\"{x:935,y:778,t:1528139840598};\\\", \\\"{x:1026,y:785,t:1528139840615};\\\", \\\"{x:1077,y:786,t:1528139840632};\\\", \\\"{x:1110,y:786,t:1528139840648};\\\", \\\"{x:1128,y:786,t:1528139840665};\\\", \\\"{x:1142,y:788,t:1528139840682};\\\", \\\"{x:1151,y:790,t:1528139840698};\\\", \\\"{x:1163,y:793,t:1528139840715};\\\", \\\"{x:1180,y:798,t:1528139840732};\\\", \\\"{x:1189,y:801,t:1528139840749};\\\", \\\"{x:1202,y:806,t:1528139840765};\\\", \\\"{x:1218,y:815,t:1528139840782};\\\", \\\"{x:1239,y:824,t:1528139840800};\\\", \\\"{x:1256,y:832,t:1528139840816};\\\", \\\"{x:1283,y:844,t:1528139840832};\\\", \\\"{x:1303,y:852,t:1528139840849};\\\", \\\"{x:1312,y:857,t:1528139840866};\\\", \\\"{x:1317,y:860,t:1528139840883};\\\", \\\"{x:1320,y:865,t:1528139840900};\\\", \\\"{x:1321,y:868,t:1528139840916};\\\", \\\"{x:1325,y:872,t:1528139840933};\\\", \\\"{x:1328,y:876,t:1528139840950};\\\", \\\"{x:1329,y:878,t:1528139840966};\\\", \\\"{x:1329,y:880,t:1528139840983};\\\", \\\"{x:1329,y:887,t:1528139841000};\\\", \\\"{x:1331,y:893,t:1528139841016};\\\", \\\"{x:1331,y:899,t:1528139841033};\\\", \\\"{x:1331,y:902,t:1528139841050};\\\", \\\"{x:1331,y:905,t:1528139841065};\\\", \\\"{x:1331,y:909,t:1528139841083};\\\", \\\"{x:1331,y:916,t:1528139841099};\\\", \\\"{x:1331,y:925,t:1528139841116};\\\", \\\"{x:1331,y:931,t:1528139841132};\\\", \\\"{x:1331,y:936,t:1528139841150};\\\", \\\"{x:1331,y:939,t:1528139841166};\\\", \\\"{x:1331,y:941,t:1528139841183};\\\", \\\"{x:1331,y:943,t:1528139841248};\\\", \\\"{x:1332,y:944,t:1528139841266};\\\", \\\"{x:1333,y:945,t:1528139841282};\\\", \\\"{x:1333,y:946,t:1528139841300};\\\", \\\"{x:1334,y:947,t:1528139841317};\\\", \\\"{x:1335,y:947,t:1528139841333};\\\", \\\"{x:1335,y:949,t:1528139841352};\\\", \\\"{x:1335,y:950,t:1528139841368};\\\", \\\"{x:1336,y:951,t:1528139841416};\\\", \\\"{x:1337,y:952,t:1528139841976};\\\", \\\"{x:1337,y:953,t:1528139841992};\\\", \\\"{x:1337,y:955,t:1528139842000};\\\", \\\"{x:1340,y:960,t:1528139842017};\\\", \\\"{x:1345,y:967,t:1528139842034};\\\", \\\"{x:1347,y:972,t:1528139842050};\\\", \\\"{x:1350,y:975,t:1528139842066};\\\", \\\"{x:1351,y:975,t:1528139842083};\\\", \\\"{x:1351,y:976,t:1528139842100};\\\", \\\"{x:1352,y:976,t:1528139842208};\\\", \\\"{x:1352,y:974,t:1528139842232};\\\", \\\"{x:1352,y:973,t:1528139842833};\\\", \\\"{x:1353,y:971,t:1528139843120};\\\", \\\"{x:1354,y:970,t:1528139843134};\\\", \\\"{x:1354,y:968,t:1528139843152};\\\", \\\"{x:1356,y:965,t:1528139843168};\\\", \\\"{x:1359,y:962,t:1528139843185};\\\", \\\"{x:1359,y:960,t:1528139843201};\\\", \\\"{x:1363,y:955,t:1528139843218};\\\", \\\"{x:1364,y:952,t:1528139843234};\\\", \\\"{x:1364,y:951,t:1528139843250};\\\", \\\"{x:1364,y:950,t:1528139843268};\\\", \\\"{x:1365,y:948,t:1528139843285};\\\", \\\"{x:1367,y:945,t:1528139843301};\\\", \\\"{x:1370,y:937,t:1528139843318};\\\", \\\"{x:1372,y:932,t:1528139843335};\\\", \\\"{x:1374,y:929,t:1528139843351};\\\", \\\"{x:1375,y:925,t:1528139843368};\\\", \\\"{x:1375,y:924,t:1528139843385};\\\", \\\"{x:1375,y:921,t:1528139843401};\\\", \\\"{x:1376,y:919,t:1528139843418};\\\", \\\"{x:1376,y:917,t:1528139843435};\\\", \\\"{x:1377,y:916,t:1528139843451};\\\", \\\"{x:1377,y:915,t:1528139843472};\\\", \\\"{x:1377,y:914,t:1528139843496};\\\", \\\"{x:1378,y:913,t:1528139843512};\\\", \\\"{x:1378,y:912,t:1528139843545};\\\", \\\"{x:1378,y:911,t:1528139843552};\\\", \\\"{x:1378,y:910,t:1528139843568};\\\", \\\"{x:1378,y:908,t:1528139843585};\\\", \\\"{x:1380,y:905,t:1528139843601};\\\", \\\"{x:1381,y:904,t:1528139843617};\\\", \\\"{x:1381,y:903,t:1528139843664};\\\", \\\"{x:1381,y:902,t:1528139843682};\\\", \\\"{x:1382,y:901,t:1528139843701};\\\", \\\"{x:1383,y:897,t:1528139843718};\\\", \\\"{x:1384,y:896,t:1528139843769};\\\", \\\"{x:1384,y:894,t:1528139844088};\\\", \\\"{x:1384,y:892,t:1528139844101};\\\", \\\"{x:1385,y:888,t:1528139844119};\\\", \\\"{x:1389,y:879,t:1528139844135};\\\", \\\"{x:1390,y:866,t:1528139844152};\\\", \\\"{x:1393,y:856,t:1528139844168};\\\", \\\"{x:1395,y:850,t:1528139844185};\\\", \\\"{x:1398,y:845,t:1528139844202};\\\", \\\"{x:1400,y:839,t:1528139844219};\\\", \\\"{x:1402,y:829,t:1528139844234};\\\", \\\"{x:1406,y:820,t:1528139844251};\\\", \\\"{x:1407,y:816,t:1528139844268};\\\", \\\"{x:1407,y:811,t:1528139844284};\\\", \\\"{x:1410,y:805,t:1528139844301};\\\", \\\"{x:1413,y:800,t:1528139844318};\\\", \\\"{x:1417,y:792,t:1528139844334};\\\", \\\"{x:1421,y:784,t:1528139844351};\\\", \\\"{x:1422,y:780,t:1528139844368};\\\", \\\"{x:1424,y:777,t:1528139844384};\\\", \\\"{x:1427,y:770,t:1528139844401};\\\", \\\"{x:1430,y:765,t:1528139844419};\\\", \\\"{x:1434,y:760,t:1528139844434};\\\", \\\"{x:1438,y:755,t:1528139844451};\\\", \\\"{x:1439,y:751,t:1528139844469};\\\", \\\"{x:1442,y:747,t:1528139844484};\\\", \\\"{x:1443,y:742,t:1528139844501};\\\", \\\"{x:1446,y:738,t:1528139844518};\\\", \\\"{x:1450,y:731,t:1528139844535};\\\", \\\"{x:1455,y:724,t:1528139844552};\\\", \\\"{x:1459,y:718,t:1528139844568};\\\", \\\"{x:1462,y:711,t:1528139844586};\\\", \\\"{x:1467,y:703,t:1528139844601};\\\", \\\"{x:1469,y:700,t:1528139844619};\\\", \\\"{x:1474,y:691,t:1528139844635};\\\", \\\"{x:1481,y:683,t:1528139844652};\\\", \\\"{x:1486,y:673,t:1528139844669};\\\", \\\"{x:1493,y:665,t:1528139844686};\\\", \\\"{x:1500,y:655,t:1528139844702};\\\", \\\"{x:1505,y:645,t:1528139844719};\\\", \\\"{x:1513,y:631,t:1528139844736};\\\", \\\"{x:1519,y:619,t:1528139844751};\\\", \\\"{x:1525,y:608,t:1528139844769};\\\", \\\"{x:1530,y:599,t:1528139844786};\\\", \\\"{x:1534,y:590,t:1528139844802};\\\", \\\"{x:1542,y:577,t:1528139844819};\\\", \\\"{x:1547,y:564,t:1528139844836};\\\", \\\"{x:1552,y:549,t:1528139844852};\\\", \\\"{x:1557,y:540,t:1528139844869};\\\", \\\"{x:1558,y:536,t:1528139844886};\\\", \\\"{x:1562,y:530,t:1528139844902};\\\", \\\"{x:1563,y:524,t:1528139844919};\\\", \\\"{x:1567,y:518,t:1528139844936};\\\", \\\"{x:1569,y:514,t:1528139844952};\\\", \\\"{x:1570,y:513,t:1528139844969};\\\", \\\"{x:1572,y:510,t:1528139844986};\\\", \\\"{x:1575,y:505,t:1528139845002};\\\", \\\"{x:1578,y:500,t:1528139845019};\\\", \\\"{x:1580,y:498,t:1528139845036};\\\", \\\"{x:1584,y:494,t:1528139845053};\\\", \\\"{x:1585,y:492,t:1528139845068};\\\", \\\"{x:1586,y:491,t:1528139845087};\\\", \\\"{x:1588,y:489,t:1528139845102};\\\", \\\"{x:1590,y:487,t:1528139845119};\\\", \\\"{x:1591,y:486,t:1528139845136};\\\", \\\"{x:1589,y:487,t:1528139845544};\\\", \\\"{x:1585,y:488,t:1528139845553};\\\", \\\"{x:1570,y:492,t:1528139845571};\\\", \\\"{x:1548,y:495,t:1528139845586};\\\", \\\"{x:1526,y:497,t:1528139845603};\\\", \\\"{x:1496,y:502,t:1528139845620};\\\", \\\"{x:1448,y:510,t:1528139845637};\\\", \\\"{x:1375,y:513,t:1528139845653};\\\", \\\"{x:1293,y:517,t:1528139845670};\\\", \\\"{x:1221,y:517,t:1528139845687};\\\", \\\"{x:1157,y:517,t:1528139845703};\\\", \\\"{x:1079,y:517,t:1528139845720};\\\", \\\"{x:1026,y:517,t:1528139845736};\\\", \\\"{x:986,y:517,t:1528139845753};\\\", \\\"{x:958,y:519,t:1528139845770};\\\", \\\"{x:936,y:522,t:1528139845786};\\\", \\\"{x:918,y:525,t:1528139845805};\\\", \\\"{x:896,y:528,t:1528139845819};\\\", \\\"{x:867,y:531,t:1528139845836};\\\", \\\"{x:851,y:534,t:1528139845852};\\\", \\\"{x:842,y:535,t:1528139845869};\\\", \\\"{x:838,y:536,t:1528139845887};\\\", \\\"{x:831,y:538,t:1528139845903};\\\", \\\"{x:817,y:543,t:1528139845919};\\\", \\\"{x:805,y:544,t:1528139845936};\\\", \\\"{x:791,y:545,t:1528139845953};\\\", \\\"{x:780,y:546,t:1528139845969};\\\", \\\"{x:765,y:548,t:1528139845987};\\\", \\\"{x:736,y:551,t:1528139846004};\\\", \\\"{x:694,y:551,t:1528139846021};\\\", \\\"{x:647,y:551,t:1528139846037};\\\", \\\"{x:577,y:551,t:1528139846054};\\\", \\\"{x:516,y:551,t:1528139846069};\\\", \\\"{x:470,y:551,t:1528139846087};\\\", \\\"{x:432,y:545,t:1528139846102};\\\", \\\"{x:408,y:542,t:1528139846119};\\\", \\\"{x:392,y:540,t:1528139846137};\\\", \\\"{x:386,y:538,t:1528139846154};\\\", \\\"{x:383,y:538,t:1528139846952};\\\", \\\"{x:376,y:538,t:1528139846959};\\\", \\\"{x:364,y:538,t:1528139846971};\\\", \\\"{x:349,y:538,t:1528139846987};\\\", \\\"{x:342,y:538,t:1528139847003};\\\", \\\"{x:341,y:538,t:1528139847021};\\\", \\\"{x:338,y:539,t:1528139847037};\\\", \\\"{x:336,y:539,t:1528139847054};\\\", \\\"{x:333,y:540,t:1528139847071};\\\", \\\"{x:332,y:540,t:1528139847087};\\\", \\\"{x:328,y:541,t:1528139847103};\\\", \\\"{x:327,y:542,t:1528139847127};\\\", \\\"{x:325,y:542,t:1528139847137};\\\", \\\"{x:320,y:543,t:1528139847154};\\\", \\\"{x:316,y:545,t:1528139847171};\\\", \\\"{x:314,y:546,t:1528139847186};\\\", \\\"{x:317,y:547,t:1528139847376};\\\", \\\"{x:319,y:549,t:1528139847388};\\\", \\\"{x:329,y:558,t:1528139847405};\\\", \\\"{x:340,y:566,t:1528139847422};\\\", \\\"{x:350,y:574,t:1528139847437};\\\", \\\"{x:357,y:579,t:1528139847454};\\\", \\\"{x:367,y:585,t:1528139847470};\\\", \\\"{x:377,y:594,t:1528139847487};\\\", \\\"{x:381,y:598,t:1528139847505};\\\", \\\"{x:383,y:599,t:1528139847688};\\\", \\\"{x:386,y:601,t:1528139847707};\\\", \\\"{x:387,y:603,t:1528139847722};\\\", \\\"{x:387,y:604,t:1528139847791};\\\", \\\"{x:387,y:606,t:1528139847804};\\\", \\\"{x:389,y:609,t:1528139847822};\\\", \\\"{x:390,y:610,t:1528139847839};\\\", \\\"{x:390,y:612,t:1528139847855};\\\", \\\"{x:390,y:614,t:1528139847879};\\\", \\\"{x:390,y:617,t:1528139847888};\\\", \\\"{x:390,y:620,t:1528139847905};\\\", \\\"{x:390,y:622,t:1528139847922};\\\", \\\"{x:390,y:623,t:1528139847939};\\\", \\\"{x:391,y:623,t:1528139847954};\\\", \\\"{x:393,y:624,t:1528139848263};\\\", \\\"{x:395,y:625,t:1528139848271};\\\", \\\"{x:401,y:629,t:1528139848290};\\\", \\\"{x:409,y:636,t:1528139848305};\\\", \\\"{x:422,y:648,t:1528139848323};\\\", \\\"{x:437,y:660,t:1528139848338};\\\", \\\"{x:451,y:673,t:1528139848355};\\\", \\\"{x:464,y:683,t:1528139848371};\\\", \\\"{x:474,y:694,t:1528139848389};\\\", \\\"{x:483,y:704,t:1528139848404};\\\", \\\"{x:487,y:709,t:1528139848422};\\\", \\\"{x:492,y:714,t:1528139848438};\\\", \\\"{x:498,y:721,t:1528139848455};\\\", \\\"{x:500,y:723,t:1528139848472};\\\", \\\"{x:501,y:724,t:1528139848488};\\\", \\\"{x:502,y:728,t:1528139848624};\\\", \\\"{x:502,y:730,t:1528139848639};\\\", \\\"{x:503,y:732,t:1528139848655};\\\", \\\"{x:504,y:733,t:1528139848672};\\\", \\\"{x:504,y:734,t:1528139848689};\\\" ] }, { \\\"rt\\\": 18575, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 613144, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-M -G -L -F -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:744,t:1528139857065};\\\", \\\"{x:523,y:764,t:1528139857073};\\\", \\\"{x:552,y:789,t:1528139857085};\\\", \\\"{x:640,y:845,t:1528139857102};\\\", \\\"{x:741,y:901,t:1528139857112};\\\", \\\"{x:855,y:953,t:1528139857129};\\\", \\\"{x:962,y:1001,t:1528139857146};\\\", \\\"{x:1074,y:1038,t:1528139857162};\\\", \\\"{x:1204,y:1072,t:1528139857179};\\\", \\\"{x:1338,y:1104,t:1528139857195};\\\", \\\"{x:1466,y:1121,t:1528139857212};\\\", \\\"{x:1557,y:1121,t:1528139857228};\\\", \\\"{x:1610,y:1121,t:1528139857246};\\\", \\\"{x:1659,y:1113,t:1528139857262};\\\", \\\"{x:1735,y:1095,t:1528139857279};\\\", \\\"{x:1768,y:1088,t:1528139857296};\\\", \\\"{x:1788,y:1080,t:1528139857312};\\\", \\\"{x:1795,y:1076,t:1528139857331};\\\", \\\"{x:1798,y:1072,t:1528139857349};\\\", \\\"{x:1799,y:1069,t:1528139857365};\\\", \\\"{x:1799,y:1068,t:1528139857382};\\\", \\\"{x:1800,y:1067,t:1528139857402};\\\", \\\"{x:1793,y:1065,t:1528139857459};\\\", \\\"{x:1792,y:1064,t:1528139857465};\\\", \\\"{x:1783,y:1058,t:1528139857481};\\\", \\\"{x:1774,y:1056,t:1528139857498};\\\", \\\"{x:1763,y:1054,t:1528139857516};\\\", \\\"{x:1738,y:1050,t:1528139857532};\\\", \\\"{x:1694,y:1050,t:1528139857549};\\\", \\\"{x:1649,y:1050,t:1528139857566};\\\", \\\"{x:1616,y:1048,t:1528139857582};\\\", \\\"{x:1578,y:1043,t:1528139857599};\\\", \\\"{x:1533,y:1028,t:1528139857616};\\\", \\\"{x:1482,y:1005,t:1528139857633};\\\", \\\"{x:1453,y:990,t:1528139857649};\\\", \\\"{x:1424,y:973,t:1528139857666};\\\", \\\"{x:1415,y:965,t:1528139857683};\\\", \\\"{x:1413,y:964,t:1528139857700};\\\", \\\"{x:1409,y:958,t:1528139857716};\\\", \\\"{x:1406,y:950,t:1528139857732};\\\", \\\"{x:1401,y:938,t:1528139857749};\\\", \\\"{x:1400,y:930,t:1528139857767};\\\", \\\"{x:1396,y:919,t:1528139857783};\\\", \\\"{x:1392,y:906,t:1528139857799};\\\", \\\"{x:1389,y:899,t:1528139857817};\\\", \\\"{x:1387,y:894,t:1528139857833};\\\", \\\"{x:1382,y:883,t:1528139857849};\\\", \\\"{x:1379,y:873,t:1528139857868};\\\", \\\"{x:1379,y:866,t:1528139857883};\\\", \\\"{x:1379,y:854,t:1528139857900};\\\", \\\"{x:1379,y:836,t:1528139857917};\\\", \\\"{x:1379,y:814,t:1528139857934};\\\", \\\"{x:1379,y:796,t:1528139857949};\\\", \\\"{x:1379,y:783,t:1528139857966};\\\", \\\"{x:1379,y:774,t:1528139857984};\\\", \\\"{x:1382,y:768,t:1528139857999};\\\", \\\"{x:1384,y:766,t:1528139858017};\\\", \\\"{x:1387,y:764,t:1528139858034};\\\", \\\"{x:1387,y:763,t:1528139858050};\\\", \\\"{x:1391,y:760,t:1528139858227};\\\", \\\"{x:1391,y:749,t:1528139858235};\\\", \\\"{x:1385,y:713,t:1528139858250};\\\", \\\"{x:1358,y:659,t:1528139858267};\\\", \\\"{x:1339,y:627,t:1528139858284};\\\", \\\"{x:1334,y:618,t:1528139858301};\\\", \\\"{x:1334,y:616,t:1528139858317};\\\", \\\"{x:1334,y:615,t:1528139858333};\\\", \\\"{x:1334,y:614,t:1528139858351};\\\", \\\"{x:1334,y:613,t:1528139858366};\\\", \\\"{x:1333,y:613,t:1528139858467};\\\", \\\"{x:1334,y:611,t:1528139858484};\\\", \\\"{x:1335,y:610,t:1528139858500};\\\", \\\"{x:1340,y:606,t:1528139858517};\\\", \\\"{x:1344,y:603,t:1528139858534};\\\", \\\"{x:1351,y:597,t:1528139858551};\\\", \\\"{x:1364,y:590,t:1528139858567};\\\", \\\"{x:1378,y:583,t:1528139858584};\\\", \\\"{x:1395,y:572,t:1528139858600};\\\", \\\"{x:1416,y:560,t:1528139858620};\\\", \\\"{x:1434,y:552,t:1528139858633};\\\", \\\"{x:1453,y:547,t:1528139858650};\\\", \\\"{x:1464,y:546,t:1528139858666};\\\", \\\"{x:1476,y:545,t:1528139858683};\\\", \\\"{x:1484,y:545,t:1528139858700};\\\", \\\"{x:1494,y:545,t:1528139858717};\\\", \\\"{x:1503,y:545,t:1528139858733};\\\", \\\"{x:1505,y:545,t:1528139858750};\\\", \\\"{x:1512,y:545,t:1528139858767};\\\", \\\"{x:1524,y:554,t:1528139858783};\\\", \\\"{x:1542,y:563,t:1528139858800};\\\", \\\"{x:1560,y:572,t:1528139858818};\\\", \\\"{x:1577,y:579,t:1528139858833};\\\", \\\"{x:1583,y:580,t:1528139858850};\\\", \\\"{x:1585,y:582,t:1528139858867};\\\", \\\"{x:1587,y:584,t:1528139858884};\\\", \\\"{x:1590,y:590,t:1528139858900};\\\", \\\"{x:1592,y:597,t:1528139858917};\\\", \\\"{x:1595,y:601,t:1528139858934};\\\", \\\"{x:1596,y:602,t:1528139858954};\\\", \\\"{x:1596,y:604,t:1528139858967};\\\", \\\"{x:1599,y:608,t:1528139858984};\\\", \\\"{x:1602,y:617,t:1528139859001};\\\", \\\"{x:1607,y:632,t:1528139859017};\\\", \\\"{x:1612,y:651,t:1528139859035};\\\", \\\"{x:1615,y:659,t:1528139859051};\\\", \\\"{x:1617,y:662,t:1528139859067};\\\", \\\"{x:1617,y:664,t:1528139859085};\\\", \\\"{x:1617,y:667,t:1528139859101};\\\", \\\"{x:1618,y:670,t:1528139859117};\\\", \\\"{x:1620,y:675,t:1528139859134};\\\", \\\"{x:1620,y:672,t:1528139859267};\\\", \\\"{x:1620,y:653,t:1528139859284};\\\", \\\"{x:1620,y:631,t:1528139859301};\\\", \\\"{x:1620,y:605,t:1528139859318};\\\", \\\"{x:1626,y:576,t:1528139859334};\\\", \\\"{x:1627,y:554,t:1528139859351};\\\", \\\"{x:1628,y:539,t:1528139859368};\\\", \\\"{x:1628,y:530,t:1528139859384};\\\", \\\"{x:1628,y:524,t:1528139859402};\\\", \\\"{x:1628,y:522,t:1528139859417};\\\", \\\"{x:1628,y:521,t:1528139859434};\\\", \\\"{x:1628,y:520,t:1528139859483};\\\", \\\"{x:1628,y:519,t:1528139859499};\\\", \\\"{x:1627,y:519,t:1528139859515};\\\", \\\"{x:1627,y:518,t:1528139859547};\\\", \\\"{x:1626,y:517,t:1528139859555};\\\", \\\"{x:1624,y:516,t:1528139859570};\\\", \\\"{x:1620,y:514,t:1528139859585};\\\", \\\"{x:1613,y:512,t:1528139859602};\\\", \\\"{x:1606,y:508,t:1528139859619};\\\", \\\"{x:1597,y:503,t:1528139859635};\\\", \\\"{x:1582,y:495,t:1528139859653};\\\", \\\"{x:1573,y:488,t:1528139859670};\\\", \\\"{x:1564,y:479,t:1528139859685};\\\", \\\"{x:1553,y:470,t:1528139859701};\\\", \\\"{x:1544,y:461,t:1528139859718};\\\", \\\"{x:1536,y:452,t:1528139859734};\\\", \\\"{x:1528,y:443,t:1528139859752};\\\", \\\"{x:1525,y:438,t:1528139859769};\\\", \\\"{x:1523,y:435,t:1528139859784};\\\", \\\"{x:1520,y:429,t:1528139859801};\\\", \\\"{x:1517,y:425,t:1528139859818};\\\", \\\"{x:1517,y:423,t:1528139859835};\\\", \\\"{x:1522,y:423,t:1528139860043};\\\", \\\"{x:1536,y:411,t:1528139860051};\\\", \\\"{x:1555,y:382,t:1528139860068};\\\", \\\"{x:1557,y:357,t:1528139860085};\\\", \\\"{x:1560,y:329,t:1528139860101};\\\", \\\"{x:1560,y:301,t:1528139860118};\\\", \\\"{x:1560,y:281,t:1528139860134};\\\", \\\"{x:1559,y:270,t:1528139860151};\\\", \\\"{x:1559,y:263,t:1528139860168};\\\", \\\"{x:1559,y:260,t:1528139860185};\\\", \\\"{x:1559,y:257,t:1528139860201};\\\", \\\"{x:1559,y:259,t:1528139860282};\\\", \\\"{x:1559,y:261,t:1528139860290};\\\", \\\"{x:1560,y:263,t:1528139860302};\\\", \\\"{x:1561,y:267,t:1528139860318};\\\", \\\"{x:1562,y:276,t:1528139860335};\\\", \\\"{x:1566,y:290,t:1528139860352};\\\", \\\"{x:1571,y:312,t:1528139860368};\\\", \\\"{x:1576,y:337,t:1528139860385};\\\", \\\"{x:1588,y:382,t:1528139860402};\\\", \\\"{x:1596,y:405,t:1528139860418};\\\", \\\"{x:1601,y:417,t:1528139860435};\\\", \\\"{x:1601,y:424,t:1528139860452};\\\", \\\"{x:1599,y:434,t:1528139860468};\\\", \\\"{x:1592,y:449,t:1528139860486};\\\", \\\"{x:1585,y:465,t:1528139860503};\\\", \\\"{x:1577,y:474,t:1528139860519};\\\", \\\"{x:1570,y:482,t:1528139860536};\\\", \\\"{x:1552,y:492,t:1528139860552};\\\", \\\"{x:1533,y:502,t:1528139860570};\\\", \\\"{x:1507,y:514,t:1528139860586};\\\", \\\"{x:1467,y:537,t:1528139860602};\\\", \\\"{x:1445,y:550,t:1528139860619};\\\", \\\"{x:1434,y:560,t:1528139860636};\\\", \\\"{x:1425,y:570,t:1528139860652};\\\", \\\"{x:1420,y:579,t:1528139860669};\\\", \\\"{x:1415,y:595,t:1528139860685};\\\", \\\"{x:1409,y:612,t:1528139860702};\\\", \\\"{x:1404,y:626,t:1528139860720};\\\", \\\"{x:1401,y:637,t:1528139860735};\\\", \\\"{x:1398,y:651,t:1528139860752};\\\", \\\"{x:1395,y:662,t:1528139860770};\\\", \\\"{x:1393,y:670,t:1528139860785};\\\", \\\"{x:1390,y:677,t:1528139860803};\\\", \\\"{x:1388,y:679,t:1528139860820};\\\", \\\"{x:1383,y:683,t:1528139860836};\\\", \\\"{x:1379,y:686,t:1528139860853};\\\", \\\"{x:1376,y:688,t:1528139860869};\\\", \\\"{x:1375,y:689,t:1528139860887};\\\", \\\"{x:1374,y:689,t:1528139860923};\\\", \\\"{x:1373,y:689,t:1528139861051};\\\", \\\"{x:1372,y:689,t:1528139861082};\\\", \\\"{x:1371,y:689,t:1528139861123};\\\", \\\"{x:1370,y:689,t:1528139861178};\\\", \\\"{x:1369,y:691,t:1528139861195};\\\", \\\"{x:1367,y:691,t:1528139861212};\\\", \\\"{x:1367,y:692,t:1528139861267};\\\", \\\"{x:1366,y:692,t:1528139861290};\\\", \\\"{x:1366,y:693,t:1528139861304};\\\", \\\"{x:1365,y:693,t:1528139861330};\\\", \\\"{x:1364,y:693,t:1528139861387};\\\", \\\"{x:1363,y:693,t:1528139861443};\\\", \\\"{x:1362,y:693,t:1528139861454};\\\", \\\"{x:1361,y:694,t:1528139861470};\\\", \\\"{x:1359,y:694,t:1528139861487};\\\", \\\"{x:1358,y:695,t:1528139861504};\\\", \\\"{x:1355,y:695,t:1528139861520};\\\", \\\"{x:1354,y:696,t:1528139861537};\\\", \\\"{x:1351,y:697,t:1528139861554};\\\", \\\"{x:1349,y:697,t:1528139861586};\\\", \\\"{x:1348,y:697,t:1528139861626};\\\", \\\"{x:1347,y:697,t:1528139862282};\\\", \\\"{x:1346,y:697,t:1528139862290};\\\", \\\"{x:1344,y:697,t:1528139862355};\\\", \\\"{x:1345,y:697,t:1528139866531};\\\", \\\"{x:1346,y:697,t:1528139866586};\\\", \\\"{x:1346,y:698,t:1528139866619};\\\", \\\"{x:1347,y:698,t:1528139866635};\\\", \\\"{x:1339,y:698,t:1528139867788};\\\", \\\"{x:1329,y:698,t:1528139867794};\\\", \\\"{x:1318,y:698,t:1528139867810};\\\", \\\"{x:1283,y:690,t:1528139867826};\\\", \\\"{x:1260,y:682,t:1528139867843};\\\", \\\"{x:1234,y:674,t:1528139867860};\\\", \\\"{x:1193,y:663,t:1528139867877};\\\", \\\"{x:1151,y:651,t:1528139867893};\\\", \\\"{x:1109,y:638,t:1528139867910};\\\", \\\"{x:1061,y:629,t:1528139867927};\\\", \\\"{x:1018,y:620,t:1528139867944};\\\", \\\"{x:993,y:614,t:1528139867960};\\\", \\\"{x:971,y:611,t:1528139867977};\\\", \\\"{x:942,y:611,t:1528139867995};\\\", \\\"{x:900,y:611,t:1528139868009};\\\", \\\"{x:824,y:609,t:1528139868026};\\\", \\\"{x:790,y:609,t:1528139868040};\\\", \\\"{x:721,y:603,t:1528139868058};\\\", \\\"{x:641,y:591,t:1528139868073};\\\", \\\"{x:525,y:573,t:1528139868090};\\\", \\\"{x:476,y:564,t:1528139868108};\\\", \\\"{x:447,y:557,t:1528139868124};\\\", \\\"{x:428,y:549,t:1528139868140};\\\", \\\"{x:410,y:543,t:1528139868158};\\\", \\\"{x:400,y:541,t:1528139868174};\\\", \\\"{x:389,y:539,t:1528139868190};\\\", \\\"{x:382,y:538,t:1528139868207};\\\", \\\"{x:376,y:538,t:1528139868224};\\\", \\\"{x:369,y:537,t:1528139868241};\\\", \\\"{x:362,y:535,t:1528139868257};\\\", \\\"{x:357,y:535,t:1528139868273};\\\", \\\"{x:356,y:535,t:1528139868346};\\\", \\\"{x:354,y:535,t:1528139868357};\\\", \\\"{x:352,y:535,t:1528139868375};\\\", \\\"{x:350,y:538,t:1528139868391};\\\", \\\"{x:340,y:541,t:1528139868407};\\\", \\\"{x:327,y:545,t:1528139868425};\\\", \\\"{x:306,y:550,t:1528139868441};\\\", \\\"{x:281,y:553,t:1528139868458};\\\", \\\"{x:270,y:556,t:1528139868474};\\\", \\\"{x:261,y:558,t:1528139868490};\\\", \\\"{x:251,y:559,t:1528139868507};\\\", \\\"{x:239,y:563,t:1528139868524};\\\", \\\"{x:231,y:563,t:1528139868540};\\\", \\\"{x:223,y:563,t:1528139868557};\\\", \\\"{x:220,y:563,t:1528139868574};\\\", \\\"{x:217,y:563,t:1528139868591};\\\", \\\"{x:216,y:563,t:1528139868617};\\\", \\\"{x:215,y:563,t:1528139868625};\\\", \\\"{x:214,y:563,t:1528139868650};\\\", \\\"{x:215,y:563,t:1528139868657};\\\", \\\"{x:223,y:558,t:1528139868675};\\\", \\\"{x:239,y:550,t:1528139868692};\\\", \\\"{x:259,y:541,t:1528139868707};\\\", \\\"{x:279,y:531,t:1528139868725};\\\", \\\"{x:300,y:521,t:1528139868742};\\\", \\\"{x:324,y:515,t:1528139868758};\\\", \\\"{x:351,y:514,t:1528139868774};\\\", \\\"{x:393,y:514,t:1528139868791};\\\", \\\"{x:440,y:514,t:1528139868807};\\\", \\\"{x:494,y:514,t:1528139868825};\\\", \\\"{x:533,y:514,t:1528139868842};\\\", \\\"{x:562,y:514,t:1528139868857};\\\", \\\"{x:601,y:514,t:1528139868874};\\\", \\\"{x:640,y:514,t:1528139868892};\\\", \\\"{x:704,y:520,t:1528139868909};\\\", \\\"{x:770,y:528,t:1528139868924};\\\", \\\"{x:823,y:533,t:1528139868941};\\\", \\\"{x:855,y:539,t:1528139868957};\\\", \\\"{x:876,y:544,t:1528139868975};\\\", \\\"{x:898,y:547,t:1528139868991};\\\", \\\"{x:915,y:550,t:1528139869007};\\\", \\\"{x:924,y:550,t:1528139869024};\\\", \\\"{x:931,y:550,t:1528139869041};\\\", \\\"{x:932,y:550,t:1528139869074};\\\", \\\"{x:933,y:550,t:1528139869090};\\\", \\\"{x:934,y:551,t:1528139869138};\\\", \\\"{x:934,y:552,t:1528139869146};\\\", \\\"{x:932,y:554,t:1528139869158};\\\", \\\"{x:927,y:555,t:1528139869174};\\\", \\\"{x:921,y:557,t:1528139869193};\\\", \\\"{x:915,y:558,t:1528139869208};\\\", \\\"{x:907,y:558,t:1528139869224};\\\", \\\"{x:898,y:557,t:1528139869241};\\\", \\\"{x:890,y:555,t:1528139869258};\\\", \\\"{x:889,y:554,t:1528139869274};\\\", \\\"{x:887,y:551,t:1528139869291};\\\", \\\"{x:885,y:549,t:1528139869309};\\\", \\\"{x:883,y:547,t:1528139869325};\\\", \\\"{x:882,y:547,t:1528139869370};\\\", \\\"{x:881,y:547,t:1528139869378};\\\", \\\"{x:880,y:546,t:1528139869392};\\\", \\\"{x:877,y:545,t:1528139869409};\\\", \\\"{x:875,y:545,t:1528139869425};\\\", \\\"{x:869,y:543,t:1528139869442};\\\", \\\"{x:864,y:542,t:1528139869458};\\\", \\\"{x:863,y:542,t:1528139869475};\\\", \\\"{x:861,y:542,t:1528139869492};\\\", \\\"{x:860,y:542,t:1528139869522};\\\", \\\"{x:859,y:541,t:1528139869650};\\\", \\\"{x:859,y:541,t:1528139869665};\\\", \\\"{x:856,y:541,t:1528139869882};\\\", \\\"{x:853,y:541,t:1528139869892};\\\", \\\"{x:849,y:542,t:1528139869909};\\\", \\\"{x:842,y:542,t:1528139869926};\\\", \\\"{x:832,y:545,t:1528139869943};\\\", \\\"{x:814,y:550,t:1528139869960};\\\", \\\"{x:779,y:559,t:1528139869977};\\\", \\\"{x:743,y:578,t:1528139869994};\\\", \\\"{x:708,y:596,t:1528139870010};\\\", \\\"{x:672,y:616,t:1528139870026};\\\", \\\"{x:652,y:628,t:1528139870042};\\\", \\\"{x:637,y:641,t:1528139870059};\\\", \\\"{x:621,y:659,t:1528139870075};\\\", \\\"{x:611,y:670,t:1528139870092};\\\", \\\"{x:603,y:678,t:1528139870109};\\\", \\\"{x:597,y:686,t:1528139870125};\\\", \\\"{x:592,y:691,t:1528139870142};\\\", \\\"{x:587,y:693,t:1528139870159};\\\", \\\"{x:584,y:695,t:1528139870175};\\\", \\\"{x:582,y:698,t:1528139870193};\\\", \\\"{x:574,y:703,t:1528139870210};\\\", \\\"{x:570,y:707,t:1528139870225};\\\", \\\"{x:564,y:711,t:1528139870243};\\\", \\\"{x:559,y:714,t:1528139870260};\\\", \\\"{x:548,y:718,t:1528139870277};\\\", \\\"{x:534,y:723,t:1528139870295};\\\", \\\"{x:515,y:732,t:1528139870310};\\\", \\\"{x:498,y:740,t:1528139870325};\\\", \\\"{x:487,y:744,t:1528139870343};\\\", \\\"{x:482,y:745,t:1528139870359};\\\" ] }, { \\\"rt\\\": 11974, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 626391, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -O -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:750,t:1528139874795};\\\", \\\"{x:550,y:759,t:1528139874803};\\\", \\\"{x:601,y:765,t:1528139874814};\\\", \\\"{x:723,y:782,t:1528139874831};\\\", \\\"{x:862,y:803,t:1528139874848};\\\", \\\"{x:1014,y:825,t:1528139874861};\\\", \\\"{x:1182,y:847,t:1528139874877};\\\", \\\"{x:1334,y:862,t:1528139874894};\\\", \\\"{x:1483,y:862,t:1528139874911};\\\", \\\"{x:1594,y:862,t:1528139874928};\\\", \\\"{x:1654,y:854,t:1528139874945};\\\", \\\"{x:1681,y:844,t:1528139874961};\\\", \\\"{x:1700,y:836,t:1528139874978};\\\", \\\"{x:1707,y:831,t:1528139874994};\\\", \\\"{x:1715,y:822,t:1528139875011};\\\", \\\"{x:1720,y:801,t:1528139875028};\\\", \\\"{x:1726,y:780,t:1528139875044};\\\", \\\"{x:1731,y:759,t:1528139875061};\\\", \\\"{x:1731,y:734,t:1528139875078};\\\", \\\"{x:1724,y:708,t:1528139875095};\\\", \\\"{x:1711,y:691,t:1528139875111};\\\", \\\"{x:1694,y:677,t:1528139875127};\\\", \\\"{x:1671,y:665,t:1528139875144};\\\", \\\"{x:1643,y:649,t:1528139875160};\\\", \\\"{x:1609,y:632,t:1528139875178};\\\", \\\"{x:1594,y:626,t:1528139875194};\\\", \\\"{x:1584,y:621,t:1528139875211};\\\", \\\"{x:1576,y:617,t:1528139875228};\\\", \\\"{x:1569,y:614,t:1528139875245};\\\", \\\"{x:1559,y:612,t:1528139875260};\\\", \\\"{x:1552,y:610,t:1528139875278};\\\", \\\"{x:1551,y:610,t:1528139875347};\\\", \\\"{x:1549,y:609,t:1528139875361};\\\", \\\"{x:1546,y:608,t:1528139875378};\\\", \\\"{x:1544,y:607,t:1528139875403};\\\", \\\"{x:1543,y:606,t:1528139875411};\\\", \\\"{x:1542,y:605,t:1528139875459};\\\", \\\"{x:1541,y:605,t:1528139875490};\\\", \\\"{x:1540,y:605,t:1528139875498};\\\", \\\"{x:1539,y:605,t:1528139875512};\\\", \\\"{x:1537,y:605,t:1528139875528};\\\", \\\"{x:1534,y:605,t:1528139875545};\\\", \\\"{x:1529,y:610,t:1528139875561};\\\", \\\"{x:1525,y:614,t:1528139875578};\\\", \\\"{x:1522,y:620,t:1528139875594};\\\", \\\"{x:1517,y:627,t:1528139875611};\\\", \\\"{x:1512,y:636,t:1528139875628};\\\", \\\"{x:1508,y:651,t:1528139875645};\\\", \\\"{x:1506,y:659,t:1528139875661};\\\", \\\"{x:1504,y:669,t:1528139875678};\\\", \\\"{x:1503,y:676,t:1528139875696};\\\", \\\"{x:1502,y:682,t:1528139875711};\\\", \\\"{x:1501,y:688,t:1528139875729};\\\", \\\"{x:1500,y:693,t:1528139875745};\\\", \\\"{x:1500,y:697,t:1528139875761};\\\", \\\"{x:1498,y:704,t:1528139875779};\\\", \\\"{x:1497,y:711,t:1528139875794};\\\", \\\"{x:1496,y:715,t:1528139875811};\\\", \\\"{x:1494,y:721,t:1528139875828};\\\", \\\"{x:1494,y:722,t:1528139875846};\\\", \\\"{x:1494,y:724,t:1528139875861};\\\", \\\"{x:1494,y:725,t:1528139875878};\\\", \\\"{x:1493,y:726,t:1528139875895};\\\", \\\"{x:1493,y:725,t:1528139876099};\\\", \\\"{x:1492,y:722,t:1528139876111};\\\", \\\"{x:1491,y:717,t:1528139876129};\\\", \\\"{x:1490,y:713,t:1528139876146};\\\", \\\"{x:1490,y:710,t:1528139876162};\\\", \\\"{x:1490,y:706,t:1528139876178};\\\", \\\"{x:1490,y:703,t:1528139876194};\\\", \\\"{x:1490,y:701,t:1528139876211};\\\", \\\"{x:1490,y:700,t:1528139876228};\\\", \\\"{x:1490,y:701,t:1528139876299};\\\", \\\"{x:1491,y:705,t:1528139876311};\\\", \\\"{x:1494,y:717,t:1528139876328};\\\", \\\"{x:1501,y:731,t:1528139876345};\\\", \\\"{x:1507,y:745,t:1528139876361};\\\", \\\"{x:1513,y:760,t:1528139876380};\\\", \\\"{x:1518,y:769,t:1528139876395};\\\", \\\"{x:1519,y:774,t:1528139876411};\\\", \\\"{x:1521,y:778,t:1528139876427};\\\", \\\"{x:1521,y:779,t:1528139876444};\\\", \\\"{x:1521,y:780,t:1528139876461};\\\", \\\"{x:1523,y:782,t:1528139876478};\\\", \\\"{x:1523,y:784,t:1528139876498};\\\", \\\"{x:1523,y:786,t:1528139876538};\\\", \\\"{x:1523,y:787,t:1528139876545};\\\", \\\"{x:1523,y:789,t:1528139876570};\\\", \\\"{x:1523,y:790,t:1528139876586};\\\", \\\"{x:1523,y:791,t:1528139876594};\\\", \\\"{x:1533,y:801,t:1528139876611};\\\", \\\"{x:1537,y:805,t:1528139876628};\\\", \\\"{x:1539,y:807,t:1528139876645};\\\", \\\"{x:1541,y:808,t:1528139876661};\\\", \\\"{x:1542,y:808,t:1528139876867};\\\", \\\"{x:1544,y:802,t:1528139876879};\\\", \\\"{x:1552,y:791,t:1528139876895};\\\", \\\"{x:1556,y:782,t:1528139876912};\\\", \\\"{x:1561,y:772,t:1528139876929};\\\", \\\"{x:1562,y:766,t:1528139876945};\\\", \\\"{x:1562,y:760,t:1528139876961};\\\", \\\"{x:1562,y:738,t:1528139876978};\\\", \\\"{x:1554,y:715,t:1528139876994};\\\", \\\"{x:1540,y:691,t:1528139877011};\\\", \\\"{x:1532,y:679,t:1528139877029};\\\", \\\"{x:1527,y:665,t:1528139877045};\\\", \\\"{x:1525,y:656,t:1528139877061};\\\", \\\"{x:1524,y:653,t:1528139877078};\\\", \\\"{x:1524,y:650,t:1528139877095};\\\", \\\"{x:1529,y:645,t:1528139877111};\\\", \\\"{x:1534,y:643,t:1528139877127};\\\", \\\"{x:1542,y:639,t:1528139877144};\\\", \\\"{x:1547,y:637,t:1528139877161};\\\", \\\"{x:1547,y:636,t:1528139877178};\\\", \\\"{x:1551,y:640,t:1528139877403};\\\", \\\"{x:1564,y:643,t:1528139877411};\\\", \\\"{x:1572,y:643,t:1528139877428};\\\", \\\"{x:1573,y:643,t:1528139877762};\\\", \\\"{x:1573,y:644,t:1528139877794};\\\", \\\"{x:1574,y:644,t:1528139877835};\\\", \\\"{x:1574,y:645,t:1528139877846};\\\", \\\"{x:1579,y:649,t:1528139877861};\\\", \\\"{x:1580,y:655,t:1528139877879};\\\", \\\"{x:1583,y:660,t:1528139877895};\\\", \\\"{x:1584,y:667,t:1528139877911};\\\", \\\"{x:1588,y:673,t:1528139877928};\\\", \\\"{x:1593,y:680,t:1528139877945};\\\", \\\"{x:1597,y:686,t:1528139877963};\\\", \\\"{x:1599,y:687,t:1528139877978};\\\", \\\"{x:1599,y:688,t:1528139877995};\\\", \\\"{x:1600,y:689,t:1528139878018};\\\", \\\"{x:1601,y:692,t:1528139878028};\\\", \\\"{x:1605,y:696,t:1528139878045};\\\", \\\"{x:1607,y:697,t:1528139878061};\\\", \\\"{x:1608,y:697,t:1528139878146};\\\", \\\"{x:1609,y:698,t:1528139878163};\\\", \\\"{x:1609,y:699,t:1528139878178};\\\", \\\"{x:1609,y:700,t:1528139878540};\\\", \\\"{x:1609,y:703,t:1528139878546};\\\", \\\"{x:1609,y:706,t:1528139878563};\\\", \\\"{x:1608,y:711,t:1528139878578};\\\", \\\"{x:1605,y:716,t:1528139878595};\\\", \\\"{x:1600,y:724,t:1528139878612};\\\", \\\"{x:1593,y:735,t:1528139878629};\\\", \\\"{x:1585,y:746,t:1528139878646};\\\", \\\"{x:1578,y:759,t:1528139878662};\\\", \\\"{x:1570,y:770,t:1528139878679};\\\", \\\"{x:1565,y:782,t:1528139878695};\\\", \\\"{x:1561,y:788,t:1528139878712};\\\", \\\"{x:1559,y:795,t:1528139878728};\\\", \\\"{x:1556,y:802,t:1528139878745};\\\", \\\"{x:1555,y:811,t:1528139878762};\\\", \\\"{x:1552,y:818,t:1528139878778};\\\", \\\"{x:1548,y:828,t:1528139878795};\\\", \\\"{x:1544,y:840,t:1528139878812};\\\", \\\"{x:1535,y:855,t:1528139878829};\\\", \\\"{x:1527,y:876,t:1528139878846};\\\", \\\"{x:1519,y:894,t:1528139878862};\\\", \\\"{x:1514,y:913,t:1528139878878};\\\", \\\"{x:1509,y:925,t:1528139878896};\\\", \\\"{x:1505,y:932,t:1528139878913};\\\", \\\"{x:1503,y:938,t:1528139878928};\\\", \\\"{x:1502,y:941,t:1528139878946};\\\", \\\"{x:1500,y:947,t:1528139878963};\\\", \\\"{x:1499,y:951,t:1528139878978};\\\", \\\"{x:1498,y:953,t:1528139878995};\\\", \\\"{x:1497,y:955,t:1528139879013};\\\", \\\"{x:1495,y:959,t:1528139879029};\\\", \\\"{x:1494,y:962,t:1528139879045};\\\", \\\"{x:1493,y:964,t:1528139879063};\\\", \\\"{x:1492,y:965,t:1528139879079};\\\", \\\"{x:1491,y:966,t:1528139879095};\\\", \\\"{x:1490,y:967,t:1528139879146};\\\", \\\"{x:1489,y:968,t:1528139879162};\\\", \\\"{x:1488,y:968,t:1528139879186};\\\", \\\"{x:1487,y:968,t:1528139879259};\\\", \\\"{x:1486,y:968,t:1528139879266};\\\", \\\"{x:1485,y:968,t:1528139879278};\\\", \\\"{x:1484,y:965,t:1528139879296};\\\", \\\"{x:1483,y:962,t:1528139879312};\\\", \\\"{x:1483,y:961,t:1528139879386};\\\", \\\"{x:1483,y:960,t:1528139879627};\\\", \\\"{x:1483,y:959,t:1528139879635};\\\", \\\"{x:1482,y:957,t:1528139879651};\\\", \\\"{x:1481,y:956,t:1528139879662};\\\", \\\"{x:1480,y:954,t:1528139879678};\\\", \\\"{x:1478,y:951,t:1528139879695};\\\", \\\"{x:1475,y:947,t:1528139879713};\\\", \\\"{x:1473,y:943,t:1528139879729};\\\", \\\"{x:1469,y:936,t:1528139879745};\\\", \\\"{x:1465,y:930,t:1528139879763};\\\", \\\"{x:1463,y:927,t:1528139879778};\\\", \\\"{x:1459,y:924,t:1528139879795};\\\", \\\"{x:1455,y:918,t:1528139879812};\\\", \\\"{x:1443,y:899,t:1528139879829};\\\", \\\"{x:1432,y:882,t:1528139879846};\\\", \\\"{x:1422,y:864,t:1528139879862};\\\", \\\"{x:1411,y:840,t:1528139879878};\\\", \\\"{x:1398,y:819,t:1528139879895};\\\", \\\"{x:1386,y:796,t:1528139879912};\\\", \\\"{x:1373,y:773,t:1528139879928};\\\", \\\"{x:1362,y:753,t:1528139879946};\\\", \\\"{x:1353,y:730,t:1528139879962};\\\", \\\"{x:1352,y:717,t:1528139879979};\\\", \\\"{x:1349,y:705,t:1528139879995};\\\", \\\"{x:1343,y:691,t:1528139880013};\\\", \\\"{x:1337,y:683,t:1528139880029};\\\", \\\"{x:1336,y:682,t:1528139880046};\\\", \\\"{x:1335,y:681,t:1528139880062};\\\", \\\"{x:1334,y:678,t:1528139880079};\\\", \\\"{x:1334,y:676,t:1528139880096};\\\", \\\"{x:1333,y:672,t:1528139880113};\\\", \\\"{x:1329,y:665,t:1528139880129};\\\", \\\"{x:1321,y:651,t:1528139880145};\\\", \\\"{x:1313,y:640,t:1528139880162};\\\", \\\"{x:1305,y:628,t:1528139880178};\\\", \\\"{x:1297,y:614,t:1528139880196};\\\", \\\"{x:1290,y:600,t:1528139880213};\\\", \\\"{x:1276,y:581,t:1528139880229};\\\", \\\"{x:1262,y:562,t:1528139880246};\\\", \\\"{x:1254,y:551,t:1528139880263};\\\", \\\"{x:1249,y:541,t:1528139880279};\\\", \\\"{x:1244,y:534,t:1528139880296};\\\", \\\"{x:1242,y:529,t:1528139880313};\\\", \\\"{x:1240,y:526,t:1528139880328};\\\", \\\"{x:1238,y:522,t:1528139880346};\\\", \\\"{x:1237,y:521,t:1528139880362};\\\", \\\"{x:1236,y:521,t:1528139880451};\\\", \\\"{x:1234,y:521,t:1528139880462};\\\", \\\"{x:1222,y:529,t:1528139880478};\\\", \\\"{x:1201,y:541,t:1528139880495};\\\", \\\"{x:1162,y:557,t:1528139880513};\\\", \\\"{x:1097,y:580,t:1528139880529};\\\", \\\"{x:984,y:608,t:1528139880545};\\\", \\\"{x:818,y:622,t:1528139880563};\\\", \\\"{x:696,y:622,t:1528139880578};\\\", \\\"{x:591,y:622,t:1528139880595};\\\", \\\"{x:444,y:610,t:1528139880618};\\\", \\\"{x:362,y:592,t:1528139880635};\\\", \\\"{x:303,y:575,t:1528139880651};\\\", \\\"{x:281,y:567,t:1528139880667};\\\", \\\"{x:272,y:563,t:1528139880684};\\\", \\\"{x:271,y:563,t:1528139880729};\\\", \\\"{x:271,y:561,t:1528139880738};\\\", \\\"{x:272,y:557,t:1528139880751};\\\", \\\"{x:278,y:547,t:1528139880769};\\\", \\\"{x:279,y:542,t:1528139880784};\\\", \\\"{x:279,y:539,t:1528139880800};\\\", \\\"{x:281,y:537,t:1528139880818};\\\", \\\"{x:286,y:534,t:1528139880834};\\\", \\\"{x:293,y:531,t:1528139880851};\\\", \\\"{x:297,y:530,t:1528139880867};\\\", \\\"{x:299,y:530,t:1528139880884};\\\", \\\"{x:300,y:530,t:1528139880914};\\\", \\\"{x:302,y:530,t:1528139880946};\\\", \\\"{x:304,y:530,t:1528139880954};\\\", \\\"{x:308,y:530,t:1528139880968};\\\", \\\"{x:314,y:530,t:1528139880984};\\\", \\\"{x:316,y:530,t:1528139881001};\\\", \\\"{x:317,y:530,t:1528139881018};\\\", \\\"{x:318,y:530,t:1528139881034};\\\", \\\"{x:324,y:527,t:1528139881051};\\\", \\\"{x:331,y:523,t:1528139881069};\\\", \\\"{x:340,y:520,t:1528139881083};\\\", \\\"{x:352,y:516,t:1528139881101};\\\", \\\"{x:363,y:513,t:1528139881118};\\\", \\\"{x:373,y:509,t:1528139881133};\\\", \\\"{x:385,y:507,t:1528139881151};\\\", \\\"{x:406,y:504,t:1528139881168};\\\", \\\"{x:436,y:501,t:1528139881185};\\\", \\\"{x:473,y:495,t:1528139881201};\\\", \\\"{x:515,y:494,t:1528139881218};\\\", \\\"{x:535,y:494,t:1528139881235};\\\", \\\"{x:550,y:494,t:1528139881251};\\\", \\\"{x:554,y:494,t:1528139881268};\\\", \\\"{x:556,y:493,t:1528139881285};\\\", \\\"{x:558,y:493,t:1528139881339};\\\", \\\"{x:559,y:495,t:1528139881354};\\\", \\\"{x:561,y:496,t:1528139881368};\\\", \\\"{x:561,y:501,t:1528139881386};\\\", \\\"{x:561,y:507,t:1528139881401};\\\", \\\"{x:562,y:508,t:1528139881483};\\\", \\\"{x:563,y:508,t:1528139881490};\\\", \\\"{x:564,y:508,t:1528139881501};\\\", \\\"{x:572,y:504,t:1528139881518};\\\", \\\"{x:579,y:500,t:1528139881535};\\\", \\\"{x:585,y:495,t:1528139881553};\\\", \\\"{x:589,y:492,t:1528139881568};\\\", \\\"{x:590,y:491,t:1528139881585};\\\", \\\"{x:592,y:490,t:1528139881602};\\\", \\\"{x:592,y:489,t:1528139881618};\\\", \\\"{x:593,y:489,t:1528139881683};\\\", \\\"{x:594,y:489,t:1528139881690};\\\", \\\"{x:594,y:489,t:1528139881755};\\\", \\\"{x:595,y:489,t:1528139881843};\\\", \\\"{x:596,y:489,t:1528139881858};\\\", \\\"{x:598,y:489,t:1528139881868};\\\", \\\"{x:604,y:489,t:1528139881885};\\\", \\\"{x:608,y:489,t:1528139881902};\\\", \\\"{x:611,y:489,t:1528139881919};\\\", \\\"{x:615,y:491,t:1528139881935};\\\", \\\"{x:620,y:496,t:1528139881952};\\\", \\\"{x:629,y:500,t:1528139881969};\\\", \\\"{x:640,y:502,t:1528139881985};\\\", \\\"{x:646,y:503,t:1528139882002};\\\", \\\"{x:647,y:503,t:1528139882019};\\\", \\\"{x:647,y:504,t:1528139882035};\\\", \\\"{x:647,y:506,t:1528139882058};\\\", \\\"{x:647,y:508,t:1528139882074};\\\", \\\"{x:647,y:509,t:1528139882089};\\\", \\\"{x:647,y:510,t:1528139882102};\\\", \\\"{x:645,y:512,t:1528139882120};\\\", \\\"{x:638,y:512,t:1528139882136};\\\", \\\"{x:633,y:513,t:1528139882153};\\\", \\\"{x:631,y:513,t:1528139882169};\\\", \\\"{x:629,y:513,t:1528139882185};\\\", \\\"{x:628,y:513,t:1528139882203};\\\", \\\"{x:624,y:513,t:1528139882219};\\\", \\\"{x:621,y:511,t:1528139882236};\\\", \\\"{x:617,y:508,t:1528139882253};\\\", \\\"{x:613,y:507,t:1528139882269};\\\", \\\"{x:611,y:506,t:1528139882285};\\\", \\\"{x:609,y:506,t:1528139882302};\\\", \\\"{x:609,y:505,t:1528139882538};\\\", \\\"{x:609,y:504,t:1528139882552};\\\", \\\"{x:621,y:500,t:1528139882569};\\\", \\\"{x:655,y:494,t:1528139882586};\\\", \\\"{x:686,y:492,t:1528139882602};\\\", \\\"{x:715,y:492,t:1528139882619};\\\", \\\"{x:732,y:492,t:1528139882637};\\\", \\\"{x:743,y:492,t:1528139882652};\\\", \\\"{x:751,y:492,t:1528139882669};\\\", \\\"{x:761,y:494,t:1528139882685};\\\", \\\"{x:769,y:498,t:1528139882702};\\\", \\\"{x:775,y:498,t:1528139882719};\\\", \\\"{x:778,y:498,t:1528139882736};\\\", \\\"{x:780,y:498,t:1528139882752};\\\", \\\"{x:781,y:498,t:1528139882770};\\\", \\\"{x:783,y:498,t:1528139882786};\\\", \\\"{x:784,y:499,t:1528139882802};\\\", \\\"{x:785,y:499,t:1528139882826};\\\", \\\"{x:787,y:499,t:1528139882850};\\\", \\\"{x:788,y:499,t:1528139882858};\\\", \\\"{x:791,y:499,t:1528139882869};\\\", \\\"{x:793,y:499,t:1528139882886};\\\", \\\"{x:794,y:499,t:1528139882902};\\\", \\\"{x:799,y:499,t:1528139882920};\\\", \\\"{x:808,y:495,t:1528139882937};\\\", \\\"{x:815,y:495,t:1528139882953};\\\", \\\"{x:822,y:493,t:1528139882969};\\\", \\\"{x:828,y:493,t:1528139882987};\\\", \\\"{x:834,y:493,t:1528139883003};\\\", \\\"{x:836,y:493,t:1528139883019};\\\", \\\"{x:840,y:493,t:1528139883036};\\\", \\\"{x:841,y:493,t:1528139883053};\\\", \\\"{x:842,y:493,t:1528139883082};\\\", \\\"{x:842,y:495,t:1528139883362};\\\", \\\"{x:840,y:498,t:1528139883386};\\\", \\\"{x:840,y:500,t:1528139883403};\\\", \\\"{x:839,y:502,t:1528139883420};\\\", \\\"{x:839,y:504,t:1528139883483};\\\", \\\"{x:839,y:505,t:1528139883498};\\\", \\\"{x:834,y:508,t:1528139883506};\\\", \\\"{x:828,y:514,t:1528139883522};\\\", \\\"{x:809,y:531,t:1528139883538};\\\", \\\"{x:778,y:560,t:1528139883554};\\\", \\\"{x:684,y:617,t:1528139883569};\\\", \\\"{x:607,y:651,t:1528139883586};\\\", \\\"{x:562,y:671,t:1528139883603};\\\", \\\"{x:517,y:693,t:1528139883620};\\\", \\\"{x:488,y:710,t:1528139883635};\\\", \\\"{x:468,y:720,t:1528139883653};\\\", \\\"{x:458,y:727,t:1528139883670};\\\", \\\"{x:456,y:728,t:1528139883685};\\\", \\\"{x:452,y:734,t:1528139883703};\\\", \\\"{x:449,y:739,t:1528139883720};\\\", \\\"{x:446,y:742,t:1528139883737};\\\", \\\"{x:445,y:745,t:1528139883753};\\\", \\\"{x:444,y:746,t:1528139883770};\\\", \\\"{x:444,y:747,t:1528139883809};\\\", \\\"{x:445,y:747,t:1528139883820};\\\", \\\"{x:450,y:747,t:1528139883836};\\\", \\\"{x:458,y:747,t:1528139883853};\\\", \\\"{x:466,y:744,t:1528139883870};\\\", \\\"{x:470,y:742,t:1528139883887};\\\", \\\"{x:471,y:741,t:1528139883903};\\\", \\\"{x:471,y:739,t:1528139884065};\\\", \\\"{x:470,y:738,t:1528139884097};\\\", \\\"{x:469,y:738,t:1528139884162};\\\", \\\"{x:467,y:737,t:1528139884482};\\\", \\\"{x:467,y:736,t:1528139884498};\\\", \\\"{x:466,y:735,t:1528139884538};\\\", \\\"{x:465,y:734,t:1528139884561};\\\", \\\"{x:465,y:733,t:1528139884602};\\\", \\\"{x:464,y:732,t:1528139884618};\\\", \\\"{x:464,y:731,t:1528139884634};\\\", \\\"{x:463,y:730,t:1528139884650};\\\", \\\"{x:462,y:729,t:1528139884690};\\\", \\\"{x:462,y:728,t:1528139884704};\\\", \\\"{x:461,y:727,t:1528139884746};\\\" ] }, { \\\"rt\\\": 7124, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 634725, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-03 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:461,y:725,t:1528139886042};\\\", \\\"{x:463,y:723,t:1528139886054};\\\", \\\"{x:492,y:723,t:1528139886070};\\\", \\\"{x:563,y:734,t:1528139886087};\\\", \\\"{x:652,y:750,t:1528139886105};\\\", \\\"{x:742,y:769,t:1528139886120};\\\", \\\"{x:777,y:775,t:1528139886139};\\\", \\\"{x:778,y:776,t:1528139887739};\\\", \\\"{x:783,y:780,t:1528139887746};\\\", \\\"{x:790,y:785,t:1528139887757};\\\", \\\"{x:811,y:799,t:1528139887774};\\\", \\\"{x:842,y:813,t:1528139887791};\\\", \\\"{x:881,y:830,t:1528139887807};\\\", \\\"{x:934,y:855,t:1528139887823};\\\", \\\"{x:976,y:875,t:1528139887841};\\\", \\\"{x:1015,y:895,t:1528139887859};\\\", \\\"{x:1037,y:906,t:1528139887874};\\\", \\\"{x:1054,y:915,t:1528139887890};\\\", \\\"{x:1074,y:925,t:1528139887908};\\\", \\\"{x:1092,y:934,t:1528139887924};\\\", \\\"{x:1110,y:943,t:1528139887941};\\\", \\\"{x:1126,y:950,t:1528139887958};\\\", \\\"{x:1144,y:958,t:1528139887974};\\\", \\\"{x:1159,y:963,t:1528139887991};\\\", \\\"{x:1177,y:966,t:1528139888008};\\\", \\\"{x:1199,y:970,t:1528139888024};\\\", \\\"{x:1224,y:976,t:1528139888041};\\\", \\\"{x:1261,y:989,t:1528139888059};\\\", \\\"{x:1283,y:994,t:1528139888074};\\\", \\\"{x:1304,y:1000,t:1528139888090};\\\", \\\"{x:1326,y:1003,t:1528139888108};\\\", \\\"{x:1345,y:1006,t:1528139888124};\\\", \\\"{x:1365,y:1008,t:1528139888141};\\\", \\\"{x:1378,y:1008,t:1528139888158};\\\", \\\"{x:1386,y:1009,t:1528139888174};\\\", \\\"{x:1392,y:1009,t:1528139888190};\\\", \\\"{x:1397,y:1009,t:1528139888207};\\\", \\\"{x:1405,y:1009,t:1528139888225};\\\", \\\"{x:1419,y:1008,t:1528139888241};\\\", \\\"{x:1453,y:1008,t:1528139888258};\\\", \\\"{x:1471,y:1011,t:1528139888274};\\\", \\\"{x:1480,y:1011,t:1528139888291};\\\", \\\"{x:1487,y:1011,t:1528139888308};\\\", \\\"{x:1491,y:1011,t:1528139888325};\\\", \\\"{x:1493,y:1011,t:1528139888341};\\\", \\\"{x:1499,y:1009,t:1528139888358};\\\", \\\"{x:1510,y:1008,t:1528139888375};\\\", \\\"{x:1522,y:1008,t:1528139888391};\\\", \\\"{x:1536,y:1008,t:1528139888407};\\\", \\\"{x:1544,y:1008,t:1528139888425};\\\", \\\"{x:1552,y:1007,t:1528139888441};\\\", \\\"{x:1561,y:1005,t:1528139888458};\\\", \\\"{x:1565,y:1004,t:1528139888475};\\\", \\\"{x:1568,y:1004,t:1528139888490};\\\", \\\"{x:1569,y:1004,t:1528139888530};\\\", \\\"{x:1570,y:1004,t:1528139888541};\\\", \\\"{x:1571,y:1003,t:1528139888558};\\\", \\\"{x:1572,y:1002,t:1528139888575};\\\", \\\"{x:1575,y:1000,t:1528139888592};\\\", \\\"{x:1578,y:996,t:1528139888608};\\\", \\\"{x:1579,y:991,t:1528139888624};\\\", \\\"{x:1580,y:987,t:1528139888642};\\\", \\\"{x:1581,y:986,t:1528139888658};\\\", \\\"{x:1581,y:985,t:1528139888682};\\\", \\\"{x:1581,y:984,t:1528139888699};\\\", \\\"{x:1581,y:983,t:1528139888714};\\\", \\\"{x:1581,y:982,t:1528139888724};\\\", \\\"{x:1579,y:981,t:1528139888742};\\\", \\\"{x:1579,y:980,t:1528139888758};\\\", \\\"{x:1578,y:980,t:1528139888779};\\\", \\\"{x:1576,y:979,t:1528139888818};\\\", \\\"{x:1574,y:978,t:1528139888826};\\\", \\\"{x:1571,y:977,t:1528139888842};\\\", \\\"{x:1570,y:976,t:1528139888899};\\\", \\\"{x:1569,y:976,t:1528139888914};\\\", \\\"{x:1568,y:976,t:1528139888931};\\\", \\\"{x:1564,y:975,t:1528139888946};\\\", \\\"{x:1562,y:974,t:1528139888959};\\\", \\\"{x:1559,y:973,t:1528139888975};\\\", \\\"{x:1558,y:973,t:1528139888991};\\\", \\\"{x:1557,y:972,t:1528139889009};\\\", \\\"{x:1556,y:971,t:1528139889025};\\\", \\\"{x:1555,y:970,t:1528139889050};\\\", \\\"{x:1554,y:968,t:1528139889058};\\\", \\\"{x:1552,y:964,t:1528139889074};\\\", \\\"{x:1550,y:962,t:1528139889092};\\\", \\\"{x:1550,y:959,t:1528139889108};\\\", \\\"{x:1547,y:950,t:1528139889124};\\\", \\\"{x:1541,y:938,t:1528139889141};\\\", \\\"{x:1535,y:926,t:1528139889159};\\\", \\\"{x:1530,y:913,t:1528139889175};\\\", \\\"{x:1526,y:903,t:1528139889192};\\\", \\\"{x:1522,y:898,t:1528139889208};\\\", \\\"{x:1521,y:892,t:1528139889224};\\\", \\\"{x:1518,y:883,t:1528139889242};\\\", \\\"{x:1516,y:874,t:1528139889257};\\\", \\\"{x:1512,y:866,t:1528139889275};\\\", \\\"{x:1509,y:863,t:1528139889292};\\\", \\\"{x:1508,y:862,t:1528139889309};\\\", \\\"{x:1508,y:861,t:1528139889339};\\\", \\\"{x:1508,y:859,t:1528139889371};\\\", \\\"{x:1507,y:858,t:1528139889378};\\\", \\\"{x:1506,y:857,t:1528139889392};\\\", \\\"{x:1505,y:855,t:1528139889409};\\\", \\\"{x:1502,y:851,t:1528139889426};\\\", \\\"{x:1500,y:848,t:1528139889442};\\\", \\\"{x:1498,y:845,t:1528139889459};\\\", \\\"{x:1496,y:843,t:1528139889476};\\\", \\\"{x:1495,y:841,t:1528139889492};\\\", \\\"{x:1493,y:839,t:1528139889509};\\\", \\\"{x:1492,y:836,t:1528139889526};\\\", \\\"{x:1490,y:835,t:1528139889542};\\\", \\\"{x:1490,y:834,t:1528139889559};\\\", \\\"{x:1489,y:833,t:1528139889610};\\\", \\\"{x:1488,y:832,t:1528139889627};\\\", \\\"{x:1488,y:831,t:1528139889643};\\\", \\\"{x:1487,y:830,t:1528139889659};\\\", \\\"{x:1487,y:829,t:1528139889676};\\\", \\\"{x:1486,y:828,t:1528139889694};\\\", \\\"{x:1483,y:824,t:1528139889709};\\\", \\\"{x:1481,y:821,t:1528139889725};\\\", \\\"{x:1480,y:819,t:1528139889742};\\\", \\\"{x:1478,y:817,t:1528139889758};\\\", \\\"{x:1475,y:812,t:1528139889776};\\\", \\\"{x:1470,y:800,t:1528139889792};\\\", \\\"{x:1461,y:783,t:1528139889808};\\\", \\\"{x:1447,y:758,t:1528139889825};\\\", \\\"{x:1436,y:736,t:1528139889842};\\\", \\\"{x:1421,y:713,t:1528139889858};\\\", \\\"{x:1405,y:688,t:1528139889875};\\\", \\\"{x:1382,y:652,t:1528139889892};\\\", \\\"{x:1348,y:607,t:1528139889908};\\\", \\\"{x:1309,y:571,t:1528139889925};\\\", \\\"{x:1267,y:541,t:1528139889943};\\\", \\\"{x:1221,y:518,t:1528139889959};\\\", \\\"{x:1180,y:500,t:1528139889976};\\\", \\\"{x:1130,y:486,t:1528139889993};\\\", \\\"{x:1074,y:478,t:1528139890009};\\\", \\\"{x:946,y:455,t:1528139890026};\\\", \\\"{x:862,y:440,t:1528139890042};\\\", \\\"{x:798,y:432,t:1528139890058};\\\", \\\"{x:746,y:421,t:1528139890076};\\\", \\\"{x:711,y:414,t:1528139890093};\\\", \\\"{x:679,y:412,t:1528139890108};\\\", \\\"{x:646,y:412,t:1528139890126};\\\", \\\"{x:622,y:417,t:1528139890143};\\\", \\\"{x:611,y:420,t:1528139890160};\\\", \\\"{x:605,y:422,t:1528139890176};\\\", \\\"{x:596,y:426,t:1528139890193};\\\", \\\"{x:577,y:436,t:1528139890210};\\\", \\\"{x:562,y:446,t:1528139890226};\\\", \\\"{x:547,y:463,t:1528139890243};\\\", \\\"{x:537,y:476,t:1528139890260};\\\", \\\"{x:533,y:482,t:1528139890275};\\\", \\\"{x:531,y:484,t:1528139890293};\\\", \\\"{x:529,y:492,t:1528139890312};\\\", \\\"{x:529,y:503,t:1528139890325};\\\", \\\"{x:529,y:516,t:1528139890342};\\\", \\\"{x:529,y:526,t:1528139890359};\\\", \\\"{x:531,y:532,t:1528139890375};\\\", \\\"{x:533,y:536,t:1528139890392};\\\", \\\"{x:536,y:540,t:1528139890408};\\\", \\\"{x:544,y:548,t:1528139890425};\\\", \\\"{x:552,y:553,t:1528139890442};\\\", \\\"{x:562,y:560,t:1528139890459};\\\", \\\"{x:571,y:565,t:1528139890476};\\\", \\\"{x:578,y:568,t:1528139890491};\\\", \\\"{x:580,y:568,t:1528139890509};\\\", \\\"{x:581,y:568,t:1528139890525};\\\", \\\"{x:582,y:568,t:1528139890542};\\\", \\\"{x:583,y:569,t:1528139890558};\\\", \\\"{x:584,y:570,t:1528139890575};\\\", \\\"{x:588,y:570,t:1528139890592};\\\", \\\"{x:590,y:570,t:1528139890609};\\\", \\\"{x:592,y:570,t:1528139890625};\\\", \\\"{x:594,y:570,t:1528139890642};\\\", \\\"{x:595,y:570,t:1528139890658};\\\", \\\"{x:596,y:570,t:1528139890675};\\\", \\\"{x:599,y:571,t:1528139890691};\\\", \\\"{x:599,y:573,t:1528139890708};\\\", \\\"{x:599,y:576,t:1528139890724};\\\", \\\"{x:599,y:579,t:1528139891002};\\\", \\\"{x:596,y:587,t:1528139891010};\\\", \\\"{x:591,y:600,t:1528139891026};\\\", \\\"{x:582,y:621,t:1528139891041};\\\", \\\"{x:579,y:634,t:1528139891059};\\\", \\\"{x:579,y:635,t:1528139891076};\\\", \\\"{x:580,y:636,t:1528139891092};\\\", \\\"{x:587,y:633,t:1528139891109};\\\", \\\"{x:593,y:629,t:1528139891125};\\\", \\\"{x:610,y:616,t:1528139891142};\\\", \\\"{x:626,y:603,t:1528139891160};\\\", \\\"{x:630,y:599,t:1528139891176};\\\", \\\"{x:632,y:597,t:1528139891192};\\\", \\\"{x:632,y:596,t:1528139891209};\\\", \\\"{x:632,y:594,t:1528139891241};\\\", \\\"{x:632,y:592,t:1528139891250};\\\", \\\"{x:632,y:591,t:1528139891259};\\\", \\\"{x:632,y:587,t:1528139891276};\\\", \\\"{x:630,y:584,t:1528139891292};\\\", \\\"{x:629,y:583,t:1528139891309};\\\", \\\"{x:628,y:582,t:1528139891326};\\\", \\\"{x:627,y:582,t:1528139891353};\\\", \\\"{x:626,y:582,t:1528139891369};\\\", \\\"{x:624,y:582,t:1528139891378};\\\", \\\"{x:621,y:582,t:1528139891393};\\\", \\\"{x:616,y:581,t:1528139891410};\\\", \\\"{x:613,y:580,t:1528139891426};\\\", \\\"{x:612,y:579,t:1528139891466};\\\", \\\"{x:605,y:587,t:1528139891858};\\\", \\\"{x:589,y:614,t:1528139891867};\\\", \\\"{x:574,y:641,t:1528139891878};\\\", \\\"{x:545,y:698,t:1528139891893};\\\", \\\"{x:534,y:719,t:1528139891909};\\\", \\\"{x:524,y:735,t:1528139891927};\\\", \\\"{x:512,y:752,t:1528139891943};\\\", \\\"{x:504,y:763,t:1528139891959};\\\", \\\"{x:501,y:765,t:1528139891976};\\\", \\\"{x:500,y:765,t:1528139892010};\\\", \\\"{x:503,y:764,t:1528139892106};\\\", \\\"{x:504,y:762,t:1528139892114};\\\", \\\"{x:506,y:758,t:1528139892126};\\\", \\\"{x:511,y:751,t:1528139892144};\\\", \\\"{x:515,y:746,t:1528139892159};\\\", \\\"{x:518,y:741,t:1528139892176};\\\", \\\"{x:519,y:735,t:1528139892194};\\\", \\\"{x:520,y:734,t:1528139892211};\\\" ] }, { \\\"rt\\\": 21616, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 657615, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X -K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:734,t:1528139893681};\\\", \\\"{x:532,y:736,t:1528139893694};\\\", \\\"{x:560,y:739,t:1528139893711};\\\", \\\"{x:586,y:739,t:1528139893727};\\\", \\\"{x:587,y:739,t:1528139893744};\\\", \\\"{x:587,y:737,t:1528139894274};\\\", \\\"{x:587,y:733,t:1528139894281};\\\", \\\"{x:586,y:728,t:1528139894294};\\\", \\\"{x:584,y:716,t:1528139894312};\\\", \\\"{x:580,y:701,t:1528139894327};\\\", \\\"{x:576,y:684,t:1528139894344};\\\", \\\"{x:554,y:628,t:1528139894363};\\\", \\\"{x:528,y:587,t:1528139894378};\\\", \\\"{x:487,y:530,t:1528139894395};\\\", \\\"{x:449,y:482,t:1528139894412};\\\", \\\"{x:427,y:458,t:1528139894428};\\\", \\\"{x:418,y:447,t:1528139894446};\\\", \\\"{x:416,y:444,t:1528139894462};\\\", \\\"{x:416,y:443,t:1528139894489};\\\", \\\"{x:416,y:442,t:1528139894513};\\\", \\\"{x:416,y:440,t:1528139894529};\\\", \\\"{x:416,y:439,t:1528139894546};\\\", \\\"{x:417,y:439,t:1528139894787};\\\", \\\"{x:418,y:439,t:1528139894802};\\\", \\\"{x:419,y:439,t:1528139894813};\\\", \\\"{x:422,y:439,t:1528139894830};\\\", \\\"{x:425,y:437,t:1528139894846};\\\", \\\"{x:428,y:437,t:1528139894862};\\\", \\\"{x:430,y:439,t:1528139895297};\\\", \\\"{x:431,y:449,t:1528139895313};\\\", \\\"{x:434,y:460,t:1528139895331};\\\", \\\"{x:436,y:466,t:1528139895347};\\\", \\\"{x:437,y:471,t:1528139895362};\\\", \\\"{x:438,y:474,t:1528139895378};\\\", \\\"{x:441,y:474,t:1528139896003};\\\", \\\"{x:446,y:474,t:1528139896010};\\\", \\\"{x:452,y:472,t:1528139896029};\\\", \\\"{x:465,y:472,t:1528139896046};\\\", \\\"{x:478,y:471,t:1528139896063};\\\", \\\"{x:491,y:471,t:1528139896080};\\\", \\\"{x:505,y:471,t:1528139896096};\\\", \\\"{x:525,y:471,t:1528139896113};\\\", \\\"{x:534,y:471,t:1528139896129};\\\", \\\"{x:540,y:471,t:1528139896146};\\\", \\\"{x:544,y:473,t:1528139896162};\\\", \\\"{x:549,y:474,t:1528139896179};\\\", \\\"{x:556,y:474,t:1528139896196};\\\", \\\"{x:566,y:474,t:1528139896213};\\\", \\\"{x:579,y:477,t:1528139896229};\\\", \\\"{x:591,y:479,t:1528139896247};\\\", \\\"{x:606,y:479,t:1528139896263};\\\", \\\"{x:622,y:482,t:1528139896280};\\\", \\\"{x:634,y:482,t:1528139896296};\\\", \\\"{x:641,y:483,t:1528139896313};\\\", \\\"{x:642,y:484,t:1528139896329};\\\", \\\"{x:643,y:484,t:1528139896353};\\\", \\\"{x:643,y:484,t:1528139896644};\\\", \\\"{x:646,y:484,t:1528139896715};\\\", \\\"{x:655,y:478,t:1528139896731};\\\", \\\"{x:663,y:476,t:1528139896747};\\\", \\\"{x:669,y:469,t:1528139896764};\\\", \\\"{x:677,y:464,t:1528139896781};\\\", \\\"{x:679,y:463,t:1528139896797};\\\", \\\"{x:680,y:463,t:1528139896814};\\\", \\\"{x:677,y:463,t:1528139900075};\\\", \\\"{x:670,y:463,t:1528139900083};\\\", \\\"{x:654,y:459,t:1528139900100};\\\", \\\"{x:636,y:450,t:1528139900117};\\\", \\\"{x:621,y:443,t:1528139900134};\\\", \\\"{x:613,y:441,t:1528139900150};\\\", \\\"{x:611,y:439,t:1528139900167};\\\", \\\"{x:610,y:439,t:1528139900184};\\\", \\\"{x:608,y:438,t:1528139900200};\\\", \\\"{x:606,y:437,t:1528139900217};\\\", \\\"{x:605,y:437,t:1528139900234};\\\", \\\"{x:604,y:436,t:1528139900299};\\\", \\\"{x:604,y:438,t:1528139900483};\\\", \\\"{x:604,y:440,t:1528139900490};\\\", \\\"{x:605,y:442,t:1528139900500};\\\", \\\"{x:606,y:443,t:1528139900518};\\\", \\\"{x:608,y:447,t:1528139900534};\\\", \\\"{x:611,y:451,t:1528139900551};\\\", \\\"{x:613,y:454,t:1528139900567};\\\", \\\"{x:614,y:455,t:1528139900585};\\\", \\\"{x:615,y:456,t:1528139900601};\\\", \\\"{x:619,y:460,t:1528139900617};\\\", \\\"{x:624,y:468,t:1528139900634};\\\", \\\"{x:626,y:470,t:1528139900651};\\\", \\\"{x:628,y:471,t:1528139900667};\\\", \\\"{x:629,y:472,t:1528139900684};\\\", \\\"{x:629,y:473,t:1528139900701};\\\", \\\"{x:631,y:473,t:1528139900738};\\\", \\\"{x:632,y:473,t:1528139900762};\\\", \\\"{x:634,y:473,t:1528139900777};\\\", \\\"{x:635,y:473,t:1528139900834};\\\", \\\"{x:634,y:473,t:1528139901130};\\\", \\\"{x:632,y:473,t:1528139901138};\\\", \\\"{x:629,y:473,t:1528139901151};\\\", \\\"{x:619,y:473,t:1528139901168};\\\", \\\"{x:603,y:473,t:1528139901184};\\\", \\\"{x:582,y:473,t:1528139901200};\\\", \\\"{x:515,y:473,t:1528139901234};\\\", \\\"{x:490,y:473,t:1528139901249};\\\", \\\"{x:465,y:473,t:1528139901268};\\\", \\\"{x:446,y:473,t:1528139901284};\\\", \\\"{x:431,y:473,t:1528139901301};\\\", \\\"{x:417,y:473,t:1528139901318};\\\", \\\"{x:401,y:473,t:1528139901333};\\\", \\\"{x:376,y:473,t:1528139901351};\\\", \\\"{x:349,y:473,t:1528139901367};\\\", \\\"{x:327,y:471,t:1528139901383};\\\", \\\"{x:311,y:471,t:1528139901401};\\\", \\\"{x:297,y:471,t:1528139901417};\\\", \\\"{x:294,y:471,t:1528139901434};\\\", \\\"{x:293,y:471,t:1528139901451};\\\", \\\"{x:293,y:471,t:1528139902763};\\\", \\\"{x:297,y:469,t:1528139902987};\\\", \\\"{x:306,y:468,t:1528139903001};\\\", \\\"{x:333,y:468,t:1528139903017};\\\", \\\"{x:383,y:468,t:1528139903034};\\\", \\\"{x:525,y:468,t:1528139903050};\\\", \\\"{x:647,y:468,t:1528139903067};\\\", \\\"{x:809,y:485,t:1528139903084};\\\", \\\"{x:980,y:509,t:1528139903100};\\\", \\\"{x:1160,y:534,t:1528139903117};\\\", \\\"{x:1307,y:556,t:1528139903133};\\\", \\\"{x:1435,y:579,t:1528139903149};\\\", \\\"{x:1524,y:604,t:1528139903167};\\\", \\\"{x:1573,y:622,t:1528139903183};\\\", \\\"{x:1597,y:634,t:1528139903200};\\\", \\\"{x:1609,y:643,t:1528139903216};\\\", \\\"{x:1624,y:658,t:1528139903233};\\\", \\\"{x:1646,y:688,t:1528139903250};\\\", \\\"{x:1660,y:711,t:1528139903268};\\\", \\\"{x:1670,y:738,t:1528139903284};\\\", \\\"{x:1677,y:775,t:1528139903301};\\\", \\\"{x:1685,y:825,t:1528139903317};\\\", \\\"{x:1695,y:898,t:1528139903333};\\\", \\\"{x:1709,y:963,t:1528139903351};\\\", \\\"{x:1717,y:1019,t:1528139903368};\\\", \\\"{x:1719,y:1036,t:1528139903384};\\\", \\\"{x:1719,y:1040,t:1528139903400};\\\", \\\"{x:1719,y:1043,t:1528139903416};\\\", \\\"{x:1717,y:1046,t:1528139903433};\\\", \\\"{x:1712,y:1047,t:1528139903450};\\\", \\\"{x:1711,y:1047,t:1528139903465};\\\", \\\"{x:1707,y:1047,t:1528139905747};\\\", \\\"{x:1702,y:1047,t:1528139905754};\\\", \\\"{x:1700,y:1047,t:1528139905765};\\\", \\\"{x:1696,y:1047,t:1528139905783};\\\", \\\"{x:1691,y:1047,t:1528139905799};\\\", \\\"{x:1679,y:1047,t:1528139905815};\\\", \\\"{x:1670,y:1046,t:1528139905833};\\\", \\\"{x:1659,y:1044,t:1528139905851};\\\", \\\"{x:1655,y:1044,t:1528139905866};\\\", \\\"{x:1650,y:1042,t:1528139905882};\\\", \\\"{x:1647,y:1042,t:1528139905900};\\\", \\\"{x:1642,y:1042,t:1528139905916};\\\", \\\"{x:1634,y:1040,t:1528139905933};\\\", \\\"{x:1622,y:1037,t:1528139905950};\\\", \\\"{x:1614,y:1035,t:1528139905966};\\\", \\\"{x:1610,y:1033,t:1528139905983};\\\", \\\"{x:1604,y:1032,t:1528139905999};\\\", \\\"{x:1596,y:1029,t:1528139906016};\\\", \\\"{x:1586,y:1025,t:1528139906033};\\\", \\\"{x:1571,y:1022,t:1528139906050};\\\", \\\"{x:1555,y:1017,t:1528139906066};\\\", \\\"{x:1542,y:1013,t:1528139906082};\\\", \\\"{x:1530,y:1009,t:1528139906099};\\\", \\\"{x:1522,y:1005,t:1528139906115};\\\", \\\"{x:1515,y:1003,t:1528139906132};\\\", \\\"{x:1507,y:1002,t:1528139906149};\\\", \\\"{x:1497,y:999,t:1528139906166};\\\", \\\"{x:1485,y:995,t:1528139906182};\\\", \\\"{x:1474,y:991,t:1528139906198};\\\", \\\"{x:1467,y:990,t:1528139906216};\\\", \\\"{x:1465,y:988,t:1528139906233};\\\", \\\"{x:1464,y:986,t:1528139906249};\\\", \\\"{x:1463,y:985,t:1528139906266};\\\", \\\"{x:1462,y:984,t:1528139906282};\\\", \\\"{x:1462,y:982,t:1528139906306};\\\", \\\"{x:1462,y:980,t:1528139906322};\\\", \\\"{x:1462,y:979,t:1528139906333};\\\", \\\"{x:1463,y:976,t:1528139906349};\\\", \\\"{x:1465,y:974,t:1528139906366};\\\", \\\"{x:1467,y:971,t:1528139906383};\\\", \\\"{x:1468,y:970,t:1528139906399};\\\", \\\"{x:1469,y:968,t:1528139906419};\\\", \\\"{x:1470,y:968,t:1528139906442};\\\", \\\"{x:1471,y:968,t:1528139906450};\\\", \\\"{x:1471,y:967,t:1528139906466};\\\", \\\"{x:1472,y:967,t:1528139906522};\\\", \\\"{x:1473,y:967,t:1528139906532};\\\", \\\"{x:1474,y:967,t:1528139906549};\\\", \\\"{x:1475,y:967,t:1528139906570};\\\", \\\"{x:1476,y:967,t:1528139906587};\\\", \\\"{x:1477,y:967,t:1528139906602};\\\", \\\"{x:1478,y:967,t:1528139906650};\\\", \\\"{x:1479,y:966,t:1528139906665};\\\", \\\"{x:1479,y:965,t:1528139906682};\\\", \\\"{x:1480,y:965,t:1528139906699};\\\", \\\"{x:1481,y:964,t:1528139906729};\\\", \\\"{x:1483,y:962,t:1528139907267};\\\", \\\"{x:1483,y:955,t:1528139907282};\\\", \\\"{x:1484,y:951,t:1528139907298};\\\", \\\"{x:1486,y:946,t:1528139907316};\\\", \\\"{x:1487,y:940,t:1528139907332};\\\", \\\"{x:1488,y:931,t:1528139907349};\\\", \\\"{x:1488,y:923,t:1528139907366};\\\", \\\"{x:1488,y:908,t:1528139907382};\\\", \\\"{x:1488,y:891,t:1528139907399};\\\", \\\"{x:1488,y:884,t:1528139907415};\\\", \\\"{x:1488,y:879,t:1528139907431};\\\", \\\"{x:1488,y:875,t:1528139907449};\\\", \\\"{x:1488,y:872,t:1528139907465};\\\", \\\"{x:1489,y:869,t:1528139907482};\\\", \\\"{x:1489,y:866,t:1528139907499};\\\", \\\"{x:1489,y:862,t:1528139907515};\\\", \\\"{x:1489,y:860,t:1528139907532};\\\", \\\"{x:1489,y:858,t:1528139907549};\\\", \\\"{x:1489,y:856,t:1528139907565};\\\", \\\"{x:1489,y:855,t:1528139907582};\\\", \\\"{x:1489,y:853,t:1528139907599};\\\", \\\"{x:1489,y:851,t:1528139907615};\\\", \\\"{x:1489,y:849,t:1528139907632};\\\", \\\"{x:1488,y:845,t:1528139907649};\\\", \\\"{x:1486,y:842,t:1528139907665};\\\", \\\"{x:1486,y:840,t:1528139907682};\\\", \\\"{x:1485,y:838,t:1528139907707};\\\", \\\"{x:1485,y:837,t:1528139907738};\\\", \\\"{x:1484,y:836,t:1528139907755};\\\", \\\"{x:1484,y:835,t:1528139907765};\\\", \\\"{x:1484,y:834,t:1528139907813};\\\", \\\"{x:1484,y:833,t:1528139907831};\\\", \\\"{x:1483,y:832,t:1528139907848};\\\", \\\"{x:1482,y:830,t:1528139907864};\\\", \\\"{x:1482,y:829,t:1528139907905};\\\", \\\"{x:1481,y:827,t:1528139907961};\\\", \\\"{x:1481,y:826,t:1528139908962};\\\", \\\"{x:1481,y:825,t:1528139908986};\\\", \\\"{x:1481,y:823,t:1528139908999};\\\", \\\"{x:1481,y:821,t:1528139909015};\\\", \\\"{x:1481,y:819,t:1528139909030};\\\", \\\"{x:1481,y:816,t:1528139909048};\\\", \\\"{x:1481,y:815,t:1528139909065};\\\", \\\"{x:1481,y:813,t:1528139909081};\\\", \\\"{x:1481,y:810,t:1528139909099};\\\", \\\"{x:1481,y:809,t:1528139909114};\\\", \\\"{x:1481,y:808,t:1528139909131};\\\", \\\"{x:1481,y:805,t:1528139909148};\\\", \\\"{x:1481,y:802,t:1528139909165};\\\", \\\"{x:1481,y:797,t:1528139909181};\\\", \\\"{x:1481,y:794,t:1528139909198};\\\", \\\"{x:1481,y:790,t:1528139909214};\\\", \\\"{x:1481,y:785,t:1528139909230};\\\", \\\"{x:1481,y:782,t:1528139909248};\\\", \\\"{x:1481,y:778,t:1528139909265};\\\", \\\"{x:1481,y:773,t:1528139909281};\\\", \\\"{x:1481,y:762,t:1528139909299};\\\", \\\"{x:1481,y:755,t:1528139909314};\\\", \\\"{x:1481,y:748,t:1528139909331};\\\", \\\"{x:1481,y:744,t:1528139909348};\\\", \\\"{x:1481,y:739,t:1528139909364};\\\", \\\"{x:1481,y:733,t:1528139909381};\\\", \\\"{x:1481,y:729,t:1528139909398};\\\", \\\"{x:1481,y:720,t:1528139909414};\\\", \\\"{x:1481,y:713,t:1528139909431};\\\", \\\"{x:1481,y:710,t:1528139909448};\\\", \\\"{x:1481,y:706,t:1528139909464};\\\", \\\"{x:1481,y:703,t:1528139909481};\\\", \\\"{x:1480,y:696,t:1528139909498};\\\", \\\"{x:1479,y:692,t:1528139909514};\\\", \\\"{x:1479,y:690,t:1528139909531};\\\", \\\"{x:1479,y:686,t:1528139909548};\\\", \\\"{x:1479,y:685,t:1528139909564};\\\", \\\"{x:1479,y:684,t:1528139909867};\\\", \\\"{x:1479,y:675,t:1528139909881};\\\", \\\"{x:1484,y:635,t:1528139909898};\\\", \\\"{x:1489,y:623,t:1528139909914};\\\", \\\"{x:1493,y:611,t:1528139909931};\\\", \\\"{x:1498,y:601,t:1528139909948};\\\", \\\"{x:1501,y:590,t:1528139909964};\\\", \\\"{x:1503,y:581,t:1528139909981};\\\", \\\"{x:1503,y:579,t:1528139909997};\\\", \\\"{x:1503,y:574,t:1528139910014};\\\", \\\"{x:1503,y:569,t:1528139910031};\\\", \\\"{x:1503,y:566,t:1528139910047};\\\", \\\"{x:1503,y:558,t:1528139910064};\\\", \\\"{x:1501,y:555,t:1528139910081};\\\", \\\"{x:1497,y:549,t:1528139910097};\\\", \\\"{x:1495,y:545,t:1528139910114};\\\", \\\"{x:1493,y:543,t:1528139910131};\\\", \\\"{x:1491,y:539,t:1528139910147};\\\", \\\"{x:1490,y:536,t:1528139910164};\\\", \\\"{x:1488,y:533,t:1528139910181};\\\", \\\"{x:1485,y:530,t:1528139910197};\\\", \\\"{x:1485,y:529,t:1528139910214};\\\", \\\"{x:1484,y:528,t:1528139910242};\\\", \\\"{x:1484,y:527,t:1528139910282};\\\", \\\"{x:1484,y:526,t:1528139910297};\\\", \\\"{x:1484,y:523,t:1528139910314};\\\", \\\"{x:1484,y:520,t:1528139910330};\\\", \\\"{x:1484,y:516,t:1528139910347};\\\", \\\"{x:1484,y:512,t:1528139910364};\\\", \\\"{x:1484,y:509,t:1528139910381};\\\", \\\"{x:1484,y:506,t:1528139910397};\\\", \\\"{x:1484,y:500,t:1528139910413};\\\", \\\"{x:1485,y:490,t:1528139910430};\\\", \\\"{x:1486,y:480,t:1528139910446};\\\", \\\"{x:1488,y:471,t:1528139910463};\\\", \\\"{x:1489,y:461,t:1528139910480};\\\", \\\"{x:1489,y:453,t:1528139910497};\\\", \\\"{x:1490,y:443,t:1528139910513};\\\", \\\"{x:1490,y:438,t:1528139910530};\\\", \\\"{x:1490,y:433,t:1528139910546};\\\", \\\"{x:1490,y:428,t:1528139910563};\\\", \\\"{x:1490,y:424,t:1528139910580};\\\", \\\"{x:1490,y:421,t:1528139910597};\\\", \\\"{x:1490,y:418,t:1528139910614};\\\", \\\"{x:1492,y:414,t:1528139910631};\\\", \\\"{x:1492,y:412,t:1528139910647};\\\", \\\"{x:1492,y:410,t:1528139910664};\\\", \\\"{x:1492,y:408,t:1528139910680};\\\", \\\"{x:1492,y:406,t:1528139910697};\\\", \\\"{x:1492,y:401,t:1528139910714};\\\", \\\"{x:1492,y:397,t:1528139910730};\\\", \\\"{x:1492,y:392,t:1528139910747};\\\", \\\"{x:1492,y:386,t:1528139910764};\\\", \\\"{x:1492,y:383,t:1528139910780};\\\", \\\"{x:1491,y:377,t:1528139910797};\\\", \\\"{x:1491,y:373,t:1528139910814};\\\", \\\"{x:1489,y:366,t:1528139910830};\\\", \\\"{x:1488,y:358,t:1528139910847};\\\", \\\"{x:1487,y:347,t:1528139910865};\\\", \\\"{x:1484,y:331,t:1528139910880};\\\", \\\"{x:1483,y:320,t:1528139910897};\\\", \\\"{x:1480,y:311,t:1528139910914};\\\", \\\"{x:1478,y:305,t:1528139910930};\\\", \\\"{x:1477,y:297,t:1528139910948};\\\", \\\"{x:1476,y:289,t:1528139910965};\\\", \\\"{x:1475,y:282,t:1528139910980};\\\", \\\"{x:1474,y:278,t:1528139910997};\\\", \\\"{x:1474,y:275,t:1528139911014};\\\", \\\"{x:1474,y:274,t:1528139911030};\\\", \\\"{x:1473,y:272,t:1528139911354};\\\", \\\"{x:1460,y:272,t:1528139911363};\\\", \\\"{x:1423,y:284,t:1528139911379};\\\", \\\"{x:1322,y:303,t:1528139911397};\\\", \\\"{x:1186,y:324,t:1528139911413};\\\", \\\"{x:1020,y:349,t:1528139911429};\\\", \\\"{x:846,y:376,t:1528139911447};\\\", \\\"{x:681,y:407,t:1528139911463};\\\", \\\"{x:563,y:425,t:1528139911479};\\\", \\\"{x:396,y:458,t:1528139911497};\\\", \\\"{x:292,y:485,t:1528139911513};\\\", \\\"{x:231,y:518,t:1528139911531};\\\", \\\"{x:224,y:527,t:1528139911546};\\\", \\\"{x:223,y:531,t:1528139911562};\\\", \\\"{x:223,y:533,t:1528139911575};\\\", \\\"{x:224,y:536,t:1528139911590};\\\", \\\"{x:233,y:548,t:1528139911607};\\\", \\\"{x:248,y:565,t:1528139911624};\\\", \\\"{x:289,y:606,t:1528139911643};\\\", \\\"{x:320,y:634,t:1528139911660};\\\", \\\"{x:354,y:667,t:1528139911676};\\\", \\\"{x:376,y:684,t:1528139911692};\\\", \\\"{x:392,y:691,t:1528139911709};\\\", \\\"{x:406,y:693,t:1528139911725};\\\", \\\"{x:416,y:693,t:1528139911742};\\\", \\\"{x:437,y:683,t:1528139911760};\\\", \\\"{x:461,y:674,t:1528139911776};\\\", \\\"{x:494,y:661,t:1528139911792};\\\", \\\"{x:534,y:636,t:1528139911810};\\\", \\\"{x:557,y:622,t:1528139911826};\\\", \\\"{x:567,y:615,t:1528139911843};\\\", \\\"{x:571,y:612,t:1528139911860};\\\", \\\"{x:572,y:609,t:1528139911877};\\\", \\\"{x:572,y:604,t:1528139911892};\\\", \\\"{x:566,y:597,t:1528139911909};\\\", \\\"{x:549,y:588,t:1528139911926};\\\", \\\"{x:528,y:579,t:1528139911942};\\\", \\\"{x:507,y:574,t:1528139911960};\\\", \\\"{x:492,y:572,t:1528139911976};\\\", \\\"{x:481,y:569,t:1528139911993};\\\", \\\"{x:476,y:568,t:1528139912009};\\\", \\\"{x:474,y:568,t:1528139912762};\\\", \\\"{x:471,y:569,t:1528139912778};\\\", \\\"{x:468,y:572,t:1528139912795};\\\", \\\"{x:467,y:573,t:1528139912810};\\\", \\\"{x:467,y:574,t:1528139912841};\\\", \\\"{x:466,y:576,t:1528139912849};\\\", \\\"{x:465,y:579,t:1528139912866};\\\", \\\"{x:465,y:580,t:1528139912876};\\\", \\\"{x:463,y:583,t:1528139912894};\\\", \\\"{x:462,y:587,t:1528139912910};\\\", \\\"{x:460,y:589,t:1528139912926};\\\", \\\"{x:459,y:590,t:1528139912945};\\\", \\\"{x:457,y:590,t:1528139912986};\\\", \\\"{x:456,y:590,t:1528139912994};\\\", \\\"{x:446,y:584,t:1528139913010};\\\", \\\"{x:434,y:574,t:1528139913028};\\\", \\\"{x:423,y:567,t:1528139913044};\\\", \\\"{x:416,y:560,t:1528139913061};\\\", \\\"{x:413,y:557,t:1528139913078};\\\", \\\"{x:412,y:555,t:1528139913093};\\\", \\\"{x:411,y:557,t:1528139913186};\\\", \\\"{x:409,y:562,t:1528139913194};\\\", \\\"{x:408,y:566,t:1528139913211};\\\", \\\"{x:405,y:572,t:1528139913228};\\\", \\\"{x:404,y:576,t:1528139913244};\\\", \\\"{x:403,y:580,t:1528139913260};\\\", \\\"{x:402,y:584,t:1528139913277};\\\", \\\"{x:401,y:585,t:1528139913354};\\\", \\\"{x:405,y:583,t:1528139913769};\\\", \\\"{x:434,y:583,t:1528139913777};\\\", \\\"{x:508,y:589,t:1528139913795};\\\", \\\"{x:587,y:597,t:1528139913810};\\\", \\\"{x:656,y:604,t:1528139913827};\\\", \\\"{x:706,y:610,t:1528139913845};\\\", \\\"{x:726,y:611,t:1528139913861};\\\", \\\"{x:729,y:612,t:1528139913877};\\\", \\\"{x:731,y:612,t:1528139913955};\\\", \\\"{x:727,y:614,t:1528139914059};\\\", \\\"{x:725,y:614,t:1528139914066};\\\", \\\"{x:722,y:614,t:1528139914078};\\\", \\\"{x:711,y:614,t:1528139914095};\\\", \\\"{x:695,y:614,t:1528139914112};\\\", \\\"{x:674,y:612,t:1528139914128};\\\", \\\"{x:654,y:611,t:1528139914145};\\\", \\\"{x:628,y:607,t:1528139914162};\\\", \\\"{x:624,y:606,t:1528139914177};\\\", \\\"{x:622,y:605,t:1528139914194};\\\", \\\"{x:621,y:604,t:1528139914225};\\\", \\\"{x:620,y:604,t:1528139914257};\\\", \\\"{x:619,y:603,t:1528139914265};\\\", \\\"{x:618,y:601,t:1528139914281};\\\", \\\"{x:618,y:599,t:1528139914294};\\\", \\\"{x:618,y:597,t:1528139914312};\\\", \\\"{x:618,y:595,t:1528139914327};\\\", \\\"{x:618,y:594,t:1528139914344};\\\", \\\"{x:618,y:592,t:1528139914362};\\\", \\\"{x:618,y:591,t:1528139914379};\\\", \\\"{x:619,y:589,t:1528139914394};\\\", \\\"{x:617,y:591,t:1528139914649};\\\", \\\"{x:616,y:592,t:1528139914661};\\\", \\\"{x:612,y:596,t:1528139914679};\\\", \\\"{x:610,y:600,t:1528139914722};\\\", \\\"{x:608,y:604,t:1528139914730};\\\", \\\"{x:608,y:607,t:1528139914745};\\\", \\\"{x:602,y:628,t:1528139914762};\\\", \\\"{x:597,y:642,t:1528139914779};\\\", \\\"{x:591,y:657,t:1528139914795};\\\", \\\"{x:579,y:668,t:1528139914811};\\\", \\\"{x:572,y:683,t:1528139914828};\\\", \\\"{x:567,y:697,t:1528139914846};\\\", \\\"{x:563,y:706,t:1528139914861};\\\", \\\"{x:559,y:713,t:1528139914878};\\\", \\\"{x:555,y:718,t:1528139914896};\\\", \\\"{x:550,y:728,t:1528139914911};\\\", \\\"{x:545,y:736,t:1528139914929};\\\", \\\"{x:543,y:741,t:1528139914944};\\\", \\\"{x:542,y:742,t:1528139914961};\\\", \\\"{x:542,y:743,t:1528139914978};\\\", \\\"{x:542,y:744,t:1528139914996};\\\", \\\"{x:540,y:746,t:1528139915012};\\\", \\\"{x:539,y:747,t:1528139915042};\\\", \\\"{x:539,y:749,t:1528139915057};\\\", \\\"{x:538,y:750,t:1528139915066};\\\", \\\"{x:537,y:752,t:1528139915079};\\\", \\\"{x:534,y:757,t:1528139915096};\\\", \\\"{x:534,y:758,t:1528139915112};\\\", \\\"{x:533,y:758,t:1528139915794};\\\" ] }, { \\\"rt\\\": 106656, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 765547, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"First you find 12pm along the axis representing times of day, the x axis. There are two lines that intersect at that point. The right one represents start time while the left shows end time. So to find what starts at 12pm, follow the right line. All events on that line start at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11295, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United StateS\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 777849, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 12420, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 791290, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6980, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 799605, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"6GNVQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"6GNVQ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 282, dom: 1913, initialDom: 1966",
  "javascriptErrors": []
}