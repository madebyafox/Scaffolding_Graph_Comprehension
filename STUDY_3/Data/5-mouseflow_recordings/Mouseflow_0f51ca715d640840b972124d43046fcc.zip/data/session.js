var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0f51ca715d640840b972124d43046fcc",
  "created": "2018-05-29T16:08:29.8779515-07:00",
  "lastActivity": "2018-05-29T16:11:32.7549515-07:00",
  "pageViews": [
    {
      "id": "05293001ff6fcfdd2f6e9e33f9118d85b46e83bb",
      "startTime": "2018-05-29T16:08:29.8779515-07:00",
      "endTime": "2018-05-29T16:11:32.7549515-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 182877,
      "engagementTime": 115902,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 182877,
  "engagementTime": 115902,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CSU5Z",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4ee87f751a437b197d95b6811537a8a9",
  "gdpr": false
}