var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "97ad98c7982e71c5e8da939d3c63a837",
  "created": "2018-05-15T17:10:01.2827536-07:00",
  "lastActivity": "2018-05-15T17:12:11.3638909-07:00",
  "pageViews": [
    {
      "id": "05150172eb6059ec8da32d5b963241723ae2c0cf",
      "startTime": "2018-05-15T17:10:01.4682207-07:00",
      "endTime": "2018-05-15T17:12:11.3638909-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 130213,
      "engagementTime": 124494,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 130213,
  "engagementTime": 124494,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=QY1F7",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9c153a681b651330fadfbeb9280834e5",
  "gdpr": false
}