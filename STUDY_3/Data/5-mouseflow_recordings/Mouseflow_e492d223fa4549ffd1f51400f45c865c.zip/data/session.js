var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e492d223fa4549ffd1f51400f45c865c",
  "created": "2018-05-22T13:13:09.8380781-07:00",
  "lastActivity": "2018-05-22T13:13:20.2780781-07:00",
  "pageViews": [
    {
      "id": "052210744332494674a14d0639ced42dfcc1794f",
      "startTime": "2018-05-22T13:13:09.8380781-07:00",
      "endTime": "2018-05-22T13:13:20.2780781-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 10440,
      "engagementTime": 10364,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10440,
  "engagementTime": 10364,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZKB08",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ceb268f4ef2d98fd695a83bd2b8029f8",
  "gdpr": false
}