var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "616a13b320cd5256f81c9068399f7dbc",
  "created": "2018-05-31T12:15:07.4278122-07:00",
  "lastActivity": "2018-05-31T12:16:20.7128816-07:00",
  "pageViews": [
    {
      "id": "05310780fb00232e1cfa13eeca9951a86401e811",
      "startTime": "2018-05-31T12:15:07.7868816-07:00",
      "endTime": "2018-05-31T12:16:20.7128816-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 72926,
      "engagementTime": 72281,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 72926,
  "engagementTime": 72281,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=XQ4O8",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0d7ff5a44289baf548fdabfc65d20963",
  "gdpr": false
}