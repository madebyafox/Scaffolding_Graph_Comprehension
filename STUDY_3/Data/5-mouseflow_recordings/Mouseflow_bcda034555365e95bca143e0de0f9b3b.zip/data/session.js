var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bcda034555365e95bca143e0de0f9b3b",
  "created": "2018-05-22T16:06:53.7161956-07:00",
  "lastActivity": "2018-05-22T16:07:25.9073814-07:00",
  "pageViews": [
    {
      "id": "052254094e0c609bc6929ce7c32b6d27352de80d",
      "startTime": "2018-05-22T16:06:53.7493814-07:00",
      "endTime": "2018-05-22T16:07:25.9073814-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 32158,
      "engagementTime": 32157,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32158,
  "engagementTime": 32157,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=E5L6P",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a3b42519afd507e40c546a3d2b4f756f",
  "gdpr": false
}