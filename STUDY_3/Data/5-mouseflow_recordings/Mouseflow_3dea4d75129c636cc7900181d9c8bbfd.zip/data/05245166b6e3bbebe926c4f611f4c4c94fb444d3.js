var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05245166b6e3bbebe926c4f611f4c4c94fb444d3"] = {
  "startTime": "2018-05-24T19:15:51.2457374Z",
  "websitePageUrl": "/16",
  "visitTime": 86531,
  "engagementTime": 84718,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3dea4d75129c636cc7900181d9c8bbfd",
    "created": "2018-05-24T19:15:51.1818348+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=X66XB",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1e95ee9776fec211e03a1e2b5ca4a652",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3dea4d75129c636cc7900181d9c8bbfd/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 684,
      "e": 684,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 655,
      "y": 573
    },
    {
      "t": 2192,
      "e": 2192,
      "ty": 6,
      "x": 586,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 586,
      "y": 550
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 42368,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2291,
      "e": 2291,
      "ty": 7,
      "x": 406,
      "y": 464,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 406,
      "y": 464
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 400,
      "y": 461
    },
    {
      "t": 2476,
      "e": 2476,
      "ty": 6,
      "x": 391,
      "y": 472,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 389,
      "y": 478
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 32813,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 383,
      "y": 485
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 381,
      "y": 487
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 31801,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 380,
      "y": 487
    },
    {
      "t": 4067,
      "e": 4067,
      "ty": 3,
      "x": 380,
      "y": 487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4069,
      "e": 4069,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4259,
      "e": 4259,
      "ty": 4,
      "x": 31801,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4259,
      "e": 4259,
      "ty": 5,
      "x": 380,
      "y": 487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 9259,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10949,
      "e": 9259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 10950,
      "e": 9260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11076,
      "e": 9386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11076,
      "e": 9386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11116,
      "e": 9426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 11173,
      "e": 9483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 11228,
      "e": 9538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11229,
      "e": 9539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11332,
      "e": 9642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you"
    },
    {
      "t": 11493,
      "e": 9803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11493,
      "e": 9803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11580,
      "e": 9890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you "
    },
    {
      "t": 11811,
      "e": 10121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11812,
      "e": 10122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11892,
      "e": 10202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 12003,
      "e": 10313,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you l"
    },
    {
      "t": 12005,
      "e": 10315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12005,
      "e": 10315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12060,
      "e": 10370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12139,
      "e": 10449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12140,
      "e": 10450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12237,
      "e": 10547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 12237,
      "e": 10547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12268,
      "e": 10578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 12332,
      "e": 10642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12476,
      "e": 10786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12477,
      "e": 10787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12603,
      "e": 10913,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look "
    },
    {
      "t": 12628,
      "e": 10938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12781,
      "e": 11091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12781,
      "e": 11091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12844,
      "e": 11154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12844,
      "e": 11154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12924,
      "e": 11234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 12931,
      "e": 11241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13100,
      "e": 11410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13101,
      "e": 11411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13202,
      "e": 11512,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at "
    },
    {
      "t": 13203,
      "e": 11513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13203,
      "e": 11513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13211,
      "e": 11521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 13333,
      "e": 11643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13348,
      "e": 11658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13349,
      "e": 11659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13460,
      "e": 11770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13469,
      "e": 11779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13469,
      "e": 11779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13596,
      "e": 11906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13597,
      "e": 11907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13598,
      "e": 11908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13692,
      "e": 12002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14227,
      "e": 12537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14227,
      "e": 12537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14349,
      "e": 12659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 14420,
      "e": 12730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14421,
      "e": 12731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14532,
      "e": 12842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14532,
      "e": 12842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14539,
      "e": 12849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 14660,
      "e": 12970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14860,
      "e": 13170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14861,
      "e": 13171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15004,
      "e": 13314,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x ax"
    },
    {
      "t": 15005,
      "e": 13315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 15060,
      "e": 13370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15061,
      "e": 13371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15172,
      "e": 13482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15228,
      "e": 13538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15228,
      "e": 13538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15324,
      "e": 13634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15396,
      "e": 13706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15397,
      "e": 13707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15485,
      "e": 13795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16221,
      "e": 14531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16291,
      "e": 14601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis"
    },
    {
      "t": 16404,
      "e": 14714,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis"
    },
    {
      "t": 16548,
      "e": 14858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 16549,
      "e": 14859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16603,
      "e": 14913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 16724,
      "e": 15034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16724,
      "e": 15034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16812,
      "e": 15122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16924,
      "e": 15234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16924,
      "e": 15234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16996,
      "e": 15306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16997,
      "e": 15307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17035,
      "e": 15345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 17116,
      "e": 15426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17164,
      "e": 15474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17164,
      "e": 15474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17251,
      "e": 15561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17284,
      "e": 15594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17284,
      "e": 15594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17396,
      "e": 15706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 17420,
      "e": 15730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17421,
      "e": 15731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17500,
      "e": 15810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17604,
      "e": 15914,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find "
    },
    {
      "t": 18284,
      "e": 16594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18285,
      "e": 16595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18403,
      "e": 16713,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 1"
    },
    {
      "t": 18435,
      "e": 16745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18437,
      "e": 16747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18459,
      "e": 16769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 18564,
      "e": 16874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18763,
      "e": 17073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18763,
      "e": 17073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18860,
      "e": 17170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19060,
      "e": 17370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19061,
      "e": 17371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19124,
      "e": 17434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19917,
      "e": 18227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 19917,
      "e": 18227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19987,
      "e": 18297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 20001,
      "e": 18311,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20796,
      "e": 19106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20797,
      "e": 19107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20884,
      "e": 19194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21084,
      "e": 19394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21085,
      "e": 19395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21203,
      "e": 19513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, a"
    },
    {
      "t": 21228,
      "e": 19538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21380,
      "e": 19690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21380,
      "e": 19690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21476,
      "e": 19786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21492,
      "e": 19802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21492,
      "e": 19802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21587,
      "e": 19897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21636,
      "e": 19946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21636,
      "e": 19946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21731,
      "e": 20041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26165,
      "e": 24475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26165,
      "e": 24475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26299,
      "e": 24609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26771,
      "e": 25081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26883,
      "e": 25193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and "
    },
    {
      "t": 27396,
      "e": 25706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27396,
      "e": 25706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27500,
      "e": 25810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27612,
      "e": 25922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27613,
      "e": 25923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27715,
      "e": 26025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 27715,
      "e": 26025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27756,
      "e": 26066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ov"
    },
    {
      "t": 27764,
      "e": 26074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27764,
      "e": 26074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27788,
      "e": 26098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 27915,
      "e": 26225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27916,
      "e": 26226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27947,
      "e": 26257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28059,
      "e": 26369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28060,
      "e": 26370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28060,
      "e": 26370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28187,
      "e": 26497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28324,
      "e": 26634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28326,
      "e": 26636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28403,
      "e": 26713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 28604,
      "e": 26914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28605,
      "e": 26915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28740,
      "e": 27050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28932,
      "e": 27242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28932,
      "e": 27242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29061,
      "e": 27371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29101,
      "e": 27411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29101,
      "e": 27411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29203,
      "e": 27513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up f"
    },
    {
      "t": 29228,
      "e": 27538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29228,
      "e": 27538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29267,
      "e": 27577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 29356,
      "e": 27666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29380,
      "e": 27690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29381,
      "e": 27691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29515,
      "e": 27825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30001,
      "e": 28311,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30027,
      "e": 28337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30027,
      "e": 28337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30139,
      "e": 28449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 30356,
      "e": 28666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30357,
      "e": 28667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30444,
      "e": 28754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30499,
      "e": 28809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30500,
      "e": 28810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30604,
      "e": 28914,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from t"
    },
    {
      "t": 30612,
      "e": 28922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30620,
      "e": 28930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30621,
      "e": 28931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30747,
      "e": 29057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30844,
      "e": 29154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30845,
      "e": 29155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31003,
      "e": 29313,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from the"
    },
    {
      "t": 31028,
      "e": 29338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31035,
      "e": 29345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31036,
      "e": 29346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31203,
      "e": 29513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from ther"
    },
    {
      "t": 31228,
      "e": 29538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31229,
      "e": 29539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31243,
      "e": 29553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 31340,
      "e": 29650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31396,
      "e": 29706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31396,
      "e": 29706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31508,
      "e": 29818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31547,
      "e": 29857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31547,
      "e": 29857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31652,
      "e": 29962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31708,
      "e": 30018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31709,
      "e": 30019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31844,
      "e": 30154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31948,
      "e": 30258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31949,
      "e": 30259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32068,
      "e": 30378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32091,
      "e": 30401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32092,
      "e": 30402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32204,
      "e": 30514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to s"
    },
    {
      "t": 32220,
      "e": 30530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32324,
      "e": 30634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32325,
      "e": 30635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32412,
      "e": 30722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32524,
      "e": 30834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32526,
      "e": 30836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32587,
      "e": 30897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32828,
      "e": 31138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32830,
      "e": 31140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32939,
      "e": 31249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33740,
      "e": 32050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33741,
      "e": 32051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33860,
      "e": 32170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33868,
      "e": 32178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33868,
      "e": 32178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34004,
      "e": 32314,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if"
    },
    {
      "t": 34005,
      "e": 32315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34108,
      "e": 32418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34109,
      "e": 32419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34219,
      "e": 32529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34358,
      "e": 32668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34359,
      "e": 32669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34451,
      "e": 32761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34531,
      "e": 32841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34532,
      "e": 32842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34643,
      "e": 32953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34643,
      "e": 32953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34651,
      "e": 32961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 34756,
      "e": 33066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34805,
      "e": 33115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34805,
      "e": 33115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34915,
      "e": 33225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34987,
      "e": 33297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34988,
      "e": 33298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35099,
      "e": 33409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35099,
      "e": 33409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35123,
      "e": 33433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 35220,
      "e": 33530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35260,
      "e": 33570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35261,
      "e": 33571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35372,
      "e": 33682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35499,
      "e": 33809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35501,
      "e": 33811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35603,
      "e": 33913,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a"
    },
    {
      "t": 35628,
      "e": 33914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35675,
      "e": 33961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35675,
      "e": 33961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35780,
      "e": 34066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36004,
      "e": 34290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36005,
      "e": 34291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36108,
      "e": 34394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36180,
      "e": 34466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36180,
      "e": 34466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36276,
      "e": 34562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36420,
      "e": 34706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36421,
      "e": 34707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36523,
      "e": 34809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 36523,
      "e": 34809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36539,
      "e": 34825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 36660,
      "e": 34946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36780,
      "e": 35066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36781,
      "e": 35067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36875,
      "e": 35161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36980,
      "e": 35266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36981,
      "e": 35267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37059,
      "e": 35345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37676,
      "e": 35962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37677,
      "e": 35963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37804,
      "e": 36090,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift s"
    },
    {
      "t": 37805,
      "e": 36091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 37989,
      "e": 36275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37990,
      "e": 36276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38092,
      "e": 36378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38131,
      "e": 36417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38132,
      "e": 36418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38284,
      "e": 36570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38300,
      "e": 36586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38301,
      "e": 36587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38380,
      "e": 36666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38475,
      "e": 36761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38476,
      "e": 36762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38579,
      "e": 36865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38628,
      "e": 36914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38628,
      "e": 36914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38756,
      "e": 37042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38811,
      "e": 37097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38811,
      "e": 37097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38907,
      "e": 37193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38988,
      "e": 37274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38988,
      "e": 37274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39091,
      "e": 37377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39155,
      "e": 37441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 39156,
      "e": 37442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39243,
      "e": 37529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 39548,
      "e": 37834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39627,
      "e": 37913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift starts e"
    },
    {
      "t": 39852,
      "e": 38138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39853,
      "e": 38139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39924,
      "e": 38210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39924,
      "e": 38210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39931,
      "e": 38217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 40035,
      "e": 38321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40172,
      "e": 38458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40173,
      "e": 38459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40275,
      "e": 38561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40459,
      "e": 38745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 40461,
      "e": 38747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40539,
      "e": 38825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 40653,
      "e": 38939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40653,
      "e": 38939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40723,
      "e": 39009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40788,
      "e": 39074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40788,
      "e": 39074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40907,
      "e": 39193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40996,
      "e": 39282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40997,
      "e": 39283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41091,
      "e": 39377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41147,
      "e": 39433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 41147,
      "e": 39433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41260,
      "e": 39546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 41613,
      "e": 39899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 41613,
      "e": 39899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41684,
      "e": 39970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 41803,
      "e": 40089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift starts ends, etc."
    },
    {
      "t": 42602,
      "e": 40888,
      "ty": 2,
      "x": 366,
      "y": 509
    },
    {
      "t": 42628,
      "e": 40914,
      "ty": 7,
      "x": 350,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42701,
      "e": 40987,
      "ty": 2,
      "x": 338,
      "y": 602
    },
    {
      "t": 42746,
      "e": 41032,
      "ty": 6,
      "x": 340,
      "y": 608,
      "ta": "#strategyButton"
    },
    {
      "t": 42751,
      "e": 41037,
      "ty": 41,
      "x": 767,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 42802,
      "e": 41088,
      "ty": 2,
      "x": 348,
      "y": 614
    },
    {
      "t": 42893,
      "e": 41179,
      "ty": 7,
      "x": 351,
      "y": 589,
      "ta": "#strategyButton"
    },
    {
      "t": 42901,
      "e": 41187,
      "ty": 2,
      "x": 351,
      "y": 589
    },
    {
      "t": 42926,
      "e": 41212,
      "ty": 6,
      "x": 303,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42976,
      "e": 41262,
      "ty": 7,
      "x": 205,
      "y": 461,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43001,
      "e": 41287,
      "ty": 2,
      "x": 201,
      "y": 459
    },
    {
      "t": 43002,
      "e": 41288,
      "ty": 41,
      "x": 11680,
      "y": 40410,
      "ta": "#.strategy > p"
    },
    {
      "t": 43051,
      "e": 41289,
      "ty": 6,
      "x": 204,
      "y": 471,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43101,
      "e": 41339,
      "ty": 2,
      "x": 206,
      "y": 519
    },
    {
      "t": 43201,
      "e": 41439,
      "ty": 2,
      "x": 200,
      "y": 532
    },
    {
      "t": 43251,
      "e": 41489,
      "ty": 41,
      "x": 11118,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43301,
      "e": 41539,
      "ty": 2,
      "x": 192,
      "y": 492
    },
    {
      "t": 43501,
      "e": 41739,
      "ty": 2,
      "x": 188,
      "y": 495
    },
    {
      "t": 43501,
      "e": 41739,
      "ty": 41,
      "x": 10218,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43601,
      "e": 41839,
      "ty": 2,
      "x": 186,
      "y": 499
    },
    {
      "t": 43752,
      "e": 41990,
      "ty": 41,
      "x": 9993,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43785,
      "e": 42023,
      "ty": 3,
      "x": 186,
      "y": 499,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43873,
      "e": 42111,
      "ty": 4,
      "x": 9993,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43873,
      "e": 42111,
      "ty": 5,
      "x": 186,
      "y": 499,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44588,
      "e": 42826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 44588,
      "e": 42826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44643,
      "e": 42881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift starts, ends, etc."
    },
    {
      "t": 45505,
      "e": 43743,
      "ty": 2,
      "x": 193,
      "y": 497
    },
    {
      "t": 45505,
      "e": 43743,
      "ty": 41,
      "x": 10780,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45604,
      "e": 43842,
      "ty": 2,
      "x": 199,
      "y": 494
    },
    {
      "t": 45705,
      "e": 43943,
      "ty": 2,
      "x": 204,
      "y": 493
    },
    {
      "t": 45755,
      "e": 43993,
      "ty": 41,
      "x": 12017,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45860,
      "e": 44098,
      "ty": 3,
      "x": 204,
      "y": 493,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45981,
      "e": 44219,
      "ty": 4,
      "x": 12017,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45982,
      "e": 44220,
      "ty": 5,
      "x": 204,
      "y": 493,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46487,
      "e": 44725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46542,
      "e": 44780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift starts,ends, etc."
    },
    {
      "t": 47105,
      "e": 45343,
      "ty": 2,
      "x": 208,
      "y": 493
    },
    {
      "t": 47133,
      "e": 45371,
      "ty": 7,
      "x": 386,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47134,
      "e": 45372,
      "ty": 6,
      "x": 386,
      "y": 605,
      "ta": "#strategyButton"
    },
    {
      "t": 47149,
      "e": 45387,
      "ty": 7,
      "x": 522,
      "y": 721,
      "ta": "#strategyButton"
    },
    {
      "t": 47204,
      "e": 45442,
      "ty": 2,
      "x": 616,
      "y": 832
    },
    {
      "t": 47255,
      "e": 45493,
      "ty": 41,
      "x": 59566,
      "y": 49531,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47304,
      "e": 45542,
      "ty": 2,
      "x": 616,
      "y": 763
    },
    {
      "t": 47405,
      "e": 45643,
      "ty": 2,
      "x": 498,
      "y": 677
    },
    {
      "t": 47505,
      "e": 45743,
      "ty": 2,
      "x": 480,
      "y": 678
    },
    {
      "t": 47505,
      "e": 45743,
      "ty": 41,
      "x": 43042,
      "y": 40769,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47584,
      "e": 45822,
      "ty": 6,
      "x": 408,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 47604,
      "e": 45842,
      "ty": 2,
      "x": 404,
      "y": 630
    },
    {
      "t": 47704,
      "e": 45942,
      "ty": 2,
      "x": 402,
      "y": 629
    },
    {
      "t": 47755,
      "e": 45993,
      "ty": 41,
      "x": 34627,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 47854,
      "e": 46092,
      "ty": 3,
      "x": 402,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 47855,
      "e": 46093,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis, find 12pm, and movce up from there to see if either a shift starts,ends, etc."
    },
    {
      "t": 47856,
      "e": 46094,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47857,
      "e": 46095,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 47924,
      "e": 46162,
      "ty": 4,
      "x": 34627,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 47935,
      "e": 46173,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 47936,
      "e": 46174,
      "ty": 5,
      "x": 402,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 47943,
      "e": 46181,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48405,
      "e": 46643,
      "ty": 2,
      "x": 527,
      "y": 521
    },
    {
      "t": 48504,
      "e": 46742,
      "ty": 2,
      "x": 730,
      "y": 251
    },
    {
      "t": 48505,
      "e": 46743,
      "ty": 41,
      "x": 24864,
      "y": 14786,
      "ta": "html > body"
    },
    {
      "t": 48604,
      "e": 46842,
      "ty": 2,
      "x": 732,
      "y": 245
    },
    {
      "t": 48754,
      "e": 46992,
      "ty": 41,
      "x": 24932,
      "y": 14421,
      "ta": "html > body"
    },
    {
      "t": 48941,
      "e": 47179,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 49604,
      "e": 47842,
      "ty": 2,
      "x": 700,
      "y": 359
    },
    {
      "t": 49704,
      "e": 47942,
      "ty": 2,
      "x": 744,
      "y": 492
    },
    {
      "t": 49754,
      "e": 47992,
      "ty": 41,
      "x": 25415,
      "y": 29572,
      "ta": "html > body"
    },
    {
      "t": 49804,
      "e": 48042,
      "ty": 2,
      "x": 750,
      "y": 496
    },
    {
      "t": 49904,
      "e": 48142,
      "ty": 2,
      "x": 786,
      "y": 512
    },
    {
      "t": 50004,
      "e": 48242,
      "ty": 2,
      "x": 852,
      "y": 545
    },
    {
      "t": 50004,
      "e": 48242,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50006,
      "e": 48244,
      "ty": 41,
      "x": 9516,
      "y": 10570,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50104,
      "e": 48342,
      "ty": 2,
      "x": 887,
      "y": 533
    },
    {
      "t": 50204,
      "e": 48442,
      "ty": 2,
      "x": 887,
      "y": 525
    },
    {
      "t": 50254,
      "e": 48492,
      "ty": 41,
      "x": 16654,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 50285,
      "e": 48523,
      "ty": 6,
      "x": 880,
      "y": 518,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50304,
      "e": 48542,
      "ty": 2,
      "x": 878,
      "y": 513
    },
    {
      "t": 50404,
      "e": 48642,
      "ty": 2,
      "x": 876,
      "y": 509
    },
    {
      "t": 50445,
      "e": 48683,
      "ty": 3,
      "x": 876,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50446,
      "e": 48684,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50504,
      "e": 48742,
      "ty": 2,
      "x": 876,
      "y": 508
    },
    {
      "t": 50504,
      "e": 48742,
      "ty": 41,
      "x": 14707,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50524,
      "e": 48762,
      "ty": 4,
      "x": 14707,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50524,
      "e": 48762,
      "ty": 5,
      "x": 876,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51047,
      "e": 49285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 51047,
      "e": 49285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51151,
      "e": 49389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 51175,
      "e": 49413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 51176,
      "e": 49414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51262,
      "e": 49500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 51590,
      "e": 49828,
      "ty": 7,
      "x": 795,
      "y": 507,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51604,
      "e": 49842,
      "ty": 2,
      "x": 756,
      "y": 507
    },
    {
      "t": 51703,
      "e": 49941,
      "ty": 2,
      "x": 731,
      "y": 612
    },
    {
      "t": 51754,
      "e": 49992,
      "ty": 41,
      "x": 27033,
      "y": 39552,
      "ta": "html > body"
    },
    {
      "t": 51804,
      "e": 50042,
      "ty": 2,
      "x": 811,
      "y": 631
    },
    {
      "t": 51837,
      "e": 50075,
      "ty": 6,
      "x": 850,
      "y": 597,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51854,
      "e": 50092,
      "ty": 7,
      "x": 875,
      "y": 591,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51904,
      "e": 50142,
      "ty": 2,
      "x": 932,
      "y": 581
    },
    {
      "t": 52004,
      "e": 50242,
      "ty": 2,
      "x": 926,
      "y": 575
    },
    {
      "t": 52004,
      "e": 50242,
      "ty": 41,
      "x": 25521,
      "y": 63194,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 52104,
      "e": 50342,
      "ty": 2,
      "x": 910,
      "y": 585
    },
    {
      "t": 52155,
      "e": 50393,
      "ty": 6,
      "x": 901,
      "y": 596,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52204,
      "e": 50442,
      "ty": 2,
      "x": 894,
      "y": 607
    },
    {
      "t": 52254,
      "e": 50492,
      "ty": 41,
      "x": 18384,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52304,
      "e": 50542,
      "ty": 2,
      "x": 893,
      "y": 607
    },
    {
      "t": 52398,
      "e": 50636,
      "ty": 3,
      "x": 893,
      "y": 607,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52399,
      "e": 50637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 52400,
      "e": 50638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52400,
      "e": 50638,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52493,
      "e": 50731,
      "ty": 4,
      "x": 18384,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52493,
      "e": 50731,
      "ty": 5,
      "x": 893,
      "y": 607,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53551,
      "e": 51789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 53671,
      "e": 51909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 53672,
      "e": 51910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53750,
      "e": 51988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 53943,
      "e": 52181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 53943,
      "e": 52181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54086,
      "e": 52324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 54199,
      "e": 52437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 54200,
      "e": 52438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54342,
      "e": 52580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 54342,
      "e": 52580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 54973,
      "e": 53211,
      "ty": 7,
      "x": 904,
      "y": 616,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54989,
      "e": 53227,
      "ty": 6,
      "x": 916,
      "y": 623,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55004,
      "e": 53242,
      "ty": 2,
      "x": 916,
      "y": 623
    },
    {
      "t": 55004,
      "e": 53242,
      "ty": 41,
      "x": 10348,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55104,
      "e": 53342,
      "ty": 2,
      "x": 968,
      "y": 638
    },
    {
      "t": 55140,
      "e": 53378,
      "ty": 7,
      "x": 995,
      "y": 661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55204,
      "e": 53442,
      "ty": 2,
      "x": 995,
      "y": 667
    },
    {
      "t": 55254,
      "e": 53492,
      "ty": 41,
      "x": 33990,
      "y": 40099,
      "ta": "html > body"
    },
    {
      "t": 55374,
      "e": 53612,
      "ty": 6,
      "x": 971,
      "y": 651,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55404,
      "e": 53642,
      "ty": 2,
      "x": 961,
      "y": 643
    },
    {
      "t": 55504,
      "e": 53742,
      "ty": 2,
      "x": 954,
      "y": 637
    },
    {
      "t": 55504,
      "e": 53742,
      "ty": 41,
      "x": 29932,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56237,
      "e": 54475,
      "ty": 3,
      "x": 954,
      "y": 637,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56239,
      "e": 54477,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 56239,
      "e": 54477,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56239,
      "e": 54477,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56324,
      "e": 54562,
      "ty": 4,
      "x": 29932,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56325,
      "e": 54563,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56325,
      "e": 54563,
      "ty": 5,
      "x": 954,
      "y": 637,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56325,
      "e": 54563,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 57340,
      "e": 55578,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 58004,
      "e": 56242,
      "ty": 2,
      "x": 951,
      "y": 558
    },
    {
      "t": 58004,
      "e": 56242,
      "ty": 41,
      "x": 30752,
      "y": 33626,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58104,
      "e": 56342,
      "ty": 2,
      "x": 915,
      "y": 421
    },
    {
      "t": 58191,
      "e": 56429,
      "ty": 6,
      "x": 838,
      "y": 218,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 58204,
      "e": 56442,
      "ty": 2,
      "x": 838,
      "y": 218
    },
    {
      "t": 58254,
      "e": 56492,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 58476,
      "e": 56714,
      "ty": 7,
      "x": 840,
      "y": 212,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 58504,
      "e": 56742,
      "ty": 2,
      "x": 843,
      "y": 205
    },
    {
      "t": 58504,
      "e": 56742,
      "ty": 41,
      "x": 16434,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 58604,
      "e": 56842,
      "ty": 2,
      "x": 843,
      "y": 188
    },
    {
      "t": 58704,
      "e": 56942,
      "ty": 2,
      "x": 843,
      "y": 185
    },
    {
      "t": 58755,
      "e": 56993,
      "ty": 41,
      "x": 17669,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 58804,
      "e": 57042,
      "ty": 2,
      "x": 840,
      "y": 184
    },
    {
      "t": 58806,
      "e": 57043,
      "ty": 6,
      "x": 838,
      "y": 182,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 58904,
      "e": 57141,
      "ty": 2,
      "x": 831,
      "y": 181
    },
    {
      "t": 59004,
      "e": 57241,
      "ty": 2,
      "x": 829,
      "y": 181
    },
    {
      "t": 59004,
      "e": 57241,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59254,
      "e": 57491,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59304,
      "e": 57541,
      "ty": 2,
      "x": 829,
      "y": 182
    },
    {
      "t": 59504,
      "e": 57741,
      "ty": 2,
      "x": 831,
      "y": 186
    },
    {
      "t": 59505,
      "e": 57742,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59525,
      "e": 57762,
      "ty": 7,
      "x": 831,
      "y": 192,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59605,
      "e": 57842,
      "ty": 2,
      "x": 831,
      "y": 194
    },
    {
      "t": 59704,
      "e": 57941,
      "ty": 2,
      "x": 831,
      "y": 200
    },
    {
      "t": 59755,
      "e": 57992,
      "ty": 41,
      "x": 7294,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 59804,
      "e": 58041,
      "ty": 2,
      "x": 831,
      "y": 205
    },
    {
      "t": 59932,
      "e": 58169,
      "ty": 3,
      "x": 831,
      "y": 205,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 60036,
      "e": 58273,
      "ty": 4,
      "x": 7294,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 60036,
      "e": 58273,
      "ty": 5,
      "x": 831,
      "y": 205,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 60036,
      "e": 58273,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60036,
      "e": 58273,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 60180,
      "e": 58417,
      "ty": 6,
      "x": 833,
      "y": 208,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60204,
      "e": 58441,
      "ty": 2,
      "x": 836,
      "y": 212
    },
    {
      "t": 60255,
      "e": 58492,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60304,
      "e": 58541,
      "ty": 2,
      "x": 839,
      "y": 218
    },
    {
      "t": 60309,
      "e": 58546,
      "ty": 7,
      "x": 841,
      "y": 223,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60404,
      "e": 58641,
      "ty": 2,
      "x": 858,
      "y": 292
    },
    {
      "t": 60504,
      "e": 58741,
      "ty": 2,
      "x": 857,
      "y": 368
    },
    {
      "t": 60504,
      "e": 58741,
      "ty": 41,
      "x": 41647,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 60804,
      "e": 59041,
      "ty": 2,
      "x": 856,
      "y": 369
    },
    {
      "t": 60904,
      "e": 59141,
      "ty": 2,
      "x": 846,
      "y": 362
    },
    {
      "t": 61004,
      "e": 59241,
      "ty": 2,
      "x": 842,
      "y": 362
    },
    {
      "t": 61004,
      "e": 59241,
      "ty": 41,
      "x": 24088,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 62496,
      "e": 60733,
      "ty": 6,
      "x": 838,
      "y": 385,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 62504,
      "e": 60741,
      "ty": 2,
      "x": 838,
      "y": 385
    },
    {
      "t": 62504,
      "e": 60741,
      "ty": 41,
      "x": 58367,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 62579,
      "e": 60816,
      "ty": 7,
      "x": 838,
      "y": 397,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 62604,
      "e": 60841,
      "ty": 2,
      "x": 838,
      "y": 401
    },
    {
      "t": 62628,
      "e": 60865,
      "ty": 6,
      "x": 838,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 62661,
      "e": 60898,
      "ty": 7,
      "x": 838,
      "y": 429,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 62696,
      "e": 60933,
      "ty": 6,
      "x": 838,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 62704,
      "e": 60941,
      "ty": 2,
      "x": 838,
      "y": 440
    },
    {
      "t": 62755,
      "e": 60992,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 62805,
      "e": 61042,
      "ty": 2,
      "x": 838,
      "y": 449
    },
    {
      "t": 62829,
      "e": 61066,
      "ty": 7,
      "x": 838,
      "y": 455,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 62904,
      "e": 61141,
      "ty": 2,
      "x": 838,
      "y": 462
    },
    {
      "t": 63005,
      "e": 61242,
      "ty": 41,
      "x": 3934,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 63304,
      "e": 61541,
      "ty": 2,
      "x": 835,
      "y": 463
    },
    {
      "t": 63505,
      "e": 61742,
      "ty": 41,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 65004,
      "e": 63241,
      "ty": 2,
      "x": 834,
      "y": 463
    },
    {
      "t": 65005,
      "e": 63242,
      "ty": 41,
      "x": 2985,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 65098,
      "e": 63335,
      "ty": 6,
      "x": 826,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65104,
      "e": 63341,
      "ty": 2,
      "x": 826,
      "y": 451
    },
    {
      "t": 65114,
      "e": 63351,
      "ty": 7,
      "x": 822,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65205,
      "e": 63442,
      "ty": 2,
      "x": 822,
      "y": 448
    },
    {
      "t": 65255,
      "e": 63492,
      "ty": 41,
      "x": 518,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 65404,
      "e": 63641,
      "ty": 2,
      "x": 824,
      "y": 444
    },
    {
      "t": 65493,
      "e": 63730,
      "ty": 3,
      "x": 825,
      "y": 443,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 65495,
      "e": 63732,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 65505,
      "e": 63742,
      "ty": 2,
      "x": 825,
      "y": 443
    },
    {
      "t": 65505,
      "e": 63742,
      "ty": 41,
      "x": 3211,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 65628,
      "e": 63865,
      "ty": 4,
      "x": 3211,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 65629,
      "e": 63866,
      "ty": 5,
      "x": 825,
      "y": 443,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 65629,
      "e": 63866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65629,
      "e": 63866,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 65668,
      "e": 63905,
      "ty": 6,
      "x": 827,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65704,
      "e": 63941,
      "ty": 2,
      "x": 827,
      "y": 443
    },
    {
      "t": 65755,
      "e": 63992,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65905,
      "e": 64142,
      "ty": 2,
      "x": 828,
      "y": 443
    },
    {
      "t": 65965,
      "e": 64202,
      "ty": 7,
      "x": 838,
      "y": 459,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 66004,
      "e": 64241,
      "ty": 2,
      "x": 863,
      "y": 528
    },
    {
      "t": 66005,
      "e": 64242,
      "ty": 41,
      "x": 41275,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 66105,
      "e": 64342,
      "ty": 2,
      "x": 922,
      "y": 687
    },
    {
      "t": 66205,
      "e": 64442,
      "ty": 2,
      "x": 922,
      "y": 688
    },
    {
      "t": 66254,
      "e": 64491,
      "ty": 41,
      "x": 23869,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 66305,
      "e": 64542,
      "ty": 2,
      "x": 922,
      "y": 685
    },
    {
      "t": 66404,
      "e": 64641,
      "ty": 2,
      "x": 920,
      "y": 667
    },
    {
      "t": 66505,
      "e": 64742,
      "ty": 41,
      "x": 23395,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 66604,
      "e": 64841,
      "ty": 2,
      "x": 914,
      "y": 664
    },
    {
      "t": 66705,
      "e": 64942,
      "ty": 2,
      "x": 908,
      "y": 662
    },
    {
      "t": 66755,
      "e": 64992,
      "ty": 41,
      "x": 20072,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 66805,
      "e": 65042,
      "ty": 2,
      "x": 905,
      "y": 660
    },
    {
      "t": 66904,
      "e": 65141,
      "ty": 2,
      "x": 886,
      "y": 676
    },
    {
      "t": 67005,
      "e": 65242,
      "ty": 2,
      "x": 874,
      "y": 685
    },
    {
      "t": 67005,
      "e": 65242,
      "ty": 41,
      "x": 13196,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 67104,
      "e": 65341,
      "ty": 2,
      "x": 873,
      "y": 685
    },
    {
      "t": 67205,
      "e": 65442,
      "ty": 2,
      "x": 873,
      "y": 703
    },
    {
      "t": 67254,
      "e": 65491,
      "ty": 41,
      "x": 21521,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67405,
      "e": 65642,
      "ty": 2,
      "x": 891,
      "y": 710
    },
    {
      "t": 67504,
      "e": 65741,
      "ty": 2,
      "x": 892,
      "y": 710
    },
    {
      "t": 67505,
      "e": 65742,
      "ty": 41,
      "x": 29449,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 68404,
      "e": 66641,
      "ty": 2,
      "x": 881,
      "y": 745
    },
    {
      "t": 68504,
      "e": 66741,
      "ty": 2,
      "x": 867,
      "y": 753
    },
    {
      "t": 68505,
      "e": 66742,
      "ty": 41,
      "x": 26901,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 68604,
      "e": 66841,
      "ty": 2,
      "x": 864,
      "y": 755
    },
    {
      "t": 68705,
      "e": 66942,
      "ty": 2,
      "x": 862,
      "y": 767
    },
    {
      "t": 68755,
      "e": 66992,
      "ty": 41,
      "x": 23360,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 68805,
      "e": 67042,
      "ty": 2,
      "x": 861,
      "y": 770
    },
    {
      "t": 68904,
      "e": 67141,
      "ty": 2,
      "x": 852,
      "y": 781
    },
    {
      "t": 69004,
      "e": 67241,
      "ty": 2,
      "x": 849,
      "y": 788
    },
    {
      "t": 69005,
      "e": 67242,
      "ty": 41,
      "x": 19430,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 69952,
      "e": 68189,
      "ty": 6,
      "x": 830,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 69968,
      "e": 68205,
      "ty": 7,
      "x": 812,
      "y": 748,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 70005,
      "e": 68242,
      "ty": 2,
      "x": 796,
      "y": 703
    },
    {
      "t": 70005,
      "e": 68242,
      "ty": 41,
      "x": 27136,
      "y": 42290,
      "ta": "html > body"
    },
    {
      "t": 70104,
      "e": 68341,
      "ty": 2,
      "x": 823,
      "y": 600
    },
    {
      "t": 70204,
      "e": 68441,
      "ty": 2,
      "x": 825,
      "y": 599
    },
    {
      "t": 70255,
      "e": 68492,
      "ty": 41,
      "x": 3934,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 70304,
      "e": 68541,
      "ty": 2,
      "x": 840,
      "y": 614
    },
    {
      "t": 70404,
      "e": 68641,
      "ty": 2,
      "x": 865,
      "y": 659
    },
    {
      "t": 70504,
      "e": 68741,
      "ty": 2,
      "x": 866,
      "y": 659
    },
    {
      "t": 70505,
      "e": 68742,
      "ty": 41,
      "x": 11232,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 70905,
      "e": 69142,
      "ty": 2,
      "x": 845,
      "y": 691
    },
    {
      "t": 71005,
      "e": 69242,
      "ty": 41,
      "x": 5595,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 71205,
      "e": 69442,
      "ty": 2,
      "x": 845,
      "y": 692
    },
    {
      "t": 71256,
      "e": 69443,
      "ty": 41,
      "x": 5595,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 71305,
      "e": 69492,
      "ty": 2,
      "x": 842,
      "y": 709
    },
    {
      "t": 71404,
      "e": 69591,
      "ty": 2,
      "x": 840,
      "y": 723
    },
    {
      "t": 71505,
      "e": 69692,
      "ty": 41,
      "x": 4409,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 71537,
      "e": 69724,
      "ty": 6,
      "x": 836,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 71586,
      "e": 69773,
      "ty": 7,
      "x": 827,
      "y": 741,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 71604,
      "e": 69791,
      "ty": 2,
      "x": 826,
      "y": 742
    },
    {
      "t": 71755,
      "e": 69942,
      "ty": 41,
      "x": 2562,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 72005,
      "e": 70192,
      "ty": 2,
      "x": 824,
      "y": 739
    },
    {
      "t": 72006,
      "e": 70193,
      "ty": 41,
      "x": 1443,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 72087,
      "e": 70274,
      "ty": 6,
      "x": 829,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 72104,
      "e": 70291,
      "ty": 2,
      "x": 829,
      "y": 706
    },
    {
      "t": 72204,
      "e": 70391,
      "ty": 2,
      "x": 829,
      "y": 704
    },
    {
      "t": 72255,
      "e": 70442,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 73120,
      "e": 71307,
      "ty": 7,
      "x": 828,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 73155,
      "e": 71342,
      "ty": 6,
      "x": 832,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73171,
      "e": 71358,
      "ty": 7,
      "x": 835,
      "y": 744,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73205,
      "e": 71392,
      "ty": 2,
      "x": 838,
      "y": 752
    },
    {
      "t": 73255,
      "e": 71442,
      "ty": 41,
      "x": 9785,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 73305,
      "e": 71492,
      "ty": 2,
      "x": 838,
      "y": 753
    },
    {
      "t": 73389,
      "e": 71576,
      "ty": 6,
      "x": 838,
      "y": 755,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73405,
      "e": 71592,
      "ty": 2,
      "x": 838,
      "y": 758
    },
    {
      "t": 73504,
      "e": 71691,
      "ty": 2,
      "x": 837,
      "y": 763
    },
    {
      "t": 73505,
      "e": 71692,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 74004,
      "e": 72191,
      "ty": 2,
      "x": 836,
      "y": 764
    },
    {
      "t": 74004,
      "e": 72191,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 75493,
      "e": 73680,
      "ty": 7,
      "x": 833,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 75504,
      "e": 73691,
      "ty": 2,
      "x": 833,
      "y": 753
    },
    {
      "t": 75504,
      "e": 73691,
      "ty": 41,
      "x": 6833,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 75604,
      "e": 73791,
      "ty": 2,
      "x": 805,
      "y": 596
    },
    {
      "t": 75704,
      "e": 73891,
      "ty": 2,
      "x": 805,
      "y": 601
    },
    {
      "t": 75754,
      "e": 73941,
      "ty": 41,
      "x": 27653,
      "y": 37909,
      "ta": "html > body"
    },
    {
      "t": 75804,
      "e": 73991,
      "ty": 2,
      "x": 828,
      "y": 659
    },
    {
      "t": 75904,
      "e": 74091,
      "ty": 2,
      "x": 842,
      "y": 663
    },
    {
      "t": 76004,
      "e": 74191,
      "ty": 2,
      "x": 843,
      "y": 663
    },
    {
      "t": 76004,
      "e": 74191,
      "ty": 41,
      "x": 5121,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 76104,
      "e": 74291,
      "ty": 2,
      "x": 838,
      "y": 656
    },
    {
      "t": 76107,
      "e": 74294,
      "ty": 6,
      "x": 836,
      "y": 654,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76204,
      "e": 74391,
      "ty": 2,
      "x": 836,
      "y": 654
    },
    {
      "t": 76254,
      "e": 74441,
      "ty": 41,
      "x": 48284,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76309,
      "e": 74496,
      "ty": 3,
      "x": 836,
      "y": 654,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76310,
      "e": 74497,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 76311,
      "e": 74498,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76412,
      "e": 74599,
      "ty": 4,
      "x": 48284,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76412,
      "e": 74599,
      "ty": 5,
      "x": 836,
      "y": 654,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76412,
      "e": 74599,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 76690,
      "e": 74877,
      "ty": 7,
      "x": 847,
      "y": 658,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76704,
      "e": 74891,
      "ty": 2,
      "x": 847,
      "y": 658
    },
    {
      "t": 76753,
      "e": 74940,
      "ty": 41,
      "x": 18885,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 76804,
      "e": 74991,
      "ty": 2,
      "x": 933,
      "y": 765
    },
    {
      "t": 76904,
      "e": 75091,
      "ty": 2,
      "x": 933,
      "y": 771
    },
    {
      "t": 77003,
      "e": 75190,
      "ty": 2,
      "x": 914,
      "y": 800
    },
    {
      "t": 77004,
      "e": 75191,
      "ty": 41,
      "x": 21971,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 77104,
      "e": 75291,
      "ty": 2,
      "x": 871,
      "y": 858
    },
    {
      "t": 77174,
      "e": 75361,
      "ty": 6,
      "x": 833,
      "y": 886,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77190,
      "e": 75377,
      "ty": 7,
      "x": 823,
      "y": 890,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77204,
      "e": 75391,
      "ty": 2,
      "x": 823,
      "y": 890
    },
    {
      "t": 77254,
      "e": 75441,
      "ty": 41,
      "x": 27274,
      "y": 54216,
      "ta": "html > body"
    },
    {
      "t": 77303,
      "e": 75490,
      "ty": 2,
      "x": 799,
      "y": 900
    },
    {
      "t": 77404,
      "e": 75591,
      "ty": 2,
      "x": 810,
      "y": 898
    },
    {
      "t": 77504,
      "e": 75691,
      "ty": 2,
      "x": 824,
      "y": 900
    },
    {
      "t": 77505,
      "e": 75692,
      "ty": 41,
      "x": 2085,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77604,
      "e": 75791,
      "ty": 2,
      "x": 826,
      "y": 902
    },
    {
      "t": 77693,
      "e": 75880,
      "ty": 6,
      "x": 828,
      "y": 905,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77704,
      "e": 75891,
      "ty": 2,
      "x": 828,
      "y": 905
    },
    {
      "t": 77754,
      "e": 75941,
      "ty": 41,
      "x": 7955,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77804,
      "e": 75991,
      "ty": 2,
      "x": 830,
      "y": 907
    },
    {
      "t": 77869,
      "e": 76056,
      "ty": 3,
      "x": 830,
      "y": 907,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77870,
      "e": 76057,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77870,
      "e": 76057,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77903,
      "e": 76090,
      "ty": 2,
      "x": 831,
      "y": 908
    },
    {
      "t": 77964,
      "e": 76151,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77964,
      "e": 76151,
      "ty": 5,
      "x": 832,
      "y": 908,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77964,
      "e": 76151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 78004,
      "e": 76191,
      "ty": 2,
      "x": 832,
      "y": 908
    },
    {
      "t": 78004,
      "e": 76191,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 78074,
      "e": 76261,
      "ty": 7,
      "x": 842,
      "y": 925,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 78104,
      "e": 76291,
      "ty": 2,
      "x": 849,
      "y": 936
    },
    {
      "t": 78126,
      "e": 76313,
      "ty": 6,
      "x": 871,
      "y": 957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78204,
      "e": 76391,
      "ty": 2,
      "x": 875,
      "y": 963
    },
    {
      "t": 78254,
      "e": 76441,
      "ty": 41,
      "x": 24005,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78304,
      "e": 76491,
      "ty": 2,
      "x": 876,
      "y": 963
    },
    {
      "t": 78389,
      "e": 76576,
      "ty": 3,
      "x": 876,
      "y": 963,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78390,
      "e": 76577,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 78390,
      "e": 76577,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78484,
      "e": 76671,
      "ty": 4,
      "x": 24521,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78484,
      "e": 76671,
      "ty": 5,
      "x": 877,
      "y": 963,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78490,
      "e": 76677,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78491,
      "e": 76678,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 78493,
      "e": 76680,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 78504,
      "e": 76691,
      "ty": 2,
      "x": 877,
      "y": 963
    },
    {
      "t": 78504,
      "e": 76691,
      "ty": 41,
      "x": 29926,
      "y": 58111,
      "ta": "html > body"
    },
    {
      "t": 78803,
      "e": 76990,
      "ty": 2,
      "x": 920,
      "y": 944
    },
    {
      "t": 78904,
      "e": 77091,
      "ty": 2,
      "x": 1265,
      "y": 592
    },
    {
      "t": 79004,
      "e": 77191,
      "ty": 2,
      "x": 938,
      "y": 272
    },
    {
      "t": 79004,
      "e": 77191,
      "ty": 41,
      "x": 32027,
      "y": 16064,
      "ta": "html > body"
    },
    {
      "t": 79104,
      "e": 77291,
      "ty": 2,
      "x": 766,
      "y": 205
    },
    {
      "t": 79203,
      "e": 77390,
      "ty": 2,
      "x": 756,
      "y": 206
    },
    {
      "t": 79254,
      "e": 77441,
      "ty": 41,
      "x": 25621,
      "y": 12474,
      "ta": "html > body"
    },
    {
      "t": 79304,
      "e": 77491,
      "ty": 2,
      "x": 752,
      "y": 216
    },
    {
      "t": 79504,
      "e": 77691,
      "ty": 41,
      "x": 25621,
      "y": 12656,
      "ta": "html > body"
    },
    {
      "t": 79838,
      "e": 78025,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 80504,
      "e": 78691,
      "ty": 2,
      "x": 752,
      "y": 218
    },
    {
      "t": 80504,
      "e": 78691,
      "ty": 41,
      "x": 22559,
      "y": 7780,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80604,
      "e": 78791,
      "ty": 2,
      "x": 838,
      "y": 508
    },
    {
      "t": 80704,
      "e": 78891,
      "ty": 2,
      "x": 857,
      "y": 690
    },
    {
      "t": 80754,
      "e": 78941,
      "ty": 41,
      "x": 27724,
      "y": 43592,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80804,
      "e": 78991,
      "ty": 2,
      "x": 855,
      "y": 690
    },
    {
      "t": 80904,
      "e": 79091,
      "ty": 2,
      "x": 854,
      "y": 693
    },
    {
      "t": 81004,
      "e": 79191,
      "ty": 41,
      "x": 27577,
      "y": 45347,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 81104,
      "e": 79291,
      "ty": 2,
      "x": 854,
      "y": 694
    },
    {
      "t": 81204,
      "e": 79391,
      "ty": 2,
      "x": 854,
      "y": 738
    },
    {
      "t": 81254,
      "e": 79441,
      "ty": 41,
      "x": 27774,
      "y": 40374,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 81304,
      "e": 79491,
      "ty": 2,
      "x": 858,
      "y": 780
    },
    {
      "t": 81604,
      "e": 79791,
      "ty": 2,
      "x": 866,
      "y": 781
    },
    {
      "t": 81704,
      "e": 79891,
      "ty": 2,
      "x": 874,
      "y": 779
    },
    {
      "t": 81754,
      "e": 79941,
      "ty": 41,
      "x": 28659,
      "y": 39203,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 81804,
      "e": 79991,
      "ty": 2,
      "x": 894,
      "y": 802
    },
    {
      "t": 81904,
      "e": 80091,
      "ty": 2,
      "x": 981,
      "y": 867
    },
    {
      "t": 82004,
      "e": 80191,
      "ty": 2,
      "x": 983,
      "y": 876
    },
    {
      "t": 82004,
      "e": 80191,
      "ty": 41,
      "x": 33923,
      "y": 57830,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 82096,
      "e": 80283,
      "ty": 6,
      "x": 967,
      "y": 985,
      "ta": "#start"
    },
    {
      "t": 82104,
      "e": 80291,
      "ty": 2,
      "x": 967,
      "y": 985
    },
    {
      "t": 82204,
      "e": 80391,
      "ty": 2,
      "x": 965,
      "y": 987
    },
    {
      "t": 82254,
      "e": 80441,
      "ty": 41,
      "x": 30309,
      "y": 12920,
      "ta": "#start"
    },
    {
      "t": 82304,
      "e": 80491,
      "ty": 2,
      "x": 965,
      "y": 984
    },
    {
      "t": 82504,
      "e": 80691,
      "ty": 2,
      "x": 965,
      "y": 981
    },
    {
      "t": 82505,
      "e": 80692,
      "ty": 41,
      "x": 30309,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 82696,
      "e": 80883,
      "ty": 7,
      "x": 965,
      "y": 976,
      "ta": "#start"
    },
    {
      "t": 82704,
      "e": 80891,
      "ty": 2,
      "x": 965,
      "y": 976
    },
    {
      "t": 82754,
      "e": 80941,
      "ty": 41,
      "x": 32988,
      "y": 65056,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 82804,
      "e": 80991,
      "ty": 2,
      "x": 964,
      "y": 971
    },
    {
      "t": 83004,
      "e": 81191,
      "ty": 2,
      "x": 963,
      "y": 967
    },
    {
      "t": 83005,
      "e": 81192,
      "ty": 41,
      "x": 32939,
      "y": 64751,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 83204,
      "e": 81391,
      "ty": 2,
      "x": 963,
      "y": 968
    },
    {
      "t": 83213,
      "e": 81400,
      "ty": 6,
      "x": 963,
      "y": 977,
      "ta": "#start"
    },
    {
      "t": 83254,
      "e": 81441,
      "ty": 41,
      "x": 30856,
      "y": 34122,
      "ta": "#start"
    },
    {
      "t": 83304,
      "e": 81491,
      "ty": 2,
      "x": 967,
      "y": 1002
    },
    {
      "t": 83404,
      "e": 81591,
      "ty": 2,
      "x": 970,
      "y": 998
    },
    {
      "t": 83504,
      "e": 81691,
      "ty": 2,
      "x": 970,
      "y": 989
    },
    {
      "t": 83504,
      "e": 81691,
      "ty": 41,
      "x": 33040,
      "y": 22557,
      "ta": "#start"
    },
    {
      "t": 83754,
      "e": 81941,
      "ty": 41,
      "x": 32494,
      "y": 34122,
      "ta": "#start"
    },
    {
      "t": 83804,
      "e": 81991,
      "ty": 2,
      "x": 969,
      "y": 1003
    },
    {
      "t": 83932,
      "e": 82119,
      "ty": 3,
      "x": 969,
      "y": 1003,
      "ta": "#start"
    },
    {
      "t": 83932,
      "e": 82119,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 84004,
      "e": 82191,
      "ty": 41,
      "x": 32494,
      "y": 49542,
      "ta": "#start"
    },
    {
      "t": 84043,
      "e": 82230,
      "ty": 4,
      "x": 32494,
      "y": 49542,
      "ta": "#start"
    },
    {
      "t": 84045,
      "e": 82232,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 84046,
      "e": 82233,
      "ty": 5,
      "x": 969,
      "y": 1003,
      "ta": "#start"
    },
    {
      "t": 84047,
      "e": 82234,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 84404,
      "e": 82591,
      "ty": 2,
      "x": 1138,
      "y": 921
    },
    {
      "t": 84504,
      "e": 82691,
      "ty": 2,
      "x": 1654,
      "y": 697
    },
    {
      "t": 84505,
      "e": 82692,
      "ty": 41,
      "x": 56684,
      "y": 41925,
      "ta": "html > body"
    },
    {
      "t": 84604,
      "e": 82791,
      "ty": 2,
      "x": 1596,
      "y": 533
    },
    {
      "t": 84704,
      "e": 82891,
      "ty": 2,
      "x": 1535,
      "y": 465
    },
    {
      "t": 84754,
      "e": 82941,
      "ty": 41,
      "x": 52586,
      "y": 27808,
      "ta": "html > body"
    },
    {
      "t": 85004,
      "e": 83191,
      "ty": 2,
      "x": 1532,
      "y": 466
    },
    {
      "t": 85005,
      "e": 83192,
      "ty": 41,
      "x": 52483,
      "y": 27869,
      "ta": "html > body"
    },
    {
      "t": 85090,
      "e": 83277,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 85833,
      "e": 84020,
      "ty": 2,
      "x": 1530,
      "y": 467
    },
    {
      "t": 85833,
      "e": 84020,
      "ty": 41,
      "x": 65335,
      "y": 32748,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 86531,
      "e": 84718,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":3,\"id\":2447,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2446}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"1\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2463}},{\"nodeType\":1,\"id\":2465,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"3\",\"parentNode\":{\"id\":2466}},{\"nodeType\":1,\"id\":2468,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"4\",\"parentNode\":{\"id\":2469}},{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2472,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"5\",\"parentNode\":{\"id\":2472}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"6\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2479,\"textContent\":\"7\",\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2482,\"textContent\":\"8\",\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2485,\"textContent\":\"9\",\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2439}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2488,\"textContent\":\"10\",\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2441}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2491,\"textContent\":\"11\",\"parentNode\":{\"id\":2490}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2443}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2494,\"textContent\":\"12\",\"parentNode\":{\"id\":2493}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2445}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2448}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2449}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2450}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2451}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2452}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2453}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2454}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2455}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2456}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2457}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2458}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2459}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2578},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2580,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2581,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2580},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2582},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2584,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2549}},{\"nodeType\":1,\"id\":2585,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2584},\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"A \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"B \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"C \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"D \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"E \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"F \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"G \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"H \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"I \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"J \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"K \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"L \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2598,\"textContent\":\"M \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2599,\"textContent\":\"N \",\"parentNode\":{\"id\":2577}},{\"nodeType\":3,\"id\":2600,\"textContent\":\"O \",\"parentNode\":{\"id\":2579}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"P \",\"parentNode\":{\"id\":2581}},{\"nodeType\":3,\"id\":2602,\"textContent\":\"Z \",\"parentNode\":{\"id\":2583}},{\"nodeType\":3,\"id\":2603,\"textContent\":\"X \",\"parentNode\":{\"id\":2585}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2446},{\"id\":2447},{\"id\":2422},{\"id\":2460},{\"id\":2461},{\"id\":2423},{\"id\":2462},{\"id\":2424},{\"id\":2463},{\"id\":2464},{\"id\":2425},{\"id\":2465},{\"id\":2426},{\"id\":2466},{\"id\":2467},{\"id\":2427},{\"id\":2468},{\"id\":2428},{\"id\":2469},{\"id\":2470},{\"id\":2429},{\"id\":2471},{\"id\":2430},{\"id\":2472},{\"id\":2473},{\"id\":2431},{\"id\":2474},{\"id\":2432},{\"id\":2475},{\"id\":2476},{\"id\":2433},{\"id\":2477},{\"id\":2434},{\"id\":2478},{\"id\":2479},{\"id\":2435},{\"id\":2480},{\"id\":2436},{\"id\":2481},{\"id\":2482},{\"id\":2437},{\"id\":2483},{\"id\":2438},{\"id\":2484},{\"id\":2485},{\"id\":2439},{\"id\":2486},{\"id\":2440},{\"id\":2487},{\"id\":2488},{\"id\":2441},{\"id\":2489},{\"id\":2442},{\"id\":2490},{\"id\":2491},{\"id\":2443},{\"id\":2492},{\"id\":2444},{\"id\":2493},{\"id\":2494},{\"id\":2445},{\"id\":2495},{\"id\":2313},{\"id\":2448},{\"id\":2496},{\"id\":2449},{\"id\":2497},{\"id\":2450},{\"id\":2498},{\"id\":2451},{\"id\":2499},{\"id\":2452},{\"id\":2500},{\"id\":2453},{\"id\":2501},{\"id\":2454},{\"id\":2502},{\"id\":2455},{\"id\":2503},{\"id\":2456},{\"id\":2504},{\"id\":2457},{\"id\":2505},{\"id\":2458},{\"id\":2506},{\"id\":2459},{\"id\":2507},{\"id\":2314},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2315},{\"id\":2532},{\"id\":2550},{\"id\":2551},{\"id\":2586},{\"id\":2533},{\"id\":2552},{\"id\":2553},{\"id\":2587},{\"id\":2534},{\"id\":2554},{\"id\":2555},{\"id\":2588},{\"id\":2535},{\"id\":2556},{\"id\":2557},{\"id\":2589},{\"id\":2536},{\"id\":2558},{\"id\":2559},{\"id\":2590},{\"id\":2537},{\"id\":2560},{\"id\":2561},{\"id\":2591},{\"id\":2538},{\"id\":2562},{\"id\":2563},{\"id\":2592},{\"id\":2539},{\"id\":2564},{\"id\":2565},{\"id\":2593},{\"id\":2540},{\"id\":2566},{\"id\":2567},{\"id\":2594},{\"id\":2541},{\"id\":2568},{\"id\":2569},{\"id\":2595},{\"id\":2542},{\"id\":2570},{\"id\":2571},{\"id\":2596},{\"id\":2543},{\"id\":2572},{\"id\":2573},{\"id\":2597},{\"id\":2544},{\"id\":2574},{\"id\":2575},{\"id\":2598},{\"id\":2545},{\"id\":2576},{\"id\":2577},{\"id\":2599},{\"id\":2546},{\"id\":2578},{\"id\":2579},{\"id\":2600},{\"id\":2547},{\"id\":2580},{\"id\":2581},{\"id\":2601},{\"id\":2548},{\"id\":2582},{\"id\":2583},{\"id\":2602},{\"id\":2549},{\"id\":2584},{\"id\":2585},{\"id\":2603},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 43332, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 43335, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 8062, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 52484, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 16042, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 69537, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 4870, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 75503, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 11896, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 88402, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 19535, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 109153, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-10 AM-11 AM-C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:866,y:911,t:1527188705975};\\\", \\\"{x:863,y:908,t:1527188705999};\\\", \\\"{x:861,y:905,t:1527188706229};\\\", \\\"{x:860,y:905,t:1527188706248};\\\", \\\"{x:862,y:903,t:1527188708765};\\\", \\\"{x:874,y:897,t:1527188708783};\\\", \\\"{x:886,y:887,t:1527188708800};\\\", \\\"{x:892,y:874,t:1527188708816};\\\", \\\"{x:893,y:863,t:1527188708833};\\\", \\\"{x:896,y:842,t:1527188708850};\\\", \\\"{x:903,y:817,t:1527188708866};\\\", \\\"{x:916,y:775,t:1527188708883};\\\", \\\"{x:940,y:697,t:1527188708900};\\\", \\\"{x:951,y:640,t:1527188708916};\\\", \\\"{x:954,y:580,t:1527188708933};\\\", \\\"{x:950,y:573,t:1527188708949};\\\", \\\"{x:950,y:574,t:1527188709557};\\\", \\\"{x:953,y:576,t:1527188709568};\\\", \\\"{x:959,y:578,t:1527188709584};\\\", \\\"{x:961,y:580,t:1527188709600};\\\", \\\"{x:961,y:581,t:1527188709653};\\\", \\\"{x:961,y:582,t:1527188709667};\\\", \\\"{x:963,y:583,t:1527188709684};\\\", \\\"{x:964,y:583,t:1527188709700};\\\", \\\"{x:968,y:584,t:1527188709717};\\\", \\\"{x:973,y:586,t:1527188709734};\\\", \\\"{x:980,y:587,t:1527188709750};\\\", \\\"{x:986,y:588,t:1527188709768};\\\", \\\"{x:995,y:590,t:1527188709784};\\\", \\\"{x:1004,y:592,t:1527188709801};\\\", \\\"{x:1018,y:600,t:1527188709818};\\\", \\\"{x:1027,y:606,t:1527188709834};\\\", \\\"{x:1040,y:616,t:1527188709850};\\\", \\\"{x:1048,y:624,t:1527188709868};\\\", \\\"{x:1052,y:633,t:1527188709884};\\\", \\\"{x:1059,y:646,t:1527188709901};\\\", \\\"{x:1066,y:658,t:1527188709918};\\\", \\\"{x:1071,y:668,t:1527188709933};\\\", \\\"{x:1078,y:677,t:1527188709951};\\\", \\\"{x:1084,y:687,t:1527188709967};\\\", \\\"{x:1088,y:694,t:1527188709984};\\\", \\\"{x:1093,y:703,t:1527188710001};\\\", \\\"{x:1097,y:720,t:1527188710017};\\\", \\\"{x:1106,y:750,t:1527188710034};\\\", \\\"{x:1116,y:779,t:1527188710051};\\\", \\\"{x:1122,y:798,t:1527188710068};\\\", \\\"{x:1129,y:822,t:1527188710084};\\\", \\\"{x:1133,y:838,t:1527188710100};\\\", \\\"{x:1134,y:851,t:1527188710116};\\\", \\\"{x:1137,y:862,t:1527188710134};\\\", \\\"{x:1137,y:867,t:1527188710151};\\\", \\\"{x:1137,y:868,t:1527188710167};\\\", \\\"{x:1138,y:869,t:1527188710277};\\\", \\\"{x:1139,y:870,t:1527188710284};\\\", \\\"{x:1141,y:874,t:1527188710301};\\\", \\\"{x:1143,y:877,t:1527188710317};\\\", \\\"{x:1145,y:880,t:1527188710334};\\\", \\\"{x:1150,y:887,t:1527188710351};\\\", \\\"{x:1156,y:893,t:1527188710367};\\\", \\\"{x:1161,y:898,t:1527188710384};\\\", \\\"{x:1168,y:904,t:1527188710401};\\\", \\\"{x:1182,y:915,t:1527188710417};\\\", \\\"{x:1196,y:924,t:1527188710435};\\\", \\\"{x:1208,y:934,t:1527188710451};\\\", \\\"{x:1225,y:945,t:1527188710467};\\\", \\\"{x:1234,y:950,t:1527188710484};\\\", \\\"{x:1244,y:953,t:1527188710500};\\\", \\\"{x:1253,y:953,t:1527188710518};\\\", \\\"{x:1258,y:953,t:1527188710533};\\\", \\\"{x:1264,y:953,t:1527188710551};\\\", \\\"{x:1268,y:950,t:1527188710567};\\\", \\\"{x:1270,y:949,t:1527188710584};\\\", \\\"{x:1272,y:946,t:1527188710600};\\\", \\\"{x:1274,y:942,t:1527188710618};\\\", \\\"{x:1275,y:938,t:1527188710634};\\\", \\\"{x:1277,y:933,t:1527188710651};\\\", \\\"{x:1277,y:928,t:1527188710668};\\\", \\\"{x:1278,y:924,t:1527188710684};\\\", \\\"{x:1279,y:921,t:1527188710701};\\\", \\\"{x:1279,y:918,t:1527188710718};\\\", \\\"{x:1280,y:916,t:1527188710734};\\\", \\\"{x:1280,y:912,t:1527188710751};\\\", \\\"{x:1280,y:911,t:1527188710772};\\\", \\\"{x:1280,y:909,t:1527188710789};\\\", \\\"{x:1280,y:908,t:1527188710852};\\\", \\\"{x:1280,y:906,t:1527188712980};\\\", \\\"{x:1279,y:903,t:1527188712988};\\\", \\\"{x:1274,y:898,t:1527188713003};\\\", \\\"{x:1264,y:888,t:1527188713018};\\\", \\\"{x:1256,y:876,t:1527188713035};\\\", \\\"{x:1254,y:871,t:1527188713053};\\\", \\\"{x:1248,y:862,t:1527188713068};\\\", \\\"{x:1238,y:840,t:1527188713086};\\\", \\\"{x:1222,y:807,t:1527188713103};\\\", \\\"{x:1214,y:786,t:1527188713118};\\\", \\\"{x:1207,y:766,t:1527188713136};\\\", \\\"{x:1203,y:749,t:1527188713153};\\\", \\\"{x:1197,y:734,t:1527188713169};\\\", \\\"{x:1192,y:720,t:1527188713187};\\\", \\\"{x:1189,y:716,t:1527188713203};\\\", \\\"{x:1188,y:717,t:1527188713332};\\\", \\\"{x:1187,y:722,t:1527188713340};\\\", \\\"{x:1186,y:732,t:1527188713353};\\\", \\\"{x:1184,y:746,t:1527188713370};\\\", \\\"{x:1183,y:760,t:1527188713386};\\\", \\\"{x:1183,y:771,t:1527188713403};\\\", \\\"{x:1184,y:783,t:1527188713420};\\\", \\\"{x:1185,y:787,t:1527188713436};\\\", \\\"{x:1186,y:788,t:1527188713484};\\\", \\\"{x:1187,y:788,t:1527188713491};\\\", \\\"{x:1188,y:788,t:1527188713508};\\\", \\\"{x:1191,y:788,t:1527188713520};\\\", \\\"{x:1196,y:787,t:1527188713536};\\\", \\\"{x:1202,y:785,t:1527188713552};\\\", \\\"{x:1209,y:782,t:1527188713570};\\\", \\\"{x:1214,y:781,t:1527188713587};\\\", \\\"{x:1215,y:781,t:1527188713603};\\\", \\\"{x:1218,y:781,t:1527188714285};\\\", \\\"{x:1222,y:781,t:1527188714294};\\\", \\\"{x:1227,y:781,t:1527188714305};\\\", \\\"{x:1236,y:783,t:1527188714320};\\\", \\\"{x:1243,y:785,t:1527188714342};\\\", \\\"{x:1245,y:785,t:1527188714355};\\\", \\\"{x:1250,y:787,t:1527188714370};\\\", \\\"{x:1252,y:787,t:1527188714387};\\\", \\\"{x:1267,y:787,t:1527188714404};\\\", \\\"{x:1278,y:787,t:1527188714420};\\\", \\\"{x:1292,y:787,t:1527188714437};\\\", \\\"{x:1302,y:787,t:1527188714454};\\\", \\\"{x:1305,y:787,t:1527188714470};\\\", \\\"{x:1306,y:787,t:1527188714487};\\\", \\\"{x:1306,y:786,t:1527188714637};\\\", \\\"{x:1301,y:782,t:1527188714654};\\\", \\\"{x:1292,y:779,t:1527188714670};\\\", \\\"{x:1291,y:778,t:1527188714687};\\\", \\\"{x:1290,y:777,t:1527188714996};\\\", \\\"{x:1290,y:776,t:1527188715597};\\\", \\\"{x:1290,y:775,t:1527188715613};\\\", \\\"{x:1289,y:775,t:1527188715622};\\\", \\\"{x:1288,y:774,t:1527188715661};\\\", \\\"{x:1287,y:774,t:1527188715781};\\\", \\\"{x:1286,y:774,t:1527188715788};\\\", \\\"{x:1285,y:774,t:1527188715821};\\\", \\\"{x:1283,y:774,t:1527188715838};\\\", \\\"{x:1282,y:774,t:1527188715855};\\\", \\\"{x:1280,y:774,t:1527188715871};\\\", \\\"{x:1279,y:772,t:1527188718244};\\\", \\\"{x:1278,y:768,t:1527188718256};\\\", \\\"{x:1277,y:764,t:1527188718274};\\\", \\\"{x:1277,y:759,t:1527188718291};\\\", \\\"{x:1276,y:755,t:1527188718307};\\\", \\\"{x:1276,y:751,t:1527188718323};\\\", \\\"{x:1275,y:747,t:1527188718340};\\\", \\\"{x:1274,y:744,t:1527188718356};\\\", \\\"{x:1274,y:742,t:1527188718373};\\\", \\\"{x:1274,y:738,t:1527188718390};\\\", \\\"{x:1274,y:736,t:1527188718407};\\\", \\\"{x:1274,y:734,t:1527188718424};\\\", \\\"{x:1274,y:730,t:1527188718440};\\\", \\\"{x:1274,y:727,t:1527188718456};\\\", \\\"{x:1274,y:723,t:1527188718474};\\\", \\\"{x:1274,y:717,t:1527188718491};\\\", \\\"{x:1274,y:716,t:1527188718506};\\\", \\\"{x:1274,y:712,t:1527188718524};\\\", \\\"{x:1274,y:710,t:1527188718541};\\\", \\\"{x:1274,y:709,t:1527188718558};\\\", \\\"{x:1274,y:708,t:1527188718573};\\\", \\\"{x:1274,y:707,t:1527188718605};\\\", \\\"{x:1274,y:704,t:1527188719245};\\\", \\\"{x:1275,y:702,t:1527188719258};\\\", \\\"{x:1277,y:691,t:1527188719274};\\\", \\\"{x:1277,y:680,t:1527188719290};\\\", \\\"{x:1280,y:666,t:1527188719308};\\\", \\\"{x:1282,y:651,t:1527188719325};\\\", \\\"{x:1283,y:645,t:1527188719341};\\\", \\\"{x:1284,y:641,t:1527188719358};\\\", \\\"{x:1284,y:639,t:1527188719374};\\\", \\\"{x:1284,y:638,t:1527188719391};\\\", \\\"{x:1284,y:636,t:1527188719407};\\\", \\\"{x:1284,y:635,t:1527188719429};\\\", \\\"{x:1284,y:634,t:1527188719629};\\\", \\\"{x:1283,y:635,t:1527188719709};\\\", \\\"{x:1282,y:636,t:1527188719748};\\\", \\\"{x:1282,y:637,t:1527188719772};\\\", \\\"{x:1281,y:638,t:1527188719788};\\\", \\\"{x:1280,y:640,t:1527188719805};\\\", \\\"{x:1279,y:641,t:1527188719813};\\\", \\\"{x:1278,y:642,t:1527188719829};\\\", \\\"{x:1278,y:643,t:1527188719842};\\\", \\\"{x:1278,y:644,t:1527188719877};\\\", \\\"{x:1277,y:645,t:1527188719892};\\\", \\\"{x:1276,y:645,t:1527188721709};\\\", \\\"{x:1266,y:644,t:1527188721726};\\\", \\\"{x:1249,y:641,t:1527188721742};\\\", \\\"{x:1226,y:641,t:1527188721760};\\\", \\\"{x:1177,y:635,t:1527188721775};\\\", \\\"{x:1083,y:624,t:1527188721792};\\\", \\\"{x:956,y:607,t:1527188721810};\\\", \\\"{x:830,y:599,t:1527188721826};\\\", \\\"{x:719,y:599,t:1527188721842};\\\", \\\"{x:630,y:599,t:1527188721859};\\\", \\\"{x:566,y:597,t:1527188721878};\\\", \\\"{x:554,y:590,t:1527188721892};\\\", \\\"{x:551,y:583,t:1527188721908};\\\", \\\"{x:550,y:576,t:1527188721927};\\\", \\\"{x:545,y:566,t:1527188721944};\\\", \\\"{x:534,y:555,t:1527188721961};\\\", \\\"{x:512,y:542,t:1527188721977};\\\", \\\"{x:500,y:536,t:1527188721994};\\\", \\\"{x:499,y:535,t:1527188722020};\\\", \\\"{x:499,y:534,t:1527188722043};\\\", \\\"{x:499,y:533,t:1527188722068};\\\", \\\"{x:499,y:532,t:1527188722078};\\\", \\\"{x:495,y:528,t:1527188722095};\\\", \\\"{x:490,y:524,t:1527188722111};\\\", \\\"{x:476,y:514,t:1527188722128};\\\", \\\"{x:453,y:501,t:1527188722144};\\\", \\\"{x:410,y:477,t:1527188722162};\\\", \\\"{x:381,y:462,t:1527188722178};\\\", \\\"{x:368,y:452,t:1527188722194};\\\", \\\"{x:365,y:447,t:1527188722210};\\\", \\\"{x:363,y:444,t:1527188722227};\\\", \\\"{x:362,y:443,t:1527188722244};\\\", \\\"{x:362,y:444,t:1527188722348};\\\", \\\"{x:363,y:446,t:1527188722361};\\\", \\\"{x:373,y:456,t:1527188722378};\\\", \\\"{x:389,y:468,t:1527188722394};\\\", \\\"{x:399,y:473,t:1527188722412};\\\", \\\"{x:402,y:474,t:1527188722427};\\\", \\\"{x:399,y:474,t:1527188722508};\\\", \\\"{x:398,y:474,t:1527188722516};\\\", \\\"{x:393,y:472,t:1527188722528};\\\", \\\"{x:391,y:472,t:1527188722545};\\\", \\\"{x:391,y:471,t:1527188722588};\\\", \\\"{x:392,y:472,t:1527188722916};\\\", \\\"{x:393,y:472,t:1527188722928};\\\", \\\"{x:400,y:476,t:1527188722945};\\\", \\\"{x:412,y:486,t:1527188722962};\\\", \\\"{x:428,y:501,t:1527188722978};\\\", \\\"{x:445,y:521,t:1527188722995};\\\", \\\"{x:464,y:545,t:1527188723013};\\\", \\\"{x:492,y:584,t:1527188723029};\\\", \\\"{x:509,y:608,t:1527188723045};\\\", \\\"{x:521,y:628,t:1527188723061};\\\", \\\"{x:527,y:644,t:1527188723078};\\\", \\\"{x:531,y:651,t:1527188723096};\\\", \\\"{x:532,y:653,t:1527188723111};\\\", \\\"{x:532,y:654,t:1527188723128};\\\", \\\"{x:531,y:655,t:1527188723493};\\\", \\\"{x:529,y:657,t:1527188723500};\\\", \\\"{x:527,y:658,t:1527188723513};\\\", \\\"{x:523,y:662,t:1527188723528};\\\", \\\"{x:518,y:665,t:1527188723545};\\\", \\\"{x:515,y:671,t:1527188723563};\\\", \\\"{x:513,y:673,t:1527188723579};\\\", \\\"{x:512,y:677,t:1527188723596};\\\", \\\"{x:510,y:678,t:1527188723612};\\\", \\\"{x:510,y:679,t:1527188723629};\\\", \\\"{x:510,y:677,t:1527188723901};\\\", \\\"{x:509,y:674,t:1527188723916};\\\", \\\"{x:508,y:673,t:1527188723933};\\\" ] }, { \\\"rt\\\": 16944, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 127358, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -D -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:672,t:1527188729845};\\\", \\\"{x:515,y:672,t:1527188729858};\\\", \\\"{x:536,y:672,t:1527188729870};\\\", \\\"{x:559,y:672,t:1527188729888};\\\", \\\"{x:578,y:672,t:1527188729904};\\\", \\\"{x:592,y:672,t:1527188729921};\\\", \\\"{x:604,y:672,t:1527188729937};\\\", \\\"{x:619,y:672,t:1527188729951};\\\", \\\"{x:640,y:674,t:1527188729968};\\\", \\\"{x:658,y:676,t:1527188729983};\\\", \\\"{x:681,y:676,t:1527188730001};\\\", \\\"{x:708,y:676,t:1527188730017};\\\", \\\"{x:744,y:676,t:1527188730033};\\\", \\\"{x:777,y:676,t:1527188730050};\\\", \\\"{x:845,y:676,t:1527188730068};\\\", \\\"{x:884,y:676,t:1527188730083};\\\", \\\"{x:915,y:676,t:1527188730100};\\\", \\\"{x:949,y:676,t:1527188730118};\\\", \\\"{x:978,y:676,t:1527188730135};\\\", \\\"{x:1002,y:676,t:1527188730150};\\\", \\\"{x:1021,y:676,t:1527188730167};\\\", \\\"{x:1022,y:676,t:1527188730184};\\\", \\\"{x:1023,y:676,t:1527188730200};\\\", \\\"{x:1025,y:676,t:1527188730621};\\\", \\\"{x:1028,y:676,t:1527188730635};\\\", \\\"{x:1034,y:676,t:1527188730652};\\\", \\\"{x:1039,y:677,t:1527188730668};\\\", \\\"{x:1046,y:677,t:1527188730685};\\\", \\\"{x:1054,y:677,t:1527188730702};\\\", \\\"{x:1067,y:679,t:1527188730718};\\\", \\\"{x:1081,y:680,t:1527188730735};\\\", \\\"{x:1101,y:685,t:1527188730752};\\\", \\\"{x:1128,y:690,t:1527188730768};\\\", \\\"{x:1159,y:693,t:1527188730785};\\\", \\\"{x:1185,y:698,t:1527188730802};\\\", \\\"{x:1206,y:700,t:1527188730818};\\\", \\\"{x:1219,y:700,t:1527188730835};\\\", \\\"{x:1224,y:700,t:1527188730852};\\\", \\\"{x:1226,y:701,t:1527188730893};\\\", \\\"{x:1228,y:703,t:1527188730902};\\\", \\\"{x:1231,y:707,t:1527188730918};\\\", \\\"{x:1235,y:712,t:1527188730935};\\\", \\\"{x:1241,y:719,t:1527188730952};\\\", \\\"{x:1254,y:730,t:1527188730968};\\\", \\\"{x:1264,y:738,t:1527188730985};\\\", \\\"{x:1273,y:743,t:1527188731001};\\\", \\\"{x:1282,y:749,t:1527188731019};\\\", \\\"{x:1287,y:751,t:1527188731035};\\\", \\\"{x:1292,y:752,t:1527188731052};\\\", \\\"{x:1293,y:752,t:1527188731133};\\\", \\\"{x:1294,y:752,t:1527188731141};\\\", \\\"{x:1295,y:752,t:1527188731152};\\\", \\\"{x:1297,y:752,t:1527188731169};\\\", \\\"{x:1301,y:751,t:1527188731185};\\\", \\\"{x:1304,y:748,t:1527188731203};\\\", \\\"{x:1307,y:744,t:1527188731219};\\\", \\\"{x:1310,y:741,t:1527188731235};\\\", \\\"{x:1317,y:736,t:1527188731252};\\\", \\\"{x:1320,y:733,t:1527188731269};\\\", \\\"{x:1327,y:729,t:1527188731285};\\\", \\\"{x:1332,y:727,t:1527188731302};\\\", \\\"{x:1336,y:724,t:1527188731320};\\\", \\\"{x:1343,y:719,t:1527188731336};\\\", \\\"{x:1352,y:716,t:1527188731352};\\\", \\\"{x:1360,y:712,t:1527188731369};\\\", \\\"{x:1366,y:710,t:1527188731385};\\\", \\\"{x:1371,y:708,t:1527188731402};\\\", \\\"{x:1375,y:707,t:1527188731419};\\\", \\\"{x:1380,y:707,t:1527188731438};\\\", \\\"{x:1385,y:707,t:1527188731451};\\\", \\\"{x:1386,y:707,t:1527188731468};\\\", \\\"{x:1387,y:707,t:1527188731564};\\\", \\\"{x:1388,y:707,t:1527188731757};\\\", \\\"{x:1389,y:707,t:1527188731769};\\\", \\\"{x:1389,y:706,t:1527188731796};\\\", \\\"{x:1390,y:706,t:1527188732341};\\\", \\\"{x:1392,y:705,t:1527188732353};\\\", \\\"{x:1397,y:704,t:1527188732370};\\\", \\\"{x:1403,y:703,t:1527188732386};\\\", \\\"{x:1404,y:703,t:1527188732402};\\\", \\\"{x:1405,y:703,t:1527188732419};\\\", \\\"{x:1407,y:703,t:1527188732572};\\\", \\\"{x:1411,y:703,t:1527188732585};\\\", \\\"{x:1416,y:703,t:1527188732603};\\\", \\\"{x:1421,y:703,t:1527188732620};\\\", \\\"{x:1422,y:703,t:1527188732636};\\\", \\\"{x:1423,y:703,t:1527188732660};\\\", \\\"{x:1425,y:703,t:1527188732692};\\\", \\\"{x:1427,y:703,t:1527188732708};\\\", \\\"{x:1429,y:703,t:1527188732720};\\\", \\\"{x:1430,y:704,t:1527188732736};\\\", \\\"{x:1433,y:703,t:1527188732773};\\\", \\\"{x:1439,y:699,t:1527188732787};\\\", \\\"{x:1458,y:682,t:1527188732803};\\\", \\\"{x:1500,y:646,t:1527188732821};\\\", \\\"{x:1530,y:615,t:1527188732837};\\\", \\\"{x:1557,y:575,t:1527188732853};\\\", \\\"{x:1578,y:542,t:1527188732870};\\\", \\\"{x:1591,y:521,t:1527188732887};\\\", \\\"{x:1597,y:501,t:1527188732903};\\\", \\\"{x:1598,y:487,t:1527188732920};\\\", \\\"{x:1598,y:480,t:1527188732937};\\\", \\\"{x:1596,y:471,t:1527188732953};\\\", \\\"{x:1594,y:462,t:1527188732970};\\\", \\\"{x:1594,y:454,t:1527188732987};\\\", \\\"{x:1595,y:449,t:1527188733002};\\\", \\\"{x:1598,y:440,t:1527188733019};\\\", \\\"{x:1600,y:436,t:1527188733036};\\\", \\\"{x:1600,y:435,t:1527188733052};\\\", \\\"{x:1600,y:432,t:1527188733069};\\\", \\\"{x:1603,y:429,t:1527188733087};\\\", \\\"{x:1606,y:426,t:1527188733103};\\\", \\\"{x:1609,y:423,t:1527188733120};\\\", \\\"{x:1615,y:414,t:1527188733136};\\\", \\\"{x:1618,y:410,t:1527188733153};\\\", \\\"{x:1621,y:406,t:1527188733169};\\\", \\\"{x:1624,y:402,t:1527188733187};\\\", \\\"{x:1626,y:396,t:1527188733204};\\\", \\\"{x:1627,y:393,t:1527188733220};\\\", \\\"{x:1627,y:392,t:1527188733237};\\\", \\\"{x:1628,y:389,t:1527188733254};\\\", \\\"{x:1628,y:388,t:1527188733270};\\\", \\\"{x:1627,y:388,t:1527188733380};\\\", \\\"{x:1623,y:385,t:1527188733388};\\\", \\\"{x:1622,y:385,t:1527188733404};\\\", \\\"{x:1622,y:384,t:1527188733420};\\\", \\\"{x:1622,y:383,t:1527188733581};\\\", \\\"{x:1621,y:383,t:1527188733613};\\\", \\\"{x:1621,y:382,t:1527188733620};\\\", \\\"{x:1619,y:381,t:1527188733637};\\\", \\\"{x:1618,y:381,t:1527188733701};\\\", \\\"{x:1617,y:381,t:1527188733724};\\\", \\\"{x:1616,y:381,t:1527188733748};\\\", \\\"{x:1615,y:381,t:1527188733900};\\\", \\\"{x:1614,y:381,t:1527188733940};\\\", \\\"{x:1613,y:382,t:1527188735093};\\\", \\\"{x:1613,y:388,t:1527188735106};\\\", \\\"{x:1613,y:400,t:1527188735122};\\\", \\\"{x:1612,y:411,t:1527188735138};\\\", \\\"{x:1612,y:420,t:1527188735156};\\\", \\\"{x:1612,y:433,t:1527188735172};\\\", \\\"{x:1612,y:438,t:1527188735188};\\\", \\\"{x:1612,y:446,t:1527188735205};\\\", \\\"{x:1613,y:450,t:1527188735222};\\\", \\\"{x:1615,y:455,t:1527188735239};\\\", \\\"{x:1615,y:456,t:1527188735260};\\\", \\\"{x:1615,y:457,t:1527188735272};\\\", \\\"{x:1615,y:459,t:1527188735289};\\\", \\\"{x:1615,y:465,t:1527188735305};\\\", \\\"{x:1619,y:475,t:1527188735322};\\\", \\\"{x:1620,y:484,t:1527188735338};\\\", \\\"{x:1620,y:491,t:1527188735356};\\\", \\\"{x:1621,y:500,t:1527188735372};\\\", \\\"{x:1622,y:503,t:1527188735388};\\\", \\\"{x:1622,y:505,t:1527188735405};\\\", \\\"{x:1622,y:506,t:1527188735423};\\\", \\\"{x:1622,y:509,t:1527188735439};\\\", \\\"{x:1622,y:510,t:1527188735456};\\\", \\\"{x:1622,y:513,t:1527188735472};\\\", \\\"{x:1622,y:517,t:1527188735489};\\\", \\\"{x:1622,y:519,t:1527188735505};\\\", \\\"{x:1621,y:519,t:1527188735929};\\\", \\\"{x:1620,y:519,t:1527188735943};\\\", \\\"{x:1619,y:519,t:1527188735960};\\\", \\\"{x:1619,y:520,t:1527188736521};\\\", \\\"{x:1619,y:523,t:1527188736528};\\\", \\\"{x:1619,y:525,t:1527188736543};\\\", \\\"{x:1618,y:531,t:1527188736559};\\\", \\\"{x:1618,y:535,t:1527188736580};\\\", \\\"{x:1618,y:536,t:1527188736623};\\\", \\\"{x:1618,y:537,t:1527188736655};\\\", \\\"{x:1618,y:538,t:1527188736679};\\\", \\\"{x:1618,y:539,t:1527188736692};\\\", \\\"{x:1618,y:540,t:1527188736709};\\\", \\\"{x:1618,y:541,t:1527188736727};\\\", \\\"{x:1616,y:543,t:1527188736743};\\\", \\\"{x:1616,y:546,t:1527188736759};\\\", \\\"{x:1615,y:548,t:1527188736777};\\\", \\\"{x:1613,y:553,t:1527188736794};\\\", \\\"{x:1611,y:557,t:1527188736810};\\\", \\\"{x:1610,y:563,t:1527188736827};\\\", \\\"{x:1610,y:567,t:1527188736844};\\\", \\\"{x:1610,y:569,t:1527188736860};\\\", \\\"{x:1608,y:573,t:1527188736876};\\\", \\\"{x:1608,y:576,t:1527188736893};\\\", \\\"{x:1608,y:587,t:1527188736909};\\\", \\\"{x:1608,y:598,t:1527188736927};\\\", \\\"{x:1608,y:609,t:1527188736943};\\\", \\\"{x:1608,y:613,t:1527188736959};\\\", \\\"{x:1608,y:616,t:1527188736977};\\\", \\\"{x:1608,y:617,t:1527188736993};\\\", \\\"{x:1608,y:619,t:1527188737010};\\\", \\\"{x:1608,y:622,t:1527188737027};\\\", \\\"{x:1608,y:623,t:1527188737043};\\\", \\\"{x:1608,y:624,t:1527188737060};\\\", \\\"{x:1608,y:625,t:1527188737077};\\\", \\\"{x:1608,y:626,t:1527188737094};\\\", \\\"{x:1608,y:628,t:1527188737110};\\\", \\\"{x:1609,y:632,t:1527188737126};\\\", \\\"{x:1609,y:638,t:1527188737143};\\\", \\\"{x:1609,y:641,t:1527188737161};\\\", \\\"{x:1610,y:644,t:1527188737177};\\\", \\\"{x:1610,y:646,t:1527188737208};\\\", \\\"{x:1610,y:647,t:1527188737216};\\\", \\\"{x:1612,y:649,t:1527188737227};\\\", \\\"{x:1612,y:651,t:1527188737244};\\\", \\\"{x:1612,y:653,t:1527188737260};\\\", \\\"{x:1612,y:654,t:1527188737277};\\\", \\\"{x:1612,y:656,t:1527188738369};\\\", \\\"{x:1612,y:658,t:1527188738379};\\\", \\\"{x:1612,y:662,t:1527188738395};\\\", \\\"{x:1612,y:667,t:1527188738410};\\\", \\\"{x:1612,y:670,t:1527188738427};\\\", \\\"{x:1612,y:674,t:1527188738444};\\\", \\\"{x:1612,y:675,t:1527188738462};\\\", \\\"{x:1612,y:678,t:1527188738477};\\\", \\\"{x:1612,y:680,t:1527188738495};\\\", \\\"{x:1612,y:683,t:1527188738511};\\\", \\\"{x:1612,y:685,t:1527188738527};\\\", \\\"{x:1613,y:686,t:1527188738544};\\\", \\\"{x:1613,y:687,t:1527188738561};\\\", \\\"{x:1613,y:688,t:1527188738577};\\\", \\\"{x:1613,y:691,t:1527188738595};\\\", \\\"{x:1613,y:693,t:1527188738612};\\\", \\\"{x:1613,y:695,t:1527188738628};\\\", \\\"{x:1613,y:697,t:1527188738644};\\\", \\\"{x:1613,y:700,t:1527188738661};\\\", \\\"{x:1613,y:701,t:1527188738678};\\\", \\\"{x:1613,y:703,t:1527188738694};\\\", \\\"{x:1613,y:704,t:1527188738720};\\\", \\\"{x:1613,y:705,t:1527188738728};\\\", \\\"{x:1613,y:707,t:1527188738752};\\\", \\\"{x:1613,y:708,t:1527188738800};\\\", \\\"{x:1613,y:714,t:1527188739625};\\\", \\\"{x:1613,y:719,t:1527188739632};\\\", \\\"{x:1613,y:723,t:1527188739646};\\\", \\\"{x:1613,y:735,t:1527188739662};\\\", \\\"{x:1613,y:743,t:1527188739680};\\\", \\\"{x:1613,y:752,t:1527188739696};\\\", \\\"{x:1613,y:756,t:1527188739713};\\\", \\\"{x:1613,y:758,t:1527188739729};\\\", \\\"{x:1613,y:760,t:1527188739746};\\\", \\\"{x:1614,y:763,t:1527188739762};\\\", \\\"{x:1614,y:765,t:1527188739779};\\\", \\\"{x:1614,y:766,t:1527188739800};\\\", \\\"{x:1614,y:768,t:1527188739832};\\\", \\\"{x:1614,y:769,t:1527188739846};\\\", \\\"{x:1614,y:772,t:1527188739863};\\\", \\\"{x:1614,y:775,t:1527188739880};\\\", \\\"{x:1614,y:779,t:1527188739896};\\\", \\\"{x:1614,y:781,t:1527188739913};\\\", \\\"{x:1614,y:783,t:1527188739929};\\\", \\\"{x:1614,y:784,t:1527188739946};\\\", \\\"{x:1614,y:783,t:1527188740296};\\\", \\\"{x:1614,y:782,t:1527188740320};\\\", \\\"{x:1612,y:782,t:1527188740544};\\\", \\\"{x:1612,y:785,t:1527188740552};\\\", \\\"{x:1612,y:789,t:1527188740563};\\\", \\\"{x:1611,y:794,t:1527188740580};\\\", \\\"{x:1607,y:803,t:1527188740596};\\\", \\\"{x:1607,y:811,t:1527188740612};\\\", \\\"{x:1607,y:816,t:1527188740629};\\\", \\\"{x:1606,y:819,t:1527188740645};\\\", \\\"{x:1606,y:821,t:1527188740743};\\\", \\\"{x:1606,y:822,t:1527188740784};\\\", \\\"{x:1606,y:824,t:1527188740796};\\\", \\\"{x:1606,y:826,t:1527188740813};\\\", \\\"{x:1606,y:828,t:1527188740830};\\\", \\\"{x:1606,y:831,t:1527188740847};\\\", \\\"{x:1607,y:833,t:1527188740880};\\\", \\\"{x:1607,y:834,t:1527188740944};\\\", \\\"{x:1607,y:835,t:1527188740952};\\\", \\\"{x:1608,y:837,t:1527188740963};\\\", \\\"{x:1610,y:842,t:1527188740980};\\\", \\\"{x:1615,y:852,t:1527188740997};\\\", \\\"{x:1616,y:860,t:1527188741013};\\\", \\\"{x:1618,y:868,t:1527188741030};\\\", \\\"{x:1620,y:878,t:1527188741047};\\\", \\\"{x:1622,y:891,t:1527188741063};\\\", \\\"{x:1622,y:910,t:1527188741080};\\\", \\\"{x:1622,y:925,t:1527188741097};\\\", \\\"{x:1622,y:940,t:1527188741114};\\\", \\\"{x:1620,y:954,t:1527188741130};\\\", \\\"{x:1618,y:968,t:1527188741147};\\\", \\\"{x:1615,y:980,t:1527188741164};\\\", \\\"{x:1610,y:986,t:1527188741181};\\\", \\\"{x:1600,y:989,t:1527188741197};\\\", \\\"{x:1574,y:990,t:1527188741214};\\\", \\\"{x:1518,y:974,t:1527188741229};\\\", \\\"{x:1412,y:942,t:1527188741248};\\\", \\\"{x:1326,y:905,t:1527188741264};\\\", \\\"{x:1205,y:852,t:1527188741280};\\\", \\\"{x:1053,y:785,t:1527188741296};\\\", \\\"{x:870,y:714,t:1527188741313};\\\", \\\"{x:691,y:645,t:1527188741330};\\\", \\\"{x:512,y:593,t:1527188741347};\\\", \\\"{x:411,y:559,t:1527188741364};\\\", \\\"{x:410,y:557,t:1527188741379};\\\", \\\"{x:413,y:558,t:1527188741399};\\\", \\\"{x:422,y:566,t:1527188741414};\\\", \\\"{x:436,y:582,t:1527188741431};\\\", \\\"{x:448,y:592,t:1527188741446};\\\", \\\"{x:452,y:595,t:1527188741464};\\\", \\\"{x:450,y:593,t:1527188741535};\\\", \\\"{x:445,y:589,t:1527188741546};\\\", \\\"{x:434,y:580,t:1527188741564};\\\", \\\"{x:420,y:567,t:1527188741581};\\\", \\\"{x:401,y:553,t:1527188741597};\\\", \\\"{x:385,y:535,t:1527188741613};\\\", \\\"{x:375,y:521,t:1527188741631};\\\", \\\"{x:370,y:513,t:1527188741647};\\\", \\\"{x:368,y:513,t:1527188741679};\\\", \\\"{x:367,y:513,t:1527188741687};\\\", \\\"{x:366,y:513,t:1527188741727};\\\", \\\"{x:365,y:513,t:1527188742040};\\\", \\\"{x:360,y:513,t:1527188742048};\\\", \\\"{x:347,y:520,t:1527188742065};\\\", \\\"{x:335,y:528,t:1527188742081};\\\", \\\"{x:319,y:539,t:1527188742098};\\\", \\\"{x:295,y:551,t:1527188742115};\\\", \\\"{x:259,y:563,t:1527188742130};\\\", \\\"{x:218,y:570,t:1527188742148};\\\", \\\"{x:207,y:573,t:1527188742165};\\\", \\\"{x:206,y:574,t:1527188742181};\\\", \\\"{x:203,y:576,t:1527188742351};\\\", \\\"{x:201,y:578,t:1527188742364};\\\", \\\"{x:200,y:582,t:1527188742381};\\\", \\\"{x:199,y:594,t:1527188742398};\\\", \\\"{x:197,y:604,t:1527188742416};\\\", \\\"{x:188,y:614,t:1527188742431};\\\", \\\"{x:179,y:618,t:1527188742448};\\\", \\\"{x:175,y:619,t:1527188742465};\\\", \\\"{x:173,y:619,t:1527188742481};\\\", \\\"{x:172,y:619,t:1527188742528};\\\", \\\"{x:171,y:619,t:1527188742544};\\\", \\\"{x:169,y:619,t:1527188742560};\\\", \\\"{x:167,y:617,t:1527188742567};\\\", \\\"{x:164,y:612,t:1527188742582};\\\", \\\"{x:161,y:604,t:1527188742599};\\\", \\\"{x:160,y:600,t:1527188742614};\\\", \\\"{x:159,y:598,t:1527188742632};\\\", \\\"{x:159,y:597,t:1527188742671};\\\", \\\"{x:159,y:596,t:1527188742683};\\\", \\\"{x:157,y:592,t:1527188742698};\\\", \\\"{x:156,y:587,t:1527188742715};\\\", \\\"{x:155,y:582,t:1527188742732};\\\", \\\"{x:153,y:579,t:1527188742749};\\\", \\\"{x:154,y:579,t:1527188742983};\\\", \\\"{x:156,y:579,t:1527188742999};\\\", \\\"{x:168,y:585,t:1527188743015};\\\", \\\"{x:200,y:608,t:1527188743033};\\\", \\\"{x:259,y:637,t:1527188743049};\\\", \\\"{x:330,y:664,t:1527188743064};\\\", \\\"{x:383,y:682,t:1527188743082};\\\", \\\"{x:439,y:697,t:1527188743099};\\\", \\\"{x:483,y:703,t:1527188743115};\\\", \\\"{x:510,y:703,t:1527188743131};\\\", \\\"{x:526,y:694,t:1527188743149};\\\", \\\"{x:532,y:680,t:1527188743166};\\\", \\\"{x:533,y:667,t:1527188743182};\\\", \\\"{x:522,y:648,t:1527188743199};\\\", \\\"{x:516,y:640,t:1527188743215};\\\", \\\"{x:515,y:637,t:1527188743232};\\\", \\\"{x:513,y:637,t:1527188743249};\\\", \\\"{x:512,y:636,t:1527188743266};\\\", \\\"{x:511,y:636,t:1527188743282};\\\", \\\"{x:510,y:636,t:1527188743299};\\\", \\\"{x:509,y:636,t:1527188743368};\\\", \\\"{x:508,y:637,t:1527188743382};\\\", \\\"{x:507,y:640,t:1527188743399};\\\", \\\"{x:507,y:649,t:1527188743417};\\\", \\\"{x:508,y:654,t:1527188743432};\\\", \\\"{x:508,y:657,t:1527188743449};\\\", \\\"{x:508,y:659,t:1527188743465};\\\", \\\"{x:508,y:660,t:1527188743482};\\\", \\\"{x:508,y:661,t:1527188743503};\\\", \\\"{x:508,y:662,t:1527188743515};\\\", \\\"{x:508,y:663,t:1527188743535};\\\", \\\"{x:508,y:665,t:1527188743549};\\\", \\\"{x:518,y:670,t:1527188744526};\\\", \\\"{x:553,y:682,t:1527188744534};\\\", \\\"{x:609,y:701,t:1527188744550};\\\", \\\"{x:708,y:732,t:1527188744566};\\\", \\\"{x:711,y:733,t:1527188744582};\\\", \\\"{x:711,y:732,t:1527188744704};\\\", \\\"{x:708,y:725,t:1527188744717};\\\", \\\"{x:661,y:695,t:1527188744750};\\\", \\\"{x:622,y:661,t:1527188744767};\\\", \\\"{x:586,y:630,t:1527188744782};\\\", \\\"{x:577,y:619,t:1527188744800};\\\", \\\"{x:577,y:618,t:1527188744817};\\\" ] }, { \\\"rt\\\": 16636, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 145269, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-Z -F -C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:681,y:555,t:1527188744990};\\\", \\\"{x:705,y:545,t:1527188745000};\\\", \\\"{x:730,y:531,t:1527188745018};\\\", \\\"{x:749,y:516,t:1527188745034};\\\", \\\"{x:758,y:509,t:1527188745049};\\\", \\\"{x:761,y:506,t:1527188745067};\\\", \\\"{x:768,y:496,t:1527188745085};\\\", \\\"{x:778,y:481,t:1527188745100};\\\", \\\"{x:788,y:467,t:1527188745117};\\\", \\\"{x:802,y:449,t:1527188745135};\\\", \\\"{x:803,y:445,t:1527188745150};\\\", \\\"{x:815,y:436,t:1527188745166};\\\", \\\"{x:820,y:435,t:1527188745184};\\\", \\\"{x:822,y:435,t:1527188745200};\\\", \\\"{x:821,y:435,t:1527188745408};\\\", \\\"{x:818,y:435,t:1527188745417};\\\", \\\"{x:803,y:435,t:1527188745434};\\\", \\\"{x:781,y:435,t:1527188745450};\\\", \\\"{x:758,y:435,t:1527188745467};\\\", \\\"{x:734,y:435,t:1527188745484};\\\", \\\"{x:586,y:411,t:1527188745582};\\\", \\\"{x:582,y:409,t:1527188745589};\\\", \\\"{x:580,y:409,t:1527188745600};\\\", \\\"{x:581,y:409,t:1527188745703};\\\", \\\"{x:584,y:409,t:1527188745717};\\\", \\\"{x:589,y:409,t:1527188745733};\\\", \\\"{x:608,y:411,t:1527188745751};\\\", \\\"{x:627,y:411,t:1527188745767};\\\", \\\"{x:662,y:411,t:1527188745784};\\\", \\\"{x:735,y:411,t:1527188745801};\\\", \\\"{x:843,y:415,t:1527188745818};\\\", \\\"{x:972,y:422,t:1527188745834};\\\", \\\"{x:1109,y:430,t:1527188745852};\\\", \\\"{x:1226,y:436,t:1527188745868};\\\", \\\"{x:1324,y:440,t:1527188745885};\\\", \\\"{x:1396,y:440,t:1527188745901};\\\", \\\"{x:1450,y:440,t:1527188745918};\\\", \\\"{x:1475,y:441,t:1527188745935};\\\", \\\"{x:1477,y:441,t:1527188745951};\\\", \\\"{x:1478,y:441,t:1527188745983};\\\", \\\"{x:1482,y:441,t:1527188745991};\\\", \\\"{x:1485,y:441,t:1527188746001};\\\", \\\"{x:1492,y:441,t:1527188746018};\\\", \\\"{x:1503,y:439,t:1527188746035};\\\", \\\"{x:1505,y:439,t:1527188746051};\\\", \\\"{x:1505,y:446,t:1527188747104};\\\", \\\"{x:1505,y:481,t:1527188747120};\\\", \\\"{x:1505,y:553,t:1527188747136};\\\", \\\"{x:1502,y:642,t:1527188747153};\\\", \\\"{x:1486,y:748,t:1527188747169};\\\", \\\"{x:1470,y:825,t:1527188747186};\\\", \\\"{x:1452,y:878,t:1527188747203};\\\", \\\"{x:1438,y:904,t:1527188747219};\\\", \\\"{x:1423,y:916,t:1527188747236};\\\", \\\"{x:1409,y:919,t:1527188747253};\\\", \\\"{x:1402,y:919,t:1527188747269};\\\", \\\"{x:1398,y:920,t:1527188747286};\\\", \\\"{x:1393,y:920,t:1527188747304};\\\", \\\"{x:1385,y:915,t:1527188747319};\\\", \\\"{x:1378,y:910,t:1527188747336};\\\", \\\"{x:1373,y:900,t:1527188747353};\\\", \\\"{x:1364,y:884,t:1527188747369};\\\", \\\"{x:1357,y:867,t:1527188747386};\\\", \\\"{x:1348,y:846,t:1527188747405};\\\", \\\"{x:1341,y:823,t:1527188747420};\\\", \\\"{x:1332,y:801,t:1527188747436};\\\", \\\"{x:1326,y:782,t:1527188747454};\\\", \\\"{x:1320,y:765,t:1527188747469};\\\", \\\"{x:1319,y:753,t:1527188747486};\\\", \\\"{x:1319,y:738,t:1527188747503};\\\", \\\"{x:1319,y:734,t:1527188747519};\\\", \\\"{x:1319,y:732,t:1527188747536};\\\", \\\"{x:1319,y:729,t:1527188747552};\\\", \\\"{x:1321,y:728,t:1527188747569};\\\", \\\"{x:1326,y:726,t:1527188747587};\\\", \\\"{x:1331,y:725,t:1527188747604};\\\", \\\"{x:1336,y:721,t:1527188747620};\\\", \\\"{x:1349,y:713,t:1527188747636};\\\", \\\"{x:1362,y:704,t:1527188747653};\\\", \\\"{x:1375,y:696,t:1527188747670};\\\", \\\"{x:1388,y:687,t:1527188747686};\\\", \\\"{x:1398,y:680,t:1527188747703};\\\", \\\"{x:1402,y:678,t:1527188747719};\\\", \\\"{x:1399,y:679,t:1527188748320};\\\", \\\"{x:1393,y:683,t:1527188748337};\\\", \\\"{x:1387,y:691,t:1527188748354};\\\", \\\"{x:1379,y:708,t:1527188748370};\\\", \\\"{x:1369,y:730,t:1527188748389};\\\", \\\"{x:1358,y:761,t:1527188748405};\\\", \\\"{x:1341,y:795,t:1527188748420};\\\", \\\"{x:1325,y:816,t:1527188748437};\\\", \\\"{x:1312,y:825,t:1527188748454};\\\", \\\"{x:1307,y:828,t:1527188748471};\\\", \\\"{x:1304,y:830,t:1527188748488};\\\", \\\"{x:1301,y:830,t:1527188748503};\\\", \\\"{x:1300,y:830,t:1527188748521};\\\", \\\"{x:1294,y:824,t:1527188748538};\\\", \\\"{x:1283,y:816,t:1527188748555};\\\", \\\"{x:1260,y:807,t:1527188748571};\\\", \\\"{x:1246,y:801,t:1527188748587};\\\", \\\"{x:1233,y:798,t:1527188748604};\\\", \\\"{x:1223,y:792,t:1527188748622};\\\", \\\"{x:1213,y:787,t:1527188748638};\\\", \\\"{x:1211,y:782,t:1527188748655};\\\", \\\"{x:1209,y:778,t:1527188748672};\\\", \\\"{x:1210,y:778,t:1527188748824};\\\", \\\"{x:1213,y:780,t:1527188752016};\\\", \\\"{x:1215,y:784,t:1527188752026};\\\", \\\"{x:1219,y:791,t:1527188752042};\\\", \\\"{x:1223,y:797,t:1527188752057};\\\", \\\"{x:1226,y:799,t:1527188752075};\\\", \\\"{x:1227,y:799,t:1527188752153};\\\", \\\"{x:1230,y:799,t:1527188752160};\\\", \\\"{x:1234,y:795,t:1527188752175};\\\", \\\"{x:1250,y:782,t:1527188752191};\\\", \\\"{x:1257,y:777,t:1527188752208};\\\", \\\"{x:1260,y:772,t:1527188752225};\\\", \\\"{x:1263,y:770,t:1527188752242};\\\", \\\"{x:1266,y:768,t:1527188752259};\\\", \\\"{x:1268,y:768,t:1527188752275};\\\", \\\"{x:1269,y:766,t:1527188752295};\\\", \\\"{x:1270,y:766,t:1527188752344};\\\", \\\"{x:1271,y:766,t:1527188752359};\\\", \\\"{x:1272,y:766,t:1527188752375};\\\", \\\"{x:1274,y:765,t:1527188752391};\\\", \\\"{x:1275,y:765,t:1527188752409};\\\", \\\"{x:1276,y:765,t:1527188752464};\\\", \\\"{x:1278,y:765,t:1527188752475};\\\", \\\"{x:1281,y:765,t:1527188752491};\\\", \\\"{x:1283,y:765,t:1527188752508};\\\", \\\"{x:1284,y:765,t:1527188752525};\\\", \\\"{x:1285,y:766,t:1527188752713};\\\", \\\"{x:1285,y:768,t:1527188753105};\\\", \\\"{x:1285,y:769,t:1527188753111};\\\", \\\"{x:1285,y:772,t:1527188753126};\\\", \\\"{x:1286,y:775,t:1527188753143};\\\", \\\"{x:1286,y:780,t:1527188753160};\\\", \\\"{x:1288,y:785,t:1527188753176};\\\", \\\"{x:1292,y:789,t:1527188753192};\\\", \\\"{x:1296,y:791,t:1527188753209};\\\", \\\"{x:1303,y:795,t:1527188753226};\\\", \\\"{x:1313,y:797,t:1527188753243};\\\", \\\"{x:1325,y:800,t:1527188753260};\\\", \\\"{x:1337,y:801,t:1527188753275};\\\", \\\"{x:1346,y:801,t:1527188753292};\\\", \\\"{x:1348,y:801,t:1527188753309};\\\", \\\"{x:1353,y:800,t:1527188753325};\\\", \\\"{x:1357,y:800,t:1527188753342};\\\", \\\"{x:1364,y:796,t:1527188753358};\\\", \\\"{x:1368,y:796,t:1527188753375};\\\", \\\"{x:1371,y:794,t:1527188753393};\\\", \\\"{x:1372,y:794,t:1527188753409};\\\", \\\"{x:1372,y:792,t:1527188753480};\\\", \\\"{x:1372,y:790,t:1527188753493};\\\", \\\"{x:1366,y:784,t:1527188753510};\\\", \\\"{x:1351,y:776,t:1527188753525};\\\", \\\"{x:1342,y:773,t:1527188753542};\\\", \\\"{x:1338,y:772,t:1527188753559};\\\", \\\"{x:1339,y:772,t:1527188753760};\\\", \\\"{x:1341,y:772,t:1527188753784};\\\", \\\"{x:1342,y:772,t:1527188753792};\\\", \\\"{x:1344,y:772,t:1527188753810};\\\", \\\"{x:1345,y:772,t:1527188753904};\\\", \\\"{x:1345,y:773,t:1527188753912};\\\", \\\"{x:1334,y:773,t:1527188755008};\\\", \\\"{x:1314,y:773,t:1527188755016};\\\", \\\"{x:1272,y:773,t:1527188755027};\\\", \\\"{x:1148,y:763,t:1527188755044};\\\", \\\"{x:1010,y:742,t:1527188755060};\\\", \\\"{x:858,y:720,t:1527188755077};\\\", \\\"{x:686,y:696,t:1527188755094};\\\", \\\"{x:525,y:665,t:1527188755111};\\\", \\\"{x:332,y:616,t:1527188755127};\\\", \\\"{x:274,y:591,t:1527188755144};\\\", \\\"{x:254,y:570,t:1527188755175};\\\", \\\"{x:254,y:560,t:1527188755192};\\\", \\\"{x:251,y:551,t:1527188755209};\\\", \\\"{x:247,y:546,t:1527188755226};\\\", \\\"{x:239,y:542,t:1527188755242};\\\", \\\"{x:235,y:541,t:1527188755258};\\\", \\\"{x:234,y:541,t:1527188755275};\\\", \\\"{x:233,y:541,t:1527188755292};\\\", \\\"{x:236,y:541,t:1527188755351};\\\", \\\"{x:240,y:541,t:1527188755358};\\\", \\\"{x:256,y:538,t:1527188755375};\\\", \\\"{x:260,y:538,t:1527188755392};\\\", \\\"{x:261,y:538,t:1527188755409};\\\", \\\"{x:262,y:538,t:1527188755425};\\\", \\\"{x:262,y:539,t:1527188755455};\\\", \\\"{x:259,y:541,t:1527188755463};\\\", \\\"{x:257,y:542,t:1527188755475};\\\", \\\"{x:247,y:545,t:1527188755492};\\\", \\\"{x:231,y:548,t:1527188755509};\\\", \\\"{x:211,y:553,t:1527188755524};\\\", \\\"{x:192,y:558,t:1527188755542};\\\", \\\"{x:172,y:562,t:1527188755560};\\\", \\\"{x:158,y:562,t:1527188755575};\\\", \\\"{x:140,y:562,t:1527188755592};\\\", \\\"{x:118,y:563,t:1527188755609};\\\", \\\"{x:99,y:564,t:1527188755626};\\\", \\\"{x:86,y:567,t:1527188755643};\\\", \\\"{x:83,y:569,t:1527188755659};\\\", \\\"{x:84,y:569,t:1527188755711};\\\", \\\"{x:89,y:569,t:1527188755725};\\\", \\\"{x:111,y:564,t:1527188755743};\\\", \\\"{x:184,y:557,t:1527188755759};\\\", \\\"{x:259,y:546,t:1527188755776};\\\", \\\"{x:337,y:533,t:1527188755795};\\\", \\\"{x:425,y:524,t:1527188755810};\\\", \\\"{x:518,y:520,t:1527188755827};\\\", \\\"{x:593,y:520,t:1527188755843};\\\", \\\"{x:646,y:520,t:1527188755859};\\\", \\\"{x:670,y:520,t:1527188755875};\\\", \\\"{x:673,y:520,t:1527188755892};\\\", \\\"{x:674,y:521,t:1527188756039};\\\", \\\"{x:674,y:525,t:1527188756048};\\\", \\\"{x:674,y:530,t:1527188756060};\\\", \\\"{x:670,y:539,t:1527188756076};\\\", \\\"{x:666,y:548,t:1527188756092};\\\", \\\"{x:663,y:564,t:1527188756109};\\\", \\\"{x:663,y:572,t:1527188756127};\\\", \\\"{x:663,y:579,t:1527188756143};\\\", \\\"{x:664,y:583,t:1527188756159};\\\", \\\"{x:672,y:584,t:1527188756175};\\\", \\\"{x:686,y:585,t:1527188756193};\\\", \\\"{x:705,y:589,t:1527188756209};\\\", \\\"{x:734,y:589,t:1527188756226};\\\", \\\"{x:762,y:589,t:1527188756243};\\\", \\\"{x:786,y:586,t:1527188756259};\\\", \\\"{x:814,y:577,t:1527188756277};\\\", \\\"{x:841,y:567,t:1527188756292};\\\", \\\"{x:865,y:556,t:1527188756310};\\\", \\\"{x:890,y:540,t:1527188756326};\\\", \\\"{x:905,y:530,t:1527188756342};\\\", \\\"{x:904,y:527,t:1527188756375};\\\", \\\"{x:894,y:524,t:1527188756393};\\\", \\\"{x:873,y:519,t:1527188756410};\\\", \\\"{x:839,y:519,t:1527188756426};\\\", \\\"{x:775,y:519,t:1527188756443};\\\", \\\"{x:689,y:519,t:1527188756460};\\\", \\\"{x:586,y:520,t:1527188756476};\\\", \\\"{x:478,y:534,t:1527188756493};\\\", \\\"{x:389,y:547,t:1527188756509};\\\", \\\"{x:323,y:552,t:1527188756526};\\\", \\\"{x:289,y:554,t:1527188756543};\\\", \\\"{x:282,y:554,t:1527188756560};\\\", \\\"{x:283,y:554,t:1527188756679};\\\", \\\"{x:289,y:552,t:1527188756694};\\\", \\\"{x:302,y:552,t:1527188756710};\\\", \\\"{x:327,y:548,t:1527188756726};\\\", \\\"{x:359,y:548,t:1527188756743};\\\", \\\"{x:370,y:548,t:1527188756760};\\\", \\\"{x:374,y:547,t:1527188756777};\\\", \\\"{x:375,y:547,t:1527188756793};\\\", \\\"{x:375,y:546,t:1527188756814};\\\", \\\"{x:375,y:545,t:1527188756838};\\\", \\\"{x:374,y:543,t:1527188756846};\\\", \\\"{x:368,y:541,t:1527188756861};\\\", \\\"{x:347,y:533,t:1527188756877};\\\", \\\"{x:306,y:522,t:1527188756893};\\\", \\\"{x:282,y:518,t:1527188756911};\\\", \\\"{x:251,y:513,t:1527188756928};\\\", \\\"{x:234,y:507,t:1527188756943};\\\", \\\"{x:230,y:507,t:1527188756960};\\\", \\\"{x:229,y:507,t:1527188756977};\\\", \\\"{x:231,y:507,t:1527188757023};\\\", \\\"{x:234,y:508,t:1527188757031};\\\", \\\"{x:235,y:510,t:1527188757044};\\\", \\\"{x:237,y:510,t:1527188757061};\\\", \\\"{x:237,y:514,t:1527188757077};\\\", \\\"{x:237,y:520,t:1527188757093};\\\", \\\"{x:226,y:528,t:1527188757111};\\\", \\\"{x:196,y:537,t:1527188757126};\\\", \\\"{x:169,y:539,t:1527188757143};\\\", \\\"{x:139,y:539,t:1527188757160};\\\", \\\"{x:125,y:539,t:1527188757177};\\\", \\\"{x:123,y:539,t:1527188757193};\\\", \\\"{x:121,y:539,t:1527188757210};\\\", \\\"{x:121,y:537,t:1527188757227};\\\", \\\"{x:124,y:536,t:1527188757244};\\\", \\\"{x:130,y:533,t:1527188757260};\\\", \\\"{x:136,y:528,t:1527188757278};\\\", \\\"{x:144,y:523,t:1527188757295};\\\", \\\"{x:156,y:516,t:1527188757311};\\\", \\\"{x:164,y:506,t:1527188757327};\\\", \\\"{x:165,y:504,t:1527188757343};\\\", \\\"{x:165,y:503,t:1527188757360};\\\", \\\"{x:167,y:502,t:1527188757726};\\\", \\\"{x:171,y:502,t:1527188757744};\\\", \\\"{x:176,y:504,t:1527188757760};\\\", \\\"{x:192,y:511,t:1527188757777};\\\", \\\"{x:223,y:527,t:1527188757795};\\\", \\\"{x:275,y:545,t:1527188757811};\\\", \\\"{x:322,y:567,t:1527188757827};\\\", \\\"{x:363,y:585,t:1527188757844};\\\", \\\"{x:404,y:608,t:1527188757861};\\\", \\\"{x:435,y:624,t:1527188757877};\\\", \\\"{x:455,y:631,t:1527188757894};\\\", \\\"{x:474,y:637,t:1527188757910};\\\", \\\"{x:477,y:640,t:1527188757927};\\\", \\\"{x:480,y:642,t:1527188757944};\\\", \\\"{x:486,y:646,t:1527188757960};\\\", \\\"{x:493,y:649,t:1527188757978};\\\", \\\"{x:500,y:653,t:1527188757994};\\\", \\\"{x:511,y:654,t:1527188758010};\\\", \\\"{x:515,y:654,t:1527188758027};\\\", \\\"{x:516,y:654,t:1527188758045};\\\", \\\"{x:518,y:654,t:1527188758079};\\\", \\\"{x:519,y:654,t:1527188758095};\\\", \\\"{x:523,y:659,t:1527188758111};\\\", \\\"{x:525,y:663,t:1527188758128};\\\", \\\"{x:525,y:665,t:1527188758158};\\\" ] }, { \\\"rt\\\": 60930, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 207425, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -A -C -C -A -F -O -O -O -O -O -K -O -K -03 PM-03 PM-04 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:667,t:1527188770680};\\\", \\\"{x:545,y:675,t:1527188770695};\\\", \\\"{x:555,y:677,t:1527188770702};\\\", \\\"{x:566,y:680,t:1527188770715};\\\", \\\"{x:587,y:687,t:1527188770731};\\\", \\\"{x:612,y:692,t:1527188770748};\\\", \\\"{x:661,y:703,t:1527188770769};\\\", \\\"{x:726,y:717,t:1527188770787};\\\", \\\"{x:807,y:728,t:1527188770802};\\\", \\\"{x:895,y:737,t:1527188770819};\\\", \\\"{x:1000,y:751,t:1527188770837};\\\", \\\"{x:1099,y:757,t:1527188770853};\\\", \\\"{x:1208,y:765,t:1527188770870};\\\", \\\"{x:1343,y:772,t:1527188770886};\\\", \\\"{x:1404,y:772,t:1527188770903};\\\", \\\"{x:1452,y:772,t:1527188770920};\\\", \\\"{x:1487,y:772,t:1527188770937};\\\", \\\"{x:1508,y:772,t:1527188770953};\\\", \\\"{x:1522,y:773,t:1527188770969};\\\", \\\"{x:1526,y:774,t:1527188770986};\\\", \\\"{x:1527,y:774,t:1527188771007};\\\", \\\"{x:1528,y:774,t:1527188771368};\\\", \\\"{x:1527,y:774,t:1527188771440};\\\", \\\"{x:1526,y:774,t:1527188771454};\\\", \\\"{x:1523,y:773,t:1527188771471};\\\", \\\"{x:1517,y:769,t:1527188771487};\\\", \\\"{x:1508,y:766,t:1527188771503};\\\", \\\"{x:1502,y:764,t:1527188771520};\\\", \\\"{x:1497,y:764,t:1527188771537};\\\", \\\"{x:1491,y:764,t:1527188771554};\\\", \\\"{x:1484,y:769,t:1527188771570};\\\", \\\"{x:1479,y:778,t:1527188771591};\\\", \\\"{x:1471,y:788,t:1527188771606};\\\", \\\"{x:1463,y:797,t:1527188771620};\\\", \\\"{x:1456,y:804,t:1527188771638};\\\", \\\"{x:1446,y:810,t:1527188771654};\\\", \\\"{x:1438,y:813,t:1527188771671};\\\", \\\"{x:1419,y:813,t:1527188771687};\\\", \\\"{x:1397,y:813,t:1527188771704};\\\", \\\"{x:1365,y:806,t:1527188771720};\\\", \\\"{x:1323,y:794,t:1527188771737};\\\", \\\"{x:1278,y:780,t:1527188771755};\\\", \\\"{x:1239,y:769,t:1527188771771};\\\", \\\"{x:1221,y:766,t:1527188771787};\\\", \\\"{x:1209,y:762,t:1527188771805};\\\", \\\"{x:1207,y:762,t:1527188771822};\\\", \\\"{x:1206,y:763,t:1527188771912};\\\", \\\"{x:1206,y:765,t:1527188771927};\\\", \\\"{x:1206,y:767,t:1527188771937};\\\", \\\"{x:1207,y:768,t:1527188771955};\\\", \\\"{x:1208,y:769,t:1527188771975};\\\", \\\"{x:1210,y:770,t:1527188771991};\\\", \\\"{x:1210,y:771,t:1527188772005};\\\", \\\"{x:1212,y:772,t:1527188772022};\\\", \\\"{x:1213,y:773,t:1527188772037};\\\", \\\"{x:1214,y:773,t:1527188773088};\\\", \\\"{x:1222,y:778,t:1527188773105};\\\", \\\"{x:1229,y:780,t:1527188773121};\\\", \\\"{x:1230,y:781,t:1527188773138};\\\", \\\"{x:1231,y:781,t:1527188773175};\\\", \\\"{x:1232,y:781,t:1527188773188};\\\", \\\"{x:1237,y:783,t:1527188773205};\\\", \\\"{x:1240,y:785,t:1527188773221};\\\", \\\"{x:1241,y:785,t:1527188773239};\\\", \\\"{x:1242,y:785,t:1527188773255};\\\", \\\"{x:1244,y:785,t:1527188773423};\\\", \\\"{x:1247,y:785,t:1527188773438};\\\", \\\"{x:1254,y:785,t:1527188773456};\\\", \\\"{x:1260,y:783,t:1527188773472};\\\", \\\"{x:1264,y:782,t:1527188773488};\\\", \\\"{x:1266,y:780,t:1527188773505};\\\", \\\"{x:1268,y:780,t:1527188773528};\\\", \\\"{x:1269,y:780,t:1527188773543};\\\", \\\"{x:1271,y:780,t:1527188773556};\\\", \\\"{x:1274,y:780,t:1527188773571};\\\", \\\"{x:1277,y:780,t:1527188773588};\\\", \\\"{x:1278,y:780,t:1527188773605};\\\", \\\"{x:1279,y:779,t:1527188774576};\\\", \\\"{x:1279,y:778,t:1527188774784};\\\", \\\"{x:1280,y:776,t:1527188774799};\\\", \\\"{x:1280,y:779,t:1527188776383};\\\", \\\"{x:1283,y:785,t:1527188776392};\\\", \\\"{x:1285,y:791,t:1527188776406};\\\", \\\"{x:1294,y:811,t:1527188776424};\\\", \\\"{x:1298,y:816,t:1527188776441};\\\", \\\"{x:1301,y:820,t:1527188776457};\\\", \\\"{x:1303,y:822,t:1527188776473};\\\", \\\"{x:1304,y:824,t:1527188776490};\\\", \\\"{x:1306,y:826,t:1527188776508};\\\", \\\"{x:1306,y:829,t:1527188776524};\\\", \\\"{x:1308,y:832,t:1527188776541};\\\", \\\"{x:1309,y:835,t:1527188776557};\\\", \\\"{x:1310,y:837,t:1527188776573};\\\", \\\"{x:1312,y:841,t:1527188776591};\\\", \\\"{x:1316,y:848,t:1527188776607};\\\", \\\"{x:1329,y:860,t:1527188776624};\\\", \\\"{x:1340,y:868,t:1527188776641};\\\", \\\"{x:1348,y:873,t:1527188776656};\\\", \\\"{x:1353,y:873,t:1527188776673};\\\", \\\"{x:1357,y:873,t:1527188776690};\\\", \\\"{x:1359,y:873,t:1527188776706};\\\", \\\"{x:1361,y:872,t:1527188776724};\\\", \\\"{x:1362,y:869,t:1527188776741};\\\", \\\"{x:1363,y:868,t:1527188776757};\\\", \\\"{x:1364,y:866,t:1527188776773};\\\", \\\"{x:1364,y:864,t:1527188776790};\\\", \\\"{x:1366,y:862,t:1527188776806};\\\", \\\"{x:1366,y:860,t:1527188776824};\\\", \\\"{x:1366,y:858,t:1527188776855};\\\", \\\"{x:1366,y:855,t:1527188776874};\\\", \\\"{x:1366,y:854,t:1527188776890};\\\", \\\"{x:1365,y:853,t:1527188776919};\\\", \\\"{x:1364,y:850,t:1527188776927};\\\", \\\"{x:1362,y:849,t:1527188776941};\\\", \\\"{x:1360,y:845,t:1527188776957};\\\", \\\"{x:1357,y:841,t:1527188776973};\\\", \\\"{x:1354,y:838,t:1527188776990};\\\", \\\"{x:1352,y:836,t:1527188777007};\\\", \\\"{x:1353,y:836,t:1527188777480};\\\", \\\"{x:1355,y:836,t:1527188777491};\\\", \\\"{x:1356,y:836,t:1527188777507};\\\", \\\"{x:1358,y:836,t:1527188777523};\\\", \\\"{x:1361,y:837,t:1527188777540};\\\", \\\"{x:1362,y:837,t:1527188777557};\\\", \\\"{x:1365,y:839,t:1527188777575};\\\", \\\"{x:1366,y:840,t:1527188777591};\\\", \\\"{x:1367,y:842,t:1527188777607};\\\", \\\"{x:1368,y:842,t:1527188777625};\\\", \\\"{x:1369,y:843,t:1527188777641};\\\", \\\"{x:1372,y:844,t:1527188777658};\\\", \\\"{x:1373,y:844,t:1527188777675};\\\", \\\"{x:1374,y:844,t:1527188777691};\\\", \\\"{x:1375,y:844,t:1527188777707};\\\", \\\"{x:1376,y:844,t:1527188777767};\\\", \\\"{x:1377,y:844,t:1527188777775};\\\", \\\"{x:1378,y:844,t:1527188777792};\\\", \\\"{x:1380,y:844,t:1527188777823};\\\", \\\"{x:1383,y:844,t:1527188777841};\\\", \\\"{x:1386,y:844,t:1527188777858};\\\", \\\"{x:1389,y:845,t:1527188777875};\\\", \\\"{x:1390,y:846,t:1527188777890};\\\", \\\"{x:1391,y:846,t:1527188777960};\\\", \\\"{x:1395,y:846,t:1527188777975};\\\", \\\"{x:1401,y:845,t:1527188777991};\\\", \\\"{x:1405,y:845,t:1527188778007};\\\", \\\"{x:1406,y:845,t:1527188778024};\\\", \\\"{x:1407,y:845,t:1527188778040};\\\", \\\"{x:1408,y:845,t:1527188778079};\\\", \\\"{x:1409,y:845,t:1527188778095};\\\", \\\"{x:1410,y:845,t:1527188778108};\\\", \\\"{x:1411,y:845,t:1527188778124};\\\", \\\"{x:1412,y:845,t:1527188778140};\\\", \\\"{x:1414,y:845,t:1527188778158};\\\", \\\"{x:1415,y:845,t:1527188778175};\\\", \\\"{x:1417,y:845,t:1527188778191};\\\", \\\"{x:1418,y:845,t:1527188778207};\\\", \\\"{x:1420,y:845,t:1527188778225};\\\", \\\"{x:1421,y:845,t:1527188778247};\\\", \\\"{x:1422,y:845,t:1527188778271};\\\", \\\"{x:1423,y:845,t:1527188778336};\\\", \\\"{x:1424,y:845,t:1527188778343};\\\", \\\"{x:1425,y:845,t:1527188778358};\\\", \\\"{x:1427,y:845,t:1527188778375};\\\", \\\"{x:1430,y:845,t:1527188778392};\\\", \\\"{x:1431,y:845,t:1527188778407};\\\", \\\"{x:1432,y:845,t:1527188778447};\\\", \\\"{x:1434,y:845,t:1527188778458};\\\", \\\"{x:1438,y:845,t:1527188778475};\\\", \\\"{x:1441,y:844,t:1527188778492};\\\", \\\"{x:1444,y:844,t:1527188778508};\\\", \\\"{x:1445,y:844,t:1527188778525};\\\", \\\"{x:1445,y:842,t:1527188779015};\\\", \\\"{x:1444,y:841,t:1527188779025};\\\", \\\"{x:1436,y:837,t:1527188779042};\\\", \\\"{x:1429,y:836,t:1527188779058};\\\", \\\"{x:1423,y:834,t:1527188779074};\\\", \\\"{x:1417,y:834,t:1527188779092};\\\", \\\"{x:1410,y:835,t:1527188779108};\\\", \\\"{x:1405,y:838,t:1527188779124};\\\", \\\"{x:1403,y:839,t:1527188779142};\\\", \\\"{x:1400,y:841,t:1527188779159};\\\", \\\"{x:1399,y:842,t:1527188779175};\\\", \\\"{x:1398,y:843,t:1527188779192};\\\", \\\"{x:1397,y:842,t:1527188779448};\\\", \\\"{x:1393,y:837,t:1527188779458};\\\", \\\"{x:1382,y:824,t:1527188779474};\\\", \\\"{x:1367,y:808,t:1527188779491};\\\", \\\"{x:1349,y:791,t:1527188779508};\\\", \\\"{x:1331,y:775,t:1527188779525};\\\", \\\"{x:1319,y:760,t:1527188779541};\\\", \\\"{x:1304,y:740,t:1527188779558};\\\", \\\"{x:1296,y:731,t:1527188779575};\\\", \\\"{x:1288,y:725,t:1527188779591};\\\", \\\"{x:1286,y:722,t:1527188779609};\\\", \\\"{x:1284,y:721,t:1527188779831};\\\", \\\"{x:1283,y:720,t:1527188779841};\\\", \\\"{x:1279,y:719,t:1527188779859};\\\", \\\"{x:1277,y:718,t:1527188779876};\\\", \\\"{x:1276,y:717,t:1527188779892};\\\", \\\"{x:1276,y:716,t:1527188779908};\\\", \\\"{x:1275,y:716,t:1527188779943};\\\", \\\"{x:1274,y:715,t:1527188779959};\\\", \\\"{x:1273,y:713,t:1527188779975};\\\", \\\"{x:1272,y:710,t:1527188779992};\\\", \\\"{x:1270,y:706,t:1527188780009};\\\", \\\"{x:1269,y:704,t:1527188780026};\\\", \\\"{x:1268,y:701,t:1527188780041};\\\", \\\"{x:1268,y:699,t:1527188780058};\\\", \\\"{x:1267,y:699,t:1527188780075};\\\", \\\"{x:1265,y:700,t:1527188780415};\\\", \\\"{x:1262,y:703,t:1527188780426};\\\", \\\"{x:1258,y:710,t:1527188780443};\\\", \\\"{x:1256,y:714,t:1527188780458};\\\", \\\"{x:1255,y:715,t:1527188780475};\\\", \\\"{x:1254,y:716,t:1527188780492};\\\", \\\"{x:1254,y:717,t:1527188780688};\\\", \\\"{x:1258,y:718,t:1527188780696};\\\", \\\"{x:1265,y:718,t:1527188780708};\\\", \\\"{x:1285,y:720,t:1527188780726};\\\", \\\"{x:1315,y:720,t:1527188780743};\\\", \\\"{x:1335,y:720,t:1527188780758};\\\", \\\"{x:1351,y:718,t:1527188780776};\\\", \\\"{x:1364,y:715,t:1527188780793};\\\", \\\"{x:1372,y:713,t:1527188780809};\\\", \\\"{x:1380,y:710,t:1527188780825};\\\", \\\"{x:1382,y:710,t:1527188780842};\\\", \\\"{x:1382,y:709,t:1527188787223};\\\", \\\"{x:1380,y:705,t:1527188787231};\\\", \\\"{x:1374,y:700,t:1527188787247};\\\", \\\"{x:1357,y:675,t:1527188787263};\\\", \\\"{x:1349,y:659,t:1527188787279};\\\", \\\"{x:1348,y:647,t:1527188787296};\\\", \\\"{x:1348,y:638,t:1527188787313};\\\", \\\"{x:1348,y:632,t:1527188787330};\\\", \\\"{x:1348,y:629,t:1527188787346};\\\", \\\"{x:1348,y:627,t:1527188787363};\\\", \\\"{x:1348,y:626,t:1527188787380};\\\", \\\"{x:1348,y:624,t:1527188787396};\\\", \\\"{x:1348,y:622,t:1527188787413};\\\", \\\"{x:1348,y:620,t:1527188787429};\\\", \\\"{x:1348,y:619,t:1527188787445};\\\", \\\"{x:1348,y:618,t:1527188787480};\\\", \\\"{x:1348,y:617,t:1527188787496};\\\", \\\"{x:1344,y:614,t:1527188787513};\\\", \\\"{x:1338,y:608,t:1527188787530};\\\", \\\"{x:1333,y:599,t:1527188787546};\\\", \\\"{x:1327,y:590,t:1527188787563};\\\", \\\"{x:1324,y:580,t:1527188787580};\\\", \\\"{x:1324,y:578,t:1527188787596};\\\", \\\"{x:1324,y:577,t:1527188787613};\\\", \\\"{x:1323,y:576,t:1527188787688};\\\", \\\"{x:1322,y:576,t:1527188787712};\\\", \\\"{x:1321,y:576,t:1527188787776};\\\", \\\"{x:1320,y:576,t:1527188787791};\\\", \\\"{x:1319,y:576,t:1527188787815};\\\", \\\"{x:1318,y:576,t:1527188787919};\\\", \\\"{x:1316,y:577,t:1527188787951};\\\", \\\"{x:1315,y:577,t:1527188788055};\\\", \\\"{x:1314,y:576,t:1527188788071};\\\", \\\"{x:1313,y:576,t:1527188788095};\\\", \\\"{x:1312,y:576,t:1527188788103};\\\", \\\"{x:1311,y:576,t:1527188793054};\\\", \\\"{x:1311,y:577,t:1527188793066};\\\", \\\"{x:1311,y:585,t:1527188793084};\\\", \\\"{x:1311,y:590,t:1527188793099};\\\", \\\"{x:1311,y:595,t:1527188793116};\\\", \\\"{x:1311,y:597,t:1527188793133};\\\", \\\"{x:1311,y:600,t:1527188793149};\\\", \\\"{x:1311,y:602,t:1527188793166};\\\", \\\"{x:1311,y:603,t:1527188793183};\\\", \\\"{x:1311,y:606,t:1527188793199};\\\", \\\"{x:1311,y:608,t:1527188793223};\\\", \\\"{x:1311,y:609,t:1527188793233};\\\", \\\"{x:1311,y:611,t:1527188793249};\\\", \\\"{x:1311,y:613,t:1527188793271};\\\", \\\"{x:1311,y:614,t:1527188793283};\\\", \\\"{x:1311,y:617,t:1527188793299};\\\", \\\"{x:1311,y:619,t:1527188793316};\\\", \\\"{x:1311,y:622,t:1527188793333};\\\", \\\"{x:1311,y:625,t:1527188793349};\\\", \\\"{x:1311,y:627,t:1527188793366};\\\", \\\"{x:1312,y:631,t:1527188793383};\\\", \\\"{x:1312,y:634,t:1527188793399};\\\", \\\"{x:1313,y:639,t:1527188793416};\\\", \\\"{x:1313,y:643,t:1527188793434};\\\", \\\"{x:1313,y:648,t:1527188793449};\\\", \\\"{x:1315,y:653,t:1527188793467};\\\", \\\"{x:1315,y:657,t:1527188793483};\\\", \\\"{x:1315,y:661,t:1527188793498};\\\", \\\"{x:1315,y:664,t:1527188793516};\\\", \\\"{x:1315,y:670,t:1527188793533};\\\", \\\"{x:1315,y:675,t:1527188793550};\\\", \\\"{x:1315,y:679,t:1527188793566};\\\", \\\"{x:1315,y:686,t:1527188793582};\\\", \\\"{x:1315,y:690,t:1527188793599};\\\", \\\"{x:1315,y:695,t:1527188793616};\\\", \\\"{x:1315,y:699,t:1527188793633};\\\", \\\"{x:1315,y:704,t:1527188793650};\\\", \\\"{x:1316,y:709,t:1527188793666};\\\", \\\"{x:1316,y:713,t:1527188793683};\\\", \\\"{x:1316,y:717,t:1527188793699};\\\", \\\"{x:1316,y:725,t:1527188793716};\\\", \\\"{x:1317,y:733,t:1527188793733};\\\", \\\"{x:1319,y:741,t:1527188793749};\\\", \\\"{x:1320,y:751,t:1527188793765};\\\", \\\"{x:1321,y:764,t:1527188793783};\\\", \\\"{x:1322,y:771,t:1527188793800};\\\", \\\"{x:1325,y:779,t:1527188793816};\\\", \\\"{x:1325,y:784,t:1527188793833};\\\", \\\"{x:1326,y:790,t:1527188793850};\\\", \\\"{x:1326,y:795,t:1527188793866};\\\", \\\"{x:1328,y:799,t:1527188793883};\\\", \\\"{x:1329,y:806,t:1527188793900};\\\", \\\"{x:1329,y:810,t:1527188793916};\\\", \\\"{x:1329,y:814,t:1527188793933};\\\", \\\"{x:1330,y:817,t:1527188793950};\\\", \\\"{x:1330,y:820,t:1527188793966};\\\", \\\"{x:1331,y:824,t:1527188793982};\\\", \\\"{x:1331,y:826,t:1527188794000};\\\", \\\"{x:1331,y:830,t:1527188794016};\\\", \\\"{x:1331,y:836,t:1527188794033};\\\", \\\"{x:1331,y:842,t:1527188794050};\\\", \\\"{x:1331,y:850,t:1527188794066};\\\", \\\"{x:1331,y:860,t:1527188794084};\\\", \\\"{x:1331,y:869,t:1527188794100};\\\", \\\"{x:1330,y:877,t:1527188794116};\\\", \\\"{x:1330,y:885,t:1527188794132};\\\", \\\"{x:1328,y:889,t:1527188794150};\\\", \\\"{x:1328,y:894,t:1527188794166};\\\", \\\"{x:1327,y:899,t:1527188794182};\\\", \\\"{x:1327,y:901,t:1527188794200};\\\", \\\"{x:1327,y:903,t:1527188794216};\\\", \\\"{x:1326,y:906,t:1527188794233};\\\", \\\"{x:1325,y:909,t:1527188794250};\\\", \\\"{x:1325,y:910,t:1527188794268};\\\", \\\"{x:1324,y:913,t:1527188794283};\\\", \\\"{x:1323,y:914,t:1527188794302};\\\", \\\"{x:1323,y:916,t:1527188794319};\\\", \\\"{x:1323,y:917,t:1527188794333};\\\", \\\"{x:1323,y:918,t:1527188794350};\\\", \\\"{x:1321,y:919,t:1527188794366};\\\", \\\"{x:1321,y:920,t:1527188794389};\\\", \\\"{x:1321,y:915,t:1527188794592};\\\", \\\"{x:1321,y:906,t:1527188794600};\\\", \\\"{x:1320,y:883,t:1527188794617};\\\", \\\"{x:1320,y:856,t:1527188794632};\\\", \\\"{x:1320,y:830,t:1527188794650};\\\", \\\"{x:1320,y:797,t:1527188794667};\\\", \\\"{x:1320,y:768,t:1527188794682};\\\", \\\"{x:1320,y:741,t:1527188794700};\\\", \\\"{x:1321,y:717,t:1527188794717};\\\", \\\"{x:1323,y:693,t:1527188794734};\\\", \\\"{x:1326,y:678,t:1527188794751};\\\", \\\"{x:1328,y:665,t:1527188794767};\\\", \\\"{x:1329,y:662,t:1527188794783};\\\", \\\"{x:1329,y:659,t:1527188794871};\\\", \\\"{x:1329,y:658,t:1527188794883};\\\", \\\"{x:1329,y:653,t:1527188794900};\\\", \\\"{x:1329,y:647,t:1527188794917};\\\", \\\"{x:1329,y:640,t:1527188794934};\\\", \\\"{x:1326,y:628,t:1527188794950};\\\", \\\"{x:1320,y:605,t:1527188794967};\\\", \\\"{x:1317,y:589,t:1527188794984};\\\", \\\"{x:1315,y:576,t:1527188795001};\\\", \\\"{x:1315,y:569,t:1527188795017};\\\", \\\"{x:1316,y:563,t:1527188795034};\\\", \\\"{x:1316,y:561,t:1527188795050};\\\", \\\"{x:1316,y:560,t:1527188795067};\\\", \\\"{x:1316,y:563,t:1527188795216};\\\", \\\"{x:1316,y:566,t:1527188795223};\\\", \\\"{x:1317,y:569,t:1527188795234};\\\", \\\"{x:1317,y:572,t:1527188795250};\\\", \\\"{x:1318,y:577,t:1527188795267};\\\", \\\"{x:1319,y:581,t:1527188795285};\\\", \\\"{x:1319,y:583,t:1527188795327};\\\", \\\"{x:1319,y:584,t:1527188795335};\\\", \\\"{x:1318,y:584,t:1527188795359};\\\", \\\"{x:1317,y:585,t:1527188795384};\\\", \\\"{x:1317,y:584,t:1527188795738};\\\", \\\"{x:1316,y:582,t:1527188795755};\\\", \\\"{x:1316,y:581,t:1527188795794};\\\", \\\"{x:1317,y:581,t:1527188796050};\\\", \\\"{x:1319,y:581,t:1527188796115};\\\", \\\"{x:1324,y:582,t:1527188796122};\\\", \\\"{x:1330,y:583,t:1527188796137};\\\", \\\"{x:1349,y:586,t:1527188796154};\\\", \\\"{x:1353,y:586,t:1527188796171};\\\", \\\"{x:1355,y:586,t:1527188796188};\\\", \\\"{x:1356,y:586,t:1527188796218};\\\", \\\"{x:1359,y:586,t:1527188796226};\\\", \\\"{x:1359,y:587,t:1527188796237};\\\", \\\"{x:1362,y:587,t:1527188796255};\\\", \\\"{x:1365,y:588,t:1527188796271};\\\", \\\"{x:1368,y:589,t:1527188796287};\\\", \\\"{x:1369,y:589,t:1527188796305};\\\", \\\"{x:1370,y:589,t:1527188796322};\\\", \\\"{x:1372,y:589,t:1527188796337};\\\", \\\"{x:1373,y:588,t:1527188796354};\\\", \\\"{x:1375,y:586,t:1527188796372};\\\", \\\"{x:1376,y:586,t:1527188796394};\\\", \\\"{x:1379,y:583,t:1527188796405};\\\", \\\"{x:1381,y:583,t:1527188796422};\\\", \\\"{x:1382,y:583,t:1527188796437};\\\", \\\"{x:1383,y:582,t:1527188796454};\\\", \\\"{x:1385,y:581,t:1527188796483};\\\", \\\"{x:1386,y:581,t:1527188796531};\\\", \\\"{x:1386,y:580,t:1527188796538};\\\", \\\"{x:1386,y:579,t:1527188796562};\\\", \\\"{x:1386,y:578,t:1527188796572};\\\", \\\"{x:1385,y:577,t:1527188796594};\\\", \\\"{x:1383,y:576,t:1527188796619};\\\", \\\"{x:1382,y:576,t:1527188796634};\\\", \\\"{x:1381,y:576,t:1527188796642};\\\", \\\"{x:1380,y:576,t:1527188796655};\\\", \\\"{x:1379,y:575,t:1527188796690};\\\", \\\"{x:1377,y:575,t:1527188796738};\\\", \\\"{x:1378,y:576,t:1527188798114};\\\", \\\"{x:1379,y:578,t:1527188798122};\\\", \\\"{x:1380,y:580,t:1527188798138};\\\", \\\"{x:1382,y:581,t:1527188798156};\\\", \\\"{x:1383,y:582,t:1527188798177};\\\", \\\"{x:1383,y:583,t:1527188798188};\\\", \\\"{x:1387,y:584,t:1527188798205};\\\", \\\"{x:1395,y:587,t:1527188798222};\\\", \\\"{x:1399,y:588,t:1527188798239};\\\", \\\"{x:1405,y:589,t:1527188798256};\\\", \\\"{x:1410,y:589,t:1527188798273};\\\", \\\"{x:1414,y:589,t:1527188798288};\\\", \\\"{x:1421,y:591,t:1527188798306};\\\", \\\"{x:1432,y:592,t:1527188798322};\\\", \\\"{x:1441,y:593,t:1527188798339};\\\", \\\"{x:1450,y:593,t:1527188798355};\\\", \\\"{x:1452,y:595,t:1527188798372};\\\", \\\"{x:1453,y:595,t:1527188798389};\\\", \\\"{x:1454,y:595,t:1527188798434};\\\", \\\"{x:1455,y:595,t:1527188798458};\\\", \\\"{x:1456,y:595,t:1527188798473};\\\", \\\"{x:1458,y:594,t:1527188798489};\\\", \\\"{x:1460,y:593,t:1527188798505};\\\", \\\"{x:1461,y:591,t:1527188798522};\\\", \\\"{x:1461,y:590,t:1527188798538};\\\", \\\"{x:1461,y:589,t:1527188798556};\\\", \\\"{x:1461,y:585,t:1527188798573};\\\", \\\"{x:1458,y:584,t:1527188798588};\\\", \\\"{x:1457,y:584,t:1527188798605};\\\", \\\"{x:1455,y:584,t:1527188798626};\\\", \\\"{x:1454,y:583,t:1527188798639};\\\", \\\"{x:1453,y:583,t:1527188798656};\\\", \\\"{x:1453,y:582,t:1527188798673};\\\", \\\"{x:1451,y:581,t:1527188798688};\\\", \\\"{x:1449,y:581,t:1527188798706};\\\", \\\"{x:1448,y:581,t:1527188798722};\\\", \\\"{x:1448,y:580,t:1527188798754};\\\", \\\"{x:1447,y:579,t:1527188798891};\\\", \\\"{x:1450,y:579,t:1527188800915};\\\", \\\"{x:1455,y:579,t:1527188800924};\\\", \\\"{x:1466,y:579,t:1527188800940};\\\", \\\"{x:1477,y:579,t:1527188800957};\\\", \\\"{x:1488,y:579,t:1527188800973};\\\", \\\"{x:1495,y:578,t:1527188800991};\\\", \\\"{x:1498,y:577,t:1527188801006};\\\", \\\"{x:1500,y:576,t:1527188801024};\\\", \\\"{x:1501,y:576,t:1527188801250};\\\", \\\"{x:1502,y:576,t:1527188801258};\\\", \\\"{x:1504,y:576,t:1527188801274};\\\", \\\"{x:1505,y:576,t:1527188801291};\\\", \\\"{x:1506,y:576,t:1527188801338};\\\", \\\"{x:1508,y:576,t:1527188801354};\\\", \\\"{x:1509,y:576,t:1527188801427};\\\", \\\"{x:1512,y:576,t:1527188801458};\\\", \\\"{x:1514,y:576,t:1527188801474};\\\", \\\"{x:1515,y:577,t:1527188801506};\\\", \\\"{x:1517,y:577,t:1527188801554};\\\", \\\"{x:1515,y:579,t:1527188803427};\\\", \\\"{x:1492,y:587,t:1527188803443};\\\", \\\"{x:1460,y:598,t:1527188803458};\\\", \\\"{x:1435,y:606,t:1527188803474};\\\", \\\"{x:1413,y:611,t:1527188803491};\\\", \\\"{x:1397,y:615,t:1527188803508};\\\", \\\"{x:1391,y:615,t:1527188803524};\\\", \\\"{x:1389,y:615,t:1527188803541};\\\", \\\"{x:1385,y:615,t:1527188803558};\\\", \\\"{x:1382,y:611,t:1527188803574};\\\", \\\"{x:1376,y:606,t:1527188803591};\\\", \\\"{x:1371,y:602,t:1527188803608};\\\", \\\"{x:1368,y:601,t:1527188803624};\\\", \\\"{x:1364,y:599,t:1527188803641};\\\", \\\"{x:1359,y:598,t:1527188803658};\\\", \\\"{x:1352,y:595,t:1527188803674};\\\", \\\"{x:1343,y:594,t:1527188803691};\\\", \\\"{x:1329,y:591,t:1527188803708};\\\", \\\"{x:1318,y:589,t:1527188803724};\\\", \\\"{x:1309,y:585,t:1527188803741};\\\", \\\"{x:1303,y:583,t:1527188803758};\\\", \\\"{x:1297,y:581,t:1527188803774};\\\", \\\"{x:1291,y:578,t:1527188803791};\\\", \\\"{x:1290,y:578,t:1527188803809};\\\", \\\"{x:1289,y:577,t:1527188803825};\\\", \\\"{x:1290,y:577,t:1527188803986};\\\", \\\"{x:1291,y:577,t:1527188803993};\\\", \\\"{x:1292,y:577,t:1527188804009};\\\", \\\"{x:1295,y:578,t:1527188804026};\\\", \\\"{x:1299,y:580,t:1527188804041};\\\", \\\"{x:1301,y:581,t:1527188804059};\\\", \\\"{x:1303,y:581,t:1527188804076};\\\", \\\"{x:1305,y:581,t:1527188804194};\\\", \\\"{x:1306,y:581,t:1527188804208};\\\", \\\"{x:1308,y:581,t:1527188804226};\\\", \\\"{x:1309,y:581,t:1527188804258};\\\", \\\"{x:1310,y:581,t:1527188804642};\\\", \\\"{x:1311,y:581,t:1527188804668};\\\", \\\"{x:1312,y:581,t:1527188804676};\\\", \\\"{x:1313,y:581,t:1527188804692};\\\", \\\"{x:1316,y:581,t:1527188804708};\\\", \\\"{x:1317,y:582,t:1527188804726};\\\", \\\"{x:1318,y:582,t:1527188804744};\\\", \\\"{x:1319,y:582,t:1527188804795};\\\", \\\"{x:1320,y:582,t:1527188804809};\\\", \\\"{x:1322,y:583,t:1527188804825};\\\", \\\"{x:1323,y:583,t:1527188804842};\\\", \\\"{x:1323,y:584,t:1527188804874};\\\", \\\"{x:1324,y:584,t:1527188804898};\\\", \\\"{x:1325,y:584,t:1527188804930};\\\", \\\"{x:1327,y:584,t:1527188804954};\\\", \\\"{x:1329,y:584,t:1527188804970};\\\", \\\"{x:1331,y:584,t:1527188804978};\\\", \\\"{x:1333,y:584,t:1527188804994};\\\", \\\"{x:1334,y:584,t:1527188805010};\\\", \\\"{x:1335,y:583,t:1527188805025};\\\", \\\"{x:1336,y:583,t:1527188805050};\\\", \\\"{x:1337,y:583,t:1527188805059};\\\", \\\"{x:1338,y:582,t:1527188805075};\\\", \\\"{x:1340,y:581,t:1527188805093};\\\", \\\"{x:1341,y:580,t:1527188805110};\\\", \\\"{x:1343,y:579,t:1527188805126};\\\", \\\"{x:1345,y:578,t:1527188805142};\\\", \\\"{x:1346,y:577,t:1527188805160};\\\", \\\"{x:1350,y:576,t:1527188805176};\\\", \\\"{x:1353,y:575,t:1527188805193};\\\", \\\"{x:1357,y:574,t:1527188805210};\\\", \\\"{x:1358,y:573,t:1527188805225};\\\", \\\"{x:1359,y:573,t:1527188805515};\\\", \\\"{x:1358,y:573,t:1527188805537};\\\", \\\"{x:1357,y:573,t:1527188805554};\\\", \\\"{x:1355,y:573,t:1527188805562};\\\", \\\"{x:1354,y:573,t:1527188805576};\\\", \\\"{x:1352,y:573,t:1527188805592};\\\", \\\"{x:1349,y:573,t:1527188805610};\\\", \\\"{x:1348,y:573,t:1527188805642};\\\", \\\"{x:1346,y:573,t:1527188805660};\\\", \\\"{x:1345,y:573,t:1527188805676};\\\", \\\"{x:1343,y:573,t:1527188805693};\\\", \\\"{x:1340,y:573,t:1527188805710};\\\", \\\"{x:1335,y:571,t:1527188805726};\\\", \\\"{x:1332,y:570,t:1527188805743};\\\", \\\"{x:1330,y:569,t:1527188805760};\\\", \\\"{x:1329,y:569,t:1527188805777};\\\", \\\"{x:1328,y:568,t:1527188805793};\\\", \\\"{x:1327,y:568,t:1527188805810};\\\", \\\"{x:1328,y:568,t:1527188805906};\\\", \\\"{x:1330,y:568,t:1527188805922};\\\", \\\"{x:1332,y:569,t:1527188805930};\\\", \\\"{x:1335,y:570,t:1527188805946};\\\", \\\"{x:1339,y:572,t:1527188805960};\\\", \\\"{x:1348,y:576,t:1527188805977};\\\", \\\"{x:1353,y:577,t:1527188805993};\\\", \\\"{x:1360,y:580,t:1527188806010};\\\", \\\"{x:1364,y:581,t:1527188806026};\\\", \\\"{x:1366,y:582,t:1527188806082};\\\", \\\"{x:1367,y:582,t:1527188806098};\\\", \\\"{x:1369,y:582,t:1527188806227};\\\", \\\"{x:1370,y:582,t:1527188806250};\\\", \\\"{x:1371,y:582,t:1527188806266};\\\", \\\"{x:1373,y:581,t:1527188806277};\\\", \\\"{x:1379,y:579,t:1527188806293};\\\", \\\"{x:1381,y:579,t:1527188806310};\\\", \\\"{x:1383,y:579,t:1527188806327};\\\", \\\"{x:1384,y:578,t:1527188806343};\\\", \\\"{x:1386,y:578,t:1527188806386};\\\", \\\"{x:1389,y:578,t:1527188806393};\\\", \\\"{x:1390,y:578,t:1527188806410};\\\", \\\"{x:1395,y:576,t:1527188806426};\\\", \\\"{x:1398,y:576,t:1527188806444};\\\", \\\"{x:1401,y:575,t:1527188806460};\\\", \\\"{x:1409,y:574,t:1527188806477};\\\", \\\"{x:1421,y:572,t:1527188806494};\\\", \\\"{x:1437,y:571,t:1527188806510};\\\", \\\"{x:1446,y:570,t:1527188806527};\\\", \\\"{x:1452,y:569,t:1527188806544};\\\", \\\"{x:1452,y:568,t:1527188806746};\\\", \\\"{x:1450,y:568,t:1527188806770};\\\", \\\"{x:1449,y:568,t:1527188806778};\\\", \\\"{x:1448,y:570,t:1527188806794};\\\", \\\"{x:1447,y:573,t:1527188806809};\\\", \\\"{x:1445,y:575,t:1527188806827};\\\", \\\"{x:1445,y:578,t:1527188806844};\\\", \\\"{x:1445,y:580,t:1527188806859};\\\", \\\"{x:1445,y:581,t:1527188806877};\\\", \\\"{x:1445,y:583,t:1527188806894};\\\", \\\"{x:1445,y:584,t:1527188807066};\\\", \\\"{x:1446,y:584,t:1527188807082};\\\", \\\"{x:1451,y:584,t:1527188807094};\\\", \\\"{x:1458,y:585,t:1527188807112};\\\", \\\"{x:1467,y:586,t:1527188807127};\\\", \\\"{x:1474,y:586,t:1527188807144};\\\", \\\"{x:1481,y:587,t:1527188807161};\\\", \\\"{x:1486,y:587,t:1527188807177};\\\", \\\"{x:1491,y:587,t:1527188807193};\\\", \\\"{x:1494,y:587,t:1527188807210};\\\", \\\"{x:1498,y:587,t:1527188807227};\\\", \\\"{x:1503,y:586,t:1527188807243};\\\", \\\"{x:1507,y:585,t:1527188807260};\\\", \\\"{x:1509,y:584,t:1527188807277};\\\", \\\"{x:1509,y:583,t:1527188807363};\\\", \\\"{x:1510,y:583,t:1527188807377};\\\", \\\"{x:1514,y:581,t:1527188807394};\\\", \\\"{x:1517,y:581,t:1527188807410};\\\", \\\"{x:1518,y:580,t:1527188807433};\\\", \\\"{x:1519,y:579,t:1527188807449};\\\", \\\"{x:1521,y:579,t:1527188807467};\\\", \\\"{x:1521,y:577,t:1527188807482};\\\", \\\"{x:1526,y:576,t:1527188808395};\\\", \\\"{x:1536,y:580,t:1527188808410};\\\", \\\"{x:1546,y:582,t:1527188808427};\\\", \\\"{x:1556,y:583,t:1527188808444};\\\", \\\"{x:1563,y:584,t:1527188808460};\\\", \\\"{x:1568,y:584,t:1527188808477};\\\", \\\"{x:1573,y:584,t:1527188808494};\\\", \\\"{x:1582,y:584,t:1527188808510};\\\", \\\"{x:1590,y:584,t:1527188808528};\\\", \\\"{x:1599,y:584,t:1527188808545};\\\", \\\"{x:1604,y:584,t:1527188808560};\\\", \\\"{x:1605,y:587,t:1527188809945};\\\", \\\"{x:1605,y:600,t:1527188809961};\\\", \\\"{x:1600,y:615,t:1527188809978};\\\", \\\"{x:1595,y:631,t:1527188809994};\\\", \\\"{x:1594,y:648,t:1527188810011};\\\", \\\"{x:1592,y:665,t:1527188810028};\\\", \\\"{x:1592,y:678,t:1527188810045};\\\", \\\"{x:1590,y:696,t:1527188810061};\\\", \\\"{x:1587,y:712,t:1527188810078};\\\", \\\"{x:1583,y:726,t:1527188810095};\\\", \\\"{x:1579,y:734,t:1527188810111};\\\", \\\"{x:1574,y:746,t:1527188810128};\\\", \\\"{x:1572,y:760,t:1527188810144};\\\", \\\"{x:1555,y:783,t:1527188810161};\\\", \\\"{x:1544,y:789,t:1527188810178};\\\", \\\"{x:1530,y:798,t:1527188810195};\\\", \\\"{x:1527,y:801,t:1527188810211};\\\", \\\"{x:1523,y:805,t:1527188810228};\\\", \\\"{x:1521,y:808,t:1527188810245};\\\", \\\"{x:1518,y:812,t:1527188810261};\\\", \\\"{x:1517,y:813,t:1527188810279};\\\", \\\"{x:1515,y:816,t:1527188810295};\\\", \\\"{x:1514,y:817,t:1527188810312};\\\", \\\"{x:1514,y:819,t:1527188810329};\\\", \\\"{x:1511,y:823,t:1527188810345};\\\", \\\"{x:1510,y:826,t:1527188810362};\\\", \\\"{x:1507,y:836,t:1527188810378};\\\", \\\"{x:1503,y:849,t:1527188810395};\\\", \\\"{x:1503,y:861,t:1527188810412};\\\", \\\"{x:1503,y:876,t:1527188810429};\\\", \\\"{x:1513,y:893,t:1527188810446};\\\", \\\"{x:1516,y:900,t:1527188810461};\\\", \\\"{x:1520,y:907,t:1527188810479};\\\", \\\"{x:1526,y:916,t:1527188810495};\\\", \\\"{x:1534,y:927,t:1527188810512};\\\", \\\"{x:1544,y:939,t:1527188810530};\\\", \\\"{x:1546,y:944,t:1527188810545};\\\", \\\"{x:1546,y:945,t:1527188810562};\\\", \\\"{x:1547,y:945,t:1527188810650};\\\", \\\"{x:1549,y:945,t:1527188810662};\\\", \\\"{x:1553,y:942,t:1527188810678};\\\", \\\"{x:1559,y:938,t:1527188810695};\\\", \\\"{x:1568,y:931,t:1527188810711};\\\", \\\"{x:1579,y:923,t:1527188810728};\\\", \\\"{x:1591,y:914,t:1527188810744};\\\", \\\"{x:1594,y:910,t:1527188810762};\\\", \\\"{x:1598,y:906,t:1527188810778};\\\", \\\"{x:1599,y:904,t:1527188810796};\\\", \\\"{x:1600,y:902,t:1527188810811};\\\", \\\"{x:1601,y:900,t:1527188810828};\\\", \\\"{x:1603,y:900,t:1527188810922};\\\", \\\"{x:1605,y:903,t:1527188810930};\\\", \\\"{x:1612,y:914,t:1527188810946};\\\", \\\"{x:1616,y:918,t:1527188810963};\\\", \\\"{x:1618,y:918,t:1527188810978};\\\", \\\"{x:1618,y:919,t:1527188811058};\\\", \\\"{x:1619,y:919,t:1527188811234};\\\", \\\"{x:1619,y:917,t:1527188811246};\\\", \\\"{x:1619,y:914,t:1527188811264};\\\", \\\"{x:1619,y:912,t:1527188811279};\\\", \\\"{x:1619,y:911,t:1527188811297};\\\", \\\"{x:1619,y:910,t:1527188811313};\\\", \\\"{x:1618,y:909,t:1527188811466};\\\", \\\"{x:1617,y:909,t:1527188811481};\\\", \\\"{x:1616,y:909,t:1527188811513};\\\", \\\"{x:1615,y:909,t:1527188811577};\\\", \\\"{x:1614,y:909,t:1527188811593};\\\", \\\"{x:1613,y:909,t:1527188811601};\\\", \\\"{x:1612,y:909,t:1527188811666};\\\", \\\"{x:1610,y:909,t:1527188811680};\\\", \\\"{x:1608,y:909,t:1527188811696};\\\", \\\"{x:1607,y:909,t:1527188811713};\\\", \\\"{x:1606,y:909,t:1527188811730};\\\", \\\"{x:1606,y:910,t:1527188811746};\\\", \\\"{x:1605,y:910,t:1527188811810};\\\", \\\"{x:1607,y:910,t:1527188812058};\\\", \\\"{x:1607,y:909,t:1527188812066};\\\", \\\"{x:1609,y:909,t:1527188812881};\\\", \\\"{x:1611,y:909,t:1527188812897};\\\", \\\"{x:1613,y:909,t:1527188812914};\\\", \\\"{x:1614,y:909,t:1527188812986};\\\", \\\"{x:1614,y:908,t:1527188813650};\\\", \\\"{x:1614,y:905,t:1527188813664};\\\", \\\"{x:1614,y:896,t:1527188813681};\\\", \\\"{x:1612,y:891,t:1527188813696};\\\", \\\"{x:1609,y:879,t:1527188813713};\\\", \\\"{x:1602,y:866,t:1527188813730};\\\", \\\"{x:1593,y:851,t:1527188813747};\\\", \\\"{x:1584,y:832,t:1527188813763};\\\", \\\"{x:1579,y:820,t:1527188813780};\\\", \\\"{x:1577,y:814,t:1527188813797};\\\", \\\"{x:1576,y:806,t:1527188813813};\\\", \\\"{x:1575,y:797,t:1527188813831};\\\", \\\"{x:1575,y:793,t:1527188813847};\\\", \\\"{x:1573,y:789,t:1527188813863};\\\", \\\"{x:1572,y:785,t:1527188813881};\\\", \\\"{x:1572,y:782,t:1527188813896};\\\", \\\"{x:1573,y:777,t:1527188813913};\\\", \\\"{x:1574,y:775,t:1527188813931};\\\", \\\"{x:1575,y:773,t:1527188813946};\\\", \\\"{x:1577,y:772,t:1527188813963};\\\", \\\"{x:1579,y:771,t:1527188813981};\\\", \\\"{x:1581,y:772,t:1527188814026};\\\", \\\"{x:1582,y:774,t:1527188814034};\\\", \\\"{x:1585,y:778,t:1527188814046};\\\", \\\"{x:1591,y:783,t:1527188814063};\\\", \\\"{x:1594,y:785,t:1527188814081};\\\", \\\"{x:1596,y:786,t:1527188814097};\\\", \\\"{x:1597,y:787,t:1527188814138};\\\", \\\"{x:1598,y:787,t:1527188814148};\\\", \\\"{x:1601,y:787,t:1527188814164};\\\", \\\"{x:1604,y:787,t:1527188814180};\\\", \\\"{x:1605,y:787,t:1527188814198};\\\", \\\"{x:1607,y:787,t:1527188814330};\\\", \\\"{x:1608,y:787,t:1527188814348};\\\", \\\"{x:1609,y:786,t:1527188814364};\\\", \\\"{x:1610,y:785,t:1527188814386};\\\", \\\"{x:1611,y:785,t:1527188814398};\\\", \\\"{x:1612,y:783,t:1527188814414};\\\", \\\"{x:1612,y:782,t:1527188814431};\\\", \\\"{x:1613,y:781,t:1527188814448};\\\", \\\"{x:1614,y:780,t:1527188814465};\\\", \\\"{x:1615,y:780,t:1527188814498};\\\", \\\"{x:1616,y:780,t:1527188814515};\\\", \\\"{x:1618,y:778,t:1527188814538};\\\", \\\"{x:1619,y:778,t:1527188814548};\\\", \\\"{x:1620,y:778,t:1527188814635};\\\", \\\"{x:1620,y:777,t:1527188814648};\\\", \\\"{x:1620,y:776,t:1527188814667};\\\", \\\"{x:1620,y:775,t:1527188814682};\\\", \\\"{x:1617,y:775,t:1527188815530};\\\", \\\"{x:1616,y:775,t:1527188815546};\\\", \\\"{x:1615,y:775,t:1527188815554};\\\", \\\"{x:1613,y:775,t:1527188815566};\\\", \\\"{x:1612,y:776,t:1527188815583};\\\", \\\"{x:1610,y:776,t:1527188815598};\\\", \\\"{x:1609,y:778,t:1527188815615};\\\", \\\"{x:1605,y:779,t:1527188815632};\\\", \\\"{x:1597,y:782,t:1527188815648};\\\", \\\"{x:1589,y:784,t:1527188815665};\\\", \\\"{x:1570,y:787,t:1527188815682};\\\", \\\"{x:1556,y:789,t:1527188815698};\\\", \\\"{x:1540,y:792,t:1527188815715};\\\", \\\"{x:1521,y:794,t:1527188815733};\\\", \\\"{x:1503,y:795,t:1527188815749};\\\", \\\"{x:1493,y:798,t:1527188815765};\\\", \\\"{x:1489,y:798,t:1527188815783};\\\", \\\"{x:1488,y:799,t:1527188815798};\\\", \\\"{x:1488,y:798,t:1527188815914};\\\", \\\"{x:1490,y:797,t:1527188815932};\\\", \\\"{x:1491,y:796,t:1527188815948};\\\", \\\"{x:1492,y:795,t:1527188815965};\\\", \\\"{x:1492,y:794,t:1527188815982};\\\", \\\"{x:1492,y:793,t:1527188815999};\\\", \\\"{x:1492,y:792,t:1527188816015};\\\", \\\"{x:1492,y:791,t:1527188816033};\\\", \\\"{x:1492,y:789,t:1527188816049};\\\", \\\"{x:1492,y:788,t:1527188816066};\\\", \\\"{x:1492,y:787,t:1527188816081};\\\", \\\"{x:1491,y:786,t:1527188816099};\\\", \\\"{x:1489,y:785,t:1527188816115};\\\", \\\"{x:1488,y:785,t:1527188816138};\\\", \\\"{x:1487,y:784,t:1527188816149};\\\", \\\"{x:1485,y:783,t:1527188816210};\\\", \\\"{x:1485,y:782,t:1527188816274};\\\", \\\"{x:1484,y:782,t:1527188816626};\\\", \\\"{x:1483,y:782,t:1527188816634};\\\", \\\"{x:1482,y:782,t:1527188816649};\\\", \\\"{x:1481,y:782,t:1527188816665};\\\", \\\"{x:1481,y:780,t:1527188816930};\\\", \\\"{x:1481,y:779,t:1527188816962};\\\", \\\"{x:1482,y:778,t:1527188816986};\\\", \\\"{x:1483,y:778,t:1527188817001};\\\", \\\"{x:1485,y:778,t:1527188817049};\\\", \\\"{x:1493,y:779,t:1527188817066};\\\", \\\"{x:1506,y:782,t:1527188817082};\\\", \\\"{x:1523,y:787,t:1527188817099};\\\", \\\"{x:1541,y:789,t:1527188817116};\\\", \\\"{x:1552,y:790,t:1527188817132};\\\", \\\"{x:1555,y:790,t:1527188817150};\\\", \\\"{x:1556,y:790,t:1527188817167};\\\", \\\"{x:1556,y:788,t:1527188817218};\\\", \\\"{x:1556,y:787,t:1527188817241};\\\", \\\"{x:1558,y:785,t:1527188817258};\\\", \\\"{x:1558,y:784,t:1527188817266};\\\", \\\"{x:1558,y:783,t:1527188817283};\\\", \\\"{x:1558,y:782,t:1527188817299};\\\", \\\"{x:1558,y:781,t:1527188817316};\\\", \\\"{x:1558,y:779,t:1527188817333};\\\", \\\"{x:1556,y:778,t:1527188817378};\\\", \\\"{x:1555,y:778,t:1527188817410};\\\", \\\"{x:1554,y:778,t:1527188817417};\\\", \\\"{x:1553,y:777,t:1527188817434};\\\", \\\"{x:1551,y:776,t:1527188817449};\\\", \\\"{x:1550,y:775,t:1527188817468};\\\", \\\"{x:1549,y:775,t:1527188817482};\\\", \\\"{x:1548,y:774,t:1527188817499};\\\", \\\"{x:1547,y:774,t:1527188817521};\\\", \\\"{x:1545,y:774,t:1527188817553};\\\", \\\"{x:1547,y:774,t:1527188817714};\\\", \\\"{x:1549,y:774,t:1527188817722};\\\", \\\"{x:1550,y:775,t:1527188817734};\\\", \\\"{x:1553,y:776,t:1527188817749};\\\", \\\"{x:1560,y:778,t:1527188817766};\\\", \\\"{x:1566,y:779,t:1527188817782};\\\", \\\"{x:1572,y:779,t:1527188817799};\\\", \\\"{x:1578,y:780,t:1527188817816};\\\", \\\"{x:1585,y:780,t:1527188817833};\\\", \\\"{x:1588,y:782,t:1527188817849};\\\", \\\"{x:1589,y:782,t:1527188817867};\\\", \\\"{x:1591,y:782,t:1527188817883};\\\", \\\"{x:1592,y:782,t:1527188817900};\\\", \\\"{x:1593,y:782,t:1527188817916};\\\", \\\"{x:1594,y:782,t:1527188817933};\\\", \\\"{x:1596,y:782,t:1527188817951};\\\", \\\"{x:1598,y:781,t:1527188817966};\\\", \\\"{x:1605,y:780,t:1527188817984};\\\", \\\"{x:1613,y:778,t:1527188818000};\\\", \\\"{x:1617,y:778,t:1527188818016};\\\", \\\"{x:1620,y:777,t:1527188818034};\\\", \\\"{x:1617,y:775,t:1527188819601};\\\", \\\"{x:1531,y:748,t:1527188819617};\\\", \\\"{x:1404,y:734,t:1527188819633};\\\", \\\"{x:1240,y:740,t:1527188819650};\\\", \\\"{x:1063,y:760,t:1527188819668};\\\", \\\"{x:924,y:761,t:1527188819684};\\\", \\\"{x:814,y:751,t:1527188819699};\\\", \\\"{x:739,y:739,t:1527188819716};\\\", \\\"{x:717,y:728,t:1527188819734};\\\", \\\"{x:715,y:725,t:1527188819750};\\\", \\\"{x:717,y:720,t:1527188819767};\\\", \\\"{x:728,y:709,t:1527188819784};\\\", \\\"{x:742,y:698,t:1527188819800};\\\", \\\"{x:755,y:678,t:1527188819817};\\\", \\\"{x:757,y:663,t:1527188819834};\\\", \\\"{x:757,y:652,t:1527188819851};\\\", \\\"{x:751,y:641,t:1527188819868};\\\", \\\"{x:751,y:637,t:1527188819884};\\\", \\\"{x:750,y:633,t:1527188819901};\\\", \\\"{x:750,y:632,t:1527188819919};\\\", \\\"{x:747,y:630,t:1527188819934};\\\", \\\"{x:737,y:623,t:1527188819950};\\\", \\\"{x:719,y:614,t:1527188819966};\\\", \\\"{x:697,y:596,t:1527188819985};\\\", \\\"{x:664,y:573,t:1527188820000};\\\", \\\"{x:653,y:564,t:1527188820017};\\\", \\\"{x:652,y:562,t:1527188820032};\\\", \\\"{x:647,y:558,t:1527188820050};\\\", \\\"{x:646,y:556,t:1527188820066};\\\", \\\"{x:645,y:555,t:1527188820082};\\\", \\\"{x:644,y:550,t:1527188820099};\\\", \\\"{x:640,y:547,t:1527188820116};\\\", \\\"{x:636,y:543,t:1527188820132};\\\", \\\"{x:636,y:542,t:1527188820148};\\\", \\\"{x:635,y:542,t:1527188820184};\\\", \\\"{x:634,y:545,t:1527188820289};\\\", \\\"{x:633,y:546,t:1527188820299};\\\", \\\"{x:632,y:547,t:1527188820316};\\\", \\\"{x:629,y:550,t:1527188820332};\\\", \\\"{x:628,y:551,t:1527188820348};\\\", \\\"{x:627,y:552,t:1527188820366};\\\", \\\"{x:625,y:552,t:1527188820383};\\\", \\\"{x:622,y:552,t:1527188820398};\\\", \\\"{x:620,y:552,t:1527188820417};\\\", \\\"{x:619,y:553,t:1527188820809};\\\", \\\"{x:619,y:555,t:1527188820840};\\\", \\\"{x:619,y:561,t:1527188820850};\\\", \\\"{x:619,y:574,t:1527188820866};\\\", \\\"{x:618,y:595,t:1527188820883};\\\", \\\"{x:618,y:611,t:1527188820900};\\\", \\\"{x:617,y:619,t:1527188820916};\\\", \\\"{x:617,y:623,t:1527188820933};\\\", \\\"{x:614,y:627,t:1527188820949};\\\", \\\"{x:610,y:631,t:1527188820965};\\\", \\\"{x:602,y:637,t:1527188820982};\\\", \\\"{x:595,y:642,t:1527188821000};\\\", \\\"{x:587,y:646,t:1527188821015};\\\", \\\"{x:576,y:649,t:1527188821033};\\\", \\\"{x:567,y:649,t:1527188821049};\\\", \\\"{x:553,y:649,t:1527188821067};\\\", \\\"{x:538,y:649,t:1527188821083};\\\", \\\"{x:522,y:649,t:1527188821099};\\\", \\\"{x:508,y:651,t:1527188821116};\\\", \\\"{x:504,y:653,t:1527188821133};\\\", \\\"{x:503,y:653,t:1527188821150};\\\", \\\"{x:503,y:654,t:1527188821241};\\\", \\\"{x:503,y:657,t:1527188821250};\\\", \\\"{x:503,y:658,t:1527188821267};\\\", \\\"{x:503,y:660,t:1527188821283};\\\", \\\"{x:503,y:663,t:1527188821300};\\\", \\\"{x:503,y:665,t:1527188821317};\\\", \\\"{x:503,y:667,t:1527188821333};\\\", \\\"{x:503,y:669,t:1527188821350};\\\" ] }, { \\\"rt\\\": 116211, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 325214, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -I -I -O -O -I -I -I -I -I -I -H -O -O -F -F -F -F -F -F -F -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:669,t:1527188826698};\\\", \\\"{x:506,y:669,t:1527188831066};\\\", \\\"{x:515,y:669,t:1527188831074};\\\", \\\"{x:540,y:669,t:1527188831092};\\\", \\\"{x:582,y:669,t:1527188831109};\\\", \\\"{x:630,y:669,t:1527188831124};\\\", \\\"{x:666,y:669,t:1527188831141};\\\", \\\"{x:707,y:669,t:1527188831158};\\\", \\\"{x:773,y:676,t:1527188831175};\\\", \\\"{x:867,y:688,t:1527188831191};\\\", \\\"{x:988,y:700,t:1527188831209};\\\", \\\"{x:1163,y:700,t:1527188831225};\\\", \\\"{x:1254,y:700,t:1527188831241};\\\", \\\"{x:1324,y:700,t:1527188831258};\\\", \\\"{x:1380,y:700,t:1527188831276};\\\", \\\"{x:1410,y:700,t:1527188831292};\\\", \\\"{x:1427,y:700,t:1527188831308};\\\", \\\"{x:1434,y:700,t:1527188831326};\\\", \\\"{x:1435,y:700,t:1527188831410};\\\", \\\"{x:1435,y:701,t:1527188831450};\\\", \\\"{x:1435,y:702,t:1527188831458};\\\", \\\"{x:1436,y:703,t:1527188831475};\\\", \\\"{x:1437,y:705,t:1527188831493};\\\", \\\"{x:1437,y:711,t:1527188831508};\\\", \\\"{x:1437,y:713,t:1527188831525};\\\", \\\"{x:1437,y:714,t:1527188831543};\\\", \\\"{x:1436,y:714,t:1527188832010};\\\", \\\"{x:1415,y:696,t:1527188832026};\\\", \\\"{x:1393,y:680,t:1527188832043};\\\", \\\"{x:1382,y:668,t:1527188832060};\\\", \\\"{x:1372,y:652,t:1527188832076};\\\", \\\"{x:1364,y:634,t:1527188832093};\\\", \\\"{x:1359,y:613,t:1527188832110};\\\", \\\"{x:1352,y:590,t:1527188832127};\\\", \\\"{x:1344,y:562,t:1527188832144};\\\", \\\"{x:1341,y:539,t:1527188832160};\\\", \\\"{x:1337,y:521,t:1527188832177};\\\", \\\"{x:1336,y:510,t:1527188832194};\\\", \\\"{x:1336,y:506,t:1527188832210};\\\", \\\"{x:1334,y:503,t:1527188832227};\\\", \\\"{x:1333,y:497,t:1527188832244};\\\", \\\"{x:1327,y:488,t:1527188832260};\\\", \\\"{x:1319,y:478,t:1527188832277};\\\", \\\"{x:1308,y:468,t:1527188832294};\\\", \\\"{x:1302,y:460,t:1527188832309};\\\", \\\"{x:1301,y:454,t:1527188832327};\\\", \\\"{x:1300,y:451,t:1527188832343};\\\", \\\"{x:1300,y:450,t:1527188832393};\\\", \\\"{x:1298,y:447,t:1527188832411};\\\", \\\"{x:1297,y:444,t:1527188832427};\\\", \\\"{x:1297,y:443,t:1527188832444};\\\", \\\"{x:1297,y:442,t:1527188832595};\\\", \\\"{x:1304,y:441,t:1527188832610};\\\", \\\"{x:1309,y:441,t:1527188832629};\\\", \\\"{x:1313,y:441,t:1527188832644};\\\", \\\"{x:1314,y:440,t:1527188832661};\\\", \\\"{x:1315,y:444,t:1527188835256};\\\", \\\"{x:1315,y:452,t:1527188835264};\\\", \\\"{x:1315,y:463,t:1527188835280};\\\", \\\"{x:1316,y:466,t:1527188835297};\\\", \\\"{x:1325,y:469,t:1527188835809};\\\", \\\"{x:1332,y:471,t:1527188835817};\\\", \\\"{x:1333,y:471,t:1527188835831};\\\", \\\"{x:1330,y:467,t:1527188837387};\\\", \\\"{x:1315,y:458,t:1527188837400};\\\", \\\"{x:1298,y:454,t:1527188837417};\\\", \\\"{x:1278,y:463,t:1527188837432};\\\", \\\"{x:1238,y:485,t:1527188837449};\\\", \\\"{x:1170,y:524,t:1527188837466};\\\", \\\"{x:1126,y:546,t:1527188837482};\\\", \\\"{x:1126,y:549,t:1527188837946};\\\", \\\"{x:1127,y:550,t:1527188837953};\\\", \\\"{x:1129,y:551,t:1527188837967};\\\", \\\"{x:1142,y:553,t:1527188837984};\\\", \\\"{x:1167,y:553,t:1527188838002};\\\", \\\"{x:1183,y:549,t:1527188838018};\\\", \\\"{x:1195,y:541,t:1527188838034};\\\", \\\"{x:1209,y:532,t:1527188838051};\\\", \\\"{x:1218,y:525,t:1527188838068};\\\", \\\"{x:1230,y:516,t:1527188838084};\\\", \\\"{x:1241,y:502,t:1527188838100};\\\", \\\"{x:1252,y:489,t:1527188838118};\\\", \\\"{x:1263,y:475,t:1527188838133};\\\", \\\"{x:1269,y:458,t:1527188838150};\\\", \\\"{x:1274,y:446,t:1527188838168};\\\", \\\"{x:1279,y:434,t:1527188838184};\\\", \\\"{x:1286,y:422,t:1527188838200};\\\", \\\"{x:1288,y:418,t:1527188838218};\\\", \\\"{x:1288,y:417,t:1527188838297};\\\", \\\"{x:1286,y:417,t:1527188838361};\\\", \\\"{x:1282,y:417,t:1527188838370};\\\", \\\"{x:1279,y:420,t:1527188838384};\\\", \\\"{x:1278,y:422,t:1527188838400};\\\", \\\"{x:1275,y:426,t:1527188838417};\\\", \\\"{x:1275,y:429,t:1527188838434};\\\", \\\"{x:1275,y:435,t:1527188838450};\\\", \\\"{x:1275,y:438,t:1527188838467};\\\", \\\"{x:1276,y:438,t:1527188838537};\\\", \\\"{x:1279,y:438,t:1527188838550};\\\", \\\"{x:1292,y:440,t:1527188838568};\\\", \\\"{x:1312,y:441,t:1527188838585};\\\", \\\"{x:1326,y:444,t:1527188838602};\\\", \\\"{x:1337,y:446,t:1527188838618};\\\", \\\"{x:1342,y:448,t:1527188838635};\\\", \\\"{x:1343,y:449,t:1527188838651};\\\", \\\"{x:1342,y:449,t:1527188839569};\\\", \\\"{x:1339,y:449,t:1527188839585};\\\", \\\"{x:1333,y:452,t:1527188839603};\\\", \\\"{x:1329,y:452,t:1527188839618};\\\", \\\"{x:1323,y:452,t:1527188839636};\\\", \\\"{x:1322,y:453,t:1527188839652};\\\", \\\"{x:1321,y:452,t:1527188839818};\\\", \\\"{x:1320,y:452,t:1527188839825};\\\", \\\"{x:1319,y:451,t:1527188839836};\\\", \\\"{x:1319,y:450,t:1527188839864};\\\", \\\"{x:1318,y:450,t:1527188839873};\\\", \\\"{x:1316,y:448,t:1527188839904};\\\", \\\"{x:1315,y:447,t:1527188839936};\\\", \\\"{x:1314,y:446,t:1527188839953};\\\", \\\"{x:1314,y:445,t:1527188839969};\\\", \\\"{x:1313,y:445,t:1527188839986};\\\", \\\"{x:1313,y:444,t:1527188840002};\\\", \\\"{x:1313,y:446,t:1527188845241};\\\", \\\"{x:1313,y:449,t:1527188845248};\\\", \\\"{x:1312,y:453,t:1527188845260};\\\", \\\"{x:1312,y:460,t:1527188845275};\\\", \\\"{x:1312,y:467,t:1527188845293};\\\", \\\"{x:1312,y:473,t:1527188845310};\\\", \\\"{x:1312,y:475,t:1527188845326};\\\", \\\"{x:1312,y:477,t:1527188845343};\\\", \\\"{x:1312,y:478,t:1527188845360};\\\", \\\"{x:1312,y:480,t:1527188845377};\\\", \\\"{x:1312,y:481,t:1527188845401};\\\", \\\"{x:1312,y:482,t:1527188845418};\\\", \\\"{x:1312,y:483,t:1527188845433};\\\", \\\"{x:1312,y:484,t:1527188845448};\\\", \\\"{x:1312,y:485,t:1527188845460};\\\", \\\"{x:1312,y:487,t:1527188845476};\\\", \\\"{x:1312,y:489,t:1527188845493};\\\", \\\"{x:1312,y:492,t:1527188845509};\\\", \\\"{x:1312,y:493,t:1527188845527};\\\", \\\"{x:1312,y:497,t:1527188845543};\\\", \\\"{x:1312,y:500,t:1527188845561};\\\", \\\"{x:1312,y:508,t:1527188845577};\\\", \\\"{x:1312,y:513,t:1527188845594};\\\", \\\"{x:1312,y:517,t:1527188845610};\\\", \\\"{x:1312,y:518,t:1527188845627};\\\", \\\"{x:1312,y:521,t:1527188845644};\\\", \\\"{x:1312,y:523,t:1527188845660};\\\", \\\"{x:1312,y:524,t:1527188845677};\\\", \\\"{x:1312,y:526,t:1527188845694};\\\", \\\"{x:1312,y:530,t:1527188845710};\\\", \\\"{x:1312,y:533,t:1527188845727};\\\", \\\"{x:1312,y:539,t:1527188845744};\\\", \\\"{x:1314,y:546,t:1527188845760};\\\", \\\"{x:1315,y:555,t:1527188845777};\\\", \\\"{x:1316,y:563,t:1527188845795};\\\", \\\"{x:1317,y:570,t:1527188845810};\\\", \\\"{x:1318,y:576,t:1527188845827};\\\", \\\"{x:1319,y:583,t:1527188845845};\\\", \\\"{x:1321,y:590,t:1527188845861};\\\", \\\"{x:1321,y:595,t:1527188845877};\\\", \\\"{x:1322,y:599,t:1527188845894};\\\", \\\"{x:1322,y:603,t:1527188845911};\\\", \\\"{x:1322,y:605,t:1527188845927};\\\", \\\"{x:1322,y:606,t:1527188845944};\\\", \\\"{x:1322,y:608,t:1527188845961};\\\", \\\"{x:1322,y:609,t:1527188845977};\\\", \\\"{x:1322,y:611,t:1527188845994};\\\", \\\"{x:1322,y:613,t:1527188846010};\\\", \\\"{x:1322,y:615,t:1527188846026};\\\", \\\"{x:1322,y:619,t:1527188846044};\\\", \\\"{x:1322,y:622,t:1527188846060};\\\", \\\"{x:1322,y:629,t:1527188846077};\\\", \\\"{x:1322,y:634,t:1527188846093};\\\", \\\"{x:1321,y:638,t:1527188846111};\\\", \\\"{x:1321,y:642,t:1527188846128};\\\", \\\"{x:1320,y:646,t:1527188846144};\\\", \\\"{x:1320,y:650,t:1527188846161};\\\", \\\"{x:1320,y:651,t:1527188846178};\\\", \\\"{x:1318,y:655,t:1527188846193};\\\", \\\"{x:1318,y:657,t:1527188846211};\\\", \\\"{x:1318,y:658,t:1527188846227};\\\", \\\"{x:1318,y:660,t:1527188846243};\\\", \\\"{x:1318,y:661,t:1527188846261};\\\", \\\"{x:1318,y:663,t:1527188846278};\\\", \\\"{x:1318,y:665,t:1527188846295};\\\", \\\"{x:1318,y:667,t:1527188846311};\\\", \\\"{x:1318,y:670,t:1527188846328};\\\", \\\"{x:1318,y:673,t:1527188846345};\\\", \\\"{x:1318,y:677,t:1527188846361};\\\", \\\"{x:1318,y:681,t:1527188846378};\\\", \\\"{x:1318,y:684,t:1527188846394};\\\", \\\"{x:1318,y:689,t:1527188846411};\\\", \\\"{x:1317,y:695,t:1527188846429};\\\", \\\"{x:1316,y:700,t:1527188846445};\\\", \\\"{x:1314,y:707,t:1527188846461};\\\", \\\"{x:1312,y:715,t:1527188846478};\\\", \\\"{x:1310,y:721,t:1527188846496};\\\", \\\"{x:1309,y:727,t:1527188846511};\\\", \\\"{x:1309,y:733,t:1527188846528};\\\", \\\"{x:1306,y:739,t:1527188846545};\\\", \\\"{x:1306,y:740,t:1527188846560};\\\", \\\"{x:1306,y:741,t:1527188846578};\\\", \\\"{x:1305,y:742,t:1527188846617};\\\", \\\"{x:1305,y:743,t:1527188846841};\\\", \\\"{x:1305,y:744,t:1527188846848};\\\", \\\"{x:1305,y:745,t:1527188846862};\\\", \\\"{x:1305,y:747,t:1527188846877};\\\", \\\"{x:1305,y:749,t:1527188846895};\\\", \\\"{x:1305,y:751,t:1527188846912};\\\", \\\"{x:1305,y:754,t:1527188846928};\\\", \\\"{x:1305,y:755,t:1527188846946};\\\", \\\"{x:1305,y:756,t:1527188846969};\\\", \\\"{x:1305,y:757,t:1527188846994};\\\", \\\"{x:1306,y:758,t:1527188847001};\\\", \\\"{x:1306,y:760,t:1527188847012};\\\", \\\"{x:1306,y:761,t:1527188847029};\\\", \\\"{x:1307,y:764,t:1527188847045};\\\", \\\"{x:1309,y:768,t:1527188847062};\\\", \\\"{x:1309,y:772,t:1527188847079};\\\", \\\"{x:1309,y:775,t:1527188847095};\\\", \\\"{x:1310,y:778,t:1527188847112};\\\", \\\"{x:1310,y:779,t:1527188847129};\\\", \\\"{x:1310,y:780,t:1527188847153};\\\", \\\"{x:1310,y:781,t:1527188847169};\\\", \\\"{x:1310,y:782,t:1527188847193};\\\", \\\"{x:1310,y:783,t:1527188847201};\\\", \\\"{x:1310,y:784,t:1527188847217};\\\", \\\"{x:1310,y:785,t:1527188847241};\\\", \\\"{x:1310,y:786,t:1527188847250};\\\", \\\"{x:1311,y:787,t:1527188847265};\\\", \\\"{x:1311,y:788,t:1527188847281};\\\", \\\"{x:1311,y:790,t:1527188847297};\\\", \\\"{x:1311,y:792,t:1527188847312};\\\", \\\"{x:1312,y:795,t:1527188847330};\\\", \\\"{x:1312,y:796,t:1527188847346};\\\", \\\"{x:1313,y:798,t:1527188847362};\\\", \\\"{x:1313,y:799,t:1527188847379};\\\", \\\"{x:1313,y:802,t:1527188847396};\\\", \\\"{x:1313,y:803,t:1527188847412};\\\", \\\"{x:1313,y:807,t:1527188847429};\\\", \\\"{x:1314,y:810,t:1527188847446};\\\", \\\"{x:1314,y:813,t:1527188847463};\\\", \\\"{x:1316,y:818,t:1527188847479};\\\", \\\"{x:1316,y:822,t:1527188847496};\\\", \\\"{x:1316,y:829,t:1527188847512};\\\", \\\"{x:1317,y:834,t:1527188847529};\\\", \\\"{x:1317,y:838,t:1527188847546};\\\", \\\"{x:1317,y:841,t:1527188847564};\\\", \\\"{x:1318,y:846,t:1527188847579};\\\", \\\"{x:1318,y:847,t:1527188847597};\\\", \\\"{x:1318,y:849,t:1527188847614};\\\", \\\"{x:1318,y:850,t:1527188847809};\\\", \\\"{x:1318,y:851,t:1527188847817};\\\", \\\"{x:1318,y:852,t:1527188847829};\\\", \\\"{x:1318,y:853,t:1527188847846};\\\", \\\"{x:1318,y:854,t:1527188847864};\\\", \\\"{x:1318,y:855,t:1527188847880};\\\", \\\"{x:1318,y:856,t:1527188847896};\\\", \\\"{x:1318,y:858,t:1527188847913};\\\", \\\"{x:1318,y:859,t:1527188847936};\\\", \\\"{x:1318,y:860,t:1527188847946};\\\", \\\"{x:1318,y:861,t:1527188847963};\\\", \\\"{x:1318,y:863,t:1527188847981};\\\", \\\"{x:1318,y:865,t:1527188847996};\\\", \\\"{x:1318,y:867,t:1527188848013};\\\", \\\"{x:1318,y:870,t:1527188848030};\\\", \\\"{x:1318,y:874,t:1527188848047};\\\", \\\"{x:1318,y:878,t:1527188848062};\\\", \\\"{x:1318,y:883,t:1527188848079};\\\", \\\"{x:1318,y:888,t:1527188848096};\\\", \\\"{x:1318,y:892,t:1527188848113};\\\", \\\"{x:1318,y:893,t:1527188848130};\\\", \\\"{x:1318,y:895,t:1527188848177};\\\", \\\"{x:1318,y:896,t:1527188848226};\\\", \\\"{x:1318,y:898,t:1527188848290};\\\", \\\"{x:1318,y:899,t:1527188848313};\\\", \\\"{x:1318,y:901,t:1527188848330};\\\", \\\"{x:1318,y:902,t:1527188848353};\\\", \\\"{x:1318,y:903,t:1527188848369};\\\", \\\"{x:1318,y:904,t:1527188848385};\\\", \\\"{x:1318,y:905,t:1527188848398};\\\", \\\"{x:1318,y:908,t:1527188848414};\\\", \\\"{x:1318,y:910,t:1527188848430};\\\", \\\"{x:1318,y:919,t:1527188848447};\\\", \\\"{x:1318,y:923,t:1527188848464};\\\", \\\"{x:1317,y:928,t:1527188848480};\\\", \\\"{x:1315,y:934,t:1527188848497};\\\", \\\"{x:1314,y:935,t:1527188848514};\\\", \\\"{x:1313,y:936,t:1527188848530};\\\", \\\"{x:1312,y:934,t:1527188848713};\\\", \\\"{x:1310,y:930,t:1527188848731};\\\", \\\"{x:1309,y:927,t:1527188848747};\\\", \\\"{x:1308,y:925,t:1527188848764};\\\", \\\"{x:1308,y:923,t:1527188848782};\\\", \\\"{x:1308,y:921,t:1527188848801};\\\", \\\"{x:1309,y:921,t:1527188849473};\\\", \\\"{x:1309,y:920,t:1527188849482};\\\", \\\"{x:1309,y:916,t:1527188849994};\\\", \\\"{x:1309,y:906,t:1527188850001};\\\", \\\"{x:1309,y:897,t:1527188850016};\\\", \\\"{x:1310,y:871,t:1527188850033};\\\", \\\"{x:1320,y:791,t:1527188850049};\\\", \\\"{x:1333,y:707,t:1527188850066};\\\", \\\"{x:1342,y:630,t:1527188850083};\\\", \\\"{x:1344,y:555,t:1527188850099};\\\", \\\"{x:1354,y:495,t:1527188850117};\\\", \\\"{x:1365,y:451,t:1527188850133};\\\", \\\"{x:1370,y:429,t:1527188850149};\\\", \\\"{x:1372,y:420,t:1527188850166};\\\", \\\"{x:1372,y:419,t:1527188850183};\\\", \\\"{x:1372,y:418,t:1527188850265};\\\", \\\"{x:1371,y:418,t:1527188850283};\\\", \\\"{x:1367,y:418,t:1527188850300};\\\", \\\"{x:1363,y:419,t:1527188850317};\\\", \\\"{x:1357,y:424,t:1527188850333};\\\", \\\"{x:1351,y:428,t:1527188850349};\\\", \\\"{x:1348,y:431,t:1527188850367};\\\", \\\"{x:1341,y:435,t:1527188850384};\\\", \\\"{x:1335,y:438,t:1527188850400};\\\", \\\"{x:1332,y:440,t:1527188850416};\\\", \\\"{x:1329,y:441,t:1527188850433};\\\", \\\"{x:1327,y:442,t:1527188850450};\\\", \\\"{x:1325,y:443,t:1527188850530};\\\", \\\"{x:1324,y:445,t:1527188850537};\\\", \\\"{x:1323,y:445,t:1527188850551};\\\", \\\"{x:1321,y:447,t:1527188850566};\\\", \\\"{x:1318,y:449,t:1527188850584};\\\", \\\"{x:1316,y:450,t:1527188850601};\\\", \\\"{x:1315,y:450,t:1527188850616};\\\", \\\"{x:1313,y:450,t:1527188850657};\\\", \\\"{x:1312,y:450,t:1527188850667};\\\", \\\"{x:1309,y:450,t:1527188850684};\\\", \\\"{x:1306,y:449,t:1527188850700};\\\", \\\"{x:1304,y:448,t:1527188850717};\\\", \\\"{x:1303,y:448,t:1527188850734};\\\", \\\"{x:1302,y:448,t:1527188850751};\\\", \\\"{x:1301,y:448,t:1527188850833};\\\", \\\"{x:1298,y:447,t:1527188850851};\\\", \\\"{x:1297,y:447,t:1527188850946};\\\", \\\"{x:1296,y:447,t:1527188851017};\\\", \\\"{x:1295,y:447,t:1527188851041};\\\", \\\"{x:1296,y:447,t:1527188851113};\\\", \\\"{x:1297,y:447,t:1527188851121};\\\", \\\"{x:1299,y:447,t:1527188851134};\\\", \\\"{x:1300,y:446,t:1527188851150};\\\", \\\"{x:1301,y:446,t:1527188851184};\\\", \\\"{x:1310,y:446,t:1527188851200};\\\", \\\"{x:1315,y:447,t:1527188851217};\\\", \\\"{x:1319,y:450,t:1527188851234};\\\", \\\"{x:1322,y:450,t:1527188851250};\\\", \\\"{x:1322,y:449,t:1527188851554};\\\", \\\"{x:1320,y:448,t:1527188851569};\\\", \\\"{x:1320,y:447,t:1527188851585};\\\", \\\"{x:1319,y:445,t:1527188851602};\\\", \\\"{x:1318,y:444,t:1527188851634};\\\", \\\"{x:1317,y:444,t:1527188851657};\\\", \\\"{x:1316,y:444,t:1527188851673};\\\", \\\"{x:1316,y:443,t:1527188851745};\\\", \\\"{x:1314,y:442,t:1527188851752};\\\", \\\"{x:1314,y:441,t:1527188851769};\\\", \\\"{x:1313,y:441,t:1527188851817};\\\", \\\"{x:1312,y:442,t:1527188858972};\\\", \\\"{x:1310,y:445,t:1527188858981};\\\", \\\"{x:1310,y:447,t:1527188858997};\\\", \\\"{x:1310,y:449,t:1527188859015};\\\", \\\"{x:1309,y:450,t:1527188859031};\\\", \\\"{x:1308,y:452,t:1527188859049};\\\", \\\"{x:1308,y:453,t:1527188859064};\\\", \\\"{x:1308,y:454,t:1527188859101};\\\", \\\"{x:1308,y:455,t:1527188859117};\\\", \\\"{x:1307,y:455,t:1527188859132};\\\", \\\"{x:1307,y:456,t:1527188859148};\\\", \\\"{x:1307,y:457,t:1527188859165};\\\", \\\"{x:1307,y:458,t:1527188859182};\\\", \\\"{x:1306,y:460,t:1527188859198};\\\", \\\"{x:1306,y:462,t:1527188859215};\\\", \\\"{x:1305,y:463,t:1527188859232};\\\", \\\"{x:1305,y:464,t:1527188859249};\\\", \\\"{x:1305,y:466,t:1527188859265};\\\", \\\"{x:1305,y:467,t:1527188859292};\\\", \\\"{x:1305,y:468,t:1527188859308};\\\", \\\"{x:1304,y:469,t:1527188859317};\\\", \\\"{x:1304,y:470,t:1527188859373};\\\", \\\"{x:1304,y:471,t:1527188859397};\\\", \\\"{x:1304,y:472,t:1527188859413};\\\", \\\"{x:1304,y:475,t:1527188859428};\\\", \\\"{x:1304,y:476,t:1527188859444};\\\", \\\"{x:1304,y:479,t:1527188859452};\\\", \\\"{x:1304,y:481,t:1527188859468};\\\", \\\"{x:1304,y:482,t:1527188859482};\\\", \\\"{x:1304,y:486,t:1527188859499};\\\", \\\"{x:1304,y:489,t:1527188859516};\\\", \\\"{x:1305,y:489,t:1527188859668};\\\", \\\"{x:1306,y:487,t:1527188859682};\\\", \\\"{x:1307,y:484,t:1527188859698};\\\", \\\"{x:1307,y:482,t:1527188859715};\\\", \\\"{x:1308,y:479,t:1527188859731};\\\", \\\"{x:1308,y:477,t:1527188859748};\\\", \\\"{x:1308,y:473,t:1527188859765};\\\", \\\"{x:1310,y:470,t:1527188859783};\\\", \\\"{x:1311,y:465,t:1527188859799};\\\", \\\"{x:1313,y:460,t:1527188859815};\\\", \\\"{x:1313,y:457,t:1527188859832};\\\", \\\"{x:1313,y:454,t:1527188859849};\\\", \\\"{x:1314,y:451,t:1527188859865};\\\", \\\"{x:1314,y:450,t:1527188859882};\\\", \\\"{x:1315,y:449,t:1527188859900};\\\", \\\"{x:1315,y:448,t:1527188859915};\\\", \\\"{x:1315,y:447,t:1527188859932};\\\", \\\"{x:1317,y:445,t:1527188859949};\\\", \\\"{x:1317,y:444,t:1527188859965};\\\", \\\"{x:1317,y:442,t:1527188859983};\\\", \\\"{x:1318,y:441,t:1527188859999};\\\", \\\"{x:1318,y:439,t:1527188860016};\\\", \\\"{x:1320,y:436,t:1527188860033};\\\", \\\"{x:1321,y:433,t:1527188860049};\\\", \\\"{x:1324,y:429,t:1527188860066};\\\", \\\"{x:1325,y:424,t:1527188860083};\\\", \\\"{x:1326,y:421,t:1527188860100};\\\", \\\"{x:1327,y:417,t:1527188860116};\\\", \\\"{x:1327,y:420,t:1527188860229};\\\", \\\"{x:1327,y:425,t:1527188860237};\\\", \\\"{x:1325,y:431,t:1527188860249};\\\", \\\"{x:1322,y:444,t:1527188860267};\\\", \\\"{x:1319,y:454,t:1527188860283};\\\", \\\"{x:1317,y:460,t:1527188860299};\\\", \\\"{x:1316,y:462,t:1527188860316};\\\", \\\"{x:1316,y:463,t:1527188860597};\\\", \\\"{x:1315,y:463,t:1527188860612};\\\", \\\"{x:1315,y:462,t:1527188860621};\\\", \\\"{x:1314,y:462,t:1527188860633};\\\", \\\"{x:1314,y:460,t:1527188860650};\\\", \\\"{x:1314,y:459,t:1527188860749};\\\", \\\"{x:1314,y:457,t:1527188861149};\\\", \\\"{x:1314,y:456,t:1527188861165};\\\", \\\"{x:1314,y:454,t:1527188861172};\\\", \\\"{x:1314,y:453,t:1527188861185};\\\", \\\"{x:1314,y:451,t:1527188861201};\\\", \\\"{x:1314,y:448,t:1527188861217};\\\", \\\"{x:1314,y:447,t:1527188861234};\\\", \\\"{x:1315,y:446,t:1527188861250};\\\", \\\"{x:1315,y:445,t:1527188861268};\\\", \\\"{x:1315,y:443,t:1527188861285};\\\", \\\"{x:1315,y:442,t:1527188861349};\\\", \\\"{x:1316,y:441,t:1527188861356};\\\", \\\"{x:1316,y:440,t:1527188861997};\\\", \\\"{x:1318,y:440,t:1527188862004};\\\", \\\"{x:1320,y:440,t:1527188862022};\\\", \\\"{x:1321,y:440,t:1527188862036};\\\", \\\"{x:1325,y:442,t:1527188862052};\\\", \\\"{x:1329,y:444,t:1527188862068};\\\", \\\"{x:1331,y:445,t:1527188862086};\\\", \\\"{x:1333,y:446,t:1527188862102};\\\", \\\"{x:1336,y:447,t:1527188862118};\\\", \\\"{x:1338,y:447,t:1527188862135};\\\", \\\"{x:1340,y:447,t:1527188862152};\\\", \\\"{x:1341,y:447,t:1527188862173};\\\", \\\"{x:1342,y:447,t:1527188862188};\\\", \\\"{x:1344,y:447,t:1527188862201};\\\", \\\"{x:1348,y:447,t:1527188862219};\\\", \\\"{x:1356,y:448,t:1527188862236};\\\", \\\"{x:1367,y:448,t:1527188862252};\\\", \\\"{x:1371,y:448,t:1527188862269};\\\", \\\"{x:1372,y:448,t:1527188862286};\\\", \\\"{x:1373,y:448,t:1527188862397};\\\", \\\"{x:1374,y:448,t:1527188862493};\\\", \\\"{x:1375,y:448,t:1527188862502};\\\", \\\"{x:1376,y:448,t:1527188862541};\\\", \\\"{x:1378,y:448,t:1527188862553};\\\", \\\"{x:1378,y:447,t:1527188862612};\\\", \\\"{x:1379,y:446,t:1527188862645};\\\", \\\"{x:1381,y:444,t:1527188862653};\\\", \\\"{x:1382,y:443,t:1527188862693};\\\", \\\"{x:1384,y:443,t:1527188863405};\\\", \\\"{x:1385,y:443,t:1527188863420};\\\", \\\"{x:1387,y:443,t:1527188863437};\\\", \\\"{x:1391,y:446,t:1527188863454};\\\", \\\"{x:1395,y:448,t:1527188863471};\\\", \\\"{x:1400,y:451,t:1527188863487};\\\", \\\"{x:1405,y:454,t:1527188863504};\\\", \\\"{x:1410,y:456,t:1527188863521};\\\", \\\"{x:1412,y:456,t:1527188863537};\\\", \\\"{x:1413,y:457,t:1527188863589};\\\", \\\"{x:1415,y:457,t:1527188863605};\\\", \\\"{x:1420,y:457,t:1527188863621};\\\", \\\"{x:1426,y:457,t:1527188863637};\\\", \\\"{x:1431,y:457,t:1527188863654};\\\", \\\"{x:1435,y:457,t:1527188863671};\\\", \\\"{x:1437,y:457,t:1527188863688};\\\", \\\"{x:1438,y:457,t:1527188863757};\\\", \\\"{x:1440,y:457,t:1527188863788};\\\", \\\"{x:1441,y:457,t:1527188863804};\\\", \\\"{x:1444,y:456,t:1527188863821};\\\", \\\"{x:1445,y:456,t:1527188863837};\\\", \\\"{x:1445,y:455,t:1527188863855};\\\", \\\"{x:1446,y:454,t:1527188863871};\\\", \\\"{x:1447,y:453,t:1527188863888};\\\", \\\"{x:1449,y:451,t:1527188863905};\\\", \\\"{x:1452,y:449,t:1527188863920};\\\", \\\"{x:1455,y:446,t:1527188863938};\\\", \\\"{x:1455,y:445,t:1527188863965};\\\", \\\"{x:1456,y:445,t:1527188863972};\\\", \\\"{x:1456,y:444,t:1527188863988};\\\", \\\"{x:1457,y:443,t:1527188864004};\\\", \\\"{x:1457,y:442,t:1527188864028};\\\", \\\"{x:1457,y:441,t:1527188864132};\\\", \\\"{x:1457,y:440,t:1527188864140};\\\", \\\"{x:1456,y:440,t:1527188864154};\\\", \\\"{x:1455,y:440,t:1527188864172};\\\", \\\"{x:1454,y:440,t:1527188864205};\\\", \\\"{x:1453,y:440,t:1527188864222};\\\", \\\"{x:1452,y:440,t:1527188864238};\\\", \\\"{x:1451,y:440,t:1527188864254};\\\", \\\"{x:1449,y:440,t:1527188864272};\\\", \\\"{x:1451,y:440,t:1527188865765};\\\", \\\"{x:1450,y:440,t:1527188866133};\\\", \\\"{x:1448,y:440,t:1527188866140};\\\", \\\"{x:1447,y:440,t:1527188866156};\\\", \\\"{x:1445,y:441,t:1527188866173};\\\", \\\"{x:1445,y:442,t:1527188866191};\\\", \\\"{x:1444,y:443,t:1527188866207};\\\", \\\"{x:1444,y:444,t:1527188866253};\\\", \\\"{x:1437,y:448,t:1527188869413};\\\", \\\"{x:1410,y:455,t:1527188869429};\\\", \\\"{x:1374,y:472,t:1527188869444};\\\", \\\"{x:1349,y:483,t:1527188869461};\\\", \\\"{x:1321,y:487,t:1527188869478};\\\", \\\"{x:1295,y:490,t:1527188869495};\\\", \\\"{x:1289,y:490,t:1527188869512};\\\", \\\"{x:1288,y:490,t:1527188869528};\\\", \\\"{x:1287,y:490,t:1527188869572};\\\", \\\"{x:1287,y:487,t:1527188869588};\\\", \\\"{x:1288,y:483,t:1527188869605};\\\", \\\"{x:1292,y:478,t:1527188869612};\\\", \\\"{x:1299,y:470,t:1527188869627};\\\", \\\"{x:1303,y:466,t:1527188869644};\\\", \\\"{x:1308,y:463,t:1527188869661};\\\", \\\"{x:1310,y:460,t:1527188869677};\\\", \\\"{x:1312,y:456,t:1527188869694};\\\", \\\"{x:1312,y:454,t:1527188869712};\\\", \\\"{x:1316,y:447,t:1527188869729};\\\", \\\"{x:1320,y:441,t:1527188869745};\\\", \\\"{x:1323,y:434,t:1527188869761};\\\", \\\"{x:1326,y:429,t:1527188869778};\\\", \\\"{x:1327,y:426,t:1527188869794};\\\", \\\"{x:1327,y:424,t:1527188869811};\\\", \\\"{x:1327,y:423,t:1527188869916};\\\", \\\"{x:1327,y:424,t:1527188869928};\\\", \\\"{x:1323,y:430,t:1527188869944};\\\", \\\"{x:1322,y:436,t:1527188869961};\\\", \\\"{x:1320,y:439,t:1527188869979};\\\", \\\"{x:1318,y:444,t:1527188869995};\\\", \\\"{x:1317,y:446,t:1527188870011};\\\", \\\"{x:1316,y:446,t:1527188870028};\\\", \\\"{x:1316,y:448,t:1527188870051};\\\", \\\"{x:1316,y:447,t:1527188871156};\\\", \\\"{x:1316,y:446,t:1527188871164};\\\", \\\"{x:1316,y:445,t:1527188871179};\\\", \\\"{x:1315,y:444,t:1527188871531};\\\", \\\"{x:1313,y:443,t:1527188871546};\\\", \\\"{x:1311,y:441,t:1527188871563};\\\", \\\"{x:1309,y:441,t:1527188871580};\\\", \\\"{x:1310,y:441,t:1527188875908};\\\", \\\"{x:1311,y:441,t:1527188889124};\\\", \\\"{x:1312,y:441,t:1527188889731};\\\", \\\"{x:1314,y:441,t:1527188891028};\\\", \\\"{x:1314,y:442,t:1527188891038};\\\", \\\"{x:1316,y:444,t:1527188891055};\\\", \\\"{x:1317,y:446,t:1527188891073};\\\", \\\"{x:1319,y:447,t:1527188891089};\\\", \\\"{x:1320,y:448,t:1527188891237};\\\", \\\"{x:1323,y:449,t:1527188891244};\\\", \\\"{x:1326,y:450,t:1527188891255};\\\", \\\"{x:1332,y:452,t:1527188891272};\\\", \\\"{x:1338,y:454,t:1527188891289};\\\", \\\"{x:1346,y:454,t:1527188891305};\\\", \\\"{x:1347,y:454,t:1527188891322};\\\", \\\"{x:1349,y:454,t:1527188891339};\\\", \\\"{x:1351,y:454,t:1527188891461};\\\", \\\"{x:1353,y:454,t:1527188891473};\\\", \\\"{x:1355,y:454,t:1527188891490};\\\", \\\"{x:1358,y:455,t:1527188891505};\\\", \\\"{x:1359,y:456,t:1527188891523};\\\", \\\"{x:1360,y:457,t:1527188891540};\\\", \\\"{x:1362,y:457,t:1527188891556};\\\", \\\"{x:1363,y:457,t:1527188891636};\\\", \\\"{x:1365,y:457,t:1527188891652};\\\", \\\"{x:1367,y:460,t:1527188891659};\\\", \\\"{x:1368,y:460,t:1527188891673};\\\", \\\"{x:1372,y:464,t:1527188891689};\\\", \\\"{x:1375,y:466,t:1527188891706};\\\", \\\"{x:1380,y:469,t:1527188891723};\\\", \\\"{x:1384,y:473,t:1527188891740};\\\", \\\"{x:1387,y:474,t:1527188891756};\\\", \\\"{x:1390,y:475,t:1527188891773};\\\", \\\"{x:1392,y:476,t:1527188891790};\\\", \\\"{x:1394,y:476,t:1527188891806};\\\", \\\"{x:1395,y:476,t:1527188891824};\\\", \\\"{x:1397,y:476,t:1527188891840};\\\", \\\"{x:1400,y:476,t:1527188891857};\\\", \\\"{x:1405,y:479,t:1527188891874};\\\", \\\"{x:1413,y:479,t:1527188891890};\\\", \\\"{x:1422,y:482,t:1527188891907};\\\", \\\"{x:1430,y:484,t:1527188891924};\\\", \\\"{x:1434,y:486,t:1527188891940};\\\", \\\"{x:1435,y:486,t:1527188891964};\\\", \\\"{x:1437,y:486,t:1527188891980};\\\", \\\"{x:1438,y:486,t:1527188891996};\\\", \\\"{x:1439,y:486,t:1527188892020};\\\", \\\"{x:1440,y:486,t:1527188892036};\\\", \\\"{x:1442,y:486,t:1527188892044};\\\", \\\"{x:1444,y:485,t:1527188892060};\\\", \\\"{x:1446,y:484,t:1527188892074};\\\", \\\"{x:1452,y:481,t:1527188892091};\\\", \\\"{x:1456,y:479,t:1527188892107};\\\", \\\"{x:1461,y:477,t:1527188892124};\\\", \\\"{x:1463,y:476,t:1527188892140};\\\", \\\"{x:1464,y:475,t:1527188892156};\\\", \\\"{x:1467,y:474,t:1527188892174};\\\", \\\"{x:1471,y:472,t:1527188892191};\\\", \\\"{x:1474,y:471,t:1527188892207};\\\", \\\"{x:1476,y:471,t:1527188892223};\\\", \\\"{x:1478,y:471,t:1527188892241};\\\", \\\"{x:1479,y:470,t:1527188892256};\\\", \\\"{x:1482,y:468,t:1527188892274};\\\", \\\"{x:1489,y:466,t:1527188892291};\\\", \\\"{x:1499,y:462,t:1527188892307};\\\", \\\"{x:1515,y:454,t:1527188892324};\\\", \\\"{x:1521,y:452,t:1527188892340};\\\", \\\"{x:1523,y:452,t:1527188892358};\\\", \\\"{x:1523,y:451,t:1527188892492};\\\", \\\"{x:1522,y:449,t:1527188892508};\\\", \\\"{x:1516,y:446,t:1527188892524};\\\", \\\"{x:1509,y:443,t:1527188892541};\\\", \\\"{x:1507,y:442,t:1527188892558};\\\", \\\"{x:1509,y:442,t:1527188894156};\\\", \\\"{x:1509,y:443,t:1527188894316};\\\", \\\"{x:1510,y:443,t:1527188894444};\\\", \\\"{x:1512,y:443,t:1527188894691};\\\", \\\"{x:1513,y:443,t:1527188894715};\\\", \\\"{x:1514,y:443,t:1527188894771};\\\", \\\"{x:1515,y:443,t:1527188894795};\\\", \\\"{x:1516,y:443,t:1527188894827};\\\", \\\"{x:1515,y:443,t:1527188897236};\\\", \\\"{x:1507,y:444,t:1527188897247};\\\", \\\"{x:1490,y:456,t:1527188897264};\\\", \\\"{x:1472,y:466,t:1527188897279};\\\", \\\"{x:1463,y:471,t:1527188897296};\\\", \\\"{x:1457,y:474,t:1527188897314};\\\", \\\"{x:1456,y:474,t:1527188897329};\\\", \\\"{x:1456,y:476,t:1527188897372};\\\", \\\"{x:1454,y:479,t:1527188897380};\\\", \\\"{x:1446,y:486,t:1527188897397};\\\", \\\"{x:1441,y:490,t:1527188897414};\\\", \\\"{x:1437,y:494,t:1527188897430};\\\", \\\"{x:1433,y:498,t:1527188897447};\\\", \\\"{x:1431,y:500,t:1527188897463};\\\", \\\"{x:1429,y:503,t:1527188897480};\\\", \\\"{x:1428,y:505,t:1527188897497};\\\", \\\"{x:1427,y:506,t:1527188897514};\\\", \\\"{x:1425,y:507,t:1527188897604};\\\", \\\"{x:1424,y:507,t:1527188897636};\\\", \\\"{x:1423,y:507,t:1527188897647};\\\", \\\"{x:1422,y:508,t:1527188897664};\\\", \\\"{x:1420,y:509,t:1527188897682};\\\", \\\"{x:1416,y:510,t:1527188897697};\\\", \\\"{x:1415,y:511,t:1527188897714};\\\", \\\"{x:1414,y:512,t:1527188897731};\\\", \\\"{x:1413,y:512,t:1527188897836};\\\", \\\"{x:1412,y:512,t:1527188897851};\\\", \\\"{x:1411,y:512,t:1527188897908};\\\", \\\"{x:1409,y:512,t:1527188897916};\\\", \\\"{x:1409,y:515,t:1527188905165};\\\", \\\"{x:1409,y:518,t:1527188905173};\\\", \\\"{x:1410,y:529,t:1527188905190};\\\", \\\"{x:1413,y:538,t:1527188905206};\\\", \\\"{x:1413,y:542,t:1527188905223};\\\", \\\"{x:1413,y:544,t:1527188905240};\\\", \\\"{x:1414,y:545,t:1527188905373};\\\", \\\"{x:1415,y:546,t:1527188905387};\\\", \\\"{x:1415,y:547,t:1527188905396};\\\", \\\"{x:1415,y:548,t:1527188905407};\\\", \\\"{x:1415,y:552,t:1527188905424};\\\", \\\"{x:1416,y:555,t:1527188905440};\\\", \\\"{x:1416,y:559,t:1527188905457};\\\", \\\"{x:1416,y:560,t:1527188905474};\\\", \\\"{x:1416,y:561,t:1527188905491};\\\", \\\"{x:1417,y:563,t:1527188905507};\\\", \\\"{x:1417,y:564,t:1527188905644};\\\", \\\"{x:1417,y:565,t:1527188905657};\\\", \\\"{x:1417,y:568,t:1527188905674};\\\", \\\"{x:1417,y:571,t:1527188905692};\\\", \\\"{x:1417,y:572,t:1527188905708};\\\", \\\"{x:1417,y:573,t:1527188905724};\\\", \\\"{x:1414,y:573,t:1527188908140};\\\", \\\"{x:1411,y:573,t:1527188908148};\\\", \\\"{x:1409,y:573,t:1527188908161};\\\", \\\"{x:1400,y:573,t:1527188908177};\\\", \\\"{x:1389,y:573,t:1527188908195};\\\", \\\"{x:1378,y:573,t:1527188908210};\\\", \\\"{x:1366,y:572,t:1527188908227};\\\", \\\"{x:1359,y:570,t:1527188908244};\\\", \\\"{x:1354,y:569,t:1527188908261};\\\", \\\"{x:1348,y:567,t:1527188908277};\\\", \\\"{x:1341,y:565,t:1527188908294};\\\", \\\"{x:1324,y:562,t:1527188908311};\\\", \\\"{x:1314,y:561,t:1527188908326};\\\", \\\"{x:1307,y:560,t:1527188908344};\\\", \\\"{x:1305,y:560,t:1527188908361};\\\", \\\"{x:1304,y:560,t:1527188908676};\\\", \\\"{x:1304,y:561,t:1527188908692};\\\", \\\"{x:1304,y:563,t:1527188908700};\\\", \\\"{x:1304,y:564,t:1527188908712};\\\", \\\"{x:1304,y:566,t:1527188908728};\\\", \\\"{x:1304,y:567,t:1527188908745};\\\", \\\"{x:1304,y:569,t:1527188908844};\\\", \\\"{x:1305,y:570,t:1527188908861};\\\", \\\"{x:1306,y:571,t:1527188908878};\\\", \\\"{x:1306,y:572,t:1527188908896};\\\", \\\"{x:1306,y:573,t:1527188908932};\\\", \\\"{x:1307,y:574,t:1527188908945};\\\", \\\"{x:1308,y:574,t:1527188908961};\\\", \\\"{x:1310,y:576,t:1527188908979};\\\", \\\"{x:1311,y:576,t:1527188909034};\\\", \\\"{x:1312,y:576,t:1527188909074};\\\", \\\"{x:1312,y:577,t:1527188909082};\\\", \\\"{x:1311,y:579,t:1527188918096};\\\", \\\"{x:1311,y:583,t:1527188918112};\\\", \\\"{x:1326,y:597,t:1527188918127};\\\", \\\"{x:1342,y:607,t:1527188918144};\\\", \\\"{x:1358,y:617,t:1527188918161};\\\", \\\"{x:1369,y:623,t:1527188918177};\\\", \\\"{x:1376,y:627,t:1527188918194};\\\", \\\"{x:1378,y:629,t:1527188918211};\\\", \\\"{x:1380,y:630,t:1527188918228};\\\", \\\"{x:1381,y:631,t:1527188918244};\\\", \\\"{x:1382,y:633,t:1527188918261};\\\", \\\"{x:1384,y:636,t:1527188918277};\\\", \\\"{x:1384,y:639,t:1527188918294};\\\", \\\"{x:1384,y:642,t:1527188918311};\\\", \\\"{x:1385,y:649,t:1527188918327};\\\", \\\"{x:1387,y:651,t:1527188918344};\\\", \\\"{x:1387,y:656,t:1527188918360};\\\", \\\"{x:1387,y:659,t:1527188918378};\\\", \\\"{x:1387,y:662,t:1527188918394};\\\", \\\"{x:1387,y:666,t:1527188918411};\\\", \\\"{x:1387,y:670,t:1527188918428};\\\", \\\"{x:1387,y:674,t:1527188918445};\\\", \\\"{x:1387,y:677,t:1527188918461};\\\", \\\"{x:1387,y:679,t:1527188918478};\\\", \\\"{x:1387,y:680,t:1527188918494};\\\", \\\"{x:1387,y:683,t:1527188918511};\\\", \\\"{x:1386,y:686,t:1527188918528};\\\", \\\"{x:1385,y:688,t:1527188918544};\\\", \\\"{x:1383,y:694,t:1527188918562};\\\", \\\"{x:1380,y:699,t:1527188918578};\\\", \\\"{x:1379,y:703,t:1527188918595};\\\", \\\"{x:1376,y:708,t:1527188918612};\\\", \\\"{x:1373,y:711,t:1527188918628};\\\", \\\"{x:1371,y:713,t:1527188918645};\\\", \\\"{x:1370,y:715,t:1527188918661};\\\", \\\"{x:1373,y:714,t:1527188918847};\\\", \\\"{x:1376,y:712,t:1527188918862};\\\", \\\"{x:1379,y:711,t:1527188918879};\\\", \\\"{x:1383,y:708,t:1527188918895};\\\", \\\"{x:1385,y:707,t:1527188918911};\\\", \\\"{x:1385,y:705,t:1527188918930};\\\", \\\"{x:1384,y:705,t:1527188919312};\\\", \\\"{x:1383,y:706,t:1527188919456};\\\", \\\"{x:1381,y:706,t:1527188919472};\\\", \\\"{x:1378,y:707,t:1527188919487};\\\", \\\"{x:1377,y:708,t:1527188919495};\\\", \\\"{x:1376,y:709,t:1527188919512};\\\", \\\"{x:1375,y:710,t:1527188919535};\\\", \\\"{x:1374,y:710,t:1527188919649};\\\", \\\"{x:1374,y:709,t:1527188919664};\\\", \\\"{x:1374,y:708,t:1527188919815};\\\", \\\"{x:1374,y:707,t:1527188919831};\\\", \\\"{x:1374,y:706,t:1527188919854};\\\", \\\"{x:1377,y:706,t:1527188919874};\\\", \\\"{x:1382,y:705,t:1527188919879};\\\", \\\"{x:1388,y:703,t:1527188919896};\\\", \\\"{x:1389,y:702,t:1527188919912};\\\", \\\"{x:1388,y:702,t:1527188920336};\\\", \\\"{x:1387,y:703,t:1527188920346};\\\", \\\"{x:1386,y:703,t:1527188920363};\\\", \\\"{x:1385,y:704,t:1527188920391};\\\", \\\"{x:1384,y:704,t:1527188920416};\\\", \\\"{x:1384,y:705,t:1527188920432};\\\", \\\"{x:1383,y:705,t:1527188920512};\\\", \\\"{x:1382,y:706,t:1527188921135};\\\", \\\"{x:1379,y:708,t:1527188921151};\\\", \\\"{x:1378,y:709,t:1527188921167};\\\", \\\"{x:1377,y:710,t:1527188921191};\\\", \\\"{x:1375,y:713,t:1527188922728};\\\", \\\"{x:1374,y:713,t:1527188922743};\\\", \\\"{x:1373,y:714,t:1527188922759};\\\", \\\"{x:1372,y:715,t:1527188922768};\\\", \\\"{x:1372,y:716,t:1527188922807};\\\", \\\"{x:1373,y:716,t:1527188923160};\\\", \\\"{x:1374,y:716,t:1527188923175};\\\", \\\"{x:1376,y:716,t:1527188923208};\\\", \\\"{x:1377,y:715,t:1527188923256};\\\", \\\"{x:1379,y:715,t:1527188923440};\\\", \\\"{x:1380,y:714,t:1527188923467};\\\", \\\"{x:1381,y:714,t:1527188923483};\\\", \\\"{x:1382,y:714,t:1527188923500};\\\", \\\"{x:1382,y:713,t:1527188928528};\\\", \\\"{x:1384,y:715,t:1527188936607};\\\", \\\"{x:1389,y:726,t:1527188936618};\\\", \\\"{x:1402,y:747,t:1527188936634};\\\", \\\"{x:1415,y:767,t:1527188936651};\\\", \\\"{x:1443,y:793,t:1527188936667};\\\", \\\"{x:1486,y:818,t:1527188936684};\\\", \\\"{x:1522,y:833,t:1527188936701};\\\", \\\"{x:1554,y:843,t:1527188936718};\\\", \\\"{x:1574,y:849,t:1527188936735};\\\", \\\"{x:1578,y:849,t:1527188936751};\\\", \\\"{x:1579,y:848,t:1527188936772};\\\", \\\"{x:1579,y:846,t:1527188936784};\\\", \\\"{x:1579,y:842,t:1527188936801};\\\", \\\"{x:1579,y:837,t:1527188936818};\\\", \\\"{x:1578,y:830,t:1527188936834};\\\", \\\"{x:1569,y:819,t:1527188936850};\\\", \\\"{x:1555,y:808,t:1527188936867};\\\", \\\"{x:1542,y:802,t:1527188936884};\\\", \\\"{x:1538,y:799,t:1527188936901};\\\", \\\"{x:1537,y:798,t:1527188936966};\\\", \\\"{x:1537,y:797,t:1527188936974};\\\", \\\"{x:1534,y:795,t:1527188936984};\\\", \\\"{x:1529,y:792,t:1527188937001};\\\", \\\"{x:1527,y:791,t:1527188937018};\\\", \\\"{x:1523,y:789,t:1527188937035};\\\", \\\"{x:1519,y:786,t:1527188937051};\\\", \\\"{x:1515,y:784,t:1527188937068};\\\", \\\"{x:1511,y:783,t:1527188937085};\\\", \\\"{x:1509,y:782,t:1527188937101};\\\", \\\"{x:1508,y:781,t:1527188937118};\\\", \\\"{x:1507,y:779,t:1527188937215};\\\", \\\"{x:1505,y:778,t:1527188937223};\\\", \\\"{x:1501,y:776,t:1527188937235};\\\", \\\"{x:1494,y:773,t:1527188937253};\\\", \\\"{x:1491,y:772,t:1527188937269};\\\", \\\"{x:1490,y:772,t:1527188937285};\\\", \\\"{x:1489,y:771,t:1527188937302};\\\", \\\"{x:1488,y:771,t:1527188937447};\\\", \\\"{x:1487,y:771,t:1527188937455};\\\", \\\"{x:1486,y:771,t:1527188937800};\\\", \\\"{x:1485,y:771,t:1527188937815};\\\", \\\"{x:1484,y:772,t:1527188938256};\\\", \\\"{x:1484,y:773,t:1527188938286};\\\", \\\"{x:1484,y:774,t:1527188938303};\\\", \\\"{x:1486,y:774,t:1527188938319};\\\", \\\"{x:1491,y:775,t:1527188938337};\\\", \\\"{x:1494,y:776,t:1527188938353};\\\", \\\"{x:1502,y:779,t:1527188938370};\\\", \\\"{x:1507,y:781,t:1527188938386};\\\", \\\"{x:1513,y:783,t:1527188938404};\\\", \\\"{x:1517,y:783,t:1527188938420};\\\", \\\"{x:1520,y:783,t:1527188938436};\\\", \\\"{x:1523,y:783,t:1527188938453};\\\", \\\"{x:1528,y:783,t:1527188938470};\\\", \\\"{x:1533,y:784,t:1527188938486};\\\", \\\"{x:1538,y:784,t:1527188938503};\\\", \\\"{x:1539,y:784,t:1527188938584};\\\", \\\"{x:1540,y:784,t:1527188938591};\\\", \\\"{x:1541,y:784,t:1527188938607};\\\", \\\"{x:1542,y:784,t:1527188938728};\\\", \\\"{x:1543,y:784,t:1527188938737};\\\", \\\"{x:1545,y:784,t:1527188938753};\\\", \\\"{x:1548,y:782,t:1527188938770};\\\", \\\"{x:1550,y:781,t:1527188938791};\\\", \\\"{x:1551,y:780,t:1527188938807};\\\", \\\"{x:1552,y:780,t:1527188938831};\\\", \\\"{x:1554,y:779,t:1527188938863};\\\", \\\"{x:1549,y:779,t:1527188939159};\\\", \\\"{x:1539,y:779,t:1527188939171};\\\", \\\"{x:1497,y:779,t:1527188939187};\\\", \\\"{x:1430,y:777,t:1527188939204};\\\", \\\"{x:1354,y:774,t:1527188939222};\\\", \\\"{x:1258,y:768,t:1527188939237};\\\", \\\"{x:1145,y:758,t:1527188939254};\\\", \\\"{x:950,y:728,t:1527188939270};\\\", \\\"{x:823,y:711,t:1527188939287};\\\", \\\"{x:714,y:695,t:1527188939304};\\\", \\\"{x:645,y:685,t:1527188939321};\\\", \\\"{x:589,y:677,t:1527188939337};\\\", \\\"{x:559,y:672,t:1527188939355};\\\", \\\"{x:542,y:670,t:1527188939371};\\\", \\\"{x:535,y:668,t:1527188939387};\\\", \\\"{x:532,y:668,t:1527188939405};\\\", \\\"{x:529,y:668,t:1527188939422};\\\", \\\"{x:528,y:668,t:1527188939439};\\\", \\\"{x:526,y:668,t:1527188939462};\\\", \\\"{x:521,y:668,t:1527188939472};\\\", \\\"{x:487,y:666,t:1527188939488};\\\", \\\"{x:407,y:657,t:1527188939505};\\\", \\\"{x:367,y:655,t:1527188939522};\\\", \\\"{x:350,y:653,t:1527188939539};\\\", \\\"{x:339,y:646,t:1527188939556};\\\", \\\"{x:337,y:642,t:1527188939572};\\\", \\\"{x:337,y:636,t:1527188939589};\\\", \\\"{x:338,y:631,t:1527188939606};\\\", \\\"{x:339,y:625,t:1527188939622};\\\", \\\"{x:339,y:620,t:1527188939638};\\\", \\\"{x:339,y:613,t:1527188939656};\\\", \\\"{x:341,y:607,t:1527188939673};\\\", \\\"{x:343,y:602,t:1527188939689};\\\", \\\"{x:347,y:595,t:1527188939706};\\\", \\\"{x:354,y:588,t:1527188939722};\\\", \\\"{x:361,y:581,t:1527188939739};\\\", \\\"{x:376,y:574,t:1527188939757};\\\", \\\"{x:392,y:569,t:1527188939773};\\\", \\\"{x:401,y:567,t:1527188939789};\\\", \\\"{x:422,y:562,t:1527188939806};\\\", \\\"{x:445,y:558,t:1527188939822};\\\", \\\"{x:471,y:555,t:1527188939839};\\\", \\\"{x:498,y:550,t:1527188939856};\\\", \\\"{x:527,y:546,t:1527188939874};\\\", \\\"{x:549,y:539,t:1527188939890};\\\", \\\"{x:559,y:534,t:1527188939907};\\\", \\\"{x:560,y:534,t:1527188939923};\\\", \\\"{x:560,y:533,t:1527188939950};\\\", \\\"{x:560,y:532,t:1527188939974};\\\", \\\"{x:560,y:533,t:1527188940055};\\\", \\\"{x:560,y:535,t:1527188940063};\\\", \\\"{x:560,y:539,t:1527188940073};\\\", \\\"{x:560,y:549,t:1527188940089};\\\", \\\"{x:566,y:559,t:1527188940106};\\\", \\\"{x:572,y:567,t:1527188940122};\\\", \\\"{x:578,y:572,t:1527188940139};\\\", \\\"{x:578,y:573,t:1527188940155};\\\", \\\"{x:580,y:573,t:1527188940173};\\\", \\\"{x:581,y:574,t:1527188940223};\\\", \\\"{x:583,y:574,t:1527188940240};\\\", \\\"{x:586,y:574,t:1527188940256};\\\", \\\"{x:590,y:574,t:1527188940273};\\\", \\\"{x:592,y:574,t:1527188940289};\\\", \\\"{x:593,y:573,t:1527188940307};\\\", \\\"{x:594,y:573,t:1527188940334};\\\", \\\"{x:595,y:572,t:1527188940351};\\\", \\\"{x:596,y:572,t:1527188940358};\\\", \\\"{x:597,y:571,t:1527188940373};\\\", \\\"{x:599,y:569,t:1527188940391};\\\", \\\"{x:600,y:568,t:1527188940406};\\\", \\\"{x:600,y:569,t:1527188940798};\\\", \\\"{x:600,y:571,t:1527188940807};\\\", \\\"{x:600,y:574,t:1527188940824};\\\", \\\"{x:600,y:578,t:1527188940840};\\\", \\\"{x:599,y:581,t:1527188940857};\\\", \\\"{x:599,y:582,t:1527188940873};\\\", \\\"{x:599,y:583,t:1527188940889};\\\", \\\"{x:598,y:583,t:1527188940999};\\\", \\\"{x:597,y:583,t:1527188941007};\\\", \\\"{x:592,y:583,t:1527188941024};\\\", \\\"{x:589,y:586,t:1527188941040};\\\", \\\"{x:579,y:597,t:1527188941057};\\\", \\\"{x:562,y:626,t:1527188941076};\\\", \\\"{x:537,y:665,t:1527188941090};\\\", \\\"{x:515,y:696,t:1527188941107};\\\", \\\"{x:504,y:710,t:1527188941124};\\\", \\\"{x:500,y:716,t:1527188941140};\\\", \\\"{x:500,y:717,t:1527188941156};\\\", \\\"{x:500,y:716,t:1527188941205};\\\", \\\"{x:500,y:713,t:1527188941224};\\\", \\\"{x:500,y:709,t:1527188941240};\\\", \\\"{x:500,y:703,t:1527188941257};\\\", \\\"{x:500,y:694,t:1527188941275};\\\", \\\"{x:501,y:688,t:1527188941290};\\\", \\\"{x:502,y:682,t:1527188941306};\\\", \\\"{x:502,y:681,t:1527188941324};\\\", \\\"{x:503,y:679,t:1527188941341};\\\", \\\"{x:505,y:678,t:1527188941935};\\\", \\\"{x:507,y:676,t:1527188941951};\\\", \\\"{x:508,y:675,t:1527188941958};\\\", \\\"{x:511,y:673,t:1527188941974};\\\", \\\"{x:525,y:663,t:1527188941990};\\\", \\\"{x:539,y:653,t:1527188942007};\\\", \\\"{x:572,y:637,t:1527188942024};\\\", \\\"{x:607,y:619,t:1527188942041};\\\", \\\"{x:644,y:601,t:1527188942057};\\\", \\\"{x:689,y:588,t:1527188942074};\\\", \\\"{x:729,y:573,t:1527188942091};\\\", \\\"{x:772,y:566,t:1527188942107};\\\", \\\"{x:818,y:557,t:1527188942124};\\\", \\\"{x:859,y:546,t:1527188942141};\\\", \\\"{x:883,y:539,t:1527188942158};\\\", \\\"{x:913,y:530,t:1527188942174};\\\", \\\"{x:932,y:524,t:1527188942191};\\\", \\\"{x:949,y:519,t:1527188942208};\\\", \\\"{x:965,y:512,t:1527188942224};\\\", \\\"{x:980,y:507,t:1527188942241};\\\", \\\"{x:996,y:500,t:1527188942257};\\\", \\\"{x:1009,y:493,t:1527188942274};\\\", \\\"{x:1023,y:488,t:1527188942291};\\\", \\\"{x:1036,y:483,t:1527188942308};\\\", \\\"{x:1047,y:480,t:1527188942324};\\\", \\\"{x:1056,y:477,t:1527188942341};\\\", \\\"{x:1059,y:476,t:1527188942359};\\\", \\\"{x:1060,y:476,t:1527188942382};\\\" ] }, { \\\"rt\\\": 7347, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 334090, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1061,y:476,t:1527188945607};\\\", \\\"{x:1063,y:476,t:1527188945614};\\\", \\\"{x:1067,y:476,t:1527188945627};\\\", \\\"{x:1080,y:478,t:1527188945645};\\\", \\\"{x:1105,y:486,t:1527188945661};\\\", \\\"{x:1150,y:498,t:1527188945678};\\\", \\\"{x:1226,y:513,t:1527188945694};\\\", \\\"{x:1275,y:518,t:1527188945711};\\\", \\\"{x:1307,y:518,t:1527188945727};\\\", \\\"{x:1330,y:518,t:1527188945745};\\\", \\\"{x:1344,y:518,t:1527188945761};\\\", \\\"{x:1348,y:518,t:1527188945778};\\\", \\\"{x:1350,y:517,t:1527188945795};\\\", \\\"{x:1351,y:516,t:1527188945815};\\\", \\\"{x:1351,y:515,t:1527188945831};\\\", \\\"{x:1351,y:514,t:1527188945847};\\\", \\\"{x:1351,y:513,t:1527188945870};\\\", \\\"{x:1351,y:512,t:1527188945896};\\\", \\\"{x:1351,y:509,t:1527188945911};\\\", \\\"{x:1341,y:502,t:1527188945928};\\\", \\\"{x:1326,y:497,t:1527188945945};\\\", \\\"{x:1314,y:494,t:1527188945961};\\\", \\\"{x:1310,y:493,t:1527188945978};\\\", \\\"{x:1308,y:493,t:1527188945995};\\\", \\\"{x:1307,y:493,t:1527188946011};\\\", \\\"{x:1305,y:493,t:1527188946027};\\\", \\\"{x:1304,y:493,t:1527188946045};\\\", \\\"{x:1302,y:493,t:1527188946063};\\\", \\\"{x:1301,y:493,t:1527188946078};\\\", \\\"{x:1295,y:493,t:1527188946095};\\\", \\\"{x:1291,y:494,t:1527188946111};\\\", \\\"{x:1288,y:497,t:1527188946127};\\\", \\\"{x:1283,y:501,t:1527188946145};\\\", \\\"{x:1281,y:503,t:1527188946161};\\\", \\\"{x:1277,y:507,t:1527188946181};\\\", \\\"{x:1275,y:508,t:1527188946195};\\\", \\\"{x:1273,y:509,t:1527188946211};\\\", \\\"{x:1272,y:510,t:1527188946294};\\\", \\\"{x:1267,y:510,t:1527188946311};\\\", \\\"{x:1254,y:516,t:1527188946328};\\\", \\\"{x:1224,y:523,t:1527188946345};\\\", \\\"{x:1168,y:531,t:1527188946361};\\\", \\\"{x:1085,y:540,t:1527188946377};\\\", \\\"{x:992,y:548,t:1527188946393};\\\", \\\"{x:909,y:557,t:1527188946412};\\\", \\\"{x:852,y:560,t:1527188946427};\\\", \\\"{x:802,y:560,t:1527188946444};\\\", \\\"{x:768,y:560,t:1527188946461};\\\", \\\"{x:733,y:560,t:1527188946478};\\\", \\\"{x:718,y:560,t:1527188946496};\\\", \\\"{x:705,y:557,t:1527188946510};\\\", \\\"{x:693,y:555,t:1527188946528};\\\", \\\"{x:670,y:551,t:1527188946544};\\\", \\\"{x:642,y:550,t:1527188946561};\\\", \\\"{x:627,y:548,t:1527188946578};\\\", \\\"{x:620,y:547,t:1527188946595};\\\", \\\"{x:619,y:546,t:1527188946611};\\\", \\\"{x:619,y:545,t:1527188946628};\\\", \\\"{x:618,y:544,t:1527188946645};\\\", \\\"{x:618,y:542,t:1527188946661};\\\", \\\"{x:613,y:535,t:1527188946679};\\\", \\\"{x:610,y:528,t:1527188946695};\\\", \\\"{x:607,y:521,t:1527188946711};\\\", \\\"{x:603,y:510,t:1527188946728};\\\", \\\"{x:598,y:501,t:1527188946747};\\\", \\\"{x:596,y:496,t:1527188946761};\\\", \\\"{x:594,y:493,t:1527188946778};\\\", \\\"{x:591,y:488,t:1527188946795};\\\", \\\"{x:590,y:487,t:1527188946812};\\\", \\\"{x:590,y:486,t:1527188946828};\\\", \\\"{x:590,y:482,t:1527188946845};\\\", \\\"{x:590,y:477,t:1527188946862};\\\", \\\"{x:590,y:476,t:1527188946877};\\\", \\\"{x:590,y:473,t:1527188946895};\\\", \\\"{x:590,y:469,t:1527188946912};\\\", \\\"{x:592,y:465,t:1527188946928};\\\", \\\"{x:595,y:460,t:1527188946946};\\\", \\\"{x:599,y:456,t:1527188946962};\\\", \\\"{x:600,y:454,t:1527188946979};\\\", \\\"{x:602,y:450,t:1527188946995};\\\", \\\"{x:603,y:450,t:1527188947012};\\\", \\\"{x:606,y:449,t:1527188947389};\\\", \\\"{x:610,y:449,t:1527188947398};\\\", \\\"{x:615,y:451,t:1527188947412};\\\", \\\"{x:624,y:453,t:1527188947429};\\\", \\\"{x:637,y:456,t:1527188947445};\\\", \\\"{x:671,y:464,t:1527188947462};\\\", \\\"{x:696,y:469,t:1527188947480};\\\", \\\"{x:724,y:473,t:1527188947495};\\\", \\\"{x:752,y:478,t:1527188947512};\\\", \\\"{x:782,y:481,t:1527188947529};\\\", \\\"{x:804,y:484,t:1527188947545};\\\", \\\"{x:823,y:484,t:1527188947562};\\\", \\\"{x:830,y:484,t:1527188947579};\\\", \\\"{x:832,y:484,t:1527188947595};\\\", \\\"{x:832,y:483,t:1527188947679};\\\", \\\"{x:829,y:481,t:1527188947696};\\\", \\\"{x:827,y:480,t:1527188947712};\\\", \\\"{x:827,y:482,t:1527188947926};\\\", \\\"{x:829,y:482,t:1527188947950};\\\", \\\"{x:829,y:484,t:1527188948758};\\\", \\\"{x:829,y:485,t:1527188948765};\\\", \\\"{x:826,y:486,t:1527188948780};\\\", \\\"{x:822,y:490,t:1527188948797};\\\", \\\"{x:816,y:495,t:1527188948814};\\\", \\\"{x:811,y:504,t:1527188948831};\\\", \\\"{x:807,y:509,t:1527188948846};\\\", \\\"{x:803,y:518,t:1527188948864};\\\", \\\"{x:801,y:528,t:1527188948880};\\\", \\\"{x:795,y:538,t:1527188948896};\\\", \\\"{x:783,y:554,t:1527188948914};\\\", \\\"{x:770,y:569,t:1527188948930};\\\", \\\"{x:753,y:582,t:1527188948947};\\\", \\\"{x:735,y:595,t:1527188948963};\\\", \\\"{x:715,y:605,t:1527188948980};\\\", \\\"{x:695,y:614,t:1527188948997};\\\", \\\"{x:677,y:623,t:1527188949013};\\\", \\\"{x:656,y:633,t:1527188949030};\\\", \\\"{x:644,y:636,t:1527188949047};\\\", \\\"{x:632,y:639,t:1527188949063};\\\", \\\"{x:620,y:640,t:1527188949080};\\\", \\\"{x:608,y:643,t:1527188949097};\\\", \\\"{x:595,y:646,t:1527188949114};\\\", \\\"{x:586,y:650,t:1527188949130};\\\", \\\"{x:581,y:653,t:1527188949147};\\\", \\\"{x:571,y:661,t:1527188949163};\\\", \\\"{x:562,y:666,t:1527188949180};\\\", \\\"{x:552,y:671,t:1527188949197};\\\", \\\"{x:545,y:677,t:1527188949213};\\\", \\\"{x:534,y:686,t:1527188949230};\\\", \\\"{x:531,y:689,t:1527188949247};\\\", \\\"{x:530,y:691,t:1527188949263};\\\", \\\"{x:530,y:693,t:1527188949280};\\\", \\\"{x:528,y:694,t:1527188949297};\\\", \\\"{x:527,y:695,t:1527188949431};\\\", \\\"{x:525,y:695,t:1527188949447};\\\", \\\"{x:524,y:696,t:1527188949463};\\\", \\\"{x:522,y:696,t:1527188949481};\\\", \\\"{x:520,y:698,t:1527188949498};\\\", \\\"{x:515,y:699,t:1527188949513};\\\", \\\"{x:509,y:702,t:1527188949532};\\\", \\\"{x:500,y:703,t:1527188949547};\\\", \\\"{x:492,y:703,t:1527188949563};\\\", \\\"{x:487,y:703,t:1527188949580};\\\", \\\"{x:482,y:703,t:1527188949597};\\\", \\\"{x:477,y:702,t:1527188949613};\\\", \\\"{x:476,y:701,t:1527188949630};\\\", \\\"{x:473,y:698,t:1527188949647};\\\", \\\"{x:472,y:697,t:1527188949664};\\\", \\\"{x:471,y:696,t:1527188949680};\\\", \\\"{x:471,y:694,t:1527188950110};\\\", \\\"{x:472,y:692,t:1527188950118};\\\", \\\"{x:474,y:690,t:1527188950131};\\\", \\\"{x:475,y:687,t:1527188950147};\\\", \\\"{x:475,y:686,t:1527188950165};\\\", \\\"{x:475,y:685,t:1527188950181};\\\", \\\"{x:476,y:685,t:1527188950197};\\\", \\\"{x:476,y:683,t:1527188951159};\\\", \\\"{x:476,y:682,t:1527188951174};\\\", \\\"{x:476,y:680,t:1527188951190};\\\" ] }, { \\\"rt\\\": 20483, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 355786, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:677,t:1527188959774};\\\", \\\"{x:510,y:667,t:1527188959790};\\\", \\\"{x:544,y:661,t:1527188959807};\\\", \\\"{x:630,y:650,t:1527188959823};\\\", \\\"{x:713,y:641,t:1527188959839};\\\", \\\"{x:792,y:626,t:1527188959856};\\\", \\\"{x:878,y:613,t:1527188959871};\\\", \\\"{x:954,y:600,t:1527188959889};\\\", \\\"{x:1048,y:589,t:1527188959905};\\\", \\\"{x:1134,y:575,t:1527188959922};\\\", \\\"{x:1201,y:567,t:1527188959939};\\\", \\\"{x:1254,y:559,t:1527188959955};\\\", \\\"{x:1284,y:543,t:1527188959971};\\\", \\\"{x:1295,y:536,t:1527188959989};\\\", \\\"{x:1303,y:523,t:1527188960006};\\\", \\\"{x:1306,y:517,t:1527188960022};\\\", \\\"{x:1310,y:513,t:1527188960038};\\\", \\\"{x:1314,y:509,t:1527188960056};\\\", \\\"{x:1313,y:509,t:1527188960159};\\\", \\\"{x:1308,y:511,t:1527188960173};\\\", \\\"{x:1292,y:519,t:1527188960189};\\\", \\\"{x:1270,y:531,t:1527188960206};\\\", \\\"{x:1256,y:537,t:1527188960223};\\\", \\\"{x:1249,y:543,t:1527188960239};\\\", \\\"{x:1245,y:547,t:1527188960256};\\\", \\\"{x:1240,y:549,t:1527188960283};\\\", \\\"{x:1239,y:550,t:1527188960288};\\\", \\\"{x:1237,y:550,t:1527188960317};\\\", \\\"{x:1237,y:551,t:1527188960349};\\\", \\\"{x:1237,y:553,t:1527188960365};\\\", \\\"{x:1237,y:554,t:1527188960374};\\\", \\\"{x:1237,y:557,t:1527188960388};\\\", \\\"{x:1236,y:560,t:1527188960405};\\\", \\\"{x:1236,y:561,t:1527188960422};\\\", \\\"{x:1236,y:562,t:1527188960439};\\\", \\\"{x:1236,y:563,t:1527188960455};\\\", \\\"{x:1236,y:564,t:1527188960473};\\\", \\\"{x:1236,y:566,t:1527188960489};\\\", \\\"{x:1236,y:567,t:1527188960517};\\\", \\\"{x:1236,y:568,t:1527188960534};\\\", \\\"{x:1236,y:569,t:1527188960559};\\\", \\\"{x:1236,y:570,t:1527188960591};\\\", \\\"{x:1237,y:572,t:1527188960631};\\\", \\\"{x:1237,y:573,t:1527188960640};\\\", \\\"{x:1239,y:574,t:1527188960656};\\\", \\\"{x:1241,y:576,t:1527188960673};\\\", \\\"{x:1241,y:577,t:1527188960691};\\\", \\\"{x:1244,y:578,t:1527188960752};\\\", \\\"{x:1245,y:578,t:1527188960759};\\\", \\\"{x:1247,y:578,t:1527188960774};\\\", \\\"{x:1255,y:579,t:1527188960791};\\\", \\\"{x:1260,y:579,t:1527188960806};\\\", \\\"{x:1261,y:579,t:1527188960823};\\\", \\\"{x:1262,y:579,t:1527188965423};\\\", \\\"{x:1262,y:578,t:1527188965430};\\\", \\\"{x:1257,y:575,t:1527188965443};\\\", \\\"{x:1250,y:571,t:1527188965461};\\\", \\\"{x:1247,y:570,t:1527188965477};\\\", \\\"{x:1246,y:570,t:1527188965767};\\\", \\\"{x:1246,y:571,t:1527188966463};\\\", \\\"{x:1254,y:578,t:1527188966478};\\\", \\\"{x:1260,y:596,t:1527188966494};\\\", \\\"{x:1273,y:618,t:1527188966511};\\\", \\\"{x:1287,y:631,t:1527188966527};\\\", \\\"{x:1303,y:642,t:1527188966544};\\\", \\\"{x:1321,y:651,t:1527188966561};\\\", \\\"{x:1335,y:654,t:1527188966578};\\\", \\\"{x:1343,y:655,t:1527188966594};\\\", \\\"{x:1347,y:655,t:1527188966610};\\\", \\\"{x:1349,y:655,t:1527188966627};\\\", \\\"{x:1352,y:655,t:1527188966645};\\\", \\\"{x:1355,y:654,t:1527188966660};\\\", \\\"{x:1359,y:652,t:1527188966678};\\\", \\\"{x:1366,y:647,t:1527188966694};\\\", \\\"{x:1368,y:645,t:1527188966711};\\\", \\\"{x:1369,y:642,t:1527188966728};\\\", \\\"{x:1369,y:641,t:1527188966744};\\\", \\\"{x:1368,y:638,t:1527188966761};\\\", \\\"{x:1367,y:637,t:1527188966777};\\\", \\\"{x:1366,y:637,t:1527188966878};\\\", \\\"{x:1365,y:637,t:1527188966894};\\\", \\\"{x:1363,y:637,t:1527188966911};\\\", \\\"{x:1361,y:637,t:1527188966927};\\\", \\\"{x:1360,y:637,t:1527188966944};\\\", \\\"{x:1358,y:637,t:1527188966961};\\\", \\\"{x:1357,y:637,t:1527188966982};\\\", \\\"{x:1355,y:637,t:1527188966999};\\\", \\\"{x:1354,y:637,t:1527188967014};\\\", \\\"{x:1353,y:638,t:1527188967027};\\\", \\\"{x:1352,y:639,t:1527188967045};\\\", \\\"{x:1352,y:640,t:1527188967088};\\\", \\\"{x:1352,y:641,t:1527188968583};\\\", \\\"{x:1348,y:643,t:1527188968595};\\\", \\\"{x:1335,y:651,t:1527188968614};\\\", \\\"{x:1296,y:662,t:1527188968629};\\\", \\\"{x:1217,y:669,t:1527188968645};\\\", \\\"{x:1045,y:669,t:1527188968662};\\\", \\\"{x:909,y:669,t:1527188968679};\\\", \\\"{x:763,y:653,t:1527188968695};\\\", \\\"{x:624,y:629,t:1527188968713};\\\", \\\"{x:523,y:607,t:1527188968730};\\\", \\\"{x:476,y:589,t:1527188968747};\\\", \\\"{x:464,y:582,t:1527188968763};\\\", \\\"{x:461,y:579,t:1527188968779};\\\", \\\"{x:461,y:576,t:1527188968797};\\\", \\\"{x:461,y:574,t:1527188968812};\\\", \\\"{x:464,y:569,t:1527188968829};\\\", \\\"{x:472,y:563,t:1527188968846};\\\", \\\"{x:482,y:553,t:1527188968863};\\\", \\\"{x:496,y:537,t:1527188968880};\\\", \\\"{x:518,y:518,t:1527188968897};\\\", \\\"{x:544,y:496,t:1527188968914};\\\", \\\"{x:578,y:471,t:1527188968930};\\\", \\\"{x:602,y:454,t:1527188968947};\\\", \\\"{x:621,y:440,t:1527188968963};\\\", \\\"{x:631,y:433,t:1527188968981};\\\", \\\"{x:633,y:432,t:1527188968997};\\\", \\\"{x:633,y:431,t:1527188969013};\\\", \\\"{x:634,y:431,t:1527188969070};\\\", \\\"{x:637,y:431,t:1527188969080};\\\", \\\"{x:645,y:436,t:1527188969098};\\\", \\\"{x:661,y:444,t:1527188969113};\\\", \\\"{x:681,y:455,t:1527188969130};\\\", \\\"{x:698,y:460,t:1527188969147};\\\", \\\"{x:716,y:461,t:1527188969163};\\\", \\\"{x:731,y:461,t:1527188969181};\\\", \\\"{x:736,y:461,t:1527188969196};\\\", \\\"{x:741,y:458,t:1527188969213};\\\", \\\"{x:743,y:456,t:1527188969229};\\\", \\\"{x:746,y:455,t:1527188969247};\\\", \\\"{x:753,y:451,t:1527188969263};\\\", \\\"{x:764,y:446,t:1527188969280};\\\", \\\"{x:773,y:443,t:1527188969297};\\\", \\\"{x:778,y:440,t:1527188969313};\\\", \\\"{x:782,y:439,t:1527188969330};\\\", \\\"{x:783,y:439,t:1527188969350};\\\", \\\"{x:784,y:439,t:1527188969375};\\\", \\\"{x:785,y:439,t:1527188969382};\\\", \\\"{x:789,y:439,t:1527188969397};\\\", \\\"{x:814,y:439,t:1527188969414};\\\", \\\"{x:825,y:439,t:1527188969430};\\\", \\\"{x:841,y:439,t:1527188969448};\\\", \\\"{x:851,y:439,t:1527188969464};\\\", \\\"{x:853,y:440,t:1527188969479};\\\", \\\"{x:852,y:441,t:1527188969703};\\\", \\\"{x:851,y:441,t:1527188969726};\\\", \\\"{x:850,y:442,t:1527188969742};\\\", \\\"{x:849,y:443,t:1527188969750};\\\", \\\"{x:847,y:444,t:1527188969764};\\\", \\\"{x:846,y:446,t:1527188969781};\\\", \\\"{x:844,y:449,t:1527188969797};\\\", \\\"{x:843,y:451,t:1527188969814};\\\", \\\"{x:842,y:452,t:1527188969831};\\\", \\\"{x:840,y:452,t:1527188970086};\\\", \\\"{x:834,y:452,t:1527188970097};\\\", \\\"{x:813,y:453,t:1527188970114};\\\", \\\"{x:790,y:454,t:1527188970131};\\\", \\\"{x:763,y:458,t:1527188970147};\\\", \\\"{x:729,y:470,t:1527188970165};\\\", \\\"{x:683,y:487,t:1527188970181};\\\", \\\"{x:571,y:538,t:1527188970198};\\\", \\\"{x:491,y:584,t:1527188970215};\\\", \\\"{x:438,y:611,t:1527188970231};\\\", \\\"{x:403,y:627,t:1527188970248};\\\", \\\"{x:380,y:637,t:1527188970264};\\\", \\\"{x:361,y:641,t:1527188970281};\\\", \\\"{x:343,y:641,t:1527188970298};\\\", \\\"{x:320,y:640,t:1527188970314};\\\", \\\"{x:289,y:631,t:1527188970331};\\\", \\\"{x:262,y:625,t:1527188970348};\\\", \\\"{x:248,y:619,t:1527188970366};\\\", \\\"{x:242,y:613,t:1527188970382};\\\", \\\"{x:238,y:601,t:1527188970398};\\\", \\\"{x:238,y:595,t:1527188970415};\\\", \\\"{x:238,y:589,t:1527188970431};\\\", \\\"{x:240,y:584,t:1527188970449};\\\", \\\"{x:241,y:582,t:1527188970465};\\\", \\\"{x:241,y:581,t:1527188970481};\\\", \\\"{x:241,y:577,t:1527188970499};\\\", \\\"{x:237,y:572,t:1527188970515};\\\", \\\"{x:226,y:562,t:1527188970531};\\\", \\\"{x:213,y:554,t:1527188970548};\\\", \\\"{x:201,y:546,t:1527188970566};\\\", \\\"{x:185,y:535,t:1527188970582};\\\", \\\"{x:166,y:525,t:1527188970597};\\\", \\\"{x:159,y:520,t:1527188970615};\\\", \\\"{x:157,y:519,t:1527188970631};\\\", \\\"{x:155,y:518,t:1527188970649};\\\", \\\"{x:154,y:517,t:1527188970665};\\\", \\\"{x:154,y:516,t:1527188970710};\\\", \\\"{x:154,y:515,t:1527188970759};\\\", \\\"{x:154,y:514,t:1527188970774};\\\", \\\"{x:154,y:513,t:1527188970782};\\\", \\\"{x:155,y:512,t:1527188970799};\\\", \\\"{x:156,y:510,t:1527188970814};\\\", \\\"{x:156,y:506,t:1527188970832};\\\", \\\"{x:156,y:502,t:1527188970849};\\\", \\\"{x:156,y:498,t:1527188970865};\\\", \\\"{x:156,y:491,t:1527188970881};\\\", \\\"{x:156,y:488,t:1527188970898};\\\", \\\"{x:156,y:486,t:1527188970915};\\\", \\\"{x:158,y:484,t:1527188970931};\\\", \\\"{x:158,y:483,t:1527188970950};\\\", \\\"{x:159,y:482,t:1527188970965};\\\", \\\"{x:160,y:481,t:1527188971214};\\\", \\\"{x:164,y:482,t:1527188971232};\\\", \\\"{x:173,y:485,t:1527188971248};\\\", \\\"{x:180,y:488,t:1527188971265};\\\", \\\"{x:186,y:491,t:1527188971282};\\\", \\\"{x:194,y:498,t:1527188971299};\\\", \\\"{x:200,y:503,t:1527188971315};\\\", \\\"{x:208,y:516,t:1527188971333};\\\", \\\"{x:219,y:531,t:1527188971349};\\\", \\\"{x:232,y:548,t:1527188971365};\\\", \\\"{x:256,y:575,t:1527188971381};\\\", \\\"{x:274,y:592,t:1527188971398};\\\", \\\"{x:297,y:607,t:1527188971415};\\\", \\\"{x:335,y:628,t:1527188971433};\\\", \\\"{x:376,y:646,t:1527188971448};\\\", \\\"{x:433,y:666,t:1527188971465};\\\", \\\"{x:480,y:678,t:1527188971482};\\\", \\\"{x:517,y:689,t:1527188971499};\\\", \\\"{x:538,y:693,t:1527188971515};\\\", \\\"{x:543,y:694,t:1527188971532};\\\", \\\"{x:544,y:694,t:1527188971549};\\\", \\\"{x:544,y:691,t:1527188971574};\\\", \\\"{x:541,y:685,t:1527188971582};\\\", \\\"{x:536,y:674,t:1527188971599};\\\", \\\"{x:532,y:666,t:1527188971616};\\\", \\\"{x:527,y:659,t:1527188971632};\\\", \\\"{x:525,y:656,t:1527188971649};\\\", \\\"{x:526,y:656,t:1527188971758};\\\", \\\"{x:527,y:656,t:1527188971766};\\\", \\\"{x:527,y:659,t:1527188971782};\\\", \\\"{x:528,y:664,t:1527188971799};\\\", \\\"{x:528,y:671,t:1527188971816};\\\", \\\"{x:528,y:673,t:1527188971832};\\\", \\\"{x:528,y:674,t:1527188971849};\\\", \\\"{x:528,y:675,t:1527188971866};\\\", \\\"{x:528,y:676,t:1527188971902};\\\", \\\"{x:528,y:677,t:1527188971916};\\\", \\\"{x:528,y:678,t:1527188971932};\\\", \\\"{x:528,y:680,t:1527188971949};\\\", \\\"{x:528,y:681,t:1527188971967};\\\", \\\"{x:531,y:678,t:1527188972518};\\\", \\\"{x:545,y:668,t:1527188972533};\\\", \\\"{x:586,y:636,t:1527188972549};\\\", \\\"{x:697,y:562,t:1527188972566};\\\", \\\"{x:787,y:510,t:1527188972583};\\\", \\\"{x:873,y:456,t:1527188972600};\\\", \\\"{x:936,y:416,t:1527188972617};\\\", \\\"{x:967,y:393,t:1527188972633};\\\", \\\"{x:981,y:380,t:1527188972650};\\\", \\\"{x:983,y:378,t:1527188972667};\\\" ] }, { \\\"rt\\\": 35719, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 392766, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B -B -F -F -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:983,y:379,t:1527188977050};\\\", \\\"{x:983,y:386,t:1527188977058};\\\", \\\"{x:981,y:400,t:1527188977081};\\\", \\\"{x:979,y:417,t:1527188977090};\\\", \\\"{x:978,y:434,t:1527188977107};\\\", \\\"{x:981,y:453,t:1527188977124};\\\", \\\"{x:991,y:470,t:1527188977140};\\\", \\\"{x:1002,y:485,t:1527188977157};\\\", \\\"{x:1016,y:498,t:1527188977174};\\\", \\\"{x:1036,y:509,t:1527188977190};\\\", \\\"{x:1069,y:525,t:1527188977207};\\\", \\\"{x:1105,y:541,t:1527188977224};\\\", \\\"{x:1158,y:563,t:1527188977240};\\\", \\\"{x:1243,y:593,t:1527188977257};\\\", \\\"{x:1300,y:605,t:1527188977274};\\\", \\\"{x:1350,y:611,t:1527188977290};\\\", \\\"{x:1391,y:614,t:1527188977307};\\\", \\\"{x:1423,y:614,t:1527188977324};\\\", \\\"{x:1442,y:614,t:1527188977340};\\\", \\\"{x:1445,y:614,t:1527188977357};\\\", \\\"{x:1446,y:613,t:1527188977374};\\\", \\\"{x:1446,y:611,t:1527188977391};\\\", \\\"{x:1446,y:607,t:1527188977407};\\\", \\\"{x:1446,y:604,t:1527188977424};\\\", \\\"{x:1443,y:594,t:1527188977441};\\\", \\\"{x:1435,y:583,t:1527188977458};\\\", \\\"{x:1421,y:572,t:1527188977474};\\\", \\\"{x:1398,y:559,t:1527188977492};\\\", \\\"{x:1383,y:550,t:1527188977507};\\\", \\\"{x:1373,y:545,t:1527188977524};\\\", \\\"{x:1370,y:544,t:1527188977542};\\\", \\\"{x:1369,y:544,t:1527188977586};\\\", \\\"{x:1368,y:544,t:1527188977602};\\\", \\\"{x:1366,y:544,t:1527188977610};\\\", \\\"{x:1365,y:548,t:1527188977625};\\\", \\\"{x:1357,y:573,t:1527188977642};\\\", \\\"{x:1354,y:590,t:1527188977658};\\\", \\\"{x:1351,y:605,t:1527188977674};\\\", \\\"{x:1349,y:621,t:1527188977692};\\\", \\\"{x:1347,y:636,t:1527188977708};\\\", \\\"{x:1347,y:643,t:1527188977727};\\\", \\\"{x:1347,y:646,t:1527188977741};\\\", \\\"{x:1347,y:648,t:1527188977905};\\\", \\\"{x:1347,y:650,t:1527188977922};\\\", \\\"{x:1347,y:652,t:1527188977938};\\\", \\\"{x:1347,y:653,t:1527188977945};\\\", \\\"{x:1347,y:654,t:1527188977958};\\\", \\\"{x:1347,y:656,t:1527188977975};\\\", \\\"{x:1347,y:657,t:1527188977992};\\\", \\\"{x:1347,y:660,t:1527188978009};\\\", \\\"{x:1348,y:663,t:1527188978024};\\\", \\\"{x:1349,y:667,t:1527188978042};\\\", \\\"{x:1349,y:670,t:1527188978058};\\\", \\\"{x:1349,y:674,t:1527188978075};\\\", \\\"{x:1349,y:677,t:1527188978092};\\\", \\\"{x:1350,y:681,t:1527188978108};\\\", \\\"{x:1351,y:685,t:1527188978124};\\\", \\\"{x:1352,y:687,t:1527188978141};\\\", \\\"{x:1353,y:688,t:1527188978158};\\\", \\\"{x:1353,y:689,t:1527188978210};\\\", \\\"{x:1353,y:690,t:1527188978298};\\\", \\\"{x:1353,y:693,t:1527188978314};\\\", \\\"{x:1353,y:694,t:1527188978330};\\\", \\\"{x:1352,y:697,t:1527188978342};\\\", \\\"{x:1352,y:698,t:1527188978359};\\\", \\\"{x:1352,y:700,t:1527188978376};\\\", \\\"{x:1352,y:702,t:1527188978391};\\\", \\\"{x:1352,y:703,t:1527188978409};\\\", \\\"{x:1352,y:704,t:1527188978450};\\\", \\\"{x:1352,y:705,t:1527188978466};\\\", \\\"{x:1352,y:706,t:1527188978476};\\\", \\\"{x:1351,y:707,t:1527188978492};\\\", \\\"{x:1350,y:708,t:1527188978509};\\\", \\\"{x:1350,y:709,t:1527188978530};\\\", \\\"{x:1350,y:710,t:1527188978541};\\\", \\\"{x:1349,y:712,t:1527188978558};\\\", \\\"{x:1346,y:716,t:1527188978575};\\\", \\\"{x:1345,y:719,t:1527188978591};\\\", \\\"{x:1345,y:720,t:1527188978608};\\\", \\\"{x:1343,y:721,t:1527188978625};\\\", \\\"{x:1343,y:720,t:1527188981762};\\\", \\\"{x:1343,y:717,t:1527188981776};\\\", \\\"{x:1345,y:716,t:1527188981793};\\\", \\\"{x:1346,y:715,t:1527188981811};\\\", \\\"{x:1347,y:713,t:1527188981827};\\\", \\\"{x:1346,y:712,t:1527188982186};\\\", \\\"{x:1343,y:712,t:1527188982195};\\\", \\\"{x:1340,y:712,t:1527188982213};\\\", \\\"{x:1339,y:712,t:1527188982228};\\\", \\\"{x:1338,y:712,t:1527188982244};\\\", \\\"{x:1336,y:711,t:1527188982261};\\\", \\\"{x:1332,y:712,t:1527188983754};\\\", \\\"{x:1322,y:717,t:1527188983763};\\\", \\\"{x:1306,y:723,t:1527188983780};\\\", \\\"{x:1287,y:732,t:1527188983796};\\\", \\\"{x:1264,y:742,t:1527188983814};\\\", \\\"{x:1250,y:747,t:1527188983830};\\\", \\\"{x:1245,y:749,t:1527188983846};\\\", \\\"{x:1245,y:747,t:1527188983995};\\\", \\\"{x:1243,y:745,t:1527188984002};\\\", \\\"{x:1242,y:739,t:1527188984014};\\\", \\\"{x:1241,y:734,t:1527188984029};\\\", \\\"{x:1238,y:728,t:1527188984046};\\\", \\\"{x:1236,y:726,t:1527188984062};\\\", \\\"{x:1230,y:723,t:1527188984079};\\\", \\\"{x:1221,y:720,t:1527188984097};\\\", \\\"{x:1210,y:718,t:1527188984112};\\\", \\\"{x:1195,y:715,t:1527188984129};\\\", \\\"{x:1190,y:715,t:1527188984147};\\\", \\\"{x:1187,y:714,t:1527188984163};\\\", \\\"{x:1187,y:715,t:1527188984379};\\\", \\\"{x:1186,y:721,t:1527188984394};\\\", \\\"{x:1186,y:723,t:1527188984402};\\\", \\\"{x:1186,y:729,t:1527188984414};\\\", \\\"{x:1186,y:742,t:1527188984430};\\\", \\\"{x:1186,y:756,t:1527188984447};\\\", \\\"{x:1188,y:766,t:1527188984464};\\\", \\\"{x:1190,y:779,t:1527188984480};\\\", \\\"{x:1195,y:786,t:1527188984496};\\\", \\\"{x:1198,y:792,t:1527188984513};\\\", \\\"{x:1201,y:795,t:1527188984529};\\\", \\\"{x:1203,y:797,t:1527188984546};\\\", \\\"{x:1203,y:798,t:1527188984601};\\\", \\\"{x:1203,y:799,t:1527188984641};\\\", \\\"{x:1204,y:800,t:1527188984698};\\\", \\\"{x:1205,y:800,t:1527188984730};\\\", \\\"{x:1206,y:800,t:1527188984747};\\\", \\\"{x:1207,y:800,t:1527188984764};\\\", \\\"{x:1209,y:800,t:1527188984780};\\\", \\\"{x:1210,y:800,t:1527188984797};\\\", \\\"{x:1211,y:797,t:1527188984814};\\\", \\\"{x:1213,y:793,t:1527188984830};\\\", \\\"{x:1214,y:792,t:1527188984847};\\\", \\\"{x:1214,y:789,t:1527188984864};\\\", \\\"{x:1214,y:788,t:1527188984882};\\\", \\\"{x:1214,y:786,t:1527188991859};\\\", \\\"{x:1215,y:786,t:1527188992650};\\\", \\\"{x:1217,y:786,t:1527188992658};\\\", \\\"{x:1221,y:786,t:1527188992670};\\\", \\\"{x:1228,y:786,t:1527188992686};\\\", \\\"{x:1233,y:785,t:1527188992703};\\\", \\\"{x:1252,y:781,t:1527188992720};\\\", \\\"{x:1269,y:774,t:1527188992736};\\\", \\\"{x:1285,y:768,t:1527188992753};\\\", \\\"{x:1309,y:757,t:1527188992770};\\\", \\\"{x:1330,y:752,t:1527188992787};\\\", \\\"{x:1350,y:746,t:1527188992803};\\\", \\\"{x:1366,y:742,t:1527188992821};\\\", \\\"{x:1375,y:737,t:1527188992838};\\\", \\\"{x:1379,y:736,t:1527188992853};\\\", \\\"{x:1381,y:736,t:1527188992870};\\\", \\\"{x:1382,y:735,t:1527188992987};\\\", \\\"{x:1382,y:732,t:1527188993003};\\\", \\\"{x:1381,y:726,t:1527188993020};\\\", \\\"{x:1372,y:714,t:1527188993037};\\\", \\\"{x:1360,y:707,t:1527188993053};\\\", \\\"{x:1349,y:702,t:1527188993070};\\\", \\\"{x:1347,y:701,t:1527188993087};\\\", \\\"{x:1346,y:701,t:1527188993103};\\\", \\\"{x:1344,y:700,t:1527188996410};\\\", \\\"{x:1344,y:693,t:1527188996423};\\\", \\\"{x:1344,y:680,t:1527188996440};\\\", \\\"{x:1344,y:664,t:1527188996456};\\\", \\\"{x:1344,y:646,t:1527188996473};\\\", \\\"{x:1344,y:637,t:1527188996489};\\\", \\\"{x:1344,y:631,t:1527188996506};\\\", \\\"{x:1344,y:628,t:1527188996523};\\\", \\\"{x:1344,y:625,t:1527188996539};\\\", \\\"{x:1344,y:623,t:1527188996555};\\\", \\\"{x:1344,y:622,t:1527188996572};\\\", \\\"{x:1344,y:621,t:1527188998290};\\\", \\\"{x:1343,y:615,t:1527188998307};\\\", \\\"{x:1337,y:602,t:1527188998325};\\\", \\\"{x:1334,y:591,t:1527188998341};\\\", \\\"{x:1332,y:585,t:1527188998357};\\\", \\\"{x:1331,y:579,t:1527188998375};\\\", \\\"{x:1329,y:575,t:1527188998392};\\\", \\\"{x:1327,y:569,t:1527188998407};\\\", \\\"{x:1323,y:563,t:1527188998425};\\\", \\\"{x:1311,y:550,t:1527188998441};\\\", \\\"{x:1301,y:536,t:1527188998458};\\\", \\\"{x:1288,y:520,t:1527188998474};\\\", \\\"{x:1278,y:508,t:1527188998492};\\\", \\\"{x:1269,y:498,t:1527188998510};\\\", \\\"{x:1266,y:494,t:1527188998524};\\\", \\\"{x:1266,y:492,t:1527188998542};\\\", \\\"{x:1267,y:492,t:1527188998658};\\\", \\\"{x:1270,y:493,t:1527188998674};\\\", \\\"{x:1274,y:494,t:1527188998692};\\\", \\\"{x:1277,y:497,t:1527188998709};\\\", \\\"{x:1279,y:502,t:1527188998724};\\\", \\\"{x:1281,y:505,t:1527188998742};\\\", \\\"{x:1281,y:507,t:1527188998758};\\\", \\\"{x:1282,y:510,t:1527188998775};\\\", \\\"{x:1282,y:511,t:1527188998791};\\\", \\\"{x:1282,y:514,t:1527188998808};\\\", \\\"{x:1282,y:516,t:1527188998825};\\\", \\\"{x:1283,y:517,t:1527188998841};\\\", \\\"{x:1284,y:518,t:1527189004074};\\\", \\\"{x:1283,y:520,t:1527189007274};\\\", \\\"{x:1268,y:529,t:1527189007281};\\\", \\\"{x:1220,y:553,t:1527189007299};\\\", \\\"{x:1145,y:586,t:1527189007314};\\\", \\\"{x:1043,y:627,t:1527189007332};\\\", \\\"{x:937,y:668,t:1527189007349};\\\", \\\"{x:845,y:695,t:1527189007364};\\\", \\\"{x:767,y:718,t:1527189007382};\\\", \\\"{x:717,y:724,t:1527189007399};\\\", \\\"{x:684,y:724,t:1527189007414};\\\", \\\"{x:656,y:717,t:1527189007431};\\\", \\\"{x:632,y:704,t:1527189007448};\\\", \\\"{x:602,y:670,t:1527189007465};\\\", \\\"{x:579,y:642,t:1527189007481};\\\", \\\"{x:538,y:604,t:1527189007499};\\\", \\\"{x:472,y:561,t:1527189007517};\\\", \\\"{x:381,y:524,t:1527189007531};\\\", \\\"{x:321,y:502,t:1527189007552};\\\", \\\"{x:294,y:496,t:1527189007582};\\\", \\\"{x:293,y:496,t:1527189007599};\\\", \\\"{x:296,y:497,t:1527189007616};\\\", \\\"{x:308,y:497,t:1527189007632};\\\", \\\"{x:339,y:488,t:1527189007649};\\\", \\\"{x:363,y:479,t:1527189007666};\\\", \\\"{x:392,y:466,t:1527189007682};\\\", \\\"{x:422,y:459,t:1527189007700};\\\", \\\"{x:463,y:454,t:1527189007715};\\\", \\\"{x:490,y:453,t:1527189007732};\\\", \\\"{x:504,y:453,t:1527189007750};\\\", \\\"{x:505,y:453,t:1527189007857};\\\", \\\"{x:507,y:453,t:1527189007866};\\\", \\\"{x:509,y:453,t:1527189007883};\\\", \\\"{x:515,y:454,t:1527189007900};\\\", \\\"{x:535,y:456,t:1527189007916};\\\", \\\"{x:561,y:461,t:1527189007934};\\\", \\\"{x:590,y:465,t:1527189007951};\\\", \\\"{x:609,y:467,t:1527189007967};\\\", \\\"{x:612,y:467,t:1527189007983};\\\", \\\"{x:612,y:466,t:1527189008033};\\\", \\\"{x:611,y:466,t:1527189008065};\\\", \\\"{x:610,y:466,t:1527189008081};\\\", \\\"{x:606,y:464,t:1527189008090};\\\", \\\"{x:605,y:464,t:1527189008099};\\\", \\\"{x:604,y:463,t:1527189008116};\\\", \\\"{x:603,y:462,t:1527189008134};\\\", \\\"{x:603,y:461,t:1527189008177};\\\", \\\"{x:604,y:461,t:1527189008185};\\\", \\\"{x:604,y:460,t:1527189008203};\\\", \\\"{x:605,y:459,t:1527189008216};\\\", \\\"{x:606,y:458,t:1527189008257};\\\", \\\"{x:607,y:458,t:1527189008297};\\\", \\\"{x:606,y:458,t:1527189008473};\\\", \\\"{x:604,y:458,t:1527189008483};\\\", \\\"{x:594,y:478,t:1527189008501};\\\", \\\"{x:578,y:520,t:1527189008517};\\\", \\\"{x:547,y:589,t:1527189008533};\\\", \\\"{x:526,y:654,t:1527189008550};\\\", \\\"{x:510,y:705,t:1527189008566};\\\", \\\"{x:507,y:727,t:1527189008583};\\\", \\\"{x:507,y:737,t:1527189008600};\\\", \\\"{x:508,y:741,t:1527189008617};\\\", \\\"{x:508,y:742,t:1527189008633};\\\", \\\"{x:508,y:741,t:1527189008681};\\\", \\\"{x:511,y:737,t:1527189008689};\\\", \\\"{x:511,y:735,t:1527189008700};\\\", \\\"{x:512,y:729,t:1527189008717};\\\", \\\"{x:515,y:720,t:1527189008734};\\\", \\\"{x:519,y:709,t:1527189008750};\\\", \\\"{x:521,y:699,t:1527189008767};\\\", \\\"{x:524,y:688,t:1527189008783};\\\", \\\"{x:526,y:683,t:1527189008800};\\\", \\\"{x:527,y:680,t:1527189008817};\\\", \\\"{x:527,y:679,t:1527189008841};\\\" ] }, { \\\"rt\\\": 76145, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 470166, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -I -I -B -I -I -B -J -J -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:680,t:1527189014786};\\\", \\\"{x:526,y:687,t:1527189014803};\\\", \\\"{x:522,y:700,t:1527189014818};\\\", \\\"{x:521,y:710,t:1527189014836};\\\", \\\"{x:519,y:723,t:1527189014852};\\\", \\\"{x:521,y:733,t:1527189014870};\\\", \\\"{x:538,y:748,t:1527189014888};\\\", \\\"{x:562,y:760,t:1527189014906};\\\", \\\"{x:598,y:769,t:1527189014922};\\\", \\\"{x:651,y:777,t:1527189014939};\\\", \\\"{x:732,y:786,t:1527189014956};\\\", \\\"{x:826,y:799,t:1527189014971};\\\", \\\"{x:927,y:803,t:1527189014988};\\\", \\\"{x:1019,y:809,t:1527189015006};\\\", \\\"{x:1100,y:809,t:1527189015021};\\\", \\\"{x:1165,y:811,t:1527189015038};\\\", \\\"{x:1213,y:814,t:1527189015056};\\\", \\\"{x:1239,y:814,t:1527189015071};\\\", \\\"{x:1266,y:810,t:1527189015089};\\\", \\\"{x:1274,y:805,t:1527189015105};\\\", \\\"{x:1279,y:802,t:1527189015121};\\\", \\\"{x:1284,y:799,t:1527189015139};\\\", \\\"{x:1291,y:796,t:1527189015156};\\\", \\\"{x:1300,y:790,t:1527189015172};\\\", \\\"{x:1306,y:785,t:1527189015189};\\\", \\\"{x:1313,y:779,t:1527189015205};\\\", \\\"{x:1316,y:777,t:1527189015223};\\\", \\\"{x:1317,y:775,t:1527189015239};\\\", \\\"{x:1317,y:770,t:1527189015255};\\\", \\\"{x:1317,y:769,t:1527189015272};\\\", \\\"{x:1317,y:766,t:1527189015345};\\\", \\\"{x:1315,y:763,t:1527189015355};\\\", \\\"{x:1306,y:758,t:1527189015372};\\\", \\\"{x:1303,y:757,t:1527189015388};\\\", \\\"{x:1301,y:757,t:1527189015405};\\\", \\\"{x:1300,y:756,t:1527189015422};\\\", \\\"{x:1294,y:754,t:1527189015439};\\\", \\\"{x:1286,y:754,t:1527189015455};\\\", \\\"{x:1273,y:754,t:1527189015473};\\\", \\\"{x:1268,y:754,t:1527189015488};\\\", \\\"{x:1264,y:756,t:1527189015506};\\\", \\\"{x:1261,y:758,t:1527189015523};\\\", \\\"{x:1256,y:761,t:1527189015538};\\\", \\\"{x:1254,y:762,t:1527189015556};\\\", \\\"{x:1249,y:763,t:1527189015573};\\\", \\\"{x:1245,y:766,t:1527189015589};\\\", \\\"{x:1243,y:766,t:1527189015606};\\\", \\\"{x:1242,y:767,t:1527189015623};\\\", \\\"{x:1240,y:768,t:1527189015640};\\\", \\\"{x:1239,y:769,t:1527189015656};\\\", \\\"{x:1238,y:769,t:1527189015690};\\\", \\\"{x:1238,y:770,t:1527189015890};\\\", \\\"{x:1236,y:770,t:1527189015906};\\\", \\\"{x:1235,y:771,t:1527189015923};\\\", \\\"{x:1234,y:771,t:1527189015941};\\\", \\\"{x:1233,y:772,t:1527189016010};\\\", \\\"{x:1231,y:774,t:1527189016023};\\\", \\\"{x:1226,y:776,t:1527189016040};\\\", \\\"{x:1221,y:777,t:1527189016056};\\\", \\\"{x:1216,y:779,t:1527189016076};\\\", \\\"{x:1213,y:780,t:1527189016090};\\\", \\\"{x:1211,y:781,t:1527189016106};\\\", \\\"{x:1209,y:781,t:1527189016123};\\\", \\\"{x:1208,y:783,t:1527189016139};\\\", \\\"{x:1204,y:784,t:1527189016157};\\\", \\\"{x:1199,y:786,t:1527189016172};\\\", \\\"{x:1198,y:786,t:1527189016190};\\\", \\\"{x:1196,y:786,t:1527189016386};\\\", \\\"{x:1195,y:786,t:1527189016410};\\\", \\\"{x:1194,y:786,t:1527189016450};\\\", \\\"{x:1193,y:786,t:1527189016482};\\\", \\\"{x:1193,y:784,t:1527189016498};\\\", \\\"{x:1193,y:783,t:1527189016507};\\\", \\\"{x:1191,y:781,t:1527189016523};\\\", \\\"{x:1191,y:780,t:1527189016540};\\\", \\\"{x:1191,y:779,t:1527189016557};\\\", \\\"{x:1191,y:778,t:1527189016585};\\\", \\\"{x:1195,y:778,t:1527189018106};\\\", \\\"{x:1200,y:778,t:1527189018113};\\\", \\\"{x:1203,y:778,t:1527189018125};\\\", \\\"{x:1205,y:778,t:1527189018141};\\\", \\\"{x:1207,y:778,t:1527189018158};\\\", \\\"{x:1208,y:778,t:1527189018464};\\\", \\\"{x:1209,y:778,t:1527189018475};\\\", \\\"{x:1210,y:778,t:1527189018492};\\\", \\\"{x:1211,y:777,t:1527189023617};\\\", \\\"{x:1211,y:772,t:1527189023629};\\\", \\\"{x:1207,y:762,t:1527189023648};\\\", \\\"{x:1199,y:751,t:1527189023663};\\\", \\\"{x:1195,y:746,t:1527189023679};\\\", \\\"{x:1193,y:743,t:1527189023697};\\\", \\\"{x:1192,y:741,t:1527189023712};\\\", \\\"{x:1191,y:740,t:1527189023761};\\\", \\\"{x:1191,y:738,t:1527189023801};\\\", \\\"{x:1190,y:738,t:1527189023813};\\\", \\\"{x:1188,y:733,t:1527189023829};\\\", \\\"{x:1186,y:728,t:1527189023847};\\\", \\\"{x:1184,y:724,t:1527189023862};\\\", \\\"{x:1183,y:722,t:1527189023880};\\\", \\\"{x:1183,y:721,t:1527189023897};\\\", \\\"{x:1183,y:720,t:1527189023912};\\\", \\\"{x:1181,y:717,t:1527189023929};\\\", \\\"{x:1181,y:716,t:1527189023954};\\\", \\\"{x:1181,y:715,t:1527189023963};\\\", \\\"{x:1181,y:714,t:1527189023985};\\\", \\\"{x:1180,y:712,t:1527189024001};\\\", \\\"{x:1180,y:711,t:1527189024017};\\\", \\\"{x:1180,y:709,t:1527189024033};\\\", \\\"{x:1180,y:708,t:1527189024049};\\\", \\\"{x:1180,y:706,t:1527189024065};\\\", \\\"{x:1179,y:705,t:1527189024080};\\\", \\\"{x:1179,y:704,t:1527189024097};\\\", \\\"{x:1179,y:703,t:1527189024113};\\\", \\\"{x:1178,y:703,t:1527189027578};\\\", \\\"{x:1178,y:704,t:1527189027585};\\\", \\\"{x:1178,y:705,t:1527189027599};\\\", \\\"{x:1179,y:710,t:1527189027615};\\\", \\\"{x:1181,y:711,t:1527189027632};\\\", \\\"{x:1181,y:712,t:1527189027649};\\\", \\\"{x:1184,y:713,t:1527189027665};\\\", \\\"{x:1188,y:714,t:1527189027682};\\\", \\\"{x:1193,y:716,t:1527189027699};\\\", \\\"{x:1197,y:716,t:1527189027715};\\\", \\\"{x:1200,y:716,t:1527189027732};\\\", \\\"{x:1203,y:716,t:1527189027749};\\\", \\\"{x:1205,y:716,t:1527189027766};\\\", \\\"{x:1206,y:716,t:1527189027782};\\\", \\\"{x:1208,y:716,t:1527189027800};\\\", \\\"{x:1211,y:716,t:1527189027815};\\\", \\\"{x:1212,y:716,t:1527189027832};\\\", \\\"{x:1218,y:713,t:1527189027849};\\\", \\\"{x:1220,y:712,t:1527189027866};\\\", \\\"{x:1223,y:711,t:1527189027882};\\\", \\\"{x:1225,y:709,t:1527189027899};\\\", \\\"{x:1226,y:709,t:1527189027916};\\\", \\\"{x:1228,y:708,t:1527189027933};\\\", \\\"{x:1229,y:707,t:1527189027949};\\\", \\\"{x:1232,y:706,t:1527189027967};\\\", \\\"{x:1236,y:705,t:1527189027982};\\\", \\\"{x:1239,y:703,t:1527189028000};\\\", \\\"{x:1241,y:702,t:1527189028017};\\\", \\\"{x:1243,y:702,t:1527189028545};\\\", \\\"{x:1247,y:704,t:1527189028553};\\\", \\\"{x:1250,y:708,t:1527189028566};\\\", \\\"{x:1255,y:713,t:1527189028583};\\\", \\\"{x:1260,y:719,t:1527189028600};\\\", \\\"{x:1268,y:725,t:1527189028617};\\\", \\\"{x:1273,y:728,t:1527189028633};\\\", \\\"{x:1278,y:730,t:1527189028650};\\\", \\\"{x:1287,y:732,t:1527189028667};\\\", \\\"{x:1298,y:733,t:1527189028684};\\\", \\\"{x:1311,y:733,t:1527189028700};\\\", \\\"{x:1321,y:733,t:1527189028717};\\\", \\\"{x:1328,y:730,t:1527189028734};\\\", \\\"{x:1331,y:728,t:1527189028750};\\\", \\\"{x:1332,y:728,t:1527189028767};\\\", \\\"{x:1332,y:726,t:1527189028858};\\\", \\\"{x:1332,y:725,t:1527189028866};\\\", \\\"{x:1329,y:721,t:1527189028883};\\\", \\\"{x:1323,y:717,t:1527189028901};\\\", \\\"{x:1320,y:716,t:1527189028917};\\\", \\\"{x:1319,y:715,t:1527189028934};\\\", \\\"{x:1317,y:713,t:1527189028953};\\\", \\\"{x:1317,y:711,t:1527189028969};\\\", \\\"{x:1317,y:710,t:1527189028984};\\\", \\\"{x:1316,y:709,t:1527189029001};\\\", \\\"{x:1315,y:707,t:1527189029017};\\\", \\\"{x:1315,y:706,t:1527189029057};\\\", \\\"{x:1316,y:706,t:1527189030737};\\\", \\\"{x:1317,y:706,t:1527189030752};\\\", \\\"{x:1318,y:706,t:1527189030768};\\\", \\\"{x:1319,y:706,t:1527189030785};\\\", \\\"{x:1320,y:706,t:1527189030833};\\\", \\\"{x:1321,y:706,t:1527189030841};\\\", \\\"{x:1322,y:706,t:1527189030851};\\\", \\\"{x:1323,y:706,t:1527189030868};\\\", \\\"{x:1324,y:706,t:1527189030885};\\\", \\\"{x:1325,y:706,t:1527189030961};\\\", \\\"{x:1326,y:706,t:1527189030969};\\\", \\\"{x:1327,y:706,t:1527189030985};\\\", \\\"{x:1328,y:706,t:1527189031002};\\\", \\\"{x:1330,y:706,t:1527189031019};\\\", \\\"{x:1332,y:708,t:1527189031036};\\\", \\\"{x:1334,y:709,t:1527189031052};\\\", \\\"{x:1338,y:710,t:1527189031069};\\\", \\\"{x:1343,y:712,t:1527189031085};\\\", \\\"{x:1346,y:714,t:1527189031101};\\\", \\\"{x:1347,y:714,t:1527189031119};\\\", \\\"{x:1349,y:714,t:1527189031136};\\\", \\\"{x:1351,y:714,t:1527189031151};\\\", \\\"{x:1356,y:714,t:1527189031170};\\\", \\\"{x:1359,y:714,t:1527189031185};\\\", \\\"{x:1361,y:714,t:1527189031202};\\\", \\\"{x:1363,y:714,t:1527189031219};\\\", \\\"{x:1365,y:714,t:1527189031235};\\\", \\\"{x:1368,y:714,t:1527189031251};\\\", \\\"{x:1374,y:715,t:1527189031268};\\\", \\\"{x:1380,y:715,t:1527189031285};\\\", \\\"{x:1384,y:715,t:1527189031302};\\\", \\\"{x:1387,y:715,t:1527189031318};\\\", \\\"{x:1388,y:715,t:1527189031337};\\\", \\\"{x:1389,y:715,t:1527189031377};\\\", \\\"{x:1391,y:715,t:1527189031385};\\\", \\\"{x:1392,y:714,t:1527189031402};\\\", \\\"{x:1392,y:713,t:1527189031553};\\\", \\\"{x:1391,y:712,t:1527189031568};\\\", \\\"{x:1390,y:712,t:1527189031586};\\\", \\\"{x:1389,y:711,t:1527189031603};\\\", \\\"{x:1388,y:710,t:1527189031624};\\\", \\\"{x:1385,y:710,t:1527189031649};\\\", \\\"{x:1382,y:710,t:1527189031665};\\\", \\\"{x:1380,y:709,t:1527189031673};\\\", \\\"{x:1377,y:707,t:1527189031686};\\\", \\\"{x:1372,y:705,t:1527189031702};\\\", \\\"{x:1371,y:705,t:1527189031718};\\\", \\\"{x:1370,y:705,t:1527189031810};\\\", \\\"{x:1372,y:705,t:1527189031945};\\\", \\\"{x:1373,y:705,t:1527189031953};\\\", \\\"{x:1374,y:705,t:1527189031977};\\\", \\\"{x:1373,y:707,t:1527189035658};\\\", \\\"{x:1367,y:709,t:1527189035672};\\\", \\\"{x:1353,y:716,t:1527189035689};\\\", \\\"{x:1337,y:723,t:1527189035705};\\\", \\\"{x:1322,y:732,t:1527189035722};\\\", \\\"{x:1310,y:737,t:1527189035739};\\\", \\\"{x:1298,y:742,t:1527189035756};\\\", \\\"{x:1288,y:747,t:1527189035773};\\\", \\\"{x:1277,y:748,t:1527189035789};\\\", \\\"{x:1263,y:751,t:1527189035806};\\\", \\\"{x:1240,y:754,t:1527189035822};\\\", \\\"{x:1214,y:754,t:1527189035839};\\\", \\\"{x:1193,y:757,t:1527189035856};\\\", \\\"{x:1183,y:758,t:1527189035873};\\\", \\\"{x:1182,y:758,t:1527189035969};\\\", \\\"{x:1181,y:757,t:1527189035977};\\\", \\\"{x:1181,y:756,t:1527189035988};\\\", \\\"{x:1179,y:753,t:1527189036006};\\\", \\\"{x:1179,y:749,t:1527189036027};\\\", \\\"{x:1178,y:743,t:1527189036043};\\\", \\\"{x:1177,y:738,t:1527189036061};\\\", \\\"{x:1177,y:732,t:1527189036077};\\\", \\\"{x:1177,y:729,t:1527189036093};\\\", \\\"{x:1179,y:724,t:1527189036110};\\\", \\\"{x:1180,y:722,t:1527189036127};\\\", \\\"{x:1182,y:720,t:1527189036143};\\\", \\\"{x:1183,y:718,t:1527189036160};\\\", \\\"{x:1184,y:717,t:1527189036178};\\\", \\\"{x:1185,y:715,t:1527189036194};\\\", \\\"{x:1186,y:714,t:1527189036213};\\\", \\\"{x:1186,y:713,t:1527189036253};\\\", \\\"{x:1188,y:711,t:1527189036278};\\\", \\\"{x:1188,y:712,t:1527189036742};\\\", \\\"{x:1187,y:715,t:1527189036749};\\\", \\\"{x:1184,y:720,t:1527189036761};\\\", \\\"{x:1183,y:726,t:1527189036777};\\\", \\\"{x:1182,y:729,t:1527189036795};\\\", \\\"{x:1181,y:732,t:1527189036810};\\\", \\\"{x:1180,y:735,t:1527189036826};\\\", \\\"{x:1179,y:738,t:1527189036843};\\\", \\\"{x:1179,y:744,t:1527189036860};\\\", \\\"{x:1177,y:746,t:1527189036877};\\\", \\\"{x:1177,y:747,t:1527189036893};\\\", \\\"{x:1177,y:748,t:1527189036910};\\\", \\\"{x:1177,y:747,t:1527189037093};\\\", \\\"{x:1179,y:741,t:1527189037111};\\\", \\\"{x:1180,y:737,t:1527189037127};\\\", \\\"{x:1180,y:733,t:1527189037144};\\\", \\\"{x:1180,y:731,t:1527189037162};\\\", \\\"{x:1180,y:730,t:1527189037178};\\\", \\\"{x:1180,y:729,t:1527189037253};\\\", \\\"{x:1180,y:727,t:1527189037260};\\\", \\\"{x:1180,y:725,t:1527189037277};\\\", \\\"{x:1180,y:723,t:1527189037293};\\\", \\\"{x:1180,y:721,t:1527189037310};\\\", \\\"{x:1180,y:720,t:1527189037328};\\\", \\\"{x:1179,y:718,t:1527189037343};\\\", \\\"{x:1178,y:717,t:1527189037361};\\\", \\\"{x:1180,y:716,t:1527189039038};\\\", \\\"{x:1181,y:716,t:1527189039046};\\\", \\\"{x:1184,y:716,t:1527189039062};\\\", \\\"{x:1186,y:714,t:1527189039078};\\\", \\\"{x:1187,y:714,t:1527189039096};\\\", \\\"{x:1188,y:714,t:1527189039141};\\\", \\\"{x:1189,y:714,t:1527189039157};\\\", \\\"{x:1190,y:714,t:1527189039173};\\\", \\\"{x:1191,y:714,t:1527189039189};\\\", \\\"{x:1193,y:713,t:1527189039197};\\\", \\\"{x:1194,y:713,t:1527189039211};\\\", \\\"{x:1198,y:713,t:1527189039228};\\\", \\\"{x:1204,y:713,t:1527189039246};\\\", \\\"{x:1208,y:713,t:1527189039261};\\\", \\\"{x:1211,y:713,t:1527189039278};\\\", \\\"{x:1219,y:713,t:1527189039295};\\\", \\\"{x:1223,y:713,t:1527189039312};\\\", \\\"{x:1226,y:713,t:1527189039328};\\\", \\\"{x:1227,y:713,t:1527189039345};\\\", \\\"{x:1229,y:713,t:1527189039365};\\\", \\\"{x:1230,y:713,t:1527189039381};\\\", \\\"{x:1232,y:713,t:1527189039396};\\\", \\\"{x:1233,y:713,t:1527189039413};\\\", \\\"{x:1234,y:713,t:1527189039510};\\\", \\\"{x:1236,y:713,t:1527189039566};\\\", \\\"{x:1237,y:713,t:1527189039579};\\\", \\\"{x:1239,y:713,t:1527189039595};\\\", \\\"{x:1242,y:713,t:1527189039613};\\\", \\\"{x:1243,y:714,t:1527189040022};\\\", \\\"{x:1246,y:716,t:1527189040029};\\\", \\\"{x:1249,y:717,t:1527189040046};\\\", \\\"{x:1250,y:718,t:1527189040063};\\\", \\\"{x:1251,y:719,t:1527189040079};\\\", \\\"{x:1252,y:719,t:1527189040095};\\\", \\\"{x:1254,y:720,t:1527189040112};\\\", \\\"{x:1260,y:723,t:1527189040129};\\\", \\\"{x:1277,y:728,t:1527189040145};\\\", \\\"{x:1292,y:731,t:1527189040163};\\\", \\\"{x:1303,y:733,t:1527189040180};\\\", \\\"{x:1310,y:733,t:1527189040196};\\\", \\\"{x:1314,y:733,t:1527189040212};\\\", \\\"{x:1315,y:733,t:1527189040260};\\\", \\\"{x:1316,y:733,t:1527189040324};\\\", \\\"{x:1316,y:732,t:1527189040381};\\\", \\\"{x:1316,y:731,t:1527189040413};\\\", \\\"{x:1316,y:729,t:1527189040430};\\\", \\\"{x:1314,y:726,t:1527189040446};\\\", \\\"{x:1312,y:723,t:1527189040463};\\\", \\\"{x:1312,y:721,t:1527189040480};\\\", \\\"{x:1312,y:720,t:1527189040497};\\\", \\\"{x:1312,y:718,t:1527189040513};\\\", \\\"{x:1312,y:716,t:1527189040530};\\\", \\\"{x:1312,y:713,t:1527189040547};\\\", \\\"{x:1310,y:712,t:1527189040563};\\\", \\\"{x:1310,y:711,t:1527189040580};\\\", \\\"{x:1310,y:709,t:1527189040605};\\\", \\\"{x:1310,y:708,t:1527189040638};\\\", \\\"{x:1310,y:707,t:1527189040653};\\\", \\\"{x:1311,y:706,t:1527189040664};\\\", \\\"{x:1312,y:706,t:1527189042789};\\\", \\\"{x:1313,y:706,t:1527189042805};\\\", \\\"{x:1314,y:706,t:1527189042816};\\\", \\\"{x:1315,y:706,t:1527189042832};\\\", \\\"{x:1317,y:706,t:1527189042853};\\\", \\\"{x:1319,y:707,t:1527189042869};\\\", \\\"{x:1320,y:707,t:1527189042882};\\\", \\\"{x:1326,y:710,t:1527189042899};\\\", \\\"{x:1330,y:710,t:1527189042915};\\\", \\\"{x:1335,y:710,t:1527189042932};\\\", \\\"{x:1338,y:711,t:1527189042949};\\\", \\\"{x:1341,y:711,t:1527189042966};\\\", \\\"{x:1344,y:711,t:1527189042983};\\\", \\\"{x:1347,y:711,t:1527189042999};\\\", \\\"{x:1351,y:711,t:1527189043015};\\\", \\\"{x:1356,y:711,t:1527189043033};\\\", \\\"{x:1361,y:711,t:1527189043049};\\\", \\\"{x:1370,y:711,t:1527189043065};\\\", \\\"{x:1375,y:711,t:1527189043083};\\\", \\\"{x:1379,y:711,t:1527189043100};\\\", \\\"{x:1381,y:711,t:1527189043116};\\\", \\\"{x:1382,y:711,t:1527189043132};\\\", \\\"{x:1384,y:711,t:1527189043182};\\\", \\\"{x:1385,y:711,t:1527189043253};\\\", \\\"{x:1382,y:711,t:1527189044150};\\\", \\\"{x:1378,y:711,t:1527189044167};\\\", \\\"{x:1377,y:711,t:1527189044293};\\\", \\\"{x:1375,y:711,t:1527189045678};\\\", \\\"{x:1373,y:712,t:1527189045693};\\\", \\\"{x:1371,y:713,t:1527189045701};\\\", \\\"{x:1367,y:718,t:1527189045717};\\\", \\\"{x:1360,y:722,t:1527189045735};\\\", \\\"{x:1349,y:732,t:1527189045752};\\\", \\\"{x:1331,y:743,t:1527189045767};\\\", \\\"{x:1315,y:756,t:1527189045784};\\\", \\\"{x:1297,y:769,t:1527189045801};\\\", \\\"{x:1281,y:777,t:1527189045817};\\\", \\\"{x:1262,y:786,t:1527189045834};\\\", \\\"{x:1246,y:793,t:1527189045852};\\\", \\\"{x:1230,y:799,t:1527189045867};\\\", \\\"{x:1217,y:806,t:1527189045884};\\\", \\\"{x:1197,y:814,t:1527189045901};\\\", \\\"{x:1187,y:817,t:1527189045918};\\\", \\\"{x:1177,y:818,t:1527189045934};\\\", \\\"{x:1170,y:819,t:1527189045952};\\\", \\\"{x:1167,y:819,t:1527189045968};\\\", \\\"{x:1166,y:817,t:1527189046038};\\\", \\\"{x:1166,y:816,t:1527189046053};\\\", \\\"{x:1167,y:813,t:1527189046068};\\\", \\\"{x:1174,y:806,t:1527189046085};\\\", \\\"{x:1184,y:801,t:1527189046102};\\\", \\\"{x:1190,y:796,t:1527189046118};\\\", \\\"{x:1195,y:792,t:1527189046135};\\\", \\\"{x:1197,y:790,t:1527189046151};\\\", \\\"{x:1198,y:789,t:1527189046173};\\\", \\\"{x:1198,y:788,t:1527189046213};\\\", \\\"{x:1199,y:788,t:1527189046245};\\\", \\\"{x:1201,y:788,t:1527189055878};\\\", \\\"{x:1205,y:786,t:1527189055893};\\\", \\\"{x:1210,y:782,t:1527189055908};\\\", \\\"{x:1211,y:781,t:1527189055926};\\\", \\\"{x:1212,y:780,t:1527189055943};\\\", \\\"{x:1213,y:779,t:1527189055980};\\\", \\\"{x:1214,y:779,t:1527189056020};\\\", \\\"{x:1212,y:778,t:1527189057085};\\\", \\\"{x:1210,y:777,t:1527189057093};\\\", \\\"{x:1207,y:776,t:1527189057118};\\\", \\\"{x:1206,y:775,t:1527189057141};\\\", \\\"{x:1205,y:775,t:1527189057198};\\\", \\\"{x:1204,y:775,t:1527189057414};\\\", \\\"{x:1205,y:775,t:1527189057436};\\\", \\\"{x:1206,y:776,t:1527189057445};\\\", \\\"{x:1207,y:776,t:1527189057492};\\\", \\\"{x:1208,y:777,t:1527189057511};\\\", \\\"{x:1210,y:777,t:1527189057533};\\\", \\\"{x:1210,y:778,t:1527189057544};\\\", \\\"{x:1211,y:778,t:1527189057613};\\\", \\\"{x:1212,y:778,t:1527189057628};\\\", \\\"{x:1213,y:778,t:1527189057677};\\\", \\\"{x:1214,y:778,t:1527189057693};\\\", \\\"{x:1215,y:778,t:1527189057716};\\\", \\\"{x:1216,y:778,t:1527189057829};\\\", \\\"{x:1216,y:776,t:1527189057844};\\\", \\\"{x:1210,y:773,t:1527189057860};\\\", \\\"{x:1208,y:772,t:1527189057902};\\\", \\\"{x:1206,y:772,t:1527189057917};\\\", \\\"{x:1205,y:772,t:1527189057941};\\\", \\\"{x:1203,y:772,t:1527189057949};\\\", \\\"{x:1201,y:772,t:1527189057965};\\\", \\\"{x:1199,y:774,t:1527189057978};\\\", \\\"{x:1197,y:779,t:1527189057993};\\\", \\\"{x:1194,y:786,t:1527189058011};\\\", \\\"{x:1193,y:790,t:1527189058028};\\\", \\\"{x:1193,y:794,t:1527189058044};\\\", \\\"{x:1193,y:797,t:1527189058060};\\\", \\\"{x:1193,y:798,t:1527189058093};\\\", \\\"{x:1193,y:799,t:1527189058110};\\\", \\\"{x:1195,y:800,t:1527189058128};\\\", \\\"{x:1196,y:800,t:1527189058144};\\\", \\\"{x:1198,y:800,t:1527189058161};\\\", \\\"{x:1201,y:800,t:1527189058178};\\\", \\\"{x:1208,y:800,t:1527189058194};\\\", \\\"{x:1215,y:799,t:1527189058211};\\\", \\\"{x:1221,y:796,t:1527189058228};\\\", \\\"{x:1227,y:792,t:1527189058245};\\\", \\\"{x:1229,y:791,t:1527189058261};\\\", \\\"{x:1230,y:791,t:1527189058278};\\\", \\\"{x:1230,y:790,t:1527189058301};\\\", \\\"{x:1230,y:787,t:1527189058311};\\\", \\\"{x:1230,y:785,t:1527189058328};\\\", \\\"{x:1230,y:784,t:1527189058345};\\\", \\\"{x:1230,y:783,t:1527189058372};\\\", \\\"{x:1230,y:782,t:1527189058381};\\\", \\\"{x:1228,y:781,t:1527189058395};\\\", \\\"{x:1228,y:780,t:1527189058411};\\\", \\\"{x:1227,y:779,t:1527189058428};\\\", \\\"{x:1224,y:777,t:1527189058445};\\\", \\\"{x:1221,y:777,t:1527189058461};\\\", \\\"{x:1220,y:776,t:1527189058478};\\\", \\\"{x:1218,y:776,t:1527189058495};\\\", \\\"{x:1217,y:775,t:1527189058510};\\\", \\\"{x:1215,y:775,t:1527189058528};\\\", \\\"{x:1212,y:775,t:1527189058545};\\\", \\\"{x:1209,y:777,t:1527189058561};\\\", \\\"{x:1208,y:779,t:1527189058579};\\\", \\\"{x:1207,y:781,t:1527189058595};\\\", \\\"{x:1207,y:784,t:1527189058611};\\\", \\\"{x:1207,y:785,t:1527189058628};\\\", \\\"{x:1207,y:787,t:1527189058645};\\\", \\\"{x:1207,y:788,t:1527189058669};\\\", \\\"{x:1207,y:789,t:1527189058693};\\\", \\\"{x:1208,y:790,t:1527189058709};\\\", \\\"{x:1210,y:790,t:1527189058774};\\\", \\\"{x:1212,y:790,t:1527189058781};\\\", \\\"{x:1214,y:790,t:1527189058794};\\\", \\\"{x:1218,y:790,t:1527189058812};\\\", \\\"{x:1222,y:789,t:1527189058829};\\\", \\\"{x:1224,y:788,t:1527189058845};\\\", \\\"{x:1226,y:787,t:1527189058862};\\\", \\\"{x:1227,y:786,t:1527189058878};\\\", \\\"{x:1228,y:784,t:1527189058895};\\\", \\\"{x:1229,y:783,t:1527189058912};\\\", \\\"{x:1230,y:782,t:1527189058928};\\\", \\\"{x:1230,y:779,t:1527189058945};\\\", \\\"{x:1230,y:776,t:1527189058962};\\\", \\\"{x:1230,y:774,t:1527189058978};\\\", \\\"{x:1230,y:773,t:1527189058995};\\\", \\\"{x:1230,y:771,t:1527189059029};\\\", \\\"{x:1229,y:770,t:1527189059053};\\\", \\\"{x:1228,y:770,t:1527189059085};\\\", \\\"{x:1227,y:770,t:1527189059109};\\\", \\\"{x:1226,y:769,t:1527189059116};\\\", \\\"{x:1224,y:769,t:1527189059149};\\\", \\\"{x:1223,y:768,t:1527189059162};\\\", \\\"{x:1222,y:768,t:1527189059180};\\\", \\\"{x:1221,y:768,t:1527189059195};\\\", \\\"{x:1220,y:768,t:1527189059212};\\\", \\\"{x:1216,y:768,t:1527189059229};\\\", \\\"{x:1215,y:768,t:1527189059245};\\\", \\\"{x:1212,y:770,t:1527189059262};\\\", \\\"{x:1211,y:771,t:1527189059279};\\\", \\\"{x:1210,y:773,t:1527189059295};\\\", \\\"{x:1209,y:774,t:1527189059329};\\\", \\\"{x:1209,y:775,t:1527189059348};\\\", \\\"{x:1209,y:776,t:1527189059364};\\\", \\\"{x:1209,y:777,t:1527189059388};\\\", \\\"{x:1209,y:778,t:1527189059404};\\\", \\\"{x:1209,y:779,t:1527189059477};\\\", \\\"{x:1210,y:779,t:1527189059484};\\\", \\\"{x:1212,y:780,t:1527189059495};\\\", \\\"{x:1213,y:780,t:1527189059517};\\\", \\\"{x:1214,y:780,t:1527189059557};\\\", \\\"{x:1215,y:780,t:1527189059564};\\\", \\\"{x:1216,y:780,t:1527189059579};\\\", \\\"{x:1219,y:780,t:1527189059596};\\\", \\\"{x:1223,y:780,t:1527189059613};\\\", \\\"{x:1226,y:779,t:1527189059629};\\\", \\\"{x:1227,y:778,t:1527189059660};\\\", \\\"{x:1227,y:777,t:1527189059685};\\\", \\\"{x:1227,y:776,t:1527189059701};\\\", \\\"{x:1227,y:774,t:1527189059724};\\\", \\\"{x:1227,y:773,t:1527189059740};\\\", \\\"{x:1227,y:771,t:1527189059756};\\\", \\\"{x:1225,y:770,t:1527189059773};\\\", \\\"{x:1224,y:770,t:1527189059893};\\\", \\\"{x:1223,y:769,t:1527189059901};\\\", \\\"{x:1222,y:769,t:1527189059957};\\\", \\\"{x:1217,y:769,t:1527189078869};\\\", \\\"{x:1205,y:769,t:1527189078878};\\\", \\\"{x:1194,y:763,t:1527189078895};\\\", \\\"{x:1189,y:761,t:1527189078911};\\\", \\\"{x:1186,y:759,t:1527189078928};\\\", \\\"{x:1183,y:757,t:1527189083741};\\\", \\\"{x:1109,y:721,t:1527189083748};\\\", \\\"{x:924,y:635,t:1527189083765};\\\", \\\"{x:753,y:583,t:1527189083782};\\\", \\\"{x:609,y:540,t:1527189083799};\\\", \\\"{x:482,y:512,t:1527189083815};\\\", \\\"{x:379,y:506,t:1527189083832};\\\", \\\"{x:322,y:525,t:1527189083851};\\\", \\\"{x:298,y:544,t:1527189083867};\\\", \\\"{x:267,y:572,t:1527189083884};\\\", \\\"{x:247,y:583,t:1527189083901};\\\", \\\"{x:237,y:591,t:1527189083916};\\\", \\\"{x:233,y:602,t:1527189083933};\\\", \\\"{x:229,y:617,t:1527189083950};\\\", \\\"{x:227,y:629,t:1527189083966};\\\", \\\"{x:227,y:632,t:1527189083983};\\\", \\\"{x:226,y:632,t:1527189084035};\\\", \\\"{x:223,y:629,t:1527189084050};\\\", \\\"{x:208,y:611,t:1527189084066};\\\", \\\"{x:186,y:594,t:1527189084084};\\\", \\\"{x:171,y:582,t:1527189084101};\\\", \\\"{x:159,y:565,t:1527189084118};\\\", \\\"{x:144,y:544,t:1527189084134};\\\", \\\"{x:133,y:526,t:1527189084150};\\\", \\\"{x:126,y:516,t:1527189084167};\\\", \\\"{x:123,y:512,t:1527189084184};\\\", \\\"{x:123,y:510,t:1527189084200};\\\", \\\"{x:123,y:508,t:1527189084219};\\\", \\\"{x:124,y:507,t:1527189084233};\\\", \\\"{x:127,y:504,t:1527189084250};\\\", \\\"{x:130,y:500,t:1527189084267};\\\", \\\"{x:147,y:486,t:1527189084283};\\\", \\\"{x:159,y:480,t:1527189084301};\\\", \\\"{x:172,y:471,t:1527189084318};\\\", \\\"{x:180,y:466,t:1527189084333};\\\", \\\"{x:183,y:463,t:1527189084351};\\\", \\\"{x:184,y:462,t:1527189084395};\\\", \\\"{x:184,y:461,t:1527189084508};\\\", \\\"{x:183,y:460,t:1527189084524};\\\", \\\"{x:182,y:460,t:1527189084534};\\\", \\\"{x:179,y:459,t:1527189084550};\\\", \\\"{x:176,y:457,t:1527189084568};\\\", \\\"{x:173,y:455,t:1527189084584};\\\", \\\"{x:165,y:452,t:1527189084600};\\\", \\\"{x:157,y:447,t:1527189084617};\\\", \\\"{x:152,y:444,t:1527189084633};\\\", \\\"{x:151,y:443,t:1527189084684};\\\", \\\"{x:151,y:442,t:1527189084772};\\\", \\\"{x:151,y:441,t:1527189084783};\\\", \\\"{x:153,y:440,t:1527189084804};\\\", \\\"{x:157,y:440,t:1527189085180};\\\", \\\"{x:159,y:440,t:1527189085187};\\\", \\\"{x:164,y:444,t:1527189085201};\\\", \\\"{x:173,y:455,t:1527189085217};\\\", \\\"{x:184,y:473,t:1527189085236};\\\", \\\"{x:212,y:520,t:1527189085251};\\\", \\\"{x:238,y:562,t:1527189085267};\\\", \\\"{x:266,y:608,t:1527189085285};\\\", \\\"{x:294,y:646,t:1527189085301};\\\", \\\"{x:318,y:666,t:1527189085317};\\\", \\\"{x:341,y:676,t:1527189085334};\\\", \\\"{x:357,y:681,t:1527189085351};\\\", \\\"{x:366,y:682,t:1527189085367};\\\", \\\"{x:368,y:682,t:1527189085384};\\\", \\\"{x:370,y:682,t:1527189085453};\\\", \\\"{x:376,y:681,t:1527189085468};\\\", \\\"{x:390,y:673,t:1527189085485};\\\", \\\"{x:411,y:659,t:1527189085502};\\\", \\\"{x:444,y:643,t:1527189085518};\\\", \\\"{x:489,y:630,t:1527189085535};\\\", \\\"{x:529,y:623,t:1527189085552};\\\", \\\"{x:556,y:623,t:1527189085568};\\\", \\\"{x:574,y:623,t:1527189085584};\\\", \\\"{x:581,y:627,t:1527189085601};\\\", \\\"{x:585,y:632,t:1527189085617};\\\", \\\"{x:587,y:641,t:1527189085635};\\\", \\\"{x:588,y:648,t:1527189085651};\\\", \\\"{x:584,y:660,t:1527189085668};\\\", \\\"{x:578,y:669,t:1527189085685};\\\", \\\"{x:573,y:676,t:1527189085701};\\\", \\\"{x:567,y:682,t:1527189085718};\\\", \\\"{x:563,y:684,t:1527189085736};\\\", \\\"{x:558,y:685,t:1527189085750};\\\", \\\"{x:555,y:685,t:1527189085768};\\\", \\\"{x:550,y:685,t:1527189085785};\\\", \\\"{x:544,y:685,t:1527189085801};\\\", \\\"{x:542,y:685,t:1527189085818};\\\", \\\"{x:539,y:685,t:1527189085836};\\\" ] }, { \\\"rt\\\": 54567, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 526275, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-F -Z -X -X -X -Z -Z -Z -Z -Z -F -F -B -B -12 PM-Z -04 PM-X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:692,t:1527189089876};\\\", \\\"{x:542,y:703,t:1527189089886};\\\", \\\"{x:556,y:722,t:1527189089902};\\\", \\\"{x:584,y:749,t:1527189089922};\\\", \\\"{x:639,y:787,t:1527189089938};\\\", \\\"{x:706,y:830,t:1527189089954};\\\", \\\"{x:850,y:890,t:1527189089971};\\\", \\\"{x:943,y:925,t:1527189089988};\\\", \\\"{x:1018,y:946,t:1527189090004};\\\", \\\"{x:1074,y:955,t:1527189090021};\\\", \\\"{x:1108,y:959,t:1527189090039};\\\", \\\"{x:1132,y:959,t:1527189090055};\\\", \\\"{x:1149,y:955,t:1527189090071};\\\", \\\"{x:1158,y:950,t:1527189090089};\\\", \\\"{x:1165,y:945,t:1527189090105};\\\", \\\"{x:1173,y:941,t:1527189090122};\\\", \\\"{x:1185,y:937,t:1527189090139};\\\", \\\"{x:1201,y:936,t:1527189090154};\\\", \\\"{x:1249,y:936,t:1527189090171};\\\", \\\"{x:1305,y:936,t:1527189090189};\\\", \\\"{x:1380,y:936,t:1527189090205};\\\", \\\"{x:1464,y:936,t:1527189090222};\\\", \\\"{x:1525,y:936,t:1527189090239};\\\", \\\"{x:1566,y:934,t:1527189090255};\\\", \\\"{x:1594,y:934,t:1527189090272};\\\", \\\"{x:1608,y:934,t:1527189090289};\\\", \\\"{x:1612,y:932,t:1527189090305};\\\", \\\"{x:1613,y:931,t:1527189090322};\\\", \\\"{x:1614,y:929,t:1527189090339};\\\", \\\"{x:1607,y:923,t:1527189090355};\\\", \\\"{x:1596,y:918,t:1527189090372};\\\", \\\"{x:1580,y:912,t:1527189090390};\\\", \\\"{x:1560,y:903,t:1527189090406};\\\", \\\"{x:1541,y:895,t:1527189090422};\\\", \\\"{x:1526,y:889,t:1527189090439};\\\", \\\"{x:1509,y:881,t:1527189090456};\\\", \\\"{x:1496,y:873,t:1527189090472};\\\", \\\"{x:1487,y:866,t:1527189090489};\\\", \\\"{x:1478,y:856,t:1527189090506};\\\", \\\"{x:1466,y:838,t:1527189090522};\\\", \\\"{x:1450,y:816,t:1527189090540};\\\", \\\"{x:1410,y:766,t:1527189090556};\\\", \\\"{x:1381,y:732,t:1527189090572};\\\", \\\"{x:1351,y:695,t:1527189090589};\\\", \\\"{x:1332,y:669,t:1527189090606};\\\", \\\"{x:1322,y:652,t:1527189090622};\\\", \\\"{x:1320,y:645,t:1527189090639};\\\", \\\"{x:1319,y:643,t:1527189090657};\\\", \\\"{x:1318,y:643,t:1527189090700};\\\", \\\"{x:1314,y:645,t:1527189090716};\\\", \\\"{x:1314,y:646,t:1527189090724};\\\", \\\"{x:1314,y:648,t:1527189090740};\\\", \\\"{x:1310,y:662,t:1527189090756};\\\", \\\"{x:1309,y:667,t:1527189090772};\\\", \\\"{x:1309,y:672,t:1527189090789};\\\", \\\"{x:1310,y:671,t:1527189092332};\\\", \\\"{x:1321,y:666,t:1527189092340};\\\", \\\"{x:1353,y:655,t:1527189092358};\\\", \\\"{x:1379,y:642,t:1527189092375};\\\", \\\"{x:1397,y:635,t:1527189092391};\\\", \\\"{x:1409,y:632,t:1527189092407};\\\", \\\"{x:1415,y:631,t:1527189092425};\\\", \\\"{x:1416,y:631,t:1527189092441};\\\", \\\"{x:1416,y:632,t:1527189092484};\\\", \\\"{x:1413,y:633,t:1527189092492};\\\", \\\"{x:1409,y:635,t:1527189092507};\\\", \\\"{x:1389,y:638,t:1527189092524};\\\", \\\"{x:1376,y:642,t:1527189092541};\\\", \\\"{x:1369,y:645,t:1527189092558};\\\", \\\"{x:1364,y:647,t:1527189092574};\\\", \\\"{x:1362,y:648,t:1527189092590};\\\", \\\"{x:1361,y:648,t:1527189092692};\\\", \\\"{x:1359,y:648,t:1527189092749};\\\", \\\"{x:1358,y:648,t:1527189092757};\\\", \\\"{x:1356,y:648,t:1527189092774};\\\", \\\"{x:1354,y:648,t:1527189092791};\\\", \\\"{x:1353,y:648,t:1527189092807};\\\", \\\"{x:1351,y:648,t:1527189093271};\\\", \\\"{x:1350,y:648,t:1527189093290};\\\", \\\"{x:1348,y:646,t:1527189093772};\\\", \\\"{x:1348,y:645,t:1527189093780};\\\", \\\"{x:1348,y:644,t:1527189093803};\\\", \\\"{x:1347,y:642,t:1527189093819};\\\", \\\"{x:1346,y:642,t:1527189093852};\\\", \\\"{x:1345,y:642,t:1527189094252};\\\", \\\"{x:1344,y:642,t:1527189094692};\\\", \\\"{x:1344,y:643,t:1527189094715};\\\", \\\"{x:1344,y:644,t:1527189094725};\\\", \\\"{x:1344,y:645,t:1527189094748};\\\", \\\"{x:1344,y:646,t:1527189094788};\\\", \\\"{x:1346,y:648,t:1527189094804};\\\", \\\"{x:1350,y:649,t:1527189094821};\\\", \\\"{x:1352,y:649,t:1527189094828};\\\", \\\"{x:1354,y:649,t:1527189094842};\\\", \\\"{x:1360,y:650,t:1527189094859};\\\", \\\"{x:1365,y:652,t:1527189094875};\\\", \\\"{x:1369,y:653,t:1527189094892};\\\", \\\"{x:1373,y:654,t:1527189094909};\\\", \\\"{x:1375,y:655,t:1527189094926};\\\", \\\"{x:1379,y:656,t:1527189094942};\\\", \\\"{x:1386,y:656,t:1527189094960};\\\", \\\"{x:1396,y:656,t:1527189094975};\\\", \\\"{x:1404,y:656,t:1527189094993};\\\", \\\"{x:1411,y:655,t:1527189095010};\\\", \\\"{x:1415,y:652,t:1527189095025};\\\", \\\"{x:1417,y:651,t:1527189095043};\\\", \\\"{x:1417,y:650,t:1527189095059};\\\", \\\"{x:1418,y:650,t:1527189095101};\\\", \\\"{x:1419,y:650,t:1527189095110};\\\", \\\"{x:1420,y:648,t:1527189095126};\\\", \\\"{x:1422,y:648,t:1527189095142};\\\", \\\"{x:1423,y:647,t:1527189095236};\\\", \\\"{x:1421,y:645,t:1527189095244};\\\", \\\"{x:1417,y:644,t:1527189095259};\\\", \\\"{x:1414,y:642,t:1527189095276};\\\", \\\"{x:1416,y:643,t:1527189096472};\\\", \\\"{x:1417,y:643,t:1527189096480};\\\", \\\"{x:1419,y:648,t:1527189096497};\\\", \\\"{x:1422,y:653,t:1527189096514};\\\", \\\"{x:1428,y:659,t:1527189096530};\\\", \\\"{x:1431,y:662,t:1527189096546};\\\", \\\"{x:1434,y:665,t:1527189096563};\\\", \\\"{x:1436,y:665,t:1527189096580};\\\", \\\"{x:1437,y:665,t:1527189096599};\\\", \\\"{x:1439,y:665,t:1527189096623};\\\", \\\"{x:1440,y:665,t:1527189096631};\\\", \\\"{x:1446,y:664,t:1527189096647};\\\", \\\"{x:1452,y:661,t:1527189096664};\\\", \\\"{x:1457,y:659,t:1527189096681};\\\", \\\"{x:1463,y:657,t:1527189096697};\\\", \\\"{x:1467,y:655,t:1527189096714};\\\", \\\"{x:1470,y:654,t:1527189096730};\\\", \\\"{x:1474,y:653,t:1527189096747};\\\", \\\"{x:1479,y:653,t:1527189096763};\\\", \\\"{x:1486,y:650,t:1527189096780};\\\", \\\"{x:1490,y:648,t:1527189096797};\\\", \\\"{x:1493,y:648,t:1527189096814};\\\", \\\"{x:1494,y:647,t:1527189096830};\\\", \\\"{x:1493,y:645,t:1527189096856};\\\", \\\"{x:1489,y:643,t:1527189096863};\\\", \\\"{x:1487,y:642,t:1527189096881};\\\", \\\"{x:1482,y:641,t:1527189096897};\\\", \\\"{x:1481,y:639,t:1527189096914};\\\", \\\"{x:1480,y:639,t:1527189097447};\\\", \\\"{x:1478,y:641,t:1527189097463};\\\", \\\"{x:1478,y:645,t:1527189097480};\\\", \\\"{x:1478,y:652,t:1527189097498};\\\", \\\"{x:1479,y:659,t:1527189097515};\\\", \\\"{x:1482,y:664,t:1527189097531};\\\", \\\"{x:1484,y:668,t:1527189097548};\\\", \\\"{x:1487,y:670,t:1527189097564};\\\", \\\"{x:1487,y:671,t:1527189097580};\\\", \\\"{x:1488,y:671,t:1527189097597};\\\", \\\"{x:1489,y:671,t:1527189097630};\\\", \\\"{x:1493,y:671,t:1527189097647};\\\", \\\"{x:1504,y:671,t:1527189097664};\\\", \\\"{x:1517,y:671,t:1527189097680};\\\", \\\"{x:1527,y:669,t:1527189097697};\\\", \\\"{x:1541,y:667,t:1527189097714};\\\", \\\"{x:1546,y:666,t:1527189097730};\\\", \\\"{x:1554,y:665,t:1527189097746};\\\", \\\"{x:1558,y:664,t:1527189097764};\\\", \\\"{x:1563,y:663,t:1527189097780};\\\", \\\"{x:1569,y:661,t:1527189097797};\\\", \\\"{x:1573,y:659,t:1527189097814};\\\", \\\"{x:1577,y:657,t:1527189097830};\\\", \\\"{x:1579,y:655,t:1527189097847};\\\", \\\"{x:1579,y:654,t:1527189097864};\\\", \\\"{x:1579,y:650,t:1527189097880};\\\", \\\"{x:1576,y:648,t:1527189097897};\\\", \\\"{x:1570,y:645,t:1527189097915};\\\", \\\"{x:1562,y:642,t:1527189097931};\\\", \\\"{x:1556,y:640,t:1527189097948};\\\", \\\"{x:1555,y:639,t:1527189097964};\\\", \\\"{x:1553,y:639,t:1527189098191};\\\", \\\"{x:1550,y:639,t:1527189098199};\\\", \\\"{x:1548,y:640,t:1527189098215};\\\", \\\"{x:1546,y:642,t:1527189098231};\\\", \\\"{x:1545,y:643,t:1527189098247};\\\", \\\"{x:1543,y:645,t:1527189098265};\\\", \\\"{x:1542,y:647,t:1527189098281};\\\", \\\"{x:1542,y:648,t:1527189098520};\\\", \\\"{x:1542,y:649,t:1527189098543};\\\", \\\"{x:1543,y:649,t:1527189098816};\\\", \\\"{x:1545,y:649,t:1527189098831};\\\", \\\"{x:1547,y:649,t:1527189098863};\\\", \\\"{x:1548,y:649,t:1527189098967};\\\", \\\"{x:1551,y:649,t:1527189098982};\\\", \\\"{x:1559,y:651,t:1527189098999};\\\", \\\"{x:1580,y:657,t:1527189099015};\\\", \\\"{x:1590,y:662,t:1527189099032};\\\", \\\"{x:1596,y:663,t:1527189099049};\\\", \\\"{x:1597,y:664,t:1527189099065};\\\", \\\"{x:1598,y:663,t:1527189099128};\\\", \\\"{x:1599,y:663,t:1527189099135};\\\", \\\"{x:1600,y:661,t:1527189099148};\\\", \\\"{x:1602,y:659,t:1527189099165};\\\", \\\"{x:1604,y:655,t:1527189099181};\\\", \\\"{x:1606,y:651,t:1527189099198};\\\", \\\"{x:1608,y:648,t:1527189099214};\\\", \\\"{x:1608,y:646,t:1527189099230};\\\", \\\"{x:1610,y:644,t:1527189099248};\\\", \\\"{x:1612,y:642,t:1527189099265};\\\", \\\"{x:1615,y:640,t:1527189099281};\\\", \\\"{x:1615,y:639,t:1527189099319};\\\", \\\"{x:1614,y:639,t:1527189099331};\\\", \\\"{x:1611,y:642,t:1527189103104};\\\", \\\"{x:1606,y:652,t:1527189103119};\\\", \\\"{x:1586,y:689,t:1527189103135};\\\", \\\"{x:1575,y:710,t:1527189103152};\\\", \\\"{x:1569,y:720,t:1527189103168};\\\", \\\"{x:1566,y:725,t:1527189103185};\\\", \\\"{x:1562,y:728,t:1527189103202};\\\", \\\"{x:1559,y:729,t:1527189103219};\\\", \\\"{x:1555,y:729,t:1527189103234};\\\", \\\"{x:1549,y:729,t:1527189103252};\\\", \\\"{x:1542,y:729,t:1527189103268};\\\", \\\"{x:1531,y:731,t:1527189103285};\\\", \\\"{x:1518,y:735,t:1527189103302};\\\", \\\"{x:1501,y:744,t:1527189103319};\\\", \\\"{x:1496,y:749,t:1527189103335};\\\", \\\"{x:1493,y:752,t:1527189103352};\\\", \\\"{x:1493,y:753,t:1527189103439};\\\", \\\"{x:1492,y:755,t:1527189103451};\\\", \\\"{x:1489,y:758,t:1527189103469};\\\", \\\"{x:1486,y:763,t:1527189103485};\\\", \\\"{x:1484,y:766,t:1527189103502};\\\", \\\"{x:1480,y:771,t:1527189103519};\\\", \\\"{x:1478,y:773,t:1527189103535};\\\", \\\"{x:1477,y:773,t:1527189103552};\\\", \\\"{x:1477,y:774,t:1527189103569};\\\", \\\"{x:1476,y:775,t:1527189103585};\\\", \\\"{x:1475,y:779,t:1527189103603};\\\", \\\"{x:1473,y:783,t:1527189103619};\\\", \\\"{x:1472,y:785,t:1527189103635};\\\", \\\"{x:1473,y:785,t:1527189103888};\\\", \\\"{x:1473,y:784,t:1527189103903};\\\", \\\"{x:1474,y:784,t:1527189103927};\\\", \\\"{x:1475,y:783,t:1527189103943};\\\", \\\"{x:1475,y:781,t:1527189103975};\\\", \\\"{x:1476,y:781,t:1527189104088};\\\", \\\"{x:1476,y:780,t:1527189104103};\\\", \\\"{x:1477,y:780,t:1527189104135};\\\", \\\"{x:1478,y:779,t:1527189104169};\\\", \\\"{x:1480,y:778,t:1527189104271};\\\", \\\"{x:1483,y:775,t:1527189109063};\\\", \\\"{x:1492,y:773,t:1527189109074};\\\", \\\"{x:1501,y:772,t:1527189109089};\\\", \\\"{x:1505,y:769,t:1527189109106};\\\", \\\"{x:1507,y:769,t:1527189109123};\\\", \\\"{x:1508,y:767,t:1527189109247};\\\", \\\"{x:1508,y:764,t:1527189109256};\\\", \\\"{x:1512,y:755,t:1527189109273};\\\", \\\"{x:1524,y:739,t:1527189109289};\\\", \\\"{x:1541,y:717,t:1527189109306};\\\", \\\"{x:1560,y:694,t:1527189109322};\\\", \\\"{x:1581,y:672,t:1527189109339};\\\", \\\"{x:1598,y:655,t:1527189109355};\\\", \\\"{x:1608,y:640,t:1527189109373};\\\", \\\"{x:1610,y:628,t:1527189109389};\\\", \\\"{x:1610,y:616,t:1527189109406};\\\", \\\"{x:1604,y:602,t:1527189109422};\\\", \\\"{x:1603,y:598,t:1527189109440};\\\", \\\"{x:1602,y:597,t:1527189109510};\\\", \\\"{x:1601,y:597,t:1527189109522};\\\", \\\"{x:1598,y:597,t:1527189109540};\\\", \\\"{x:1597,y:597,t:1527189109555};\\\", \\\"{x:1597,y:608,t:1527189109573};\\\", \\\"{x:1606,y:620,t:1527189109590};\\\", \\\"{x:1615,y:632,t:1527189109606};\\\", \\\"{x:1622,y:639,t:1527189109623};\\\", \\\"{x:1628,y:642,t:1527189109640};\\\", \\\"{x:1630,y:643,t:1527189109656};\\\", \\\"{x:1631,y:644,t:1527189109673};\\\", \\\"{x:1631,y:645,t:1527189109690};\\\", \\\"{x:1631,y:646,t:1527189109706};\\\", \\\"{x:1634,y:650,t:1527189109723};\\\", \\\"{x:1634,y:653,t:1527189109739};\\\", \\\"{x:1635,y:657,t:1527189109756};\\\", \\\"{x:1637,y:661,t:1527189109773};\\\", \\\"{x:1637,y:662,t:1527189109790};\\\", \\\"{x:1637,y:663,t:1527189109807};\\\", \\\"{x:1630,y:663,t:1527189109823};\\\", \\\"{x:1626,y:662,t:1527189109840};\\\", \\\"{x:1624,y:661,t:1527189109856};\\\", \\\"{x:1623,y:661,t:1527189109935};\\\", \\\"{x:1623,y:660,t:1527189109943};\\\", \\\"{x:1622,y:659,t:1527189110023};\\\", \\\"{x:1618,y:656,t:1527189110041};\\\", \\\"{x:1617,y:655,t:1527189110057};\\\", \\\"{x:1615,y:653,t:1527189110073};\\\", \\\"{x:1615,y:652,t:1527189110102};\\\", \\\"{x:1615,y:651,t:1527189110119};\\\", \\\"{x:1615,y:650,t:1527189110127};\\\", \\\"{x:1615,y:649,t:1527189110160};\\\", \\\"{x:1615,y:646,t:1527189110190};\\\", \\\"{x:1615,y:642,t:1527189110207};\\\", \\\"{x:1614,y:639,t:1527189110223};\\\", \\\"{x:1612,y:635,t:1527189110241};\\\", \\\"{x:1612,y:634,t:1527189110311};\\\", \\\"{x:1612,y:633,t:1527189110326};\\\", \\\"{x:1612,y:632,t:1527189110350};\\\", \\\"{x:1612,y:631,t:1527189110391};\\\", \\\"{x:1611,y:633,t:1527189111047};\\\", \\\"{x:1611,y:637,t:1527189111057};\\\", \\\"{x:1607,y:648,t:1527189111075};\\\", \\\"{x:1606,y:658,t:1527189111091};\\\", \\\"{x:1603,y:669,t:1527189111107};\\\", \\\"{x:1603,y:676,t:1527189111124};\\\", \\\"{x:1602,y:682,t:1527189111140};\\\", \\\"{x:1602,y:686,t:1527189111156};\\\", \\\"{x:1601,y:686,t:1527189111174};\\\", \\\"{x:1601,y:687,t:1527189111262};\\\", \\\"{x:1601,y:688,t:1527189111274};\\\", \\\"{x:1601,y:692,t:1527189111290};\\\", \\\"{x:1601,y:696,t:1527189111308};\\\", \\\"{x:1601,y:700,t:1527189111323};\\\", \\\"{x:1601,y:706,t:1527189111340};\\\", \\\"{x:1601,y:708,t:1527189111358};\\\", \\\"{x:1601,y:710,t:1527189111373};\\\", \\\"{x:1601,y:711,t:1527189111431};\\\", \\\"{x:1601,y:713,t:1527189111441};\\\", \\\"{x:1601,y:719,t:1527189111458};\\\", \\\"{x:1601,y:727,t:1527189111474};\\\", \\\"{x:1601,y:734,t:1527189111490};\\\", \\\"{x:1601,y:739,t:1527189111507};\\\", \\\"{x:1601,y:745,t:1527189111523};\\\", \\\"{x:1601,y:750,t:1527189111540};\\\", \\\"{x:1601,y:754,t:1527189111558};\\\", \\\"{x:1601,y:756,t:1527189111573};\\\", \\\"{x:1601,y:757,t:1527189111591};\\\", \\\"{x:1601,y:758,t:1527189111646};\\\", \\\"{x:1601,y:759,t:1527189111657};\\\", \\\"{x:1602,y:761,t:1527189111674};\\\", \\\"{x:1603,y:766,t:1527189111691};\\\", \\\"{x:1604,y:768,t:1527189111707};\\\", \\\"{x:1604,y:772,t:1527189111723};\\\", \\\"{x:1606,y:774,t:1527189111741};\\\", \\\"{x:1608,y:777,t:1527189111757};\\\", \\\"{x:1609,y:782,t:1527189111774};\\\", \\\"{x:1611,y:785,t:1527189111791};\\\", \\\"{x:1611,y:787,t:1527189111807};\\\", \\\"{x:1612,y:787,t:1527189111825};\\\", \\\"{x:1612,y:788,t:1527189111895};\\\", \\\"{x:1612,y:791,t:1527189111908};\\\", \\\"{x:1612,y:795,t:1527189111925};\\\", \\\"{x:1613,y:804,t:1527189111940};\\\", \\\"{x:1614,y:817,t:1527189111958};\\\", \\\"{x:1615,y:825,t:1527189111974};\\\", \\\"{x:1615,y:834,t:1527189111991};\\\", \\\"{x:1615,y:839,t:1527189112008};\\\", \\\"{x:1615,y:842,t:1527189112024};\\\", \\\"{x:1615,y:843,t:1527189112041};\\\", \\\"{x:1615,y:844,t:1527189112058};\\\", \\\"{x:1616,y:846,t:1527189112143};\\\", \\\"{x:1616,y:851,t:1527189112160};\\\", \\\"{x:1616,y:857,t:1527189112175};\\\", \\\"{x:1616,y:863,t:1527189112192};\\\", \\\"{x:1616,y:869,t:1527189112208};\\\", \\\"{x:1616,y:873,t:1527189112225};\\\", \\\"{x:1616,y:876,t:1527189112241};\\\", \\\"{x:1616,y:871,t:1527189112512};\\\", \\\"{x:1616,y:864,t:1527189112525};\\\", \\\"{x:1614,y:846,t:1527189112542};\\\", \\\"{x:1610,y:823,t:1527189112558};\\\", \\\"{x:1608,y:792,t:1527189112574};\\\", \\\"{x:1608,y:776,t:1527189112592};\\\", \\\"{x:1608,y:765,t:1527189112608};\\\", \\\"{x:1609,y:755,t:1527189112625};\\\", \\\"{x:1612,y:746,t:1527189112642};\\\", \\\"{x:1614,y:737,t:1527189112658};\\\", \\\"{x:1617,y:725,t:1527189112675};\\\", \\\"{x:1617,y:707,t:1527189112692};\\\", \\\"{x:1619,y:692,t:1527189112710};\\\", \\\"{x:1623,y:682,t:1527189112726};\\\", \\\"{x:1624,y:677,t:1527189112742};\\\", \\\"{x:1626,y:671,t:1527189112760};\\\", \\\"{x:1626,y:669,t:1527189112775};\\\", \\\"{x:1626,y:668,t:1527189112792};\\\", \\\"{x:1627,y:663,t:1527189112810};\\\", \\\"{x:1627,y:660,t:1527189112825};\\\", \\\"{x:1627,y:654,t:1527189112842};\\\", \\\"{x:1627,y:644,t:1527189112859};\\\", \\\"{x:1619,y:631,t:1527189112876};\\\", \\\"{x:1615,y:625,t:1527189112892};\\\", \\\"{x:1615,y:624,t:1527189112910};\\\", \\\"{x:1615,y:623,t:1527189112925};\\\", \\\"{x:1614,y:623,t:1527189113199};\\\", \\\"{x:1606,y:623,t:1527189113209};\\\", \\\"{x:1585,y:623,t:1527189113226};\\\", \\\"{x:1567,y:626,t:1527189113242};\\\", \\\"{x:1549,y:631,t:1527189113259};\\\", \\\"{x:1521,y:637,t:1527189113276};\\\", \\\"{x:1496,y:643,t:1527189113292};\\\", \\\"{x:1476,y:654,t:1527189113309};\\\", \\\"{x:1460,y:661,t:1527189113326};\\\", \\\"{x:1444,y:667,t:1527189113342};\\\", \\\"{x:1415,y:673,t:1527189113359};\\\", \\\"{x:1393,y:673,t:1527189113376};\\\", \\\"{x:1372,y:673,t:1527189113392};\\\", \\\"{x:1349,y:668,t:1527189113409};\\\", \\\"{x:1327,y:663,t:1527189113426};\\\", \\\"{x:1309,y:656,t:1527189113442};\\\", \\\"{x:1291,y:649,t:1527189113459};\\\", \\\"{x:1289,y:648,t:1527189113477};\\\", \\\"{x:1289,y:647,t:1527189113575};\\\", \\\"{x:1289,y:645,t:1527189113593};\\\", \\\"{x:1297,y:643,t:1527189113610};\\\", \\\"{x:1303,y:639,t:1527189113626};\\\", \\\"{x:1309,y:637,t:1527189113642};\\\", \\\"{x:1310,y:635,t:1527189113659};\\\", \\\"{x:1312,y:635,t:1527189113703};\\\", \\\"{x:1314,y:635,t:1527189113718};\\\", \\\"{x:1316,y:635,t:1527189113727};\\\", \\\"{x:1319,y:636,t:1527189113743};\\\", \\\"{x:1320,y:636,t:1527189113831};\\\", \\\"{x:1322,y:636,t:1527189113847};\\\", \\\"{x:1323,y:636,t:1527189113895};\\\", \\\"{x:1325,y:637,t:1527189113935};\\\", \\\"{x:1327,y:638,t:1527189113942};\\\", \\\"{x:1330,y:639,t:1527189113959};\\\", \\\"{x:1333,y:641,t:1527189113976};\\\", \\\"{x:1334,y:641,t:1527189113994};\\\", \\\"{x:1335,y:641,t:1527189114015};\\\", \\\"{x:1336,y:641,t:1527189114026};\\\", \\\"{x:1339,y:643,t:1527189114044};\\\", \\\"{x:1341,y:643,t:1527189114059};\\\", \\\"{x:1342,y:643,t:1527189114077};\\\", \\\"{x:1343,y:643,t:1527189114160};\\\", \\\"{x:1344,y:643,t:1527189114271};\\\", \\\"{x:1346,y:643,t:1527189114279};\\\", \\\"{x:1347,y:643,t:1527189114295};\\\", \\\"{x:1349,y:643,t:1527189114310};\\\", \\\"{x:1352,y:642,t:1527189114326};\\\", \\\"{x:1359,y:639,t:1527189114344};\\\", \\\"{x:1361,y:639,t:1527189114360};\\\", \\\"{x:1362,y:639,t:1527189114376};\\\", \\\"{x:1360,y:639,t:1527189114680};\\\", \\\"{x:1359,y:639,t:1527189114800};\\\", \\\"{x:1357,y:640,t:1527189114810};\\\", \\\"{x:1355,y:641,t:1527189114827};\\\", \\\"{x:1353,y:642,t:1527189114844};\\\", \\\"{x:1351,y:643,t:1527189114859};\\\", \\\"{x:1350,y:643,t:1527189114876};\\\", \\\"{x:1349,y:643,t:1527189114934};\\\", \\\"{x:1348,y:644,t:1527189114957};\\\", \\\"{x:1347,y:644,t:1527189114990};\\\", \\\"{x:1346,y:645,t:1527189115047};\\\", \\\"{x:1346,y:646,t:1527189115059};\\\", \\\"{x:1346,y:650,t:1527189115078};\\\", \\\"{x:1345,y:656,t:1527189115093};\\\", \\\"{x:1344,y:663,t:1527189115110};\\\", \\\"{x:1344,y:679,t:1527189115126};\\\", \\\"{x:1344,y:689,t:1527189115143};\\\", \\\"{x:1344,y:696,t:1527189115160};\\\", \\\"{x:1344,y:703,t:1527189115177};\\\", \\\"{x:1344,y:708,t:1527189115195};\\\", \\\"{x:1344,y:714,t:1527189115210};\\\", \\\"{x:1344,y:715,t:1527189115228};\\\", \\\"{x:1344,y:718,t:1527189115244};\\\", \\\"{x:1344,y:721,t:1527189115261};\\\", \\\"{x:1344,y:724,t:1527189115277};\\\", \\\"{x:1344,y:727,t:1527189115294};\\\", \\\"{x:1344,y:732,t:1527189115310};\\\", \\\"{x:1346,y:745,t:1527189115327};\\\", \\\"{x:1348,y:752,t:1527189115344};\\\", \\\"{x:1348,y:760,t:1527189115360};\\\", \\\"{x:1348,y:766,t:1527189115378};\\\", \\\"{x:1350,y:776,t:1527189115395};\\\", \\\"{x:1350,y:782,t:1527189115410};\\\", \\\"{x:1350,y:795,t:1527189115427};\\\", \\\"{x:1350,y:805,t:1527189115444};\\\", \\\"{x:1350,y:814,t:1527189115460};\\\", \\\"{x:1350,y:822,t:1527189115477};\\\", \\\"{x:1350,y:834,t:1527189115495};\\\", \\\"{x:1350,y:837,t:1527189115510};\\\", \\\"{x:1350,y:852,t:1527189115527};\\\", \\\"{x:1350,y:859,t:1527189115544};\\\", \\\"{x:1350,y:864,t:1527189115561};\\\", \\\"{x:1350,y:868,t:1527189115577};\\\", \\\"{x:1350,y:871,t:1527189115595};\\\", \\\"{x:1350,y:874,t:1527189115611};\\\", \\\"{x:1350,y:875,t:1527189115671};\\\", \\\"{x:1350,y:877,t:1527189115687};\\\", \\\"{x:1350,y:878,t:1527189115695};\\\", \\\"{x:1350,y:881,t:1527189115711};\\\", \\\"{x:1350,y:885,t:1527189115728};\\\", \\\"{x:1348,y:892,t:1527189115744};\\\", \\\"{x:1347,y:897,t:1527189115762};\\\", \\\"{x:1347,y:903,t:1527189115778};\\\", \\\"{x:1345,y:910,t:1527189115794};\\\", \\\"{x:1345,y:912,t:1527189115812};\\\", \\\"{x:1345,y:913,t:1527189115828};\\\", \\\"{x:1344,y:915,t:1527189115844};\\\", \\\"{x:1344,y:917,t:1527189115862};\\\", \\\"{x:1344,y:919,t:1527189115877};\\\", \\\"{x:1344,y:920,t:1527189115911};\\\", \\\"{x:1344,y:913,t:1527189116056};\\\", \\\"{x:1345,y:906,t:1527189116063};\\\", \\\"{x:1347,y:898,t:1527189116078};\\\", \\\"{x:1353,y:876,t:1527189116094};\\\", \\\"{x:1377,y:824,t:1527189116111};\\\", \\\"{x:1389,y:796,t:1527189116129};\\\", \\\"{x:1395,y:773,t:1527189116144};\\\", \\\"{x:1395,y:741,t:1527189116162};\\\", \\\"{x:1393,y:719,t:1527189116178};\\\", \\\"{x:1390,y:709,t:1527189116195};\\\", \\\"{x:1388,y:704,t:1527189116211};\\\", \\\"{x:1387,y:699,t:1527189116228};\\\", \\\"{x:1384,y:696,t:1527189116244};\\\", \\\"{x:1383,y:696,t:1527189116262};\\\", \\\"{x:1382,y:696,t:1527189116295};\\\", \\\"{x:1380,y:694,t:1527189116312};\\\", \\\"{x:1379,y:694,t:1527189116328};\\\", \\\"{x:1374,y:692,t:1527189116344};\\\", \\\"{x:1371,y:689,t:1527189116362};\\\", \\\"{x:1369,y:684,t:1527189116379};\\\", \\\"{x:1369,y:679,t:1527189116395};\\\", \\\"{x:1368,y:675,t:1527189116411};\\\", \\\"{x:1367,y:669,t:1527189116428};\\\", \\\"{x:1365,y:665,t:1527189116444};\\\", \\\"{x:1363,y:661,t:1527189116461};\\\", \\\"{x:1363,y:659,t:1527189116478};\\\", \\\"{x:1363,y:655,t:1527189116495};\\\", \\\"{x:1361,y:650,t:1527189116511};\\\", \\\"{x:1361,y:646,t:1527189116529};\\\", \\\"{x:1361,y:641,t:1527189116545};\\\", \\\"{x:1361,y:638,t:1527189116561};\\\", \\\"{x:1359,y:636,t:1527189116578};\\\", \\\"{x:1359,y:635,t:1527189116595};\\\", \\\"{x:1361,y:635,t:1527189116720};\\\", \\\"{x:1364,y:636,t:1527189116728};\\\", \\\"{x:1367,y:637,t:1527189116746};\\\", \\\"{x:1368,y:639,t:1527189116761};\\\", \\\"{x:1370,y:639,t:1527189116778};\\\", \\\"{x:1372,y:640,t:1527189116794};\\\", \\\"{x:1376,y:642,t:1527189116810};\\\", \\\"{x:1378,y:643,t:1527189116827};\\\", \\\"{x:1380,y:643,t:1527189116844};\\\", \\\"{x:1382,y:644,t:1527189116861};\\\", \\\"{x:1383,y:644,t:1527189116942};\\\", \\\"{x:1384,y:644,t:1527189116966};\\\", \\\"{x:1385,y:644,t:1527189116978};\\\", \\\"{x:1386,y:644,t:1527189116995};\\\", \\\"{x:1387,y:644,t:1527189117022};\\\", \\\"{x:1388,y:644,t:1527189117030};\\\", \\\"{x:1390,y:643,t:1527189117045};\\\", \\\"{x:1392,y:642,t:1527189117062};\\\", \\\"{x:1394,y:641,t:1527189117078};\\\", \\\"{x:1397,y:639,t:1527189117095};\\\", \\\"{x:1398,y:638,t:1527189117112};\\\", \\\"{x:1400,y:638,t:1527189117128};\\\", \\\"{x:1400,y:637,t:1527189117145};\\\", \\\"{x:1401,y:637,t:1527189117191};\\\", \\\"{x:1402,y:637,t:1527189117199};\\\", \\\"{x:1404,y:637,t:1527189117213};\\\", \\\"{x:1408,y:637,t:1527189117228};\\\", \\\"{x:1410,y:637,t:1527189117245};\\\", \\\"{x:1411,y:637,t:1527189117495};\\\", \\\"{x:1414,y:637,t:1527189117512};\\\", \\\"{x:1418,y:639,t:1527189117529};\\\", \\\"{x:1421,y:642,t:1527189117545};\\\", \\\"{x:1421,y:643,t:1527189117562};\\\", \\\"{x:1423,y:644,t:1527189117579};\\\", \\\"{x:1432,y:648,t:1527189117595};\\\", \\\"{x:1444,y:653,t:1527189117611};\\\", \\\"{x:1456,y:657,t:1527189117628};\\\", \\\"{x:1468,y:663,t:1527189117644};\\\", \\\"{x:1472,y:665,t:1527189117661};\\\", \\\"{x:1474,y:665,t:1527189117702};\\\", \\\"{x:1475,y:665,t:1527189117726};\\\", \\\"{x:1476,y:664,t:1527189117734};\\\", \\\"{x:1477,y:662,t:1527189117745};\\\", \\\"{x:1483,y:657,t:1527189117762};\\\", \\\"{x:1488,y:653,t:1527189117778};\\\", \\\"{x:1493,y:649,t:1527189117795};\\\", \\\"{x:1495,y:647,t:1527189117812};\\\", \\\"{x:1495,y:646,t:1527189117828};\\\", \\\"{x:1495,y:645,t:1527189117845};\\\", \\\"{x:1495,y:644,t:1527189117862};\\\", \\\"{x:1495,y:643,t:1527189117943};\\\", \\\"{x:1493,y:642,t:1527189117951};\\\", \\\"{x:1491,y:642,t:1527189117963};\\\", \\\"{x:1487,y:639,t:1527189117979};\\\", \\\"{x:1485,y:639,t:1527189117995};\\\", \\\"{x:1484,y:638,t:1527189118013};\\\", \\\"{x:1483,y:638,t:1527189118030};\\\", \\\"{x:1482,y:637,t:1527189118046};\\\", \\\"{x:1481,y:637,t:1527189118062};\\\", \\\"{x:1479,y:637,t:1527189118080};\\\", \\\"{x:1477,y:636,t:1527189118097};\\\", \\\"{x:1476,y:636,t:1527189118158};\\\", \\\"{x:1479,y:636,t:1527189118174};\\\", \\\"{x:1480,y:638,t:1527189118181};\\\", \\\"{x:1482,y:639,t:1527189118195};\\\", \\\"{x:1491,y:643,t:1527189118212};\\\", \\\"{x:1505,y:647,t:1527189118229};\\\", \\\"{x:1523,y:651,t:1527189118245};\\\", \\\"{x:1536,y:652,t:1527189118262};\\\", \\\"{x:1543,y:652,t:1527189118278};\\\", \\\"{x:1546,y:652,t:1527189118296};\\\", \\\"{x:1547,y:652,t:1527189118383};\\\", \\\"{x:1548,y:652,t:1527189118471};\\\", \\\"{x:1548,y:651,t:1527189118479};\\\", \\\"{x:1548,y:650,t:1527189118503};\\\", \\\"{x:1549,y:649,t:1527189118728};\\\", \\\"{x:1552,y:649,t:1527189118735};\\\", \\\"{x:1553,y:649,t:1527189118746};\\\", \\\"{x:1558,y:650,t:1527189118763};\\\", \\\"{x:1562,y:652,t:1527189118779};\\\", \\\"{x:1565,y:653,t:1527189118796};\\\", \\\"{x:1571,y:655,t:1527189118814};\\\", \\\"{x:1580,y:659,t:1527189118830};\\\", \\\"{x:1597,y:663,t:1527189118847};\\\", \\\"{x:1608,y:663,t:1527189118863};\\\", \\\"{x:1613,y:663,t:1527189118879};\\\", \\\"{x:1614,y:663,t:1527189118896};\\\", \\\"{x:1614,y:662,t:1527189118919};\\\", \\\"{x:1614,y:661,t:1527189118943};\\\", \\\"{x:1614,y:659,t:1527189118958};\\\", \\\"{x:1616,y:657,t:1527189118966};\\\", \\\"{x:1617,y:656,t:1527189118980};\\\", \\\"{x:1617,y:652,t:1527189118996};\\\", \\\"{x:1619,y:649,t:1527189119013};\\\", \\\"{x:1622,y:645,t:1527189119030};\\\", \\\"{x:1624,y:644,t:1527189119047};\\\", \\\"{x:1624,y:643,t:1527189119160};\\\", \\\"{x:1624,y:642,t:1527189119183};\\\", \\\"{x:1623,y:642,t:1527189119196};\\\", \\\"{x:1621,y:640,t:1527189119213};\\\", \\\"{x:1619,y:639,t:1527189119231};\\\", \\\"{x:1618,y:639,t:1527189119247};\\\", \\\"{x:1617,y:639,t:1527189119262};\\\", \\\"{x:1616,y:639,t:1527189119281};\\\", \\\"{x:1615,y:639,t:1527189119296};\\\", \\\"{x:1613,y:639,t:1527189119313};\\\", \\\"{x:1611,y:639,t:1527189119330};\\\", \\\"{x:1611,y:641,t:1527189119511};\\\", \\\"{x:1611,y:642,t:1527189119518};\\\", \\\"{x:1611,y:643,t:1527189119530};\\\", \\\"{x:1611,y:644,t:1527189119547};\\\", \\\"{x:1611,y:645,t:1527189119710};\\\", \\\"{x:1611,y:646,t:1527189119719};\\\", \\\"{x:1611,y:649,t:1527189119731};\\\", \\\"{x:1611,y:654,t:1527189119748};\\\", \\\"{x:1611,y:661,t:1527189119763};\\\", \\\"{x:1611,y:668,t:1527189119781};\\\", \\\"{x:1611,y:676,t:1527189119798};\\\", \\\"{x:1613,y:683,t:1527189119813};\\\", \\\"{x:1614,y:690,t:1527189119830};\\\", \\\"{x:1614,y:692,t:1527189119847};\\\", \\\"{x:1614,y:693,t:1527189119863};\\\", \\\"{x:1614,y:694,t:1527189119902};\\\", \\\"{x:1614,y:695,t:1527189119914};\\\", \\\"{x:1614,y:699,t:1527189119930};\\\", \\\"{x:1614,y:704,t:1527189119947};\\\", \\\"{x:1614,y:710,t:1527189119964};\\\", \\\"{x:1614,y:714,t:1527189119980};\\\", \\\"{x:1614,y:723,t:1527189119996};\\\", \\\"{x:1614,y:734,t:1527189120013};\\\", \\\"{x:1614,y:743,t:1527189120030};\\\", \\\"{x:1614,y:751,t:1527189120047};\\\", \\\"{x:1614,y:754,t:1527189120064};\\\", \\\"{x:1614,y:756,t:1527189120080};\\\", \\\"{x:1614,y:758,t:1527189120097};\\\", \\\"{x:1614,y:759,t:1527189120215};\\\", \\\"{x:1614,y:761,t:1527189120230};\\\", \\\"{x:1614,y:765,t:1527189120248};\\\", \\\"{x:1614,y:771,t:1527189120265};\\\", \\\"{x:1614,y:777,t:1527189120280};\\\", \\\"{x:1614,y:781,t:1527189120296};\\\", \\\"{x:1614,y:785,t:1527189120314};\\\", \\\"{x:1614,y:791,t:1527189120331};\\\", \\\"{x:1614,y:796,t:1527189120346};\\\", \\\"{x:1613,y:802,t:1527189120364};\\\", \\\"{x:1612,y:808,t:1527189120380};\\\", \\\"{x:1611,y:812,t:1527189120397};\\\", \\\"{x:1610,y:818,t:1527189120414};\\\", \\\"{x:1610,y:822,t:1527189120430};\\\", \\\"{x:1610,y:830,t:1527189120446};\\\", \\\"{x:1610,y:838,t:1527189120464};\\\", \\\"{x:1610,y:848,t:1527189120481};\\\", \\\"{x:1609,y:855,t:1527189120497};\\\", \\\"{x:1608,y:865,t:1527189120514};\\\", \\\"{x:1608,y:878,t:1527189120531};\\\", \\\"{x:1606,y:889,t:1527189120547};\\\", \\\"{x:1605,y:902,t:1527189120563};\\\", \\\"{x:1603,y:911,t:1527189120581};\\\", \\\"{x:1602,y:916,t:1527189120597};\\\", \\\"{x:1601,y:919,t:1527189120614};\\\", \\\"{x:1601,y:921,t:1527189120630};\\\", \\\"{x:1601,y:922,t:1527189120687};\\\", \\\"{x:1602,y:922,t:1527189120823};\\\", \\\"{x:1606,y:922,t:1527189120830};\\\", \\\"{x:1611,y:922,t:1527189120849};\\\", \\\"{x:1615,y:920,t:1527189120864};\\\", \\\"{x:1617,y:918,t:1527189120881};\\\", \\\"{x:1617,y:917,t:1527189120919};\\\", \\\"{x:1617,y:916,t:1527189120959};\\\", \\\"{x:1617,y:915,t:1527189120967};\\\", \\\"{x:1618,y:915,t:1527189120981};\\\", \\\"{x:1619,y:912,t:1527189120999};\\\", \\\"{x:1619,y:911,t:1527189121015};\\\", \\\"{x:1620,y:910,t:1527189121032};\\\", \\\"{x:1620,y:909,t:1527189121056};\\\", \\\"{x:1618,y:908,t:1527189122144};\\\", \\\"{x:1614,y:906,t:1527189122536};\\\", \\\"{x:1607,y:899,t:1527189122549};\\\", \\\"{x:1583,y:879,t:1527189122566};\\\", \\\"{x:1521,y:827,t:1527189122583};\\\", \\\"{x:1507,y:809,t:1527189122599};\\\", \\\"{x:1502,y:801,t:1527189122616};\\\", \\\"{x:1499,y:795,t:1527189122633};\\\", \\\"{x:1497,y:789,t:1527189122649};\\\", \\\"{x:1496,y:788,t:1527189122666};\\\", \\\"{x:1496,y:789,t:1527189122783};\\\", \\\"{x:1495,y:790,t:1527189122822};\\\", \\\"{x:1492,y:790,t:1527189122839};\\\", \\\"{x:1487,y:790,t:1527189122850};\\\", \\\"{x:1484,y:788,t:1527189122866};\\\", \\\"{x:1481,y:787,t:1527189122883};\\\", \\\"{x:1481,y:786,t:1527189122992};\\\", \\\"{x:1481,y:785,t:1527189123000};\\\", \\\"{x:1480,y:781,t:1527189123017};\\\", \\\"{x:1480,y:778,t:1527189123032};\\\", \\\"{x:1479,y:775,t:1527189123049};\\\", \\\"{x:1478,y:772,t:1527189123066};\\\", \\\"{x:1477,y:772,t:1527189123084};\\\", \\\"{x:1476,y:771,t:1527189123759};\\\", \\\"{x:1479,y:771,t:1527189124703};\\\", \\\"{x:1481,y:772,t:1527189124718};\\\", \\\"{x:1486,y:775,t:1527189124735};\\\", \\\"{x:1488,y:775,t:1527189124752};\\\", \\\"{x:1490,y:777,t:1527189124767};\\\", \\\"{x:1494,y:779,t:1527189124784};\\\", \\\"{x:1499,y:781,t:1527189124800};\\\", \\\"{x:1502,y:783,t:1527189124818};\\\", \\\"{x:1506,y:784,t:1527189124835};\\\", \\\"{x:1507,y:785,t:1527189124850};\\\", \\\"{x:1509,y:786,t:1527189124868};\\\", \\\"{x:1512,y:788,t:1527189124884};\\\", \\\"{x:1519,y:791,t:1527189124901};\\\", \\\"{x:1522,y:792,t:1527189124917};\\\", \\\"{x:1523,y:792,t:1527189124975};\\\", \\\"{x:1525,y:791,t:1527189124984};\\\", \\\"{x:1528,y:789,t:1527189125001};\\\", \\\"{x:1533,y:787,t:1527189125018};\\\", \\\"{x:1538,y:783,t:1527189125035};\\\", \\\"{x:1543,y:782,t:1527189125050};\\\", \\\"{x:1545,y:779,t:1527189125068};\\\", \\\"{x:1546,y:779,t:1527189125084};\\\", \\\"{x:1547,y:778,t:1527189125102};\\\", \\\"{x:1549,y:777,t:1527189125117};\\\", \\\"{x:1552,y:774,t:1527189125135};\\\", \\\"{x:1555,y:772,t:1527189125151};\\\", \\\"{x:1559,y:769,t:1527189125168};\\\", \\\"{x:1561,y:765,t:1527189125184};\\\", \\\"{x:1562,y:762,t:1527189125202};\\\", \\\"{x:1565,y:758,t:1527189125217};\\\", \\\"{x:1566,y:757,t:1527189125235};\\\", \\\"{x:1566,y:759,t:1527189125351};\\\", \\\"{x:1571,y:768,t:1527189125368};\\\", \\\"{x:1577,y:778,t:1527189125384};\\\", \\\"{x:1585,y:786,t:1527189125402};\\\", \\\"{x:1589,y:790,t:1527189125417};\\\", \\\"{x:1590,y:792,t:1527189125434};\\\", \\\"{x:1591,y:792,t:1527189125455};\\\", \\\"{x:1593,y:793,t:1527189125527};\\\", \\\"{x:1595,y:794,t:1527189125535};\\\", \\\"{x:1597,y:795,t:1527189125552};\\\", \\\"{x:1598,y:796,t:1527189125569};\\\", \\\"{x:1599,y:797,t:1527189125607};\\\", \\\"{x:1601,y:797,t:1527189125618};\\\", \\\"{x:1609,y:795,t:1527189125635};\\\", \\\"{x:1614,y:792,t:1527189125652};\\\", \\\"{x:1620,y:789,t:1527189125669};\\\", \\\"{x:1622,y:785,t:1527189125685};\\\", \\\"{x:1623,y:782,t:1527189125701};\\\", \\\"{x:1623,y:774,t:1527189125719};\\\", \\\"{x:1624,y:771,t:1527189125735};\\\", \\\"{x:1624,y:770,t:1527189125752};\\\", \\\"{x:1624,y:769,t:1527189125768};\\\", \\\"{x:1624,y:768,t:1527189125823};\\\", \\\"{x:1624,y:767,t:1527189125839};\\\", \\\"{x:1623,y:767,t:1527189125851};\\\", \\\"{x:1622,y:767,t:1527189125879};\\\", \\\"{x:1621,y:767,t:1527189126127};\\\", \\\"{x:1619,y:767,t:1527189126143};\\\", \\\"{x:1618,y:767,t:1527189126183};\\\", \\\"{x:1617,y:767,t:1527189126191};\\\", \\\"{x:1616,y:767,t:1527189126207};\\\", \\\"{x:1615,y:767,t:1527189126239};\\\", \\\"{x:1614,y:767,t:1527189126252};\\\", \\\"{x:1613,y:767,t:1527189126268};\\\", \\\"{x:1612,y:767,t:1527189126285};\\\", \\\"{x:1611,y:767,t:1527189126302};\\\", \\\"{x:1610,y:768,t:1527189126341};\\\", \\\"{x:1607,y:768,t:1527189127822};\\\", \\\"{x:1590,y:768,t:1527189127836};\\\", \\\"{x:1509,y:758,t:1527189127852};\\\", \\\"{x:1379,y:737,t:1527189127869};\\\", \\\"{x:1179,y:733,t:1527189127885};\\\", \\\"{x:1060,y:733,t:1527189127904};\\\", \\\"{x:941,y:716,t:1527189127919};\\\", \\\"{x:822,y:685,t:1527189127936};\\\", \\\"{x:716,y:650,t:1527189127953};\\\", \\\"{x:618,y:612,t:1527189127969};\\\", \\\"{x:556,y:582,t:1527189127986};\\\", \\\"{x:531,y:566,t:1527189128004};\\\", \\\"{x:523,y:561,t:1527189128018};\\\", \\\"{x:519,y:555,t:1527189128036};\\\", \\\"{x:510,y:542,t:1527189128056};\\\", \\\"{x:499,y:527,t:1527189128073};\\\", \\\"{x:481,y:510,t:1527189128091};\\\", \\\"{x:450,y:488,t:1527189128106};\\\", \\\"{x:406,y:461,t:1527189128123};\\\", \\\"{x:360,y:438,t:1527189128140};\\\", \\\"{x:323,y:418,t:1527189128156};\\\", \\\"{x:290,y:405,t:1527189128173};\\\", \\\"{x:253,y:389,t:1527189128190};\\\", \\\"{x:240,y:384,t:1527189128206};\\\", \\\"{x:236,y:382,t:1527189128223};\\\", \\\"{x:234,y:382,t:1527189128240};\\\", \\\"{x:233,y:382,t:1527189128262};\\\", \\\"{x:233,y:383,t:1527189128273};\\\", \\\"{x:231,y:385,t:1527189128290};\\\", \\\"{x:231,y:392,t:1527189128307};\\\", \\\"{x:231,y:405,t:1527189128323};\\\", \\\"{x:232,y:422,t:1527189128340};\\\", \\\"{x:236,y:441,t:1527189128358};\\\", \\\"{x:236,y:445,t:1527189128373};\\\", \\\"{x:236,y:454,t:1527189128389};\\\", \\\"{x:237,y:458,t:1527189128406};\\\", \\\"{x:237,y:459,t:1527189128686};\\\", \\\"{x:243,y:467,t:1527189128694};\\\", \\\"{x:249,y:479,t:1527189128707};\\\", \\\"{x:271,y:508,t:1527189128723};\\\", \\\"{x:300,y:545,t:1527189128740};\\\", \\\"{x:378,y:624,t:1527189128757};\\\", \\\"{x:423,y:661,t:1527189128773};\\\", \\\"{x:632,y:785,t:1527189128789};\\\", \\\"{x:820,y:866,t:1527189128807};\\\", \\\"{x:1011,y:930,t:1527189128823};\\\", \\\"{x:1209,y:979,t:1527189128840};\\\", \\\"{x:1389,y:1013,t:1527189128857};\\\", \\\"{x:1539,y:1032,t:1527189128874};\\\", \\\"{x:1622,y:1031,t:1527189128890};\\\", \\\"{x:1655,y:1017,t:1527189128907};\\\", \\\"{x:1660,y:1000,t:1527189128924};\\\", \\\"{x:1645,y:965,t:1527189128941};\\\", \\\"{x:1584,y:883,t:1527189128958};\\\", \\\"{x:1526,y:820,t:1527189128974};\\\", \\\"{x:1479,y:762,t:1527189128990};\\\", \\\"{x:1441,y:709,t:1527189129007};\\\", \\\"{x:1425,y:683,t:1527189129024};\\\", \\\"{x:1414,y:666,t:1527189129040};\\\", \\\"{x:1409,y:659,t:1527189129057};\\\", \\\"{x:1408,y:658,t:1527189129074};\\\", \\\"{x:1409,y:658,t:1527189129157};\\\", \\\"{x:1414,y:660,t:1527189129174};\\\", \\\"{x:1422,y:662,t:1527189129190};\\\", \\\"{x:1431,y:667,t:1527189129207};\\\", \\\"{x:1443,y:674,t:1527189129224};\\\", \\\"{x:1454,y:683,t:1527189129240};\\\", \\\"{x:1472,y:699,t:1527189129257};\\\", \\\"{x:1493,y:723,t:1527189129275};\\\", \\\"{x:1508,y:745,t:1527189129291};\\\", \\\"{x:1520,y:766,t:1527189129307};\\\", \\\"{x:1525,y:782,t:1527189129324};\\\", \\\"{x:1527,y:790,t:1527189129341};\\\", \\\"{x:1527,y:795,t:1527189129357};\\\", \\\"{x:1526,y:796,t:1527189129373};\\\", \\\"{x:1525,y:798,t:1527189129391};\\\", \\\"{x:1524,y:798,t:1527189129407};\\\", \\\"{x:1522,y:798,t:1527189129437};\\\", \\\"{x:1520,y:798,t:1527189129445};\\\", \\\"{x:1516,y:796,t:1527189129457};\\\", \\\"{x:1490,y:789,t:1527189129474};\\\", \\\"{x:1423,y:768,t:1527189129491};\\\", \\\"{x:1326,y:742,t:1527189129507};\\\", \\\"{x:1198,y:717,t:1527189129524};\\\", \\\"{x:1051,y:695,t:1527189129541};\\\", \\\"{x:801,y:660,t:1527189129557};\\\", \\\"{x:637,y:635,t:1527189129574};\\\", \\\"{x:486,y:616,t:1527189129591};\\\", \\\"{x:373,y:604,t:1527189129606};\\\", \\\"{x:308,y:604,t:1527189129623};\\\", \\\"{x:283,y:604,t:1527189129639};\\\", \\\"{x:279,y:604,t:1527189129655};\\\", \\\"{x:278,y:604,t:1527189129702};\\\", \\\"{x:278,y:606,t:1527189129709};\\\", \\\"{x:281,y:606,t:1527189129723};\\\", \\\"{x:282,y:607,t:1527189129739};\\\", \\\"{x:283,y:608,t:1527189129781};\\\", \\\"{x:285,y:606,t:1527189129789};\\\", \\\"{x:292,y:597,t:1527189129805};\\\", \\\"{x:305,y:588,t:1527189129822};\\\", \\\"{x:317,y:576,t:1527189129840};\\\", \\\"{x:326,y:567,t:1527189129856};\\\", \\\"{x:332,y:553,t:1527189129874};\\\", \\\"{x:333,y:543,t:1527189129892};\\\", \\\"{x:336,y:535,t:1527189129908};\\\", \\\"{x:338,y:526,t:1527189129924};\\\", \\\"{x:341,y:518,t:1527189129941};\\\", \\\"{x:345,y:509,t:1527189129958};\\\", \\\"{x:348,y:504,t:1527189129974};\\\", \\\"{x:349,y:503,t:1527189129991};\\\", \\\"{x:350,y:505,t:1527189130029};\\\", \\\"{x:347,y:511,t:1527189130041};\\\", \\\"{x:326,y:526,t:1527189130057};\\\", \\\"{x:293,y:548,t:1527189130075};\\\", \\\"{x:254,y:575,t:1527189130091};\\\", \\\"{x:214,y:595,t:1527189130109};\\\", \\\"{x:174,y:608,t:1527189130126};\\\", \\\"{x:158,y:614,t:1527189130142};\\\", \\\"{x:155,y:614,t:1527189130158};\\\", \\\"{x:165,y:614,t:1527189130317};\\\", \\\"{x:190,y:614,t:1527189130326};\\\", \\\"{x:287,y:614,t:1527189130342};\\\", \\\"{x:420,y:614,t:1527189130359};\\\", \\\"{x:561,y:614,t:1527189130376};\\\", \\\"{x:695,y:609,t:1527189130391};\\\", \\\"{x:811,y:595,t:1527189130408};\\\", \\\"{x:864,y:587,t:1527189130425};\\\", \\\"{x:874,y:582,t:1527189130441};\\\", \\\"{x:872,y:578,t:1527189130459};\\\", \\\"{x:849,y:566,t:1527189130475};\\\", \\\"{x:820,y:557,t:1527189130491};\\\", \\\"{x:810,y:552,t:1527189130508};\\\", \\\"{x:796,y:551,t:1527189130525};\\\", \\\"{x:766,y:546,t:1527189130541};\\\", \\\"{x:736,y:541,t:1527189130558};\\\", \\\"{x:700,y:540,t:1527189130575};\\\", \\\"{x:666,y:540,t:1527189130592};\\\", \\\"{x:639,y:540,t:1527189130608};\\\", \\\"{x:624,y:540,t:1527189130625};\\\", \\\"{x:619,y:540,t:1527189130642};\\\", \\\"{x:613,y:540,t:1527189130658};\\\", \\\"{x:610,y:540,t:1527189130675};\\\", \\\"{x:609,y:540,t:1527189130709};\\\", \\\"{x:608,y:540,t:1527189130725};\\\", \\\"{x:601,y:540,t:1527189130742};\\\", \\\"{x:599,y:539,t:1527189130758};\\\", \\\"{x:598,y:539,t:1527189130790};\\\", \\\"{x:598,y:540,t:1527189130821};\\\", \\\"{x:598,y:541,t:1527189130838};\\\", \\\"{x:599,y:541,t:1527189130845};\\\", \\\"{x:600,y:542,t:1527189130857};\\\", \\\"{x:602,y:543,t:1527189130875};\\\", \\\"{x:605,y:544,t:1527189130892};\\\", \\\"{x:606,y:544,t:1527189130910};\\\", \\\"{x:607,y:544,t:1527189130925};\\\", \\\"{x:608,y:544,t:1527189130958};\\\", \\\"{x:609,y:544,t:1527189131085};\\\", \\\"{x:609,y:542,t:1527189131093};\\\", \\\"{x:609,y:540,t:1527189131108};\\\", \\\"{x:611,y:532,t:1527189131126};\\\", \\\"{x:612,y:528,t:1527189131142};\\\", \\\"{x:612,y:526,t:1527189131159};\\\", \\\"{x:613,y:525,t:1527189131175};\\\", \\\"{x:613,y:524,t:1527189141766};\\\", \\\"{x:608,y:526,t:1527189141774};\\\", \\\"{x:600,y:530,t:1527189141788};\\\", \\\"{x:580,y:546,t:1527189141806};\\\", \\\"{x:563,y:561,t:1527189141821};\\\", \\\"{x:536,y:582,t:1527189141854};\\\", \\\"{x:535,y:583,t:1527189141867};\\\", \\\"{x:532,y:585,t:1527189141883};\\\", \\\"{x:530,y:588,t:1527189141901};\\\", \\\"{x:526,y:598,t:1527189141916};\\\", \\\"{x:519,y:615,t:1527189141933};\\\", \\\"{x:514,y:626,t:1527189141951};\\\", \\\"{x:509,y:633,t:1527189141967};\\\", \\\"{x:507,y:639,t:1527189141983};\\\", \\\"{x:506,y:641,t:1527189142001};\\\", \\\"{x:506,y:642,t:1527189142017};\\\", \\\"{x:506,y:644,t:1527189142034};\\\", \\\"{x:506,y:645,t:1527189142051};\\\", \\\"{x:506,y:647,t:1527189142067};\\\", \\\"{x:506,y:648,t:1527189142084};\\\", \\\"{x:506,y:649,t:1527189142101};\\\", \\\"{x:506,y:651,t:1527189142117};\\\", \\\"{x:506,y:656,t:1527189142134};\\\", \\\"{x:506,y:659,t:1527189142150};\\\", \\\"{x:506,y:661,t:1527189142167};\\\", \\\"{x:506,y:664,t:1527189142184};\\\", \\\"{x:506,y:666,t:1527189142201};\\\", \\\"{x:505,y:667,t:1527189142219};\\\", \\\"{x:504,y:668,t:1527189142233};\\\", \\\"{x:503,y:668,t:1527189142251};\\\", \\\"{x:503,y:669,t:1527189142268};\\\", \\\"{x:502,y:669,t:1527189142285};\\\", \\\"{x:501,y:669,t:1527189142325};\\\", \\\"{x:501,y:670,t:1527189142336};\\\", \\\"{x:499,y:671,t:1527189142352};\\\", \\\"{x:498,y:672,t:1527189142374};\\\", \\\"{x:497,y:673,t:1527189142386};\\\", \\\"{x:497,y:674,t:1527189142406};\\\", \\\"{x:497,y:675,t:1527189142422};\\\", \\\"{x:497,y:673,t:1527189142910};\\\", \\\"{x:497,y:668,t:1527189142919};\\\", \\\"{x:499,y:661,t:1527189142936};\\\", \\\"{x:508,y:649,t:1527189142952};\\\", \\\"{x:516,y:636,t:1527189142968};\\\", \\\"{x:532,y:620,t:1527189142986};\\\", \\\"{x:548,y:605,t:1527189143001};\\\", \\\"{x:565,y:593,t:1527189143018};\\\", \\\"{x:584,y:579,t:1527189143036};\\\", \\\"{x:603,y:563,t:1527189143052};\\\", \\\"{x:626,y:548,t:1527189143069};\\\", \\\"{x:660,y:521,t:1527189143086};\\\", \\\"{x:676,y:503,t:1527189143102};\\\", \\\"{x:694,y:489,t:1527189143119};\\\", \\\"{x:711,y:477,t:1527189143135};\\\", \\\"{x:723,y:467,t:1527189143152};\\\", \\\"{x:737,y:454,t:1527189143169};\\\", \\\"{x:751,y:444,t:1527189143185};\\\", \\\"{x:760,y:435,t:1527189143203};\\\", \\\"{x:767,y:425,t:1527189143219};\\\", \\\"{x:773,y:417,t:1527189143236};\\\", \\\"{x:783,y:410,t:1527189143253};\\\", \\\"{x:787,y:406,t:1527189143268};\\\", \\\"{x:788,y:406,t:1527189143302};\\\", \\\"{x:787,y:406,t:1527189143502};\\\", \\\"{x:783,y:407,t:1527189143519};\\\", \\\"{x:781,y:408,t:1527189143536};\\\", \\\"{x:778,y:409,t:1527189143552};\\\", \\\"{x:777,y:410,t:1527189143570};\\\", \\\"{x:776,y:411,t:1527189143586};\\\", \\\"{x:775,y:411,t:1527189143603};\\\" ] }, { \\\"rt\\\": 8690, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 536321, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:774,y:412,t:1527189144589};\\\", \\\"{x:774,y:413,t:1527189145591};\\\", \\\"{x:774,y:422,t:1527189145604};\\\", \\\"{x:774,y:438,t:1527189145622};\\\", \\\"{x:771,y:470,t:1527189145638};\\\", \\\"{x:772,y:494,t:1527189145655};\\\", \\\"{x:785,y:535,t:1527189145671};\\\", \\\"{x:822,y:596,t:1527189145688};\\\", \\\"{x:871,y:663,t:1527189145703};\\\", \\\"{x:923,y:736,t:1527189145720};\\\", \\\"{x:961,y:801,t:1527189145738};\\\", \\\"{x:1001,y:867,t:1527189145755};\\\", \\\"{x:1047,y:931,t:1527189145771};\\\", \\\"{x:1088,y:981,t:1527189145788};\\\", \\\"{x:1131,y:1008,t:1527189145805};\\\", \\\"{x:1155,y:1021,t:1527189145821};\\\", \\\"{x:1184,y:1024,t:1527189145837};\\\", \\\"{x:1199,y:1022,t:1527189145855};\\\", \\\"{x:1214,y:1013,t:1527189145871};\\\", \\\"{x:1229,y:1002,t:1527189145888};\\\", \\\"{x:1244,y:991,t:1527189145906};\\\", \\\"{x:1258,y:979,t:1527189145921};\\\", \\\"{x:1272,y:968,t:1527189145938};\\\", \\\"{x:1286,y:955,t:1527189145955};\\\", \\\"{x:1298,y:949,t:1527189145971};\\\", \\\"{x:1309,y:944,t:1527189145987};\\\", \\\"{x:1317,y:939,t:1527189146005};\\\", \\\"{x:1324,y:935,t:1527189146021};\\\", \\\"{x:1331,y:931,t:1527189146038};\\\", \\\"{x:1334,y:928,t:1527189146055};\\\", \\\"{x:1335,y:928,t:1527189146093};\\\", \\\"{x:1337,y:927,t:1527189146104};\\\", \\\"{x:1343,y:926,t:1527189146121};\\\", \\\"{x:1348,y:925,t:1527189146138};\\\", \\\"{x:1353,y:925,t:1527189146155};\\\", \\\"{x:1357,y:923,t:1527189146171};\\\", \\\"{x:1358,y:923,t:1527189146188};\\\", \\\"{x:1359,y:923,t:1527189146222};\\\", \\\"{x:1359,y:922,t:1527189146238};\\\", \\\"{x:1359,y:921,t:1527189146255};\\\", \\\"{x:1359,y:920,t:1527189146334};\\\", \\\"{x:1359,y:919,t:1527189146366};\\\", \\\"{x:1359,y:918,t:1527189146447};\\\", \\\"{x:1356,y:917,t:1527189146455};\\\", \\\"{x:1353,y:917,t:1527189146472};\\\", \\\"{x:1352,y:916,t:1527189146488};\\\", \\\"{x:1351,y:916,t:1527189146518};\\\", \\\"{x:1350,y:916,t:1527189146574};\\\", \\\"{x:1349,y:915,t:1527189146679};\\\", \\\"{x:1348,y:914,t:1527189146703};\\\", \\\"{x:1347,y:913,t:1527189146718};\\\", \\\"{x:1347,y:912,t:1527189146982};\\\", \\\"{x:1347,y:911,t:1527189146997};\\\", \\\"{x:1347,y:909,t:1527189147013};\\\", \\\"{x:1347,y:908,t:1527189147022};\\\", \\\"{x:1347,y:906,t:1527189147039};\\\", \\\"{x:1347,y:904,t:1527189147055};\\\", \\\"{x:1347,y:902,t:1527189147072};\\\", \\\"{x:1347,y:900,t:1527189147089};\\\", \\\"{x:1347,y:899,t:1527189147110};\\\", \\\"{x:1347,y:898,t:1527189147126};\\\", \\\"{x:1347,y:897,t:1527189147150};\\\", \\\"{x:1347,y:896,t:1527189147167};\\\", \\\"{x:1347,y:895,t:1527189147246};\\\", \\\"{x:1347,y:894,t:1527189147262};\\\", \\\"{x:1348,y:892,t:1527189147273};\\\", \\\"{x:1348,y:890,t:1527189147302};\\\", \\\"{x:1348,y:889,t:1527189147311};\\\", \\\"{x:1348,y:887,t:1527189147323};\\\", \\\"{x:1348,y:883,t:1527189147339};\\\", \\\"{x:1348,y:876,t:1527189147356};\\\", \\\"{x:1349,y:867,t:1527189147373};\\\", \\\"{x:1350,y:855,t:1527189147389};\\\", \\\"{x:1350,y:835,t:1527189147406};\\\", \\\"{x:1350,y:823,t:1527189147422};\\\", \\\"{x:1353,y:815,t:1527189147439};\\\", \\\"{x:1353,y:809,t:1527189147456};\\\", \\\"{x:1352,y:805,t:1527189147473};\\\", \\\"{x:1352,y:800,t:1527189147489};\\\", \\\"{x:1352,y:796,t:1527189147507};\\\", \\\"{x:1352,y:793,t:1527189147523};\\\", \\\"{x:1352,y:791,t:1527189147540};\\\", \\\"{x:1352,y:788,t:1527189147557};\\\", \\\"{x:1352,y:784,t:1527189147573};\\\", \\\"{x:1352,y:779,t:1527189147590};\\\", \\\"{x:1352,y:769,t:1527189147607};\\\", \\\"{x:1352,y:761,t:1527189147624};\\\", \\\"{x:1352,y:753,t:1527189147640};\\\", \\\"{x:1353,y:746,t:1527189147657};\\\", \\\"{x:1353,y:742,t:1527189147674};\\\", \\\"{x:1353,y:739,t:1527189147689};\\\", \\\"{x:1353,y:738,t:1527189147707};\\\", \\\"{x:1354,y:735,t:1527189147724};\\\", \\\"{x:1354,y:734,t:1527189147742};\\\", \\\"{x:1354,y:732,t:1527189147758};\\\", \\\"{x:1354,y:731,t:1527189147839};\\\", \\\"{x:1354,y:729,t:1527189147857};\\\", \\\"{x:1354,y:728,t:1527189147873};\\\", \\\"{x:1353,y:725,t:1527189147890};\\\", \\\"{x:1352,y:719,t:1527189147907};\\\", \\\"{x:1350,y:716,t:1527189147923};\\\", \\\"{x:1346,y:710,t:1527189147942};\\\", \\\"{x:1344,y:705,t:1527189147956};\\\", \\\"{x:1343,y:703,t:1527189147973};\\\", \\\"{x:1341,y:700,t:1527189147989};\\\", \\\"{x:1341,y:699,t:1527189148005};\\\", \\\"{x:1341,y:698,t:1527189148029};\\\", \\\"{x:1341,y:697,t:1527189148062};\\\", \\\"{x:1340,y:697,t:1527189148073};\\\", \\\"{x:1340,y:696,t:1527189148089};\\\", \\\"{x:1339,y:693,t:1527189148106};\\\", \\\"{x:1339,y:689,t:1527189148123};\\\", \\\"{x:1339,y:686,t:1527189148140};\\\", \\\"{x:1339,y:680,t:1527189148156};\\\", \\\"{x:1339,y:672,t:1527189148173};\\\", \\\"{x:1339,y:663,t:1527189148190};\\\", \\\"{x:1339,y:657,t:1527189148206};\\\", \\\"{x:1339,y:653,t:1527189148224};\\\", \\\"{x:1339,y:649,t:1527189148241};\\\", \\\"{x:1339,y:646,t:1527189148256};\\\", \\\"{x:1339,y:645,t:1527189148273};\\\", \\\"{x:1339,y:642,t:1527189148290};\\\", \\\"{x:1339,y:641,t:1527189148306};\\\", \\\"{x:1339,y:639,t:1527189148323};\\\", \\\"{x:1339,y:638,t:1527189148350};\\\", \\\"{x:1339,y:637,t:1527189148382};\\\", \\\"{x:1339,y:636,t:1527189148407};\\\", \\\"{x:1339,y:635,t:1527189148438};\\\", \\\"{x:1339,y:634,t:1527189148454};\\\", \\\"{x:1339,y:633,t:1527189148471};\\\", \\\"{x:1339,y:632,t:1527189148487};\\\", \\\"{x:1339,y:631,t:1527189148495};\\\", \\\"{x:1339,y:630,t:1527189148507};\\\", \\\"{x:1339,y:629,t:1527189148523};\\\", \\\"{x:1339,y:627,t:1527189148541};\\\", \\\"{x:1340,y:624,t:1527189148558};\\\", \\\"{x:1340,y:621,t:1527189148574};\\\", \\\"{x:1341,y:618,t:1527189148590};\\\", \\\"{x:1341,y:617,t:1527189148606};\\\", \\\"{x:1341,y:615,t:1527189148623};\\\", \\\"{x:1341,y:613,t:1527189148641};\\\", \\\"{x:1341,y:612,t:1527189148657};\\\", \\\"{x:1341,y:609,t:1527189148674};\\\", \\\"{x:1342,y:607,t:1527189148690};\\\", \\\"{x:1343,y:605,t:1527189148708};\\\", \\\"{x:1343,y:602,t:1527189148723};\\\", \\\"{x:1343,y:597,t:1527189148741};\\\", \\\"{x:1343,y:592,t:1527189148758};\\\", \\\"{x:1345,y:581,t:1527189148774};\\\", \\\"{x:1346,y:572,t:1527189148790};\\\", \\\"{x:1347,y:564,t:1527189148808};\\\", \\\"{x:1347,y:557,t:1527189148824};\\\", \\\"{x:1347,y:552,t:1527189148841};\\\", \\\"{x:1347,y:546,t:1527189148859};\\\", \\\"{x:1347,y:542,t:1527189148874};\\\", \\\"{x:1347,y:538,t:1527189148890};\\\", \\\"{x:1347,y:535,t:1527189148907};\\\", \\\"{x:1347,y:532,t:1527189148923};\\\", \\\"{x:1347,y:528,t:1527189148941};\\\", \\\"{x:1347,y:524,t:1527189148958};\\\", \\\"{x:1347,y:520,t:1527189148974};\\\", \\\"{x:1347,y:512,t:1527189148991};\\\", \\\"{x:1346,y:508,t:1527189149007};\\\", \\\"{x:1344,y:503,t:1527189149024};\\\", \\\"{x:1343,y:501,t:1527189149040};\\\", \\\"{x:1339,y:500,t:1527189149059};\\\", \\\"{x:1327,y:495,t:1527189149074};\\\", \\\"{x:1316,y:492,t:1527189149090};\\\", \\\"{x:1295,y:490,t:1527189149108};\\\", \\\"{x:1266,y:488,t:1527189149124};\\\", \\\"{x:1211,y:491,t:1527189149141};\\\", \\\"{x:1060,y:515,t:1527189149158};\\\", \\\"{x:935,y:529,t:1527189149175};\\\", \\\"{x:810,y:550,t:1527189149191};\\\", \\\"{x:690,y:556,t:1527189149207};\\\", \\\"{x:576,y:556,t:1527189149224};\\\", \\\"{x:475,y:552,t:1527189149241};\\\", \\\"{x:410,y:529,t:1527189149258};\\\", \\\"{x:378,y:514,t:1527189149274};\\\", \\\"{x:372,y:509,t:1527189149291};\\\", \\\"{x:372,y:499,t:1527189149309};\\\", \\\"{x:372,y:493,t:1527189149323};\\\", \\\"{x:373,y:485,t:1527189149341};\\\", \\\"{x:376,y:482,t:1527189149356};\\\", \\\"{x:391,y:475,t:1527189149374};\\\", \\\"{x:403,y:470,t:1527189149392};\\\", \\\"{x:420,y:465,t:1527189149407};\\\", \\\"{x:434,y:461,t:1527189149424};\\\", \\\"{x:447,y:460,t:1527189149441};\\\", \\\"{x:462,y:460,t:1527189149457};\\\", \\\"{x:479,y:460,t:1527189149474};\\\", \\\"{x:501,y:462,t:1527189149493};\\\", \\\"{x:520,y:462,t:1527189149508};\\\", \\\"{x:536,y:463,t:1527189149524};\\\", \\\"{x:552,y:464,t:1527189149541};\\\", \\\"{x:567,y:467,t:1527189149558};\\\", \\\"{x:588,y:469,t:1527189149574};\\\", \\\"{x:595,y:470,t:1527189149591};\\\", \\\"{x:596,y:470,t:1527189149629};\\\", \\\"{x:594,y:469,t:1527189149641};\\\", \\\"{x:588,y:467,t:1527189149658};\\\", \\\"{x:587,y:466,t:1527189149674};\\\", \\\"{x:590,y:466,t:1527189149742};\\\", \\\"{x:604,y:472,t:1527189149760};\\\", \\\"{x:620,y:481,t:1527189149775};\\\", \\\"{x:639,y:491,t:1527189149791};\\\", \\\"{x:652,y:499,t:1527189149808};\\\", \\\"{x:664,y:506,t:1527189149824};\\\", \\\"{x:668,y:509,t:1527189149841};\\\", \\\"{x:669,y:509,t:1527189149857};\\\", \\\"{x:669,y:510,t:1527189149926};\\\", \\\"{x:671,y:510,t:1527189149941};\\\", \\\"{x:691,y:500,t:1527189149958};\\\", \\\"{x:717,y:494,t:1527189149974};\\\", \\\"{x:750,y:489,t:1527189149991};\\\", \\\"{x:789,y:485,t:1527189150008};\\\", \\\"{x:814,y:481,t:1527189150025};\\\", \\\"{x:828,y:479,t:1527189150041};\\\", \\\"{x:833,y:478,t:1527189150058};\\\", \\\"{x:834,y:478,t:1527189150109};\\\", \\\"{x:835,y:477,t:1527189150134};\\\", \\\"{x:836,y:476,t:1527189150189};\\\", \\\"{x:834,y:475,t:1527189150213};\\\", \\\"{x:833,y:474,t:1527189150225};\\\", \\\"{x:832,y:472,t:1527189150245};\\\", \\\"{x:831,y:471,t:1527189150263};\\\", \\\"{x:831,y:470,t:1527189150275};\\\", \\\"{x:831,y:467,t:1527189150291};\\\", \\\"{x:831,y:466,t:1527189150308};\\\", \\\"{x:831,y:465,t:1527189150325};\\\", \\\"{x:831,y:464,t:1527189150341};\\\", \\\"{x:831,y:463,t:1527189150357};\\\", \\\"{x:831,y:462,t:1527189150453};\\\", \\\"{x:831,y:461,t:1527189150461};\\\", \\\"{x:831,y:460,t:1527189150511};\\\", \\\"{x:831,y:459,t:1527189150605};\\\", \\\"{x:826,y:457,t:1527189150813};\\\", \\\"{x:817,y:457,t:1527189150825};\\\", \\\"{x:796,y:457,t:1527189150842};\\\", \\\"{x:772,y:457,t:1527189150859};\\\", \\\"{x:749,y:466,t:1527189150875};\\\", \\\"{x:720,y:474,t:1527189150893};\\\", \\\"{x:681,y:486,t:1527189150909};\\\", \\\"{x:625,y:502,t:1527189150924};\\\", \\\"{x:506,y:533,t:1527189150943};\\\", \\\"{x:428,y:557,t:1527189150960};\\\", \\\"{x:364,y:577,t:1527189150974};\\\", \\\"{x:310,y:586,t:1527189150992};\\\", \\\"{x:271,y:592,t:1527189151010};\\\", \\\"{x:240,y:596,t:1527189151025};\\\", \\\"{x:214,y:596,t:1527189151042};\\\", \\\"{x:190,y:596,t:1527189151059};\\\", \\\"{x:172,y:596,t:1527189151075};\\\", \\\"{x:165,y:596,t:1527189151092};\\\", \\\"{x:160,y:596,t:1527189151108};\\\", \\\"{x:156,y:596,t:1527189151125};\\\", \\\"{x:155,y:596,t:1527189151149};\\\", \\\"{x:154,y:593,t:1527189151206};\\\", \\\"{x:155,y:590,t:1527189151214};\\\", \\\"{x:157,y:585,t:1527189151227};\\\", \\\"{x:162,y:574,t:1527189151243};\\\", \\\"{x:163,y:568,t:1527189151259};\\\", \\\"{x:163,y:559,t:1527189151276};\\\", \\\"{x:163,y:551,t:1527189151292};\\\", \\\"{x:162,y:540,t:1527189151309};\\\", \\\"{x:147,y:522,t:1527189151325};\\\", \\\"{x:142,y:516,t:1527189151342};\\\", \\\"{x:140,y:513,t:1527189151358};\\\", \\\"{x:140,y:512,t:1527189151375};\\\", \\\"{x:143,y:511,t:1527189151392};\\\", \\\"{x:144,y:509,t:1527189151410};\\\", \\\"{x:146,y:508,t:1527189151425};\\\", \\\"{x:147,y:505,t:1527189151442};\\\", \\\"{x:147,y:504,t:1527189151469};\\\", \\\"{x:147,y:503,t:1527189151478};\\\", \\\"{x:147,y:502,t:1527189151504};\\\", \\\"{x:147,y:501,t:1527189151541};\\\", \\\"{x:149,y:499,t:1527189151557};\\\", \\\"{x:150,y:499,t:1527189151565};\\\", \\\"{x:151,y:498,t:1527189151576};\\\", \\\"{x:153,y:497,t:1527189151593};\\\", \\\"{x:154,y:497,t:1527189151653};\\\", \\\"{x:154,y:496,t:1527189151702};\\\", \\\"{x:154,y:495,t:1527189151733};\\\", \\\"{x:155,y:494,t:1527189151742};\\\", \\\"{x:160,y:494,t:1527189151949};\\\", \\\"{x:166,y:497,t:1527189151959};\\\", \\\"{x:178,y:503,t:1527189151977};\\\", \\\"{x:194,y:510,t:1527189151993};\\\", \\\"{x:223,y:536,t:1527189152009};\\\", \\\"{x:251,y:564,t:1527189152027};\\\", \\\"{x:286,y:592,t:1527189152043};\\\", \\\"{x:330,y:620,t:1527189152061};\\\", \\\"{x:366,y:637,t:1527189152076};\\\", \\\"{x:388,y:648,t:1527189152093};\\\", \\\"{x:420,y:662,t:1527189152110};\\\", \\\"{x:434,y:668,t:1527189152126};\\\", \\\"{x:441,y:670,t:1527189152143};\\\", \\\"{x:443,y:670,t:1527189152159};\\\", \\\"{x:444,y:670,t:1527189152238};\\\", \\\"{x:445,y:670,t:1527189152270};\\\", \\\"{x:447,y:670,t:1527189152279};\\\", \\\"{x:454,y:670,t:1527189152293};\\\", \\\"{x:459,y:672,t:1527189152310};\\\", \\\"{x:462,y:673,t:1527189152326};\\\", \\\"{x:463,y:674,t:1527189152343};\\\", \\\"{x:464,y:674,t:1527189152360};\\\", \\\"{x:465,y:674,t:1527189152405};\\\", \\\"{x:467,y:675,t:1527189152413};\\\", \\\"{x:468,y:675,t:1527189152427};\\\", \\\"{x:472,y:676,t:1527189152443};\\\", \\\"{x:476,y:676,t:1527189152460};\\\", \\\"{x:478,y:677,t:1527189152476};\\\", \\\"{x:479,y:677,t:1527189152493};\\\", \\\"{x:479,y:676,t:1527189153639};\\\", \\\"{x:479,y:675,t:1527189153646};\\\", \\\"{x:481,y:673,t:1527189153661};\\\", \\\"{x:488,y:667,t:1527189153677};\\\", \\\"{x:497,y:655,t:1527189153706};\\\", \\\"{x:499,y:654,t:1527189153710};\\\", \\\"{x:505,y:645,t:1527189153727};\\\", \\\"{x:511,y:641,t:1527189153744};\\\", \\\"{x:518,y:637,t:1527189153760};\\\", \\\"{x:528,y:634,t:1527189153777};\\\" ] }, { \\\"rt\\\": 7969, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 545510, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B -F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:665,y:612,t:1527189153897};\\\", \\\"{x:679,y:604,t:1527189153911};\\\", \\\"{x:685,y:601,t:1527189153928};\\\", \\\"{x:691,y:597,t:1527189153944};\\\", \\\"{x:697,y:594,t:1527189153961};\\\", \\\"{x:706,y:590,t:1527189153989};\\\", \\\"{x:712,y:588,t:1527189153995};\\\", \\\"{x:727,y:581,t:1527189154011};\\\", \\\"{x:741,y:576,t:1527189154029};\\\", \\\"{x:758,y:567,t:1527189154045};\\\", \\\"{x:766,y:564,t:1527189154061};\\\", \\\"{x:767,y:563,t:1527189154078};\\\", \\\"{x:769,y:562,t:1527189154094};\\\", \\\"{x:770,y:561,t:1527189154141};\\\", \\\"{x:771,y:560,t:1527189154173};\\\", \\\"{x:772,y:560,t:1527189154222};\\\", \\\"{x:769,y:560,t:1527189154830};\\\", \\\"{x:768,y:560,t:1527189154845};\\\", \\\"{x:767,y:561,t:1527189154862};\\\", \\\"{x:766,y:561,t:1527189154886};\\\", \\\"{x:765,y:562,t:1527189155094};\\\", \\\"{x:764,y:562,t:1527189155102};\\\", \\\"{x:763,y:562,t:1527189155150};\\\", \\\"{x:763,y:563,t:1527189155415};\\\", \\\"{x:763,y:566,t:1527189155429};\\\", \\\"{x:765,y:572,t:1527189155445};\\\", \\\"{x:768,y:576,t:1527189155463};\\\", \\\"{x:773,y:582,t:1527189155481};\\\", \\\"{x:778,y:587,t:1527189155495};\\\", \\\"{x:792,y:597,t:1527189155512};\\\", \\\"{x:819,y:611,t:1527189155529};\\\", \\\"{x:864,y:633,t:1527189155546};\\\", \\\"{x:925,y:659,t:1527189155562};\\\", \\\"{x:984,y:679,t:1527189155579};\\\", \\\"{x:1065,y:704,t:1527189155596};\\\", \\\"{x:1148,y:728,t:1527189155612};\\\", \\\"{x:1247,y:764,t:1527189155629};\\\", \\\"{x:1307,y:786,t:1527189155646};\\\", \\\"{x:1350,y:801,t:1527189155662};\\\", \\\"{x:1376,y:809,t:1527189155680};\\\", \\\"{x:1396,y:817,t:1527189155696};\\\", \\\"{x:1408,y:819,t:1527189155712};\\\", \\\"{x:1413,y:820,t:1527189155729};\\\", \\\"{x:1414,y:820,t:1527189155790};\\\", \\\"{x:1415,y:820,t:1527189155797};\\\", \\\"{x:1416,y:820,t:1527189155903};\\\", \\\"{x:1417,y:822,t:1527189155919};\\\", \\\"{x:1418,y:824,t:1527189155930};\\\", \\\"{x:1418,y:829,t:1527189155947};\\\", \\\"{x:1418,y:832,t:1527189155964};\\\", \\\"{x:1418,y:833,t:1527189155979};\\\", \\\"{x:1418,y:834,t:1527189156071};\\\", \\\"{x:1418,y:836,t:1527189156080};\\\", \\\"{x:1415,y:836,t:1527189156097};\\\", \\\"{x:1409,y:836,t:1527189156114};\\\", \\\"{x:1397,y:834,t:1527189156130};\\\", \\\"{x:1385,y:829,t:1527189156147};\\\", \\\"{x:1369,y:823,t:1527189156169};\\\", \\\"{x:1356,y:813,t:1527189156184};\\\", \\\"{x:1350,y:807,t:1527189156200};\\\", \\\"{x:1350,y:792,t:1527189156217};\\\", \\\"{x:1350,y:773,t:1527189156234};\\\", \\\"{x:1350,y:755,t:1527189156251};\\\", \\\"{x:1350,y:739,t:1527189156267};\\\", \\\"{x:1350,y:719,t:1527189156284};\\\", \\\"{x:1345,y:701,t:1527189156300};\\\", \\\"{x:1342,y:686,t:1527189156318};\\\", \\\"{x:1339,y:677,t:1527189156334};\\\", \\\"{x:1339,y:671,t:1527189156351};\\\", \\\"{x:1339,y:666,t:1527189156368};\\\", \\\"{x:1339,y:660,t:1527189156384};\\\", \\\"{x:1339,y:654,t:1527189156401};\\\", \\\"{x:1335,y:644,t:1527189156418};\\\", \\\"{x:1330,y:637,t:1527189156434};\\\", \\\"{x:1329,y:636,t:1527189156451};\\\", \\\"{x:1329,y:635,t:1527189156490};\\\", \\\"{x:1330,y:634,t:1527189156501};\\\", \\\"{x:1331,y:634,t:1527189156517};\\\", \\\"{x:1332,y:633,t:1527189156534};\\\", \\\"{x:1333,y:633,t:1527189156562};\\\", \\\"{x:1335,y:631,t:1527189156586};\\\", \\\"{x:1336,y:631,t:1527189156619};\\\", \\\"{x:1338,y:630,t:1527189156634};\\\", \\\"{x:1340,y:630,t:1527189156651};\\\", \\\"{x:1342,y:628,t:1527189156668};\\\", \\\"{x:1344,y:628,t:1527189156685};\\\", \\\"{x:1346,y:627,t:1527189156700};\\\", \\\"{x:1347,y:626,t:1527189156717};\\\", \\\"{x:1349,y:626,t:1527189156930};\\\", \\\"{x:1350,y:626,t:1527189156954};\\\", \\\"{x:1350,y:628,t:1527189156970};\\\", \\\"{x:1350,y:630,t:1527189156984};\\\", \\\"{x:1350,y:636,t:1527189157002};\\\", \\\"{x:1350,y:639,t:1527189157020};\\\", \\\"{x:1350,y:644,t:1527189157034};\\\", \\\"{x:1350,y:645,t:1527189157051};\\\", \\\"{x:1350,y:647,t:1527189157067};\\\", \\\"{x:1350,y:648,t:1527189157084};\\\", \\\"{x:1350,y:651,t:1527189157101};\\\", \\\"{x:1350,y:652,t:1527189157117};\\\", \\\"{x:1350,y:656,t:1527189157134};\\\", \\\"{x:1350,y:658,t:1527189157151};\\\", \\\"{x:1350,y:663,t:1527189157167};\\\", \\\"{x:1350,y:668,t:1527189157184};\\\", \\\"{x:1350,y:675,t:1527189157201};\\\", \\\"{x:1350,y:680,t:1527189157217};\\\", \\\"{x:1350,y:683,t:1527189157234};\\\", \\\"{x:1349,y:689,t:1527189157251};\\\", \\\"{x:1348,y:695,t:1527189157268};\\\", \\\"{x:1348,y:696,t:1527189157284};\\\", \\\"{x:1348,y:698,t:1527189157302};\\\", \\\"{x:1347,y:700,t:1527189157318};\\\", \\\"{x:1347,y:701,t:1527189157334};\\\", \\\"{x:1347,y:705,t:1527189157352};\\\", \\\"{x:1346,y:706,t:1527189157368};\\\", \\\"{x:1346,y:708,t:1527189157384};\\\", \\\"{x:1346,y:711,t:1527189157401};\\\", \\\"{x:1345,y:714,t:1527189157417};\\\", \\\"{x:1343,y:717,t:1527189157436};\\\", \\\"{x:1343,y:720,t:1527189157452};\\\", \\\"{x:1342,y:723,t:1527189157469};\\\", \\\"{x:1341,y:726,t:1527189157485};\\\", \\\"{x:1341,y:728,t:1527189157501};\\\", \\\"{x:1341,y:729,t:1527189157517};\\\", \\\"{x:1334,y:729,t:1527189157978};\\\", \\\"{x:1321,y:729,t:1527189157985};\\\", \\\"{x:1248,y:736,t:1527189158001};\\\", \\\"{x:1151,y:738,t:1527189158018};\\\", \\\"{x:1029,y:738,t:1527189158035};\\\", \\\"{x:893,y:738,t:1527189158052};\\\", \\\"{x:775,y:731,t:1527189158068};\\\", \\\"{x:674,y:707,t:1527189158085};\\\", \\\"{x:589,y:676,t:1527189158102};\\\", \\\"{x:539,y:652,t:1527189158118};\\\", \\\"{x:510,y:635,t:1527189158135};\\\", \\\"{x:501,y:627,t:1527189158153};\\\", \\\"{x:499,y:620,t:1527189158168};\\\", \\\"{x:499,y:611,t:1527189158187};\\\", \\\"{x:500,y:601,t:1527189158203};\\\", \\\"{x:500,y:584,t:1527189158235};\\\", \\\"{x:500,y:578,t:1527189158252};\\\", \\\"{x:499,y:572,t:1527189158268};\\\", \\\"{x:495,y:565,t:1527189158286};\\\", \\\"{x:482,y:556,t:1527189158302};\\\", \\\"{x:464,y:546,t:1527189158318};\\\", \\\"{x:442,y:534,t:1527189158335};\\\", \\\"{x:422,y:525,t:1527189158352};\\\", \\\"{x:406,y:512,t:1527189158368};\\\", \\\"{x:384,y:497,t:1527189158385};\\\", \\\"{x:373,y:489,t:1527189158401};\\\", \\\"{x:359,y:484,t:1527189158418};\\\", \\\"{x:348,y:479,t:1527189158435};\\\", \\\"{x:342,y:476,t:1527189158452};\\\", \\\"{x:339,y:475,t:1527189158469};\\\", \\\"{x:337,y:474,t:1527189158485};\\\", \\\"{x:336,y:473,t:1527189158502};\\\", \\\"{x:335,y:473,t:1527189158519};\\\", \\\"{x:333,y:472,t:1527189158535};\\\", \\\"{x:332,y:472,t:1527189158552};\\\", \\\"{x:328,y:470,t:1527189158570};\\\", \\\"{x:322,y:469,t:1527189158586};\\\", \\\"{x:312,y:469,t:1527189158602};\\\", \\\"{x:297,y:469,t:1527189158619};\\\", \\\"{x:282,y:469,t:1527189158636};\\\", \\\"{x:264,y:469,t:1527189158651};\\\", \\\"{x:245,y:469,t:1527189158669};\\\", \\\"{x:227,y:470,t:1527189158686};\\\", \\\"{x:205,y:475,t:1527189158702};\\\", \\\"{x:185,y:481,t:1527189158719};\\\", \\\"{x:164,y:487,t:1527189158735};\\\", \\\"{x:149,y:495,t:1527189158751};\\\", \\\"{x:138,y:505,t:1527189158769};\\\", \\\"{x:137,y:507,t:1527189158786};\\\", \\\"{x:137,y:508,t:1527189158801};\\\", \\\"{x:136,y:509,t:1527189158819};\\\", \\\"{x:136,y:510,t:1527189158836};\\\", \\\"{x:135,y:511,t:1527189158852};\\\", \\\"{x:134,y:512,t:1527189158869};\\\", \\\"{x:134,y:521,t:1527189158886};\\\", \\\"{x:134,y:537,t:1527189158902};\\\", \\\"{x:134,y:551,t:1527189158920};\\\", \\\"{x:137,y:563,t:1527189158936};\\\", \\\"{x:139,y:569,t:1527189158952};\\\", \\\"{x:141,y:574,t:1527189158968};\\\", \\\"{x:143,y:576,t:1527189158986};\\\", \\\"{x:143,y:578,t:1527189159002};\\\", \\\"{x:143,y:579,t:1527189159019};\\\", \\\"{x:143,y:580,t:1527189159036};\\\", \\\"{x:145,y:579,t:1527189159090};\\\", \\\"{x:147,y:574,t:1527189159103};\\\", \\\"{x:152,y:564,t:1527189159120};\\\", \\\"{x:158,y:553,t:1527189159136};\\\", \\\"{x:166,y:530,t:1527189159153};\\\", \\\"{x:168,y:524,t:1527189159168};\\\", \\\"{x:170,y:517,t:1527189159187};\\\", \\\"{x:170,y:516,t:1527189159202};\\\", \\\"{x:170,y:515,t:1527189159219};\\\", \\\"{x:170,y:514,t:1527189159236};\\\", \\\"{x:170,y:513,t:1527189159257};\\\", \\\"{x:170,y:511,t:1527189159269};\\\", \\\"{x:168,y:510,t:1527189159286};\\\", \\\"{x:164,y:508,t:1527189159304};\\\", \\\"{x:162,y:506,t:1527189159319};\\\", \\\"{x:159,y:503,t:1527189159336};\\\", \\\"{x:155,y:496,t:1527189159354};\\\", \\\"{x:153,y:493,t:1527189159369};\\\", \\\"{x:151,y:491,t:1527189159386};\\\", \\\"{x:150,y:489,t:1527189159404};\\\", \\\"{x:149,y:488,t:1527189159419};\\\", \\\"{x:149,y:487,t:1527189159436};\\\", \\\"{x:148,y:486,t:1527189159453};\\\", \\\"{x:147,y:485,t:1527189159470};\\\", \\\"{x:147,y:483,t:1527189159486};\\\", \\\"{x:150,y:483,t:1527189159771};\\\", \\\"{x:157,y:486,t:1527189159785};\\\", \\\"{x:165,y:489,t:1527189159803};\\\", \\\"{x:175,y:495,t:1527189159821};\\\", \\\"{x:197,y:511,t:1527189159836};\\\", \\\"{x:226,y:533,t:1527189159853};\\\", \\\"{x:275,y:571,t:1527189159871};\\\", \\\"{x:332,y:614,t:1527189159887};\\\", \\\"{x:389,y:647,t:1527189159903};\\\", \\\"{x:437,y:671,t:1527189159920};\\\", \\\"{x:470,y:685,t:1527189159936};\\\", \\\"{x:497,y:695,t:1527189159952};\\\", \\\"{x:504,y:696,t:1527189159970};\\\", \\\"{x:506,y:696,t:1527189159987};\\\", \\\"{x:507,y:696,t:1527189160033};\\\", \\\"{x:504,y:695,t:1527189160154};\\\", \\\"{x:482,y:683,t:1527189160170};\\\", \\\"{x:441,y:659,t:1527189160189};\\\", \\\"{x:398,y:627,t:1527189160204};\\\", \\\"{x:334,y:583,t:1527189160220};\\\", \\\"{x:300,y:558,t:1527189160237};\\\", \\\"{x:277,y:538,t:1527189160254};\\\", \\\"{x:269,y:528,t:1527189160271};\\\", \\\"{x:266,y:523,t:1527189160286};\\\", \\\"{x:265,y:522,t:1527189160426};\\\", \\\"{x:264,y:522,t:1527189160437};\\\", \\\"{x:253,y:522,t:1527189160454};\\\", \\\"{x:234,y:522,t:1527189160470};\\\", \\\"{x:210,y:522,t:1527189160487};\\\", \\\"{x:190,y:518,t:1527189160506};\\\", \\\"{x:182,y:514,t:1527189160520};\\\", \\\"{x:181,y:514,t:1527189160537};\\\", \\\"{x:181,y:512,t:1527189160561};\\\", \\\"{x:181,y:511,t:1527189160593};\\\", \\\"{x:181,y:509,t:1527189160617};\\\", \\\"{x:181,y:508,t:1527189160633};\\\", \\\"{x:181,y:506,t:1527189160657};\\\", \\\"{x:181,y:505,t:1527189160670};\\\", \\\"{x:181,y:502,t:1527189160688};\\\", \\\"{x:175,y:499,t:1527189160704};\\\", \\\"{x:171,y:497,t:1527189160720};\\\", \\\"{x:164,y:494,t:1527189160738};\\\", \\\"{x:163,y:494,t:1527189160754};\\\", \\\"{x:162,y:493,t:1527189160770};\\\", \\\"{x:164,y:493,t:1527189161041};\\\", \\\"{x:165,y:493,t:1527189161054};\\\", \\\"{x:175,y:496,t:1527189161071};\\\", \\\"{x:182,y:500,t:1527189161087};\\\", \\\"{x:193,y:504,t:1527189161105};\\\", \\\"{x:230,y:523,t:1527189161121};\\\", \\\"{x:270,y:548,t:1527189161137};\\\", \\\"{x:311,y:579,t:1527189161154};\\\", \\\"{x:359,y:615,t:1527189161171};\\\", \\\"{x:401,y:643,t:1527189161187};\\\", \\\"{x:438,y:670,t:1527189161204};\\\", \\\"{x:474,y:691,t:1527189161221};\\\", \\\"{x:495,y:702,t:1527189161238};\\\", \\\"{x:504,y:706,t:1527189161254};\\\", \\\"{x:506,y:706,t:1527189161271};\\\", \\\"{x:507,y:706,t:1527189161386};\\\", \\\"{x:508,y:706,t:1527189161482};\\\", \\\"{x:508,y:704,t:1527189161505};\\\", \\\"{x:508,y:698,t:1527189161523};\\\", \\\"{x:508,y:693,t:1527189161538};\\\", \\\"{x:508,y:691,t:1527189161554};\\\", \\\"{x:508,y:688,t:1527189161571};\\\" ] }, { \\\"rt\\\": 61342, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 608057, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -04 PM-F -F -F -B -O -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:688,t:1527189171322};\\\", \\\"{x:567,y:689,t:1527189171350};\\\", \\\"{x:586,y:689,t:1527189171359};\\\", \\\"{x:639,y:689,t:1527189171375};\\\", \\\"{x:778,y:689,t:1527189171395};\\\", \\\"{x:927,y:689,t:1527189171412};\\\", \\\"{x:1099,y:689,t:1527189171430};\\\", \\\"{x:1286,y:672,t:1527189171445};\\\", \\\"{x:1482,y:645,t:1527189171463};\\\", \\\"{x:1659,y:622,t:1527189171480};\\\", \\\"{x:1899,y:583,t:1527189171497};\\\", \\\"{x:1919,y:562,t:1527189171513};\\\", \\\"{x:1919,y:541,t:1527189171529};\\\", \\\"{x:1919,y:538,t:1527189171546};\\\", \\\"{x:1919,y:537,t:1527189171577};\\\", \\\"{x:1918,y:535,t:1527189171585};\\\", \\\"{x:1909,y:533,t:1527189171597};\\\", \\\"{x:1896,y:527,t:1527189171614};\\\", \\\"{x:1888,y:523,t:1527189171630};\\\", \\\"{x:1883,y:522,t:1527189171646};\\\", \\\"{x:1882,y:522,t:1527189171663};\\\", \\\"{x:1881,y:522,t:1527189171681};\\\", \\\"{x:1880,y:522,t:1527189171697};\\\", \\\"{x:1878,y:522,t:1527189171713};\\\", \\\"{x:1873,y:522,t:1527189171730};\\\", \\\"{x:1867,y:523,t:1527189171747};\\\", \\\"{x:1849,y:530,t:1527189171763};\\\", \\\"{x:1826,y:537,t:1527189171780};\\\", \\\"{x:1794,y:548,t:1527189171797};\\\", \\\"{x:1753,y:559,t:1527189171813};\\\", \\\"{x:1716,y:570,t:1527189171830};\\\", \\\"{x:1683,y:579,t:1527189171847};\\\", \\\"{x:1665,y:583,t:1527189171864};\\\", \\\"{x:1651,y:585,t:1527189171880};\\\", \\\"{x:1644,y:586,t:1527189171897};\\\", \\\"{x:1643,y:587,t:1527189171914};\\\", \\\"{x:1642,y:588,t:1527189171938};\\\", \\\"{x:1642,y:589,t:1527189171947};\\\", \\\"{x:1640,y:590,t:1527189171964};\\\", \\\"{x:1639,y:591,t:1527189171981};\\\", \\\"{x:1638,y:592,t:1527189171997};\\\", \\\"{x:1636,y:594,t:1527189172015};\\\", \\\"{x:1632,y:601,t:1527189172030};\\\", \\\"{x:1628,y:607,t:1527189172047};\\\", \\\"{x:1624,y:613,t:1527189172064};\\\", \\\"{x:1620,y:618,t:1527189172080};\\\", \\\"{x:1616,y:623,t:1527189172097};\\\", \\\"{x:1615,y:626,t:1527189172114};\\\", \\\"{x:1613,y:628,t:1527189172131};\\\", \\\"{x:1611,y:631,t:1527189172147};\\\", \\\"{x:1610,y:632,t:1527189172169};\\\", \\\"{x:1610,y:633,t:1527189172181};\\\", \\\"{x:1609,y:634,t:1527189172202};\\\", \\\"{x:1608,y:635,t:1527189172218};\\\", \\\"{x:1607,y:636,t:1527189172234};\\\", \\\"{x:1606,y:637,t:1527189172249};\\\", \\\"{x:1606,y:638,t:1527189172265};\\\", \\\"{x:1606,y:639,t:1527189172281};\\\", \\\"{x:1605,y:639,t:1527189172298};\\\", \\\"{x:1604,y:641,t:1527189172386};\\\", \\\"{x:1604,y:642,t:1527189172488};\\\", \\\"{x:1604,y:643,t:1527189172521};\\\", \\\"{x:1604,y:644,t:1527189172537};\\\", \\\"{x:1605,y:644,t:1527189172610};\\\", \\\"{x:1605,y:645,t:1527189172617};\\\", \\\"{x:1606,y:645,t:1527189172641};\\\", \\\"{x:1607,y:645,t:1527189172657};\\\", \\\"{x:1608,y:646,t:1527189172666};\\\", \\\"{x:1609,y:646,t:1527189172683};\\\", \\\"{x:1610,y:646,t:1527189172698};\\\", \\\"{x:1611,y:648,t:1527189173626};\\\", \\\"{x:1613,y:648,t:1527189173633};\\\", \\\"{x:1615,y:649,t:1527189173650};\\\", \\\"{x:1614,y:649,t:1527189174025};\\\", \\\"{x:1613,y:649,t:1527189174032};\\\", \\\"{x:1612,y:648,t:1527189174065};\\\", \\\"{x:1612,y:647,t:1527189174088};\\\", \\\"{x:1612,y:646,t:1527189174112};\\\", \\\"{x:1610,y:646,t:1527189206482};\\\", \\\"{x:1610,y:645,t:1527189207418};\\\", \\\"{x:1610,y:644,t:1527189207429};\\\", \\\"{x:1610,y:642,t:1527189207446};\\\", \\\"{x:1611,y:641,t:1527189207463};\\\", \\\"{x:1612,y:640,t:1527189207479};\\\", \\\"{x:1613,y:640,t:1527189207496};\\\", \\\"{x:1615,y:639,t:1527189207513};\\\", \\\"{x:1617,y:639,t:1527189207529};\\\", \\\"{x:1619,y:638,t:1527189207548};\\\", \\\"{x:1620,y:638,t:1527189207563};\\\", \\\"{x:1620,y:640,t:1527189208153};\\\", \\\"{x:1619,y:643,t:1527189208164};\\\", \\\"{x:1614,y:654,t:1527189208182};\\\", \\\"{x:1614,y:662,t:1527189208197};\\\", \\\"{x:1609,y:676,t:1527189208214};\\\", \\\"{x:1608,y:691,t:1527189208231};\\\", \\\"{x:1608,y:703,t:1527189208248};\\\", \\\"{x:1608,y:717,t:1527189208263};\\\", \\\"{x:1608,y:740,t:1527189208281};\\\", \\\"{x:1608,y:758,t:1527189208297};\\\", \\\"{x:1608,y:780,t:1527189208314};\\\", \\\"{x:1608,y:800,t:1527189208331};\\\", \\\"{x:1608,y:823,t:1527189208347};\\\", \\\"{x:1607,y:848,t:1527189208364};\\\", \\\"{x:1607,y:860,t:1527189208381};\\\", \\\"{x:1607,y:869,t:1527189208398};\\\", \\\"{x:1607,y:876,t:1527189208413};\\\", \\\"{x:1607,y:878,t:1527189208431};\\\", \\\"{x:1607,y:882,t:1527189208447};\\\", \\\"{x:1609,y:888,t:1527189208464};\\\", \\\"{x:1610,y:896,t:1527189208481};\\\", \\\"{x:1611,y:901,t:1527189208497};\\\", \\\"{x:1613,y:903,t:1527189208513};\\\", \\\"{x:1613,y:906,t:1527189208531};\\\", \\\"{x:1613,y:908,t:1527189208553};\\\", \\\"{x:1613,y:910,t:1527189208565};\\\", \\\"{x:1614,y:915,t:1527189208581};\\\", \\\"{x:1615,y:918,t:1527189208598};\\\", \\\"{x:1615,y:920,t:1527189208614};\\\", \\\"{x:1616,y:921,t:1527189208631};\\\", \\\"{x:1612,y:916,t:1527189209169};\\\", \\\"{x:1599,y:902,t:1527189209183};\\\", \\\"{x:1553,y:864,t:1527189209198};\\\", \\\"{x:1478,y:802,t:1527189209215};\\\", \\\"{x:1404,y:739,t:1527189209232};\\\", \\\"{x:1348,y:685,t:1527189209248};\\\", \\\"{x:1312,y:642,t:1527189209265};\\\", \\\"{x:1309,y:630,t:1527189209281};\\\", \\\"{x:1309,y:627,t:1527189209299};\\\", \\\"{x:1309,y:625,t:1527189209315};\\\", \\\"{x:1312,y:623,t:1527189209332};\\\", \\\"{x:1314,y:623,t:1527189209377};\\\", \\\"{x:1315,y:623,t:1527189209393};\\\", \\\"{x:1318,y:623,t:1527189209400};\\\", \\\"{x:1320,y:623,t:1527189209414};\\\", \\\"{x:1323,y:624,t:1527189209431};\\\", \\\"{x:1331,y:628,t:1527189209449};\\\", \\\"{x:1337,y:629,t:1527189209465};\\\", \\\"{x:1339,y:631,t:1527189209482};\\\", \\\"{x:1342,y:632,t:1527189209499};\\\", \\\"{x:1342,y:635,t:1527189209570};\\\", \\\"{x:1343,y:635,t:1527189209582};\\\", \\\"{x:1345,y:639,t:1527189209599};\\\", \\\"{x:1345,y:641,t:1527189209615};\\\", \\\"{x:1342,y:642,t:1527189213418};\\\", \\\"{x:1332,y:642,t:1527189213425};\\\", \\\"{x:1313,y:643,t:1527189213435};\\\", \\\"{x:1254,y:643,t:1527189213452};\\\", \\\"{x:1177,y:637,t:1527189213469};\\\", \\\"{x:1111,y:621,t:1527189213485};\\\", \\\"{x:1073,y:607,t:1527189213502};\\\", \\\"{x:1049,y:595,t:1527189213519};\\\", \\\"{x:1016,y:576,t:1527189213535};\\\", \\\"{x:992,y:562,t:1527189213552};\\\", \\\"{x:974,y:539,t:1527189213569};\\\", \\\"{x:970,y:519,t:1527189213585};\\\", \\\"{x:963,y:494,t:1527189213601};\\\", \\\"{x:958,y:473,t:1527189213618};\\\", \\\"{x:953,y:458,t:1527189213635};\\\", \\\"{x:945,y:445,t:1527189213654};\\\", \\\"{x:939,y:437,t:1527189213668};\\\", \\\"{x:934,y:433,t:1527189213686};\\\", \\\"{x:933,y:433,t:1527189213736};\\\", \\\"{x:932,y:433,t:1527189213747};\\\", \\\"{x:923,y:433,t:1527189213764};\\\", \\\"{x:903,y:433,t:1527189213781};\\\", \\\"{x:875,y:438,t:1527189213798};\\\", \\\"{x:858,y:445,t:1527189213815};\\\", \\\"{x:847,y:450,t:1527189213831};\\\", \\\"{x:844,y:450,t:1527189213848};\\\", \\\"{x:843,y:451,t:1527189213866};\\\", \\\"{x:842,y:451,t:1527189213888};\\\", \\\"{x:841,y:451,t:1527189213898};\\\", \\\"{x:839,y:451,t:1527189213915};\\\", \\\"{x:837,y:451,t:1527189213931};\\\", \\\"{x:836,y:452,t:1527189214577};\\\", \\\"{x:837,y:463,t:1527189214586};\\\", \\\"{x:844,y:475,t:1527189214599};\\\", \\\"{x:861,y:495,t:1527189214615};\\\", \\\"{x:912,y:525,t:1527189214632};\\\", \\\"{x:957,y:545,t:1527189214649};\\\", \\\"{x:990,y:559,t:1527189214665};\\\", \\\"{x:1019,y:573,t:1527189214682};\\\", \\\"{x:1039,y:582,t:1527189214698};\\\", \\\"{x:1053,y:587,t:1527189214715};\\\", \\\"{x:1069,y:589,t:1527189214732};\\\", \\\"{x:1081,y:591,t:1527189214748};\\\", \\\"{x:1091,y:592,t:1527189214766};\\\", \\\"{x:1097,y:592,t:1527189214783};\\\", \\\"{x:1103,y:592,t:1527189214798};\\\", \\\"{x:1117,y:586,t:1527189214815};\\\", \\\"{x:1160,y:581,t:1527189214833};\\\", \\\"{x:1192,y:580,t:1527189214849};\\\", \\\"{x:1224,y:580,t:1527189214865};\\\", \\\"{x:1243,y:580,t:1527189214882};\\\", \\\"{x:1249,y:580,t:1527189214900};\\\", \\\"{x:1250,y:580,t:1527189214916};\\\", \\\"{x:1252,y:580,t:1527189214933};\\\", \\\"{x:1253,y:580,t:1527189214949};\\\", \\\"{x:1255,y:581,t:1527189214965};\\\", \\\"{x:1257,y:581,t:1527189214983};\\\", \\\"{x:1260,y:583,t:1527189215000};\\\", \\\"{x:1265,y:588,t:1527189215016};\\\", \\\"{x:1277,y:601,t:1527189215033};\\\", \\\"{x:1283,y:609,t:1527189215050};\\\", \\\"{x:1291,y:620,t:1527189215065};\\\", \\\"{x:1306,y:633,t:1527189215082};\\\", \\\"{x:1325,y:648,t:1527189215100};\\\", \\\"{x:1344,y:663,t:1527189215116};\\\", \\\"{x:1367,y:673,t:1527189215133};\\\", \\\"{x:1376,y:673,t:1527189215150};\\\", \\\"{x:1377,y:673,t:1527189215169};\\\", \\\"{x:1378,y:673,t:1527189215185};\\\", \\\"{x:1380,y:675,t:1527189215594};\\\", \\\"{x:1380,y:673,t:1527189215865};\\\", \\\"{x:1380,y:670,t:1527189215873};\\\", \\\"{x:1378,y:667,t:1527189215883};\\\", \\\"{x:1370,y:661,t:1527189215899};\\\", \\\"{x:1366,y:658,t:1527189215917};\\\", \\\"{x:1363,y:656,t:1527189215933};\\\", \\\"{x:1361,y:656,t:1527189215949};\\\", \\\"{x:1358,y:654,t:1527189215966};\\\", \\\"{x:1357,y:653,t:1527189216129};\\\", \\\"{x:1354,y:652,t:1527189216145};\\\", \\\"{x:1350,y:650,t:1527189216153};\\\", \\\"{x:1348,y:649,t:1527189216167};\\\", \\\"{x:1342,y:648,t:1527189216188};\\\", \\\"{x:1342,y:647,t:1527189216509};\\\", \\\"{x:1342,y:646,t:1527189216521};\\\", \\\"{x:1342,y:650,t:1527189216613};\\\", \\\"{x:1342,y:657,t:1527189216621};\\\", \\\"{x:1340,y:671,t:1527189216638};\\\", \\\"{x:1337,y:692,t:1527189216655};\\\", \\\"{x:1336,y:709,t:1527189216672};\\\", \\\"{x:1334,y:725,t:1527189216688};\\\", \\\"{x:1334,y:733,t:1527189216705};\\\", \\\"{x:1334,y:737,t:1527189216721};\\\", \\\"{x:1334,y:738,t:1527189216737};\\\", \\\"{x:1334,y:739,t:1527189216901};\\\", \\\"{x:1336,y:738,t:1527189216916};\\\", \\\"{x:1338,y:735,t:1527189216923};\\\", \\\"{x:1340,y:732,t:1527189216937};\\\", \\\"{x:1343,y:725,t:1527189216954};\\\", \\\"{x:1345,y:719,t:1527189216971};\\\", \\\"{x:1345,y:711,t:1527189216988};\\\", \\\"{x:1346,y:710,t:1527189217004};\\\", \\\"{x:1347,y:707,t:1527189217021};\\\", \\\"{x:1349,y:707,t:1527189218669};\\\", \\\"{x:1352,y:708,t:1527189218677};\\\", \\\"{x:1355,y:709,t:1527189218690};\\\", \\\"{x:1364,y:713,t:1527189218705};\\\", \\\"{x:1371,y:717,t:1527189218722};\\\", \\\"{x:1376,y:718,t:1527189218739};\\\", \\\"{x:1381,y:719,t:1527189218756};\\\", \\\"{x:1387,y:720,t:1527189218772};\\\", \\\"{x:1393,y:720,t:1527189218788};\\\", \\\"{x:1397,y:721,t:1527189218806};\\\", \\\"{x:1403,y:722,t:1527189218822};\\\", \\\"{x:1412,y:723,t:1527189218839};\\\", \\\"{x:1426,y:727,t:1527189218856};\\\", \\\"{x:1446,y:731,t:1527189218872};\\\", \\\"{x:1468,y:736,t:1527189218890};\\\", \\\"{x:1489,y:738,t:1527189218907};\\\", \\\"{x:1509,y:739,t:1527189218922};\\\", \\\"{x:1524,y:739,t:1527189218939};\\\", \\\"{x:1534,y:739,t:1527189218956};\\\", \\\"{x:1535,y:739,t:1527189219036};\\\", \\\"{x:1535,y:738,t:1527189219061};\\\", \\\"{x:1535,y:737,t:1527189219157};\\\", \\\"{x:1535,y:734,t:1527189219173};\\\", \\\"{x:1535,y:730,t:1527189219190};\\\", \\\"{x:1532,y:724,t:1527189219207};\\\", \\\"{x:1529,y:720,t:1527189219224};\\\", \\\"{x:1529,y:719,t:1527189219239};\\\", \\\"{x:1529,y:717,t:1527189219257};\\\", \\\"{x:1529,y:716,t:1527189219273};\\\", \\\"{x:1528,y:716,t:1527189219290};\\\", \\\"{x:1528,y:714,t:1527189219365};\\\", \\\"{x:1527,y:714,t:1527189219374};\\\", \\\"{x:1524,y:712,t:1527189219390};\\\", \\\"{x:1523,y:712,t:1527189219406};\\\", \\\"{x:1521,y:711,t:1527189219423};\\\", \\\"{x:1520,y:710,t:1527189219440};\\\", \\\"{x:1519,y:710,t:1527189219457};\\\", \\\"{x:1516,y:709,t:1527189219473};\\\", \\\"{x:1515,y:708,t:1527189219492};\\\", \\\"{x:1513,y:708,t:1527189219517};\\\", \\\"{x:1512,y:708,t:1527189219645};\\\", \\\"{x:1511,y:711,t:1527189219656};\\\", \\\"{x:1504,y:719,t:1527189219675};\\\", \\\"{x:1496,y:731,t:1527189219690};\\\", \\\"{x:1489,y:747,t:1527189219707};\\\", \\\"{x:1483,y:763,t:1527189219723};\\\", \\\"{x:1477,y:777,t:1527189219740};\\\", \\\"{x:1472,y:792,t:1527189219757};\\\", \\\"{x:1471,y:800,t:1527189219773};\\\", \\\"{x:1469,y:804,t:1527189219791};\\\", \\\"{x:1468,y:807,t:1527189219806};\\\", \\\"{x:1467,y:809,t:1527189219823};\\\", \\\"{x:1467,y:807,t:1527189219909};\\\", \\\"{x:1467,y:803,t:1527189219924};\\\", \\\"{x:1467,y:796,t:1527189219940};\\\", \\\"{x:1467,y:793,t:1527189219957};\\\", \\\"{x:1467,y:790,t:1527189219973};\\\", \\\"{x:1468,y:785,t:1527189219990};\\\", \\\"{x:1472,y:782,t:1527189220006};\\\", \\\"{x:1475,y:780,t:1527189220023};\\\", \\\"{x:1477,y:779,t:1527189220040};\\\", \\\"{x:1479,y:777,t:1527189220057};\\\", \\\"{x:1480,y:777,t:1527189220124};\\\", \\\"{x:1480,y:775,t:1527189220156};\\\", \\\"{x:1478,y:775,t:1527189221788};\\\", \\\"{x:1476,y:775,t:1527189221796};\\\", \\\"{x:1472,y:775,t:1527189221810};\\\", \\\"{x:1466,y:775,t:1527189221826};\\\", \\\"{x:1461,y:775,t:1527189221842};\\\", \\\"{x:1455,y:774,t:1527189221859};\\\", \\\"{x:1449,y:773,t:1527189221875};\\\", \\\"{x:1443,y:769,t:1527189221892};\\\", \\\"{x:1421,y:759,t:1527189221909};\\\", \\\"{x:1394,y:747,t:1527189221926};\\\", \\\"{x:1338,y:730,t:1527189221942};\\\", \\\"{x:1296,y:717,t:1527189221959};\\\", \\\"{x:1260,y:708,t:1527189221975};\\\", \\\"{x:1199,y:691,t:1527189221992};\\\", \\\"{x:1155,y:672,t:1527189222009};\\\", \\\"{x:1067,y:653,t:1527189222026};\\\", \\\"{x:992,y:634,t:1527189222042};\\\", \\\"{x:955,y:620,t:1527189222059};\\\", \\\"{x:932,y:609,t:1527189222076};\\\", \\\"{x:900,y:589,t:1527189222092};\\\", \\\"{x:857,y:567,t:1527189222108};\\\", \\\"{x:801,y:540,t:1527189222126};\\\", \\\"{x:740,y:510,t:1527189222141};\\\", \\\"{x:701,y:493,t:1527189222159};\\\", \\\"{x:673,y:482,t:1527189222175};\\\", \\\"{x:655,y:478,t:1527189222192};\\\", \\\"{x:643,y:477,t:1527189222208};\\\", \\\"{x:638,y:477,t:1527189222225};\\\", \\\"{x:630,y:479,t:1527189222242};\\\", \\\"{x:621,y:482,t:1527189222258};\\\", \\\"{x:600,y:488,t:1527189222275};\\\", \\\"{x:572,y:501,t:1527189222292};\\\", \\\"{x:566,y:504,t:1527189222309};\\\", \\\"{x:567,y:507,t:1527189222325};\\\", \\\"{x:568,y:508,t:1527189222342};\\\", \\\"{x:570,y:508,t:1527189222359};\\\", \\\"{x:572,y:508,t:1527189222375};\\\", \\\"{x:573,y:509,t:1527189222392};\\\", \\\"{x:573,y:510,t:1527189222436};\\\", \\\"{x:574,y:510,t:1527189222443};\\\", \\\"{x:576,y:512,t:1527189222459};\\\", \\\"{x:581,y:520,t:1527189222475};\\\", \\\"{x:588,y:527,t:1527189222492};\\\", \\\"{x:594,y:531,t:1527189222509};\\\", \\\"{x:604,y:537,t:1527189222525};\\\", \\\"{x:608,y:538,t:1527189222542};\\\", \\\"{x:609,y:539,t:1527189222559};\\\", \\\"{x:611,y:539,t:1527189222575};\\\", \\\"{x:609,y:539,t:1527189222724};\\\", \\\"{x:608,y:539,t:1527189222732};\\\", \\\"{x:606,y:538,t:1527189222743};\\\", \\\"{x:604,y:538,t:1527189222759};\\\", \\\"{x:604,y:535,t:1527189222778};\\\", \\\"{x:603,y:535,t:1527189222792};\\\", \\\"{x:603,y:533,t:1527189222810};\\\", \\\"{x:603,y:532,t:1527189222825};\\\", \\\"{x:604,y:531,t:1527189222959};\\\", \\\"{x:604,y:531,t:1527189223054};\\\", \\\"{x:603,y:531,t:1527189223123};\\\", \\\"{x:602,y:531,t:1527189223131};\\\", \\\"{x:596,y:531,t:1527189223142};\\\", \\\"{x:585,y:541,t:1527189223160};\\\", \\\"{x:569,y:559,t:1527189223177};\\\", \\\"{x:553,y:578,t:1527189223192};\\\", \\\"{x:541,y:596,t:1527189223209};\\\", \\\"{x:527,y:613,t:1527189223226};\\\", \\\"{x:515,y:625,t:1527189223242};\\\", \\\"{x:507,y:638,t:1527189223260};\\\", \\\"{x:506,y:643,t:1527189223276};\\\", \\\"{x:505,y:645,t:1527189223293};\\\", \\\"{x:505,y:647,t:1527189223310};\\\", \\\"{x:505,y:650,t:1527189223326};\\\", \\\"{x:505,y:654,t:1527189223344};\\\", \\\"{x:504,y:662,t:1527189223359};\\\", \\\"{x:503,y:673,t:1527189223377};\\\", \\\"{x:503,y:680,t:1527189223393};\\\", \\\"{x:503,y:686,t:1527189223409};\\\", \\\"{x:503,y:691,t:1527189223426};\\\", \\\"{x:503,y:696,t:1527189223443};\\\", \\\"{x:503,y:702,t:1527189223460};\\\", \\\"{x:503,y:710,t:1527189223476};\\\", \\\"{x:504,y:711,t:1527189223539};\\\", \\\"{x:504,y:710,t:1527189223628};\\\", \\\"{x:504,y:705,t:1527189223644};\\\", \\\"{x:505,y:703,t:1527189223659};\\\", \\\"{x:505,y:699,t:1527189223678};\\\", \\\"{x:506,y:697,t:1527189223693};\\\", \\\"{x:506,y:696,t:1527189223812};\\\", \\\"{x:506,y:695,t:1527189223826};\\\", \\\"{x:507,y:694,t:1527189223843};\\\" ] }, { \\\"rt\\\": 50825, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 660420, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-X -X -X -B -B -B -B -B -F -F -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:693,t:1527189228821};\\\", \\\"{x:521,y:693,t:1527189228834};\\\", \\\"{x:553,y:700,t:1527189228851};\\\", \\\"{x:617,y:718,t:1527189228867};\\\", \\\"{x:691,y:746,t:1527189228884};\\\", \\\"{x:791,y:776,t:1527189228901};\\\", \\\"{x:857,y:793,t:1527189228913};\\\", \\\"{x:1005,y:828,t:1527189228931};\\\", \\\"{x:1158,y:849,t:1527189228946};\\\", \\\"{x:1377,y:873,t:1527189228963};\\\", \\\"{x:1496,y:873,t:1527189228980};\\\", \\\"{x:1596,y:873,t:1527189228996};\\\", \\\"{x:1675,y:879,t:1527189229014};\\\", \\\"{x:1728,y:879,t:1527189229031};\\\", \\\"{x:1762,y:879,t:1527189229047};\\\", \\\"{x:1784,y:878,t:1527189229063};\\\", \\\"{x:1798,y:875,t:1527189229081};\\\", \\\"{x:1803,y:874,t:1527189229096};\\\", \\\"{x:1806,y:873,t:1527189229114};\\\", \\\"{x:1807,y:873,t:1527189229205};\\\", \\\"{x:1807,y:872,t:1527189229214};\\\", \\\"{x:1807,y:870,t:1527189229231};\\\", \\\"{x:1796,y:865,t:1527189229247};\\\", \\\"{x:1786,y:862,t:1527189229264};\\\", \\\"{x:1778,y:861,t:1527189229281};\\\", \\\"{x:1769,y:861,t:1527189229297};\\\", \\\"{x:1754,y:864,t:1527189229313};\\\", \\\"{x:1738,y:870,t:1527189229330};\\\", \\\"{x:1712,y:880,t:1527189229347};\\\", \\\"{x:1690,y:885,t:1527189229363};\\\", \\\"{x:1669,y:892,t:1527189229380};\\\", \\\"{x:1652,y:896,t:1527189229397};\\\", \\\"{x:1634,y:899,t:1527189229413};\\\", \\\"{x:1612,y:902,t:1527189229430};\\\", \\\"{x:1591,y:905,t:1527189229447};\\\", \\\"{x:1571,y:905,t:1527189229463};\\\", \\\"{x:1554,y:905,t:1527189229480};\\\", \\\"{x:1542,y:905,t:1527189229497};\\\", \\\"{x:1532,y:905,t:1527189229513};\\\", \\\"{x:1526,y:905,t:1527189229530};\\\", \\\"{x:1525,y:905,t:1527189229547};\\\", \\\"{x:1525,y:903,t:1527189229603};\\\", \\\"{x:1525,y:902,t:1527189229619};\\\", \\\"{x:1525,y:901,t:1527189229691};\\\", \\\"{x:1525,y:900,t:1527189229707};\\\", \\\"{x:1526,y:900,t:1527189229715};\\\", \\\"{x:1527,y:900,t:1527189229755};\\\", \\\"{x:1530,y:900,t:1527189229763};\\\", \\\"{x:1536,y:900,t:1527189229781};\\\", \\\"{x:1543,y:901,t:1527189229797};\\\", \\\"{x:1548,y:903,t:1527189229814};\\\", \\\"{x:1556,y:905,t:1527189229830};\\\", \\\"{x:1572,y:910,t:1527189229847};\\\", \\\"{x:1586,y:913,t:1527189229864};\\\", \\\"{x:1598,y:916,t:1527189229880};\\\", \\\"{x:1600,y:917,t:1527189229898};\\\", \\\"{x:1601,y:917,t:1527189229914};\\\", \\\"{x:1600,y:917,t:1527189229947};\\\", \\\"{x:1595,y:917,t:1527189229964};\\\", \\\"{x:1586,y:915,t:1527189229981};\\\", \\\"{x:1580,y:915,t:1527189229997};\\\", \\\"{x:1578,y:915,t:1527189230014};\\\", \\\"{x:1578,y:916,t:1527189230030};\\\", \\\"{x:1576,y:917,t:1527189230047};\\\", \\\"{x:1573,y:917,t:1527189230140};\\\", \\\"{x:1570,y:917,t:1527189230147};\\\", \\\"{x:1560,y:917,t:1527189230164};\\\", \\\"{x:1547,y:916,t:1527189230180};\\\", \\\"{x:1540,y:915,t:1527189230198};\\\", \\\"{x:1538,y:915,t:1527189230214};\\\", \\\"{x:1537,y:915,t:1527189230231};\\\", \\\"{x:1537,y:914,t:1527189230315};\\\", \\\"{x:1537,y:913,t:1527189230331};\\\", \\\"{x:1537,y:911,t:1527189230347};\\\", \\\"{x:1537,y:910,t:1527189230364};\\\", \\\"{x:1537,y:909,t:1527189230395};\\\", \\\"{x:1538,y:909,t:1527189230923};\\\", \\\"{x:1541,y:909,t:1527189230931};\\\", \\\"{x:1545,y:907,t:1527189230947};\\\", \\\"{x:1547,y:907,t:1527189230965};\\\", \\\"{x:1547,y:906,t:1527189230981};\\\", \\\"{x:1549,y:906,t:1527189234355};\\\", \\\"{x:1556,y:906,t:1527189234366};\\\", \\\"{x:1563,y:907,t:1527189234383};\\\", \\\"{x:1569,y:907,t:1527189234400};\\\", \\\"{x:1568,y:907,t:1527189234515};\\\", \\\"{x:1565,y:907,t:1527189234524};\\\", \\\"{x:1564,y:907,t:1527189234534};\\\", \\\"{x:1563,y:907,t:1527189234549};\\\", \\\"{x:1562,y:906,t:1527189234643};\\\", \\\"{x:1559,y:905,t:1527189234659};\\\", \\\"{x:1558,y:905,t:1527189234667};\\\", \\\"{x:1556,y:904,t:1527189234683};\\\", \\\"{x:1550,y:901,t:1527189234699};\\\", \\\"{x:1543,y:901,t:1527189234716};\\\", \\\"{x:1534,y:900,t:1527189234733};\\\", \\\"{x:1528,y:900,t:1527189234750};\\\", \\\"{x:1526,y:900,t:1527189234767};\\\", \\\"{x:1526,y:898,t:1527189235083};\\\", \\\"{x:1530,y:896,t:1527189235101};\\\", \\\"{x:1533,y:894,t:1527189235117};\\\", \\\"{x:1535,y:893,t:1527189235134};\\\", \\\"{x:1534,y:891,t:1527189236187};\\\", \\\"{x:1533,y:890,t:1527189236203};\\\", \\\"{x:1532,y:889,t:1527189236217};\\\", \\\"{x:1526,y:881,t:1527189236235};\\\", \\\"{x:1520,y:864,t:1527189236251};\\\", \\\"{x:1505,y:827,t:1527189236267};\\\", \\\"{x:1492,y:793,t:1527189236284};\\\", \\\"{x:1482,y:768,t:1527189236301};\\\", \\\"{x:1475,y:757,t:1527189236317};\\\", \\\"{x:1474,y:754,t:1527189236335};\\\", \\\"{x:1474,y:752,t:1527189236351};\\\", \\\"{x:1474,y:751,t:1527189236367};\\\", \\\"{x:1474,y:752,t:1527189236555};\\\", \\\"{x:1474,y:753,t:1527189236567};\\\", \\\"{x:1474,y:756,t:1527189236585};\\\", \\\"{x:1474,y:762,t:1527189236600};\\\", \\\"{x:1475,y:767,t:1527189236618};\\\", \\\"{x:1476,y:770,t:1527189236635};\\\", \\\"{x:1476,y:772,t:1527189236650};\\\", \\\"{x:1477,y:772,t:1527189236987};\\\", \\\"{x:1478,y:772,t:1527189237002};\\\", \\\"{x:1479,y:772,t:1527189237017};\\\", \\\"{x:1482,y:772,t:1527189237034};\\\", \\\"{x:1483,y:772,t:1527189237051};\\\", \\\"{x:1484,y:772,t:1527189237635};\\\", \\\"{x:1485,y:773,t:1527189237651};\\\", \\\"{x:1485,y:779,t:1527189237668};\\\", \\\"{x:1485,y:781,t:1527189237684};\\\", \\\"{x:1485,y:783,t:1527189237702};\\\", \\\"{x:1486,y:784,t:1527189237719};\\\", \\\"{x:1487,y:784,t:1527189237836};\\\", \\\"{x:1489,y:784,t:1527189237852};\\\", \\\"{x:1490,y:784,t:1527189237876};\\\", \\\"{x:1491,y:784,t:1527189237885};\\\", \\\"{x:1493,y:784,t:1527189238219};\\\", \\\"{x:1499,y:784,t:1527189238234};\\\", \\\"{x:1501,y:784,t:1527189238252};\\\", \\\"{x:1502,y:784,t:1527189238269};\\\", \\\"{x:1505,y:785,t:1527189238286};\\\", \\\"{x:1508,y:785,t:1527189238302};\\\", \\\"{x:1512,y:785,t:1527189238318};\\\", \\\"{x:1526,y:784,t:1527189238336};\\\", \\\"{x:1538,y:784,t:1527189238352};\\\", \\\"{x:1551,y:783,t:1527189238369};\\\", \\\"{x:1559,y:783,t:1527189238386};\\\", \\\"{x:1565,y:781,t:1527189238402};\\\", \\\"{x:1566,y:781,t:1527189238419};\\\", \\\"{x:1567,y:780,t:1527189238563};\\\", \\\"{x:1567,y:779,t:1527189238571};\\\", \\\"{x:1566,y:777,t:1527189238587};\\\", \\\"{x:1565,y:777,t:1527189238602};\\\", \\\"{x:1563,y:776,t:1527189238618};\\\", \\\"{x:1560,y:775,t:1527189238636};\\\", \\\"{x:1558,y:774,t:1527189238652};\\\", \\\"{x:1557,y:773,t:1527189238669};\\\", \\\"{x:1555,y:773,t:1527189238707};\\\", \\\"{x:1554,y:773,t:1527189238747};\\\", \\\"{x:1552,y:773,t:1527189239195};\\\", \\\"{x:1552,y:772,t:1527189239203};\\\", \\\"{x:1551,y:772,t:1527189239219};\\\", \\\"{x:1549,y:772,t:1527189239236};\\\", \\\"{x:1548,y:772,t:1527189239253};\\\", \\\"{x:1546,y:772,t:1527189239275};\\\", \\\"{x:1545,y:769,t:1527189239860};\\\", \\\"{x:1545,y:765,t:1527189239869};\\\", \\\"{x:1545,y:756,t:1527189239885};\\\", \\\"{x:1545,y:747,t:1527189239903};\\\", \\\"{x:1544,y:739,t:1527189239920};\\\", \\\"{x:1542,y:732,t:1527189239936};\\\", \\\"{x:1539,y:728,t:1527189239953};\\\", \\\"{x:1538,y:726,t:1527189239970};\\\", \\\"{x:1537,y:726,t:1527189239985};\\\", \\\"{x:1536,y:724,t:1527189240003};\\\", \\\"{x:1533,y:722,t:1527189240019};\\\", \\\"{x:1529,y:720,t:1527189240036};\\\", \\\"{x:1527,y:719,t:1527189240052};\\\", \\\"{x:1525,y:717,t:1527189240070};\\\", \\\"{x:1525,y:716,t:1527189240148};\\\", \\\"{x:1525,y:715,t:1527189240155};\\\", \\\"{x:1525,y:714,t:1527189240170};\\\", \\\"{x:1525,y:713,t:1527189240186};\\\", \\\"{x:1525,y:711,t:1527189240202};\\\", \\\"{x:1524,y:711,t:1527189240220};\\\", \\\"{x:1526,y:710,t:1527189240275};\\\", \\\"{x:1528,y:710,t:1527189240287};\\\", \\\"{x:1536,y:711,t:1527189240303};\\\", \\\"{x:1538,y:712,t:1527189240320};\\\", \\\"{x:1539,y:712,t:1527189240692};\\\", \\\"{x:1541,y:712,t:1527189240715};\\\", \\\"{x:1537,y:713,t:1527189241189};\\\", \\\"{x:1517,y:716,t:1527189241204};\\\", \\\"{x:1495,y:719,t:1527189241221};\\\", \\\"{x:1467,y:721,t:1527189241238};\\\", \\\"{x:1444,y:721,t:1527189241255};\\\", \\\"{x:1434,y:721,t:1527189241271};\\\", \\\"{x:1432,y:721,t:1527189241288};\\\", \\\"{x:1431,y:721,t:1527189241305};\\\", \\\"{x:1429,y:721,t:1527189241324};\\\", \\\"{x:1428,y:721,t:1527189241337};\\\", \\\"{x:1424,y:720,t:1527189241354};\\\", \\\"{x:1420,y:718,t:1527189241371};\\\", \\\"{x:1418,y:718,t:1527189241387};\\\", \\\"{x:1414,y:717,t:1527189241404};\\\", \\\"{x:1413,y:717,t:1527189241421};\\\", \\\"{x:1411,y:717,t:1527189241437};\\\", \\\"{x:1408,y:717,t:1527189241454};\\\", \\\"{x:1405,y:716,t:1527189241472};\\\", \\\"{x:1397,y:715,t:1527189241488};\\\", \\\"{x:1393,y:714,t:1527189241504};\\\", \\\"{x:1388,y:713,t:1527189241522};\\\", \\\"{x:1383,y:711,t:1527189241538};\\\", \\\"{x:1376,y:710,t:1527189241554};\\\", \\\"{x:1364,y:706,t:1527189241573};\\\", \\\"{x:1360,y:705,t:1527189241587};\\\", \\\"{x:1352,y:703,t:1527189241604};\\\", \\\"{x:1348,y:702,t:1527189241622};\\\", \\\"{x:1345,y:700,t:1527189241637};\\\", \\\"{x:1343,y:699,t:1527189241655};\\\", \\\"{x:1341,y:699,t:1527189241672};\\\", \\\"{x:1340,y:699,t:1527189241893};\\\", \\\"{x:1341,y:699,t:1527189241932};\\\", \\\"{x:1342,y:699,t:1527189241980};\\\", \\\"{x:1343,y:700,t:1527189241988};\\\", \\\"{x:1343,y:701,t:1527189242004};\\\", \\\"{x:1344,y:702,t:1527189242084};\\\", \\\"{x:1346,y:702,t:1527189242108};\\\", \\\"{x:1347,y:702,t:1527189242121};\\\", \\\"{x:1347,y:703,t:1527189242138};\\\", \\\"{x:1349,y:704,t:1527189242196};\\\", \\\"{x:1350,y:705,t:1527189242213};\\\", \\\"{x:1352,y:706,t:1527189242222};\\\", \\\"{x:1354,y:707,t:1527189242240};\\\", \\\"{x:1356,y:708,t:1527189242254};\\\", \\\"{x:1359,y:709,t:1527189242272};\\\", \\\"{x:1360,y:709,t:1527189242292};\\\", \\\"{x:1361,y:709,t:1527189242305};\\\", \\\"{x:1362,y:710,t:1527189242322};\\\", \\\"{x:1365,y:710,t:1527189242338};\\\", \\\"{x:1369,y:711,t:1527189242355};\\\", \\\"{x:1372,y:711,t:1527189242371};\\\", \\\"{x:1373,y:711,t:1527189242420};\\\", \\\"{x:1374,y:711,t:1527189242508};\\\", \\\"{x:1375,y:711,t:1527189242524};\\\", \\\"{x:1377,y:711,t:1527189242540};\\\", \\\"{x:1377,y:710,t:1527189242554};\\\", \\\"{x:1378,y:710,t:1527189242620};\\\", \\\"{x:1379,y:709,t:1527189242652};\\\", \\\"{x:1380,y:709,t:1527189242669};\\\", \\\"{x:1381,y:709,t:1527189242700};\\\", \\\"{x:1380,y:709,t:1527189243531};\\\", \\\"{x:1377,y:709,t:1527189243539};\\\", \\\"{x:1369,y:708,t:1527189243555};\\\", \\\"{x:1363,y:707,t:1527189243571};\\\", \\\"{x:1356,y:705,t:1527189243588};\\\", \\\"{x:1354,y:705,t:1527189243605};\\\", \\\"{x:1353,y:705,t:1527189243622};\\\", \\\"{x:1351,y:705,t:1527189243643};\\\", \\\"{x:1350,y:705,t:1527189243660};\\\", \\\"{x:1349,y:704,t:1527189243672};\\\", \\\"{x:1348,y:704,t:1527189243688};\\\", \\\"{x:1347,y:704,t:1527189243705};\\\", \\\"{x:1346,y:703,t:1527189243722};\\\", \\\"{x:1344,y:702,t:1527189243738};\\\", \\\"{x:1343,y:702,t:1527189243755};\\\", \\\"{x:1344,y:702,t:1527189243812};\\\", \\\"{x:1348,y:703,t:1527189243822};\\\", \\\"{x:1353,y:705,t:1527189243839};\\\", \\\"{x:1357,y:707,t:1527189243856};\\\", \\\"{x:1360,y:708,t:1527189243872};\\\", \\\"{x:1363,y:710,t:1527189243888};\\\", \\\"{x:1372,y:712,t:1527189243906};\\\", \\\"{x:1382,y:714,t:1527189243923};\\\", \\\"{x:1394,y:715,t:1527189243938};\\\", \\\"{x:1406,y:715,t:1527189243956};\\\", \\\"{x:1410,y:715,t:1527189243972};\\\", \\\"{x:1411,y:715,t:1527189244148};\\\", \\\"{x:1411,y:714,t:1527189244172};\\\", \\\"{x:1411,y:711,t:1527189244190};\\\", \\\"{x:1411,y:710,t:1527189244206};\\\", \\\"{x:1410,y:707,t:1527189244223};\\\", \\\"{x:1408,y:705,t:1527189244240};\\\", \\\"{x:1407,y:705,t:1527189244255};\\\", \\\"{x:1406,y:705,t:1527189244613};\\\", \\\"{x:1407,y:706,t:1527189244652};\\\", \\\"{x:1408,y:706,t:1527189244676};\\\", \\\"{x:1409,y:708,t:1527189244690};\\\", \\\"{x:1410,y:708,t:1527189244708};\\\", \\\"{x:1413,y:709,t:1527189244724};\\\", \\\"{x:1421,y:714,t:1527189244740};\\\", \\\"{x:1433,y:718,t:1527189244756};\\\", \\\"{x:1444,y:722,t:1527189244773};\\\", \\\"{x:1460,y:728,t:1527189244790};\\\", \\\"{x:1473,y:732,t:1527189244807};\\\", \\\"{x:1480,y:733,t:1527189244822};\\\", \\\"{x:1483,y:733,t:1527189244840};\\\", \\\"{x:1485,y:733,t:1527189244856};\\\", \\\"{x:1486,y:733,t:1527189244925};\\\", \\\"{x:1488,y:731,t:1527189244939};\\\", \\\"{x:1491,y:728,t:1527189244955};\\\", \\\"{x:1493,y:725,t:1527189244972};\\\", \\\"{x:1493,y:724,t:1527189244989};\\\", \\\"{x:1494,y:722,t:1527189245006};\\\", \\\"{x:1494,y:720,t:1527189245059};\\\", \\\"{x:1494,y:719,t:1527189245073};\\\", \\\"{x:1492,y:718,t:1527189245089};\\\", \\\"{x:1491,y:717,t:1527189245132};\\\", \\\"{x:1491,y:716,t:1527189245148};\\\", \\\"{x:1491,y:715,t:1527189245155};\\\", \\\"{x:1491,y:713,t:1527189245172};\\\", \\\"{x:1491,y:712,t:1527189245190};\\\", \\\"{x:1491,y:710,t:1527189245207};\\\", \\\"{x:1491,y:708,t:1527189245224};\\\", \\\"{x:1491,y:707,t:1527189245239};\\\", \\\"{x:1491,y:706,t:1527189245364};\\\", \\\"{x:1490,y:706,t:1527189245948};\\\", \\\"{x:1489,y:706,t:1527189245980};\\\", \\\"{x:1487,y:706,t:1527189245996};\\\", \\\"{x:1486,y:706,t:1527189246020};\\\", \\\"{x:1485,y:706,t:1527189246036};\\\", \\\"{x:1485,y:707,t:1527189246044};\\\", \\\"{x:1484,y:707,t:1527189246076};\\\", \\\"{x:1483,y:707,t:1527189246100};\\\", \\\"{x:1483,y:708,t:1527189246124};\\\", \\\"{x:1482,y:708,t:1527189246164};\\\", \\\"{x:1482,y:713,t:1527189247716};\\\", \\\"{x:1482,y:721,t:1527189247724};\\\", \\\"{x:1485,y:739,t:1527189247741};\\\", \\\"{x:1487,y:757,t:1527189247757};\\\", \\\"{x:1493,y:776,t:1527189247775};\\\", \\\"{x:1501,y:792,t:1527189247791};\\\", \\\"{x:1508,y:805,t:1527189247808};\\\", \\\"{x:1513,y:820,t:1527189247824};\\\", \\\"{x:1520,y:834,t:1527189247843};\\\", \\\"{x:1524,y:843,t:1527189247858};\\\", \\\"{x:1528,y:850,t:1527189247875};\\\", \\\"{x:1531,y:857,t:1527189247891};\\\", \\\"{x:1532,y:861,t:1527189247908};\\\", \\\"{x:1534,y:862,t:1527189247924};\\\", \\\"{x:1534,y:865,t:1527189247942};\\\", \\\"{x:1535,y:867,t:1527189247958};\\\", \\\"{x:1536,y:870,t:1527189247975};\\\", \\\"{x:1536,y:872,t:1527189247992};\\\", \\\"{x:1536,y:873,t:1527189248007};\\\", \\\"{x:1537,y:877,t:1527189248025};\\\", \\\"{x:1537,y:884,t:1527189248043};\\\", \\\"{x:1539,y:891,t:1527189248058};\\\", \\\"{x:1541,y:899,t:1527189248075};\\\", \\\"{x:1546,y:908,t:1527189248091};\\\", \\\"{x:1548,y:911,t:1527189248108};\\\", \\\"{x:1549,y:913,t:1527189248125};\\\", \\\"{x:1550,y:914,t:1527189248142};\\\", \\\"{x:1552,y:914,t:1527189248276};\\\", \\\"{x:1553,y:914,t:1527189248324};\\\", \\\"{x:1552,y:913,t:1527189248587};\\\", \\\"{x:1552,y:912,t:1527189249013};\\\", \\\"{x:1551,y:912,t:1527189249024};\\\", \\\"{x:1545,y:909,t:1527189249044};\\\", \\\"{x:1544,y:909,t:1527189249058};\\\", \\\"{x:1543,y:909,t:1527189249075};\\\", \\\"{x:1543,y:908,t:1527189249092};\\\", \\\"{x:1544,y:908,t:1527189249380};\\\", \\\"{x:1545,y:908,t:1527189249396};\\\", \\\"{x:1546,y:909,t:1527189249412};\\\", \\\"{x:1547,y:909,t:1527189250212};\\\", \\\"{x:1547,y:908,t:1527189250252};\\\", \\\"{x:1547,y:907,t:1527189250284};\\\", \\\"{x:1547,y:906,t:1527189250292};\\\", \\\"{x:1547,y:905,t:1527189250323};\\\", \\\"{x:1547,y:904,t:1527189250332};\\\", \\\"{x:1547,y:903,t:1527189250343};\\\", \\\"{x:1547,y:902,t:1527189250364};\\\", \\\"{x:1547,y:901,t:1527189250380};\\\", \\\"{x:1547,y:900,t:1527189250396};\\\", \\\"{x:1547,y:899,t:1527189250412};\\\", \\\"{x:1547,y:898,t:1527189250426};\\\", \\\"{x:1547,y:897,t:1527189250443};\\\", \\\"{x:1547,y:895,t:1527189250459};\\\", \\\"{x:1547,y:894,t:1527189250475};\\\", \\\"{x:1547,y:892,t:1527189250492};\\\", \\\"{x:1547,y:891,t:1527189250510};\\\", \\\"{x:1547,y:888,t:1527189250526};\\\", \\\"{x:1547,y:885,t:1527189250543};\\\", \\\"{x:1547,y:881,t:1527189250560};\\\", \\\"{x:1546,y:877,t:1527189250576};\\\", \\\"{x:1545,y:874,t:1527189250593};\\\", \\\"{x:1545,y:872,t:1527189250610};\\\", \\\"{x:1545,y:868,t:1527189250626};\\\", \\\"{x:1544,y:866,t:1527189250643};\\\", \\\"{x:1544,y:864,t:1527189250660};\\\", \\\"{x:1544,y:862,t:1527189250676};\\\", \\\"{x:1543,y:861,t:1527189250693};\\\", \\\"{x:1542,y:859,t:1527189250731};\\\", \\\"{x:1542,y:858,t:1527189250756};\\\", \\\"{x:1542,y:856,t:1527189250788};\\\", \\\"{x:1542,y:855,t:1527189250812};\\\", \\\"{x:1542,y:853,t:1527189250828};\\\", \\\"{x:1542,y:852,t:1527189250844};\\\", \\\"{x:1542,y:850,t:1527189250860};\\\", \\\"{x:1542,y:849,t:1527189250884};\\\", \\\"{x:1542,y:847,t:1527189250900};\\\", \\\"{x:1542,y:845,t:1527189250910};\\\", \\\"{x:1542,y:843,t:1527189250932};\\\", \\\"{x:1542,y:842,t:1527189250943};\\\", \\\"{x:1542,y:841,t:1527189250960};\\\", \\\"{x:1543,y:839,t:1527189250977};\\\", \\\"{x:1543,y:837,t:1527189250993};\\\", \\\"{x:1543,y:836,t:1527189251012};\\\", \\\"{x:1543,y:834,t:1527189251044};\\\", \\\"{x:1544,y:833,t:1527189251060};\\\", \\\"{x:1544,y:831,t:1527189251092};\\\", \\\"{x:1544,y:830,t:1527189251116};\\\", \\\"{x:1544,y:828,t:1527189251139};\\\", \\\"{x:1545,y:827,t:1527189251156};\\\", \\\"{x:1545,y:825,t:1527189251180};\\\", \\\"{x:1545,y:824,t:1527189251193};\\\", \\\"{x:1546,y:823,t:1527189251210};\\\", \\\"{x:1546,y:820,t:1527189251227};\\\", \\\"{x:1546,y:814,t:1527189251244};\\\", \\\"{x:1548,y:811,t:1527189251259};\\\", \\\"{x:1548,y:807,t:1527189251276};\\\", \\\"{x:1549,y:805,t:1527189251293};\\\", \\\"{x:1549,y:804,t:1527189251310};\\\", \\\"{x:1549,y:801,t:1527189251327};\\\", \\\"{x:1549,y:800,t:1527189251343};\\\", \\\"{x:1549,y:797,t:1527189251360};\\\", \\\"{x:1549,y:796,t:1527189251380};\\\", \\\"{x:1549,y:795,t:1527189251393};\\\", \\\"{x:1549,y:794,t:1527189251409};\\\", \\\"{x:1549,y:793,t:1527189251427};\\\", \\\"{x:1549,y:791,t:1527189251444};\\\", \\\"{x:1549,y:790,t:1527189251460};\\\", \\\"{x:1549,y:788,t:1527189251477};\\\", \\\"{x:1549,y:785,t:1527189251493};\\\", \\\"{x:1549,y:784,t:1527189251510};\\\", \\\"{x:1549,y:782,t:1527189251527};\\\", \\\"{x:1549,y:781,t:1527189251548};\\\", \\\"{x:1549,y:779,t:1527189251564};\\\", \\\"{x:1549,y:778,t:1527189251581};\\\", \\\"{x:1549,y:776,t:1527189251596};\\\", \\\"{x:1549,y:775,t:1527189251612};\\\", \\\"{x:1549,y:773,t:1527189251627};\\\", \\\"{x:1549,y:772,t:1527189251645};\\\", \\\"{x:1549,y:770,t:1527189251660};\\\", \\\"{x:1549,y:767,t:1527189251677};\\\", \\\"{x:1549,y:766,t:1527189251693};\\\", \\\"{x:1550,y:763,t:1527189251710};\\\", \\\"{x:1550,y:762,t:1527189251727};\\\", \\\"{x:1551,y:760,t:1527189251744};\\\", \\\"{x:1551,y:758,t:1527189251759};\\\", \\\"{x:1552,y:756,t:1527189251777};\\\", \\\"{x:1552,y:753,t:1527189251794};\\\", \\\"{x:1552,y:750,t:1527189251810};\\\", \\\"{x:1552,y:745,t:1527189251827};\\\", \\\"{x:1552,y:739,t:1527189251844};\\\", \\\"{x:1552,y:735,t:1527189251860};\\\", \\\"{x:1552,y:731,t:1527189251877};\\\", \\\"{x:1552,y:728,t:1527189251894};\\\", \\\"{x:1553,y:726,t:1527189251910};\\\", \\\"{x:1553,y:725,t:1527189251927};\\\", \\\"{x:1553,y:723,t:1527189252045};\\\", \\\"{x:1553,y:722,t:1527189252076};\\\", \\\"{x:1553,y:721,t:1527189252094};\\\", \\\"{x:1551,y:719,t:1527189252110};\\\", \\\"{x:1550,y:718,t:1527189252126};\\\", \\\"{x:1549,y:717,t:1527189252144};\\\", \\\"{x:1547,y:715,t:1527189252159};\\\", \\\"{x:1546,y:715,t:1527189252179};\\\", \\\"{x:1545,y:714,t:1527189252211};\\\", \\\"{x:1544,y:713,t:1527189252276};\\\", \\\"{x:1544,y:712,t:1527189252299};\\\", \\\"{x:1544,y:711,t:1527189252380};\\\", \\\"{x:1543,y:710,t:1527189252412};\\\", \\\"{x:1543,y:709,t:1527189253397};\\\", \\\"{x:1544,y:709,t:1527189253411};\\\", \\\"{x:1544,y:708,t:1527189253428};\\\", \\\"{x:1545,y:708,t:1527189253468};\\\", \\\"{x:1545,y:707,t:1527189253812};\\\", \\\"{x:1544,y:707,t:1527189255788};\\\", \\\"{x:1522,y:707,t:1527189255796};\\\", \\\"{x:1381,y:694,t:1527189255812};\\\", \\\"{x:1220,y:663,t:1527189255829};\\\", \\\"{x:1049,y:618,t:1527189255846};\\\", \\\"{x:881,y:573,t:1527189255863};\\\", \\\"{x:740,y:530,t:1527189255879};\\\", \\\"{x:610,y:494,t:1527189255895};\\\", \\\"{x:477,y:469,t:1527189255920};\\\", \\\"{x:448,y:467,t:1527189255936};\\\", \\\"{x:431,y:467,t:1527189255953};\\\", \\\"{x:428,y:467,t:1527189255969};\\\", \\\"{x:427,y:468,t:1527189255987};\\\", \\\"{x:426,y:469,t:1527189256004};\\\", \\\"{x:425,y:470,t:1527189256019};\\\", \\\"{x:423,y:472,t:1527189256037};\\\", \\\"{x:419,y:475,t:1527189256054};\\\", \\\"{x:415,y:478,t:1527189256071};\\\", \\\"{x:407,y:482,t:1527189256086};\\\", \\\"{x:393,y:487,t:1527189256103};\\\", \\\"{x:380,y:492,t:1527189256120};\\\", \\\"{x:371,y:494,t:1527189256137};\\\", \\\"{x:365,y:495,t:1527189256153};\\\", \\\"{x:351,y:498,t:1527189256170};\\\", \\\"{x:343,y:501,t:1527189256186};\\\", \\\"{x:316,y:509,t:1527189256203};\\\", \\\"{x:289,y:514,t:1527189256221};\\\", \\\"{x:262,y:518,t:1527189256237};\\\", \\\"{x:239,y:520,t:1527189256254};\\\", \\\"{x:222,y:523,t:1527189256270};\\\", \\\"{x:212,y:524,t:1527189256287};\\\", \\\"{x:208,y:524,t:1527189256303};\\\", \\\"{x:204,y:524,t:1527189256320};\\\", \\\"{x:201,y:524,t:1527189256336};\\\", \\\"{x:194,y:525,t:1527189256353};\\\", \\\"{x:187,y:526,t:1527189256370};\\\", \\\"{x:172,y:529,t:1527189256386};\\\", \\\"{x:142,y:536,t:1527189256404};\\\", \\\"{x:121,y:540,t:1527189256420};\\\", \\\"{x:104,y:545,t:1527189256437};\\\", \\\"{x:87,y:551,t:1527189256454};\\\", \\\"{x:78,y:552,t:1527189256470};\\\", \\\"{x:76,y:553,t:1527189256487};\\\", \\\"{x:80,y:554,t:1527189256610};\\\", \\\"{x:89,y:554,t:1527189256620};\\\", \\\"{x:105,y:556,t:1527189256637};\\\", \\\"{x:121,y:556,t:1527189256653};\\\", \\\"{x:135,y:559,t:1527189256670};\\\", \\\"{x:144,y:560,t:1527189256687};\\\", \\\"{x:147,y:560,t:1527189256703};\\\", \\\"{x:150,y:560,t:1527189256721};\\\", \\\"{x:154,y:557,t:1527189256737};\\\", \\\"{x:158,y:552,t:1527189256753};\\\", \\\"{x:162,y:541,t:1527189256771};\\\", \\\"{x:162,y:531,t:1527189256787};\\\", \\\"{x:162,y:522,t:1527189256803};\\\", \\\"{x:162,y:518,t:1527189256820};\\\", \\\"{x:162,y:515,t:1527189256837};\\\", \\\"{x:162,y:514,t:1527189256854};\\\", \\\"{x:161,y:513,t:1527189256870};\\\", \\\"{x:160,y:513,t:1527189256887};\\\", \\\"{x:159,y:512,t:1527189256904};\\\", \\\"{x:159,y:510,t:1527189256938};\\\", \\\"{x:159,y:508,t:1527189256955};\\\", \\\"{x:159,y:502,t:1527189256971};\\\", \\\"{x:159,y:498,t:1527189256988};\\\", \\\"{x:159,y:497,t:1527189257004};\\\", \\\"{x:159,y:495,t:1527189257021};\\\", \\\"{x:159,y:494,t:1527189257037};\\\", \\\"{x:159,y:493,t:1527189257054};\\\", \\\"{x:158,y:492,t:1527189257071};\\\", \\\"{x:157,y:491,t:1527189257099};\\\", \\\"{x:157,y:490,t:1527189257124};\\\", \\\"{x:156,y:489,t:1527189257138};\\\", \\\"{x:156,y:488,t:1527189257154};\\\", \\\"{x:157,y:488,t:1527189257587};\\\", \\\"{x:166,y:491,t:1527189257605};\\\", \\\"{x:179,y:497,t:1527189257622};\\\", \\\"{x:199,y:508,t:1527189257639};\\\", \\\"{x:225,y:520,t:1527189257655};\\\", \\\"{x:256,y:531,t:1527189257672};\\\", \\\"{x:320,y:548,t:1527189257688};\\\", \\\"{x:420,y:568,t:1527189257704};\\\", \\\"{x:531,y:584,t:1527189257722};\\\", \\\"{x:639,y:594,t:1527189257738};\\\", \\\"{x:748,y:598,t:1527189257754};\\\", \\\"{x:903,y:598,t:1527189257771};\\\", \\\"{x:997,y:598,t:1527189257789};\\\", \\\"{x:1067,y:598,t:1527189257804};\\\", \\\"{x:1104,y:598,t:1527189257822};\\\", \\\"{x:1123,y:598,t:1527189257839};\\\", \\\"{x:1133,y:598,t:1527189257854};\\\", \\\"{x:1137,y:598,t:1527189257871};\\\", \\\"{x:1143,y:599,t:1527189257888};\\\", \\\"{x:1150,y:600,t:1527189257905};\\\", \\\"{x:1154,y:600,t:1527189257922};\\\", \\\"{x:1162,y:601,t:1527189257939};\\\", \\\"{x:1166,y:602,t:1527189257955};\\\", \\\"{x:1168,y:603,t:1527189258060};\\\", \\\"{x:1172,y:604,t:1527189258072};\\\", \\\"{x:1183,y:607,t:1527189258089};\\\", \\\"{x:1204,y:615,t:1527189258105};\\\", \\\"{x:1230,y:628,t:1527189258122};\\\", \\\"{x:1269,y:652,t:1527189258139};\\\", \\\"{x:1304,y:673,t:1527189258155};\\\", \\\"{x:1310,y:677,t:1527189258172};\\\", \\\"{x:1312,y:677,t:1527189258189};\\\", \\\"{x:1315,y:677,t:1527189258364};\\\", \\\"{x:1316,y:677,t:1527189258372};\\\", \\\"{x:1318,y:676,t:1527189258389};\\\", \\\"{x:1319,y:676,t:1527189258460};\\\", \\\"{x:1320,y:675,t:1527189258472};\\\", \\\"{x:1320,y:671,t:1527189258489};\\\", \\\"{x:1319,y:667,t:1527189258506};\\\", \\\"{x:1318,y:665,t:1527189258522};\\\", \\\"{x:1314,y:661,t:1527189258539};\\\", \\\"{x:1313,y:659,t:1527189258557};\\\", \\\"{x:1315,y:659,t:1527189258684};\\\", \\\"{x:1318,y:658,t:1527189258692};\\\", \\\"{x:1323,y:657,t:1527189258706};\\\", \\\"{x:1327,y:655,t:1527189258722};\\\", \\\"{x:1330,y:653,t:1527189258739};\\\", \\\"{x:1331,y:653,t:1527189258756};\\\", \\\"{x:1333,y:653,t:1527189258972};\\\", \\\"{x:1335,y:652,t:1527189258989};\\\", \\\"{x:1336,y:651,t:1527189259007};\\\", \\\"{x:1337,y:651,t:1527189259024};\\\", \\\"{x:1338,y:651,t:1527189259039};\\\", \\\"{x:1339,y:651,t:1527189259116};\\\", \\\"{x:1341,y:651,t:1527189259356};\\\", \\\"{x:1345,y:651,t:1527189259373};\\\", \\\"{x:1348,y:651,t:1527189259390};\\\", \\\"{x:1349,y:651,t:1527189259492};\\\", \\\"{x:1349,y:650,t:1527189259508};\\\", \\\"{x:1347,y:649,t:1527189259523};\\\", \\\"{x:1347,y:646,t:1527189260404};\\\", \\\"{x:1347,y:634,t:1527189260412};\\\", \\\"{x:1347,y:625,t:1527189260424};\\\", \\\"{x:1343,y:613,t:1527189260441};\\\", \\\"{x:1340,y:600,t:1527189260457};\\\", \\\"{x:1336,y:594,t:1527189260474};\\\", \\\"{x:1334,y:587,t:1527189260491};\\\", \\\"{x:1333,y:584,t:1527189260507};\\\", \\\"{x:1331,y:580,t:1527189260523};\\\", \\\"{x:1331,y:579,t:1527189260540};\\\", \\\"{x:1330,y:578,t:1527189260563};\\\", \\\"{x:1329,y:578,t:1527189260574};\\\", \\\"{x:1329,y:577,t:1527189260603};\\\", \\\"{x:1328,y:576,t:1527189260612};\\\", \\\"{x:1327,y:575,t:1527189260624};\\\", \\\"{x:1325,y:571,t:1527189260640};\\\", \\\"{x:1323,y:567,t:1527189260657};\\\", \\\"{x:1320,y:562,t:1527189260674};\\\", \\\"{x:1318,y:554,t:1527189260691};\\\", \\\"{x:1314,y:540,t:1527189260708};\\\", \\\"{x:1309,y:531,t:1527189260724};\\\", \\\"{x:1303,y:521,t:1527189260741};\\\", \\\"{x:1298,y:516,t:1527189260758};\\\", \\\"{x:1293,y:510,t:1527189260775};\\\", \\\"{x:1289,y:506,t:1527189260790};\\\", \\\"{x:1288,y:504,t:1527189260807};\\\", \\\"{x:1285,y:502,t:1527189260824};\\\", \\\"{x:1283,y:501,t:1527189260840};\\\", \\\"{x:1279,y:500,t:1527189260857};\\\", \\\"{x:1277,y:500,t:1527189260940};\\\", \\\"{x:1276,y:500,t:1527189261083};\\\", \\\"{x:1276,y:501,t:1527189261091};\\\", \\\"{x:1276,y:502,t:1527189261115};\\\", \\\"{x:1276,y:504,t:1527189261124};\\\", \\\"{x:1276,y:505,t:1527189261141};\\\", \\\"{x:1275,y:506,t:1527189262956};\\\", \\\"{x:1275,y:507,t:1527189262964};\\\", \\\"{x:1273,y:510,t:1527189262976};\\\", \\\"{x:1272,y:512,t:1527189262993};\\\", \\\"{x:1272,y:514,t:1527189263010};\\\", \\\"{x:1272,y:515,t:1527189263228};\\\", \\\"{x:1273,y:515,t:1527189263244};\\\", \\\"{x:1274,y:515,t:1527189263260};\\\", \\\"{x:1275,y:515,t:1527189263275};\\\", \\\"{x:1276,y:515,t:1527189263324};\\\", \\\"{x:1277,y:514,t:1527189263484};\\\", \\\"{x:1278,y:514,t:1527189264212};\\\", \\\"{x:1280,y:513,t:1527189264372};\\\", \\\"{x:1281,y:513,t:1527189264452};\\\", \\\"{x:1281,y:514,t:1527189264771};\\\", \\\"{x:1281,y:515,t:1527189265043};\\\", \\\"{x:1281,y:517,t:1527189265060};\\\", \\\"{x:1281,y:518,t:1527189265077};\\\", \\\"{x:1281,y:520,t:1527189265093};\\\", \\\"{x:1281,y:521,t:1527189265110};\\\", \\\"{x:1281,y:523,t:1527189265127};\\\", \\\"{x:1281,y:526,t:1527189265143};\\\", \\\"{x:1281,y:528,t:1527189265160};\\\", \\\"{x:1281,y:531,t:1527189265177};\\\", \\\"{x:1281,y:533,t:1527189265193};\\\", \\\"{x:1281,y:534,t:1527189265210};\\\", \\\"{x:1281,y:537,t:1527189265227};\\\", \\\"{x:1281,y:539,t:1527189265243};\\\", \\\"{x:1281,y:540,t:1527189265260};\\\", \\\"{x:1281,y:543,t:1527189265277};\\\", \\\"{x:1281,y:546,t:1527189265293};\\\", \\\"{x:1281,y:549,t:1527189265310};\\\", \\\"{x:1281,y:552,t:1527189265328};\\\", \\\"{x:1281,y:554,t:1527189265343};\\\", \\\"{x:1281,y:556,t:1527189265360};\\\", \\\"{x:1281,y:559,t:1527189265377};\\\", \\\"{x:1281,y:562,t:1527189265393};\\\", \\\"{x:1281,y:566,t:1527189265410};\\\", \\\"{x:1281,y:572,t:1527189265427};\\\", \\\"{x:1281,y:577,t:1527189265443};\\\", \\\"{x:1281,y:580,t:1527189265460};\\\", \\\"{x:1281,y:581,t:1527189265478};\\\", \\\"{x:1281,y:583,t:1527189265493};\\\", \\\"{x:1281,y:586,t:1527189265510};\\\", \\\"{x:1281,y:587,t:1527189265527};\\\", \\\"{x:1281,y:590,t:1527189265544};\\\", \\\"{x:1281,y:593,t:1527189265560};\\\", \\\"{x:1281,y:595,t:1527189265576};\\\", \\\"{x:1281,y:599,t:1527189265593};\\\", \\\"{x:1281,y:601,t:1527189265610};\\\", \\\"{x:1281,y:606,t:1527189265626};\\\", \\\"{x:1280,y:610,t:1527189265644};\\\", \\\"{x:1280,y:614,t:1527189265660};\\\", \\\"{x:1280,y:618,t:1527189265677};\\\", \\\"{x:1280,y:621,t:1527189265694};\\\", \\\"{x:1280,y:625,t:1527189265710};\\\", \\\"{x:1280,y:627,t:1527189265727};\\\", \\\"{x:1280,y:630,t:1527189265744};\\\", \\\"{x:1280,y:632,t:1527189265760};\\\", \\\"{x:1280,y:634,t:1527189265777};\\\", \\\"{x:1280,y:635,t:1527189265794};\\\", \\\"{x:1280,y:638,t:1527189265810};\\\", \\\"{x:1280,y:643,t:1527189265827};\\\", \\\"{x:1280,y:644,t:1527189265845};\\\", \\\"{x:1280,y:645,t:1527189265860};\\\", \\\"{x:1279,y:645,t:1527189265877};\\\", \\\"{x:1279,y:646,t:1527189265894};\\\", \\\"{x:1279,y:647,t:1527189265910};\\\", \\\"{x:1278,y:649,t:1527189265927};\\\", \\\"{x:1278,y:652,t:1527189265945};\\\", \\\"{x:1278,y:654,t:1527189265960};\\\", \\\"{x:1278,y:657,t:1527189265977};\\\", \\\"{x:1278,y:659,t:1527189265994};\\\", \\\"{x:1278,y:661,t:1527189266009};\\\", \\\"{x:1278,y:663,t:1527189266026};\\\", \\\"{x:1278,y:664,t:1527189266044};\\\", \\\"{x:1278,y:666,t:1527189266060};\\\", \\\"{x:1278,y:667,t:1527189266077};\\\", \\\"{x:1278,y:669,t:1527189266094};\\\", \\\"{x:1278,y:670,t:1527189266111};\\\", \\\"{x:1278,y:672,t:1527189266127};\\\", \\\"{x:1278,y:675,t:1527189266144};\\\", \\\"{x:1278,y:676,t:1527189266161};\\\", \\\"{x:1278,y:679,t:1527189266177};\\\", \\\"{x:1278,y:681,t:1527189266194};\\\", \\\"{x:1278,y:685,t:1527189266211};\\\", \\\"{x:1279,y:688,t:1527189266227};\\\", \\\"{x:1279,y:692,t:1527189266244};\\\", \\\"{x:1279,y:696,t:1527189266261};\\\", \\\"{x:1280,y:700,t:1527189266277};\\\", \\\"{x:1280,y:703,t:1527189266294};\\\", \\\"{x:1280,y:707,t:1527189266311};\\\", \\\"{x:1280,y:712,t:1527189266327};\\\", \\\"{x:1280,y:718,t:1527189266344};\\\", \\\"{x:1280,y:721,t:1527189266361};\\\", \\\"{x:1280,y:724,t:1527189266377};\\\", \\\"{x:1280,y:725,t:1527189266395};\\\", \\\"{x:1280,y:726,t:1527189266411};\\\", \\\"{x:1280,y:727,t:1527189266428};\\\", \\\"{x:1280,y:728,t:1527189266444};\\\", \\\"{x:1281,y:731,t:1527189266461};\\\", \\\"{x:1281,y:732,t:1527189266483};\\\", \\\"{x:1281,y:733,t:1527189266494};\\\", \\\"{x:1281,y:734,t:1527189266511};\\\", \\\"{x:1281,y:736,t:1527189266527};\\\", \\\"{x:1281,y:739,t:1527189266544};\\\", \\\"{x:1281,y:740,t:1527189266561};\\\", \\\"{x:1281,y:743,t:1527189266578};\\\", \\\"{x:1281,y:747,t:1527189266594};\\\", \\\"{x:1281,y:753,t:1527189266611};\\\", \\\"{x:1281,y:756,t:1527189266628};\\\", \\\"{x:1281,y:760,t:1527189266644};\\\", \\\"{x:1281,y:762,t:1527189266661};\\\", \\\"{x:1281,y:764,t:1527189266678};\\\", \\\"{x:1281,y:767,t:1527189266694};\\\", \\\"{x:1281,y:769,t:1527189266711};\\\", \\\"{x:1281,y:770,t:1527189266728};\\\", \\\"{x:1281,y:772,t:1527189266744};\\\", \\\"{x:1281,y:773,t:1527189266771};\\\", \\\"{x:1281,y:775,t:1527189266803};\\\", \\\"{x:1281,y:776,t:1527189266819};\\\", \\\"{x:1281,y:778,t:1527189266842};\\\", \\\"{x:1281,y:779,t:1527189266858};\\\", \\\"{x:1281,y:781,t:1527189266874};\\\", \\\"{x:1281,y:782,t:1527189266890};\\\", \\\"{x:1281,y:784,t:1527189266907};\\\", \\\"{x:1281,y:785,t:1527189266922};\\\", \\\"{x:1281,y:787,t:1527189266939};\\\", \\\"{x:1281,y:789,t:1527189266954};\\\", \\\"{x:1281,y:790,t:1527189266963};\\\", \\\"{x:1281,y:791,t:1527189266978};\\\", \\\"{x:1281,y:794,t:1527189266995};\\\", \\\"{x:1281,y:798,t:1527189267011};\\\", \\\"{x:1281,y:800,t:1527189267028};\\\", \\\"{x:1281,y:803,t:1527189267045};\\\", \\\"{x:1281,y:804,t:1527189267062};\\\", \\\"{x:1281,y:806,t:1527189267078};\\\", \\\"{x:1281,y:808,t:1527189267094};\\\", \\\"{x:1281,y:811,t:1527189267112};\\\", \\\"{x:1281,y:813,t:1527189267128};\\\", \\\"{x:1281,y:814,t:1527189267146};\\\", \\\"{x:1281,y:818,t:1527189267162};\\\", \\\"{x:1281,y:823,t:1527189267178};\\\", \\\"{x:1281,y:831,t:1527189267195};\\\", \\\"{x:1281,y:836,t:1527189267211};\\\", \\\"{x:1281,y:842,t:1527189267229};\\\", \\\"{x:1281,y:848,t:1527189267246};\\\", \\\"{x:1281,y:856,t:1527189267261};\\\", \\\"{x:1280,y:862,t:1527189267278};\\\", \\\"{x:1279,y:866,t:1527189267296};\\\", \\\"{x:1278,y:871,t:1527189267311};\\\", \\\"{x:1278,y:874,t:1527189267328};\\\", \\\"{x:1278,y:875,t:1527189267345};\\\", \\\"{x:1278,y:876,t:1527189267361};\\\", \\\"{x:1278,y:877,t:1527189267388};\\\", \\\"{x:1278,y:878,t:1527189267420};\\\", \\\"{x:1278,y:879,t:1527189267429};\\\", \\\"{x:1278,y:881,t:1527189267445};\\\", \\\"{x:1278,y:883,t:1527189267461};\\\", \\\"{x:1278,y:888,t:1527189267478};\\\", \\\"{x:1278,y:892,t:1527189267496};\\\", \\\"{x:1278,y:898,t:1527189267511};\\\", \\\"{x:1279,y:902,t:1527189267529};\\\", \\\"{x:1280,y:904,t:1527189267546};\\\", \\\"{x:1281,y:905,t:1527189267562};\\\", \\\"{x:1282,y:906,t:1527189267604};\\\", \\\"{x:1282,y:907,t:1527189267708};\\\", \\\"{x:1282,y:908,t:1527189267732};\\\", \\\"{x:1282,y:909,t:1527189267755};\\\", \\\"{x:1282,y:910,t:1527189267780};\\\", \\\"{x:1282,y:911,t:1527189267795};\\\", \\\"{x:1282,y:912,t:1527189267835};\\\", \\\"{x:1280,y:911,t:1527189275868};\\\", \\\"{x:1165,y:884,t:1527189275885};\\\", \\\"{x:1043,y:863,t:1527189275901};\\\", \\\"{x:924,y:848,t:1527189275918};\\\", \\\"{x:799,y:828,t:1527189275934};\\\", \\\"{x:657,y:806,t:1527189275951};\\\", \\\"{x:531,y:779,t:1527189275967};\\\", \\\"{x:462,y:759,t:1527189275985};\\\", \\\"{x:445,y:752,t:1527189276001};\\\", \\\"{x:444,y:750,t:1527189276017};\\\", \\\"{x:444,y:749,t:1527189276051};\\\", \\\"{x:445,y:748,t:1527189276075};\\\", \\\"{x:445,y:747,t:1527189276115};\\\", \\\"{x:446,y:746,t:1527189276123};\\\", \\\"{x:447,y:746,t:1527189276135};\\\", \\\"{x:449,y:745,t:1527189276200};\\\", \\\"{x:451,y:742,t:1527189276207};\\\", \\\"{x:452,y:740,t:1527189276221};\\\", \\\"{x:461,y:730,t:1527189276239};\\\", \\\"{x:470,y:719,t:1527189276254};\\\", \\\"{x:490,y:701,t:1527189276272};\\\", \\\"{x:512,y:673,t:1527189276288};\\\", \\\"{x:521,y:665,t:1527189276304};\\\", \\\"{x:522,y:663,t:1527189276321};\\\", \\\"{x:522,y:666,t:1527189276479};\\\", \\\"{x:522,y:670,t:1527189276491};\\\", \\\"{x:522,y:678,t:1527189276507};\\\", \\\"{x:523,y:683,t:1527189276524};\\\", \\\"{x:523,y:686,t:1527189276541};\\\", \\\"{x:524,y:687,t:1527189276624};\\\" ] }, { \\\"rt\\\": 72319, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 733993, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -M -M -J -I -I -I -B -B -12 PM-12 PM-B -F -F -12 PM-F -F -C -F -E -11 AM-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:694,t:1527189278542};\\\", \\\"{x:491,y:694,t:1527189278552};\\\", \\\"{x:486,y:694,t:1527189278560};\\\", \\\"{x:482,y:694,t:1527189278577};\\\", \\\"{x:480,y:694,t:1527189278593};\\\", \\\"{x:481,y:694,t:1527189284471};\\\", \\\"{x:492,y:694,t:1527189284479};\\\", \\\"{x:524,y:689,t:1527189284497};\\\", \\\"{x:574,y:681,t:1527189284515};\\\", \\\"{x:653,y:680,t:1527189284530};\\\", \\\"{x:744,y:680,t:1527189284546};\\\", \\\"{x:860,y:680,t:1527189284563};\\\", \\\"{x:996,y:680,t:1527189284580};\\\", \\\"{x:1121,y:680,t:1527189284598};\\\", \\\"{x:1292,y:680,t:1527189284614};\\\", \\\"{x:1389,y:680,t:1527189284631};\\\", \\\"{x:1467,y:680,t:1527189284647};\\\", \\\"{x:1518,y:680,t:1527189284665};\\\", \\\"{x:1549,y:680,t:1527189284680};\\\", \\\"{x:1570,y:680,t:1527189284698};\\\", \\\"{x:1582,y:675,t:1527189284714};\\\", \\\"{x:1584,y:672,t:1527189284731};\\\", \\\"{x:1583,y:675,t:1527189285102};\\\", \\\"{x:1582,y:676,t:1527189285118};\\\", \\\"{x:1582,y:679,t:1527189285131};\\\", \\\"{x:1580,y:690,t:1527189285148};\\\", \\\"{x:1580,y:703,t:1527189285164};\\\", \\\"{x:1579,y:723,t:1527189285181};\\\", \\\"{x:1574,y:742,t:1527189285197};\\\", \\\"{x:1563,y:771,t:1527189285214};\\\", \\\"{x:1553,y:791,t:1527189285231};\\\", \\\"{x:1542,y:807,t:1527189285248};\\\", \\\"{x:1529,y:821,t:1527189285265};\\\", \\\"{x:1513,y:838,t:1527189285282};\\\", \\\"{x:1499,y:852,t:1527189285299};\\\", \\\"{x:1488,y:859,t:1527189285315};\\\", \\\"{x:1477,y:866,t:1527189285332};\\\", \\\"{x:1470,y:876,t:1527189285349};\\\", \\\"{x:1464,y:882,t:1527189285365};\\\", \\\"{x:1462,y:884,t:1527189285381};\\\", \\\"{x:1462,y:886,t:1527189285399};\\\", \\\"{x:1463,y:886,t:1527189285536};\\\", \\\"{x:1464,y:888,t:1527189285549};\\\", \\\"{x:1469,y:890,t:1527189285564};\\\", \\\"{x:1473,y:892,t:1527189285582};\\\", \\\"{x:1479,y:895,t:1527189285599};\\\", \\\"{x:1479,y:897,t:1527189285615};\\\", \\\"{x:1481,y:898,t:1527189285631};\\\", \\\"{x:1481,y:900,t:1527189285687};\\\", \\\"{x:1481,y:901,t:1527189285776};\\\", \\\"{x:1481,y:904,t:1527189285791};\\\", \\\"{x:1481,y:906,t:1527189285816};\\\", \\\"{x:1481,y:907,t:1527189285832};\\\", \\\"{x:1481,y:908,t:1527189285849};\\\", \\\"{x:1481,y:909,t:1527189285866};\\\", \\\"{x:1481,y:910,t:1527189285882};\\\", \\\"{x:1480,y:905,t:1527189292191};\\\", \\\"{x:1478,y:901,t:1527189292204};\\\", \\\"{x:1476,y:887,t:1527189292220};\\\", \\\"{x:1473,y:876,t:1527189292237};\\\", \\\"{x:1472,y:864,t:1527189292255};\\\", \\\"{x:1472,y:861,t:1527189292270};\\\", \\\"{x:1472,y:857,t:1527189292287};\\\", \\\"{x:1473,y:855,t:1527189292304};\\\", \\\"{x:1473,y:853,t:1527189292321};\\\", \\\"{x:1474,y:850,t:1527189292338};\\\", \\\"{x:1475,y:849,t:1527189292354};\\\", \\\"{x:1476,y:847,t:1527189292371};\\\", \\\"{x:1476,y:846,t:1527189292391};\\\", \\\"{x:1476,y:845,t:1527189292405};\\\", \\\"{x:1477,y:842,t:1527189292422};\\\", \\\"{x:1478,y:840,t:1527189292438};\\\", \\\"{x:1479,y:837,t:1527189292462};\\\", \\\"{x:1479,y:838,t:1527189292672};\\\", \\\"{x:1479,y:842,t:1527189292688};\\\", \\\"{x:1479,y:845,t:1527189292704};\\\", \\\"{x:1479,y:846,t:1527189292721};\\\", \\\"{x:1478,y:847,t:1527189292739};\\\", \\\"{x:1477,y:847,t:1527189294376};\\\", \\\"{x:1473,y:847,t:1527189294389};\\\", \\\"{x:1454,y:847,t:1527189294406};\\\", \\\"{x:1412,y:847,t:1527189294422};\\\", \\\"{x:1383,y:848,t:1527189294442};\\\", \\\"{x:1365,y:849,t:1527189294456};\\\", \\\"{x:1356,y:849,t:1527189294472};\\\", \\\"{x:1355,y:849,t:1527189294489};\\\", \\\"{x:1356,y:849,t:1527189294782};\\\", \\\"{x:1357,y:849,t:1527189294791};\\\", \\\"{x:1359,y:849,t:1527189294807};\\\", \\\"{x:1360,y:849,t:1527189294823};\\\", \\\"{x:1361,y:849,t:1527189294840};\\\", \\\"{x:1362,y:849,t:1527189294912};\\\", \\\"{x:1363,y:849,t:1527189294923};\\\", \\\"{x:1366,y:849,t:1527189294939};\\\", \\\"{x:1370,y:849,t:1527189294957};\\\", \\\"{x:1372,y:849,t:1527189294974};\\\", \\\"{x:1374,y:849,t:1527189294991};\\\", \\\"{x:1375,y:849,t:1527189295007};\\\", \\\"{x:1376,y:849,t:1527189295102};\\\", \\\"{x:1377,y:849,t:1527189295110};\\\", \\\"{x:1378,y:849,t:1527189295123};\\\", \\\"{x:1379,y:849,t:1527189295960};\\\", \\\"{x:1379,y:848,t:1527189295974};\\\", \\\"{x:1379,y:840,t:1527189295990};\\\", \\\"{x:1379,y:838,t:1527189296008};\\\", \\\"{x:1379,y:837,t:1527189296024};\\\", \\\"{x:1380,y:840,t:1527189296976};\\\", \\\"{x:1381,y:846,t:1527189296991};\\\", \\\"{x:1383,y:853,t:1527189297008};\\\", \\\"{x:1390,y:861,t:1527189297024};\\\", \\\"{x:1397,y:864,t:1527189297041};\\\", \\\"{x:1401,y:866,t:1527189297058};\\\", \\\"{x:1402,y:866,t:1527189297074};\\\", \\\"{x:1403,y:867,t:1527189297136};\\\", \\\"{x:1404,y:867,t:1527189297143};\\\", \\\"{x:1412,y:864,t:1527189297159};\\\", \\\"{x:1422,y:858,t:1527189297175};\\\", \\\"{x:1428,y:853,t:1527189297191};\\\", \\\"{x:1434,y:849,t:1527189297209};\\\", \\\"{x:1435,y:847,t:1527189297225};\\\", \\\"{x:1437,y:845,t:1527189297242};\\\", \\\"{x:1438,y:845,t:1527189297259};\\\", \\\"{x:1439,y:844,t:1527189297274};\\\", \\\"{x:1440,y:844,t:1527189297292};\\\", \\\"{x:1442,y:842,t:1527189297308};\\\", \\\"{x:1445,y:841,t:1527189297324};\\\", \\\"{x:1449,y:840,t:1527189297341};\\\", \\\"{x:1451,y:839,t:1527189297359};\\\", \\\"{x:1456,y:838,t:1527189297374};\\\", \\\"{x:1457,y:837,t:1527189297519};\\\", \\\"{x:1457,y:836,t:1527189297527};\\\", \\\"{x:1456,y:835,t:1527189297542};\\\", \\\"{x:1449,y:834,t:1527189297559};\\\", \\\"{x:1445,y:834,t:1527189297575};\\\", \\\"{x:1443,y:834,t:1527189297592};\\\", \\\"{x:1442,y:834,t:1527189297609};\\\", \\\"{x:1441,y:834,t:1527189297630};\\\", \\\"{x:1440,y:834,t:1527189297642};\\\", \\\"{x:1440,y:835,t:1527189298495};\\\", \\\"{x:1441,y:837,t:1527189298510};\\\", \\\"{x:1444,y:838,t:1527189298526};\\\", \\\"{x:1446,y:839,t:1527189298542};\\\", \\\"{x:1447,y:840,t:1527189298567};\\\", \\\"{x:1447,y:841,t:1527189298591};\\\", \\\"{x:1447,y:842,t:1527189298599};\\\", \\\"{x:1447,y:843,t:1527189298623};\\\", \\\"{x:1447,y:844,t:1527189298631};\\\", \\\"{x:1448,y:845,t:1527189298643};\\\", \\\"{x:1450,y:843,t:1527189302424};\\\", \\\"{x:1450,y:838,t:1527189302431};\\\", \\\"{x:1452,y:831,t:1527189302446};\\\", \\\"{x:1457,y:807,t:1527189302463};\\\", \\\"{x:1457,y:790,t:1527189302479};\\\", \\\"{x:1457,y:774,t:1527189302495};\\\", \\\"{x:1456,y:760,t:1527189302512};\\\", \\\"{x:1454,y:753,t:1527189302528};\\\", \\\"{x:1454,y:752,t:1527189302545};\\\", \\\"{x:1454,y:751,t:1527189302590};\\\", \\\"{x:1453,y:751,t:1527189302638};\\\", \\\"{x:1452,y:751,t:1527189302662};\\\", \\\"{x:1451,y:751,t:1527189302711};\\\", \\\"{x:1451,y:753,t:1527189302718};\\\", \\\"{x:1450,y:755,t:1527189302729};\\\", \\\"{x:1450,y:757,t:1527189302746};\\\", \\\"{x:1449,y:758,t:1527189302763};\\\", \\\"{x:1448,y:759,t:1527189302779};\\\", \\\"{x:1447,y:761,t:1527189302796};\\\", \\\"{x:1446,y:764,t:1527189302813};\\\", \\\"{x:1445,y:767,t:1527189302830};\\\", \\\"{x:1444,y:769,t:1527189302846};\\\", \\\"{x:1444,y:771,t:1527189302863};\\\", \\\"{x:1444,y:772,t:1527189303207};\\\", \\\"{x:1443,y:773,t:1527189303215};\\\", \\\"{x:1442,y:775,t:1527189303230};\\\", \\\"{x:1424,y:782,t:1527189303247};\\\", \\\"{x:1407,y:786,t:1527189303262};\\\", \\\"{x:1390,y:792,t:1527189303280};\\\", \\\"{x:1378,y:797,t:1527189303296};\\\", \\\"{x:1372,y:798,t:1527189303313};\\\", \\\"{x:1368,y:801,t:1527189303330};\\\", \\\"{x:1364,y:802,t:1527189303347};\\\", \\\"{x:1357,y:804,t:1527189303362};\\\", \\\"{x:1347,y:805,t:1527189303380};\\\", \\\"{x:1332,y:806,t:1527189303396};\\\", \\\"{x:1308,y:806,t:1527189303412};\\\", \\\"{x:1280,y:806,t:1527189303430};\\\", \\\"{x:1223,y:806,t:1527189303447};\\\", \\\"{x:1189,y:806,t:1527189303463};\\\", \\\"{x:1173,y:806,t:1527189303480};\\\", \\\"{x:1169,y:806,t:1527189303497};\\\", \\\"{x:1169,y:805,t:1527189303535};\\\", \\\"{x:1170,y:804,t:1527189303547};\\\", \\\"{x:1177,y:800,t:1527189303562};\\\", \\\"{x:1190,y:794,t:1527189303580};\\\", \\\"{x:1200,y:790,t:1527189303596};\\\", \\\"{x:1205,y:787,t:1527189303613};\\\", \\\"{x:1206,y:786,t:1527189303630};\\\", \\\"{x:1207,y:785,t:1527189303839};\\\", \\\"{x:1208,y:783,t:1527189303854};\\\", \\\"{x:1209,y:783,t:1527189303863};\\\", \\\"{x:1211,y:782,t:1527189303879};\\\", \\\"{x:1213,y:781,t:1527189303897};\\\", \\\"{x:1213,y:780,t:1527189303913};\\\", \\\"{x:1213,y:779,t:1527189303930};\\\", \\\"{x:1214,y:779,t:1527189303946};\\\", \\\"{x:1215,y:778,t:1527189304166};\\\", \\\"{x:1216,y:777,t:1527189304179};\\\", \\\"{x:1216,y:776,t:1527189304197};\\\", \\\"{x:1218,y:774,t:1527189304214};\\\", \\\"{x:1219,y:774,t:1527189304271};\\\", \\\"{x:1221,y:774,t:1527189304944};\\\", \\\"{x:1223,y:775,t:1527189304951};\\\", \\\"{x:1225,y:775,t:1527189304963};\\\", \\\"{x:1226,y:776,t:1527189304980};\\\", \\\"{x:1226,y:775,t:1527189305511};\\\", \\\"{x:1224,y:773,t:1527189305519};\\\", \\\"{x:1222,y:768,t:1527189305531};\\\", \\\"{x:1219,y:759,t:1527189305548};\\\", \\\"{x:1214,y:751,t:1527189305565};\\\", \\\"{x:1210,y:744,t:1527189305582};\\\", \\\"{x:1209,y:739,t:1527189305598};\\\", \\\"{x:1208,y:736,t:1527189305615};\\\", \\\"{x:1207,y:732,t:1527189305631};\\\", \\\"{x:1204,y:726,t:1527189305648};\\\", \\\"{x:1200,y:722,t:1527189305665};\\\", \\\"{x:1195,y:719,t:1527189305682};\\\", \\\"{x:1189,y:715,t:1527189305697};\\\", \\\"{x:1186,y:712,t:1527189305715};\\\", \\\"{x:1181,y:709,t:1527189305732};\\\", \\\"{x:1177,y:708,t:1527189305748};\\\", \\\"{x:1174,y:705,t:1527189305766};\\\", \\\"{x:1173,y:704,t:1527189305781};\\\", \\\"{x:1172,y:702,t:1527189305798};\\\", \\\"{x:1173,y:702,t:1527189305959};\\\", \\\"{x:1174,y:703,t:1527189305966};\\\", \\\"{x:1176,y:704,t:1527189305981};\\\", \\\"{x:1183,y:715,t:1527189305999};\\\", \\\"{x:1192,y:724,t:1527189306016};\\\", \\\"{x:1198,y:730,t:1527189306031};\\\", \\\"{x:1201,y:736,t:1527189306049};\\\", \\\"{x:1205,y:741,t:1527189306065};\\\", \\\"{x:1213,y:749,t:1527189306082};\\\", \\\"{x:1224,y:760,t:1527189306098};\\\", \\\"{x:1236,y:767,t:1527189306115};\\\", \\\"{x:1247,y:772,t:1527189306132};\\\", \\\"{x:1256,y:775,t:1527189306148};\\\", \\\"{x:1265,y:776,t:1527189306165};\\\", \\\"{x:1268,y:777,t:1527189306181};\\\", \\\"{x:1279,y:777,t:1527189306198};\\\", \\\"{x:1295,y:777,t:1527189306215};\\\", \\\"{x:1310,y:777,t:1527189306232};\\\", \\\"{x:1325,y:777,t:1527189306249};\\\", \\\"{x:1343,y:771,t:1527189306265};\\\", \\\"{x:1358,y:763,t:1527189306282};\\\", \\\"{x:1370,y:757,t:1527189306299};\\\", \\\"{x:1377,y:752,t:1527189306316};\\\", \\\"{x:1382,y:747,t:1527189306332};\\\", \\\"{x:1385,y:744,t:1527189306349};\\\", \\\"{x:1386,y:738,t:1527189306366};\\\", \\\"{x:1387,y:734,t:1527189306382};\\\", \\\"{x:1387,y:727,t:1527189306399};\\\", \\\"{x:1387,y:723,t:1527189306416};\\\", \\\"{x:1386,y:718,t:1527189306432};\\\", \\\"{x:1382,y:715,t:1527189306449};\\\", \\\"{x:1376,y:711,t:1527189306466};\\\", \\\"{x:1371,y:709,t:1527189306482};\\\", \\\"{x:1368,y:708,t:1527189306499};\\\", \\\"{x:1366,y:706,t:1527189306516};\\\", \\\"{x:1365,y:705,t:1527189306559};\\\", \\\"{x:1364,y:705,t:1527189306567};\\\", \\\"{x:1363,y:704,t:1527189306582};\\\", \\\"{x:1361,y:704,t:1527189306599};\\\", \\\"{x:1359,y:703,t:1527189306623};\\\", \\\"{x:1358,y:702,t:1527189306638};\\\", \\\"{x:1357,y:702,t:1527189306654};\\\", \\\"{x:1356,y:702,t:1527189306671};\\\", \\\"{x:1355,y:702,t:1527189306695};\\\", \\\"{x:1354,y:702,t:1527189306702};\\\", \\\"{x:1353,y:702,t:1527189306716};\\\", \\\"{x:1352,y:702,t:1527189306743};\\\", \\\"{x:1351,y:702,t:1527189306750};\\\", \\\"{x:1350,y:703,t:1527189306766};\\\", \\\"{x:1350,y:704,t:1527189306782};\\\", \\\"{x:1349,y:704,t:1527189307559};\\\", \\\"{x:1347,y:707,t:1527189308872};\\\", \\\"{x:1345,y:709,t:1527189308884};\\\", \\\"{x:1342,y:713,t:1527189308902};\\\", \\\"{x:1340,y:717,t:1527189308917};\\\", \\\"{x:1339,y:721,t:1527189308934};\\\", \\\"{x:1336,y:727,t:1527189308950};\\\", \\\"{x:1336,y:728,t:1527189308968};\\\", \\\"{x:1335,y:729,t:1527189308984};\\\", \\\"{x:1335,y:730,t:1527189309014};\\\", \\\"{x:1335,y:731,t:1527189309023};\\\", \\\"{x:1335,y:732,t:1527189309034};\\\", \\\"{x:1333,y:734,t:1527189309051};\\\", \\\"{x:1332,y:738,t:1527189309067};\\\", \\\"{x:1331,y:741,t:1527189309084};\\\", \\\"{x:1330,y:744,t:1527189309101};\\\", \\\"{x:1330,y:746,t:1527189309118};\\\", \\\"{x:1329,y:749,t:1527189309133};\\\", \\\"{x:1328,y:753,t:1527189309151};\\\", \\\"{x:1328,y:756,t:1527189309168};\\\", \\\"{x:1328,y:757,t:1527189309184};\\\", \\\"{x:1328,y:760,t:1527189309201};\\\", \\\"{x:1327,y:760,t:1527189309218};\\\", \\\"{x:1326,y:761,t:1527189309234};\\\", \\\"{x:1326,y:762,t:1527189309251};\\\", \\\"{x:1326,y:763,t:1527189309268};\\\", \\\"{x:1326,y:765,t:1527189309284};\\\", \\\"{x:1326,y:766,t:1527189309301};\\\", \\\"{x:1327,y:768,t:1527189309318};\\\", \\\"{x:1329,y:769,t:1527189309334};\\\", \\\"{x:1332,y:770,t:1527189309350};\\\", \\\"{x:1333,y:770,t:1527189309368};\\\", \\\"{x:1334,y:770,t:1527189309384};\\\", \\\"{x:1335,y:770,t:1527189309406};\\\", \\\"{x:1336,y:772,t:1527189309418};\\\", \\\"{x:1338,y:772,t:1527189309435};\\\", \\\"{x:1341,y:773,t:1527189309451};\\\", \\\"{x:1343,y:774,t:1527189309468};\\\", \\\"{x:1343,y:775,t:1527189309520};\\\", \\\"{x:1346,y:779,t:1527189309535};\\\", \\\"{x:1348,y:782,t:1527189309551};\\\", \\\"{x:1350,y:789,t:1527189309568};\\\", \\\"{x:1353,y:798,t:1527189309585};\\\", \\\"{x:1356,y:808,t:1527189309601};\\\", \\\"{x:1357,y:817,t:1527189309618};\\\", \\\"{x:1358,y:824,t:1527189309635};\\\", \\\"{x:1360,y:832,t:1527189309651};\\\", \\\"{x:1360,y:838,t:1527189309668};\\\", \\\"{x:1360,y:844,t:1527189309685};\\\", \\\"{x:1360,y:850,t:1527189309701};\\\", \\\"{x:1360,y:855,t:1527189309718};\\\", \\\"{x:1360,y:865,t:1527189309735};\\\", \\\"{x:1360,y:870,t:1527189309751};\\\", \\\"{x:1360,y:876,t:1527189309768};\\\", \\\"{x:1359,y:879,t:1527189309785};\\\", \\\"{x:1359,y:881,t:1527189309801};\\\", \\\"{x:1358,y:884,t:1527189309818};\\\", \\\"{x:1358,y:887,t:1527189309836};\\\", \\\"{x:1357,y:891,t:1527189309851};\\\", \\\"{x:1357,y:895,t:1527189309867};\\\", \\\"{x:1355,y:901,t:1527189309884};\\\", \\\"{x:1354,y:906,t:1527189309901};\\\", \\\"{x:1353,y:910,t:1527189309917};\\\", \\\"{x:1349,y:919,t:1527189309934};\\\", \\\"{x:1349,y:922,t:1527189309952};\\\", \\\"{x:1347,y:925,t:1527189309967};\\\", \\\"{x:1345,y:930,t:1527189309985};\\\", \\\"{x:1344,y:932,t:1527189310002};\\\", \\\"{x:1342,y:935,t:1527189310017};\\\", \\\"{x:1342,y:936,t:1527189310035};\\\", \\\"{x:1342,y:935,t:1527189310126};\\\", \\\"{x:1342,y:931,t:1527189310135};\\\", \\\"{x:1342,y:920,t:1527189310152};\\\", \\\"{x:1342,y:901,t:1527189310169};\\\", \\\"{x:1347,y:883,t:1527189310184};\\\", \\\"{x:1354,y:859,t:1527189310202};\\\", \\\"{x:1358,y:842,t:1527189310218};\\\", \\\"{x:1364,y:824,t:1527189310235};\\\", \\\"{x:1368,y:809,t:1527189310252};\\\", \\\"{x:1369,y:794,t:1527189310268};\\\", \\\"{x:1371,y:783,t:1527189310285};\\\", \\\"{x:1371,y:774,t:1527189310302};\\\", \\\"{x:1372,y:763,t:1527189310319};\\\", \\\"{x:1372,y:761,t:1527189310335};\\\", \\\"{x:1372,y:760,t:1527189310352};\\\", \\\"{x:1372,y:758,t:1527189310423};\\\", \\\"{x:1372,y:755,t:1527189310435};\\\", \\\"{x:1370,y:745,t:1527189310451};\\\", \\\"{x:1366,y:736,t:1527189310469};\\\", \\\"{x:1364,y:732,t:1527189310485};\\\", \\\"{x:1363,y:728,t:1527189310502};\\\", \\\"{x:1361,y:724,t:1527189310518};\\\", \\\"{x:1360,y:719,t:1527189310534};\\\", \\\"{x:1359,y:713,t:1527189310552};\\\", \\\"{x:1358,y:708,t:1527189310569};\\\", \\\"{x:1357,y:705,t:1527189310585};\\\", \\\"{x:1355,y:702,t:1527189310602};\\\", \\\"{x:1355,y:701,t:1527189310619};\\\", \\\"{x:1354,y:701,t:1527189310751};\\\", \\\"{x:1353,y:701,t:1527189310769};\\\", \\\"{x:1352,y:701,t:1527189310799};\\\", \\\"{x:1351,y:701,t:1527189310831};\\\", \\\"{x:1349,y:701,t:1527189310847};\\\", \\\"{x:1348,y:701,t:1527189310911};\\\", \\\"{x:1348,y:699,t:1527189316638};\\\", \\\"{x:1350,y:693,t:1527189316657};\\\", \\\"{x:1351,y:684,t:1527189316674};\\\", \\\"{x:1354,y:675,t:1527189316691};\\\", \\\"{x:1357,y:664,t:1527189316707};\\\", \\\"{x:1357,y:657,t:1527189316723};\\\", \\\"{x:1358,y:654,t:1527189316740};\\\", \\\"{x:1358,y:652,t:1527189316758};\\\", \\\"{x:1358,y:651,t:1527189316773};\\\", \\\"{x:1358,y:649,t:1527189316911};\\\", \\\"{x:1358,y:647,t:1527189316924};\\\", \\\"{x:1358,y:644,t:1527189316940};\\\", \\\"{x:1357,y:641,t:1527189316957};\\\", \\\"{x:1355,y:636,t:1527189316975};\\\", \\\"{x:1354,y:633,t:1527189316991};\\\", \\\"{x:1352,y:631,t:1527189317008};\\\", \\\"{x:1351,y:628,t:1527189317024};\\\", \\\"{x:1350,y:627,t:1527189317040};\\\", \\\"{x:1350,y:628,t:1527189317319};\\\", \\\"{x:1350,y:630,t:1527189317326};\\\", \\\"{x:1350,y:631,t:1527189317341};\\\", \\\"{x:1350,y:633,t:1527189317358};\\\", \\\"{x:1350,y:636,t:1527189317375};\\\", \\\"{x:1351,y:636,t:1527189321871};\\\", \\\"{x:1353,y:637,t:1527189321887};\\\", \\\"{x:1354,y:637,t:1527189321974};\\\", \\\"{x:1356,y:637,t:1527189321990};\\\", \\\"{x:1357,y:637,t:1527189322006};\\\", \\\"{x:1359,y:637,t:1527189322014};\\\", \\\"{x:1361,y:638,t:1527189322030};\\\", \\\"{x:1362,y:638,t:1527189322045};\\\", \\\"{x:1364,y:638,t:1527189322061};\\\", \\\"{x:1373,y:639,t:1527189322079};\\\", \\\"{x:1384,y:639,t:1527189322094};\\\", \\\"{x:1397,y:639,t:1527189322111};\\\", \\\"{x:1408,y:639,t:1527189322129};\\\", \\\"{x:1420,y:639,t:1527189322145};\\\", \\\"{x:1427,y:639,t:1527189322162};\\\", \\\"{x:1429,y:639,t:1527189322178};\\\", \\\"{x:1430,y:639,t:1527189322198};\\\", \\\"{x:1429,y:639,t:1527189322326};\\\", \\\"{x:1426,y:639,t:1527189322334};\\\", \\\"{x:1423,y:639,t:1527189322345};\\\", \\\"{x:1419,y:639,t:1527189322362};\\\", \\\"{x:1417,y:640,t:1527189322379};\\\", \\\"{x:1415,y:641,t:1527189322406};\\\", \\\"{x:1418,y:643,t:1527189322719};\\\", \\\"{x:1421,y:644,t:1527189322729};\\\", \\\"{x:1429,y:645,t:1527189322746};\\\", \\\"{x:1440,y:646,t:1527189322761};\\\", \\\"{x:1452,y:648,t:1527189322778};\\\", \\\"{x:1460,y:649,t:1527189322796};\\\", \\\"{x:1467,y:650,t:1527189322811};\\\", \\\"{x:1471,y:650,t:1527189322828};\\\", \\\"{x:1475,y:650,t:1527189322846};\\\", \\\"{x:1477,y:650,t:1527189322861};\\\", \\\"{x:1478,y:650,t:1527189322879};\\\", \\\"{x:1479,y:650,t:1527189322935};\\\", \\\"{x:1481,y:650,t:1527189322950};\\\", \\\"{x:1482,y:650,t:1527189322967};\\\", \\\"{x:1483,y:650,t:1527189322979};\\\", \\\"{x:1485,y:649,t:1527189322996};\\\", \\\"{x:1486,y:648,t:1527189323013};\\\", \\\"{x:1486,y:647,t:1527189323047};\\\", \\\"{x:1486,y:646,t:1527189323086};\\\", \\\"{x:1486,y:645,t:1527189323159};\\\", \\\"{x:1486,y:643,t:1527189323183};\\\", \\\"{x:1486,y:642,t:1527189323196};\\\", \\\"{x:1484,y:642,t:1527189323215};\\\", \\\"{x:1482,y:641,t:1527189323231};\\\", \\\"{x:1481,y:640,t:1527189323246};\\\", \\\"{x:1480,y:640,t:1527189323287};\\\", \\\"{x:1479,y:639,t:1527189323296};\\\", \\\"{x:1478,y:639,t:1527189326351};\\\", \\\"{x:1474,y:639,t:1527189326365};\\\", \\\"{x:1467,y:642,t:1527189326381};\\\", \\\"{x:1459,y:645,t:1527189326398};\\\", \\\"{x:1450,y:650,t:1527189326415};\\\", \\\"{x:1447,y:653,t:1527189326431};\\\", \\\"{x:1445,y:655,t:1527189326448};\\\", \\\"{x:1444,y:656,t:1527189326470};\\\", \\\"{x:1443,y:657,t:1527189326481};\\\", \\\"{x:1440,y:659,t:1527189326498};\\\", \\\"{x:1438,y:661,t:1527189326515};\\\", \\\"{x:1434,y:663,t:1527189326531};\\\", \\\"{x:1432,y:663,t:1527189326549};\\\", \\\"{x:1424,y:664,t:1527189326564};\\\", \\\"{x:1416,y:664,t:1527189326581};\\\", \\\"{x:1399,y:664,t:1527189326598};\\\", \\\"{x:1391,y:664,t:1527189326615};\\\", \\\"{x:1386,y:664,t:1527189326632};\\\", \\\"{x:1383,y:664,t:1527189326649};\\\", \\\"{x:1382,y:664,t:1527189326664};\\\", \\\"{x:1381,y:664,t:1527189326694};\\\", \\\"{x:1379,y:663,t:1527189326710};\\\", \\\"{x:1377,y:663,t:1527189326750};\\\", \\\"{x:1376,y:662,t:1527189326774};\\\", \\\"{x:1375,y:662,t:1527189326782};\\\", \\\"{x:1373,y:661,t:1527189326799};\\\", \\\"{x:1370,y:659,t:1527189326814};\\\", \\\"{x:1368,y:656,t:1527189326832};\\\", \\\"{x:1366,y:655,t:1527189326848};\\\", \\\"{x:1365,y:655,t:1527189326864};\\\", \\\"{x:1365,y:654,t:1527189326881};\\\", \\\"{x:1364,y:652,t:1527189326898};\\\", \\\"{x:1362,y:651,t:1527189326915};\\\", \\\"{x:1361,y:649,t:1527189326931};\\\", \\\"{x:1359,y:647,t:1527189326948};\\\", \\\"{x:1359,y:645,t:1527189326965};\\\", \\\"{x:1357,y:643,t:1527189326981};\\\", \\\"{x:1354,y:640,t:1527189326998};\\\", \\\"{x:1353,y:639,t:1527189327015};\\\", \\\"{x:1352,y:637,t:1527189327031};\\\", \\\"{x:1351,y:637,t:1527189327053};\\\", \\\"{x:1350,y:637,t:1527189327087};\\\", \\\"{x:1349,y:637,t:1527189327111};\\\", \\\"{x:1348,y:637,t:1527189327126};\\\", \\\"{x:1347,y:637,t:1527189327133};\\\", \\\"{x:1346,y:637,t:1527189327149};\\\", \\\"{x:1344,y:637,t:1527189327174};\\\", \\\"{x:1344,y:638,t:1527189327198};\\\", \\\"{x:1343,y:638,t:1527189327216};\\\", \\\"{x:1343,y:639,t:1527189327232};\\\", \\\"{x:1342,y:641,t:1527189327287};\\\", \\\"{x:1342,y:644,t:1527189327299};\\\", \\\"{x:1342,y:648,t:1527189327317};\\\", \\\"{x:1343,y:654,t:1527189327333};\\\", \\\"{x:1343,y:659,t:1527189327349};\\\", \\\"{x:1345,y:662,t:1527189327366};\\\", \\\"{x:1345,y:663,t:1527189327383};\\\", \\\"{x:1345,y:664,t:1527189327398};\\\", \\\"{x:1345,y:665,t:1527189327479};\\\", \\\"{x:1345,y:666,t:1527189327501};\\\", \\\"{x:1345,y:668,t:1527189327515};\\\", \\\"{x:1345,y:670,t:1527189327532};\\\", \\\"{x:1345,y:672,t:1527189327548};\\\", \\\"{x:1345,y:677,t:1527189327565};\\\", \\\"{x:1344,y:682,t:1527189327581};\\\", \\\"{x:1342,y:687,t:1527189327598};\\\", \\\"{x:1341,y:691,t:1527189327615};\\\", \\\"{x:1341,y:692,t:1527189327632};\\\", \\\"{x:1341,y:693,t:1527189327649};\\\", \\\"{x:1341,y:694,t:1527189327665};\\\", \\\"{x:1341,y:696,t:1527189327683};\\\", \\\"{x:1340,y:696,t:1527189327698};\\\", \\\"{x:1339,y:699,t:1527189327715};\\\", \\\"{x:1339,y:700,t:1527189327734};\\\", \\\"{x:1339,y:702,t:1527189327749};\\\", \\\"{x:1338,y:706,t:1527189327765};\\\", \\\"{x:1337,y:712,t:1527189327782};\\\", \\\"{x:1337,y:717,t:1527189327799};\\\", \\\"{x:1337,y:721,t:1527189327816};\\\", \\\"{x:1337,y:724,t:1527189327832};\\\", \\\"{x:1337,y:726,t:1527189327849};\\\", \\\"{x:1337,y:728,t:1527189327865};\\\", \\\"{x:1337,y:731,t:1527189327882};\\\", \\\"{x:1337,y:735,t:1527189327899};\\\", \\\"{x:1337,y:740,t:1527189327915};\\\", \\\"{x:1337,y:744,t:1527189327932};\\\", \\\"{x:1338,y:747,t:1527189327950};\\\", \\\"{x:1338,y:750,t:1527189327965};\\\", \\\"{x:1339,y:755,t:1527189327982};\\\", \\\"{x:1339,y:759,t:1527189327999};\\\", \\\"{x:1341,y:767,t:1527189328015};\\\", \\\"{x:1345,y:775,t:1527189328032};\\\", \\\"{x:1353,y:786,t:1527189328049};\\\", \\\"{x:1358,y:794,t:1527189328065};\\\", \\\"{x:1360,y:799,t:1527189328082};\\\", \\\"{x:1361,y:800,t:1527189328100};\\\", \\\"{x:1362,y:801,t:1527189328115};\\\", \\\"{x:1362,y:803,t:1527189328133};\\\", \\\"{x:1363,y:803,t:1527189328149};\\\", \\\"{x:1364,y:804,t:1527189328166};\\\", \\\"{x:1364,y:805,t:1527189328238};\\\", \\\"{x:1364,y:806,t:1527189328250};\\\", \\\"{x:1364,y:810,t:1527189328266};\\\", \\\"{x:1364,y:817,t:1527189328283};\\\", \\\"{x:1364,y:826,t:1527189328300};\\\", \\\"{x:1363,y:835,t:1527189328317};\\\", \\\"{x:1360,y:841,t:1527189328333};\\\", \\\"{x:1359,y:846,t:1527189328350};\\\", \\\"{x:1358,y:849,t:1527189328367};\\\", \\\"{x:1357,y:854,t:1527189328383};\\\", \\\"{x:1356,y:855,t:1527189328400};\\\", \\\"{x:1355,y:859,t:1527189328417};\\\", \\\"{x:1355,y:863,t:1527189328433};\\\", \\\"{x:1352,y:865,t:1527189328449};\\\", \\\"{x:1352,y:867,t:1527189328467};\\\", \\\"{x:1350,y:872,t:1527189328482};\\\", \\\"{x:1349,y:877,t:1527189328499};\\\", \\\"{x:1345,y:886,t:1527189328516};\\\", \\\"{x:1343,y:895,t:1527189328532};\\\", \\\"{x:1341,y:900,t:1527189328549};\\\", \\\"{x:1340,y:908,t:1527189328566};\\\", \\\"{x:1339,y:911,t:1527189328583};\\\", \\\"{x:1339,y:915,t:1527189328599};\\\", \\\"{x:1339,y:918,t:1527189328617};\\\", \\\"{x:1338,y:919,t:1527189328632};\\\", \\\"{x:1337,y:919,t:1527189328649};\\\", \\\"{x:1337,y:921,t:1527189328694};\\\", \\\"{x:1337,y:922,t:1527189328702};\\\", \\\"{x:1337,y:923,t:1527189328716};\\\", \\\"{x:1336,y:925,t:1527189328734};\\\", \\\"{x:1336,y:926,t:1527189328749};\\\", \\\"{x:1336,y:925,t:1527189328886};\\\", \\\"{x:1336,y:924,t:1527189328909};\\\", \\\"{x:1336,y:922,t:1527189328941};\\\", \\\"{x:1336,y:919,t:1527189329607};\\\", \\\"{x:1336,y:915,t:1527189329617};\\\", \\\"{x:1337,y:903,t:1527189329633};\\\", \\\"{x:1339,y:887,t:1527189329651};\\\", \\\"{x:1344,y:864,t:1527189329668};\\\", \\\"{x:1346,y:844,t:1527189329683};\\\", \\\"{x:1350,y:823,t:1527189329700};\\\", \\\"{x:1355,y:801,t:1527189329718};\\\", \\\"{x:1362,y:780,t:1527189329733};\\\", \\\"{x:1373,y:752,t:1527189329751};\\\", \\\"{x:1378,y:740,t:1527189329768};\\\", \\\"{x:1380,y:734,t:1527189329784};\\\", \\\"{x:1381,y:730,t:1527189329801};\\\", \\\"{x:1381,y:729,t:1527189329818};\\\", \\\"{x:1381,y:726,t:1527189329834};\\\", \\\"{x:1381,y:722,t:1527189329851};\\\", \\\"{x:1381,y:719,t:1527189329867};\\\", \\\"{x:1381,y:714,t:1527189329884};\\\", \\\"{x:1380,y:708,t:1527189329901};\\\", \\\"{x:1376,y:701,t:1527189329917};\\\", \\\"{x:1367,y:685,t:1527189329935};\\\", \\\"{x:1362,y:676,t:1527189329951};\\\", \\\"{x:1355,y:666,t:1527189329968};\\\", \\\"{x:1351,y:657,t:1527189329985};\\\", \\\"{x:1348,y:650,t:1527189330001};\\\", \\\"{x:1347,y:643,t:1527189330018};\\\", \\\"{x:1344,y:636,t:1527189330035};\\\", \\\"{x:1343,y:632,t:1527189330050};\\\", \\\"{x:1340,y:629,t:1527189330068};\\\", \\\"{x:1337,y:626,t:1527189330084};\\\", \\\"{x:1340,y:628,t:1527189330279};\\\", \\\"{x:1341,y:634,t:1527189330287};\\\", \\\"{x:1341,y:641,t:1527189330301};\\\", \\\"{x:1342,y:650,t:1527189330318};\\\", \\\"{x:1344,y:655,t:1527189330334};\\\", \\\"{x:1344,y:656,t:1527189330358};\\\", \\\"{x:1342,y:656,t:1527189331206};\\\", \\\"{x:1331,y:653,t:1527189331219};\\\", \\\"{x:1300,y:650,t:1527189331235};\\\", \\\"{x:1257,y:643,t:1527189331252};\\\", \\\"{x:1189,y:638,t:1527189331269};\\\", \\\"{x:1041,y:634,t:1527189331286};\\\", \\\"{x:918,y:628,t:1527189331302};\\\", \\\"{x:797,y:616,t:1527189331318};\\\", \\\"{x:694,y:604,t:1527189331336};\\\", \\\"{x:605,y:589,t:1527189331353};\\\", \\\"{x:559,y:578,t:1527189331368};\\\", \\\"{x:528,y:568,t:1527189331385};\\\", \\\"{x:512,y:564,t:1527189331403};\\\", \\\"{x:504,y:562,t:1527189331419};\\\", \\\"{x:502,y:561,t:1527189331437};\\\", \\\"{x:500,y:560,t:1527189331452};\\\", \\\"{x:499,y:559,t:1527189331477};\\\", \\\"{x:498,y:559,t:1527189331501};\\\", \\\"{x:497,y:558,t:1527189331509};\\\", \\\"{x:496,y:557,t:1527189331520};\\\", \\\"{x:491,y:552,t:1527189331537};\\\", \\\"{x:489,y:548,t:1527189331553};\\\", \\\"{x:489,y:540,t:1527189331569};\\\", \\\"{x:492,y:525,t:1527189331586};\\\", \\\"{x:505,y:507,t:1527189331604};\\\", \\\"{x:522,y:494,t:1527189331620};\\\", \\\"{x:539,y:479,t:1527189331636};\\\", \\\"{x:567,y:464,t:1527189331653};\\\", \\\"{x:581,y:459,t:1527189331670};\\\", \\\"{x:586,y:457,t:1527189331686};\\\", \\\"{x:588,y:456,t:1527189331725};\\\", \\\"{x:589,y:456,t:1527189331736};\\\", \\\"{x:596,y:456,t:1527189331753};\\\", \\\"{x:610,y:456,t:1527189331771};\\\", \\\"{x:623,y:456,t:1527189331787};\\\", \\\"{x:638,y:456,t:1527189331803};\\\", \\\"{x:665,y:456,t:1527189331820};\\\", \\\"{x:714,y:456,t:1527189331837};\\\", \\\"{x:740,y:456,t:1527189331854};\\\", \\\"{x:752,y:456,t:1527189331870};\\\", \\\"{x:759,y:456,t:1527189331887};\\\", \\\"{x:761,y:456,t:1527189331903};\\\", \\\"{x:761,y:457,t:1527189331934};\\\", \\\"{x:763,y:457,t:1527189331991};\\\", \\\"{x:764,y:459,t:1527189332006};\\\", \\\"{x:765,y:459,t:1527189332022};\\\", \\\"{x:768,y:459,t:1527189332038};\\\", \\\"{x:772,y:459,t:1527189332054};\\\", \\\"{x:777,y:460,t:1527189332070};\\\", \\\"{x:784,y:463,t:1527189332088};\\\", \\\"{x:791,y:463,t:1527189332103};\\\", \\\"{x:799,y:463,t:1527189332121};\\\", \\\"{x:802,y:464,t:1527189332138};\\\", \\\"{x:811,y:464,t:1527189332153};\\\", \\\"{x:814,y:466,t:1527189332170};\\\", \\\"{x:816,y:466,t:1527189332188};\\\", \\\"{x:816,y:467,t:1527189332214};\\\", \\\"{x:818,y:468,t:1527189332230};\\\", \\\"{x:819,y:469,t:1527189332238};\\\", \\\"{x:822,y:470,t:1527189332253};\\\", \\\"{x:825,y:471,t:1527189332271};\\\", \\\"{x:829,y:471,t:1527189332289};\\\", \\\"{x:830,y:471,t:1527189332304};\\\", \\\"{x:831,y:471,t:1527189332320};\\\", \\\"{x:832,y:471,t:1527189332336};\\\", \\\"{x:833,y:471,t:1527189332365};\\\", \\\"{x:834,y:471,t:1527189332373};\\\", \\\"{x:835,y:471,t:1527189332386};\\\", \\\"{x:836,y:471,t:1527189332403};\\\", \\\"{x:837,y:471,t:1527189332445};\\\", \\\"{x:839,y:471,t:1527189333871};\\\", \\\"{x:845,y:473,t:1527189333889};\\\", \\\"{x:851,y:474,t:1527189333907};\\\", \\\"{x:858,y:474,t:1527189333921};\\\", \\\"{x:867,y:475,t:1527189333938};\\\", \\\"{x:884,y:478,t:1527189333955};\\\", \\\"{x:911,y:481,t:1527189333972};\\\", \\\"{x:945,y:485,t:1527189333989};\\\", \\\"{x:999,y:492,t:1527189334005};\\\", \\\"{x:1041,y:497,t:1527189334022};\\\", \\\"{x:1103,y:509,t:1527189334038};\\\", \\\"{x:1197,y:531,t:1527189334056};\\\", \\\"{x:1274,y:549,t:1527189334072};\\\", \\\"{x:1341,y:561,t:1527189334089};\\\", \\\"{x:1384,y:570,t:1527189334105};\\\", \\\"{x:1417,y:576,t:1527189334123};\\\", \\\"{x:1452,y:578,t:1527189334138};\\\", \\\"{x:1480,y:578,t:1527189334156};\\\", \\\"{x:1497,y:578,t:1527189334172};\\\", \\\"{x:1512,y:578,t:1527189334189};\\\", \\\"{x:1528,y:577,t:1527189334205};\\\", \\\"{x:1529,y:576,t:1527189334238};\\\", \\\"{x:1526,y:576,t:1527189334303};\\\", \\\"{x:1525,y:576,t:1527189334310};\\\", \\\"{x:1523,y:575,t:1527189334323};\\\", \\\"{x:1518,y:575,t:1527189334339};\\\", \\\"{x:1515,y:575,t:1527189334356};\\\", \\\"{x:1513,y:575,t:1527189334373};\\\", \\\"{x:1512,y:575,t:1527189334389};\\\", \\\"{x:1509,y:575,t:1527189334406};\\\", \\\"{x:1508,y:575,t:1527189334422};\\\", \\\"{x:1505,y:575,t:1527189334439};\\\", \\\"{x:1503,y:575,t:1527189334455};\\\", \\\"{x:1502,y:575,t:1527189334472};\\\", \\\"{x:1496,y:576,t:1527189334489};\\\", \\\"{x:1491,y:578,t:1527189334506};\\\", \\\"{x:1484,y:583,t:1527189334523};\\\", \\\"{x:1472,y:588,t:1527189334539};\\\", \\\"{x:1456,y:596,t:1527189334556};\\\", \\\"{x:1440,y:604,t:1527189334572};\\\", \\\"{x:1405,y:623,t:1527189334590};\\\", \\\"{x:1388,y:635,t:1527189334605};\\\", \\\"{x:1370,y:645,t:1527189334622};\\\", \\\"{x:1357,y:651,t:1527189334640};\\\", \\\"{x:1344,y:654,t:1527189334656};\\\", \\\"{x:1334,y:655,t:1527189334673};\\\", \\\"{x:1328,y:655,t:1527189334689};\\\", \\\"{x:1326,y:655,t:1527189334706};\\\", \\\"{x:1324,y:655,t:1527189334723};\\\", \\\"{x:1323,y:655,t:1527189334740};\\\", \\\"{x:1323,y:654,t:1527189334879};\\\", \\\"{x:1323,y:653,t:1527189334889};\\\", \\\"{x:1327,y:647,t:1527189334906};\\\", \\\"{x:1330,y:643,t:1527189334923};\\\", \\\"{x:1333,y:638,t:1527189334941};\\\", \\\"{x:1335,y:635,t:1527189334957};\\\", \\\"{x:1336,y:635,t:1527189334974};\\\", \\\"{x:1338,y:634,t:1527189335094};\\\", \\\"{x:1340,y:634,t:1527189335107};\\\", \\\"{x:1354,y:638,t:1527189335122};\\\", \\\"{x:1369,y:641,t:1527189335140};\\\", \\\"{x:1384,y:644,t:1527189335156};\\\", \\\"{x:1392,y:646,t:1527189335173};\\\", \\\"{x:1393,y:646,t:1527189335189};\\\", \\\"{x:1392,y:646,t:1527189335262};\\\", \\\"{x:1388,y:646,t:1527189335274};\\\", \\\"{x:1380,y:646,t:1527189335289};\\\", \\\"{x:1372,y:648,t:1527189335307};\\\", \\\"{x:1368,y:648,t:1527189335324};\\\", \\\"{x:1367,y:648,t:1527189335340};\\\", \\\"{x:1366,y:648,t:1527189335415};\\\", \\\"{x:1365,y:648,t:1527189335430};\\\", \\\"{x:1364,y:648,t:1527189335559};\\\", \\\"{x:1362,y:647,t:1527189335574};\\\", \\\"{x:1359,y:647,t:1527189335590};\\\", \\\"{x:1354,y:644,t:1527189335607};\\\", \\\"{x:1346,y:640,t:1527189335625};\\\", \\\"{x:1338,y:639,t:1527189335641};\\\", \\\"{x:1334,y:636,t:1527189335657};\\\", \\\"{x:1330,y:636,t:1527189335674};\\\", \\\"{x:1329,y:635,t:1527189335690};\\\", \\\"{x:1330,y:635,t:1527189335942};\\\", \\\"{x:1331,y:635,t:1527189335957};\\\", \\\"{x:1333,y:635,t:1527189335974};\\\", \\\"{x:1334,y:635,t:1527189335990};\\\", \\\"{x:1334,y:636,t:1527189336014};\\\", \\\"{x:1334,y:637,t:1527189336150};\\\", \\\"{x:1334,y:639,t:1527189336158};\\\", \\\"{x:1334,y:640,t:1527189336174};\\\", \\\"{x:1334,y:641,t:1527189336274};\\\", \\\"{x:1328,y:643,t:1527189336507};\\\", \\\"{x:1317,y:645,t:1527189336515};\\\", \\\"{x:1305,y:648,t:1527189336528};\\\", \\\"{x:1290,y:651,t:1527189336545};\\\", \\\"{x:1289,y:652,t:1527189336562};\\\", \\\"{x:1288,y:651,t:1527189336659};\\\", \\\"{x:1289,y:643,t:1527189336667};\\\", \\\"{x:1294,y:637,t:1527189336679};\\\", \\\"{x:1303,y:627,t:1527189336695};\\\", \\\"{x:1308,y:621,t:1527189336712};\\\", \\\"{x:1311,y:616,t:1527189336730};\\\", \\\"{x:1312,y:612,t:1527189336745};\\\", \\\"{x:1316,y:605,t:1527189336762};\\\", \\\"{x:1318,y:603,t:1527189336779};\\\", \\\"{x:1320,y:600,t:1527189336795};\\\", \\\"{x:1324,y:597,t:1527189336813};\\\", \\\"{x:1326,y:594,t:1527189336830};\\\", \\\"{x:1328,y:593,t:1527189336845};\\\", \\\"{x:1330,y:591,t:1527189336862};\\\", \\\"{x:1331,y:591,t:1527189336881};\\\", \\\"{x:1331,y:590,t:1527189336897};\\\", \\\"{x:1332,y:589,t:1527189336921};\\\", \\\"{x:1333,y:588,t:1527189336930};\\\", \\\"{x:1335,y:585,t:1527189336945};\\\", \\\"{x:1338,y:581,t:1527189336962};\\\", \\\"{x:1340,y:579,t:1527189336979};\\\", \\\"{x:1342,y:575,t:1527189336995};\\\", \\\"{x:1344,y:571,t:1527189337011};\\\", \\\"{x:1344,y:570,t:1527189337028};\\\", \\\"{x:1344,y:569,t:1527189337044};\\\", \\\"{x:1345,y:568,t:1527189337522};\\\", \\\"{x:1346,y:563,t:1527189337530};\\\", \\\"{x:1350,y:552,t:1527189337546};\\\", \\\"{x:1353,y:539,t:1527189337562};\\\", \\\"{x:1355,y:527,t:1527189337579};\\\", \\\"{x:1355,y:519,t:1527189337597};\\\", \\\"{x:1355,y:515,t:1527189337613};\\\", \\\"{x:1355,y:513,t:1527189337629};\\\", \\\"{x:1353,y:512,t:1527189337779};\\\", \\\"{x:1352,y:511,t:1527189337796};\\\", \\\"{x:1349,y:510,t:1527189337813};\\\", \\\"{x:1347,y:509,t:1527189337829};\\\", \\\"{x:1346,y:509,t:1527189337847};\\\", \\\"{x:1342,y:509,t:1527189338763};\\\", \\\"{x:1339,y:509,t:1527189338780};\\\", \\\"{x:1334,y:509,t:1527189338798};\\\", \\\"{x:1326,y:509,t:1527189338814};\\\", \\\"{x:1323,y:509,t:1527189338830};\\\", \\\"{x:1320,y:509,t:1527189338848};\\\", \\\"{x:1318,y:509,t:1527189338866};\\\", \\\"{x:1316,y:509,t:1527189338880};\\\", \\\"{x:1313,y:509,t:1527189338897};\\\", \\\"{x:1305,y:509,t:1527189338914};\\\", \\\"{x:1298,y:509,t:1527189338930};\\\", \\\"{x:1297,y:509,t:1527189338954};\\\", \\\"{x:1295,y:509,t:1527189339003};\\\", \\\"{x:1292,y:509,t:1527189339026};\\\", \\\"{x:1288,y:510,t:1527189339034};\\\", \\\"{x:1286,y:510,t:1527189339047};\\\", \\\"{x:1284,y:511,t:1527189339064};\\\", \\\"{x:1282,y:512,t:1527189339080};\\\", \\\"{x:1281,y:512,t:1527189339097};\\\", \\\"{x:1281,y:513,t:1527189339171};\\\", \\\"{x:1280,y:513,t:1527189339194};\\\", \\\"{x:1279,y:514,t:1527189339202};\\\", \\\"{x:1279,y:518,t:1527189339484};\\\", \\\"{x:1279,y:519,t:1527189339498};\\\", \\\"{x:1279,y:527,t:1527189339514};\\\", \\\"{x:1279,y:530,t:1527189339531};\\\", \\\"{x:1279,y:535,t:1527189339548};\\\", \\\"{x:1279,y:540,t:1527189339564};\\\", \\\"{x:1279,y:543,t:1527189339581};\\\", \\\"{x:1279,y:547,t:1527189339598};\\\", \\\"{x:1279,y:550,t:1527189339614};\\\", \\\"{x:1278,y:554,t:1527189339631};\\\", \\\"{x:1278,y:563,t:1527189339650};\\\", \\\"{x:1278,y:566,t:1527189339664};\\\", \\\"{x:1278,y:574,t:1527189339681};\\\", \\\"{x:1277,y:586,t:1527189339699};\\\", \\\"{x:1277,y:591,t:1527189339714};\\\", \\\"{x:1277,y:598,t:1527189339731};\\\", \\\"{x:1277,y:602,t:1527189339748};\\\", \\\"{x:1277,y:606,t:1527189339764};\\\", \\\"{x:1277,y:611,t:1527189339781};\\\", \\\"{x:1277,y:614,t:1527189339799};\\\", \\\"{x:1277,y:616,t:1527189339814};\\\", \\\"{x:1277,y:617,t:1527189339832};\\\", \\\"{x:1277,y:620,t:1527189339850};\\\", \\\"{x:1277,y:623,t:1527189339864};\\\", \\\"{x:1277,y:626,t:1527189339881};\\\", \\\"{x:1277,y:629,t:1527189339898};\\\", \\\"{x:1277,y:630,t:1527189339914};\\\", \\\"{x:1277,y:633,t:1527189339931};\\\", \\\"{x:1276,y:634,t:1527189339949};\\\", \\\"{x:1276,y:636,t:1527189339965};\\\", \\\"{x:1276,y:639,t:1527189339981};\\\", \\\"{x:1276,y:641,t:1527189339998};\\\", \\\"{x:1276,y:643,t:1527189340015};\\\", \\\"{x:1276,y:645,t:1527189340032};\\\", \\\"{x:1276,y:646,t:1527189340050};\\\", \\\"{x:1276,y:647,t:1527189340066};\\\", \\\"{x:1276,y:648,t:1527189340081};\\\", \\\"{x:1276,y:649,t:1527189340121};\\\", \\\"{x:1276,y:651,t:1527189340130};\\\", \\\"{x:1276,y:652,t:1527189340148};\\\", \\\"{x:1276,y:655,t:1527189340165};\\\", \\\"{x:1276,y:658,t:1527189340180};\\\", \\\"{x:1277,y:662,t:1527189340198};\\\", \\\"{x:1278,y:666,t:1527189340214};\\\", \\\"{x:1278,y:670,t:1527189340231};\\\", \\\"{x:1278,y:673,t:1527189340249};\\\", \\\"{x:1279,y:675,t:1527189340264};\\\", \\\"{x:1279,y:679,t:1527189340281};\\\", \\\"{x:1281,y:684,t:1527189340298};\\\", \\\"{x:1281,y:686,t:1527189340315};\\\", \\\"{x:1281,y:690,t:1527189340331};\\\", \\\"{x:1281,y:693,t:1527189340348};\\\", \\\"{x:1281,y:697,t:1527189340365};\\\", \\\"{x:1282,y:699,t:1527189340381};\\\", \\\"{x:1282,y:700,t:1527189340398};\\\", \\\"{x:1282,y:703,t:1527189340415};\\\", \\\"{x:1282,y:705,t:1527189340432};\\\", \\\"{x:1283,y:707,t:1527189340449};\\\", \\\"{x:1283,y:712,t:1527189340465};\\\", \\\"{x:1283,y:716,t:1527189340481};\\\", \\\"{x:1284,y:723,t:1527189340497};\\\", \\\"{x:1284,y:727,t:1527189340515};\\\", \\\"{x:1284,y:732,t:1527189340531};\\\", \\\"{x:1284,y:736,t:1527189340548};\\\", \\\"{x:1284,y:740,t:1527189340565};\\\", \\\"{x:1284,y:745,t:1527189340581};\\\", \\\"{x:1284,y:747,t:1527189340598};\\\", \\\"{x:1284,y:749,t:1527189340615};\\\", \\\"{x:1285,y:752,t:1527189340632};\\\", \\\"{x:1285,y:753,t:1527189340649};\\\", \\\"{x:1285,y:756,t:1527189340666};\\\", \\\"{x:1285,y:764,t:1527189340682};\\\", \\\"{x:1285,y:771,t:1527189340698};\\\", \\\"{x:1285,y:777,t:1527189340716};\\\", \\\"{x:1285,y:782,t:1527189340733};\\\", \\\"{x:1285,y:790,t:1527189340748};\\\", \\\"{x:1285,y:794,t:1527189340766};\\\", \\\"{x:1285,y:798,t:1527189340782};\\\", \\\"{x:1284,y:800,t:1527189340798};\\\", \\\"{x:1284,y:803,t:1527189340814};\\\", \\\"{x:1284,y:804,t:1527189340832};\\\", \\\"{x:1284,y:805,t:1527189340849};\\\", \\\"{x:1284,y:807,t:1527189340865};\\\", \\\"{x:1284,y:808,t:1527189340882};\\\", \\\"{x:1283,y:811,t:1527189340899};\\\", \\\"{x:1283,y:813,t:1527189340916};\\\", \\\"{x:1282,y:815,t:1527189340932};\\\", \\\"{x:1282,y:817,t:1527189340948};\\\", \\\"{x:1281,y:822,t:1527189340965};\\\", \\\"{x:1281,y:824,t:1527189340982};\\\", \\\"{x:1280,y:829,t:1527189340999};\\\", \\\"{x:1280,y:832,t:1527189341015};\\\", \\\"{x:1279,y:836,t:1527189341032};\\\", \\\"{x:1279,y:841,t:1527189341049};\\\", \\\"{x:1278,y:846,t:1527189341066};\\\", \\\"{x:1277,y:849,t:1527189341083};\\\", \\\"{x:1277,y:851,t:1527189341099};\\\", \\\"{x:1277,y:853,t:1527189341115};\\\", \\\"{x:1277,y:856,t:1527189341132};\\\", \\\"{x:1277,y:860,t:1527189341150};\\\", \\\"{x:1276,y:865,t:1527189341165};\\\", \\\"{x:1276,y:868,t:1527189341182};\\\", \\\"{x:1274,y:873,t:1527189341199};\\\", \\\"{x:1274,y:876,t:1527189341215};\\\", \\\"{x:1274,y:878,t:1527189341232};\\\", \\\"{x:1274,y:885,t:1527189341251};\\\", \\\"{x:1274,y:888,t:1527189341265};\\\", \\\"{x:1274,y:895,t:1527189341282};\\\", \\\"{x:1274,y:899,t:1527189341299};\\\", \\\"{x:1274,y:902,t:1527189341315};\\\", \\\"{x:1274,y:903,t:1527189341333};\\\", \\\"{x:1274,y:904,t:1527189341349};\\\", \\\"{x:1274,y:905,t:1527189341365};\\\", \\\"{x:1274,y:907,t:1527189341383};\\\", \\\"{x:1276,y:914,t:1527189341399};\\\", \\\"{x:1277,y:920,t:1527189341416};\\\", \\\"{x:1278,y:923,t:1527189341432};\\\", \\\"{x:1279,y:924,t:1527189341449};\\\", \\\"{x:1279,y:925,t:1527189341466};\\\", \\\"{x:1279,y:924,t:1527189341914};\\\", \\\"{x:1279,y:914,t:1527189341922};\\\", \\\"{x:1279,y:902,t:1527189341933};\\\", \\\"{x:1276,y:876,t:1527189341950};\\\", \\\"{x:1275,y:845,t:1527189341966};\\\", \\\"{x:1269,y:806,t:1527189341983};\\\", \\\"{x:1266,y:768,t:1527189341999};\\\", \\\"{x:1263,y:717,t:1527189342017};\\\", \\\"{x:1262,y:682,t:1527189342033};\\\", \\\"{x:1262,y:646,t:1527189342050};\\\", \\\"{x:1262,y:612,t:1527189342066};\\\", \\\"{x:1262,y:595,t:1527189342083};\\\", \\\"{x:1260,y:586,t:1527189342100};\\\", \\\"{x:1257,y:580,t:1527189342116};\\\", \\\"{x:1257,y:578,t:1527189342133};\\\", \\\"{x:1257,y:577,t:1527189342149};\\\", \\\"{x:1257,y:576,t:1527189342227};\\\", \\\"{x:1258,y:574,t:1527189342234};\\\", \\\"{x:1260,y:570,t:1527189342249};\\\", \\\"{x:1264,y:565,t:1527189342266};\\\", \\\"{x:1267,y:560,t:1527189342283};\\\", \\\"{x:1269,y:554,t:1527189342299};\\\", \\\"{x:1271,y:552,t:1527189342317};\\\", \\\"{x:1271,y:549,t:1527189342333};\\\", \\\"{x:1273,y:546,t:1527189342350};\\\", \\\"{x:1273,y:543,t:1527189342367};\\\", \\\"{x:1273,y:540,t:1527189342383};\\\", \\\"{x:1273,y:536,t:1527189342400};\\\", \\\"{x:1274,y:534,t:1527189342417};\\\", \\\"{x:1274,y:530,t:1527189342433};\\\", \\\"{x:1275,y:525,t:1527189342450};\\\", \\\"{x:1277,y:522,t:1527189342466};\\\", \\\"{x:1277,y:518,t:1527189342484};\\\", \\\"{x:1280,y:514,t:1527189342500};\\\", \\\"{x:1280,y:511,t:1527189342516};\\\", \\\"{x:1283,y:506,t:1527189342532};\\\", \\\"{x:1284,y:503,t:1527189342550};\\\", \\\"{x:1285,y:501,t:1527189342566};\\\", \\\"{x:1285,y:500,t:1527189342582};\\\", \\\"{x:1285,y:501,t:1527189342795};\\\", \\\"{x:1283,y:505,t:1527189342803};\\\", \\\"{x:1283,y:508,t:1527189342833};\\\", \\\"{x:1283,y:510,t:1527189342849};\\\", \\\"{x:1282,y:510,t:1527189342867};\\\", \\\"{x:1282,y:511,t:1527189342905};\\\", \\\"{x:1281,y:511,t:1527189345946};\\\", \\\"{x:1279,y:511,t:1527189345953};\\\", \\\"{x:1271,y:511,t:1527189345970};\\\", \\\"{x:1229,y:515,t:1527189345987};\\\", \\\"{x:1168,y:517,t:1527189346003};\\\", \\\"{x:1082,y:517,t:1527189346020};\\\", \\\"{x:975,y:514,t:1527189346037};\\\", \\\"{x:836,y:490,t:1527189346054};\\\", \\\"{x:690,y:451,t:1527189346069};\\\", \\\"{x:544,y:414,t:1527189346086};\\\", \\\"{x:448,y:374,t:1527189346103};\\\", \\\"{x:395,y:351,t:1527189346119};\\\", \\\"{x:386,y:345,t:1527189346135};\\\", \\\"{x:384,y:346,t:1527189346193};\\\", \\\"{x:384,y:349,t:1527189346203};\\\", \\\"{x:384,y:360,t:1527189346218};\\\", \\\"{x:384,y:374,t:1527189346236};\\\", \\\"{x:389,y:390,t:1527189346253};\\\", \\\"{x:393,y:402,t:1527189346269};\\\", \\\"{x:396,y:406,t:1527189346286};\\\", \\\"{x:400,y:409,t:1527189346303};\\\", \\\"{x:412,y:411,t:1527189346319};\\\", \\\"{x:441,y:411,t:1527189346336};\\\", \\\"{x:471,y:411,t:1527189346353};\\\", \\\"{x:513,y:411,t:1527189346369};\\\", \\\"{x:531,y:411,t:1527189346386};\\\", \\\"{x:537,y:411,t:1527189346403};\\\", \\\"{x:538,y:411,t:1527189346421};\\\", \\\"{x:539,y:412,t:1527189346514};\\\", \\\"{x:543,y:416,t:1527189346522};\\\", \\\"{x:547,y:419,t:1527189346536};\\\", \\\"{x:556,y:426,t:1527189346553};\\\", \\\"{x:562,y:431,t:1527189346569};\\\", \\\"{x:565,y:434,t:1527189346586};\\\", \\\"{x:570,y:442,t:1527189346604};\\\", \\\"{x:575,y:451,t:1527189346622};\\\", \\\"{x:580,y:459,t:1527189346635};\\\", \\\"{x:583,y:464,t:1527189346652};\\\", \\\"{x:585,y:467,t:1527189346669};\\\", \\\"{x:587,y:468,t:1527189346685};\\\", \\\"{x:588,y:468,t:1527189346737};\\\", \\\"{x:594,y:468,t:1527189346753};\\\", \\\"{x:598,y:466,t:1527189346769};\\\", \\\"{x:604,y:460,t:1527189346789};\\\", \\\"{x:605,y:459,t:1527189346802};\\\", \\\"{x:605,y:458,t:1527189346820};\\\", \\\"{x:606,y:458,t:1527189346841};\\\", \\\"{x:607,y:458,t:1527189346881};\\\", \\\"{x:609,y:457,t:1527189347086};\\\", \\\"{x:610,y:456,t:1527189347104};\\\", \\\"{x:610,y:456,t:1527189347166};\\\", \\\"{x:611,y:456,t:1527189347370};\\\", \\\"{x:611,y:459,t:1527189347387};\\\", \\\"{x:596,y:482,t:1527189347405};\\\", \\\"{x:580,y:511,t:1527189347421};\\\", \\\"{x:569,y:538,t:1527189347437};\\\", \\\"{x:563,y:556,t:1527189347455};\\\", \\\"{x:559,y:571,t:1527189347474};\\\", \\\"{x:555,y:580,t:1527189347486};\\\", \\\"{x:548,y:590,t:1527189347504};\\\", \\\"{x:546,y:594,t:1527189347521};\\\", \\\"{x:545,y:599,t:1527189347537};\\\", \\\"{x:543,y:601,t:1527189347554};\\\", \\\"{x:542,y:602,t:1527189347585};\\\", \\\"{x:541,y:603,t:1527189347593};\\\", \\\"{x:541,y:604,t:1527189347609};\\\", \\\"{x:540,y:604,t:1527189347621};\\\", \\\"{x:538,y:608,t:1527189347637};\\\", \\\"{x:535,y:612,t:1527189347655};\\\", \\\"{x:532,y:621,t:1527189347671};\\\", \\\"{x:531,y:633,t:1527189347688};\\\", \\\"{x:527,y:655,t:1527189347705};\\\", \\\"{x:526,y:667,t:1527189347721};\\\", \\\"{x:525,y:676,t:1527189347738};\\\", \\\"{x:523,y:681,t:1527189347756};\\\", \\\"{x:522,y:684,t:1527189347772};\\\", \\\"{x:520,y:685,t:1527189348090};\\\", \\\"{x:519,y:685,t:1527189348235};\\\", \\\"{x:517,y:685,t:1527189348266};\\\", \\\"{x:517,y:683,t:1527189348282};\\\", \\\"{x:517,y:680,t:1527189348290};\\\", \\\"{x:517,y:678,t:1527189348305};\\\", \\\"{x:517,y:672,t:1527189348321};\\\", \\\"{x:517,y:667,t:1527189348338};\\\", \\\"{x:517,y:666,t:1527189348355};\\\", \\\"{x:517,y:664,t:1527189348371};\\\", \\\"{x:516,y:663,t:1527189348514};\\\", \\\"{x:514,y:663,t:1527189348890};\\\", \\\"{x:511,y:664,t:1527189348905};\\\", \\\"{x:504,y:665,t:1527189348922};\\\", \\\"{x:494,y:668,t:1527189348938};\\\", \\\"{x:483,y:670,t:1527189348956};\\\", \\\"{x:477,y:672,t:1527189348972};\\\", \\\"{x:474,y:673,t:1527189348988};\\\", \\\"{x:472,y:673,t:1527189349042};\\\", \\\"{x:471,y:673,t:1527189349055};\\\", \\\"{x:470,y:672,t:1527189349073};\\\", \\\"{x:470,y:676,t:1527189349154};\\\", \\\"{x:470,y:688,t:1527189349174};\\\", \\\"{x:475,y:704,t:1527189349188};\\\", \\\"{x:482,y:716,t:1527189349205};\\\", \\\"{x:484,y:719,t:1527189349221};\\\", \\\"{x:485,y:720,t:1527189349239};\\\", \\\"{x:486,y:720,t:1527189349257};\\\", \\\"{x:487,y:720,t:1527189349280};\\\", \\\"{x:489,y:719,t:1527189349313};\\\", \\\"{x:489,y:718,t:1527189349322};\\\", \\\"{x:489,y:715,t:1527189349339};\\\", \\\"{x:489,y:712,t:1527189349355};\\\", \\\"{x:489,y:710,t:1527189349372};\\\", \\\"{x:490,y:708,t:1527189349388};\\\", \\\"{x:490,y:707,t:1527189349405};\\\", \\\"{x:491,y:706,t:1527189349449};\\\", \\\"{x:492,y:705,t:1527189349458};\\\", \\\"{x:493,y:705,t:1527189349474};\\\", \\\"{x:493,y:703,t:1527189350818};\\\", \\\"{x:493,y:700,t:1527189350826};\\\", \\\"{x:493,y:698,t:1527189350840};\\\", \\\"{x:493,y:690,t:1527189350857};\\\", \\\"{x:496,y:681,t:1527189350873};\\\", \\\"{x:498,y:673,t:1527189350890};\\\", \\\"{x:501,y:664,t:1527189350907};\\\", \\\"{x:510,y:653,t:1527189350923};\\\", \\\"{x:516,y:644,t:1527189350940};\\\", \\\"{x:524,y:637,t:1527189350957};\\\", \\\"{x:532,y:631,t:1527189350973};\\\", \\\"{x:541,y:627,t:1527189350990};\\\", \\\"{x:552,y:623,t:1527189351007};\\\", \\\"{x:567,y:618,t:1527189351023};\\\", \\\"{x:586,y:615,t:1527189351040};\\\", \\\"{x:625,y:609,t:1527189351057};\\\", \\\"{x:645,y:607,t:1527189351073};\\\", \\\"{x:662,y:604,t:1527189351090};\\\", \\\"{x:676,y:601,t:1527189351107};\\\", \\\"{x:685,y:598,t:1527189351123};\\\", \\\"{x:692,y:597,t:1527189351140};\\\", \\\"{x:697,y:594,t:1527189351157};\\\", \\\"{x:699,y:594,t:1527189351173};\\\" ] }, { \\\"rt\\\": 47379, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 782937, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"you look at the x axis, find 12pm, and movce up from there to see if either a shift starts,ends, etc.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7384, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 791326, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 21149, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 813491, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 4211, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 819046, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"X66XB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"X66XB\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 339, dom: 1208, initialDom: 1326",
  "javascriptErrors": []
}