var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3dea4d75129c636cc7900181d9c8bbfd",
  "created": "2018-05-24T12:15:51.1818348-07:00",
  "lastActivity": "2018-05-24T12:17:17.5090213-07:00",
  "pageViews": [
    {
      "id": "05245166b6e3bbebe926c4f611f4c4c94fb444d3",
      "startTime": "2018-05-24T12:15:51.2457374-07:00",
      "endTime": "2018-05-24T12:17:17.5090213-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 86531,
      "engagementTime": 84718,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 86531,
  "engagementTime": 84718,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=X66XB",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1e95ee9776fec211e03a1e2b5ca4a652",
  "gdpr": false
}