var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fb80d7a3e9fb893fee914a6b6dbeb8ca",
  "created": "2018-06-04T13:20:19.6207466-07:00",
  "lastActivity": "2018-06-04T13:20:39.9821806-07:00",
  "pageViews": [
    {
      "id": "06041916de375b3694d75efe7be41b0d2f1ed15c",
      "startTime": "2018-06-04T13:20:19.6211806-07:00",
      "endTime": "2018-06-04T13:20:39.9821806-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 20361,
      "engagementTime": 19217,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20361,
  "engagementTime": 19217,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MUULG",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2624ef68804cf2e4202700c098a2eb20",
  "gdpr": false
}