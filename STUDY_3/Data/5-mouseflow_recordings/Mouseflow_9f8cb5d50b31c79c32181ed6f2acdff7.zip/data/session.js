var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9f8cb5d50b31c79c32181ed6f2acdff7",
  "created": "2018-05-22T16:09:25.9404904-07:00",
  "lastActivity": "2018-05-22T16:10:02.3494904-07:00",
  "pageViews": [
    {
      "id": "05222659a9c6606ff590ad9f5ea64dd0ea15c6eb",
      "startTime": "2018-05-22T16:09:25.9404904-07:00",
      "endTime": "2018-05-22T16:10:02.3494904-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 36409,
      "engagementTime": 36009,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36409,
  "engagementTime": 36009,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2KONX",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5f12888a0183c88b12ed4f6dbefe7dbf",
  "gdpr": false
}