var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052543459e626a75f8cee5fa04f7c12668289c76"] = {
  "startTime": "2018-05-25T16:21:42.9091289Z",
  "websitePageUrl": "/16",
  "visitTime": 87381,
  "engagementTime": 78881,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a9f4456e1fb3ba4e4f0caba76b40d1f4",
    "created": "2018-05-25T16:21:42.9091289+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=EJPRM",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c062e4c94af0b551150b34e5e25a5bb4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a9f4456e1fb3ba4e4f0caba76b40d1f4/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 517,
      "e": 517,
      "ty": 2,
      "x": 1038,
      "y": 755
    },
    {
      "t": 519,
      "e": 519,
      "ty": 41,
      "x": 17758,
      "y": 44191,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 657,
      "e": 657,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 1013,
      "y": 738
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 730,
      "y": 584
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 714,
      "y": 577
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 1946,
      "y": 31169,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1577,
      "e": 1577,
      "ty": 6,
      "x": 677,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 671,
      "y": 595
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 616,
      "y": 572
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 58330,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1897,
      "e": 1897,
      "ty": 3,
      "x": 616,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1899,
      "e": 1899,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2096,
      "e": 2096,
      "ty": 4,
      "x": 58330,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2097,
      "e": 2097,
      "ty": 5,
      "x": 616,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 601,
      "y": 565
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 601,
      "y": 564
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 56644,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 602,
      "y": 559
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 56756,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9634,
      "e": 8501,
      "ty": 7,
      "x": 701,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9701,
      "e": 8568,
      "ty": 2,
      "x": 1122,
      "y": 713
    },
    {
      "t": 9751,
      "e": 8618,
      "ty": 41,
      "x": 40660,
      "y": 54863,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9801,
      "e": 8668,
      "ty": 2,
      "x": 1392,
      "y": 1004
    },
    {
      "t": 9901,
      "e": 8768,
      "ty": 2,
      "x": 1309,
      "y": 1039
    },
    {
      "t": 10001,
      "e": 8868,
      "ty": 2,
      "x": 1195,
      "y": 1043
    },
    {
      "t": 10002,
      "e": 8869,
      "ty": 41,
      "x": 12972,
      "y": 52428,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 10002,
      "e": 8869,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10101,
      "e": 8968,
      "ty": 2,
      "x": 1143,
      "y": 996
    },
    {
      "t": 10201,
      "e": 9068,
      "ty": 2,
      "x": 1133,
      "y": 973
    },
    {
      "t": 10251,
      "e": 9118,
      "ty": 41,
      "x": 20194,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 10301,
      "e": 9168,
      "ty": 2,
      "x": 1134,
      "y": 960
    },
    {
      "t": 10401,
      "e": 9268,
      "ty": 2,
      "x": 1162,
      "y": 957
    },
    {
      "t": 10501,
      "e": 9368,
      "ty": 2,
      "x": 1166,
      "y": 957
    },
    {
      "t": 10501,
      "e": 9368,
      "ty": 41,
      "x": 26778,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10702,
      "e": 9569,
      "ty": 2,
      "x": 1161,
      "y": 957
    },
    {
      "t": 10752,
      "e": 9619,
      "ty": 41,
      "x": 26144,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10801,
      "e": 9668,
      "ty": 2,
      "x": 1154,
      "y": 957
    },
    {
      "t": 10901,
      "e": 9768,
      "ty": 2,
      "x": 1149,
      "y": 957
    },
    {
      "t": 11002,
      "e": 9869,
      "ty": 41,
      "x": 25580,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20004,
      "e": 14869,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 23152,
      "e": 14869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23153,
      "e": 14870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23239,
      "e": 14956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 23327,
      "e": 15044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23327,
      "e": 15044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23375,
      "e": 15092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 23471,
      "e": 15188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23472,
      "e": 15189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23543,
      "e": 15260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 23543,
      "e": 15260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23606,
      "e": 15323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 23630,
      "e": 15347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23743,
      "e": 15460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23744,
      "e": 15461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23798,
      "e": 15515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23798,
      "e": 15515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23895,
      "e": 15612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 23927,
      "e": 15644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24103,
      "e": 15820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24206,
      "e": 15923,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "looki"
    },
    {
      "t": 24603,
      "e": 16320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24635,
      "e": 16352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24669,
      "e": 16386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24702,
      "e": 16419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24735,
      "e": 16452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24768,
      "e": 16485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24801,
      "e": 16518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24834,
      "e": 16551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24867,
      "e": 16584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24900,
      "e": 16617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24933,
      "e": 16650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24966,
      "e": 16683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24967,
      "e": 16684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 25175,
      "e": 16892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 25295,
      "e": 17012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 25296,
      "e": 17013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25374,
      "e": 17091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 25390,
      "e": 17107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 25431,
      "e": 17148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25431,
      "e": 17148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25519,
      "e": 17236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By"
    },
    {
      "t": 25583,
      "e": 17300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25584,
      "e": 17301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25710,
      "e": 17427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25711,
      "e": 17428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25742,
      "e": 17459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 25798,
      "e": 17515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25886,
      "e": 17603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25887,
      "e": 17604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25935,
      "e": 17652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26015,
      "e": 17732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26016,
      "e": 17733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26063,
      "e": 17780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 26064,
      "e": 17781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26135,
      "e": 17852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 26167,
      "e": 17884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26271,
      "e": 17988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26272,
      "e": 17989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26326,
      "e": 18043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26326,
      "e": 18043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26399,
      "e": 18116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 26423,
      "e": 18140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26423,
      "e": 18140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26471,
      "e": 18188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 26527,
      "e": 18244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26528,
      "e": 18245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26539,
      "e": 18256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26582,
      "e": 18299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26583,
      "e": 18300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26606,
      "e": 18323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26662,
      "e": 18379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26663,
      "e": 18380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26726,
      "e": 18443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26759,
      "e": 18476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26824,
      "e": 18541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26824,
      "e": 18541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26870,
      "e": 18587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26871,
      "e": 18588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26879,
      "e": 18596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 26983,
      "e": 18700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26983,
      "e": 18700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27039,
      "e": 18756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27039,
      "e": 18756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27046,
      "e": 18763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 27095,
      "e": 18812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27102,
      "e": 18819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27191,
      "e": 18908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27192,
      "e": 18909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27343,
      "e": 19060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27343,
      "e": 19060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 27576,
      "e": 19293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 27576,
      "e": 19293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27655,
      "e": 19372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 27694,
      "e": 19411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27871,
      "e": 19588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 27872,
      "e": 19589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27943,
      "e": 19660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 28079,
      "e": 19796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28079,
      "e": 19796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28167,
      "e": 19884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28391,
      "e": 20108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 28392,
      "e": 20109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28478,
      "e": 20195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 28519,
      "e": 20236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28519,
      "e": 20236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28631,
      "e": 20348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28631,
      "e": 20348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28638,
      "e": 20355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 28736,
      "e": 20453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28768,
      "e": 20485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28768,
      "e": 20485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28839,
      "e": 20556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28840,
      "e": 20557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28862,
      "e": 20579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 28975,
      "e": 20692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28982,
      "e": 20699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28983,
      "e": 20700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29030,
      "e": 20747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29030,
      "e": 20747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29094,
      "e": 20811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 29183,
      "e": 20900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29944,
      "e": 21661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29944,
      "e": 21661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30005,
      "e": 21722,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30054,
      "e": 21771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30439,
      "e": 22156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30439,
      "e": 22156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30551,
      "e": 22268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30552,
      "e": 22269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30631,
      "e": 22348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 30639,
      "e": 22356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30759,
      "e": 22476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30759,
      "e": 22476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30878,
      "e": 22595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30878,
      "e": 22595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30878,
      "e": 22595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30951,
      "e": 22668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30951,
      "e": 22668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31062,
      "e": 22779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 31119,
      "e": 22836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31143,
      "e": 22860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31143,
      "e": 22860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31222,
      "e": 22939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 31294,
      "e": 23011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31294,
      "e": 23011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31375,
      "e": 23092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31375,
      "e": 23092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31383,
      "e": 23100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 31495,
      "e": 23212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31496,
      "e": 23213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31559,
      "e": 23276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31560,
      "e": 23277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31566,
      "e": 23283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 31639,
      "e": 23356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31670,
      "e": 23387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31726,
      "e": 23443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31728,
      "e": 23445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31783,
      "e": 23500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31783,
      "e": 23500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31807,
      "e": 23524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 31895,
      "e": 23612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31983,
      "e": 23700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31984,
      "e": 23701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32086,
      "e": 23803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32086,
      "e": 23803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32183,
      "e": 23900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32183,
      "e": 23900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32222,
      "e": 23939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oin"
    },
    {
      "t": 32270,
      "e": 23987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32270,
      "e": 23987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32302,
      "e": 24019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32335,
      "e": 24052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32407,
      "e": 24124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32407,
      "e": 24124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32446,
      "e": 24163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32527,
      "e": 24244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32551,
      "e": 24268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32551,
      "e": 24268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32647,
      "e": 24364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32663,
      "e": 24380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32664,
      "e": 24381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32758,
      "e": 24475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32774,
      "e": 24491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32774,
      "e": 24491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32839,
      "e": 24556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32839,
      "e": 24556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32911,
      "e": 24628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 32927,
      "e": 24644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32928,
      "e": 24645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32958,
      "e": 24675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33054,
      "e": 24771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33086,
      "e": 24803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33087,
      "e": 24804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33183,
      "e": 24900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34536,
      "e": 26253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34537,
      "e": 26254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34630,
      "e": 26347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34630,
      "e": 26347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34670,
      "e": 26387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fa"
    },
    {
      "t": 34743,
      "e": 26460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34743,
      "e": 26460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34758,
      "e": 26475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34814,
      "e": 26531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34911,
      "e": 26628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34912,
      "e": 26629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34958,
      "e": 26675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34958,
      "e": 26675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35006,
      "e": 26723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 35111,
      "e": 26828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35127,
      "e": 26844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35127,
      "e": 26844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35287,
      "e": 27004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35288,
      "e": 27005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35351,
      "e": 27068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||un"
    },
    {
      "t": 35367,
      "e": 27084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35367,
      "e": 27084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35430,
      "e": 27147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35431,
      "e": 27148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35527,
      "e": 27244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35528,
      "e": 27245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35599,
      "e": 27316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35599,
      "e": 27316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35686,
      "e": 27403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 35694,
      "e": 27411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35727,
      "e": 27444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35727,
      "e": 27444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35790,
      "e": 27507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35791,
      "e": 27508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35814,
      "e": 27531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 35895,
      "e": 27612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35895,
      "e": 27612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35934,
      "e": 27651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35934,
      "e": 27651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35999,
      "e": 27716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 36038,
      "e": 27755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36046,
      "e": 27763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36086,
      "e": 27803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36086,
      "e": 27803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36199,
      "e": 27916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36318,
      "e": 28035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 36319,
      "e": 28036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36406,
      "e": 28123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 36407,
      "e": 28124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36479,
      "e": 28196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 36534,
      "e": 28251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36630,
      "e": 28347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 36631,
      "e": 28348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36727,
      "e": 28444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36727,
      "e": 28444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36807,
      "e": 28524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 36887,
      "e": 28604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36888,
      "e": 28605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36889,
      "e": 28606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36982,
      "e": 28699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 36982,
      "e": 28699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37006,
      "e": 28723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| c"
    },
    {
      "t": 37094,
      "e": 28811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37094,
      "e": 28811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37110,
      "e": 28827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 37216,
      "e": 28828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37255,
      "e": 28867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37256,
      "e": 28868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37359,
      "e": 28971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37360,
      "e": 28972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37390,
      "e": 29002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 37446,
      "e": 29058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37519,
      "e": 29131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 37519,
      "e": 29131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37654,
      "e": 29266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 37767,
      "e": 29379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37768,
      "e": 29380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37807,
      "e": 29419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37808,
      "e": 29420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37862,
      "e": 29474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 37942,
      "e": 29554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38127,
      "e": 29739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38238,
      "e": 29850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categr"
    },
    {
      "t": 38463,
      "e": 30075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38463,
      "e": 30075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38606,
      "e": 30218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categro"
    },
    {
      "t": 38616,
      "e": 30228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38655,
      "e": 30267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38656,
      "e": 30268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38758,
      "e": 30370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38774,
      "e": 30386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38775,
      "e": 30387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38935,
      "e": 30547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 39175,
      "e": 30787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39239,
      "e": 30851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categror"
    },
    {
      "t": 39366,
      "e": 30978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39430,
      "e": 31042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categro"
    },
    {
      "t": 39535,
      "e": 31147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39623,
      "e": 31235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categr"
    },
    {
      "t": 39911,
      "e": 31523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40031,
      "e": 31643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm categ"
    },
    {
      "t": 40695,
      "e": 32307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40696,
      "e": 32308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40805,
      "e": 32417,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm catego"
    },
    {
      "t": 40814,
      "e": 32426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40846,
      "e": 32458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40846,
      "e": 32458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40958,
      "e": 32570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40967,
      "e": 32579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 40967,
      "e": 32579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41054,
      "e": 32666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 41367,
      "e": 32979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 41368,
      "e": 32980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41495,
      "e": 33107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 42303,
      "e": 33915,
      "ty": 2,
      "x": 1136,
      "y": 970
    },
    {
      "t": 42404,
      "e": 34016,
      "ty": 2,
      "x": 936,
      "y": 1162
    },
    {
      "t": 42503,
      "e": 34115,
      "ty": 2,
      "x": 933,
      "y": 1167
    },
    {
      "t": 42505,
      "e": 34117,
      "ty": 41,
      "x": 31854,
      "y": 64205,
      "ta": "> div.stimulus"
    },
    {
      "t": 42604,
      "e": 34216,
      "ty": 2,
      "x": 855,
      "y": 849
    },
    {
      "t": 42704,
      "e": 34316,
      "ty": 2,
      "x": 426,
      "y": 611
    },
    {
      "t": 42754,
      "e": 34366,
      "ty": 41,
      "x": 36297,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 42803,
      "e": 34415,
      "ty": 2,
      "x": 413,
      "y": 630
    },
    {
      "t": 42866,
      "e": 34416,
      "ty": 6,
      "x": 407,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 42904,
      "e": 34454,
      "ty": 2,
      "x": 405,
      "y": 676
    },
    {
      "t": 43002,
      "e": 34552,
      "ty": 3,
      "x": 404,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 43003,
      "e": 34553,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X-axis and seeing the points that fall under the 12pm category."
    },
    {
      "t": 43004,
      "e": 34554,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43004,
      "e": 34554,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43004,
      "e": 34554,
      "ty": 2,
      "x": 404,
      "y": 681
    },
    {
      "t": 43005,
      "e": 34555,
      "ty": 41,
      "x": 35719,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 43123,
      "e": 34673,
      "ty": 4,
      "x": 35719,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 43140,
      "e": 34690,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43142,
      "e": 34692,
      "ty": 5,
      "x": 404,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 43147,
      "e": 34697,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 43404,
      "e": 34954,
      "ty": 2,
      "x": 400,
      "y": 688
    },
    {
      "t": 43503,
      "e": 35053,
      "ty": 2,
      "x": 387,
      "y": 723
    },
    {
      "t": 43504,
      "e": 35054,
      "ty": 41,
      "x": 13051,
      "y": 39609,
      "ta": "html > body"
    },
    {
      "t": 44148,
      "e": 35698,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 44404,
      "e": 35954,
      "ty": 2,
      "x": 387,
      "y": 725
    },
    {
      "t": 44504,
      "e": 36054,
      "ty": 2,
      "x": 387,
      "y": 728
    },
    {
      "t": 44504,
      "e": 36054,
      "ty": 41,
      "x": 13051,
      "y": 39886,
      "ta": "html > body"
    },
    {
      "t": 44904,
      "e": 36454,
      "ty": 2,
      "x": 459,
      "y": 708
    },
    {
      "t": 44949,
      "e": 36499,
      "ty": 6,
      "x": 889,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44965,
      "e": 36515,
      "ty": 7,
      "x": 998,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45004,
      "e": 36554,
      "ty": 2,
      "x": 1125,
      "y": 543
    },
    {
      "t": 45004,
      "e": 36554,
      "ty": 41,
      "x": 38466,
      "y": 29637,
      "ta": "html > body"
    },
    {
      "t": 45104,
      "e": 36654,
      "ty": 2,
      "x": 1144,
      "y": 543
    },
    {
      "t": 45204,
      "e": 36754,
      "ty": 2,
      "x": 1129,
      "y": 544
    },
    {
      "t": 45254,
      "e": 36804,
      "ty": 41,
      "x": 60344,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 45304,
      "e": 36854,
      "ty": 2,
      "x": 1076,
      "y": 551
    },
    {
      "t": 45334,
      "e": 36884,
      "ty": 6,
      "x": 1072,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45404,
      "e": 36954,
      "ty": 2,
      "x": 1060,
      "y": 564
    },
    {
      "t": 45468,
      "e": 37018,
      "ty": 3,
      "x": 1060,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45469,
      "e": 37019,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45504,
      "e": 37054,
      "ty": 41,
      "x": 54504,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45594,
      "e": 37144,
      "ty": 4,
      "x": 54504,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45595,
      "e": 37145,
      "ty": 5,
      "x": 1060,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46263,
      "e": 37813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 46264,
      "e": 37814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46343,
      "e": 37893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "99"
    },
    {
      "t": 46343,
      "e": 37893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46382,
      "e": 37932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 46439,
      "e": 37989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 46971,
      "e": 38521,
      "ty": 7,
      "x": 1056,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47004,
      "e": 38554,
      "ty": 2,
      "x": 1047,
      "y": 607
    },
    {
      "t": 47004,
      "e": 38554,
      "ty": 41,
      "x": 51692,
      "y": 14043,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 47051,
      "e": 38601,
      "ty": 6,
      "x": 1037,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47101,
      "e": 38651,
      "ty": 7,
      "x": 1031,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47104,
      "e": 38654,
      "ty": 2,
      "x": 1031,
      "y": 672
    },
    {
      "t": 47204,
      "e": 38754,
      "ty": 2,
      "x": 1026,
      "y": 695
    },
    {
      "t": 47254,
      "e": 38804,
      "ty": 41,
      "x": 35057,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 47304,
      "e": 38854,
      "ty": 2,
      "x": 1033,
      "y": 684
    },
    {
      "t": 47404,
      "e": 38954,
      "ty": 2,
      "x": 1042,
      "y": 669
    },
    {
      "t": 47442,
      "e": 38992,
      "ty": 6,
      "x": 1042,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47482,
      "e": 39032,
      "ty": 3,
      "x": 1042,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47482,
      "e": 39032,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 47483,
      "e": 39033,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47483,
      "e": 39033,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47504,
      "e": 39054,
      "ty": 2,
      "x": 1042,
      "y": 667
    },
    {
      "t": 47504,
      "e": 39054,
      "ty": 41,
      "x": 50611,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47603,
      "e": 39153,
      "ty": 4,
      "x": 50611,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47603,
      "e": 39153,
      "ty": 5,
      "x": 1042,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47704,
      "e": 39254,
      "ty": 2,
      "x": 1050,
      "y": 653
    },
    {
      "t": 47755,
      "e": 39305,
      "ty": 41,
      "x": 52557,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47804,
      "e": 39354,
      "ty": 2,
      "x": 1051,
      "y": 651
    },
    {
      "t": 48167,
      "e": 39717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 48383,
      "e": 39933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 48384,
      "e": 39934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48534,
      "e": 40084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 48542,
      "e": 40092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 48543,
      "e": 40093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 48543,
      "e": 40093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48671,
      "e": 40221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 48671,
      "e": 40221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48702,
      "e": 40252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 48751,
      "e": 40301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 48752,
      "e": 40302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48799,
      "e": 40349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 48847,
      "e": 40397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 48848,
      "e": 40398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48902,
      "e": 40452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 48926,
      "e": 40476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 49014,
      "e": 40564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 49015,
      "e": 40565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49127,
      "e": 40677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 49159,
      "e": 40709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 49160,
      "e": 40710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49246,
      "e": 40796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49286,
      "e": 40836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 49359,
      "e": 40909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 49360,
      "e": 40910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49431,
      "e": 40981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 49511,
      "e": 41061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 49527,
      "e": 41077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 49528,
      "e": 41078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49623,
      "e": 41173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 49624,
      "e": 41174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49646,
      "e": 41196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 49726,
      "e": 41276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 49726,
      "e": 41276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49734,
      "e": 41284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 49815,
      "e": 41365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 49815,
      "e": 41365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49871,
      "e": 41421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 49872,
      "e": 41422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49886,
      "e": 41436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 49958,
      "e": 41508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 49999,
      "e": 41549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 50004,
      "e": 41554,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50604,
      "e": 42154,
      "ty": 7,
      "x": 1020,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50604,
      "e": 42154,
      "ty": 2,
      "x": 1020,
      "y": 672
    },
    {
      "t": 50620,
      "e": 42170,
      "ty": 6,
      "x": 1011,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50704,
      "e": 42254,
      "ty": 2,
      "x": 1002,
      "y": 681
    },
    {
      "t": 50754,
      "e": 42304,
      "ty": 41,
      "x": 46940,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50804,
      "e": 42354,
      "ty": 2,
      "x": 983,
      "y": 696
    },
    {
      "t": 50835,
      "e": 42385,
      "ty": 3,
      "x": 983,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50836,
      "e": 42386,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 50837,
      "e": 42387,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50838,
      "e": 42388,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50946,
      "e": 42496,
      "ty": 4,
      "x": 44879,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50947,
      "e": 42497,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50948,
      "e": 42498,
      "ty": 5,
      "x": 983,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50948,
      "e": 42498,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 51004,
      "e": 42554,
      "ty": 41,
      "x": 33576,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 51965,
      "e": 43515,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 53104,
      "e": 44654,
      "ty": 2,
      "x": 982,
      "y": 694
    },
    {
      "t": 53205,
      "e": 44755,
      "ty": 2,
      "x": 982,
      "y": 543
    },
    {
      "t": 53255,
      "e": 44805,
      "ty": 41,
      "x": 38109,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 53305,
      "e": 44855,
      "ty": 2,
      "x": 968,
      "y": 498
    },
    {
      "t": 53405,
      "e": 44955,
      "ty": 2,
      "x": 942,
      "y": 400
    },
    {
      "t": 53504,
      "e": 45054,
      "ty": 2,
      "x": 900,
      "y": 177
    },
    {
      "t": 53505,
      "e": 45055,
      "ty": 41,
      "x": 18648,
      "y": 1195,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 53604,
      "e": 45154,
      "ty": 2,
      "x": 847,
      "y": 107
    },
    {
      "t": 53705,
      "e": 45255,
      "ty": 2,
      "x": 837,
      "y": 121
    },
    {
      "t": 53754,
      "e": 45304,
      "ty": 41,
      "x": 2273,
      "y": 1195,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 53804,
      "e": 45354,
      "ty": 2,
      "x": 831,
      "y": 209
    },
    {
      "t": 53989,
      "e": 45539,
      "ty": 6,
      "x": 838,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54004,
      "e": 45554,
      "ty": 2,
      "x": 838,
      "y": 233
    },
    {
      "t": 54004,
      "e": 45554,
      "ty": 41,
      "x": 58367,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54004,
      "e": 45554,
      "ty": 7,
      "x": 848,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54104,
      "e": 45654,
      "ty": 2,
      "x": 857,
      "y": 248
    },
    {
      "t": 54204,
      "e": 45754,
      "ty": 2,
      "x": 861,
      "y": 246
    },
    {
      "t": 54255,
      "e": 45805,
      "ty": 41,
      "x": 35684,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 54299,
      "e": 45849,
      "ty": 3,
      "x": 865,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 54303,
      "e": 45853,
      "ty": 2,
      "x": 865,
      "y": 238
    },
    {
      "t": 54443,
      "e": 45993,
      "ty": 4,
      "x": 35684,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 54443,
      "e": 45993,
      "ty": 5,
      "x": 865,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 54443,
      "e": 45993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54443,
      "e": 45993,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 54904,
      "e": 46454,
      "ty": 2,
      "x": 865,
      "y": 275
    },
    {
      "t": 55004,
      "e": 46554,
      "ty": 2,
      "x": 865,
      "y": 421
    },
    {
      "t": 55004,
      "e": 46554,
      "ty": 41,
      "x": 51012,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 55104,
      "e": 46654,
      "ty": 2,
      "x": 865,
      "y": 422
    },
    {
      "t": 55254,
      "e": 46804,
      "ty": 41,
      "x": 51012,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 55804,
      "e": 47354,
      "ty": 2,
      "x": 866,
      "y": 422
    },
    {
      "t": 56005,
      "e": 47555,
      "ty": 41,
      "x": 52182,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 56104,
      "e": 47654,
      "ty": 2,
      "x": 872,
      "y": 423
    },
    {
      "t": 56205,
      "e": 47755,
      "ty": 2,
      "x": 897,
      "y": 451
    },
    {
      "t": 56255,
      "e": 47805,
      "ty": 41,
      "x": 18173,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 56304,
      "e": 47854,
      "ty": 2,
      "x": 898,
      "y": 456
    },
    {
      "t": 56404,
      "e": 47954,
      "ty": 2,
      "x": 892,
      "y": 513
    },
    {
      "t": 56504,
      "e": 48054,
      "ty": 2,
      "x": 883,
      "y": 585
    },
    {
      "t": 56504,
      "e": 48054,
      "ty": 41,
      "x": 61129,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 56604,
      "e": 48154,
      "ty": 2,
      "x": 883,
      "y": 581
    },
    {
      "t": 56704,
      "e": 48254,
      "ty": 2,
      "x": 880,
      "y": 525
    },
    {
      "t": 56754,
      "e": 48304,
      "ty": 41,
      "x": 61530,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 56804,
      "e": 48354,
      "ty": 2,
      "x": 873,
      "y": 521
    },
    {
      "t": 56904,
      "e": 48454,
      "ty": 2,
      "x": 872,
      "y": 534
    },
    {
      "t": 57004,
      "e": 48554,
      "ty": 2,
      "x": 889,
      "y": 552
    },
    {
      "t": 57005,
      "e": 48555,
      "ty": 41,
      "x": 46110,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 57104,
      "e": 48654,
      "ty": 2,
      "x": 882,
      "y": 552
    },
    {
      "t": 57204,
      "e": 48754,
      "ty": 2,
      "x": 853,
      "y": 523
    },
    {
      "t": 57255,
      "e": 48805,
      "ty": 41,
      "x": 35784,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 57305,
      "e": 48855,
      "ty": 2,
      "x": 852,
      "y": 522
    },
    {
      "t": 57404,
      "e": 48954,
      "ty": 2,
      "x": 857,
      "y": 520
    },
    {
      "t": 57504,
      "e": 49054,
      "ty": 2,
      "x": 863,
      "y": 509
    },
    {
      "t": 57505,
      "e": 49055,
      "ty": 41,
      "x": 9867,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 57604,
      "e": 49154,
      "ty": 2,
      "x": 863,
      "y": 508
    },
    {
      "t": 57704,
      "e": 49254,
      "ty": 2,
      "x": 863,
      "y": 504
    },
    {
      "t": 57755,
      "e": 49305,
      "ty": 41,
      "x": 37318,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 57844,
      "e": 49394,
      "ty": 3,
      "x": 863,
      "y": 504,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 57844,
      "e": 49394,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 58003,
      "e": 49553,
      "ty": 4,
      "x": 37318,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 58003,
      "e": 49553,
      "ty": 5,
      "x": 863,
      "y": 504,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 58003,
      "e": 49553,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58004,
      "e": 49554,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 58504,
      "e": 50054,
      "ty": 2,
      "x": 910,
      "y": 565
    },
    {
      "t": 58505,
      "e": 50055,
      "ty": 41,
      "x": 21021,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 58604,
      "e": 50154,
      "ty": 2,
      "x": 1036,
      "y": 692
    },
    {
      "t": 58704,
      "e": 50254,
      "ty": 2,
      "x": 1051,
      "y": 706
    },
    {
      "t": 58755,
      "e": 50305,
      "ty": 41,
      "x": 57849,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 59704,
      "e": 51254,
      "ty": 2,
      "x": 1037,
      "y": 714
    },
    {
      "t": 59755,
      "e": 51305,
      "ty": 41,
      "x": 51597,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 59804,
      "e": 51354,
      "ty": 2,
      "x": 998,
      "y": 734
    },
    {
      "t": 59905,
      "e": 51455,
      "ty": 2,
      "x": 973,
      "y": 746
    },
    {
      "t": 60005,
      "e": 51555,
      "ty": 2,
      "x": 954,
      "y": 761
    },
    {
      "t": 60005,
      "e": 51555,
      "ty": 41,
      "x": 55318,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 60105,
      "e": 51655,
      "ty": 2,
      "x": 940,
      "y": 782
    },
    {
      "t": 60204,
      "e": 51754,
      "ty": 2,
      "x": 937,
      "y": 784
    },
    {
      "t": 60254,
      "e": 51804,
      "ty": 41,
      "x": 29449,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 60304,
      "e": 51854,
      "ty": 2,
      "x": 874,
      "y": 736
    },
    {
      "t": 60505,
      "e": 52055,
      "ty": 2,
      "x": 873,
      "y": 735
    },
    {
      "t": 60505,
      "e": 52055,
      "ty": 41,
      "x": 12945,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60563,
      "e": 52113,
      "ty": 3,
      "x": 873,
      "y": 735,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60564,
      "e": 52114,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60747,
      "e": 52297,
      "ty": 4,
      "x": 12945,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60747,
      "e": 52297,
      "ty": 5,
      "x": 873,
      "y": 735,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60749,
      "e": 52299,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60750,
      "e": 52300,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 62604,
      "e": 54154,
      "ty": 2,
      "x": 874,
      "y": 742
    },
    {
      "t": 62704,
      "e": 54254,
      "ty": 2,
      "x": 877,
      "y": 766
    },
    {
      "t": 62754,
      "e": 54254,
      "ty": 41,
      "x": 32233,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 62804,
      "e": 54304,
      "ty": 2,
      "x": 883,
      "y": 803
    },
    {
      "t": 62904,
      "e": 54404,
      "ty": 2,
      "x": 899,
      "y": 843
    },
    {
      "t": 63004,
      "e": 54504,
      "ty": 2,
      "x": 900,
      "y": 848
    },
    {
      "t": 63005,
      "e": 54505,
      "ty": 41,
      "x": 55362,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 63405,
      "e": 54905,
      "ty": 2,
      "x": 907,
      "y": 852
    },
    {
      "t": 63504,
      "e": 55004,
      "ty": 2,
      "x": 896,
      "y": 898
    },
    {
      "t": 63504,
      "e": 55004,
      "ty": 41,
      "x": 17699,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 63605,
      "e": 55105,
      "ty": 2,
      "x": 880,
      "y": 938
    },
    {
      "t": 63705,
      "e": 55205,
      "ty": 2,
      "x": 873,
      "y": 961
    },
    {
      "t": 63755,
      "e": 55255,
      "ty": 41,
      "x": 41722,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63804,
      "e": 55304,
      "ty": 2,
      "x": 873,
      "y": 964
    },
    {
      "t": 63843,
      "e": 55343,
      "ty": 3,
      "x": 873,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63843,
      "e": 55343,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63970,
      "e": 55470,
      "ty": 4,
      "x": 41722,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63970,
      "e": 55470,
      "ty": 5,
      "x": 873,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63971,
      "e": 55471,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63971,
      "e": 55471,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 64104,
      "e": 55604,
      "ty": 2,
      "x": 881,
      "y": 978
    },
    {
      "t": 64204,
      "e": 55704,
      "ty": 2,
      "x": 890,
      "y": 1000
    },
    {
      "t": 64231,
      "e": 55731,
      "ty": 6,
      "x": 891,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64254,
      "e": 55754,
      "ty": 41,
      "x": 32252,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64304,
      "e": 55804,
      "ty": 2,
      "x": 895,
      "y": 1022
    },
    {
      "t": 64378,
      "e": 55878,
      "ty": 3,
      "x": 896,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64379,
      "e": 55879,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64379,
      "e": 55879,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64403,
      "e": 55903,
      "ty": 2,
      "x": 896,
      "y": 1029
    },
    {
      "t": 64504,
      "e": 56004,
      "ty": 41,
      "x": 34313,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64523,
      "e": 56023,
      "ty": 4,
      "x": 34313,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64523,
      "e": 56023,
      "ty": 5,
      "x": 896,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64525,
      "e": 56025,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64527,
      "e": 56027,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64528,
      "e": 56028,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 65878,
      "e": 57378,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 69104,
      "e": 60604,
      "ty": 2,
      "x": 923,
      "y": 1045
    },
    {
      "t": 69204,
      "e": 60704,
      "ty": 2,
      "x": 951,
      "y": 1064
    },
    {
      "t": 69254,
      "e": 60754,
      "ty": 41,
      "x": 32349,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69504,
      "e": 61004,
      "ty": 2,
      "x": 955,
      "y": 1064
    },
    {
      "t": 69505,
      "e": 61005,
      "ty": 41,
      "x": 32546,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69604,
      "e": 61104,
      "ty": 2,
      "x": 975,
      "y": 1062
    },
    {
      "t": 69704,
      "e": 61204,
      "ty": 2,
      "x": 988,
      "y": 1018
    },
    {
      "t": 69754,
      "e": 61254,
      "ty": 41,
      "x": 34218,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69804,
      "e": 61304,
      "ty": 2,
      "x": 992,
      "y": 979
    },
    {
      "t": 69904,
      "e": 61404,
      "ty": 2,
      "x": 992,
      "y": 977
    },
    {
      "t": 70004,
      "e": 61504,
      "ty": 2,
      "x": 996,
      "y": 997
    },
    {
      "t": 70004,
      "e": 61504,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70006,
      "e": 61506,
      "ty": 41,
      "x": 34563,
      "y": 60293,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70103,
      "e": 61603,
      "ty": 2,
      "x": 1029,
      "y": 1042
    },
    {
      "t": 70204,
      "e": 61704,
      "ty": 2,
      "x": 1030,
      "y": 1042
    },
    {
      "t": 70254,
      "e": 61754,
      "ty": 41,
      "x": 36235,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73007,
      "e": 64507,
      "ty": 2,
      "x": 1026,
      "y": 1047
    },
    {
      "t": 73009,
      "e": 64509,
      "ty": 41,
      "x": 36039,
      "y": 63756,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73109,
      "e": 64609,
      "ty": 2,
      "x": 1022,
      "y": 1048
    },
    {
      "t": 73208,
      "e": 64708,
      "ty": 2,
      "x": 1016,
      "y": 1051
    },
    {
      "t": 73258,
      "e": 64758,
      "ty": 41,
      "x": 35399,
      "y": 64102,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73309,
      "e": 64809,
      "ty": 2,
      "x": 1009,
      "y": 1054
    },
    {
      "t": 73408,
      "e": 64908,
      "ty": 2,
      "x": 991,
      "y": 1062
    },
    {
      "t": 73508,
      "e": 65008,
      "ty": 2,
      "x": 986,
      "y": 1064
    },
    {
      "t": 73509,
      "e": 65009,
      "ty": 41,
      "x": 34071,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73608,
      "e": 65108,
      "ty": 2,
      "x": 978,
      "y": 1068
    },
    {
      "t": 73642,
      "e": 65142,
      "ty": 6,
      "x": 975,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 73708,
      "e": 65208,
      "ty": 2,
      "x": 974,
      "y": 1076
    },
    {
      "t": 73758,
      "e": 65258,
      "ty": 41,
      "x": 35225,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 73807,
      "e": 65307,
      "ty": 2,
      "x": 974,
      "y": 1077
    },
    {
      "t": 74108,
      "e": 65608,
      "ty": 2,
      "x": 971,
      "y": 1079
    },
    {
      "t": 74208,
      "e": 65708,
      "ty": 2,
      "x": 971,
      "y": 1080
    },
    {
      "t": 74259,
      "e": 65759,
      "ty": 41,
      "x": 33586,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 74508,
      "e": 66008,
      "ty": 2,
      "x": 972,
      "y": 1078
    },
    {
      "t": 74508,
      "e": 66008,
      "ty": 41,
      "x": 34132,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 74608,
      "e": 66108,
      "ty": 2,
      "x": 976,
      "y": 1074
    },
    {
      "t": 74708,
      "e": 66208,
      "ty": 2,
      "x": 978,
      "y": 1073
    },
    {
      "t": 74758,
      "e": 66258,
      "ty": 41,
      "x": 37409,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 76244,
      "e": 67744,
      "ty": 7,
      "x": 982,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 76259,
      "e": 67759,
      "ty": 41,
      "x": 33874,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76308,
      "e": 67808,
      "ty": 2,
      "x": 990,
      "y": 1064
    },
    {
      "t": 76408,
      "e": 67908,
      "ty": 2,
      "x": 999,
      "y": 1059
    },
    {
      "t": 76508,
      "e": 68008,
      "ty": 2,
      "x": 1000,
      "y": 1059
    },
    {
      "t": 76508,
      "e": 68008,
      "ty": 41,
      "x": 34759,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76608,
      "e": 68108,
      "ty": 2,
      "x": 1004,
      "y": 1060
    },
    {
      "t": 76708,
      "e": 68208,
      "ty": 2,
      "x": 1006,
      "y": 1062
    },
    {
      "t": 76758,
      "e": 68258,
      "ty": 41,
      "x": 35104,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76808,
      "e": 68308,
      "ty": 2,
      "x": 1010,
      "y": 1066
    },
    {
      "t": 76908,
      "e": 68408,
      "ty": 2,
      "x": 1011,
      "y": 1068
    },
    {
      "t": 77009,
      "e": 68509,
      "ty": 41,
      "x": 35301,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80008,
      "e": 71508,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80109,
      "e": 71609,
      "ty": 2,
      "x": 1011,
      "y": 1066
    },
    {
      "t": 80259,
      "e": 71759,
      "ty": 41,
      "x": 35301,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84308,
      "e": 75808,
      "ty": 2,
      "x": 1009,
      "y": 1066
    },
    {
      "t": 84335,
      "e": 75835,
      "ty": 6,
      "x": 992,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 84408,
      "e": 75908,
      "ty": 2,
      "x": 983,
      "y": 1075
    },
    {
      "t": 84509,
      "e": 76009,
      "ty": 41,
      "x": 40140,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 84609,
      "e": 76109,
      "ty": 2,
      "x": 979,
      "y": 1077
    },
    {
      "t": 84709,
      "e": 76209,
      "ty": 2,
      "x": 975,
      "y": 1083
    },
    {
      "t": 84759,
      "e": 76259,
      "ty": 41,
      "x": 35771,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 84984,
      "e": 76484,
      "ty": 3,
      "x": 975,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 84984,
      "e": 76484,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85174,
      "e": 76674,
      "ty": 4,
      "x": 35771,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 85176,
      "e": 76676,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85177,
      "e": 76677,
      "ty": 5,
      "x": 975,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 85178,
      "e": 76678,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 86008,
      "e": 77508,
      "ty": 2,
      "x": 976,
      "y": 1096
    },
    {
      "t": 86009,
      "e": 77509,
      "ty": 41,
      "x": 33335,
      "y": 60272,
      "ta": "html > body"
    },
    {
      "t": 86108,
      "e": 77608,
      "ty": 2,
      "x": 957,
      "y": 1108
    },
    {
      "t": 86211,
      "e": 77711,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 86840,
      "e": 78340,
      "ty": 41,
      "x": 32622,
      "y": 32907,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 87381,
      "e": 78881,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 81941, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 81944, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4250, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 87548, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8194, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"LIMA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 96751, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13909, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 111749, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10409, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 123163, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 149737, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1014,y:1031,t:1527264541262};\\\", \\\"{x:1006,y:1026,t:1527264541278};\\\", \\\"{x:999,y:1025,t:1527264541295};\\\", \\\"{x:996,y:1022,t:1527264541311};\\\", \\\"{x:993,y:1022,t:1527264541327};\\\", \\\"{x:991,y:1022,t:1527264541345};\\\", \\\"{x:990,y:1022,t:1527264541364};\\\", \\\"{x:990,y:1020,t:1527264543101};\\\", \\\"{x:990,y:1019,t:1527264543113};\\\", \\\"{x:998,y:1012,t:1527264543129};\\\", \\\"{x:1008,y:1004,t:1527264543146};\\\", \\\"{x:1023,y:993,t:1527264543162};\\\", \\\"{x:1034,y:985,t:1527264543178};\\\", \\\"{x:1047,y:977,t:1527264543195};\\\", \\\"{x:1068,y:962,t:1527264543211};\\\", \\\"{x:1078,y:958,t:1527264543228};\\\", \\\"{x:1085,y:954,t:1527264543245};\\\", \\\"{x:1091,y:950,t:1527264543262};\\\", \\\"{x:1096,y:947,t:1527264543278};\\\", \\\"{x:1098,y:945,t:1527264543295};\\\", \\\"{x:1100,y:943,t:1527264543313};\\\", \\\"{x:1100,y:942,t:1527264543329};\\\", \\\"{x:1100,y:944,t:1527264543461};\\\", \\\"{x:1099,y:946,t:1527264543468};\\\", \\\"{x:1097,y:948,t:1527264543480};\\\", \\\"{x:1094,y:952,t:1527264543496};\\\", \\\"{x:1094,y:953,t:1527264543513};\\\", \\\"{x:1092,y:955,t:1527264543530};\\\", \\\"{x:1091,y:956,t:1527264543546};\\\", \\\"{x:1090,y:957,t:1527264543563};\\\", \\\"{x:1089,y:957,t:1527264543613};\\\", \\\"{x:1087,y:958,t:1527264543644};\\\", \\\"{x:1087,y:959,t:1527264543669};\\\", \\\"{x:1086,y:960,t:1527264543685};\\\", \\\"{x:1085,y:961,t:1527264543741};\\\", \\\"{x:1085,y:962,t:1527264545252};\\\", \\\"{x:1084,y:963,t:1527264545263};\\\", \\\"{x:1083,y:967,t:1527264545280};\\\", \\\"{x:1082,y:970,t:1527264545300};\\\", \\\"{x:1082,y:971,t:1527264545349};\\\", \\\"{x:1082,y:973,t:1527264545397};\\\", \\\"{x:1081,y:974,t:1527264545444};\\\", \\\"{x:1081,y:975,t:1527264545477};\\\", \\\"{x:1081,y:976,t:1527264545645};\\\", \\\"{x:1082,y:976,t:1527264545653};\\\", \\\"{x:1082,y:975,t:1527264545668};\\\", \\\"{x:1083,y:973,t:1527264545681};\\\", \\\"{x:1084,y:972,t:1527264545698};\\\", \\\"{x:1085,y:971,t:1527264545713};\\\", \\\"{x:1086,y:970,t:1527264545731};\\\", \\\"{x:1086,y:969,t:1527264546005};\\\", \\\"{x:1086,y:967,t:1527264546029};\\\", \\\"{x:1088,y:965,t:1527264558182};\\\", \\\"{x:1094,y:965,t:1527264558191};\\\", \\\"{x:1108,y:965,t:1527264558207};\\\", \\\"{x:1126,y:967,t:1527264558223};\\\", \\\"{x:1144,y:972,t:1527264558240};\\\", \\\"{x:1161,y:977,t:1527264558256};\\\", \\\"{x:1180,y:983,t:1527264558273};\\\", \\\"{x:1198,y:986,t:1527264558290};\\\", \\\"{x:1216,y:989,t:1527264558306};\\\", \\\"{x:1234,y:991,t:1527264558323};\\\", \\\"{x:1263,y:995,t:1527264558340};\\\", \\\"{x:1285,y:997,t:1527264558357};\\\", \\\"{x:1303,y:1000,t:1527264558373};\\\", \\\"{x:1321,y:1002,t:1527264558390};\\\", \\\"{x:1334,y:1004,t:1527264558407};\\\", \\\"{x:1346,y:1004,t:1527264558423};\\\", \\\"{x:1354,y:1004,t:1527264558440};\\\", \\\"{x:1360,y:1004,t:1527264558457};\\\", \\\"{x:1363,y:1004,t:1527264558473};\\\", \\\"{x:1365,y:1004,t:1527264558490};\\\", \\\"{x:1366,y:1004,t:1527264558565};\\\", \\\"{x:1366,y:1003,t:1527264558580};\\\", \\\"{x:1366,y:1002,t:1527264558590};\\\", \\\"{x:1362,y:998,t:1527264558607};\\\", \\\"{x:1350,y:991,t:1527264558623};\\\", \\\"{x:1332,y:987,t:1527264558640};\\\", \\\"{x:1312,y:981,t:1527264558657};\\\", \\\"{x:1289,y:975,t:1527264558673};\\\", \\\"{x:1271,y:969,t:1527264558691};\\\", \\\"{x:1265,y:967,t:1527264558708};\\\", \\\"{x:1263,y:966,t:1527264558723};\\\", \\\"{x:1265,y:965,t:1527264558925};\\\", \\\"{x:1270,y:965,t:1527264558941};\\\", \\\"{x:1274,y:965,t:1527264558957};\\\", \\\"{x:1278,y:963,t:1527264558975};\\\", \\\"{x:1279,y:962,t:1527264558991};\\\", \\\"{x:1283,y:961,t:1527264559008};\\\", \\\"{x:1284,y:960,t:1527264559053};\\\", \\\"{x:1285,y:960,t:1527264559061};\\\", \\\"{x:1287,y:960,t:1527264559077};\\\", \\\"{x:1289,y:960,t:1527264559092};\\\", \\\"{x:1290,y:960,t:1527264559107};\\\", \\\"{x:1294,y:960,t:1527264559124};\\\", \\\"{x:1295,y:960,t:1527264559140};\\\", \\\"{x:1296,y:960,t:1527264559158};\\\", \\\"{x:1296,y:961,t:1527264559221};\\\", \\\"{x:1296,y:962,t:1527264559229};\\\", \\\"{x:1296,y:963,t:1527264559244};\\\", \\\"{x:1295,y:963,t:1527264559259};\\\", \\\"{x:1294,y:963,t:1527264559274};\\\", \\\"{x:1293,y:963,t:1527264559291};\\\", \\\"{x:1291,y:964,t:1527264559306};\\\", \\\"{x:1289,y:965,t:1527264559324};\\\", \\\"{x:1287,y:966,t:1527264559341};\\\", \\\"{x:1284,y:966,t:1527264559357};\\\", \\\"{x:1280,y:967,t:1527264559374};\\\", \\\"{x:1279,y:967,t:1527264559391};\\\", \\\"{x:1278,y:967,t:1527264559407};\\\", \\\"{x:1277,y:967,t:1527264559424};\\\", \\\"{x:1276,y:967,t:1527264559444};\\\", \\\"{x:1271,y:967,t:1527264562485};\\\", \\\"{x:1259,y:967,t:1527264562493};\\\", \\\"{x:1223,y:962,t:1527264562510};\\\", \\\"{x:1140,y:941,t:1527264562526};\\\", \\\"{x:1001,y:893,t:1527264562543};\\\", \\\"{x:836,y:825,t:1527264562561};\\\", \\\"{x:660,y:742,t:1527264562576};\\\", \\\"{x:519,y:676,t:1527264562593};\\\", \\\"{x:416,y:627,t:1527264562609};\\\", \\\"{x:337,y:585,t:1527264562627};\\\", \\\"{x:278,y:542,t:1527264562643};\\\", \\\"{x:213,y:483,t:1527264562659};\\\", \\\"{x:182,y:455,t:1527264562676};\\\", \\\"{x:144,y:434,t:1527264562693};\\\", \\\"{x:96,y:411,t:1527264562710};\\\", \\\"{x:41,y:388,t:1527264562726};\\\", \\\"{x:0,y:372,t:1527264562743};\\\", \\\"{x:0,y:366,t:1527264562760};\\\", \\\"{x:0,y:362,t:1527264562776};\\\", \\\"{x:0,y:363,t:1527264562803};\\\", \\\"{x:0,y:366,t:1527264562811};\\\", \\\"{x:1,y:372,t:1527264562827};\\\", \\\"{x:11,y:394,t:1527264562843};\\\", \\\"{x:50,y:453,t:1527264562860};\\\", \\\"{x:96,y:501,t:1527264562877};\\\", \\\"{x:129,y:530,t:1527264562894};\\\", \\\"{x:149,y:543,t:1527264562910};\\\", \\\"{x:163,y:554,t:1527264562929};\\\", \\\"{x:170,y:559,t:1527264562945};\\\", \\\"{x:174,y:562,t:1527264562960};\\\", \\\"{x:178,y:562,t:1527264562978};\\\", \\\"{x:184,y:563,t:1527264562995};\\\", \\\"{x:197,y:567,t:1527264563011};\\\", \\\"{x:232,y:577,t:1527264563028};\\\", \\\"{x:256,y:578,t:1527264563045};\\\", \\\"{x:279,y:578,t:1527264563062};\\\", \\\"{x:306,y:578,t:1527264563078};\\\", \\\"{x:336,y:578,t:1527264563096};\\\", \\\"{x:360,y:578,t:1527264563112};\\\", \\\"{x:379,y:573,t:1527264563129};\\\", \\\"{x:390,y:567,t:1527264563145};\\\", \\\"{x:397,y:562,t:1527264563162};\\\", \\\"{x:400,y:559,t:1527264563178};\\\", \\\"{x:402,y:551,t:1527264563194};\\\", \\\"{x:402,y:541,t:1527264563212};\\\", \\\"{x:400,y:534,t:1527264563230};\\\", \\\"{x:395,y:529,t:1527264563245};\\\", \\\"{x:394,y:527,t:1527264563262};\\\", \\\"{x:393,y:527,t:1527264563924};\\\", \\\"{x:392,y:527,t:1527264563931};\\\", \\\"{x:391,y:527,t:1527264563945};\\\", \\\"{x:388,y:527,t:1527264563962};\\\", \\\"{x:387,y:527,t:1527264564076};\\\", \\\"{x:387,y:529,t:1527264564084};\\\", \\\"{x:392,y:537,t:1527264564097};\\\", \\\"{x:422,y:566,t:1527264564112};\\\", \\\"{x:464,y:613,t:1527264564129};\\\", \\\"{x:510,y:671,t:1527264564146};\\\", \\\"{x:546,y:714,t:1527264564163};\\\", \\\"{x:575,y:761,t:1527264564180};\\\", \\\"{x:586,y:783,t:1527264564195};\\\", \\\"{x:586,y:787,t:1527264564212};\\\", \\\"{x:586,y:789,t:1527264564228};\\\", \\\"{x:586,y:791,t:1527264564246};\\\", \\\"{x:585,y:791,t:1527264564262};\\\", \\\"{x:584,y:792,t:1527264564279};\\\", \\\"{x:583,y:792,t:1527264564308};\\\", \\\"{x:582,y:792,t:1527264564331};\\\", \\\"{x:581,y:792,t:1527264564346};\\\", \\\"{x:577,y:784,t:1527264564363};\\\", \\\"{x:571,y:768,t:1527264564379};\\\", \\\"{x:553,y:738,t:1527264564396};\\\", \\\"{x:542,y:725,t:1527264564413};\\\", \\\"{x:537,y:720,t:1527264564428};\\\", \\\"{x:534,y:719,t:1527264564445};\\\", \\\"{x:533,y:718,t:1527264564507};\\\", \\\"{x:533,y:717,t:1527264564531};\\\", \\\"{x:534,y:717,t:1527264564827};\\\", \\\"{x:537,y:718,t:1527264564835};\\\", \\\"{x:539,y:719,t:1527264564846};\\\", \\\"{x:544,y:722,t:1527264564862};\\\", \\\"{x:550,y:726,t:1527264564879};\\\", \\\"{x:558,y:729,t:1527264564896};\\\", \\\"{x:564,y:734,t:1527264564913};\\\", \\\"{x:567,y:735,t:1527264564930};\\\", \\\"{x:569,y:736,t:1527264564946};\\\", \\\"{x:570,y:737,t:1527264564964};\\\" ] }, { \\\"rt\\\": 9777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 160788, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:572,y:737,t:1527264568812};\\\", \\\"{x:592,y:726,t:1527264568820};\\\", \\\"{x:621,y:710,t:1527264568832};\\\", \\\"{x:702,y:670,t:1527264568850};\\\", \\\"{x:807,y:607,t:1527264568868};\\\", \\\"{x:930,y:536,t:1527264568883};\\\", \\\"{x:1077,y:471,t:1527264568900};\\\", \\\"{x:1135,y:445,t:1527264568916};\\\", \\\"{x:1168,y:430,t:1527264568933};\\\", \\\"{x:1193,y:417,t:1527264568949};\\\", \\\"{x:1218,y:403,t:1527264568966};\\\", \\\"{x:1246,y:383,t:1527264568983};\\\", \\\"{x:1288,y:362,t:1527264569001};\\\", \\\"{x:1343,y:339,t:1527264569016};\\\", \\\"{x:1393,y:318,t:1527264569033};\\\", \\\"{x:1435,y:311,t:1527264569050};\\\", \\\"{x:1473,y:308,t:1527264569066};\\\", \\\"{x:1510,y:308,t:1527264569083};\\\", \\\"{x:1530,y:310,t:1527264569099};\\\", \\\"{x:1550,y:320,t:1527264569116};\\\", \\\"{x:1569,y:335,t:1527264569134};\\\", \\\"{x:1587,y:352,t:1527264569151};\\\", \\\"{x:1610,y:379,t:1527264569166};\\\", \\\"{x:1635,y:405,t:1527264569183};\\\", \\\"{x:1654,y:422,t:1527264569200};\\\", \\\"{x:1668,y:434,t:1527264569217};\\\", \\\"{x:1677,y:445,t:1527264569234};\\\", \\\"{x:1681,y:457,t:1527264569250};\\\", \\\"{x:1681,y:491,t:1527264569268};\\\", \\\"{x:1681,y:525,t:1527264569283};\\\", \\\"{x:1685,y:558,t:1527264569300};\\\", \\\"{x:1691,y:579,t:1527264569318};\\\", \\\"{x:1696,y:593,t:1527264569334};\\\", \\\"{x:1698,y:600,t:1527264569350};\\\", \\\"{x:1700,y:608,t:1527264569368};\\\", \\\"{x:1701,y:617,t:1527264569383};\\\", \\\"{x:1701,y:629,t:1527264569401};\\\", \\\"{x:1701,y:640,t:1527264569417};\\\", \\\"{x:1697,y:646,t:1527264569433};\\\", \\\"{x:1694,y:647,t:1527264569450};\\\", \\\"{x:1693,y:647,t:1527264569467};\\\", \\\"{x:1691,y:647,t:1527264569533};\\\", \\\"{x:1690,y:647,t:1527264569564};\\\", \\\"{x:1689,y:647,t:1527264569580};\\\", \\\"{x:1688,y:647,t:1527264569589};\\\", \\\"{x:1688,y:646,t:1527264569717};\\\", \\\"{x:1688,y:637,t:1527264569735};\\\", \\\"{x:1688,y:615,t:1527264569752};\\\", \\\"{x:1687,y:586,t:1527264569767};\\\", \\\"{x:1680,y:560,t:1527264569785};\\\", \\\"{x:1676,y:535,t:1527264569802};\\\", \\\"{x:1669,y:514,t:1527264569818};\\\", \\\"{x:1666,y:501,t:1527264569835};\\\", \\\"{x:1663,y:482,t:1527264569852};\\\", \\\"{x:1662,y:468,t:1527264569868};\\\", \\\"{x:1659,y:457,t:1527264569884};\\\", \\\"{x:1654,y:445,t:1527264569901};\\\", \\\"{x:1651,y:439,t:1527264569918};\\\", \\\"{x:1650,y:435,t:1527264569934};\\\", \\\"{x:1649,y:435,t:1527264569951};\\\", \\\"{x:1649,y:434,t:1527264569967};\\\", \\\"{x:1648,y:433,t:1527264569985};\\\", \\\"{x:1648,y:431,t:1527264570002};\\\", \\\"{x:1646,y:430,t:1527264570019};\\\", \\\"{x:1643,y:429,t:1527264570035};\\\", \\\"{x:1634,y:428,t:1527264570052};\\\", \\\"{x:1624,y:425,t:1527264570068};\\\", \\\"{x:1609,y:421,t:1527264570085};\\\", \\\"{x:1593,y:415,t:1527264570101};\\\", \\\"{x:1586,y:414,t:1527264570118};\\\", \\\"{x:1581,y:411,t:1527264570135};\\\", \\\"{x:1577,y:409,t:1527264570152};\\\", \\\"{x:1574,y:408,t:1527264570169};\\\", \\\"{x:1572,y:407,t:1527264570184};\\\", \\\"{x:1574,y:407,t:1527264570236};\\\", \\\"{x:1578,y:407,t:1527264570251};\\\", \\\"{x:1584,y:408,t:1527264570268};\\\", \\\"{x:1594,y:414,t:1527264570285};\\\", \\\"{x:1602,y:418,t:1527264570301};\\\", \\\"{x:1605,y:418,t:1527264570319};\\\", \\\"{x:1611,y:420,t:1527264570335};\\\", \\\"{x:1613,y:421,t:1527264570351};\\\", \\\"{x:1613,y:422,t:1527264570580};\\\", \\\"{x:1613,y:423,t:1527264570588};\\\", \\\"{x:1613,y:424,t:1527264570604};\\\", \\\"{x:1612,y:428,t:1527264570621};\\\", \\\"{x:1612,y:433,t:1527264570636};\\\", \\\"{x:1612,y:444,t:1527264570653};\\\", \\\"{x:1612,y:455,t:1527264570669};\\\", \\\"{x:1613,y:467,t:1527264570685};\\\", \\\"{x:1616,y:484,t:1527264570703};\\\", \\\"{x:1617,y:499,t:1527264570719};\\\", \\\"{x:1617,y:509,t:1527264570736};\\\", \\\"{x:1617,y:517,t:1527264570752};\\\", \\\"{x:1617,y:523,t:1527264570770};\\\", \\\"{x:1615,y:532,t:1527264570785};\\\", \\\"{x:1611,y:543,t:1527264570803};\\\", \\\"{x:1607,y:552,t:1527264570820};\\\", \\\"{x:1606,y:558,t:1527264570836};\\\", \\\"{x:1606,y:563,t:1527264570852};\\\", \\\"{x:1606,y:566,t:1527264570870};\\\", \\\"{x:1606,y:569,t:1527264570886};\\\", \\\"{x:1606,y:572,t:1527264570903};\\\", \\\"{x:1606,y:573,t:1527264570920};\\\", \\\"{x:1606,y:576,t:1527264570936};\\\", \\\"{x:1606,y:580,t:1527264570952};\\\", \\\"{x:1607,y:582,t:1527264570970};\\\", \\\"{x:1607,y:583,t:1527264570987};\\\", \\\"{x:1608,y:583,t:1527264571052};\\\", \\\"{x:1609,y:583,t:1527264571070};\\\", \\\"{x:1610,y:582,t:1527264571087};\\\", \\\"{x:1611,y:580,t:1527264571108};\\\", \\\"{x:1612,y:579,t:1527264571349};\\\", \\\"{x:1614,y:579,t:1527264571372};\\\", \\\"{x:1614,y:581,t:1527264571386};\\\", \\\"{x:1617,y:599,t:1527264571404};\\\", \\\"{x:1620,y:616,t:1527264571420};\\\", \\\"{x:1624,y:642,t:1527264571436};\\\", \\\"{x:1631,y:663,t:1527264571453};\\\", \\\"{x:1635,y:675,t:1527264571471};\\\", \\\"{x:1635,y:678,t:1527264571486};\\\", \\\"{x:1635,y:683,t:1527264571504};\\\", \\\"{x:1635,y:691,t:1527264571521};\\\", \\\"{x:1635,y:702,t:1527264571537};\\\", \\\"{x:1635,y:714,t:1527264571553};\\\", \\\"{x:1635,y:727,t:1527264571571};\\\", \\\"{x:1635,y:737,t:1527264571587};\\\", \\\"{x:1635,y:759,t:1527264571604};\\\", \\\"{x:1635,y:776,t:1527264571620};\\\", \\\"{x:1635,y:792,t:1527264571637};\\\", \\\"{x:1635,y:809,t:1527264571654};\\\", \\\"{x:1635,y:827,t:1527264571671};\\\", \\\"{x:1635,y:838,t:1527264571687};\\\", \\\"{x:1635,y:851,t:1527264571704};\\\", \\\"{x:1635,y:862,t:1527264571721};\\\", \\\"{x:1635,y:873,t:1527264571738};\\\", \\\"{x:1635,y:883,t:1527264571754};\\\", \\\"{x:1635,y:889,t:1527264571771};\\\", \\\"{x:1635,y:892,t:1527264571788};\\\", \\\"{x:1635,y:894,t:1527264571804};\\\", \\\"{x:1635,y:895,t:1527264572013};\\\", \\\"{x:1635,y:886,t:1527264572148};\\\", \\\"{x:1635,y:875,t:1527264572156};\\\", \\\"{x:1635,y:859,t:1527264572171};\\\", \\\"{x:1635,y:756,t:1527264572188};\\\", \\\"{x:1635,y:694,t:1527264572204};\\\", \\\"{x:1635,y:636,t:1527264572222};\\\", \\\"{x:1635,y:591,t:1527264572238};\\\", \\\"{x:1635,y:568,t:1527264572255};\\\", \\\"{x:1635,y:550,t:1527264572272};\\\", \\\"{x:1635,y:539,t:1527264572288};\\\", \\\"{x:1635,y:533,t:1527264572305};\\\", \\\"{x:1635,y:529,t:1527264572322};\\\", \\\"{x:1635,y:524,t:1527264572338};\\\", \\\"{x:1635,y:516,t:1527264572354};\\\", \\\"{x:1635,y:493,t:1527264572372};\\\", \\\"{x:1635,y:482,t:1527264572388};\\\", \\\"{x:1634,y:479,t:1527264572405};\\\", \\\"{x:1634,y:478,t:1527264572422};\\\", \\\"{x:1634,y:477,t:1527264572438};\\\", \\\"{x:1633,y:475,t:1527264572455};\\\", \\\"{x:1632,y:475,t:1527264572476};\\\", \\\"{x:1631,y:476,t:1527264572489};\\\", \\\"{x:1627,y:481,t:1527264572505};\\\", \\\"{x:1626,y:488,t:1527264572522};\\\", \\\"{x:1625,y:494,t:1527264572539};\\\", \\\"{x:1623,y:499,t:1527264572555};\\\", \\\"{x:1623,y:509,t:1527264572572};\\\", \\\"{x:1623,y:517,t:1527264572588};\\\", \\\"{x:1621,y:532,t:1527264572605};\\\", \\\"{x:1621,y:549,t:1527264572622};\\\", \\\"{x:1621,y:568,t:1527264572639};\\\", \\\"{x:1620,y:583,t:1527264572655};\\\", \\\"{x:1620,y:603,t:1527264572672};\\\", \\\"{x:1620,y:621,t:1527264572689};\\\", \\\"{x:1617,y:643,t:1527264572706};\\\", \\\"{x:1615,y:657,t:1527264572722};\\\", \\\"{x:1613,y:664,t:1527264572739};\\\", \\\"{x:1601,y:669,t:1527264572756};\\\", \\\"{x:1580,y:669,t:1527264572774};\\\", \\\"{x:1517,y:653,t:1527264572789};\\\", \\\"{x:1401,y:622,t:1527264572806};\\\", \\\"{x:1227,y:572,t:1527264572822};\\\", \\\"{x:1031,y:514,t:1527264572839};\\\", \\\"{x:846,y:469,t:1527264572856};\\\", \\\"{x:683,y:449,t:1527264572872};\\\", \\\"{x:567,y:449,t:1527264572888};\\\", \\\"{x:491,y:462,t:1527264572906};\\\", \\\"{x:464,y:483,t:1527264572922};\\\", \\\"{x:452,y:510,t:1527264572940};\\\", \\\"{x:450,y:525,t:1527264572955};\\\", \\\"{x:448,y:530,t:1527264572972};\\\", \\\"{x:448,y:529,t:1527264573812};\\\", \\\"{x:449,y:528,t:1527264573844};\\\", \\\"{x:449,y:527,t:1527264573859};\\\", \\\"{x:447,y:527,t:1527264573933};\\\", \\\"{x:444,y:526,t:1527264573940};\\\", \\\"{x:438,y:526,t:1527264573956};\\\", \\\"{x:431,y:526,t:1527264573972};\\\", \\\"{x:422,y:527,t:1527264573989};\\\", \\\"{x:416,y:529,t:1527264574006};\\\", \\\"{x:410,y:534,t:1527264574023};\\\", \\\"{x:404,y:541,t:1527264574040};\\\", \\\"{x:399,y:559,t:1527264574071};\\\", \\\"{x:395,y:568,t:1527264574087};\\\", \\\"{x:393,y:574,t:1527264574104};\\\", \\\"{x:390,y:581,t:1527264574121};\\\", \\\"{x:387,y:586,t:1527264574138};\\\", \\\"{x:385,y:589,t:1527264574153};\\\", \\\"{x:381,y:593,t:1527264574170};\\\", \\\"{x:372,y:597,t:1527264574188};\\\", \\\"{x:362,y:600,t:1527264574203};\\\", \\\"{x:348,y:604,t:1527264574220};\\\", \\\"{x:326,y:606,t:1527264574237};\\\", \\\"{x:306,y:610,t:1527264574253};\\\", \\\"{x:284,y:611,t:1527264574270};\\\", \\\"{x:262,y:613,t:1527264574287};\\\", \\\"{x:247,y:613,t:1527264574303};\\\", \\\"{x:241,y:615,t:1527264574320};\\\", \\\"{x:239,y:615,t:1527264574337};\\\", \\\"{x:238,y:614,t:1527264574363};\\\", \\\"{x:237,y:613,t:1527264574371};\\\", \\\"{x:234,y:607,t:1527264574388};\\\", \\\"{x:230,y:602,t:1527264574403};\\\", \\\"{x:225,y:596,t:1527264574420};\\\", \\\"{x:223,y:593,t:1527264574437};\\\", \\\"{x:221,y:591,t:1527264574453};\\\", \\\"{x:218,y:589,t:1527264574470};\\\", \\\"{x:210,y:586,t:1527264574487};\\\", \\\"{x:205,y:585,t:1527264574504};\\\", \\\"{x:200,y:584,t:1527264574520};\\\", \\\"{x:199,y:584,t:1527264574537};\\\", \\\"{x:198,y:584,t:1527264574555};\\\", \\\"{x:197,y:584,t:1527264574570};\\\", \\\"{x:191,y:586,t:1527264574589};\\\", \\\"{x:182,y:594,t:1527264574604};\\\", \\\"{x:176,y:604,t:1527264574620};\\\", \\\"{x:168,y:618,t:1527264574638};\\\", \\\"{x:167,y:623,t:1527264574655};\\\", \\\"{x:166,y:625,t:1527264574670};\\\", \\\"{x:165,y:628,t:1527264574687};\\\", \\\"{x:164,y:630,t:1527264574707};\\\", \\\"{x:163,y:632,t:1527264574723};\\\", \\\"{x:163,y:633,t:1527264574747};\\\", \\\"{x:163,y:635,t:1527264574755};\\\", \\\"{x:160,y:639,t:1527264574772};\\\", \\\"{x:160,y:640,t:1527264574787};\\\", \\\"{x:160,y:642,t:1527264574804};\\\", \\\"{x:161,y:642,t:1527264575091};\\\", \\\"{x:166,y:642,t:1527264575104};\\\", \\\"{x:180,y:636,t:1527264575122};\\\", \\\"{x:206,y:635,t:1527264575138};\\\", \\\"{x:240,y:635,t:1527264575155};\\\", \\\"{x:339,y:658,t:1527264575172};\\\", \\\"{x:398,y:677,t:1527264575189};\\\", \\\"{x:448,y:689,t:1527264575205};\\\", \\\"{x:478,y:700,t:1527264575221};\\\", \\\"{x:497,y:709,t:1527264575239};\\\", \\\"{x:512,y:718,t:1527264575255};\\\", \\\"{x:521,y:723,t:1527264575271};\\\", \\\"{x:530,y:728,t:1527264575288};\\\", \\\"{x:533,y:729,t:1527264575305};\\\", \\\"{x:538,y:733,t:1527264575322};\\\", \\\"{x:544,y:737,t:1527264575339};\\\", \\\"{x:547,y:740,t:1527264575354};\\\", \\\"{x:552,y:747,t:1527264575372};\\\", \\\"{x:554,y:749,t:1527264575388};\\\", \\\"{x:554,y:748,t:1527264575476};\\\", \\\"{x:554,y:744,t:1527264575489};\\\", \\\"{x:554,y:734,t:1527264575506};\\\", \\\"{x:554,y:729,t:1527264575521};\\\", \\\"{x:554,y:726,t:1527264575538};\\\", \\\"{x:553,y:722,t:1527264575554};\\\", \\\"{x:553,y:721,t:1527264575572};\\\" ] }, { \\\"rt\\\": 60947, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 222985, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -A -A -A -A -Z -C -C -10 AM-C -A -Z -Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:719,t:1527264579285};\\\", \\\"{x:564,y:651,t:1527264579303};\\\", \\\"{x:580,y:559,t:1527264579320};\\\", \\\"{x:587,y:474,t:1527264579336};\\\", \\\"{x:588,y:403,t:1527264579358};\\\", \\\"{x:589,y:378,t:1527264579375};\\\", \\\"{x:590,y:368,t:1527264579391};\\\", \\\"{x:590,y:364,t:1527264579407};\\\", \\\"{x:589,y:362,t:1527264579425};\\\", \\\"{x:587,y:362,t:1527264579507};\\\", \\\"{x:579,y:375,t:1527264579524};\\\", \\\"{x:568,y:397,t:1527264579542};\\\", \\\"{x:555,y:430,t:1527264579559};\\\", \\\"{x:543,y:462,t:1527264579575};\\\", \\\"{x:534,y:483,t:1527264579592};\\\", \\\"{x:531,y:492,t:1527264579609};\\\", \\\"{x:531,y:495,t:1527264579624};\\\", \\\"{x:530,y:497,t:1527264579642};\\\", \\\"{x:530,y:496,t:1527264579764};\\\", \\\"{x:530,y:494,t:1527264579775};\\\", \\\"{x:530,y:489,t:1527264579792};\\\", \\\"{x:530,y:486,t:1527264579809};\\\", \\\"{x:530,y:483,t:1527264579825};\\\", \\\"{x:530,y:479,t:1527264579842};\\\", \\\"{x:530,y:476,t:1527264579859};\\\", \\\"{x:531,y:473,t:1527264579874};\\\", \\\"{x:531,y:472,t:1527264579891};\\\", \\\"{x:531,y:471,t:1527264579909};\\\", \\\"{x:530,y:471,t:1527264580020};\\\", \\\"{x:529,y:471,t:1527264580051};\\\", \\\"{x:527,y:472,t:1527264580076};\\\", \\\"{x:526,y:472,t:1527264580100};\\\", \\\"{x:526,y:473,t:1527264580116};\\\", \\\"{x:525,y:473,t:1527264580180};\\\", \\\"{x:524,y:474,t:1527264580196};\\\", \\\"{x:523,y:474,t:1527264580212};\\\", \\\"{x:522,y:475,t:1527264580244};\\\", \\\"{x:521,y:475,t:1527264580309};\\\", \\\"{x:520,y:475,t:1527264580326};\\\", \\\"{x:518,y:475,t:1527264580343};\\\", \\\"{x:517,y:475,t:1527264580359};\\\", \\\"{x:516,y:475,t:1527264580376};\\\", \\\"{x:514,y:475,t:1527264580393};\\\", \\\"{x:513,y:475,t:1527264580408};\\\", \\\"{x:512,y:475,t:1527264580428};\\\", \\\"{x:511,y:475,t:1527264580444};\\\", \\\"{x:511,y:473,t:1527264580516};\\\", \\\"{x:512,y:473,t:1527264580620};\\\", \\\"{x:513,y:472,t:1527264580628};\\\", \\\"{x:514,y:472,t:1527264580643};\\\", \\\"{x:521,y:471,t:1527264580659};\\\", \\\"{x:533,y:468,t:1527264580675};\\\", \\\"{x:545,y:463,t:1527264580693};\\\", \\\"{x:557,y:457,t:1527264580710};\\\", \\\"{x:567,y:451,t:1527264580726};\\\", \\\"{x:570,y:449,t:1527264580743};\\\", \\\"{x:571,y:449,t:1527264580828};\\\", \\\"{x:571,y:448,t:1527264580851};\\\", \\\"{x:569,y:448,t:1527264580876};\\\", \\\"{x:568,y:448,t:1527264580893};\\\", \\\"{x:565,y:448,t:1527264580916};\\\", \\\"{x:565,y:449,t:1527264580926};\\\", \\\"{x:565,y:450,t:1527264580948};\\\", \\\"{x:565,y:452,t:1527264580964};\\\", \\\"{x:565,y:453,t:1527264580976};\\\", \\\"{x:578,y:458,t:1527264580993};\\\", \\\"{x:611,y:468,t:1527264581010};\\\", \\\"{x:672,y:485,t:1527264581026};\\\", \\\"{x:757,y:506,t:1527264581044};\\\", \\\"{x:903,y:527,t:1527264581059};\\\", \\\"{x:953,y:529,t:1527264581074};\\\", \\\"{x:1028,y:529,t:1527264581091};\\\", \\\"{x:1102,y:507,t:1527264581110};\\\", \\\"{x:1148,y:482,t:1527264581126};\\\", \\\"{x:1182,y:458,t:1527264581142};\\\", \\\"{x:1206,y:445,t:1527264581159};\\\", \\\"{x:1236,y:437,t:1527264581176};\\\", \\\"{x:1262,y:433,t:1527264581193};\\\", \\\"{x:1284,y:432,t:1527264581210};\\\", \\\"{x:1303,y:432,t:1527264581226};\\\", \\\"{x:1328,y:432,t:1527264581242};\\\", \\\"{x:1374,y:434,t:1527264581259};\\\", \\\"{x:1398,y:435,t:1527264581275};\\\", \\\"{x:1408,y:436,t:1527264581292};\\\", \\\"{x:1408,y:437,t:1527264582796};\\\", \\\"{x:1408,y:438,t:1527264582893};\\\", \\\"{x:1408,y:439,t:1527264583293};\\\", \\\"{x:1408,y:441,t:1527264583308};\\\", \\\"{x:1408,y:442,t:1527264583316};\\\", \\\"{x:1408,y:443,t:1527264583347};\\\", \\\"{x:1408,y:444,t:1527264583372};\\\", \\\"{x:1408,y:445,t:1527264583620};\\\", \\\"{x:1408,y:446,t:1527264583628};\\\", \\\"{x:1408,y:449,t:1527264583646};\\\", \\\"{x:1408,y:454,t:1527264583662};\\\", \\\"{x:1408,y:465,t:1527264583678};\\\", \\\"{x:1408,y:483,t:1527264583695};\\\", \\\"{x:1408,y:505,t:1527264583711};\\\", \\\"{x:1407,y:530,t:1527264583729};\\\", \\\"{x:1402,y:564,t:1527264583745};\\\", \\\"{x:1396,y:599,t:1527264583762};\\\", \\\"{x:1390,y:649,t:1527264583778};\\\", \\\"{x:1390,y:713,t:1527264583796};\\\", \\\"{x:1412,y:827,t:1527264583812};\\\", \\\"{x:1434,y:884,t:1527264583828};\\\", \\\"{x:1446,y:917,t:1527264583846};\\\", \\\"{x:1447,y:940,t:1527264583862};\\\", \\\"{x:1443,y:967,t:1527264583879};\\\", \\\"{x:1428,y:990,t:1527264583895};\\\", \\\"{x:1415,y:1007,t:1527264583912};\\\", \\\"{x:1406,y:1017,t:1527264583928};\\\", \\\"{x:1399,y:1023,t:1527264583946};\\\", \\\"{x:1390,y:1027,t:1527264583963};\\\", \\\"{x:1378,y:1033,t:1527264583978};\\\", \\\"{x:1364,y:1038,t:1527264583996};\\\", \\\"{x:1360,y:1040,t:1527264584012};\\\", \\\"{x:1360,y:1036,t:1527264584397};\\\", \\\"{x:1360,y:1027,t:1527264584412};\\\", \\\"{x:1359,y:1019,t:1527264584429};\\\", \\\"{x:1355,y:1000,t:1527264584446};\\\", \\\"{x:1341,y:965,t:1527264584462};\\\", \\\"{x:1320,y:923,t:1527264584479};\\\", \\\"{x:1307,y:903,t:1527264584496};\\\", \\\"{x:1304,y:897,t:1527264584512};\\\", \\\"{x:1301,y:889,t:1527264584529};\\\", \\\"{x:1295,y:877,t:1527264584546};\\\", \\\"{x:1290,y:870,t:1527264584562};\\\", \\\"{x:1285,y:863,t:1527264584579};\\\", \\\"{x:1282,y:861,t:1527264584595};\\\", \\\"{x:1279,y:859,t:1527264584612};\\\", \\\"{x:1275,y:858,t:1527264584629};\\\", \\\"{x:1268,y:855,t:1527264584646};\\\", \\\"{x:1257,y:852,t:1527264584662};\\\", \\\"{x:1245,y:846,t:1527264584679};\\\", \\\"{x:1231,y:841,t:1527264584695};\\\", \\\"{x:1218,y:835,t:1527264584713};\\\", \\\"{x:1208,y:833,t:1527264584730};\\\", \\\"{x:1202,y:829,t:1527264584745};\\\", \\\"{x:1200,y:829,t:1527264584763};\\\", \\\"{x:1199,y:827,t:1527264584837};\\\", \\\"{x:1199,y:826,t:1527264584965};\\\", \\\"{x:1200,y:826,t:1527264584980};\\\", \\\"{x:1202,y:826,t:1527264584996};\\\", \\\"{x:1203,y:826,t:1527264585044};\\\", \\\"{x:1204,y:826,t:1527264585108};\\\", \\\"{x:1205,y:826,t:1527264585116};\\\", \\\"{x:1206,y:826,t:1527264585132};\\\", \\\"{x:1207,y:826,t:1527264585203};\\\", \\\"{x:1208,y:826,t:1527264585212};\\\", \\\"{x:1209,y:826,t:1527264585243};\\\", \\\"{x:1211,y:826,t:1527264585535};\\\", \\\"{x:1211,y:827,t:1527264585587};\\\", \\\"{x:1212,y:827,t:1527264585619};\\\", \\\"{x:1214,y:828,t:1527264585732};\\\", \\\"{x:1216,y:828,t:1527264585764};\\\", \\\"{x:1217,y:828,t:1527264585779};\\\", \\\"{x:1218,y:828,t:1527264585820};\\\", \\\"{x:1219,y:828,t:1527264585868};\\\", \\\"{x:1219,y:829,t:1527264585880};\\\", \\\"{x:1220,y:829,t:1527264585896};\\\", \\\"{x:1221,y:830,t:1527264586109};\\\", \\\"{x:1222,y:830,t:1527264586124};\\\", \\\"{x:1223,y:830,t:1527264586365};\\\", \\\"{x:1227,y:830,t:1527264586379};\\\", \\\"{x:1233,y:831,t:1527264586398};\\\", \\\"{x:1242,y:831,t:1527264586414};\\\", \\\"{x:1254,y:831,t:1527264586431};\\\", \\\"{x:1267,y:831,t:1527264586447};\\\", \\\"{x:1278,y:831,t:1527264586464};\\\", \\\"{x:1291,y:831,t:1527264586481};\\\", \\\"{x:1299,y:831,t:1527264586497};\\\", \\\"{x:1304,y:831,t:1527264586513};\\\", \\\"{x:1308,y:831,t:1527264586530};\\\", \\\"{x:1311,y:831,t:1527264586547};\\\", \\\"{x:1313,y:831,t:1527264586563};\\\", \\\"{x:1314,y:831,t:1527264586588};\\\", \\\"{x:1313,y:831,t:1527264586692};\\\", \\\"{x:1311,y:831,t:1527264586700};\\\", \\\"{x:1310,y:831,t:1527264586713};\\\", \\\"{x:1308,y:831,t:1527264586730};\\\", \\\"{x:1305,y:831,t:1527264586747};\\\", \\\"{x:1301,y:833,t:1527264586763};\\\", \\\"{x:1300,y:834,t:1527264586787};\\\", \\\"{x:1300,y:835,t:1527264586812};\\\", \\\"{x:1299,y:835,t:1527264586835};\\\", \\\"{x:1298,y:836,t:1527264586847};\\\", \\\"{x:1297,y:836,t:1527264586867};\\\", \\\"{x:1297,y:837,t:1527264587133};\\\", \\\"{x:1296,y:838,t:1527264587164};\\\", \\\"{x:1295,y:838,t:1527264587181};\\\", \\\"{x:1294,y:838,t:1527264587788};\\\", \\\"{x:1292,y:838,t:1527264587798};\\\", \\\"{x:1291,y:837,t:1527264587815};\\\", \\\"{x:1289,y:838,t:1527264588589};\\\", \\\"{x:1289,y:841,t:1527264588598};\\\", \\\"{x:1288,y:849,t:1527264588615};\\\", \\\"{x:1287,y:857,t:1527264588631};\\\", \\\"{x:1287,y:864,t:1527264588649};\\\", \\\"{x:1287,y:871,t:1527264588666};\\\", \\\"{x:1286,y:876,t:1527264588682};\\\", \\\"{x:1285,y:881,t:1527264588698};\\\", \\\"{x:1285,y:887,t:1527264588716};\\\", \\\"{x:1285,y:894,t:1527264588732};\\\", \\\"{x:1285,y:900,t:1527264588749};\\\", \\\"{x:1285,y:905,t:1527264588766};\\\", \\\"{x:1285,y:909,t:1527264588782};\\\", \\\"{x:1284,y:912,t:1527264588798};\\\", \\\"{x:1283,y:917,t:1527264588815};\\\", \\\"{x:1283,y:922,t:1527264588832};\\\", \\\"{x:1283,y:930,t:1527264588849};\\\", \\\"{x:1284,y:942,t:1527264588865};\\\", \\\"{x:1285,y:945,t:1527264588882};\\\", \\\"{x:1286,y:949,t:1527264588898};\\\", \\\"{x:1287,y:953,t:1527264588916};\\\", \\\"{x:1287,y:957,t:1527264588932};\\\", \\\"{x:1288,y:958,t:1527264588956};\\\", \\\"{x:1288,y:953,t:1527264589076};\\\", \\\"{x:1288,y:942,t:1527264589084};\\\", \\\"{x:1288,y:931,t:1527264589099};\\\", \\\"{x:1284,y:878,t:1527264589116};\\\", \\\"{x:1280,y:856,t:1527264589132};\\\", \\\"{x:1279,y:845,t:1527264589148};\\\", \\\"{x:1279,y:840,t:1527264589166};\\\", \\\"{x:1279,y:834,t:1527264589183};\\\", \\\"{x:1279,y:830,t:1527264589199};\\\", \\\"{x:1279,y:828,t:1527264589215};\\\", \\\"{x:1279,y:826,t:1527264589232};\\\", \\\"{x:1279,y:825,t:1527264589249};\\\", \\\"{x:1279,y:823,t:1527264589266};\\\", \\\"{x:1279,y:822,t:1527264589380};\\\", \\\"{x:1280,y:822,t:1527264589403};\\\", \\\"{x:1281,y:824,t:1527264589416};\\\", \\\"{x:1281,y:825,t:1527264589433};\\\", \\\"{x:1281,y:826,t:1527264589449};\\\", \\\"{x:1281,y:827,t:1527264589465};\\\", \\\"{x:1281,y:828,t:1527264589482};\\\", \\\"{x:1281,y:829,t:1527264589499};\\\", \\\"{x:1281,y:830,t:1527264589564};\\\", \\\"{x:1281,y:831,t:1527264589571};\\\", \\\"{x:1281,y:832,t:1527264589582};\\\", \\\"{x:1281,y:834,t:1527264589600};\\\", \\\"{x:1281,y:835,t:1527264589615};\\\", \\\"{x:1281,y:834,t:1527264590956};\\\", \\\"{x:1280,y:832,t:1527264590967};\\\", \\\"{x:1280,y:830,t:1527264590983};\\\", \\\"{x:1280,y:828,t:1527264591000};\\\", \\\"{x:1280,y:826,t:1527264591016};\\\", \\\"{x:1280,y:825,t:1527264592469};\\\", \\\"{x:1279,y:825,t:1527264592485};\\\", \\\"{x:1278,y:824,t:1527264592502};\\\", \\\"{x:1276,y:822,t:1527264592518};\\\", \\\"{x:1274,y:822,t:1527264592535};\\\", \\\"{x:1272,y:821,t:1527264592551};\\\", \\\"{x:1270,y:821,t:1527264592568};\\\", \\\"{x:1266,y:821,t:1527264592585};\\\", \\\"{x:1259,y:821,t:1527264592602};\\\", \\\"{x:1252,y:821,t:1527264592619};\\\", \\\"{x:1242,y:819,t:1527264592635};\\\", \\\"{x:1232,y:817,t:1527264592651};\\\", \\\"{x:1229,y:817,t:1527264592668};\\\", \\\"{x:1228,y:817,t:1527264592684};\\\", \\\"{x:1227,y:817,t:1527264592716};\\\", \\\"{x:1226,y:817,t:1527264592724};\\\", \\\"{x:1225,y:817,t:1527264592748};\\\", \\\"{x:1224,y:817,t:1527264592828};\\\", \\\"{x:1221,y:817,t:1527264592851};\\\", \\\"{x:1220,y:817,t:1527264592868};\\\", \\\"{x:1218,y:817,t:1527264592964};\\\", \\\"{x:1218,y:816,t:1527264593109};\\\", \\\"{x:1218,y:815,t:1527264593140};\\\", \\\"{x:1218,y:814,t:1527264593152};\\\", \\\"{x:1218,y:815,t:1527264594751};\\\", \\\"{x:1219,y:817,t:1527264594783};\\\", \\\"{x:1219,y:818,t:1527264594815};\\\", \\\"{x:1220,y:820,t:1527264594871};\\\", \\\"{x:1220,y:821,t:1527264594895};\\\", \\\"{x:1220,y:823,t:1527264594934};\\\", \\\"{x:1221,y:823,t:1527264594943};\\\", \\\"{x:1221,y:824,t:1527264595015};\\\", \\\"{x:1221,y:826,t:1527264595046};\\\", \\\"{x:1222,y:827,t:1527264595057};\\\", \\\"{x:1222,y:828,t:1527264595073};\\\", \\\"{x:1224,y:830,t:1527264595090};\\\", \\\"{x:1224,y:833,t:1527264595107};\\\", \\\"{x:1225,y:837,t:1527264595123};\\\", \\\"{x:1227,y:839,t:1527264595140};\\\", \\\"{x:1227,y:840,t:1527264595157};\\\", \\\"{x:1228,y:840,t:1527264595173};\\\", \\\"{x:1227,y:839,t:1527264595423};\\\", \\\"{x:1227,y:838,t:1527264595463};\\\", \\\"{x:1226,y:837,t:1527264595478};\\\", \\\"{x:1225,y:836,t:1527264595535};\\\", \\\"{x:1224,y:836,t:1527264595591};\\\", \\\"{x:1223,y:836,t:1527264595863};\\\", \\\"{x:1223,y:835,t:1527264595886};\\\", \\\"{x:1223,y:834,t:1527264596143};\\\", \\\"{x:1223,y:833,t:1527264596174};\\\", \\\"{x:1223,y:832,t:1527264596190};\\\", \\\"{x:1227,y:834,t:1527264599887};\\\", \\\"{x:1239,y:836,t:1527264599895};\\\", \\\"{x:1253,y:838,t:1527264599910};\\\", \\\"{x:1320,y:854,t:1527264599926};\\\", \\\"{x:1365,y:869,t:1527264599942};\\\", \\\"{x:1396,y:878,t:1527264599960};\\\", \\\"{x:1409,y:881,t:1527264599977};\\\", \\\"{x:1414,y:883,t:1527264599993};\\\", \\\"{x:1412,y:883,t:1527264600238};\\\", \\\"{x:1411,y:883,t:1527264600335};\\\", \\\"{x:1409,y:883,t:1527264600367};\\\", \\\"{x:1408,y:884,t:1527264600377};\\\", \\\"{x:1406,y:887,t:1527264600394};\\\", \\\"{x:1404,y:890,t:1527264600410};\\\", \\\"{x:1402,y:891,t:1527264600426};\\\", \\\"{x:1401,y:892,t:1527264600444};\\\", \\\"{x:1401,y:893,t:1527264600459};\\\", \\\"{x:1400,y:894,t:1527264600477};\\\", \\\"{x:1399,y:894,t:1527264600495};\\\", \\\"{x:1397,y:895,t:1527264600510};\\\", \\\"{x:1395,y:895,t:1527264600527};\\\", \\\"{x:1394,y:895,t:1527264600544};\\\", \\\"{x:1390,y:895,t:1527264600560};\\\", \\\"{x:1387,y:895,t:1527264600577};\\\", \\\"{x:1380,y:895,t:1527264600594};\\\", \\\"{x:1370,y:891,t:1527264600610};\\\", \\\"{x:1361,y:888,t:1527264600627};\\\", \\\"{x:1346,y:883,t:1527264600644};\\\", \\\"{x:1324,y:875,t:1527264600661};\\\", \\\"{x:1295,y:864,t:1527264600677};\\\", \\\"{x:1260,y:851,t:1527264600693};\\\", \\\"{x:1231,y:837,t:1527264600710};\\\", \\\"{x:1215,y:830,t:1527264600727};\\\", \\\"{x:1208,y:828,t:1527264600745};\\\", \\\"{x:1207,y:828,t:1527264600761};\\\", \\\"{x:1207,y:827,t:1527264600903};\\\", \\\"{x:1207,y:826,t:1527264600927};\\\", \\\"{x:1208,y:826,t:1527264600944};\\\", \\\"{x:1210,y:826,t:1527264600961};\\\", \\\"{x:1211,y:826,t:1527264600994};\\\", \\\"{x:1212,y:826,t:1527264624294};\\\", \\\"{x:1213,y:840,t:1527264624312};\\\", \\\"{x:1215,y:849,t:1527264624328};\\\", \\\"{x:1218,y:858,t:1527264624344};\\\", \\\"{x:1219,y:863,t:1527264624361};\\\", \\\"{x:1220,y:867,t:1527264624378};\\\", \\\"{x:1220,y:869,t:1527264624394};\\\", \\\"{x:1221,y:873,t:1527264624410};\\\", \\\"{x:1222,y:875,t:1527264624427};\\\", \\\"{x:1222,y:877,t:1527264624444};\\\", \\\"{x:1223,y:879,t:1527264624461};\\\", \\\"{x:1223,y:880,t:1527264624478};\\\", \\\"{x:1223,y:882,t:1527264624494};\\\", \\\"{x:1224,y:882,t:1527264624510};\\\", \\\"{x:1225,y:883,t:1527264624528};\\\", \\\"{x:1225,y:884,t:1527264624549};\\\", \\\"{x:1226,y:885,t:1527264624561};\\\", \\\"{x:1226,y:891,t:1527264624578};\\\", \\\"{x:1226,y:897,t:1527264624595};\\\", \\\"{x:1226,y:902,t:1527264624611};\\\", \\\"{x:1226,y:909,t:1527264624627};\\\", \\\"{x:1226,y:917,t:1527264624644};\\\", \\\"{x:1226,y:924,t:1527264624662};\\\", \\\"{x:1226,y:930,t:1527264624678};\\\", \\\"{x:1226,y:936,t:1527264624695};\\\", \\\"{x:1225,y:940,t:1527264624711};\\\", \\\"{x:1224,y:946,t:1527264624728};\\\", \\\"{x:1222,y:952,t:1527264624744};\\\", \\\"{x:1221,y:955,t:1527264624762};\\\", \\\"{x:1220,y:961,t:1527264624778};\\\", \\\"{x:1219,y:964,t:1527264624794};\\\", \\\"{x:1219,y:966,t:1527264624812};\\\", \\\"{x:1218,y:970,t:1527264624827};\\\", \\\"{x:1218,y:971,t:1527264624845};\\\", \\\"{x:1217,y:974,t:1527264624862};\\\", \\\"{x:1217,y:975,t:1527264624878};\\\", \\\"{x:1217,y:976,t:1527264624895};\\\", \\\"{x:1217,y:977,t:1527264624926};\\\", \\\"{x:1217,y:976,t:1527264625253};\\\", \\\"{x:1217,y:973,t:1527264625269};\\\", \\\"{x:1217,y:972,t:1527264625279};\\\", \\\"{x:1217,y:963,t:1527264625294};\\\", \\\"{x:1217,y:947,t:1527264625311};\\\", \\\"{x:1212,y:918,t:1527264625328};\\\", \\\"{x:1207,y:876,t:1527264625345};\\\", \\\"{x:1202,y:848,t:1527264625362};\\\", \\\"{x:1199,y:828,t:1527264625379};\\\", \\\"{x:1197,y:816,t:1527264625394};\\\", \\\"{x:1195,y:809,t:1527264625411};\\\", \\\"{x:1195,y:806,t:1527264625428};\\\", \\\"{x:1194,y:804,t:1527264625445};\\\", \\\"{x:1194,y:799,t:1527264625461};\\\", \\\"{x:1194,y:797,t:1527264625478};\\\", \\\"{x:1195,y:796,t:1527264625494};\\\", \\\"{x:1196,y:802,t:1527264625614};\\\", \\\"{x:1199,y:808,t:1527264625629};\\\", \\\"{x:1205,y:830,t:1527264625645};\\\", \\\"{x:1210,y:840,t:1527264625661};\\\", \\\"{x:1215,y:850,t:1527264625678};\\\", \\\"{x:1218,y:856,t:1527264625695};\\\", \\\"{x:1219,y:857,t:1527264625712};\\\", \\\"{x:1219,y:858,t:1527264625728};\\\", \\\"{x:1221,y:859,t:1527264625822};\\\", \\\"{x:1222,y:859,t:1527264625830};\\\", \\\"{x:1223,y:858,t:1527264625845};\\\", \\\"{x:1226,y:855,t:1527264625861};\\\", \\\"{x:1226,y:850,t:1527264625878};\\\", \\\"{x:1226,y:845,t:1527264625896};\\\", \\\"{x:1226,y:839,t:1527264625912};\\\", \\\"{x:1226,y:838,t:1527264625929};\\\", \\\"{x:1226,y:836,t:1527264625945};\\\", \\\"{x:1226,y:835,t:1527264625961};\\\", \\\"{x:1225,y:835,t:1527264626078};\\\", \\\"{x:1224,y:834,t:1527264626103};\\\", \\\"{x:1223,y:834,t:1527264626118};\\\", \\\"{x:1222,y:834,t:1527264626230};\\\", \\\"{x:1222,y:833,t:1527264626255};\\\", \\\"{x:1221,y:832,t:1527264626287};\\\", \\\"{x:1220,y:830,t:1527264626319};\\\", \\\"{x:1219,y:829,t:1527264626358};\\\", \\\"{x:1218,y:828,t:1527264626399};\\\", \\\"{x:1218,y:827,t:1527264626462};\\\", \\\"{x:1219,y:826,t:1527264628519};\\\", \\\"{x:1220,y:826,t:1527264628532};\\\", \\\"{x:1225,y:827,t:1527264628548};\\\", \\\"{x:1228,y:827,t:1527264628564};\\\", \\\"{x:1230,y:827,t:1527264628581};\\\", \\\"{x:1230,y:828,t:1527264628598};\\\", \\\"{x:1231,y:828,t:1527264628655};\\\", \\\"{x:1232,y:828,t:1527264628750};\\\", \\\"{x:1233,y:828,t:1527264628774};\\\", \\\"{x:1234,y:828,t:1527264628806};\\\", \\\"{x:1235,y:828,t:1527264628814};\\\", \\\"{x:1236,y:828,t:1527264628831};\\\", \\\"{x:1237,y:828,t:1527264628861};\\\", \\\"{x:1238,y:828,t:1527264628886};\\\", \\\"{x:1239,y:828,t:1527264628901};\\\", \\\"{x:1240,y:828,t:1527264628934};\\\", \\\"{x:1241,y:828,t:1527264628947};\\\", \\\"{x:1242,y:828,t:1527264628965};\\\", \\\"{x:1244,y:828,t:1527264628981};\\\", \\\"{x:1247,y:828,t:1527264628998};\\\", \\\"{x:1249,y:828,t:1527264629014};\\\", \\\"{x:1252,y:828,t:1527264629031};\\\", \\\"{x:1254,y:828,t:1527264629047};\\\", \\\"{x:1258,y:828,t:1527264629065};\\\", \\\"{x:1262,y:828,t:1527264629081};\\\", \\\"{x:1265,y:828,t:1527264629099};\\\", \\\"{x:1267,y:828,t:1527264629115};\\\", \\\"{x:1269,y:828,t:1527264629131};\\\", \\\"{x:1272,y:828,t:1527264629148};\\\", \\\"{x:1276,y:828,t:1527264629165};\\\", \\\"{x:1280,y:828,t:1527264629180};\\\", \\\"{x:1290,y:828,t:1527264629199};\\\", \\\"{x:1295,y:828,t:1527264629214};\\\", \\\"{x:1299,y:828,t:1527264629231};\\\", \\\"{x:1304,y:828,t:1527264629248};\\\", \\\"{x:1306,y:828,t:1527264629265};\\\", \\\"{x:1310,y:828,t:1527264629281};\\\", \\\"{x:1315,y:828,t:1527264629298};\\\", \\\"{x:1320,y:828,t:1527264629314};\\\", \\\"{x:1327,y:831,t:1527264629331};\\\", \\\"{x:1334,y:835,t:1527264629347};\\\", \\\"{x:1339,y:838,t:1527264629365};\\\", \\\"{x:1343,y:842,t:1527264629380};\\\", \\\"{x:1346,y:847,t:1527264629398};\\\", \\\"{x:1348,y:852,t:1527264629415};\\\", \\\"{x:1349,y:857,t:1527264629431};\\\", \\\"{x:1349,y:862,t:1527264629448};\\\", \\\"{x:1351,y:871,t:1527264629465};\\\", \\\"{x:1353,y:878,t:1527264629481};\\\", \\\"{x:1354,y:889,t:1527264629498};\\\", \\\"{x:1357,y:896,t:1527264629515};\\\", \\\"{x:1357,y:904,t:1527264629532};\\\", \\\"{x:1357,y:908,t:1527264629548};\\\", \\\"{x:1357,y:911,t:1527264629565};\\\", \\\"{x:1357,y:912,t:1527264629582};\\\", \\\"{x:1357,y:911,t:1527264629719};\\\", \\\"{x:1357,y:910,t:1527264629732};\\\", \\\"{x:1357,y:907,t:1527264629748};\\\", \\\"{x:1357,y:905,t:1527264629765};\\\", \\\"{x:1357,y:904,t:1527264629782};\\\", \\\"{x:1357,y:903,t:1527264629798};\\\", \\\"{x:1357,y:902,t:1527264629815};\\\", \\\"{x:1357,y:900,t:1527264629870};\\\", \\\"{x:1357,y:899,t:1527264629894};\\\", \\\"{x:1356,y:899,t:1527264629910};\\\", \\\"{x:1356,y:898,t:1527264629919};\\\", \\\"{x:1355,y:896,t:1527264629935};\\\", \\\"{x:1354,y:895,t:1527264629951};\\\", \\\"{x:1353,y:894,t:1527264629982};\\\", \\\"{x:1352,y:893,t:1527264630038};\\\", \\\"{x:1352,y:892,t:1527264630064};\\\", \\\"{x:1351,y:892,t:1527264630070};\\\", \\\"{x:1350,y:892,t:1527264630098};\\\", \\\"{x:1349,y:892,t:1527264630126};\\\", \\\"{x:1348,y:892,t:1527264630166};\\\", \\\"{x:1347,y:892,t:1527264630246};\\\", \\\"{x:1346,y:892,t:1527264630262};\\\", \\\"{x:1345,y:892,t:1527264630334};\\\", \\\"{x:1344,y:892,t:1527264630358};\\\", \\\"{x:1343,y:892,t:1527264630391};\\\", \\\"{x:1343,y:891,t:1527264630863};\\\", \\\"{x:1343,y:890,t:1527264630926};\\\", \\\"{x:1344,y:890,t:1527264630990};\\\", \\\"{x:1345,y:890,t:1527264630999};\\\", \\\"{x:1345,y:892,t:1527264631047};\\\", \\\"{x:1345,y:893,t:1527264631070};\\\", \\\"{x:1345,y:895,t:1527264631094};\\\", \\\"{x:1345,y:896,t:1527264631110};\\\", \\\"{x:1345,y:898,t:1527264631118};\\\", \\\"{x:1344,y:899,t:1527264631133};\\\", \\\"{x:1344,y:903,t:1527264631150};\\\", \\\"{x:1344,y:909,t:1527264631166};\\\", \\\"{x:1342,y:911,t:1527264631183};\\\", \\\"{x:1341,y:912,t:1527264631199};\\\", \\\"{x:1341,y:914,t:1527264631216};\\\", \\\"{x:1341,y:916,t:1527264631233};\\\", \\\"{x:1341,y:917,t:1527264631249};\\\", \\\"{x:1340,y:918,t:1527264631266};\\\", \\\"{x:1341,y:918,t:1527264631350};\\\", \\\"{x:1343,y:913,t:1527264631366};\\\", \\\"{x:1345,y:905,t:1527264631383};\\\", \\\"{x:1348,y:900,t:1527264631400};\\\", \\\"{x:1350,y:898,t:1527264631416};\\\", \\\"{x:1352,y:896,t:1527264631433};\\\", \\\"{x:1353,y:896,t:1527264631449};\\\", \\\"{x:1354,y:895,t:1527264631468};\\\", \\\"{x:1354,y:894,t:1527264631486};\\\", \\\"{x:1355,y:893,t:1527264631743};\\\", \\\"{x:1355,y:892,t:1527264631774};\\\", \\\"{x:1355,y:891,t:1527264631783};\\\", \\\"{x:1355,y:888,t:1527264631800};\\\", \\\"{x:1358,y:887,t:1527264631817};\\\", \\\"{x:1360,y:884,t:1527264631838};\\\", \\\"{x:1360,y:880,t:1527264631850};\\\", \\\"{x:1361,y:875,t:1527264631870};\\\", \\\"{x:1362,y:874,t:1527264631883};\\\", \\\"{x:1364,y:869,t:1527264631900};\\\", \\\"{x:1366,y:867,t:1527264631917};\\\", \\\"{x:1366,y:864,t:1527264631933};\\\", \\\"{x:1367,y:864,t:1527264631950};\\\", \\\"{x:1367,y:863,t:1527264631967};\\\", \\\"{x:1368,y:861,t:1527264631983};\\\", \\\"{x:1368,y:859,t:1527264632006};\\\", \\\"{x:1368,y:858,t:1527264632017};\\\", \\\"{x:1368,y:853,t:1527264632033};\\\", \\\"{x:1366,y:853,t:1527264632071};\\\", \\\"{x:1364,y:849,t:1527264632087};\\\", \\\"{x:1362,y:846,t:1527264632100};\\\", \\\"{x:1362,y:845,t:1527264632117};\\\", \\\"{x:1358,y:842,t:1527264632133};\\\", \\\"{x:1356,y:834,t:1527264632150};\\\", \\\"{x:1355,y:827,t:1527264632167};\\\", \\\"{x:1356,y:825,t:1527264632198};\\\", \\\"{x:1358,y:822,t:1527264632206};\\\", \\\"{x:1358,y:819,t:1527264632218};\\\", \\\"{x:1358,y:811,t:1527264632233};\\\", \\\"{x:1358,y:802,t:1527264632249};\\\", \\\"{x:1358,y:796,t:1527264632267};\\\", \\\"{x:1358,y:790,t:1527264632283};\\\", \\\"{x:1359,y:783,t:1527264632300};\\\", \\\"{x:1360,y:778,t:1527264632316};\\\", \\\"{x:1362,y:766,t:1527264632333};\\\", \\\"{x:1363,y:759,t:1527264632350};\\\", \\\"{x:1363,y:752,t:1527264632366};\\\", \\\"{x:1363,y:745,t:1527264632384};\\\", \\\"{x:1363,y:739,t:1527264632400};\\\", \\\"{x:1363,y:737,t:1527264632417};\\\", \\\"{x:1363,y:732,t:1527264632434};\\\", \\\"{x:1363,y:731,t:1527264632450};\\\", \\\"{x:1363,y:729,t:1527264632467};\\\", \\\"{x:1363,y:728,t:1527264632485};\\\", \\\"{x:1364,y:725,t:1527264632500};\\\", \\\"{x:1364,y:723,t:1527264632518};\\\", \\\"{x:1365,y:721,t:1527264632534};\\\", \\\"{x:1365,y:719,t:1527264632550};\\\", \\\"{x:1366,y:715,t:1527264632567};\\\", \\\"{x:1366,y:711,t:1527264632584};\\\", \\\"{x:1367,y:706,t:1527264632600};\\\", \\\"{x:1367,y:701,t:1527264632617};\\\", \\\"{x:1368,y:697,t:1527264632634};\\\", \\\"{x:1369,y:693,t:1527264632650};\\\", \\\"{x:1369,y:692,t:1527264632668};\\\", \\\"{x:1368,y:691,t:1527264632719};\\\", \\\"{x:1354,y:694,t:1527264632734};\\\", \\\"{x:1330,y:701,t:1527264632750};\\\", \\\"{x:1301,y:702,t:1527264632767};\\\", \\\"{x:1262,y:702,t:1527264632784};\\\", \\\"{x:1187,y:692,t:1527264632801};\\\", \\\"{x:1093,y:667,t:1527264632817};\\\", \\\"{x:993,y:637,t:1527264632834};\\\", \\\"{x:893,y:609,t:1527264632852};\\\", \\\"{x:791,y:585,t:1527264632866};\\\", \\\"{x:753,y:580,t:1527264632884};\\\", \\\"{x:753,y:579,t:1527264633318};\\\", \\\"{x:751,y:579,t:1527264633623};\\\", \\\"{x:745,y:581,t:1527264633633};\\\", \\\"{x:723,y:586,t:1527264633650};\\\", \\\"{x:689,y:590,t:1527264633665};\\\", \\\"{x:605,y:600,t:1527264633687};\\\", \\\"{x:562,y:601,t:1527264633705};\\\", \\\"{x:533,y:601,t:1527264633722};\\\", \\\"{x:513,y:601,t:1527264633737};\\\", \\\"{x:499,y:602,t:1527264633754};\\\", \\\"{x:493,y:604,t:1527264633772};\\\", \\\"{x:489,y:605,t:1527264633788};\\\", \\\"{x:487,y:605,t:1527264633804};\\\", \\\"{x:486,y:606,t:1527264633821};\\\", \\\"{x:483,y:609,t:1527264633839};\\\", \\\"{x:480,y:612,t:1527264633855};\\\", \\\"{x:476,y:616,t:1527264633872};\\\", \\\"{x:471,y:620,t:1527264633890};\\\", \\\"{x:470,y:622,t:1527264633904};\\\", \\\"{x:468,y:624,t:1527264633922};\\\", \\\"{x:467,y:626,t:1527264633937};\\\", \\\"{x:467,y:630,t:1527264633955};\\\", \\\"{x:467,y:632,t:1527264633972};\\\", \\\"{x:467,y:635,t:1527264633987};\\\", \\\"{x:467,y:638,t:1527264634005};\\\", \\\"{x:467,y:641,t:1527264634022};\\\", \\\"{x:467,y:643,t:1527264634045};\\\", \\\"{x:467,y:645,t:1527264634085};\\\", \\\"{x:467,y:646,t:1527264634094};\\\", \\\"{x:468,y:646,t:1527264634582};\\\", \\\"{x:472,y:646,t:1527264634589};\\\", \\\"{x:490,y:645,t:1527264634605};\\\", \\\"{x:521,y:645,t:1527264634624};\\\", \\\"{x:591,y:645,t:1527264634639};\\\", \\\"{x:696,y:645,t:1527264634656};\\\", \\\"{x:829,y:659,t:1527264634673};\\\", \\\"{x:976,y:685,t:1527264634688};\\\", \\\"{x:1122,y:727,t:1527264634706};\\\", \\\"{x:1258,y:768,t:1527264634722};\\\", \\\"{x:1374,y:818,t:1527264634739};\\\", \\\"{x:1455,y:856,t:1527264634756};\\\", \\\"{x:1504,y:884,t:1527264634772};\\\", \\\"{x:1533,y:904,t:1527264634789};\\\", \\\"{x:1549,y:920,t:1527264634805};\\\", \\\"{x:1551,y:926,t:1527264634821};\\\", \\\"{x:1554,y:933,t:1527264634839};\\\", \\\"{x:1554,y:940,t:1527264634856};\\\", \\\"{x:1554,y:943,t:1527264634872};\\\", \\\"{x:1554,y:946,t:1527264634889};\\\", \\\"{x:1554,y:949,t:1527264634906};\\\", \\\"{x:1548,y:950,t:1527264634922};\\\", \\\"{x:1536,y:951,t:1527264634939};\\\", \\\"{x:1519,y:951,t:1527264634956};\\\", \\\"{x:1496,y:951,t:1527264634972};\\\", \\\"{x:1471,y:945,t:1527264634989};\\\", \\\"{x:1432,y:934,t:1527264635006};\\\", \\\"{x:1407,y:924,t:1527264635023};\\\", \\\"{x:1391,y:918,t:1527264635039};\\\", \\\"{x:1383,y:915,t:1527264635056};\\\", \\\"{x:1378,y:913,t:1527264635073};\\\", \\\"{x:1376,y:911,t:1527264635089};\\\", \\\"{x:1375,y:911,t:1527264635118};\\\", \\\"{x:1374,y:911,t:1527264635126};\\\", \\\"{x:1372,y:910,t:1527264635139};\\\", \\\"{x:1366,y:910,t:1527264635156};\\\", \\\"{x:1352,y:905,t:1527264635174};\\\", \\\"{x:1349,y:902,t:1527264635190};\\\", \\\"{x:1349,y:898,t:1527264635206};\\\", \\\"{x:1349,y:896,t:1527264635574};\\\", \\\"{x:1341,y:887,t:1527264635591};\\\", \\\"{x:1328,y:875,t:1527264635606};\\\", \\\"{x:1307,y:862,t:1527264635623};\\\", \\\"{x:1272,y:840,t:1527264635640};\\\", \\\"{x:1226,y:802,t:1527264635657};\\\", \\\"{x:1157,y:743,t:1527264635673};\\\", \\\"{x:1072,y:674,t:1527264635691};\\\", \\\"{x:983,y:605,t:1527264635706};\\\", \\\"{x:899,y:543,t:1527264635723};\\\", \\\"{x:840,y:500,t:1527264635740};\\\", \\\"{x:796,y:475,t:1527264635757};\\\", \\\"{x:774,y:459,t:1527264635774};\\\", \\\"{x:764,y:453,t:1527264635790};\\\", \\\"{x:763,y:453,t:1527264635846};\\\", \\\"{x:762,y:453,t:1527264635862};\\\", \\\"{x:759,y:453,t:1527264635873};\\\", \\\"{x:757,y:453,t:1527264635890};\\\", \\\"{x:754,y:454,t:1527264635906};\\\", \\\"{x:748,y:458,t:1527264635924};\\\", \\\"{x:739,y:462,t:1527264635941};\\\", \\\"{x:724,y:468,t:1527264635957};\\\", \\\"{x:708,y:476,t:1527264635974};\\\", \\\"{x:675,y:493,t:1527264635991};\\\", \\\"{x:650,y:502,t:1527264636008};\\\", \\\"{x:623,y:509,t:1527264636027};\\\", \\\"{x:604,y:514,t:1527264636040};\\\", \\\"{x:585,y:516,t:1527264636057};\\\", \\\"{x:575,y:519,t:1527264636072};\\\", \\\"{x:566,y:521,t:1527264636090};\\\", \\\"{x:563,y:523,t:1527264636106};\\\", \\\"{x:562,y:523,t:1527264636123};\\\", \\\"{x:561,y:524,t:1527264636138};\\\", \\\"{x:559,y:527,t:1527264636156};\\\", \\\"{x:557,y:530,t:1527264636172};\\\", \\\"{x:554,y:536,t:1527264636189};\\\", \\\"{x:552,y:541,t:1527264636206};\\\", \\\"{x:552,y:544,t:1527264636223};\\\", \\\"{x:552,y:551,t:1527264636239};\\\", \\\"{x:552,y:560,t:1527264636255};\\\", \\\"{x:552,y:566,t:1527264636273};\\\", \\\"{x:558,y:575,t:1527264636291};\\\", \\\"{x:564,y:584,t:1527264636306};\\\", \\\"{x:569,y:588,t:1527264636323};\\\", \\\"{x:574,y:591,t:1527264636340};\\\", \\\"{x:577,y:594,t:1527264636357};\\\", \\\"{x:578,y:595,t:1527264636381};\\\", \\\"{x:578,y:597,t:1527264636413};\\\", \\\"{x:578,y:599,t:1527264636429};\\\", \\\"{x:576,y:600,t:1527264636440};\\\", \\\"{x:574,y:602,t:1527264636457};\\\", \\\"{x:566,y:605,t:1527264636474};\\\", \\\"{x:558,y:608,t:1527264636490};\\\", \\\"{x:551,y:609,t:1527264636507};\\\", \\\"{x:540,y:611,t:1527264636524};\\\", \\\"{x:529,y:611,t:1527264636540};\\\", \\\"{x:516,y:611,t:1527264636557};\\\", \\\"{x:482,y:611,t:1527264636575};\\\", \\\"{x:449,y:610,t:1527264636590};\\\", \\\"{x:388,y:602,t:1527264636607};\\\", \\\"{x:327,y:596,t:1527264636625};\\\", \\\"{x:274,y:594,t:1527264636640};\\\", \\\"{x:231,y:594,t:1527264636658};\\\", \\\"{x:198,y:594,t:1527264636673};\\\", \\\"{x:176,y:594,t:1527264636691};\\\", \\\"{x:162,y:597,t:1527264636707};\\\", \\\"{x:153,y:602,t:1527264636723};\\\", \\\"{x:147,y:604,t:1527264636741};\\\", \\\"{x:140,y:610,t:1527264636756};\\\", \\\"{x:137,y:613,t:1527264636774};\\\", \\\"{x:135,y:614,t:1527264636789};\\\", \\\"{x:134,y:615,t:1527264636806};\\\", \\\"{x:134,y:614,t:1527264636878};\\\", \\\"{x:134,y:613,t:1527264636890};\\\", \\\"{x:137,y:607,t:1527264636907};\\\", \\\"{x:143,y:598,t:1527264636924};\\\", \\\"{x:150,y:585,t:1527264636941};\\\", \\\"{x:152,y:576,t:1527264636958};\\\", \\\"{x:155,y:571,t:1527264636974};\\\", \\\"{x:155,y:569,t:1527264636991};\\\", \\\"{x:155,y:568,t:1527264637007};\\\", \\\"{x:155,y:567,t:1527264637070};\\\", \\\"{x:155,y:566,t:1527264637102};\\\", \\\"{x:156,y:566,t:1527264637366};\\\", \\\"{x:161,y:565,t:1527264637373};\\\", \\\"{x:177,y:565,t:1527264637390};\\\", \\\"{x:220,y:574,t:1527264637408};\\\", \\\"{x:297,y:596,t:1527264637425};\\\", \\\"{x:386,y:623,t:1527264637441};\\\", \\\"{x:469,y:646,t:1527264637458};\\\", \\\"{x:535,y:670,t:1527264637475};\\\", \\\"{x:576,y:688,t:1527264637491};\\\", \\\"{x:593,y:698,t:1527264637508};\\\", \\\"{x:601,y:703,t:1527264637524};\\\", \\\"{x:602,y:704,t:1527264637540};\\\", \\\"{x:602,y:705,t:1527264637558};\\\", \\\"{x:602,y:707,t:1527264637574};\\\", \\\"{x:602,y:709,t:1527264637591};\\\", \\\"{x:602,y:711,t:1527264637608};\\\", \\\"{x:602,y:714,t:1527264637625};\\\", \\\"{x:602,y:715,t:1527264637654};\\\", \\\"{x:602,y:717,t:1527264637661};\\\", \\\"{x:602,y:718,t:1527264637674};\\\", \\\"{x:600,y:718,t:1527264637691};\\\", \\\"{x:598,y:719,t:1527264637708};\\\", \\\"{x:584,y:721,t:1527264637726};\\\", \\\"{x:575,y:721,t:1527264637741};\\\", \\\"{x:549,y:716,t:1527264637759};\\\", \\\"{x:539,y:714,t:1527264637775};\\\", \\\"{x:534,y:714,t:1527264637791};\\\", \\\"{x:533,y:714,t:1527264637808};\\\", \\\"{x:537,y:714,t:1527264638085};\\\", \\\"{x:546,y:714,t:1527264638093};\\\", \\\"{x:560,y:715,t:1527264638108};\\\", \\\"{x:596,y:725,t:1527264638125};\\\", \\\"{x:653,y:738,t:1527264638142};\\\", \\\"{x:697,y:748,t:1527264638158};\\\", \\\"{x:727,y:757,t:1527264638175};\\\", \\\"{x:755,y:760,t:1527264638192};\\\", \\\"{x:769,y:763,t:1527264638208};\\\", \\\"{x:783,y:765,t:1527264638225};\\\", \\\"{x:790,y:765,t:1527264638242};\\\", \\\"{x:795,y:767,t:1527264638258};\\\", \\\"{x:796,y:768,t:1527264638275};\\\" ] }, { \\\"rt\\\": 40234, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 264760, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-U -U -U -U -U -U -H -H -H -F -F -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:797,y:768,t:1527264639781};\\\", \\\"{x:798,y:768,t:1527264640774};\\\", \\\"{x:799,y:768,t:1527264641510};\\\", \\\"{x:802,y:768,t:1527264641517};\\\", \\\"{x:803,y:768,t:1527264641527};\\\", \\\"{x:812,y:764,t:1527264641544};\\\", \\\"{x:822,y:757,t:1527264641561};\\\", \\\"{x:838,y:749,t:1527264641578};\\\", \\\"{x:859,y:741,t:1527264641594};\\\", \\\"{x:871,y:739,t:1527264641612};\\\", \\\"{x:876,y:738,t:1527264641627};\\\", \\\"{x:892,y:734,t:1527264641644};\\\", \\\"{x:922,y:725,t:1527264641661};\\\", \\\"{x:939,y:721,t:1527264641678};\\\", \\\"{x:955,y:719,t:1527264641695};\\\", \\\"{x:983,y:718,t:1527264641712};\\\", \\\"{x:1013,y:714,t:1527264641728};\\\", \\\"{x:1034,y:714,t:1527264641745};\\\", \\\"{x:1088,y:716,t:1527264641762};\\\", \\\"{x:1157,y:731,t:1527264641778};\\\", \\\"{x:1246,y:761,t:1527264641795};\\\", \\\"{x:1341,y:792,t:1527264641811};\\\", \\\"{x:1436,y:826,t:1527264641828};\\\", \\\"{x:1505,y:857,t:1527264641845};\\\", \\\"{x:1506,y:858,t:1527264641862};\\\", \\\"{x:1507,y:859,t:1527264643647};\\\", \\\"{x:1508,y:860,t:1527264643663};\\\", \\\"{x:1512,y:862,t:1527264643679};\\\", \\\"{x:1518,y:865,t:1527264643696};\\\", \\\"{x:1530,y:871,t:1527264643713};\\\", \\\"{x:1544,y:877,t:1527264643730};\\\", \\\"{x:1554,y:882,t:1527264643747};\\\", \\\"{x:1567,y:890,t:1527264643762};\\\", \\\"{x:1578,y:896,t:1527264643780};\\\", \\\"{x:1586,y:902,t:1527264643797};\\\", \\\"{x:1591,y:906,t:1527264643813};\\\", \\\"{x:1597,y:910,t:1527264643830};\\\", \\\"{x:1598,y:912,t:1527264643846};\\\", \\\"{x:1600,y:915,t:1527264643863};\\\", \\\"{x:1601,y:917,t:1527264643879};\\\", \\\"{x:1604,y:922,t:1527264643897};\\\", \\\"{x:1606,y:926,t:1527264643913};\\\", \\\"{x:1608,y:930,t:1527264643929};\\\", \\\"{x:1609,y:934,t:1527264643947};\\\", \\\"{x:1609,y:939,t:1527264643963};\\\", \\\"{x:1610,y:944,t:1527264643980};\\\", \\\"{x:1610,y:949,t:1527264643997};\\\", \\\"{x:1610,y:953,t:1527264644013};\\\", \\\"{x:1610,y:956,t:1527264644029};\\\", \\\"{x:1610,y:958,t:1527264644046};\\\", \\\"{x:1610,y:959,t:1527264644062};\\\", \\\"{x:1610,y:961,t:1527264644080};\\\", \\\"{x:1611,y:964,t:1527264644097};\\\", \\\"{x:1612,y:965,t:1527264644114};\\\", \\\"{x:1612,y:966,t:1527264644134};\\\", \\\"{x:1613,y:966,t:1527264644391};\\\", \\\"{x:1614,y:966,t:1527264644407};\\\", \\\"{x:1615,y:966,t:1527264644470};\\\", \\\"{x:1616,y:965,t:1527264644559};\\\", \\\"{x:1617,y:965,t:1527264644590};\\\", \\\"{x:1618,y:965,t:1527264644606};\\\", \\\"{x:1618,y:964,t:1527264644687};\\\", \\\"{x:1619,y:962,t:1527264648103};\\\", \\\"{x:1619,y:958,t:1527264648116};\\\", \\\"{x:1620,y:954,t:1527264648133};\\\", \\\"{x:1620,y:946,t:1527264648150};\\\", \\\"{x:1620,y:939,t:1527264648166};\\\", \\\"{x:1620,y:932,t:1527264648183};\\\", \\\"{x:1620,y:926,t:1527264648200};\\\", \\\"{x:1620,y:920,t:1527264648216};\\\", \\\"{x:1620,y:914,t:1527264648233};\\\", \\\"{x:1620,y:907,t:1527264648250};\\\", \\\"{x:1620,y:901,t:1527264648266};\\\", \\\"{x:1620,y:897,t:1527264648283};\\\", \\\"{x:1619,y:890,t:1527264648300};\\\", \\\"{x:1618,y:886,t:1527264648316};\\\", \\\"{x:1617,y:881,t:1527264648333};\\\", \\\"{x:1613,y:875,t:1527264648350};\\\", \\\"{x:1612,y:869,t:1527264648366};\\\", \\\"{x:1612,y:866,t:1527264648383};\\\", \\\"{x:1612,y:862,t:1527264648400};\\\", \\\"{x:1612,y:859,t:1527264648416};\\\", \\\"{x:1612,y:853,t:1527264648433};\\\", \\\"{x:1612,y:846,t:1527264648450};\\\", \\\"{x:1612,y:841,t:1527264648466};\\\", \\\"{x:1612,y:837,t:1527264648483};\\\", \\\"{x:1612,y:832,t:1527264648500};\\\", \\\"{x:1612,y:829,t:1527264648517};\\\", \\\"{x:1613,y:825,t:1527264648533};\\\", \\\"{x:1613,y:823,t:1527264648550};\\\", \\\"{x:1613,y:822,t:1527264648566};\\\", \\\"{x:1613,y:821,t:1527264648583};\\\", \\\"{x:1613,y:820,t:1527264648600};\\\", \\\"{x:1613,y:819,t:1527264648617};\\\", \\\"{x:1613,y:817,t:1527264648633};\\\", \\\"{x:1613,y:816,t:1527264648650};\\\", \\\"{x:1613,y:815,t:1527264648670};\\\", \\\"{x:1614,y:813,t:1527264648683};\\\", \\\"{x:1614,y:809,t:1527264648700};\\\", \\\"{x:1614,y:802,t:1527264648717};\\\", \\\"{x:1613,y:792,t:1527264648733};\\\", \\\"{x:1609,y:772,t:1527264648750};\\\", \\\"{x:1608,y:759,t:1527264648767};\\\", \\\"{x:1606,y:749,t:1527264648783};\\\", \\\"{x:1603,y:741,t:1527264648800};\\\", \\\"{x:1602,y:732,t:1527264648817};\\\", \\\"{x:1600,y:728,t:1527264648833};\\\", \\\"{x:1599,y:720,t:1527264648850};\\\", \\\"{x:1596,y:716,t:1527264648867};\\\", \\\"{x:1596,y:711,t:1527264648883};\\\", \\\"{x:1595,y:709,t:1527264648900};\\\", \\\"{x:1594,y:704,t:1527264648917};\\\", \\\"{x:1593,y:699,t:1527264648933};\\\", \\\"{x:1592,y:692,t:1527264648950};\\\", \\\"{x:1590,y:687,t:1527264648967};\\\", \\\"{x:1588,y:683,t:1527264648984};\\\", \\\"{x:1587,y:677,t:1527264649000};\\\", \\\"{x:1585,y:668,t:1527264649016};\\\", \\\"{x:1584,y:657,t:1527264649034};\\\", \\\"{x:1582,y:650,t:1527264649049};\\\", \\\"{x:1581,y:644,t:1527264649066};\\\", \\\"{x:1580,y:636,t:1527264649084};\\\", \\\"{x:1578,y:631,t:1527264649099};\\\", \\\"{x:1578,y:628,t:1527264649117};\\\", \\\"{x:1577,y:623,t:1527264649133};\\\", \\\"{x:1576,y:620,t:1527264649150};\\\", \\\"{x:1575,y:616,t:1527264649167};\\\", \\\"{x:1574,y:611,t:1527264649184};\\\", \\\"{x:1573,y:607,t:1527264649199};\\\", \\\"{x:1571,y:603,t:1527264649216};\\\", \\\"{x:1571,y:600,t:1527264649234};\\\", \\\"{x:1571,y:598,t:1527264649250};\\\", \\\"{x:1571,y:596,t:1527264649267};\\\", \\\"{x:1571,y:589,t:1527264649284};\\\", \\\"{x:1569,y:577,t:1527264649300};\\\", \\\"{x:1567,y:564,t:1527264649317};\\\", \\\"{x:1566,y:552,t:1527264649333};\\\", \\\"{x:1565,y:548,t:1527264649350};\\\", \\\"{x:1564,y:545,t:1527264649367};\\\", \\\"{x:1564,y:541,t:1527264649384};\\\", \\\"{x:1564,y:537,t:1527264649400};\\\", \\\"{x:1564,y:532,t:1527264649417};\\\", \\\"{x:1563,y:529,t:1527264649434};\\\", \\\"{x:1563,y:525,t:1527264649450};\\\", \\\"{x:1563,y:520,t:1527264649466};\\\", \\\"{x:1563,y:517,t:1527264649483};\\\", \\\"{x:1563,y:512,t:1527264649501};\\\", \\\"{x:1563,y:508,t:1527264649516};\\\", \\\"{x:1563,y:502,t:1527264649533};\\\", \\\"{x:1563,y:498,t:1527264649551};\\\", \\\"{x:1563,y:493,t:1527264649567};\\\", \\\"{x:1563,y:486,t:1527264649583};\\\", \\\"{x:1563,y:481,t:1527264649601};\\\", \\\"{x:1563,y:476,t:1527264649616};\\\", \\\"{x:1563,y:475,t:1527264649634};\\\", \\\"{x:1563,y:476,t:1527264649693};\\\", \\\"{x:1559,y:494,t:1527264649701};\\\", \\\"{x:1556,y:526,t:1527264649717};\\\", \\\"{x:1548,y:680,t:1527264649734};\\\", \\\"{x:1554,y:752,t:1527264649751};\\\", \\\"{x:1566,y:794,t:1527264649767};\\\", \\\"{x:1571,y:815,t:1527264649784};\\\", \\\"{x:1573,y:835,t:1527264649801};\\\", \\\"{x:1576,y:851,t:1527264649817};\\\", \\\"{x:1576,y:859,t:1527264649834};\\\", \\\"{x:1576,y:863,t:1527264649851};\\\", \\\"{x:1576,y:866,t:1527264649866};\\\", \\\"{x:1576,y:871,t:1527264649884};\\\", \\\"{x:1576,y:876,t:1527264649901};\\\", \\\"{x:1575,y:887,t:1527264649918};\\\", \\\"{x:1575,y:900,t:1527264649934};\\\", \\\"{x:1575,y:916,t:1527264649951};\\\", \\\"{x:1575,y:930,t:1527264649968};\\\", \\\"{x:1578,y:947,t:1527264649984};\\\", \\\"{x:1584,y:964,t:1527264650002};\\\", \\\"{x:1594,y:984,t:1527264650019};\\\", \\\"{x:1607,y:1006,t:1527264650034};\\\", \\\"{x:1617,y:1018,t:1527264650051};\\\", \\\"{x:1618,y:1018,t:1527264650614};\\\", \\\"{x:1619,y:1018,t:1527264650630};\\\", \\\"{x:1619,y:1016,t:1527264650638};\\\", \\\"{x:1620,y:1011,t:1527264650651};\\\", \\\"{x:1620,y:1002,t:1527264650667};\\\", \\\"{x:1620,y:985,t:1527264650685};\\\", \\\"{x:1619,y:971,t:1527264650701};\\\", \\\"{x:1618,y:960,t:1527264650718};\\\", \\\"{x:1618,y:959,t:1527264650735};\\\", \\\"{x:1618,y:958,t:1527264650751};\\\", \\\"{x:1617,y:957,t:1527264650768};\\\", \\\"{x:1616,y:957,t:1527264650785};\\\", \\\"{x:1615,y:956,t:1527264650801};\\\", \\\"{x:1613,y:956,t:1527264650829};\\\", \\\"{x:1612,y:955,t:1527264650927};\\\", \\\"{x:1612,y:950,t:1527264650935};\\\", \\\"{x:1615,y:926,t:1527264650952};\\\", \\\"{x:1620,y:887,t:1527264650968};\\\", \\\"{x:1620,y:840,t:1527264650985};\\\", \\\"{x:1620,y:784,t:1527264651003};\\\", \\\"{x:1620,y:723,t:1527264651018};\\\", \\\"{x:1613,y:669,t:1527264651035};\\\", \\\"{x:1605,y:639,t:1527264651051};\\\", \\\"{x:1601,y:622,t:1527264651068};\\\", \\\"{x:1599,y:616,t:1527264651085};\\\", \\\"{x:1597,y:608,t:1527264651102};\\\", \\\"{x:1596,y:606,t:1527264651118};\\\", \\\"{x:1596,y:603,t:1527264651135};\\\", \\\"{x:1596,y:595,t:1527264651152};\\\", \\\"{x:1595,y:581,t:1527264651168};\\\", \\\"{x:1593,y:563,t:1527264651185};\\\", \\\"{x:1588,y:542,t:1527264651202};\\\", \\\"{x:1582,y:520,t:1527264651218};\\\", \\\"{x:1574,y:493,t:1527264651235};\\\", \\\"{x:1564,y:468,t:1527264651251};\\\", \\\"{x:1554,y:452,t:1527264651268};\\\", \\\"{x:1541,y:446,t:1527264651285};\\\", \\\"{x:1512,y:454,t:1527264651301};\\\", \\\"{x:1452,y:501,t:1527264651318};\\\", \\\"{x:1386,y:593,t:1527264651336};\\\", \\\"{x:1373,y:610,t:1527264651352};\\\", \\\"{x:1372,y:611,t:1527264652430};\\\", \\\"{x:1371,y:612,t:1527264652438};\\\", \\\"{x:1370,y:612,t:1527264652453};\\\", \\\"{x:1365,y:615,t:1527264652469};\\\", \\\"{x:1354,y:625,t:1527264652486};\\\", \\\"{x:1345,y:646,t:1527264652504};\\\", \\\"{x:1329,y:678,t:1527264652519};\\\", \\\"{x:1313,y:715,t:1527264652536};\\\", \\\"{x:1295,y:743,t:1527264652553};\\\", \\\"{x:1281,y:768,t:1527264652569};\\\", \\\"{x:1277,y:790,t:1527264652586};\\\", \\\"{x:1271,y:812,t:1527264652603};\\\", \\\"{x:1270,y:836,t:1527264652619};\\\", \\\"{x:1270,y:861,t:1527264652636};\\\", \\\"{x:1274,y:878,t:1527264652653};\\\", \\\"{x:1280,y:889,t:1527264652670};\\\", \\\"{x:1292,y:903,t:1527264652686};\\\", \\\"{x:1299,y:907,t:1527264652703};\\\", \\\"{x:1311,y:913,t:1527264652719};\\\", \\\"{x:1328,y:920,t:1527264652736};\\\", \\\"{x:1348,y:925,t:1527264652753};\\\", \\\"{x:1370,y:931,t:1527264652769};\\\", \\\"{x:1393,y:939,t:1527264652787};\\\", \\\"{x:1409,y:942,t:1527264652803};\\\", \\\"{x:1419,y:944,t:1527264652821};\\\", \\\"{x:1423,y:944,t:1527264652836};\\\", \\\"{x:1425,y:944,t:1527264652853};\\\", \\\"{x:1426,y:944,t:1527264652871};\\\", \\\"{x:1428,y:943,t:1527264652886};\\\", \\\"{x:1426,y:943,t:1527264653031};\\\", \\\"{x:1421,y:941,t:1527264653038};\\\", \\\"{x:1418,y:940,t:1527264653053};\\\", \\\"{x:1400,y:929,t:1527264653070};\\\", \\\"{x:1385,y:917,t:1527264653086};\\\", \\\"{x:1376,y:908,t:1527264653103};\\\", \\\"{x:1369,y:896,t:1527264653121};\\\", \\\"{x:1361,y:879,t:1527264653136};\\\", \\\"{x:1355,y:865,t:1527264653153};\\\", \\\"{x:1354,y:864,t:1527264653173};\\\", \\\"{x:1354,y:863,t:1527264653186};\\\", \\\"{x:1352,y:863,t:1527264653204};\\\", \\\"{x:1356,y:868,t:1527264653310};\\\", \\\"{x:1358,y:871,t:1527264653320};\\\", \\\"{x:1364,y:880,t:1527264653337};\\\", \\\"{x:1367,y:885,t:1527264653353};\\\", \\\"{x:1371,y:890,t:1527264653370};\\\", \\\"{x:1373,y:895,t:1527264653387};\\\", \\\"{x:1373,y:894,t:1527264653566};\\\", \\\"{x:1373,y:893,t:1527264653589};\\\", \\\"{x:1373,y:892,t:1527264653606};\\\", \\\"{x:1372,y:891,t:1527264653670};\\\", \\\"{x:1372,y:890,t:1527264653688};\\\", \\\"{x:1371,y:890,t:1527264653703};\\\", \\\"{x:1370,y:889,t:1527264653720};\\\", \\\"{x:1369,y:888,t:1527264653737};\\\", \\\"{x:1369,y:887,t:1527264653766};\\\", \\\"{x:1368,y:887,t:1527264653790};\\\", \\\"{x:1367,y:887,t:1527264653814};\\\", \\\"{x:1365,y:887,t:1527264653854};\\\", \\\"{x:1364,y:887,t:1527264653870};\\\", \\\"{x:1362,y:887,t:1527264653887};\\\", \\\"{x:1361,y:887,t:1527264653904};\\\", \\\"{x:1358,y:888,t:1527264653920};\\\", \\\"{x:1356,y:890,t:1527264653938};\\\", \\\"{x:1355,y:891,t:1527264653954};\\\", \\\"{x:1354,y:892,t:1527264653970};\\\", \\\"{x:1355,y:893,t:1527264654321};\\\", \\\"{x:1358,y:892,t:1527264654329};\\\", \\\"{x:1364,y:887,t:1527264654341};\\\", \\\"{x:1378,y:874,t:1527264654358};\\\", \\\"{x:1396,y:861,t:1527264654375};\\\", \\\"{x:1413,y:846,t:1527264654391};\\\", \\\"{x:1430,y:829,t:1527264654408};\\\", \\\"{x:1444,y:815,t:1527264654424};\\\", \\\"{x:1456,y:798,t:1527264654441};\\\", \\\"{x:1465,y:786,t:1527264654457};\\\", \\\"{x:1467,y:785,t:1527264654475};\\\", \\\"{x:1466,y:785,t:1527264654555};\\\", \\\"{x:1463,y:785,t:1527264654562};\\\", \\\"{x:1460,y:786,t:1527264654575};\\\", \\\"{x:1452,y:794,t:1527264654592};\\\", \\\"{x:1447,y:803,t:1527264654608};\\\", \\\"{x:1447,y:808,t:1527264654625};\\\", \\\"{x:1447,y:809,t:1527264654641};\\\", \\\"{x:1447,y:810,t:1527264654659};\\\", \\\"{x:1447,y:813,t:1527264654675};\\\", \\\"{x:1447,y:815,t:1527264654692};\\\", \\\"{x:1447,y:820,t:1527264654709};\\\", \\\"{x:1450,y:826,t:1527264654725};\\\", \\\"{x:1455,y:830,t:1527264654742};\\\", \\\"{x:1461,y:832,t:1527264654758};\\\", \\\"{x:1464,y:833,t:1527264654776};\\\", \\\"{x:1466,y:833,t:1527264654792};\\\", \\\"{x:1467,y:833,t:1527264654809};\\\", \\\"{x:1468,y:833,t:1527264654826};\\\", \\\"{x:1471,y:833,t:1527264654842};\\\", \\\"{x:1474,y:832,t:1527264654858};\\\", \\\"{x:1476,y:832,t:1527264654884};\\\", \\\"{x:1477,y:831,t:1527264654892};\\\", \\\"{x:1480,y:829,t:1527264654908};\\\", \\\"{x:1482,y:828,t:1527264654929};\\\", \\\"{x:1483,y:828,t:1527264655242};\\\", \\\"{x:1485,y:827,t:1527264655266};\\\", \\\"{x:1485,y:826,t:1527264655275};\\\", \\\"{x:1486,y:826,t:1527264655294};\\\", \\\"{x:1487,y:825,t:1527264655338};\\\", \\\"{x:1486,y:825,t:1527264655987};\\\", \\\"{x:1484,y:825,t:1527264656027};\\\", \\\"{x:1483,y:825,t:1527264656066};\\\", \\\"{x:1481,y:825,t:1527264656402};\\\", \\\"{x:1480,y:826,t:1527264656410};\\\", \\\"{x:1479,y:826,t:1527264656433};\\\", \\\"{x:1478,y:826,t:1527264656553};\\\", \\\"{x:1477,y:827,t:1527264656561};\\\", \\\"{x:1476,y:827,t:1527264657643};\\\", \\\"{x:1470,y:827,t:1527264657651};\\\", \\\"{x:1459,y:826,t:1527264657661};\\\", \\\"{x:1416,y:816,t:1527264657678};\\\", \\\"{x:1339,y:788,t:1527264657694};\\\", \\\"{x:1232,y:747,t:1527264657711};\\\", \\\"{x:1121,y:710,t:1527264657727};\\\", \\\"{x:1027,y:684,t:1527264657744};\\\", \\\"{x:964,y:658,t:1527264657761};\\\", \\\"{x:935,y:649,t:1527264657777};\\\", \\\"{x:918,y:643,t:1527264657794};\\\", \\\"{x:911,y:642,t:1527264657810};\\\", \\\"{x:900,y:642,t:1527264657827};\\\", \\\"{x:880,y:641,t:1527264657844};\\\", \\\"{x:848,y:636,t:1527264657860};\\\", \\\"{x:819,y:633,t:1527264657877};\\\", \\\"{x:783,y:626,t:1527264657894};\\\", \\\"{x:735,y:619,t:1527264657910};\\\", \\\"{x:686,y:614,t:1527264657927};\\\", \\\"{x:655,y:612,t:1527264657946};\\\", \\\"{x:624,y:612,t:1527264657961};\\\", \\\"{x:612,y:614,t:1527264657978};\\\", \\\"{x:603,y:618,t:1527264657994};\\\", \\\"{x:595,y:618,t:1527264658012};\\\", \\\"{x:581,y:619,t:1527264658028};\\\", \\\"{x:572,y:619,t:1527264658044};\\\", \\\"{x:569,y:619,t:1527264658062};\\\", \\\"{x:567,y:619,t:1527264658078};\\\", \\\"{x:568,y:619,t:1527264658154};\\\", \\\"{x:569,y:619,t:1527264658162};\\\", \\\"{x:573,y:619,t:1527264658178};\\\", \\\"{x:582,y:617,t:1527264658195};\\\", \\\"{x:587,y:616,t:1527264658212};\\\", \\\"{x:593,y:613,t:1527264658229};\\\", \\\"{x:596,y:612,t:1527264658247};\\\", \\\"{x:599,y:611,t:1527264658262};\\\", \\\"{x:602,y:609,t:1527264658279};\\\", \\\"{x:604,y:608,t:1527264658295};\\\", \\\"{x:607,y:606,t:1527264658312};\\\", \\\"{x:609,y:604,t:1527264658329};\\\", \\\"{x:611,y:603,t:1527264658345};\\\", \\\"{x:611,y:602,t:1527264658361};\\\", \\\"{x:614,y:601,t:1527264658657};\\\", \\\"{x:625,y:599,t:1527264658665};\\\", \\\"{x:640,y:599,t:1527264658679};\\\", \\\"{x:689,y:599,t:1527264658696};\\\", \\\"{x:789,y:612,t:1527264658712};\\\", \\\"{x:976,y:639,t:1527264658729};\\\", \\\"{x:1106,y:670,t:1527264658746};\\\", \\\"{x:1229,y:698,t:1527264658761};\\\", \\\"{x:1332,y:732,t:1527264658779};\\\", \\\"{x:1420,y:765,t:1527264658796};\\\", \\\"{x:1483,y:791,t:1527264658812};\\\", \\\"{x:1525,y:812,t:1527264658829};\\\", \\\"{x:1556,y:832,t:1527264658846};\\\", \\\"{x:1589,y:851,t:1527264658862};\\\", \\\"{x:1622,y:874,t:1527264658879};\\\", \\\"{x:1662,y:903,t:1527264658896};\\\", \\\"{x:1703,y:927,t:1527264658912};\\\", \\\"{x:1762,y:960,t:1527264658929};\\\", \\\"{x:1793,y:980,t:1527264658946};\\\", \\\"{x:1815,y:996,t:1527264658963};\\\", \\\"{x:1826,y:1003,t:1527264658980};\\\", \\\"{x:1828,y:1005,t:1527264658996};\\\", \\\"{x:1823,y:1004,t:1527264659057};\\\", \\\"{x:1811,y:998,t:1527264659064};\\\", \\\"{x:1796,y:987,t:1527264659078};\\\", \\\"{x:1750,y:962,t:1527264659095};\\\", \\\"{x:1683,y:926,t:1527264659113};\\\", \\\"{x:1644,y:901,t:1527264659129};\\\", \\\"{x:1616,y:881,t:1527264659146};\\\", \\\"{x:1592,y:868,t:1527264659162};\\\", \\\"{x:1573,y:856,t:1527264659179};\\\", \\\"{x:1560,y:848,t:1527264659196};\\\", \\\"{x:1553,y:844,t:1527264659213};\\\", \\\"{x:1552,y:843,t:1527264659229};\\\", \\\"{x:1550,y:843,t:1527264659274};\\\", \\\"{x:1547,y:843,t:1527264659281};\\\", \\\"{x:1544,y:841,t:1527264659296};\\\", \\\"{x:1529,y:835,t:1527264659313};\\\", \\\"{x:1521,y:834,t:1527264659330};\\\", \\\"{x:1513,y:831,t:1527264659347};\\\", \\\"{x:1505,y:830,t:1527264659363};\\\", \\\"{x:1495,y:829,t:1527264659380};\\\", \\\"{x:1483,y:826,t:1527264659397};\\\", \\\"{x:1473,y:825,t:1527264659413};\\\", \\\"{x:1468,y:824,t:1527264659429};\\\", \\\"{x:1465,y:822,t:1527264659446};\\\", \\\"{x:1464,y:822,t:1527264659563};\\\", \\\"{x:1462,y:822,t:1527264659587};\\\", \\\"{x:1461,y:821,t:1527264660081};\\\", \\\"{x:1462,y:819,t:1527264660097};\\\", \\\"{x:1465,y:818,t:1527264660113};\\\", \\\"{x:1466,y:818,t:1527264660441};\\\", \\\"{x:1466,y:819,t:1527264660458};\\\", \\\"{x:1466,y:821,t:1527264660499};\\\", \\\"{x:1467,y:822,t:1527264660626};\\\", \\\"{x:1468,y:822,t:1527264660642};\\\", \\\"{x:1470,y:822,t:1527264660650};\\\", \\\"{x:1471,y:822,t:1527264660666};\\\", \\\"{x:1472,y:822,t:1527264660680};\\\", \\\"{x:1474,y:821,t:1527264660697};\\\", \\\"{x:1475,y:821,t:1527264660714};\\\", \\\"{x:1477,y:821,t:1527264660731};\\\", \\\"{x:1478,y:821,t:1527264660753};\\\", \\\"{x:1480,y:821,t:1527264660794};\\\", \\\"{x:1482,y:822,t:1527264660810};\\\", \\\"{x:1483,y:824,t:1527264660826};\\\", \\\"{x:1484,y:825,t:1527264660834};\\\", \\\"{x:1484,y:826,t:1527264660847};\\\", \\\"{x:1484,y:828,t:1527264660864};\\\", \\\"{x:1484,y:830,t:1527264660881};\\\", \\\"{x:1484,y:831,t:1527264660898};\\\", \\\"{x:1484,y:832,t:1527264660914};\\\", \\\"{x:1486,y:832,t:1527264662467};\\\", \\\"{x:1487,y:832,t:1527264662484};\\\", \\\"{x:1488,y:831,t:1527264662499};\\\", \\\"{x:1490,y:829,t:1527264662515};\\\", \\\"{x:1490,y:828,t:1527264662533};\\\", \\\"{x:1491,y:827,t:1527264662549};\\\", \\\"{x:1492,y:824,t:1527264662565};\\\", \\\"{x:1494,y:821,t:1527264662583};\\\", \\\"{x:1497,y:814,t:1527264662599};\\\", \\\"{x:1499,y:804,t:1527264662616};\\\", \\\"{x:1503,y:792,t:1527264662633};\\\", \\\"{x:1504,y:785,t:1527264662649};\\\", \\\"{x:1504,y:778,t:1527264662666};\\\", \\\"{x:1504,y:770,t:1527264662682};\\\", \\\"{x:1504,y:761,t:1527264662699};\\\", \\\"{x:1504,y:748,t:1527264662716};\\\", \\\"{x:1502,y:735,t:1527264662733};\\\", \\\"{x:1501,y:724,t:1527264662750};\\\", \\\"{x:1497,y:712,t:1527264662765};\\\", \\\"{x:1495,y:702,t:1527264662782};\\\", \\\"{x:1491,y:693,t:1527264662800};\\\", \\\"{x:1488,y:681,t:1527264662816};\\\", \\\"{x:1485,y:671,t:1527264662832};\\\", \\\"{x:1482,y:661,t:1527264662850};\\\", \\\"{x:1481,y:657,t:1527264662866};\\\", \\\"{x:1480,y:655,t:1527264662883};\\\", \\\"{x:1479,y:655,t:1527264662994};\\\", \\\"{x:1478,y:656,t:1527264663002};\\\", \\\"{x:1474,y:664,t:1527264663017};\\\", \\\"{x:1467,y:706,t:1527264663033};\\\", \\\"{x:1459,y:787,t:1527264663050};\\\", \\\"{x:1459,y:817,t:1527264663066};\\\", \\\"{x:1459,y:837,t:1527264663083};\\\", \\\"{x:1459,y:846,t:1527264663099};\\\", \\\"{x:1459,y:850,t:1527264663116};\\\", \\\"{x:1460,y:860,t:1527264663133};\\\", \\\"{x:1461,y:868,t:1527264663150};\\\", \\\"{x:1461,y:872,t:1527264663167};\\\", \\\"{x:1461,y:878,t:1527264663182};\\\", \\\"{x:1462,y:880,t:1527264663210};\\\", \\\"{x:1463,y:880,t:1527264663266};\\\", \\\"{x:1464,y:880,t:1527264663282};\\\", \\\"{x:1465,y:877,t:1527264663300};\\\", \\\"{x:1465,y:872,t:1527264663316};\\\", \\\"{x:1465,y:859,t:1527264663333};\\\", \\\"{x:1468,y:851,t:1527264663349};\\\", \\\"{x:1469,y:848,t:1527264663366};\\\", \\\"{x:1471,y:845,t:1527264663384};\\\", \\\"{x:1471,y:844,t:1527264663399};\\\", \\\"{x:1472,y:843,t:1527264663691};\\\", \\\"{x:1472,y:842,t:1527264663699};\\\", \\\"{x:1473,y:840,t:1527264663811};\\\", \\\"{x:1476,y:838,t:1527264663818};\\\", \\\"{x:1482,y:826,t:1527264663834};\\\", \\\"{x:1490,y:795,t:1527264663851};\\\", \\\"{x:1492,y:741,t:1527264663866};\\\", \\\"{x:1492,y:677,t:1527264663883};\\\", \\\"{x:1492,y:635,t:1527264663901};\\\", \\\"{x:1488,y:614,t:1527264663917};\\\", \\\"{x:1483,y:600,t:1527264663934};\\\", \\\"{x:1479,y:594,t:1527264663951};\\\", \\\"{x:1477,y:591,t:1527264663966};\\\", \\\"{x:1477,y:590,t:1527264663987};\\\", \\\"{x:1477,y:589,t:1527264664000};\\\", \\\"{x:1476,y:585,t:1527264664016};\\\", \\\"{x:1470,y:579,t:1527264664033};\\\", \\\"{x:1460,y:569,t:1527264664050};\\\", \\\"{x:1446,y:560,t:1527264664066};\\\", \\\"{x:1438,y:556,t:1527264664083};\\\", \\\"{x:1432,y:555,t:1527264664100};\\\", \\\"{x:1428,y:555,t:1527264664116};\\\", \\\"{x:1425,y:555,t:1527264664133};\\\", \\\"{x:1423,y:554,t:1527264664150};\\\", \\\"{x:1418,y:552,t:1527264664167};\\\", \\\"{x:1412,y:551,t:1527264664183};\\\", \\\"{x:1408,y:549,t:1527264664200};\\\", \\\"{x:1401,y:547,t:1527264664217};\\\", \\\"{x:1400,y:547,t:1527264664402};\\\", \\\"{x:1399,y:547,t:1527264664554};\\\", \\\"{x:1399,y:548,t:1527264664587};\\\", \\\"{x:1399,y:549,t:1527264664602};\\\", \\\"{x:1399,y:550,t:1527264664618};\\\", \\\"{x:1399,y:551,t:1527264664634};\\\", \\\"{x:1399,y:552,t:1527264664651};\\\", \\\"{x:1400,y:554,t:1527264664668};\\\", \\\"{x:1401,y:556,t:1527264664706};\\\", \\\"{x:1401,y:557,t:1527264664722};\\\", \\\"{x:1402,y:557,t:1527264664735};\\\", \\\"{x:1402,y:558,t:1527264664751};\\\", \\\"{x:1404,y:561,t:1527264664768};\\\", \\\"{x:1405,y:562,t:1527264664801};\\\", \\\"{x:1406,y:563,t:1527264664842};\\\", \\\"{x:1407,y:563,t:1527264664906};\\\", \\\"{x:1409,y:564,t:1527264664930};\\\", \\\"{x:1410,y:564,t:1527264664962};\\\", \\\"{x:1411,y:564,t:1527264664978};\\\", \\\"{x:1412,y:564,t:1527264664988};\\\", \\\"{x:1413,y:564,t:1527264665001};\\\", \\\"{x:1414,y:564,t:1527264665018};\\\", \\\"{x:1415,y:564,t:1527264665035};\\\", \\\"{x:1416,y:564,t:1527264665058};\\\", \\\"{x:1417,y:564,t:1527264665090};\\\", \\\"{x:1418,y:563,t:1527264665101};\\\", \\\"{x:1418,y:565,t:1527264666226};\\\", \\\"{x:1418,y:566,t:1527264666235};\\\", \\\"{x:1418,y:569,t:1527264666253};\\\", \\\"{x:1418,y:570,t:1527264666282};\\\", \\\"{x:1418,y:572,t:1527264666298};\\\", \\\"{x:1418,y:573,t:1527264666314};\\\", \\\"{x:1418,y:574,t:1527264666330};\\\", \\\"{x:1418,y:576,t:1527264666338};\\\", \\\"{x:1418,y:578,t:1527264666354};\\\", \\\"{x:1418,y:579,t:1527264666369};\\\", \\\"{x:1418,y:581,t:1527264666386};\\\", \\\"{x:1418,y:582,t:1527264666402};\\\", \\\"{x:1419,y:586,t:1527264666419};\\\", \\\"{x:1419,y:588,t:1527264666436};\\\", \\\"{x:1420,y:592,t:1527264666453};\\\", \\\"{x:1420,y:594,t:1527264666469};\\\", \\\"{x:1420,y:595,t:1527264666485};\\\", \\\"{x:1421,y:599,t:1527264666503};\\\", \\\"{x:1422,y:603,t:1527264666519};\\\", \\\"{x:1423,y:607,t:1527264666536};\\\", \\\"{x:1423,y:609,t:1527264666552};\\\", \\\"{x:1423,y:612,t:1527264666569};\\\", \\\"{x:1424,y:616,t:1527264666586};\\\", \\\"{x:1424,y:618,t:1527264666602};\\\", \\\"{x:1424,y:621,t:1527264666619};\\\", \\\"{x:1424,y:622,t:1527264666635};\\\", \\\"{x:1424,y:625,t:1527264666653};\\\", \\\"{x:1424,y:626,t:1527264666669};\\\", \\\"{x:1424,y:628,t:1527264666686};\\\", \\\"{x:1425,y:629,t:1527264666730};\\\", \\\"{x:1425,y:630,t:1527264666794};\\\", \\\"{x:1425,y:629,t:1527264667154};\\\", \\\"{x:1425,y:624,t:1527264667170};\\\", \\\"{x:1425,y:618,t:1527264667186};\\\", \\\"{x:1425,y:606,t:1527264667203};\\\", \\\"{x:1425,y:600,t:1527264667220};\\\", \\\"{x:1425,y:598,t:1527264667236};\\\", \\\"{x:1424,y:596,t:1527264667253};\\\", \\\"{x:1424,y:595,t:1527264667270};\\\", \\\"{x:1424,y:593,t:1527264667287};\\\", \\\"{x:1423,y:591,t:1527264667303};\\\", \\\"{x:1423,y:587,t:1527264667320};\\\", \\\"{x:1422,y:586,t:1527264667337};\\\", \\\"{x:1421,y:583,t:1527264667352};\\\", \\\"{x:1420,y:579,t:1527264667370};\\\", \\\"{x:1419,y:577,t:1527264667387};\\\", \\\"{x:1418,y:575,t:1527264667402};\\\", \\\"{x:1417,y:572,t:1527264667420};\\\", \\\"{x:1416,y:570,t:1527264667437};\\\", \\\"{x:1416,y:569,t:1527264667453};\\\", \\\"{x:1416,y:567,t:1527264667470};\\\", \\\"{x:1416,y:566,t:1527264667486};\\\", \\\"{x:1414,y:563,t:1527264667502};\\\", \\\"{x:1414,y:561,t:1527264667520};\\\", \\\"{x:1414,y:558,t:1527264667537};\\\", \\\"{x:1414,y:560,t:1527264671162};\\\", \\\"{x:1414,y:575,t:1527264671173};\\\", \\\"{x:1414,y:611,t:1527264671189};\\\", \\\"{x:1414,y:651,t:1527264671206};\\\", \\\"{x:1419,y:701,t:1527264671223};\\\", \\\"{x:1423,y:737,t:1527264671239};\\\", \\\"{x:1427,y:763,t:1527264671256};\\\", \\\"{x:1430,y:782,t:1527264671273};\\\", \\\"{x:1430,y:795,t:1527264671289};\\\", \\\"{x:1430,y:797,t:1527264671305};\\\", \\\"{x:1430,y:799,t:1527264671323};\\\", \\\"{x:1430,y:800,t:1527264671340};\\\", \\\"{x:1429,y:800,t:1527264671394};\\\", \\\"{x:1428,y:800,t:1527264671406};\\\", \\\"{x:1423,y:800,t:1527264671423};\\\", \\\"{x:1418,y:800,t:1527264671440};\\\", \\\"{x:1411,y:800,t:1527264671456};\\\", \\\"{x:1402,y:796,t:1527264671473};\\\", \\\"{x:1393,y:788,t:1527264671489};\\\", \\\"{x:1386,y:780,t:1527264671506};\\\", \\\"{x:1382,y:776,t:1527264671523};\\\", \\\"{x:1380,y:773,t:1527264671540};\\\", \\\"{x:1379,y:772,t:1527264671556};\\\", \\\"{x:1380,y:771,t:1527264671586};\\\", \\\"{x:1381,y:770,t:1527264671593};\\\", \\\"{x:1383,y:769,t:1527264671605};\\\", \\\"{x:1385,y:768,t:1527264671623};\\\", \\\"{x:1387,y:766,t:1527264671640};\\\", \\\"{x:1388,y:765,t:1527264671656};\\\", \\\"{x:1388,y:763,t:1527264671673};\\\", \\\"{x:1389,y:763,t:1527264671690};\\\", \\\"{x:1390,y:762,t:1527264671706};\\\", \\\"{x:1391,y:760,t:1527264671787};\\\", \\\"{x:1391,y:759,t:1527264671810};\\\", \\\"{x:1392,y:757,t:1527264671825};\\\", \\\"{x:1393,y:756,t:1527264671842};\\\", \\\"{x:1391,y:756,t:1527264672154};\\\", \\\"{x:1389,y:757,t:1527264672161};\\\", \\\"{x:1385,y:757,t:1527264672173};\\\", \\\"{x:1378,y:758,t:1527264672190};\\\", \\\"{x:1374,y:760,t:1527264672208};\\\", \\\"{x:1375,y:761,t:1527264674129};\\\", \\\"{x:1376,y:761,t:1527264674141};\\\", \\\"{x:1377,y:761,t:1527264674157};\\\", \\\"{x:1378,y:761,t:1527264674174};\\\", \\\"{x:1379,y:762,t:1527264674193};\\\", \\\"{x:1381,y:762,t:1527264674722};\\\", \\\"{x:1382,y:763,t:1527264674753};\\\", \\\"{x:1382,y:764,t:1527264676162};\\\", \\\"{x:1382,y:771,t:1527264676179};\\\", \\\"{x:1380,y:780,t:1527264676194};\\\", \\\"{x:1379,y:788,t:1527264676210};\\\", \\\"{x:1378,y:796,t:1527264676227};\\\", \\\"{x:1378,y:802,t:1527264676243};\\\", \\\"{x:1378,y:807,t:1527264676260};\\\", \\\"{x:1378,y:810,t:1527264676277};\\\", \\\"{x:1378,y:814,t:1527264676293};\\\", \\\"{x:1378,y:815,t:1527264676310};\\\", \\\"{x:1378,y:818,t:1527264676327};\\\", \\\"{x:1378,y:823,t:1527264676344};\\\", \\\"{x:1378,y:830,t:1527264676360};\\\", \\\"{x:1378,y:840,t:1527264676378};\\\", \\\"{x:1378,y:849,t:1527264676394};\\\", \\\"{x:1378,y:859,t:1527264676411};\\\", \\\"{x:1378,y:870,t:1527264676428};\\\", \\\"{x:1378,y:884,t:1527264676444};\\\", \\\"{x:1378,y:891,t:1527264676461};\\\", \\\"{x:1378,y:893,t:1527264676478};\\\", \\\"{x:1378,y:895,t:1527264676494};\\\", \\\"{x:1378,y:896,t:1527264676514};\\\", \\\"{x:1378,y:897,t:1527264676528};\\\", \\\"{x:1378,y:898,t:1527264676544};\\\", \\\"{x:1377,y:899,t:1527264676560};\\\", \\\"{x:1376,y:899,t:1527264676577};\\\", \\\"{x:1376,y:900,t:1527264676617};\\\", \\\"{x:1376,y:901,t:1527264676642};\\\", \\\"{x:1375,y:902,t:1527264676666};\\\", \\\"{x:1374,y:902,t:1527264676678};\\\", \\\"{x:1372,y:902,t:1527264676695};\\\", \\\"{x:1369,y:902,t:1527264676710};\\\", \\\"{x:1365,y:902,t:1527264676727};\\\", \\\"{x:1360,y:902,t:1527264676744};\\\", \\\"{x:1356,y:902,t:1527264676760};\\\", \\\"{x:1355,y:902,t:1527264676778};\\\", \\\"{x:1354,y:902,t:1527264676874};\\\", \\\"{x:1353,y:901,t:1527264677002};\\\", \\\"{x:1352,y:900,t:1527264677012};\\\", \\\"{x:1349,y:898,t:1527264677027};\\\", \\\"{x:1344,y:895,t:1527264677045};\\\", \\\"{x:1340,y:894,t:1527264677063};\\\", \\\"{x:1338,y:892,t:1527264677078};\\\", \\\"{x:1335,y:890,t:1527264677094};\\\", \\\"{x:1335,y:889,t:1527264677111};\\\", \\\"{x:1335,y:887,t:1527264677127};\\\", \\\"{x:1335,y:885,t:1527264677144};\\\", \\\"{x:1335,y:880,t:1527264677161};\\\", \\\"{x:1335,y:877,t:1527264677177};\\\", \\\"{x:1335,y:875,t:1527264677201};\\\", \\\"{x:1335,y:874,t:1527264677226};\\\", \\\"{x:1337,y:874,t:1527264677314};\\\", \\\"{x:1339,y:874,t:1527264677330};\\\", \\\"{x:1341,y:875,t:1527264677344};\\\", \\\"{x:1351,y:882,t:1527264677361};\\\", \\\"{x:1358,y:886,t:1527264677378};\\\", \\\"{x:1364,y:891,t:1527264677394};\\\", \\\"{x:1369,y:896,t:1527264677412};\\\", \\\"{x:1374,y:900,t:1527264677427};\\\", \\\"{x:1382,y:909,t:1527264677444};\\\", \\\"{x:1387,y:914,t:1527264677461};\\\", \\\"{x:1389,y:916,t:1527264677478};\\\", \\\"{x:1390,y:917,t:1527264677494};\\\", \\\"{x:1392,y:917,t:1527264677511};\\\", \\\"{x:1393,y:919,t:1527264677529};\\\", \\\"{x:1394,y:919,t:1527264677553};\\\", \\\"{x:1393,y:919,t:1527264677688};\\\", \\\"{x:1391,y:918,t:1527264677697};\\\", \\\"{x:1390,y:918,t:1527264677710};\\\", \\\"{x:1388,y:916,t:1527264677728};\\\", \\\"{x:1387,y:916,t:1527264677744};\\\", \\\"{x:1385,y:915,t:1527264677762};\\\", \\\"{x:1383,y:913,t:1527264677777};\\\", \\\"{x:1382,y:912,t:1527264677794};\\\", \\\"{x:1380,y:911,t:1527264677811};\\\", \\\"{x:1378,y:911,t:1527264677828};\\\", \\\"{x:1376,y:910,t:1527264677844};\\\", \\\"{x:1375,y:910,t:1527264677861};\\\", \\\"{x:1374,y:909,t:1527264677878};\\\", \\\"{x:1373,y:909,t:1527264677914};\\\", \\\"{x:1373,y:907,t:1527264678058};\\\", \\\"{x:1373,y:906,t:1527264678122};\\\", \\\"{x:1373,y:904,t:1527264678146};\\\", \\\"{x:1373,y:903,t:1527264678162};\\\", \\\"{x:1367,y:893,t:1527264678178};\\\", \\\"{x:1354,y:883,t:1527264678196};\\\", \\\"{x:1323,y:866,t:1527264678211};\\\", \\\"{x:1275,y:840,t:1527264678229};\\\", \\\"{x:1207,y:801,t:1527264678245};\\\", \\\"{x:1117,y:754,t:1527264678261};\\\", \\\"{x:1031,y:713,t:1527264678278};\\\", \\\"{x:948,y:674,t:1527264678296};\\\", \\\"{x:880,y:639,t:1527264678311};\\\", \\\"{x:823,y:606,t:1527264678329};\\\", \\\"{x:740,y:577,t:1527264678346};\\\", \\\"{x:681,y:558,t:1527264678362};\\\", \\\"{x:643,y:551,t:1527264678373};\\\", \\\"{x:573,y:537,t:1527264678389};\\\", \\\"{x:430,y:517,t:1527264678412};\\\", \\\"{x:341,y:506,t:1527264678428};\\\", \\\"{x:273,y:500,t:1527264678445};\\\", \\\"{x:221,y:518,t:1527264678462};\\\", \\\"{x:192,y:546,t:1527264678479};\\\", \\\"{x:183,y:567,t:1527264678495};\\\", \\\"{x:179,y:589,t:1527264678512};\\\", \\\"{x:182,y:626,t:1527264678530};\\\", \\\"{x:193,y:649,t:1527264678545};\\\", \\\"{x:200,y:666,t:1527264678562};\\\", \\\"{x:207,y:680,t:1527264678578};\\\", \\\"{x:216,y:691,t:1527264678594};\\\", \\\"{x:226,y:701,t:1527264678611};\\\", \\\"{x:239,y:706,t:1527264678629};\\\", \\\"{x:253,y:712,t:1527264678646};\\\", \\\"{x:278,y:719,t:1527264678662};\\\", \\\"{x:311,y:727,t:1527264678679};\\\", \\\"{x:350,y:738,t:1527264678696};\\\", \\\"{x:391,y:742,t:1527264678712};\\\", \\\"{x:440,y:747,t:1527264678729};\\\", \\\"{x:458,y:748,t:1527264678746};\\\", \\\"{x:473,y:748,t:1527264678763};\\\", \\\"{x:487,y:746,t:1527264678779};\\\", \\\"{x:500,y:743,t:1527264678795};\\\", \\\"{x:513,y:739,t:1527264678813};\\\", \\\"{x:524,y:738,t:1527264678830};\\\", \\\"{x:531,y:736,t:1527264678846};\\\", \\\"{x:534,y:736,t:1527264678863};\\\", \\\"{x:535,y:736,t:1527264678880};\\\", \\\"{x:539,y:734,t:1527264678899};\\\", \\\"{x:542,y:733,t:1527264678912};\\\", \\\"{x:543,y:732,t:1527264678929};\\\", \\\"{x:545,y:730,t:1527264678946};\\\", \\\"{x:547,y:728,t:1527264678963};\\\", \\\"{x:547,y:727,t:1527264678985};\\\", \\\"{x:547,y:726,t:1527264678995};\\\", \\\"{x:548,y:724,t:1527264679012};\\\", \\\"{x:548,y:723,t:1527264679030};\\\", \\\"{x:549,y:721,t:1527264679046};\\\", \\\"{x:550,y:718,t:1527264679063};\\\", \\\"{x:550,y:716,t:1527264679079};\\\", \\\"{x:550,y:713,t:1527264679097};\\\", \\\"{x:551,y:710,t:1527264679113};\\\" ] }, { \\\"rt\\\": 151886, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 417905, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"J\\\", \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:710,t:1527264686202};\\\", \\\"{x:574,y:680,t:1527264686218};\\\", \\\"{x:599,y:632,t:1527264686234};\\\", \\\"{x:635,y:539,t:1527264686253};\\\", \\\"{x:689,y:409,t:1527264686268};\\\", \\\"{x:714,y:289,t:1527264686284};\\\", \\\"{x:726,y:213,t:1527264686301};\\\", \\\"{x:730,y:185,t:1527264686318};\\\", \\\"{x:730,y:169,t:1527264686335};\\\", \\\"{x:730,y:164,t:1527264686351};\\\", \\\"{x:730,y:163,t:1527264686377};\\\", \\\"{x:729,y:163,t:1527264686400};\\\", \\\"{x:724,y:165,t:1527264686418};\\\", \\\"{x:712,y:193,t:1527264686435};\\\", \\\"{x:694,y:252,t:1527264686451};\\\", \\\"{x:654,y:348,t:1527264686468};\\\", \\\"{x:624,y:445,t:1527264686485};\\\", \\\"{x:596,y:509,t:1527264686501};\\\", \\\"{x:577,y:539,t:1527264686518};\\\", \\\"{x:565,y:556,t:1527264686536};\\\", \\\"{x:555,y:564,t:1527264686552};\\\", \\\"{x:542,y:572,t:1527264686568};\\\", \\\"{x:520,y:582,t:1527264686585};\\\", \\\"{x:513,y:582,t:1527264686601};\\\", \\\"{x:506,y:582,t:1527264686618};\\\", \\\"{x:500,y:580,t:1527264686635};\\\", \\\"{x:496,y:576,t:1527264686652};\\\", \\\"{x:492,y:571,t:1527264686668};\\\", \\\"{x:491,y:562,t:1527264686685};\\\", \\\"{x:489,y:547,t:1527264686701};\\\", \\\"{x:489,y:528,t:1527264686718};\\\", \\\"{x:494,y:503,t:1527264686735};\\\", \\\"{x:499,y:483,t:1527264686751};\\\", \\\"{x:504,y:468,t:1527264686768};\\\", \\\"{x:508,y:463,t:1527264686785};\\\", \\\"{x:509,y:462,t:1527264686801};\\\", \\\"{x:509,y:461,t:1527264686818};\\\", \\\"{x:508,y:462,t:1527264686946};\\\", \\\"{x:506,y:463,t:1527264686961};\\\", \\\"{x:505,y:463,t:1527264686969};\\\", \\\"{x:502,y:463,t:1527264686986};\\\", \\\"{x:501,y:463,t:1527264687009};\\\", \\\"{x:499,y:463,t:1527264687049};\\\", \\\"{x:498,y:462,t:1527264687065};\\\", \\\"{x:497,y:461,t:1527264687081};\\\", \\\"{x:496,y:460,t:1527264687089};\\\", \\\"{x:494,y:459,t:1527264687138};\\\", \\\"{x:493,y:458,t:1527264687154};\\\", \\\"{x:492,y:458,t:1527264687186};\\\", \\\"{x:491,y:458,t:1527264687203};\\\", \\\"{x:494,y:458,t:1527264687474};\\\", \\\"{x:502,y:458,t:1527264687486};\\\", \\\"{x:520,y:460,t:1527264687502};\\\", \\\"{x:545,y:464,t:1527264687519};\\\", \\\"{x:567,y:467,t:1527264687535};\\\", \\\"{x:585,y:470,t:1527264687552};\\\", \\\"{x:596,y:472,t:1527264687568};\\\", \\\"{x:598,y:472,t:1527264687585};\\\", \\\"{x:599,y:472,t:1527264687649};\\\", \\\"{x:601,y:472,t:1527264687720};\\\", \\\"{x:604,y:472,t:1527264687736};\\\", \\\"{x:611,y:472,t:1527264687752};\\\", \\\"{x:624,y:470,t:1527264687770};\\\", \\\"{x:636,y:468,t:1527264687786};\\\", \\\"{x:646,y:466,t:1527264687802};\\\", \\\"{x:655,y:465,t:1527264687819};\\\", \\\"{x:659,y:464,t:1527264687836};\\\", \\\"{x:662,y:464,t:1527264687852};\\\", \\\"{x:663,y:464,t:1527264687869};\\\", \\\"{x:665,y:462,t:1527264687886};\\\", \\\"{x:665,y:462,t:1527264688547};\\\", \\\"{x:669,y:462,t:1527264689818};\\\", \\\"{x:691,y:462,t:1527264689825};\\\", \\\"{x:734,y:465,t:1527264689838};\\\", \\\"{x:819,y:500,t:1527264689855};\\\", \\\"{x:914,y:534,t:1527264689873};\\\", \\\"{x:1022,y:577,t:1527264689888};\\\", \\\"{x:1293,y:717,t:1527264689921};\\\", \\\"{x:1297,y:717,t:1527264690793};\\\", \\\"{x:1305,y:713,t:1527264690804};\\\", \\\"{x:1324,y:696,t:1527264690822};\\\", \\\"{x:1345,y:663,t:1527264690839};\\\", \\\"{x:1368,y:610,t:1527264690855};\\\", \\\"{x:1389,y:561,t:1527264690872};\\\", \\\"{x:1395,y:538,t:1527264690888};\\\", \\\"{x:1400,y:526,t:1527264690905};\\\", \\\"{x:1401,y:523,t:1527264690922};\\\", \\\"{x:1402,y:519,t:1527264690939};\\\", \\\"{x:1404,y:517,t:1527264690955};\\\", \\\"{x:1404,y:512,t:1527264690971};\\\", \\\"{x:1404,y:507,t:1527264690989};\\\", \\\"{x:1401,y:497,t:1527264691005};\\\", \\\"{x:1395,y:482,t:1527264691022};\\\", \\\"{x:1387,y:472,t:1527264691038};\\\", \\\"{x:1380,y:469,t:1527264691056};\\\", \\\"{x:1370,y:468,t:1527264691072};\\\", \\\"{x:1358,y:469,t:1527264691088};\\\", \\\"{x:1335,y:478,t:1527264691105};\\\", \\\"{x:1323,y:484,t:1527264691121};\\\", \\\"{x:1317,y:486,t:1527264691138};\\\", \\\"{x:1314,y:488,t:1527264691156};\\\", \\\"{x:1313,y:489,t:1527264691172};\\\", \\\"{x:1313,y:491,t:1527264691380};\\\", \\\"{x:1313,y:492,t:1527264691513};\\\", \\\"{x:1313,y:494,t:1527264691537};\\\", \\\"{x:1313,y:495,t:1527264691746};\\\", \\\"{x:1313,y:497,t:1527264691810};\\\", \\\"{x:1314,y:497,t:1527264692866};\\\", \\\"{x:1315,y:497,t:1527264692873};\\\", \\\"{x:1318,y:497,t:1527264719964};\\\", \\\"{x:1321,y:497,t:1527264719984};\\\", \\\"{x:1322,y:497,t:1527264719998};\\\", \\\"{x:1324,y:497,t:1527264720014};\\\", \\\"{x:1325,y:497,t:1527264720032};\\\", \\\"{x:1325,y:496,t:1527264720047};\\\", \\\"{x:1324,y:496,t:1527264720243};\\\", \\\"{x:1322,y:496,t:1527264720251};\\\", \\\"{x:1320,y:496,t:1527264720265};\\\", \\\"{x:1318,y:496,t:1527264720281};\\\", \\\"{x:1316,y:496,t:1527264720298};\\\", \\\"{x:1314,y:515,t:1527264732477};\\\", \\\"{x:1314,y:626,t:1527264732492};\\\", \\\"{x:1330,y:713,t:1527264732509};\\\", \\\"{x:1342,y:760,t:1527264732525};\\\", \\\"{x:1344,y:779,t:1527264732542};\\\", \\\"{x:1344,y:783,t:1527264732558};\\\", \\\"{x:1344,y:784,t:1527264732575};\\\", \\\"{x:1342,y:786,t:1527264732592};\\\", \\\"{x:1336,y:790,t:1527264732609};\\\", \\\"{x:1327,y:795,t:1527264732624};\\\", \\\"{x:1321,y:800,t:1527264732642};\\\", \\\"{x:1319,y:805,t:1527264732658};\\\", \\\"{x:1318,y:806,t:1527264732676};\\\", \\\"{x:1318,y:800,t:1527264732724};\\\", \\\"{x:1318,y:790,t:1527264732732};\\\", \\\"{x:1318,y:779,t:1527264732742};\\\", \\\"{x:1315,y:752,t:1527264732758};\\\", \\\"{x:1315,y:730,t:1527264732775};\\\", \\\"{x:1315,y:709,t:1527264732791};\\\", \\\"{x:1315,y:697,t:1527264732809};\\\", \\\"{x:1314,y:694,t:1527264732826};\\\", \\\"{x:1312,y:691,t:1527264732842};\\\", \\\"{x:1307,y:688,t:1527264732859};\\\", \\\"{x:1302,y:683,t:1527264732875};\\\", \\\"{x:1301,y:683,t:1527264732892};\\\", \\\"{x:1301,y:681,t:1527264732909};\\\", \\\"{x:1301,y:680,t:1527264732997};\\\", \\\"{x:1300,y:680,t:1527264733028};\\\", \\\"{x:1300,y:682,t:1527264733042};\\\", \\\"{x:1300,y:683,t:1527264733059};\\\", \\\"{x:1300,y:684,t:1527264733075};\\\", \\\"{x:1301,y:686,t:1527264733092};\\\", \\\"{x:1302,y:686,t:1527264733116};\\\", \\\"{x:1303,y:687,t:1527264733212};\\\", \\\"{x:1304,y:687,t:1527264733340};\\\", \\\"{x:1305,y:687,t:1527264733364};\\\", \\\"{x:1307,y:689,t:1527264733380};\\\", \\\"{x:1308,y:690,t:1527264733395};\\\", \\\"{x:1308,y:691,t:1527264733436};\\\", \\\"{x:1308,y:692,t:1527264733444};\\\", \\\"{x:1308,y:693,t:1527264733460};\\\", \\\"{x:1309,y:694,t:1527264733476};\\\", \\\"{x:1309,y:695,t:1527264733492};\\\", \\\"{x:1309,y:696,t:1527264733509};\\\", \\\"{x:1309,y:697,t:1527264733532};\\\", \\\"{x:1309,y:698,t:1527264733757};\\\", \\\"{x:1310,y:698,t:1527264733764};\\\", \\\"{x:1311,y:698,t:1527264733775};\\\", \\\"{x:1314,y:698,t:1527264733792};\\\", \\\"{x:1315,y:698,t:1527264733809};\\\", \\\"{x:1316,y:698,t:1527264733825};\\\", \\\"{x:1316,y:697,t:1527264733964};\\\", \\\"{x:1316,y:700,t:1527264760300};\\\", \\\"{x:1316,y:708,t:1527264760314};\\\", \\\"{x:1316,y:718,t:1527264760331};\\\", \\\"{x:1315,y:727,t:1527264760347};\\\", \\\"{x:1314,y:732,t:1527264760364};\\\", \\\"{x:1314,y:731,t:1527264760748};\\\", \\\"{x:1314,y:730,t:1527264760788};\\\", \\\"{x:1314,y:728,t:1527264760812};\\\", \\\"{x:1314,y:727,t:1527264760820};\\\", \\\"{x:1314,y:725,t:1527264760835};\\\", \\\"{x:1314,y:724,t:1527264760883};\\\", \\\"{x:1314,y:722,t:1527264760915};\\\", \\\"{x:1314,y:721,t:1527264761116};\\\", \\\"{x:1314,y:717,t:1527264808566};\\\", \\\"{x:1269,y:695,t:1527264808573};\\\", \\\"{x:1190,y:661,t:1527264808588};\\\", \\\"{x:929,y:568,t:1527264808607};\\\", \\\"{x:753,y:497,t:1527264808622};\\\", \\\"{x:596,y:432,t:1527264808638};\\\", \\\"{x:539,y:400,t:1527264808655};\\\", \\\"{x:538,y:400,t:1527264808673};\\\", \\\"{x:538,y:397,t:1527264808688};\\\", \\\"{x:545,y:391,t:1527264808706};\\\", \\\"{x:565,y:385,t:1527264808722};\\\", \\\"{x:574,y:383,t:1527264808739};\\\", \\\"{x:577,y:381,t:1527264808755};\\\", \\\"{x:584,y:379,t:1527264808773};\\\", \\\"{x:595,y:376,t:1527264808789};\\\", \\\"{x:605,y:374,t:1527264808806};\\\", \\\"{x:626,y:378,t:1527264808823};\\\", \\\"{x:650,y:401,t:1527264808840};\\\", \\\"{x:672,y:444,t:1527264808856};\\\", \\\"{x:682,y:505,t:1527264808873};\\\", \\\"{x:684,y:578,t:1527264808891};\\\", \\\"{x:677,y:640,t:1527264808906};\\\", \\\"{x:670,y:655,t:1527264808924};\\\", \\\"{x:670,y:654,t:1527264809199};\\\", \\\"{x:666,y:652,t:1527264809214};\\\", \\\"{x:663,y:647,t:1527264809225};\\\", \\\"{x:662,y:643,t:1527264809242};\\\", \\\"{x:662,y:640,t:1527264809257};\\\", \\\"{x:662,y:639,t:1527264809275};\\\", \\\"{x:660,y:637,t:1527264809292};\\\", \\\"{x:658,y:635,t:1527264809308};\\\", \\\"{x:656,y:634,t:1527264809325};\\\", \\\"{x:651,y:629,t:1527264809343};\\\", \\\"{x:645,y:624,t:1527264809359};\\\", \\\"{x:635,y:616,t:1527264809374};\\\", \\\"{x:627,y:611,t:1527264809391};\\\", \\\"{x:622,y:606,t:1527264809407};\\\", \\\"{x:617,y:598,t:1527264809423};\\\", \\\"{x:612,y:584,t:1527264809440};\\\", \\\"{x:608,y:577,t:1527264809456};\\\", \\\"{x:606,y:574,t:1527264809474};\\\", \\\"{x:605,y:570,t:1527264809491};\\\", \\\"{x:604,y:569,t:1527264809507};\\\", \\\"{x:604,y:568,t:1527264809523};\\\", \\\"{x:604,y:566,t:1527264809540};\\\", \\\"{x:604,y:565,t:1527264809997};\\\", \\\"{x:603,y:565,t:1527264810007};\\\", \\\"{x:603,y:564,t:1527264810024};\\\", \\\"{x:598,y:566,t:1527264810327};\\\", \\\"{x:598,y:567,t:1527264810340};\\\", \\\"{x:613,y:588,t:1527264810357};\\\", \\\"{x:646,y:603,t:1527264810376};\\\", \\\"{x:688,y:615,t:1527264810392};\\\", \\\"{x:727,y:624,t:1527264810409};\\\", \\\"{x:754,y:628,t:1527264810425};\\\", \\\"{x:772,y:628,t:1527264810441};\\\", \\\"{x:776,y:628,t:1527264810457};\\\", \\\"{x:777,y:625,t:1527264810474};\\\", \\\"{x:776,y:617,t:1527264810492};\\\", \\\"{x:772,y:610,t:1527264810508};\\\", \\\"{x:767,y:604,t:1527264810525};\\\", \\\"{x:761,y:599,t:1527264810541};\\\", \\\"{x:744,y:592,t:1527264810558};\\\", \\\"{x:729,y:589,t:1527264810575};\\\", \\\"{x:710,y:589,t:1527264810591};\\\", \\\"{x:692,y:589,t:1527264810607};\\\", \\\"{x:672,y:589,t:1527264810625};\\\", \\\"{x:651,y:591,t:1527264810642};\\\", \\\"{x:636,y:596,t:1527264810658};\\\", \\\"{x:626,y:599,t:1527264810675};\\\", \\\"{x:622,y:604,t:1527264810691};\\\", \\\"{x:622,y:607,t:1527264810707};\\\", \\\"{x:622,y:608,t:1527264810725};\\\", \\\"{x:622,y:610,t:1527264810741};\\\", \\\"{x:618,y:611,t:1527264810758};\\\", \\\"{x:600,y:611,t:1527264810774};\\\", \\\"{x:576,y:611,t:1527264810792};\\\", \\\"{x:553,y:611,t:1527264810807};\\\", \\\"{x:539,y:611,t:1527264810824};\\\", \\\"{x:533,y:611,t:1527264810842};\\\", \\\"{x:534,y:610,t:1527264810870};\\\", \\\"{x:539,y:610,t:1527264810877};\\\", \\\"{x:547,y:610,t:1527264810891};\\\", \\\"{x:562,y:610,t:1527264810908};\\\", \\\"{x:584,y:610,t:1527264810925};\\\", \\\"{x:618,y:610,t:1527264810941};\\\", \\\"{x:635,y:610,t:1527264810959};\\\", \\\"{x:648,y:610,t:1527264810974};\\\", \\\"{x:656,y:609,t:1527264810991};\\\", \\\"{x:656,y:608,t:1527264811009};\\\", \\\"{x:656,y:606,t:1527264811069};\\\", \\\"{x:651,y:606,t:1527264811077};\\\", \\\"{x:637,y:604,t:1527264811091};\\\", \\\"{x:603,y:600,t:1527264811109};\\\", \\\"{x:553,y:594,t:1527264811125};\\\", \\\"{x:458,y:586,t:1527264811141};\\\", \\\"{x:415,y:585,t:1527264811158};\\\", \\\"{x:396,y:585,t:1527264811174};\\\", \\\"{x:392,y:586,t:1527264811192};\\\", \\\"{x:392,y:588,t:1527264811213};\\\", \\\"{x:393,y:589,t:1527264811230};\\\", \\\"{x:394,y:590,t:1527264811246};\\\", \\\"{x:394,y:591,t:1527264811262};\\\", \\\"{x:394,y:592,t:1527264811275};\\\", \\\"{x:394,y:593,t:1527264811294};\\\", \\\"{x:394,y:595,t:1527264811318};\\\", \\\"{x:394,y:597,t:1527264811335};\\\", \\\"{x:394,y:599,t:1527264811350};\\\", \\\"{x:394,y:602,t:1527264811358};\\\", \\\"{x:394,y:606,t:1527264811374};\\\", \\\"{x:394,y:611,t:1527264811391};\\\", \\\"{x:394,y:617,t:1527264811408};\\\", \\\"{x:394,y:627,t:1527264811426};\\\", \\\"{x:394,y:638,t:1527264811442};\\\", \\\"{x:396,y:645,t:1527264811458};\\\", \\\"{x:396,y:651,t:1527264811475};\\\", \\\"{x:396,y:655,t:1527264811492};\\\", \\\"{x:396,y:657,t:1527264811509};\\\", \\\"{x:389,y:661,t:1527264811526};\\\", \\\"{x:381,y:663,t:1527264811542};\\\", \\\"{x:371,y:665,t:1527264811559};\\\", \\\"{x:360,y:666,t:1527264811575};\\\", \\\"{x:351,y:668,t:1527264811591};\\\", \\\"{x:339,y:669,t:1527264811609};\\\", \\\"{x:327,y:669,t:1527264811626};\\\", \\\"{x:313,y:669,t:1527264811642};\\\", \\\"{x:298,y:669,t:1527264811658};\\\", \\\"{x:281,y:668,t:1527264811675};\\\", \\\"{x:266,y:666,t:1527264811691};\\\", \\\"{x:252,y:662,t:1527264811710};\\\", \\\"{x:235,y:661,t:1527264811725};\\\", \\\"{x:224,y:661,t:1527264811743};\\\", \\\"{x:212,y:662,t:1527264811759};\\\", \\\"{x:206,y:663,t:1527264811776};\\\", \\\"{x:196,y:664,t:1527264811793};\\\", \\\"{x:185,y:664,t:1527264811808};\\\", \\\"{x:175,y:664,t:1527264811825};\\\", \\\"{x:165,y:664,t:1527264811843};\\\", \\\"{x:159,y:664,t:1527264811859};\\\", \\\"{x:157,y:664,t:1527264811876};\\\", \\\"{x:156,y:663,t:1527264811892};\\\", \\\"{x:156,y:662,t:1527264811910};\\\", \\\"{x:156,y:660,t:1527264811926};\\\", \\\"{x:156,y:658,t:1527264811942};\\\", \\\"{x:156,y:657,t:1527264811958};\\\", \\\"{x:156,y:656,t:1527264811981};\\\", \\\"{x:157,y:656,t:1527264811992};\\\", \\\"{x:158,y:654,t:1527264812008};\\\", \\\"{x:166,y:654,t:1527264812026};\\\", \\\"{x:181,y:654,t:1527264812043};\\\", \\\"{x:215,y:654,t:1527264812058};\\\", \\\"{x:266,y:657,t:1527264812076};\\\", \\\"{x:327,y:663,t:1527264812093};\\\", \\\"{x:399,y:663,t:1527264812109};\\\", \\\"{x:497,y:663,t:1527264812125};\\\", \\\"{x:537,y:660,t:1527264812144};\\\", \\\"{x:554,y:657,t:1527264812159};\\\", \\\"{x:563,y:656,t:1527264812175};\\\", \\\"{x:566,y:655,t:1527264812193};\\\", \\\"{x:568,y:655,t:1527264812214};\\\", \\\"{x:569,y:655,t:1527264812225};\\\", \\\"{x:573,y:655,t:1527264812242};\\\", \\\"{x:580,y:655,t:1527264812258};\\\", \\\"{x:589,y:655,t:1527264812275};\\\", \\\"{x:603,y:651,t:1527264812293};\\\", \\\"{x:619,y:649,t:1527264812309};\\\", \\\"{x:641,y:645,t:1527264812326};\\\", \\\"{x:657,y:640,t:1527264812343};\\\", \\\"{x:673,y:636,t:1527264812360};\\\", \\\"{x:694,y:630,t:1527264812376};\\\", \\\"{x:718,y:628,t:1527264812392};\\\", \\\"{x:746,y:625,t:1527264812410};\\\", \\\"{x:775,y:625,t:1527264812425};\\\", \\\"{x:805,y:625,t:1527264812442};\\\", \\\"{x:834,y:625,t:1527264812459};\\\", \\\"{x:857,y:625,t:1527264812476};\\\", \\\"{x:874,y:625,t:1527264812493};\\\", \\\"{x:903,y:625,t:1527264812508};\\\", \\\"{x:914,y:625,t:1527264812525};\\\", \\\"{x:922,y:624,t:1527264812542};\\\", \\\"{x:926,y:624,t:1527264812559};\\\", \\\"{x:930,y:624,t:1527264812575};\\\", \\\"{x:936,y:624,t:1527264812593};\\\", \\\"{x:937,y:623,t:1527264812608};\\\", \\\"{x:938,y:620,t:1527264812626};\\\", \\\"{x:937,y:614,t:1527264812643};\\\", \\\"{x:926,y:607,t:1527264812659};\\\", \\\"{x:908,y:595,t:1527264812677};\\\", \\\"{x:883,y:581,t:1527264812694};\\\", \\\"{x:855,y:570,t:1527264812710};\\\", \\\"{x:850,y:567,t:1527264812727};\\\", \\\"{x:849,y:567,t:1527264812750};\\\", \\\"{x:848,y:567,t:1527264812760};\\\", \\\"{x:847,y:567,t:1527264812830};\\\", \\\"{x:847,y:568,t:1527264812846};\\\", \\\"{x:847,y:569,t:1527264812860};\\\", \\\"{x:845,y:569,t:1527264813158};\\\", \\\"{x:843,y:569,t:1527264813173};\\\", \\\"{x:841,y:569,t:1527264813190};\\\", \\\"{x:840,y:569,t:1527264813214};\\\", \\\"{x:838,y:569,t:1527264813422};\\\", \\\"{x:831,y:569,t:1527264813429};\\\", \\\"{x:820,y:573,t:1527264813445};\\\", \\\"{x:793,y:584,t:1527264813459};\\\", \\\"{x:736,y:597,t:1527264813477};\\\", \\\"{x:602,y:608,t:1527264813495};\\\", \\\"{x:499,y:612,t:1527264813510};\\\", \\\"{x:395,y:618,t:1527264813528};\\\", \\\"{x:307,y:627,t:1527264813544};\\\", \\\"{x:256,y:635,t:1527264813560};\\\", \\\"{x:217,y:640,t:1527264813577};\\\", \\\"{x:192,y:649,t:1527264813594};\\\", \\\"{x:176,y:656,t:1527264813610};\\\", \\\"{x:165,y:663,t:1527264813627};\\\", \\\"{x:162,y:665,t:1527264813644};\\\", \\\"{x:163,y:665,t:1527264813726};\\\", \\\"{x:170,y:665,t:1527264813743};\\\", \\\"{x:180,y:663,t:1527264813761};\\\", \\\"{x:197,y:657,t:1527264813776};\\\", \\\"{x:221,y:647,t:1527264813793};\\\", \\\"{x:253,y:633,t:1527264813812};\\\", \\\"{x:291,y:618,t:1527264813828};\\\", \\\"{x:317,y:607,t:1527264813843};\\\", \\\"{x:340,y:600,t:1527264813861};\\\", \\\"{x:358,y:593,t:1527264813878};\\\", \\\"{x:369,y:588,t:1527264813895};\\\", \\\"{x:376,y:584,t:1527264813912};\\\", \\\"{x:383,y:577,t:1527264813927};\\\", \\\"{x:389,y:568,t:1527264813944};\\\", \\\"{x:397,y:555,t:1527264813962};\\\", \\\"{x:403,y:549,t:1527264813977};\\\", \\\"{x:402,y:549,t:1527264814094};\\\", \\\"{x:397,y:549,t:1527264814110};\\\", \\\"{x:390,y:551,t:1527264814129};\\\", \\\"{x:376,y:551,t:1527264814143};\\\", \\\"{x:361,y:551,t:1527264814162};\\\", \\\"{x:343,y:551,t:1527264814178};\\\", \\\"{x:322,y:551,t:1527264814194};\\\", \\\"{x:304,y:550,t:1527264814212};\\\", \\\"{x:291,y:550,t:1527264814227};\\\", \\\"{x:274,y:550,t:1527264814244};\\\", \\\"{x:260,y:552,t:1527264814262};\\\", \\\"{x:241,y:558,t:1527264814278};\\\", \\\"{x:229,y:562,t:1527264814294};\\\", \\\"{x:220,y:567,t:1527264814311};\\\", \\\"{x:211,y:569,t:1527264814328};\\\", \\\"{x:201,y:574,t:1527264814345};\\\", \\\"{x:193,y:579,t:1527264814360};\\\", \\\"{x:187,y:585,t:1527264814378};\\\", \\\"{x:184,y:591,t:1527264814395};\\\", \\\"{x:181,y:599,t:1527264814411};\\\", \\\"{x:179,y:605,t:1527264814427};\\\", \\\"{x:179,y:611,t:1527264814443};\\\", \\\"{x:179,y:615,t:1527264814461};\\\", \\\"{x:179,y:618,t:1527264814477};\\\", \\\"{x:179,y:620,t:1527264814494};\\\", \\\"{x:179,y:621,t:1527264814510};\\\", \\\"{x:179,y:626,t:1527264814528};\\\", \\\"{x:179,y:629,t:1527264814544};\\\", \\\"{x:179,y:631,t:1527264814561};\\\", \\\"{x:179,y:632,t:1527264814577};\\\", \\\"{x:179,y:633,t:1527264814605};\\\", \\\"{x:177,y:634,t:1527264814613};\\\", \\\"{x:177,y:635,t:1527264814626};\\\", \\\"{x:175,y:637,t:1527264814645};\\\", \\\"{x:173,y:639,t:1527264814660};\\\", \\\"{x:173,y:641,t:1527264814678};\\\", \\\"{x:172,y:642,t:1527264814695};\\\", \\\"{x:171,y:643,t:1527264814710};\\\", \\\"{x:171,y:644,t:1527264814727};\\\", \\\"{x:170,y:645,t:1527264814745};\\\", \\\"{x:170,y:647,t:1527264814761};\\\", \\\"{x:170,y:648,t:1527264815157};\\\", \\\"{x:168,y:649,t:1527264815173};\\\", \\\"{x:171,y:649,t:1527264815263};\\\", \\\"{x:217,y:645,t:1527264815279};\\\", \\\"{x:309,y:628,t:1527264815296};\\\", \\\"{x:435,y:602,t:1527264815312};\\\", \\\"{x:574,y:574,t:1527264815328};\\\", \\\"{x:691,y:539,t:1527264815345};\\\", \\\"{x:800,y:517,t:1527264815362};\\\", \\\"{x:892,y:517,t:1527264815379};\\\", \\\"{x:950,y:517,t:1527264815395};\\\", \\\"{x:982,y:517,t:1527264815412};\\\", \\\"{x:999,y:520,t:1527264815429};\\\", \\\"{x:1013,y:522,t:1527264815445};\\\", \\\"{x:1040,y:532,t:1527264815462};\\\", \\\"{x:1074,y:542,t:1527264815479};\\\", \\\"{x:1135,y:559,t:1527264815495};\\\", \\\"{x:1210,y:579,t:1527264815512};\\\", \\\"{x:1285,y:601,t:1527264815529};\\\", \\\"{x:1329,y:609,t:1527264815545};\\\", \\\"{x:1341,y:609,t:1527264815562};\\\", \\\"{x:1343,y:606,t:1527264815894};\\\", \\\"{x:1343,y:598,t:1527264815902};\\\", \\\"{x:1343,y:591,t:1527264815913};\\\", \\\"{x:1343,y:572,t:1527264815930};\\\", \\\"{x:1338,y:551,t:1527264815946};\\\", \\\"{x:1334,y:535,t:1527264815963};\\\", \\\"{x:1333,y:524,t:1527264815980};\\\", \\\"{x:1330,y:510,t:1527264815997};\\\", \\\"{x:1329,y:502,t:1527264816012};\\\", \\\"{x:1329,y:499,t:1527264816029};\\\", \\\"{x:1328,y:497,t:1527264816046};\\\", \\\"{x:1326,y:495,t:1527264816070};\\\", \\\"{x:1325,y:495,t:1527264816086};\\\", \\\"{x:1324,y:495,t:1527264816096};\\\", \\\"{x:1321,y:494,t:1527264816112};\\\", \\\"{x:1319,y:493,t:1527264816130};\\\", \\\"{x:1317,y:493,t:1527264816162};\\\", \\\"{x:1316,y:493,t:1527264816189};\\\", \\\"{x:1314,y:493,t:1527264816246};\\\", \\\"{x:1309,y:499,t:1527264816263};\\\", \\\"{x:1307,y:514,t:1527264816280};\\\", \\\"{x:1304,y:531,t:1527264816297};\\\", \\\"{x:1304,y:545,t:1527264816313};\\\", \\\"{x:1304,y:560,t:1527264816329};\\\", \\\"{x:1310,y:576,t:1527264816347};\\\", \\\"{x:1315,y:597,t:1527264816363};\\\", \\\"{x:1320,y:614,t:1527264816379};\\\", \\\"{x:1325,y:630,t:1527264816397};\\\", \\\"{x:1326,y:640,t:1527264816414};\\\", \\\"{x:1327,y:650,t:1527264816429};\\\", \\\"{x:1327,y:656,t:1527264816445};\\\", \\\"{x:1330,y:660,t:1527264816462};\\\", \\\"{x:1331,y:668,t:1527264816479};\\\", \\\"{x:1334,y:675,t:1527264816496};\\\", \\\"{x:1338,y:681,t:1527264816513};\\\", \\\"{x:1339,y:690,t:1527264816528};\\\", \\\"{x:1339,y:697,t:1527264816546};\\\", \\\"{x:1339,y:704,t:1527264816563};\\\", \\\"{x:1339,y:710,t:1527264816580};\\\", \\\"{x:1338,y:714,t:1527264816595};\\\", \\\"{x:1336,y:720,t:1527264816613};\\\", \\\"{x:1334,y:723,t:1527264816629};\\\", \\\"{x:1333,y:724,t:1527264816646};\\\", \\\"{x:1332,y:726,t:1527264816662};\\\", \\\"{x:1331,y:727,t:1527264816679};\\\", \\\"{x:1330,y:727,t:1527264816709};\\\", \\\"{x:1329,y:727,t:1527264816725};\\\", \\\"{x:1328,y:727,t:1527264816750};\\\", \\\"{x:1327,y:728,t:1527264816847};\\\", \\\"{x:1319,y:726,t:1527264820894};\\\", \\\"{x:1303,y:723,t:1527264820902};\\\", \\\"{x:1278,y:715,t:1527264820917};\\\", \\\"{x:1208,y:693,t:1527264820933};\\\", \\\"{x:1066,y:650,t:1527264820950};\\\", \\\"{x:983,y:623,t:1527264820967};\\\", \\\"{x:934,y:606,t:1527264820983};\\\", \\\"{x:918,y:601,t:1527264820999};\\\", \\\"{x:916,y:601,t:1527264821016};\\\", \\\"{x:915,y:601,t:1527264821101};\\\", \\\"{x:914,y:601,t:1527264821117};\\\", \\\"{x:911,y:598,t:1527264822101};\\\", \\\"{x:895,y:595,t:1527264822111};\\\", \\\"{x:868,y:590,t:1527264822128};\\\", \\\"{x:772,y:577,t:1527264822151};\\\", \\\"{x:689,y:566,t:1527264822168};\\\", \\\"{x:603,y:554,t:1527264822184};\\\", \\\"{x:514,y:553,t:1527264822200};\\\", \\\"{x:413,y:547,t:1527264822217};\\\", \\\"{x:322,y:551,t:1527264822235};\\\", \\\"{x:258,y:560,t:1527264822250};\\\", \\\"{x:218,y:568,t:1527264822267};\\\", \\\"{x:196,y:577,t:1527264822284};\\\", \\\"{x:188,y:582,t:1527264822301};\\\", \\\"{x:188,y:584,t:1527264822325};\\\", \\\"{x:188,y:586,t:1527264822333};\\\", \\\"{x:190,y:588,t:1527264822351};\\\", \\\"{x:190,y:589,t:1527264822367};\\\", \\\"{x:191,y:590,t:1527264822383};\\\", \\\"{x:191,y:591,t:1527264822405};\\\", \\\"{x:191,y:592,t:1527264822437};\\\", \\\"{x:192,y:594,t:1527264822453};\\\", \\\"{x:192,y:596,t:1527264822478};\\\", \\\"{x:194,y:598,t:1527264822493};\\\", \\\"{x:194,y:599,t:1527264822509};\\\", \\\"{x:194,y:601,t:1527264822516};\\\", \\\"{x:195,y:603,t:1527264822534};\\\", \\\"{x:195,y:604,t:1527264822552};\\\", \\\"{x:195,y:606,t:1527264822568};\\\", \\\"{x:195,y:607,t:1527264822597};\\\", \\\"{x:195,y:608,t:1527264822605};\\\", \\\"{x:195,y:609,t:1527264822621};\\\", \\\"{x:195,y:610,t:1527264822637};\\\", \\\"{x:195,y:611,t:1527264822653};\\\", \\\"{x:194,y:611,t:1527264822669};\\\", \\\"{x:193,y:611,t:1527264822684};\\\", \\\"{x:187,y:611,t:1527264822702};\\\", \\\"{x:181,y:611,t:1527264822717};\\\", \\\"{x:175,y:611,t:1527264822734};\\\", \\\"{x:163,y:607,t:1527264822751};\\\", \\\"{x:154,y:601,t:1527264822769};\\\", \\\"{x:147,y:595,t:1527264822784};\\\", \\\"{x:146,y:592,t:1527264822801};\\\", \\\"{x:146,y:590,t:1527264822818};\\\", \\\"{x:151,y:587,t:1527264822835};\\\", \\\"{x:161,y:584,t:1527264822851};\\\", \\\"{x:171,y:582,t:1527264822869};\\\", \\\"{x:185,y:579,t:1527264822884};\\\", \\\"{x:212,y:572,t:1527264822902};\\\", \\\"{x:243,y:566,t:1527264822918};\\\", \\\"{x:277,y:564,t:1527264822935};\\\", \\\"{x:322,y:556,t:1527264822952};\\\", \\\"{x:363,y:546,t:1527264822969};\\\", \\\"{x:402,y:542,t:1527264822984};\\\", \\\"{x:435,y:533,t:1527264823001};\\\", \\\"{x:457,y:531,t:1527264823018};\\\", \\\"{x:475,y:526,t:1527264823034};\\\", \\\"{x:488,y:522,t:1527264823051};\\\", \\\"{x:501,y:519,t:1527264823069};\\\", \\\"{x:512,y:516,t:1527264823084};\\\", \\\"{x:533,y:510,t:1527264823100};\\\", \\\"{x:548,y:506,t:1527264823118};\\\", \\\"{x:567,y:500,t:1527264823135};\\\", \\\"{x:586,y:497,t:1527264823152};\\\", \\\"{x:603,y:495,t:1527264823168};\\\", \\\"{x:618,y:495,t:1527264823186};\\\", \\\"{x:626,y:495,t:1527264823202};\\\", \\\"{x:636,y:495,t:1527264823218};\\\", \\\"{x:650,y:499,t:1527264823235};\\\", \\\"{x:669,y:507,t:1527264823253};\\\", \\\"{x:692,y:517,t:1527264823269};\\\", \\\"{x:749,y:543,t:1527264823286};\\\", \\\"{x:782,y:556,t:1527264823302};\\\", \\\"{x:820,y:572,t:1527264823318};\\\", \\\"{x:855,y:585,t:1527264823335};\\\", \\\"{x:879,y:594,t:1527264823352};\\\", \\\"{x:896,y:600,t:1527264823369};\\\", \\\"{x:915,y:606,t:1527264823385};\\\", \\\"{x:928,y:610,t:1527264823401};\\\", \\\"{x:941,y:614,t:1527264823418};\\\", \\\"{x:945,y:615,t:1527264823435};\\\", \\\"{x:949,y:615,t:1527264823452};\\\", \\\"{x:951,y:615,t:1527264823468};\\\", \\\"{x:951,y:616,t:1527264823485};\\\", \\\"{x:952,y:616,t:1527264823501};\\\", \\\"{x:953,y:616,t:1527264823518};\\\", \\\"{x:954,y:615,t:1527264823535};\\\", \\\"{x:954,y:614,t:1527264823557};\\\", \\\"{x:950,y:612,t:1527264823573};\\\", \\\"{x:948,y:610,t:1527264823585};\\\", \\\"{x:943,y:608,t:1527264823602};\\\", \\\"{x:935,y:607,t:1527264823619};\\\", \\\"{x:927,y:607,t:1527264823635};\\\", \\\"{x:918,y:608,t:1527264823652};\\\", \\\"{x:908,y:609,t:1527264823668};\\\", \\\"{x:891,y:612,t:1527264823685};\\\", \\\"{x:880,y:613,t:1527264823701};\\\", \\\"{x:867,y:615,t:1527264823719};\\\", \\\"{x:858,y:617,t:1527264823735};\\\", \\\"{x:853,y:618,t:1527264823752};\\\", \\\"{x:850,y:618,t:1527264823768};\\\", \\\"{x:849,y:618,t:1527264823786};\\\", \\\"{x:849,y:619,t:1527264823802};\\\", \\\"{x:848,y:619,t:1527264823818};\\\", \\\"{x:847,y:619,t:1527264823835};\\\", \\\"{x:846,y:619,t:1527264826294};\\\", \\\"{x:845,y:619,t:1527264826343};\\\", \\\"{x:844,y:619,t:1527264826355};\\\", \\\"{x:842,y:619,t:1527264826371};\\\", \\\"{x:840,y:618,t:1527264826606};\\\", \\\"{x:819,y:618,t:1527264831903};\\\", \\\"{x:683,y:606,t:1527264831925};\\\", \\\"{x:572,y:588,t:1527264831942};\\\", \\\"{x:475,y:575,t:1527264831958};\\\", \\\"{x:399,y:564,t:1527264831975};\\\", \\\"{x:355,y:558,t:1527264831992};\\\", \\\"{x:333,y:558,t:1527264832008};\\\", \\\"{x:321,y:558,t:1527264832026};\\\", \\\"{x:307,y:559,t:1527264832041};\\\", \\\"{x:291,y:563,t:1527264832058};\\\", \\\"{x:276,y:570,t:1527264832075};\\\", \\\"{x:258,y:578,t:1527264832092};\\\", \\\"{x:227,y:597,t:1527264832110};\\\", \\\"{x:218,y:607,t:1527264832125};\\\", \\\"{x:213,y:618,t:1527264832141};\\\", \\\"{x:213,y:634,t:1527264832159};\\\", \\\"{x:216,y:651,t:1527264832176};\\\", \\\"{x:232,y:665,t:1527264832193};\\\", \\\"{x:252,y:678,t:1527264832208};\\\", \\\"{x:276,y:688,t:1527264832226};\\\", \\\"{x:296,y:695,t:1527264832243};\\\", \\\"{x:324,y:704,t:1527264832259};\\\", \\\"{x:348,y:709,t:1527264832276};\\\", \\\"{x:374,y:715,t:1527264832293};\\\", \\\"{x:406,y:718,t:1527264832309};\\\", \\\"{x:422,y:718,t:1527264832327};\\\", \\\"{x:432,y:718,t:1527264832343};\\\", \\\"{x:440,y:715,t:1527264832360};\\\", \\\"{x:445,y:712,t:1527264832377};\\\", \\\"{x:448,y:711,t:1527264832393};\\\", \\\"{x:450,y:711,t:1527264832410};\\\", \\\"{x:451,y:711,t:1527264832426};\\\", \\\"{x:454,y:711,t:1527264832444};\\\", \\\"{x:459,y:712,t:1527264832460};\\\", \\\"{x:470,y:714,t:1527264832477};\\\", \\\"{x:478,y:716,t:1527264832494};\\\", \\\"{x:483,y:718,t:1527264832509};\\\", \\\"{x:488,y:720,t:1527264832526};\\\", \\\"{x:491,y:721,t:1527264832542};\\\", \\\"{x:493,y:722,t:1527264832559};\\\", \\\"{x:494,y:723,t:1527264832588};\\\" ] }, { \\\"rt\\\": 13418, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 432863, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:724,t:1527264835234};\\\", \\\"{x:494,y:723,t:1527264838722};\\\", \\\"{x:497,y:718,t:1527264838730};\\\", \\\"{x:504,y:713,t:1527264838739};\\\", \\\"{x:524,y:700,t:1527264838756};\\\", \\\"{x:540,y:689,t:1527264838767};\\\", \\\"{x:593,y:648,t:1527264838784};\\\", \\\"{x:637,y:611,t:1527264838802};\\\", \\\"{x:692,y:561,t:1527264838818};\\\", \\\"{x:760,y:510,t:1527264838834};\\\", \\\"{x:848,y:456,t:1527264838851};\\\", \\\"{x:919,y:415,t:1527264838867};\\\", \\\"{x:992,y:378,t:1527264838885};\\\", \\\"{x:1041,y:357,t:1527264838901};\\\", \\\"{x:1065,y:348,t:1527264838917};\\\", \\\"{x:1076,y:340,t:1527264838935};\\\", \\\"{x:1078,y:338,t:1527264838951};\\\", \\\"{x:1077,y:339,t:1527264839082};\\\", \\\"{x:1075,y:341,t:1527264839089};\\\", \\\"{x:1074,y:344,t:1527264839101};\\\", \\\"{x:1070,y:354,t:1527264839117};\\\", \\\"{x:1067,y:360,t:1527264839134};\\\", \\\"{x:1058,y:374,t:1527264839151};\\\", \\\"{x:1048,y:388,t:1527264839167};\\\", \\\"{x:1035,y:405,t:1527264839184};\\\", \\\"{x:1018,y:429,t:1527264839201};\\\", \\\"{x:1007,y:443,t:1527264839217};\\\", \\\"{x:998,y:458,t:1527264839234};\\\", \\\"{x:986,y:476,t:1527264839250};\\\", \\\"{x:970,y:497,t:1527264839268};\\\", \\\"{x:955,y:518,t:1527264839284};\\\", \\\"{x:936,y:535,t:1527264839301};\\\", \\\"{x:918,y:548,t:1527264839316};\\\", \\\"{x:917,y:549,t:1527264839334};\\\", \\\"{x:916,y:549,t:1527264839351};\\\", \\\"{x:915,y:549,t:1527264839368};\\\", \\\"{x:915,y:548,t:1527264839953};\\\", \\\"{x:913,y:548,t:1527264839977};\\\", \\\"{x:911,y:548,t:1527264839985};\\\", \\\"{x:878,y:557,t:1527264840004};\\\", \\\"{x:839,y:557,t:1527264840018};\\\", \\\"{x:804,y:557,t:1527264840036};\\\", \\\"{x:766,y:557,t:1527264840051};\\\", \\\"{x:728,y:555,t:1527264840069};\\\", \\\"{x:692,y:551,t:1527264840086};\\\", \\\"{x:661,y:546,t:1527264840103};\\\", \\\"{x:631,y:542,t:1527264840119};\\\", \\\"{x:607,y:535,t:1527264840136};\\\", \\\"{x:577,y:525,t:1527264840152};\\\", \\\"{x:568,y:521,t:1527264840169};\\\", \\\"{x:566,y:519,t:1527264840186};\\\", \\\"{x:564,y:517,t:1527264840202};\\\", \\\"{x:564,y:515,t:1527264840248};\\\", \\\"{x:564,y:514,t:1527264840257};\\\", \\\"{x:564,y:511,t:1527264840268};\\\", \\\"{x:569,y:507,t:1527264840286};\\\", \\\"{x:576,y:501,t:1527264840302};\\\", \\\"{x:580,y:498,t:1527264840319};\\\", \\\"{x:585,y:496,t:1527264840335};\\\", \\\"{x:591,y:494,t:1527264840352};\\\", \\\"{x:597,y:491,t:1527264840369};\\\", \\\"{x:600,y:489,t:1527264840385};\\\", \\\"{x:602,y:489,t:1527264840786};\\\", \\\"{x:606,y:492,t:1527264840802};\\\", \\\"{x:608,y:497,t:1527264840819};\\\", \\\"{x:616,y:504,t:1527264840837};\\\", \\\"{x:620,y:513,t:1527264840852};\\\", \\\"{x:624,y:518,t:1527264840870};\\\", \\\"{x:626,y:522,t:1527264840887};\\\", \\\"{x:628,y:523,t:1527264840902};\\\", \\\"{x:627,y:524,t:1527264841090};\\\", \\\"{x:624,y:524,t:1527264841103};\\\", \\\"{x:619,y:524,t:1527264841120};\\\", \\\"{x:617,y:524,t:1527264841137};\\\", \\\"{x:616,y:523,t:1527264841185};\\\", \\\"{x:616,y:521,t:1527264841193};\\\", \\\"{x:618,y:520,t:1527264841203};\\\", \\\"{x:620,y:515,t:1527264841221};\\\", \\\"{x:621,y:513,t:1527264841237};\\\", \\\"{x:621,y:512,t:1527264841253};\\\", \\\"{x:622,y:510,t:1527264841270};\\\", \\\"{x:624,y:509,t:1527264842153};\\\", \\\"{x:642,y:509,t:1527264842171};\\\", \\\"{x:668,y:512,t:1527264842188};\\\", \\\"{x:699,y:513,t:1527264842205};\\\", \\\"{x:736,y:513,t:1527264842221};\\\", \\\"{x:767,y:522,t:1527264842237};\\\", \\\"{x:782,y:525,t:1527264842253};\\\", \\\"{x:794,y:530,t:1527264842270};\\\", \\\"{x:799,y:532,t:1527264842288};\\\", \\\"{x:799,y:533,t:1527264842320};\\\", \\\"{x:799,y:535,t:1527264842377};\\\", \\\"{x:799,y:536,t:1527264842481};\\\", \\\"{x:801,y:536,t:1527264842497};\\\", \\\"{x:802,y:536,t:1527264842505};\\\", \\\"{x:808,y:539,t:1527264842520};\\\", \\\"{x:813,y:540,t:1527264842538};\\\", \\\"{x:821,y:542,t:1527264842553};\\\", \\\"{x:822,y:542,t:1527264842571};\\\", \\\"{x:824,y:542,t:1527264843227};\\\", \\\"{x:825,y:542,t:1527264843237};\\\", \\\"{x:827,y:542,t:1527264843255};\\\", \\\"{x:829,y:542,t:1527264843272};\\\", \\\"{x:832,y:542,t:1527264843288};\\\", \\\"{x:837,y:541,t:1527264843305};\\\", \\\"{x:837,y:540,t:1527264844601};\\\", \\\"{x:836,y:539,t:1527264844609};\\\", \\\"{x:835,y:539,t:1527264844622};\\\", \\\"{x:831,y:539,t:1527264844639};\\\", \\\"{x:829,y:539,t:1527264844656};\\\", \\\"{x:828,y:539,t:1527264844672};\\\", \\\"{x:827,y:539,t:1527264844713};\\\", \\\"{x:826,y:539,t:1527264844746};\\\", \\\"{x:825,y:539,t:1527264844761};\\\", \\\"{x:824,y:539,t:1527264844866};\\\", \\\"{x:823,y:540,t:1527264844899};\\\", \\\"{x:822,y:540,t:1527264844912};\\\", \\\"{x:821,y:540,t:1527264844923};\\\", \\\"{x:820,y:541,t:1527264844960};\\\", \\\"{x:819,y:541,t:1527264844973};\\\", \\\"{x:819,y:542,t:1527264845282};\\\", \\\"{x:818,y:542,t:1527264845290};\\\", \\\"{x:818,y:543,t:1527264845306};\\\", \\\"{x:817,y:543,t:1527264845377};\\\", \\\"{x:817,y:544,t:1527264845672};\\\", \\\"{x:816,y:544,t:1527264845689};\\\", \\\"{x:813,y:548,t:1527264846897};\\\", \\\"{x:812,y:552,t:1527264846907};\\\", \\\"{x:803,y:565,t:1527264846925};\\\", \\\"{x:792,y:588,t:1527264846941};\\\", \\\"{x:771,y:628,t:1527264846958};\\\", \\\"{x:735,y:691,t:1527264846974};\\\", \\\"{x:694,y:764,t:1527264846990};\\\", \\\"{x:658,y:837,t:1527264847008};\\\", \\\"{x:636,y:887,t:1527264847024};\\\", \\\"{x:614,y:922,t:1527264847041};\\\", \\\"{x:604,y:935,t:1527264847058};\\\", \\\"{x:591,y:945,t:1527264847074};\\\", \\\"{x:583,y:951,t:1527264847091};\\\", \\\"{x:577,y:954,t:1527264847108};\\\", \\\"{x:573,y:954,t:1527264847124};\\\", \\\"{x:566,y:954,t:1527264847141};\\\", \\\"{x:557,y:954,t:1527264847158};\\\", \\\"{x:548,y:952,t:1527264847175};\\\", \\\"{x:540,y:948,t:1527264847191};\\\", \\\"{x:531,y:940,t:1527264847208};\\\", \\\"{x:527,y:922,t:1527264847225};\\\", \\\"{x:527,y:904,t:1527264847241};\\\", \\\"{x:529,y:876,t:1527264847258};\\\", \\\"{x:539,y:850,t:1527264847275};\\\", \\\"{x:551,y:823,t:1527264847291};\\\", \\\"{x:563,y:793,t:1527264847308};\\\", \\\"{x:572,y:777,t:1527264847324};\\\", \\\"{x:576,y:769,t:1527264847341};\\\", \\\"{x:576,y:766,t:1527264847358};\\\", \\\"{x:576,y:762,t:1527264847375};\\\", \\\"{x:576,y:759,t:1527264847391};\\\", \\\"{x:576,y:756,t:1527264847408};\\\", \\\"{x:576,y:754,t:1527264847425};\\\", \\\"{x:576,y:752,t:1527264847553};\\\", \\\"{x:575,y:750,t:1527264847561};\\\", \\\"{x:574,y:749,t:1527264847575};\\\", \\\"{x:569,y:747,t:1527264847593};\\\", \\\"{x:561,y:746,t:1527264847609};\\\", \\\"{x:558,y:746,t:1527264847625};\\\", \\\"{x:555,y:744,t:1527264847642};\\\" ] }, { \\\"rt\\\": 35343, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 469516, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -B -B -B -F -F -F -F -B -B -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:745,t:1527264852322};\\\", \\\"{x:559,y:745,t:1527264852340};\\\", \\\"{x:561,y:745,t:1527264853057};\\\", \\\"{x:563,y:745,t:1527264853081};\\\", \\\"{x:565,y:743,t:1527264853090};\\\", \\\"{x:567,y:742,t:1527264853104};\\\", \\\"{x:568,y:742,t:1527264853119};\\\", \\\"{x:571,y:740,t:1527264853129};\\\", \\\"{x:573,y:740,t:1527264853146};\\\", \\\"{x:574,y:739,t:1527264853162};\\\", \\\"{x:578,y:737,t:1527264853179};\\\", \\\"{x:583,y:735,t:1527264853196};\\\", \\\"{x:591,y:730,t:1527264853212};\\\", \\\"{x:609,y:720,t:1527264853229};\\\", \\\"{x:639,y:708,t:1527264853246};\\\", \\\"{x:674,y:693,t:1527264853263};\\\", \\\"{x:721,y:675,t:1527264853279};\\\", \\\"{x:811,y:648,t:1527264853296};\\\", \\\"{x:885,y:629,t:1527264853313};\\\", \\\"{x:985,y:616,t:1527264853330};\\\", \\\"{x:1079,y:602,t:1527264853346};\\\", \\\"{x:1179,y:600,t:1527264853363};\\\", \\\"{x:1279,y:600,t:1527264853379};\\\", \\\"{x:1340,y:606,t:1527264853396};\\\", \\\"{x:1389,y:611,t:1527264853413};\\\", \\\"{x:1429,y:612,t:1527264853430};\\\", \\\"{x:1458,y:612,t:1527264853446};\\\", \\\"{x:1482,y:612,t:1527264853464};\\\", \\\"{x:1501,y:612,t:1527264853480};\\\", \\\"{x:1530,y:612,t:1527264853497};\\\", \\\"{x:1551,y:612,t:1527264853513};\\\", \\\"{x:1571,y:612,t:1527264853529};\\\", \\\"{x:1586,y:613,t:1527264853547};\\\", \\\"{x:1592,y:615,t:1527264853564};\\\", \\\"{x:1595,y:618,t:1527264853580};\\\", \\\"{x:1595,y:623,t:1527264853596};\\\", \\\"{x:1593,y:630,t:1527264853614};\\\", \\\"{x:1588,y:640,t:1527264853630};\\\", \\\"{x:1578,y:652,t:1527264853647};\\\", \\\"{x:1570,y:661,t:1527264853663};\\\", \\\"{x:1564,y:663,t:1527264853680};\\\", \\\"{x:1561,y:665,t:1527264853697};\\\", \\\"{x:1560,y:665,t:1527264853713};\\\", \\\"{x:1561,y:665,t:1527264854105};\\\", \\\"{x:1562,y:664,t:1527264854114};\\\", \\\"{x:1564,y:663,t:1527264854131};\\\", \\\"{x:1566,y:662,t:1527264854147};\\\", \\\"{x:1568,y:661,t:1527264854163};\\\", \\\"{x:1570,y:659,t:1527264854180};\\\", \\\"{x:1573,y:658,t:1527264854198};\\\", \\\"{x:1574,y:657,t:1527264854214};\\\", \\\"{x:1575,y:656,t:1527264854231};\\\", \\\"{x:1575,y:655,t:1527264854273};\\\", \\\"{x:1576,y:654,t:1527264854281};\\\", \\\"{x:1577,y:653,t:1527264854298};\\\", \\\"{x:1578,y:653,t:1527264854313};\\\", \\\"{x:1578,y:652,t:1527264854338};\\\", \\\"{x:1578,y:651,t:1527264854348};\\\", \\\"{x:1578,y:650,t:1527264854369};\\\", \\\"{x:1577,y:649,t:1527264854380};\\\", \\\"{x:1574,y:648,t:1527264854398};\\\", \\\"{x:1566,y:647,t:1527264854414};\\\", \\\"{x:1547,y:647,t:1527264854431};\\\", \\\"{x:1530,y:647,t:1527264854448};\\\", \\\"{x:1507,y:647,t:1527264854464};\\\", \\\"{x:1481,y:647,t:1527264854481};\\\", \\\"{x:1451,y:647,t:1527264854497};\\\", \\\"{x:1442,y:647,t:1527264854515};\\\", \\\"{x:1436,y:647,t:1527264854530};\\\", \\\"{x:1435,y:647,t:1527264854698};\\\", \\\"{x:1433,y:647,t:1527264854721};\\\", \\\"{x:1432,y:647,t:1527264854745};\\\", \\\"{x:1431,y:647,t:1527264854762};\\\", \\\"{x:1430,y:647,t:1527264854769};\\\", \\\"{x:1430,y:646,t:1527264854842};\\\", \\\"{x:1431,y:646,t:1527264854881};\\\", \\\"{x:1432,y:645,t:1527264854898};\\\", \\\"{x:1435,y:644,t:1527264854914};\\\", \\\"{x:1435,y:643,t:1527264854931};\\\", \\\"{x:1436,y:643,t:1527264854948};\\\", \\\"{x:1439,y:641,t:1527264854965};\\\", \\\"{x:1441,y:640,t:1527264854985};\\\", \\\"{x:1442,y:639,t:1527264854998};\\\", \\\"{x:1443,y:639,t:1527264855016};\\\", \\\"{x:1444,y:639,t:1527264855033};\\\", \\\"{x:1444,y:638,t:1527264855114};\\\", \\\"{x:1444,y:637,t:1527264855137};\\\", \\\"{x:1442,y:637,t:1527264855170};\\\", \\\"{x:1436,y:638,t:1527264855182};\\\", \\\"{x:1424,y:646,t:1527264855198};\\\", \\\"{x:1405,y:654,t:1527264855215};\\\", \\\"{x:1388,y:660,t:1527264855232};\\\", \\\"{x:1375,y:664,t:1527264855248};\\\", \\\"{x:1370,y:667,t:1527264855265};\\\", \\\"{x:1362,y:670,t:1527264855282};\\\", \\\"{x:1359,y:674,t:1527264855299};\\\", \\\"{x:1354,y:683,t:1527264855314};\\\", \\\"{x:1348,y:698,t:1527264855334};\\\", \\\"{x:1344,y:708,t:1527264855348};\\\", \\\"{x:1344,y:713,t:1527264855364};\\\", \\\"{x:1345,y:717,t:1527264855382};\\\", \\\"{x:1349,y:718,t:1527264855398};\\\", \\\"{x:1350,y:718,t:1527264855414};\\\", \\\"{x:1351,y:718,t:1527264855431};\\\", \\\"{x:1352,y:718,t:1527264855465};\\\", \\\"{x:1352,y:717,t:1527264855520};\\\", \\\"{x:1352,y:716,t:1527264855531};\\\", \\\"{x:1352,y:713,t:1527264855548};\\\", \\\"{x:1352,y:709,t:1527264855564};\\\", \\\"{x:1352,y:705,t:1527264855581};\\\", \\\"{x:1352,y:701,t:1527264855598};\\\", \\\"{x:1351,y:697,t:1527264855614};\\\", \\\"{x:1351,y:693,t:1527264855631};\\\", \\\"{x:1351,y:692,t:1527264855648};\\\", \\\"{x:1351,y:690,t:1527264855665};\\\", \\\"{x:1350,y:689,t:1527264855681};\\\", \\\"{x:1350,y:688,t:1527264855698};\\\", \\\"{x:1348,y:687,t:1527264855714};\\\", \\\"{x:1347,y:687,t:1527264855960};\\\", \\\"{x:1347,y:688,t:1527264855992};\\\", \\\"{x:1347,y:689,t:1527264856618};\\\", \\\"{x:1347,y:690,t:1527264856632};\\\", \\\"{x:1347,y:691,t:1527264857537};\\\", \\\"{x:1346,y:696,t:1527264866763};\\\", \\\"{x:1344,y:701,t:1527264866775};\\\", \\\"{x:1344,y:705,t:1527264866791};\\\", \\\"{x:1343,y:712,t:1527264866807};\\\", \\\"{x:1343,y:717,t:1527264866824};\\\", \\\"{x:1342,y:723,t:1527264866841};\\\", \\\"{x:1342,y:728,t:1527264866858};\\\", \\\"{x:1342,y:731,t:1527264866875};\\\", \\\"{x:1342,y:734,t:1527264866891};\\\", \\\"{x:1342,y:735,t:1527264866906};\\\", \\\"{x:1340,y:737,t:1527264866924};\\\", \\\"{x:1340,y:738,t:1527264866941};\\\", \\\"{x:1340,y:739,t:1527264866976};\\\", \\\"{x:1340,y:740,t:1527264866991};\\\", \\\"{x:1340,y:741,t:1527264867007};\\\", \\\"{x:1340,y:742,t:1527264867024};\\\", \\\"{x:1340,y:745,t:1527264867040};\\\", \\\"{x:1340,y:749,t:1527264867057};\\\", \\\"{x:1340,y:751,t:1527264867074};\\\", \\\"{x:1340,y:754,t:1527264867091};\\\", \\\"{x:1341,y:757,t:1527264867107};\\\", \\\"{x:1343,y:762,t:1527264867124};\\\", \\\"{x:1343,y:764,t:1527264867140};\\\", \\\"{x:1344,y:765,t:1527264867157};\\\", \\\"{x:1344,y:767,t:1527264867174};\\\", \\\"{x:1345,y:767,t:1527264867192};\\\", \\\"{x:1345,y:768,t:1527264867208};\\\", \\\"{x:1345,y:770,t:1527264867225};\\\", \\\"{x:1346,y:771,t:1527264867241};\\\", \\\"{x:1346,y:773,t:1527264867273};\\\", \\\"{x:1347,y:773,t:1527264867897};\\\", \\\"{x:1347,y:772,t:1527264867954};\\\", \\\"{x:1347,y:771,t:1527264867969};\\\", \\\"{x:1347,y:770,t:1527264868001};\\\", \\\"{x:1347,y:769,t:1527264868017};\\\", \\\"{x:1347,y:768,t:1527264868026};\\\", \\\"{x:1347,y:766,t:1527264868058};\\\", \\\"{x:1347,y:765,t:1527264868075};\\\", \\\"{x:1347,y:764,t:1527264868104};\\\", \\\"{x:1347,y:763,t:1527264868113};\\\", \\\"{x:1347,y:762,t:1527264868126};\\\", \\\"{x:1347,y:761,t:1527264868161};\\\", \\\"{x:1347,y:760,t:1527264868177};\\\", \\\"{x:1347,y:759,t:1527264868193};\\\", \\\"{x:1346,y:759,t:1527264868208};\\\", \\\"{x:1346,y:758,t:1527264868224};\\\", \\\"{x:1345,y:757,t:1527264868244};\\\", \\\"{x:1344,y:756,t:1527264868281};\\\", \\\"{x:1344,y:755,t:1527264868353};\\\", \\\"{x:1344,y:754,t:1527264868360};\\\", \\\"{x:1344,y:753,t:1527264868376};\\\", \\\"{x:1344,y:747,t:1527264868393};\\\", \\\"{x:1344,y:745,t:1527264868408};\\\", \\\"{x:1344,y:738,t:1527264868426};\\\", \\\"{x:1344,y:734,t:1527264868443};\\\", \\\"{x:1344,y:727,t:1527264868458};\\\", \\\"{x:1344,y:721,t:1527264868475};\\\", \\\"{x:1344,y:714,t:1527264868493};\\\", \\\"{x:1344,y:711,t:1527264868508};\\\", \\\"{x:1343,y:705,t:1527264868525};\\\", \\\"{x:1343,y:699,t:1527264868543};\\\", \\\"{x:1342,y:694,t:1527264868560};\\\", \\\"{x:1342,y:691,t:1527264868575};\\\", \\\"{x:1342,y:687,t:1527264868592};\\\", \\\"{x:1342,y:685,t:1527264868608};\\\", \\\"{x:1342,y:684,t:1527264868625};\\\", \\\"{x:1342,y:683,t:1527264868643};\\\", \\\"{x:1343,y:683,t:1527264869096};\\\", \\\"{x:1344,y:684,t:1527264869112};\\\", \\\"{x:1344,y:685,t:1527264869126};\\\", \\\"{x:1344,y:686,t:1527264869144};\\\", \\\"{x:1344,y:687,t:1527264869159};\\\", \\\"{x:1344,y:688,t:1527264869176};\\\", \\\"{x:1346,y:691,t:1527264869192};\\\", \\\"{x:1346,y:695,t:1527264869209};\\\", \\\"{x:1346,y:696,t:1527264869225};\\\", \\\"{x:1346,y:698,t:1527264869242};\\\", \\\"{x:1346,y:699,t:1527264869259};\\\", \\\"{x:1346,y:702,t:1527264869276};\\\", \\\"{x:1345,y:704,t:1527264869329};\\\", \\\"{x:1346,y:704,t:1527264869545};\\\", \\\"{x:1347,y:704,t:1527264869570};\\\", \\\"{x:1347,y:703,t:1527264869593};\\\", \\\"{x:1348,y:702,t:1527264869626};\\\", \\\"{x:1349,y:702,t:1527264872842};\\\", \\\"{x:1352,y:701,t:1527264872850};\\\", \\\"{x:1353,y:700,t:1527264872880};\\\", \\\"{x:1354,y:699,t:1527264872992};\\\", \\\"{x:1354,y:701,t:1527264873458};\\\", \\\"{x:1354,y:702,t:1527264873489};\\\", \\\"{x:1354,y:704,t:1527264873505};\\\", \\\"{x:1354,y:705,t:1527264873529};\\\", \\\"{x:1354,y:708,t:1527264873546};\\\", \\\"{x:1354,y:712,t:1527264873563};\\\", \\\"{x:1354,y:716,t:1527264873580};\\\", \\\"{x:1352,y:721,t:1527264873597};\\\", \\\"{x:1352,y:726,t:1527264873613};\\\", \\\"{x:1352,y:730,t:1527264873629};\\\", \\\"{x:1352,y:735,t:1527264873646};\\\", \\\"{x:1352,y:738,t:1527264873662};\\\", \\\"{x:1352,y:742,t:1527264873679};\\\", \\\"{x:1351,y:747,t:1527264873697};\\\", \\\"{x:1351,y:748,t:1527264873713};\\\", \\\"{x:1350,y:749,t:1527264874210};\\\", \\\"{x:1349,y:749,t:1527264874442};\\\", \\\"{x:1348,y:749,t:1527264874449};\\\", \\\"{x:1347,y:748,t:1527264874465};\\\", \\\"{x:1347,y:747,t:1527264874488};\\\", \\\"{x:1347,y:745,t:1527264874497};\\\", \\\"{x:1347,y:744,t:1527264874513};\\\", \\\"{x:1346,y:742,t:1527264874530};\\\", \\\"{x:1346,y:739,t:1527264874546};\\\", \\\"{x:1346,y:738,t:1527264874563};\\\", \\\"{x:1345,y:736,t:1527264874580};\\\", \\\"{x:1345,y:734,t:1527264874596};\\\", \\\"{x:1345,y:731,t:1527264874613};\\\", \\\"{x:1345,y:725,t:1527264874630};\\\", \\\"{x:1344,y:720,t:1527264874646};\\\", \\\"{x:1342,y:715,t:1527264874663};\\\", \\\"{x:1341,y:710,t:1527264874680};\\\", \\\"{x:1341,y:707,t:1527264874697};\\\", \\\"{x:1341,y:702,t:1527264874714};\\\", \\\"{x:1340,y:694,t:1527264874731};\\\", \\\"{x:1338,y:689,t:1527264874747};\\\", \\\"{x:1338,y:686,t:1527264874763};\\\", \\\"{x:1337,y:684,t:1527264874780};\\\", \\\"{x:1337,y:686,t:1527264874913};\\\", \\\"{x:1336,y:694,t:1527264874931};\\\", \\\"{x:1336,y:700,t:1527264874948};\\\", \\\"{x:1334,y:709,t:1527264874964};\\\", \\\"{x:1334,y:717,t:1527264874980};\\\", \\\"{x:1334,y:723,t:1527264874998};\\\", \\\"{x:1334,y:728,t:1527264875014};\\\", \\\"{x:1334,y:730,t:1527264875031};\\\", \\\"{x:1334,y:735,t:1527264875048};\\\", \\\"{x:1334,y:738,t:1527264875064};\\\", \\\"{x:1335,y:742,t:1527264875080};\\\", \\\"{x:1335,y:745,t:1527264875097};\\\", \\\"{x:1337,y:748,t:1527264875114};\\\", \\\"{x:1337,y:749,t:1527264875137};\\\", \\\"{x:1338,y:750,t:1527264875148};\\\", \\\"{x:1339,y:751,t:1527264875163};\\\", \\\"{x:1340,y:755,t:1527264875181};\\\", \\\"{x:1341,y:756,t:1527264875198};\\\", \\\"{x:1341,y:757,t:1527264875214};\\\", \\\"{x:1342,y:758,t:1527264875230};\\\", \\\"{x:1343,y:760,t:1527264875248};\\\", \\\"{x:1344,y:762,t:1527264875264};\\\", \\\"{x:1346,y:764,t:1527264875281};\\\", \\\"{x:1348,y:767,t:1527264875297};\\\", \\\"{x:1350,y:769,t:1527264875316};\\\", \\\"{x:1350,y:770,t:1527264875337};\\\", \\\"{x:1350,y:769,t:1527264876201};\\\", \\\"{x:1350,y:768,t:1527264876215};\\\", \\\"{x:1350,y:767,t:1527264876232};\\\", \\\"{x:1350,y:765,t:1527264876248};\\\", \\\"{x:1350,y:764,t:1527264876272};\\\", \\\"{x:1350,y:763,t:1527264876281};\\\", \\\"{x:1350,y:762,t:1527264876299};\\\", \\\"{x:1350,y:761,t:1527264876315};\\\", \\\"{x:1350,y:759,t:1527264876331};\\\", \\\"{x:1350,y:758,t:1527264876377};\\\", \\\"{x:1350,y:757,t:1527264876394};\\\", \\\"{x:1351,y:756,t:1527264876424};\\\", \\\"{x:1351,y:755,t:1527264877617};\\\", \\\"{x:1350,y:755,t:1527264877833};\\\", \\\"{x:1350,y:756,t:1527264877969};\\\", \\\"{x:1350,y:755,t:1527264880257};\\\", \\\"{x:1349,y:751,t:1527264880268};\\\", \\\"{x:1346,y:737,t:1527264880285};\\\", \\\"{x:1344,y:724,t:1527264880302};\\\", \\\"{x:1342,y:714,t:1527264880318};\\\", \\\"{x:1342,y:709,t:1527264880335};\\\", \\\"{x:1342,y:707,t:1527264880352};\\\", \\\"{x:1342,y:706,t:1527264880369};\\\", \\\"{x:1342,y:705,t:1527264880394};\\\", \\\"{x:1342,y:704,t:1527264880466};\\\", \\\"{x:1343,y:704,t:1527264880513};\\\", \\\"{x:1343,y:703,t:1527264880537};\\\", \\\"{x:1344,y:703,t:1527264880552};\\\", \\\"{x:1344,y:704,t:1527264880641};\\\", \\\"{x:1344,y:714,t:1527264880653};\\\", \\\"{x:1345,y:744,t:1527264880669};\\\", \\\"{x:1352,y:786,t:1527264880686};\\\", \\\"{x:1361,y:815,t:1527264880702};\\\", \\\"{x:1365,y:833,t:1527264880719};\\\", \\\"{x:1369,y:845,t:1527264880735};\\\", \\\"{x:1369,y:849,t:1527264880752};\\\", \\\"{x:1369,y:851,t:1527264880769};\\\", \\\"{x:1369,y:852,t:1527264880786};\\\", \\\"{x:1368,y:852,t:1527264880809};\\\", \\\"{x:1365,y:852,t:1527264880819};\\\", \\\"{x:1364,y:849,t:1527264880835};\\\", \\\"{x:1360,y:842,t:1527264880852};\\\", \\\"{x:1357,y:834,t:1527264880869};\\\", \\\"{x:1353,y:826,t:1527264880885};\\\", \\\"{x:1348,y:820,t:1527264880901};\\\", \\\"{x:1346,y:820,t:1527264880918};\\\", \\\"{x:1345,y:813,t:1527264880934};\\\", \\\"{x:1333,y:806,t:1527264881202};\\\", \\\"{x:1253,y:767,t:1527264881219};\\\", \\\"{x:1146,y:726,t:1527264881236};\\\", \\\"{x:1023,y:679,t:1527264881252};\\\", \\\"{x:896,y:646,t:1527264881269};\\\", \\\"{x:784,y:623,t:1527264881287};\\\", \\\"{x:686,y:605,t:1527264881301};\\\", \\\"{x:611,y:597,t:1527264881319};\\\", \\\"{x:574,y:595,t:1527264881327};\\\", \\\"{x:552,y:595,t:1527264881344};\\\", \\\"{x:541,y:597,t:1527264881361};\\\", \\\"{x:533,y:601,t:1527264881378};\\\", \\\"{x:526,y:605,t:1527264881394};\\\", \\\"{x:505,y:617,t:1527264881419};\\\", \\\"{x:480,y:625,t:1527264881436};\\\", \\\"{x:451,y:629,t:1527264881453};\\\", \\\"{x:424,y:629,t:1527264881469};\\\", \\\"{x:394,y:625,t:1527264881486};\\\", \\\"{x:363,y:615,t:1527264881503};\\\", \\\"{x:329,y:605,t:1527264881520};\\\", \\\"{x:291,y:593,t:1527264881536};\\\", \\\"{x:263,y:579,t:1527264881552};\\\", \\\"{x:244,y:572,t:1527264881569};\\\", \\\"{x:221,y:563,t:1527264881585};\\\", \\\"{x:199,y:556,t:1527264881603};\\\", \\\"{x:181,y:549,t:1527264881621};\\\", \\\"{x:165,y:545,t:1527264881636};\\\", \\\"{x:156,y:542,t:1527264881653};\\\", \\\"{x:153,y:542,t:1527264881669};\\\", \\\"{x:152,y:541,t:1527264881729};\\\", \\\"{x:153,y:540,t:1527264882048};\\\", \\\"{x:154,y:539,t:1527264882056};\\\", \\\"{x:156,y:537,t:1527264882069};\\\", \\\"{x:158,y:536,t:1527264882086};\\\", \\\"{x:161,y:536,t:1527264882102};\\\", \\\"{x:163,y:534,t:1527264882119};\\\", \\\"{x:164,y:534,t:1527264882136};\\\", \\\"{x:166,y:534,t:1527264882337};\\\", \\\"{x:176,y:534,t:1527264882353};\\\", \\\"{x:194,y:538,t:1527264882371};\\\", \\\"{x:224,y:546,t:1527264882387};\\\", \\\"{x:263,y:550,t:1527264882403};\\\", \\\"{x:295,y:555,t:1527264882419};\\\", \\\"{x:343,y:559,t:1527264882437};\\\", \\\"{x:380,y:559,t:1527264882454};\\\", \\\"{x:407,y:559,t:1527264882470};\\\", \\\"{x:431,y:559,t:1527264882487};\\\", \\\"{x:445,y:559,t:1527264882503};\\\", \\\"{x:452,y:559,t:1527264882519};\\\", \\\"{x:453,y:559,t:1527264882536};\\\", \\\"{x:454,y:559,t:1527264882600};\\\", \\\"{x:455,y:559,t:1527264882608};\\\", \\\"{x:456,y:559,t:1527264882619};\\\", \\\"{x:464,y:559,t:1527264882637};\\\", \\\"{x:473,y:559,t:1527264882653};\\\", \\\"{x:486,y:559,t:1527264882670};\\\", \\\"{x:496,y:558,t:1527264882687};\\\", \\\"{x:506,y:556,t:1527264882704};\\\", \\\"{x:515,y:552,t:1527264882721};\\\", \\\"{x:528,y:544,t:1527264882736};\\\", \\\"{x:538,y:539,t:1527264882754};\\\", \\\"{x:544,y:535,t:1527264882770};\\\", \\\"{x:549,y:534,t:1527264882787};\\\", \\\"{x:550,y:532,t:1527264882803};\\\", \\\"{x:551,y:532,t:1527264882820};\\\", \\\"{x:552,y:531,t:1527264882838};\\\", \\\"{x:555,y:530,t:1527264882854};\\\", \\\"{x:559,y:527,t:1527264882870};\\\", \\\"{x:565,y:524,t:1527264882888};\\\", \\\"{x:575,y:515,t:1527264882905};\\\", \\\"{x:578,y:511,t:1527264882920};\\\", \\\"{x:579,y:510,t:1527264882936};\\\", \\\"{x:581,y:508,t:1527264882954};\\\", \\\"{x:583,y:507,t:1527264882976};\\\", \\\"{x:585,y:506,t:1527264882987};\\\", \\\"{x:589,y:504,t:1527264883004};\\\", \\\"{x:598,y:501,t:1527264883021};\\\", \\\"{x:609,y:500,t:1527264883037};\\\", \\\"{x:627,y:500,t:1527264883054};\\\", \\\"{x:647,y:500,t:1527264883072};\\\", \\\"{x:679,y:502,t:1527264883087};\\\", \\\"{x:715,y:506,t:1527264883103};\\\", \\\"{x:788,y:512,t:1527264883121};\\\", \\\"{x:827,y:512,t:1527264883138};\\\", \\\"{x:855,y:512,t:1527264883154};\\\", \\\"{x:870,y:515,t:1527264883171};\\\", \\\"{x:874,y:515,t:1527264883186};\\\", \\\"{x:874,y:514,t:1527264883312};\\\", \\\"{x:874,y:513,t:1527264883345};\\\", \\\"{x:874,y:512,t:1527264883385};\\\", \\\"{x:872,y:511,t:1527264883393};\\\", \\\"{x:871,y:511,t:1527264883404};\\\", \\\"{x:865,y:508,t:1527264883422};\\\", \\\"{x:860,y:507,t:1527264883437};\\\", \\\"{x:854,y:507,t:1527264883453};\\\", \\\"{x:849,y:507,t:1527264883471};\\\", \\\"{x:847,y:507,t:1527264883487};\\\", \\\"{x:846,y:507,t:1527264883504};\\\", \\\"{x:846,y:506,t:1527264883905};\\\", \\\"{x:844,y:506,t:1527264883921};\\\", \\\"{x:838,y:507,t:1527264883938};\\\", \\\"{x:832,y:510,t:1527264883955};\\\", \\\"{x:819,y:517,t:1527264883972};\\\", \\\"{x:802,y:528,t:1527264883988};\\\", \\\"{x:769,y:553,t:1527264884004};\\\", \\\"{x:737,y:576,t:1527264884021};\\\", \\\"{x:715,y:602,t:1527264884038};\\\", \\\"{x:698,y:624,t:1527264884054};\\\", \\\"{x:681,y:649,t:1527264884072};\\\", \\\"{x:672,y:663,t:1527264884088};\\\", \\\"{x:663,y:679,t:1527264884105};\\\", \\\"{x:657,y:689,t:1527264884122};\\\", \\\"{x:647,y:700,t:1527264884137};\\\", \\\"{x:634,y:706,t:1527264884155};\\\", \\\"{x:616,y:708,t:1527264884171};\\\", \\\"{x:593,y:711,t:1527264884188};\\\", \\\"{x:568,y:713,t:1527264884205};\\\", \\\"{x:548,y:718,t:1527264884222};\\\", \\\"{x:532,y:724,t:1527264884238};\\\", \\\"{x:517,y:732,t:1527264884255};\\\", \\\"{x:511,y:738,t:1527264884271};\\\", \\\"{x:506,y:742,t:1527264884287};\\\", \\\"{x:506,y:744,t:1527264884305};\\\", \\\"{x:505,y:743,t:1527264885297};\\\", \\\"{x:504,y:742,t:1527264885305};\\\", \\\"{x:504,y:740,t:1527264885328};\\\", \\\"{x:504,y:739,t:1527264885339};\\\", \\\"{x:503,y:738,t:1527264885355};\\\", \\\"{x:503,y:737,t:1527264885416};\\\", \\\"{x:502,y:736,t:1527264885464};\\\", \\\"{x:501,y:735,t:1527264885544};\\\" ] }, { \\\"rt\\\": 132509, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 603306, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L -B -I -I -I -I -J -I -B -B -B -J -J -J -J -J -J -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:731,t:1527264885762};\\\", \\\"{x:496,y:731,t:1527264887233};\\\", \\\"{x:489,y:726,t:1527264887241};\\\", \\\"{x:478,y:714,t:1527264887261};\\\", \\\"{x:463,y:700,t:1527264887274};\\\", \\\"{x:458,y:696,t:1527264887290};\\\", \\\"{x:454,y:690,t:1527264887306};\\\", \\\"{x:454,y:689,t:1527264887873};\\\", \\\"{x:468,y:674,t:1527264887890};\\\", \\\"{x:483,y:647,t:1527264887909};\\\", \\\"{x:496,y:626,t:1527264887925};\\\", \\\"{x:509,y:601,t:1527264887942};\\\", \\\"{x:518,y:583,t:1527264887958};\\\", \\\"{x:525,y:568,t:1527264887974};\\\", \\\"{x:532,y:556,t:1527264887991};\\\", \\\"{x:538,y:544,t:1527264888008};\\\", \\\"{x:542,y:536,t:1527264888024};\\\", \\\"{x:547,y:525,t:1527264888040};\\\", \\\"{x:550,y:519,t:1527264888058};\\\", \\\"{x:552,y:516,t:1527264888074};\\\", \\\"{x:554,y:512,t:1527264888091};\\\", \\\"{x:559,y:506,t:1527264888107};\\\", \\\"{x:563,y:499,t:1527264888124};\\\", \\\"{x:571,y:491,t:1527264888141};\\\", \\\"{x:576,y:486,t:1527264888158};\\\", \\\"{x:584,y:480,t:1527264888175};\\\", \\\"{x:591,y:476,t:1527264888191};\\\", \\\"{x:603,y:467,t:1527264888208};\\\", \\\"{x:610,y:461,t:1527264888224};\\\", \\\"{x:616,y:456,t:1527264888241};\\\", \\\"{x:620,y:452,t:1527264888258};\\\", \\\"{x:624,y:450,t:1527264888275};\\\", \\\"{x:625,y:449,t:1527264888291};\\\", \\\"{x:625,y:447,t:1527264888308};\\\", \\\"{x:627,y:445,t:1527264888325};\\\", \\\"{x:627,y:443,t:1527264888352};\\\", \\\"{x:628,y:443,t:1527264888360};\\\", \\\"{x:628,y:442,t:1527264888417};\\\", \\\"{x:628,y:441,t:1527264888441};\\\", \\\"{x:627,y:441,t:1527264888449};\\\", \\\"{x:625,y:441,t:1527264888465};\\\", \\\"{x:623,y:441,t:1527264888475};\\\", \\\"{x:621,y:441,t:1527264888491};\\\", \\\"{x:620,y:442,t:1527264888633};\\\", \\\"{x:620,y:443,t:1527264888642};\\\", \\\"{x:624,y:445,t:1527264888658};\\\", \\\"{x:629,y:446,t:1527264888675};\\\", \\\"{x:649,y:447,t:1527264888692};\\\", \\\"{x:673,y:447,t:1527264888708};\\\", \\\"{x:714,y:447,t:1527264888725};\\\", \\\"{x:751,y:447,t:1527264888742};\\\", \\\"{x:781,y:447,t:1527264888759};\\\", \\\"{x:800,y:447,t:1527264888776};\\\", \\\"{x:809,y:447,t:1527264888793};\\\", \\\"{x:811,y:447,t:1527264888808};\\\", \\\"{x:812,y:447,t:1527264888825};\\\", \\\"{x:816,y:446,t:1527264888842};\\\", \\\"{x:819,y:445,t:1527264888858};\\\", \\\"{x:827,y:442,t:1527264888876};\\\", \\\"{x:831,y:442,t:1527264888892};\\\", \\\"{x:837,y:441,t:1527264888908};\\\", \\\"{x:841,y:439,t:1527264888926};\\\", \\\"{x:839,y:440,t:1527264889017};\\\", \\\"{x:837,y:440,t:1527264889024};\\\", \\\"{x:831,y:444,t:1527264889041};\\\", \\\"{x:825,y:447,t:1527264889059};\\\", \\\"{x:818,y:448,t:1527264889074};\\\", \\\"{x:812,y:450,t:1527264889091};\\\", \\\"{x:807,y:451,t:1527264889108};\\\", \\\"{x:804,y:452,t:1527264889124};\\\", \\\"{x:799,y:452,t:1527264889142};\\\", \\\"{x:793,y:455,t:1527264889158};\\\", \\\"{x:787,y:456,t:1527264889175};\\\", \\\"{x:783,y:459,t:1527264889192};\\\", \\\"{x:781,y:459,t:1527264889265};\\\", \\\"{x:782,y:459,t:1527264889457};\\\", \\\"{x:783,y:458,t:1527264889481};\\\", \\\"{x:785,y:458,t:1527264889769};\\\", \\\"{x:782,y:457,t:1527264889937};\\\", \\\"{x:771,y:457,t:1527264889958};\\\", \\\"{x:748,y:457,t:1527264889976};\\\", \\\"{x:732,y:457,t:1527264889993};\\\", \\\"{x:709,y:459,t:1527264890009};\\\", \\\"{x:687,y:463,t:1527264890025};\\\", \\\"{x:663,y:467,t:1527264890043};\\\", \\\"{x:639,y:468,t:1527264890059};\\\", \\\"{x:620,y:473,t:1527264890076};\\\", \\\"{x:606,y:473,t:1527264890093};\\\", \\\"{x:595,y:474,t:1527264890110};\\\", \\\"{x:585,y:474,t:1527264890125};\\\", \\\"{x:575,y:474,t:1527264890142};\\\", \\\"{x:561,y:474,t:1527264890159};\\\", \\\"{x:545,y:474,t:1527264890175};\\\", \\\"{x:532,y:474,t:1527264890193};\\\", \\\"{x:528,y:474,t:1527264890210};\\\", \\\"{x:525,y:474,t:1527264890226};\\\", \\\"{x:523,y:474,t:1527264890368};\\\", \\\"{x:523,y:473,t:1527264890417};\\\", \\\"{x:523,y:472,t:1527264890433};\\\", \\\"{x:524,y:471,t:1527264890449};\\\", \\\"{x:525,y:471,t:1527264890459};\\\", \\\"{x:528,y:469,t:1527264890476};\\\", \\\"{x:535,y:466,t:1527264890493};\\\", \\\"{x:541,y:463,t:1527264890508};\\\", \\\"{x:546,y:461,t:1527264890525};\\\", \\\"{x:552,y:459,t:1527264890541};\\\", \\\"{x:556,y:457,t:1527264890560};\\\", \\\"{x:559,y:456,t:1527264890592};\\\", \\\"{x:557,y:456,t:1527264890921};\\\", \\\"{x:556,y:456,t:1527264890936};\\\", \\\"{x:554,y:456,t:1527264891017};\\\", \\\"{x:554,y:456,t:1527264891394};\\\", \\\"{x:562,y:456,t:1527264892257};\\\", \\\"{x:578,y:456,t:1527264892265};\\\", \\\"{x:612,y:456,t:1527264892278};\\\", \\\"{x:698,y:456,t:1527264892293};\\\", \\\"{x:817,y:456,t:1527264892310};\\\", \\\"{x:947,y:456,t:1527264892328};\\\", \\\"{x:1083,y:456,t:1527264892344};\\\", \\\"{x:1238,y:456,t:1527264892361};\\\", \\\"{x:1283,y:461,t:1527264892377};\\\", \\\"{x:1298,y:467,t:1527264892394};\\\", \\\"{x:1300,y:468,t:1527264892411};\\\", \\\"{x:1300,y:469,t:1527264892428};\\\", \\\"{x:1299,y:471,t:1527264892443};\\\", \\\"{x:1299,y:472,t:1527264892857};\\\", \\\"{x:1299,y:473,t:1527264892865};\\\", \\\"{x:1299,y:474,t:1527264892889};\\\", \\\"{x:1295,y:478,t:1527264892905};\\\", \\\"{x:1286,y:483,t:1527264892914};\\\", \\\"{x:1281,y:488,t:1527264892927};\\\", \\\"{x:1280,y:490,t:1527264892943};\\\", \\\"{x:1278,y:491,t:1527264892977};\\\", \\\"{x:1276,y:492,t:1527264892993};\\\", \\\"{x:1274,y:493,t:1527264893011};\\\", \\\"{x:1274,y:494,t:1527264893049};\\\", \\\"{x:1275,y:494,t:1527264893060};\\\", \\\"{x:1282,y:494,t:1527264893078};\\\", \\\"{x:1298,y:494,t:1527264893093};\\\", \\\"{x:1318,y:494,t:1527264893111};\\\", \\\"{x:1348,y:494,t:1527264893128};\\\", \\\"{x:1384,y:494,t:1527264893144};\\\", \\\"{x:1443,y:490,t:1527264893160};\\\", \\\"{x:1479,y:484,t:1527264893177};\\\", \\\"{x:1509,y:482,t:1527264893194};\\\", \\\"{x:1532,y:480,t:1527264893210};\\\", \\\"{x:1547,y:480,t:1527264893228};\\\", \\\"{x:1560,y:480,t:1527264893244};\\\", \\\"{x:1565,y:480,t:1527264893260};\\\", \\\"{x:1567,y:480,t:1527264893277};\\\", \\\"{x:1569,y:480,t:1527264893293};\\\", \\\"{x:1572,y:480,t:1527264893310};\\\", \\\"{x:1577,y:480,t:1527264893328};\\\", \\\"{x:1584,y:480,t:1527264893345};\\\", \\\"{x:1596,y:480,t:1527264893361};\\\", \\\"{x:1603,y:480,t:1527264893377};\\\", \\\"{x:1608,y:480,t:1527264893394};\\\", \\\"{x:1612,y:480,t:1527264893410};\\\", \\\"{x:1616,y:480,t:1527264893427};\\\", \\\"{x:1619,y:480,t:1527264893444};\\\", \\\"{x:1619,y:483,t:1527264893505};\\\", \\\"{x:1617,y:483,t:1527264893514};\\\", \\\"{x:1616,y:486,t:1527264893527};\\\", \\\"{x:1614,y:487,t:1527264893543};\\\", \\\"{x:1610,y:491,t:1527264893560};\\\", \\\"{x:1608,y:493,t:1527264893577};\\\", \\\"{x:1607,y:495,t:1527264893593};\\\", \\\"{x:1605,y:497,t:1527264893610};\\\", \\\"{x:1601,y:499,t:1527264893627};\\\", \\\"{x:1600,y:499,t:1527264893643};\\\", \\\"{x:1598,y:500,t:1527264893660};\\\", \\\"{x:1597,y:501,t:1527264893678};\\\", \\\"{x:1595,y:501,t:1527264893693};\\\", \\\"{x:1595,y:502,t:1527264893710};\\\", \\\"{x:1594,y:502,t:1527264893736};\\\", \\\"{x:1592,y:502,t:1527264893744};\\\", \\\"{x:1590,y:502,t:1527264893761};\\\", \\\"{x:1587,y:502,t:1527264893777};\\\", \\\"{x:1585,y:502,t:1527264893793};\\\", \\\"{x:1584,y:501,t:1527264893826};\\\", \\\"{x:1583,y:501,t:1527264893860};\\\", \\\"{x:1581,y:502,t:1527264894000};\\\", \\\"{x:1571,y:511,t:1527264894012};\\\", \\\"{x:1548,y:529,t:1527264894028};\\\", \\\"{x:1498,y:545,t:1527264894043};\\\", \\\"{x:1434,y:551,t:1527264894060};\\\", \\\"{x:1362,y:551,t:1527264894077};\\\", \\\"{x:1303,y:551,t:1527264894093};\\\", \\\"{x:1272,y:551,t:1527264894110};\\\", \\\"{x:1254,y:551,t:1527264894127};\\\", \\\"{x:1251,y:551,t:1527264894143};\\\", \\\"{x:1250,y:551,t:1527264894184};\\\", \\\"{x:1249,y:551,t:1527264894193};\\\", \\\"{x:1246,y:551,t:1527264894210};\\\", \\\"{x:1241,y:551,t:1527264894227};\\\", \\\"{x:1237,y:551,t:1527264894244};\\\", \\\"{x:1236,y:551,t:1527264894260};\\\", \\\"{x:1235,y:552,t:1527264894376};\\\", \\\"{x:1235,y:553,t:1527264894392};\\\", \\\"{x:1235,y:554,t:1527264894400};\\\", \\\"{x:1236,y:555,t:1527264894410};\\\", \\\"{x:1237,y:556,t:1527264894427};\\\", \\\"{x:1239,y:557,t:1527264894444};\\\", \\\"{x:1241,y:558,t:1527264894460};\\\", \\\"{x:1243,y:559,t:1527264894477};\\\", \\\"{x:1244,y:559,t:1527264894494};\\\", \\\"{x:1245,y:560,t:1527264894513};\\\", \\\"{x:1247,y:561,t:1527264894527};\\\", \\\"{x:1252,y:561,t:1527264894544};\\\", \\\"{x:1259,y:561,t:1527264894560};\\\", \\\"{x:1263,y:563,t:1527264894577};\\\", \\\"{x:1267,y:564,t:1527264894594};\\\", \\\"{x:1268,y:567,t:1527264897660};\\\", \\\"{x:1272,y:573,t:1527264897668};\\\", \\\"{x:1280,y:586,t:1527264897681};\\\", \\\"{x:1320,y:637,t:1527264897698};\\\", \\\"{x:1367,y:700,t:1527264897715};\\\", \\\"{x:1404,y:739,t:1527264897731};\\\", \\\"{x:1415,y:753,t:1527264897748};\\\", \\\"{x:1417,y:755,t:1527264897764};\\\", \\\"{x:1417,y:756,t:1527264897788};\\\", \\\"{x:1417,y:757,t:1527264897804};\\\", \\\"{x:1416,y:758,t:1527264897814};\\\", \\\"{x:1411,y:761,t:1527264897831};\\\", \\\"{x:1410,y:762,t:1527264897848};\\\", \\\"{x:1408,y:764,t:1527264897864};\\\", \\\"{x:1405,y:764,t:1527264897881};\\\", \\\"{x:1395,y:763,t:1527264897898};\\\", \\\"{x:1360,y:751,t:1527264897915};\\\", \\\"{x:1332,y:740,t:1527264897931};\\\", \\\"{x:1293,y:731,t:1527264897948};\\\", \\\"{x:1279,y:731,t:1527264897964};\\\", \\\"{x:1277,y:731,t:1527264897981};\\\", \\\"{x:1277,y:735,t:1527264897998};\\\", \\\"{x:1286,y:745,t:1527264898015};\\\", \\\"{x:1295,y:755,t:1527264898031};\\\", \\\"{x:1297,y:756,t:1527264898051};\\\", \\\"{x:1299,y:756,t:1527264898459};\\\", \\\"{x:1302,y:756,t:1527264898467};\\\", \\\"{x:1303,y:756,t:1527264898481};\\\", \\\"{x:1304,y:756,t:1527264898497};\\\", \\\"{x:1306,y:756,t:1527264898514};\\\", \\\"{x:1311,y:756,t:1527264898530};\\\", \\\"{x:1318,y:759,t:1527264898547};\\\", \\\"{x:1322,y:759,t:1527264898565};\\\", \\\"{x:1325,y:759,t:1527264898580};\\\", \\\"{x:1327,y:761,t:1527264898598};\\\", \\\"{x:1330,y:762,t:1527264898615};\\\", \\\"{x:1332,y:762,t:1527264898630};\\\", \\\"{x:1336,y:764,t:1527264898648};\\\", \\\"{x:1337,y:764,t:1527264898665};\\\", \\\"{x:1339,y:764,t:1527264898732};\\\", \\\"{x:1340,y:764,t:1527264898748};\\\", \\\"{x:1342,y:764,t:1527264898805};\\\", \\\"{x:1343,y:764,t:1527264898831};\\\", \\\"{x:1346,y:764,t:1527264898847};\\\", \\\"{x:1349,y:762,t:1527264898864};\\\", \\\"{x:1350,y:762,t:1527264898884};\\\", \\\"{x:1351,y:761,t:1527264900844};\\\", \\\"{x:1350,y:761,t:1527264900852};\\\", \\\"{x:1349,y:761,t:1527264900876};\\\", \\\"{x:1348,y:760,t:1527264900892};\\\", \\\"{x:1347,y:760,t:1527264900917};\\\", \\\"{x:1346,y:760,t:1527264900931};\\\", \\\"{x:1340,y:760,t:1527264900948};\\\", \\\"{x:1334,y:761,t:1527264900965};\\\", \\\"{x:1320,y:762,t:1527264900982};\\\", \\\"{x:1303,y:765,t:1527264900998};\\\", \\\"{x:1282,y:766,t:1527264901015};\\\", \\\"{x:1262,y:766,t:1527264901032};\\\", \\\"{x:1242,y:766,t:1527264901049};\\\", \\\"{x:1229,y:766,t:1527264901065};\\\", \\\"{x:1221,y:766,t:1527264901081};\\\", \\\"{x:1214,y:766,t:1527264901098};\\\", \\\"{x:1207,y:767,t:1527264901116};\\\", \\\"{x:1206,y:767,t:1527264901131};\\\", \\\"{x:1200,y:768,t:1527264901148};\\\", \\\"{x:1191,y:768,t:1527264901165};\\\", \\\"{x:1180,y:768,t:1527264901181};\\\", \\\"{x:1171,y:768,t:1527264901199};\\\", \\\"{x:1164,y:766,t:1527264901215};\\\", \\\"{x:1160,y:764,t:1527264901231};\\\", \\\"{x:1159,y:764,t:1527264901248};\\\", \\\"{x:1159,y:762,t:1527264901265};\\\", \\\"{x:1159,y:761,t:1527264901283};\\\", \\\"{x:1160,y:761,t:1527264901299};\\\", \\\"{x:1160,y:760,t:1527264901315};\\\", \\\"{x:1161,y:759,t:1527264901332};\\\", \\\"{x:1161,y:758,t:1527264901364};\\\", \\\"{x:1161,y:757,t:1527264901453};\\\", \\\"{x:1159,y:756,t:1527264901476};\\\", \\\"{x:1159,y:755,t:1527264901492};\\\", \\\"{x:1158,y:755,t:1527264901500};\\\", \\\"{x:1156,y:755,t:1527264901515};\\\", \\\"{x:1155,y:754,t:1527264901540};\\\", \\\"{x:1154,y:753,t:1527264901571};\\\", \\\"{x:1154,y:752,t:1527264901587};\\\", \\\"{x:1154,y:750,t:1527264901604};\\\", \\\"{x:1154,y:748,t:1527264901615};\\\", \\\"{x:1158,y:745,t:1527264901632};\\\", \\\"{x:1166,y:742,t:1527264901648};\\\", \\\"{x:1174,y:741,t:1527264901665};\\\", \\\"{x:1185,y:741,t:1527264901682};\\\", \\\"{x:1199,y:744,t:1527264901698};\\\", \\\"{x:1214,y:752,t:1527264901716};\\\", \\\"{x:1236,y:770,t:1527264901731};\\\", \\\"{x:1241,y:780,t:1527264901748};\\\", \\\"{x:1245,y:794,t:1527264901765};\\\", \\\"{x:1246,y:809,t:1527264901782};\\\", \\\"{x:1246,y:824,t:1527264901798};\\\", \\\"{x:1246,y:834,t:1527264901815};\\\", \\\"{x:1246,y:840,t:1527264901832};\\\", \\\"{x:1244,y:844,t:1527264901848};\\\", \\\"{x:1242,y:848,t:1527264901865};\\\", \\\"{x:1241,y:849,t:1527264901883};\\\", \\\"{x:1240,y:849,t:1527264901898};\\\", \\\"{x:1237,y:849,t:1527264901915};\\\", \\\"{x:1226,y:849,t:1527264901932};\\\", \\\"{x:1212,y:848,t:1527264901947};\\\", \\\"{x:1199,y:845,t:1527264901965};\\\", \\\"{x:1185,y:839,t:1527264901981};\\\", \\\"{x:1171,y:833,t:1527264901998};\\\", \\\"{x:1163,y:829,t:1527264902014};\\\", \\\"{x:1158,y:825,t:1527264902032};\\\", \\\"{x:1157,y:823,t:1527264902047};\\\", \\\"{x:1157,y:820,t:1527264902064};\\\", \\\"{x:1157,y:814,t:1527264902081};\\\", \\\"{x:1157,y:807,t:1527264902097};\\\", \\\"{x:1157,y:797,t:1527264902115};\\\", \\\"{x:1157,y:790,t:1527264902131};\\\", \\\"{x:1157,y:785,t:1527264902148};\\\", \\\"{x:1157,y:777,t:1527264902165};\\\", \\\"{x:1159,y:773,t:1527264902182};\\\", \\\"{x:1161,y:767,t:1527264902198};\\\", \\\"{x:1163,y:763,t:1527264902215};\\\", \\\"{x:1165,y:760,t:1527264902232};\\\", \\\"{x:1167,y:757,t:1527264902248};\\\", \\\"{x:1170,y:756,t:1527264902264};\\\", \\\"{x:1174,y:753,t:1527264902282};\\\", \\\"{x:1177,y:753,t:1527264902298};\\\", \\\"{x:1179,y:753,t:1527264902315};\\\", \\\"{x:1184,y:753,t:1527264902332};\\\", \\\"{x:1187,y:753,t:1527264902348};\\\", \\\"{x:1190,y:757,t:1527264902365};\\\", \\\"{x:1192,y:762,t:1527264902382};\\\", \\\"{x:1193,y:770,t:1527264902398};\\\", \\\"{x:1195,y:782,t:1527264902415};\\\", \\\"{x:1196,y:789,t:1527264902432};\\\", \\\"{x:1196,y:795,t:1527264902448};\\\", \\\"{x:1197,y:801,t:1527264902465};\\\", \\\"{x:1199,y:807,t:1527264902482};\\\", \\\"{x:1199,y:811,t:1527264902499};\\\", \\\"{x:1199,y:815,t:1527264902515};\\\", \\\"{x:1199,y:818,t:1527264902531};\\\", \\\"{x:1195,y:820,t:1527264902548};\\\", \\\"{x:1189,y:820,t:1527264902565};\\\", \\\"{x:1183,y:820,t:1527264902582};\\\", \\\"{x:1176,y:819,t:1527264902598};\\\", \\\"{x:1170,y:814,t:1527264902615};\\\", \\\"{x:1165,y:809,t:1527264902632};\\\", \\\"{x:1162,y:802,t:1527264902649};\\\", \\\"{x:1159,y:792,t:1527264902666};\\\", \\\"{x:1158,y:779,t:1527264902682};\\\", \\\"{x:1154,y:761,t:1527264902698};\\\", \\\"{x:1151,y:745,t:1527264902716};\\\", \\\"{x:1151,y:737,t:1527264902732};\\\", \\\"{x:1151,y:735,t:1527264902748};\\\", \\\"{x:1152,y:734,t:1527264902765};\\\", \\\"{x:1156,y:733,t:1527264902782};\\\", \\\"{x:1160,y:731,t:1527264902798};\\\", \\\"{x:1167,y:731,t:1527264902815};\\\", \\\"{x:1174,y:731,t:1527264902832};\\\", \\\"{x:1178,y:731,t:1527264902848};\\\", \\\"{x:1182,y:731,t:1527264902866};\\\", \\\"{x:1187,y:735,t:1527264902882};\\\", \\\"{x:1191,y:739,t:1527264902898};\\\", \\\"{x:1197,y:747,t:1527264902915};\\\", \\\"{x:1203,y:753,t:1527264902932};\\\", \\\"{x:1207,y:759,t:1527264902948};\\\", \\\"{x:1212,y:766,t:1527264902965};\\\", \\\"{x:1216,y:771,t:1527264902982};\\\", \\\"{x:1219,y:775,t:1527264902998};\\\", \\\"{x:1222,y:782,t:1527264903015};\\\", \\\"{x:1223,y:784,t:1527264903032};\\\", \\\"{x:1223,y:787,t:1527264903048};\\\", \\\"{x:1223,y:790,t:1527264903066};\\\", \\\"{x:1223,y:792,t:1527264903082};\\\", \\\"{x:1223,y:794,t:1527264903098};\\\", \\\"{x:1223,y:798,t:1527264903115};\\\", \\\"{x:1223,y:803,t:1527264903132};\\\", \\\"{x:1220,y:805,t:1527264903148};\\\", \\\"{x:1218,y:806,t:1527264903165};\\\", \\\"{x:1215,y:807,t:1527264903182};\\\", \\\"{x:1211,y:809,t:1527264903198};\\\", \\\"{x:1207,y:809,t:1527264903216};\\\", \\\"{x:1202,y:809,t:1527264903232};\\\", \\\"{x:1197,y:809,t:1527264903248};\\\", \\\"{x:1194,y:809,t:1527264903265};\\\", \\\"{x:1192,y:807,t:1527264903282};\\\", \\\"{x:1192,y:806,t:1527264903298};\\\", \\\"{x:1190,y:804,t:1527264903315};\\\", \\\"{x:1190,y:803,t:1527264903331};\\\", \\\"{x:1190,y:802,t:1527264903556};\\\", \\\"{x:1190,y:801,t:1527264903595};\\\", \\\"{x:1190,y:799,t:1527264903620};\\\", \\\"{x:1190,y:797,t:1527264903632};\\\", \\\"{x:1190,y:790,t:1527264903648};\\\", \\\"{x:1186,y:777,t:1527264903665};\\\", \\\"{x:1181,y:766,t:1527264903682};\\\", \\\"{x:1173,y:755,t:1527264903699};\\\", \\\"{x:1166,y:747,t:1527264903715};\\\", \\\"{x:1162,y:742,t:1527264903732};\\\", \\\"{x:1161,y:741,t:1527264903748};\\\", \\\"{x:1161,y:740,t:1527264903765};\\\", \\\"{x:1161,y:739,t:1527264903853};\\\", \\\"{x:1162,y:739,t:1527264903876};\\\", \\\"{x:1163,y:739,t:1527264903892};\\\", \\\"{x:1165,y:739,t:1527264903900};\\\", \\\"{x:1166,y:739,t:1527264903915};\\\", \\\"{x:1172,y:739,t:1527264903931};\\\", \\\"{x:1176,y:740,t:1527264903948};\\\", \\\"{x:1180,y:743,t:1527264903965};\\\", \\\"{x:1182,y:745,t:1527264903982};\\\", \\\"{x:1184,y:749,t:1527264903998};\\\", \\\"{x:1187,y:754,t:1527264904015};\\\", \\\"{x:1188,y:755,t:1527264904032};\\\", \\\"{x:1188,y:756,t:1527264904164};\\\", \\\"{x:1187,y:756,t:1527264904229};\\\", \\\"{x:1186,y:756,t:1527264904484};\\\", \\\"{x:1186,y:757,t:1527264904500};\\\", \\\"{x:1186,y:758,t:1527264904515};\\\", \\\"{x:1186,y:764,t:1527264904532};\\\", \\\"{x:1187,y:770,t:1527264904550};\\\", \\\"{x:1189,y:772,t:1527264904565};\\\", \\\"{x:1191,y:775,t:1527264904582};\\\", \\\"{x:1194,y:780,t:1527264904599};\\\", \\\"{x:1197,y:783,t:1527264904615};\\\", \\\"{x:1201,y:788,t:1527264904632};\\\", \\\"{x:1204,y:794,t:1527264904647};\\\", \\\"{x:1208,y:803,t:1527264904664};\\\", \\\"{x:1210,y:811,t:1527264904681};\\\", \\\"{x:1213,y:818,t:1527264904697};\\\", \\\"{x:1213,y:821,t:1527264904714};\\\", \\\"{x:1213,y:822,t:1527264904731};\\\", \\\"{x:1212,y:821,t:1527264904868};\\\", \\\"{x:1211,y:820,t:1527264904882};\\\", \\\"{x:1207,y:815,t:1527264904899};\\\", \\\"{x:1197,y:806,t:1527264904915};\\\", \\\"{x:1173,y:785,t:1527264904931};\\\", \\\"{x:1157,y:771,t:1527264904949};\\\", \\\"{x:1146,y:759,t:1527264904966};\\\", \\\"{x:1141,y:754,t:1527264904982};\\\", \\\"{x:1141,y:752,t:1527264904998};\\\", \\\"{x:1141,y:751,t:1527264905015};\\\", \\\"{x:1144,y:751,t:1527264905033};\\\", \\\"{x:1145,y:750,t:1527264905084};\\\", \\\"{x:1147,y:750,t:1527264905319};\\\", \\\"{x:1149,y:752,t:1527264905332};\\\", \\\"{x:1152,y:753,t:1527264905349};\\\", \\\"{x:1157,y:757,t:1527264905365};\\\", \\\"{x:1163,y:761,t:1527264905382};\\\", \\\"{x:1166,y:764,t:1527264905399};\\\", \\\"{x:1170,y:767,t:1527264905415};\\\", \\\"{x:1172,y:769,t:1527264905432};\\\", \\\"{x:1173,y:770,t:1527264905449};\\\", \\\"{x:1173,y:769,t:1527264905683};\\\", \\\"{x:1172,y:767,t:1527264905699};\\\", \\\"{x:1172,y:766,t:1527264905715};\\\", \\\"{x:1172,y:764,t:1527264905732};\\\", \\\"{x:1172,y:761,t:1527264909557};\\\", \\\"{x:1172,y:759,t:1527264909567};\\\", \\\"{x:1172,y:757,t:1527264909582};\\\", \\\"{x:1172,y:756,t:1527264909599};\\\", \\\"{x:1172,y:757,t:1527264909627};\\\", \\\"{x:1171,y:760,t:1527264909636};\\\", \\\"{x:1169,y:765,t:1527264909650};\\\", \\\"{x:1168,y:769,t:1527264909667};\\\", \\\"{x:1168,y:772,t:1527264909683};\\\", \\\"{x:1168,y:770,t:1527264909972};\\\", \\\"{x:1168,y:769,t:1527264910028};\\\", \\\"{x:1169,y:769,t:1527264913748};\\\", \\\"{x:1170,y:769,t:1527264913766};\\\", \\\"{x:1171,y:769,t:1527264913784};\\\", \\\"{x:1172,y:769,t:1527264915396};\\\", \\\"{x:1172,y:770,t:1527264915436};\\\", \\\"{x:1172,y:771,t:1527264915467};\\\", \\\"{x:1173,y:772,t:1527264915483};\\\", \\\"{x:1174,y:772,t:1527264919020};\\\", \\\"{x:1175,y:771,t:1527264919036};\\\", \\\"{x:1175,y:770,t:1527264919059};\\\", \\\"{x:1175,y:769,t:1527264919092};\\\", \\\"{x:1176,y:769,t:1527264919196};\\\", \\\"{x:1177,y:769,t:1527264919212};\\\", \\\"{x:1177,y:768,t:1527264919228};\\\", \\\"{x:1178,y:768,t:1527264922196};\\\", \\\"{x:1178,y:766,t:1527264922218};\\\", \\\"{x:1180,y:766,t:1527264922484};\\\", \\\"{x:1190,y:765,t:1527264930213};\\\", \\\"{x:1206,y:760,t:1527264930220};\\\", \\\"{x:1210,y:757,t:1527264930236};\\\", \\\"{x:1238,y:756,t:1527264930252};\\\", \\\"{x:1250,y:756,t:1527264930269};\\\", \\\"{x:1252,y:756,t:1527264930286};\\\", \\\"{x:1254,y:756,t:1527264930302};\\\", \\\"{x:1255,y:756,t:1527264930319};\\\", \\\"{x:1257,y:755,t:1527264930335};\\\", \\\"{x:1260,y:754,t:1527264930353};\\\", \\\"{x:1263,y:753,t:1527264930369};\\\", \\\"{x:1264,y:752,t:1527264930386};\\\", \\\"{x:1266,y:751,t:1527264930402};\\\", \\\"{x:1269,y:750,t:1527264930420};\\\", \\\"{x:1270,y:749,t:1527264930435};\\\", \\\"{x:1272,y:749,t:1527264930508};\\\", \\\"{x:1274,y:749,t:1527264930520};\\\", \\\"{x:1279,y:747,t:1527264930535};\\\", \\\"{x:1289,y:746,t:1527264930552};\\\", \\\"{x:1302,y:745,t:1527264930569};\\\", \\\"{x:1315,y:744,t:1527264930585};\\\", \\\"{x:1330,y:744,t:1527264930601};\\\", \\\"{x:1345,y:744,t:1527264930619};\\\", \\\"{x:1350,y:744,t:1527264930635};\\\", \\\"{x:1354,y:744,t:1527264930652};\\\", \\\"{x:1358,y:746,t:1527264930669};\\\", \\\"{x:1366,y:751,t:1527264930685};\\\", \\\"{x:1370,y:752,t:1527264930702};\\\", \\\"{x:1374,y:752,t:1527264930719};\\\", \\\"{x:1378,y:755,t:1527264930735};\\\", \\\"{x:1380,y:756,t:1527264930752};\\\", \\\"{x:1385,y:760,t:1527264930769};\\\", \\\"{x:1389,y:763,t:1527264930785};\\\", \\\"{x:1392,y:765,t:1527264930802};\\\", \\\"{x:1392,y:766,t:1527264930827};\\\", \\\"{x:1392,y:768,t:1527264930835};\\\", \\\"{x:1387,y:771,t:1527264930852};\\\", \\\"{x:1382,y:774,t:1527264930869};\\\", \\\"{x:1376,y:775,t:1527264930885};\\\", \\\"{x:1373,y:776,t:1527264930903};\\\", \\\"{x:1368,y:777,t:1527264930919};\\\", \\\"{x:1365,y:778,t:1527264930935};\\\", \\\"{x:1362,y:778,t:1527264930952};\\\", \\\"{x:1359,y:778,t:1527264930969};\\\", \\\"{x:1357,y:778,t:1527264930986};\\\", \\\"{x:1355,y:778,t:1527264931002};\\\", \\\"{x:1350,y:778,t:1527264931019};\\\", \\\"{x:1344,y:776,t:1527264931035};\\\", \\\"{x:1341,y:776,t:1527264931052};\\\", \\\"{x:1340,y:775,t:1527264931076};\\\", \\\"{x:1339,y:774,t:1527264931188};\\\", \\\"{x:1339,y:773,t:1527264931220};\\\", \\\"{x:1340,y:772,t:1527264931235};\\\", \\\"{x:1341,y:771,t:1527264931260};\\\", \\\"{x:1341,y:770,t:1527264931269};\\\", \\\"{x:1342,y:770,t:1527264931285};\\\", \\\"{x:1344,y:769,t:1527264931303};\\\", \\\"{x:1345,y:768,t:1527264931319};\\\", \\\"{x:1346,y:767,t:1527264931335};\\\", \\\"{x:1348,y:764,t:1527264931352};\\\", \\\"{x:1349,y:762,t:1527264931369};\\\", \\\"{x:1349,y:761,t:1527264931385};\\\", \\\"{x:1349,y:760,t:1527264931402};\\\", \\\"{x:1350,y:759,t:1527264931419};\\\", \\\"{x:1350,y:758,t:1527264931436};\\\", \\\"{x:1351,y:757,t:1527264931454};\\\", \\\"{x:1351,y:756,t:1527264932924};\\\", \\\"{x:1350,y:756,t:1527264932940};\\\", \\\"{x:1349,y:756,t:1527264932964};\\\", \\\"{x:1342,y:759,t:1527264935908};\\\", \\\"{x:1334,y:763,t:1527264935920};\\\", \\\"{x:1318,y:770,t:1527264935937};\\\", \\\"{x:1299,y:777,t:1527264935953};\\\", \\\"{x:1278,y:786,t:1527264935970};\\\", \\\"{x:1262,y:792,t:1527264935986};\\\", \\\"{x:1252,y:792,t:1527264936003};\\\", \\\"{x:1243,y:796,t:1527264936019};\\\", \\\"{x:1238,y:797,t:1527264936036};\\\", \\\"{x:1233,y:800,t:1527264936052};\\\", \\\"{x:1225,y:805,t:1527264936070};\\\", \\\"{x:1217,y:808,t:1527264936086};\\\", \\\"{x:1209,y:810,t:1527264936102};\\\", \\\"{x:1203,y:814,t:1527264936119};\\\", \\\"{x:1200,y:814,t:1527264936137};\\\", \\\"{x:1199,y:814,t:1527264936152};\\\", \\\"{x:1199,y:815,t:1527264936204};\\\", \\\"{x:1198,y:816,t:1527264936220};\\\", \\\"{x:1196,y:820,t:1527264936237};\\\", \\\"{x:1195,y:820,t:1527264936254};\\\", \\\"{x:1194,y:821,t:1527264936270};\\\", \\\"{x:1194,y:820,t:1527264936364};\\\", \\\"{x:1193,y:819,t:1527264936371};\\\", \\\"{x:1193,y:818,t:1527264936524};\\\", \\\"{x:1194,y:818,t:1527264936587};\\\", \\\"{x:1195,y:818,t:1527264936602};\\\", \\\"{x:1196,y:818,t:1527264936620};\\\", \\\"{x:1198,y:818,t:1527264938388};\\\", \\\"{x:1206,y:817,t:1527264938404};\\\", \\\"{x:1211,y:816,t:1527264938420};\\\", \\\"{x:1213,y:816,t:1527264938436};\\\", \\\"{x:1214,y:816,t:1527264938453};\\\", \\\"{x:1215,y:816,t:1527264938470};\\\", \\\"{x:1217,y:816,t:1527264938488};\\\", \\\"{x:1218,y:816,t:1527264938548};\\\", \\\"{x:1218,y:817,t:1527264938652};\\\", \\\"{x:1218,y:818,t:1527264938660};\\\", \\\"{x:1218,y:822,t:1527264938670};\\\", \\\"{x:1218,y:827,t:1527264938687};\\\", \\\"{x:1218,y:830,t:1527264938704};\\\", \\\"{x:1218,y:832,t:1527264938719};\\\", \\\"{x:1218,y:833,t:1527264938736};\\\", \\\"{x:1218,y:834,t:1527264938940};\\\", \\\"{x:1218,y:835,t:1527264938973};\\\", \\\"{x:1218,y:836,t:1527264939003};\\\", \\\"{x:1218,y:834,t:1527264939532};\\\", \\\"{x:1218,y:833,t:1527264939554};\\\", \\\"{x:1218,y:831,t:1527264939571};\\\", \\\"{x:1218,y:829,t:1527264939586};\\\", \\\"{x:1217,y:829,t:1527264939619};\\\", \\\"{x:1215,y:827,t:1527264955343};\\\", \\\"{x:1209,y:825,t:1527264955360};\\\", \\\"{x:1196,y:825,t:1527264955376};\\\", \\\"{x:1183,y:827,t:1527264955392};\\\", \\\"{x:1172,y:828,t:1527264955409};\\\", \\\"{x:1163,y:830,t:1527264955426};\\\", \\\"{x:1158,y:831,t:1527264955443};\\\", \\\"{x:1160,y:831,t:1527264956031};\\\", \\\"{x:1165,y:828,t:1527264956043};\\\", \\\"{x:1175,y:822,t:1527264956058};\\\", \\\"{x:1182,y:821,t:1527264956075};\\\", \\\"{x:1190,y:818,t:1527264956093};\\\", \\\"{x:1194,y:817,t:1527264956109};\\\", \\\"{x:1197,y:816,t:1527264956125};\\\", \\\"{x:1201,y:815,t:1527264956142};\\\", \\\"{x:1203,y:815,t:1527264956159};\\\", \\\"{x:1204,y:815,t:1527264956176};\\\", \\\"{x:1211,y:815,t:1527264956192};\\\", \\\"{x:1220,y:816,t:1527264956209};\\\", \\\"{x:1229,y:816,t:1527264956225};\\\", \\\"{x:1233,y:816,t:1527264956242};\\\", \\\"{x:1234,y:816,t:1527264956259};\\\", \\\"{x:1234,y:817,t:1527264956374};\\\", \\\"{x:1234,y:818,t:1527264956389};\\\", \\\"{x:1233,y:819,t:1527264956398};\\\", \\\"{x:1231,y:820,t:1527264956408};\\\", \\\"{x:1230,y:823,t:1527264956425};\\\", \\\"{x:1227,y:826,t:1527264956442};\\\", \\\"{x:1223,y:830,t:1527264956459};\\\", \\\"{x:1218,y:833,t:1527264956476};\\\", \\\"{x:1216,y:834,t:1527264956493};\\\", \\\"{x:1214,y:835,t:1527264956509};\\\", \\\"{x:1213,y:836,t:1527264956526};\\\", \\\"{x:1212,y:836,t:1527264956550};\\\", \\\"{x:1215,y:833,t:1527265002623};\\\", \\\"{x:1238,y:809,t:1527265002632};\\\", \\\"{x:1293,y:761,t:1527265002648};\\\", \\\"{x:1332,y:721,t:1527265002665};\\\", \\\"{x:1376,y:682,t:1527265002682};\\\", \\\"{x:1395,y:649,t:1527265002698};\\\", \\\"{x:1405,y:629,t:1527265002715};\\\", \\\"{x:1407,y:612,t:1527265002732};\\\", \\\"{x:1407,y:605,t:1527265002748};\\\", \\\"{x:1405,y:593,t:1527265002765};\\\", \\\"{x:1404,y:583,t:1527265002782};\\\", \\\"{x:1400,y:574,t:1527265002799};\\\", \\\"{x:1396,y:565,t:1527265002815};\\\", \\\"{x:1387,y:557,t:1527265002833};\\\", \\\"{x:1370,y:550,t:1527265002848};\\\", \\\"{x:1341,y:543,t:1527265002865};\\\", \\\"{x:1308,y:542,t:1527265002882};\\\", \\\"{x:1275,y:539,t:1527265002898};\\\", \\\"{x:1245,y:539,t:1527265002915};\\\", \\\"{x:1226,y:539,t:1527265002932};\\\", \\\"{x:1219,y:541,t:1527265002948};\\\", \\\"{x:1215,y:543,t:1527265002966};\\\", \\\"{x:1215,y:544,t:1527265002981};\\\", \\\"{x:1214,y:546,t:1527265002998};\\\", \\\"{x:1213,y:550,t:1527265003016};\\\", \\\"{x:1213,y:552,t:1527265003033};\\\", \\\"{x:1213,y:554,t:1527265003049};\\\", \\\"{x:1213,y:556,t:1527265003065};\\\", \\\"{x:1213,y:557,t:1527265003083};\\\", \\\"{x:1213,y:558,t:1527265003099};\\\", \\\"{x:1213,y:560,t:1527265003116};\\\", \\\"{x:1213,y:561,t:1527265003132};\\\", \\\"{x:1220,y:561,t:1527265003150};\\\", \\\"{x:1228,y:561,t:1527265003166};\\\", \\\"{x:1236,y:561,t:1527265003182};\\\", \\\"{x:1241,y:561,t:1527265003198};\\\", \\\"{x:1247,y:561,t:1527265003216};\\\", \\\"{x:1251,y:562,t:1527265003233};\\\", \\\"{x:1256,y:562,t:1527265003249};\\\", \\\"{x:1261,y:563,t:1527265003266};\\\", \\\"{x:1263,y:563,t:1527265003283};\\\", \\\"{x:1267,y:564,t:1527265003299};\\\", \\\"{x:1268,y:564,t:1527265003316};\\\", \\\"{x:1269,y:564,t:1527265003390};\\\", \\\"{x:1270,y:564,t:1527265003399};\\\", \\\"{x:1271,y:564,t:1527265003416};\\\", \\\"{x:1274,y:564,t:1527265003433};\\\", \\\"{x:1275,y:563,t:1527265003449};\\\", \\\"{x:1277,y:563,t:1527265003483};\\\", \\\"{x:1278,y:562,t:1527265003499};\\\", \\\"{x:1281,y:562,t:1527265003516};\\\", \\\"{x:1283,y:560,t:1527265003534};\\\", \\\"{x:1284,y:560,t:1527265003582};\\\", \\\"{x:1285,y:560,t:1527265003621};\\\", \\\"{x:1286,y:559,t:1527265003647};\\\", \\\"{x:1287,y:559,t:1527265003742};\\\", \\\"{x:1287,y:558,t:1527265004141};\\\", \\\"{x:1286,y:557,t:1527265004165};\\\", \\\"{x:1285,y:557,t:1527265004182};\\\", \\\"{x:1283,y:557,t:1527265004214};\\\", \\\"{x:1282,y:556,t:1527265004221};\\\", \\\"{x:1281,y:556,t:1527265006358};\\\", \\\"{x:1281,y:557,t:1527265006366};\\\", \\\"{x:1281,y:559,t:1527265006384};\\\", \\\"{x:1281,y:562,t:1527265006400};\\\", \\\"{x:1281,y:563,t:1527265006416};\\\", \\\"{x:1281,y:564,t:1527265006433};\\\", \\\"{x:1271,y:564,t:1527265016335};\\\", \\\"{x:1150,y:564,t:1527265016351};\\\", \\\"{x:1011,y:564,t:1527265016368};\\\", \\\"{x:862,y:564,t:1527265016387};\\\", \\\"{x:714,y:557,t:1527265016400};\\\", \\\"{x:604,y:545,t:1527265016417};\\\", \\\"{x:560,y:534,t:1527265016434};\\\", \\\"{x:547,y:528,t:1527265016450};\\\", \\\"{x:542,y:525,t:1527265016468};\\\", \\\"{x:541,y:524,t:1527265016484};\\\", \\\"{x:538,y:524,t:1527265016501};\\\", \\\"{x:537,y:523,t:1527265016532};\\\", \\\"{x:537,y:522,t:1527265016540};\\\", \\\"{x:541,y:519,t:1527265016552};\\\", \\\"{x:565,y:509,t:1527265016568};\\\", \\\"{x:586,y:498,t:1527265016584};\\\", \\\"{x:606,y:486,t:1527265016602};\\\", \\\"{x:618,y:481,t:1527265016617};\\\", \\\"{x:623,y:479,t:1527265016634};\\\", \\\"{x:624,y:478,t:1527265016651};\\\", \\\"{x:627,y:477,t:1527265016668};\\\", \\\"{x:625,y:477,t:1527265016781};\\\", \\\"{x:624,y:477,t:1527265016790};\\\", \\\"{x:623,y:478,t:1527265016802};\\\", \\\"{x:620,y:479,t:1527265016818};\\\", \\\"{x:617,y:482,t:1527265016835};\\\", \\\"{x:616,y:483,t:1527265016852};\\\", \\\"{x:616,y:484,t:1527265016869};\\\", \\\"{x:615,y:485,t:1527265016885};\\\", \\\"{x:614,y:486,t:1527265016902};\\\", \\\"{x:613,y:487,t:1527265017070};\\\", \\\"{x:605,y:496,t:1527265017084};\\\", \\\"{x:598,y:507,t:1527265017101};\\\", \\\"{x:595,y:512,t:1527265017119};\\\", \\\"{x:598,y:512,t:1527265017357};\\\", \\\"{x:603,y:508,t:1527265017370};\\\", \\\"{x:611,y:504,t:1527265017386};\\\", \\\"{x:618,y:501,t:1527265017403};\\\", \\\"{x:619,y:500,t:1527265017418};\\\", \\\"{x:620,y:500,t:1527265017452};\\\", \\\"{x:617,y:500,t:1527265017637};\\\", \\\"{x:613,y:501,t:1527265017651};\\\", \\\"{x:596,y:521,t:1527265017669};\\\", \\\"{x:584,y:550,t:1527265017686};\\\", \\\"{x:573,y:579,t:1527265017702};\\\", \\\"{x:566,y:606,t:1527265017719};\\\", \\\"{x:560,y:634,t:1527265017736};\\\", \\\"{x:553,y:657,t:1527265017752};\\\", \\\"{x:543,y:692,t:1527265017768};\\\", \\\"{x:528,y:735,t:1527265017787};\\\", \\\"{x:518,y:777,t:1527265017803};\\\", \\\"{x:514,y:800,t:1527265017819};\\\", \\\"{x:510,y:818,t:1527265017835};\\\", \\\"{x:509,y:834,t:1527265017852};\\\", \\\"{x:509,y:838,t:1527265017869};\\\", \\\"{x:509,y:839,t:1527265017901};\\\", \\\"{x:508,y:839,t:1527265017909};\\\", \\\"{x:508,y:836,t:1527265017920};\\\", \\\"{x:508,y:830,t:1527265017936};\\\", \\\"{x:506,y:825,t:1527265017953};\\\", \\\"{x:506,y:819,t:1527265017968};\\\", \\\"{x:506,y:813,t:1527265017986};\\\", \\\"{x:506,y:798,t:1527265018002};\\\", \\\"{x:506,y:784,t:1527265018019};\\\", \\\"{x:506,y:771,t:1527265018036};\\\", \\\"{x:508,y:758,t:1527265018053};\\\", \\\"{x:511,y:751,t:1527265018070};\\\", \\\"{x:516,y:740,t:1527265018085};\\\", \\\"{x:516,y:738,t:1527265018103};\\\", \\\"{x:516,y:736,t:1527265018120};\\\", \\\"{x:522,y:743,t:1527265018461};\\\", \\\"{x:530,y:754,t:1527265018469};\\\", \\\"{x:547,y:777,t:1527265018486};\\\", \\\"{x:565,y:796,t:1527265018503};\\\", \\\"{x:590,y:823,t:1527265018520};\\\", \\\"{x:608,y:839,t:1527265018536};\\\", \\\"{x:619,y:849,t:1527265018553};\\\", \\\"{x:623,y:861,t:1527265018570};\\\", \\\"{x:625,y:866,t:1527265018585};\\\", \\\"{x:625,y:869,t:1527265018603};\\\", \\\"{x:625,y:870,t:1527265018619};\\\", \\\"{x:625,y:871,t:1527265019005};\\\", \\\"{x:625,y:872,t:1527265019020};\\\", \\\"{x:625,y:875,t:1527265019070};\\\", \\\"{x:625,y:878,t:1527265019087};\\\", \\\"{x:626,y:879,t:1527265019103};\\\", \\\"{x:627,y:879,t:1527265019119};\\\", \\\"{x:628,y:881,t:1527265019137};\\\", \\\"{x:630,y:883,t:1527265019153};\\\" ] }, { \\\"rt\\\": 21589, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 626435, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-I -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:633,y:883,t:1527265019836};\\\", \\\"{x:634,y:883,t:1527265020092};\\\", \\\"{x:634,y:882,t:1527265020103};\\\", \\\"{x:634,y:881,t:1527265020125};\\\", \\\"{x:634,y:878,t:1527265020138};\\\", \\\"{x:634,y:876,t:1527265020154};\\\", \\\"{x:634,y:872,t:1527265020170};\\\", \\\"{x:634,y:869,t:1527265020187};\\\", \\\"{x:634,y:867,t:1527265020203};\\\", \\\"{x:634,y:864,t:1527265020220};\\\", \\\"{x:634,y:862,t:1527265020237};\\\", \\\"{x:634,y:861,t:1527265020293};\\\", \\\"{x:634,y:858,t:1527265020309};\\\", \\\"{x:634,y:857,t:1527265020322};\\\", \\\"{x:634,y:854,t:1527265020338};\\\", \\\"{x:636,y:849,t:1527265020354};\\\", \\\"{x:637,y:844,t:1527265020371};\\\", \\\"{x:641,y:839,t:1527265020388};\\\", \\\"{x:644,y:835,t:1527265020404};\\\", \\\"{x:648,y:829,t:1527265020421};\\\", \\\"{x:649,y:827,t:1527265020438};\\\", \\\"{x:650,y:825,t:1527265020455};\\\", \\\"{x:650,y:824,t:1527265020471};\\\", \\\"{x:651,y:822,t:1527265020488};\\\", \\\"{x:652,y:822,t:1527265020506};\\\", \\\"{x:653,y:821,t:1527265020521};\\\", \\\"{x:653,y:819,t:1527265020538};\\\", \\\"{x:654,y:818,t:1527265020555};\\\", \\\"{x:655,y:818,t:1527265020589};\\\", \\\"{x:656,y:817,t:1527265020613};\\\", \\\"{x:656,y:816,t:1527265020621};\\\", \\\"{x:657,y:816,t:1527265020645};\\\", \\\"{x:659,y:815,t:1527265020660};\\\", \\\"{x:661,y:813,t:1527265020676};\\\", \\\"{x:662,y:813,t:1527265020688};\\\", \\\"{x:665,y:810,t:1527265020705};\\\", \\\"{x:668,y:806,t:1527265020720};\\\", \\\"{x:670,y:804,t:1527265020737};\\\", \\\"{x:672,y:802,t:1527265020755};\\\", \\\"{x:673,y:801,t:1527265020780};\\\", \\\"{x:675,y:806,t:1527265021462};\\\", \\\"{x:676,y:810,t:1527265021472};\\\", \\\"{x:676,y:814,t:1527265021489};\\\", \\\"{x:676,y:818,t:1527265021504};\\\", \\\"{x:676,y:825,t:1527265021522};\\\", \\\"{x:676,y:834,t:1527265021538};\\\", \\\"{x:676,y:840,t:1527265021555};\\\", \\\"{x:676,y:842,t:1527265021571};\\\", \\\"{x:676,y:844,t:1527265022334};\\\", \\\"{x:675,y:845,t:1527265022341};\\\", \\\"{x:674,y:844,t:1527265022373};\\\", \\\"{x:667,y:816,t:1527265022389};\\\", \\\"{x:650,y:755,t:1527265022406};\\\", \\\"{x:632,y:683,t:1527265022424};\\\", \\\"{x:613,y:588,t:1527265022440};\\\", \\\"{x:587,y:512,t:1527265022456};\\\", \\\"{x:572,y:481,t:1527265022473};\\\", \\\"{x:554,y:456,t:1527265022489};\\\", \\\"{x:534,y:432,t:1527265022505};\\\", \\\"{x:516,y:413,t:1527265022522};\\\", \\\"{x:495,y:401,t:1527265022539};\\\", \\\"{x:483,y:391,t:1527265022555};\\\", \\\"{x:468,y:385,t:1527265022571};\\\", \\\"{x:459,y:384,t:1527265022589};\\\", \\\"{x:458,y:383,t:1527265022606};\\\", \\\"{x:457,y:387,t:1527265022885};\\\", \\\"{x:456,y:395,t:1527265022894};\\\", \\\"{x:454,y:404,t:1527265022906};\\\", \\\"{x:449,y:423,t:1527265022924};\\\", \\\"{x:446,y:443,t:1527265022940};\\\", \\\"{x:445,y:463,t:1527265022956};\\\", \\\"{x:446,y:489,t:1527265022974};\\\", \\\"{x:451,y:505,t:1527265022989};\\\", \\\"{x:453,y:513,t:1527265023005};\\\", \\\"{x:455,y:515,t:1527265023022};\\\", \\\"{x:456,y:512,t:1527265023126};\\\", \\\"{x:456,y:509,t:1527265023138};\\\", \\\"{x:461,y:496,t:1527265023155};\\\", \\\"{x:463,y:485,t:1527265023174};\\\", \\\"{x:463,y:479,t:1527265023187};\\\", \\\"{x:464,y:475,t:1527265023206};\\\", \\\"{x:464,y:472,t:1527265023223};\\\", \\\"{x:464,y:470,t:1527265023240};\\\", \\\"{x:464,y:468,t:1527265023257};\\\", \\\"{x:465,y:467,t:1527265023374};\\\", \\\"{x:472,y:463,t:1527265023390};\\\", \\\"{x:483,y:458,t:1527265023407};\\\", \\\"{x:492,y:457,t:1527265023425};\\\", \\\"{x:501,y:456,t:1527265023440};\\\", \\\"{x:506,y:455,t:1527265023457};\\\", \\\"{x:508,y:454,t:1527265023474};\\\", \\\"{x:510,y:454,t:1527265023501};\\\", \\\"{x:510,y:453,t:1527265023525};\\\", \\\"{x:511,y:453,t:1527265023557};\\\", \\\"{x:510,y:453,t:1527265023806};\\\", \\\"{x:509,y:453,t:1527265023821};\\\", \\\"{x:507,y:453,t:1527265023829};\\\", \\\"{x:505,y:453,t:1527265023845};\\\", \\\"{x:504,y:453,t:1527265023857};\\\", \\\"{x:500,y:453,t:1527265023874};\\\", \\\"{x:494,y:453,t:1527265023890};\\\", \\\"{x:490,y:453,t:1527265023907};\\\", \\\"{x:487,y:453,t:1527265023925};\\\", \\\"{x:485,y:453,t:1527265023941};\\\", \\\"{x:484,y:453,t:1527265023958};\\\", \\\"{x:484,y:452,t:1527265024165};\\\", \\\"{x:485,y:452,t:1527265024174};\\\", \\\"{x:486,y:451,t:1527265024191};\\\", \\\"{x:488,y:450,t:1527265024207};\\\", \\\"{x:489,y:450,t:1527265024224};\\\", \\\"{x:490,y:449,t:1527265024241};\\\", \\\"{x:492,y:449,t:1527265024258};\\\", \\\"{x:493,y:448,t:1527265024277};\\\", \\\"{x:494,y:448,t:1527265024293};\\\", \\\"{x:495,y:448,t:1527265024373};\\\", \\\"{x:498,y:448,t:1527265024493};\\\", \\\"{x:503,y:448,t:1527265024508};\\\", \\\"{x:518,y:448,t:1527265024524};\\\", \\\"{x:550,y:451,t:1527265024540};\\\", \\\"{x:574,y:452,t:1527265024558};\\\", \\\"{x:598,y:452,t:1527265024574};\\\", \\\"{x:622,y:452,t:1527265024590};\\\", \\\"{x:645,y:452,t:1527265024608};\\\", \\\"{x:661,y:452,t:1527265024624};\\\", \\\"{x:671,y:452,t:1527265024640};\\\", \\\"{x:678,y:452,t:1527265024658};\\\", \\\"{x:684,y:452,t:1527265024674};\\\", \\\"{x:689,y:451,t:1527265024691};\\\", \\\"{x:690,y:451,t:1527265024708};\\\", \\\"{x:693,y:450,t:1527265024724};\\\", \\\"{x:695,y:450,t:1527265024741};\\\", \\\"{x:699,y:450,t:1527265024757};\\\", \\\"{x:701,y:449,t:1527265024774};\\\", \\\"{x:703,y:448,t:1527265024791};\\\", \\\"{x:705,y:448,t:1527265024808};\\\", \\\"{x:706,y:448,t:1527265024828};\\\", \\\"{x:708,y:448,t:1527265024841};\\\", \\\"{x:709,y:448,t:1527265024857};\\\", \\\"{x:709,y:448,t:1527265025199};\\\", \\\"{x:717,y:448,t:1527265025318};\\\", \\\"{x:756,y:441,t:1527265025325};\\\", \\\"{x:889,y:441,t:1527265025343};\\\", \\\"{x:1033,y:441,t:1527265025359};\\\", \\\"{x:1193,y:441,t:1527265025375};\\\", \\\"{x:1370,y:441,t:1527265025392};\\\", \\\"{x:1525,y:439,t:1527265025409};\\\", \\\"{x:1631,y:439,t:1527265025426};\\\", \\\"{x:1697,y:445,t:1527265025442};\\\", \\\"{x:1714,y:459,t:1527265025459};\\\", \\\"{x:1716,y:474,t:1527265025475};\\\", \\\"{x:1716,y:498,t:1527265025492};\\\", \\\"{x:1705,y:540,t:1527265025508};\\\", \\\"{x:1680,y:650,t:1527265025525};\\\", \\\"{x:1669,y:739,t:1527265025543};\\\", \\\"{x:1668,y:758,t:1527265025559};\\\", \\\"{x:1668,y:760,t:1527265025576};\\\", \\\"{x:1665,y:761,t:1527265026126};\\\", \\\"{x:1663,y:763,t:1527265026143};\\\", \\\"{x:1616,y:770,t:1527265026160};\\\", \\\"{x:1538,y:781,t:1527265026175};\\\", \\\"{x:1458,y:804,t:1527265026192};\\\", \\\"{x:1366,y:833,t:1527265026209};\\\", \\\"{x:1292,y:861,t:1527265026225};\\\", \\\"{x:1234,y:877,t:1527265026243};\\\", \\\"{x:1172,y:894,t:1527265026260};\\\", \\\"{x:1122,y:910,t:1527265026275};\\\", \\\"{x:1083,y:920,t:1527265026293};\\\", \\\"{x:1030,y:931,t:1527265026309};\\\", \\\"{x:1007,y:936,t:1527265026326};\\\", \\\"{x:998,y:939,t:1527265026342};\\\", \\\"{x:990,y:940,t:1527265026360};\\\", \\\"{x:986,y:941,t:1527265026376};\\\", \\\"{x:985,y:941,t:1527265026393};\\\", \\\"{x:985,y:940,t:1527265026413};\\\", \\\"{x:989,y:936,t:1527265026425};\\\", \\\"{x:1011,y:923,t:1527265026442};\\\", \\\"{x:1037,y:906,t:1527265026459};\\\", \\\"{x:1058,y:890,t:1527265026476};\\\", \\\"{x:1082,y:861,t:1527265026492};\\\", \\\"{x:1108,y:830,t:1527265026509};\\\", \\\"{x:1124,y:816,t:1527265026526};\\\", \\\"{x:1135,y:804,t:1527265026543};\\\", \\\"{x:1139,y:800,t:1527265026559};\\\", \\\"{x:1140,y:800,t:1527265026576};\\\", \\\"{x:1141,y:799,t:1527265026605};\\\", \\\"{x:1142,y:798,t:1527265026677};\\\", \\\"{x:1143,y:797,t:1527265026693};\\\", \\\"{x:1147,y:793,t:1527265026710};\\\", \\\"{x:1149,y:790,t:1527265026726};\\\", \\\"{x:1156,y:785,t:1527265026742};\\\", \\\"{x:1164,y:778,t:1527265026759};\\\", \\\"{x:1176,y:769,t:1527265026776};\\\", \\\"{x:1187,y:757,t:1527265026792};\\\", \\\"{x:1201,y:739,t:1527265026809};\\\", \\\"{x:1215,y:724,t:1527265026826};\\\", \\\"{x:1217,y:719,t:1527265026842};\\\", \\\"{x:1218,y:717,t:1527265026859};\\\", \\\"{x:1216,y:723,t:1527265026908};\\\", \\\"{x:1215,y:742,t:1527265026926};\\\", \\\"{x:1215,y:770,t:1527265026943};\\\", \\\"{x:1223,y:791,t:1527265026959};\\\", \\\"{x:1226,y:805,t:1527265026976};\\\", \\\"{x:1226,y:810,t:1527265026994};\\\", \\\"{x:1226,y:815,t:1527265027010};\\\", \\\"{x:1226,y:818,t:1527265027026};\\\", \\\"{x:1225,y:818,t:1527265027149};\\\", \\\"{x:1224,y:818,t:1527265027165};\\\", \\\"{x:1224,y:817,t:1527265027181};\\\", \\\"{x:1224,y:814,t:1527265027194};\\\", \\\"{x:1224,y:806,t:1527265027210};\\\", \\\"{x:1224,y:794,t:1527265027227};\\\", \\\"{x:1224,y:770,t:1527265027243};\\\", \\\"{x:1224,y:748,t:1527265027259};\\\", \\\"{x:1224,y:735,t:1527265027277};\\\", \\\"{x:1224,y:726,t:1527265027294};\\\", \\\"{x:1224,y:723,t:1527265027310};\\\", \\\"{x:1224,y:722,t:1527265027326};\\\", \\\"{x:1224,y:721,t:1527265027348};\\\", \\\"{x:1224,y:720,t:1527265027359};\\\", \\\"{x:1224,y:717,t:1527265027376};\\\", \\\"{x:1224,y:712,t:1527265027393};\\\", \\\"{x:1224,y:705,t:1527265027410};\\\", \\\"{x:1224,y:694,t:1527265027426};\\\", \\\"{x:1224,y:680,t:1527265027443};\\\", \\\"{x:1224,y:667,t:1527265027460};\\\", \\\"{x:1224,y:661,t:1527265027477};\\\", \\\"{x:1224,y:659,t:1527265027501};\\\", \\\"{x:1224,y:658,t:1527265027524};\\\", \\\"{x:1224,y:656,t:1527265027557};\\\", \\\"{x:1224,y:655,t:1527265027630};\\\", \\\"{x:1224,y:653,t:1527265027662};\\\", \\\"{x:1223,y:653,t:1527265027742};\\\", \\\"{x:1220,y:656,t:1527265027750};\\\", \\\"{x:1217,y:662,t:1527265027761};\\\", \\\"{x:1215,y:668,t:1527265027777};\\\", \\\"{x:1213,y:673,t:1527265027793};\\\", \\\"{x:1212,y:676,t:1527265027810};\\\", \\\"{x:1212,y:681,t:1527265027827};\\\", \\\"{x:1212,y:688,t:1527265027844};\\\", \\\"{x:1210,y:702,t:1527265027861};\\\", \\\"{x:1206,y:724,t:1527265027877};\\\", \\\"{x:1205,y:740,t:1527265027894};\\\", \\\"{x:1201,y:754,t:1527265027911};\\\", \\\"{x:1198,y:764,t:1527265027928};\\\", \\\"{x:1196,y:782,t:1527265027944};\\\", \\\"{x:1195,y:799,t:1527265027960};\\\", \\\"{x:1195,y:814,t:1527265027977};\\\", \\\"{x:1198,y:830,t:1527265027994};\\\", \\\"{x:1202,y:839,t:1527265028011};\\\", \\\"{x:1203,y:844,t:1527265028027};\\\", \\\"{x:1206,y:848,t:1527265028043};\\\", \\\"{x:1207,y:850,t:1527265028061};\\\", \\\"{x:1207,y:852,t:1527265028078};\\\", \\\"{x:1207,y:854,t:1527265028121};\\\", \\\"{x:1208,y:855,t:1527265028148};\\\", \\\"{x:1208,y:853,t:1527265028180};\\\", \\\"{x:1208,y:850,t:1527265028193};\\\", \\\"{x:1207,y:837,t:1527265028210};\\\", \\\"{x:1197,y:816,t:1527265028227};\\\", \\\"{x:1177,y:788,t:1527265028243};\\\", \\\"{x:1150,y:751,t:1527265028260};\\\", \\\"{x:1139,y:741,t:1527265028276};\\\", \\\"{x:1130,y:736,t:1527265028293};\\\", \\\"{x:1131,y:735,t:1527265028421};\\\", \\\"{x:1131,y:734,t:1527265028429};\\\", \\\"{x:1132,y:734,t:1527265028444};\\\", \\\"{x:1137,y:734,t:1527265028460};\\\", \\\"{x:1145,y:733,t:1527265028477};\\\", \\\"{x:1150,y:733,t:1527265028494};\\\", \\\"{x:1158,y:735,t:1527265028510};\\\", \\\"{x:1163,y:738,t:1527265028528};\\\", \\\"{x:1169,y:741,t:1527265028544};\\\", \\\"{x:1170,y:743,t:1527265028561};\\\", \\\"{x:1170,y:744,t:1527265028578};\\\", \\\"{x:1170,y:745,t:1527265028595};\\\", \\\"{x:1170,y:746,t:1527265028613};\\\", \\\"{x:1170,y:747,t:1527265028645};\\\", \\\"{x:1171,y:749,t:1527265029117};\\\", \\\"{x:1172,y:749,t:1527265029127};\\\", \\\"{x:1173,y:750,t:1527265029144};\\\", \\\"{x:1175,y:750,t:1527265029188};\\\", \\\"{x:1176,y:751,t:1527265029341};\\\", \\\"{x:1176,y:752,t:1527265029437};\\\", \\\"{x:1176,y:754,t:1527265029453};\\\", \\\"{x:1176,y:755,t:1527265029461};\\\", \\\"{x:1176,y:757,t:1527265029477};\\\", \\\"{x:1176,y:760,t:1527265029497};\\\", \\\"{x:1177,y:764,t:1527265029511};\\\", \\\"{x:1178,y:766,t:1527265029528};\\\", \\\"{x:1179,y:768,t:1527265029544};\\\", \\\"{x:1181,y:769,t:1527265029561};\\\", \\\"{x:1182,y:769,t:1527265029807};\\\", \\\"{x:1183,y:769,t:1527265029821};\\\", \\\"{x:1184,y:769,t:1527265029837};\\\", \\\"{x:1186,y:769,t:1527265029862};\\\", \\\"{x:1186,y:768,t:1527265029878};\\\", \\\"{x:1186,y:767,t:1527265031022};\\\", \\\"{x:1186,y:766,t:1527265031030};\\\", \\\"{x:1186,y:765,t:1527265031046};\\\", \\\"{x:1186,y:763,t:1527265031063};\\\", \\\"{x:1186,y:762,t:1527265031079};\\\", \\\"{x:1186,y:761,t:1527265039142};\\\", \\\"{x:1182,y:761,t:1527265039151};\\\", \\\"{x:1167,y:759,t:1527265039169};\\\", \\\"{x:1155,y:757,t:1527265039186};\\\", \\\"{x:1142,y:753,t:1527265039202};\\\", \\\"{x:1130,y:750,t:1527265039219};\\\", \\\"{x:1117,y:746,t:1527265039235};\\\", \\\"{x:1102,y:743,t:1527265039251};\\\", \\\"{x:1078,y:736,t:1527265039269};\\\", \\\"{x:1007,y:719,t:1527265039285};\\\", \\\"{x:912,y:698,t:1527265039301};\\\", \\\"{x:793,y:669,t:1527265039317};\\\", \\\"{x:675,y:639,t:1527265039334};\\\", \\\"{x:575,y:612,t:1527265039351};\\\", \\\"{x:508,y:592,t:1527265039367};\\\", \\\"{x:481,y:585,t:1527265039385};\\\", \\\"{x:468,y:582,t:1527265039402};\\\", \\\"{x:464,y:582,t:1527265039419};\\\", \\\"{x:457,y:582,t:1527265039436};\\\", \\\"{x:447,y:582,t:1527265039453};\\\", \\\"{x:433,y:580,t:1527265039469};\\\", \\\"{x:418,y:576,t:1527265039487};\\\", \\\"{x:401,y:572,t:1527265039502};\\\", \\\"{x:387,y:567,t:1527265039519};\\\", \\\"{x:378,y:565,t:1527265039537};\\\", \\\"{x:375,y:562,t:1527265039553};\\\", \\\"{x:374,y:562,t:1527265039588};\\\", \\\"{x:374,y:561,t:1527265039603};\\\", \\\"{x:373,y:559,t:1527265039620};\\\", \\\"{x:372,y:556,t:1527265039636};\\\", \\\"{x:372,y:555,t:1527265039661};\\\", \\\"{x:372,y:554,t:1527265039670};\\\", \\\"{x:372,y:552,t:1527265039686};\\\", \\\"{x:372,y:548,t:1527265039703};\\\", \\\"{x:373,y:541,t:1527265039720};\\\", \\\"{x:375,y:532,t:1527265039737};\\\", \\\"{x:376,y:523,t:1527265039754};\\\", \\\"{x:376,y:516,t:1527265039771};\\\", \\\"{x:376,y:509,t:1527265039786};\\\", \\\"{x:376,y:505,t:1527265039804};\\\", \\\"{x:376,y:504,t:1527265039819};\\\", \\\"{x:377,y:504,t:1527265039837};\\\", \\\"{x:376,y:503,t:1527265039861};\\\", \\\"{x:372,y:501,t:1527265039871};\\\", \\\"{x:353,y:500,t:1527265039886};\\\", \\\"{x:320,y:499,t:1527265039904};\\\", \\\"{x:261,y:491,t:1527265039921};\\\", \\\"{x:200,y:482,t:1527265039937};\\\", \\\"{x:157,y:475,t:1527265039953};\\\", \\\"{x:134,y:471,t:1527265039970};\\\", \\\"{x:123,y:470,t:1527265039987};\\\", \\\"{x:122,y:469,t:1527265040004};\\\", \\\"{x:121,y:469,t:1527265040077};\\\", \\\"{x:120,y:469,t:1527265040093};\\\", \\\"{x:120,y:470,t:1527265040109};\\\", \\\"{x:120,y:471,t:1527265040120};\\\", \\\"{x:120,y:478,t:1527265040137};\\\", \\\"{x:120,y:486,t:1527265040153};\\\", \\\"{x:132,y:497,t:1527265040170};\\\", \\\"{x:152,y:505,t:1527265040186};\\\", \\\"{x:177,y:513,t:1527265040204};\\\", \\\"{x:202,y:520,t:1527265040221};\\\", \\\"{x:207,y:520,t:1527265040237};\\\", \\\"{x:208,y:520,t:1527265040350};\\\", \\\"{x:208,y:519,t:1527265040357};\\\", \\\"{x:207,y:515,t:1527265040372};\\\", \\\"{x:198,y:509,t:1527265040386};\\\", \\\"{x:186,y:502,t:1527265040404};\\\", \\\"{x:172,y:495,t:1527265040421};\\\", \\\"{x:168,y:494,t:1527265040437};\\\", \\\"{x:166,y:493,t:1527265040454};\\\", \\\"{x:167,y:493,t:1527265040764};\\\", \\\"{x:172,y:493,t:1527265040772};\\\", \\\"{x:181,y:497,t:1527265040788};\\\", \\\"{x:250,y:532,t:1527265040805};\\\", \\\"{x:330,y:568,t:1527265040821};\\\", \\\"{x:413,y:609,t:1527265040839};\\\", \\\"{x:493,y:643,t:1527265040855};\\\", \\\"{x:516,y:663,t:1527265040871};\\\", \\\"{x:532,y:681,t:1527265040888};\\\", \\\"{x:534,y:688,t:1527265040904};\\\", \\\"{x:534,y:691,t:1527265040920};\\\", \\\"{x:534,y:692,t:1527265040938};\\\", \\\"{x:534,y:693,t:1527265040953};\\\", \\\"{x:533,y:694,t:1527265040971};\\\", \\\"{x:523,y:698,t:1527265040987};\\\", \\\"{x:519,y:699,t:1527265041004};\\\", \\\"{x:516,y:699,t:1527265041020};\\\", \\\"{x:501,y:696,t:1527265041038};\\\", \\\"{x:486,y:689,t:1527265041053};\\\", \\\"{x:476,y:687,t:1527265041070};\\\", \\\"{x:471,y:686,t:1527265041087};\\\", \\\"{x:470,y:685,t:1527265041104};\\\", \\\"{x:470,y:688,t:1527265041149};\\\", \\\"{x:472,y:693,t:1527265041157};\\\", \\\"{x:473,y:696,t:1527265041171};\\\", \\\"{x:476,y:705,t:1527265041188};\\\", \\\"{x:481,y:717,t:1527265041203};\\\", \\\"{x:488,y:736,t:1527265041221};\\\", \\\"{x:490,y:739,t:1527265041237};\\\", \\\"{x:491,y:740,t:1527265041301};\\\", \\\"{x:490,y:740,t:1527265041460};\\\", \\\"{x:490,y:739,t:1527265041472};\\\", \\\"{x:490,y:738,t:1527265041492};\\\", \\\"{x:491,y:738,t:1527265041508};\\\", \\\"{x:491,y:737,t:1527265041522};\\\", \\\"{x:493,y:737,t:1527265041538};\\\", \\\"{x:494,y:737,t:1527265041555};\\\", \\\"{x:496,y:737,t:1527265041571};\\\", \\\"{x:498,y:737,t:1527265041589};\\\", \\\"{x:499,y:737,t:1527265041605};\\\", \\\"{x:500,y:737,t:1527265041622};\\\", \\\"{x:501,y:737,t:1527265041638};\\\", \\\"{x:502,y:737,t:1527265041655};\\\", \\\"{x:503,y:737,t:1527265041701};\\\", \\\"{x:504,y:737,t:1527265041724};\\\", \\\"{x:506,y:738,t:1527265041739};\\\", \\\"{x:507,y:739,t:1527265041773};\\\", \\\"{x:508,y:739,t:1527265041788};\\\", \\\"{x:509,y:740,t:1527265041805};\\\", \\\"{x:510,y:740,t:1527265041822};\\\", \\\"{x:511,y:740,t:1527265041839};\\\", \\\"{x:512,y:740,t:1527265041855};\\\", \\\"{x:514,y:740,t:1527265041872};\\\", \\\"{x:516,y:741,t:1527265041889};\\\", \\\"{x:519,y:745,t:1527265041905};\\\", \\\"{x:523,y:752,t:1527265041922};\\\", \\\"{x:527,y:759,t:1527265041939};\\\" ] }, { \\\"rt\\\": 51647, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 679400, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B -F -B -X -X -O -O -O -03 PM-O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:759,t:1527265044772};\\\", \\\"{x:529,y:759,t:1527265044781};\\\", \\\"{x:530,y:759,t:1527265044805};\\\", \\\"{x:531,y:759,t:1527265044859};\\\", \\\"{x:533,y:759,t:1527265044876};\\\", \\\"{x:535,y:758,t:1527265044890};\\\", \\\"{x:542,y:756,t:1527265044908};\\\", \\\"{x:559,y:751,t:1527265044924};\\\", \\\"{x:599,y:746,t:1527265044941};\\\", \\\"{x:630,y:742,t:1527265044957};\\\", \\\"{x:678,y:736,t:1527265044974};\\\", \\\"{x:745,y:726,t:1527265044990};\\\", \\\"{x:834,y:712,t:1527265045007};\\\", \\\"{x:920,y:703,t:1527265045023};\\\", \\\"{x:1017,y:699,t:1527265045041};\\\", \\\"{x:1109,y:699,t:1527265045057};\\\", \\\"{x:1198,y:699,t:1527265045074};\\\", \\\"{x:1265,y:699,t:1527265045090};\\\", \\\"{x:1304,y:699,t:1527265045107};\\\", \\\"{x:1327,y:699,t:1527265045124};\\\", \\\"{x:1346,y:699,t:1527265045142};\\\", \\\"{x:1356,y:700,t:1527265045158};\\\", \\\"{x:1372,y:702,t:1527265045174};\\\", \\\"{x:1394,y:702,t:1527265045191};\\\", \\\"{x:1411,y:702,t:1527265045208};\\\", \\\"{x:1423,y:702,t:1527265045224};\\\", \\\"{x:1427,y:702,t:1527265045241};\\\", \\\"{x:1428,y:703,t:1527265045258};\\\", \\\"{x:1427,y:703,t:1527265045333};\\\", \\\"{x:1426,y:703,t:1527265045349};\\\", \\\"{x:1425,y:703,t:1527265045397};\\\", \\\"{x:1425,y:704,t:1527265045409};\\\", \\\"{x:1423,y:702,t:1527265045424};\\\", \\\"{x:1420,y:700,t:1527265045441};\\\", \\\"{x:1420,y:699,t:1527265045461};\\\", \\\"{x:1420,y:701,t:1527265045740};\\\", \\\"{x:1420,y:705,t:1527265045758};\\\", \\\"{x:1413,y:713,t:1527265045775};\\\", \\\"{x:1405,y:718,t:1527265045791};\\\", \\\"{x:1396,y:723,t:1527265045808};\\\", \\\"{x:1381,y:728,t:1527265045825};\\\", \\\"{x:1372,y:729,t:1527265045841};\\\", \\\"{x:1367,y:732,t:1527265045858};\\\", \\\"{x:1362,y:732,t:1527265045875};\\\", \\\"{x:1361,y:733,t:1527265045891};\\\", \\\"{x:1359,y:735,t:1527265045908};\\\", \\\"{x:1358,y:733,t:1527265046069};\\\", \\\"{x:1358,y:732,t:1527265046077};\\\", \\\"{x:1357,y:731,t:1527265046093};\\\", \\\"{x:1356,y:730,t:1527265046109};\\\", \\\"{x:1355,y:728,t:1527265046125};\\\", \\\"{x:1353,y:726,t:1527265046142};\\\", \\\"{x:1351,y:724,t:1527265046158};\\\", \\\"{x:1350,y:722,t:1527265046175};\\\", \\\"{x:1350,y:719,t:1527265046192};\\\", \\\"{x:1348,y:716,t:1527265046209};\\\", \\\"{x:1348,y:713,t:1527265046225};\\\", \\\"{x:1348,y:710,t:1527265046242};\\\", \\\"{x:1348,y:708,t:1527265046258};\\\", \\\"{x:1348,y:707,t:1527265046275};\\\", \\\"{x:1348,y:702,t:1527265046293};\\\", \\\"{x:1349,y:698,t:1527265046308};\\\", \\\"{x:1349,y:697,t:1527265046326};\\\", \\\"{x:1349,y:700,t:1527265046389};\\\", \\\"{x:1347,y:710,t:1527265046398};\\\", \\\"{x:1347,y:722,t:1527265046409};\\\", \\\"{x:1344,y:747,t:1527265046426};\\\", \\\"{x:1340,y:776,t:1527265046443};\\\", \\\"{x:1340,y:800,t:1527265046459};\\\", \\\"{x:1340,y:814,t:1527265046475};\\\", \\\"{x:1340,y:819,t:1527265046492};\\\", \\\"{x:1340,y:821,t:1527265046508};\\\", \\\"{x:1340,y:819,t:1527265046573};\\\", \\\"{x:1340,y:816,t:1527265046590};\\\", \\\"{x:1341,y:813,t:1527265046598};\\\", \\\"{x:1341,y:809,t:1527265046608};\\\", \\\"{x:1341,y:801,t:1527265046626};\\\", \\\"{x:1341,y:793,t:1527265046643};\\\", \\\"{x:1341,y:782,t:1527265046659};\\\", \\\"{x:1341,y:769,t:1527265046675};\\\", \\\"{x:1341,y:750,t:1527265046693};\\\", \\\"{x:1341,y:742,t:1527265046708};\\\", \\\"{x:1340,y:730,t:1527265046725};\\\", \\\"{x:1339,y:729,t:1527265046743};\\\", \\\"{x:1340,y:728,t:1527265046854};\\\", \\\"{x:1341,y:727,t:1527265046910};\\\", \\\"{x:1343,y:725,t:1527265046925};\\\", \\\"{x:1345,y:723,t:1527265046943};\\\", \\\"{x:1347,y:720,t:1527265046959};\\\", \\\"{x:1351,y:715,t:1527265046975};\\\", \\\"{x:1351,y:712,t:1527265046992};\\\", \\\"{x:1352,y:711,t:1527265047010};\\\", \\\"{x:1353,y:710,t:1527265047025};\\\", \\\"{x:1353,y:711,t:1527265047069};\\\", \\\"{x:1353,y:713,t:1527265047077};\\\", \\\"{x:1353,y:717,t:1527265047092};\\\", \\\"{x:1353,y:730,t:1527265047109};\\\", \\\"{x:1353,y:738,t:1527265047125};\\\", \\\"{x:1353,y:747,t:1527265047143};\\\", \\\"{x:1353,y:752,t:1527265047160};\\\", \\\"{x:1353,y:755,t:1527265047176};\\\", \\\"{x:1354,y:757,t:1527265047193};\\\", \\\"{x:1353,y:756,t:1527265047373};\\\", \\\"{x:1353,y:754,t:1527265047381};\\\", \\\"{x:1352,y:752,t:1527265047392};\\\", \\\"{x:1349,y:747,t:1527265047410};\\\", \\\"{x:1348,y:740,t:1527265047427};\\\", \\\"{x:1344,y:728,t:1527265047442};\\\", \\\"{x:1341,y:716,t:1527265047460};\\\", \\\"{x:1340,y:706,t:1527265047476};\\\", \\\"{x:1340,y:701,t:1527265047493};\\\", \\\"{x:1340,y:695,t:1527265047510};\\\", \\\"{x:1339,y:691,t:1527265047526};\\\", \\\"{x:1339,y:690,t:1527265047542};\\\", \\\"{x:1339,y:689,t:1527265047560};\\\", \\\"{x:1339,y:688,t:1527265047581};\\\", \\\"{x:1340,y:688,t:1527265047758};\\\", \\\"{x:1341,y:688,t:1527265047765};\\\", \\\"{x:1341,y:689,t:1527265047781};\\\", \\\"{x:1342,y:691,t:1527265047794};\\\", \\\"{x:1343,y:693,t:1527265047809};\\\", \\\"{x:1344,y:694,t:1527265047826};\\\", \\\"{x:1346,y:696,t:1527265047843};\\\", \\\"{x:1347,y:697,t:1527265047860};\\\", \\\"{x:1347,y:698,t:1527265047876};\\\", \\\"{x:1347,y:699,t:1527265048142};\\\", \\\"{x:1347,y:700,t:1527265048149};\\\", \\\"{x:1347,y:701,t:1527265048159};\\\", \\\"{x:1348,y:705,t:1527265048177};\\\", \\\"{x:1348,y:708,t:1527265048193};\\\", \\\"{x:1348,y:714,t:1527265048209};\\\", \\\"{x:1348,y:719,t:1527265048226};\\\", \\\"{x:1350,y:724,t:1527265048244};\\\", \\\"{x:1351,y:727,t:1527265048260};\\\", \\\"{x:1351,y:733,t:1527265048277};\\\", \\\"{x:1351,y:736,t:1527265048293};\\\", \\\"{x:1352,y:740,t:1527265048311};\\\", \\\"{x:1354,y:744,t:1527265048327};\\\", \\\"{x:1355,y:748,t:1527265048343};\\\", \\\"{x:1357,y:750,t:1527265048360};\\\", \\\"{x:1357,y:751,t:1527265048376};\\\", \\\"{x:1357,y:752,t:1527265048394};\\\", \\\"{x:1358,y:754,t:1527265048411};\\\", \\\"{x:1358,y:755,t:1527265048426};\\\", \\\"{x:1358,y:756,t:1527265048444};\\\", \\\"{x:1358,y:757,t:1527265048460};\\\", \\\"{x:1357,y:757,t:1527265048597};\\\", \\\"{x:1356,y:757,t:1527265048646};\\\", \\\"{x:1355,y:757,t:1527265049038};\\\", \\\"{x:1354,y:758,t:1527265049061};\\\", \\\"{x:1354,y:759,t:1527265049078};\\\", \\\"{x:1354,y:760,t:1527265049118};\\\", \\\"{x:1354,y:761,t:1527265049445};\\\", \\\"{x:1353,y:762,t:1527265050197};\\\", \\\"{x:1360,y:760,t:1527265084604};\\\", \\\"{x:1407,y:742,t:1527265084616};\\\", \\\"{x:1521,y:687,t:1527265084633};\\\", \\\"{x:1552,y:634,t:1527265084649};\\\", \\\"{x:1552,y:594,t:1527265084666};\\\", \\\"{x:1556,y:587,t:1527265084682};\\\", \\\"{x:1557,y:586,t:1527265084754};\\\", \\\"{x:1557,y:585,t:1527265084786};\\\", \\\"{x:1556,y:584,t:1527265084798};\\\", \\\"{x:1529,y:585,t:1527265084816};\\\", \\\"{x:1428,y:639,t:1527265084833};\\\", \\\"{x:1307,y:692,t:1527265084848};\\\", \\\"{x:1113,y:747,t:1527265084866};\\\", \\\"{x:963,y:771,t:1527265084883};\\\", \\\"{x:804,y:782,t:1527265084898};\\\", \\\"{x:645,y:775,t:1527265084916};\\\", \\\"{x:508,y:749,t:1527265084934};\\\", \\\"{x:402,y:712,t:1527265084950};\\\", \\\"{x:316,y:689,t:1527265084965};\\\", \\\"{x:251,y:674,t:1527265084987};\\\", \\\"{x:231,y:672,t:1527265085004};\\\", \\\"{x:224,y:672,t:1527265085021};\\\", \\\"{x:222,y:678,t:1527265085037};\\\", \\\"{x:222,y:689,t:1527265085054};\\\", \\\"{x:224,y:695,t:1527265085071};\\\", \\\"{x:232,y:695,t:1527265085087};\\\", \\\"{x:241,y:692,t:1527265085104};\\\", \\\"{x:264,y:676,t:1527265085122};\\\", \\\"{x:287,y:654,t:1527265085138};\\\", \\\"{x:311,y:632,t:1527265085155};\\\", \\\"{x:340,y:608,t:1527265085172};\\\", \\\"{x:358,y:592,t:1527265085189};\\\", \\\"{x:371,y:584,t:1527265085205};\\\", \\\"{x:380,y:579,t:1527265085221};\\\", \\\"{x:383,y:577,t:1527265085237};\\\", \\\"{x:384,y:577,t:1527265085255};\\\", \\\"{x:386,y:576,t:1527265085271};\\\", \\\"{x:387,y:576,t:1527265085289};\\\", \\\"{x:390,y:576,t:1527265085305};\\\", \\\"{x:410,y:584,t:1527265085322};\\\", \\\"{x:438,y:590,t:1527265085338};\\\", \\\"{x:465,y:593,t:1527265085354};\\\", \\\"{x:489,y:594,t:1527265085372};\\\", \\\"{x:507,y:595,t:1527265085387};\\\", \\\"{x:522,y:596,t:1527265085404};\\\", \\\"{x:536,y:601,t:1527265085422};\\\", \\\"{x:545,y:601,t:1527265085438};\\\", \\\"{x:551,y:601,t:1527265085454};\\\", \\\"{x:556,y:601,t:1527265085471};\\\", \\\"{x:560,y:601,t:1527265085488};\\\", \\\"{x:564,y:601,t:1527265085504};\\\", \\\"{x:571,y:601,t:1527265085521};\\\", \\\"{x:576,y:601,t:1527265085539};\\\", \\\"{x:579,y:599,t:1527265085556};\\\", \\\"{x:582,y:596,t:1527265085571};\\\", \\\"{x:584,y:593,t:1527265085589};\\\", \\\"{x:586,y:592,t:1527265085604};\\\", \\\"{x:591,y:590,t:1527265085621};\\\", \\\"{x:594,y:588,t:1527265085638};\\\", \\\"{x:596,y:588,t:1527265085654};\\\", \\\"{x:597,y:587,t:1527265085706};\\\", \\\"{x:597,y:586,t:1527265085721};\\\", \\\"{x:598,y:586,t:1527265085986};\\\", \\\"{x:610,y:586,t:1527265085994};\\\", \\\"{x:631,y:586,t:1527265086006};\\\", \\\"{x:690,y:594,t:1527265086022};\\\", \\\"{x:765,y:604,t:1527265086039};\\\", \\\"{x:873,y:619,t:1527265086055};\\\", \\\"{x:978,y:637,t:1527265086072};\\\", \\\"{x:1099,y:664,t:1527265086089};\\\", \\\"{x:1262,y:708,t:1527265086105};\\\", \\\"{x:1313,y:724,t:1527265086121};\\\", \\\"{x:1332,y:729,t:1527265086138};\\\", \\\"{x:1334,y:730,t:1527265086156};\\\", \\\"{x:1334,y:731,t:1527265086173};\\\", \\\"{x:1330,y:734,t:1527265086188};\\\", \\\"{x:1324,y:740,t:1527265086206};\\\", \\\"{x:1320,y:745,t:1527265086222};\\\", \\\"{x:1317,y:747,t:1527265086239};\\\", \\\"{x:1307,y:747,t:1527265086255};\\\", \\\"{x:1270,y:744,t:1527265086272};\\\", \\\"{x:1190,y:721,t:1527265086288};\\\", \\\"{x:1002,y:673,t:1527265086305};\\\", \\\"{x:853,y:631,t:1527265086323};\\\", \\\"{x:731,y:593,t:1527265086339};\\\", \\\"{x:651,y:573,t:1527265086355};\\\", \\\"{x:629,y:566,t:1527265086372};\\\", \\\"{x:625,y:565,t:1527265086388};\\\", \\\"{x:624,y:564,t:1527265086449};\\\", \\\"{x:624,y:566,t:1527265086563};\\\", \\\"{x:624,y:567,t:1527265086641};\\\", \\\"{x:623,y:567,t:1527265086655};\\\", \\\"{x:622,y:569,t:1527265086673};\\\", \\\"{x:622,y:570,t:1527265086689};\\\", \\\"{x:621,y:571,t:1527265086721};\\\", \\\"{x:624,y:575,t:1527265087138};\\\", \\\"{x:630,y:581,t:1527265087146};\\\", \\\"{x:647,y:590,t:1527265087157};\\\", \\\"{x:720,y:628,t:1527265087173};\\\", \\\"{x:865,y:683,t:1527265087190};\\\", \\\"{x:1040,y:742,t:1527265087207};\\\", \\\"{x:1234,y:802,t:1527265087223};\\\", \\\"{x:1413,y:852,t:1527265087239};\\\", \\\"{x:1547,y:897,t:1527265087256};\\\", \\\"{x:1632,y:933,t:1527265087272};\\\", \\\"{x:1659,y:949,t:1527265087290};\\\", \\\"{x:1660,y:955,t:1527265087306};\\\", \\\"{x:1660,y:967,t:1527265087322};\\\", \\\"{x:1660,y:985,t:1527265087340};\\\", \\\"{x:1659,y:1002,t:1527265087357};\\\", \\\"{x:1658,y:1013,t:1527265087373};\\\", \\\"{x:1657,y:1015,t:1527265087389};\\\", \\\"{x:1657,y:1016,t:1527265087407};\\\", \\\"{x:1657,y:1021,t:1527265087423};\\\", \\\"{x:1657,y:1028,t:1527265087440};\\\", \\\"{x:1657,y:1031,t:1527265087457};\\\", \\\"{x:1655,y:1029,t:1527265087787};\\\", \\\"{x:1647,y:1013,t:1527265087794};\\\", \\\"{x:1628,y:992,t:1527265087807};\\\", \\\"{x:1582,y:958,t:1527265087824};\\\", \\\"{x:1538,y:927,t:1527265087840};\\\", \\\"{x:1510,y:906,t:1527265087857};\\\", \\\"{x:1490,y:890,t:1527265087874};\\\", \\\"{x:1486,y:887,t:1527265087891};\\\", \\\"{x:1485,y:885,t:1527265087907};\\\", \\\"{x:1485,y:883,t:1527265087924};\\\", \\\"{x:1484,y:879,t:1527265087940};\\\", \\\"{x:1481,y:872,t:1527265087957};\\\", \\\"{x:1477,y:865,t:1527265087974};\\\", \\\"{x:1477,y:862,t:1527265087991};\\\", \\\"{x:1477,y:857,t:1527265088007};\\\", \\\"{x:1477,y:853,t:1527265088024};\\\", \\\"{x:1477,y:850,t:1527265088041};\\\", \\\"{x:1477,y:846,t:1527265088057};\\\", \\\"{x:1477,y:843,t:1527265088074};\\\", \\\"{x:1479,y:841,t:1527265088090};\\\", \\\"{x:1480,y:839,t:1527265088107};\\\", \\\"{x:1481,y:837,t:1527265088124};\\\", \\\"{x:1483,y:834,t:1527265088141};\\\", \\\"{x:1484,y:833,t:1527265088157};\\\", \\\"{x:1484,y:832,t:1527265088174};\\\", \\\"{x:1484,y:831,t:1527265088190};\\\", \\\"{x:1484,y:830,t:1527265088207};\\\", \\\"{x:1484,y:829,t:1527265088250};\\\", \\\"{x:1484,y:824,t:1527265088779};\\\", \\\"{x:1485,y:817,t:1527265088791};\\\", \\\"{x:1493,y:799,t:1527265088808};\\\", \\\"{x:1499,y:781,t:1527265088825};\\\", \\\"{x:1507,y:763,t:1527265088841};\\\", \\\"{x:1514,y:749,t:1527265088858};\\\", \\\"{x:1516,y:746,t:1527265088874};\\\", \\\"{x:1517,y:739,t:1527265088891};\\\", \\\"{x:1518,y:738,t:1527265088908};\\\", \\\"{x:1519,y:737,t:1527265088930};\\\", \\\"{x:1520,y:736,t:1527265088986};\\\", \\\"{x:1520,y:737,t:1527265089226};\\\", \\\"{x:1518,y:745,t:1527265089242};\\\", \\\"{x:1516,y:751,t:1527265089257};\\\", \\\"{x:1513,y:758,t:1527265089275};\\\", \\\"{x:1513,y:761,t:1527265089291};\\\", \\\"{x:1513,y:762,t:1527265089308};\\\", \\\"{x:1512,y:765,t:1527265089325};\\\", \\\"{x:1512,y:766,t:1527265089342};\\\", \\\"{x:1512,y:768,t:1527265089358};\\\", \\\"{x:1511,y:772,t:1527265089376};\\\", \\\"{x:1511,y:774,t:1527265089392};\\\", \\\"{x:1510,y:776,t:1527265089408};\\\", \\\"{x:1509,y:779,t:1527265089425};\\\", \\\"{x:1509,y:782,t:1527265089442};\\\", \\\"{x:1508,y:784,t:1527265089458};\\\", \\\"{x:1508,y:786,t:1527265089475};\\\", \\\"{x:1508,y:789,t:1527265089492};\\\", \\\"{x:1508,y:795,t:1527265089508};\\\", \\\"{x:1513,y:802,t:1527265089525};\\\", \\\"{x:1520,y:811,t:1527265089542};\\\", \\\"{x:1529,y:820,t:1527265089558};\\\", \\\"{x:1537,y:827,t:1527265089575};\\\", \\\"{x:1544,y:833,t:1527265089593};\\\", \\\"{x:1550,y:837,t:1527265089608};\\\", \\\"{x:1554,y:841,t:1527265089625};\\\", \\\"{x:1559,y:845,t:1527265089642};\\\", \\\"{x:1562,y:848,t:1527265089659};\\\", \\\"{x:1565,y:852,t:1527265089675};\\\", \\\"{x:1569,y:861,t:1527265089692};\\\", \\\"{x:1572,y:871,t:1527265089709};\\\", \\\"{x:1574,y:886,t:1527265089725};\\\", \\\"{x:1574,y:903,t:1527265089742};\\\", \\\"{x:1576,y:920,t:1527265089759};\\\", \\\"{x:1578,y:936,t:1527265089775};\\\", \\\"{x:1579,y:949,t:1527265089792};\\\", \\\"{x:1579,y:961,t:1527265089809};\\\", \\\"{x:1579,y:971,t:1527265089825};\\\", \\\"{x:1579,y:988,t:1527265089842};\\\", \\\"{x:1579,y:994,t:1527265089858};\\\", \\\"{x:1579,y:997,t:1527265089875};\\\", \\\"{x:1579,y:998,t:1527265089898};\\\", \\\"{x:1579,y:999,t:1527265089909};\\\", \\\"{x:1578,y:1001,t:1527265089925};\\\", \\\"{x:1574,y:1004,t:1527265089942};\\\", \\\"{x:1573,y:1004,t:1527265089959};\\\", \\\"{x:1572,y:1004,t:1527265089975};\\\", \\\"{x:1571,y:1004,t:1527265090010};\\\", \\\"{x:1569,y:1004,t:1527265090025};\\\", \\\"{x:1557,y:996,t:1527265090042};\\\", \\\"{x:1540,y:982,t:1527265090059};\\\", \\\"{x:1527,y:970,t:1527265090074};\\\", \\\"{x:1515,y:960,t:1527265090092};\\\", \\\"{x:1513,y:955,t:1527265090108};\\\", \\\"{x:1515,y:955,t:1527265090177};\\\", \\\"{x:1518,y:955,t:1527265090192};\\\", \\\"{x:1522,y:955,t:1527265090208};\\\", \\\"{x:1526,y:956,t:1527265090226};\\\", \\\"{x:1527,y:956,t:1527265090241};\\\", \\\"{x:1528,y:957,t:1527265090259};\\\", \\\"{x:1529,y:957,t:1527265090275};\\\", \\\"{x:1530,y:957,t:1527265090297};\\\", \\\"{x:1531,y:957,t:1527265090314};\\\", \\\"{x:1532,y:957,t:1527265090330};\\\", \\\"{x:1533,y:957,t:1527265090713};\\\", \\\"{x:1533,y:956,t:1527265091251};\\\", \\\"{x:1533,y:953,t:1527265091261};\\\", \\\"{x:1533,y:946,t:1527265091276};\\\", \\\"{x:1533,y:930,t:1527265091293};\\\", \\\"{x:1533,y:903,t:1527265091309};\\\", \\\"{x:1527,y:871,t:1527265091326};\\\", \\\"{x:1519,y:841,t:1527265091343};\\\", \\\"{x:1510,y:814,t:1527265091360};\\\", \\\"{x:1505,y:794,t:1527265091376};\\\", \\\"{x:1502,y:781,t:1527265091392};\\\", \\\"{x:1501,y:775,t:1527265091409};\\\", \\\"{x:1501,y:770,t:1527265091425};\\\", \\\"{x:1501,y:767,t:1527265091443};\\\", \\\"{x:1501,y:764,t:1527265091460};\\\", \\\"{x:1501,y:762,t:1527265091482};\\\", \\\"{x:1500,y:761,t:1527265091492};\\\", \\\"{x:1499,y:759,t:1527265091510};\\\", \\\"{x:1499,y:758,t:1527265091526};\\\", \\\"{x:1499,y:757,t:1527265091658};\\\", \\\"{x:1499,y:756,t:1527265091674};\\\", \\\"{x:1499,y:754,t:1527265091682};\\\", \\\"{x:1501,y:753,t:1527265091698};\\\", \\\"{x:1502,y:752,t:1527265091711};\\\", \\\"{x:1507,y:749,t:1527265091728};\\\", \\\"{x:1508,y:748,t:1527265091743};\\\", \\\"{x:1511,y:746,t:1527265091761};\\\", \\\"{x:1512,y:746,t:1527265091777};\\\", \\\"{x:1513,y:745,t:1527265091793};\\\", \\\"{x:1515,y:745,t:1527265091947};\\\", \\\"{x:1517,y:745,t:1527265091960};\\\", \\\"{x:1520,y:745,t:1527265091976};\\\", \\\"{x:1537,y:757,t:1527265091993};\\\", \\\"{x:1550,y:763,t:1527265092010};\\\", \\\"{x:1559,y:765,t:1527265092027};\\\", \\\"{x:1565,y:766,t:1527265092044};\\\", \\\"{x:1563,y:766,t:1527265093441};\\\", \\\"{x:1562,y:764,t:1527265093449};\\\", \\\"{x:1561,y:763,t:1527265093561};\\\", \\\"{x:1560,y:763,t:1527265093578};\\\", \\\"{x:1556,y:762,t:1527265093667};\\\", \\\"{x:1546,y:757,t:1527265093678};\\\", \\\"{x:1478,y:739,t:1527265093695};\\\", \\\"{x:1365,y:713,t:1527265093712};\\\", \\\"{x:1258,y:689,t:1527265093728};\\\", \\\"{x:1149,y:668,t:1527265093745};\\\", \\\"{x:902,y:635,t:1527265093762};\\\", \\\"{x:730,y:629,t:1527265093779};\\\", \\\"{x:591,y:629,t:1527265093795};\\\", \\\"{x:440,y:661,t:1527265093828};\\\", \\\"{x:417,y:669,t:1527265093837};\\\", \\\"{x:392,y:679,t:1527265093855};\\\", \\\"{x:379,y:688,t:1527265093871};\\\", \\\"{x:373,y:691,t:1527265093894};\\\", \\\"{x:366,y:695,t:1527265093912};\\\", \\\"{x:357,y:700,t:1527265093928};\\\", \\\"{x:349,y:703,t:1527265093944};\\\", \\\"{x:343,y:706,t:1527265093960};\\\", \\\"{x:343,y:708,t:1527265093978};\\\", \\\"{x:343,y:712,t:1527265093994};\\\", \\\"{x:352,y:716,t:1527265094011};\\\", \\\"{x:374,y:718,t:1527265094029};\\\", \\\"{x:393,y:722,t:1527265094045};\\\", \\\"{x:408,y:722,t:1527265094061};\\\", \\\"{x:417,y:723,t:1527265094079};\\\", \\\"{x:425,y:726,t:1527265094094};\\\", \\\"{x:429,y:729,t:1527265094111};\\\", \\\"{x:437,y:733,t:1527265094129};\\\", \\\"{x:441,y:735,t:1527265094145};\\\", \\\"{x:447,y:737,t:1527265094162};\\\", \\\"{x:449,y:737,t:1527265094179};\\\", \\\"{x:450,y:737,t:1527265094195};\\\", \\\"{x:451,y:737,t:1527265094794};\\\", \\\"{x:452,y:737,t:1527265094818};\\\", \\\"{x:452,y:736,t:1527265094850};\\\", \\\"{x:453,y:735,t:1527265094938};\\\", \\\"{x:454,y:735,t:1527265094969};\\\", \\\"{x:454,y:734,t:1527265094979};\\\", \\\"{x:455,y:734,t:1527265095042};\\\", \\\"{x:455,y:733,t:1527265095074};\\\", \\\"{x:456,y:733,t:1527265095089};\\\", \\\"{x:457,y:732,t:1527265095138};\\\", \\\"{x:458,y:731,t:1527265095177};\\\" ] }, { \\\"rt\\\": 14084, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 694732, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:460,y:725,t:1527265096714};\\\", \\\"{x:467,y:666,t:1527265096738};\\\", \\\"{x:471,y:621,t:1527265096751};\\\", \\\"{x:473,y:556,t:1527265096764};\\\", \\\"{x:473,y:520,t:1527265096781};\\\", \\\"{x:473,y:507,t:1527265096797};\\\", \\\"{x:473,y:504,t:1527265096814};\\\", \\\"{x:473,y:503,t:1527265096914};\\\", \\\"{x:473,y:500,t:1527265096931};\\\", \\\"{x:477,y:499,t:1527265096948};\\\", \\\"{x:482,y:496,t:1527265096964};\\\", \\\"{x:489,y:494,t:1527265096981};\\\", \\\"{x:500,y:489,t:1527265096999};\\\", \\\"{x:515,y:483,t:1527265097014};\\\", \\\"{x:526,y:476,t:1527265097030};\\\", \\\"{x:536,y:471,t:1527265097048};\\\", \\\"{x:547,y:466,t:1527265097063};\\\", \\\"{x:553,y:465,t:1527265097081};\\\", \\\"{x:560,y:463,t:1527265097097};\\\", \\\"{x:563,y:462,t:1527265097114};\\\", \\\"{x:567,y:461,t:1527265097130};\\\", \\\"{x:568,y:461,t:1527265097148};\\\", \\\"{x:571,y:459,t:1527265097163};\\\", \\\"{x:572,y:458,t:1527265097181};\\\", \\\"{x:574,y:458,t:1527265097198};\\\", \\\"{x:576,y:456,t:1527265097214};\\\", \\\"{x:578,y:455,t:1527265097231};\\\", \\\"{x:580,y:454,t:1527265097250};\\\", \\\"{x:582,y:454,t:1527265097264};\\\", \\\"{x:591,y:451,t:1527265097282};\\\", \\\"{x:597,y:451,t:1527265097298};\\\", \\\"{x:600,y:448,t:1527265097314};\\\", \\\"{x:602,y:448,t:1527265097331};\\\", \\\"{x:603,y:448,t:1527265097348};\\\", \\\"{x:607,y:448,t:1527265097364};\\\", \\\"{x:613,y:448,t:1527265097381};\\\", \\\"{x:616,y:448,t:1527265097399};\\\", \\\"{x:618,y:449,t:1527265097415};\\\", \\\"{x:617,y:450,t:1527265097506};\\\", \\\"{x:616,y:451,t:1527265097522};\\\", \\\"{x:615,y:452,t:1527265097531};\\\", \\\"{x:614,y:452,t:1527265097548};\\\", \\\"{x:613,y:452,t:1527265097570};\\\", \\\"{x:611,y:453,t:1527265097582};\\\", \\\"{x:610,y:453,t:1527265097610};\\\", \\\"{x:609,y:454,t:1527265097634};\\\", \\\"{x:604,y:454,t:1527265097810};\\\", \\\"{x:598,y:453,t:1527265097818};\\\", \\\"{x:591,y:450,t:1527265097832};\\\", \\\"{x:580,y:448,t:1527265097848};\\\", \\\"{x:563,y:447,t:1527265097865};\\\", \\\"{x:554,y:447,t:1527265097880};\\\", \\\"{x:548,y:447,t:1527265097897};\\\", \\\"{x:542,y:447,t:1527265097914};\\\", \\\"{x:536,y:447,t:1527265097931};\\\", \\\"{x:530,y:447,t:1527265097947};\\\", \\\"{x:521,y:447,t:1527265097964};\\\", \\\"{x:512,y:447,t:1527265097982};\\\", \\\"{x:500,y:447,t:1527265097998};\\\", \\\"{x:491,y:447,t:1527265098015};\\\", \\\"{x:485,y:447,t:1527265098032};\\\", \\\"{x:480,y:447,t:1527265098048};\\\", \\\"{x:472,y:447,t:1527265098065};\\\", \\\"{x:463,y:447,t:1527265098081};\\\", \\\"{x:458,y:448,t:1527265098098};\\\", \\\"{x:455,y:449,t:1527265098115};\\\", \\\"{x:454,y:449,t:1527265098137};\\\", \\\"{x:459,y:450,t:1527265098410};\\\", \\\"{x:472,y:453,t:1527265098431};\\\", \\\"{x:481,y:454,t:1527265098449};\\\", \\\"{x:486,y:454,t:1527265098465};\\\", \\\"{x:492,y:454,t:1527265098481};\\\", \\\"{x:496,y:454,t:1527265098499};\\\", \\\"{x:500,y:454,t:1527265098514};\\\", \\\"{x:503,y:454,t:1527265098532};\\\", \\\"{x:506,y:454,t:1527265098548};\\\", \\\"{x:508,y:454,t:1527265098565};\\\", \\\"{x:513,y:454,t:1527265098582};\\\", \\\"{x:517,y:454,t:1527265098599};\\\", \\\"{x:523,y:454,t:1527265098614};\\\", \\\"{x:526,y:454,t:1527265098632};\\\", \\\"{x:533,y:454,t:1527265098649};\\\", \\\"{x:542,y:454,t:1527265098665};\\\", \\\"{x:551,y:454,t:1527265098681};\\\", \\\"{x:559,y:454,t:1527265098699};\\\", \\\"{x:562,y:454,t:1527265098715};\\\", \\\"{x:563,y:454,t:1527265098761};\\\", \\\"{x:562,y:454,t:1527265099082};\\\", \\\"{x:561,y:454,t:1527265099130};\\\", \\\"{x:560,y:454,t:1527265099138};\\\", \\\"{x:559,y:454,t:1527265099151};\\\", \\\"{x:557,y:454,t:1527265099354};\\\", \\\"{x:556,y:454,t:1527265099367};\\\", \\\"{x:554,y:454,t:1527265099383};\\\", \\\"{x:553,y:454,t:1527265099399};\\\", \\\"{x:552,y:454,t:1527265099417};\\\", \\\"{x:552,y:454,t:1527265099771};\\\", \\\"{x:582,y:474,t:1527265100451};\\\", \\\"{x:683,y:530,t:1527265100469};\\\", \\\"{x:817,y:609,t:1527265100483};\\\", \\\"{x:960,y:687,t:1527265100500};\\\", \\\"{x:1110,y:765,t:1527265100517};\\\", \\\"{x:1221,y:826,t:1527265100533};\\\", \\\"{x:1297,y:866,t:1527265100550};\\\", \\\"{x:1320,y:892,t:1527265100566};\\\", \\\"{x:1320,y:894,t:1527265100584};\\\", \\\"{x:1322,y:894,t:1527265101171};\\\", \\\"{x:1324,y:894,t:1527265101185};\\\", \\\"{x:1331,y:893,t:1527265101201};\\\", \\\"{x:1334,y:892,t:1527265101217};\\\", \\\"{x:1341,y:892,t:1527265101234};\\\", \\\"{x:1348,y:892,t:1527265101251};\\\", \\\"{x:1354,y:895,t:1527265101267};\\\", \\\"{x:1361,y:899,t:1527265101284};\\\", \\\"{x:1365,y:902,t:1527265101301};\\\", \\\"{x:1368,y:905,t:1527265101317};\\\", \\\"{x:1370,y:910,t:1527265101334};\\\", \\\"{x:1371,y:914,t:1527265101351};\\\", \\\"{x:1371,y:920,t:1527265101367};\\\", \\\"{x:1371,y:926,t:1527265101384};\\\", \\\"{x:1371,y:935,t:1527265101402};\\\", \\\"{x:1371,y:939,t:1527265101417};\\\", \\\"{x:1371,y:940,t:1527265101434};\\\", \\\"{x:1371,y:941,t:1527265101452};\\\", \\\"{x:1370,y:942,t:1527265101474};\\\", \\\"{x:1368,y:943,t:1527265101490};\\\", \\\"{x:1367,y:943,t:1527265101506};\\\", \\\"{x:1366,y:944,t:1527265101518};\\\", \\\"{x:1365,y:944,t:1527265101534};\\\", \\\"{x:1363,y:945,t:1527265101551};\\\", \\\"{x:1361,y:947,t:1527265101569};\\\", \\\"{x:1359,y:949,t:1527265101584};\\\", \\\"{x:1356,y:952,t:1527265101601};\\\", \\\"{x:1352,y:954,t:1527265101618};\\\", \\\"{x:1348,y:958,t:1527265101635};\\\", \\\"{x:1344,y:961,t:1527265101652};\\\", \\\"{x:1340,y:964,t:1527265101669};\\\", \\\"{x:1334,y:968,t:1527265101685};\\\", \\\"{x:1327,y:972,t:1527265101701};\\\", \\\"{x:1326,y:973,t:1527265101719};\\\", \\\"{x:1328,y:972,t:1527265102740};\\\", \\\"{x:1330,y:971,t:1527265102754};\\\", \\\"{x:1332,y:971,t:1527265102778};\\\", \\\"{x:1333,y:971,t:1527265102810};\\\", \\\"{x:1334,y:970,t:1527265102819};\\\", \\\"{x:1335,y:969,t:1527265102906};\\\", \\\"{x:1336,y:968,t:1527265103092};\\\", \\\"{x:1337,y:968,t:1527265103131};\\\", \\\"{x:1338,y:968,t:1527265103138};\\\", \\\"{x:1339,y:968,t:1527265103162};\\\", \\\"{x:1340,y:968,t:1527265103178};\\\", \\\"{x:1341,y:968,t:1527265103195};\\\", \\\"{x:1343,y:966,t:1527265103210};\\\", \\\"{x:1344,y:966,t:1527265103226};\\\", \\\"{x:1345,y:966,t:1527265103242};\\\", \\\"{x:1346,y:966,t:1527265103259};\\\", \\\"{x:1347,y:966,t:1527265103270};\\\", \\\"{x:1348,y:966,t:1527265103290};\\\", \\\"{x:1349,y:966,t:1527265103306};\\\", \\\"{x:1350,y:966,t:1527265103427};\\\", \\\"{x:1351,y:966,t:1527265103437};\\\", \\\"{x:1352,y:966,t:1527265103867};\\\", \\\"{x:1352,y:967,t:1527265103930};\\\", \\\"{x:1351,y:967,t:1527265103987};\\\", \\\"{x:1350,y:967,t:1527265104081};\\\", \\\"{x:1350,y:968,t:1527265104089};\\\", \\\"{x:1349,y:968,t:1527265104137};\\\", \\\"{x:1349,y:969,t:1527265104153};\\\", \\\"{x:1349,y:968,t:1527265104586};\\\", \\\"{x:1349,y:967,t:1527265104618};\\\", \\\"{x:1350,y:966,t:1527265104626};\\\", \\\"{x:1351,y:966,t:1527265104715};\\\", \\\"{x:1352,y:965,t:1527265104778};\\\", \\\"{x:1353,y:965,t:1527265104802};\\\", \\\"{x:1353,y:964,t:1527265104811};\\\", \\\"{x:1354,y:963,t:1527265104826};\\\", \\\"{x:1355,y:962,t:1527265104842};\\\", \\\"{x:1355,y:960,t:1527265104854};\\\", \\\"{x:1358,y:954,t:1527265104871};\\\", \\\"{x:1362,y:944,t:1527265104888};\\\", \\\"{x:1365,y:930,t:1527265104903};\\\", \\\"{x:1368,y:915,t:1527265104920};\\\", \\\"{x:1372,y:883,t:1527265104938};\\\", \\\"{x:1372,y:865,t:1527265104954};\\\", \\\"{x:1372,y:853,t:1527265104970};\\\", \\\"{x:1372,y:843,t:1527265104988};\\\", \\\"{x:1371,y:832,t:1527265105004};\\\", \\\"{x:1371,y:823,t:1527265105021};\\\", \\\"{x:1371,y:817,t:1527265105038};\\\", \\\"{x:1371,y:810,t:1527265105055};\\\", \\\"{x:1371,y:805,t:1527265105070};\\\", \\\"{x:1371,y:802,t:1527265105087};\\\", \\\"{x:1370,y:798,t:1527265105105};\\\", \\\"{x:1369,y:793,t:1527265105121};\\\", \\\"{x:1364,y:786,t:1527265105138};\\\", \\\"{x:1362,y:780,t:1527265105154};\\\", \\\"{x:1360,y:776,t:1527265105171};\\\", \\\"{x:1358,y:772,t:1527265105188};\\\", \\\"{x:1356,y:769,t:1527265105204};\\\", \\\"{x:1355,y:766,t:1527265105220};\\\", \\\"{x:1353,y:764,t:1527265105238};\\\", \\\"{x:1353,y:763,t:1527265105254};\\\", \\\"{x:1353,y:762,t:1527265105270};\\\", \\\"{x:1352,y:761,t:1527265105287};\\\", \\\"{x:1352,y:760,t:1527265105304};\\\", \\\"{x:1352,y:759,t:1527265105320};\\\", \\\"{x:1352,y:758,t:1527265105338};\\\", \\\"{x:1351,y:757,t:1527265105354};\\\", \\\"{x:1350,y:756,t:1527265105370};\\\", \\\"{x:1350,y:755,t:1527265105417};\\\", \\\"{x:1350,y:754,t:1527265105433};\\\", \\\"{x:1350,y:753,t:1527265105441};\\\", \\\"{x:1350,y:752,t:1527265105454};\\\", \\\"{x:1350,y:747,t:1527265105472};\\\", \\\"{x:1350,y:742,t:1527265105487};\\\", \\\"{x:1350,y:735,t:1527265105504};\\\", \\\"{x:1350,y:727,t:1527265105521};\\\", \\\"{x:1350,y:725,t:1527265105537};\\\", \\\"{x:1350,y:724,t:1527265105555};\\\", \\\"{x:1349,y:722,t:1527265105572};\\\", \\\"{x:1348,y:721,t:1527265105634};\\\", \\\"{x:1345,y:720,t:1527265105642};\\\", \\\"{x:1338,y:719,t:1527265105654};\\\", \\\"{x:1314,y:713,t:1527265105672};\\\", \\\"{x:1251,y:700,t:1527265105688};\\\", \\\"{x:1145,y:678,t:1527265105705};\\\", \\\"{x:980,y:627,t:1527265105722};\\\", \\\"{x:845,y:591,t:1527265105739};\\\", \\\"{x:731,y:556,t:1527265105754};\\\", \\\"{x:643,y:531,t:1527265105772};\\\", \\\"{x:598,y:517,t:1527265105789};\\\", \\\"{x:581,y:513,t:1527265105804};\\\", \\\"{x:578,y:512,t:1527265105821};\\\", \\\"{x:577,y:512,t:1527265105838};\\\", \\\"{x:576,y:512,t:1527265105921};\\\", \\\"{x:576,y:513,t:1527265105938};\\\", \\\"{x:576,y:515,t:1527265105954};\\\", \\\"{x:576,y:516,t:1527265106050};\\\", \\\"{x:577,y:516,t:1527265106057};\\\", \\\"{x:578,y:516,t:1527265106074};\\\", \\\"{x:580,y:516,t:1527265106088};\\\", \\\"{x:582,y:515,t:1527265106104};\\\", \\\"{x:592,y:510,t:1527265106121};\\\", \\\"{x:602,y:506,t:1527265106138};\\\", \\\"{x:608,y:502,t:1527265106155};\\\", \\\"{x:613,y:499,t:1527265106171};\\\", \\\"{x:618,y:497,t:1527265106188};\\\", \\\"{x:622,y:495,t:1527265106205};\\\", \\\"{x:623,y:494,t:1527265106222};\\\", \\\"{x:626,y:493,t:1527265106238};\\\", \\\"{x:633,y:491,t:1527265106254};\\\", \\\"{x:645,y:489,t:1527265106271};\\\", \\\"{x:666,y:487,t:1527265106288};\\\", \\\"{x:698,y:487,t:1527265106305};\\\", \\\"{x:741,y:487,t:1527265106323};\\\", \\\"{x:770,y:484,t:1527265106338};\\\", \\\"{x:788,y:481,t:1527265106355};\\\", \\\"{x:794,y:481,t:1527265106371};\\\", \\\"{x:796,y:480,t:1527265106433};\\\", \\\"{x:797,y:480,t:1527265106449};\\\", \\\"{x:798,y:479,t:1527265106481};\\\", \\\"{x:799,y:479,t:1527265106586};\\\", \\\"{x:799,y:481,t:1527265106594};\\\", \\\"{x:799,y:484,t:1527265106605};\\\", \\\"{x:800,y:485,t:1527265106621};\\\", \\\"{x:801,y:486,t:1527265106638};\\\", \\\"{x:804,y:489,t:1527265106657};\\\", \\\"{x:809,y:491,t:1527265106672};\\\", \\\"{x:817,y:494,t:1527265106689};\\\", \\\"{x:826,y:496,t:1527265106706};\\\", \\\"{x:835,y:496,t:1527265106723};\\\", \\\"{x:840,y:496,t:1527265106738};\\\", \\\"{x:845,y:497,t:1527265106755};\\\", \\\"{x:850,y:498,t:1527265106772};\\\", \\\"{x:852,y:499,t:1527265106801};\\\", \\\"{x:852,y:500,t:1527265106882};\\\", \\\"{x:850,y:501,t:1527265107594};\\\", \\\"{x:839,y:504,t:1527265107606};\\\", \\\"{x:800,y:504,t:1527265107624};\\\", \\\"{x:735,y:506,t:1527265107639};\\\", \\\"{x:641,y:506,t:1527265107656};\\\", \\\"{x:538,y:506,t:1527265107672};\\\", \\\"{x:411,y:506,t:1527265107689};\\\", \\\"{x:354,y:516,t:1527265107706};\\\", \\\"{x:321,y:525,t:1527265107723};\\\", \\\"{x:309,y:527,t:1527265107739};\\\", \\\"{x:306,y:527,t:1527265107756};\\\", \\\"{x:305,y:528,t:1527265107773};\\\", \\\"{x:305,y:529,t:1527265107789};\\\", \\\"{x:304,y:530,t:1527265107806};\\\", \\\"{x:303,y:531,t:1527265107823};\\\", \\\"{x:302,y:532,t:1527265107839};\\\", \\\"{x:300,y:534,t:1527265107856};\\\", \\\"{x:295,y:536,t:1527265107873};\\\", \\\"{x:286,y:539,t:1527265107889};\\\", \\\"{x:266,y:541,t:1527265107908};\\\", \\\"{x:242,y:544,t:1527265107923};\\\", \\\"{x:215,y:544,t:1527265107939};\\\", \\\"{x:189,y:544,t:1527265107956};\\\", \\\"{x:167,y:544,t:1527265107973};\\\", \\\"{x:150,y:544,t:1527265107989};\\\", \\\"{x:142,y:543,t:1527265108006};\\\", \\\"{x:138,y:543,t:1527265108023};\\\", \\\"{x:136,y:543,t:1527265108039};\\\", \\\"{x:137,y:543,t:1527265108354};\\\", \\\"{x:138,y:542,t:1527265108362};\\\", \\\"{x:139,y:541,t:1527265108374};\\\", \\\"{x:141,y:541,t:1527265108650};\\\", \\\"{x:144,y:541,t:1527265108657};\\\", \\\"{x:152,y:541,t:1527265108674};\\\", \\\"{x:156,y:541,t:1527265108690};\\\", \\\"{x:162,y:540,t:1527265108706};\\\", \\\"{x:165,y:539,t:1527265108723};\\\", \\\"{x:166,y:539,t:1527265108857};\\\", \\\"{x:170,y:539,t:1527265109137};\\\", \\\"{x:179,y:549,t:1527265109145};\\\", \\\"{x:187,y:561,t:1527265109158};\\\", \\\"{x:214,y:586,t:1527265109174};\\\", \\\"{x:252,y:617,t:1527265109193};\\\", \\\"{x:286,y:642,t:1527265109208};\\\", \\\"{x:305,y:658,t:1527265109223};\\\", \\\"{x:322,y:669,t:1527265109240};\\\", \\\"{x:343,y:684,t:1527265109257};\\\", \\\"{x:357,y:695,t:1527265109273};\\\", \\\"{x:370,y:703,t:1527265109291};\\\", \\\"{x:385,y:713,t:1527265109308};\\\", \\\"{x:398,y:720,t:1527265109324};\\\", \\\"{x:407,y:725,t:1527265109340};\\\", \\\"{x:418,y:733,t:1527265109357};\\\", \\\"{x:426,y:739,t:1527265109375};\\\", \\\"{x:436,y:746,t:1527265109391};\\\", \\\"{x:444,y:749,t:1527265109407};\\\", \\\"{x:448,y:751,t:1527265109426};\\\", \\\"{x:454,y:752,t:1527265109440};\\\", \\\"{x:456,y:752,t:1527265109457};\\\", \\\"{x:458,y:752,t:1527265109474};\\\", \\\"{x:462,y:751,t:1527265109491};\\\", \\\"{x:469,y:750,t:1527265109508};\\\", \\\"{x:480,y:748,t:1527265109524};\\\", \\\"{x:483,y:746,t:1527265109540};\\\", \\\"{x:485,y:745,t:1527265109557};\\\" ] }, { \\\"rt\\\": 10294, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 706276, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:744,t:1527265112730};\\\", \\\"{x:486,y:744,t:1527265112969};\\\", \\\"{x:486,y:745,t:1527265112993};\\\", \\\"{x:487,y:746,t:1527265113009};\\\", \\\"{x:488,y:746,t:1527265113042};\\\", \\\"{x:489,y:747,t:1527265113058};\\\", \\\"{x:493,y:745,t:1527265113546};\\\", \\\"{x:507,y:736,t:1527265113561};\\\", \\\"{x:516,y:726,t:1527265113578};\\\", \\\"{x:523,y:710,t:1527265113596};\\\", \\\"{x:531,y:690,t:1527265113611};\\\", \\\"{x:543,y:668,t:1527265113627};\\\", \\\"{x:552,y:642,t:1527265113644};\\\", \\\"{x:561,y:621,t:1527265113661};\\\", \\\"{x:571,y:597,t:1527265113678};\\\", \\\"{x:582,y:570,t:1527265113695};\\\", \\\"{x:589,y:552,t:1527265113711};\\\", \\\"{x:595,y:536,t:1527265113727};\\\", \\\"{x:598,y:528,t:1527265113744};\\\", \\\"{x:600,y:525,t:1527265113761};\\\", \\\"{x:600,y:524,t:1527265113802};\\\", \\\"{x:600,y:522,t:1527265113811};\\\", \\\"{x:601,y:520,t:1527265113828};\\\", \\\"{x:602,y:518,t:1527265113844};\\\", \\\"{x:606,y:512,t:1527265113861};\\\", \\\"{x:612,y:505,t:1527265113877};\\\", \\\"{x:620,y:497,t:1527265113894};\\\", \\\"{x:632,y:483,t:1527265113912};\\\", \\\"{x:644,y:465,t:1527265113928};\\\", \\\"{x:648,y:456,t:1527265113945};\\\", \\\"{x:652,y:449,t:1527265113961};\\\", \\\"{x:652,y:447,t:1527265113977};\\\", \\\"{x:653,y:444,t:1527265113994};\\\", \\\"{x:654,y:444,t:1527265114011};\\\", \\\"{x:656,y:443,t:1527265114186};\\\", \\\"{x:660,y:443,t:1527265114195};\\\", \\\"{x:682,y:448,t:1527265114211};\\\", \\\"{x:737,y:462,t:1527265114228};\\\", \\\"{x:842,y:492,t:1527265114246};\\\", \\\"{x:967,y:526,t:1527265114261};\\\", \\\"{x:1113,y:565,t:1527265114279};\\\", \\\"{x:1245,y:601,t:1527265114295};\\\", \\\"{x:1362,y:639,t:1527265114311};\\\", \\\"{x:1459,y:667,t:1527265114329};\\\", \\\"{x:1520,y:693,t:1527265114345};\\\", \\\"{x:1568,y:714,t:1527265114361};\\\", \\\"{x:1582,y:721,t:1527265114379};\\\", \\\"{x:1589,y:728,t:1527265114395};\\\", \\\"{x:1594,y:735,t:1527265114412};\\\", \\\"{x:1595,y:741,t:1527265114429};\\\", \\\"{x:1596,y:745,t:1527265114445};\\\", \\\"{x:1596,y:749,t:1527265114462};\\\", \\\"{x:1596,y:755,t:1527265114479};\\\", \\\"{x:1598,y:761,t:1527265114496};\\\", \\\"{x:1600,y:765,t:1527265114512};\\\", \\\"{x:1602,y:767,t:1527265114529};\\\", \\\"{x:1602,y:768,t:1527265114866};\\\", \\\"{x:1595,y:768,t:1527265114930};\\\", \\\"{x:1572,y:764,t:1527265114946};\\\", \\\"{x:1550,y:759,t:1527265114964};\\\", \\\"{x:1527,y:754,t:1527265114980};\\\", \\\"{x:1508,y:752,t:1527265114996};\\\", \\\"{x:1491,y:749,t:1527265115013};\\\", \\\"{x:1475,y:747,t:1527265115030};\\\", \\\"{x:1460,y:745,t:1527265115047};\\\", \\\"{x:1446,y:743,t:1527265115063};\\\", \\\"{x:1429,y:739,t:1527265115080};\\\", \\\"{x:1414,y:738,t:1527265115097};\\\", \\\"{x:1398,y:735,t:1527265115113};\\\", \\\"{x:1385,y:733,t:1527265115130};\\\", \\\"{x:1378,y:730,t:1527265115148};\\\", \\\"{x:1370,y:728,t:1527265115163};\\\", \\\"{x:1364,y:724,t:1527265115180};\\\", \\\"{x:1355,y:719,t:1527265115198};\\\", \\\"{x:1343,y:708,t:1527265115214};\\\", \\\"{x:1334,y:699,t:1527265115231};\\\", \\\"{x:1327,y:689,t:1527265115247};\\\", \\\"{x:1323,y:683,t:1527265115264};\\\", \\\"{x:1320,y:679,t:1527265115280};\\\", \\\"{x:1320,y:678,t:1527265115297};\\\", \\\"{x:1320,y:676,t:1527265115458};\\\", \\\"{x:1320,y:675,t:1527265115466};\\\", \\\"{x:1322,y:675,t:1527265115482};\\\", \\\"{x:1327,y:674,t:1527265115497};\\\", \\\"{x:1332,y:674,t:1527265115514};\\\", \\\"{x:1333,y:674,t:1527265115537};\\\", \\\"{x:1334,y:674,t:1527265115547};\\\", \\\"{x:1336,y:674,t:1527265115564};\\\", \\\"{x:1337,y:675,t:1527265115581};\\\", \\\"{x:1338,y:675,t:1527265115597};\\\", \\\"{x:1339,y:676,t:1527265115617};\\\", \\\"{x:1340,y:676,t:1527265115633};\\\", \\\"{x:1340,y:678,t:1527265115649};\\\", \\\"{x:1341,y:680,t:1527265115665};\\\", \\\"{x:1341,y:681,t:1527265115681};\\\", \\\"{x:1341,y:684,t:1527265115698};\\\", \\\"{x:1341,y:686,t:1527265115715};\\\", \\\"{x:1342,y:691,t:1527265115730};\\\", \\\"{x:1342,y:694,t:1527265115747};\\\", \\\"{x:1343,y:699,t:1527265115766};\\\", \\\"{x:1344,y:703,t:1527265115782};\\\", \\\"{x:1345,y:705,t:1527265115798};\\\", \\\"{x:1345,y:706,t:1527265115815};\\\", \\\"{x:1345,y:708,t:1527265115831};\\\", \\\"{x:1345,y:710,t:1527265115848};\\\", \\\"{x:1345,y:711,t:1527265115865};\\\", \\\"{x:1345,y:712,t:1527265115881};\\\", \\\"{x:1345,y:714,t:1527265115913};\\\", \\\"{x:1345,y:715,t:1527265115938};\\\", \\\"{x:1345,y:717,t:1527265115962};\\\", \\\"{x:1345,y:718,t:1527265115970};\\\", \\\"{x:1345,y:719,t:1527265115982};\\\", \\\"{x:1345,y:720,t:1527265115998};\\\", \\\"{x:1345,y:722,t:1527265116015};\\\", \\\"{x:1345,y:724,t:1527265116032};\\\", \\\"{x:1344,y:728,t:1527265116049};\\\", \\\"{x:1344,y:730,t:1527265116065};\\\", \\\"{x:1343,y:735,t:1527265116082};\\\", \\\"{x:1343,y:737,t:1527265116099};\\\", \\\"{x:1341,y:740,t:1527265116116};\\\", \\\"{x:1341,y:743,t:1527265116132};\\\", \\\"{x:1341,y:744,t:1527265116149};\\\", \\\"{x:1340,y:744,t:1527265116165};\\\", \\\"{x:1340,y:745,t:1527265116182};\\\", \\\"{x:1340,y:747,t:1527265116199};\\\", \\\"{x:1339,y:747,t:1527265116215};\\\", \\\"{x:1339,y:748,t:1527265116233};\\\", \\\"{x:1339,y:749,t:1527265116258};\\\", \\\"{x:1338,y:750,t:1527265116274};\\\", \\\"{x:1338,y:751,t:1527265116355};\\\", \\\"{x:1338,y:752,t:1527265116378};\\\", \\\"{x:1338,y:753,t:1527265116393};\\\", \\\"{x:1338,y:754,t:1527265116426};\\\", \\\"{x:1338,y:755,t:1527265116442};\\\", \\\"{x:1338,y:757,t:1527265116458};\\\", \\\"{x:1338,y:758,t:1527265116481};\\\", \\\"{x:1338,y:759,t:1527265116490};\\\", \\\"{x:1338,y:760,t:1527265116499};\\\", \\\"{x:1338,y:761,t:1527265116522};\\\", \\\"{x:1338,y:762,t:1527265116533};\\\", \\\"{x:1338,y:763,t:1527265116548};\\\", \\\"{x:1338,y:764,t:1527265116566};\\\", \\\"{x:1338,y:765,t:1527265116582};\\\", \\\"{x:1339,y:766,t:1527265116600};\\\", \\\"{x:1339,y:767,t:1527265116617};\\\", \\\"{x:1339,y:769,t:1527265116633};\\\", \\\"{x:1339,y:771,t:1527265116673};\\\", \\\"{x:1340,y:772,t:1527265116698};\\\", \\\"{x:1340,y:774,t:1527265116745};\\\", \\\"{x:1341,y:775,t:1527265116770};\\\", \\\"{x:1342,y:776,t:1527265116786};\\\", \\\"{x:1342,y:777,t:1527265116802};\\\", \\\"{x:1342,y:778,t:1527265116825};\\\", \\\"{x:1342,y:780,t:1527265116866};\\\", \\\"{x:1343,y:780,t:1527265116883};\\\", \\\"{x:1343,y:781,t:1527265116901};\\\", \\\"{x:1344,y:782,t:1527265116918};\\\", \\\"{x:1345,y:783,t:1527265116938};\\\", \\\"{x:1345,y:784,t:1527265116951};\\\", \\\"{x:1346,y:784,t:1527265116967};\\\", \\\"{x:1346,y:786,t:1527265116984};\\\", \\\"{x:1347,y:787,t:1527265117000};\\\", \\\"{x:1348,y:788,t:1527265117034};\\\", \\\"{x:1349,y:789,t:1527265117058};\\\", \\\"{x:1350,y:790,t:1527265117090};\\\", \\\"{x:1351,y:791,t:1527265117105};\\\", \\\"{x:1352,y:791,t:1527265117122};\\\", \\\"{x:1352,y:792,t:1527265117134};\\\", \\\"{x:1353,y:793,t:1527265117154};\\\", \\\"{x:1354,y:794,t:1527265117186};\\\", \\\"{x:1355,y:795,t:1527265117202};\\\", \\\"{x:1355,y:796,t:1527265117226};\\\", \\\"{x:1356,y:797,t:1527265117234};\\\", \\\"{x:1356,y:798,t:1527265117251};\\\", \\\"{x:1357,y:798,t:1527265117268};\\\", \\\"{x:1358,y:799,t:1527265117284};\\\", \\\"{x:1358,y:801,t:1527265117301};\\\", \\\"{x:1359,y:802,t:1527265117318};\\\", \\\"{x:1359,y:803,t:1527265117346};\\\", \\\"{x:1360,y:804,t:1527265117354};\\\", \\\"{x:1360,y:805,t:1527265117370};\\\", \\\"{x:1360,y:806,t:1527265117386};\\\", \\\"{x:1360,y:807,t:1527265117402};\\\", \\\"{x:1361,y:808,t:1527265117418};\\\", \\\"{x:1361,y:810,t:1527265117434};\\\", \\\"{x:1362,y:813,t:1527265117451};\\\", \\\"{x:1362,y:814,t:1527265117469};\\\", \\\"{x:1364,y:816,t:1527265117486};\\\", \\\"{x:1364,y:818,t:1527265117501};\\\", \\\"{x:1366,y:820,t:1527265117519};\\\", \\\"{x:1366,y:821,t:1527265117535};\\\", \\\"{x:1366,y:823,t:1527265117551};\\\", \\\"{x:1368,y:827,t:1527265117568};\\\", \\\"{x:1369,y:828,t:1527265117585};\\\", \\\"{x:1370,y:831,t:1527265117601};\\\", \\\"{x:1373,y:836,t:1527265117618};\\\", \\\"{x:1374,y:838,t:1527265117635};\\\", \\\"{x:1376,y:842,t:1527265117652};\\\", \\\"{x:1376,y:845,t:1527265117669};\\\", \\\"{x:1377,y:849,t:1527265117685};\\\", \\\"{x:1377,y:851,t:1527265117703};\\\", \\\"{x:1377,y:854,t:1527265117719};\\\", \\\"{x:1377,y:856,t:1527265117736};\\\", \\\"{x:1377,y:859,t:1527265117752};\\\", \\\"{x:1377,y:862,t:1527265117768};\\\", \\\"{x:1377,y:868,t:1527265117786};\\\", \\\"{x:1377,y:871,t:1527265117802};\\\", \\\"{x:1377,y:873,t:1527265117819};\\\", \\\"{x:1377,y:874,t:1527265117835};\\\", \\\"{x:1377,y:876,t:1527265117853};\\\", \\\"{x:1376,y:877,t:1527265117870};\\\", \\\"{x:1376,y:879,t:1527265117885};\\\", \\\"{x:1374,y:881,t:1527265117903};\\\", \\\"{x:1372,y:884,t:1527265117919};\\\", \\\"{x:1371,y:887,t:1527265117935};\\\", \\\"{x:1369,y:889,t:1527265117952};\\\", \\\"{x:1366,y:894,t:1527265117969};\\\", \\\"{x:1363,y:898,t:1527265117985};\\\", \\\"{x:1357,y:905,t:1527265118002};\\\", \\\"{x:1352,y:911,t:1527265118019};\\\", \\\"{x:1348,y:916,t:1527265118036};\\\", \\\"{x:1345,y:920,t:1527265118052};\\\", \\\"{x:1342,y:924,t:1527265118068};\\\", \\\"{x:1342,y:928,t:1527265118086};\\\", \\\"{x:1341,y:931,t:1527265118102};\\\", \\\"{x:1341,y:935,t:1527265118119};\\\", \\\"{x:1341,y:938,t:1527265118136};\\\", \\\"{x:1341,y:940,t:1527265118152};\\\", \\\"{x:1341,y:941,t:1527265118169};\\\", \\\"{x:1341,y:944,t:1527265118186};\\\", \\\"{x:1341,y:945,t:1527265118218};\\\", \\\"{x:1341,y:946,t:1527265118226};\\\", \\\"{x:1341,y:947,t:1527265118298};\\\", \\\"{x:1342,y:943,t:1527265118330};\\\", \\\"{x:1343,y:936,t:1527265118338};\\\", \\\"{x:1343,y:927,t:1527265118353};\\\", \\\"{x:1345,y:900,t:1527265118370};\\\", \\\"{x:1345,y:883,t:1527265118386};\\\", \\\"{x:1345,y:861,t:1527265118403};\\\", \\\"{x:1345,y:840,t:1527265118420};\\\", \\\"{x:1348,y:816,t:1527265118437};\\\", \\\"{x:1350,y:796,t:1527265118453};\\\", \\\"{x:1354,y:777,t:1527265118471};\\\", \\\"{x:1356,y:758,t:1527265118486};\\\", \\\"{x:1356,y:744,t:1527265118504};\\\", \\\"{x:1356,y:738,t:1527265118520};\\\", \\\"{x:1356,y:736,t:1527265118537};\\\", \\\"{x:1355,y:736,t:1527265118553};\\\", \\\"{x:1353,y:735,t:1527265118570};\\\", \\\"{x:1352,y:735,t:1527265118587};\\\", \\\"{x:1349,y:735,t:1527265118603};\\\", \\\"{x:1344,y:735,t:1527265118620};\\\", \\\"{x:1336,y:735,t:1527265118638};\\\", \\\"{x:1320,y:742,t:1527265118654};\\\", \\\"{x:1305,y:751,t:1527265118670};\\\", \\\"{x:1295,y:756,t:1527265118687};\\\", \\\"{x:1285,y:756,t:1527265119115};\\\", \\\"{x:1264,y:757,t:1527265119122};\\\", \\\"{x:1201,y:753,t:1527265119138};\\\", \\\"{x:1115,y:740,t:1527265119154};\\\", \\\"{x:1002,y:711,t:1527265119171};\\\", \\\"{x:877,y:671,t:1527265119188};\\\", \\\"{x:758,y:638,t:1527265119203};\\\", \\\"{x:667,y:615,t:1527265119221};\\\", \\\"{x:608,y:596,t:1527265119238};\\\", \\\"{x:564,y:584,t:1527265119255};\\\", \\\"{x:541,y:575,t:1527265119265};\\\", \\\"{x:524,y:568,t:1527265119281};\\\", \\\"{x:516,y:564,t:1527265119298};\\\", \\\"{x:509,y:560,t:1527265119316};\\\", \\\"{x:498,y:557,t:1527265119332};\\\", \\\"{x:479,y:551,t:1527265119349};\\\", \\\"{x:451,y:543,t:1527265119365};\\\", \\\"{x:420,y:536,t:1527265119382};\\\", \\\"{x:380,y:529,t:1527265119398};\\\", \\\"{x:313,y:518,t:1527265119416};\\\", \\\"{x:234,y:511,t:1527265119432};\\\", \\\"{x:132,y:497,t:1527265119449};\\\", \\\"{x:99,y:494,t:1527265119465};\\\", \\\"{x:86,y:494,t:1527265119482};\\\", \\\"{x:85,y:494,t:1527265119499};\\\", \\\"{x:84,y:494,t:1527265119516};\\\", \\\"{x:84,y:497,t:1527265119532};\\\", \\\"{x:89,y:505,t:1527265119548};\\\", \\\"{x:92,y:511,t:1527265119566};\\\", \\\"{x:98,y:517,t:1527265119582};\\\", \\\"{x:100,y:518,t:1527265119600};\\\", \\\"{x:102,y:520,t:1527265119615};\\\", \\\"{x:103,y:520,t:1527265119650};\\\", \\\"{x:108,y:522,t:1527265119665};\\\", \\\"{x:118,y:526,t:1527265119683};\\\", \\\"{x:138,y:533,t:1527265119698};\\\", \\\"{x:158,y:537,t:1527265119717};\\\", \\\"{x:175,y:541,t:1527265119733};\\\", \\\"{x:183,y:542,t:1527265119749};\\\", \\\"{x:186,y:542,t:1527265119766};\\\", \\\"{x:188,y:544,t:1527265120112};\\\", \\\"{x:192,y:546,t:1527265120121};\\\", \\\"{x:201,y:550,t:1527265120132};\\\", \\\"{x:228,y:565,t:1527265120150};\\\", \\\"{x:281,y:591,t:1527265120166};\\\", \\\"{x:365,y:634,t:1527265120183};\\\", \\\"{x:455,y:686,t:1527265120198};\\\", \\\"{x:513,y:714,t:1527265120216};\\\", \\\"{x:524,y:722,t:1527265120233};\\\", \\\"{x:533,y:729,t:1527265120249};\\\", \\\"{x:533,y:730,t:1527265120265};\\\", \\\"{x:533,y:733,t:1527265120283};\\\", \\\"{x:533,y:732,t:1527265120426};\\\", \\\"{x:532,y:727,t:1527265120433};\\\", \\\"{x:531,y:722,t:1527265120451};\\\", \\\"{x:529,y:720,t:1527265120467};\\\", \\\"{x:528,y:719,t:1527265120485};\\\", \\\"{x:528,y:721,t:1527265121003};\\\", \\\"{x:528,y:722,t:1527265121024};\\\", \\\"{x:528,y:724,t:1527265121033};\\\", \\\"{x:528,y:725,t:1527265121050};\\\", \\\"{x:528,y:728,t:1527265121066};\\\", \\\"{x:528,y:729,t:1527265121083};\\\", \\\"{x:528,y:730,t:1527265121100};\\\", \\\"{x:528,y:731,t:1527265121329};\\\", \\\"{x:528,y:733,t:1527265121474};\\\", \\\"{x:528,y:736,t:1527265121484};\\\", \\\"{x:527,y:738,t:1527265121501};\\\" ] }, { \\\"rt\\\": 32558, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 740043, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:739,t:1527265122714};\\\", \\\"{x:528,y:739,t:1527265123826};\\\", \\\"{x:529,y:736,t:1527265123837};\\\", \\\"{x:536,y:717,t:1527265123853};\\\", \\\"{x:549,y:692,t:1527265123869};\\\", \\\"{x:566,y:646,t:1527265123886};\\\", \\\"{x:579,y:592,t:1527265123902};\\\", \\\"{x:587,y:546,t:1527265123919};\\\", \\\"{x:590,y:517,t:1527265123937};\\\", \\\"{x:593,y:494,t:1527265123952};\\\", \\\"{x:593,y:468,t:1527265123969};\\\", \\\"{x:593,y:451,t:1527265123986};\\\", \\\"{x:589,y:437,t:1527265124002};\\\", \\\"{x:589,y:432,t:1527265124019};\\\", \\\"{x:588,y:431,t:1527265124035};\\\", \\\"{x:590,y:432,t:1527265124258};\\\", \\\"{x:590,y:433,t:1527265124274};\\\", \\\"{x:593,y:434,t:1527265124285};\\\", \\\"{x:596,y:435,t:1527265124301};\\\", \\\"{x:598,y:437,t:1527265124318};\\\", \\\"{x:600,y:438,t:1527265124335};\\\", \\\"{x:603,y:440,t:1527265124351};\\\", \\\"{x:605,y:443,t:1527265124368};\\\", \\\"{x:607,y:445,t:1527265124385};\\\", \\\"{x:610,y:449,t:1527265124402};\\\", \\\"{x:614,y:452,t:1527265124417};\\\", \\\"{x:618,y:456,t:1527265124434};\\\", \\\"{x:622,y:460,t:1527265124451};\\\", \\\"{x:624,y:461,t:1527265124468};\\\", \\\"{x:625,y:461,t:1527265124570};\\\", \\\"{x:626,y:461,t:1527265124602};\\\", \\\"{x:627,y:461,t:1527265124618};\\\", \\\"{x:627,y:460,t:1527265124778};\\\", \\\"{x:627,y:459,t:1527265124785};\\\", \\\"{x:626,y:458,t:1527265124802};\\\", \\\"{x:625,y:458,t:1527265124825};\\\", \\\"{x:624,y:457,t:1527265124833};\\\", \\\"{x:624,y:456,t:1527265124986};\\\", \\\"{x:622,y:454,t:1527265125001};\\\", \\\"{x:616,y:452,t:1527265125017};\\\", \\\"{x:607,y:449,t:1527265125037};\\\", \\\"{x:596,y:446,t:1527265125054};\\\", \\\"{x:589,y:446,t:1527265125070};\\\", \\\"{x:582,y:446,t:1527265125087};\\\", \\\"{x:578,y:446,t:1527265125102};\\\", \\\"{x:572,y:446,t:1527265125119};\\\", \\\"{x:567,y:446,t:1527265125136};\\\", \\\"{x:565,y:446,t:1527265125152};\\\", \\\"{x:564,y:446,t:1527265125170};\\\", \\\"{x:561,y:447,t:1527265125187};\\\", \\\"{x:559,y:447,t:1527265125203};\\\", \\\"{x:556,y:447,t:1527265125219};\\\", \\\"{x:555,y:447,t:1527265125237};\\\", \\\"{x:554,y:447,t:1527265125306};\\\", \\\"{x:553,y:449,t:1527265125320};\\\", \\\"{x:551,y:449,t:1527265125337};\\\", \\\"{x:551,y:449,t:1527265125587};\\\", \\\"{x:550,y:450,t:1527265125658};\\\", \\\"{x:554,y:453,t:1527265125671};\\\", \\\"{x:584,y:453,t:1527265125687};\\\", \\\"{x:626,y:453,t:1527265125705};\\\", \\\"{x:746,y:453,t:1527265125721};\\\", \\\"{x:851,y:453,t:1527265125737};\\\", \\\"{x:960,y:457,t:1527265125754};\\\", \\\"{x:1055,y:475,t:1527265125771};\\\", \\\"{x:1118,y:490,t:1527265125787};\\\", \\\"{x:1164,y:505,t:1527265125804};\\\", \\\"{x:1200,y:526,t:1527265125821};\\\", \\\"{x:1228,y:547,t:1527265125837};\\\", \\\"{x:1247,y:559,t:1527265125854};\\\", \\\"{x:1248,y:559,t:1527265125871};\\\", \\\"{x:1252,y:561,t:1527265126274};\\\", \\\"{x:1254,y:562,t:1527265126288};\\\", \\\"{x:1268,y:572,t:1527265126305};\\\", \\\"{x:1297,y:588,t:1527265126322};\\\", \\\"{x:1311,y:597,t:1527265126338};\\\", \\\"{x:1323,y:611,t:1527265126354};\\\", \\\"{x:1330,y:624,t:1527265126371};\\\", \\\"{x:1335,y:638,t:1527265126388};\\\", \\\"{x:1340,y:654,t:1527265126404};\\\", \\\"{x:1348,y:674,t:1527265126422};\\\", \\\"{x:1365,y:699,t:1527265126438};\\\", \\\"{x:1392,y:738,t:1527265126454};\\\", \\\"{x:1420,y:769,t:1527265126471};\\\", \\\"{x:1445,y:790,t:1527265126489};\\\", \\\"{x:1477,y:823,t:1527265126505};\\\", \\\"{x:1484,y:836,t:1527265126521};\\\", \\\"{x:1487,y:849,t:1527265126538};\\\", \\\"{x:1486,y:863,t:1527265126555};\\\", \\\"{x:1477,y:874,t:1527265126571};\\\", \\\"{x:1465,y:884,t:1527265126589};\\\", \\\"{x:1446,y:891,t:1527265126606};\\\", \\\"{x:1421,y:898,t:1527265126621};\\\", \\\"{x:1384,y:905,t:1527265126638};\\\", \\\"{x:1345,y:912,t:1527265126656};\\\", \\\"{x:1343,y:914,t:1527265126671};\\\", \\\"{x:1334,y:916,t:1527265126688};\\\", \\\"{x:1335,y:916,t:1527265127858};\\\", \\\"{x:1349,y:912,t:1527265127873};\\\", \\\"{x:1381,y:912,t:1527265127889};\\\", \\\"{x:1419,y:904,t:1527265127906};\\\", \\\"{x:1469,y:890,t:1527265127923};\\\", \\\"{x:1511,y:870,t:1527265127940};\\\", \\\"{x:1548,y:850,t:1527265127957};\\\", \\\"{x:1586,y:828,t:1527265127973};\\\", \\\"{x:1627,y:802,t:1527265127990};\\\", \\\"{x:1656,y:783,t:1527265128006};\\\", \\\"{x:1674,y:765,t:1527265128022};\\\", \\\"{x:1686,y:745,t:1527265128040};\\\", \\\"{x:1695,y:722,t:1527265128057};\\\", \\\"{x:1701,y:701,t:1527265128073};\\\", \\\"{x:1702,y:668,t:1527265128089};\\\", \\\"{x:1702,y:645,t:1527265128106};\\\", \\\"{x:1702,y:627,t:1527265128123};\\\", \\\"{x:1702,y:615,t:1527265128139};\\\", \\\"{x:1703,y:610,t:1527265128157};\\\", \\\"{x:1703,y:604,t:1527265128174};\\\", \\\"{x:1703,y:599,t:1527265128190};\\\", \\\"{x:1700,y:596,t:1527265128207};\\\", \\\"{x:1696,y:595,t:1527265128224};\\\", \\\"{x:1689,y:595,t:1527265128239};\\\", \\\"{x:1683,y:595,t:1527265128257};\\\", \\\"{x:1675,y:601,t:1527265128274};\\\", \\\"{x:1663,y:630,t:1527265128290};\\\", \\\"{x:1657,y:651,t:1527265128307};\\\", \\\"{x:1651,y:669,t:1527265128324};\\\", \\\"{x:1646,y:685,t:1527265128340};\\\", \\\"{x:1644,y:693,t:1527265128356};\\\", \\\"{x:1642,y:700,t:1527265128374};\\\", \\\"{x:1639,y:706,t:1527265128390};\\\", \\\"{x:1637,y:711,t:1527265128407};\\\", \\\"{x:1636,y:716,t:1527265128423};\\\", \\\"{x:1635,y:719,t:1527265128440};\\\", \\\"{x:1633,y:723,t:1527265128456};\\\", \\\"{x:1631,y:727,t:1527265128473};\\\", \\\"{x:1630,y:727,t:1527265128538};\\\", \\\"{x:1629,y:725,t:1527265128545};\\\", \\\"{x:1627,y:724,t:1527265128557};\\\", \\\"{x:1621,y:718,t:1527265128574};\\\", \\\"{x:1614,y:712,t:1527265128591};\\\", \\\"{x:1607,y:707,t:1527265128606};\\\", \\\"{x:1603,y:703,t:1527265128624};\\\", \\\"{x:1601,y:702,t:1527265128641};\\\", \\\"{x:1600,y:701,t:1527265128657};\\\", \\\"{x:1600,y:700,t:1527265128794};\\\", \\\"{x:1600,y:699,t:1527265128810};\\\", \\\"{x:1602,y:698,t:1527265128867};\\\", \\\"{x:1603,y:697,t:1527265128874};\\\", \\\"{x:1606,y:697,t:1527265128891};\\\", \\\"{x:1609,y:694,t:1527265128909};\\\", \\\"{x:1612,y:694,t:1527265128923};\\\", \\\"{x:1613,y:693,t:1527265128940};\\\", \\\"{x:1614,y:693,t:1527265128956};\\\", \\\"{x:1615,y:692,t:1527265129041};\\\", \\\"{x:1606,y:692,t:1527265147474};\\\", \\\"{x:1476,y:710,t:1527265147490};\\\", \\\"{x:1335,y:732,t:1527265147507};\\\", \\\"{x:1180,y:749,t:1527265147524};\\\", \\\"{x:1041,y:760,t:1527265147540};\\\", \\\"{x:891,y:760,t:1527265147557};\\\", \\\"{x:783,y:760,t:1527265147574};\\\", \\\"{x:733,y:760,t:1527265147590};\\\", \\\"{x:707,y:760,t:1527265147607};\\\", \\\"{x:691,y:760,t:1527265147624};\\\", \\\"{x:672,y:760,t:1527265147640};\\\", \\\"{x:653,y:756,t:1527265147657};\\\", \\\"{x:619,y:741,t:1527265147674};\\\", \\\"{x:582,y:714,t:1527265147690};\\\", \\\"{x:528,y:677,t:1527265147707};\\\", \\\"{x:459,y:628,t:1527265147725};\\\", \\\"{x:399,y:581,t:1527265147741};\\\", \\\"{x:359,y:542,t:1527265147757};\\\", \\\"{x:314,y:480,t:1527265147789};\\\", \\\"{x:307,y:461,t:1527265147806};\\\", \\\"{x:304,y:450,t:1527265147823};\\\", \\\"{x:303,y:441,t:1527265147839};\\\", \\\"{x:303,y:435,t:1527265147855};\\\", \\\"{x:303,y:433,t:1527265147873};\\\", \\\"{x:301,y:433,t:1527265147897};\\\", \\\"{x:298,y:433,t:1527265147906};\\\", \\\"{x:287,y:433,t:1527265147922};\\\", \\\"{x:271,y:438,t:1527265147938};\\\", \\\"{x:253,y:453,t:1527265147956};\\\", \\\"{x:237,y:473,t:1527265147973};\\\", \\\"{x:219,y:492,t:1527265147990};\\\", \\\"{x:201,y:509,t:1527265148005};\\\", \\\"{x:195,y:511,t:1527265148022};\\\", \\\"{x:191,y:514,t:1527265148039};\\\", \\\"{x:190,y:515,t:1527265148056};\\\", \\\"{x:190,y:517,t:1527265148073};\\\", \\\"{x:190,y:518,t:1527265148091};\\\", \\\"{x:190,y:519,t:1527265148121};\\\", \\\"{x:190,y:520,t:1527265148138};\\\", \\\"{x:191,y:521,t:1527265148146};\\\", \\\"{x:191,y:523,t:1527265148156};\\\", \\\"{x:191,y:529,t:1527265148175};\\\", \\\"{x:191,y:540,t:1527265148189};\\\", \\\"{x:191,y:553,t:1527265148206};\\\", \\\"{x:187,y:565,t:1527265148224};\\\", \\\"{x:185,y:574,t:1527265148240};\\\", \\\"{x:182,y:582,t:1527265148256};\\\", \\\"{x:181,y:586,t:1527265148273};\\\", \\\"{x:181,y:592,t:1527265148290};\\\", \\\"{x:181,y:595,t:1527265148306};\\\", \\\"{x:181,y:598,t:1527265148323};\\\", \\\"{x:181,y:602,t:1527265148340};\\\", \\\"{x:181,y:605,t:1527265148356};\\\", \\\"{x:181,y:610,t:1527265148372};\\\", \\\"{x:181,y:614,t:1527265148390};\\\", \\\"{x:181,y:617,t:1527265148406};\\\", \\\"{x:181,y:619,t:1527265148423};\\\", \\\"{x:181,y:623,t:1527265148439};\\\", \\\"{x:181,y:627,t:1527265148457};\\\", \\\"{x:183,y:632,t:1527265148473};\\\", \\\"{x:184,y:636,t:1527265148490};\\\", \\\"{x:186,y:640,t:1527265148507};\\\", \\\"{x:191,y:645,t:1527265148523};\\\", \\\"{x:201,y:652,t:1527265148540};\\\", \\\"{x:222,y:664,t:1527265148556};\\\", \\\"{x:247,y:675,t:1527265148574};\\\", \\\"{x:288,y:692,t:1527265148590};\\\", \\\"{x:338,y:706,t:1527265148607};\\\", \\\"{x:388,y:713,t:1527265148623};\\\", \\\"{x:422,y:713,t:1527265148640};\\\", \\\"{x:459,y:702,t:1527265148658};\\\", \\\"{x:504,y:677,t:1527265148674};\\\", \\\"{x:519,y:667,t:1527265148691};\\\", \\\"{x:532,y:657,t:1527265148707};\\\", \\\"{x:540,y:651,t:1527265148724};\\\", \\\"{x:548,y:643,t:1527265148741};\\\", \\\"{x:558,y:632,t:1527265148757};\\\", \\\"{x:571,y:614,t:1527265148776};\\\", \\\"{x:584,y:601,t:1527265148791};\\\", \\\"{x:599,y:588,t:1527265148809};\\\", \\\"{x:610,y:580,t:1527265148824};\\\", \\\"{x:615,y:576,t:1527265148840};\\\", \\\"{x:620,y:570,t:1527265148857};\\\", \\\"{x:623,y:565,t:1527265148874};\\\", \\\"{x:623,y:564,t:1527265148890};\\\", \\\"{x:625,y:560,t:1527265148909};\\\", \\\"{x:631,y:552,t:1527265148924};\\\", \\\"{x:634,y:545,t:1527265148940};\\\", \\\"{x:637,y:541,t:1527265148957};\\\", \\\"{x:639,y:539,t:1527265148974};\\\", \\\"{x:640,y:539,t:1527265149042};\\\", \\\"{x:641,y:539,t:1527265149082};\\\", \\\"{x:643,y:539,t:1527265149099};\\\", \\\"{x:644,y:539,t:1527265149113};\\\", \\\"{x:647,y:539,t:1527265149123};\\\", \\\"{x:653,y:537,t:1527265149139};\\\", \\\"{x:664,y:536,t:1527265149156};\\\", \\\"{x:679,y:534,t:1527265149172};\\\", \\\"{x:703,y:527,t:1527265149189};\\\", \\\"{x:740,y:506,t:1527265149207};\\\", \\\"{x:778,y:486,t:1527265149223};\\\", \\\"{x:814,y:476,t:1527265149240};\\\", \\\"{x:831,y:475,t:1527265149256};\\\", \\\"{x:851,y:475,t:1527265149273};\\\", \\\"{x:862,y:475,t:1527265149290};\\\", \\\"{x:866,y:475,t:1527265149306};\\\", \\\"{x:869,y:475,t:1527265149324};\\\", \\\"{x:870,y:475,t:1527265149345};\\\", \\\"{x:871,y:476,t:1527265149370};\\\", \\\"{x:871,y:477,t:1527265149377};\\\", \\\"{x:871,y:480,t:1527265149391};\\\", \\\"{x:871,y:486,t:1527265149407};\\\", \\\"{x:869,y:492,t:1527265149424};\\\", \\\"{x:867,y:496,t:1527265149441};\\\", \\\"{x:861,y:500,t:1527265149457};\\\", \\\"{x:849,y:506,t:1527265149473};\\\", \\\"{x:844,y:508,t:1527265149491};\\\", \\\"{x:840,y:508,t:1527265149507};\\\", \\\"{x:838,y:508,t:1527265149523};\\\", \\\"{x:837,y:508,t:1527265149541};\\\", \\\"{x:836,y:508,t:1527265149557};\\\", \\\"{x:837,y:511,t:1527265150105};\\\", \\\"{x:852,y:512,t:1527265150115};\\\", \\\"{x:881,y:514,t:1527265150125};\\\", \\\"{x:1009,y:530,t:1527265150141};\\\", \\\"{x:1161,y:552,t:1527265150158};\\\", \\\"{x:1339,y:586,t:1527265150174};\\\", \\\"{x:1518,y:636,t:1527265150190};\\\", \\\"{x:1644,y:678,t:1527265150208};\\\", \\\"{x:1702,y:704,t:1527265150224};\\\", \\\"{x:1716,y:716,t:1527265150241};\\\", \\\"{x:1717,y:729,t:1527265150257};\\\", \\\"{x:1711,y:743,t:1527265150274};\\\", \\\"{x:1697,y:760,t:1527265150291};\\\", \\\"{x:1679,y:774,t:1527265150308};\\\", \\\"{x:1654,y:786,t:1527265150324};\\\", \\\"{x:1624,y:795,t:1527265150341};\\\", \\\"{x:1550,y:807,t:1527265150358};\\\", \\\"{x:1458,y:809,t:1527265150376};\\\", \\\"{x:1391,y:809,t:1527265150391};\\\", \\\"{x:1357,y:809,t:1527265150408};\\\", \\\"{x:1337,y:806,t:1527265150426};\\\", \\\"{x:1334,y:806,t:1527265150441};\\\", \\\"{x:1333,y:806,t:1527265150459};\\\", \\\"{x:1335,y:806,t:1527265150515};\\\", \\\"{x:1337,y:806,t:1527265150525};\\\", \\\"{x:1346,y:799,t:1527265150542};\\\", \\\"{x:1355,y:792,t:1527265150559};\\\", \\\"{x:1366,y:779,t:1527265150575};\\\", \\\"{x:1374,y:764,t:1527265150591};\\\", \\\"{x:1383,y:748,t:1527265150608};\\\", \\\"{x:1390,y:731,t:1527265150626};\\\", \\\"{x:1395,y:714,t:1527265150641};\\\", \\\"{x:1395,y:701,t:1527265150658};\\\", \\\"{x:1395,y:697,t:1527265150675};\\\", \\\"{x:1393,y:693,t:1527265150691};\\\", \\\"{x:1391,y:693,t:1527265150714};\\\", \\\"{x:1390,y:692,t:1527265150726};\\\", \\\"{x:1389,y:692,t:1527265150742};\\\", \\\"{x:1387,y:690,t:1527265150759};\\\", \\\"{x:1384,y:690,t:1527265150776};\\\", \\\"{x:1383,y:689,t:1527265150794};\\\", \\\"{x:1382,y:689,t:1527265150808};\\\", \\\"{x:1380,y:688,t:1527265150826};\\\", \\\"{x:1374,y:689,t:1527265150841};\\\", \\\"{x:1364,y:720,t:1527265150858};\\\", \\\"{x:1358,y:740,t:1527265150875};\\\", \\\"{x:1358,y:752,t:1527265150891};\\\", \\\"{x:1358,y:764,t:1527265150908};\\\", \\\"{x:1358,y:770,t:1527265150926};\\\", \\\"{x:1358,y:772,t:1527265150942};\\\", \\\"{x:1358,y:773,t:1527265150959};\\\", \\\"{x:1358,y:774,t:1527265151059};\\\", \\\"{x:1357,y:774,t:1527265151075};\\\", \\\"{x:1356,y:774,t:1527265151098};\\\", \\\"{x:1355,y:774,t:1527265151114};\\\", \\\"{x:1354,y:774,t:1527265151126};\\\", \\\"{x:1353,y:774,t:1527265151146};\\\", \\\"{x:1350,y:774,t:1527265151158};\\\", \\\"{x:1348,y:774,t:1527265151175};\\\", \\\"{x:1345,y:774,t:1527265151192};\\\", \\\"{x:1346,y:774,t:1527265151627};\\\", \\\"{x:1353,y:786,t:1527265151642};\\\", \\\"{x:1361,y:802,t:1527265151660};\\\", \\\"{x:1383,y:831,t:1527265151676};\\\", \\\"{x:1404,y:858,t:1527265151692};\\\", \\\"{x:1426,y:875,t:1527265151710};\\\", \\\"{x:1442,y:885,t:1527265151726};\\\", \\\"{x:1453,y:891,t:1527265151743};\\\", \\\"{x:1455,y:892,t:1527265151759};\\\", \\\"{x:1456,y:892,t:1527265151843};\\\", \\\"{x:1457,y:892,t:1527265151860};\\\", \\\"{x:1461,y:889,t:1527265151876};\\\", \\\"{x:1468,y:880,t:1527265151893};\\\", \\\"{x:1478,y:865,t:1527265151910};\\\", \\\"{x:1490,y:852,t:1527265151926};\\\", \\\"{x:1500,y:838,t:1527265151943};\\\", \\\"{x:1505,y:827,t:1527265151959};\\\", \\\"{x:1506,y:822,t:1527265151977};\\\", \\\"{x:1507,y:821,t:1527265151993};\\\", \\\"{x:1507,y:820,t:1527265152010};\\\", \\\"{x:1507,y:819,t:1527265152090};\\\", \\\"{x:1504,y:819,t:1527265152097};\\\", \\\"{x:1502,y:819,t:1527265152109};\\\", \\\"{x:1501,y:819,t:1527265152137};\\\", \\\"{x:1499,y:820,t:1527265152482};\\\", \\\"{x:1497,y:820,t:1527265152498};\\\", \\\"{x:1496,y:820,t:1527265152522};\\\", \\\"{x:1495,y:820,t:1527265152530};\\\", \\\"{x:1493,y:822,t:1527265152547};\\\", \\\"{x:1492,y:823,t:1527265152571};\\\", \\\"{x:1492,y:824,t:1527265152578};\\\", \\\"{x:1491,y:825,t:1527265152602};\\\", \\\"{x:1490,y:827,t:1527265152659};\\\", \\\"{x:1490,y:828,t:1527265152698};\\\", \\\"{x:1490,y:829,t:1527265152730};\\\", \\\"{x:1490,y:830,t:1527265152746};\\\", \\\"{x:1490,y:831,t:1527265152779};\\\", \\\"{x:1490,y:832,t:1527265152827};\\\", \\\"{x:1490,y:833,t:1527265152858};\\\", \\\"{x:1489,y:834,t:1527265152898};\\\", \\\"{x:1488,y:835,t:1527265152910};\\\", \\\"{x:1482,y:836,t:1527265152926};\\\", \\\"{x:1471,y:836,t:1527265152944};\\\", \\\"{x:1444,y:835,t:1527265152960};\\\", \\\"{x:1388,y:821,t:1527265152977};\\\", \\\"{x:1305,y:796,t:1527265152994};\\\", \\\"{x:1227,y:774,t:1527265153010};\\\", \\\"{x:1140,y:749,t:1527265153027};\\\", \\\"{x:1114,y:741,t:1527265153044};\\\", \\\"{x:1095,y:739,t:1527265153059};\\\", \\\"{x:1091,y:736,t:1527265153076};\\\", \\\"{x:1090,y:736,t:1527265153094};\\\", \\\"{x:1084,y:735,t:1527265153110};\\\", \\\"{x:1067,y:726,t:1527265153127};\\\", \\\"{x:1029,y:703,t:1527265153144};\\\", \\\"{x:957,y:655,t:1527265153160};\\\", \\\"{x:857,y:582,t:1527265153178};\\\", \\\"{x:686,y:473,t:1527265153193};\\\", \\\"{x:603,y:432,t:1527265153209};\\\", \\\"{x:556,y:412,t:1527265153227};\\\", \\\"{x:531,y:403,t:1527265153243};\\\", \\\"{x:515,y:400,t:1527265153260};\\\", \\\"{x:501,y:400,t:1527265153277};\\\", \\\"{x:486,y:406,t:1527265153294};\\\", \\\"{x:464,y:420,t:1527265153310};\\\", \\\"{x:443,y:439,t:1527265153327};\\\", \\\"{x:424,y:457,t:1527265153344};\\\", \\\"{x:413,y:469,t:1527265153360};\\\", \\\"{x:410,y:485,t:1527265153377};\\\", \\\"{x:408,y:498,t:1527265153394};\\\", \\\"{x:408,y:512,t:1527265153410};\\\", \\\"{x:408,y:528,t:1527265153428};\\\", \\\"{x:408,y:541,t:1527265153444};\\\", \\\"{x:408,y:550,t:1527265153460};\\\", \\\"{x:410,y:559,t:1527265153478};\\\", \\\"{x:411,y:562,t:1527265153494};\\\", \\\"{x:411,y:565,t:1527265153510};\\\", \\\"{x:411,y:573,t:1527265153527};\\\", \\\"{x:411,y:581,t:1527265153544};\\\", \\\"{x:412,y:591,t:1527265153560};\\\", \\\"{x:423,y:607,t:1527265153578};\\\", \\\"{x:437,y:614,t:1527265153594};\\\", \\\"{x:463,y:623,t:1527265153610};\\\", \\\"{x:490,y:630,t:1527265153627};\\\", \\\"{x:518,y:634,t:1527265153645};\\\", \\\"{x:545,y:634,t:1527265153661};\\\", \\\"{x:563,y:632,t:1527265153677};\\\", \\\"{x:577,y:629,t:1527265153694};\\\", \\\"{x:585,y:627,t:1527265153711};\\\", \\\"{x:588,y:625,t:1527265153727};\\\", \\\"{x:590,y:625,t:1527265153744};\\\", \\\"{x:591,y:624,t:1527265153761};\\\", \\\"{x:592,y:624,t:1527265153802};\\\", \\\"{x:593,y:622,t:1527265153811};\\\", \\\"{x:593,y:620,t:1527265153827};\\\", \\\"{x:596,y:613,t:1527265153845};\\\", \\\"{x:598,y:608,t:1527265153861};\\\", \\\"{x:600,y:604,t:1527265153878};\\\", \\\"{x:602,y:600,t:1527265153895};\\\", \\\"{x:604,y:597,t:1527265153911};\\\", \\\"{x:605,y:594,t:1527265153927};\\\", \\\"{x:609,y:589,t:1527265153944};\\\", \\\"{x:613,y:584,t:1527265153961};\\\", \\\"{x:613,y:585,t:1527265154209};\\\", \\\"{x:613,y:594,t:1527265154218};\\\", \\\"{x:608,y:608,t:1527265154228};\\\", \\\"{x:600,y:643,t:1527265154244};\\\", \\\"{x:587,y:686,t:1527265154261};\\\", \\\"{x:577,y:708,t:1527265154278};\\\", \\\"{x:569,y:727,t:1527265154293};\\\", \\\"{x:561,y:744,t:1527265154312};\\\", \\\"{x:557,y:755,t:1527265154329};\\\", \\\"{x:554,y:761,t:1527265154344};\\\", \\\"{x:552,y:767,t:1527265154361};\\\", \\\"{x:552,y:770,t:1527265154377};\\\", \\\"{x:551,y:774,t:1527265154394};\\\", \\\"{x:547,y:778,t:1527265154411};\\\", \\\"{x:545,y:780,t:1527265154427};\\\", \\\"{x:544,y:782,t:1527265154444};\\\", \\\"{x:543,y:781,t:1527265154481};\\\", \\\"{x:543,y:778,t:1527265154494};\\\", \\\"{x:541,y:768,t:1527265154511};\\\", \\\"{x:540,y:757,t:1527265154527};\\\", \\\"{x:538,y:751,t:1527265154545};\\\", \\\"{x:537,y:749,t:1527265154561};\\\", \\\"{x:536,y:748,t:1527265154578};\\\" ] }, { \\\"rt\\\": 42467, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 783775, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-02 PM-02 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:744,t:1527265157939};\\\", \\\"{x:557,y:732,t:1527265157950};\\\", \\\"{x:586,y:720,t:1527265157969};\\\", \\\"{x:613,y:710,t:1527265157982};\\\", \\\"{x:655,y:699,t:1527265157996};\\\", \\\"{x:699,y:680,t:1527265158013};\\\", \\\"{x:717,y:666,t:1527265158029};\\\", \\\"{x:722,y:651,t:1527265158046};\\\", \\\"{x:723,y:641,t:1527265158063};\\\", \\\"{x:720,y:626,t:1527265158080};\\\", \\\"{x:711,y:615,t:1527265158096};\\\", \\\"{x:700,y:593,t:1527265158114};\\\", \\\"{x:691,y:578,t:1527265158131};\\\", \\\"{x:674,y:553,t:1527265158148};\\\", \\\"{x:655,y:530,t:1527265158164};\\\", \\\"{x:640,y:514,t:1527265158182};\\\", \\\"{x:628,y:506,t:1527265158197};\\\", \\\"{x:626,y:504,t:1527265158214};\\\", \\\"{x:624,y:503,t:1527265158231};\\\", \\\"{x:621,y:500,t:1527265158425};\\\", \\\"{x:616,y:492,t:1527265158433};\\\", \\\"{x:613,y:487,t:1527265158448};\\\", \\\"{x:609,y:481,t:1527265158464};\\\", \\\"{x:606,y:474,t:1527265158481};\\\", \\\"{x:605,y:470,t:1527265158498};\\\", \\\"{x:605,y:467,t:1527265158514};\\\", \\\"{x:605,y:464,t:1527265158531};\\\", \\\"{x:604,y:464,t:1527265158548};\\\", \\\"{x:604,y:463,t:1527265158585};\\\", \\\"{x:605,y:461,t:1527265158601};\\\", \\\"{x:609,y:460,t:1527265158615};\\\", \\\"{x:629,y:459,t:1527265158631};\\\", \\\"{x:678,y:459,t:1527265158649};\\\", \\\"{x:824,y:478,t:1527265158666};\\\", \\\"{x:942,y:503,t:1527265158683};\\\", \\\"{x:1085,y:542,t:1527265158698};\\\", \\\"{x:1207,y:577,t:1527265158715};\\\", \\\"{x:1325,y:621,t:1527265158730};\\\", \\\"{x:1427,y:664,t:1527265158748};\\\", \\\"{x:1482,y:698,t:1527265158763};\\\", \\\"{x:1512,y:724,t:1527265158780};\\\", \\\"{x:1527,y:753,t:1527265158797};\\\", \\\"{x:1537,y:782,t:1527265158813};\\\", \\\"{x:1548,y:819,t:1527265158830};\\\", \\\"{x:1551,y:826,t:1527265158847};\\\", \\\"{x:1551,y:828,t:1527265159347};\\\", \\\"{x:1547,y:849,t:1527265159363};\\\", \\\"{x:1537,y:882,t:1527265159380};\\\", \\\"{x:1529,y:913,t:1527265159396};\\\", \\\"{x:1525,y:936,t:1527265159413};\\\", \\\"{x:1522,y:961,t:1527265159429};\\\", \\\"{x:1520,y:979,t:1527265159445};\\\", \\\"{x:1520,y:994,t:1527265159462};\\\", \\\"{x:1522,y:1009,t:1527265159478};\\\", \\\"{x:1532,y:1023,t:1527265159495};\\\", \\\"{x:1542,y:1031,t:1527265159512};\\\", \\\"{x:1552,y:1033,t:1527265159528};\\\", \\\"{x:1566,y:1034,t:1527265159545};\\\", \\\"{x:1572,y:1034,t:1527265159562};\\\", \\\"{x:1582,y:1030,t:1527265159578};\\\", \\\"{x:1589,y:1025,t:1527265159596};\\\", \\\"{x:1600,y:1016,t:1527265159611};\\\", \\\"{x:1604,y:1010,t:1527265159628};\\\", \\\"{x:1607,y:1001,t:1527265159646};\\\", \\\"{x:1608,y:997,t:1527265159661};\\\", \\\"{x:1608,y:995,t:1527265159679};\\\", \\\"{x:1607,y:994,t:1527265159695};\\\", \\\"{x:1601,y:994,t:1527265159712};\\\", \\\"{x:1591,y:993,t:1527265159729};\\\", \\\"{x:1581,y:992,t:1527265159745};\\\", \\\"{x:1562,y:989,t:1527265159762};\\\", \\\"{x:1547,y:985,t:1527265159777};\\\", \\\"{x:1540,y:983,t:1527265159795};\\\", \\\"{x:1536,y:983,t:1527265159812};\\\", \\\"{x:1534,y:981,t:1527265159827};\\\", \\\"{x:1532,y:978,t:1527265159844};\\\", \\\"{x:1530,y:974,t:1527265159861};\\\", \\\"{x:1529,y:972,t:1527265159878};\\\", \\\"{x:1528,y:967,t:1527265159896};\\\", \\\"{x:1528,y:965,t:1527265159912};\\\", \\\"{x:1528,y:962,t:1527265159928};\\\", \\\"{x:1528,y:957,t:1527265159945};\\\", \\\"{x:1529,y:955,t:1527265159961};\\\", \\\"{x:1530,y:953,t:1527265159978};\\\", \\\"{x:1531,y:953,t:1527265160010};\\\", \\\"{x:1531,y:952,t:1527265160028};\\\", \\\"{x:1532,y:952,t:1527265160050};\\\", \\\"{x:1533,y:951,t:1527265160061};\\\", \\\"{x:1535,y:951,t:1527265160082};\\\", \\\"{x:1535,y:950,t:1527265160093};\\\", \\\"{x:1536,y:950,t:1527265160111};\\\", \\\"{x:1537,y:950,t:1527265160138};\\\", \\\"{x:1538,y:949,t:1527265160146};\\\", \\\"{x:1539,y:948,t:1527265160186};\\\", \\\"{x:1540,y:948,t:1527265160227};\\\", \\\"{x:1541,y:948,t:1527265160259};\\\", \\\"{x:1542,y:949,t:1527265160411};\\\", \\\"{x:1546,y:953,t:1527265160427};\\\", \\\"{x:1549,y:957,t:1527265160444};\\\", \\\"{x:1550,y:958,t:1527265160459};\\\", \\\"{x:1552,y:960,t:1527265160476};\\\", \\\"{x:1553,y:961,t:1527265160494};\\\", \\\"{x:1554,y:961,t:1527265160509};\\\", \\\"{x:1555,y:962,t:1527265160527};\\\", \\\"{x:1555,y:963,t:1527265160873};\\\", \\\"{x:1555,y:964,t:1527265160881};\\\", \\\"{x:1555,y:966,t:1527265160892};\\\", \\\"{x:1555,y:967,t:1527265161139};\\\", \\\"{x:1555,y:969,t:1527265161203};\\\", \\\"{x:1555,y:970,t:1527265161363};\\\", \\\"{x:1554,y:970,t:1527265161378};\\\", \\\"{x:1553,y:970,t:1527265161391};\\\", \\\"{x:1552,y:970,t:1527265161407};\\\", \\\"{x:1547,y:969,t:1527265173147};\\\", \\\"{x:1429,y:907,t:1527265173163};\\\", \\\"{x:1312,y:845,t:1527265173179};\\\", \\\"{x:1185,y:789,t:1527265173196};\\\", \\\"{x:1019,y:733,t:1527265173213};\\\", \\\"{x:849,y:702,t:1527265173228};\\\", \\\"{x:734,y:691,t:1527265173245};\\\", \\\"{x:680,y:700,t:1527265173262};\\\", \\\"{x:656,y:719,t:1527265173279};\\\", \\\"{x:646,y:737,t:1527265173295};\\\", \\\"{x:646,y:744,t:1527265173312};\\\", \\\"{x:646,y:749,t:1527265173329};\\\", \\\"{x:646,y:753,t:1527265173346};\\\", \\\"{x:646,y:754,t:1527265173361};\\\", \\\"{x:646,y:748,t:1527265173458};\\\", \\\"{x:643,y:736,t:1527265173466};\\\", \\\"{x:637,y:719,t:1527265173478};\\\", \\\"{x:611,y:671,t:1527265173495};\\\", \\\"{x:568,y:624,t:1527265173513};\\\", \\\"{x:513,y:598,t:1527265173529};\\\", \\\"{x:431,y:584,t:1527265173561};\\\", \\\"{x:397,y:582,t:1527265173572};\\\", \\\"{x:361,y:582,t:1527265173589};\\\", \\\"{x:355,y:587,t:1527265173610};\\\", \\\"{x:358,y:584,t:1527265173874};\\\", \\\"{x:358,y:578,t:1527265173882};\\\", \\\"{x:358,y:576,t:1527265173897};\\\", \\\"{x:357,y:575,t:1527265173910};\\\", \\\"{x:354,y:573,t:1527265173927};\\\", \\\"{x:348,y:572,t:1527265173943};\\\", \\\"{x:341,y:569,t:1527265173960};\\\", \\\"{x:328,y:567,t:1527265173976};\\\", \\\"{x:307,y:567,t:1527265173994};\\\", \\\"{x:287,y:567,t:1527265174010};\\\", \\\"{x:269,y:567,t:1527265174028};\\\", \\\"{x:254,y:567,t:1527265174042};\\\", \\\"{x:243,y:568,t:1527265174060};\\\", \\\"{x:238,y:569,t:1527265174077};\\\", \\\"{x:234,y:570,t:1527265174094};\\\", \\\"{x:232,y:571,t:1527265174110};\\\", \\\"{x:230,y:572,t:1527265174127};\\\", \\\"{x:226,y:572,t:1527265174143};\\\", \\\"{x:214,y:569,t:1527265174161};\\\", \\\"{x:200,y:562,t:1527265174177};\\\", \\\"{x:180,y:554,t:1527265174195};\\\", \\\"{x:169,y:552,t:1527265174211};\\\", \\\"{x:166,y:550,t:1527265174227};\\\", \\\"{x:165,y:550,t:1527265174244};\\\", \\\"{x:165,y:549,t:1527265174281};\\\", \\\"{x:165,y:548,t:1527265174294};\\\", \\\"{x:164,y:545,t:1527265174311};\\\", \\\"{x:163,y:542,t:1527265174327};\\\", \\\"{x:171,y:543,t:1527265174657};\\\", \\\"{x:188,y:543,t:1527265174665};\\\", \\\"{x:216,y:543,t:1527265174679};\\\", \\\"{x:288,y:543,t:1527265174694};\\\", \\\"{x:393,y:543,t:1527265174711};\\\", \\\"{x:512,y:543,t:1527265174728};\\\", \\\"{x:626,y:543,t:1527265174744};\\\", \\\"{x:776,y:543,t:1527265174761};\\\", \\\"{x:870,y:557,t:1527265174779};\\\", \\\"{x:962,y:582,t:1527265174793};\\\", \\\"{x:1063,y:620,t:1527265174811};\\\", \\\"{x:1142,y:667,t:1527265174828};\\\", \\\"{x:1205,y:716,t:1527265174844};\\\", \\\"{x:1263,y:771,t:1527265174861};\\\", \\\"{x:1321,y:831,t:1527265174878};\\\", \\\"{x:1373,y:889,t:1527265174894};\\\", \\\"{x:1429,y:939,t:1527265174911};\\\", \\\"{x:1480,y:976,t:1527265174928};\\\", \\\"{x:1513,y:997,t:1527265174944};\\\", \\\"{x:1533,y:1009,t:1527265174961};\\\", \\\"{x:1534,y:1009,t:1527265175010};\\\", \\\"{x:1536,y:1009,t:1527265175363};\\\", \\\"{x:1533,y:1009,t:1527265175393};\\\", \\\"{x:1530,y:1006,t:1527265175412};\\\", \\\"{x:1516,y:999,t:1527265175427};\\\", \\\"{x:1513,y:996,t:1527265175450};\\\", \\\"{x:1506,y:992,t:1527265175462};\\\", \\\"{x:1500,y:986,t:1527265175477};\\\", \\\"{x:1491,y:977,t:1527265175495};\\\", \\\"{x:1483,y:967,t:1527265175512};\\\", \\\"{x:1475,y:950,t:1527265175527};\\\", \\\"{x:1469,y:926,t:1527265175545};\\\", \\\"{x:1455,y:885,t:1527265175562};\\\", \\\"{x:1437,y:846,t:1527265175577};\\\", \\\"{x:1417,y:797,t:1527265175594};\\\", \\\"{x:1402,y:764,t:1527265175612};\\\", \\\"{x:1396,y:745,t:1527265175628};\\\", \\\"{x:1391,y:731,t:1527265175644};\\\", \\\"{x:1387,y:720,t:1527265175661};\\\", \\\"{x:1382,y:707,t:1527265175677};\\\", \\\"{x:1374,y:695,t:1527265175694};\\\", \\\"{x:1365,y:684,t:1527265175711};\\\", \\\"{x:1355,y:679,t:1527265175727};\\\", \\\"{x:1352,y:678,t:1527265175744};\\\", \\\"{x:1351,y:678,t:1527265175761};\\\", \\\"{x:1350,y:678,t:1527265175786};\\\", \\\"{x:1348,y:678,t:1527265175794};\\\", \\\"{x:1339,y:682,t:1527265175811};\\\", \\\"{x:1328,y:696,t:1527265175827};\\\", \\\"{x:1321,y:710,t:1527265175845};\\\", \\\"{x:1318,y:726,t:1527265175861};\\\", \\\"{x:1318,y:738,t:1527265175878};\\\", \\\"{x:1318,y:751,t:1527265175894};\\\", \\\"{x:1320,y:762,t:1527265175910};\\\", \\\"{x:1335,y:783,t:1527265175928};\\\", \\\"{x:1356,y:813,t:1527265175945};\\\", \\\"{x:1373,y:836,t:1527265175961};\\\", \\\"{x:1380,y:848,t:1527265175978};\\\", \\\"{x:1377,y:844,t:1527265176042};\\\", \\\"{x:1374,y:837,t:1527265176050};\\\", \\\"{x:1369,y:831,t:1527265176061};\\\", \\\"{x:1361,y:817,t:1527265176078};\\\", \\\"{x:1350,y:801,t:1527265176094};\\\", \\\"{x:1341,y:788,t:1527265176111};\\\", \\\"{x:1333,y:777,t:1527265176127};\\\", \\\"{x:1324,y:768,t:1527265176144};\\\", \\\"{x:1316,y:762,t:1527265176159};\\\", \\\"{x:1311,y:758,t:1527265176177};\\\", \\\"{x:1311,y:759,t:1527265176394};\\\", \\\"{x:1312,y:761,t:1527265176986};\\\", \\\"{x:1311,y:765,t:1527265176993};\\\", \\\"{x:1305,y:773,t:1527265177011};\\\", \\\"{x:1304,y:775,t:1527265177027};\\\", \\\"{x:1303,y:775,t:1527265177044};\\\", \\\"{x:1303,y:776,t:1527265177061};\\\", \\\"{x:1303,y:777,t:1527265177082};\\\", \\\"{x:1294,y:771,t:1527265197668};\\\", \\\"{x:1267,y:756,t:1527265197676};\\\", \\\"{x:1236,y:734,t:1527265197688};\\\", \\\"{x:1154,y:668,t:1527265197705};\\\", \\\"{x:1049,y:603,t:1527265197720};\\\", \\\"{x:926,y:554,t:1527265197739};\\\", \\\"{x:839,y:548,t:1527265197755};\\\", \\\"{x:793,y:562,t:1527265197771};\\\", \\\"{x:752,y:607,t:1527265197798};\\\", \\\"{x:744,y:624,t:1527265197814};\\\", \\\"{x:737,y:630,t:1527265197832};\\\", \\\"{x:725,y:633,t:1527265197849};\\\", \\\"{x:704,y:636,t:1527265197865};\\\", \\\"{x:676,y:645,t:1527265197882};\\\", \\\"{x:626,y:675,t:1527265197900};\\\", \\\"{x:607,y:689,t:1527265197916};\\\", \\\"{x:593,y:695,t:1527265197933};\\\", \\\"{x:572,y:698,t:1527265197949};\\\", \\\"{x:550,y:698,t:1527265197966};\\\", \\\"{x:521,y:698,t:1527265197982};\\\", \\\"{x:497,y:698,t:1527265198000};\\\", \\\"{x:473,y:702,t:1527265198017};\\\", \\\"{x:453,y:707,t:1527265198033};\\\", \\\"{x:440,y:712,t:1527265198050};\\\", \\\"{x:433,y:715,t:1527265198067};\\\", \\\"{x:433,y:718,t:1527265198083};\\\", \\\"{x:433,y:719,t:1527265198101};\\\", \\\"{x:433,y:720,t:1527265198197};\\\", \\\"{x:433,y:723,t:1527265198205};\\\", \\\"{x:433,y:728,t:1527265198217};\\\", \\\"{x:436,y:743,t:1527265198234};\\\", \\\"{x:446,y:754,t:1527265198250};\\\", \\\"{x:454,y:759,t:1527265198267};\\\", \\\"{x:461,y:761,t:1527265198283};\\\", \\\"{x:464,y:761,t:1527265198301};\\\", \\\"{x:466,y:761,t:1527265198318};\\\", \\\"{x:469,y:760,t:1527265198508};\\\", \\\"{x:476,y:754,t:1527265198518};\\\", \\\"{x:491,y:746,t:1527265198533};\\\", \\\"{x:498,y:743,t:1527265198550};\\\", \\\"{x:500,y:740,t:1527265198566};\\\", \\\"{x:501,y:738,t:1527265198583};\\\" ] }, { \\\"rt\\\": 102021, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 887054, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-04 PM-03 PM-02 PM-6-F -B -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:728,t:1527265202862};\\\", \\\"{x:547,y:712,t:1527265202870};\\\", \\\"{x:645,y:661,t:1527265202887};\\\", \\\"{x:760,y:593,t:1527265202903};\\\", \\\"{x:898,y:509,t:1527265202920};\\\", \\\"{x:1054,y:416,t:1527265202936};\\\", \\\"{x:1200,y:347,t:1527265202953};\\\", \\\"{x:1329,y:297,t:1527265202970};\\\", \\\"{x:1414,y:278,t:1527265202986};\\\", \\\"{x:1454,y:277,t:1527265203002};\\\", \\\"{x:1524,y:290,t:1527265203019};\\\", \\\"{x:1554,y:309,t:1527265203037};\\\", \\\"{x:1590,y:343,t:1527265203053};\\\", \\\"{x:1637,y:396,t:1527265203070};\\\", \\\"{x:1679,y:450,t:1527265203086};\\\", \\\"{x:1713,y:493,t:1527265203103};\\\", \\\"{x:1723,y:515,t:1527265203120};\\\", \\\"{x:1724,y:515,t:1527265203136};\\\", \\\"{x:1725,y:514,t:1527265203620};\\\", \\\"{x:1728,y:513,t:1527265203637};\\\", \\\"{x:1736,y:510,t:1527265203654};\\\", \\\"{x:1740,y:509,t:1527265203670};\\\", \\\"{x:1742,y:508,t:1527265203687};\\\", \\\"{x:1745,y:507,t:1527265203703};\\\", \\\"{x:1746,y:506,t:1527265203732};\\\", \\\"{x:1744,y:506,t:1527265203845};\\\", \\\"{x:1743,y:506,t:1527265203853};\\\", \\\"{x:1738,y:507,t:1527265203869};\\\", \\\"{x:1734,y:509,t:1527265203887};\\\", \\\"{x:1729,y:509,t:1527265203903};\\\", \\\"{x:1724,y:509,t:1527265203920};\\\", \\\"{x:1719,y:509,t:1527265203936};\\\", \\\"{x:1712,y:510,t:1527265203953};\\\", \\\"{x:1707,y:511,t:1527265203970};\\\", \\\"{x:1699,y:511,t:1527265203987};\\\", \\\"{x:1666,y:520,t:1527265204003};\\\", \\\"{x:1525,y:546,t:1527265204020};\\\", \\\"{x:1484,y:553,t:1527265204036};\\\", \\\"{x:1390,y:588,t:1527265204052};\\\", \\\"{x:1324,y:614,t:1527265204070};\\\", \\\"{x:1260,y:643,t:1527265204085};\\\", \\\"{x:1201,y:676,t:1527265204102};\\\", \\\"{x:1149,y:706,t:1527265204119};\\\", \\\"{x:1110,y:730,t:1527265204135};\\\", \\\"{x:1109,y:732,t:1527265204153};\\\", \\\"{x:1109,y:733,t:1527265205597};\\\", \\\"{x:1109,y:734,t:1527265205844};\\\", \\\"{x:1109,y:733,t:1527265207220};\\\", \\\"{x:1108,y:733,t:1527265207236};\\\", \\\"{x:1108,y:737,t:1527265210173};\\\", \\\"{x:1108,y:747,t:1527265210181};\\\", \\\"{x:1108,y:762,t:1527265210197};\\\", \\\"{x:1108,y:773,t:1527265210214};\\\", \\\"{x:1108,y:784,t:1527265210231};\\\", \\\"{x:1109,y:791,t:1527265210247};\\\", \\\"{x:1112,y:798,t:1527265210264};\\\", \\\"{x:1118,y:804,t:1527265210280};\\\", \\\"{x:1123,y:808,t:1527265210296};\\\", \\\"{x:1132,y:815,t:1527265210313};\\\", \\\"{x:1145,y:821,t:1527265210331};\\\", \\\"{x:1164,y:829,t:1527265210347};\\\", \\\"{x:1225,y:856,t:1527265210365};\\\", \\\"{x:1294,y:883,t:1527265210381};\\\", \\\"{x:1380,y:910,t:1527265210397};\\\", \\\"{x:1459,y:938,t:1527265210414};\\\", \\\"{x:1534,y:958,t:1527265210431};\\\", \\\"{x:1593,y:968,t:1527265210447};\\\", \\\"{x:1630,y:974,t:1527265210465};\\\", \\\"{x:1650,y:977,t:1527265210482};\\\", \\\"{x:1663,y:979,t:1527265210497};\\\", \\\"{x:1669,y:979,t:1527265210514};\\\", \\\"{x:1671,y:979,t:1527265210529};\\\", \\\"{x:1672,y:979,t:1527265210548};\\\", \\\"{x:1671,y:979,t:1527265210652};\\\", \\\"{x:1667,y:979,t:1527265210664};\\\", \\\"{x:1653,y:979,t:1527265210680};\\\", \\\"{x:1631,y:979,t:1527265210697};\\\", \\\"{x:1593,y:979,t:1527265210714};\\\", \\\"{x:1546,y:979,t:1527265210730};\\\", \\\"{x:1497,y:977,t:1527265210747};\\\", \\\"{x:1430,y:967,t:1527265210764};\\\", \\\"{x:1407,y:963,t:1527265210781};\\\", \\\"{x:1402,y:962,t:1527265210797};\\\", \\\"{x:1401,y:961,t:1527265210814};\\\", \\\"{x:1401,y:959,t:1527265210829};\\\", \\\"{x:1410,y:957,t:1527265210847};\\\", \\\"{x:1426,y:954,t:1527265210863};\\\", \\\"{x:1441,y:952,t:1527265210879};\\\", \\\"{x:1454,y:948,t:1527265210896};\\\", \\\"{x:1460,y:946,t:1527265210913};\\\", \\\"{x:1465,y:945,t:1527265210929};\\\", \\\"{x:1472,y:944,t:1527265210947};\\\", \\\"{x:1480,y:943,t:1527265210963};\\\", \\\"{x:1493,y:941,t:1527265210980};\\\", \\\"{x:1503,y:941,t:1527265210996};\\\", \\\"{x:1512,y:941,t:1527265211013};\\\", \\\"{x:1518,y:941,t:1527265211030};\\\", \\\"{x:1521,y:941,t:1527265211047};\\\", \\\"{x:1520,y:941,t:1527265211125};\\\", \\\"{x:1519,y:943,t:1527265211132};\\\", \\\"{x:1516,y:946,t:1527265211147};\\\", \\\"{x:1510,y:951,t:1527265211163};\\\", \\\"{x:1498,y:958,t:1527265211180};\\\", \\\"{x:1491,y:962,t:1527265211197};\\\", \\\"{x:1488,y:963,t:1527265211214};\\\", \\\"{x:1485,y:964,t:1527265211230};\\\", \\\"{x:1484,y:965,t:1527265211247};\\\", \\\"{x:1482,y:966,t:1527265211412};\\\", \\\"{x:1481,y:966,t:1527265211476};\\\", \\\"{x:1479,y:955,t:1527265265503};\\\", \\\"{x:1490,y:673,t:1527265265518};\\\", \\\"{x:1464,y:484,t:1527265265536};\\\", \\\"{x:1399,y:362,t:1527265265552};\\\", \\\"{x:1289,y:264,t:1527265265569};\\\", \\\"{x:1146,y:175,t:1527265265585};\\\", \\\"{x:965,y:106,t:1527265265602};\\\", \\\"{x:774,y:72,t:1527265265618};\\\", \\\"{x:593,y:73,t:1527265265635};\\\", \\\"{x:439,y:111,t:1527265265651};\\\", \\\"{x:317,y:164,t:1527265265668};\\\", \\\"{x:243,y:226,t:1527265265684};\\\", \\\"{x:215,y:268,t:1527265265701};\\\", \\\"{x:207,y:310,t:1527265265718};\\\", \\\"{x:207,y:335,t:1527265265735};\\\", \\\"{x:207,y:347,t:1527265265751};\\\", \\\"{x:207,y:354,t:1527265265768};\\\", \\\"{x:207,y:357,t:1527265265785};\\\", \\\"{x:207,y:360,t:1527265265801};\\\", \\\"{x:207,y:362,t:1527265265818};\\\", \\\"{x:208,y:370,t:1527265265834};\\\", \\\"{x:213,y:390,t:1527265265852};\\\", \\\"{x:224,y:424,t:1527265265869};\\\", \\\"{x:240,y:465,t:1527265265885};\\\", \\\"{x:256,y:503,t:1527265265902};\\\", \\\"{x:283,y:554,t:1527265265918};\\\", \\\"{x:293,y:571,t:1527265265934};\\\", \\\"{x:294,y:573,t:1527265265957};\\\", \\\"{x:294,y:575,t:1527265265974};\\\", \\\"{x:293,y:577,t:1527265265992};\\\", \\\"{x:292,y:577,t:1527265266022};\\\", \\\"{x:291,y:577,t:1527265266046};\\\", \\\"{x:290,y:577,t:1527265266058};\\\", \\\"{x:285,y:577,t:1527265266075};\\\", \\\"{x:279,y:577,t:1527265266091};\\\", \\\"{x:266,y:574,t:1527265266109};\\\", \\\"{x:246,y:572,t:1527265266125};\\\", \\\"{x:224,y:568,t:1527265266141};\\\", \\\"{x:193,y:568,t:1527265266158};\\\", \\\"{x:178,y:568,t:1527265266174};\\\", \\\"{x:172,y:566,t:1527265266191};\\\", \\\"{x:171,y:565,t:1527265266208};\\\", \\\"{x:170,y:565,t:1527265266343};\\\", \\\"{x:170,y:571,t:1527265266359};\\\", \\\"{x:171,y:578,t:1527265266376};\\\", \\\"{x:171,y:583,t:1527265266392};\\\", \\\"{x:171,y:587,t:1527265266407};\\\", \\\"{x:171,y:592,t:1527265266424};\\\", \\\"{x:171,y:599,t:1527265266440};\\\", \\\"{x:166,y:611,t:1527265266458};\\\", \\\"{x:160,y:624,t:1527265266475};\\\", \\\"{x:154,y:639,t:1527265266491};\\\", \\\"{x:144,y:655,t:1527265266509};\\\", \\\"{x:137,y:670,t:1527265266525};\\\", \\\"{x:136,y:677,t:1527265266541};\\\", \\\"{x:136,y:682,t:1527265266558};\\\", \\\"{x:140,y:684,t:1527265266575};\\\", \\\"{x:151,y:685,t:1527265266591};\\\", \\\"{x:172,y:689,t:1527265266608};\\\", \\\"{x:205,y:692,t:1527265266625};\\\", \\\"{x:257,y:696,t:1527265266641};\\\", \\\"{x:289,y:695,t:1527265266658};\\\", \\\"{x:330,y:679,t:1527265266676};\\\", \\\"{x:357,y:663,t:1527265266692};\\\", \\\"{x:374,y:648,t:1527265266709};\\\", \\\"{x:384,y:640,t:1527265266729};\\\", \\\"{x:391,y:633,t:1527265266741};\\\", \\\"{x:395,y:630,t:1527265266758};\\\", \\\"{x:400,y:627,t:1527265266775};\\\", \\\"{x:406,y:624,t:1527265266792};\\\", \\\"{x:415,y:619,t:1527265266808};\\\", \\\"{x:423,y:615,t:1527265266825};\\\", \\\"{x:433,y:611,t:1527265266843};\\\", \\\"{x:443,y:605,t:1527265266859};\\\", \\\"{x:458,y:598,t:1527265266874};\\\", \\\"{x:478,y:593,t:1527265266891};\\\", \\\"{x:500,y:590,t:1527265266908};\\\", \\\"{x:526,y:588,t:1527265266925};\\\", \\\"{x:565,y:588,t:1527265266942};\\\", \\\"{x:592,y:588,t:1527265266958};\\\", \\\"{x:621,y:588,t:1527265266976};\\\", \\\"{x:657,y:588,t:1527265266993};\\\", \\\"{x:723,y:593,t:1527265267008};\\\", \\\"{x:806,y:593,t:1527265267026};\\\", \\\"{x:882,y:594,t:1527265267042};\\\", \\\"{x:954,y:594,t:1527265267059};\\\", \\\"{x:1007,y:594,t:1527265267076};\\\", \\\"{x:1046,y:594,t:1527265267093};\\\", \\\"{x:1066,y:594,t:1527265267108};\\\", \\\"{x:1072,y:590,t:1527265267126};\\\", \\\"{x:1074,y:585,t:1527265267142};\\\", \\\"{x:1074,y:578,t:1527265267158};\\\", \\\"{x:1073,y:572,t:1527265267176};\\\", \\\"{x:1066,y:563,t:1527265267193};\\\", \\\"{x:1060,y:555,t:1527265267209};\\\", \\\"{x:1051,y:549,t:1527265267226};\\\", \\\"{x:1042,y:547,t:1527265267242};\\\", \\\"{x:1034,y:545,t:1527265267258};\\\", \\\"{x:1023,y:546,t:1527265267275};\\\", \\\"{x:1010,y:552,t:1527265267293};\\\", \\\"{x:999,y:559,t:1527265267310};\\\", \\\"{x:989,y:561,t:1527265267326};\\\", \\\"{x:984,y:560,t:1527265267343};\\\", \\\"{x:977,y:555,t:1527265267359};\\\", \\\"{x:974,y:551,t:1527265267376};\\\", \\\"{x:969,y:544,t:1527265267392};\\\", \\\"{x:963,y:540,t:1527265267410};\\\", \\\"{x:951,y:535,t:1527265267426};\\\", \\\"{x:939,y:530,t:1527265267444};\\\", \\\"{x:925,y:528,t:1527265267459};\\\", \\\"{x:917,y:528,t:1527265267475};\\\", \\\"{x:913,y:528,t:1527265267492};\\\", \\\"{x:911,y:528,t:1527265267509};\\\", \\\"{x:910,y:528,t:1527265267535};\\\", \\\"{x:909,y:528,t:1527265267543};\\\", \\\"{x:906,y:528,t:1527265267559};\\\", \\\"{x:901,y:528,t:1527265267576};\\\", \\\"{x:896,y:528,t:1527265267592};\\\", \\\"{x:892,y:528,t:1527265267609};\\\", \\\"{x:886,y:528,t:1527265267626};\\\", \\\"{x:882,y:526,t:1527265267642};\\\", \\\"{x:878,y:524,t:1527265267659};\\\", \\\"{x:873,y:521,t:1527265267676};\\\", \\\"{x:864,y:516,t:1527265267693};\\\", \\\"{x:850,y:509,t:1527265267709};\\\", \\\"{x:837,y:504,t:1527265267726};\\\", \\\"{x:833,y:502,t:1527265267743};\\\", \\\"{x:832,y:502,t:1527265267760};\\\", \\\"{x:831,y:506,t:1527265268031};\\\", \\\"{x:831,y:512,t:1527265268043};\\\", \\\"{x:830,y:519,t:1527265268059};\\\", \\\"{x:830,y:526,t:1527265268076};\\\", \\\"{x:830,y:531,t:1527265268093};\\\", \\\"{x:830,y:533,t:1527265268109};\\\", \\\"{x:830,y:534,t:1527265268191};\\\", \\\"{x:831,y:534,t:1527265268207};\\\", \\\"{x:832,y:531,t:1527265268224};\\\", \\\"{x:834,y:526,t:1527265268244};\\\", \\\"{x:836,y:522,t:1527265268260};\\\", \\\"{x:836,y:520,t:1527265268276};\\\", \\\"{x:836,y:519,t:1527265268293};\\\", \\\"{x:837,y:519,t:1527265268494};\\\", \\\"{x:838,y:519,t:1527265268518};\\\", \\\"{x:841,y:519,t:1527265268526};\\\", \\\"{x:864,y:521,t:1527265268543};\\\", \\\"{x:935,y:549,t:1527265268561};\\\", \\\"{x:1023,y:586,t:1527265268577};\\\", \\\"{x:1128,y:631,t:1527265268593};\\\", \\\"{x:1245,y:691,t:1527265268609};\\\", \\\"{x:1351,y:747,t:1527265268627};\\\", \\\"{x:1382,y:768,t:1527265268643};\\\", \\\"{x:1382,y:769,t:1527265268659};\\\", \\\"{x:1380,y:766,t:1527265269144};\\\", \\\"{x:1377,y:755,t:1527265269161};\\\", \\\"{x:1372,y:742,t:1527265269177};\\\", \\\"{x:1368,y:730,t:1527265269194};\\\", \\\"{x:1363,y:721,t:1527265269211};\\\", \\\"{x:1363,y:717,t:1527265269227};\\\", \\\"{x:1362,y:715,t:1527265269244};\\\", \\\"{x:1362,y:714,t:1527265269263};\\\", \\\"{x:1362,y:712,t:1527265269279};\\\", \\\"{x:1362,y:711,t:1527265269294};\\\", \\\"{x:1361,y:705,t:1527265269311};\\\", \\\"{x:1359,y:697,t:1527265269327};\\\", \\\"{x:1358,y:691,t:1527265269344};\\\", \\\"{x:1357,y:686,t:1527265269361};\\\", \\\"{x:1357,y:684,t:1527265269377};\\\", \\\"{x:1356,y:684,t:1527265269415};\\\", \\\"{x:1354,y:684,t:1527265269428};\\\", \\\"{x:1347,y:688,t:1527265269444};\\\", \\\"{x:1341,y:703,t:1527265269462};\\\", \\\"{x:1335,y:720,t:1527265269478};\\\", \\\"{x:1331,y:740,t:1527265269494};\\\", \\\"{x:1329,y:757,t:1527265269511};\\\", \\\"{x:1329,y:766,t:1527265269527};\\\", \\\"{x:1329,y:769,t:1527265269544};\\\", \\\"{x:1329,y:770,t:1527265269560};\\\", \\\"{x:1329,y:771,t:1527265269578};\\\", \\\"{x:1329,y:772,t:1527265269594};\\\", \\\"{x:1329,y:773,t:1527265269631};\\\", \\\"{x:1329,y:774,t:1527265269644};\\\", \\\"{x:1331,y:775,t:1527265269661};\\\", \\\"{x:1336,y:776,t:1527265269678};\\\", \\\"{x:1341,y:776,t:1527265269694};\\\", \\\"{x:1348,y:776,t:1527265269711};\\\", \\\"{x:1352,y:776,t:1527265269728};\\\", \\\"{x:1357,y:773,t:1527265269744};\\\", \\\"{x:1361,y:771,t:1527265269761};\\\", \\\"{x:1363,y:770,t:1527265269778};\\\", \\\"{x:1363,y:768,t:1527265269863};\\\", \\\"{x:1362,y:767,t:1527265269878};\\\", \\\"{x:1361,y:767,t:1527265269895};\\\", \\\"{x:1359,y:766,t:1527265269911};\\\", \\\"{x:1358,y:766,t:1527265270031};\\\", \\\"{x:1357,y:766,t:1527265270045};\\\", \\\"{x:1356,y:766,t:1527265270095};\\\", \\\"{x:1355,y:764,t:1527265270111};\\\", \\\"{x:1354,y:764,t:1527265270128};\\\", \\\"{x:1353,y:764,t:1527265270162};\\\", \\\"{x:1352,y:764,t:1527265270195};\\\", \\\"{x:1351,y:764,t:1527265270212};\\\", \\\"{x:1351,y:762,t:1527265271974};\\\", \\\"{x:1351,y:755,t:1527265271983};\\\", \\\"{x:1352,y:746,t:1527265271994};\\\", \\\"{x:1353,y:738,t:1527265272012};\\\", \\\"{x:1353,y:729,t:1527265272028};\\\", \\\"{x:1353,y:720,t:1527265272046};\\\", \\\"{x:1353,y:718,t:1527265272061};\\\", \\\"{x:1353,y:717,t:1527265272079};\\\", \\\"{x:1353,y:716,t:1527265272142};\\\", \\\"{x:1353,y:714,t:1527265272215};\\\", \\\"{x:1352,y:710,t:1527265272229};\\\", \\\"{x:1351,y:700,t:1527265272246};\\\", \\\"{x:1350,y:692,t:1527265272262};\\\", \\\"{x:1348,y:682,t:1527265272279};\\\", \\\"{x:1348,y:681,t:1527265272296};\\\", \\\"{x:1347,y:680,t:1527265272312};\\\", \\\"{x:1346,y:682,t:1527265272623};\\\", \\\"{x:1346,y:683,t:1527265272663};\\\", \\\"{x:1346,y:684,t:1527265272679};\\\", \\\"{x:1346,y:685,t:1527265272696};\\\", \\\"{x:1346,y:686,t:1527265272713};\\\", \\\"{x:1345,y:687,t:1527265272734};\\\", \\\"{x:1345,y:688,t:1527265272758};\\\", \\\"{x:1345,y:689,t:1527265272799};\\\", \\\"{x:1344,y:691,t:1527265272815};\\\", \\\"{x:1344,y:692,t:1527265272848};\\\", \\\"{x:1343,y:693,t:1527265272879};\\\", \\\"{x:1333,y:693,t:1527265301417};\\\", \\\"{x:1297,y:676,t:1527265301428};\\\", \\\"{x:1191,y:639,t:1527265301446};\\\", \\\"{x:1008,y:622,t:1527265301462};\\\", \\\"{x:867,y:622,t:1527265301480};\\\", \\\"{x:750,y:628,t:1527265301495};\\\", \\\"{x:613,y:677,t:1527265301528};\\\", \\\"{x:586,y:693,t:1527265301551};\\\", \\\"{x:576,y:697,t:1527265301569};\\\", \\\"{x:574,y:698,t:1527265301586};\\\", \\\"{x:574,y:699,t:1527265301602};\\\", \\\"{x:573,y:700,t:1527265301619};\\\", \\\"{x:570,y:701,t:1527265301636};\\\", \\\"{x:563,y:706,t:1527265301651};\\\", \\\"{x:559,y:711,t:1527265301668};\\\", \\\"{x:558,y:713,t:1527265301685};\\\", \\\"{x:558,y:714,t:1527265301726};\\\", \\\"{x:556,y:716,t:1527265301735};\\\", \\\"{x:551,y:722,t:1527265301752};\\\", \\\"{x:542,y:730,t:1527265301769};\\\", \\\"{x:531,y:741,t:1527265301787};\\\", \\\"{x:525,y:748,t:1527265301802};\\\", \\\"{x:521,y:755,t:1527265301820};\\\", \\\"{x:520,y:758,t:1527265301837};\\\" ] }, { \\\"rt\\\": 42610, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 931213, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"By looking at the X-axis and seeing the points that fall under the 12pm category.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6801, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 939019, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12560, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 952598, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19302, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 973247, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"EJPRM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"EJPRM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 193, dom: 1008, initialDom: 1098",
  "javascriptErrors": []
}