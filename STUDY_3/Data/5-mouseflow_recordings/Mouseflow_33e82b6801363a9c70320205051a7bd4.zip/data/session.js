var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "33e82b6801363a9c70320205051a7bd4",
  "created": "2018-05-24T12:13:45.2892224-07:00",
  "lastActivity": "2018-05-24T12:14:37.6331737-07:00",
  "pageViews": [
    {
      "id": "0524453979e85e70ada6773b467910e1e1f1b0c6",
      "startTime": "2018-05-24T12:13:45.2892224-07:00",
      "endTime": "2018-05-24T12:14:37.6331737-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 52399,
      "engagementTime": 49299,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 52399,
  "engagementTime": 49299,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X66XB",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7cdfd7a2ce7a4d5d81073a90df099fa9",
  "gdpr": false
}