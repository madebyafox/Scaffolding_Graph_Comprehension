var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0531361325c6f90b08b1f2830313ba1532f3104e"] = {
  "startTime": "2018-05-31T19:04:36.3628184Z",
  "websitePageUrl": "/",
  "visitTime": 99582,
  "engagementTime": 41547,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "1f33959efab62542807dab077b4fb4d5",
    "created": "2018-05-31T19:04:36.3628184+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "dda0489517de24fa9e80529b8e34c7ef",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1f33959efab62542807dab077b4fb4d5/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 330,
      "e": 330,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 540,
      "y": 534
    },
    {
      "t": 2004,
      "e": 2004,
      "ty": 41,
      "x": 9857,
      "y": 31743,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 694,
      "y": 765
    },
    {
      "t": 2255,
      "e": 2255,
      "ty": 41,
      "x": 18267,
      "y": 50666,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 695,
      "y": 777
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 773,
      "y": 895
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 811,
      "y": 895
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 24657,
      "y": 61316,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 834,
      "y": 882
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 835,
      "y": 882
    },
    {
      "t": 2753,
      "e": 2753,
      "ty": 41,
      "x": 25968,
      "y": 60251,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3370,
      "e": 3370,
      "ty": 3,
      "x": 835,
      "y": 882,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3506,
      "e": 3506,
      "ty": 4,
      "x": 25968,
      "y": 60251,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3506,
      "e": 3506,
      "ty": 5,
      "x": 835,
      "y": 882,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 835,
      "y": 948
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 25968,
      "y": 61316,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10010,
      "e": 9501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 57900,
      "e": 9501,
      "ty": 2,
      "x": 835,
      "y": 936
    },
    {
      "t": 58001,
      "e": 9602,
      "ty": 2,
      "x": 835,
      "y": 928
    },
    {
      "t": 58001,
      "e": 9602,
      "ty": 41,
      "x": 6627,
      "y": 59623,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 58201,
      "e": 9802,
      "ty": 2,
      "x": 826,
      "y": 924
    },
    {
      "t": 58251,
      "e": 9852,
      "ty": 41,
      "x": 4527,
      "y": 47708,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 58300,
      "e": 9901,
      "ty": 2,
      "x": 823,
      "y": 924
    },
    {
      "t": 58338,
      "e": 9939,
      "ty": 3,
      "x": 823,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58417,
      "e": 10018,
      "ty": 4,
      "x": 64101,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58418,
      "e": 10019,
      "ty": 5,
      "x": 823,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58422,
      "e": 10023,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 58425,
      "e": 10026,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 58501,
      "e": 10102,
      "ty": 41,
      "x": 64101,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 59100,
      "e": 10701,
      "ty": 2,
      "x": 796,
      "y": 970
    },
    {
      "t": 59201,
      "e": 10802,
      "ty": 2,
      "x": 809,
      "y": 994
    },
    {
      "t": 59250,
      "e": 10851,
      "ty": 41,
      "x": 27478,
      "y": 63825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59300,
      "e": 10901,
      "ty": 2,
      "x": 978,
      "y": 1185
    },
    {
      "t": 59401,
      "e": 11002,
      "ty": 2,
      "x": 994,
      "y": 1199
    },
    {
      "t": 59800,
      "e": 11401,
      "ty": 2,
      "x": 996,
      "y": 1199
    },
    {
      "t": 59900,
      "e": 11501,
      "ty": 2,
      "x": 1019,
      "y": 1191
    },
    {
      "t": 60000,
      "e": 11601,
      "ty": 2,
      "x": 1044,
      "y": 1175
    },
    {
      "t": 60000,
      "e": 11601,
      "ty": 41,
      "x": 35677,
      "y": 64648,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60100,
      "e": 11701,
      "ty": 2,
      "x": 1071,
      "y": 1158
    },
    {
      "t": 60200,
      "e": 11801,
      "ty": 2,
      "x": 1106,
      "y": 1152
    },
    {
      "t": 60251,
      "e": 11852,
      "ty": 41,
      "x": 38088,
      "y": 63873,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60300,
      "e": 11901,
      "ty": 2,
      "x": 1108,
      "y": 1180
    },
    {
      "t": 60400,
      "e": 12001,
      "ty": 2,
      "x": 994,
      "y": 1167
    },
    {
      "t": 60500,
      "e": 12101,
      "ty": 2,
      "x": 971,
      "y": 1125
    },
    {
      "t": 60501,
      "e": 12102,
      "ty": 41,
      "x": 38150,
      "y": 28980,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 60599,
      "e": 12200,
      "ty": 2,
      "x": 973,
      "y": 1088
    },
    {
      "t": 60700,
      "e": 12301,
      "ty": 2,
      "x": 973,
      "y": 1070
    },
    {
      "t": 60751,
      "e": 12352,
      "ty": 41,
      "x": 33431,
      "y": 65348,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60900,
      "e": 12501,
      "ty": 2,
      "x": 972,
      "y": 1082
    },
    {
      "t": 61001,
      "e": 12602,
      "ty": 41,
      "x": 34132,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 61700,
      "e": 13301,
      "ty": 2,
      "x": 971,
      "y": 1084
    },
    {
      "t": 61750,
      "e": 13351,
      "ty": 41,
      "x": 33040,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 61799,
      "e": 13400,
      "ty": 2,
      "x": 970,
      "y": 1084
    },
    {
      "t": 61899,
      "e": 13500,
      "ty": 2,
      "x": 968,
      "y": 1084
    },
    {
      "t": 61999,
      "e": 13600,
      "ty": 41,
      "x": 31948,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 62458,
      "e": 14059,
      "ty": 3,
      "x": 968,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 62459,
      "e": 14060,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 62461,
      "e": 14062,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62601,
      "e": 14202,
      "ty": 4,
      "x": 31948,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 62602,
      "e": 14203,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62604,
      "e": 14205,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 62604,
      "e": 14205,
      "ty": 5,
      "x": 968,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 62999,
      "e": 14600,
      "ty": 2,
      "x": 968,
      "y": 1081
    },
    {
      "t": 62999,
      "e": 14600,
      "ty": 41,
      "x": 33060,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 63611,
      "e": 15212,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 63800,
      "e": 15401,
      "ty": 2,
      "x": 968,
      "y": 1080
    },
    {
      "t": 63999,
      "e": 15600,
      "ty": 2,
      "x": 952,
      "y": 1034
    },
    {
      "t": 64000,
      "e": 15601,
      "ty": 41,
      "x": 32509,
      "y": 56837,
      "ta": "html > body"
    },
    {
      "t": 64100,
      "e": 15701,
      "ty": 2,
      "x": 894,
      "y": 932
    },
    {
      "t": 64200,
      "e": 15801,
      "ty": 2,
      "x": 891,
      "y": 882
    },
    {
      "t": 64250,
      "e": 15851,
      "ty": 41,
      "x": 30684,
      "y": 46422,
      "ta": "html > body"
    },
    {
      "t": 64300,
      "e": 15901,
      "ty": 2,
      "x": 914,
      "y": 804
    },
    {
      "t": 64371,
      "e": 15972,
      "ty": 6,
      "x": 919,
      "y": 739,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64400,
      "e": 16001,
      "ty": 2,
      "x": 919,
      "y": 732
    },
    {
      "t": 64453,
      "e": 16054,
      "ty": 7,
      "x": 918,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64470,
      "e": 16071,
      "ty": 6,
      "x": 914,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64486,
      "e": 16087,
      "ty": 7,
      "x": 909,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64500,
      "e": 16101,
      "ty": 2,
      "x": 909,
      "y": 678
    },
    {
      "t": 64500,
      "e": 16101,
      "ty": 41,
      "x": 21845,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 64600,
      "e": 16201,
      "ty": 2,
      "x": 886,
      "y": 629
    },
    {
      "t": 64700,
      "e": 16301,
      "ty": 2,
      "x": 876,
      "y": 615
    },
    {
      "t": 64750,
      "e": 16351,
      "ty": 41,
      "x": 14491,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 64800,
      "e": 16401,
      "ty": 2,
      "x": 875,
      "y": 614
    },
    {
      "t": 64900,
      "e": 16501,
      "ty": 2,
      "x": 875,
      "y": 609
    },
    {
      "t": 64921,
      "e": 16522,
      "ty": 6,
      "x": 873,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65000,
      "e": 16601,
      "ty": 2,
      "x": 870,
      "y": 597
    },
    {
      "t": 65000,
      "e": 16601,
      "ty": 41,
      "x": 13409,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65064,
      "e": 16665,
      "ty": 3,
      "x": 869,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65066,
      "e": 16667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65100,
      "e": 16701,
      "ty": 2,
      "x": 869,
      "y": 596
    },
    {
      "t": 65186,
      "e": 16787,
      "ty": 4,
      "x": 13193,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65186,
      "e": 16787,
      "ty": 5,
      "x": 869,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65250,
      "e": 16851,
      "ty": 41,
      "x": 13193,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67020,
      "e": 18621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 67020,
      "e": 18621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67108,
      "e": 18709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "u"
    },
    {
      "t": 67116,
      "e": 18717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 67116,
      "e": 18717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67229,
      "e": 18830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 67229,
      "e": 18830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67284,
      "e": 18885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "uni"
    },
    {
      "t": 67316,
      "e": 18917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 67317,
      "e": 18918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67356,
      "e": 18957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "unif"
    },
    {
      "t": 67380,
      "e": 18981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 67445,
      "e": 19046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 67445,
      "e": 19046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67517,
      "e": 19118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 67517,
      "e": 19118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67548,
      "e": 19149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||or"
    },
    {
      "t": 67620,
      "e": 19221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 67621,
      "e": 19222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67628,
      "e": 19229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 67756,
      "e": 19357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 68084,
      "e": 19685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 68085,
      "e": 19686,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "uniform"
    },
    {
      "t": 68085,
      "e": 19686,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68085,
      "e": 19686,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68221,
      "e": 19822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 69093,
      "e": 20694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 69093,
      "e": 20694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69180,
      "e": 20781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 69285,
      "e": 20886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 69286,
      "e": 20887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69356,
      "e": 20957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 69357,
      "e": 20958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69428,
      "e": 21029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 69493,
      "e": 21094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 70041,
      "e": 21642,
      "ty": 7,
      "x": 889,
      "y": 615,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70100,
      "e": 21701,
      "ty": 2,
      "x": 899,
      "y": 645
    },
    {
      "t": 70200,
      "e": 21801,
      "ty": 2,
      "x": 904,
      "y": 669
    },
    {
      "t": 70250,
      "e": 21851,
      "ty": 41,
      "x": 21628,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70274,
      "e": 21875,
      "ty": 6,
      "x": 910,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70299,
      "e": 21900,
      "ty": 2,
      "x": 910,
      "y": 680
    },
    {
      "t": 70400,
      "e": 22001,
      "ty": 2,
      "x": 913,
      "y": 684
    },
    {
      "t": 70500,
      "e": 22101,
      "ty": 41,
      "x": 22710,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70876,
      "e": 22477,
      "ty": 7,
      "x": 913,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70900,
      "e": 22501,
      "ty": 2,
      "x": 913,
      "y": 704
    },
    {
      "t": 70926,
      "e": 22527,
      "ty": 6,
      "x": 913,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71000,
      "e": 22601,
      "ty": 2,
      "x": 915,
      "y": 714
    },
    {
      "t": 71000,
      "e": 22601,
      "ty": 41,
      "x": 9832,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71100,
      "e": 22701,
      "ty": 2,
      "x": 916,
      "y": 726
    },
    {
      "t": 71200,
      "e": 22801,
      "ty": 2,
      "x": 916,
      "y": 730
    },
    {
      "t": 71250,
      "e": 22851,
      "ty": 41,
      "x": 10348,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71600,
      "e": 23201,
      "ty": 2,
      "x": 926,
      "y": 731
    },
    {
      "t": 71700,
      "e": 23301,
      "ty": 2,
      "x": 930,
      "y": 733
    },
    {
      "t": 71751,
      "e": 23352,
      "ty": 41,
      "x": 17563,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71800,
      "e": 23401,
      "ty": 2,
      "x": 930,
      "y": 734
    },
    {
      "t": 72128,
      "e": 23729,
      "ty": 3,
      "x": 930,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72128,
      "e": 23729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 72129,
      "e": 23730,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72129,
      "e": 23730,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72257,
      "e": 23858,
      "ty": 4,
      "x": 17563,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72259,
      "e": 23860,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72259,
      "e": 23860,
      "ty": 5,
      "x": 930,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72260,
      "e": 23861,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 73366,
      "e": 24967,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 73396,
      "e": 24997,
      "ty": 6,
      "x": 930,
      "y": 734,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 78949,
      "e": 29997,
      "ty": 7,
      "x": 924,
      "y": 788,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 79000,
      "e": 30048,
      "ty": 2,
      "x": 921,
      "y": 878
    },
    {
      "t": 79001,
      "e": 30049,
      "ty": 41,
      "x": 30873,
      "y": 52053,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79099,
      "e": 30147,
      "ty": 2,
      "x": 933,
      "y": 1016
    },
    {
      "t": 79200,
      "e": 30248,
      "ty": 2,
      "x": 948,
      "y": 1052
    },
    {
      "t": 79251,
      "e": 30299,
      "ty": 41,
      "x": 32250,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79301,
      "e": 30349,
      "ty": 2,
      "x": 949,
      "y": 1061
    },
    {
      "t": 79400,
      "e": 30448,
      "ty": 2,
      "x": 949,
      "y": 1070
    },
    {
      "t": 79416,
      "e": 30464,
      "ty": 6,
      "x": 949,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 79500,
      "e": 30548,
      "ty": 2,
      "x": 949,
      "y": 1086
    },
    {
      "t": 79500,
      "e": 30548,
      "ty": 41,
      "x": 21571,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 80001,
      "e": 31049,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 82553,
      "e": 33601,
      "ty": 3,
      "x": 949,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 82553,
      "e": 33601,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 82688,
      "e": 33736,
      "ty": 4,
      "x": 21571,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 82689,
      "e": 33737,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 82690,
      "e": 33738,
      "ty": 5,
      "x": 949,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 82693,
      "e": 33741,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 83099,
      "e": 34147,
      "ty": 2,
      "x": 805,
      "y": 906
    },
    {
      "t": 83200,
      "e": 34248,
      "ty": 2,
      "x": 797,
      "y": 902
    },
    {
      "t": 83250,
      "e": 34298,
      "ty": 41,
      "x": 27171,
      "y": 49525,
      "ta": "html > body"
    },
    {
      "t": 83693,
      "e": 34741,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 84400,
      "e": 35448,
      "ty": 2,
      "x": 812,
      "y": 902
    },
    {
      "t": 84500,
      "e": 35548,
      "ty": 2,
      "x": 813,
      "y": 902
    },
    {
      "t": 84500,
      "e": 35548,
      "ty": 41,
      "x": 25655,
      "y": 58740,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 84599,
      "e": 35647,
      "ty": 2,
      "x": 834,
      "y": 898
    },
    {
      "t": 84699,
      "e": 35747,
      "ty": 2,
      "x": 869,
      "y": 895
    },
    {
      "t": 84750,
      "e": 35798,
      "ty": 41,
      "x": 28616,
      "y": 58197,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 84800,
      "e": 35848,
      "ty": 2,
      "x": 874,
      "y": 894
    },
    {
      "t": 84900,
      "e": 35948,
      "ty": 2,
      "x": 876,
      "y": 893
    },
    {
      "t": 84999,
      "e": 36047,
      "ty": 2,
      "x": 883,
      "y": 889
    },
    {
      "t": 85000,
      "e": 36048,
      "ty": 41,
      "x": 29053,
      "y": 57731,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 85100,
      "e": 36148,
      "ty": 2,
      "x": 895,
      "y": 874
    },
    {
      "t": 85199,
      "e": 36247,
      "ty": 2,
      "x": 899,
      "y": 871
    },
    {
      "t": 85250,
      "e": 36298,
      "ty": 41,
      "x": 29879,
      "y": 56023,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 85300,
      "e": 36348,
      "ty": 2,
      "x": 899,
      "y": 860
    },
    {
      "t": 85400,
      "e": 36448,
      "ty": 2,
      "x": 889,
      "y": 851
    },
    {
      "t": 85499,
      "e": 36547,
      "ty": 41,
      "x": 29345,
      "y": 54780,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 90000,
      "e": 41048,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 98574,
      "e": 41547,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 99582,
      "e": 41547,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 284, dom: 689, initialDom: 692",
  "javascriptErrors": []
}