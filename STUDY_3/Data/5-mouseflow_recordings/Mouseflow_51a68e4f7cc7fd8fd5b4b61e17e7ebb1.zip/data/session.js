var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "51a68e4f7cc7fd8fd5b4b61e17e7ebb1",
  "created": "2018-05-24T12:15:02.5477396-07:00",
  "lastActivity": "2018-05-24T12:15:11.0147396-07:00",
  "pageViews": [
    {
      "id": "0524029253198a95979fb5ef3c4fdef2724419a5",
      "startTime": "2018-05-24T12:15:02.5477396-07:00",
      "endTime": "2018-05-24T12:15:11.0147396-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 8467,
      "engagementTime": 8416,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8467,
  "engagementTime": 8416,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K2YPP",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "72084bf3aa4d1f81fc0d966d33d02e7d",
  "gdpr": false
}