var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "268acd76b901c5560ca82f24a2f65209",
  "created": "2018-05-22T14:12:25.2561796-07:00",
  "lastActivity": "2018-05-22T14:13:37.3217081-07:00",
  "pageViews": [
    {
      "id": "05222521aa712e0279cbe10d58b5be35e6d92de0",
      "startTime": "2018-05-22T14:12:25.2561796-07:00",
      "endTime": "2018-05-22T14:13:37.3217081-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 72091,
      "engagementTime": 71792,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 72091,
  "engagementTime": 71792,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QOJ6L",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7044692d909ab25e6a1744e3eee3b12e",
  "gdpr": false
}