var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4a14fcab1af6af50389619a4ae22347f",
  "created": "2018-05-29T10:08:39.7167711-07:00",
  "lastActivity": "2018-05-29T10:09:22.8684236-07:00",
  "pageViews": [
    {
      "id": "05293904bf1da1f2d54b65f064ec75189087bcf3",
      "startTime": "2018-05-29T10:08:40.0021629-07:00",
      "endTime": "2018-05-29T10:09:22.8684236-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 43004,
      "engagementTime": 40054,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 43004,
  "engagementTime": 40054,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1FK1X",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a9d02e716824135516e0a395236ff9b7",
  "gdpr": false
}