var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7c6dcebc1e22db7c5f5c48bdb770d918",
  "created": "2018-05-21T12:53:04.6281567-07:00",
  "lastActivity": "2018-05-21T12:53:47.5687641-07:00",
  "pageViews": [
    {
      "id": "0521035970c99fd47332d0c9187b5419e298c9a4",
      "startTime": "2018-05-21T12:53:04.631247-07:00",
      "endTime": "2018-05-21T12:53:47.5687641-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 43766,
      "engagementTime": 43766,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 43766,
  "engagementTime": 43766,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.248",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e100623d8918b9ae6fa985d73b1840ec",
  "gdpr": false
}