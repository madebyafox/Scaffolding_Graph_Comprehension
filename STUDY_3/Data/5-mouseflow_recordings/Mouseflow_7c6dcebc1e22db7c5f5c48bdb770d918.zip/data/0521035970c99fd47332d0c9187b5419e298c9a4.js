var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0521035970c99fd47332d0c9187b5419e298c9a4"] = {
  "startTime": "2018-05-21T19:53:04.631247Z",
  "websitePageUrl": "/",
  "visitTime": 43766,
  "engagementTime": 43766,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1356,
  "viewportHeight": 752,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "7c6dcebc1e22db7c5f5c48bdb770d918",
    "created": "2018-05-21T19:53:04.6281567+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-us",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
    "browser": "Safari",
    "browserVersion": "11.0.3",
    "os": "OS X",
    "osVersion": "10.11 El Capitan",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1440x900",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e100623d8918b9ae6fa985d73b1840ec",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7c6dcebc1e22db7c5f5c48bdb770d918/play"
  },
  "events": [
    {
      "t": 104,
      "e": 104,
      "ty": 0,
      "x": 1356,
      "y": 752
    },
    {
      "t": 233,
      "e": 233,
      "ty": 14,
      "x": 0,
      "y": 760
    },
    {
      "t": 3269,
      "e": 3269,
      "ty": 41,
      "x": 52591,
      "y": 14991,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3332,
      "e": 3332,
      "ty": 2,
      "x": 996,
      "y": 243
    },
    {
      "t": 3433,
      "e": 3433,
      "ty": 2,
      "x": 947,
      "y": 279
    },
    {
      "t": 3519,
      "e": 3519,
      "ty": 41,
      "x": 47021,
      "y": 24247,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3534,
      "e": 3534,
      "ty": 2,
      "x": 947,
      "y": 280
    },
    {
      "t": 3634,
      "e": 3634,
      "ty": 2,
      "x": 948,
      "y": 279
    },
    {
      "t": 3770,
      "e": 3770,
      "ty": 41,
      "x": 47075,
      "y": 24166,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3847,
      "e": 3847,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 4272,
      "e": 4272,
      "ty": 41,
      "x": 37068,
      "y": 35991,
      "ta": "html > body"
    },
    {
      "t": 4340,
      "e": 4340,
      "ty": 2,
      "x": 585,
      "y": 395
    },
    {
      "t": 4441,
      "e": 4441,
      "ty": 2,
      "x": 554,
      "y": 98
    },
    {
      "t": 4485,
      "e": 4485,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 4523,
      "e": 4523,
      "ty": 41,
      "x": 28514,
      "y": 3311,
      "ta": "html > body"
    },
    {
      "t": 4542,
      "e": 4542,
      "ty": 2,
      "x": 609,
      "y": 35
    },
    {
      "t": 4590,
      "e": 4590,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4642,
      "e": 4642,
      "ty": 2,
      "x": 638,
      "y": 1
    },
    {
      "t": 4774,
      "e": 4774,
      "ty": 41,
      "x": 30834,
      "y": 87,
      "ta": "html"
    },
    {
      "t": 4938,
      "e": 4938,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 5993,
      "e": 5993,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 6493,
      "e": 6493,
      "ty": 2,
      "x": 1072,
      "y": 11
    },
    {
      "t": 6543,
      "e": 6543,
      "ty": 41,
      "x": 60572,
      "y": 5216,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 6594,
      "e": 6594,
      "ty": 2,
      "x": 991,
      "y": 119
    },
    {
      "t": 6694,
      "e": 6694,
      "ty": 2,
      "x": 780,
      "y": 408
    },
    {
      "t": 6793,
      "e": 6793,
      "ty": 41,
      "x": 38567,
      "y": 54822,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 6794,
      "e": 6794,
      "ty": 2,
      "x": 770,
      "y": 422
    },
    {
      "t": 7019,
      "e": 7019,
      "ty": 39,
      "x": 0,
      "y": 133,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7120,
      "e": 7120,
      "ty": 39,
      "x": 0,
      "y": 247,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7221,
      "e": 7221,
      "ty": 39,
      "x": 0,
      "y": 251,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7322,
      "e": 7322,
      "ty": 39,
      "x": 0,
      "y": 248,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7404,
      "e": 7404,
      "ty": 2,
      "x": 757,
      "y": 411
    },
    {
      "t": 7423,
      "e": 7423,
      "ty": 39,
      "x": 0,
      "y": 246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7505,
      "e": 7505,
      "ty": 2,
      "x": 630,
      "y": 539
    },
    {
      "t": 7525,
      "e": 7525,
      "ty": 39,
      "x": 0,
      "y": 245,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7544,
      "e": 7544,
      "ty": 41,
      "x": 25932,
      "y": 54554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7606,
      "e": 7606,
      "ty": 2,
      "x": 565,
      "y": 587
    },
    {
      "t": 7707,
      "e": 7707,
      "ty": 2,
      "x": 530,
      "y": 577
    },
    {
      "t": 7795,
      "e": 7795,
      "ty": 41,
      "x": 21858,
      "y": 55365,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 7807,
      "e": 7807,
      "ty": 2,
      "x": 531,
      "y": 563
    },
    {
      "t": 7908,
      "e": 7908,
      "ty": 2,
      "x": 543,
      "y": 550
    },
    {
      "t": 8008,
      "e": 8008,
      "ty": 2,
      "x": 544,
      "y": 550
    },
    {
      "t": 8046,
      "e": 8046,
      "ty": 41,
      "x": 46079,
      "y": 4915,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8107,
      "e": 8107,
      "ty": 3,
      "x": 544,
      "y": 550,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8194,
      "e": 8194,
      "ty": 4,
      "x": 49356,
      "y": 4915,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8195,
      "e": 8195,
      "ty": 5,
      "x": 545,
      "y": 550,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8197,
      "e": 8197,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 8209,
      "e": 8209,
      "ty": 2,
      "x": 545,
      "y": 550
    },
    {
      "t": 8296,
      "e": 8296,
      "ty": 41,
      "x": 23170,
      "y": 54428,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 39,
      "x": 0,
      "y": 131,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 8310,
      "e": 8310,
      "ty": 2,
      "x": 547,
      "y": 545
    },
    {
      "t": 8411,
      "e": 8411,
      "ty": 2,
      "x": 618,
      "y": 600
    },
    {
      "t": 8512,
      "e": 8512,
      "ty": 2,
      "x": 712,
      "y": 658
    },
    {
      "t": 8547,
      "e": 8547,
      "ty": 41,
      "x": 39906,
      "y": 13404,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 8612,
      "e": 8612,
      "ty": 2,
      "x": 725,
      "y": 668
    },
    {
      "t": 8713,
      "e": 8713,
      "ty": 2,
      "x": 723,
      "y": 670
    },
    {
      "t": 8798,
      "e": 8798,
      "ty": 41,
      "x": 38856,
      "y": 55108,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 8813,
      "e": 8813,
      "ty": 2,
      "x": 713,
      "y": 681
    },
    {
      "t": 8823,
      "e": 8823,
      "ty": 6,
      "x": 711,
      "y": 684,
      "ta": "#start"
    },
    {
      "t": 8914,
      "e": 8914,
      "ty": 2,
      "x": 705,
      "y": 696
    },
    {
      "t": 9014,
      "e": 9014,
      "ty": 2,
      "x": 700,
      "y": 700
    },
    {
      "t": 9048,
      "e": 9048,
      "ty": 41,
      "x": 34405,
      "y": 31231,
      "ta": "#start"
    },
    {
      "t": 9114,
      "e": 9114,
      "ty": 2,
      "x": 697,
      "y": 701
    },
    {
      "t": 9215,
      "e": 9215,
      "ty": 2,
      "x": 696,
      "y": 700
    },
    {
      "t": 9298,
      "e": 9298,
      "ty": 41,
      "x": 32221,
      "y": 29304,
      "ta": "#start"
    },
    {
      "t": 9316,
      "e": 9316,
      "ty": 2,
      "x": 695,
      "y": 700
    },
    {
      "t": 9333,
      "e": 9333,
      "ty": 3,
      "x": 695,
      "y": 700,
      "ta": "#start"
    },
    {
      "t": 9477,
      "e": 9477,
      "ty": 4,
      "x": 32221,
      "y": 29304,
      "ta": "#start"
    },
    {
      "t": 9479,
      "e": 9479,
      "ty": 5,
      "x": 695,
      "y": 700,
      "ta": "#start"
    },
    {
      "t": 9481,
      "e": 9481,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 9518,
      "e": 9518,
      "ty": 2,
      "x": 695,
      "y": 695
    },
    {
      "t": 9550,
      "e": 9550,
      "ty": 41,
      "x": 33202,
      "y": 59696,
      "ta": "html > body"
    },
    {
      "t": 9619,
      "e": 9619,
      "ty": 2,
      "x": 695,
      "y": 693
    },
    {
      "t": 9801,
      "e": 9801,
      "ty": 41,
      "x": 33202,
      "y": 58127,
      "ta": "html > body"
    },
    {
      "t": 9821,
      "e": 9821,
      "ty": 2,
      "x": 695,
      "y": 650
    },
    {
      "t": 9922,
      "e": 9922,
      "ty": 2,
      "x": 657,
      "y": 299
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10023,
      "e": 10023,
      "ty": 2,
      "x": 659,
      "y": 236
    },
    {
      "t": 10052,
      "e": 10052,
      "ty": 41,
      "x": 31559,
      "y": 19869,
      "ta": "html > body"
    },
    {
      "t": 10125,
      "e": 10125,
      "ty": 2,
      "x": 663,
      "y": 237
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 41,
      "x": 31655,
      "y": 19956,
      "ta": "html > body"
    },
    {
      "t": 10487,
      "e": 10487,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 10491,
      "e": 10491,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 10932,
      "e": 10932,
      "ty": 2,
      "x": 663,
      "y": 245
    },
    {
      "t": 11033,
      "e": 11033,
      "ty": 6,
      "x": 652,
      "y": 384,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11034,
      "e": 11034,
      "ty": 2,
      "x": 652,
      "y": 384
    },
    {
      "t": 11050,
      "e": 11050,
      "ty": 7,
      "x": 651,
      "y": 392,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11053,
      "e": 11053,
      "ty": 41,
      "x": 25271,
      "y": 60361,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11135,
      "e": 11135,
      "ty": 2,
      "x": 649,
      "y": 405
    },
    {
      "t": 11236,
      "e": 11236,
      "ty": 2,
      "x": 650,
      "y": 401
    },
    {
      "t": 11305,
      "e": 11305,
      "ty": 41,
      "x": 25914,
      "y": 60361,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11337,
      "e": 11337,
      "ty": 2,
      "x": 654,
      "y": 392
    },
    {
      "t": 11392,
      "e": 11392,
      "ty": 3,
      "x": 654,
      "y": 392,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11520,
      "e": 11520,
      "ty": 4,
      "x": 25914,
      "y": 60361,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11520,
      "e": 11520,
      "ty": 5,
      "x": 654,
      "y": 392,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11556,
      "e": 11556,
      "ty": 41,
      "x": 25914,
      "y": 59671,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 11579,
      "e": 11579,
      "ty": 6,
      "x": 654,
      "y": 389,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11640,
      "e": 11640,
      "ty": 2,
      "x": 654,
      "y": 388
    },
    {
      "t": 11741,
      "e": 11741,
      "ty": 2,
      "x": 654,
      "y": 387
    },
    {
      "t": 11806,
      "e": 11806,
      "ty": 41,
      "x": 25823,
      "y": 56911,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11809,
      "e": 11809,
      "ty": 3,
      "x": 654,
      "y": 387,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11810,
      "e": 11810,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 4,
      "x": 25823,
      "y": 56911,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11922,
      "e": 11922,
      "ty": 5,
      "x": 654,
      "y": 387,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12017,
      "e": 12017,
      "ty": 7,
      "x": 660,
      "y": 355,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12044,
      "e": 12044,
      "ty": 2,
      "x": 688,
      "y": 245
    },
    {
      "t": 12057,
      "e": 12057,
      "ty": 41,
      "x": 34749,
      "y": 11154,
      "ta": "html > body"
    },
    {
      "t": 12087,
      "e": 12087,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 12146,
      "e": 12146,
      "ty": 2,
      "x": 763,
      "y": 58
    },
    {
      "t": 12308,
      "e": 12308,
      "ty": 41,
      "x": 36488,
      "y": 4357,
      "ta": "html > body"
    },
    {
      "t": 12567,
      "e": 12567,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 17219,
      "e": 17219,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 17221,
      "e": 17221,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 17423,
      "e": 17423,
      "ty": 2,
      "x": 1053,
      "y": 7
    },
    {
      "t": 17473,
      "e": 17473,
      "ty": 41,
      "x": 48377,
      "y": 4095,
      "ta": "html > body"
    },
    {
      "t": 17524,
      "e": 17524,
      "ty": 2,
      "x": 992,
      "y": 70
    },
    {
      "t": 17723,
      "e": 17723,
      "ty": 41,
      "x": 47556,
      "y": 5403,
      "ta": "html > body"
    },
    {
      "t": 17765,
      "e": 17765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 17928,
      "e": 17928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 17928,
      "e": 17928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18148,
      "e": 18148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "S"
    },
    {
      "t": 18363,
      "e": 18363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 18365,
      "e": 18365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18518,
      "e": 18518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ST"
    },
    {
      "t": 18648,
      "e": 18648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 18648,
      "e": 18648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18780,
      "e": 18780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 18780,
      "e": 18780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18786,
      "e": 18786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRA"
    },
    {
      "t": 18904,
      "e": 18904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 18904,
      "e": 18904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18959,
      "e": 18959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||T"
    },
    {
      "t": 19036,
      "e": 19036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 19036,
      "e": 19036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19063,
      "e": 19063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 19172,
      "e": 19172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "71"
    },
    {
      "t": 19172,
      "e": 19172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19178,
      "e": 19178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||G"
    },
    {
      "t": 19339,
      "e": 19339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 19341,
      "e": 19341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 19341,
      "e": 19341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19476,
      "e": 19476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||Y"
    },
    {
      "t": 19675,
      "e": 19675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "189"
    },
    {
      "t": 19675,
      "e": 19675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19811,
      "e": 19811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||-"
    },
    {
      "t": 19861,
      "e": 19861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 19861,
      "e": 19861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19993,
      "e": 19993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||C"
    },
    {
      "t": 19997,
      "e": 19997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 19997,
      "e": 19997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20128,
      "e": 20128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||O"
    },
    {
      "t": 20210,
      "e": 20210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 20210,
      "e": 20210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20281,
      "e": 20281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||N"
    },
    {
      "t": 20363,
      "e": 20363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 20363,
      "e": 20363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20470,
      "e": 20470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||N"
    },
    {
      "t": 20501,
      "e": 20501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 20502,
      "e": 20502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20606,
      "e": 20606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 20606,
      "e": 20606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20662,
      "e": 20662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||EC"
    },
    {
      "t": 20725,
      "e": 20725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 20913,
      "e": 20913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 20914,
      "e": 20914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21012,
      "e": 21012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 21012,
      "e": 21012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21047,
      "e": 21047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||TI"
    },
    {
      "t": 21088,
      "e": 21088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 21088,
      "e": 21088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21200,
      "e": 21200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 21200,
      "e": 21200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21267,
      "e": 21267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||ON"
    },
    {
      "t": 21339,
      "e": 21339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 21363,
      "e": 21363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 21775,
      "e": 21775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 21859,
      "e": 21859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-CONNECTIO"
    },
    {
      "t": 21940,
      "e": 21940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 22004,
      "e": 22004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-CONNECTI"
    },
    {
      "t": 22211,
      "e": 22211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 22212,
      "e": 22212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 22275,
      "e": 22275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||N"
    },
    {
      "t": 22350,
      "e": 22350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "71"
    },
    {
      "t": 22350,
      "e": 22350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 22489,
      "e": 22489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||G"
    },
    {
      "t": 22668,
      "e": 22668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 23744,
      "e": 23744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 23745,
      "e": 23745,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-CONNECTING"
    },
    {
      "t": 23746,
      "e": 23746,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23746,
      "e": 23746,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23908,
      "e": 23908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 23983,
      "e": 23983,
      "ty": 2,
      "x": 941,
      "y": 54
    },
    {
      "t": 24002,
      "e": 24002,
      "ty": 41,
      "x": 43883,
      "y": 1481,
      "ta": "html > body"
    },
    {
      "t": 24017,
      "e": 24017,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 24083,
      "e": 24083,
      "ty": 2,
      "x": 916,
      "y": 25
    },
    {
      "t": 24727,
      "e": 24727,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28494,
      "e": 28494,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28495,
      "e": 28495,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28998,
      "e": 28998,
      "ty": 41,
      "x": 33540,
      "y": 58879,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 28998,
      "e": 28998,
      "ty": 2,
      "x": 692,
      "y": 298
    },
    {
      "t": 29020,
      "e": 29020,
      "ty": 6,
      "x": 540,
      "y": 484,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29036,
      "e": 29036,
      "ty": 7,
      "x": 514,
      "y": 521,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29099,
      "e": 29099,
      "ty": 2,
      "x": 488,
      "y": 569
    },
    {
      "t": 29200,
      "e": 29200,
      "ty": 2,
      "x": 508,
      "y": 561
    },
    {
      "t": 29249,
      "e": 29249,
      "ty": 41,
      "x": 24744,
      "y": 48018,
      "ta": "html > body"
    },
    {
      "t": 29301,
      "e": 29301,
      "ty": 2,
      "x": 536,
      "y": 559
    },
    {
      "t": 29401,
      "e": 29401,
      "ty": 2,
      "x": 601,
      "y": 552
    },
    {
      "t": 29499,
      "e": 29499,
      "ty": 41,
      "x": 30109,
      "y": 45839,
      "ta": "html > body"
    },
    {
      "t": 29501,
      "e": 29501,
      "ty": 2,
      "x": 631,
      "y": 534
    },
    {
      "t": 29517,
      "e": 29517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 29518,
      "e": 29518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29602,
      "e": 29602,
      "ty": 2,
      "x": 636,
      "y": 533
    },
    {
      "t": 29689,
      "e": 29689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 29690,
      "e": 29690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29703,
      "e": 29703,
      "ty": 2,
      "x": 638,
      "y": 532
    },
    {
      "t": 29721,
      "e": 29721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 29750,
      "e": 29750,
      "ty": 41,
      "x": 30496,
      "y": 45665,
      "ta": "html > body"
    },
    {
      "t": 29804,
      "e": 29804,
      "ty": 2,
      "x": 639,
      "y": 532
    },
    {
      "t": 29881,
      "e": 29881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 29882,
      "e": 29882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29905,
      "e": 29905,
      "ty": 2,
      "x": 643,
      "y": 531
    },
    {
      "t": 29918,
      "e": 29918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 29983,
      "e": 29983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 41,
      "x": 31124,
      "y": 45578,
      "ta": "html > body"
    },
    {
      "t": 30002,
      "e": 30002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30005,
      "e": 30005,
      "ty": 2,
      "x": 652,
      "y": 531
    },
    {
      "t": 30105,
      "e": 30105,
      "ty": 2,
      "x": 657,
      "y": 531
    },
    {
      "t": 30206,
      "e": 30206,
      "ty": 2,
      "x": 674,
      "y": 530
    },
    {
      "t": 30229,
      "e": 30229,
      "ty": 6,
      "x": 678,
      "y": 526,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30250,
      "e": 30250,
      "ty": 41,
      "x": 29159,
      "y": 60570,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30306,
      "e": 30306,
      "ty": 2,
      "x": 681,
      "y": 522
    },
    {
      "t": 30407,
      "e": 30407,
      "ty": 2,
      "x": 682,
      "y": 520
    },
    {
      "t": 30500,
      "e": 30500,
      "ty": 41,
      "x": 30705,
      "y": 48654,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30508,
      "e": 30508,
      "ty": 2,
      "x": 682,
      "y": 519
    },
    {
      "t": 30582,
      "e": 30582,
      "ty": 3,
      "x": 684,
      "y": 519,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30583,
      "e": 30583,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 30583,
      "e": 30583,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30609,
      "e": 30609,
      "ty": 2,
      "x": 684,
      "y": 519
    },
    {
      "t": 30702,
      "e": 30702,
      "ty": 4,
      "x": 31736,
      "y": 48654,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30705,
      "e": 30705,
      "ty": 5,
      "x": 684,
      "y": 519,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 30706,
      "e": 30706,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 30751,
      "e": 30751,
      "ty": 41,
      "x": 32670,
      "y": 44445,
      "ta": "html > body"
    },
    {
      "t": 30811,
      "e": 30811,
      "ty": 2,
      "x": 684,
      "y": 515
    },
    {
      "t": 30912,
      "e": 30912,
      "ty": 2,
      "x": 704,
      "y": 510
    },
    {
      "t": 31001,
      "e": 31001,
      "ty": 41,
      "x": 40741,
      "y": 39913,
      "ta": "html > body"
    },
    {
      "t": 31013,
      "e": 31013,
      "ty": 2,
      "x": 851,
      "y": 466
    },
    {
      "t": 31113,
      "e": 31113,
      "ty": 2,
      "x": 885,
      "y": 458
    },
    {
      "t": 31215,
      "e": 31215,
      "ty": 2,
      "x": 886,
      "y": 457
    },
    {
      "t": 31251,
      "e": 31251,
      "ty": 41,
      "x": 42433,
      "y": 39129,
      "ta": "html > body"
    },
    {
      "t": 31291,
      "e": 31291,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 31719,
      "e": 31719,
      "ty": 2,
      "x": 885,
      "y": 457
    },
    {
      "t": 31753,
      "e": 31753,
      "ty": 41,
      "x": 42240,
      "y": 39129,
      "ta": "html > body"
    },
    {
      "t": 31797,
      "e": 31797,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 31820,
      "e": 31820,
      "ty": 2,
      "x": 874,
      "y": 459
    },
    {
      "t": 31921,
      "e": 31921,
      "ty": 2,
      "x": 865,
      "y": 462
    },
    {
      "t": 32005,
      "e": 32005,
      "ty": 41,
      "x": 45126,
      "y": 41486,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 32113,
      "e": 32113,
      "ty": 38,
      "x": 11,
      "y": 0
    },
    {
      "t": 32224,
      "e": 32224,
      "ty": 2,
      "x": 862,
      "y": 464
    },
    {
      "t": 32256,
      "e": 32256,
      "ty": 41,
      "x": 44711,
      "y": 42212,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 32282,
      "e": 32282,
      "ty": 6,
      "x": 850,
      "y": 473,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 32325,
      "e": 32325,
      "ty": 2,
      "x": 839,
      "y": 478
    },
    {
      "t": 32426,
      "e": 32426,
      "ty": 2,
      "x": 739,
      "y": 489
    },
    {
      "t": 32472,
      "e": 32472,
      "ty": 7,
      "x": 683,
      "y": 499,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 32472,
      "e": 32472,
      "ty": 6,
      "x": 683,
      "y": 499,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 32507,
      "e": 32507,
      "ty": 41,
      "x": 30372,
      "y": 10532,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 32526,
      "e": 32526,
      "ty": 2,
      "x": 655,
      "y": 507
    },
    {
      "t": 32628,
      "e": 32628,
      "ty": 2,
      "x": 653,
      "y": 508
    },
    {
      "t": 32758,
      "e": 32758,
      "ty": 41,
      "x": 29004,
      "y": 24575,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 33638,
      "e": 33638,
      "ty": 1,
      "x": 0,
      "y": 9
    },
    {
      "t": 33739,
      "e": 33739,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 33839,
      "e": 33839,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 33939,
      "e": 33939,
      "ty": 1,
      "x": 0,
      "y": 13
    },
    {
      "t": 34142,
      "e": 34142,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 34242,
      "e": 34242,
      "ty": 1,
      "x": 0,
      "y": 9
    },
    {
      "t": 34343,
      "e": 34343,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 34444,
      "e": 34444,
      "ty": 2,
      "x": 653,
      "y": 516
    },
    {
      "t": 34514,
      "e": 34514,
      "ty": 41,
      "x": 29004,
      "y": 43299,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 38638,
      "e": 38638,
      "ty": 7,
      "x": 652,
      "y": 529,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 38639,
      "e": 38639,
      "ty": 6,
      "x": 652,
      "y": 529,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38673,
      "e": 38673,
      "ty": 7,
      "x": 642,
      "y": 571,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38673,
      "e": 38673,
      "ty": 6,
      "x": 642,
      "y": 571,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38686,
      "e": 38686,
      "ty": 2,
      "x": 642,
      "y": 571
    },
    {
      "t": 38691,
      "e": 38691,
      "ty": 7,
      "x": 637,
      "y": 609,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38781,
      "e": 38781,
      "ty": 41,
      "x": 6553,
      "y": 53345,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 38787,
      "e": 38787,
      "ty": 2,
      "x": 630,
      "y": 746
    },
    {
      "t": 38888,
      "e": 38888,
      "ty": 2,
      "x": 654,
      "y": 748
    },
    {
      "t": 38969,
      "e": 38969,
      "ty": 6,
      "x": 697,
      "y": 716,
      "ta": "#start"
    },
    {
      "t": 38989,
      "e": 38989,
      "ty": 2,
      "x": 701,
      "y": 714
    },
    {
      "t": 39031,
      "e": 39031,
      "ty": 41,
      "x": 38774,
      "y": 50506,
      "ta": "#start"
    },
    {
      "t": 39090,
      "e": 39090,
      "ty": 2,
      "x": 719,
      "y": 701
    },
    {
      "t": 39175,
      "e": 39175,
      "ty": 7,
      "x": 732,
      "y": 683,
      "ta": "#start"
    },
    {
      "t": 39191,
      "e": 39191,
      "ty": 2,
      "x": 732,
      "y": 683
    },
    {
      "t": 39238,
      "e": 39238,
      "ty": 6,
      "x": 732,
      "y": 684,
      "ta": "#start"
    },
    {
      "t": 39282,
      "e": 39282,
      "ty": 41,
      "x": 52428,
      "y": 11956,
      "ta": "#start"
    },
    {
      "t": 39291,
      "e": 39291,
      "ty": 2,
      "x": 732,
      "y": 695
    },
    {
      "t": 39392,
      "e": 39392,
      "ty": 2,
      "x": 732,
      "y": 706
    },
    {
      "t": 39532,
      "e": 39532,
      "ty": 41,
      "x": 52428,
      "y": 40869,
      "ta": "#start"
    },
    {
      "t": 39559,
      "e": 39559,
      "ty": 3,
      "x": 732,
      "y": 706,
      "ta": "#start"
    },
    {
      "t": 39695,
      "e": 39695,
      "ty": 4,
      "x": 52428,
      "y": 40869,
      "ta": "#start"
    },
    {
      "t": 39696,
      "e": 39696,
      "ty": 5,
      "x": 732,
      "y": 706,
      "ta": "#start"
    },
    {
      "t": 39698,
      "e": 39698,
      "ty": 38,
      "x": 12,
      "y": 0
    },
    {
      "t": 40003,
      "e": 40003,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40297,
      "e": 40297,
      "ty": 38,
      "x": 13,
      "y": 0
    },
    {
      "t": 40700,
      "e": 40700,
      "ty": 38,
      "x": 14,
      "y": 0
    },
    {
      "t": 41621,
      "e": 41621,
      "ty": 1,
      "x": 0,
      "y": 35
    },
    {
      "t": 41721,
      "e": 41721,
      "ty": 1,
      "x": 0,
      "y": 76
    },
    {
      "t": 41822,
      "e": 41822,
      "ty": 1,
      "x": 0,
      "y": 80
    },
    {
      "t": 41923,
      "e": 41923,
      "ty": 1,
      "x": 0,
      "y": 75
    },
    {
      "t": 42023,
      "e": 42023,
      "ty": 1,
      "x": 0,
      "y": 71
    },
    {
      "t": 42124,
      "e": 42124,
      "ty": 1,
      "x": 0,
      "y": 69
    },
    {
      "t": 42225,
      "e": 42225,
      "ty": 2,
      "x": 732,
      "y": 767
    },
    {
      "t": 42225,
      "e": 42225,
      "ty": 1,
      "x": 0,
      "y": 68
    },
    {
      "t": 42320,
      "e": 42320,
      "ty": 41,
      "x": 35000,
      "y": 64913,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42326,
      "e": 42326,
      "ty": 2,
      "x": 732,
      "y": 766
    },
    {
      "t": 42427,
      "e": 42427,
      "ty": 2,
      "x": 734,
      "y": 760
    },
    {
      "t": 42571,
      "e": 42571,
      "ty": 41,
      "x": 35097,
      "y": 64447,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42760,
      "e": 42760,
      "ty": 38,
      "x": 15,
      "y": 0
    },
    {
      "t": 42832,
      "e": 42832,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 42933,
      "e": 42933,
      "ty": 2,
      "x": 734,
      "y": 700
    },
    {
      "t": 43073,
      "e": 43073,
      "ty": 41,
      "x": 35087,
      "y": 60306,
      "ta": "html > body"
    },
    {
      "t": 43299,
      "e": 43299,
      "ty": 38,
      "x": 16,
      "y": 0
    },
    {
      "t": 43766,
      "e": 43766,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":61}],[{\"nodeType\":1,\"id\":62,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":63,\"previousSibling\":{\"id\":62},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":64,\"textContent\":\" \",\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":66,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":68,\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":69,\"textContent\":\" \",\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":70,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":71,\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":72,\"textContent\":\" \",\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":74,\"previousSibling\":{\"id\":73},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":75,\"textContent\":\" \",\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":77,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":76},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":78,\"textContent\":\" \",\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"parentNode\":{\"id\":77}},{\"nodeType\":1,\"id\":80,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":79},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"previousSibling\":{\"id\":80},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":82,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":80}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"parentNode\":{\"id\":70}},{\"nodeType\":1,\"id\":84,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":83},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":85,\"textContent\":\" \",\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":93,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":84}},{\"nodeType\":8,\"id\":95,\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":97,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":96},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":98,\"textContent\":\" \",\"previousSibling\":{\"id\":97},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":99,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":100,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":101,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":102,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":93}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"parentNode\":{\"id\":97}},{\"nodeType\":1,\"id\":104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":103},\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":105,\"textContent\":\" \",\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":106,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":104}},{\"nodeType\":1,\"id\":107,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":104}},{\"nodeType\":1,\"id\":109,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":108},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":110,\"textContent\":\" \",\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"parentNode\":{\"id\":73}},{\"nodeType\":1,\"id\":112,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":111},\"parentNode\":{\"id\":73}},{\"nodeType\":3,\"id\":113,\"textContent\":\" \",\"previousSibling\":{\"id\":112},\"parentNode\":{\"id\":73}},{\"nodeType\":3,\"id\":114,\"textContent\":\"START\",\"parentNode\":{\"id\":112}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":115,\"tagName\":\"SCRIPT\",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":62},{\"id\":65},{\"id\":66},{\"id\":76},{\"id\":77},{\"id\":79},{\"id\":80},{\"id\":82},{\"id\":81},{\"id\":78},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":83},{\"id\":84},{\"id\":86},{\"id\":87},{\"id\":99},{\"id\":88},{\"id\":89},{\"id\":100},{\"id\":90},{\"id\":91},{\"id\":101},{\"id\":92},{\"id\":93},{\"id\":102},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":103},{\"id\":104},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":105},{\"id\":98},{\"id\":85},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":111},{\"id\":112},{\"id\":114},{\"id\":113},{\"id\":74},{\"id\":75},{\"id\":63},{\"id\":64},{\"id\":115}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":116,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":116},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":118,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":117},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":119,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":118},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":120,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":116}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":120}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":117}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":1,\"id\":125,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":118}},{\"nodeType\":1,\"id\":126,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":125},\"parentNode\":{\"id\":118}},{\"nodeType\":3,\"id\":127,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":125}},{\"nodeType\":3,\"id\":128,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":119}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":129,\"tagName\":\"SCRIPT\",\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":116},{\"id\":120},{\"id\":121},{\"id\":117},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":118},{\"id\":125},{\"id\":127},{\"id\":126},{\"id\":119},{\"id\":128},{\"id\":129}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":130,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":130}],[{\"nodeType\":1,\"id\":131,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"previousSibling\":{\"id\":131},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":136,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":131}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":139,\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \",\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":143,\"previousSibling\":{\"id\":142},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":144,\"textContent\":\" \",\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":145,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":146,\"previousSibling\":{\"id\":145},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \",\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"parentNode\":{\"id\":138}},{\"nodeType\":1,\"id\":149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":148},\"parentNode\":{\"id\":138}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"previousSibling\":{\"id\":149},\"parentNode\":{\"id\":138}},{\"nodeType\":3,\"id\":151,\"textContent\":\" \",\"parentNode\":{\"id\":149}},{\"nodeType\":1,\"id\":152,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":149}},{\"nodeType\":3,\"id\":153,\"textContent\":\" \",\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":149}},{\"nodeType\":3,\"id\":154,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":152}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":141}},{\"nodeType\":1,\"id\":156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":157,\"textContent\":\" \",\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":141}},{\"nodeType\":8,\"id\":158,\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":159,\"textContent\":\" \",\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":161,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":162,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \",\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":164,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":165,\"textContent\":\" \",\"previousSibling\":{\"id\":164},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":168,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":167},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"previousSibling\":{\"id\":168},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":170,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":171,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":170},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":172,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":173,\"textContent\":\"all\",\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \",\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":176,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":177,\"textContent\":\" \",\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":178,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":180,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":180},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":186,\"textContent\":\" \",\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":187,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":186},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"previousSibling\":{\"id\":187},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":187}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":178}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":178}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":178}},{\"nodeType\":1,\"id\":196,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":197,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":198,\"textContent\":\" \",\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":199,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":198},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"previousSibling\":{\"id\":199},\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":203,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":199}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":205,\"textContent\":\" \",\"parentNode\":{\"id\":184}},{\"nodeType\":1,\"id\":206,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":207,\"textContent\":\" \",\"previousSibling\":{\"id\":206},\"parentNode\":{\"id\":184}},{\"nodeType\":1,\"id\":208,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":206}},{\"nodeType\":3,\"id\":209,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":208}},{\"nodeType\":1,\"id\":210,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":164}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \",\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":164}},{\"nodeType\":3,\"id\":212,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":210}},{\"nodeType\":3,\"id\":213,\"textContent\":\" \\t\",\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":215,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":217,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":216},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":218,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":221,\"textContent\":\" \",\"previousSibling\":{\"id\":220},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":214}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":223},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":225,\"textContent\":\" \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":226,\"textContent\":\"carefully\",\"parentNode\":{\"id\":224}},{\"nodeType\":1,\"id\":227,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":216}},{\"nodeType\":3,\"id\":228,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":227},\"parentNode\":{\"id\":216}},{\"nodeType\":1,\"id\":229,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":218}},{\"nodeType\":3,\"id\":230,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":218}},{\"nodeType\":1,\"id\":231,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":220}},{\"nodeType\":3,\"id\":232,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":231},\"parentNode\":{\"id\":220}},{\"nodeType\":3,\"id\":233,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":168}},{\"nodeType\":3,\"id\":234,\"textContent\":\" \\t\",\"parentNode\":{\"id\":145}},{\"nodeType\":1,\"id\":235,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":234},\"parentNode\":{\"id\":145}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \",\"previousSibling\":{\"id\":235},\"parentNode\":{\"id\":145}},{\"nodeType\":3,\"id\":237,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":235}}],[],[]]}"
    },
    {
      "sequence": 11,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":238,\"tagName\":\"SCRIPT\",\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 12,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":131},{\"id\":136},{\"id\":132},{\"id\":133},{\"id\":137},{\"id\":138},{\"id\":148},{\"id\":149},{\"id\":151},{\"id\":152},{\"id\":154},{\"id\":153},{\"id\":150},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":155},{\"id\":156},{\"id\":160},{\"id\":161},{\"id\":170},{\"id\":171},{\"id\":173},{\"id\":172},{\"id\":162},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":186},{\"id\":187},{\"id\":191},{\"id\":188},{\"id\":189},{\"id\":192},{\"id\":190},{\"id\":177},{\"id\":178},{\"id\":193},{\"id\":194},{\"id\":196},{\"id\":197},{\"id\":195},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":198},{\"id\":199},{\"id\":203},{\"id\":200},{\"id\":201},{\"id\":204},{\"id\":202},{\"id\":183},{\"id\":184},{\"id\":205},{\"id\":206},{\"id\":208},{\"id\":209},{\"id\":207},{\"id\":185},{\"id\":163},{\"id\":164},{\"id\":210},{\"id\":212},{\"id\":211},{\"id\":165},{\"id\":166},{\"id\":213},{\"id\":214},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":226},{\"id\":225},{\"id\":215},{\"id\":216},{\"id\":227},{\"id\":228},{\"id\":217},{\"id\":218},{\"id\":229},{\"id\":230},{\"id\":219},{\"id\":220},{\"id\":231},{\"id\":232},{\"id\":221},{\"id\":167},{\"id\":168},{\"id\":233},{\"id\":169},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":234},{\"id\":235},{\"id\":237},{\"id\":236},{\"id\":146},{\"id\":147},{\"id\":134},{\"id\":135},{\"id\":238}],[],[],[]]}"
    },
    {
      "sequence": 13,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":239,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 14,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":240,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"previousSibling\":{\"id\":239},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":241,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":240},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":242,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":241}}],[],[]]}"
    },
    {
      "sequence": 15,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242}],[],[],[]]}"
    },
    {
      "sequence": 16,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":243,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\",\"style\":\"\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":60,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 208, dom: 1949, initialDom: 2027",
  "javascriptErrors": []
}