var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b161febce4c599d9d9784aec60f17ca0",
  "created": "2018-06-04T13:18:20.2516953-07:00",
  "lastActivity": "2018-06-04T13:19:12.7618063-07:00",
  "pageViews": [
    {
      "id": "060420176b8eddad20b1696ccdbbe3361be3ce98",
      "startTime": "2018-06-04T13:18:20.3719802-07:00",
      "endTime": "2018-06-04T13:19:12.7618063-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 52683,
      "engagementTime": 52197,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 52683,
  "engagementTime": 52197,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GD39M",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9d3a9cb65751dd4de1dd77d61361ed25",
  "gdpr": false
}