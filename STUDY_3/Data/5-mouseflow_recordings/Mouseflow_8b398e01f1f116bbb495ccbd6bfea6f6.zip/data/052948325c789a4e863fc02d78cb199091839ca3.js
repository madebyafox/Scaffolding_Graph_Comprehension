var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052948325c789a4e863fc02d78cb199091839ca3"] = {
  "startTime": "2018-05-29T17:07:48.2783807Z",
  "websitePageUrl": "/",
  "visitTime": 24304,
  "engagementTime": 24304,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "8b398e01f1f116bbb495ccbd6bfea6f6",
    "created": "2018-05-29T17:07:48.2783807+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ea0464c9e7adc3d4dc2abc4b656f485a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8b398e01f1f116bbb495ccbd6bfea6f6/play"
  },
  "events": [
    {
      "t": 75,
      "e": 75,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 773,
      "y": 795
    },
    {
      "t": 413,
      "e": 413,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 505,
      "e": 505,
      "ty": 2,
      "x": 887,
      "y": 1016
    },
    {
      "t": 506,
      "e": 506,
      "ty": 41,
      "x": 30270,
      "y": 61336,
      "ta": "html > body"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 1063,
      "y": 956
    },
    {
      "t": 758,
      "e": 758,
      "ty": 41,
      "x": 36331,
      "y": 57685,
      "ta": "html > body"
    },
    {
      "t": 909,
      "e": 909,
      "ty": 3,
      "x": 1063,
      "y": 956,
      "ta": "html > body"
    },
    {
      "t": 1029,
      "e": 1029,
      "ty": 4,
      "x": 36331,
      "y": 57685,
      "ta": "html > body"
    },
    {
      "t": 1029,
      "e": 1029,
      "ty": 5,
      "x": 1063,
      "y": 956,
      "ta": "html > body"
    },
    {
      "t": 1503,
      "e": 1503,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 853,
      "y": 806
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 2,
      "x": 650,
      "y": 685
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 22109,
      "y": 41195,
      "ta": "html > body"
    },
    {
      "t": 2584,
      "e": 2584,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 650,
      "y": 684
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 646,
      "y": 671
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 16507,
      "y": 8425,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 616,
      "y": 623
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 613,
      "y": 618
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 628,
      "y": 638
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 16458,
      "y": 8425,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 3081,
      "e": 3081,
      "ty": 6,
      "x": 917,
      "y": 980,
      "ta": "#start"
    },
    {
      "t": 3096,
      "e": 3096,
      "ty": 7,
      "x": 1003,
      "y": 1042,
      "ta": "#start"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 1003,
      "y": 1042
    },
    {
      "t": 3202,
      "e": 3202,
      "ty": 2,
      "x": 1075,
      "y": 1078
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 36882,
      "y": 64865,
      "ta": "> div.masterdiv"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1083,
      "y": 1032
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1025,
      "y": 925
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 994,
      "y": 871
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 40013,
      "y": 47661,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 3603,
      "e": 3603,
      "ty": 2,
      "x": 987,
      "y": 860
    },
    {
      "t": 3706,
      "e": 3706,
      "ty": 3,
      "x": 987,
      "y": 860,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 3767,
      "e": 3767,
      "ty": 41,
      "x": 38543,
      "y": 14894,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 3786,
      "e": 3786,
      "ty": 4,
      "x": 38543,
      "y": 14894,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 3786,
      "e": 3786,
      "ty": 5,
      "x": 987,
      "y": 860,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 3787,
      "e": 3787,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 3790,
      "e": 3790,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 3914,
      "e": 3914,
      "ty": 2,
      "x": 984,
      "y": 874
    },
    {
      "t": 3995,
      "e": 3995,
      "ty": 6,
      "x": 968,
      "y": 978,
      "ta": "#start"
    },
    {
      "t": 4015,
      "e": 4015,
      "ty": 2,
      "x": 966,
      "y": 985
    },
    {
      "t": 4015,
      "e": 4015,
      "ty": 41,
      "x": 30856,
      "y": 14847,
      "ta": "#start"
    },
    {
      "t": 4120,
      "e": 4120,
      "ty": 2,
      "x": 964,
      "y": 990
    },
    {
      "t": 4270,
      "e": 4270,
      "ty": 41,
      "x": 29763,
      "y": 24485,
      "ta": "#start"
    },
    {
      "t": 5110,
      "e": 5110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "122"
    },
    {
      "t": 5121,
      "e": 5121,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 5131,
      "e": 5131,
      "ty": 7,
      "x": 964,
      "y": 1056,
      "ta": "#start"
    },
    {
      "t": 5206,
      "e": 5206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 5215,
      "e": 5215,
      "ty": 2,
      "x": 964,
      "y": 1056
    },
    {
      "t": 5265,
      "e": 5265,
      "ty": 41,
      "x": 32988,
      "y": 64379,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 5617,
      "e": 5617,
      "ty": 2,
      "x": 964,
      "y": 1059
    },
    {
      "t": 5646,
      "e": 5646,
      "ty": 6,
      "x": 964,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 5696,
      "e": 5696,
      "ty": 7,
      "x": 960,
      "y": 1110,
      "ta": "#start"
    },
    {
      "t": 5714,
      "e": 5714,
      "ty": 2,
      "x": 959,
      "y": 1112
    },
    {
      "t": 5767,
      "e": 5767,
      "ty": 41,
      "x": 32533,
      "y": 21778,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 5818,
      "e": 5818,
      "ty": 2,
      "x": 959,
      "y": 1109
    },
    {
      "t": 5845,
      "e": 5845,
      "ty": 6,
      "x": 959,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 5915,
      "e": 5915,
      "ty": 2,
      "x": 960,
      "y": 1101
    },
    {
      "t": 6021,
      "e": 6021,
      "ty": 2,
      "x": 960,
      "y": 1099
    },
    {
      "t": 6022,
      "e": 6022,
      "ty": 41,
      "x": 27579,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 6042,
      "e": 6042,
      "ty": 3,
      "x": 960,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 6043,
      "e": 6043,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 6043,
      "e": 6043,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 6138,
      "e": 6138,
      "ty": 4,
      "x": 27579,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 6138,
      "e": 6138,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 6140,
      "e": 6140,
      "ty": 5,
      "x": 960,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 6140,
      "e": 6140,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 6416,
      "e": 6416,
      "ty": 2,
      "x": 960,
      "y": 1098
    },
    {
      "t": 6522,
      "e": 6522,
      "ty": 41,
      "x": 32784,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 6914,
      "e": 6914,
      "ty": 2,
      "x": 946,
      "y": 970
    },
    {
      "t": 7014,
      "e": 7014,
      "ty": 2,
      "x": 917,
      "y": 794
    },
    {
      "t": 7014,
      "e": 7014,
      "ty": 41,
      "x": 31303,
      "y": 43542,
      "ta": "html > body"
    },
    {
      "t": 7114,
      "e": 7114,
      "ty": 2,
      "x": 919,
      "y": 770
    },
    {
      "t": 7141,
      "e": 7141,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 7214,
      "e": 7214,
      "ty": 6,
      "x": 865,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7215,
      "e": 7215,
      "ty": 2,
      "x": 865,
      "y": 606
    },
    {
      "t": 7264,
      "e": 7264,
      "ty": 7,
      "x": 852,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7264,
      "e": 7264,
      "ty": 41,
      "x": 9516,
      "y": 38052,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 7314,
      "e": 7314,
      "ty": 2,
      "x": 840,
      "y": 532
    },
    {
      "t": 7420,
      "e": 7420,
      "ty": 2,
      "x": 840,
      "y": 529
    },
    {
      "t": 7522,
      "e": 7522,
      "ty": 41,
      "x": 6921,
      "y": 4932,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 7598,
      "e": 7598,
      "ty": 6,
      "x": 869,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7614,
      "e": 7614,
      "ty": 2,
      "x": 871,
      "y": 589
    },
    {
      "t": 7714,
      "e": 7714,
      "ty": 2,
      "x": 873,
      "y": 591
    },
    {
      "t": 7767,
      "e": 7767,
      "ty": 41,
      "x": 14058,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7866,
      "e": 7866,
      "ty": 3,
      "x": 873,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7866,
      "e": 7866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7978,
      "e": 7978,
      "ty": 4,
      "x": 14058,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 7978,
      "e": 7978,
      "ty": 5,
      "x": 873,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8094,
      "e": 8094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 8094,
      "e": 8094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8182,
      "e": 8182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 8293,
      "e": 8293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 8294,
      "e": 8294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8406,
      "e": 8406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "52"
    },
    {
      "t": 8406,
      "e": 8406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8434,
      "e": 8434,
      "ty": 7,
      "x": 873,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8437,
      "e": 8437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "11*"
    },
    {
      "t": 8515,
      "e": 8515,
      "ty": 2,
      "x": 870,
      "y": 678
    },
    {
      "t": 8515,
      "e": 8515,
      "ty": 41,
      "x": 13409,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 8515,
      "e": 8515,
      "ty": 6,
      "x": 870,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8550,
      "e": 8550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "11*"
    },
    {
      "t": 8615,
      "e": 8615,
      "ty": 2,
      "x": 870,
      "y": 680
    },
    {
      "t": 8720,
      "e": 8720,
      "ty": 2,
      "x": 870,
      "y": 681
    },
    {
      "t": 8771,
      "e": 8771,
      "ty": 41,
      "x": 13409,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8778,
      "e": 8778,
      "ty": 3,
      "x": 870,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8778,
      "e": 8778,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "11*"
    },
    {
      "t": 8778,
      "e": 8778,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8779,
      "e": 8779,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8850,
      "e": 8850,
      "ty": 4,
      "x": 13409,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8851,
      "e": 8850,
      "ty": 5,
      "x": 870,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8899,
      "e": 8898,
      "ty": 7,
      "x": 873,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8915,
      "e": 8914,
      "ty": 2,
      "x": 873,
      "y": 674
    },
    {
      "t": 9015,
      "e": 9014,
      "ty": 41,
      "x": 14058,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 9478,
      "e": 9477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 9478,
      "e": 9477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9534,
      "e": 9533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 9534,
      "e": 9533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9566,
      "e": 9565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "os"
    },
    {
      "t": 9606,
      "e": 9605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 9606,
      "e": 9605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9646,
      "e": 9645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "osc"
    },
    {
      "t": 9710,
      "e": 9709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 9710,
      "e": 9709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9742,
      "e": 9741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "osca"
    },
    {
      "t": 9893,
      "e": 9892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 9933,
      "e": 9932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 9933,
      "e": 9932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 10053,
      "e": 10052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 10306,
      "e": 10305,
      "ty": 6,
      "x": 874,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 10316,
      "e": 10315,
      "ty": 2,
      "x": 874,
      "y": 682
    },
    {
      "t": 10383,
      "e": 10382,
      "ty": 7,
      "x": 884,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 10414,
      "e": 10413,
      "ty": 2,
      "x": 891,
      "y": 713
    },
    {
      "t": 10418,
      "e": 10417,
      "ty": 6,
      "x": 897,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 10514,
      "e": 10513,
      "ty": 2,
      "x": 903,
      "y": 726
    },
    {
      "t": 10515,
      "e": 10514,
      "ty": 41,
      "x": 3647,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 10615,
      "e": 10614,
      "ty": 2,
      "x": 905,
      "y": 726
    },
    {
      "t": 10771,
      "e": 10770,
      "ty": 41,
      "x": 4678,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 12068,
      "e": 12067,
      "ty": 7,
      "x": 907,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 12085,
      "e": 12084,
      "ty": 6,
      "x": 910,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 12115,
      "e": 12114,
      "ty": 2,
      "x": 912,
      "y": 682
    },
    {
      "t": 12118,
      "e": 12117,
      "ty": 7,
      "x": 917,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 12215,
      "e": 12214,
      "ty": 2,
      "x": 930,
      "y": 609
    },
    {
      "t": 12265,
      "e": 12264,
      "ty": 41,
      "x": 26387,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 12314,
      "e": 12313,
      "ty": 2,
      "x": 930,
      "y": 624
    },
    {
      "t": 12420,
      "e": 12419,
      "ty": 2,
      "x": 930,
      "y": 627
    },
    {
      "t": 12517,
      "e": 12516,
      "ty": 2,
      "x": 930,
      "y": 625
    },
    {
      "t": 12517,
      "e": 12516,
      "ty": 41,
      "x": 26387,
      "y": 7046,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 12749,
      "e": 12748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 12817,
      "e": 12816,
      "ty": 2,
      "x": 930,
      "y": 624
    },
    {
      "t": 12914,
      "e": 12913,
      "ty": 2,
      "x": 930,
      "y": 621
    },
    {
      "t": 13020,
      "e": 13019,
      "ty": 41,
      "x": 26387,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 13217,
      "e": 13216,
      "ty": 2,
      "x": 930,
      "y": 620
    },
    {
      "t": 13243,
      "e": 13242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13265,
      "e": 13264,
      "ty": 41,
      "x": 26387,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 13276,
      "e": 13275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13309,
      "e": 13308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13315,
      "e": 13314,
      "ty": 2,
      "x": 930,
      "y": 613
    },
    {
      "t": 13342,
      "e": 13341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13375,
      "e": 13374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13408,
      "e": 13407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13414,
      "e": 13413,
      "ty": 2,
      "x": 928,
      "y": 607
    },
    {
      "t": 13419,
      "e": 13418,
      "ty": 6,
      "x": 927,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13441,
      "e": 13440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13481,
      "e": 13480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13507,
      "e": 13506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13515,
      "e": 13514,
      "ty": 2,
      "x": 927,
      "y": 605
    },
    {
      "t": 13515,
      "e": 13514,
      "ty": 41,
      "x": 25738,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13540,
      "e": 13539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 13541,
      "e": 13540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 13615,
      "e": 13614,
      "ty": 2,
      "x": 927,
      "y": 604
    },
    {
      "t": 13715,
      "e": 13714,
      "ty": 2,
      "x": 926,
      "y": 604
    },
    {
      "t": 13730,
      "e": 13729,
      "ty": 3,
      "x": 926,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13730,
      "e": 13729,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13731,
      "e": 13730,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13765,
      "e": 13764,
      "ty": 41,
      "x": 25521,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13804,
      "e": 13803,
      "ty": 7,
      "x": 786,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13814,
      "e": 13813,
      "ty": 2,
      "x": 786,
      "y": 599
    },
    {
      "t": 13915,
      "e": 13914,
      "ty": 2,
      "x": 338,
      "y": 644
    },
    {
      "t": 13962,
      "e": 13961,
      "ty": 4,
      "x": 10606,
      "y": 35232,
      "ta": "html > body"
    },
    {
      "t": 14015,
      "e": 14014,
      "ty": 2,
      "x": 316,
      "y": 644
    },
    {
      "t": 14015,
      "e": 14014,
      "ty": 41,
      "x": 10606,
      "y": 35232,
      "ta": "html > body"
    },
    {
      "t": 14621,
      "e": 14620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "191"
    },
    {
      "t": 14622,
      "e": 14621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14693,
      "e": 14692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 14694,
      "e": 14693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14718,
      "e": 14717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "os"
    },
    {
      "t": 14814,
      "e": 14813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 14814,
      "e": 14813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14821,
      "e": 14820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osc"
    },
    {
      "t": 14909,
      "e": 14908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 14909,
      "e": 14908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14942,
      "e": 14941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osca"
    },
    {
      "t": 15061,
      "e": 15060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 15061,
      "e": 15060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15086,
      "e": 15085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 15181,
      "e": 15180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 15415,
      "e": 15414,
      "ty": 2,
      "x": 1157,
      "y": 868
    },
    {
      "t": 15521,
      "e": 15520,
      "ty": 2,
      "x": 1193,
      "y": 866
    },
    {
      "t": 15521,
      "e": 15520,
      "ty": 41,
      "x": 40808,
      "y": 47530,
      "ta": "html > body"
    },
    {
      "t": 15614,
      "e": 15613,
      "ty": 2,
      "x": 1145,
      "y": 763
    },
    {
      "t": 15672,
      "e": 15671,
      "ty": 6,
      "x": 1070,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 15715,
      "e": 15714,
      "ty": 2,
      "x": 1063,
      "y": 691
    },
    {
      "t": 15765,
      "e": 15764,
      "ty": 41,
      "x": 54288,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 15815,
      "e": 15814,
      "ty": 2,
      "x": 1048,
      "y": 683
    },
    {
      "t": 16020,
      "e": 16019,
      "ty": 41,
      "x": 51908,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16154,
      "e": 16153,
      "ty": 3,
      "x": 1048,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16154,
      "e": 16153,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "oscar"
    },
    {
      "t": 16155,
      "e": 16154,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16155,
      "e": 16154,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16290,
      "e": 16289,
      "ty": 4,
      "x": 51908,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16290,
      "e": 16289,
      "ty": 5,
      "x": 1048,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16781,
      "e": 16780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 16781,
      "e": 16780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16877,
      "e": 16876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 16966,
      "e": 16965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 16966,
      "e": 16965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17069,
      "e": 17068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 17070,
      "e": 17069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17110,
      "e": 17109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 17206,
      "e": 17205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 17806,
      "e": 17805,
      "ty": 7,
      "x": 1036,
      "y": 709,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17814,
      "e": 17813,
      "ty": 2,
      "x": 1036,
      "y": 709
    },
    {
      "t": 17914,
      "e": 17913,
      "ty": 2,
      "x": 1006,
      "y": 758
    },
    {
      "t": 18014,
      "e": 18013,
      "ty": 2,
      "x": 1001,
      "y": 758
    },
    {
      "t": 18015,
      "e": 18014,
      "ty": 41,
      "x": 34196,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 18115,
      "e": 18114,
      "ty": 2,
      "x": 987,
      "y": 744
    },
    {
      "t": 18217,
      "e": 18216,
      "ty": 2,
      "x": 984,
      "y": 741
    },
    {
      "t": 18229,
      "e": 18228,
      "ty": 6,
      "x": 984,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18264,
      "e": 18263,
      "ty": 41,
      "x": 43848,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18315,
      "e": 18314,
      "ty": 2,
      "x": 977,
      "y": 736
    },
    {
      "t": 18422,
      "e": 18421,
      "ty": 2,
      "x": 977,
      "y": 735
    },
    {
      "t": 18465,
      "e": 18464,
      "ty": 3,
      "x": 977,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18466,
      "e": 18465,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 18466,
      "e": 18465,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18466,
      "e": 18465,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18522,
      "e": 18521,
      "ty": 41,
      "x": 41786,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18569,
      "e": 18568,
      "ty": 4,
      "x": 41786,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18570,
      "e": 18569,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18572,
      "e": 18571,
      "ty": 5,
      "x": 977,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 18572,
      "e": 18571,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 19655,
      "e": 19654,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 19680,
      "e": 19679,
      "ty": 6,
      "x": 977,
      "y": 735,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 20016,
      "e": 20015,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20041,
      "e": 20041,
      "ty": 7,
      "x": 968,
      "y": 774,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 20042,
      "e": 20042,
      "ty": 6,
      "x": 968,
      "y": 774,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 20057,
      "e": 20057,
      "ty": 7,
      "x": 957,
      "y": 805,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 20114,
      "e": 20114,
      "ty": 2,
      "x": 913,
      "y": 980
    },
    {
      "t": 20215,
      "e": 20215,
      "ty": 2,
      "x": 911,
      "y": 996
    },
    {
      "t": 20265,
      "e": 20265,
      "ty": 41,
      "x": 30381,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 20315,
      "e": 20315,
      "ty": 2,
      "x": 920,
      "y": 1038
    },
    {
      "t": 20391,
      "e": 20391,
      "ty": 6,
      "x": 948,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 20415,
      "e": 20415,
      "ty": 2,
      "x": 950,
      "y": 1074
    },
    {
      "t": 20515,
      "e": 20515,
      "ty": 2,
      "x": 954,
      "y": 1074
    },
    {
      "t": 20515,
      "e": 20515,
      "ty": 41,
      "x": 24302,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 20614,
      "e": 20614,
      "ty": 2,
      "x": 962,
      "y": 1078
    },
    {
      "t": 20715,
      "e": 20715,
      "ty": 2,
      "x": 975,
      "y": 1086
    },
    {
      "t": 20765,
      "e": 20765,
      "ty": 41,
      "x": 35771,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 21001,
      "e": 21001,
      "ty": 3,
      "x": 975,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 21002,
      "e": 21002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 21146,
      "e": 21146,
      "ty": 4,
      "x": 35771,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 21147,
      "e": 21147,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 21147,
      "e": 21147,
      "ty": 5,
      "x": 975,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 21147,
      "e": 21147,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 22149,
      "e": 22149,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 23301,
      "e": 23301,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 24304,
      "e": 24304,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 86, dom: 585, initialDom: 593",
  "javascriptErrors": []
}