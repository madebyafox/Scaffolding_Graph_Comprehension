var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0fdee96e6312dc57176d863a3fbd2595",
  "created": "2018-06-01T09:24:19.8070373-07:00",
  "lastActivity": "2018-06-01T09:26:56.7000373-07:00",
  "pageViews": [
    {
      "id": "06012007c6c244b380bbdda5dcb11cfdd7c4ddfd",
      "startTime": "2018-06-01T09:24:19.8070373-07:00",
      "endTime": "2018-06-01T09:26:56.7000373-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 156893,
      "engagementTime": 147502,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 156893,
  "engagementTime": 147502,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=A9C1X",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e27e9b6d7ef67ba0458f798a75cc5627",
  "gdpr": false
}