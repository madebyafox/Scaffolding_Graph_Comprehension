var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05251203e7414a83e6870b3c217495f6ed352a53"] = {
  "startTime": "2018-05-25T18:06:12.703685Z",
  "websitePageUrl": "/",
  "visitTime": 159473,
  "engagementTime": 50366,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "77510a0fa8eb9a086b7b0905eea1a34a",
    "created": "2018-05-25T18:06:12.703685+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "fb797e496d643cc9e4fb1c851d3a2f5e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/77510a0fa8eb9a086b7b0905eea1a34a/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 323,
      "e": 323,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10005,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 28500,
      "e": 5101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 28500,
      "e": 5101,
      "ty": 2,
      "x": 387,
      "y": 585
    },
    {
      "t": 28500,
      "e": 5101,
      "ty": 41,
      "x": 1501,
      "y": 31579,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 32700,
      "e": 9301,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 32700,
      "e": 9301,
      "ty": 2,
      "x": 387,
      "y": 519
    },
    {
      "t": 32750,
      "e": 9351,
      "ty": 41,
      "x": 1501,
      "y": 30514,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34600,
      "e": 11201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 34600,
      "e": 11201,
      "ty": 2,
      "x": 387,
      "y": 585
    },
    {
      "t": 34750,
      "e": 11351,
      "ty": 41,
      "x": 1501,
      "y": 31579,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40001,
      "e": 16351,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80204,
      "e": 16351,
      "ty": 2,
      "x": 445,
      "y": 560
    },
    {
      "t": 80253,
      "e": 16400,
      "ty": 41,
      "x": 8328,
      "y": 31006,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 80303,
      "e": 16450,
      "ty": 2,
      "x": 607,
      "y": 627
    },
    {
      "t": 80403,
      "e": 16550,
      "ty": 2,
      "x": 748,
      "y": 708
    },
    {
      "t": 80503,
      "e": 16650,
      "ty": 2,
      "x": 885,
      "y": 774
    },
    {
      "t": 80503,
      "e": 16650,
      "ty": 41,
      "x": 28698,
      "y": 47062,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 80603,
      "e": 16750,
      "ty": 2,
      "x": 960,
      "y": 814
    },
    {
      "t": 80703,
      "e": 16850,
      "ty": 2,
      "x": 1000,
      "y": 857
    },
    {
      "t": 80754,
      "e": 16901,
      "ty": 41,
      "x": 35470,
      "y": 55581,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 80803,
      "e": 16950,
      "ty": 2,
      "x": 1011,
      "y": 885
    },
    {
      "t": 81003,
      "e": 17150,
      "ty": 2,
      "x": 1012,
      "y": 885
    },
    {
      "t": 81004,
      "e": 17151,
      "ty": 41,
      "x": 35634,
      "y": 56155,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81103,
      "e": 17250,
      "ty": 2,
      "x": 1009,
      "y": 872
    },
    {
      "t": 81203,
      "e": 17350,
      "ty": 2,
      "x": 1009,
      "y": 774
    },
    {
      "t": 81254,
      "e": 17401,
      "ty": 41,
      "x": 36999,
      "y": 24288,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81303,
      "e": 17450,
      "ty": 2,
      "x": 1088,
      "y": 347
    },
    {
      "t": 81403,
      "e": 17550,
      "ty": 2,
      "x": 1103,
      "y": 303
    },
    {
      "t": 81503,
      "e": 17650,
      "ty": 2,
      "x": 1133,
      "y": 378
    },
    {
      "t": 81504,
      "e": 17651,
      "ty": 41,
      "x": 42242,
      "y": 14622,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81603,
      "e": 17750,
      "ty": 2,
      "x": 1138,
      "y": 409
    },
    {
      "t": 81703,
      "e": 17850,
      "ty": 2,
      "x": 1141,
      "y": 422
    },
    {
      "t": 81753,
      "e": 17900,
      "ty": 41,
      "x": 43608,
      "y": 20438,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81803,
      "e": 17950,
      "ty": 2,
      "x": 1179,
      "y": 473
    },
    {
      "t": 81903,
      "e": 18050,
      "ty": 2,
      "x": 1185,
      "y": 499
    },
    {
      "t": 82003,
      "e": 18150,
      "ty": 2,
      "x": 1191,
      "y": 519
    },
    {
      "t": 82003,
      "e": 18150,
      "ty": 41,
      "x": 45410,
      "y": 26173,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82104,
      "e": 18251,
      "ty": 2,
      "x": 1200,
      "y": 539
    },
    {
      "t": 82204,
      "e": 18351,
      "ty": 2,
      "x": 1202,
      "y": 546
    },
    {
      "t": 82254,
      "e": 18401,
      "ty": 41,
      "x": 46011,
      "y": 28384,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82492,
      "e": 18639,
      "ty": 3,
      "x": 1202,
      "y": 546,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82628,
      "e": 18775,
      "ty": 4,
      "x": 46011,
      "y": 28384,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82629,
      "e": 18776,
      "ty": 5,
      "x": 1202,
      "y": 546,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82803,
      "e": 18950,
      "ty": 2,
      "x": 1164,
      "y": 496
    },
    {
      "t": 82903,
      "e": 19050,
      "ty": 2,
      "x": 903,
      "y": 332
    },
    {
      "t": 83003,
      "e": 19150,
      "ty": 2,
      "x": 795,
      "y": 286
    },
    {
      "t": 83004,
      "e": 19151,
      "ty": 41,
      "x": 23783,
      "y": 7085,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 83204,
      "e": 19351,
      "ty": 2,
      "x": 796,
      "y": 283
    },
    {
      "t": 83253,
      "e": 19400,
      "ty": 41,
      "x": 23838,
      "y": 6840,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 90004,
      "e": 24400,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 133507,
      "e": 24400,
      "ty": 2,
      "x": 787,
      "y": 294
    },
    {
      "t": 133507,
      "e": 24400,
      "ty": 41,
      "x": 24281,
      "y": 11612,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 133607,
      "e": 24500,
      "ty": 2,
      "x": 837,
      "y": 501
    },
    {
      "t": 133707,
      "e": 24600,
      "ty": 2,
      "x": 854,
      "y": 669
    },
    {
      "t": 133757,
      "e": 24650,
      "ty": 41,
      "x": 27577,
      "y": 29498,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 133807,
      "e": 24700,
      "ty": 2,
      "x": 816,
      "y": 859
    },
    {
      "t": 133906,
      "e": 24799,
      "ty": 2,
      "x": 781,
      "y": 984
    },
    {
      "t": 134007,
      "e": 24900,
      "ty": 41,
      "x": 23985,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134107,
      "e": 25000,
      "ty": 2,
      "x": 791,
      "y": 971
    },
    {
      "t": 134207,
      "e": 25100,
      "ty": 2,
      "x": 801,
      "y": 947
    },
    {
      "t": 134257,
      "e": 25150,
      "ty": 41,
      "x": 25117,
      "y": 56485,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134306,
      "e": 25199,
      "ty": 2,
      "x": 806,
      "y": 935
    },
    {
      "t": 134407,
      "e": 25300,
      "ty": 2,
      "x": 806,
      "y": 930
    },
    {
      "t": 134508,
      "e": 25401,
      "ty": 41,
      "x": 8396,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134707,
      "e": 25600,
      "ty": 2,
      "x": 807,
      "y": 928
    },
    {
      "t": 134757,
      "e": 25650,
      "ty": 3,
      "x": 807,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134757,
      "e": 25650,
      "ty": 41,
      "x": 11673,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134853,
      "e": 25746,
      "ty": 4,
      "x": 11673,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134854,
      "e": 25747,
      "ty": 5,
      "x": 807,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134855,
      "e": 25748,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 134861,
      "e": 25754,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 135007,
      "e": 25900,
      "ty": 2,
      "x": 845,
      "y": 973
    },
    {
      "t": 135007,
      "e": 25900,
      "ty": 41,
      "x": 27134,
      "y": 58631,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 135107,
      "e": 26000,
      "ty": 2,
      "x": 900,
      "y": 1016
    },
    {
      "t": 135207,
      "e": 26100,
      "ty": 2,
      "x": 957,
      "y": 1066
    },
    {
      "t": 135257,
      "e": 26150,
      "ty": 41,
      "x": 26487,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 135307,
      "e": 26200,
      "ty": 2,
      "x": 960,
      "y": 1082
    },
    {
      "t": 135407,
      "e": 26300,
      "ty": 2,
      "x": 961,
      "y": 1088
    },
    {
      "t": 135478,
      "e": 26371,
      "ty": 3,
      "x": 962,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 135479,
      "e": 26372,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 135480,
      "e": 26373,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 135507,
      "e": 26400,
      "ty": 2,
      "x": 963,
      "y": 1089
    },
    {
      "t": 135507,
      "e": 26400,
      "ty": 41,
      "x": 29217,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 135557,
      "e": 26450,
      "ty": 4,
      "x": 29217,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 135558,
      "e": 26451,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 135559,
      "e": 26452,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 135559,
      "e": 26452,
      "ty": 5,
      "x": 963,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 136006,
      "e": 26899,
      "ty": 2,
      "x": 951,
      "y": 1062
    },
    {
      "t": 136006,
      "e": 26899,
      "ty": 41,
      "x": 32474,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 136206,
      "e": 27099,
      "ty": 2,
      "x": 950,
      "y": 1062
    },
    {
      "t": 136257,
      "e": 27150,
      "ty": 41,
      "x": 32440,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 136567,
      "e": 27460,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 136707,
      "e": 27600,
      "ty": 2,
      "x": 949,
      "y": 1062
    },
    {
      "t": 136757,
      "e": 27650,
      "ty": 41,
      "x": 32405,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 137107,
      "e": 28000,
      "ty": 2,
      "x": 893,
      "y": 941
    },
    {
      "t": 137207,
      "e": 28100,
      "ty": 2,
      "x": 849,
      "y": 516
    },
    {
      "t": 137257,
      "e": 28150,
      "ty": 41,
      "x": 28755,
      "y": 24596,
      "ta": "html > body"
    },
    {
      "t": 137306,
      "e": 28199,
      "ty": 2,
      "x": 843,
      "y": 451
    },
    {
      "t": 137407,
      "e": 28300,
      "ty": 2,
      "x": 848,
      "y": 462
    },
    {
      "t": 137507,
      "e": 28400,
      "ty": 2,
      "x": 865,
      "y": 498
    },
    {
      "t": 137507,
      "e": 28400,
      "ty": 41,
      "x": 20607,
      "y": 51491,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 137607,
      "e": 28500,
      "ty": 2,
      "x": 873,
      "y": 521
    },
    {
      "t": 137707,
      "e": 28600,
      "ty": 2,
      "x": 883,
      "y": 549
    },
    {
      "t": 137758,
      "e": 28651,
      "ty": 41,
      "x": 16654,
      "y": 39789,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 137807,
      "e": 28700,
      "ty": 2,
      "x": 893,
      "y": 574
    },
    {
      "t": 137868,
      "e": 28761,
      "ty": 6,
      "x": 896,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137907,
      "e": 28800,
      "ty": 2,
      "x": 898,
      "y": 596
    },
    {
      "t": 138007,
      "e": 28900,
      "ty": 2,
      "x": 898,
      "y": 597
    },
    {
      "t": 138007,
      "e": 28900,
      "ty": 41,
      "x": 19465,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138126,
      "e": 29019,
      "ty": 3,
      "x": 898,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138127,
      "e": 29020,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138237,
      "e": 29130,
      "ty": 4,
      "x": 19465,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138237,
      "e": 29130,
      "ty": 5,
      "x": 898,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140006,
      "e": 30899,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140050,
      "e": 30943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 140161,
      "e": 31054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 140163,
      "e": 31056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140265,
      "e": 31158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 140425,
      "e": 31318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 140426,
      "e": 31319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140522,
      "e": 31415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 140874,
      "e": 31767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 140875,
      "e": 31768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140953,
      "e": 31846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 141274,
      "e": 32167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 141274,
      "e": 32167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 141344,
      "e": 32237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 141728,
      "e": 32621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 141728,
      "e": 32621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 141824,
      "e": 32717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 141986,
      "e": 32879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 141986,
      "e": 32879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142082,
      "e": 32975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||B"
    },
    {
      "t": 142337,
      "e": 33230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 142339,
      "e": 33232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142408,
      "e": 33301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 142553,
      "e": 33446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 142554,
      "e": 33447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142624,
      "e": 33517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 142809,
      "e": 33702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 144407,
      "e": 35300,
      "ty": 2,
      "x": 894,
      "y": 602
    },
    {
      "t": 144442,
      "e": 35335,
      "ty": 7,
      "x": 882,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144506,
      "e": 35399,
      "ty": 2,
      "x": 874,
      "y": 638
    },
    {
      "t": 144506,
      "e": 35399,
      "ty": 41,
      "x": 14274,
      "y": 11702,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 144606,
      "e": 35499,
      "ty": 2,
      "x": 873,
      "y": 652
    },
    {
      "t": 144706,
      "e": 35599,
      "ty": 2,
      "x": 871,
      "y": 662
    },
    {
      "t": 144757,
      "e": 35650,
      "ty": 41,
      "x": 13409,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 144791,
      "e": 35684,
      "ty": 6,
      "x": 869,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144806,
      "e": 35699,
      "ty": 2,
      "x": 869,
      "y": 680
    },
    {
      "t": 144906,
      "e": 35799,
      "ty": 2,
      "x": 866,
      "y": 697
    },
    {
      "t": 144908,
      "e": 35801,
      "ty": 7,
      "x": 866,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145006,
      "e": 35899,
      "ty": 2,
      "x": 859,
      "y": 737
    },
    {
      "t": 145006,
      "e": 35899,
      "ty": 41,
      "x": 29306,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 145107,
      "e": 36000,
      "ty": 2,
      "x": 859,
      "y": 739
    },
    {
      "t": 145207,
      "e": 36100,
      "ty": 2,
      "x": 859,
      "y": 736
    },
    {
      "t": 145257,
      "e": 36150,
      "ty": 41,
      "x": 29272,
      "y": 39886,
      "ta": "html > body"
    },
    {
      "t": 145307,
      "e": 36200,
      "ty": 2,
      "x": 858,
      "y": 724
    },
    {
      "t": 145407,
      "e": 36300,
      "ty": 2,
      "x": 858,
      "y": 714
    },
    {
      "t": 145506,
      "e": 36399,
      "ty": 2,
      "x": 856,
      "y": 704
    },
    {
      "t": 145507,
      "e": 36400,
      "ty": 41,
      "x": 10381,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 145590,
      "e": 36483,
      "ty": 6,
      "x": 855,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145606,
      "e": 36499,
      "ty": 2,
      "x": 855,
      "y": 698
    },
    {
      "t": 145707,
      "e": 36600,
      "ty": 2,
      "x": 854,
      "y": 691
    },
    {
      "t": 145757,
      "e": 36650,
      "ty": 41,
      "x": 9949,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145808,
      "e": 36701,
      "ty": 2,
      "x": 854,
      "y": 690
    },
    {
      "t": 145813,
      "e": 36706,
      "ty": 3,
      "x": 854,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145814,
      "e": 36707,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 145815,
      "e": 36708,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 145815,
      "e": 36708,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145924,
      "e": 36817,
      "ty": 4,
      "x": 9949,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145924,
      "e": 36817,
      "ty": 5,
      "x": 854,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147425,
      "e": 38318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 147425,
      "e": 38318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147513,
      "e": 38406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 147578,
      "e": 38471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 147578,
      "e": 38471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147649,
      "e": 38542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 147786,
      "e": 38679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "100"
    },
    {
      "t": 147787,
      "e": 38680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147848,
      "e": 38741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 148606,
      "e": 39499,
      "ty": 2,
      "x": 861,
      "y": 696
    },
    {
      "t": 148612,
      "e": 39505,
      "ty": 7,
      "x": 869,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 148629,
      "e": 39522,
      "ty": 6,
      "x": 910,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148661,
      "e": 39554,
      "ty": 7,
      "x": 984,
      "y": 742,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148706,
      "e": 39599,
      "ty": 2,
      "x": 987,
      "y": 742
    },
    {
      "t": 148757,
      "e": 39650,
      "ty": 41,
      "x": 33714,
      "y": 40661,
      "ta": "html > body"
    },
    {
      "t": 148806,
      "e": 39699,
      "ty": 2,
      "x": 989,
      "y": 742
    },
    {
      "t": 148846,
      "e": 39739,
      "ty": 6,
      "x": 989,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148907,
      "e": 39800,
      "ty": 2,
      "x": 989,
      "y": 740
    },
    {
      "t": 149007,
      "e": 39900,
      "ty": 2,
      "x": 990,
      "y": 729
    },
    {
      "t": 149007,
      "e": 39900,
      "ty": 41,
      "x": 48486,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149086,
      "e": 39979,
      "ty": 3,
      "x": 990,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149088,
      "e": 39981,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 149088,
      "e": 39981,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149088,
      "e": 39981,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149106,
      "e": 39999,
      "ty": 2,
      "x": 990,
      "y": 728
    },
    {
      "t": 149173,
      "e": 40066,
      "ty": 4,
      "x": 48486,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149173,
      "e": 40066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149175,
      "e": 40068,
      "ty": 5,
      "x": 990,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149175,
      "e": 40068,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 149257,
      "e": 40150,
      "ty": 41,
      "x": 33817,
      "y": 39886,
      "ta": "html > body"
    },
    {
      "t": 150007,
      "e": 40900,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150273,
      "e": 41166,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 150300,
      "e": 41193,
      "ty": 6,
      "x": 990,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 151207,
      "e": 42100,
      "ty": 2,
      "x": 990,
      "y": 729
    },
    {
      "t": 151257,
      "e": 42150,
      "ty": 41,
      "x": 33335,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 151263,
      "e": 42156,
      "ty": 7,
      "x": 994,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 151263,
      "e": 42156,
      "ty": 6,
      "x": 994,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 151297,
      "e": 42190,
      "ty": 7,
      "x": 1001,
      "y": 798,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 151307,
      "e": 42200,
      "ty": 2,
      "x": 1001,
      "y": 798
    },
    {
      "t": 151407,
      "e": 42300,
      "ty": 2,
      "x": 1007,
      "y": 880
    },
    {
      "t": 151507,
      "e": 42400,
      "ty": 2,
      "x": 1004,
      "y": 905
    },
    {
      "t": 151507,
      "e": 42400,
      "ty": 41,
      "x": 34956,
      "y": 53923,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 151606,
      "e": 42499,
      "ty": 2,
      "x": 997,
      "y": 900
    },
    {
      "t": 151707,
      "e": 42600,
      "ty": 2,
      "x": 981,
      "y": 870
    },
    {
      "t": 151757,
      "e": 42650,
      "ty": 41,
      "x": 33677,
      "y": 51430,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 151806,
      "e": 42699,
      "ty": 2,
      "x": 971,
      "y": 875
    },
    {
      "t": 151907,
      "e": 42800,
      "ty": 2,
      "x": 935,
      "y": 951
    },
    {
      "t": 152006,
      "e": 42899,
      "ty": 2,
      "x": 945,
      "y": 1009
    },
    {
      "t": 152007,
      "e": 42900,
      "ty": 41,
      "x": 32054,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 152048,
      "e": 42941,
      "ty": 6,
      "x": 958,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 152080,
      "e": 42973,
      "ty": 7,
      "x": 961,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 152106,
      "e": 42999,
      "ty": 2,
      "x": 961,
      "y": 1117
    },
    {
      "t": 152206,
      "e": 43099,
      "ty": 2,
      "x": 965,
      "y": 1140
    },
    {
      "t": 152257,
      "e": 43150,
      "ty": 41,
      "x": 35810,
      "y": 38398,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 152307,
      "e": 43200,
      "ty": 2,
      "x": 969,
      "y": 1136
    },
    {
      "t": 152406,
      "e": 43299,
      "ty": 2,
      "x": 969,
      "y": 1118
    },
    {
      "t": 152506,
      "e": 43399,
      "ty": 2,
      "x": 968,
      "y": 1111
    },
    {
      "t": 152507,
      "e": 43400,
      "ty": 41,
      "x": 36746,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 152531,
      "e": 43424,
      "ty": 6,
      "x": 967,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 152607,
      "e": 43500,
      "ty": 2,
      "x": 963,
      "y": 1097
    },
    {
      "t": 152707,
      "e": 43600,
      "ty": 2,
      "x": 963,
      "y": 1095
    },
    {
      "t": 152757,
      "e": 43650,
      "ty": 41,
      "x": 29217,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 153422,
      "e": 44315,
      "ty": 3,
      "x": 963,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 153423,
      "e": 44316,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153613,
      "e": 44506,
      "ty": 4,
      "x": 29217,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 153615,
      "e": 44508,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153615,
      "e": 44508,
      "ty": 5,
      "x": 963,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 153620,
      "e": 44513,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 154618,
      "e": 45511,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 155406,
      "e": 46299,
      "ty": 2,
      "x": 961,
      "y": 1089
    },
    {
      "t": 155507,
      "e": 46400,
      "ty": 2,
      "x": 958,
      "y": 1084
    },
    {
      "t": 155508,
      "e": 46401,
      "ty": 41,
      "x": 32715,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 155607,
      "e": 46500,
      "ty": 2,
      "x": 958,
      "y": 1079
    },
    {
      "t": 155707,
      "e": 46600,
      "ty": 2,
      "x": 957,
      "y": 1071
    },
    {
      "t": 155757,
      "e": 46650,
      "ty": 41,
      "x": 32543,
      "y": 58111,
      "ta": "html > body"
    },
    {
      "t": 155807,
      "e": 46700,
      "ty": 2,
      "x": 951,
      "y": 1046
    },
    {
      "t": 155907,
      "e": 46800,
      "ty": 2,
      "x": 947,
      "y": 1033
    },
    {
      "t": 156007,
      "e": 46900,
      "ty": 2,
      "x": 943,
      "y": 1023
    },
    {
      "t": 156008,
      "e": 46901,
      "ty": 41,
      "x": 26928,
      "y": 36278,
      "ta": "> p"
    },
    {
      "t": 158467,
      "e": 49360,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 159473,
      "e": 50366,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 198, dom: 663, initialDom: 667",
  "javascriptErrors": []
}