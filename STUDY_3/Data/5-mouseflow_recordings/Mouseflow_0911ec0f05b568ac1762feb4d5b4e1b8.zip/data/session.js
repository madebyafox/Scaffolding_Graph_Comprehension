var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0911ec0f05b568ac1762feb4d5b4e1b8",
  "created": "2018-05-18T11:19:50.2807525-07:00",
  "lastActivity": "2018-05-18T11:20:03.7857123-07:00",
  "pageViews": [
    {
      "id": "05185033a2d7b77b1a744af8c3c05fa3a4d9f921",
      "startTime": "2018-05-18T11:19:50.9075197-07:00",
      "endTime": "2018-05-18T11:20:03.7857123-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 13421,
      "engagementTime": 13421,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13421,
  "engagementTime": 13421,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.51",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T2OHS",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f228eb335c00cfb75b72bc53946dfd7a",
  "gdpr": false
}