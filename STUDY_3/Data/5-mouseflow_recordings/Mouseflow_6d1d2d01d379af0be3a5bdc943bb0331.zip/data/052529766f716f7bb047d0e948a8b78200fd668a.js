var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052529766f716f7bb047d0e948a8b78200fd668a"] = {
  "startTime": "2018-05-25T18:08:29.7539247Z",
  "websitePageUrl": "/",
  "visitTime": 137937,
  "engagementTime": 73900,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "6d1d2d01d379af0be3a5bdc943bb0331",
    "created": "2018-05-25T18:08:29.7539247+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ce2080bfa9350a89e3513b9be0e8fb53",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6d1d2d01d379af0be3a5bdc943bb0331/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 309,
      "e": 309,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 447,
      "y": 131
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 1293,
      "y": 611
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 53219,
      "y": 40181,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 1334,
      "y": 637
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 8501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12261,
      "e": 8501,
      "ty": 3,
      "x": 1334,
      "y": 637,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12347,
      "e": 8587,
      "ty": 4,
      "x": 53219,
      "y": 40181,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12348,
      "e": 8588,
      "ty": 5,
      "x": 1334,
      "y": 637,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12402,
      "e": 8642,
      "ty": 2,
      "x": 1334,
      "y": 634
    },
    {
      "t": 12501,
      "e": 8741,
      "ty": 2,
      "x": 1334,
      "y": 633
    },
    {
      "t": 12502,
      "e": 8742,
      "ty": 41,
      "x": 53219,
      "y": 39853,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12701,
      "e": 8941,
      "ty": 2,
      "x": 1324,
      "y": 585
    },
    {
      "t": 12751,
      "e": 8991,
      "ty": 41,
      "x": 51745,
      "y": 36085,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12801,
      "e": 9041,
      "ty": 2,
      "x": 1286,
      "y": 595
    },
    {
      "t": 12901,
      "e": 9141,
      "ty": 2,
      "x": 1275,
      "y": 595
    },
    {
      "t": 13001,
      "e": 9241,
      "ty": 41,
      "x": 49997,
      "y": 36740,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13201,
      "e": 9441,
      "ty": 2,
      "x": 1274,
      "y": 594
    },
    {
      "t": 13251,
      "e": 9491,
      "ty": 41,
      "x": 49997,
      "y": 36494,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13301,
      "e": 9541,
      "ty": 2,
      "x": 1275,
      "y": 592
    },
    {
      "t": 13691,
      "e": 9931,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 14776,
      "e": 11016,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 20000,
      "e": 14541,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22101,
      "e": 14541,
      "ty": 2,
      "x": 1276,
      "y": 585
    },
    {
      "t": 22200,
      "e": 14640,
      "ty": 2,
      "x": 1177,
      "y": 440
    },
    {
      "t": 22251,
      "e": 14691,
      "ty": 41,
      "x": 37760,
      "y": 520,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 22301,
      "e": 14741,
      "ty": 2,
      "x": 969,
      "y": 315
    },
    {
      "t": 22400,
      "e": 14840,
      "ty": 2,
      "x": 893,
      "y": 356
    },
    {
      "t": 22501,
      "e": 14941,
      "ty": 2,
      "x": 809,
      "y": 507
    },
    {
      "t": 22502,
      "e": 14942,
      "ty": 41,
      "x": 25363,
      "y": 40829,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 23000,
      "e": 15440,
      "ty": 2,
      "x": 811,
      "y": 478
    },
    {
      "t": 23000,
      "e": 15440,
      "ty": 41,
      "x": 25461,
      "y": 33287,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 23101,
      "e": 15541,
      "ty": 2,
      "x": 812,
      "y": 463
    },
    {
      "t": 23251,
      "e": 15691,
      "ty": 41,
      "x": 25510,
      "y": 29386,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 30001,
      "e": 20691,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33101,
      "e": 20691,
      "ty": 2,
      "x": 813,
      "y": 462
    },
    {
      "t": 33251,
      "e": 20841,
      "ty": 41,
      "x": 25560,
      "y": 29126,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 40000,
      "e": 25841,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40200,
      "e": 25841,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 40200,
      "e": 25841,
      "ty": 2,
      "x": 813,
      "y": 528
    },
    {
      "t": 40250,
      "e": 25891,
      "ty": 41,
      "x": 25560,
      "y": 32511,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 41600,
      "e": 27241,
      "ty": 2,
      "x": 811,
      "y": 526
    },
    {
      "t": 41700,
      "e": 27341,
      "ty": 2,
      "x": 802,
      "y": 525
    },
    {
      "t": 41750,
      "e": 27391,
      "ty": 41,
      "x": 25018,
      "y": 31731,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 42200,
      "e": 27841,
      "ty": 2,
      "x": 802,
      "y": 526
    },
    {
      "t": 42251,
      "e": 27892,
      "ty": 41,
      "x": 25018,
      "y": 32771,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 42300,
      "e": 27941,
      "ty": 2,
      "x": 800,
      "y": 547
    },
    {
      "t": 42400,
      "e": 28041,
      "ty": 2,
      "x": 759,
      "y": 840
    },
    {
      "t": 42500,
      "e": 28141,
      "ty": 2,
      "x": 751,
      "y": 934
    },
    {
      "t": 42500,
      "e": 28141,
      "ty": 41,
      "x": 22509,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 42600,
      "e": 28241,
      "ty": 2,
      "x": 751,
      "y": 936
    },
    {
      "t": 42751,
      "e": 28392,
      "ty": 41,
      "x": 22509,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 42801,
      "e": 28442,
      "ty": 2,
      "x": 752,
      "y": 936
    },
    {
      "t": 43000,
      "e": 28641,
      "ty": 41,
      "x": 22559,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 50000,
      "e": 33641,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 58001,
      "e": 33641,
      "ty": 2,
      "x": 753,
      "y": 935
    },
    {
      "t": 58002,
      "e": 33642,
      "ty": 41,
      "x": 22608,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 58201,
      "e": 33841,
      "ty": 2,
      "x": 720,
      "y": 938
    },
    {
      "t": 58251,
      "e": 33891,
      "ty": 41,
      "x": 20640,
      "y": 56208,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 58301,
      "e": 33941,
      "ty": 2,
      "x": 713,
      "y": 938
    },
    {
      "t": 58901,
      "e": 34541,
      "ty": 2,
      "x": 713,
      "y": 940
    },
    {
      "t": 59001,
      "e": 34641,
      "ty": 41,
      "x": 20640,
      "y": 56346,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61249,
      "e": 36889,
      "ty": 41,
      "x": 20738,
      "y": 56346,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61300,
      "e": 36940,
      "ty": 2,
      "x": 781,
      "y": 940
    },
    {
      "t": 61399,
      "e": 37039,
      "ty": 2,
      "x": 1305,
      "y": 940
    },
    {
      "t": 61500,
      "e": 37140,
      "ty": 2,
      "x": 1337,
      "y": 940
    },
    {
      "t": 61500,
      "e": 37140,
      "ty": 41,
      "x": 51339,
      "y": 56346,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61599,
      "e": 37239,
      "ty": 2,
      "x": 1343,
      "y": 896
    },
    {
      "t": 61699,
      "e": 37339,
      "ty": 2,
      "x": 1202,
      "y": 825
    },
    {
      "t": 61749,
      "e": 37389,
      "ty": 41,
      "x": 41745,
      "y": 65074,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 61799,
      "e": 37439,
      "ty": 2,
      "x": 1127,
      "y": 812
    },
    {
      "t": 61899,
      "e": 37539,
      "ty": 2,
      "x": 1108,
      "y": 821
    },
    {
      "t": 61999,
      "e": 37639,
      "ty": 2,
      "x": 1102,
      "y": 824
    },
    {
      "t": 62000,
      "e": 37640,
      "ty": 41,
      "x": 39778,
      "y": 54148,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62100,
      "e": 37740,
      "ty": 2,
      "x": 1081,
      "y": 826
    },
    {
      "t": 62199,
      "e": 37839,
      "ty": 2,
      "x": 1006,
      "y": 827
    },
    {
      "t": 62250,
      "e": 37890,
      "ty": 41,
      "x": 32054,
      "y": 1188,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 62299,
      "e": 37939,
      "ty": 2,
      "x": 906,
      "y": 837
    },
    {
      "t": 62399,
      "e": 38039,
      "ty": 2,
      "x": 903,
      "y": 838
    },
    {
      "t": 62499,
      "e": 38139,
      "ty": 2,
      "x": 903,
      "y": 839
    },
    {
      "t": 62500,
      "e": 38140,
      "ty": 41,
      "x": 29987,
      "y": 9380,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 62600,
      "e": 38240,
      "ty": 2,
      "x": 882,
      "y": 889
    },
    {
      "t": 62699,
      "e": 38339,
      "ty": 2,
      "x": 875,
      "y": 910
    },
    {
      "t": 62750,
      "e": 38390,
      "ty": 41,
      "x": 15026,
      "y": 6004,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 62799,
      "e": 38439,
      "ty": 2,
      "x": 875,
      "y": 911
    },
    {
      "t": 62899,
      "e": 38539,
      "ty": 2,
      "x": 872,
      "y": 914
    },
    {
      "t": 62999,
      "e": 38639,
      "ty": 2,
      "x": 858,
      "y": 914
    },
    {
      "t": 63000,
      "e": 38640,
      "ty": 41,
      "x": 11456,
      "y": 17919,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 63099,
      "e": 38739,
      "ty": 2,
      "x": 829,
      "y": 915
    },
    {
      "t": 63194,
      "e": 38834,
      "ty": 3,
      "x": 829,
      "y": 915,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 63249,
      "e": 38889,
      "ty": 41,
      "x": 5367,
      "y": 20898,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 63288,
      "e": 38928,
      "ty": 4,
      "x": 5367,
      "y": 20898,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 63288,
      "e": 38928,
      "ty": 5,
      "x": 829,
      "y": 915,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 63288,
      "e": 38928,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 63293,
      "e": 38933,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 63600,
      "e": 39240,
      "ty": 2,
      "x": 876,
      "y": 931
    },
    {
      "t": 63699,
      "e": 39339,
      "ty": 2,
      "x": 973,
      "y": 960
    },
    {
      "t": 63749,
      "e": 39389,
      "ty": 41,
      "x": 36334,
      "y": 57731,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 63798,
      "e": 39438,
      "ty": 2,
      "x": 1071,
      "y": 948
    },
    {
      "t": 63899,
      "e": 39539,
      "ty": 2,
      "x": 1078,
      "y": 947
    },
    {
      "t": 64000,
      "e": 39640,
      "ty": 41,
      "x": 38597,
      "y": 56831,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65099,
      "e": 40739,
      "ty": 2,
      "x": 1070,
      "y": 969
    },
    {
      "t": 65199,
      "e": 40839,
      "ty": 2,
      "x": 1067,
      "y": 980
    },
    {
      "t": 65248,
      "e": 40888,
      "ty": 41,
      "x": 37908,
      "y": 59532,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65299,
      "e": 40939,
      "ty": 2,
      "x": 1062,
      "y": 993
    },
    {
      "t": 65399,
      "e": 41039,
      "ty": 2,
      "x": 1044,
      "y": 1029
    },
    {
      "t": 65478,
      "e": 41118,
      "ty": 6,
      "x": 1012,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 65499,
      "e": 41139,
      "ty": 2,
      "x": 1004,
      "y": 1090
    },
    {
      "t": 65500,
      "e": 41140,
      "ty": 41,
      "x": 51608,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 65544,
      "e": 41184,
      "ty": 7,
      "x": 991,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 65598,
      "e": 41238,
      "ty": 2,
      "x": 989,
      "y": 1108
    },
    {
      "t": 65745,
      "e": 41385,
      "ty": 6,
      "x": 988,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 65750,
      "e": 41390,
      "ty": 41,
      "x": 42870,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 65799,
      "e": 41439,
      "ty": 2,
      "x": 987,
      "y": 1102
    },
    {
      "t": 65944,
      "e": 41584,
      "ty": 3,
      "x": 987,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 65945,
      "e": 41585,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 65945,
      "e": 41585,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 65998,
      "e": 41638,
      "ty": 2,
      "x": 987,
      "y": 1101
    },
    {
      "t": 65998,
      "e": 41638,
      "ty": 41,
      "x": 42324,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 66032,
      "e": 41672,
      "ty": 4,
      "x": 42324,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 66035,
      "e": 41675,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66037,
      "e": 41677,
      "ty": 5,
      "x": 987,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 66037,
      "e": 41677,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 67043,
      "e": 42683,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 67898,
      "e": 43538,
      "ty": 2,
      "x": 956,
      "y": 897
    },
    {
      "t": 67999,
      "e": 43639,
      "ty": 2,
      "x": 898,
      "y": 513
    },
    {
      "t": 67999,
      "e": 43639,
      "ty": 41,
      "x": 24854,
      "y": 56319,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 68099,
      "e": 43739,
      "ty": 2,
      "x": 899,
      "y": 507
    },
    {
      "t": 68198,
      "e": 43838,
      "ty": 2,
      "x": 905,
      "y": 541
    },
    {
      "t": 68248,
      "e": 43888,
      "ty": 41,
      "x": 20979,
      "y": 32415,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 68298,
      "e": 43938,
      "ty": 2,
      "x": 905,
      "y": 583
    },
    {
      "t": 68312,
      "e": 43952,
      "ty": 6,
      "x": 905,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68399,
      "e": 44039,
      "ty": 2,
      "x": 905,
      "y": 594
    },
    {
      "t": 68499,
      "e": 44139,
      "ty": 41,
      "x": 20979,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68824,
      "e": 44464,
      "ty": 3,
      "x": 905,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68825,
      "e": 44465,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68959,
      "e": 44599,
      "ty": 4,
      "x": 20979,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68960,
      "e": 44600,
      "ty": 5,
      "x": 905,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69998,
      "e": 45638,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73955,
      "e": 49595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 74083,
      "e": 49723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 74084,
      "e": 49724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74195,
      "e": 49835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 74203,
      "e": 49843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 74203,
      "e": 49843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74211,
      "e": 49851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 74315,
      "e": 49955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 74411,
      "e": 50051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 74411,
      "e": 50051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74547,
      "e": 50187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 74547,
      "e": 50187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74580,
      "e": 50220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nove"
    },
    {
      "t": 74628,
      "e": 50268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 74629,
      "e": 50269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74651,
      "e": 50291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 74731,
      "e": 50371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 74835,
      "e": 50475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 74837,
      "e": 50477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74971,
      "e": 50611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 74971,
      "e": 50611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75003,
      "e": 50643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||be"
    },
    {
      "t": 75067,
      "e": 50707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 75068,
      "e": 50708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75115,
      "e": 50755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 75188,
      "e": 50828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 75299,
      "e": 50939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 75299,
      "e": 50939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 75300,
      "e": 50940,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75300,
      "e": 50940,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75387,
      "e": 51027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 76612,
      "e": 52252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 76612,
      "e": 52252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76667,
      "e": 52307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 76779,
      "e": 52419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 76779,
      "e": 52419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76891,
      "e": 52531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 76892,
      "e": 52532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76962,
      "e": 52602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 77042,
      "e": 52682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 78288,
      "e": 53928,
      "ty": 7,
      "x": 921,
      "y": 615,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78299,
      "e": 53939,
      "ty": 2,
      "x": 921,
      "y": 615
    },
    {
      "t": 78322,
      "e": 53962,
      "ty": 6,
      "x": 981,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78338,
      "e": 53978,
      "ty": 7,
      "x": 1002,
      "y": 707,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78356,
      "e": 53996,
      "ty": 6,
      "x": 1017,
      "y": 730,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78371,
      "e": 54011,
      "ty": 7,
      "x": 1027,
      "y": 749,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78399,
      "e": 54039,
      "ty": 2,
      "x": 1030,
      "y": 761
    },
    {
      "t": 78498,
      "e": 54138,
      "ty": 2,
      "x": 1035,
      "y": 789
    },
    {
      "t": 78499,
      "e": 54139,
      "ty": 41,
      "x": 35367,
      "y": 43265,
      "ta": "html > body"
    },
    {
      "t": 78588,
      "e": 54228,
      "ty": 6,
      "x": 987,
      "y": 739,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78598,
      "e": 54238,
      "ty": 2,
      "x": 987,
      "y": 739
    },
    {
      "t": 78638,
      "e": 54278,
      "ty": 7,
      "x": 941,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78699,
      "e": 54339,
      "ty": 2,
      "x": 937,
      "y": 702
    },
    {
      "t": 78749,
      "e": 54389,
      "ty": 41,
      "x": 27901,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78839,
      "e": 54479,
      "ty": 6,
      "x": 937,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78898,
      "e": 54538,
      "ty": 2,
      "x": 937,
      "y": 721
    },
    {
      "t": 78998,
      "e": 54638,
      "ty": 2,
      "x": 937,
      "y": 724
    },
    {
      "t": 78999,
      "e": 54639,
      "ty": 41,
      "x": 21171,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 79999,
      "e": 55639,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 87073,
      "e": 59639,
      "ty": 3,
      "x": 937,
      "y": 724,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87074,
      "e": 59640,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 87074,
      "e": 59640,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87075,
      "e": 59641,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87159,
      "e": 59725,
      "ty": 4,
      "x": 21171,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87160,
      "e": 59726,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87160,
      "e": 59726,
      "ty": 5,
      "x": 937,
      "y": 724,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87161,
      "e": 59727,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 88495,
      "e": 61061,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 88528,
      "e": 61094,
      "ty": 6,
      "x": 937,
      "y": 724,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 99998,
      "e": 66094,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120941,
      "e": 66094,
      "ty": 7,
      "x": 933,
      "y": 743,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 120942,
      "e": 66095,
      "ty": 6,
      "x": 933,
      "y": 743,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 120955,
      "e": 66108,
      "ty": 7,
      "x": 930,
      "y": 767,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 120955,
      "e": 66108,
      "ty": 6,
      "x": 930,
      "y": 767,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 120972,
      "e": 66125,
      "ty": 7,
      "x": 929,
      "y": 815,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 120996,
      "e": 66149,
      "ty": 2,
      "x": 924,
      "y": 854
    },
    {
      "t": 120996,
      "e": 66149,
      "ty": 41,
      "x": 31021,
      "y": 50391,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121096,
      "e": 66249,
      "ty": 2,
      "x": 895,
      "y": 1007
    },
    {
      "t": 121196,
      "e": 66349,
      "ty": 2,
      "x": 889,
      "y": 1122
    },
    {
      "t": 121247,
      "e": 66400,
      "ty": 41,
      "x": 1170,
      "y": 28980,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 121296,
      "e": 66449,
      "ty": 2,
      "x": 897,
      "y": 1125
    },
    {
      "t": 121396,
      "e": 66549,
      "ty": 2,
      "x": 953,
      "y": 1116
    },
    {
      "t": 121496,
      "e": 66649,
      "ty": 2,
      "x": 969,
      "y": 1123
    },
    {
      "t": 121497,
      "e": 66650,
      "ty": 41,
      "x": 37214,
      "y": 27872,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 121597,
      "e": 66750,
      "ty": 2,
      "x": 989,
      "y": 1126
    },
    {
      "t": 121696,
      "e": 66849,
      "ty": 2,
      "x": 998,
      "y": 1107
    },
    {
      "t": 121747,
      "e": 66900,
      "ty": 41,
      "x": 50789,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 121758,
      "e": 66911,
      "ty": 6,
      "x": 998,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 121797,
      "e": 66950,
      "ty": 2,
      "x": 998,
      "y": 1105
    },
    {
      "t": 121896,
      "e": 67049,
      "ty": 2,
      "x": 989,
      "y": 1098
    },
    {
      "t": 121996,
      "e": 67149,
      "ty": 2,
      "x": 982,
      "y": 1092
    },
    {
      "t": 121996,
      "e": 67149,
      "ty": 41,
      "x": 39594,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 122630,
      "e": 67783,
      "ty": 3,
      "x": 982,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 122631,
      "e": 67784,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122748,
      "e": 67901,
      "ty": 4,
      "x": 39594,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 122748,
      "e": 67901,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122749,
      "e": 67902,
      "ty": 5,
      "x": 982,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 122750,
      "e": 67903,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 122896,
      "e": 68049,
      "ty": 2,
      "x": 972,
      "y": 1086
    },
    {
      "t": 122996,
      "e": 68149,
      "ty": 2,
      "x": 952,
      "y": 1071
    },
    {
      "t": 122997,
      "e": 68150,
      "ty": 41,
      "x": 32509,
      "y": 58887,
      "ta": "html > body"
    },
    {
      "t": 123296,
      "e": 68449,
      "ty": 2,
      "x": 952,
      "y": 1070
    },
    {
      "t": 123397,
      "e": 68550,
      "ty": 2,
      "x": 953,
      "y": 1070
    },
    {
      "t": 123497,
      "e": 68650,
      "ty": 41,
      "x": 32543,
      "y": 58831,
      "ta": "html > body"
    },
    {
      "t": 123596,
      "e": 68749,
      "ty": 2,
      "x": 969,
      "y": 1063
    },
    {
      "t": 123696,
      "e": 68849,
      "ty": 2,
      "x": 979,
      "y": 1055
    },
    {
      "t": 123747,
      "e": 68900,
      "ty": 41,
      "x": 33439,
      "y": 58000,
      "ta": "html > body"
    },
    {
      "t": 123752,
      "e": 68905,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 129997,
      "e": 73900,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 136930,
      "e": 73900,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 137937,
      "e": 73900,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 103, dom: 521, initialDom: 525",
  "javascriptErrors": []
}