var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fced643efeebb7804eec5ae5a269fb3d",
  "created": "2018-05-22T15:15:37.0190812-07:00",
  "lastActivity": "2018-05-22T15:16:27.3556787-07:00",
  "pageViews": [
    {
      "id": "052237687d5084edb8d8dc2d81c90e552fb64620",
      "startTime": "2018-05-22T15:15:37.355181-07:00",
      "endTime": "2018-05-22T15:16:27.3556787-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 50271,
      "engagementTime": 38124,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 50271,
  "engagementTime": 38124,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Q3JLW",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "180b4cdcdff91d42119398cde0e079b6",
  "gdpr": false
}