var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a2decd4f7d6256df5de62c8364b07bc2",
  "created": "2018-05-18T11:10:51.8987323-07:00",
  "lastActivity": "2018-05-18T11:11:09.4723923-07:00",
  "pageViews": [
    {
      "id": "0518522773a6d418ca9f5d1a09c9b439d4263049",
      "startTime": "2018-05-18T11:10:52.4596063-07:00",
      "endTime": "2018-05-18T11:11:09.4723923-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 17067,
      "engagementTime": 16966,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17067,
  "engagementTime": 16966,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4KEEF",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bd8438098a7b11556bc2cbf2154ed401",
  "gdpr": false
}