var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525591002447983a6d73352f4fc7b86d71f975f"] = {
  "startTime": "2018-05-25T17:06:00.1789511Z",
  "websitePageUrl": "/",
  "visitTime": 143863,
  "engagementTime": 55909,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1582,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "12580fc5690e126df0705d273e856fe3",
    "created": "2018-05-25T17:06:00.0144645+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6275561e72d15ea34c10605d5a12199c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/12580fc5690e126df0705d273e856fe3/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1582,
      "y": 1047
    },
    {
      "t": 308,
      "e": 308,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 10007,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 26101,
      "e": 5102,
      "ty": 2,
      "x": 666,
      "y": 19
    },
    {
      "t": 26201,
      "e": 5202,
      "ty": 2,
      "x": 650,
      "y": 208
    },
    {
      "t": 26251,
      "e": 5252,
      "ty": 41,
      "x": 24766,
      "y": 14991,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26301,
      "e": 5302,
      "ty": 2,
      "x": 644,
      "y": 321
    },
    {
      "t": 26401,
      "e": 5402,
      "ty": 2,
      "x": 638,
      "y": 326
    },
    {
      "t": 26509,
      "e": 5510,
      "ty": 2,
      "x": 634,
      "y": 328
    },
    {
      "t": 26510,
      "e": 5511,
      "ty": 41,
      "x": 24220,
      "y": 16793,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 27902,
      "e": 6903,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 28001,
      "e": 7002,
      "ty": 2,
      "x": 652,
      "y": 423
    },
    {
      "t": 28001,
      "e": 7002,
      "ty": 41,
      "x": 15974,
      "y": 18308,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40002,
      "e": 12002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 99905,
      "e": 12002,
      "ty": 2,
      "x": 640,
      "y": 411
    },
    {
      "t": 100005,
      "e": 12102,
      "ty": 2,
      "x": 655,
      "y": 380
    },
    {
      "t": 100005,
      "e": 12102,
      "ty": 41,
      "x": 17787,
      "y": 61646,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 100104,
      "e": 12201,
      "ty": 2,
      "x": 729,
      "y": 323
    },
    {
      "t": 100205,
      "e": 12302,
      "ty": 2,
      "x": 768,
      "y": 307
    },
    {
      "t": 100256,
      "e": 12353,
      "ty": 41,
      "x": 26150,
      "y": 11959,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100305,
      "e": 12402,
      "ty": 2,
      "x": 1017,
      "y": 295
    },
    {
      "t": 100405,
      "e": 12502,
      "ty": 2,
      "x": 1248,
      "y": 307
    },
    {
      "t": 100506,
      "e": 12603,
      "ty": 2,
      "x": 1292,
      "y": 311
    },
    {
      "t": 100506,
      "e": 12603,
      "ty": 41,
      "x": 49125,
      "y": 7813,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 100705,
      "e": 12802,
      "ty": 2,
      "x": 1277,
      "y": 319
    },
    {
      "t": 100755,
      "e": 12852,
      "ty": 41,
      "x": 48092,
      "y": 20296,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 100805,
      "e": 12902,
      "ty": 2,
      "x": 1224,
      "y": 345
    },
    {
      "t": 100904,
      "e": 13001,
      "ty": 2,
      "x": 1195,
      "y": 352
    },
    {
      "t": 101005,
      "e": 13102,
      "ty": 2,
      "x": 1129,
      "y": 367
    },
    {
      "t": 101005,
      "e": 13102,
      "ty": 41,
      "x": 41106,
      "y": 51503,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 101105,
      "e": 13202,
      "ty": 2,
      "x": 1046,
      "y": 375
    },
    {
      "t": 101204,
      "e": 13301,
      "ty": 2,
      "x": 927,
      "y": 392
    },
    {
      "t": 101254,
      "e": 13351,
      "ty": 41,
      "x": 28315,
      "y": 9837,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 101304,
      "e": 13401,
      "ty": 2,
      "x": 819,
      "y": 399
    },
    {
      "t": 101404,
      "e": 13501,
      "ty": 2,
      "x": 634,
      "y": 422
    },
    {
      "t": 101505,
      "e": 13602,
      "ty": 2,
      "x": 507,
      "y": 428
    },
    {
      "t": 101505,
      "e": 13602,
      "ty": 41,
      "x": 10505,
      "y": 6505,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 101604,
      "e": 13701,
      "ty": 2,
      "x": 482,
      "y": 429
    },
    {
      "t": 101705,
      "e": 13802,
      "ty": 2,
      "x": 463,
      "y": 435
    },
    {
      "t": 101755,
      "e": 13852,
      "ty": 41,
      "x": 8341,
      "y": 8325,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 102304,
      "e": 14401,
      "ty": 2,
      "x": 465,
      "y": 435
    },
    {
      "t": 102404,
      "e": 14501,
      "ty": 2,
      "x": 466,
      "y": 435
    },
    {
      "t": 102504,
      "e": 14601,
      "ty": 41,
      "x": 8488,
      "y": 8325,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 102755,
      "e": 14852,
      "ty": 41,
      "x": 8488,
      "y": 8586,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 102804,
      "e": 14901,
      "ty": 2,
      "x": 464,
      "y": 445
    },
    {
      "t": 102904,
      "e": 15001,
      "ty": 2,
      "x": 489,
      "y": 497
    },
    {
      "t": 103004,
      "e": 15101,
      "ty": 2,
      "x": 584,
      "y": 631
    },
    {
      "t": 103004,
      "e": 15101,
      "ty": 41,
      "x": 14294,
      "y": 59297,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 103105,
      "e": 15202,
      "ty": 2,
      "x": 658,
      "y": 707
    },
    {
      "t": 103204,
      "e": 15301,
      "ty": 2,
      "x": 671,
      "y": 709
    },
    {
      "t": 103255,
      "e": 15352,
      "ty": 41,
      "x": 19115,
      "y": 16859,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103305,
      "e": 15402,
      "ty": 2,
      "x": 713,
      "y": 710
    },
    {
      "t": 103404,
      "e": 15501,
      "ty": 2,
      "x": 797,
      "y": 724
    },
    {
      "t": 103505,
      "e": 15602,
      "ty": 2,
      "x": 798,
      "y": 725
    },
    {
      "t": 103505,
      "e": 15602,
      "ty": 41,
      "x": 24822,
      "y": 24348,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103604,
      "e": 15701,
      "ty": 2,
      "x": 818,
      "y": 727
    },
    {
      "t": 103704,
      "e": 15801,
      "ty": 2,
      "x": 853,
      "y": 742
    },
    {
      "t": 103755,
      "e": 15852,
      "ty": 41,
      "x": 27577,
      "y": 32306,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103804,
      "e": 15901,
      "ty": 2,
      "x": 854,
      "y": 742
    },
    {
      "t": 104204,
      "e": 16301,
      "ty": 2,
      "x": 850,
      "y": 748
    },
    {
      "t": 104255,
      "e": 16352,
      "ty": 41,
      "x": 26544,
      "y": 41200,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 104304,
      "e": 16401,
      "ty": 2,
      "x": 824,
      "y": 768
    },
    {
      "t": 104404,
      "e": 16501,
      "ty": 2,
      "x": 818,
      "y": 781
    },
    {
      "t": 104504,
      "e": 16601,
      "ty": 2,
      "x": 777,
      "y": 997
    },
    {
      "t": 104505,
      "e": 16602,
      "ty": 41,
      "x": 23789,
      "y": 60293,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 104604,
      "e": 16701,
      "ty": 2,
      "x": 819,
      "y": 1199
    },
    {
      "t": 104704,
      "e": 16801,
      "ty": 2,
      "x": 827,
      "y": 1199
    },
    {
      "t": 104754,
      "e": 16851,
      "ty": 41,
      "x": 28548,
      "y": 63983,
      "ta": "> div.masterdiv"
    },
    {
      "t": 104805,
      "e": 16902,
      "ty": 2,
      "x": 842,
      "y": 1039
    },
    {
      "t": 104904,
      "e": 17001,
      "ty": 2,
      "x": 841,
      "y": 942
    },
    {
      "t": 105004,
      "e": 17101,
      "ty": 2,
      "x": 827,
      "y": 947
    },
    {
      "t": 105004,
      "e": 17101,
      "ty": 41,
      "x": 26248,
      "y": 56831,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105305,
      "e": 17402,
      "ty": 2,
      "x": 814,
      "y": 936
    },
    {
      "t": 105404,
      "e": 17501,
      "ty": 2,
      "x": 797,
      "y": 924
    },
    {
      "t": 105410,
      "e": 17507,
      "ty": 3,
      "x": 797,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 105505,
      "e": 17602,
      "ty": 41,
      "x": 24772,
      "y": 42972,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 105530,
      "e": 17627,
      "ty": 4,
      "x": 24772,
      "y": 42972,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 105530,
      "e": 17627,
      "ty": 5,
      "x": 797,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 105705,
      "e": 17802,
      "ty": 2,
      "x": 799,
      "y": 923
    },
    {
      "t": 105757,
      "e": 17854,
      "ty": 41,
      "x": 1843,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 105804,
      "e": 17901,
      "ty": 2,
      "x": 816,
      "y": 918
    },
    {
      "t": 105898,
      "e": 17995,
      "ty": 3,
      "x": 817,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 105904,
      "e": 18001,
      "ty": 2,
      "x": 817,
      "y": 917
    },
    {
      "t": 105993,
      "e": 18090,
      "ty": 4,
      "x": 44440,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 105994,
      "e": 18091,
      "ty": 5,
      "x": 817,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 105996,
      "e": 18093,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 106001,
      "e": 18098,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 106004,
      "e": 18101,
      "ty": 41,
      "x": 44440,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 106205,
      "e": 18302,
      "ty": 2,
      "x": 841,
      "y": 1011
    },
    {
      "t": 106255,
      "e": 18352,
      "ty": 41,
      "x": 30098,
      "y": 60604,
      "ta": "> div.masterdiv"
    },
    {
      "t": 106304,
      "e": 18401,
      "ty": 2,
      "x": 908,
      "y": 1119
    },
    {
      "t": 106405,
      "e": 18502,
      "ty": 2,
      "x": 929,
      "y": 1115
    },
    {
      "t": 106504,
      "e": 18601,
      "ty": 2,
      "x": 942,
      "y": 1099
    },
    {
      "t": 106504,
      "e": 18601,
      "ty": 41,
      "x": 17749,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 106602,
      "e": 18699,
      "ty": 3,
      "x": 954,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 106604,
      "e": 18701,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 106604,
      "e": 18701,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106607,
      "e": 18704,
      "ty": 2,
      "x": 954,
      "y": 1082
    },
    {
      "t": 106680,
      "e": 18777,
      "ty": 4,
      "x": 27579,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 106682,
      "e": 18779,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106683,
      "e": 18780,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 106683,
      "e": 18780,
      "ty": 5,
      "x": 960,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 106704,
      "e": 18801,
      "ty": 2,
      "x": 960,
      "y": 1083
    },
    {
      "t": 106754,
      "e": 18851,
      "ty": 41,
      "x": 32784,
      "y": 59552,
      "ta": "html > body"
    },
    {
      "t": 107005,
      "e": 19102,
      "ty": 2,
      "x": 960,
      "y": 1081
    },
    {
      "t": 107005,
      "e": 19102,
      "ty": 41,
      "x": 32784,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 107105,
      "e": 19202,
      "ty": 2,
      "x": 963,
      "y": 997
    },
    {
      "t": 107204,
      "e": 19301,
      "ty": 2,
      "x": 942,
      "y": 848
    },
    {
      "t": 107254,
      "e": 19351,
      "ty": 41,
      "x": 31648,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 107305,
      "e": 19402,
      "ty": 2,
      "x": 903,
      "y": 689
    },
    {
      "t": 107404,
      "e": 19501,
      "ty": 2,
      "x": 883,
      "y": 627
    },
    {
      "t": 107505,
      "e": 19602,
      "ty": 2,
      "x": 880,
      "y": 618
    },
    {
      "t": 107505,
      "e": 19602,
      "ty": 41,
      "x": 30029,
      "y": 33792,
      "ta": "html > body"
    },
    {
      "t": 107691,
      "e": 19788,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 108304,
      "e": 20401,
      "ty": 2,
      "x": 880,
      "y": 611
    },
    {
      "t": 108306,
      "e": 20403,
      "ty": 6,
      "x": 880,
      "y": 601,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108405,
      "e": 20502,
      "ty": 2,
      "x": 879,
      "y": 589
    },
    {
      "t": 108505,
      "e": 20602,
      "ty": 41,
      "x": 15356,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108602,
      "e": 20699,
      "ty": 3,
      "x": 879,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108603,
      "e": 20700,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108704,
      "e": 20801,
      "ty": 4,
      "x": 15356,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108705,
      "e": 20801,
      "ty": 5,
      "x": 879,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108754,
      "e": 20850,
      "ty": 41,
      "x": 17519,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108804,
      "e": 20900,
      "ty": 2,
      "x": 890,
      "y": 586
    },
    {
      "t": 109005,
      "e": 21101,
      "ty": 41,
      "x": 17735,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110526,
      "e": 22622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 110527,
      "e": 22623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110622,
      "e": 22718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "m"
    },
    {
      "t": 110933,
      "e": 23029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 111021,
      "e": 23117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 111142,
      "e": 23238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 111333,
      "e": 23429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 111334,
      "e": 23430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111389,
      "e": 23485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 111405,
      "e": 23501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 111669,
      "e": 23765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 111757,
      "e": 23853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 111758,
      "e": 23854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111861,
      "e": 23957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 111917,
      "e": 24013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 112038,
      "e": 24134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 112149,
      "e": 24245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 112149,
      "e": 24245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112237,
      "e": 24333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MiK"
    },
    {
      "t": 112301,
      "e": 24397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MiK"
    },
    {
      "t": 112486,
      "e": 24582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 112589,
      "e": 24685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 112693,
      "e": 24789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 112773,
      "e": 24869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 112949,
      "e": 25045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 113069,
      "e": 25165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 113070,
      "e": 25166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113210,
      "e": 25306,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 113213,
      "e": 25309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 113229,
      "e": 25325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 113607,
      "e": 25703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 113701,
      "e": 25797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 114542,
      "e": 26638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 114621,
      "e": 26717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 115573,
      "e": 27669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 115774,
      "e": 27870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 115774,
      "e": 27870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 115869,
      "e": 27965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 115900,
      "e": 27996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Mi"
    },
    {
      "t": 116437,
      "e": 28533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 116533,
      "e": 28629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 117518,
      "e": 29614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 117518,
      "e": 29614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 117589,
      "e": 29685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MI"
    },
    {
      "t": 117990,
      "e": 30086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 117991,
      "e": 30087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118060,
      "e": 30156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MIK"
    },
    {
      "t": 118269,
      "e": 30365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 118269,
      "e": 30365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118404,
      "e": 30500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MIKE"
    },
    {
      "t": 118622,
      "e": 30718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 118765,
      "e": 30861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 119133,
      "e": 31229,
      "ty": 7,
      "x": 891,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 119205,
      "e": 31301,
      "ty": 2,
      "x": 842,
      "y": 671
    },
    {
      "t": 119255,
      "e": 31351,
      "ty": 41,
      "x": 7353,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 119283,
      "e": 31379,
      "ty": 6,
      "x": 826,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119304,
      "e": 31400,
      "ty": 2,
      "x": 817,
      "y": 698
    },
    {
      "t": 119315,
      "e": 31411,
      "ty": 7,
      "x": 814,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119405,
      "e": 31501,
      "ty": 2,
      "x": 822,
      "y": 728
    },
    {
      "t": 119509,
      "e": 31605,
      "ty": 2,
      "x": 871,
      "y": 711
    },
    {
      "t": 119509,
      "e": 31605,
      "ty": 41,
      "x": 29719,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 119608,
      "e": 31704,
      "ty": 2,
      "x": 871,
      "y": 710
    },
    {
      "t": 119708,
      "e": 31804,
      "ty": 2,
      "x": 884,
      "y": 705
    },
    {
      "t": 119759,
      "e": 31855,
      "ty": 41,
      "x": 17519,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 119809,
      "e": 31905,
      "ty": 2,
      "x": 889,
      "y": 704
    },
    {
      "t": 119909,
      "e": 32005,
      "ty": 2,
      "x": 894,
      "y": 701
    },
    {
      "t": 119982,
      "e": 32078,
      "ty": 6,
      "x": 894,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120009,
      "e": 32105,
      "ty": 2,
      "x": 894,
      "y": 692
    },
    {
      "t": 120009,
      "e": 32105,
      "ty": 41,
      "x": 18600,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120009,
      "e": 32105,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120109,
      "e": 32205,
      "ty": 2,
      "x": 894,
      "y": 688
    },
    {
      "t": 120259,
      "e": 32355,
      "ty": 41,
      "x": 18600,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120261,
      "e": 32357,
      "ty": 3,
      "x": 894,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120262,
      "e": 32358,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MIKE"
    },
    {
      "t": 120262,
      "e": 32358,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120263,
      "e": 32359,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120348,
      "e": 32444,
      "ty": 4,
      "x": 18600,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 120348,
      "e": 32444,
      "ty": 5,
      "x": 894,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 121177,
      "e": 33273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 121177,
      "e": 33273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 121296,
      "e": 33392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 121424,
      "e": 33520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 121425,
      "e": 33521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 121544,
      "e": 33640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 121681,
      "e": 33777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 121681,
      "e": 33777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 121745,
      "e": 33841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 123556,
      "e": 35652,
      "ty": 7,
      "x": 976,
      "y": 710,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123556,
      "e": 35652,
      "ty": 6,
      "x": 976,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 123572,
      "e": 35668,
      "ty": 7,
      "x": 1024,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 123609,
      "e": 35705,
      "ty": 2,
      "x": 1072,
      "y": 739
    },
    {
      "t": 123709,
      "e": 35805,
      "ty": 2,
      "x": 1072,
      "y": 741
    },
    {
      "t": 123759,
      "e": 35855,
      "ty": 41,
      "x": 35023,
      "y": 40606,
      "ta": "html > body"
    },
    {
      "t": 123808,
      "e": 35904,
      "ty": 2,
      "x": 925,
      "y": 741
    },
    {
      "t": 123822,
      "e": 35918,
      "ty": 6,
      "x": 899,
      "y": 738,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 123839,
      "e": 35935,
      "ty": 7,
      "x": 893,
      "y": 733,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 123908,
      "e": 36004,
      "ty": 2,
      "x": 893,
      "y": 732
    },
    {
      "t": 124006,
      "e": 36102,
      "ty": 6,
      "x": 897,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124008,
      "e": 36104,
      "ty": 2,
      "x": 897,
      "y": 728
    },
    {
      "t": 124008,
      "e": 36104,
      "ty": 41,
      "x": 555,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124108,
      "e": 36204,
      "ty": 2,
      "x": 920,
      "y": 725
    },
    {
      "t": 124206,
      "e": 36302,
      "ty": 3,
      "x": 939,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124207,
      "e": 36303,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 124208,
      "e": 36304,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124208,
      "e": 36304,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124210,
      "e": 36306,
      "ty": 2,
      "x": 939,
      "y": 721
    },
    {
      "t": 124258,
      "e": 36354,
      "ty": 41,
      "x": 22202,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124276,
      "e": 36372,
      "ty": 4,
      "x": 22202,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124277,
      "e": 36373,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124278,
      "e": 36374,
      "ty": 5,
      "x": 939,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124278,
      "e": 36374,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 124609,
      "e": 36705,
      "ty": 2,
      "x": 943,
      "y": 714
    },
    {
      "t": 124708,
      "e": 36804,
      "ty": 2,
      "x": 931,
      "y": 619
    },
    {
      "t": 124759,
      "e": 36855,
      "ty": 41,
      "x": 30408,
      "y": 29859,
      "ta": "html > body"
    },
    {
      "t": 124809,
      "e": 36905,
      "ty": 2,
      "x": 871,
      "y": 520
    },
    {
      "t": 124909,
      "e": 37005,
      "ty": 2,
      "x": 869,
      "y": 520
    },
    {
      "t": 125009,
      "e": 37105,
      "ty": 2,
      "x": 860,
      "y": 506
    },
    {
      "t": 125009,
      "e": 37105,
      "ty": 41,
      "x": 29340,
      "y": 27587,
      "ta": "html > body"
    },
    {
      "t": 125108,
      "e": 37204,
      "ty": 2,
      "x": 860,
      "y": 504
    },
    {
      "t": 125259,
      "e": 37355,
      "ty": 41,
      "x": 29340,
      "y": 27477,
      "ta": "html > body"
    },
    {
      "t": 125371,
      "e": 37467,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 126008,
      "e": 38104,
      "ty": 2,
      "x": 809,
      "y": 467
    },
    {
      "t": 126008,
      "e": 38104,
      "ty": 41,
      "x": 25363,
      "y": 9453,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 126108,
      "e": 38204,
      "ty": 2,
      "x": 711,
      "y": 337
    },
    {
      "t": 126209,
      "e": 38305,
      "ty": 2,
      "x": 711,
      "y": 335
    },
    {
      "t": 126260,
      "e": 38356,
      "ty": 41,
      "x": 20246,
      "y": 16044,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126309,
      "e": 38405,
      "ty": 2,
      "x": 733,
      "y": 407
    },
    {
      "t": 126409,
      "e": 38505,
      "ty": 2,
      "x": 890,
      "y": 326
    },
    {
      "t": 126508,
      "e": 38604,
      "ty": 2,
      "x": 1020,
      "y": 233
    },
    {
      "t": 126509,
      "e": 38605,
      "ty": 41,
      "x": 35743,
      "y": 7388,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126609,
      "e": 38705,
      "ty": 2,
      "x": 1031,
      "y": 343
    },
    {
      "t": 126709,
      "e": 38805,
      "ty": 2,
      "x": 1071,
      "y": 412
    },
    {
      "t": 126758,
      "e": 38854,
      "ty": 41,
      "x": 39187,
      "y": 16114,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126808,
      "e": 38904,
      "ty": 2,
      "x": 1089,
      "y": 353
    },
    {
      "t": 126908,
      "e": 39004,
      "ty": 2,
      "x": 1074,
      "y": 370
    },
    {
      "t": 127009,
      "e": 39105,
      "ty": 2,
      "x": 1103,
      "y": 399
    },
    {
      "t": 127010,
      "e": 39106,
      "ty": 41,
      "x": 39827,
      "y": 18883,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127109,
      "e": 39205,
      "ty": 2,
      "x": 1108,
      "y": 399
    },
    {
      "t": 127259,
      "e": 39355,
      "ty": 41,
      "x": 40073,
      "y": 18883,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129408,
      "e": 41504,
      "ty": 2,
      "x": 1125,
      "y": 424
    },
    {
      "t": 129508,
      "e": 41604,
      "ty": 2,
      "x": 1135,
      "y": 430
    },
    {
      "t": 129508,
      "e": 41604,
      "ty": 41,
      "x": 41401,
      "y": 28104,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 129608,
      "e": 41704,
      "ty": 2,
      "x": 1133,
      "y": 433
    },
    {
      "t": 129708,
      "e": 41804,
      "ty": 2,
      "x": 1044,
      "y": 467
    },
    {
      "t": 129759,
      "e": 41855,
      "ty": 41,
      "x": 54690,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 129808,
      "e": 41904,
      "ty": 2,
      "x": 575,
      "y": 509
    },
    {
      "t": 129811,
      "e": 41907,
      "ty": 6,
      "x": 531,
      "y": 513,
      "ta": "#da1"
    },
    {
      "t": 129861,
      "e": 41957,
      "ty": 7,
      "x": 473,
      "y": 536,
      "ta": "#da1"
    },
    {
      "t": 129908,
      "e": 42004,
      "ty": 2,
      "x": 442,
      "y": 596
    },
    {
      "t": 129945,
      "e": 42041,
      "ty": 6,
      "x": 406,
      "y": 676,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130008,
      "e": 42104,
      "ty": 2,
      "x": 397,
      "y": 694
    },
    {
      "t": 130009,
      "e": 42105,
      "ty": 41,
      "x": 3292,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130009,
      "e": 42105,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130078,
      "e": 42174,
      "ty": 7,
      "x": 404,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130079,
      "e": 42175,
      "ty": 6,
      "x": 404,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130108,
      "e": 42204,
      "ty": 2,
      "x": 415,
      "y": 715
    },
    {
      "t": 130127,
      "e": 42223,
      "ty": 7,
      "x": 446,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130127,
      "e": 42223,
      "ty": 6,
      "x": 446,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130208,
      "e": 42304,
      "ty": 2,
      "x": 498,
      "y": 748
    },
    {
      "t": 130258,
      "e": 42354,
      "ty": 41,
      "x": 10030,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130308,
      "e": 42404,
      "ty": 2,
      "x": 531,
      "y": 753
    },
    {
      "t": 130408,
      "e": 42504,
      "ty": 2,
      "x": 529,
      "y": 754
    },
    {
      "t": 130508,
      "e": 42604,
      "ty": 2,
      "x": 493,
      "y": 735
    },
    {
      "t": 130509,
      "e": 42605,
      "ty": 41,
      "x": 8156,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130578,
      "e": 42674,
      "ty": 7,
      "x": 485,
      "y": 723,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130579,
      "e": 42675,
      "ty": 6,
      "x": 485,
      "y": 723,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130608,
      "e": 42704,
      "ty": 2,
      "x": 484,
      "y": 720
    },
    {
      "t": 130708,
      "e": 42804,
      "ty": 2,
      "x": 482,
      "y": 700
    },
    {
      "t": 130712,
      "e": 42808,
      "ty": 7,
      "x": 492,
      "y": 694,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130713,
      "e": 42809,
      "ty": 6,
      "x": 492,
      "y": 694,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130759,
      "e": 42855,
      "ty": 41,
      "x": 2857,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > ul > li > i:[2]"
    },
    {
      "t": 130762,
      "e": 42858,
      "ty": 7,
      "x": 558,
      "y": 670,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130808,
      "e": 42904,
      "ty": 2,
      "x": 641,
      "y": 662
    },
    {
      "t": 130846,
      "e": 42942,
      "ty": 6,
      "x": 828,
      "y": 679,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130879,
      "e": 42975,
      "ty": 7,
      "x": 877,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 130880,
      "e": 42976,
      "ty": 6,
      "x": 877,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130895,
      "e": 42991,
      "ty": 7,
      "x": 898,
      "y": 733,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 130896,
      "e": 42992,
      "ty": 6,
      "x": 898,
      "y": 733,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130908,
      "e": 43004,
      "ty": 2,
      "x": 898,
      "y": 733
    },
    {
      "t": 130929,
      "e": 43025,
      "ty": 7,
      "x": 921,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 130932,
      "e": 43028,
      "ty": 6,
      "x": 921,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 130995,
      "e": 43091,
      "ty": 7,
      "x": 935,
      "y": 791,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131008,
      "e": 43104,
      "ty": 2,
      "x": 935,
      "y": 791
    },
    {
      "t": 131008,
      "e": 43104,
      "ty": 41,
      "x": 31562,
      "y": 59650,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 131108,
      "e": 43204,
      "ty": 2,
      "x": 949,
      "y": 853
    },
    {
      "t": 131208,
      "e": 43304,
      "ty": 2,
      "x": 937,
      "y": 865
    },
    {
      "t": 131259,
      "e": 43355,
      "ty": 41,
      "x": 27232,
      "y": 52122,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 131308,
      "e": 43404,
      "ty": 2,
      "x": 696,
      "y": 852
    },
    {
      "t": 131379,
      "e": 43475,
      "ty": 6,
      "x": 397,
      "y": 773,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131408,
      "e": 43504,
      "ty": 2,
      "x": 372,
      "y": 765
    },
    {
      "t": 131508,
      "e": 43604,
      "ty": 2,
      "x": 354,
      "y": 756
    },
    {
      "t": 131508,
      "e": 43604,
      "ty": 41,
      "x": 1113,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131580,
      "e": 43676,
      "ty": 7,
      "x": 354,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131580,
      "e": 43676,
      "ty": 6,
      "x": 354,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 131608,
      "e": 43704,
      "ty": 2,
      "x": 358,
      "y": 750
    },
    {
      "t": 131708,
      "e": 43804,
      "ty": 2,
      "x": 517,
      "y": 733
    },
    {
      "t": 131745,
      "e": 43841,
      "ty": 7,
      "x": 569,
      "y": 766,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 131745,
      "e": 43841,
      "ty": 6,
      "x": 569,
      "y": 766,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131758,
      "e": 43854,
      "ty": 41,
      "x": 12006,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131779,
      "e": 43875,
      "ty": 7,
      "x": 600,
      "y": 787,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 131808,
      "e": 43904,
      "ty": 2,
      "x": 615,
      "y": 797
    },
    {
      "t": 131907,
      "e": 44003,
      "ty": 2,
      "x": 847,
      "y": 855
    },
    {
      "t": 132008,
      "e": 44104,
      "ty": 2,
      "x": 1043,
      "y": 879
    },
    {
      "t": 132009,
      "e": 44105,
      "ty": 41,
      "x": 36875,
      "y": 52122,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 132108,
      "e": 44204,
      "ty": 2,
      "x": 1084,
      "y": 995
    },
    {
      "t": 132208,
      "e": 44304,
      "ty": 2,
      "x": 1084,
      "y": 1053
    },
    {
      "t": 132259,
      "e": 44355,
      "ty": 41,
      "x": 38892,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 132408,
      "e": 44504,
      "ty": 2,
      "x": 1013,
      "y": 1068
    },
    {
      "t": 132413,
      "e": 44509,
      "ty": 6,
      "x": 1000,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 132462,
      "e": 44558,
      "ty": 7,
      "x": 965,
      "y": 1110,
      "ta": "#start"
    },
    {
      "t": 132508,
      "e": 44604,
      "ty": 2,
      "x": 947,
      "y": 1123
    },
    {
      "t": 132509,
      "e": 44605,
      "ty": 41,
      "x": 26916,
      "y": 27872,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 132608,
      "e": 44704,
      "ty": 2,
      "x": 944,
      "y": 1126
    },
    {
      "t": 132708,
      "e": 44804,
      "ty": 2,
      "x": 950,
      "y": 1108
    },
    {
      "t": 132758,
      "e": 44854,
      "ty": 41,
      "x": 29724,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 132789,
      "e": 44885,
      "ty": 6,
      "x": 953,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 132808,
      "e": 44904,
      "ty": 2,
      "x": 954,
      "y": 1103
    },
    {
      "t": 132908,
      "e": 45004,
      "ty": 2,
      "x": 957,
      "y": 1098
    },
    {
      "t": 132918,
      "e": 45014,
      "ty": 3,
      "x": 957,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 132919,
      "e": 45015,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133008,
      "e": 45104,
      "ty": 2,
      "x": 957,
      "y": 1097
    },
    {
      "t": 133008,
      "e": 45104,
      "ty": 41,
      "x": 25940,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 133028,
      "e": 45124,
      "ty": 4,
      "x": 25940,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 133029,
      "e": 45125,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 133029,
      "e": 45125,
      "ty": 5,
      "x": 957,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 133032,
      "e": 45128,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 133258,
      "e": 45354,
      "ty": 41,
      "x": 32681,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 133308,
      "e": 45404,
      "ty": 2,
      "x": 959,
      "y": 1081
    },
    {
      "t": 133408,
      "e": 45504,
      "ty": 2,
      "x": 936,
      "y": 956
    },
    {
      "t": 133508,
      "e": 45604,
      "ty": 2,
      "x": 693,
      "y": 432
    },
    {
      "t": 133508,
      "e": 45604,
      "ty": 41,
      "x": 23589,
      "y": 23488,
      "ta": "html > body"
    },
    {
      "t": 133608,
      "e": 45704,
      "ty": 2,
      "x": 487,
      "y": 153
    },
    {
      "t": 133709,
      "e": 45805,
      "ty": 2,
      "x": 496,
      "y": 152
    },
    {
      "t": 133758,
      "e": 45854,
      "ty": 41,
      "x": 16977,
      "y": 8088,
      "ta": "html > body"
    },
    {
      "t": 133809,
      "e": 45905,
      "ty": 2,
      "x": 502,
      "y": 154
    },
    {
      "t": 133908,
      "e": 46004,
      "ty": 2,
      "x": 503,
      "y": 161
    },
    {
      "t": 134008,
      "e": 46104,
      "ty": 2,
      "x": 318,
      "y": 243
    },
    {
      "t": 134009,
      "e": 46105,
      "ty": 41,
      "x": 10675,
      "y": 13018,
      "ta": "html > body"
    },
    {
      "t": 134031,
      "e": 46127,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 134108,
      "e": 46204,
      "ty": 2,
      "x": 278,
      "y": 262
    },
    {
      "t": 134208,
      "e": 46304,
      "ty": 2,
      "x": 282,
      "y": 262
    },
    {
      "t": 134258,
      "e": 46354,
      "ty": 41,
      "x": 509,
      "y": 11142,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134308,
      "e": 46404,
      "ty": 2,
      "x": 348,
      "y": 374
    },
    {
      "t": 134408,
      "e": 46504,
      "ty": 2,
      "x": 517,
      "y": 568
    },
    {
      "t": 134508,
      "e": 46604,
      "ty": 2,
      "x": 551,
      "y": 570
    },
    {
      "t": 134508,
      "e": 46604,
      "ty": 41,
      "x": 12937,
      "y": 32961,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134608,
      "e": 46704,
      "ty": 2,
      "x": 618,
      "y": 541
    },
    {
      "t": 134708,
      "e": 46804,
      "ty": 2,
      "x": 629,
      "y": 528
    },
    {
      "t": 134759,
      "e": 46855,
      "ty": 41,
      "x": 16723,
      "y": 28923,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134808,
      "e": 46904,
      "ty": 2,
      "x": 627,
      "y": 501
    },
    {
      "t": 134908,
      "e": 47004,
      "ty": 2,
      "x": 613,
      "y": 489
    },
    {
      "t": 135008,
      "e": 47104,
      "ty": 2,
      "x": 693,
      "y": 447
    },
    {
      "t": 135008,
      "e": 47104,
      "ty": 41,
      "x": 19830,
      "y": 23410,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135108,
      "e": 47204,
      "ty": 2,
      "x": 740,
      "y": 435
    },
    {
      "t": 135208,
      "e": 47304,
      "ty": 2,
      "x": 759,
      "y": 436
    },
    {
      "t": 135259,
      "e": 47355,
      "ty": 41,
      "x": 23568,
      "y": 22712,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135309,
      "e": 47405,
      "ty": 2,
      "x": 812,
      "y": 440
    },
    {
      "t": 135408,
      "e": 47504,
      "ty": 2,
      "x": 858,
      "y": 448
    },
    {
      "t": 135508,
      "e": 47604,
      "ty": 2,
      "x": 886,
      "y": 446
    },
    {
      "t": 135508,
      "e": 47604,
      "ty": 41,
      "x": 29199,
      "y": 23333,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135608,
      "e": 47704,
      "ty": 2,
      "x": 919,
      "y": 436
    },
    {
      "t": 135708,
      "e": 47804,
      "ty": 2,
      "x": 928,
      "y": 433
    },
    {
      "t": 135758,
      "e": 47854,
      "ty": 41,
      "x": 31238,
      "y": 22323,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135808,
      "e": 47904,
      "ty": 2,
      "x": 934,
      "y": 433
    },
    {
      "t": 135909,
      "e": 48005,
      "ty": 2,
      "x": 967,
      "y": 429
    },
    {
      "t": 136009,
      "e": 48105,
      "ty": 2,
      "x": 972,
      "y": 429
    },
    {
      "t": 136009,
      "e": 48105,
      "ty": 41,
      "x": 33374,
      "y": 22013,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136259,
      "e": 48355,
      "ty": 41,
      "x": 32549,
      "y": 22556,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136308,
      "e": 48404,
      "ty": 2,
      "x": 939,
      "y": 442
    },
    {
      "t": 136409,
      "e": 48505,
      "ty": 2,
      "x": 858,
      "y": 469
    },
    {
      "t": 136508,
      "e": 48604,
      "ty": 2,
      "x": 689,
      "y": 510
    },
    {
      "t": 136509,
      "e": 48605,
      "ty": 41,
      "x": 19636,
      "y": 28302,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136608,
      "e": 48704,
      "ty": 2,
      "x": 682,
      "y": 519
    },
    {
      "t": 136708,
      "e": 48804,
      "ty": 2,
      "x": 674,
      "y": 538
    },
    {
      "t": 136759,
      "e": 48855,
      "ty": 41,
      "x": 18908,
      "y": 30476,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136808,
      "e": 48904,
      "ty": 2,
      "x": 677,
      "y": 538
    },
    {
      "t": 136908,
      "e": 49004,
      "ty": 2,
      "x": 717,
      "y": 520
    },
    {
      "t": 137008,
      "e": 49104,
      "ty": 41,
      "x": 20995,
      "y": 29079,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 137108,
      "e": 49204,
      "ty": 2,
      "x": 747,
      "y": 507
    },
    {
      "t": 137209,
      "e": 49305,
      "ty": 2,
      "x": 778,
      "y": 489
    },
    {
      "t": 137259,
      "e": 49355,
      "ty": 41,
      "x": 23956,
      "y": 26672,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138108,
      "e": 50204,
      "ty": 2,
      "x": 778,
      "y": 492
    },
    {
      "t": 138208,
      "e": 50304,
      "ty": 2,
      "x": 775,
      "y": 502
    },
    {
      "t": 138258,
      "e": 50304,
      "ty": 41,
      "x": 23811,
      "y": 27681,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138308,
      "e": 50354,
      "ty": 2,
      "x": 775,
      "y": 504
    },
    {
      "t": 138409,
      "e": 50455,
      "ty": 2,
      "x": 796,
      "y": 529
    },
    {
      "t": 138508,
      "e": 50554,
      "ty": 2,
      "x": 1049,
      "y": 591
    },
    {
      "t": 138508,
      "e": 50554,
      "ty": 41,
      "x": 37112,
      "y": 34592,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138608,
      "e": 50654,
      "ty": 2,
      "x": 1553,
      "y": 625
    },
    {
      "t": 138708,
      "e": 50754,
      "ty": 2,
      "x": 1560,
      "y": 629
    },
    {
      "t": 138759,
      "e": 50805,
      "ty": 41,
      "x": 61918,
      "y": 37542,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138808,
      "e": 50854,
      "ty": 2,
      "x": 1557,
      "y": 631
    },
    {
      "t": 138908,
      "e": 50954,
      "ty": 2,
      "x": 1517,
      "y": 631
    },
    {
      "t": 139008,
      "e": 51054,
      "ty": 2,
      "x": 1386,
      "y": 639
    },
    {
      "t": 139008,
      "e": 51054,
      "ty": 41,
      "x": 53471,
      "y": 38319,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 139108,
      "e": 51154,
      "ty": 2,
      "x": 1202,
      "y": 665
    },
    {
      "t": 139208,
      "e": 51254,
      "ty": 2,
      "x": 1185,
      "y": 665
    },
    {
      "t": 139259,
      "e": 51305,
      "ty": 41,
      "x": 43520,
      "y": 40493,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 139308,
      "e": 51354,
      "ty": 2,
      "x": 1150,
      "y": 685
    },
    {
      "t": 139409,
      "e": 51455,
      "ty": 2,
      "x": 998,
      "y": 934
    },
    {
      "t": 139508,
      "e": 51554,
      "ty": 2,
      "x": 939,
      "y": 1199
    },
    {
      "t": 139608,
      "e": 51654,
      "ty": 2,
      "x": 943,
      "y": 1184
    },
    {
      "t": 139708,
      "e": 51754,
      "ty": 2,
      "x": 953,
      "y": 1157
    },
    {
      "t": 139758,
      "e": 51804,
      "ty": 41,
      "x": 32715,
      "y": 62654,
      "ta": "html > body"
    },
    {
      "t": 139809,
      "e": 51855,
      "ty": 2,
      "x": 964,
      "y": 1111
    },
    {
      "t": 139909,
      "e": 51955,
      "ty": 2,
      "x": 965,
      "y": 1044
    },
    {
      "t": 140008,
      "e": 52054,
      "ty": 2,
      "x": 968,
      "y": 1016
    },
    {
      "t": 140009,
      "e": 52055,
      "ty": 41,
      "x": 35779,
      "y": 19894,
      "ta": "> p"
    },
    {
      "t": 140108,
      "e": 52154,
      "ty": 2,
      "x": 976,
      "y": 967
    },
    {
      "t": 140208,
      "e": 52254,
      "ty": 2,
      "x": 986,
      "y": 947
    },
    {
      "t": 140258,
      "e": 52304,
      "ty": 41,
      "x": 35073,
      "y": 60914,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 140308,
      "e": 52354,
      "ty": 2,
      "x": 1035,
      "y": 911
    },
    {
      "t": 140408,
      "e": 52454,
      "ty": 2,
      "x": 1047,
      "y": 898
    },
    {
      "t": 140508,
      "e": 52554,
      "ty": 41,
      "x": 37015,
      "y": 58430,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 140608,
      "e": 52654,
      "ty": 2,
      "x": 1047,
      "y": 897
    },
    {
      "t": 140708,
      "e": 52754,
      "ty": 2,
      "x": 1020,
      "y": 893
    },
    {
      "t": 140758,
      "e": 52804,
      "ty": 41,
      "x": 32694,
      "y": 56488,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 140808,
      "e": 52854,
      "ty": 2,
      "x": 940,
      "y": 860
    },
    {
      "t": 140908,
      "e": 52954,
      "ty": 2,
      "x": 938,
      "y": 853
    },
    {
      "t": 141008,
      "e": 53054,
      "ty": 2,
      "x": 915,
      "y": 813
    },
    {
      "t": 141009,
      "e": 53055,
      "ty": 41,
      "x": 30607,
      "y": 51830,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 141109,
      "e": 53155,
      "ty": 2,
      "x": 914,
      "y": 809
    },
    {
      "t": 141259,
      "e": 53305,
      "ty": 41,
      "x": 30558,
      "y": 51519,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 142858,
      "e": 54904,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 143863,
      "e": 55909,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 151, dom: 669, initialDom: 701",
  "javascriptErrors": []
}