var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06045987e9450afb27352f3f1a42679c2fbc4a18"] = {
  "startTime": "2018-06-04T19:19:59.2509661Z",
  "websitePageUrl": "/16",
  "visitTime": 77481,
  "engagementTime": 76778,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "cbe42e2a772a8a84527999f2f174fcea",
    "created": "2018-06-04T19:19:59.2509661+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=02TJQ",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "068c19307976b509586d0bf05dfda065",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/cbe42e2a772a8a84527999f2f174fcea/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 508,
      "y": 760
    },
    {
      "t": 1375,
      "e": 1375,
      "ty": 6,
      "x": 487,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 486,
      "y": 577
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 482,
      "y": 561
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 43267,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2860,
      "e": 2860,
      "ty": 3,
      "x": 482,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2861,
      "e": 2861,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3003,
      "e": 3003,
      "ty": 4,
      "x": 43267,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3004,
      "e": 3004,
      "ty": 5,
      "x": 482,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4395,
      "e": 4395,
      "ty": 7,
      "x": 602,
      "y": 643,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 602,
      "y": 643
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1144,
      "y": 990
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 25228,
      "y": 61022,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1316,
      "y": 1158
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1321,
      "y": 1166
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 45251,
      "y": 64150,
      "ta": "> div.stimulus"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1339,
      "y": 1125
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1357,
      "y": 1076
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1363,
      "y": 1054
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 39196,
      "y": 65037,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1353,
      "y": 1038
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1315,
      "y": 1034
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 39451,
      "y": 26214,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1289,
      "y": 1035
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1205,
      "y": 1012
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1159,
      "y": 983
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 42230,
      "y": 57599,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1157,
      "y": 982
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 38990,
      "y": 53503,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1156,
      "y": 968
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 26074,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1156,
      "y": 956
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1156,
      "y": 937
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 26074,
      "y": 55937,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1156,
      "y": 915
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1156,
      "y": 903
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1156,
      "y": 893
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 26074,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1156,
      "y": 887
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 26074,
      "y": 53645,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1178,
      "y": 903
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 32063,
      "y": 61022,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 1326,
      "y": 1109
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 1400,
      "y": 1199
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1422,
      "y": 1199
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11449,
      "e": 11449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11947,
      "e": 11947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11980,
      "e": 11980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12012,
      "e": 12012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12046,
      "e": 12046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12078,
      "e": 12078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12112,
      "e": 12112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12145,
      "e": 12145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12178,
      "e": 12178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12211,
      "e": 12211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12243,
      "e": 12243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12276,
      "e": 12276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12310,
      "e": 12310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12342,
      "e": 12342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12367,
      "e": 12367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 12368,
      "e": 12368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12519,
      "e": 12519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "c"
    },
    {
      "t": 12591,
      "e": 12591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "c"
    },
    {
      "t": 12647,
      "e": 12647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12648,
      "e": 12648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12750,
      "e": 12750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "cO"
    },
    {
      "t": 12871,
      "e": 12871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12872,
      "e": 12872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12967,
      "e": 12967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "cOF"
    },
    {
      "t": 13335,
      "e": 13335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13336,
      "e": 13336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13439,
      "e": 13439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "cOFF"
    },
    {
      "t": 17835,
      "e": 17835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18007,
      "e": 18007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "cOF"
    },
    {
      "t": 18334,
      "e": 18334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18367,
      "e": 18367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18400,
      "e": 18400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18433,
      "e": 18433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18466,
      "e": 18466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18499,
      "e": 18499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18532,
      "e": 18532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18566,
      "e": 18566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18599,
      "e": 18599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18611,
      "e": 18611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 18682,
      "e": 18682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 18786,
      "e": 18786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 19043,
      "e": 19043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19307,
      "e": 19307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 19307,
      "e": 19307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19418,
      "e": 19418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "C"
    },
    {
      "t": 19466,
      "e": 19466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "C"
    },
    {
      "t": 19579,
      "e": 19579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19579,
      "e": 19579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19650,
      "e": 19650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Co"
    },
    {
      "t": 19971,
      "e": 19971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19971,
      "e": 19971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20004,
      "e": 20004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20049,
      "e": 20049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Cof"
    },
    {
      "t": 20379,
      "e": 20379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20379,
      "e": 20379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20474,
      "e": 20474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coff"
    },
    {
      "t": 20635,
      "e": 20635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20635,
      "e": 20635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20746,
      "e": 20746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20859,
      "e": 20859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20860,
      "e": 20860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20921,
      "e": 20921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20946,
      "e": 20946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20946,
      "e": 20946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21057,
      "e": 21057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21515,
      "e": 21515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21515,
      "e": 21515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21587,
      "e": 21587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 21618,
      "e": 21618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21620,
      "e": 21620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21706,
      "e": 21706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 21807,
      "e": 21807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee br"
    },
    {
      "t": 21858,
      "e": 21858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21859,
      "e": 21859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21938,
      "e": 21938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22027,
      "e": 22027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22028,
      "e": 22028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22138,
      "e": 22138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22202,
      "e": 22202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 22202,
      "e": 22202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22274,
      "e": 22274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 22379,
      "e": 22379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22380,
      "e": 22380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22449,
      "e": 22449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22506,
      "e": 22506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 22506,
      "e": 22506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22586,
      "e": 22586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 22667,
      "e": 22667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22667,
      "e": 22667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22738,
      "e": 22738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22835,
      "e": 22835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22835,
      "e": 22835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22914,
      "e": 22914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23010,
      "e": 23010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23010,
      "e": 23010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23066,
      "e": 23066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23207,
      "e": 23207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee break for "
    },
    {
      "t": 23922,
      "e": 23922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24422,
      "e": 24422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24455,
      "e": 24455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24488,
      "e": 24488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24521,
      "e": 24521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24531,
      "e": 24531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24531,
      "e": 24531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24633,
      "e": 24633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 24714,
      "e": 24714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24947,
      "e": 24947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 24948,
      "e": 24948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25034,
      "e": 25034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 25195,
      "e": 25195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25195,
      "e": 25195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25274,
      "e": 25274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25306,
      "e": 25306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 25492,
      "e": 25492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 25492,
      "e": 25492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25553,
      "e": 25553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 25634,
      "e": 25634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26274,
      "e": 26274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 26275,
      "e": 26275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26338,
      "e": 26338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 26546,
      "e": 26546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26547,
      "e": 26547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26601,
      "e": 26601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26690,
      "e": 26690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 26954,
      "e": 26954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26956,
      "e": 26956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27082,
      "e": 27082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 27106,
      "e": 27106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27187,
      "e": 27187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27187,
      "e": 27187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27258,
      "e": 27258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27410,
      "e": 27410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27411,
      "e": 27411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27491,
      "e": 27491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27607,
      "e": 27607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee break for F, B. Shi"
    },
    {
      "t": 27635,
      "e": 27635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 27636,
      "e": 27636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27762,
      "e": 27762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 27858,
      "e": 27858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27859,
      "e": 27859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27946,
      "e": 27946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28074,
      "e": 28074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28074,
      "e": 28074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28178,
      "e": 28178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28241,
      "e": 28241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28243,
      "e": 28243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28338,
      "e": 28338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28410,
      "e": 28410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28410,
      "e": 28410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28474,
      "e": 28474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28569,
      "e": 28569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28570,
      "e": 28570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28659,
      "e": 28659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28770,
      "e": 28770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28771,
      "e": 28771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28825,
      "e": 28825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29018,
      "e": 29018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29019,
      "e": 29019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29106,
      "e": 29106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29207,
      "e": 29207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee break for F, B. Shift start"
    },
    {
      "t": 29266,
      "e": 29266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29268,
      "e": 29268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29407,
      "e": 29407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee break for F, B. Shift start "
    },
    {
      "t": 29419,
      "e": 29419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29906,
      "e": 29906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29908,
      "e": 29908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30004,
      "e": 30004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30010,
      "e": 30010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 30138,
      "e": 30138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30138,
      "e": 30138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30226,
      "e": 30226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30283,
      "e": 30283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30283,
      "e": 30283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30394,
      "e": 30394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 30514,
      "e": 30514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30514,
      "e": 30514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30586,
      "e": 30586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36011,
      "e": 35586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36402,
      "e": 35977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36403,
      "e": 35978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36474,
      "e": 36049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 36578,
      "e": 36153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36970,
      "e": 36545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 36971,
      "e": 36546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37073,
      "e": 36648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 37210,
      "e": 36785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37402,
      "e": 36977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37403,
      "e": 36978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37466,
      "e": 37041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 37546,
      "e": 37121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38504,
      "e": 38079,
      "ty": 2,
      "x": 1110,
      "y": 1199
    },
    {
      "t": 38604,
      "e": 38179,
      "ty": 2,
      "x": 956,
      "y": 1199
    },
    {
      "t": 38704,
      "e": 38279,
      "ty": 2,
      "x": 779,
      "y": 1199
    },
    {
      "t": 38804,
      "e": 38379,
      "ty": 2,
      "x": 384,
      "y": 1193
    },
    {
      "t": 38904,
      "e": 38479,
      "ty": 2,
      "x": 362,
      "y": 1058
    },
    {
      "t": 39004,
      "e": 38579,
      "ty": 2,
      "x": 417,
      "y": 1039
    },
    {
      "t": 39005,
      "e": 38580,
      "ty": 41,
      "x": 35960,
      "y": 57114,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 39104,
      "e": 38679,
      "ty": 2,
      "x": 450,
      "y": 886
    },
    {
      "t": 39204,
      "e": 38779,
      "ty": 2,
      "x": 388,
      "y": 734
    },
    {
      "t": 39254,
      "e": 38829,
      "ty": 41,
      "x": 34830,
      "y": 61776,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 39304,
      "e": 38879,
      "ty": 2,
      "x": 398,
      "y": 692
    },
    {
      "t": 39311,
      "e": 38886,
      "ty": 6,
      "x": 403,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 39404,
      "e": 38979,
      "ty": 2,
      "x": 404,
      "y": 670
    },
    {
      "t": 39502,
      "e": 39077,
      "ty": 3,
      "x": 404,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 39503,
      "e": 39078,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Coffee break for F, B. Shift start for M,L"
    },
    {
      "t": 39504,
      "e": 39079,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39505,
      "e": 39080,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39508,
      "e": 39083,
      "ty": 41,
      "x": 35719,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 39621,
      "e": 39196,
      "ty": 4,
      "x": 35719,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 39632,
      "e": 39207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39634,
      "e": 39209,
      "ty": 5,
      "x": 404,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 39643,
      "e": 39218,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 40004,
      "e": 39579,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40641,
      "e": 40216,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 40754,
      "e": 40329,
      "ty": 41,
      "x": 13843,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 40804,
      "e": 40379,
      "ty": 2,
      "x": 411,
      "y": 659
    },
    {
      "t": 41004,
      "e": 40579,
      "ty": 41,
      "x": 13878,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 41304,
      "e": 40879,
      "ty": 2,
      "x": 454,
      "y": 652
    },
    {
      "t": 41404,
      "e": 40979,
      "ty": 2,
      "x": 757,
      "y": 650
    },
    {
      "t": 41444,
      "e": 41019,
      "ty": 6,
      "x": 822,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41461,
      "e": 41036,
      "ty": 7,
      "x": 835,
      "y": 645,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41505,
      "e": 41080,
      "ty": 2,
      "x": 835,
      "y": 645
    },
    {
      "t": 41505,
      "e": 41080,
      "ty": 41,
      "x": 5839,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41604,
      "e": 41179,
      "ty": 2,
      "x": 859,
      "y": 626
    },
    {
      "t": 41704,
      "e": 41279,
      "ty": 2,
      "x": 911,
      "y": 593
    },
    {
      "t": 41754,
      "e": 41329,
      "ty": 41,
      "x": 24873,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41804,
      "e": 41379,
      "ty": 2,
      "x": 925,
      "y": 575
    },
    {
      "t": 41838,
      "e": 41413,
      "ty": 6,
      "x": 925,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41904,
      "e": 41479,
      "ty": 2,
      "x": 925,
      "y": 573
    },
    {
      "t": 42004,
      "e": 41579,
      "ty": 2,
      "x": 928,
      "y": 566
    },
    {
      "t": 42004,
      "e": 41579,
      "ty": 41,
      "x": 25954,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42190,
      "e": 41765,
      "ty": 3,
      "x": 928,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42190,
      "e": 41765,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42326,
      "e": 41901,
      "ty": 4,
      "x": 25954,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42327,
      "e": 41902,
      "ty": 5,
      "x": 928,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44042,
      "e": 43617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 44043,
      "e": 43618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44162,
      "e": 43737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 44722,
      "e": 44297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 44722,
      "e": 44297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44849,
      "e": 44424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 44981,
      "e": 44556,
      "ty": 7,
      "x": 918,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45004,
      "e": 44579,
      "ty": 2,
      "x": 904,
      "y": 598
    },
    {
      "t": 45005,
      "e": 44580,
      "ty": 41,
      "x": 20763,
      "y": 10570,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 45104,
      "e": 44679,
      "ty": 2,
      "x": 896,
      "y": 621
    },
    {
      "t": 45204,
      "e": 44779,
      "ty": 2,
      "x": 874,
      "y": 646
    },
    {
      "t": 45215,
      "e": 44790,
      "ty": 6,
      "x": 866,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45255,
      "e": 44830,
      "ty": 41,
      "x": 11895,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45304,
      "e": 44879,
      "ty": 2,
      "x": 863,
      "y": 659
    },
    {
      "t": 45405,
      "e": 44980,
      "ty": 2,
      "x": 862,
      "y": 660
    },
    {
      "t": 45462,
      "e": 45037,
      "ty": 3,
      "x": 862,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45464,
      "e": 45039,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 45464,
      "e": 45039,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45465,
      "e": 45040,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45504,
      "e": 45079,
      "ty": 41,
      "x": 11679,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45581,
      "e": 45156,
      "ty": 4,
      "x": 11679,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45582,
      "e": 45157,
      "ty": 5,
      "x": 862,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46035,
      "e": 45610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 46434,
      "e": 46009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "66"
    },
    {
      "t": 46434,
      "e": 46009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46505,
      "e": 46080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "B"
    },
    {
      "t": 46529,
      "e": 46104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "B"
    },
    {
      "t": 46642,
      "e": 46217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 46643,
      "e": 46218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46697,
      "e": 46272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 46697,
      "e": 46272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46729,
      "e": 46304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ban"
    },
    {
      "t": 46769,
      "e": 46344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ban"
    },
    {
      "t": 47330,
      "e": 46905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "71"
    },
    {
      "t": 47332,
      "e": 46907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47441,
      "e": 47016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Bang"
    },
    {
      "t": 48042,
      "e": 47617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 48042,
      "e": 47617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48130,
      "e": 47705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||l"
    },
    {
      "t": 48185,
      "e": 47760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 48186,
      "e": 47761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48273,
      "e": 47848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 48434,
      "e": 48009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 48435,
      "e": 48010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48513,
      "e": 48088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 49370,
      "e": 48945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 49371,
      "e": 48946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49481,
      "e": 49056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 49658,
      "e": 49233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 49658,
      "e": 49233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49761,
      "e": 49336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 50005,
      "e": 49580,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50034,
      "e": 49609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 50034,
      "e": 49609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50097,
      "e": 49672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||h"
    },
    {
      "t": 50206,
      "e": 49781,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Bangladesh"
    },
    {
      "t": 50770,
      "e": 50345,
      "ty": 7,
      "x": 904,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50787,
      "e": 50362,
      "ty": 6,
      "x": 961,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50804,
      "e": 50379,
      "ty": 2,
      "x": 970,
      "y": 682
    },
    {
      "t": 50904,
      "e": 50479,
      "ty": 2,
      "x": 973,
      "y": 683
    },
    {
      "t": 51005,
      "e": 50580,
      "ty": 2,
      "x": 968,
      "y": 685
    },
    {
      "t": 51005,
      "e": 50580,
      "ty": 41,
      "x": 37148,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51104,
      "e": 50679,
      "ty": 2,
      "x": 966,
      "y": 686
    },
    {
      "t": 51126,
      "e": 50701,
      "ty": 3,
      "x": 966,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51128,
      "e": 50703,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Bangladesh"
    },
    {
      "t": 51128,
      "e": 50703,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51128,
      "e": 50703,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51213,
      "e": 50788,
      "ty": 4,
      "x": 36117,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51213,
      "e": 50788,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51214,
      "e": 50789,
      "ty": 5,
      "x": 966,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51215,
      "e": 50790,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 51254,
      "e": 50829,
      "ty": 41,
      "x": 32991,
      "y": 37559,
      "ta": "html > body"
    },
    {
      "t": 51905,
      "e": 51480,
      "ty": 2,
      "x": 823,
      "y": 886
    },
    {
      "t": 52004,
      "e": 51579,
      "ty": 2,
      "x": 796,
      "y": 922
    },
    {
      "t": 52005,
      "e": 51580,
      "ty": 41,
      "x": 27136,
      "y": 50633,
      "ta": "html > body"
    },
    {
      "t": 52105,
      "e": 51680,
      "ty": 2,
      "x": 783,
      "y": 948
    },
    {
      "t": 52204,
      "e": 51779,
      "ty": 2,
      "x": 642,
      "y": 1065
    },
    {
      "t": 52228,
      "e": 51803,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 52254,
      "e": 51829,
      "ty": 41,
      "x": 19560,
      "y": 61435,
      "ta": "html > body"
    },
    {
      "t": 52304,
      "e": 51879,
      "ty": 2,
      "x": 553,
      "y": 1128
    },
    {
      "t": 52504,
      "e": 52079,
      "ty": 41,
      "x": 18768,
      "y": 62044,
      "ta": "html > body"
    },
    {
      "t": 52604,
      "e": 52179,
      "ty": 2,
      "x": 557,
      "y": 1125
    },
    {
      "t": 52703,
      "e": 52278,
      "ty": 2,
      "x": 588,
      "y": 1092
    },
    {
      "t": 52754,
      "e": 52329,
      "ty": 41,
      "x": 20662,
      "y": 56671,
      "ta": "html > body"
    },
    {
      "t": 52804,
      "e": 52379,
      "ty": 2,
      "x": 623,
      "y": 994
    },
    {
      "t": 52904,
      "e": 52479,
      "ty": 2,
      "x": 710,
      "y": 885
    },
    {
      "t": 53004,
      "e": 52579,
      "ty": 2,
      "x": 1348,
      "y": 52
    },
    {
      "t": 53004,
      "e": 52579,
      "ty": 41,
      "x": 46146,
      "y": 2437,
      "ta": "html > body"
    },
    {
      "t": 53104,
      "e": 52679,
      "ty": 2,
      "x": 1615,
      "y": 0
    },
    {
      "t": 53205,
      "e": 52780,
      "ty": 2,
      "x": 1600,
      "y": 36
    },
    {
      "t": 53255,
      "e": 52830,
      "ty": 41,
      "x": 54755,
      "y": 1606,
      "ta": "html > body"
    },
    {
      "t": 53305,
      "e": 52880,
      "ty": 2,
      "x": 1526,
      "y": 76
    },
    {
      "t": 53403,
      "e": 52978,
      "ty": 2,
      "x": 1364,
      "y": 163
    },
    {
      "t": 53503,
      "e": 53078,
      "ty": 2,
      "x": 1298,
      "y": 215
    },
    {
      "t": 53504,
      "e": 53079,
      "ty": 41,
      "x": 44424,
      "y": 11467,
      "ta": "html > body"
    },
    {
      "t": 53603,
      "e": 53178,
      "ty": 2,
      "x": 1103,
      "y": 243
    },
    {
      "t": 53703,
      "e": 53278,
      "ty": 2,
      "x": 952,
      "y": 242
    },
    {
      "t": 53754,
      "e": 53329,
      "ty": 41,
      "x": 60250,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 53803,
      "e": 53378,
      "ty": 2,
      "x": 838,
      "y": 227
    },
    {
      "t": 53903,
      "e": 53478,
      "ty": 2,
      "x": 768,
      "y": 247
    },
    {
      "t": 54004,
      "e": 53579,
      "ty": 2,
      "x": 763,
      "y": 271
    },
    {
      "t": 54004,
      "e": 53579,
      "ty": 41,
      "x": 26000,
      "y": 14569,
      "ta": "html > body"
    },
    {
      "t": 54103,
      "e": 53678,
      "ty": 2,
      "x": 779,
      "y": 285
    },
    {
      "t": 54204,
      "e": 53779,
      "ty": 2,
      "x": 805,
      "y": 287
    },
    {
      "t": 54254,
      "e": 53829,
      "ty": 41,
      "x": 27825,
      "y": 15566,
      "ta": "html > body"
    },
    {
      "t": 54304,
      "e": 53879,
      "ty": 2,
      "x": 824,
      "y": 296
    },
    {
      "t": 54306,
      "e": 53881,
      "ty": 6,
      "x": 829,
      "y": 299,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54323,
      "e": 53898,
      "ty": 7,
      "x": 832,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54390,
      "e": 53965,
      "ty": 6,
      "x": 836,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 54404,
      "e": 53979,
      "ty": 2,
      "x": 836,
      "y": 316
    },
    {
      "t": 54504,
      "e": 54079,
      "ty": 2,
      "x": 836,
      "y": 323
    },
    {
      "t": 54504,
      "e": 54079,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 54703,
      "e": 54278,
      "ty": 2,
      "x": 830,
      "y": 322
    },
    {
      "t": 54753,
      "e": 54328,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 54804,
      "e": 54379,
      "ty": 2,
      "x": 829,
      "y": 322
    },
    {
      "t": 55104,
      "e": 54679,
      "ty": 2,
      "x": 833,
      "y": 323
    },
    {
      "t": 55204,
      "e": 54779,
      "ty": 2,
      "x": 834,
      "y": 323
    },
    {
      "t": 55254,
      "e": 54829,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55263,
      "e": 54838,
      "ty": 3,
      "x": 835,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55264,
      "e": 54839,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55303,
      "e": 54878,
      "ty": 2,
      "x": 835,
      "y": 323
    },
    {
      "t": 55357,
      "e": 54932,
      "ty": 4,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55359,
      "e": 54934,
      "ty": 5,
      "x": 835,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55359,
      "e": 54934,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 55904,
      "e": 55479,
      "ty": 2,
      "x": 836,
      "y": 324
    },
    {
      "t": 56004,
      "e": 55579,
      "ty": 2,
      "x": 835,
      "y": 327
    },
    {
      "t": 56004,
      "e": 55579,
      "ty": 41,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56558,
      "e": 56133,
      "ty": 7,
      "x": 832,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56604,
      "e": 56179,
      "ty": 2,
      "x": 832,
      "y": 337
    },
    {
      "t": 56704,
      "e": 56279,
      "ty": 2,
      "x": 837,
      "y": 373
    },
    {
      "t": 56754,
      "e": 56329,
      "ty": 41,
      "x": 3697,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 56804,
      "e": 56379,
      "ty": 2,
      "x": 837,
      "y": 385
    },
    {
      "t": 56858,
      "e": 56433,
      "ty": 6,
      "x": 837,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56874,
      "e": 56449,
      "ty": 7,
      "x": 840,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56904,
      "e": 56479,
      "ty": 2,
      "x": 841,
      "y": 430
    },
    {
      "t": 57004,
      "e": 56579,
      "ty": 2,
      "x": 850,
      "y": 485
    },
    {
      "t": 57004,
      "e": 56579,
      "ty": 41,
      "x": 6782,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 57104,
      "e": 56679,
      "ty": 2,
      "x": 851,
      "y": 495
    },
    {
      "t": 57255,
      "e": 56680,
      "ty": 41,
      "x": 26547,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 57303,
      "e": 56728,
      "ty": 2,
      "x": 852,
      "y": 495
    },
    {
      "t": 57403,
      "e": 56828,
      "ty": 2,
      "x": 862,
      "y": 462
    },
    {
      "t": 57504,
      "e": 56929,
      "ty": 2,
      "x": 882,
      "y": 420
    },
    {
      "t": 57505,
      "e": 56930,
      "ty": 41,
      "x": 14376,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 57604,
      "e": 57029,
      "ty": 2,
      "x": 923,
      "y": 368
    },
    {
      "t": 57704,
      "e": 57129,
      "ty": 2,
      "x": 956,
      "y": 354
    },
    {
      "t": 57754,
      "e": 57179,
      "ty": 41,
      "x": 32176,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 57803,
      "e": 57228,
      "ty": 2,
      "x": 957,
      "y": 354
    },
    {
      "t": 58003,
      "e": 57428,
      "ty": 2,
      "x": 916,
      "y": 392
    },
    {
      "t": 58004,
      "e": 57429,
      "ty": 41,
      "x": 22445,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 58104,
      "e": 57529,
      "ty": 2,
      "x": 892,
      "y": 419
    },
    {
      "t": 58204,
      "e": 57629,
      "ty": 2,
      "x": 884,
      "y": 427
    },
    {
      "t": 58254,
      "e": 57679,
      "ty": 41,
      "x": 13902,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 58304,
      "e": 57729,
      "ty": 2,
      "x": 877,
      "y": 432
    },
    {
      "t": 58404,
      "e": 57829,
      "ty": 2,
      "x": 872,
      "y": 434
    },
    {
      "t": 58504,
      "e": 57929,
      "ty": 2,
      "x": 865,
      "y": 437
    },
    {
      "t": 58504,
      "e": 57929,
      "ty": 41,
      "x": 34808,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58604,
      "e": 58029,
      "ty": 2,
      "x": 849,
      "y": 437
    },
    {
      "t": 58704,
      "e": 58129,
      "ty": 2,
      "x": 844,
      "y": 436
    },
    {
      "t": 58754,
      "e": 58179,
      "ty": 41,
      "x": 17235,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58803,
      "e": 58228,
      "ty": 2,
      "x": 841,
      "y": 434
    },
    {
      "t": 58904,
      "e": 58329,
      "ty": 2,
      "x": 838,
      "y": 426
    },
    {
      "t": 59004,
      "e": 58429,
      "ty": 2,
      "x": 836,
      "y": 425
    },
    {
      "t": 59004,
      "e": 58429,
      "ty": 41,
      "x": 3459,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59104,
      "e": 58529,
      "ty": 2,
      "x": 840,
      "y": 428
    },
    {
      "t": 59204,
      "e": 58629,
      "ty": 2,
      "x": 843,
      "y": 431
    },
    {
      "t": 59254,
      "e": 58679,
      "ty": 41,
      "x": 17235,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 59304,
      "e": 58729,
      "ty": 2,
      "x": 843,
      "y": 434
    },
    {
      "t": 59404,
      "e": 58829,
      "ty": 2,
      "x": 842,
      "y": 435
    },
    {
      "t": 59504,
      "e": 58929,
      "ty": 2,
      "x": 840,
      "y": 436
    },
    {
      "t": 59505,
      "e": 58930,
      "ty": 41,
      "x": 14839,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 59518,
      "e": 58943,
      "ty": 6,
      "x": 839,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59559,
      "e": 58984,
      "ty": 7,
      "x": 831,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59604,
      "e": 59029,
      "ty": 2,
      "x": 825,
      "y": 425
    },
    {
      "t": 59704,
      "e": 59129,
      "ty": 2,
      "x": 824,
      "y": 420
    },
    {
      "t": 59754,
      "e": 59179,
      "ty": 41,
      "x": 3017,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59804,
      "e": 59229,
      "ty": 2,
      "x": 825,
      "y": 415
    },
    {
      "t": 59806,
      "e": 59231,
      "ty": 6,
      "x": 826,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 59904,
      "e": 59329,
      "ty": 2,
      "x": 828,
      "y": 413
    },
    {
      "t": 60004,
      "e": 59429,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60023,
      "e": 59448,
      "ty": 3,
      "x": 828,
      "y": 413,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60024,
      "e": 59449,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 60024,
      "e": 59449,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60149,
      "e": 59574,
      "ty": 4,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60149,
      "e": 59574,
      "ty": 5,
      "x": 828,
      "y": 413,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60149,
      "e": 59574,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 60846,
      "e": 60271,
      "ty": 7,
      "x": 827,
      "y": 426,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 60904,
      "e": 60329,
      "ty": 2,
      "x": 802,
      "y": 519
    },
    {
      "t": 60995,
      "e": 60420,
      "ty": 6,
      "x": 828,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 61004,
      "e": 60429,
      "ty": 2,
      "x": 828,
      "y": 671
    },
    {
      "t": 61004,
      "e": 60429,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 61011,
      "e": 60436,
      "ty": 7,
      "x": 837,
      "y": 689,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 61103,
      "e": 60528,
      "ty": 2,
      "x": 854,
      "y": 714
    },
    {
      "t": 61203,
      "e": 60628,
      "ty": 2,
      "x": 855,
      "y": 716
    },
    {
      "t": 61254,
      "e": 60628,
      "ty": 41,
      "x": 8427,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61304,
      "e": 60678,
      "ty": 2,
      "x": 855,
      "y": 724
    },
    {
      "t": 61504,
      "e": 60878,
      "ty": 2,
      "x": 850,
      "y": 728
    },
    {
      "t": 61504,
      "e": 60878,
      "ty": 41,
      "x": 7172,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61604,
      "e": 60978,
      "ty": 2,
      "x": 841,
      "y": 738
    },
    {
      "t": 61704,
      "e": 61078,
      "ty": 2,
      "x": 837,
      "y": 743
    },
    {
      "t": 61728,
      "e": 61102,
      "ty": 6,
      "x": 833,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 61754,
      "e": 61128,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 61804,
      "e": 61178,
      "ty": 2,
      "x": 829,
      "y": 759
    },
    {
      "t": 62005,
      "e": 61379,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62161,
      "e": 61535,
      "ty": 7,
      "x": 828,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62204,
      "e": 61578,
      "ty": 2,
      "x": 827,
      "y": 739
    },
    {
      "t": 62229,
      "e": 61603,
      "ty": 6,
      "x": 827,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62254,
      "e": 61628,
      "ty": 41,
      "x": 2914,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62304,
      "e": 61678,
      "ty": 2,
      "x": 828,
      "y": 724
    },
    {
      "t": 62312,
      "e": 61686,
      "ty": 7,
      "x": 828,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62404,
      "e": 61778,
      "ty": 2,
      "x": 828,
      "y": 722
    },
    {
      "t": 62446,
      "e": 61820,
      "ty": 6,
      "x": 837,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62504,
      "e": 61878,
      "ty": 2,
      "x": 839,
      "y": 705
    },
    {
      "t": 62504,
      "e": 61878,
      "ty": 41,
      "x": 63408,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62604,
      "e": 61978,
      "ty": 2,
      "x": 839,
      "y": 704
    },
    {
      "t": 62754,
      "e": 62128,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62780,
      "e": 62154,
      "ty": 7,
      "x": 822,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62804,
      "e": 62178,
      "ty": 2,
      "x": 820,
      "y": 704
    },
    {
      "t": 62904,
      "e": 62278,
      "ty": 2,
      "x": 818,
      "y": 703
    },
    {
      "t": 63004,
      "e": 62378,
      "ty": 2,
      "x": 818,
      "y": 702
    },
    {
      "t": 63005,
      "e": 62379,
      "ty": 41,
      "x": 27894,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 63104,
      "e": 62478,
      "ty": 2,
      "x": 823,
      "y": 697
    },
    {
      "t": 63134,
      "e": 62508,
      "ty": 6,
      "x": 826,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63204,
      "e": 62578,
      "ty": 2,
      "x": 830,
      "y": 697
    },
    {
      "t": 63254,
      "e": 62628,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63755,
      "e": 63129,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63793,
      "e": 63167,
      "ty": 7,
      "x": 832,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63804,
      "e": 63178,
      "ty": 2,
      "x": 832,
      "y": 709
    },
    {
      "t": 63942,
      "e": 63316,
      "ty": 3,
      "x": 832,
      "y": 709,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63943,
      "e": 63317,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 64004,
      "e": 63378,
      "ty": 41,
      "x": 2665,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64061,
      "e": 63435,
      "ty": 4,
      "x": 2665,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64061,
      "e": 63435,
      "ty": 5,
      "x": 832,
      "y": 709,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64062,
      "e": 63436,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64062,
      "e": 63436,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 64704,
      "e": 64078,
      "ty": 2,
      "x": 833,
      "y": 778
    },
    {
      "t": 64714,
      "e": 64088,
      "ty": 6,
      "x": 833,
      "y": 814,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64731,
      "e": 64105,
      "ty": 7,
      "x": 833,
      "y": 842,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64731,
      "e": 64105,
      "ty": 6,
      "x": 833,
      "y": 842,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 64748,
      "e": 64122,
      "ty": 7,
      "x": 833,
      "y": 870,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 64755,
      "e": 64129,
      "ty": 41,
      "x": 2747,
      "y": 52980,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64804,
      "e": 64178,
      "ty": 2,
      "x": 841,
      "y": 929
    },
    {
      "t": 64881,
      "e": 64178,
      "ty": 6,
      "x": 831,
      "y": 988,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 64898,
      "e": 64195,
      "ty": 7,
      "x": 826,
      "y": 999,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 64904,
      "e": 64201,
      "ty": 2,
      "x": 826,
      "y": 999
    },
    {
      "t": 65004,
      "e": 64301,
      "ty": 2,
      "x": 823,
      "y": 1011
    },
    {
      "t": 65004,
      "e": 64301,
      "ty": 41,
      "x": 374,
      "y": 63517,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 65104,
      "e": 64401,
      "ty": 2,
      "x": 817,
      "y": 982
    },
    {
      "t": 65204,
      "e": 64501,
      "ty": 2,
      "x": 814,
      "y": 962
    },
    {
      "t": 65254,
      "e": 64551,
      "ty": 41,
      "x": 27756,
      "y": 52849,
      "ta": "html > body"
    },
    {
      "t": 65304,
      "e": 64601,
      "ty": 2,
      "x": 815,
      "y": 959
    },
    {
      "t": 65404,
      "e": 64701,
      "ty": 2,
      "x": 842,
      "y": 945
    },
    {
      "t": 65505,
      "e": 64802,
      "ty": 2,
      "x": 848,
      "y": 943
    },
    {
      "t": 65505,
      "e": 64802,
      "ty": 41,
      "x": 29029,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 65754,
      "e": 65051,
      "ty": 41,
      "x": 26845,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 65804,
      "e": 65101,
      "ty": 2,
      "x": 844,
      "y": 941
    },
    {
      "t": 65904,
      "e": 65201,
      "ty": 2,
      "x": 840,
      "y": 940
    },
    {
      "t": 65915,
      "e": 65212,
      "ty": 6,
      "x": 839,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66004,
      "e": 65301,
      "ty": 2,
      "x": 838,
      "y": 938
    },
    {
      "t": 66004,
      "e": 65301,
      "ty": 41,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66126,
      "e": 65423,
      "ty": 3,
      "x": 838,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66127,
      "e": 65424,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66128,
      "e": 65425,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66245,
      "e": 65542,
      "ty": 4,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66245,
      "e": 65542,
      "ty": 5,
      "x": 838,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66245,
      "e": 65542,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 66462,
      "e": 65759,
      "ty": 7,
      "x": 837,
      "y": 948,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66500,
      "e": 65797,
      "ty": 6,
      "x": 850,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66504,
      "e": 65801,
      "ty": 2,
      "x": 850,
      "y": 1008
    },
    {
      "t": 66504,
      "e": 65801,
      "ty": 41,
      "x": 10605,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66516,
      "e": 65813,
      "ty": 7,
      "x": 862,
      "y": 1044,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66604,
      "e": 65901,
      "ty": 2,
      "x": 901,
      "y": 1100
    },
    {
      "t": 66704,
      "e": 66001,
      "ty": 2,
      "x": 904,
      "y": 1063
    },
    {
      "t": 66754,
      "e": 66051,
      "ty": 41,
      "x": 30856,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 66783,
      "e": 66080,
      "ty": 6,
      "x": 902,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66804,
      "e": 66101,
      "ty": 2,
      "x": 901,
      "y": 1037
    },
    {
      "t": 67004,
      "e": 66301,
      "ty": 2,
      "x": 901,
      "y": 1036
    },
    {
      "t": 67005,
      "e": 66302,
      "ty": 41,
      "x": 36890,
      "y": 61563,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67105,
      "e": 66402,
      "ty": 2,
      "x": 900,
      "y": 1032
    },
    {
      "t": 67110,
      "e": 66407,
      "ty": 3,
      "x": 900,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67112,
      "e": 66409,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67112,
      "e": 66409,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67237,
      "e": 66534,
      "ty": 4,
      "x": 36375,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67237,
      "e": 66534,
      "ty": 5,
      "x": 900,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67240,
      "e": 66537,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67241,
      "e": 66538,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67241,
      "e": 66538,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 67254,
      "e": 66551,
      "ty": 41,
      "x": 30718,
      "y": 56726,
      "ta": "html > body"
    },
    {
      "t": 68204,
      "e": 67501,
      "ty": 2,
      "x": 1636,
      "y": 797
    },
    {
      "t": 68304,
      "e": 67601,
      "ty": 2,
      "x": 1919,
      "y": 934
    },
    {
      "t": 68404,
      "e": 67701,
      "ty": 2,
      "x": 1919,
      "y": 1133
    },
    {
      "t": 68505,
      "e": 67802,
      "ty": 2,
      "x": 1919,
      "y": 1169
    },
    {
      "t": 68576,
      "e": 67873,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 68604,
      "e": 67901,
      "ty": 2,
      "x": 1919,
      "y": 1199
    },
    {
      "t": 68755,
      "e": 68052,
      "ty": 41,
      "x": 64880,
      "y": 62654,
      "ta": "> div.masterdiv"
    },
    {
      "t": 68804,
      "e": 68101,
      "ty": 2,
      "x": 1643,
      "y": 997
    },
    {
      "t": 68904,
      "e": 68201,
      "ty": 2,
      "x": 928,
      "y": 738
    },
    {
      "t": 69004,
      "e": 68301,
      "ty": 2,
      "x": 271,
      "y": 452
    },
    {
      "t": 69004,
      "e": 68301,
      "ty": 41,
      "x": 9057,
      "y": 24596,
      "ta": "> div.masterdiv"
    },
    {
      "t": 69105,
      "e": 68402,
      "ty": 2,
      "x": 224,
      "y": 431
    },
    {
      "t": 69205,
      "e": 68502,
      "ty": 2,
      "x": 504,
      "y": 711
    },
    {
      "t": 69254,
      "e": 68551,
      "ty": 41,
      "x": 13752,
      "y": 52047,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69304,
      "e": 68601,
      "ty": 2,
      "x": 599,
      "y": 829
    },
    {
      "t": 69404,
      "e": 68701,
      "ty": 2,
      "x": 676,
      "y": 917
    },
    {
      "t": 69504,
      "e": 68801,
      "ty": 2,
      "x": 828,
      "y": 1042
    },
    {
      "t": 69504,
      "e": 68801,
      "ty": 41,
      "x": 26298,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69604,
      "e": 68901,
      "ty": 2,
      "x": 860,
      "y": 1067
    },
    {
      "t": 69705,
      "e": 69002,
      "ty": 2,
      "x": 869,
      "y": 1041
    },
    {
      "t": 69755,
      "e": 69052,
      "ty": 41,
      "x": 28659,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69805,
      "e": 69102,
      "ty": 2,
      "x": 881,
      "y": 1029
    },
    {
      "t": 69905,
      "e": 69202,
      "ty": 2,
      "x": 886,
      "y": 955
    },
    {
      "t": 70005,
      "e": 69302,
      "ty": 2,
      "x": 837,
      "y": 838
    },
    {
      "t": 70005,
      "e": 69302,
      "ty": 41,
      "x": 26740,
      "y": 46243,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 70005,
      "e": 69302,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70104,
      "e": 69401,
      "ty": 2,
      "x": 820,
      "y": 792
    },
    {
      "t": 70204,
      "e": 69501,
      "ty": 2,
      "x": 824,
      "y": 776
    },
    {
      "t": 70255,
      "e": 69552,
      "ty": 41,
      "x": 26101,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 70304,
      "e": 69601,
      "ty": 2,
      "x": 826,
      "y": 771
    },
    {
      "t": 70404,
      "e": 69701,
      "ty": 2,
      "x": 828,
      "y": 771
    },
    {
      "t": 70505,
      "e": 69802,
      "ty": 41,
      "x": 26298,
      "y": 59985,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 71003,
      "e": 70300,
      "ty": 2,
      "x": 897,
      "y": 833
    },
    {
      "t": 71004,
      "e": 70301,
      "ty": 41,
      "x": 29692,
      "y": 40392,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 71104,
      "e": 70401,
      "ty": 2,
      "x": 1111,
      "y": 1059
    },
    {
      "t": 71255,
      "e": 70552,
      "ty": 41,
      "x": 40811,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71304,
      "e": 70601,
      "ty": 2,
      "x": 1129,
      "y": 1039
    },
    {
      "t": 71504,
      "e": 70801,
      "ty": 2,
      "x": 1120,
      "y": 1044
    },
    {
      "t": 71504,
      "e": 70801,
      "ty": 41,
      "x": 40663,
      "y": 63548,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71604,
      "e": 70901,
      "ty": 2,
      "x": 1125,
      "y": 1035
    },
    {
      "t": 71755,
      "e": 71052,
      "ty": 41,
      "x": 40909,
      "y": 62925,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 72704,
      "e": 72001,
      "ty": 2,
      "x": 1125,
      "y": 1034
    },
    {
      "t": 72755,
      "e": 72052,
      "ty": 41,
      "x": 40909,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73206,
      "e": 72503,
      "ty": 2,
      "x": 1109,
      "y": 1035
    },
    {
      "t": 73255,
      "e": 72552,
      "ty": 41,
      "x": 36678,
      "y": 63479,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73305,
      "e": 72602,
      "ty": 2,
      "x": 1003,
      "y": 1050
    },
    {
      "t": 73404,
      "e": 72701,
      "ty": 2,
      "x": 981,
      "y": 1054
    },
    {
      "t": 73505,
      "e": 72802,
      "ty": 2,
      "x": 971,
      "y": 1055
    },
    {
      "t": 73505,
      "e": 72802,
      "ty": 41,
      "x": 33333,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73604,
      "e": 72901,
      "ty": 2,
      "x": 960,
      "y": 1053
    },
    {
      "t": 73704,
      "e": 73001,
      "ty": 2,
      "x": 951,
      "y": 1050
    },
    {
      "t": 73754,
      "e": 73051,
      "ty": 41,
      "x": 32349,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73904,
      "e": 73201,
      "ty": 2,
      "x": 947,
      "y": 1052
    },
    {
      "t": 74004,
      "e": 73301,
      "ty": 2,
      "x": 947,
      "y": 1057
    },
    {
      "t": 74005,
      "e": 73302,
      "ty": 41,
      "x": 32152,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74104,
      "e": 73401,
      "ty": 2,
      "x": 956,
      "y": 1064
    },
    {
      "t": 74124,
      "e": 73421,
      "ty": 6,
      "x": 965,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 74204,
      "e": 73501,
      "ty": 2,
      "x": 978,
      "y": 1088
    },
    {
      "t": 74254,
      "e": 73551,
      "ty": 41,
      "x": 37409,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 74318,
      "e": 73615,
      "ty": 3,
      "x": 978,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 74318,
      "e": 73615,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74429,
      "e": 73726,
      "ty": 4,
      "x": 37409,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 74431,
      "e": 73728,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74432,
      "e": 73729,
      "ty": 5,
      "x": 978,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 74434,
      "e": 73731,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 74904,
      "e": 74201,
      "ty": 2,
      "x": 975,
      "y": 1086
    },
    {
      "t": 75004,
      "e": 74301,
      "ty": 2,
      "x": 857,
      "y": 1021
    },
    {
      "t": 75005,
      "e": 74302,
      "ty": 41,
      "x": 29237,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 75105,
      "e": 74402,
      "ty": 2,
      "x": 726,
      "y": 968
    },
    {
      "t": 75204,
      "e": 74501,
      "ty": 2,
      "x": 514,
      "y": 888
    },
    {
      "t": 75254,
      "e": 74551,
      "ty": 41,
      "x": 13602,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 75304,
      "e": 74601,
      "ty": 2,
      "x": 339,
      "y": 822
    },
    {
      "t": 75404,
      "e": 74701,
      "ty": 2,
      "x": 309,
      "y": 810
    },
    {
      "t": 75472,
      "e": 74769,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 76577,
      "e": 75874,
      "ty": 2,
      "x": 297,
      "y": 803
    },
    {
      "t": 76577,
      "e": 75874,
      "ty": 41,
      "x": 10384,
      "y": 32801,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 76809,
      "e": 76106,
      "ty": 2,
      "x": 296,
      "y": 803
    },
    {
      "t": 76908,
      "e": 76205,
      "ty": 2,
      "x": 295,
      "y": 802
    },
    {
      "t": 77009,
      "e": 76306,
      "ty": 2,
      "x": 293,
      "y": 801
    },
    {
      "t": 77010,
      "e": 76307,
      "ty": 41,
      "x": 10249,
      "y": 32800,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 77109,
      "e": 76406,
      "ty": 2,
      "x": 290,
      "y": 801
    },
    {
      "t": 77209,
      "e": 76506,
      "ty": 2,
      "x": 281,
      "y": 798
    },
    {
      "t": 77260,
      "e": 76557,
      "ty": 41,
      "x": 9742,
      "y": 32800,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 77308,
      "e": 76605,
      "ty": 2,
      "x": 276,
      "y": 796
    },
    {
      "t": 77409,
      "e": 76706,
      "ty": 2,
      "x": 273,
      "y": 795
    },
    {
      "t": 77481,
      "e": 76778,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 62046, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 62051, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4107, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 67516, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13982, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 82504, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 36386, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 119982, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11571, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 132555, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 82194, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 216144, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-C -11 AM-A -A -A -A -C -I -J -J -O -H -H -Z -Z -12 PM-01 PM-02 PM-03 PM-04 PM-06 PM-02 PM-A -A -A -F -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:717,y:259,t:1528139518922};\\\", \\\"{x:721,y:255,t:1528139518930};\\\", \\\"{x:728,y:248,t:1528139518941};\\\", \\\"{x:739,y:235,t:1528139518957};\\\", \\\"{x:753,y:221,t:1528139518974};\\\", \\\"{x:763,y:214,t:1528139518992};\\\", \\\"{x:775,y:205,t:1528139519006};\\\", \\\"{x:790,y:195,t:1528139519024};\\\", \\\"{x:807,y:185,t:1528139519041};\\\", \\\"{x:829,y:174,t:1528139519057};\\\", \\\"{x:861,y:158,t:1528139519073};\\\", \\\"{x:880,y:148,t:1528139519091};\\\", \\\"{x:905,y:135,t:1528139519107};\\\", \\\"{x:932,y:119,t:1528139519124};\\\", \\\"{x:960,y:108,t:1528139519141};\\\", \\\"{x:991,y:99,t:1528139519157};\\\", \\\"{x:1028,y:88,t:1528139519173};\\\", \\\"{x:1074,y:79,t:1528139519190};\\\", \\\"{x:1122,y:72,t:1528139519207};\\\", \\\"{x:1179,y:69,t:1528139519224};\\\", \\\"{x:1291,y:65,t:1528139519241};\\\", \\\"{x:1385,y:65,t:1528139519257};\\\", \\\"{x:1496,y:65,t:1528139519274};\\\", \\\"{x:1582,y:55,t:1528139519291};\\\", \\\"{x:1702,y:33,t:1528139519307};\\\", \\\"{x:1823,y:0,t:1528139519324};\\\", \\\"{x:1919,y:0,t:1528139519341};\\\", \\\"{x:1919,y:3,t:1528139519377};\\\", \\\"{x:1919,y:16,t:1528139519391};\\\", \\\"{x:1919,y:58,t:1528139519407};\\\", \\\"{x:1919,y:97,t:1528139519425};\\\", \\\"{x:1919,y:132,t:1528139519441};\\\", \\\"{x:1919,y:174,t:1528139519457};\\\", \\\"{x:1919,y:202,t:1528139519474};\\\", \\\"{x:1919,y:226,t:1528139519490};\\\", \\\"{x:1919,y:248,t:1528139519508};\\\", \\\"{x:1919,y:273,t:1528139519524};\\\", \\\"{x:1919,y:293,t:1528139519540};\\\", \\\"{x:1919,y:305,t:1528139519558};\\\", \\\"{x:1919,y:320,t:1528139519575};\\\", \\\"{x:1919,y:337,t:1528139519591};\\\", \\\"{x:1919,y:354,t:1528139519607};\\\", \\\"{x:1919,y:364,t:1528139519625};\\\", \\\"{x:1917,y:351,t:1528139519874};\\\", \\\"{x:1891,y:312,t:1528139519892};\\\", \\\"{x:1866,y:278,t:1528139519908};\\\", \\\"{x:1828,y:234,t:1528139519926};\\\", \\\"{x:1761,y:168,t:1528139519942};\\\", \\\"{x:1660,y:86,t:1528139519957};\\\", \\\"{x:1530,y:0,t:1528139519975};\\\", \\\"{x:1384,y:0,t:1528139519992};\\\", \\\"{x:1236,y:0,t:1528139520007};\\\", \\\"{x:1082,y:0,t:1528139520024};\\\", \\\"{x:860,y:0,t:1528139520041};\\\", \\\"{x:712,y:0,t:1528139520057};\\\", \\\"{x:562,y:0,t:1528139520074};\\\", \\\"{x:410,y:0,t:1528139520091};\\\", \\\"{x:263,y:0,t:1528139520107};\\\", \\\"{x:120,y:0,t:1528139520125};\\\", \\\"{x:0,y:0,t:1528139520141};\\\", \\\"{x:0,y:1,t:1528139520281};\\\", \\\"{x:0,y:2,t:1528139520297};\\\", \\\"{x:0,y:4,t:1528139520308};\\\", \\\"{x:0,y:6,t:1528139520324};\\\", \\\"{x:0,y:9,t:1528139520342};\\\", \\\"{x:0,y:10,t:1528139520358};\\\", \\\"{x:0,y:12,t:1528139520375};\\\", \\\"{x:0,y:15,t:1528139520392};\\\", \\\"{x:0,y:16,t:1528139520417};\\\", \\\"{x:0,y:17,t:1528139520466};\\\", \\\"{x:0,y:18,t:1528139520475};\\\", \\\"{x:0,y:19,t:1528139520493};\\\", \\\"{x:0,y:20,t:1528139520510};\\\", \\\"{x:0,y:23,t:1528139520525};\\\", \\\"{x:0,y:25,t:1528139520542};\\\", \\\"{x:0,y:28,t:1528139520559};\\\", \\\"{x:0,y:38,t:1528139520575};\\\", \\\"{x:0,y:48,t:1528139520593};\\\", \\\"{x:2,y:62,t:1528139520609};\\\", \\\"{x:15,y:72,t:1528139520625};\\\", \\\"{x:38,y:83,t:1528139520642};\\\", \\\"{x:63,y:94,t:1528139520659};\\\", \\\"{x:91,y:104,t:1528139520675};\\\", \\\"{x:135,y:114,t:1528139520692};\\\", \\\"{x:182,y:133,t:1528139520710};\\\", \\\"{x:222,y:149,t:1528139520725};\\\", \\\"{x:265,y:164,t:1528139520742};\\\", \\\"{x:316,y:180,t:1528139520759};\\\", \\\"{x:374,y:196,t:1528139520775};\\\", \\\"{x:445,y:222,t:1528139520792};\\\", \\\"{x:520,y:242,t:1528139520808};\\\", \\\"{x:594,y:262,t:1528139520825};\\\", \\\"{x:714,y:295,t:1528139520842};\\\", \\\"{x:786,y:317,t:1528139520859};\\\", \\\"{x:861,y:337,t:1528139520875};\\\", \\\"{x:930,y:357,t:1528139520892};\\\", \\\"{x:994,y:376,t:1528139520909};\\\", \\\"{x:1045,y:392,t:1528139520926};\\\", \\\"{x:1098,y:406,t:1528139520941};\\\", \\\"{x:1131,y:415,t:1528139520959};\\\", \\\"{x:1162,y:424,t:1528139520976};\\\", \\\"{x:1193,y:434,t:1528139520992};\\\", \\\"{x:1212,y:439,t:1528139521009};\\\", \\\"{x:1228,y:444,t:1528139521026};\\\", \\\"{x:1231,y:445,t:1528139521042};\\\", \\\"{x:1233,y:446,t:1528139521059};\\\", \\\"{x:1233,y:447,t:1528139521148};\\\", \\\"{x:1233,y:448,t:1528139521159};\\\", \\\"{x:1230,y:450,t:1528139521176};\\\", \\\"{x:1227,y:451,t:1528139521193};\\\", \\\"{x:1226,y:452,t:1528139521209};\\\", \\\"{x:1224,y:454,t:1528139521226};\\\", \\\"{x:1224,y:455,t:1528139521379};\\\", \\\"{x:1224,y:457,t:1528139521393};\\\", \\\"{x:1227,y:464,t:1528139521409};\\\", \\\"{x:1234,y:471,t:1528139521426};\\\", \\\"{x:1244,y:481,t:1528139521443};\\\", \\\"{x:1257,y:490,t:1528139521459};\\\", \\\"{x:1272,y:500,t:1528139521476};\\\", \\\"{x:1290,y:508,t:1528139521494};\\\", \\\"{x:1306,y:518,t:1528139521509};\\\", \\\"{x:1322,y:527,t:1528139521526};\\\", \\\"{x:1336,y:532,t:1528139521543};\\\", \\\"{x:1352,y:539,t:1528139521559};\\\", \\\"{x:1368,y:545,t:1528139521576};\\\", \\\"{x:1384,y:550,t:1528139521593};\\\", \\\"{x:1400,y:554,t:1528139521609};\\\", \\\"{x:1421,y:560,t:1528139521626};\\\", \\\"{x:1436,y:564,t:1528139521643};\\\", \\\"{x:1451,y:570,t:1528139521659};\\\", \\\"{x:1463,y:572,t:1528139521675};\\\", \\\"{x:1475,y:576,t:1528139521693};\\\", \\\"{x:1480,y:579,t:1528139521708};\\\", \\\"{x:1484,y:580,t:1528139521725};\\\", \\\"{x:1487,y:581,t:1528139521743};\\\", \\\"{x:1487,y:582,t:1528139521759};\\\", \\\"{x:1487,y:583,t:1528139521874};\\\", \\\"{x:1485,y:583,t:1528139521882};\\\", \\\"{x:1482,y:585,t:1528139521893};\\\", \\\"{x:1475,y:586,t:1528139521911};\\\", \\\"{x:1460,y:587,t:1528139521926};\\\", \\\"{x:1439,y:587,t:1528139521943};\\\", \\\"{x:1415,y:587,t:1528139521960};\\\", \\\"{x:1388,y:587,t:1528139521976};\\\", \\\"{x:1329,y:587,t:1528139521993};\\\", \\\"{x:1192,y:570,t:1528139522010};\\\", \\\"{x:1075,y:552,t:1528139522026};\\\", \\\"{x:902,y:514,t:1528139522044};\\\", \\\"{x:680,y:462,t:1528139522060};\\\", \\\"{x:407,y:395,t:1528139522076};\\\", \\\"{x:107,y:317,t:1528139522093};\\\", \\\"{x:0,y:239,t:1528139522110};\\\", \\\"{x:0,y:181,t:1528139522126};\\\", \\\"{x:0,y:149,t:1528139522143};\\\", \\\"{x:0,y:135,t:1528139522160};\\\", \\\"{x:0,y:129,t:1528139522176};\\\", \\\"{x:4,y:129,t:1528139522386};\\\", \\\"{x:9,y:129,t:1528139522394};\\\", \\\"{x:18,y:129,t:1528139522410};\\\", \\\"{x:37,y:133,t:1528139522427};\\\", \\\"{x:63,y:136,t:1528139522443};\\\", \\\"{x:95,y:143,t:1528139522460};\\\", \\\"{x:142,y:155,t:1528139522477};\\\", \\\"{x:197,y:170,t:1528139522493};\\\", \\\"{x:253,y:186,t:1528139522510};\\\", \\\"{x:306,y:202,t:1528139522527};\\\", \\\"{x:346,y:213,t:1528139522543};\\\", \\\"{x:367,y:220,t:1528139522560};\\\", \\\"{x:384,y:227,t:1528139522577};\\\", \\\"{x:400,y:236,t:1528139522593};\\\", \\\"{x:407,y:241,t:1528139522610};\\\", \\\"{x:410,y:243,t:1528139522627};\\\", \\\"{x:411,y:244,t:1528139522643};\\\", \\\"{x:414,y:248,t:1528139522660};\\\", \\\"{x:418,y:256,t:1528139522678};\\\", \\\"{x:423,y:269,t:1528139522693};\\\", \\\"{x:431,y:284,t:1528139522710};\\\", \\\"{x:437,y:297,t:1528139522727};\\\", \\\"{x:442,y:311,t:1528139522743};\\\", \\\"{x:450,y:331,t:1528139522761};\\\", \\\"{x:455,y:352,t:1528139522777};\\\", \\\"{x:461,y:382,t:1528139522794};\\\", \\\"{x:463,y:394,t:1528139522810};\\\", \\\"{x:465,y:403,t:1528139522828};\\\", \\\"{x:467,y:410,t:1528139522844};\\\", \\\"{x:468,y:414,t:1528139522860};\\\", \\\"{x:469,y:416,t:1528139522877};\\\", \\\"{x:470,y:417,t:1528139522930};\\\", \\\"{x:470,y:418,t:1528139522947};\\\", \\\"{x:470,y:420,t:1528139522962};\\\", \\\"{x:470,y:421,t:1528139522985};\\\", \\\"{x:471,y:424,t:1528139522994};\\\", \\\"{x:473,y:429,t:1528139523011};\\\", \\\"{x:475,y:433,t:1528139523027};\\\", \\\"{x:478,y:439,t:1528139523045};\\\", \\\"{x:482,y:444,t:1528139523060};\\\", \\\"{x:487,y:448,t:1528139523077};\\\", \\\"{x:492,y:452,t:1528139523094};\\\", \\\"{x:498,y:456,t:1528139523110};\\\", \\\"{x:507,y:460,t:1528139523127};\\\", \\\"{x:520,y:463,t:1528139523144};\\\", \\\"{x:537,y:467,t:1528139523160};\\\", \\\"{x:558,y:474,t:1528139523177};\\\", \\\"{x:579,y:483,t:1528139523194};\\\", \\\"{x:595,y:490,t:1528139523209};\\\", \\\"{x:613,y:497,t:1528139523226};\\\", \\\"{x:636,y:503,t:1528139523244};\\\", \\\"{x:661,y:510,t:1528139523260};\\\", \\\"{x:692,y:515,t:1528139523277};\\\", \\\"{x:736,y:519,t:1528139523294};\\\", \\\"{x:785,y:530,t:1528139523310};\\\", \\\"{x:836,y:537,t:1528139523326};\\\", \\\"{x:885,y:542,t:1528139523344};\\\", \\\"{x:966,y:554,t:1528139523361};\\\", \\\"{x:1006,y:561,t:1528139523376};\\\", \\\"{x:1042,y:571,t:1528139523393};\\\", \\\"{x:1068,y:579,t:1528139523410};\\\", \\\"{x:1092,y:586,t:1528139523427};\\\", \\\"{x:1109,y:591,t:1528139523443};\\\", \\\"{x:1121,y:593,t:1528139523461};\\\", \\\"{x:1130,y:597,t:1528139523478};\\\", \\\"{x:1137,y:597,t:1528139523493};\\\", \\\"{x:1145,y:600,t:1528139523511};\\\", \\\"{x:1154,y:601,t:1528139523528};\\\", \\\"{x:1163,y:604,t:1528139523543};\\\", \\\"{x:1183,y:609,t:1528139523561};\\\", \\\"{x:1192,y:610,t:1528139523577};\\\", \\\"{x:1199,y:611,t:1528139523594};\\\", \\\"{x:1210,y:615,t:1528139523611};\\\", \\\"{x:1223,y:619,t:1528139523628};\\\", \\\"{x:1233,y:621,t:1528139523644};\\\", \\\"{x:1244,y:624,t:1528139523661};\\\", \\\"{x:1256,y:628,t:1528139523678};\\\", \\\"{x:1268,y:629,t:1528139523694};\\\", \\\"{x:1282,y:632,t:1528139523710};\\\", \\\"{x:1292,y:635,t:1528139523728};\\\", \\\"{x:1311,y:641,t:1528139523745};\\\", \\\"{x:1319,y:642,t:1528139523761};\\\", \\\"{x:1328,y:644,t:1528139523778};\\\", \\\"{x:1336,y:645,t:1528139523795};\\\", \\\"{x:1345,y:647,t:1528139523811};\\\", \\\"{x:1352,y:647,t:1528139523828};\\\", \\\"{x:1358,y:647,t:1528139523845};\\\", \\\"{x:1361,y:647,t:1528139523860};\\\", \\\"{x:1365,y:647,t:1528139523877};\\\", \\\"{x:1368,y:644,t:1528139523895};\\\", \\\"{x:1371,y:644,t:1528139523910};\\\", \\\"{x:1376,y:642,t:1528139523928};\\\", \\\"{x:1385,y:641,t:1528139523947};\\\", \\\"{x:1397,y:641,t:1528139523962};\\\", \\\"{x:1412,y:641,t:1528139523978};\\\", \\\"{x:1427,y:641,t:1528139523995};\\\", \\\"{x:1442,y:641,t:1528139524012};\\\", \\\"{x:1456,y:641,t:1528139524028};\\\", \\\"{x:1466,y:641,t:1528139524045};\\\", \\\"{x:1470,y:641,t:1528139524063};\\\", \\\"{x:1472,y:641,t:1528139524078};\\\", \\\"{x:1473,y:641,t:1528139524096};\\\", \\\"{x:1470,y:641,t:1528139524171};\\\", \\\"{x:1463,y:641,t:1528139524178};\\\", \\\"{x:1444,y:641,t:1528139524195};\\\", \\\"{x:1416,y:641,t:1528139524212};\\\", \\\"{x:1390,y:641,t:1528139524228};\\\", \\\"{x:1364,y:643,t:1528139524245};\\\", \\\"{x:1335,y:643,t:1528139524263};\\\", \\\"{x:1293,y:643,t:1528139524278};\\\", \\\"{x:1240,y:643,t:1528139524295};\\\", \\\"{x:1190,y:643,t:1528139524313};\\\", \\\"{x:1137,y:643,t:1528139524328};\\\", \\\"{x:1050,y:643,t:1528139524346};\\\", \\\"{x:1006,y:640,t:1528139524361};\\\", \\\"{x:955,y:636,t:1528139524379};\\\", \\\"{x:926,y:633,t:1528139524397};\\\", \\\"{x:911,y:631,t:1528139524412};\\\", \\\"{x:900,y:628,t:1528139524427};\\\", \\\"{x:890,y:627,t:1528139524445};\\\", \\\"{x:875,y:625,t:1528139524462};\\\", \\\"{x:862,y:623,t:1528139524478};\\\", \\\"{x:850,y:622,t:1528139524494};\\\", \\\"{x:836,y:622,t:1528139524512};\\\", \\\"{x:798,y:622,t:1528139524529};\\\", \\\"{x:762,y:615,t:1528139524546};\\\", \\\"{x:714,y:608,t:1528139524562};\\\", \\\"{x:669,y:602,t:1528139524579};\\\", \\\"{x:611,y:589,t:1528139524595};\\\", \\\"{x:558,y:573,t:1528139524612};\\\", \\\"{x:505,y:556,t:1528139524629};\\\", \\\"{x:445,y:541,t:1528139524645};\\\", \\\"{x:404,y:525,t:1528139524661};\\\", \\\"{x:379,y:514,t:1528139524679};\\\", \\\"{x:357,y:504,t:1528139524694};\\\", \\\"{x:335,y:496,t:1528139524711};\\\", \\\"{x:313,y:486,t:1528139524729};\\\", \\\"{x:310,y:485,t:1528139524746};\\\", \\\"{x:310,y:484,t:1528139524890};\\\", \\\"{x:311,y:483,t:1528139524897};\\\", \\\"{x:314,y:481,t:1528139524913};\\\", \\\"{x:317,y:481,t:1528139524929};\\\", \\\"{x:321,y:481,t:1528139524947};\\\", \\\"{x:328,y:481,t:1528139524963};\\\", \\\"{x:338,y:481,t:1528139524979};\\\", \\\"{x:352,y:483,t:1528139524996};\\\", \\\"{x:373,y:488,t:1528139525013};\\\", \\\"{x:392,y:495,t:1528139525030};\\\", \\\"{x:406,y:499,t:1528139525045};\\\", \\\"{x:419,y:504,t:1528139525063};\\\", \\\"{x:427,y:507,t:1528139525080};\\\", \\\"{x:434,y:509,t:1528139525096};\\\", \\\"{x:441,y:511,t:1528139525113};\\\", \\\"{x:442,y:511,t:1528139525130};\\\", \\\"{x:445,y:511,t:1528139525147};\\\", \\\"{x:446,y:512,t:1528139525163};\\\", \\\"{x:449,y:512,t:1528139525180};\\\", \\\"{x:453,y:514,t:1528139525197};\\\", \\\"{x:460,y:516,t:1528139525214};\\\", \\\"{x:463,y:517,t:1528139525230};\\\", \\\"{x:471,y:519,t:1528139525247};\\\", \\\"{x:478,y:520,t:1528139525263};\\\", \\\"{x:490,y:524,t:1528139525280};\\\", \\\"{x:509,y:529,t:1528139525297};\\\", \\\"{x:525,y:534,t:1528139525313};\\\", \\\"{x:548,y:539,t:1528139525331};\\\", \\\"{x:574,y:542,t:1528139525348};\\\", \\\"{x:602,y:548,t:1528139525363};\\\", \\\"{x:641,y:559,t:1528139525378};\\\", \\\"{x:698,y:570,t:1528139525395};\\\", \\\"{x:793,y:586,t:1528139525411};\\\", \\\"{x:924,y:611,t:1528139525428};\\\", \\\"{x:1068,y:653,t:1528139525445};\\\", \\\"{x:1244,y:695,t:1528139525463};\\\", \\\"{x:1424,y:750,t:1528139525478};\\\", \\\"{x:1609,y:807,t:1528139525496};\\\", \\\"{x:1873,y:894,t:1528139525513};\\\", \\\"{x:1919,y:953,t:1528139525528};\\\", \\\"{x:1919,y:994,t:1528139525546};\\\", \\\"{x:1919,y:1022,t:1528139525563};\\\", \\\"{x:1919,y:1033,t:1528139525579};\\\", \\\"{x:1919,y:1036,t:1528139525595};\\\", \\\"{x:1917,y:1036,t:1528139525698};\\\", \\\"{x:1913,y:1036,t:1528139525714};\\\", \\\"{x:1911,y:1036,t:1528139525730};\\\", \\\"{x:1901,y:1036,t:1528139525747};\\\", \\\"{x:1887,y:1036,t:1528139525763};\\\", \\\"{x:1870,y:1036,t:1528139525779};\\\", \\\"{x:1857,y:1036,t:1528139525795};\\\", \\\"{x:1846,y:1036,t:1528139525813};\\\", \\\"{x:1832,y:1036,t:1528139525830};\\\", \\\"{x:1821,y:1036,t:1528139525846};\\\", \\\"{x:1807,y:1036,t:1528139525863};\\\", \\\"{x:1790,y:1035,t:1528139525879};\\\", \\\"{x:1777,y:1033,t:1528139525895};\\\", \\\"{x:1752,y:1030,t:1528139525913};\\\", \\\"{x:1732,y:1028,t:1528139525929};\\\", \\\"{x:1705,y:1023,t:1528139525946};\\\", \\\"{x:1665,y:1015,t:1528139525963};\\\", \\\"{x:1618,y:1001,t:1528139525979};\\\", \\\"{x:1570,y:987,t:1528139525996};\\\", \\\"{x:1522,y:972,t:1528139526012};\\\", \\\"{x:1463,y:952,t:1528139526030};\\\", \\\"{x:1401,y:931,t:1528139526046};\\\", \\\"{x:1345,y:905,t:1528139526063};\\\", \\\"{x:1291,y:884,t:1528139526080};\\\", \\\"{x:1214,y:850,t:1528139526096};\\\", \\\"{x:1170,y:830,t:1528139526113};\\\", \\\"{x:1133,y:810,t:1528139526130};\\\", \\\"{x:1097,y:795,t:1528139526146};\\\", \\\"{x:1077,y:784,t:1528139526162};\\\", \\\"{x:1063,y:777,t:1528139526180};\\\", \\\"{x:1050,y:769,t:1528139526197};\\\", \\\"{x:1041,y:764,t:1528139526213};\\\", \\\"{x:1037,y:761,t:1528139526230};\\\", \\\"{x:1035,y:760,t:1528139526247};\\\", \\\"{x:1032,y:759,t:1528139526262};\\\", \\\"{x:1031,y:758,t:1528139526280};\\\", \\\"{x:1030,y:758,t:1528139526297};\\\", \\\"{x:1030,y:757,t:1528139526362};\\\", \\\"{x:1028,y:756,t:1528139526378};\\\", \\\"{x:1028,y:754,t:1528139526385};\\\", \\\"{x:1027,y:752,t:1528139526401};\\\", \\\"{x:1026,y:750,t:1528139526418};\\\", \\\"{x:1026,y:748,t:1528139526430};\\\", \\\"{x:1025,y:745,t:1528139526447};\\\", \\\"{x:1025,y:742,t:1528139526464};\\\", \\\"{x:1025,y:738,t:1528139526480};\\\", \\\"{x:1024,y:729,t:1528139526497};\\\", \\\"{x:1023,y:723,t:1528139526514};\\\", \\\"{x:1023,y:719,t:1528139526530};\\\", \\\"{x:1023,y:715,t:1528139526546};\\\", \\\"{x:1023,y:712,t:1528139526564};\\\", \\\"{x:1024,y:707,t:1528139526580};\\\", \\\"{x:1026,y:700,t:1528139526596};\\\", \\\"{x:1030,y:690,t:1528139526614};\\\", \\\"{x:1033,y:685,t:1528139526629};\\\", \\\"{x:1035,y:681,t:1528139526647};\\\", \\\"{x:1035,y:678,t:1528139526663};\\\", \\\"{x:1037,y:675,t:1528139526679};\\\", \\\"{x:1039,y:666,t:1528139526697};\\\", \\\"{x:1042,y:657,t:1528139526713};\\\", \\\"{x:1047,y:644,t:1528139526730};\\\", \\\"{x:1052,y:634,t:1528139526747};\\\", \\\"{x:1056,y:626,t:1528139526764};\\\", \\\"{x:1060,y:619,t:1528139526782};\\\", \\\"{x:1064,y:612,t:1528139526797};\\\", \\\"{x:1068,y:603,t:1528139526814};\\\", \\\"{x:1069,y:599,t:1528139526831};\\\", \\\"{x:1070,y:597,t:1528139526847};\\\", \\\"{x:1074,y:601,t:1528139527513};\\\", \\\"{x:1077,y:608,t:1528139527521};\\\", \\\"{x:1082,y:616,t:1528139527531};\\\", \\\"{x:1089,y:631,t:1528139527548};\\\", \\\"{x:1099,y:652,t:1528139527565};\\\", \\\"{x:1110,y:673,t:1528139527581};\\\", \\\"{x:1122,y:694,t:1528139527598};\\\", \\\"{x:1142,y:725,t:1528139527615};\\\", \\\"{x:1158,y:746,t:1528139527631};\\\", \\\"{x:1178,y:770,t:1528139527648};\\\", \\\"{x:1194,y:793,t:1528139527665};\\\", \\\"{x:1205,y:811,t:1528139527681};\\\", \\\"{x:1215,y:828,t:1528139527702};\\\", \\\"{x:1222,y:847,t:1528139527715};\\\", \\\"{x:1231,y:886,t:1528139527747};\\\", \\\"{x:1232,y:901,t:1528139527764};\\\", \\\"{x:1233,y:915,t:1528139527781};\\\", \\\"{x:1235,y:919,t:1528139527798};\\\", \\\"{x:1235,y:921,t:1528139527813};\\\", \\\"{x:1236,y:922,t:1528139527831};\\\", \\\"{x:1236,y:924,t:1528139527897};\\\", \\\"{x:1236,y:927,t:1528139527914};\\\", \\\"{x:1236,y:929,t:1528139527931};\\\", \\\"{x:1236,y:932,t:1528139527947};\\\", \\\"{x:1236,y:938,t:1528139527963};\\\", \\\"{x:1237,y:946,t:1528139527981};\\\", \\\"{x:1241,y:953,t:1528139527998};\\\", \\\"{x:1244,y:958,t:1528139528014};\\\", \\\"{x:1245,y:960,t:1528139528031};\\\", \\\"{x:1247,y:962,t:1528139528048};\\\", \\\"{x:1250,y:966,t:1528139528064};\\\", \\\"{x:1254,y:970,t:1528139528081};\\\", \\\"{x:1256,y:971,t:1528139528098};\\\", \\\"{x:1257,y:972,t:1528139528129};\\\", \\\"{x:1257,y:973,t:1528139528147};\\\", \\\"{x:1258,y:973,t:1528139528161};\\\", \\\"{x:1260,y:973,t:1528139528186};\\\", \\\"{x:1261,y:974,t:1528139528201};\\\", \\\"{x:1262,y:974,t:1528139528243};\\\", \\\"{x:1265,y:974,t:1528139528250};\\\", \\\"{x:1268,y:974,t:1528139528265};\\\", \\\"{x:1279,y:974,t:1528139528281};\\\", \\\"{x:1284,y:974,t:1528139528298};\\\", \\\"{x:1288,y:974,t:1528139528315};\\\", \\\"{x:1290,y:974,t:1528139528331};\\\", \\\"{x:1289,y:974,t:1528139528866};\\\", \\\"{x:1288,y:974,t:1528139528882};\\\", \\\"{x:1287,y:974,t:1528139528899};\\\", \\\"{x:1286,y:974,t:1528139528922};\\\", \\\"{x:1285,y:974,t:1528139528962};\\\", \\\"{x:1284,y:974,t:1528139529393};\\\", \\\"{x:1285,y:972,t:1528139529458};\\\", \\\"{x:1287,y:970,t:1528139529489};\\\", \\\"{x:1288,y:970,t:1528139529529};\\\", \\\"{x:1290,y:970,t:1528139529570};\\\", \\\"{x:1291,y:970,t:1528139529583};\\\", \\\"{x:1295,y:970,t:1528139529600};\\\", \\\"{x:1297,y:971,t:1528139529615};\\\", \\\"{x:1298,y:972,t:1528139529633};\\\", \\\"{x:1301,y:974,t:1528139529650};\\\", \\\"{x:1301,y:975,t:1528139529906};\\\", \\\"{x:1299,y:975,t:1528139529916};\\\", \\\"{x:1295,y:975,t:1528139529933};\\\", \\\"{x:1290,y:975,t:1528139529949};\\\", \\\"{x:1285,y:975,t:1528139529967};\\\", \\\"{x:1284,y:974,t:1528139529986};\\\", \\\"{x:1283,y:974,t:1528139530050};\\\", \\\"{x:1283,y:971,t:1528139531090};\\\", \\\"{x:1283,y:968,t:1528139531101};\\\", \\\"{x:1283,y:967,t:1528139531117};\\\", \\\"{x:1283,y:965,t:1528139531134};\\\", \\\"{x:1283,y:963,t:1528139531151};\\\", \\\"{x:1283,y:962,t:1528139531166};\\\", \\\"{x:1282,y:960,t:1528139531183};\\\", \\\"{x:1282,y:957,t:1528139531200};\\\", \\\"{x:1282,y:955,t:1528139531216};\\\", \\\"{x:1281,y:946,t:1528139531233};\\\", \\\"{x:1280,y:937,t:1528139531250};\\\", \\\"{x:1279,y:933,t:1528139531266};\\\", \\\"{x:1279,y:931,t:1528139531283};\\\", \\\"{x:1279,y:929,t:1528139531300};\\\", \\\"{x:1279,y:928,t:1528139531316};\\\", \\\"{x:1279,y:925,t:1528139531333};\\\", \\\"{x:1279,y:922,t:1528139531350};\\\", \\\"{x:1279,y:919,t:1528139531366};\\\", \\\"{x:1279,y:915,t:1528139531383};\\\", \\\"{x:1279,y:912,t:1528139531400};\\\", \\\"{x:1279,y:898,t:1528139531417};\\\", \\\"{x:1278,y:885,t:1528139531433};\\\", \\\"{x:1278,y:882,t:1528139531450};\\\", \\\"{x:1278,y:878,t:1528139531467};\\\", \\\"{x:1278,y:875,t:1528139531483};\\\", \\\"{x:1278,y:873,t:1528139531501};\\\", \\\"{x:1278,y:871,t:1528139531517};\\\", \\\"{x:1278,y:869,t:1528139531533};\\\", \\\"{x:1278,y:866,t:1528139531550};\\\", \\\"{x:1279,y:864,t:1528139531567};\\\", \\\"{x:1279,y:861,t:1528139531583};\\\", \\\"{x:1280,y:859,t:1528139531600};\\\", \\\"{x:1282,y:854,t:1528139531617};\\\", \\\"{x:1283,y:851,t:1528139531633};\\\", \\\"{x:1283,y:849,t:1528139531657};\\\", \\\"{x:1283,y:848,t:1528139531668};\\\", \\\"{x:1283,y:846,t:1528139531683};\\\", \\\"{x:1283,y:843,t:1528139531700};\\\", \\\"{x:1283,y:841,t:1528139531718};\\\", \\\"{x:1283,y:840,t:1528139531737};\\\", \\\"{x:1282,y:839,t:1528139531938};\\\", \\\"{x:1281,y:838,t:1528139531952};\\\", \\\"{x:1280,y:838,t:1528139531967};\\\", \\\"{x:1278,y:836,t:1528139531984};\\\", \\\"{x:1275,y:834,t:1528139532000};\\\", \\\"{x:1272,y:832,t:1528139532017};\\\", \\\"{x:1273,y:832,t:1528139532370};\\\", \\\"{x:1274,y:832,t:1528139532385};\\\", \\\"{x:1275,y:832,t:1528139532401};\\\", \\\"{x:1277,y:832,t:1528139532422};\\\", \\\"{x:1279,y:833,t:1528139532451};\\\", \\\"{x:1281,y:848,t:1528139535077};\\\", \\\"{x:1281,y:879,t:1528139535096};\\\", \\\"{x:1280,y:895,t:1528139535112};\\\", \\\"{x:1280,y:912,t:1528139535129};\\\", \\\"{x:1280,y:931,t:1528139535146};\\\", \\\"{x:1280,y:941,t:1528139535163};\\\", \\\"{x:1280,y:946,t:1528139535180};\\\", \\\"{x:1280,y:951,t:1528139535197};\\\", \\\"{x:1279,y:955,t:1528139535214};\\\", \\\"{x:1279,y:960,t:1528139535230};\\\", \\\"{x:1279,y:965,t:1528139535246};\\\", \\\"{x:1279,y:968,t:1528139535264};\\\", \\\"{x:1279,y:967,t:1528139535556};\\\", \\\"{x:1279,y:966,t:1528139535564};\\\", \\\"{x:1279,y:964,t:1528139535581};\\\", \\\"{x:1279,y:963,t:1528139535597};\\\", \\\"{x:1279,y:962,t:1528139535619};\\\", \\\"{x:1279,y:961,t:1528139535651};\\\", \\\"{x:1279,y:960,t:1528139535664};\\\", \\\"{x:1279,y:959,t:1528139535691};\\\", \\\"{x:1279,y:958,t:1528139535706};\\\", \\\"{x:1280,y:956,t:1528139535723};\\\", \\\"{x:1280,y:955,t:1528139535756};\\\", \\\"{x:1280,y:954,t:1528139535764};\\\", \\\"{x:1280,y:951,t:1528139535781};\\\", \\\"{x:1280,y:948,t:1528139535797};\\\", \\\"{x:1280,y:942,t:1528139535814};\\\", \\\"{x:1281,y:934,t:1528139535831};\\\", \\\"{x:1282,y:930,t:1528139535846};\\\", \\\"{x:1283,y:925,t:1528139535864};\\\", \\\"{x:1283,y:922,t:1528139535881};\\\", \\\"{x:1283,y:920,t:1528139535896};\\\", \\\"{x:1283,y:915,t:1528139535914};\\\", \\\"{x:1283,y:908,t:1528139535930};\\\", \\\"{x:1283,y:902,t:1528139535946};\\\", \\\"{x:1284,y:899,t:1528139535963};\\\", \\\"{x:1286,y:894,t:1528139535981};\\\", \\\"{x:1287,y:890,t:1528139535996};\\\", \\\"{x:1289,y:887,t:1528139536014};\\\", \\\"{x:1290,y:884,t:1528139536031};\\\", \\\"{x:1290,y:880,t:1528139536047};\\\", \\\"{x:1292,y:878,t:1528139536064};\\\", \\\"{x:1292,y:876,t:1528139536081};\\\", \\\"{x:1292,y:875,t:1528139536097};\\\", \\\"{x:1292,y:874,t:1528139536114};\\\", \\\"{x:1292,y:871,t:1528139536131};\\\", \\\"{x:1292,y:869,t:1528139536148};\\\", \\\"{x:1292,y:867,t:1528139536164};\\\", \\\"{x:1292,y:866,t:1528139536181};\\\", \\\"{x:1292,y:865,t:1528139536227};\\\", \\\"{x:1292,y:864,t:1528139536235};\\\", \\\"{x:1292,y:863,t:1528139536251};\\\", \\\"{x:1292,y:862,t:1528139536267};\\\", \\\"{x:1292,y:861,t:1528139536283};\\\", \\\"{x:1292,y:860,t:1528139536298};\\\", \\\"{x:1291,y:858,t:1528139536323};\\\", \\\"{x:1291,y:857,t:1528139536356};\\\", \\\"{x:1291,y:855,t:1528139536371};\\\", \\\"{x:1291,y:854,t:1528139536381};\\\", \\\"{x:1291,y:851,t:1528139536398};\\\", \\\"{x:1292,y:849,t:1528139536414};\\\", \\\"{x:1292,y:848,t:1528139536431};\\\", \\\"{x:1292,y:847,t:1528139536448};\\\", \\\"{x:1292,y:845,t:1528139536464};\\\", \\\"{x:1292,y:844,t:1528139536491};\\\", \\\"{x:1292,y:843,t:1528139536523};\\\", \\\"{x:1292,y:842,t:1528139536562};\\\", \\\"{x:1292,y:841,t:1528139536699};\\\", \\\"{x:1291,y:840,t:1528139536715};\\\", \\\"{x:1290,y:840,t:1528139536771};\\\", \\\"{x:1289,y:840,t:1528139536781};\\\", \\\"{x:1289,y:839,t:1528139536835};\\\", \\\"{x:1288,y:838,t:1528139536859};\\\", \\\"{x:1288,y:837,t:1528139536874};\\\", \\\"{x:1288,y:836,t:1528139536891};\\\", \\\"{x:1287,y:836,t:1528139536915};\\\", \\\"{x:1286,y:835,t:1528139537116};\\\", \\\"{x:1285,y:835,t:1528139537146};\\\", \\\"{x:1284,y:833,t:1528139537207};\\\", \\\"{x:1283,y:833,t:1528139537249};\\\", \\\"{x:1281,y:833,t:1528139537306};\\\", \\\"{x:1281,y:832,t:1528139537314};\\\", \\\"{x:1280,y:832,t:1528139537346};\\\", \\\"{x:1279,y:831,t:1528139537361};\\\", \\\"{x:1278,y:831,t:1528139539418};\\\", \\\"{x:1279,y:831,t:1528139545507};\\\", \\\"{x:1281,y:831,t:1528139545521};\\\", \\\"{x:1290,y:829,t:1528139545543};\\\", \\\"{x:1291,y:829,t:1528139545555};\\\", \\\"{x:1293,y:828,t:1528139545571};\\\", \\\"{x:1294,y:828,t:1528139545588};\\\", \\\"{x:1295,y:828,t:1528139545690};\\\", \\\"{x:1296,y:828,t:1528139545730};\\\", \\\"{x:1297,y:828,t:1528139545738};\\\", \\\"{x:1298,y:826,t:1528139545757};\\\", \\\"{x:1299,y:826,t:1528139545772};\\\", \\\"{x:1300,y:826,t:1528139545788};\\\", \\\"{x:1301,y:826,t:1528139545809};\\\", \\\"{x:1302,y:825,t:1528139545821};\\\", \\\"{x:1303,y:825,t:1528139545857};\\\", \\\"{x:1304,y:825,t:1528139545872};\\\", \\\"{x:1305,y:825,t:1528139546043};\\\", \\\"{x:1304,y:825,t:1528139546055};\\\", \\\"{x:1300,y:825,t:1528139546072};\\\", \\\"{x:1299,y:824,t:1528139546090};\\\", \\\"{x:1298,y:823,t:1528139546105};\\\", \\\"{x:1297,y:823,t:1528139546371};\\\", \\\"{x:1296,y:823,t:1528139546427};\\\", \\\"{x:1294,y:822,t:1528139546442};\\\", \\\"{x:1292,y:822,t:1528139546499};\\\", \\\"{x:1291,y:822,t:1528139546506};\\\", \\\"{x:1290,y:822,t:1528139546522};\\\", \\\"{x:1288,y:822,t:1528139546539};\\\", \\\"{x:1288,y:823,t:1528139546556};\\\", \\\"{x:1287,y:823,t:1528139546859};\\\", \\\"{x:1286,y:823,t:1528139546939};\\\", \\\"{x:1285,y:823,t:1528139546962};\\\", \\\"{x:1283,y:824,t:1528139546973};\\\", \\\"{x:1282,y:825,t:1528139546993};\\\", \\\"{x:1281,y:825,t:1528139547097};\\\", \\\"{x:1280,y:825,t:1528139547162};\\\", \\\"{x:1279,y:826,t:1528139547267};\\\", \\\"{x:1277,y:826,t:1528139548556};\\\", \\\"{x:1267,y:827,t:1528139548575};\\\", \\\"{x:1253,y:828,t:1528139548591};\\\", \\\"{x:1243,y:830,t:1528139548607};\\\", \\\"{x:1237,y:830,t:1528139548624};\\\", \\\"{x:1234,y:830,t:1528139548641};\\\", \\\"{x:1232,y:830,t:1528139548657};\\\", \\\"{x:1231,y:830,t:1528139548673};\\\", \\\"{x:1229,y:830,t:1528139548691};\\\", \\\"{x:1227,y:830,t:1528139548707};\\\", \\\"{x:1225,y:830,t:1528139548724};\\\", \\\"{x:1223,y:830,t:1528139548741};\\\", \\\"{x:1222,y:830,t:1528139548770};\\\", \\\"{x:1220,y:830,t:1528139548942};\\\", \\\"{x:1219,y:830,t:1528139548977};\\\", \\\"{x:1217,y:830,t:1528139549058};\\\", \\\"{x:1215,y:830,t:1528139549074};\\\", \\\"{x:1212,y:829,t:1528139549091};\\\", \\\"{x:1209,y:829,t:1528139549107};\\\", \\\"{x:1207,y:829,t:1528139549126};\\\", \\\"{x:1206,y:829,t:1528139549141};\\\", \\\"{x:1205,y:829,t:1528139549956};\\\", \\\"{x:1206,y:837,t:1528139549963};\\\", \\\"{x:1208,y:845,t:1528139549976};\\\", \\\"{x:1214,y:857,t:1528139549993};\\\", \\\"{x:1221,y:867,t:1528139550009};\\\", \\\"{x:1227,y:878,t:1528139550025};\\\", \\\"{x:1237,y:895,t:1528139550043};\\\", \\\"{x:1242,y:905,t:1528139550059};\\\", \\\"{x:1243,y:913,t:1528139550078};\\\", \\\"{x:1245,y:918,t:1528139550092};\\\", \\\"{x:1246,y:923,t:1528139550109};\\\", \\\"{x:1247,y:927,t:1528139550125};\\\", \\\"{x:1247,y:928,t:1528139550141};\\\", \\\"{x:1247,y:931,t:1528139550158};\\\", \\\"{x:1247,y:934,t:1528139550175};\\\", \\\"{x:1247,y:940,t:1528139550192};\\\", \\\"{x:1249,y:943,t:1528139550209};\\\", \\\"{x:1252,y:950,t:1528139550225};\\\", \\\"{x:1255,y:954,t:1528139550242};\\\", \\\"{x:1258,y:958,t:1528139550259};\\\", \\\"{x:1262,y:962,t:1528139550275};\\\", \\\"{x:1264,y:963,t:1528139550293};\\\", \\\"{x:1266,y:964,t:1528139550309};\\\", \\\"{x:1268,y:965,t:1528139550325};\\\", \\\"{x:1269,y:965,t:1528139550395};\\\", \\\"{x:1271,y:965,t:1528139550483};\\\", \\\"{x:1273,y:965,t:1528139550498};\\\", \\\"{x:1274,y:965,t:1528139550514};\\\", \\\"{x:1276,y:965,t:1528139550525};\\\", \\\"{x:1277,y:965,t:1528139550542};\\\", \\\"{x:1279,y:965,t:1528139550570};\\\", \\\"{x:1280,y:965,t:1528139550617};\\\", \\\"{x:1282,y:965,t:1528139550626};\\\", \\\"{x:1285,y:965,t:1528139550642};\\\", \\\"{x:1286,y:965,t:1528139550659};\\\", \\\"{x:1287,y:965,t:1528139550676};\\\", \\\"{x:1288,y:964,t:1528139551203};\\\", \\\"{x:1288,y:962,t:1528139551211};\\\", \\\"{x:1288,y:958,t:1528139551227};\\\", \\\"{x:1289,y:955,t:1528139551244};\\\", \\\"{x:1290,y:951,t:1528139551260};\\\", \\\"{x:1291,y:949,t:1528139551277};\\\", \\\"{x:1291,y:947,t:1528139551294};\\\", \\\"{x:1291,y:945,t:1528139551309};\\\", \\\"{x:1293,y:943,t:1528139551326};\\\", \\\"{x:1294,y:942,t:1528139551347};\\\", \\\"{x:1296,y:940,t:1528139551370};\\\", \\\"{x:1296,y:939,t:1528139551411};\\\", \\\"{x:1298,y:938,t:1528139551427};\\\", \\\"{x:1299,y:937,t:1528139551443};\\\", \\\"{x:1300,y:935,t:1528139551461};\\\", \\\"{x:1302,y:933,t:1528139551476};\\\", \\\"{x:1303,y:932,t:1528139551494};\\\", \\\"{x:1305,y:930,t:1528139551511};\\\", \\\"{x:1306,y:928,t:1528139551527};\\\", \\\"{x:1307,y:927,t:1528139551544};\\\", \\\"{x:1308,y:925,t:1528139551561};\\\", \\\"{x:1309,y:923,t:1528139551576};\\\", \\\"{x:1309,y:920,t:1528139551594};\\\", \\\"{x:1309,y:919,t:1528139551611};\\\", \\\"{x:1309,y:917,t:1528139551627};\\\", \\\"{x:1309,y:916,t:1528139551651};\\\", \\\"{x:1309,y:914,t:1528139551683};\\\", \\\"{x:1309,y:912,t:1528139551779};\\\", \\\"{x:1309,y:911,t:1528139551794};\\\", \\\"{x:1308,y:910,t:1528139551811};\\\", \\\"{x:1308,y:908,t:1528139551827};\\\", \\\"{x:1307,y:906,t:1528139551844};\\\", \\\"{x:1307,y:905,t:1528139551861};\\\", \\\"{x:1307,y:904,t:1528139551878};\\\", \\\"{x:1307,y:902,t:1528139551893};\\\", \\\"{x:1307,y:900,t:1528139551911};\\\", \\\"{x:1307,y:898,t:1528139551927};\\\", \\\"{x:1307,y:896,t:1528139551944};\\\", \\\"{x:1307,y:895,t:1528139551961};\\\", \\\"{x:1307,y:893,t:1528139551978};\\\", \\\"{x:1307,y:891,t:1528139551994};\\\", \\\"{x:1310,y:884,t:1528139552010};\\\", \\\"{x:1314,y:879,t:1528139552027};\\\", \\\"{x:1320,y:870,t:1528139552043};\\\", \\\"{x:1329,y:860,t:1528139552061};\\\", \\\"{x:1339,y:852,t:1528139552078};\\\", \\\"{x:1354,y:844,t:1528139552094};\\\", \\\"{x:1365,y:839,t:1528139552111};\\\", \\\"{x:1374,y:834,t:1528139552128};\\\", \\\"{x:1382,y:830,t:1528139552143};\\\", \\\"{x:1390,y:825,t:1528139552161};\\\", \\\"{x:1396,y:822,t:1528139552178};\\\", \\\"{x:1401,y:820,t:1528139552194};\\\", \\\"{x:1406,y:817,t:1528139552210};\\\", \\\"{x:1407,y:815,t:1528139552228};\\\", \\\"{x:1407,y:813,t:1528139552283};\\\", \\\"{x:1405,y:811,t:1528139552294};\\\", \\\"{x:1397,y:811,t:1528139552311};\\\", \\\"{x:1383,y:811,t:1528139552328};\\\", \\\"{x:1369,y:814,t:1528139552344};\\\", \\\"{x:1350,y:822,t:1528139552360};\\\", \\\"{x:1334,y:829,t:1528139552380};\\\", \\\"{x:1310,y:834,t:1528139552393};\\\", \\\"{x:1302,y:835,t:1528139552410};\\\", \\\"{x:1300,y:835,t:1528139552426};\\\", \\\"{x:1298,y:835,t:1528139552445};\\\", \\\"{x:1294,y:837,t:1528139552460};\\\", \\\"{x:1286,y:839,t:1528139552477};\\\", \\\"{x:1278,y:841,t:1528139552494};\\\", \\\"{x:1272,y:842,t:1528139552509};\\\", \\\"{x:1261,y:843,t:1528139552527};\\\", \\\"{x:1248,y:843,t:1528139552544};\\\", \\\"{x:1237,y:846,t:1528139552559};\\\", \\\"{x:1224,y:847,t:1528139552576};\\\", \\\"{x:1206,y:849,t:1528139552593};\\\", \\\"{x:1190,y:852,t:1528139552610};\\\", \\\"{x:1176,y:853,t:1528139552627};\\\", \\\"{x:1165,y:856,t:1528139552644};\\\", \\\"{x:1155,y:857,t:1528139552661};\\\", \\\"{x:1144,y:859,t:1528139552677};\\\", \\\"{x:1134,y:863,t:1528139552694};\\\", \\\"{x:1124,y:866,t:1528139552712};\\\", \\\"{x:1111,y:869,t:1528139552727};\\\", \\\"{x:1100,y:873,t:1528139552744};\\\", \\\"{x:1092,y:876,t:1528139552762};\\\", \\\"{x:1088,y:878,t:1528139552778};\\\", \\\"{x:1082,y:883,t:1528139552795};\\\", \\\"{x:1081,y:885,t:1528139552811};\\\", \\\"{x:1080,y:888,t:1528139552827};\\\", \\\"{x:1079,y:888,t:1528139552844};\\\", \\\"{x:1083,y:885,t:1528139552970};\\\", \\\"{x:1091,y:879,t:1528139552978};\\\", \\\"{x:1106,y:868,t:1528139552995};\\\", \\\"{x:1125,y:853,t:1528139553011};\\\", \\\"{x:1148,y:837,t:1528139553028};\\\", \\\"{x:1170,y:823,t:1528139553044};\\\", \\\"{x:1190,y:806,t:1528139553061};\\\", \\\"{x:1208,y:795,t:1528139553077};\\\", \\\"{x:1220,y:780,t:1528139553094};\\\", \\\"{x:1231,y:761,t:1528139553111};\\\", \\\"{x:1239,y:754,t:1528139553128};\\\", \\\"{x:1240,y:747,t:1528139553144};\\\", \\\"{x:1240,y:742,t:1528139553161};\\\", \\\"{x:1240,y:737,t:1528139553178};\\\", \\\"{x:1240,y:735,t:1528139553194};\\\", \\\"{x:1238,y:733,t:1528139553212};\\\", \\\"{x:1235,y:732,t:1528139553228};\\\", \\\"{x:1228,y:728,t:1528139553244};\\\", \\\"{x:1226,y:728,t:1528139553261};\\\", \\\"{x:1223,y:726,t:1528139553314};\\\", \\\"{x:1217,y:723,t:1528139553329};\\\", \\\"{x:1201,y:713,t:1528139553345};\\\", \\\"{x:1192,y:708,t:1528139553362};\\\", \\\"{x:1191,y:708,t:1528139553379};\\\", \\\"{x:1190,y:707,t:1528139553426};\\\", \\\"{x:1190,y:697,t:1528139553434};\\\", \\\"{x:1190,y:682,t:1528139553445};\\\", \\\"{x:1190,y:647,t:1528139553461};\\\", \\\"{x:1192,y:606,t:1528139553479};\\\", \\\"{x:1200,y:553,t:1528139553495};\\\", \\\"{x:1203,y:525,t:1528139553512};\\\", \\\"{x:1204,y:519,t:1528139553529};\\\", \\\"{x:1204,y:518,t:1528139553546};\\\", \\\"{x:1205,y:516,t:1528139553562};\\\", \\\"{x:1208,y:514,t:1528139553579};\\\", \\\"{x:1209,y:513,t:1528139553595};\\\", \\\"{x:1211,y:509,t:1528139553611};\\\", \\\"{x:1216,y:500,t:1528139553628};\\\", \\\"{x:1225,y:491,t:1528139553646};\\\", \\\"{x:1238,y:476,t:1528139553662};\\\", \\\"{x:1257,y:448,t:1528139553679};\\\", \\\"{x:1274,y:430,t:1528139553696};\\\", \\\"{x:1283,y:424,t:1528139553713};\\\", \\\"{x:1284,y:424,t:1528139553728};\\\", \\\"{x:1286,y:424,t:1528139553777};\\\", \\\"{x:1295,y:427,t:1528139553795};\\\", \\\"{x:1301,y:429,t:1528139553811};\\\", \\\"{x:1306,y:432,t:1528139553828};\\\", \\\"{x:1312,y:437,t:1528139553845};\\\", \\\"{x:1316,y:443,t:1528139553861};\\\", \\\"{x:1318,y:448,t:1528139553879};\\\", \\\"{x:1319,y:451,t:1528139553895};\\\", \\\"{x:1320,y:456,t:1528139553911};\\\", \\\"{x:1320,y:460,t:1528139553929};\\\", \\\"{x:1322,y:462,t:1528139553945};\\\", \\\"{x:1322,y:463,t:1528139553962};\\\", \\\"{x:1322,y:464,t:1528139553986};\\\", \\\"{x:1322,y:465,t:1528139554009};\\\", \\\"{x:1322,y:467,t:1528139554026};\\\", \\\"{x:1322,y:468,t:1528139554050};\\\", \\\"{x:1321,y:469,t:1528139554063};\\\", \\\"{x:1321,y:470,t:1528139554079};\\\", \\\"{x:1320,y:471,t:1528139554096};\\\", \\\"{x:1320,y:472,t:1528139554147};\\\", \\\"{x:1319,y:473,t:1528139554210};\\\", \\\"{x:1319,y:475,t:1528139554225};\\\", \\\"{x:1318,y:476,t:1528139554241};\\\", \\\"{x:1318,y:477,t:1528139554257};\\\", \\\"{x:1318,y:478,t:1528139554266};\\\", \\\"{x:1318,y:479,t:1528139554289};\\\", \\\"{x:1318,y:480,t:1528139554321};\\\", \\\"{x:1316,y:481,t:1528139554330};\\\", \\\"{x:1316,y:482,t:1528139554346};\\\", \\\"{x:1316,y:485,t:1528139554362};\\\", \\\"{x:1316,y:486,t:1528139554378};\\\", \\\"{x:1316,y:488,t:1528139554402};\\\", \\\"{x:1316,y:489,t:1528139554418};\\\", \\\"{x:1316,y:491,t:1528139554447};\\\", \\\"{x:1316,y:492,t:1528139554461};\\\", \\\"{x:1316,y:494,t:1528139554609};\\\", \\\"{x:1315,y:494,t:1528139554625};\\\", \\\"{x:1315,y:495,t:1528139554634};\\\", \\\"{x:1315,y:497,t:1528139554658};\\\", \\\"{x:1315,y:498,t:1528139554698};\\\", \\\"{x:1315,y:499,t:1528139554731};\\\", \\\"{x:1315,y:496,t:1528139554995};\\\", \\\"{x:1317,y:485,t:1528139555004};\\\", \\\"{x:1320,y:478,t:1528139555013};\\\", \\\"{x:1326,y:471,t:1528139555029};\\\", \\\"{x:1333,y:463,t:1528139555045};\\\", \\\"{x:1339,y:457,t:1528139555063};\\\", \\\"{x:1346,y:452,t:1528139555078};\\\", \\\"{x:1355,y:444,t:1528139555096};\\\", \\\"{x:1364,y:438,t:1528139555113};\\\", \\\"{x:1372,y:433,t:1528139555129};\\\", \\\"{x:1380,y:430,t:1528139555146};\\\", \\\"{x:1384,y:429,t:1528139555163};\\\", \\\"{x:1387,y:427,t:1528139555179};\\\", \\\"{x:1389,y:426,t:1528139555196};\\\", \\\"{x:1391,y:426,t:1528139555213};\\\", \\\"{x:1395,y:423,t:1528139555229};\\\", \\\"{x:1399,y:423,t:1528139555246};\\\", \\\"{x:1402,y:422,t:1528139555263};\\\", \\\"{x:1405,y:420,t:1528139555279};\\\", \\\"{x:1406,y:420,t:1528139555296};\\\", \\\"{x:1408,y:420,t:1528139555313};\\\", \\\"{x:1409,y:420,t:1528139555395};\\\", \\\"{x:1410,y:420,t:1528139555403};\\\", \\\"{x:1411,y:420,t:1528139555414};\\\", \\\"{x:1412,y:420,t:1528139555434};\\\", \\\"{x:1412,y:422,t:1528139555457};\\\", \\\"{x:1412,y:423,t:1528139555474};\\\", \\\"{x:1413,y:424,t:1528139555505};\\\", \\\"{x:1413,y:425,t:1528139555531};\\\", \\\"{x:1414,y:426,t:1528139555563};\\\", \\\"{x:1414,y:427,t:1528139555579};\\\", \\\"{x:1415,y:427,t:1528139555601};\\\", \\\"{x:1415,y:436,t:1528139557978};\\\", \\\"{x:1415,y:500,t:1528139557998};\\\", \\\"{x:1420,y:544,t:1528139558016};\\\", \\\"{x:1429,y:587,t:1528139558032};\\\", \\\"{x:1439,y:629,t:1528139558048};\\\", \\\"{x:1444,y:659,t:1528139558065};\\\", \\\"{x:1445,y:695,t:1528139558082};\\\", \\\"{x:1445,y:724,t:1528139558098};\\\", \\\"{x:1445,y:748,t:1528139558115};\\\", \\\"{x:1442,y:763,t:1528139558132};\\\", \\\"{x:1442,y:767,t:1528139558149};\\\", \\\"{x:1442,y:768,t:1528139558165};\\\", \\\"{x:1441,y:768,t:1528139558226};\\\", \\\"{x:1439,y:762,t:1528139558234};\\\", \\\"{x:1436,y:753,t:1528139558248};\\\", \\\"{x:1428,y:736,t:1528139558265};\\\", \\\"{x:1417,y:721,t:1528139558282};\\\", \\\"{x:1412,y:718,t:1528139558300};\\\", \\\"{x:1401,y:712,t:1528139558316};\\\", \\\"{x:1389,y:705,t:1528139558333};\\\", \\\"{x:1380,y:701,t:1528139558349};\\\", \\\"{x:1377,y:698,t:1528139558366};\\\", \\\"{x:1374,y:696,t:1528139558383};\\\", \\\"{x:1373,y:694,t:1528139558400};\\\", \\\"{x:1372,y:692,t:1528139558416};\\\", \\\"{x:1369,y:689,t:1528139558433};\\\", \\\"{x:1363,y:681,t:1528139558450};\\\", \\\"{x:1359,y:676,t:1528139558466};\\\", \\\"{x:1356,y:673,t:1528139558482};\\\", \\\"{x:1351,y:669,t:1528139558499};\\\", \\\"{x:1344,y:664,t:1528139558516};\\\", \\\"{x:1336,y:660,t:1528139558533};\\\", \\\"{x:1330,y:658,t:1528139558549};\\\", \\\"{x:1327,y:656,t:1528139558565};\\\", \\\"{x:1323,y:653,t:1528139558583};\\\", \\\"{x:1320,y:650,t:1528139558600};\\\", \\\"{x:1316,y:647,t:1528139558615};\\\", \\\"{x:1314,y:645,t:1528139558633};\\\", \\\"{x:1313,y:645,t:1528139558650};\\\", \\\"{x:1313,y:644,t:1528139558665};\\\", \\\"{x:1312,y:641,t:1528139558682};\\\", \\\"{x:1312,y:638,t:1528139558700};\\\", \\\"{x:1312,y:636,t:1528139558717};\\\", \\\"{x:1312,y:635,t:1528139558736};\\\", \\\"{x:1312,y:633,t:1528139558749};\\\", \\\"{x:1312,y:632,t:1528139558767};\\\", \\\"{x:1312,y:631,t:1528139558782};\\\", \\\"{x:1312,y:630,t:1528139558799};\\\", \\\"{x:1312,y:629,t:1528139558817};\\\", \\\"{x:1313,y:627,t:1528139560458};\\\", \\\"{x:1327,y:616,t:1528139560470};\\\", \\\"{x:1358,y:600,t:1528139560483};\\\", \\\"{x:1384,y:587,t:1528139560501};\\\", \\\"{x:1411,y:576,t:1528139560517};\\\", \\\"{x:1436,y:566,t:1528139560534};\\\", \\\"{x:1452,y:558,t:1528139560550};\\\", \\\"{x:1458,y:556,t:1528139560567};\\\", \\\"{x:1459,y:554,t:1528139560584};\\\", \\\"{x:1460,y:554,t:1528139560626};\\\", \\\"{x:1460,y:553,t:1528139560738};\\\", \\\"{x:1458,y:551,t:1528139560751};\\\", \\\"{x:1452,y:551,t:1528139560769};\\\", \\\"{x:1444,y:551,t:1528139560785};\\\", \\\"{x:1436,y:553,t:1528139560801};\\\", \\\"{x:1426,y:556,t:1528139560819};\\\", \\\"{x:1423,y:556,t:1528139560835};\\\", \\\"{x:1422,y:556,t:1528139560851};\\\", \\\"{x:1420,y:556,t:1528139561307};\\\", \\\"{x:1419,y:556,t:1528139561418};\\\", \\\"{x:1418,y:556,t:1528139561627};\\\", \\\"{x:1417,y:555,t:1528139561635};\\\", \\\"{x:1414,y:555,t:1528139561652};\\\", \\\"{x:1411,y:555,t:1528139561668};\\\", \\\"{x:1409,y:555,t:1528139561686};\\\", \\\"{x:1407,y:556,t:1528139561702};\\\", \\\"{x:1404,y:556,t:1528139561875};\\\", \\\"{x:1402,y:557,t:1528139561885};\\\", \\\"{x:1400,y:559,t:1528139561902};\\\", \\\"{x:1400,y:560,t:1528139561919};\\\", \\\"{x:1399,y:560,t:1528139561935};\\\", \\\"{x:1399,y:561,t:1528139561952};\\\", \\\"{x:1399,y:564,t:1528139561969};\\\", \\\"{x:1402,y:567,t:1528139561985};\\\", \\\"{x:1402,y:568,t:1528139562001};\\\", \\\"{x:1403,y:569,t:1528139562034};\\\", \\\"{x:1403,y:570,t:1528139562066};\\\", \\\"{x:1404,y:571,t:1528139562097};\\\", \\\"{x:1405,y:571,t:1528139562106};\\\", \\\"{x:1405,y:572,t:1528139562119};\\\", \\\"{x:1406,y:572,t:1528139562135};\\\", \\\"{x:1406,y:573,t:1528139562235};\\\", \\\"{x:1408,y:573,t:1528139562346};\\\", \\\"{x:1409,y:573,t:1528139562554};\\\", \\\"{x:1410,y:573,t:1528139562568};\\\", \\\"{x:1411,y:570,t:1528139562585};\\\", \\\"{x:1412,y:568,t:1528139562603};\\\", \\\"{x:1413,y:568,t:1528139562619};\\\", \\\"{x:1412,y:568,t:1528139570770};\\\", \\\"{x:1411,y:569,t:1528139570789};\\\", \\\"{x:1410,y:569,t:1528139570809};\\\", \\\"{x:1409,y:570,t:1528139570905};\\\", \\\"{x:1408,y:570,t:1528139571267};\\\", \\\"{x:1402,y:581,t:1528139571277};\\\", \\\"{x:1388,y:601,t:1528139571293};\\\", \\\"{x:1375,y:622,t:1528139571309};\\\", \\\"{x:1361,y:654,t:1528139571326};\\\", \\\"{x:1349,y:698,t:1528139571343};\\\", \\\"{x:1333,y:746,t:1528139571361};\\\", \\\"{x:1326,y:765,t:1528139571376};\\\", \\\"{x:1328,y:774,t:1528139571393};\\\", \\\"{x:1328,y:776,t:1528139571475};\\\", \\\"{x:1329,y:777,t:1528139571482};\\\", \\\"{x:1329,y:779,t:1528139571506};\\\", \\\"{x:1329,y:782,t:1528139571522};\\\", \\\"{x:1330,y:784,t:1528139571530};\\\", \\\"{x:1330,y:787,t:1528139571543};\\\", \\\"{x:1332,y:790,t:1528139571560};\\\", \\\"{x:1332,y:791,t:1528139571576};\\\", \\\"{x:1333,y:791,t:1528139571626};\\\", \\\"{x:1334,y:791,t:1528139571674};\\\", \\\"{x:1335,y:791,t:1528139571690};\\\", \\\"{x:1337,y:793,t:1528139571730};\\\", \\\"{x:1337,y:800,t:1528139571744};\\\", \\\"{x:1337,y:819,t:1528139571761};\\\", \\\"{x:1337,y:834,t:1528139571778};\\\", \\\"{x:1334,y:844,t:1528139571794};\\\", \\\"{x:1330,y:855,t:1528139571810};\\\", \\\"{x:1326,y:863,t:1528139571827};\\\", \\\"{x:1321,y:872,t:1528139571844};\\\", \\\"{x:1315,y:888,t:1528139571860};\\\", \\\"{x:1308,y:909,t:1528139571878};\\\", \\\"{x:1304,y:933,t:1528139571893};\\\", \\\"{x:1303,y:947,t:1528139571910};\\\", \\\"{x:1302,y:951,t:1528139571927};\\\", \\\"{x:1302,y:953,t:1528139571943};\\\", \\\"{x:1302,y:954,t:1528139572002};\\\", \\\"{x:1301,y:955,t:1528139572026};\\\", \\\"{x:1300,y:956,t:1528139572043};\\\", \\\"{x:1300,y:957,t:1528139572061};\\\", \\\"{x:1299,y:959,t:1528139572077};\\\", \\\"{x:1299,y:960,t:1528139572098};\\\", \\\"{x:1299,y:962,t:1528139572122};\\\", \\\"{x:1299,y:960,t:1528139572378};\\\", \\\"{x:1302,y:950,t:1528139572394};\\\", \\\"{x:1307,y:941,t:1528139572411};\\\", \\\"{x:1314,y:931,t:1528139572427};\\\", \\\"{x:1319,y:924,t:1528139572444};\\\", \\\"{x:1322,y:918,t:1528139572461};\\\", \\\"{x:1326,y:913,t:1528139572477};\\\", \\\"{x:1330,y:907,t:1528139572495};\\\", \\\"{x:1334,y:901,t:1528139572511};\\\", \\\"{x:1339,y:895,t:1528139572528};\\\", \\\"{x:1343,y:891,t:1528139572544};\\\", \\\"{x:1344,y:889,t:1528139572560};\\\", \\\"{x:1345,y:888,t:1528139572583};\\\", \\\"{x:1347,y:885,t:1528139572593};\\\", \\\"{x:1348,y:883,t:1528139572611};\\\", \\\"{x:1350,y:880,t:1528139572627};\\\", \\\"{x:1351,y:878,t:1528139572644};\\\", \\\"{x:1352,y:873,t:1528139572661};\\\", \\\"{x:1355,y:870,t:1528139572677};\\\", \\\"{x:1355,y:867,t:1528139572693};\\\", \\\"{x:1357,y:864,t:1528139572711};\\\", \\\"{x:1357,y:863,t:1528139572726};\\\", \\\"{x:1358,y:862,t:1528139572743};\\\", \\\"{x:1358,y:861,t:1528139572778};\\\", \\\"{x:1357,y:861,t:1528139572906};\\\", \\\"{x:1355,y:868,t:1528139572914};\\\", \\\"{x:1354,y:873,t:1528139572927};\\\", \\\"{x:1351,y:886,t:1528139572945};\\\", \\\"{x:1348,y:899,t:1528139572964};\\\", \\\"{x:1346,y:914,t:1528139572978};\\\", \\\"{x:1344,y:934,t:1528139572993};\\\", \\\"{x:1344,y:946,t:1528139573011};\\\", \\\"{x:1345,y:957,t:1528139573027};\\\", \\\"{x:1350,y:965,t:1528139573044};\\\", \\\"{x:1354,y:973,t:1528139573061};\\\", \\\"{x:1362,y:982,t:1528139573077};\\\", \\\"{x:1366,y:987,t:1528139573094};\\\", \\\"{x:1367,y:988,t:1528139573111};\\\", \\\"{x:1368,y:988,t:1528139573129};\\\", \\\"{x:1369,y:988,t:1528139573194};\\\", \\\"{x:1371,y:988,t:1528139573211};\\\", \\\"{x:1375,y:988,t:1528139573228};\\\", \\\"{x:1386,y:987,t:1528139573244};\\\", \\\"{x:1399,y:986,t:1528139573261};\\\", \\\"{x:1410,y:985,t:1528139573278};\\\", \\\"{x:1427,y:982,t:1528139573294};\\\", \\\"{x:1445,y:979,t:1528139573311};\\\", \\\"{x:1460,y:979,t:1528139573328};\\\", \\\"{x:1475,y:979,t:1528139573345};\\\", \\\"{x:1492,y:979,t:1528139573362};\\\", \\\"{x:1512,y:979,t:1528139573378};\\\", \\\"{x:1524,y:979,t:1528139573394};\\\", \\\"{x:1535,y:978,t:1528139573411};\\\", \\\"{x:1547,y:978,t:1528139573428};\\\", \\\"{x:1556,y:978,t:1528139573445};\\\", \\\"{x:1564,y:978,t:1528139573461};\\\", \\\"{x:1575,y:976,t:1528139573479};\\\", \\\"{x:1585,y:975,t:1528139573495};\\\", \\\"{x:1593,y:973,t:1528139573512};\\\", \\\"{x:1601,y:972,t:1528139573528};\\\", \\\"{x:1608,y:972,t:1528139573545};\\\", \\\"{x:1616,y:971,t:1528139573562};\\\", \\\"{x:1627,y:970,t:1528139573578};\\\", \\\"{x:1634,y:968,t:1528139573596};\\\", \\\"{x:1643,y:968,t:1528139573611};\\\", \\\"{x:1647,y:968,t:1528139573628};\\\", \\\"{x:1653,y:968,t:1528139573645};\\\", \\\"{x:1658,y:967,t:1528139573661};\\\", \\\"{x:1665,y:967,t:1528139573678};\\\", \\\"{x:1673,y:967,t:1528139573695};\\\", \\\"{x:1678,y:967,t:1528139573711};\\\", \\\"{x:1681,y:967,t:1528139573729};\\\", \\\"{x:1685,y:967,t:1528139573746};\\\", \\\"{x:1687,y:967,t:1528139573761};\\\", \\\"{x:1691,y:967,t:1528139573778};\\\", \\\"{x:1695,y:966,t:1528139573795};\\\", \\\"{x:1697,y:966,t:1528139573813};\\\", \\\"{x:1698,y:965,t:1528139573828};\\\", \\\"{x:1702,y:965,t:1528139573846};\\\", \\\"{x:1708,y:964,t:1528139573863};\\\", \\\"{x:1713,y:963,t:1528139573879};\\\", \\\"{x:1720,y:963,t:1528139573895};\\\", \\\"{x:1725,y:962,t:1528139573912};\\\", \\\"{x:1729,y:961,t:1528139573928};\\\", \\\"{x:1733,y:961,t:1528139573946};\\\", \\\"{x:1742,y:960,t:1528139573962};\\\", \\\"{x:1745,y:960,t:1528139573978};\\\", \\\"{x:1749,y:960,t:1528139573996};\\\", \\\"{x:1751,y:960,t:1528139574012};\\\", \\\"{x:1753,y:960,t:1528139574028};\\\", \\\"{x:1758,y:960,t:1528139574045};\\\", \\\"{x:1760,y:960,t:1528139574063};\\\", \\\"{x:1764,y:960,t:1528139574079};\\\", \\\"{x:1768,y:960,t:1528139574096};\\\", \\\"{x:1774,y:960,t:1528139574112};\\\", \\\"{x:1784,y:960,t:1528139574129};\\\", \\\"{x:1792,y:960,t:1528139574145};\\\", \\\"{x:1798,y:960,t:1528139574162};\\\", \\\"{x:1797,y:960,t:1528139574794};\\\", \\\"{x:1796,y:961,t:1528139574802};\\\", \\\"{x:1795,y:962,t:1528139574826};\\\", \\\"{x:1794,y:962,t:1528139574834};\\\", \\\"{x:1793,y:962,t:1528139574847};\\\", \\\"{x:1790,y:963,t:1528139574862};\\\", \\\"{x:1789,y:964,t:1528139574879};\\\", \\\"{x:1786,y:964,t:1528139574896};\\\", \\\"{x:1784,y:964,t:1528139574962};\\\", \\\"{x:1782,y:965,t:1528139574980};\\\", \\\"{x:1780,y:967,t:1528139574997};\\\", \\\"{x:1777,y:968,t:1528139575012};\\\", \\\"{x:1775,y:969,t:1528139575030};\\\", \\\"{x:1772,y:971,t:1528139575047};\\\", \\\"{x:1770,y:971,t:1528139575063};\\\", \\\"{x:1768,y:972,t:1528139575079};\\\", \\\"{x:1763,y:974,t:1528139575096};\\\", \\\"{x:1757,y:975,t:1528139575112};\\\", \\\"{x:1749,y:978,t:1528139575129};\\\", \\\"{x:1737,y:982,t:1528139575146};\\\", \\\"{x:1724,y:984,t:1528139575164};\\\", \\\"{x:1712,y:986,t:1528139575180};\\\", \\\"{x:1702,y:988,t:1528139575197};\\\", \\\"{x:1695,y:989,t:1528139575214};\\\", \\\"{x:1688,y:990,t:1528139575230};\\\", \\\"{x:1684,y:992,t:1528139575247};\\\", \\\"{x:1678,y:994,t:1528139575264};\\\", \\\"{x:1669,y:999,t:1528139575279};\\\", \\\"{x:1663,y:1001,t:1528139575297};\\\", \\\"{x:1655,y:1004,t:1528139575314};\\\", \\\"{x:1649,y:1005,t:1528139575329};\\\", \\\"{x:1643,y:1007,t:1528139575346};\\\", \\\"{x:1640,y:1008,t:1528139575363};\\\", \\\"{x:1635,y:1009,t:1528139575380};\\\", \\\"{x:1632,y:1012,t:1528139575396};\\\", \\\"{x:1626,y:1013,t:1528139575414};\\\", \\\"{x:1623,y:1015,t:1528139575430};\\\", \\\"{x:1620,y:1016,t:1528139575447};\\\", \\\"{x:1619,y:1017,t:1528139575474};\\\", \\\"{x:1617,y:1017,t:1528139575498};\\\", \\\"{x:1617,y:1018,t:1528139575514};\\\", \\\"{x:1613,y:1020,t:1528139575530};\\\", \\\"{x:1612,y:1021,t:1528139575546};\\\", \\\"{x:1611,y:1021,t:1528139575563};\\\", \\\"{x:1610,y:1022,t:1528139575580};\\\", \\\"{x:1608,y:1022,t:1528139575602};\\\", \\\"{x:1607,y:1022,t:1528139575618};\\\", \\\"{x:1605,y:1023,t:1528139575635};\\\", \\\"{x:1604,y:1023,t:1528139575646};\\\", \\\"{x:1600,y:1024,t:1528139575664};\\\", \\\"{x:1596,y:1025,t:1528139575680};\\\", \\\"{x:1593,y:1026,t:1528139575697};\\\", \\\"{x:1592,y:1026,t:1528139575713};\\\", \\\"{x:1590,y:1026,t:1528139575730};\\\", \\\"{x:1589,y:1026,t:1528139575803};\\\", \\\"{x:1588,y:1026,t:1528139575818};\\\", \\\"{x:1587,y:1026,t:1528139575834};\\\", \\\"{x:1585,y:1026,t:1528139575847};\\\", \\\"{x:1581,y:1025,t:1528139575863};\\\", \\\"{x:1569,y:1019,t:1528139575880};\\\", \\\"{x:1549,y:1011,t:1528139575896};\\\", \\\"{x:1520,y:999,t:1528139575913};\\\", \\\"{x:1478,y:983,t:1528139575931};\\\", \\\"{x:1454,y:972,t:1528139575947};\\\", \\\"{x:1431,y:962,t:1528139575964};\\\", \\\"{x:1413,y:953,t:1528139575981};\\\", \\\"{x:1397,y:944,t:1528139575997};\\\", \\\"{x:1388,y:940,t:1528139576013};\\\", \\\"{x:1387,y:939,t:1528139576031};\\\", \\\"{x:1386,y:939,t:1528139576048};\\\", \\\"{x:1385,y:938,t:1528139576107};\\\", \\\"{x:1385,y:937,t:1528139576114};\\\", \\\"{x:1382,y:936,t:1528139576131};\\\", \\\"{x:1373,y:929,t:1528139576147};\\\", \\\"{x:1370,y:928,t:1528139576164};\\\", \\\"{x:1366,y:925,t:1528139576180};\\\", \\\"{x:1364,y:923,t:1528139576198};\\\", \\\"{x:1360,y:920,t:1528139576213};\\\", \\\"{x:1354,y:918,t:1528139576230};\\\", \\\"{x:1350,y:916,t:1528139576247};\\\", \\\"{x:1347,y:914,t:1528139576264};\\\", \\\"{x:1346,y:913,t:1528139576282};\\\", \\\"{x:1345,y:912,t:1528139576483};\\\", \\\"{x:1344,y:908,t:1528139576498};\\\", \\\"{x:1343,y:906,t:1528139576514};\\\", \\\"{x:1341,y:902,t:1528139576530};\\\", \\\"{x:1340,y:899,t:1528139576547};\\\", \\\"{x:1339,y:898,t:1528139576564};\\\", \\\"{x:1339,y:897,t:1528139576619};\\\", \\\"{x:1338,y:896,t:1528139576675};\\\", \\\"{x:1338,y:895,t:1528139576962};\\\", \\\"{x:1337,y:894,t:1528139576970};\\\", \\\"{x:1336,y:893,t:1528139576986};\\\", \\\"{x:1335,y:892,t:1528139577010};\\\", \\\"{x:1334,y:891,t:1528139577018};\\\", \\\"{x:1333,y:890,t:1528139577032};\\\", \\\"{x:1332,y:888,t:1528139577048};\\\", \\\"{x:1330,y:886,t:1528139577066};\\\", \\\"{x:1327,y:883,t:1528139577082};\\\", \\\"{x:1324,y:879,t:1528139577098};\\\", \\\"{x:1319,y:873,t:1528139577114};\\\", \\\"{x:1316,y:868,t:1528139577131};\\\", \\\"{x:1313,y:863,t:1528139577147};\\\", \\\"{x:1310,y:859,t:1528139577165};\\\", \\\"{x:1307,y:855,t:1528139577182};\\\", \\\"{x:1304,y:852,t:1528139577197};\\\", \\\"{x:1303,y:850,t:1528139577214};\\\", \\\"{x:1302,y:849,t:1528139577235};\\\", \\\"{x:1301,y:849,t:1528139577266};\\\", \\\"{x:1301,y:848,t:1528139577331};\\\", \\\"{x:1300,y:847,t:1528139577348};\\\", \\\"{x:1299,y:846,t:1528139577364};\\\", \\\"{x:1299,y:845,t:1528139577382};\\\", \\\"{x:1298,y:845,t:1528139577398};\\\", \\\"{x:1298,y:844,t:1528139577414};\\\", \\\"{x:1298,y:843,t:1528139577431};\\\", \\\"{x:1298,y:842,t:1528139577448};\\\", \\\"{x:1297,y:842,t:1528139577465};\\\", \\\"{x:1297,y:841,t:1528139577538};\\\", \\\"{x:1297,y:840,t:1528139577609};\\\", \\\"{x:1296,y:840,t:1528139577722};\\\", \\\"{x:1296,y:839,t:1528139577731};\\\", \\\"{x:1296,y:838,t:1528139577764};\\\", \\\"{x:1295,y:837,t:1528139577801};\\\", \\\"{x:1295,y:836,t:1528139577986};\\\", \\\"{x:1294,y:836,t:1528139578018};\\\", \\\"{x:1293,y:836,t:1528139578034};\\\", \\\"{x:1292,y:835,t:1528139578049};\\\", \\\"{x:1291,y:835,t:1528139578066};\\\", \\\"{x:1290,y:835,t:1528139578082};\\\", \\\"{x:1289,y:835,t:1528139578114};\\\", \\\"{x:1288,y:834,t:1528139578130};\\\", \\\"{x:1287,y:834,t:1528139578156};\\\", \\\"{x:1287,y:833,t:1528139578227};\\\", \\\"{x:1286,y:833,t:1528139578331};\\\", \\\"{x:1285,y:832,t:1528139578391};\\\", \\\"{x:1283,y:831,t:1528139578415};\\\", \\\"{x:1282,y:830,t:1528139578432};\\\", \\\"{x:1281,y:828,t:1528139578448};\\\", \\\"{x:1280,y:827,t:1528139578465};\\\", \\\"{x:1279,y:827,t:1528139578482};\\\", \\\"{x:1278,y:826,t:1528139578499};\\\", \\\"{x:1278,y:825,t:1528139578515};\\\", \\\"{x:1277,y:824,t:1528139578533};\\\", \\\"{x:1277,y:823,t:1528139579058};\\\", \\\"{x:1279,y:823,t:1528139579066};\\\", \\\"{x:1281,y:824,t:1528139579082};\\\", \\\"{x:1282,y:824,t:1528139579099};\\\", \\\"{x:1283,y:824,t:1528139579130};\\\", \\\"{x:1284,y:824,t:1528139579194};\\\", \\\"{x:1285,y:825,t:1528139579235};\\\", \\\"{x:1286,y:826,t:1528139579522};\\\", \\\"{x:1286,y:827,t:1528139579542};\\\", \\\"{x:1286,y:830,t:1528139581058};\\\", \\\"{x:1288,y:831,t:1528139581071};\\\", \\\"{x:1290,y:831,t:1528139581084};\\\", \\\"{x:1293,y:833,t:1528139581101};\\\", \\\"{x:1295,y:834,t:1528139581117};\\\", \\\"{x:1296,y:835,t:1528139581134};\\\", \\\"{x:1298,y:835,t:1528139581169};\\\", \\\"{x:1298,y:836,t:1528139581193};\\\", \\\"{x:1299,y:836,t:1528139581241};\\\", \\\"{x:1300,y:837,t:1528139581257};\\\", \\\"{x:1301,y:838,t:1528139581274};\\\", \\\"{x:1302,y:839,t:1528139581289};\\\", \\\"{x:1303,y:840,t:1528139581301};\\\", \\\"{x:1304,y:840,t:1528139581318};\\\", \\\"{x:1305,y:841,t:1528139581334};\\\", \\\"{x:1306,y:842,t:1528139581352};\\\", \\\"{x:1307,y:843,t:1528139581367};\\\", \\\"{x:1308,y:844,t:1528139581386};\\\", \\\"{x:1309,y:846,t:1528139581410};\\\", \\\"{x:1311,y:847,t:1528139581418};\\\", \\\"{x:1316,y:851,t:1528139581435};\\\", \\\"{x:1321,y:855,t:1528139581452};\\\", \\\"{x:1325,y:858,t:1528139581469};\\\", \\\"{x:1329,y:861,t:1528139581485};\\\", \\\"{x:1332,y:865,t:1528139581501};\\\", \\\"{x:1335,y:868,t:1528139581519};\\\", \\\"{x:1337,y:868,t:1528139581534};\\\", \\\"{x:1337,y:869,t:1528139581552};\\\", \\\"{x:1339,y:869,t:1528139581802};\\\", \\\"{x:1340,y:869,t:1528139581819};\\\", \\\"{x:1344,y:869,t:1528139581835};\\\", \\\"{x:1344,y:868,t:1528139581866};\\\", \\\"{x:1345,y:868,t:1528139581979};\\\", \\\"{x:1345,y:866,t:1528139582018};\\\", \\\"{x:1345,y:865,t:1528139582036};\\\", \\\"{x:1345,y:864,t:1528139582066};\\\", \\\"{x:1345,y:863,t:1528139582098};\\\", \\\"{x:1345,y:862,t:1528139582106};\\\", \\\"{x:1346,y:861,t:1528139582130};\\\", \\\"{x:1346,y:860,t:1528139582227};\\\", \\\"{x:1346,y:859,t:1528139582236};\\\", \\\"{x:1345,y:859,t:1528139582252};\\\", \\\"{x:1345,y:857,t:1528139582273};\\\", \\\"{x:1345,y:856,t:1528139582286};\\\", \\\"{x:1345,y:855,t:1528139582303};\\\", \\\"{x:1345,y:854,t:1528139582319};\\\", \\\"{x:1345,y:853,t:1528139582336};\\\", \\\"{x:1345,y:851,t:1528139582378};\\\", \\\"{x:1344,y:850,t:1528139582394};\\\", \\\"{x:1344,y:849,t:1528139582410};\\\", \\\"{x:1344,y:848,t:1528139582419};\\\", \\\"{x:1344,y:846,t:1528139582435};\\\", \\\"{x:1344,y:842,t:1528139582453};\\\", \\\"{x:1344,y:837,t:1528139582469};\\\", \\\"{x:1344,y:834,t:1528139582486};\\\", \\\"{x:1344,y:832,t:1528139582502};\\\", \\\"{x:1344,y:829,t:1528139582519};\\\", \\\"{x:1344,y:826,t:1528139582536};\\\", \\\"{x:1344,y:821,t:1528139582552};\\\", \\\"{x:1345,y:815,t:1528139582569};\\\", \\\"{x:1346,y:808,t:1528139582586};\\\", \\\"{x:1347,y:806,t:1528139582602};\\\", \\\"{x:1349,y:801,t:1528139582619};\\\", \\\"{x:1351,y:797,t:1528139582636};\\\", \\\"{x:1352,y:793,t:1528139582653};\\\", \\\"{x:1354,y:789,t:1528139582669};\\\", \\\"{x:1356,y:784,t:1528139582686};\\\", \\\"{x:1359,y:780,t:1528139582703};\\\", \\\"{x:1363,y:775,t:1528139582720};\\\", \\\"{x:1367,y:771,t:1528139582735};\\\", \\\"{x:1369,y:768,t:1528139582753};\\\", \\\"{x:1372,y:762,t:1528139582769};\\\", \\\"{x:1375,y:757,t:1528139582785};\\\", \\\"{x:1376,y:755,t:1528139582802};\\\", \\\"{x:1378,y:753,t:1528139582819};\\\", \\\"{x:1379,y:751,t:1528139582929};\\\", \\\"{x:1379,y:750,t:1528139582969};\\\", \\\"{x:1380,y:749,t:1528139582985};\\\", \\\"{x:1380,y:748,t:1528139583003};\\\", \\\"{x:1381,y:748,t:1528139583020};\\\", \\\"{x:1381,y:747,t:1528139583402};\\\", \\\"{x:1379,y:748,t:1528139583419};\\\", \\\"{x:1377,y:750,t:1528139583437};\\\", \\\"{x:1375,y:752,t:1528139583453};\\\", \\\"{x:1374,y:753,t:1528139583470};\\\", \\\"{x:1373,y:753,t:1528139583490};\\\", \\\"{x:1374,y:755,t:1528139583594};\\\", \\\"{x:1375,y:756,t:1528139583634};\\\", \\\"{x:1376,y:756,t:1528139583642};\\\", \\\"{x:1377,y:757,t:1528139583658};\\\", \\\"{x:1378,y:758,t:1528139583674};\\\", \\\"{x:1379,y:759,t:1528139583686};\\\", \\\"{x:1380,y:759,t:1528139583721};\\\", \\\"{x:1381,y:759,t:1528139583777};\\\", \\\"{x:1381,y:760,t:1528139583825};\\\", \\\"{x:1381,y:761,t:1528139593257};\\\", \\\"{x:1359,y:769,t:1528139593266};\\\", \\\"{x:1334,y:777,t:1528139593276};\\\", \\\"{x:1279,y:784,t:1528139593294};\\\", \\\"{x:1190,y:784,t:1528139593310};\\\", \\\"{x:1090,y:784,t:1528139593328};\\\", \\\"{x:996,y:771,t:1528139593343};\\\", \\\"{x:908,y:752,t:1528139593361};\\\", \\\"{x:788,y:724,t:1528139593378};\\\", \\\"{x:713,y:704,t:1528139593395};\\\", \\\"{x:640,y:683,t:1528139593411};\\\", \\\"{x:599,y:671,t:1528139593428};\\\", \\\"{x:568,y:661,t:1528139593444};\\\", \\\"{x:541,y:657,t:1528139593460};\\\", \\\"{x:520,y:653,t:1528139593478};\\\", \\\"{x:499,y:650,t:1528139593495};\\\", \\\"{x:480,y:648,t:1528139593511};\\\", \\\"{x:463,y:645,t:1528139593527};\\\", \\\"{x:442,y:643,t:1528139593544};\\\", \\\"{x:415,y:638,t:1528139593560};\\\", \\\"{x:387,y:634,t:1528139593577};\\\", \\\"{x:374,y:632,t:1528139593594};\\\", \\\"{x:371,y:631,t:1528139593612};\\\", \\\"{x:369,y:630,t:1528139593628};\\\", \\\"{x:368,y:630,t:1528139593689};\\\", \\\"{x:367,y:630,t:1528139593698};\\\", \\\"{x:365,y:633,t:1528139593962};\\\", \\\"{x:359,y:634,t:1528139593978};\\\", \\\"{x:350,y:637,t:1528139593995};\\\", \\\"{x:341,y:639,t:1528139594012};\\\", \\\"{x:333,y:641,t:1528139594028};\\\", \\\"{x:328,y:642,t:1528139594044};\\\", \\\"{x:324,y:642,t:1528139594062};\\\", \\\"{x:317,y:643,t:1528139594078};\\\", \\\"{x:310,y:643,t:1528139594095};\\\", \\\"{x:306,y:643,t:1528139594112};\\\", \\\"{x:305,y:643,t:1528139594128};\\\", \\\"{x:309,y:643,t:1528139594210};\\\", \\\"{x:314,y:641,t:1528139594218};\\\", \\\"{x:320,y:638,t:1528139594229};\\\", \\\"{x:337,y:634,t:1528139594245};\\\", \\\"{x:364,y:631,t:1528139594262};\\\", \\\"{x:392,y:627,t:1528139594280};\\\", \\\"{x:423,y:622,t:1528139594296};\\\", \\\"{x:449,y:618,t:1528139594312};\\\", \\\"{x:472,y:617,t:1528139594330};\\\", \\\"{x:505,y:616,t:1528139594344};\\\", \\\"{x:532,y:616,t:1528139594361};\\\", \\\"{x:558,y:616,t:1528139594378};\\\", \\\"{x:584,y:616,t:1528139594396};\\\", \\\"{x:605,y:616,t:1528139594412};\\\", \\\"{x:622,y:616,t:1528139594429};\\\", \\\"{x:632,y:614,t:1528139594445};\\\", \\\"{x:636,y:614,t:1528139594461};\\\", \\\"{x:639,y:613,t:1528139594478};\\\", \\\"{x:642,y:612,t:1528139594495};\\\", \\\"{x:650,y:611,t:1528139594512};\\\", \\\"{x:663,y:609,t:1528139594529};\\\", \\\"{x:680,y:607,t:1528139594544};\\\", \\\"{x:699,y:607,t:1528139594561};\\\", \\\"{x:717,y:603,t:1528139594579};\\\", \\\"{x:728,y:603,t:1528139594595};\\\", \\\"{x:734,y:603,t:1528139594612};\\\", \\\"{x:737,y:603,t:1528139594628};\\\", \\\"{x:739,y:603,t:1528139594657};\\\", \\\"{x:739,y:604,t:1528139594680};\\\", \\\"{x:739,y:606,t:1528139594696};\\\", \\\"{x:731,y:611,t:1528139594712};\\\", \\\"{x:719,y:617,t:1528139594728};\\\", \\\"{x:714,y:620,t:1528139594746};\\\", \\\"{x:706,y:624,t:1528139594772};\\\", \\\"{x:698,y:627,t:1528139594789};\\\", \\\"{x:692,y:628,t:1528139594805};\\\", \\\"{x:687,y:630,t:1528139594821};\\\", \\\"{x:683,y:631,t:1528139594838};\\\", \\\"{x:681,y:632,t:1528139594856};\\\", \\\"{x:680,y:633,t:1528139594871};\\\", \\\"{x:679,y:633,t:1528139594888};\\\", \\\"{x:678,y:633,t:1528139594906};\\\", \\\"{x:676,y:634,t:1528139594921};\\\", \\\"{x:673,y:635,t:1528139594939};\\\", \\\"{x:665,y:637,t:1528139594955};\\\", \\\"{x:661,y:641,t:1528139594972};\\\", \\\"{x:657,y:641,t:1528139594989};\\\", \\\"{x:653,y:643,t:1528139595005};\\\", \\\"{x:649,y:644,t:1528139595022};\\\", \\\"{x:639,y:645,t:1528139595038};\\\", \\\"{x:623,y:645,t:1528139595056};\\\", \\\"{x:601,y:645,t:1528139595072};\\\", \\\"{x:579,y:645,t:1528139595089};\\\", \\\"{x:559,y:645,t:1528139595105};\\\", \\\"{x:538,y:643,t:1528139595122};\\\", \\\"{x:516,y:640,t:1528139595139};\\\", \\\"{x:483,y:630,t:1528139595157};\\\", \\\"{x:460,y:623,t:1528139595173};\\\", \\\"{x:438,y:618,t:1528139595189};\\\", \\\"{x:415,y:610,t:1528139595207};\\\", \\\"{x:408,y:608,t:1528139595223};\\\", \\\"{x:407,y:608,t:1528139595239};\\\", \\\"{x:405,y:608,t:1528139595267};\\\", \\\"{x:405,y:607,t:1528139595348};\\\", \\\"{x:405,y:606,t:1528139595387};\\\", \\\"{x:404,y:606,t:1528139595411};\\\", \\\"{x:404,y:605,t:1528139595423};\\\", \\\"{x:402,y:604,t:1528139595439};\\\", \\\"{x:401,y:603,t:1528139595456};\\\", \\\"{x:399,y:602,t:1528139595473};\\\", \\\"{x:398,y:600,t:1528139595489};\\\", \\\"{x:396,y:600,t:1528139595506};\\\", \\\"{x:395,y:599,t:1528139595531};\\\", \\\"{x:394,y:599,t:1528139595538};\\\", \\\"{x:393,y:599,t:1528139595555};\\\", \\\"{x:392,y:599,t:1528139595578};\\\", \\\"{x:391,y:598,t:1528139595636};\\\", \\\"{x:405,y:597,t:1528139596109};\\\", \\\"{x:447,y:597,t:1528139596124};\\\", \\\"{x:594,y:611,t:1528139596140};\\\", \\\"{x:719,y:630,t:1528139596156};\\\", \\\"{x:885,y:654,t:1528139596173};\\\", \\\"{x:1054,y:683,t:1528139596189};\\\", \\\"{x:1200,y:714,t:1528139596206};\\\", \\\"{x:1332,y:750,t:1528139596223};\\\", \\\"{x:1443,y:781,t:1528139596240};\\\", \\\"{x:1515,y:805,t:1528139596257};\\\", \\\"{x:1552,y:815,t:1528139596274};\\\", \\\"{x:1573,y:823,t:1528139596289};\\\", \\\"{x:1583,y:828,t:1528139596306};\\\", \\\"{x:1584,y:828,t:1528139596324};\\\", \\\"{x:1585,y:829,t:1528139596485};\\\", \\\"{x:1584,y:829,t:1528139596492};\\\", \\\"{x:1564,y:829,t:1528139596507};\\\", \\\"{x:1537,y:829,t:1528139596524};\\\", \\\"{x:1504,y:826,t:1528139596540};\\\", \\\"{x:1466,y:816,t:1528139596558};\\\", \\\"{x:1445,y:809,t:1528139596574};\\\", \\\"{x:1429,y:802,t:1528139596590};\\\", \\\"{x:1419,y:796,t:1528139596607};\\\", \\\"{x:1417,y:795,t:1528139596624};\\\", \\\"{x:1416,y:795,t:1528139596641};\\\", \\\"{x:1416,y:793,t:1528139596772};\\\", \\\"{x:1416,y:791,t:1528139596780};\\\", \\\"{x:1416,y:790,t:1528139596792};\\\", \\\"{x:1416,y:787,t:1528139596808};\\\", \\\"{x:1413,y:785,t:1528139596824};\\\", \\\"{x:1407,y:782,t:1528139596842};\\\", \\\"{x:1403,y:779,t:1528139596857};\\\", \\\"{x:1398,y:774,t:1528139596875};\\\", \\\"{x:1392,y:771,t:1528139596892};\\\", \\\"{x:1392,y:770,t:1528139596907};\\\", \\\"{x:1391,y:769,t:1528139596924};\\\", \\\"{x:1389,y:769,t:1528139597140};\\\", \\\"{x:1388,y:769,t:1528139597158};\\\", \\\"{x:1387,y:769,t:1528139597174};\\\", \\\"{x:1386,y:769,t:1528139597191};\\\", \\\"{x:1385,y:769,t:1528139597276};\\\", \\\"{x:1384,y:769,t:1528139597308};\\\", \\\"{x:1384,y:768,t:1528139597472};\\\", \\\"{x:1383,y:766,t:1528139597490};\\\", \\\"{x:1383,y:765,t:1528139597507};\\\", \\\"{x:1382,y:765,t:1528139599540};\\\", \\\"{x:1364,y:766,t:1528139599548};\\\", \\\"{x:1317,y:768,t:1528139599558};\\\", \\\"{x:1200,y:768,t:1528139599576};\\\", \\\"{x:1089,y:768,t:1528139599592};\\\", \\\"{x:984,y:768,t:1528139599609};\\\", \\\"{x:884,y:768,t:1528139599626};\\\", \\\"{x:758,y:765,t:1528139599642};\\\", \\\"{x:705,y:757,t:1528139599658};\\\", \\\"{x:670,y:752,t:1528139599676};\\\", \\\"{x:658,y:751,t:1528139599692};\\\", \\\"{x:653,y:751,t:1528139599709};\\\", \\\"{x:648,y:753,t:1528139599726};\\\", \\\"{x:642,y:757,t:1528139599743};\\\", \\\"{x:633,y:762,t:1528139599759};\\\", \\\"{x:617,y:770,t:1528139599775};\\\", \\\"{x:604,y:775,t:1528139599793};\\\", \\\"{x:587,y:778,t:1528139599809};\\\", \\\"{x:566,y:780,t:1528139599825};\\\", \\\"{x:522,y:780,t:1528139599843};\\\", \\\"{x:502,y:780,t:1528139599859};\\\", \\\"{x:486,y:776,t:1528139599876};\\\", \\\"{x:472,y:773,t:1528139599893};\\\", \\\"{x:461,y:769,t:1528139599911};\\\", \\\"{x:459,y:769,t:1528139599925};\\\", \\\"{x:459,y:768,t:1528139600027};\\\", \\\"{x:459,y:766,t:1528139600043};\\\", \\\"{x:459,y:764,t:1528139600060};\\\", \\\"{x:459,y:763,t:1528139600077};\\\", \\\"{x:459,y:761,t:1528139600092};\\\", \\\"{x:458,y:760,t:1528139601643};\\\" ] }, { \\\"rt\\\": 24947, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 242610, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -J -D -D -D -K -K -4\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:420,y:755,t:1528139601825};\\\", \\\"{x:411,y:755,t:1528139601836};\\\", \\\"{x:406,y:755,t:1528139601850};\\\", \\\"{x:392,y:755,t:1528139601861};\\\", \\\"{x:379,y:758,t:1528139601877};\\\", \\\"{x:362,y:761,t:1528139601894};\\\", \\\"{x:334,y:764,t:1528139601915};\\\", \\\"{x:275,y:773,t:1528139601994};\\\", \\\"{x:248,y:778,t:1528139602011};\\\", \\\"{x:234,y:780,t:1528139602027};\\\", \\\"{x:220,y:783,t:1528139602044};\\\", \\\"{x:206,y:784,t:1528139602061};\\\", \\\"{x:196,y:785,t:1528139602078};\\\", \\\"{x:189,y:786,t:1528139602094};\\\", \\\"{x:180,y:786,t:1528139602111};\\\", \\\"{x:172,y:786,t:1528139602128};\\\", \\\"{x:165,y:786,t:1528139602144};\\\", \\\"{x:158,y:786,t:1528139602161};\\\", \\\"{x:154,y:786,t:1528139602177};\\\", \\\"{x:150,y:786,t:1528139602195};\\\", \\\"{x:147,y:786,t:1528139602212};\\\", \\\"{x:143,y:786,t:1528139602228};\\\", \\\"{x:142,y:786,t:1528139602245};\\\", \\\"{x:141,y:786,t:1528139602262};\\\", \\\"{x:140,y:786,t:1528139602278};\\\", \\\"{x:139,y:786,t:1528139602295};\\\", \\\"{x:138,y:786,t:1528139602315};\\\", \\\"{x:137,y:786,t:1528139602348};\\\", \\\"{x:136,y:786,t:1528139602403};\\\", \\\"{x:134,y:786,t:1528139602411};\\\", \\\"{x:130,y:785,t:1528139602428};\\\", \\\"{x:129,y:785,t:1528139602445};\\\", \\\"{x:128,y:784,t:1528139602462};\\\", \\\"{x:121,y:781,t:1528139602478};\\\", \\\"{x:114,y:778,t:1528139602495};\\\", \\\"{x:106,y:774,t:1528139602512};\\\", \\\"{x:98,y:769,t:1528139602528};\\\", \\\"{x:87,y:765,t:1528139602545};\\\", \\\"{x:78,y:761,t:1528139602561};\\\", \\\"{x:67,y:756,t:1528139602577};\\\", \\\"{x:64,y:755,t:1528139602595};\\\", \\\"{x:61,y:753,t:1528139602611};\\\", \\\"{x:56,y:751,t:1528139602628};\\\", \\\"{x:50,y:748,t:1528139602645};\\\", \\\"{x:45,y:746,t:1528139602662};\\\", \\\"{x:42,y:745,t:1528139602679};\\\", \\\"{x:41,y:745,t:1528139602732};\\\", \\\"{x:40,y:745,t:1528139602780};\\\", \\\"{x:40,y:743,t:1528139602803};\\\", \\\"{x:40,y:740,t:1528139602813};\\\", \\\"{x:40,y:731,t:1528139602829};\\\", \\\"{x:40,y:725,t:1528139602845};\\\", \\\"{x:40,y:719,t:1528139602862};\\\", \\\"{x:40,y:710,t:1528139602879};\\\", \\\"{x:40,y:701,t:1528139602896};\\\", \\\"{x:43,y:693,t:1528139602912};\\\", \\\"{x:48,y:683,t:1528139602930};\\\", \\\"{x:53,y:677,t:1528139602944};\\\", \\\"{x:58,y:673,t:1528139602961};\\\", \\\"{x:66,y:665,t:1528139602979};\\\", \\\"{x:74,y:660,t:1528139602994};\\\", \\\"{x:81,y:656,t:1528139603012};\\\", \\\"{x:89,y:651,t:1528139603029};\\\", \\\"{x:98,y:646,t:1528139603045};\\\", \\\"{x:107,y:641,t:1528139603062};\\\", \\\"{x:111,y:638,t:1528139603079};\\\", \\\"{x:113,y:635,t:1528139603095};\\\", \\\"{x:116,y:631,t:1528139603112};\\\", \\\"{x:119,y:628,t:1528139603129};\\\", \\\"{x:123,y:624,t:1528139603145};\\\", \\\"{x:127,y:618,t:1528139603162};\\\", \\\"{x:135,y:607,t:1528139603180};\\\", \\\"{x:140,y:597,t:1528139603196};\\\", \\\"{x:144,y:590,t:1528139603212};\\\", \\\"{x:145,y:587,t:1528139603229};\\\", \\\"{x:148,y:583,t:1528139603246};\\\", \\\"{x:151,y:578,t:1528139603262};\\\", \\\"{x:154,y:574,t:1528139603279};\\\", \\\"{x:157,y:568,t:1528139603297};\\\", \\\"{x:161,y:562,t:1528139603311};\\\", \\\"{x:165,y:559,t:1528139603328};\\\", \\\"{x:172,y:552,t:1528139603346};\\\", \\\"{x:183,y:545,t:1528139603363};\\\", \\\"{x:193,y:540,t:1528139603379};\\\", \\\"{x:208,y:531,t:1528139603396};\\\", \\\"{x:227,y:521,t:1528139603412};\\\", \\\"{x:249,y:511,t:1528139603429};\\\", \\\"{x:273,y:499,t:1528139603446};\\\", \\\"{x:306,y:491,t:1528139603463};\\\", \\\"{x:354,y:483,t:1528139603479};\\\", \\\"{x:395,y:479,t:1528139603495};\\\", \\\"{x:437,y:473,t:1528139603513};\\\", \\\"{x:484,y:467,t:1528139603528};\\\", \\\"{x:516,y:466,t:1528139603546};\\\", \\\"{x:537,y:466,t:1528139603562};\\\", \\\"{x:550,y:465,t:1528139603579};\\\", \\\"{x:553,y:464,t:1528139603596};\\\", \\\"{x:556,y:464,t:1528139604139};\\\", \\\"{x:560,y:464,t:1528139604147};\\\", \\\"{x:570,y:457,t:1528139604163};\\\", \\\"{x:575,y:453,t:1528139604180};\\\", \\\"{x:579,y:449,t:1528139604196};\\\", \\\"{x:585,y:445,t:1528139604213};\\\", \\\"{x:589,y:443,t:1528139604230};\\\", \\\"{x:592,y:442,t:1528139604246};\\\", \\\"{x:593,y:441,t:1528139604264};\\\", \\\"{x:595,y:440,t:1528139604280};\\\", \\\"{x:597,y:439,t:1528139604297};\\\", \\\"{x:601,y:437,t:1528139604313};\\\", \\\"{x:602,y:435,t:1528139604331};\\\", \\\"{x:604,y:435,t:1528139604346};\\\", \\\"{x:606,y:432,t:1528139604363};\\\", \\\"{x:613,y:428,t:1528139604380};\\\", \\\"{x:618,y:425,t:1528139604396};\\\", \\\"{x:621,y:423,t:1528139604413};\\\", \\\"{x:623,y:422,t:1528139604430};\\\", \\\"{x:624,y:421,t:1528139604447};\\\", \\\"{x:625,y:421,t:1528139604463};\\\", \\\"{x:628,y:420,t:1528139604480};\\\", \\\"{x:630,y:420,t:1528139604498};\\\", \\\"{x:634,y:420,t:1528139604513};\\\", \\\"{x:650,y:420,t:1528139604532};\\\", \\\"{x:658,y:420,t:1528139604546};\\\", \\\"{x:691,y:420,t:1528139604563};\\\", \\\"{x:724,y:420,t:1528139604580};\\\", \\\"{x:761,y:420,t:1528139604596};\\\", \\\"{x:805,y:424,t:1528139604614};\\\", \\\"{x:856,y:431,t:1528139604631};\\\", \\\"{x:923,y:442,t:1528139604646};\\\", \\\"{x:1014,y:465,t:1528139604663};\\\", \\\"{x:1149,y:501,t:1528139604680};\\\", \\\"{x:1316,y:535,t:1528139604697};\\\", \\\"{x:1495,y:560,t:1528139604714};\\\", \\\"{x:1766,y:602,t:1528139604731};\\\", \\\"{x:1850,y:613,t:1528139604746};\\\", \\\"{x:1919,y:660,t:1528139604763};\\\", \\\"{x:1919,y:696,t:1528139604780};\\\", \\\"{x:1919,y:727,t:1528139604797};\\\", \\\"{x:1919,y:748,t:1528139604813};\\\", \\\"{x:1919,y:760,t:1528139604829};\\\", \\\"{x:1919,y:763,t:1528139604847};\\\", \\\"{x:1917,y:764,t:1528139604891};\\\", \\\"{x:1910,y:766,t:1528139604898};\\\", \\\"{x:1899,y:767,t:1528139604914};\\\", \\\"{x:1867,y:772,t:1528139604930};\\\", \\\"{x:1849,y:776,t:1528139604947};\\\", \\\"{x:1820,y:780,t:1528139604964};\\\", \\\"{x:1792,y:783,t:1528139604980};\\\", \\\"{x:1764,y:788,t:1528139604997};\\\", \\\"{x:1735,y:793,t:1528139605014};\\\", \\\"{x:1711,y:793,t:1528139605030};\\\", \\\"{x:1690,y:793,t:1528139605046};\\\", \\\"{x:1667,y:793,t:1528139605064};\\\", \\\"{x:1648,y:793,t:1528139605081};\\\", \\\"{x:1624,y:787,t:1528139605097};\\\", \\\"{x:1594,y:778,t:1528139605114};\\\", \\\"{x:1541,y:764,t:1528139605131};\\\", \\\"{x:1510,y:755,t:1528139605147};\\\", \\\"{x:1483,y:748,t:1528139605164};\\\", \\\"{x:1461,y:744,t:1528139605180};\\\", \\\"{x:1434,y:738,t:1528139605197};\\\", \\\"{x:1410,y:732,t:1528139605214};\\\", \\\"{x:1393,y:730,t:1528139605231};\\\", \\\"{x:1379,y:727,t:1528139605247};\\\", \\\"{x:1370,y:726,t:1528139605264};\\\", \\\"{x:1363,y:723,t:1528139605281};\\\", \\\"{x:1361,y:723,t:1528139605298};\\\", \\\"{x:1358,y:723,t:1528139605315};\\\", \\\"{x:1355,y:723,t:1528139605331};\\\", \\\"{x:1354,y:723,t:1528139605347};\\\", \\\"{x:1352,y:723,t:1528139605379};\\\", \\\"{x:1351,y:723,t:1528139605411};\\\", \\\"{x:1349,y:723,t:1528139605435};\\\", \\\"{x:1348,y:723,t:1528139605448};\\\", \\\"{x:1347,y:723,t:1528139605465};\\\", \\\"{x:1344,y:725,t:1528139605481};\\\", \\\"{x:1343,y:725,t:1528139605498};\\\", \\\"{x:1341,y:726,t:1528139605515};\\\", \\\"{x:1339,y:727,t:1528139605532};\\\", \\\"{x:1335,y:727,t:1528139605547};\\\", \\\"{x:1332,y:728,t:1528139605564};\\\", \\\"{x:1324,y:731,t:1528139605582};\\\", \\\"{x:1321,y:732,t:1528139605597};\\\", \\\"{x:1316,y:735,t:1528139605615};\\\", \\\"{x:1311,y:738,t:1528139605631};\\\", \\\"{x:1307,y:741,t:1528139605649};\\\", \\\"{x:1304,y:745,t:1528139605664};\\\", \\\"{x:1303,y:746,t:1528139605681};\\\", \\\"{x:1300,y:751,t:1528139605699};\\\", \\\"{x:1299,y:757,t:1528139605714};\\\", \\\"{x:1296,y:766,t:1528139605731};\\\", \\\"{x:1296,y:771,t:1528139605749};\\\", \\\"{x:1296,y:773,t:1528139605764};\\\", \\\"{x:1296,y:776,t:1528139605781};\\\", \\\"{x:1295,y:777,t:1528139605798};\\\", \\\"{x:1295,y:778,t:1528139605828};\\\", \\\"{x:1295,y:775,t:1528139605987};\\\", \\\"{x:1295,y:765,t:1528139605998};\\\", \\\"{x:1306,y:746,t:1528139606015};\\\", \\\"{x:1319,y:724,t:1528139606031};\\\", \\\"{x:1328,y:702,t:1528139606048};\\\", \\\"{x:1331,y:686,t:1528139606064};\\\", \\\"{x:1331,y:677,t:1528139606082};\\\", \\\"{x:1331,y:674,t:1528139606098};\\\", \\\"{x:1331,y:670,t:1528139606115};\\\", \\\"{x:1327,y:668,t:1528139606132};\\\", \\\"{x:1326,y:667,t:1528139606148};\\\", \\\"{x:1325,y:667,t:1528139606166};\\\", \\\"{x:1324,y:667,t:1528139606182};\\\", \\\"{x:1323,y:666,t:1528139606198};\\\", \\\"{x:1319,y:664,t:1528139606215};\\\", \\\"{x:1313,y:661,t:1528139606232};\\\", \\\"{x:1310,y:660,t:1528139606249};\\\", \\\"{x:1303,y:657,t:1528139606266};\\\", \\\"{x:1298,y:655,t:1528139606281};\\\", \\\"{x:1291,y:653,t:1528139606298};\\\", \\\"{x:1286,y:651,t:1528139606315};\\\", \\\"{x:1285,y:651,t:1528139606332};\\\", \\\"{x:1285,y:652,t:1528139606579};\\\", \\\"{x:1285,y:654,t:1528139606587};\\\", \\\"{x:1286,y:656,t:1528139606598};\\\", \\\"{x:1287,y:658,t:1528139606615};\\\", \\\"{x:1291,y:663,t:1528139606632};\\\", \\\"{x:1298,y:671,t:1528139606648};\\\", \\\"{x:1308,y:681,t:1528139606666};\\\", \\\"{x:1317,y:687,t:1528139606683};\\\", \\\"{x:1329,y:695,t:1528139606699};\\\", \\\"{x:1349,y:707,t:1528139606715};\\\", \\\"{x:1366,y:713,t:1528139606732};\\\", \\\"{x:1386,y:719,t:1528139606749};\\\", \\\"{x:1404,y:724,t:1528139606765};\\\", \\\"{x:1424,y:729,t:1528139606783};\\\", \\\"{x:1445,y:731,t:1528139606799};\\\", \\\"{x:1471,y:739,t:1528139606815};\\\", \\\"{x:1499,y:746,t:1528139606832};\\\", \\\"{x:1525,y:752,t:1528139606849};\\\", \\\"{x:1544,y:755,t:1528139606865};\\\", \\\"{x:1564,y:759,t:1528139606883};\\\", \\\"{x:1578,y:763,t:1528139606899};\\\", \\\"{x:1592,y:768,t:1528139606916};\\\", \\\"{x:1594,y:768,t:1528139606933};\\\", \\\"{x:1596,y:768,t:1528139606948};\\\", \\\"{x:1597,y:768,t:1528139606987};\\\", \\\"{x:1597,y:769,t:1528139607019};\\\", \\\"{x:1597,y:771,t:1528139607036};\\\", \\\"{x:1597,y:775,t:1528139607049};\\\", \\\"{x:1597,y:779,t:1528139607065};\\\", \\\"{x:1597,y:785,t:1528139607083};\\\", \\\"{x:1597,y:792,t:1528139607099};\\\", \\\"{x:1597,y:795,t:1528139607116};\\\", \\\"{x:1595,y:798,t:1528139607133};\\\", \\\"{x:1595,y:801,t:1528139607149};\\\", \\\"{x:1593,y:804,t:1528139607164};\\\", \\\"{x:1591,y:809,t:1528139607182};\\\", \\\"{x:1588,y:817,t:1528139607199};\\\", \\\"{x:1587,y:821,t:1528139607215};\\\", \\\"{x:1585,y:825,t:1528139607232};\\\", \\\"{x:1584,y:828,t:1528139607249};\\\", \\\"{x:1582,y:832,t:1528139607265};\\\", \\\"{x:1579,y:836,t:1528139607281};\\\", \\\"{x:1578,y:838,t:1528139607298};\\\", \\\"{x:1577,y:840,t:1528139607315};\\\", \\\"{x:1575,y:842,t:1528139607332};\\\", \\\"{x:1574,y:843,t:1528139607349};\\\", \\\"{x:1572,y:844,t:1528139607371};\\\", \\\"{x:1572,y:845,t:1528139607386};\\\", \\\"{x:1571,y:845,t:1528139607399};\\\", \\\"{x:1569,y:846,t:1528139607415};\\\", \\\"{x:1566,y:848,t:1528139607432};\\\", \\\"{x:1564,y:848,t:1528139607450};\\\", \\\"{x:1563,y:848,t:1528139607465};\\\", \\\"{x:1562,y:848,t:1528139607499};\\\", \\\"{x:1558,y:847,t:1528139607517};\\\", \\\"{x:1553,y:839,t:1528139607532};\\\", \\\"{x:1547,y:828,t:1528139607550};\\\", \\\"{x:1540,y:811,t:1528139607566};\\\", \\\"{x:1532,y:793,t:1528139607581};\\\", \\\"{x:1528,y:783,t:1528139607598};\\\", \\\"{x:1522,y:769,t:1528139607615};\\\", \\\"{x:1517,y:756,t:1528139607632};\\\", \\\"{x:1514,y:750,t:1528139607649};\\\", \\\"{x:1512,y:739,t:1528139607666};\\\", \\\"{x:1511,y:737,t:1528139607682};\\\", \\\"{x:1510,y:731,t:1528139607698};\\\", \\\"{x:1510,y:724,t:1528139607716};\\\", \\\"{x:1509,y:715,t:1528139607732};\\\", \\\"{x:1508,y:710,t:1528139607750};\\\", \\\"{x:1506,y:705,t:1528139607766};\\\", \\\"{x:1504,y:692,t:1528139607782};\\\", \\\"{x:1502,y:682,t:1528139607799};\\\", \\\"{x:1500,y:673,t:1528139607816};\\\", \\\"{x:1497,y:665,t:1528139607833};\\\", \\\"{x:1496,y:658,t:1528139607849};\\\", \\\"{x:1496,y:654,t:1528139607867};\\\", \\\"{x:1495,y:651,t:1528139607882};\\\", \\\"{x:1495,y:646,t:1528139607899};\\\", \\\"{x:1495,y:642,t:1528139607916};\\\", \\\"{x:1495,y:635,t:1528139607932};\\\", \\\"{x:1500,y:623,t:1528139607950};\\\", \\\"{x:1514,y:603,t:1528139607966};\\\", \\\"{x:1542,y:566,t:1528139607983};\\\", \\\"{x:1568,y:534,t:1528139607999};\\\", \\\"{x:1586,y:510,t:1528139608017};\\\", \\\"{x:1600,y:492,t:1528139608034};\\\", \\\"{x:1612,y:481,t:1528139608050};\\\", \\\"{x:1618,y:476,t:1528139608066};\\\", \\\"{x:1622,y:473,t:1528139608082};\\\", \\\"{x:1623,y:472,t:1528139608099};\\\", \\\"{x:1625,y:470,t:1528139608116};\\\", \\\"{x:1626,y:469,t:1528139608133};\\\", \\\"{x:1626,y:467,t:1528139608150};\\\", \\\"{x:1627,y:464,t:1528139608166};\\\", \\\"{x:1627,y:463,t:1528139608183};\\\", \\\"{x:1627,y:461,t:1528139608199};\\\", \\\"{x:1627,y:458,t:1528139608216};\\\", \\\"{x:1627,y:455,t:1528139608233};\\\", \\\"{x:1627,y:452,t:1528139608249};\\\", \\\"{x:1627,y:450,t:1528139608266};\\\", \\\"{x:1626,y:446,t:1528139608283};\\\", \\\"{x:1626,y:444,t:1528139608300};\\\", \\\"{x:1625,y:442,t:1528139608317};\\\", \\\"{x:1625,y:441,t:1528139608333};\\\", \\\"{x:1625,y:440,t:1528139608350};\\\", \\\"{x:1625,y:439,t:1528139608367};\\\", \\\"{x:1625,y:438,t:1528139608476};\\\", \\\"{x:1624,y:436,t:1528139608491};\\\", \\\"{x:1622,y:435,t:1528139608507};\\\", \\\"{x:1621,y:434,t:1528139608517};\\\", \\\"{x:1619,y:434,t:1528139608534};\\\", \\\"{x:1616,y:432,t:1528139608558};\\\", \\\"{x:1615,y:432,t:1528139608566};\\\", \\\"{x:1614,y:432,t:1528139608583};\\\", \\\"{x:1613,y:432,t:1528139608600};\\\", \\\"{x:1612,y:431,t:1528139608616};\\\", \\\"{x:1611,y:431,t:1528139608651};\\\", \\\"{x:1609,y:430,t:1528139608666};\\\", \\\"{x:1598,y:430,t:1528139615175};\\\", \\\"{x:1562,y:434,t:1528139615187};\\\", \\\"{x:1514,y:434,t:1528139615203};\\\", \\\"{x:1469,y:434,t:1528139615222};\\\", \\\"{x:1430,y:434,t:1528139615238};\\\", \\\"{x:1407,y:434,t:1528139615255};\\\", \\\"{x:1393,y:432,t:1528139615272};\\\", \\\"{x:1386,y:430,t:1528139615288};\\\", \\\"{x:1385,y:430,t:1528139615306};\\\", \\\"{x:1386,y:430,t:1528139615419};\\\", \\\"{x:1387,y:430,t:1528139615427};\\\", \\\"{x:1388,y:430,t:1528139615439};\\\", \\\"{x:1390,y:430,t:1528139615455};\\\", \\\"{x:1394,y:431,t:1528139615473};\\\", \\\"{x:1397,y:433,t:1528139615489};\\\", \\\"{x:1401,y:433,t:1528139615505};\\\", \\\"{x:1407,y:433,t:1528139615523};\\\", \\\"{x:1408,y:433,t:1528139615540};\\\", \\\"{x:1411,y:433,t:1528139615559};\\\", \\\"{x:1412,y:433,t:1528139615572};\\\", \\\"{x:1413,y:433,t:1528139615589};\\\", \\\"{x:1415,y:433,t:1528139615605};\\\", \\\"{x:1416,y:433,t:1528139615622};\\\", \\\"{x:1417,y:433,t:1528139617419};\\\", \\\"{x:1419,y:431,t:1528139617523};\\\", \\\"{x:1437,y:428,t:1528139617534};\\\", \\\"{x:1500,y:419,t:1528139617557};\\\", \\\"{x:1538,y:415,t:1528139617574};\\\", \\\"{x:1567,y:415,t:1528139617590};\\\", \\\"{x:1586,y:415,t:1528139617607};\\\", \\\"{x:1592,y:415,t:1528139617624};\\\", \\\"{x:1593,y:415,t:1528139617640};\\\", \\\"{x:1596,y:415,t:1528139617811};\\\", \\\"{x:1598,y:415,t:1528139617825};\\\", \\\"{x:1602,y:416,t:1528139617841};\\\", \\\"{x:1605,y:419,t:1528139617857};\\\", \\\"{x:1607,y:420,t:1528139617875};\\\", \\\"{x:1608,y:420,t:1528139617892};\\\", \\\"{x:1609,y:421,t:1528139617908};\\\", \\\"{x:1610,y:422,t:1528139618156};\\\", \\\"{x:1611,y:422,t:1528139618171};\\\", \\\"{x:1612,y:423,t:1528139618179};\\\", \\\"{x:1615,y:425,t:1528139618195};\\\", \\\"{x:1617,y:426,t:1528139618208};\\\", \\\"{x:1620,y:428,t:1528139618224};\\\", \\\"{x:1623,y:430,t:1528139618242};\\\", \\\"{x:1624,y:430,t:1528139618571};\\\", \\\"{x:1624,y:431,t:1528139618579};\\\", \\\"{x:1624,y:432,t:1528139618595};\\\", \\\"{x:1623,y:432,t:1528139618611};\\\", \\\"{x:1622,y:432,t:1528139618625};\\\", \\\"{x:1621,y:433,t:1528139618642};\\\", \\\"{x:1620,y:433,t:1528139618659};\\\", \\\"{x:1619,y:433,t:1528139618743};\\\", \\\"{x:1618,y:434,t:1528139618759};\\\", \\\"{x:1616,y:434,t:1528139618875};\\\", \\\"{x:1615,y:434,t:1528139618899};\\\", \\\"{x:1614,y:434,t:1528139618915};\\\", \\\"{x:1613,y:433,t:1528139618931};\\\", \\\"{x:1609,y:436,t:1528139621965};\\\", \\\"{x:1598,y:452,t:1528139621978};\\\", \\\"{x:1565,y:485,t:1528139621994};\\\", \\\"{x:1542,y:506,t:1528139622010};\\\", \\\"{x:1521,y:534,t:1528139622028};\\\", \\\"{x:1509,y:558,t:1528139622045};\\\", \\\"{x:1502,y:586,t:1528139622060};\\\", \\\"{x:1495,y:608,t:1528139622077};\\\", \\\"{x:1495,y:609,t:1528139622114};\\\", \\\"{x:1497,y:611,t:1528139622411};\\\", \\\"{x:1497,y:612,t:1528139622428};\\\", \\\"{x:1499,y:613,t:1528139622459};\\\", \\\"{x:1500,y:613,t:1528139622475};\\\", \\\"{x:1500,y:614,t:1528139622491};\\\", \\\"{x:1502,y:615,t:1528139622499};\\\", \\\"{x:1504,y:617,t:1528139622512};\\\", \\\"{x:1509,y:622,t:1528139622528};\\\", \\\"{x:1514,y:626,t:1528139622546};\\\", \\\"{x:1517,y:628,t:1528139622562};\\\", \\\"{x:1519,y:630,t:1528139622578};\\\", \\\"{x:1520,y:631,t:1528139622595};\\\", \\\"{x:1522,y:631,t:1528139622643};\\\", \\\"{x:1524,y:632,t:1528139622662};\\\", \\\"{x:1526,y:633,t:1528139622678};\\\", \\\"{x:1530,y:635,t:1528139622694};\\\", \\\"{x:1532,y:637,t:1528139622711};\\\", \\\"{x:1533,y:637,t:1528139622728};\\\", \\\"{x:1532,y:637,t:1528139622827};\\\", \\\"{x:1531,y:637,t:1528139622835};\\\", \\\"{x:1530,y:637,t:1528139622845};\\\", \\\"{x:1528,y:637,t:1528139622862};\\\", \\\"{x:1524,y:634,t:1528139622879};\\\", \\\"{x:1521,y:633,t:1528139622895};\\\", \\\"{x:1519,y:632,t:1528139622914};\\\", \\\"{x:1518,y:631,t:1528139622928};\\\", \\\"{x:1516,y:630,t:1528139622945};\\\", \\\"{x:1514,y:630,t:1528139622970};\\\", \\\"{x:1514,y:629,t:1528139623002};\\\", \\\"{x:1513,y:628,t:1528139623042};\\\", \\\"{x:1512,y:628,t:1528139624027};\\\", \\\"{x:1510,y:628,t:1528139624035};\\\", \\\"{x:1505,y:628,t:1528139624049};\\\", \\\"{x:1479,y:628,t:1528139624062};\\\", \\\"{x:1438,y:635,t:1528139624080};\\\", \\\"{x:1402,y:640,t:1528139624096};\\\", \\\"{x:1370,y:640,t:1528139624112};\\\", \\\"{x:1308,y:647,t:1528139624130};\\\", \\\"{x:1282,y:650,t:1528139624146};\\\", \\\"{x:1213,y:667,t:1528139624163};\\\", \\\"{x:1153,y:680,t:1528139624180};\\\", \\\"{x:1100,y:688,t:1528139624196};\\\", \\\"{x:1062,y:691,t:1528139624212};\\\", \\\"{x:1039,y:691,t:1528139624231};\\\", \\\"{x:1019,y:691,t:1528139624246};\\\", \\\"{x:999,y:691,t:1528139624263};\\\", \\\"{x:983,y:691,t:1528139624279};\\\", \\\"{x:975,y:691,t:1528139624295};\\\", \\\"{x:969,y:691,t:1528139624312};\\\", \\\"{x:953,y:691,t:1528139624330};\\\", \\\"{x:947,y:691,t:1528139624346};\\\", \\\"{x:909,y:691,t:1528139624362};\\\", \\\"{x:866,y:683,t:1528139624380};\\\", \\\"{x:803,y:670,t:1528139624396};\\\", \\\"{x:734,y:650,t:1528139624412};\\\", \\\"{x:657,y:630,t:1528139624431};\\\", \\\"{x:609,y:616,t:1528139624447};\\\", \\\"{x:589,y:607,t:1528139624463};\\\", \\\"{x:582,y:604,t:1528139624479};\\\", \\\"{x:581,y:603,t:1528139624496};\\\", \\\"{x:581,y:601,t:1528139624538};\\\", \\\"{x:582,y:599,t:1528139624546};\\\", \\\"{x:591,y:594,t:1528139624563};\\\", \\\"{x:606,y:590,t:1528139624580};\\\", \\\"{x:623,y:585,t:1528139624596};\\\", \\\"{x:641,y:580,t:1528139624613};\\\", \\\"{x:655,y:577,t:1528139624630};\\\", \\\"{x:666,y:575,t:1528139624647};\\\", \\\"{x:675,y:574,t:1528139624663};\\\", \\\"{x:678,y:574,t:1528139624680};\\\", \\\"{x:680,y:574,t:1528139624696};\\\", \\\"{x:680,y:576,t:1528139624763};\\\", \\\"{x:676,y:581,t:1528139624781};\\\", \\\"{x:668,y:587,t:1528139624797};\\\", \\\"{x:655,y:593,t:1528139624813};\\\", \\\"{x:641,y:601,t:1528139624830};\\\", \\\"{x:628,y:609,t:1528139624846};\\\", \\\"{x:616,y:614,t:1528139624865};\\\", \\\"{x:609,y:615,t:1528139624880};\\\", \\\"{x:604,y:617,t:1528139624896};\\\", \\\"{x:597,y:621,t:1528139624914};\\\", \\\"{x:588,y:625,t:1528139624930};\\\", \\\"{x:576,y:631,t:1528139624947};\\\", \\\"{x:563,y:635,t:1528139624964};\\\", \\\"{x:547,y:637,t:1528139624980};\\\", \\\"{x:532,y:639,t:1528139624997};\\\", \\\"{x:517,y:639,t:1528139625014};\\\", \\\"{x:506,y:639,t:1528139625029};\\\", \\\"{x:493,y:639,t:1528139625048};\\\", \\\"{x:486,y:639,t:1528139625064};\\\", \\\"{x:484,y:639,t:1528139625080};\\\", \\\"{x:479,y:639,t:1528139625097};\\\", \\\"{x:472,y:637,t:1528139625113};\\\", \\\"{x:469,y:635,t:1528139625130};\\\", \\\"{x:468,y:635,t:1528139625146};\\\", \\\"{x:466,y:635,t:1528139625164};\\\", \\\"{x:463,y:634,t:1528139625179};\\\", \\\"{x:460,y:632,t:1528139625196};\\\", \\\"{x:459,y:631,t:1528139625213};\\\", \\\"{x:456,y:631,t:1528139625229};\\\", \\\"{x:454,y:631,t:1528139625250};\\\", \\\"{x:452,y:631,t:1528139625263};\\\", \\\"{x:447,y:631,t:1528139625281};\\\", \\\"{x:440,y:631,t:1528139625297};\\\", \\\"{x:432,y:633,t:1528139625313};\\\", \\\"{x:421,y:633,t:1528139625330};\\\", \\\"{x:412,y:635,t:1528139625347};\\\", \\\"{x:401,y:637,t:1528139625364};\\\", \\\"{x:382,y:639,t:1528139625381};\\\", \\\"{x:368,y:639,t:1528139625397};\\\", \\\"{x:362,y:639,t:1528139625414};\\\", \\\"{x:360,y:639,t:1528139625431};\\\", \\\"{x:359,y:639,t:1528139625459};\\\", \\\"{x:360,y:639,t:1528139625602};\\\", \\\"{x:364,y:639,t:1528139625614};\\\", \\\"{x:377,y:636,t:1528139625632};\\\", \\\"{x:387,y:633,t:1528139625647};\\\", \\\"{x:388,y:633,t:1528139625663};\\\", \\\"{x:390,y:633,t:1528139625680};\\\", \\\"{x:391,y:633,t:1528139625697};\\\", \\\"{x:393,y:634,t:1528139626274};\\\", \\\"{x:401,y:642,t:1528139626283};\\\", \\\"{x:419,y:657,t:1528139626300};\\\", \\\"{x:443,y:678,t:1528139626314};\\\", \\\"{x:455,y:689,t:1528139626332};\\\", \\\"{x:472,y:708,t:1528139626347};\\\", \\\"{x:485,y:724,t:1528139626364};\\\", \\\"{x:492,y:733,t:1528139626381};\\\", \\\"{x:501,y:743,t:1528139626398};\\\", \\\"{x:504,y:746,t:1528139626415};\\\", \\\"{x:507,y:748,t:1528139626431};\\\", \\\"{x:509,y:750,t:1528139626448};\\\", \\\"{x:509,y:751,t:1528139626466};\\\", \\\"{x:510,y:751,t:1528139626515};\\\", \\\"{x:512,y:751,t:1528139626539};\\\", \\\"{x:512,y:752,t:1528139626714};\\\", \\\"{x:512,y:752,t:1528139626790};\\\" ] }, { \\\"rt\\\": 15301, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 259139, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -A -C -C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:753,t:1528139628100};\\\", \\\"{x:512,y:754,t:1528139628323};\\\", \\\"{x:511,y:754,t:1528139628339};\\\", \\\"{x:510,y:754,t:1528139628350};\\\", \\\"{x:508,y:754,t:1528139628366};\\\", \\\"{x:504,y:754,t:1528139628383};\\\", \\\"{x:500,y:754,t:1528139628400};\\\", \\\"{x:498,y:754,t:1528139628416};\\\", \\\"{x:495,y:756,t:1528139628433};\\\", \\\"{x:492,y:756,t:1528139628450};\\\", \\\"{x:490,y:757,t:1528139628466};\\\", \\\"{x:485,y:759,t:1528139628482};\\\", \\\"{x:476,y:762,t:1528139628560};\\\", \\\"{x:475,y:762,t:1528139628565};\\\", \\\"{x:472,y:762,t:1528139628583};\\\", \\\"{x:470,y:762,t:1528139628599};\\\", \\\"{x:465,y:762,t:1528139628616};\\\", \\\"{x:459,y:761,t:1528139628633};\\\", \\\"{x:446,y:755,t:1528139628650};\\\", \\\"{x:429,y:747,t:1528139628666};\\\", \\\"{x:401,y:731,t:1528139628683};\\\", \\\"{x:375,y:713,t:1528139628700};\\\", \\\"{x:354,y:698,t:1528139628717};\\\", \\\"{x:337,y:686,t:1528139628734};\\\", \\\"{x:325,y:677,t:1528139628749};\\\", \\\"{x:313,y:665,t:1528139628767};\\\", \\\"{x:304,y:654,t:1528139628783};\\\", \\\"{x:291,y:634,t:1528139628800};\\\", \\\"{x:278,y:609,t:1528139628818};\\\", \\\"{x:264,y:585,t:1528139628833};\\\", \\\"{x:249,y:557,t:1528139628850};\\\", \\\"{x:244,y:540,t:1528139628867};\\\", \\\"{x:243,y:528,t:1528139628883};\\\", \\\"{x:243,y:515,t:1528139628900};\\\", \\\"{x:243,y:500,t:1528139628917};\\\", \\\"{x:248,y:480,t:1528139628932};\\\", \\\"{x:257,y:458,t:1528139628950};\\\", \\\"{x:269,y:430,t:1528139628967};\\\", \\\"{x:286,y:369,t:1528139628983};\\\", \\\"{x:300,y:338,t:1528139628999};\\\", \\\"{x:303,y:333,t:1528139629016};\\\", \\\"{x:304,y:332,t:1528139629033};\\\", \\\"{x:307,y:329,t:1528139629050};\\\", \\\"{x:311,y:327,t:1528139629066};\\\", \\\"{x:316,y:325,t:1528139629083};\\\", \\\"{x:326,y:321,t:1528139629100};\\\", \\\"{x:336,y:320,t:1528139629116};\\\", \\\"{x:344,y:320,t:1528139629133};\\\", \\\"{x:351,y:320,t:1528139629150};\\\", \\\"{x:348,y:309,t:1528139630395};\\\", \\\"{x:331,y:289,t:1528139630403};\\\", \\\"{x:311,y:273,t:1528139630415};\\\", \\\"{x:278,y:254,t:1528139630432};\\\", \\\"{x:269,y:251,t:1528139630449};\\\", \\\"{x:268,y:250,t:1528139630464};\\\", \\\"{x:269,y:250,t:1528139630707};\\\", \\\"{x:274,y:254,t:1528139630714};\\\", \\\"{x:279,y:256,t:1528139630730};\\\", \\\"{x:297,y:265,t:1528139630747};\\\", \\\"{x:339,y:281,t:1528139630764};\\\", \\\"{x:389,y:296,t:1528139630781};\\\", \\\"{x:431,y:300,t:1528139630797};\\\", \\\"{x:467,y:300,t:1528139630814};\\\", \\\"{x:514,y:304,t:1528139630831};\\\", \\\"{x:548,y:309,t:1528139630847};\\\", \\\"{x:570,y:314,t:1528139630865};\\\", \\\"{x:589,y:316,t:1528139630881};\\\", \\\"{x:606,y:319,t:1528139630897};\\\", \\\"{x:623,y:323,t:1528139630914};\\\", \\\"{x:653,y:330,t:1528139630931};\\\", \\\"{x:679,y:332,t:1528139630947};\\\", \\\"{x:710,y:337,t:1528139630964};\\\", \\\"{x:737,y:341,t:1528139630981};\\\", \\\"{x:766,y:344,t:1528139630997};\\\", \\\"{x:803,y:350,t:1528139631014};\\\", \\\"{x:850,y:356,t:1528139631030};\\\", \\\"{x:893,y:363,t:1528139631048};\\\", \\\"{x:926,y:368,t:1528139631064};\\\", \\\"{x:945,y:369,t:1528139631080};\\\", \\\"{x:960,y:372,t:1528139631097};\\\", \\\"{x:981,y:372,t:1528139631114};\\\", \\\"{x:1015,y:372,t:1528139631130};\\\", \\\"{x:1036,y:372,t:1528139631147};\\\", \\\"{x:1061,y:372,t:1528139631163};\\\", \\\"{x:1087,y:372,t:1528139631181};\\\", \\\"{x:1098,y:373,t:1528139631197};\\\", \\\"{x:1107,y:374,t:1528139631214};\\\", \\\"{x:1112,y:375,t:1528139631231};\\\", \\\"{x:1117,y:375,t:1528139631247};\\\", \\\"{x:1120,y:375,t:1528139631264};\\\", \\\"{x:1122,y:378,t:1528139632059};\\\", \\\"{x:1134,y:382,t:1528139632067};\\\", \\\"{x:1147,y:385,t:1528139632079};\\\", \\\"{x:1170,y:390,t:1528139632095};\\\", \\\"{x:1199,y:400,t:1528139632113};\\\", \\\"{x:1246,y:412,t:1528139632129};\\\", \\\"{x:1288,y:423,t:1528139632145};\\\", \\\"{x:1347,y:442,t:1528139632163};\\\", \\\"{x:1371,y:450,t:1528139632178};\\\", \\\"{x:1391,y:455,t:1528139632195};\\\", \\\"{x:1401,y:458,t:1528139632212};\\\", \\\"{x:1403,y:459,t:1528139632229};\\\", \\\"{x:1404,y:459,t:1528139632250};\\\", \\\"{x:1405,y:459,t:1528139632308};\\\", \\\"{x:1405,y:460,t:1528139632314};\\\", \\\"{x:1406,y:462,t:1528139632329};\\\", \\\"{x:1409,y:468,t:1528139632346};\\\", \\\"{x:1410,y:472,t:1528139632362};\\\", \\\"{x:1410,y:473,t:1528139632378};\\\", \\\"{x:1410,y:474,t:1528139632395};\\\", \\\"{x:1410,y:475,t:1528139632413};\\\", \\\"{x:1410,y:477,t:1528139632429};\\\", \\\"{x:1411,y:481,t:1528139632445};\\\", \\\"{x:1412,y:484,t:1528139632463};\\\", \\\"{x:1412,y:485,t:1528139632479};\\\", \\\"{x:1412,y:486,t:1528139632496};\\\", \\\"{x:1412,y:488,t:1528139632511};\\\", \\\"{x:1412,y:490,t:1528139632529};\\\", \\\"{x:1412,y:496,t:1528139632545};\\\", \\\"{x:1412,y:504,t:1528139632562};\\\", \\\"{x:1412,y:531,t:1528139632578};\\\", \\\"{x:1412,y:547,t:1528139632595};\\\", \\\"{x:1412,y:558,t:1528139632614};\\\", \\\"{x:1412,y:566,t:1528139632627};\\\", \\\"{x:1412,y:573,t:1528139632653};\\\", \\\"{x:1412,y:575,t:1528139632670};\\\", \\\"{x:1410,y:579,t:1528139632686};\\\", \\\"{x:1407,y:585,t:1528139632703};\\\", \\\"{x:1401,y:594,t:1528139632720};\\\", \\\"{x:1393,y:604,t:1528139632737};\\\", \\\"{x:1385,y:618,t:1528139632754};\\\", \\\"{x:1380,y:627,t:1528139632770};\\\", \\\"{x:1377,y:631,t:1528139632787};\\\", \\\"{x:1372,y:636,t:1528139632804};\\\", \\\"{x:1367,y:649,t:1528139632820};\\\", \\\"{x:1362,y:663,t:1528139632837};\\\", \\\"{x:1359,y:675,t:1528139632854};\\\", \\\"{x:1357,y:683,t:1528139632871};\\\", \\\"{x:1357,y:684,t:1528139632887};\\\", \\\"{x:1357,y:685,t:1528139632904};\\\", \\\"{x:1357,y:686,t:1528139632930};\\\", \\\"{x:1357,y:688,t:1528139632939};\\\", \\\"{x:1359,y:693,t:1528139632954};\\\", \\\"{x:1361,y:696,t:1528139632971};\\\", \\\"{x:1364,y:702,t:1528139632988};\\\", \\\"{x:1366,y:705,t:1528139633004};\\\", \\\"{x:1366,y:708,t:1528139633021};\\\", \\\"{x:1370,y:715,t:1528139633038};\\\", \\\"{x:1372,y:719,t:1528139633054};\\\", \\\"{x:1373,y:724,t:1528139633071};\\\", \\\"{x:1373,y:726,t:1528139633088};\\\", \\\"{x:1373,y:730,t:1528139633106};\\\", \\\"{x:1373,y:736,t:1528139633121};\\\", \\\"{x:1373,y:745,t:1528139633138};\\\", \\\"{x:1373,y:753,t:1528139633154};\\\", \\\"{x:1373,y:760,t:1528139633171};\\\", \\\"{x:1370,y:766,t:1528139633188};\\\", \\\"{x:1368,y:770,t:1528139633207};\\\", \\\"{x:1367,y:774,t:1528139633223};\\\", \\\"{x:1364,y:778,t:1528139633239};\\\", \\\"{x:1363,y:779,t:1528139633255};\\\", \\\"{x:1362,y:781,t:1528139633272};\\\", \\\"{x:1361,y:782,t:1528139633289};\\\", \\\"{x:1359,y:783,t:1528139633305};\\\", \\\"{x:1357,y:786,t:1528139633323};\\\", \\\"{x:1354,y:788,t:1528139633339};\\\", \\\"{x:1349,y:790,t:1528139633356};\\\", \\\"{x:1342,y:792,t:1528139633372};\\\", \\\"{x:1333,y:797,t:1528139633390};\\\", \\\"{x:1326,y:800,t:1528139633406};\\\", \\\"{x:1319,y:803,t:1528139633422};\\\", \\\"{x:1315,y:804,t:1528139633439};\\\", \\\"{x:1311,y:805,t:1528139633455};\\\", \\\"{x:1309,y:806,t:1528139633472};\\\", \\\"{x:1308,y:807,t:1528139633489};\\\", \\\"{x:1307,y:808,t:1528139633507};\\\", \\\"{x:1306,y:808,t:1528139633523};\\\", \\\"{x:1306,y:809,t:1528139633539};\\\", \\\"{x:1305,y:810,t:1528139633556};\\\", \\\"{x:1303,y:811,t:1528139633574};\\\", \\\"{x:1300,y:813,t:1528139633590};\\\", \\\"{x:1298,y:813,t:1528139633606};\\\", \\\"{x:1293,y:815,t:1528139633623};\\\", \\\"{x:1286,y:818,t:1528139633640};\\\", \\\"{x:1277,y:821,t:1528139633657};\\\", \\\"{x:1266,y:823,t:1528139633674};\\\", \\\"{x:1249,y:824,t:1528139633690};\\\", \\\"{x:1239,y:824,t:1528139633706};\\\", \\\"{x:1236,y:824,t:1528139633723};\\\", \\\"{x:1235,y:824,t:1528139633741};\\\", \\\"{x:1234,y:825,t:1528139633811};\\\", \\\"{x:1233,y:826,t:1528139633826};\\\", \\\"{x:1232,y:826,t:1528139633842};\\\", \\\"{x:1231,y:827,t:1528139633898};\\\", \\\"{x:1231,y:828,t:1528139633907};\\\", \\\"{x:1230,y:829,t:1528139633924};\\\", \\\"{x:1229,y:829,t:1528139633940};\\\", \\\"{x:1228,y:830,t:1528139633978};\\\", \\\"{x:1227,y:830,t:1528139633990};\\\", \\\"{x:1226,y:830,t:1528139634007};\\\", \\\"{x:1225,y:830,t:1528139634024};\\\", \\\"{x:1224,y:830,t:1528139634041};\\\", \\\"{x:1222,y:830,t:1528139634057};\\\", \\\"{x:1221,y:830,t:1528139634074};\\\", \\\"{x:1220,y:830,t:1528139634139};\\\", \\\"{x:1219,y:830,t:1528139634158};\\\", \\\"{x:1218,y:830,t:1528139634186};\\\", \\\"{x:1217,y:830,t:1528139634218};\\\", \\\"{x:1216,y:830,t:1528139634234};\\\", \\\"{x:1214,y:830,t:1528139634250};\\\", \\\"{x:1213,y:830,t:1528139634306};\\\", \\\"{x:1212,y:829,t:1528139634319};\\\", \\\"{x:1211,y:829,t:1528139634336};\\\", \\\"{x:1210,y:829,t:1528139634353};\\\", \\\"{x:1209,y:829,t:1528139634370};\\\", \\\"{x:1208,y:829,t:1528139634388};\\\", \\\"{x:1209,y:829,t:1528139635099};\\\", \\\"{x:1211,y:829,t:1528139635122};\\\", \\\"{x:1211,y:830,t:1528139635138};\\\", \\\"{x:1212,y:830,t:1528139635185};\\\", \\\"{x:1213,y:831,t:1528139635193};\\\", \\\"{x:1214,y:832,t:1528139635210};\\\", \\\"{x:1215,y:832,t:1528139635226};\\\", \\\"{x:1216,y:833,t:1528139635239};\\\", \\\"{x:1232,y:828,t:1528139637973};\\\", \\\"{x:1287,y:811,t:1528139637991};\\\", \\\"{x:1330,y:798,t:1528139638007};\\\", \\\"{x:1392,y:784,t:1528139638024};\\\", \\\"{x:1427,y:778,t:1528139638041};\\\", \\\"{x:1453,y:776,t:1528139638057};\\\", \\\"{x:1474,y:772,t:1528139638074};\\\", \\\"{x:1481,y:770,t:1528139638092};\\\", \\\"{x:1482,y:770,t:1528139638108};\\\", \\\"{x:1483,y:769,t:1528139638203};\\\", \\\"{x:1482,y:768,t:1528139638235};\\\", \\\"{x:1474,y:768,t:1528139638243};\\\", \\\"{x:1467,y:768,t:1528139638257};\\\", \\\"{x:1444,y:768,t:1528139638275};\\\", \\\"{x:1430,y:768,t:1528139638292};\\\", \\\"{x:1420,y:768,t:1528139638308};\\\", \\\"{x:1414,y:767,t:1528139638324};\\\", \\\"{x:1410,y:767,t:1528139638342};\\\", \\\"{x:1409,y:766,t:1528139638358};\\\", \\\"{x:1407,y:766,t:1528139638374};\\\", \\\"{x:1403,y:766,t:1528139638391};\\\", \\\"{x:1401,y:766,t:1528139638409};\\\", \\\"{x:1399,y:766,t:1528139638425};\\\", \\\"{x:1398,y:765,t:1528139638442};\\\", \\\"{x:1397,y:764,t:1528139638467};\\\", \\\"{x:1396,y:764,t:1528139638482};\\\", \\\"{x:1395,y:764,t:1528139638506};\\\", \\\"{x:1393,y:763,t:1528139638515};\\\", \\\"{x:1392,y:762,t:1528139638547};\\\", \\\"{x:1391,y:762,t:1528139638586};\\\", \\\"{x:1390,y:761,t:1528139638627};\\\", \\\"{x:1389,y:761,t:1528139638651};\\\", \\\"{x:1388,y:761,t:1528139638659};\\\", \\\"{x:1387,y:760,t:1528139638682};\\\", \\\"{x:1385,y:758,t:1528139638706};\\\", \\\"{x:1384,y:758,t:1528139638717};\\\", \\\"{x:1383,y:758,t:1528139638762};\\\", \\\"{x:1382,y:758,t:1528139638810};\\\", \\\"{x:1378,y:758,t:1528139640179};\\\", \\\"{x:1372,y:758,t:1528139640194};\\\", \\\"{x:1357,y:757,t:1528139640209};\\\", \\\"{x:1333,y:754,t:1528139640226};\\\", \\\"{x:1315,y:751,t:1528139640242};\\\", \\\"{x:1293,y:743,t:1528139640259};\\\", \\\"{x:1269,y:736,t:1528139640276};\\\", \\\"{x:1249,y:730,t:1528139640293};\\\", \\\"{x:1226,y:723,t:1528139640309};\\\", \\\"{x:1202,y:716,t:1528139640326};\\\", \\\"{x:1181,y:708,t:1528139640343};\\\", \\\"{x:1148,y:699,t:1528139640359};\\\", \\\"{x:1100,y:685,t:1528139640376};\\\", \\\"{x:1048,y:673,t:1528139640393};\\\", \\\"{x:1008,y:664,t:1528139640409};\\\", \\\"{x:960,y:652,t:1528139640426};\\\", \\\"{x:930,y:645,t:1528139640444};\\\", \\\"{x:892,y:636,t:1528139640458};\\\", \\\"{x:848,y:630,t:1528139640476};\\\", \\\"{x:795,y:630,t:1528139640493};\\\", \\\"{x:736,y:630,t:1528139640509};\\\", \\\"{x:675,y:622,t:1528139640528};\\\", \\\"{x:614,y:614,t:1528139640543};\\\", \\\"{x:550,y:605,t:1528139640560};\\\", \\\"{x:507,y:598,t:1528139640576};\\\", \\\"{x:474,y:590,t:1528139640594};\\\", \\\"{x:458,y:585,t:1528139640609};\\\", \\\"{x:457,y:583,t:1528139640795};\\\", \\\"{x:457,y:582,t:1528139640810};\\\", \\\"{x:464,y:580,t:1528139640827};\\\", \\\"{x:468,y:579,t:1528139640845};\\\", \\\"{x:470,y:578,t:1528139640859};\\\", \\\"{x:474,y:577,t:1528139640876};\\\", \\\"{x:478,y:575,t:1528139640893};\\\", \\\"{x:481,y:575,t:1528139640910};\\\", \\\"{x:485,y:574,t:1528139640927};\\\", \\\"{x:490,y:572,t:1528139640944};\\\", \\\"{x:494,y:572,t:1528139640960};\\\", \\\"{x:500,y:570,t:1528139640977};\\\", \\\"{x:505,y:568,t:1528139640993};\\\", \\\"{x:511,y:566,t:1528139641009};\\\", \\\"{x:517,y:564,t:1528139641026};\\\", \\\"{x:522,y:563,t:1528139641043};\\\", \\\"{x:527,y:562,t:1528139641060};\\\", \\\"{x:533,y:560,t:1528139641076};\\\", \\\"{x:538,y:560,t:1528139641093};\\\", \\\"{x:544,y:559,t:1528139641110};\\\", \\\"{x:545,y:559,t:1528139641127};\\\", \\\"{x:549,y:559,t:1528139641144};\\\", \\\"{x:555,y:561,t:1528139641160};\\\", \\\"{x:566,y:569,t:1528139641176};\\\", \\\"{x:571,y:573,t:1528139641194};\\\", \\\"{x:573,y:580,t:1528139641211};\\\", \\\"{x:574,y:586,t:1528139641227};\\\", \\\"{x:574,y:592,t:1528139641243};\\\", \\\"{x:577,y:597,t:1528139641260};\\\", \\\"{x:577,y:599,t:1528139641277};\\\", \\\"{x:578,y:601,t:1528139641293};\\\", \\\"{x:578,y:602,t:1528139641310};\\\", \\\"{x:578,y:603,t:1528139641327};\\\", \\\"{x:578,y:604,t:1528139641343};\\\", \\\"{x:574,y:607,t:1528139641360};\\\", \\\"{x:570,y:607,t:1528139641377};\\\", \\\"{x:561,y:610,t:1528139641393};\\\", \\\"{x:548,y:611,t:1528139641411};\\\", \\\"{x:538,y:613,t:1528139641428};\\\", \\\"{x:523,y:613,t:1528139641444};\\\", \\\"{x:504,y:613,t:1528139641460};\\\", \\\"{x:484,y:613,t:1528139641477};\\\", \\\"{x:464,y:613,t:1528139641494};\\\", \\\"{x:442,y:613,t:1528139641510};\\\", \\\"{x:422,y:613,t:1528139641528};\\\", \\\"{x:404,y:613,t:1528139641544};\\\", \\\"{x:379,y:609,t:1528139641561};\\\", \\\"{x:361,y:607,t:1528139641578};\\\", \\\"{x:344,y:605,t:1528139641593};\\\", \\\"{x:339,y:605,t:1528139641610};\\\", \\\"{x:335,y:605,t:1528139641627};\\\", \\\"{x:333,y:605,t:1528139641644};\\\", \\\"{x:330,y:605,t:1528139641660};\\\", \\\"{x:327,y:605,t:1528139641677};\\\", \\\"{x:325,y:608,t:1528139641694};\\\", \\\"{x:323,y:608,t:1528139641710};\\\", \\\"{x:319,y:610,t:1528139641728};\\\", \\\"{x:315,y:611,t:1528139641745};\\\", \\\"{x:307,y:612,t:1528139641760};\\\", \\\"{x:301,y:612,t:1528139641777};\\\", \\\"{x:300,y:612,t:1528139641794};\\\", \\\"{x:305,y:608,t:1528139641851};\\\", \\\"{x:311,y:605,t:1528139641860};\\\", \\\"{x:326,y:598,t:1528139641877};\\\", \\\"{x:338,y:593,t:1528139641894};\\\", \\\"{x:346,y:589,t:1528139641912};\\\", \\\"{x:349,y:588,t:1528139641927};\\\", \\\"{x:351,y:586,t:1528139641945};\\\", \\\"{x:352,y:586,t:1528139641960};\\\", \\\"{x:354,y:586,t:1528139641977};\\\", \\\"{x:355,y:586,t:1528139641994};\\\", \\\"{x:356,y:585,t:1528139642042};\\\", \\\"{x:357,y:585,t:1528139642050};\\\", \\\"{x:358,y:585,t:1528139642075};\\\", \\\"{x:360,y:585,t:1528139642082};\\\", \\\"{x:361,y:585,t:1528139642098};\\\", \\\"{x:362,y:586,t:1528139642111};\\\", \\\"{x:365,y:587,t:1528139642127};\\\", \\\"{x:367,y:588,t:1528139642145};\\\", \\\"{x:370,y:589,t:1528139642162};\\\", \\\"{x:373,y:591,t:1528139642177};\\\", \\\"{x:376,y:592,t:1528139642196};\\\", \\\"{x:378,y:593,t:1528139642211};\\\", \\\"{x:381,y:594,t:1528139642227};\\\", \\\"{x:382,y:595,t:1528139642258};\\\", \\\"{x:383,y:595,t:1528139642265};\\\", \\\"{x:384,y:595,t:1528139642277};\\\", \\\"{x:385,y:600,t:1528139642747};\\\", \\\"{x:390,y:614,t:1528139642762};\\\", \\\"{x:427,y:655,t:1528139642778};\\\", \\\"{x:450,y:675,t:1528139642794};\\\", \\\"{x:489,y:704,t:1528139642811};\\\", \\\"{x:521,y:728,t:1528139642828};\\\", \\\"{x:543,y:744,t:1528139642845};\\\", \\\"{x:557,y:754,t:1528139642861};\\\", \\\"{x:561,y:758,t:1528139642879};\\\", \\\"{x:562,y:758,t:1528139642895};\\\", \\\"{x:562,y:760,t:1528139643083};\\\", \\\"{x:561,y:760,t:1528139643098};\\\", \\\"{x:559,y:760,t:1528139643155};\\\", \\\"{x:558,y:760,t:1528139643378};\\\", \\\"{x:556,y:760,t:1528139643410};\\\", \\\"{x:555,y:760,t:1528139643418};\\\", \\\"{x:552,y:760,t:1528139643674};\\\", \\\"{x:547,y:760,t:1528139643682};\\\", \\\"{x:536,y:759,t:1528139643695};\\\", \\\"{x:508,y:752,t:1528139643713};\\\", \\\"{x:491,y:746,t:1528139643729};\\\", \\\"{x:489,y:742,t:1528139643746};\\\", \\\"{x:487,y:740,t:1528139643762};\\\", \\\"{x:480,y:731,t:1528139643779};\\\", \\\"{x:462,y:717,t:1528139643795};\\\", \\\"{x:438,y:700,t:1528139643812};\\\", \\\"{x:427,y:694,t:1528139643830};\\\", \\\"{x:422,y:690,t:1528139643846};\\\", \\\"{x:412,y:686,t:1528139643863};\\\", \\\"{x:401,y:680,t:1528139643880};\\\", \\\"{x:391,y:676,t:1528139643896};\\\", \\\"{x:372,y:667,t:1528139643913};\\\", \\\"{x:350,y:657,t:1528139643930};\\\", \\\"{x:329,y:649,t:1528139643946};\\\", \\\"{x:294,y:633,t:1528139643962};\\\", \\\"{x:271,y:622,t:1528139643980};\\\", \\\"{x:250,y:611,t:1528139643996};\\\", \\\"{x:225,y:599,t:1528139644012};\\\", \\\"{x:174,y:573,t:1528139644029};\\\", \\\"{x:143,y:557,t:1528139644045};\\\", \\\"{x:106,y:540,t:1528139644063};\\\", \\\"{x:89,y:530,t:1528139644080};\\\", \\\"{x:75,y:523,t:1528139644096};\\\", \\\"{x:70,y:519,t:1528139644112};\\\", \\\"{x:69,y:518,t:1528139644129};\\\", \\\"{x:68,y:517,t:1528139644386};\\\" ] }, { \\\"rt\\\": 16929, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 277300, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-H -H -H -H -H -H -H -1\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:50,y:515,t:1528139644531};\\\", \\\"{x:45,y:515,t:1528139644563};\\\", \\\"{x:44,y:515,t:1528139644634};\\\", \\\"{x:42,y:515,t:1528139644826};\\\", \\\"{x:41,y:515,t:1528139644850};\\\", \\\"{x:40,y:515,t:1528139644867};\\\", \\\"{x:39,y:515,t:1528139644882};\\\", \\\"{x:38,y:516,t:1528139644896};\\\", \\\"{x:37,y:516,t:1528139644953};\\\", \\\"{x:36,y:516,t:1528139644963};\\\", \\\"{x:35,y:516,t:1528139644994};\\\", \\\"{x:34,y:517,t:1528139645074};\\\", \\\"{x:33,y:517,t:1528139645195};\\\", \\\"{x:32,y:518,t:1528139645202};\\\", \\\"{x:31,y:518,t:1528139645241};\\\", \\\"{x:31,y:519,t:1528139645250};\\\", \\\"{x:30,y:519,t:1528139645266};\\\", \\\"{x:29,y:519,t:1528139645281};\\\", \\\"{x:28,y:520,t:1528139645339};\\\", \\\"{x:27,y:520,t:1528139645411};\\\", \\\"{x:26,y:520,t:1528139645538};\\\", \\\"{x:25,y:520,t:1528139646395};\\\", \\\"{x:24,y:520,t:1528139646619};\\\", \\\"{x:23,y:521,t:1528139646634};\\\", \\\"{x:23,y:522,t:1528139646650};\\\", \\\"{x:28,y:521,t:1528139646899};\\\", \\\"{x:44,y:510,t:1528139646915};\\\", \\\"{x:63,y:499,t:1528139646932};\\\", \\\"{x:79,y:490,t:1528139646948};\\\", \\\"{x:97,y:483,t:1528139646965};\\\", \\\"{x:120,y:476,t:1528139646982};\\\", \\\"{x:145,y:470,t:1528139646999};\\\", \\\"{x:183,y:465,t:1528139647015};\\\", \\\"{x:219,y:461,t:1528139647032};\\\", \\\"{x:252,y:459,t:1528139647049};\\\", \\\"{x:280,y:459,t:1528139647065};\\\", \\\"{x:306,y:458,t:1528139647082};\\\", \\\"{x:335,y:453,t:1528139647099};\\\", \\\"{x:349,y:452,t:1528139647115};\\\", \\\"{x:359,y:450,t:1528139647132};\\\", \\\"{x:369,y:449,t:1528139647149};\\\", \\\"{x:378,y:448,t:1528139647165};\\\", \\\"{x:386,y:445,t:1528139647182};\\\", \\\"{x:392,y:443,t:1528139647199};\\\", \\\"{x:398,y:442,t:1528139647214};\\\", \\\"{x:404,y:440,t:1528139647231};\\\", \\\"{x:410,y:438,t:1528139647248};\\\", \\\"{x:416,y:436,t:1528139647265};\\\", \\\"{x:422,y:435,t:1528139647282};\\\", \\\"{x:432,y:432,t:1528139647298};\\\", \\\"{x:441,y:431,t:1528139647314};\\\", \\\"{x:450,y:429,t:1528139647332};\\\", \\\"{x:460,y:428,t:1528139647349};\\\", \\\"{x:469,y:427,t:1528139647365};\\\", \\\"{x:479,y:425,t:1528139647382};\\\", \\\"{x:485,y:424,t:1528139647398};\\\", \\\"{x:494,y:423,t:1528139647414};\\\", \\\"{x:504,y:422,t:1528139647431};\\\", \\\"{x:511,y:420,t:1528139647449};\\\", \\\"{x:520,y:419,t:1528139647464};\\\", \\\"{x:527,y:419,t:1528139647482};\\\", \\\"{x:532,y:419,t:1528139647498};\\\", \\\"{x:537,y:419,t:1528139647516};\\\", \\\"{x:544,y:419,t:1528139647531};\\\", \\\"{x:554,y:419,t:1528139647548};\\\", \\\"{x:565,y:419,t:1528139647565};\\\", \\\"{x:575,y:419,t:1528139647581};\\\", \\\"{x:588,y:419,t:1528139647599};\\\", \\\"{x:599,y:419,t:1528139647615};\\\", \\\"{x:616,y:419,t:1528139647632};\\\", \\\"{x:630,y:419,t:1528139647648};\\\", \\\"{x:648,y:419,t:1528139647665};\\\", \\\"{x:663,y:418,t:1528139647681};\\\", \\\"{x:681,y:418,t:1528139647698};\\\", \\\"{x:696,y:418,t:1528139647715};\\\", \\\"{x:711,y:418,t:1528139647731};\\\", \\\"{x:723,y:418,t:1528139647748};\\\", \\\"{x:732,y:416,t:1528139647765};\\\", \\\"{x:737,y:416,t:1528139647782};\\\", \\\"{x:743,y:416,t:1528139647799};\\\", \\\"{x:747,y:415,t:1528139647816};\\\", \\\"{x:752,y:414,t:1528139647832};\\\", \\\"{x:758,y:414,t:1528139647848};\\\", \\\"{x:767,y:411,t:1528139647865};\\\", \\\"{x:783,y:409,t:1528139647882};\\\", \\\"{x:804,y:406,t:1528139647898};\\\", \\\"{x:828,y:401,t:1528139647916};\\\", \\\"{x:862,y:399,t:1528139647931};\\\", \\\"{x:914,y:394,t:1528139647948};\\\", \\\"{x:971,y:392,t:1528139647966};\\\", \\\"{x:1032,y:392,t:1528139647983};\\\", \\\"{x:1110,y:392,t:1528139647999};\\\", \\\"{x:1179,y:392,t:1528139648016};\\\", \\\"{x:1260,y:392,t:1528139648032};\\\", \\\"{x:1346,y:392,t:1528139648049};\\\", \\\"{x:1432,y:392,t:1528139648066};\\\", \\\"{x:1558,y:397,t:1528139648082};\\\", \\\"{x:1634,y:407,t:1528139648099};\\\", \\\"{x:1696,y:419,t:1528139648116};\\\", \\\"{x:1752,y:429,t:1528139648133};\\\", \\\"{x:1796,y:439,t:1528139648149};\\\", \\\"{x:1830,y:450,t:1528139648165};\\\", \\\"{x:1854,y:457,t:1528139648183};\\\", \\\"{x:1872,y:462,t:1528139648199};\\\", \\\"{x:1887,y:469,t:1528139648216};\\\", \\\"{x:1898,y:477,t:1528139648233};\\\", \\\"{x:1904,y:483,t:1528139648250};\\\", \\\"{x:1910,y:494,t:1528139648265};\\\", \\\"{x:1910,y:502,t:1528139648282};\\\", \\\"{x:1910,y:510,t:1528139648300};\\\", \\\"{x:1906,y:523,t:1528139648317};\\\", \\\"{x:1902,y:538,t:1528139648333};\\\", \\\"{x:1896,y:551,t:1528139648349};\\\", \\\"{x:1890,y:564,t:1528139648367};\\\", \\\"{x:1886,y:579,t:1528139648382};\\\", \\\"{x:1885,y:597,t:1528139648400};\\\", \\\"{x:1882,y:620,t:1528139648417};\\\", \\\"{x:1877,y:642,t:1528139648433};\\\", \\\"{x:1869,y:674,t:1528139648449};\\\", \\\"{x:1861,y:694,t:1528139648465};\\\", \\\"{x:1852,y:713,t:1528139648483};\\\", \\\"{x:1841,y:732,t:1528139648500};\\\", \\\"{x:1834,y:743,t:1528139648517};\\\", \\\"{x:1826,y:754,t:1528139648532};\\\", \\\"{x:1818,y:762,t:1528139648550};\\\", \\\"{x:1800,y:776,t:1528139648566};\\\", \\\"{x:1790,y:785,t:1528139648582};\\\", \\\"{x:1788,y:794,t:1528139648600};\\\", \\\"{x:1781,y:803,t:1528139648616};\\\", \\\"{x:1771,y:808,t:1528139648632};\\\", \\\"{x:1767,y:815,t:1528139648650};\\\", \\\"{x:1765,y:819,t:1528139648666};\\\", \\\"{x:1759,y:839,t:1528139648683};\\\", \\\"{x:1753,y:859,t:1528139648699};\\\", \\\"{x:1745,y:879,t:1528139648717};\\\", \\\"{x:1735,y:900,t:1528139648732};\\\", \\\"{x:1724,y:924,t:1528139648750};\\\", \\\"{x:1711,y:942,t:1528139648767};\\\", \\\"{x:1701,y:955,t:1528139648783};\\\", \\\"{x:1688,y:969,t:1528139648800};\\\", \\\"{x:1674,y:985,t:1528139648817};\\\", \\\"{x:1649,y:1001,t:1528139648834};\\\", \\\"{x:1644,y:1004,t:1528139648849};\\\", \\\"{x:1633,y:1009,t:1528139648867};\\\", \\\"{x:1628,y:1011,t:1528139648884};\\\", \\\"{x:1624,y:1013,t:1528139648900};\\\", \\\"{x:1623,y:1013,t:1528139648917};\\\", \\\"{x:1622,y:1013,t:1528139648955};\\\", \\\"{x:1622,y:1005,t:1528139649027};\\\", \\\"{x:1622,y:995,t:1528139649034};\\\", \\\"{x:1622,y:986,t:1528139649050};\\\", \\\"{x:1620,y:970,t:1528139649067};\\\", \\\"{x:1618,y:962,t:1528139649085};\\\", \\\"{x:1617,y:958,t:1528139649100};\\\", \\\"{x:1615,y:954,t:1528139649118};\\\", \\\"{x:1613,y:951,t:1528139649134};\\\", \\\"{x:1610,y:948,t:1528139649150};\\\", \\\"{x:1608,y:946,t:1528139649167};\\\", \\\"{x:1607,y:945,t:1528139649194};\\\", \\\"{x:1605,y:944,t:1528139649211};\\\", \\\"{x:1604,y:944,t:1528139649227};\\\", \\\"{x:1601,y:943,t:1528139649234};\\\", \\\"{x:1599,y:943,t:1528139649250};\\\", \\\"{x:1596,y:943,t:1528139649267};\\\", \\\"{x:1595,y:942,t:1528139649284};\\\", \\\"{x:1593,y:941,t:1528139649301};\\\", \\\"{x:1592,y:941,t:1528139649317};\\\", \\\"{x:1590,y:940,t:1528139649334};\\\", \\\"{x:1589,y:939,t:1528139649351};\\\", \\\"{x:1588,y:939,t:1528139649370};\\\", \\\"{x:1587,y:938,t:1528139649395};\\\", \\\"{x:1586,y:937,t:1528139649410};\\\", \\\"{x:1585,y:936,t:1528139649419};\\\", \\\"{x:1585,y:934,t:1528139649434};\\\", \\\"{x:1582,y:931,t:1528139649451};\\\", \\\"{x:1581,y:927,t:1528139649467};\\\", \\\"{x:1579,y:922,t:1528139649484};\\\", \\\"{x:1578,y:920,t:1528139649501};\\\", \\\"{x:1577,y:917,t:1528139649517};\\\", \\\"{x:1577,y:913,t:1528139649535};\\\", \\\"{x:1574,y:908,t:1528139649551};\\\", \\\"{x:1573,y:904,t:1528139649567};\\\", \\\"{x:1571,y:900,t:1528139649584};\\\", \\\"{x:1570,y:895,t:1528139649601};\\\", \\\"{x:1568,y:891,t:1528139649617};\\\", \\\"{x:1567,y:888,t:1528139649634};\\\", \\\"{x:1566,y:884,t:1528139649651};\\\", \\\"{x:1565,y:883,t:1528139649667};\\\", \\\"{x:1563,y:879,t:1528139649684};\\\", \\\"{x:1563,y:876,t:1528139649701};\\\", \\\"{x:1560,y:872,t:1528139649719};\\\", \\\"{x:1560,y:869,t:1528139649734};\\\", \\\"{x:1558,y:863,t:1528139649751};\\\", \\\"{x:1556,y:859,t:1528139649768};\\\", \\\"{x:1555,y:857,t:1528139649785};\\\", \\\"{x:1552,y:853,t:1528139649802};\\\", \\\"{x:1550,y:848,t:1528139649819};\\\", \\\"{x:1549,y:847,t:1528139649834};\\\", \\\"{x:1545,y:842,t:1528139649851};\\\", \\\"{x:1544,y:839,t:1528139649868};\\\", \\\"{x:1542,y:835,t:1528139649884};\\\", \\\"{x:1539,y:832,t:1528139649901};\\\", \\\"{x:1536,y:827,t:1528139649918};\\\", \\\"{x:1534,y:825,t:1528139649934};\\\", \\\"{x:1533,y:822,t:1528139649951};\\\", \\\"{x:1531,y:820,t:1528139649970};\\\", \\\"{x:1531,y:818,t:1528139649985};\\\", \\\"{x:1529,y:811,t:1528139650001};\\\", \\\"{x:1524,y:802,t:1528139650018};\\\", \\\"{x:1522,y:798,t:1528139650034};\\\", \\\"{x:1521,y:790,t:1528139650051};\\\", \\\"{x:1521,y:785,t:1528139650069};\\\", \\\"{x:1519,y:775,t:1528139650084};\\\", \\\"{x:1518,y:764,t:1528139650102};\\\", \\\"{x:1516,y:749,t:1528139650118};\\\", \\\"{x:1514,y:734,t:1528139650135};\\\", \\\"{x:1513,y:724,t:1528139650151};\\\", \\\"{x:1511,y:713,t:1528139650168};\\\", \\\"{x:1508,y:698,t:1528139650185};\\\", \\\"{x:1506,y:688,t:1528139650201};\\\", \\\"{x:1500,y:674,t:1528139650219};\\\", \\\"{x:1497,y:667,t:1528139650234};\\\", \\\"{x:1493,y:662,t:1528139650251};\\\", \\\"{x:1489,y:655,t:1528139650268};\\\", \\\"{x:1486,y:652,t:1528139650285};\\\", \\\"{x:1482,y:647,t:1528139650301};\\\", \\\"{x:1478,y:643,t:1528139650318};\\\", \\\"{x:1476,y:642,t:1528139650335};\\\", \\\"{x:1470,y:637,t:1528139650351};\\\", \\\"{x:1466,y:633,t:1528139650368};\\\", \\\"{x:1454,y:626,t:1528139650385};\\\", \\\"{x:1445,y:621,t:1528139650402};\\\", \\\"{x:1435,y:615,t:1528139650418};\\\", \\\"{x:1418,y:604,t:1528139650435};\\\", \\\"{x:1408,y:597,t:1528139650451};\\\", \\\"{x:1399,y:590,t:1528139650469};\\\", \\\"{x:1388,y:584,t:1528139650485};\\\", \\\"{x:1376,y:577,t:1528139650501};\\\", \\\"{x:1366,y:571,t:1528139650518};\\\", \\\"{x:1359,y:566,t:1528139650535};\\\", \\\"{x:1355,y:562,t:1528139650551};\\\", \\\"{x:1353,y:558,t:1528139650569};\\\", \\\"{x:1352,y:557,t:1528139650585};\\\", \\\"{x:1352,y:556,t:1528139650602};\\\", \\\"{x:1352,y:555,t:1528139650626};\\\", \\\"{x:1353,y:555,t:1528139650763};\\\", \\\"{x:1357,y:555,t:1528139650771};\\\", \\\"{x:1360,y:555,t:1528139650785};\\\", \\\"{x:1367,y:555,t:1528139650802};\\\", \\\"{x:1378,y:555,t:1528139650818};\\\", \\\"{x:1387,y:558,t:1528139650835};\\\", \\\"{x:1391,y:558,t:1528139650852};\\\", \\\"{x:1392,y:559,t:1528139650868};\\\", \\\"{x:1393,y:559,t:1528139650923};\\\", \\\"{x:1394,y:560,t:1528139651027};\\\", \\\"{x:1395,y:560,t:1528139651035};\\\", \\\"{x:1396,y:561,t:1528139651059};\\\", \\\"{x:1397,y:561,t:1528139651091};\\\", \\\"{x:1398,y:561,t:1528139651106};\\\", \\\"{x:1399,y:561,t:1528139651119};\\\", \\\"{x:1400,y:561,t:1528139651154};\\\", \\\"{x:1400,y:562,t:1528139651169};\\\", \\\"{x:1402,y:563,t:1528139651185};\\\", \\\"{x:1403,y:564,t:1528139651202};\\\", \\\"{x:1405,y:564,t:1528139651219};\\\", \\\"{x:1406,y:564,t:1528139651235};\\\", \\\"{x:1408,y:565,t:1528139651252};\\\", \\\"{x:1409,y:565,t:1528139651283};\\\", \\\"{x:1410,y:565,t:1528139651301};\\\", \\\"{x:1411,y:566,t:1528139654274};\\\", \\\"{x:1406,y:570,t:1528139655775};\\\", \\\"{x:1350,y:586,t:1528139655797};\\\", \\\"{x:1286,y:606,t:1528139655813};\\\", \\\"{x:1211,y:629,t:1528139655831};\\\", \\\"{x:1150,y:646,t:1528139655848};\\\", \\\"{x:1094,y:663,t:1528139655865};\\\", \\\"{x:1033,y:678,t:1528139655881};\\\", \\\"{x:975,y:686,t:1528139655898};\\\", \\\"{x:913,y:691,t:1528139655915};\\\", \\\"{x:884,y:691,t:1528139655931};\\\", \\\"{x:868,y:691,t:1528139655948};\\\", \\\"{x:854,y:691,t:1528139655966};\\\", \\\"{x:836,y:691,t:1528139655981};\\\", \\\"{x:815,y:691,t:1528139655998};\\\", \\\"{x:794,y:691,t:1528139656016};\\\", \\\"{x:779,y:691,t:1528139656031};\\\", \\\"{x:764,y:691,t:1528139656048};\\\", \\\"{x:738,y:687,t:1528139656065};\\\", \\\"{x:697,y:680,t:1528139656083};\\\", \\\"{x:654,y:673,t:1528139656098};\\\", \\\"{x:589,y:659,t:1528139656115};\\\", \\\"{x:549,y:646,t:1528139656134};\\\", \\\"{x:521,y:632,t:1528139656148};\\\", \\\"{x:501,y:621,t:1528139656165};\\\", \\\"{x:496,y:616,t:1528139656183};\\\", \\\"{x:493,y:613,t:1528139656198};\\\", \\\"{x:492,y:611,t:1528139656215};\\\", \\\"{x:491,y:607,t:1528139656233};\\\", \\\"{x:491,y:606,t:1528139656259};\\\", \\\"{x:491,y:605,t:1528139656267};\\\", \\\"{x:491,y:603,t:1528139656282};\\\", \\\"{x:494,y:599,t:1528139656299};\\\", \\\"{x:497,y:594,t:1528139656315};\\\", \\\"{x:500,y:591,t:1528139656334};\\\", \\\"{x:508,y:587,t:1528139656349};\\\", \\\"{x:512,y:586,t:1528139656365};\\\", \\\"{x:515,y:584,t:1528139656382};\\\", \\\"{x:518,y:584,t:1528139656399};\\\", \\\"{x:518,y:583,t:1528139656415};\\\", \\\"{x:519,y:583,t:1528139656432};\\\", \\\"{x:522,y:583,t:1528139656449};\\\", \\\"{x:528,y:583,t:1528139656465};\\\", \\\"{x:537,y:583,t:1528139656483};\\\", \\\"{x:547,y:583,t:1528139656499};\\\", \\\"{x:554,y:585,t:1528139656515};\\\", \\\"{x:565,y:587,t:1528139656533};\\\", \\\"{x:574,y:589,t:1528139656549};\\\", \\\"{x:581,y:591,t:1528139656566};\\\", \\\"{x:588,y:591,t:1528139656583};\\\", \\\"{x:591,y:591,t:1528139656599};\\\", \\\"{x:595,y:591,t:1528139656615};\\\", \\\"{x:599,y:593,t:1528139656633};\\\", \\\"{x:601,y:594,t:1528139656649};\\\", \\\"{x:602,y:594,t:1528139656665};\\\", \\\"{x:603,y:594,t:1528139657420};\\\", \\\"{x:601,y:599,t:1528139657433};\\\", \\\"{x:593,y:606,t:1528139657451};\\\", \\\"{x:586,y:615,t:1528139657467};\\\", \\\"{x:577,y:627,t:1528139657484};\\\", \\\"{x:572,y:636,t:1528139657499};\\\", \\\"{x:568,y:644,t:1528139657516};\\\", \\\"{x:568,y:651,t:1528139657534};\\\", \\\"{x:566,y:663,t:1528139657549};\\\", \\\"{x:565,y:677,t:1528139657566};\\\", \\\"{x:565,y:693,t:1528139657584};\\\", \\\"{x:565,y:710,t:1528139657599};\\\", \\\"{x:572,y:723,t:1528139657616};\\\", \\\"{x:586,y:733,t:1528139657633};\\\", \\\"{x:605,y:738,t:1528139657649};\\\", \\\"{x:626,y:740,t:1528139657666};\\\", \\\"{x:672,y:751,t:1528139657683};\\\", \\\"{x:703,y:756,t:1528139657700};\\\", \\\"{x:753,y:762,t:1528139657716};\\\", \\\"{x:810,y:772,t:1528139657735};\\\", \\\"{x:867,y:777,t:1528139657749};\\\", \\\"{x:933,y:783,t:1528139657767};\\\", \\\"{x:1008,y:783,t:1528139657783};\\\", \\\"{x:1104,y:767,t:1528139657800};\\\", \\\"{x:1214,y:734,t:1528139657817};\\\", \\\"{x:1320,y:704,t:1528139657834};\\\", \\\"{x:1422,y:675,t:1528139657850};\\\", \\\"{x:1519,y:646,t:1528139657866};\\\", \\\"{x:1617,y:605,t:1528139657883};\\\", \\\"{x:1661,y:593,t:1528139657901};\\\", \\\"{x:1683,y:585,t:1528139657916};\\\", \\\"{x:1691,y:579,t:1528139657934};\\\", \\\"{x:1696,y:576,t:1528139657950};\\\", \\\"{x:1697,y:575,t:1528139657967};\\\", \\\"{x:1699,y:571,t:1528139657983};\\\", \\\"{x:1699,y:566,t:1528139658001};\\\", \\\"{x:1698,y:554,t:1528139658016};\\\", \\\"{x:1689,y:542,t:1528139658033};\\\", \\\"{x:1668,y:527,t:1528139658050};\\\", \\\"{x:1630,y:512,t:1528139658066};\\\", \\\"{x:1587,y:508,t:1528139658084};\\\", \\\"{x:1557,y:509,t:1528139658100};\\\", \\\"{x:1509,y:517,t:1528139658117};\\\", \\\"{x:1457,y:528,t:1528139658133};\\\", \\\"{x:1429,y:537,t:1528139658150};\\\", \\\"{x:1414,y:543,t:1528139658166};\\\", \\\"{x:1411,y:547,t:1528139658183};\\\", \\\"{x:1409,y:548,t:1528139658201};\\\", \\\"{x:1409,y:550,t:1528139658217};\\\", \\\"{x:1409,y:553,t:1528139658233};\\\", \\\"{x:1409,y:559,t:1528139658251};\\\", \\\"{x:1409,y:562,t:1528139658270};\\\", \\\"{x:1409,y:564,t:1528139658301};\\\", \\\"{x:1408,y:565,t:1528139658556};\\\", \\\"{x:1412,y:562,t:1528139658572};\\\", \\\"{x:1419,y:557,t:1528139658585};\\\", \\\"{x:1422,y:555,t:1528139658600};\\\", \\\"{x:1424,y:553,t:1528139658617};\\\", \\\"{x:1426,y:552,t:1528139658635};\\\", \\\"{x:1428,y:550,t:1528139658650};\\\", \\\"{x:1427,y:551,t:1528139658836};\\\", \\\"{x:1424,y:554,t:1528139658851};\\\", \\\"{x:1416,y:559,t:1528139658870};\\\", \\\"{x:1415,y:560,t:1528139658885};\\\", \\\"{x:1414,y:560,t:1528139659116};\\\", \\\"{x:1413,y:559,t:1528139659131};\\\", \\\"{x:1412,y:557,t:1528139659140};\\\", \\\"{x:1411,y:555,t:1528139659154};\\\", \\\"{x:1410,y:553,t:1528139659171};\\\", \\\"{x:1410,y:552,t:1528139659187};\\\", \\\"{x:1410,y:549,t:1528139659201};\\\", \\\"{x:1408,y:547,t:1528139659217};\\\", \\\"{x:1408,y:546,t:1528139659234};\\\", \\\"{x:1406,y:538,t:1528139659252};\\\", \\\"{x:1404,y:530,t:1528139659269};\\\", \\\"{x:1401,y:519,t:1528139659285};\\\", \\\"{x:1398,y:512,t:1528139659301};\\\", \\\"{x:1396,y:506,t:1528139659318};\\\", \\\"{x:1393,y:499,t:1528139659337};\\\", \\\"{x:1390,y:491,t:1528139659352};\\\", \\\"{x:1386,y:484,t:1528139659369};\\\", \\\"{x:1383,y:477,t:1528139659384};\\\", \\\"{x:1380,y:470,t:1528139659402};\\\", \\\"{x:1376,y:464,t:1528139659418};\\\", \\\"{x:1372,y:460,t:1528139659434};\\\", \\\"{x:1367,y:457,t:1528139659451};\\\", \\\"{x:1364,y:457,t:1528139659468};\\\", \\\"{x:1363,y:457,t:1528139659484};\\\", \\\"{x:1362,y:458,t:1528139659557};\\\", \\\"{x:1362,y:461,t:1528139659569};\\\", \\\"{x:1362,y:470,t:1528139659584};\\\", \\\"{x:1362,y:480,t:1528139659602};\\\", \\\"{x:1370,y:496,t:1528139659619};\\\", \\\"{x:1382,y:515,t:1528139659635};\\\", \\\"{x:1392,y:528,t:1528139659651};\\\", \\\"{x:1402,y:543,t:1528139659668};\\\", \\\"{x:1413,y:563,t:1528139659687};\\\", \\\"{x:1421,y:582,t:1528139659703};\\\", \\\"{x:1430,y:605,t:1528139659718};\\\", \\\"{x:1436,y:633,t:1528139659734};\\\", \\\"{x:1438,y:660,t:1528139659752};\\\", \\\"{x:1438,y:685,t:1528139659768};\\\", \\\"{x:1433,y:711,t:1528139659785};\\\", \\\"{x:1424,y:738,t:1528139659801};\\\", \\\"{x:1410,y:765,t:1528139659818};\\\", \\\"{x:1375,y:797,t:1528139659835};\\\", \\\"{x:1288,y:848,t:1528139659852};\\\", \\\"{x:1222,y:874,t:1528139659868};\\\", \\\"{x:1166,y:893,t:1528139659885};\\\", \\\"{x:1135,y:902,t:1528139659902};\\\", \\\"{x:1109,y:903,t:1528139659919};\\\", \\\"{x:1085,y:903,t:1528139659936};\\\", \\\"{x:1056,y:903,t:1528139659951};\\\", \\\"{x:1028,y:899,t:1528139659969};\\\", \\\"{x:985,y:884,t:1528139659986};\\\", \\\"{x:923,y:860,t:1528139660002};\\\", \\\"{x:832,y:822,t:1528139660019};\\\", \\\"{x:674,y:761,t:1528139660035};\\\", \\\"{x:577,y:733,t:1528139660051};\\\", \\\"{x:533,y:720,t:1528139660069};\\\", \\\"{x:500,y:710,t:1528139660085};\\\", \\\"{x:479,y:702,t:1528139660102};\\\", \\\"{x:468,y:695,t:1528139660119};\\\", \\\"{x:465,y:693,t:1528139660136};\\\", \\\"{x:464,y:693,t:1528139660228};\\\", \\\"{x:462,y:693,t:1528139660235};\\\", \\\"{x:460,y:693,t:1528139660252};\\\", \\\"{x:457,y:693,t:1528139660268};\\\", \\\"{x:456,y:696,t:1528139660285};\\\", \\\"{x:456,y:708,t:1528139660303};\\\", \\\"{x:462,y:719,t:1528139660319};\\\", \\\"{x:466,y:727,t:1528139660335};\\\", \\\"{x:470,y:731,t:1528139660352};\\\", \\\"{x:471,y:734,t:1528139660369};\\\", \\\"{x:472,y:735,t:1528139660386};\\\", \\\"{x:473,y:736,t:1528139660580};\\\", \\\"{x:474,y:736,t:1528139660588};\\\", \\\"{x:476,y:738,t:1528139660605};\\\", \\\"{x:476,y:739,t:1528139660619};\\\", \\\"{x:478,y:741,t:1528139660635};\\\", \\\"{x:479,y:743,t:1528139660675};\\\", \\\"{x:480,y:743,t:1528139660739};\\\", \\\"{x:480,y:744,t:1528139660753};\\\", \\\"{x:481,y:744,t:1528139660769};\\\", \\\"{x:481,y:745,t:1528139660786};\\\", \\\"{x:482,y:746,t:1528139660802};\\\" ] }, { \\\"rt\\\": 20063, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 298678, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-4-2-10 AM-11 AM-B -U -A -I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:746,t:1528139663404};\\\", \\\"{x:516,y:656,t:1528139663423};\\\", \\\"{x:580,y:574,t:1528139663438};\\\", \\\"{x:682,y:508,t:1528139663455};\\\", \\\"{x:750,y:468,t:1528139663471};\\\", \\\"{x:752,y:468,t:1528139663488};\\\", \\\"{x:753,y:468,t:1528139664004};\\\", \\\"{x:753,y:467,t:1528139664763};\\\", \\\"{x:751,y:467,t:1528139664787};\\\", \\\"{x:749,y:467,t:1528139664795};\\\", \\\"{x:747,y:466,t:1528139664811};\\\", \\\"{x:745,y:465,t:1528139664828};\\\", \\\"{x:742,y:464,t:1528139664844};\\\", \\\"{x:741,y:463,t:1528139664859};\\\", \\\"{x:740,y:462,t:1528139664873};\\\", \\\"{x:739,y:462,t:1528139664889};\\\", \\\"{x:738,y:461,t:1528139664906};\\\", \\\"{x:737,y:460,t:1528139664923};\\\", \\\"{x:734,y:457,t:1528139664940};\\\", \\\"{x:734,y:455,t:1528139664956};\\\", \\\"{x:734,y:452,t:1528139664973};\\\", \\\"{x:734,y:448,t:1528139664989};\\\", \\\"{x:734,y:444,t:1528139665006};\\\", \\\"{x:738,y:439,t:1528139665023};\\\", \\\"{x:739,y:438,t:1528139665039};\\\", \\\"{x:739,y:436,t:1528139665056};\\\", \\\"{x:739,y:432,t:1528139665073};\\\", \\\"{x:739,y:429,t:1528139665090};\\\", \\\"{x:739,y:427,t:1528139665106};\\\", \\\"{x:740,y:425,t:1528139665123};\\\", \\\"{x:744,y:422,t:1528139665139};\\\", \\\"{x:747,y:421,t:1528139665156};\\\", \\\"{x:750,y:419,t:1528139665173};\\\", \\\"{x:752,y:419,t:1528139665190};\\\", \\\"{x:753,y:418,t:1528139665283};\\\", \\\"{x:756,y:415,t:1528139665299};\\\", \\\"{x:759,y:414,t:1528139665307};\\\", \\\"{x:764,y:410,t:1528139665323};\\\", \\\"{x:785,y:399,t:1528139665340};\\\", \\\"{x:803,y:390,t:1528139665356};\\\", \\\"{x:822,y:378,t:1528139665373};\\\", \\\"{x:844,y:371,t:1528139665390};\\\", \\\"{x:862,y:367,t:1528139665406};\\\", \\\"{x:884,y:361,t:1528139665423};\\\", \\\"{x:914,y:357,t:1528139665440};\\\", \\\"{x:964,y:349,t:1528139665457};\\\", \\\"{x:1017,y:341,t:1528139665473};\\\", \\\"{x:1052,y:337,t:1528139665490};\\\", \\\"{x:1102,y:330,t:1528139665507};\\\", \\\"{x:1150,y:322,t:1528139665523};\\\", \\\"{x:1242,y:297,t:1528139665540};\\\", \\\"{x:1320,y:272,t:1528139665557};\\\", \\\"{x:1398,y:261,t:1528139665573};\\\", \\\"{x:1471,y:260,t:1528139665590};\\\", \\\"{x:1532,y:260,t:1528139665607};\\\", \\\"{x:1585,y:260,t:1528139665624};\\\", \\\"{x:1630,y:260,t:1528139665641};\\\", \\\"{x:1662,y:260,t:1528139665657};\\\", \\\"{x:1677,y:260,t:1528139665673};\\\", \\\"{x:1680,y:260,t:1528139665690};\\\", \\\"{x:1681,y:260,t:1528139665716};\\\", \\\"{x:1680,y:260,t:1528139666036};\\\", \\\"{x:1676,y:260,t:1528139666044};\\\", \\\"{x:1674,y:262,t:1528139666057};\\\", \\\"{x:1668,y:264,t:1528139666075};\\\", \\\"{x:1662,y:266,t:1528139666090};\\\", \\\"{x:1654,y:269,t:1528139666107};\\\", \\\"{x:1648,y:271,t:1528139666124};\\\", \\\"{x:1642,y:273,t:1528139666140};\\\", \\\"{x:1641,y:273,t:1528139666157};\\\", \\\"{x:1638,y:275,t:1528139666174};\\\", \\\"{x:1634,y:277,t:1528139666190};\\\", \\\"{x:1625,y:279,t:1528139666208};\\\", \\\"{x:1620,y:281,t:1528139666225};\\\", \\\"{x:1612,y:282,t:1528139666240};\\\", \\\"{x:1599,y:286,t:1528139666257};\\\", \\\"{x:1589,y:288,t:1528139666274};\\\", \\\"{x:1578,y:290,t:1528139666292};\\\", \\\"{x:1574,y:291,t:1528139666307};\\\", \\\"{x:1555,y:291,t:1528139666324};\\\", \\\"{x:1542,y:291,t:1528139666341};\\\", \\\"{x:1528,y:291,t:1528139666357};\\\", \\\"{x:1515,y:291,t:1528139666374};\\\", \\\"{x:1506,y:291,t:1528139666391};\\\", \\\"{x:1498,y:291,t:1528139666408};\\\", \\\"{x:1490,y:290,t:1528139666424};\\\", \\\"{x:1483,y:289,t:1528139666441};\\\", \\\"{x:1478,y:289,t:1528139666457};\\\", \\\"{x:1476,y:289,t:1528139666474};\\\", \\\"{x:1472,y:288,t:1528139666491};\\\", \\\"{x:1471,y:288,t:1528139666507};\\\", \\\"{x:1469,y:288,t:1528139666524};\\\", \\\"{x:1467,y:288,t:1528139666541};\\\", \\\"{x:1464,y:288,t:1528139666557};\\\", \\\"{x:1455,y:288,t:1528139666575};\\\", \\\"{x:1441,y:288,t:1528139666591};\\\", \\\"{x:1429,y:288,t:1528139666607};\\\", \\\"{x:1416,y:286,t:1528139666624};\\\", \\\"{x:1398,y:284,t:1528139666641};\\\", \\\"{x:1383,y:283,t:1528139666657};\\\", \\\"{x:1367,y:280,t:1528139666674};\\\", \\\"{x:1340,y:276,t:1528139666692};\\\", \\\"{x:1329,y:274,t:1528139666708};\\\", \\\"{x:1325,y:274,t:1528139666724};\\\", \\\"{x:1323,y:274,t:1528139666741};\\\", \\\"{x:1322,y:274,t:1528139666852};\\\", \\\"{x:1320,y:274,t:1528139666868};\\\", \\\"{x:1319,y:274,t:1528139666876};\\\", \\\"{x:1316,y:274,t:1528139666891};\\\", \\\"{x:1313,y:274,t:1528139666907};\\\", \\\"{x:1308,y:275,t:1528139666924};\\\", \\\"{x:1306,y:276,t:1528139666941};\\\", \\\"{x:1303,y:277,t:1528139666958};\\\", \\\"{x:1301,y:278,t:1528139666975};\\\", \\\"{x:1300,y:278,t:1528139666996};\\\", \\\"{x:1299,y:278,t:1528139667011};\\\", \\\"{x:1298,y:278,t:1528139667028};\\\", \\\"{x:1297,y:279,t:1528139667043};\\\", \\\"{x:1296,y:279,t:1528139667060};\\\", \\\"{x:1296,y:280,t:1528139667076};\\\", \\\"{x:1295,y:280,t:1528139667091};\\\", \\\"{x:1288,y:283,t:1528139667108};\\\", \\\"{x:1284,y:286,t:1528139667124};\\\", \\\"{x:1276,y:290,t:1528139667141};\\\", \\\"{x:1264,y:294,t:1528139667159};\\\", \\\"{x:1259,y:295,t:1528139667175};\\\", \\\"{x:1253,y:298,t:1528139667191};\\\", \\\"{x:1247,y:300,t:1528139667208};\\\", \\\"{x:1241,y:303,t:1528139667225};\\\", \\\"{x:1236,y:305,t:1528139667242};\\\", \\\"{x:1232,y:307,t:1528139667258};\\\", \\\"{x:1222,y:311,t:1528139667275};\\\", \\\"{x:1219,y:312,t:1528139667291};\\\", \\\"{x:1205,y:319,t:1528139667308};\\\", \\\"{x:1196,y:321,t:1528139667324};\\\", \\\"{x:1188,y:325,t:1528139667341};\\\", \\\"{x:1181,y:328,t:1528139667357};\\\", \\\"{x:1177,y:329,t:1528139667374};\\\", \\\"{x:1172,y:330,t:1528139667391};\\\", \\\"{x:1167,y:332,t:1528139667407};\\\", \\\"{x:1162,y:334,t:1528139667424};\\\", \\\"{x:1153,y:338,t:1528139667441};\\\", \\\"{x:1139,y:342,t:1528139667457};\\\", \\\"{x:1114,y:349,t:1528139667475};\\\", \\\"{x:1096,y:354,t:1528139667490};\\\", \\\"{x:1072,y:361,t:1528139667508};\\\", \\\"{x:1049,y:368,t:1528139667524};\\\", \\\"{x:1022,y:375,t:1528139667541};\\\", \\\"{x:991,y:382,t:1528139667557};\\\", \\\"{x:960,y:387,t:1528139667574};\\\", \\\"{x:929,y:391,t:1528139667591};\\\", \\\"{x:905,y:394,t:1528139667607};\\\", \\\"{x:879,y:398,t:1528139667625};\\\", \\\"{x:855,y:400,t:1528139667642};\\\", \\\"{x:834,y:408,t:1528139667657};\\\", \\\"{x:806,y:415,t:1528139667675};\\\", \\\"{x:795,y:416,t:1528139667691};\\\", \\\"{x:791,y:416,t:1528139667707};\\\", \\\"{x:789,y:416,t:1528139667725};\\\", \\\"{x:787,y:418,t:1528139667742};\\\", \\\"{x:785,y:418,t:1528139667757};\\\", \\\"{x:781,y:420,t:1528139667775};\\\", \\\"{x:775,y:423,t:1528139667792};\\\", \\\"{x:769,y:425,t:1528139667808};\\\", \\\"{x:761,y:428,t:1528139667825};\\\", \\\"{x:748,y:433,t:1528139667842};\\\", \\\"{x:742,y:436,t:1528139667857};\\\", \\\"{x:738,y:437,t:1528139667875};\\\", \\\"{x:730,y:440,t:1528139667891};\\\", \\\"{x:724,y:441,t:1528139667908};\\\", \\\"{x:721,y:443,t:1528139667925};\\\", \\\"{x:719,y:443,t:1528139667942};\\\", \\\"{x:715,y:444,t:1528139667958};\\\", \\\"{x:712,y:445,t:1528139667975};\\\", \\\"{x:708,y:447,t:1528139667993};\\\", \\\"{x:707,y:447,t:1528139668008};\\\", \\\"{x:706,y:447,t:1528139668025};\\\", \\\"{x:705,y:448,t:1528139668067};\\\", \\\"{x:703,y:448,t:1528139668091};\\\", \\\"{x:703,y:449,t:1528139668109};\\\", \\\"{x:702,y:450,t:1528139668139};\\\", \\\"{x:701,y:450,t:1528139668164};\\\", \\\"{x:699,y:451,t:1528139668179};\\\", \\\"{x:699,y:452,t:1528139668196};\\\", \\\"{x:697,y:453,t:1528139668209};\\\", \\\"{x:697,y:454,t:1528139668225};\\\", \\\"{x:696,y:454,t:1528139668242};\\\", \\\"{x:693,y:457,t:1528139668259};\\\", \\\"{x:692,y:458,t:1528139668284};\\\", \\\"{x:691,y:458,t:1528139668291};\\\", \\\"{x:691,y:459,t:1528139668308};\\\", \\\"{x:690,y:460,t:1528139668325};\\\", \\\"{x:689,y:462,t:1528139668342};\\\", \\\"{x:688,y:464,t:1528139668359};\\\", \\\"{x:687,y:466,t:1528139668375};\\\", \\\"{x:686,y:468,t:1528139668392};\\\", \\\"{x:685,y:469,t:1528139668409};\\\", \\\"{x:684,y:470,t:1528139668424};\\\", \\\"{x:683,y:472,t:1528139668441};\\\", \\\"{x:682,y:473,t:1528139668483};\\\", \\\"{x:681,y:474,t:1528139668708};\\\", \\\"{x:681,y:475,t:1528139668779};\\\", \\\"{x:681,y:476,t:1528139668792};\\\", \\\"{x:680,y:477,t:1528139668827};\\\", \\\"{x:680,y:479,t:1528139668883};\\\", \\\"{x:680,y:480,t:1528139668899};\\\", \\\"{x:680,y:481,t:1528139668924};\\\", \\\"{x:680,y:482,t:1528139668972};\\\", \\\"{x:680,y:483,t:1528139668980};\\\", \\\"{x:680,y:484,t:1528139668993};\\\", \\\"{x:678,y:487,t:1528139669009};\\\", \\\"{x:678,y:488,t:1528139669026};\\\", \\\"{x:678,y:490,t:1528139669043};\\\", \\\"{x:678,y:491,t:1528139669083};\\\", \\\"{x:678,y:493,t:1528139669099};\\\", \\\"{x:679,y:494,t:1528139669115};\\\", \\\"{x:680,y:496,t:1528139669132};\\\", \\\"{x:682,y:496,t:1528139669147};\\\", \\\"{x:683,y:497,t:1528139669159};\\\", \\\"{x:685,y:498,t:1528139669176};\\\", \\\"{x:689,y:500,t:1528139669193};\\\", \\\"{x:695,y:504,t:1528139669209};\\\", \\\"{x:706,y:508,t:1528139669226};\\\", \\\"{x:723,y:515,t:1528139669244};\\\", \\\"{x:736,y:519,t:1528139669259};\\\", \\\"{x:750,y:525,t:1528139669276};\\\", \\\"{x:761,y:530,t:1528139669293};\\\", \\\"{x:767,y:533,t:1528139669309};\\\", \\\"{x:774,y:535,t:1528139669326};\\\", \\\"{x:782,y:539,t:1528139669344};\\\", \\\"{x:785,y:539,t:1528139669359};\\\", \\\"{x:787,y:541,t:1528139669376};\\\", \\\"{x:788,y:541,t:1528139669393};\\\", \\\"{x:793,y:543,t:1528139669811};\\\", \\\"{x:805,y:546,t:1528139669827};\\\", \\\"{x:818,y:550,t:1528139669843};\\\", \\\"{x:832,y:552,t:1528139669860};\\\", \\\"{x:848,y:557,t:1528139669879};\\\", \\\"{x:869,y:563,t:1528139669893};\\\", \\\"{x:890,y:569,t:1528139669910};\\\", \\\"{x:937,y:583,t:1528139669943};\\\", \\\"{x:961,y:590,t:1528139669960};\\\", \\\"{x:982,y:595,t:1528139669977};\\\", \\\"{x:1000,y:602,t:1528139669992};\\\", \\\"{x:1014,y:606,t:1528139670009};\\\", \\\"{x:1039,y:613,t:1528139670026};\\\", \\\"{x:1048,y:616,t:1528139670043};\\\", \\\"{x:1053,y:617,t:1528139670060};\\\", \\\"{x:1059,y:620,t:1528139670077};\\\", \\\"{x:1063,y:622,t:1528139670093};\\\", \\\"{x:1067,y:625,t:1528139670110};\\\", \\\"{x:1070,y:627,t:1528139670127};\\\", \\\"{x:1072,y:628,t:1528139670143};\\\", \\\"{x:1073,y:629,t:1528139670160};\\\", \\\"{x:1075,y:631,t:1528139670177};\\\", \\\"{x:1075,y:634,t:1528139670193};\\\", \\\"{x:1075,y:640,t:1528139670210};\\\", \\\"{x:1075,y:645,t:1528139670227};\\\", \\\"{x:1075,y:651,t:1528139670243};\\\", \\\"{x:1073,y:655,t:1528139670259};\\\", \\\"{x:1071,y:662,t:1528139670277};\\\", \\\"{x:1068,y:670,t:1528139670294};\\\", \\\"{x:1064,y:679,t:1528139670310};\\\", \\\"{x:1057,y:692,t:1528139670328};\\\", \\\"{x:1053,y:699,t:1528139670344};\\\", \\\"{x:1050,y:704,t:1528139670359};\\\", \\\"{x:1047,y:708,t:1528139670377};\\\", \\\"{x:1047,y:712,t:1528139670393};\\\", \\\"{x:1044,y:718,t:1528139670410};\\\", \\\"{x:1044,y:730,t:1528139670426};\\\", \\\"{x:1044,y:746,t:1528139670443};\\\", \\\"{x:1044,y:761,t:1528139670460};\\\", \\\"{x:1044,y:768,t:1528139670476};\\\", \\\"{x:1045,y:775,t:1528139670493};\\\", \\\"{x:1046,y:784,t:1528139670510};\\\", \\\"{x:1050,y:797,t:1528139670526};\\\", \\\"{x:1053,y:806,t:1528139670543};\\\", \\\"{x:1054,y:813,t:1528139670560};\\\", \\\"{x:1059,y:823,t:1528139670576};\\\", \\\"{x:1069,y:839,t:1528139670593};\\\", \\\"{x:1076,y:852,t:1528139670610};\\\", \\\"{x:1081,y:860,t:1528139670627};\\\", \\\"{x:1089,y:871,t:1528139670644};\\\", \\\"{x:1097,y:882,t:1528139670660};\\\", \\\"{x:1102,y:891,t:1528139670676};\\\", \\\"{x:1108,y:898,t:1528139670693};\\\", \\\"{x:1112,y:906,t:1528139670710};\\\", \\\"{x:1121,y:917,t:1528139670726};\\\", \\\"{x:1131,y:929,t:1528139670744};\\\", \\\"{x:1144,y:939,t:1528139670760};\\\", \\\"{x:1160,y:951,t:1528139670777};\\\", \\\"{x:1179,y:962,t:1528139670793};\\\", \\\"{x:1195,y:971,t:1528139670810};\\\", \\\"{x:1213,y:978,t:1528139670826};\\\", \\\"{x:1234,y:984,t:1528139670843};\\\", \\\"{x:1247,y:987,t:1528139670859};\\\", \\\"{x:1254,y:987,t:1528139670876};\\\", \\\"{x:1258,y:988,t:1528139670893};\\\", \\\"{x:1263,y:988,t:1528139670910};\\\", \\\"{x:1274,y:983,t:1528139670926};\\\", \\\"{x:1286,y:978,t:1528139670943};\\\", \\\"{x:1299,y:972,t:1528139670960};\\\", \\\"{x:1314,y:966,t:1528139670977};\\\", \\\"{x:1328,y:960,t:1528139670993};\\\", \\\"{x:1338,y:952,t:1528139671009};\\\", \\\"{x:1347,y:948,t:1528139671026};\\\", \\\"{x:1357,y:944,t:1528139671044};\\\", \\\"{x:1360,y:942,t:1528139671059};\\\", \\\"{x:1365,y:939,t:1528139671077};\\\", \\\"{x:1369,y:936,t:1528139671094};\\\", \\\"{x:1373,y:933,t:1528139671110};\\\", \\\"{x:1376,y:930,t:1528139671126};\\\", \\\"{x:1378,y:928,t:1528139671143};\\\", \\\"{x:1379,y:927,t:1528139671164};\\\", \\\"{x:1379,y:926,t:1528139671196};\\\", \\\"{x:1380,y:925,t:1528139671220};\\\", \\\"{x:1380,y:923,t:1528139671228};\\\", \\\"{x:1381,y:920,t:1528139671244};\\\", \\\"{x:1381,y:919,t:1528139671300};\\\", \\\"{x:1379,y:917,t:1528139671356};\\\", \\\"{x:1378,y:916,t:1528139671380};\\\", \\\"{x:1378,y:915,t:1528139671396};\\\", \\\"{x:1376,y:914,t:1528139671409};\\\", \\\"{x:1375,y:913,t:1528139671428};\\\", \\\"{x:1375,y:912,t:1528139671444};\\\", \\\"{x:1375,y:911,t:1528139671460};\\\", \\\"{x:1375,y:909,t:1528139671476};\\\", \\\"{x:1375,y:906,t:1528139671493};\\\", \\\"{x:1375,y:899,t:1528139671510};\\\", \\\"{x:1375,y:893,t:1528139671526};\\\", \\\"{x:1375,y:890,t:1528139671542};\\\", \\\"{x:1378,y:884,t:1528139671559};\\\", \\\"{x:1384,y:875,t:1528139671576};\\\", \\\"{x:1393,y:865,t:1528139671592};\\\", \\\"{x:1402,y:851,t:1528139671609};\\\", \\\"{x:1412,y:836,t:1528139671626};\\\", \\\"{x:1422,y:815,t:1528139671643};\\\", \\\"{x:1434,y:788,t:1528139671660};\\\", \\\"{x:1443,y:771,t:1528139671676};\\\", \\\"{x:1452,y:760,t:1528139671692};\\\", \\\"{x:1460,y:747,t:1528139671709};\\\", \\\"{x:1466,y:736,t:1528139671726};\\\", \\\"{x:1469,y:728,t:1528139671743};\\\", \\\"{x:1474,y:718,t:1528139671759};\\\", \\\"{x:1475,y:714,t:1528139671777};\\\", \\\"{x:1478,y:711,t:1528139671792};\\\", \\\"{x:1482,y:706,t:1528139671809};\\\", \\\"{x:1486,y:702,t:1528139671827};\\\", \\\"{x:1490,y:696,t:1528139671843};\\\", \\\"{x:1511,y:679,t:1528139671859};\\\", \\\"{x:1526,y:668,t:1528139671876};\\\", \\\"{x:1538,y:659,t:1528139671893};\\\", \\\"{x:1553,y:645,t:1528139671909};\\\", \\\"{x:1571,y:629,t:1528139671925};\\\", \\\"{x:1590,y:613,t:1528139671942};\\\", \\\"{x:1606,y:600,t:1528139671959};\\\", \\\"{x:1622,y:587,t:1528139671976};\\\", \\\"{x:1641,y:571,t:1528139671992};\\\", \\\"{x:1653,y:562,t:1528139672009};\\\", \\\"{x:1663,y:554,t:1528139672025};\\\", \\\"{x:1671,y:546,t:1528139672042};\\\", \\\"{x:1678,y:539,t:1528139672059};\\\", \\\"{x:1681,y:536,t:1528139672076};\\\", \\\"{x:1682,y:533,t:1528139672092};\\\", \\\"{x:1681,y:537,t:1528139672467};\\\", \\\"{x:1675,y:540,t:1528139672475};\\\", \\\"{x:1665,y:555,t:1528139672492};\\\", \\\"{x:1657,y:567,t:1528139672509};\\\", \\\"{x:1651,y:578,t:1528139672525};\\\", \\\"{x:1646,y:587,t:1528139672542};\\\", \\\"{x:1645,y:591,t:1528139672558};\\\", \\\"{x:1644,y:594,t:1528139672575};\\\", \\\"{x:1642,y:599,t:1528139672591};\\\", \\\"{x:1642,y:606,t:1528139672607};\\\", \\\"{x:1642,y:614,t:1528139672625};\\\", \\\"{x:1639,y:622,t:1528139672642};\\\", \\\"{x:1639,y:629,t:1528139672658};\\\", \\\"{x:1638,y:636,t:1528139672675};\\\", \\\"{x:1638,y:643,t:1528139672692};\\\", \\\"{x:1638,y:652,t:1528139672708};\\\", \\\"{x:1638,y:665,t:1528139672725};\\\", \\\"{x:1642,y:681,t:1528139672742};\\\", \\\"{x:1647,y:696,t:1528139672758};\\\", \\\"{x:1653,y:711,t:1528139672775};\\\", \\\"{x:1661,y:726,t:1528139672792};\\\", \\\"{x:1668,y:743,t:1528139672808};\\\", \\\"{x:1674,y:759,t:1528139672826};\\\", \\\"{x:1679,y:771,t:1528139672842};\\\", \\\"{x:1683,y:782,t:1528139672858};\\\", \\\"{x:1686,y:790,t:1528139672874};\\\", \\\"{x:1686,y:795,t:1528139672892};\\\", \\\"{x:1686,y:798,t:1528139672909};\\\", \\\"{x:1686,y:808,t:1528139672925};\\\", \\\"{x:1686,y:818,t:1528139672943};\\\", \\\"{x:1686,y:823,t:1528139672958};\\\", \\\"{x:1685,y:824,t:1528139672975};\\\", \\\"{x:1682,y:827,t:1528139672996};\\\", \\\"{x:1679,y:829,t:1528139673008};\\\", \\\"{x:1678,y:830,t:1528139673025};\\\", \\\"{x:1674,y:832,t:1528139673044};\\\", \\\"{x:1673,y:832,t:1528139673060};\\\", \\\"{x:1672,y:833,t:1528139673077};\\\", \\\"{x:1670,y:834,t:1528139673092};\\\", \\\"{x:1667,y:835,t:1528139673109};\\\", \\\"{x:1662,y:837,t:1528139673127};\\\", \\\"{x:1660,y:837,t:1528139673143};\\\", \\\"{x:1656,y:838,t:1528139673160};\\\", \\\"{x:1651,y:838,t:1528139673177};\\\", \\\"{x:1644,y:838,t:1528139673193};\\\", \\\"{x:1633,y:838,t:1528139673210};\\\", \\\"{x:1609,y:838,t:1528139673227};\\\", \\\"{x:1598,y:838,t:1528139673243};\\\", \\\"{x:1580,y:838,t:1528139673260};\\\", \\\"{x:1564,y:838,t:1528139673277};\\\", \\\"{x:1546,y:836,t:1528139673293};\\\", \\\"{x:1526,y:833,t:1528139673310};\\\", \\\"{x:1515,y:832,t:1528139673327};\\\", \\\"{x:1503,y:829,t:1528139673343};\\\", \\\"{x:1492,y:827,t:1528139673360};\\\", \\\"{x:1482,y:824,t:1528139673377};\\\", \\\"{x:1467,y:821,t:1528139673393};\\\", \\\"{x:1458,y:818,t:1528139673410};\\\", \\\"{x:1456,y:818,t:1528139673427};\\\", \\\"{x:1457,y:819,t:1528139673756};\\\", \\\"{x:1458,y:819,t:1528139673764};\\\", \\\"{x:1459,y:819,t:1528139673778};\\\", \\\"{x:1464,y:819,t:1528139673793};\\\", \\\"{x:1469,y:819,t:1528139673810};\\\", \\\"{x:1474,y:820,t:1528139673828};\\\", \\\"{x:1474,y:821,t:1528139673844};\\\", \\\"{x:1475,y:821,t:1528139673860};\\\", \\\"{x:1475,y:822,t:1528139673932};\\\", \\\"{x:1475,y:823,t:1528139673943};\\\", \\\"{x:1472,y:826,t:1528139673960};\\\", \\\"{x:1469,y:827,t:1528139673978};\\\", \\\"{x:1464,y:830,t:1528139673994};\\\", \\\"{x:1458,y:830,t:1528139674011};\\\", \\\"{x:1445,y:833,t:1528139674028};\\\", \\\"{x:1436,y:833,t:1528139674043};\\\", \\\"{x:1433,y:833,t:1528139674060};\\\", \\\"{x:1429,y:833,t:1528139674077};\\\", \\\"{x:1428,y:833,t:1528139674094};\\\", \\\"{x:1424,y:833,t:1528139674110};\\\", \\\"{x:1417,y:833,t:1528139674127};\\\", \\\"{x:1407,y:833,t:1528139674143};\\\", \\\"{x:1391,y:833,t:1528139674159};\\\", \\\"{x:1375,y:833,t:1528139674177};\\\", \\\"{x:1362,y:833,t:1528139674193};\\\", \\\"{x:1350,y:833,t:1528139674210};\\\", \\\"{x:1329,y:835,t:1528139674226};\\\", \\\"{x:1314,y:838,t:1528139674242};\\\", \\\"{x:1300,y:842,t:1528139674260};\\\", \\\"{x:1289,y:844,t:1528139674277};\\\", \\\"{x:1282,y:848,t:1528139674293};\\\", \\\"{x:1280,y:849,t:1528139674310};\\\", \\\"{x:1277,y:850,t:1528139674327};\\\", \\\"{x:1277,y:848,t:1528139674460};\\\", \\\"{x:1278,y:843,t:1528139674477};\\\", \\\"{x:1282,y:834,t:1528139674497};\\\", \\\"{x:1286,y:820,t:1528139674510};\\\", \\\"{x:1294,y:800,t:1528139674530};\\\", \\\"{x:1300,y:792,t:1528139674547};\\\", \\\"{x:1305,y:788,t:1528139674564};\\\", \\\"{x:1307,y:785,t:1528139674581};\\\", \\\"{x:1310,y:779,t:1528139674597};\\\", \\\"{x:1312,y:774,t:1528139674614};\\\", \\\"{x:1314,y:769,t:1528139674630};\\\", \\\"{x:1317,y:763,t:1528139674647};\\\", \\\"{x:1319,y:758,t:1528139674664};\\\", \\\"{x:1322,y:754,t:1528139674681};\\\", \\\"{x:1326,y:746,t:1528139674697};\\\", \\\"{x:1331,y:739,t:1528139674714};\\\", \\\"{x:1337,y:728,t:1528139674730};\\\", \\\"{x:1342,y:722,t:1528139674747};\\\", \\\"{x:1343,y:720,t:1528139674764};\\\", \\\"{x:1344,y:717,t:1528139674781};\\\", \\\"{x:1346,y:715,t:1528139674798};\\\", \\\"{x:1348,y:709,t:1528139674814};\\\", \\\"{x:1350,y:699,t:1528139674832};\\\", \\\"{x:1351,y:692,t:1528139674848};\\\", \\\"{x:1352,y:683,t:1528139674864};\\\", \\\"{x:1352,y:676,t:1528139674881};\\\", \\\"{x:1352,y:666,t:1528139674898};\\\", \\\"{x:1352,y:658,t:1528139674914};\\\", \\\"{x:1351,y:625,t:1528139674931};\\\", \\\"{x:1348,y:612,t:1528139674948};\\\", \\\"{x:1347,y:600,t:1528139674964};\\\", \\\"{x:1344,y:585,t:1528139674981};\\\", \\\"{x:1342,y:570,t:1528139674998};\\\", \\\"{x:1339,y:553,t:1528139675014};\\\", \\\"{x:1338,y:540,t:1528139675031};\\\", \\\"{x:1338,y:529,t:1528139675048};\\\", \\\"{x:1337,y:518,t:1528139675064};\\\", \\\"{x:1336,y:511,t:1528139675081};\\\", \\\"{x:1334,y:506,t:1528139675098};\\\", \\\"{x:1331,y:501,t:1528139675115};\\\", \\\"{x:1329,y:497,t:1528139675131};\\\", \\\"{x:1324,y:492,t:1528139675148};\\\", \\\"{x:1314,y:487,t:1528139675165};\\\", \\\"{x:1310,y:483,t:1528139675181};\\\", \\\"{x:1308,y:482,t:1528139675199};\\\", \\\"{x:1306,y:480,t:1528139675215};\\\", \\\"{x:1306,y:478,t:1528139675231};\\\", \\\"{x:1304,y:478,t:1528139675276};\\\", \\\"{x:1303,y:478,t:1528139675283};\\\", \\\"{x:1300,y:478,t:1528139675299};\\\", \\\"{x:1293,y:482,t:1528139675316};\\\", \\\"{x:1290,y:483,t:1528139675332};\\\", \\\"{x:1289,y:484,t:1528139675349};\\\", \\\"{x:1287,y:485,t:1528139675364};\\\", \\\"{x:1287,y:486,t:1528139675382};\\\", \\\"{x:1287,y:488,t:1528139675397};\\\", \\\"{x:1289,y:489,t:1528139675415};\\\", \\\"{x:1290,y:489,t:1528139675432};\\\", \\\"{x:1291,y:489,t:1528139675448};\\\", \\\"{x:1292,y:491,t:1528139675464};\\\", \\\"{x:1293,y:491,t:1528139675490};\\\", \\\"{x:1294,y:491,t:1528139675507};\\\", \\\"{x:1295,y:491,t:1528139675523};\\\", \\\"{x:1295,y:492,t:1528139675546};\\\", \\\"{x:1296,y:492,t:1528139675554};\\\", \\\"{x:1297,y:492,t:1528139675565};\\\", \\\"{x:1298,y:493,t:1528139675582};\\\", \\\"{x:1299,y:494,t:1528139675597};\\\", \\\"{x:1301,y:494,t:1528139675615};\\\", \\\"{x:1302,y:494,t:1528139675651};\\\", \\\"{x:1303,y:495,t:1528139675665};\\\", \\\"{x:1304,y:496,t:1528139675682};\\\", \\\"{x:1307,y:496,t:1528139675698};\\\", \\\"{x:1308,y:496,t:1528139675715};\\\", \\\"{x:1310,y:496,t:1528139675734};\\\", \\\"{x:1313,y:496,t:1528139675748};\\\", \\\"{x:1314,y:496,t:1528139675770};\\\", \\\"{x:1315,y:496,t:1528139675778};\\\", \\\"{x:1316,y:496,t:1528139675795};\\\", \\\"{x:1317,y:496,t:1528139678972};\\\", \\\"{x:1317,y:497,t:1528139679084};\\\", \\\"{x:1317,y:502,t:1528139679093};\\\", \\\"{x:1317,y:504,t:1528139679105};\\\", \\\"{x:1317,y:511,t:1528139679122};\\\", \\\"{x:1317,y:512,t:1528139679134};\\\", \\\"{x:1318,y:515,t:1528139679151};\\\", \\\"{x:1318,y:518,t:1528139679167};\\\", \\\"{x:1319,y:523,t:1528139679184};\\\", \\\"{x:1319,y:526,t:1528139679201};\\\", \\\"{x:1319,y:530,t:1528139679217};\\\", \\\"{x:1320,y:535,t:1528139679234};\\\", \\\"{x:1321,y:544,t:1528139679250};\\\", \\\"{x:1322,y:549,t:1528139679267};\\\", \\\"{x:1323,y:553,t:1528139679284};\\\", \\\"{x:1323,y:559,t:1528139679301};\\\", \\\"{x:1324,y:562,t:1528139679318};\\\", \\\"{x:1324,y:566,t:1528139679335};\\\", \\\"{x:1324,y:570,t:1528139679351};\\\", \\\"{x:1324,y:574,t:1528139679367};\\\", \\\"{x:1324,y:578,t:1528139679384};\\\", \\\"{x:1324,y:582,t:1528139679401};\\\", \\\"{x:1325,y:588,t:1528139679418};\\\", \\\"{x:1325,y:592,t:1528139679435};\\\", \\\"{x:1325,y:600,t:1528139679451};\\\", \\\"{x:1325,y:601,t:1528139679467};\\\", \\\"{x:1325,y:603,t:1528139679485};\\\", \\\"{x:1324,y:604,t:1528139679501};\\\", \\\"{x:1324,y:606,t:1528139679518};\\\", \\\"{x:1323,y:607,t:1528139679534};\\\", \\\"{x:1323,y:609,t:1528139679551};\\\", \\\"{x:1323,y:610,t:1528139679570};\\\", \\\"{x:1323,y:611,t:1528139679584};\\\", \\\"{x:1322,y:613,t:1528139679601};\\\", \\\"{x:1321,y:615,t:1528139679619};\\\", \\\"{x:1321,y:617,t:1528139679634};\\\", \\\"{x:1320,y:619,t:1528139679652};\\\", \\\"{x:1319,y:621,t:1528139679669};\\\", \\\"{x:1317,y:624,t:1528139679685};\\\", \\\"{x:1316,y:626,t:1528139679704};\\\", \\\"{x:1315,y:629,t:1528139679718};\\\", \\\"{x:1314,y:630,t:1528139679735};\\\", \\\"{x:1313,y:630,t:1528139680636};\\\", \\\"{x:1289,y:639,t:1528139680654};\\\", \\\"{x:1232,y:650,t:1528139680668};\\\", \\\"{x:1138,y:676,t:1528139680685};\\\", \\\"{x:1027,y:706,t:1528139680702};\\\", \\\"{x:931,y:726,t:1528139680719};\\\", \\\"{x:853,y:728,t:1528139680735};\\\", \\\"{x:817,y:728,t:1528139680752};\\\", \\\"{x:806,y:728,t:1528139680769};\\\", \\\"{x:802,y:728,t:1528139680859};\\\", \\\"{x:798,y:728,t:1528139680870};\\\", \\\"{x:789,y:727,t:1528139680885};\\\", \\\"{x:780,y:725,t:1528139680902};\\\", \\\"{x:773,y:722,t:1528139680919};\\\", \\\"{x:769,y:721,t:1528139680935};\\\", \\\"{x:764,y:719,t:1528139680952};\\\", \\\"{x:761,y:717,t:1528139680969};\\\", \\\"{x:757,y:716,t:1528139680987};\\\", \\\"{x:755,y:716,t:1528139681002};\\\", \\\"{x:746,y:714,t:1528139681019};\\\", \\\"{x:736,y:713,t:1528139681037};\\\", \\\"{x:717,y:710,t:1528139681052};\\\", \\\"{x:700,y:709,t:1528139681070};\\\", \\\"{x:683,y:708,t:1528139681087};\\\", \\\"{x:674,y:707,t:1528139681102};\\\", \\\"{x:670,y:705,t:1528139681119};\\\", \\\"{x:670,y:704,t:1528139681139};\\\", \\\"{x:670,y:700,t:1528139681153};\\\", \\\"{x:686,y:683,t:1528139681169};\\\", \\\"{x:712,y:668,t:1528139681187};\\\", \\\"{x:737,y:654,t:1528139681202};\\\", \\\"{x:772,y:633,t:1528139681219};\\\", \\\"{x:787,y:624,t:1528139681236};\\\", \\\"{x:795,y:620,t:1528139681252};\\\", \\\"{x:797,y:618,t:1528139681269};\\\", \\\"{x:798,y:618,t:1528139681291};\\\", \\\"{x:800,y:616,t:1528139681306};\\\", \\\"{x:803,y:614,t:1528139681319};\\\", \\\"{x:808,y:611,t:1528139681336};\\\", \\\"{x:810,y:609,t:1528139681352};\\\", \\\"{x:814,y:606,t:1528139681369};\\\", \\\"{x:823,y:600,t:1528139681386};\\\", \\\"{x:834,y:595,t:1528139681402};\\\", \\\"{x:838,y:593,t:1528139681420};\\\", \\\"{x:838,y:592,t:1528139681436};\\\", \\\"{x:838,y:589,t:1528139681579};\\\", \\\"{x:838,y:585,t:1528139681587};\\\", \\\"{x:836,y:582,t:1528139681603};\\\", \\\"{x:834,y:579,t:1528139681619};\\\", \\\"{x:833,y:578,t:1528139681636};\\\", \\\"{x:832,y:578,t:1528139681666};\\\", \\\"{x:830,y:577,t:1528139681691};\\\", \\\"{x:828,y:577,t:1528139682164};\\\", \\\"{x:821,y:586,t:1528139682172};\\\", \\\"{x:811,y:598,t:1528139682187};\\\", \\\"{x:781,y:625,t:1528139682204};\\\", \\\"{x:748,y:646,t:1528139682221};\\\", \\\"{x:707,y:672,t:1528139682237};\\\", \\\"{x:666,y:695,t:1528139682253};\\\", \\\"{x:631,y:714,t:1528139682270};\\\", \\\"{x:605,y:725,t:1528139682287};\\\", \\\"{x:585,y:731,t:1528139682303};\\\", \\\"{x:575,y:734,t:1528139682320};\\\", \\\"{x:570,y:736,t:1528139682336};\\\", \\\"{x:565,y:736,t:1528139682353};\\\", \\\"{x:564,y:738,t:1528139682370};\\\", \\\"{x:562,y:739,t:1528139682443};\\\", \\\"{x:560,y:742,t:1528139682453};\\\", \\\"{x:555,y:748,t:1528139682469};\\\", \\\"{x:551,y:756,t:1528139682488};\\\", \\\"{x:548,y:760,t:1528139682503};\\\", \\\"{x:545,y:764,t:1528139682520};\\\", \\\"{x:542,y:767,t:1528139682537};\\\", \\\"{x:541,y:768,t:1528139682554};\\\", \\\"{x:540,y:769,t:1528139682570};\\\", \\\"{x:539,y:769,t:1528139682587};\\\", \\\"{x:538,y:772,t:1528139682604};\\\", \\\"{x:537,y:773,t:1528139682620};\\\", \\\"{x:536,y:774,t:1528139682638};\\\" ] }, { \\\"rt\\\": 47446, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 347347, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -11 AM-11 AM-J -J -J -I -I -E -E -G -G -10 AM-11 AM-12 PM-01 PM-A -09 AM-10 AM-J -09 AM-10 AM-10 AM-11 AM-12 PM-02 PM-03 PM-12 PM-B -09 AM-10 AM-11 AM-11 AM-12 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1204,y:884,t:1528139684063};\\\", \\\"{x:1216,y:885,t:1528139684071};\\\", \\\"{x:1230,y:887,t:1528139684088};\\\", \\\"{x:1250,y:887,t:1528139684104};\\\", \\\"{x:1300,y:870,t:1528139684121};\\\", \\\"{x:1452,y:809,t:1528139684138};\\\", \\\"{x:1538,y:772,t:1528139684154};\\\", \\\"{x:1591,y:747,t:1528139684171};\\\", \\\"{x:1632,y:730,t:1528139684188};\\\", \\\"{x:1692,y:694,t:1528139684206};\\\", \\\"{x:1829,y:614,t:1528139684231};\\\", \\\"{x:1875,y:590,t:1528139684239};\\\", \\\"{x:1919,y:544,t:1528139684256};\\\", \\\"{x:1919,y:481,t:1528139684271};\\\", \\\"{x:1919,y:386,t:1528139684288};\\\", \\\"{x:1919,y:275,t:1528139684305};\\\", \\\"{x:1919,y:164,t:1528139684321};\\\", \\\"{x:1919,y:11,t:1528139684338};\\\", \\\"{x:1919,y:0,t:1528139684356};\\\", \\\"{x:1915,y:0,t:1528139684379};\\\", \\\"{x:1914,y:0,t:1528139684388};\\\", \\\"{x:1911,y:0,t:1528139684406};\\\", \\\"{x:1910,y:0,t:1528139684427};\\\", \\\"{x:1909,y:0,t:1528139684875};\\\", \\\"{x:1901,y:0,t:1528139684889};\\\", \\\"{x:1880,y:0,t:1528139684906};\\\", \\\"{x:1798,y:6,t:1528139684923};\\\", \\\"{x:1718,y:14,t:1528139684939};\\\", \\\"{x:1651,y:15,t:1528139684955};\\\", \\\"{x:1594,y:18,t:1528139684973};\\\", \\\"{x:1541,y:18,t:1528139684990};\\\", \\\"{x:1486,y:23,t:1528139685006};\\\", \\\"{x:1435,y:31,t:1528139685022};\\\", \\\"{x:1401,y:40,t:1528139685039};\\\", \\\"{x:1374,y:48,t:1528139685056};\\\", \\\"{x:1353,y:57,t:1528139685073};\\\", \\\"{x:1330,y:69,t:1528139685090};\\\", \\\"{x:1310,y:77,t:1528139685105};\\\", \\\"{x:1282,y:91,t:1528139685122};\\\", \\\"{x:1269,y:96,t:1528139685139};\\\", \\\"{x:1257,y:103,t:1528139685156};\\\", \\\"{x:1249,y:107,t:1528139685173};\\\", \\\"{x:1243,y:111,t:1528139685189};\\\", \\\"{x:1240,y:112,t:1528139685206};\\\", \\\"{x:1238,y:113,t:1528139685222};\\\", \\\"{x:1237,y:113,t:1528139685239};\\\", \\\"{x:1236,y:113,t:1528139685256};\\\", \\\"{x:1235,y:113,t:1528139685291};\\\", \\\"{x:1235,y:114,t:1528139685739};\\\", \\\"{x:1242,y:147,t:1528139685757};\\\", \\\"{x:1271,y:236,t:1528139685774};\\\", \\\"{x:1302,y:305,t:1528139685790};\\\", \\\"{x:1325,y:345,t:1528139685807};\\\", \\\"{x:1359,y:395,t:1528139685824};\\\", \\\"{x:1409,y:451,t:1528139685839};\\\", \\\"{x:1461,y:524,t:1528139685857};\\\", \\\"{x:1491,y:575,t:1528139685874};\\\", \\\"{x:1507,y:626,t:1528139685890};\\\", \\\"{x:1522,y:705,t:1528139685907};\\\", \\\"{x:1524,y:744,t:1528139685924};\\\", \\\"{x:1524,y:772,t:1528139685940};\\\", \\\"{x:1524,y:800,t:1528139685957};\\\", \\\"{x:1524,y:832,t:1528139685974};\\\", \\\"{x:1524,y:858,t:1528139685991};\\\", \\\"{x:1524,y:877,t:1528139686008};\\\", \\\"{x:1516,y:897,t:1528139686024};\\\", \\\"{x:1510,y:910,t:1528139686040};\\\", \\\"{x:1505,y:922,t:1528139686057};\\\", \\\"{x:1498,y:932,t:1528139686074};\\\", \\\"{x:1487,y:943,t:1528139686091};\\\", \\\"{x:1480,y:947,t:1528139686107};\\\", \\\"{x:1474,y:951,t:1528139686123};\\\", \\\"{x:1467,y:952,t:1528139686140};\\\", \\\"{x:1466,y:952,t:1528139686156};\\\", \\\"{x:1464,y:952,t:1528139686174};\\\", \\\"{x:1463,y:952,t:1528139686190};\\\", \\\"{x:1459,y:952,t:1528139686211};\\\", \\\"{x:1456,y:952,t:1528139686223};\\\", \\\"{x:1442,y:949,t:1528139686240};\\\", \\\"{x:1423,y:939,t:1528139686256};\\\", \\\"{x:1403,y:925,t:1528139686273};\\\", \\\"{x:1375,y:909,t:1528139686291};\\\", \\\"{x:1350,y:892,t:1528139686306};\\\", \\\"{x:1322,y:874,t:1528139686323};\\\", \\\"{x:1303,y:861,t:1528139686340};\\\", \\\"{x:1290,y:845,t:1528139686357};\\\", \\\"{x:1277,y:827,t:1528139686373};\\\", \\\"{x:1269,y:817,t:1528139686390};\\\", \\\"{x:1264,y:808,t:1528139686407};\\\", \\\"{x:1260,y:800,t:1528139686423};\\\", \\\"{x:1257,y:797,t:1528139686441};\\\", \\\"{x:1252,y:792,t:1528139686457};\\\", \\\"{x:1244,y:788,t:1528139686474};\\\", \\\"{x:1224,y:781,t:1528139686491};\\\", \\\"{x:1208,y:775,t:1528139686506};\\\", \\\"{x:1188,y:770,t:1528139686523};\\\", \\\"{x:1168,y:764,t:1528139686540};\\\", \\\"{x:1153,y:759,t:1528139686558};\\\", \\\"{x:1149,y:757,t:1528139686573};\\\", \\\"{x:1147,y:757,t:1528139686591};\\\", \\\"{x:1147,y:756,t:1528139686628};\\\", \\\"{x:1148,y:756,t:1528139686715};\\\", \\\"{x:1150,y:756,t:1528139686723};\\\", \\\"{x:1154,y:756,t:1528139686741};\\\", \\\"{x:1158,y:757,t:1528139686758};\\\", \\\"{x:1164,y:758,t:1528139686774};\\\", \\\"{x:1165,y:759,t:1528139686791};\\\", \\\"{x:1176,y:765,t:1528139686810};\\\", \\\"{x:1184,y:769,t:1528139686825};\\\", \\\"{x:1185,y:770,t:1528139686840};\\\", \\\"{x:1186,y:771,t:1528139686915};\\\", \\\"{x:1182,y:771,t:1528139687084};\\\", \\\"{x:1180,y:771,t:1528139687091};\\\", \\\"{x:1177,y:769,t:1528139687107};\\\", \\\"{x:1175,y:768,t:1528139687125};\\\", \\\"{x:1173,y:767,t:1528139687140};\\\", \\\"{x:1173,y:766,t:1528139687171};\\\", \\\"{x:1172,y:765,t:1528139687195};\\\", \\\"{x:1172,y:764,t:1528139687219};\\\", \\\"{x:1173,y:763,t:1528139687236};\\\", \\\"{x:1173,y:762,t:1528139687283};\\\", \\\"{x:1174,y:762,t:1528139687307};\\\", \\\"{x:1174,y:761,t:1528139687339};\\\", \\\"{x:1175,y:761,t:1528139687420};\\\", \\\"{x:1176,y:761,t:1528139687476};\\\", \\\"{x:1177,y:761,t:1528139687492};\\\", \\\"{x:1178,y:761,t:1528139687539};\\\", \\\"{x:1179,y:762,t:1528139687604};\\\", \\\"{x:1179,y:768,t:1528139687611};\\\", \\\"{x:1179,y:770,t:1528139687626};\\\", \\\"{x:1179,y:783,t:1528139687642};\\\", \\\"{x:1179,y:804,t:1528139687658};\\\", \\\"{x:1179,y:837,t:1528139687675};\\\", \\\"{x:1179,y:857,t:1528139687692};\\\", \\\"{x:1179,y:872,t:1528139687708};\\\", \\\"{x:1180,y:884,t:1528139687725};\\\", \\\"{x:1183,y:897,t:1528139687742};\\\", \\\"{x:1189,y:912,t:1528139687759};\\\", \\\"{x:1200,y:931,t:1528139687775};\\\", \\\"{x:1213,y:944,t:1528139687792};\\\", \\\"{x:1228,y:953,t:1528139687809};\\\", \\\"{x:1247,y:965,t:1528139687825};\\\", \\\"{x:1265,y:974,t:1528139687842};\\\", \\\"{x:1285,y:984,t:1528139687859};\\\", \\\"{x:1289,y:986,t:1528139687876};\\\", \\\"{x:1291,y:988,t:1528139687892};\\\", \\\"{x:1292,y:989,t:1528139687909};\\\", \\\"{x:1293,y:989,t:1528139687964};\\\", \\\"{x:1294,y:989,t:1528139687979};\\\", \\\"{x:1295,y:990,t:1528139687992};\\\", \\\"{x:1295,y:991,t:1528139688076};\\\", \\\"{x:1292,y:986,t:1528139688099};\\\", \\\"{x:1286,y:972,t:1528139688110};\\\", \\\"{x:1269,y:944,t:1528139688126};\\\", \\\"{x:1253,y:922,t:1528139688141};\\\", \\\"{x:1242,y:906,t:1528139688158};\\\", \\\"{x:1238,y:898,t:1528139688175};\\\", \\\"{x:1234,y:888,t:1528139688191};\\\", \\\"{x:1232,y:882,t:1528139688209};\\\", \\\"{x:1232,y:879,t:1528139688225};\\\", \\\"{x:1232,y:874,t:1528139688242};\\\", \\\"{x:1232,y:869,t:1528139688258};\\\", \\\"{x:1232,y:868,t:1528139688275};\\\", \\\"{x:1232,y:866,t:1528139688291};\\\", \\\"{x:1232,y:865,t:1528139688363};\\\", \\\"{x:1232,y:863,t:1528139688379};\\\", \\\"{x:1232,y:862,t:1528139688392};\\\", \\\"{x:1232,y:859,t:1528139688409};\\\", \\\"{x:1232,y:854,t:1528139688426};\\\", \\\"{x:1229,y:842,t:1528139688443};\\\", \\\"{x:1225,y:837,t:1528139688459};\\\", \\\"{x:1223,y:833,t:1528139688476};\\\", \\\"{x:1221,y:830,t:1528139688493};\\\", \\\"{x:1220,y:827,t:1528139688509};\\\", \\\"{x:1219,y:825,t:1528139688526};\\\", \\\"{x:1218,y:823,t:1528139688543};\\\", \\\"{x:1218,y:821,t:1528139688559};\\\", \\\"{x:1218,y:818,t:1528139688576};\\\", \\\"{x:1218,y:817,t:1528139688627};\\\", \\\"{x:1217,y:818,t:1528139688739};\\\", \\\"{x:1216,y:819,t:1528139688755};\\\", \\\"{x:1215,y:819,t:1528139688772};\\\", \\\"{x:1215,y:820,t:1528139688787};\\\", \\\"{x:1215,y:821,t:1528139688795};\\\", \\\"{x:1214,y:821,t:1528139688835};\\\", \\\"{x:1214,y:822,t:1528139688899};\\\", \\\"{x:1213,y:822,t:1528139688915};\\\", \\\"{x:1213,y:823,t:1528139689044};\\\", \\\"{x:1214,y:826,t:1528139689060};\\\", \\\"{x:1215,y:828,t:1528139689093};\\\", \\\"{x:1216,y:830,t:1528139689110};\\\", \\\"{x:1216,y:831,t:1528139689131};\\\", \\\"{x:1217,y:833,t:1528139689143};\\\", \\\"{x:1216,y:830,t:1528139689427};\\\", \\\"{x:1215,y:826,t:1528139689443};\\\", \\\"{x:1215,y:822,t:1528139689461};\\\", \\\"{x:1214,y:813,t:1528139689477};\\\", \\\"{x:1214,y:803,t:1528139689494};\\\", \\\"{x:1212,y:795,t:1528139689510};\\\", \\\"{x:1212,y:787,t:1528139689527};\\\", \\\"{x:1207,y:773,t:1528139689543};\\\", \\\"{x:1205,y:771,t:1528139689560};\\\", \\\"{x:1205,y:770,t:1528139689577};\\\", \\\"{x:1204,y:768,t:1528139689594};\\\", \\\"{x:1203,y:766,t:1528139689610};\\\", \\\"{x:1202,y:761,t:1528139689627};\\\", \\\"{x:1199,y:756,t:1528139689644};\\\", \\\"{x:1198,y:755,t:1528139689660};\\\", \\\"{x:1197,y:755,t:1528139689677};\\\", \\\"{x:1196,y:754,t:1528139689716};\\\", \\\"{x:1196,y:753,t:1528139689727};\\\", \\\"{x:1191,y:753,t:1528139689744};\\\", \\\"{x:1186,y:753,t:1528139689761};\\\", \\\"{x:1182,y:753,t:1528139689777};\\\", \\\"{x:1179,y:753,t:1528139689794};\\\", \\\"{x:1178,y:753,t:1528139689810};\\\", \\\"{x:1177,y:753,t:1528139689835};\\\", \\\"{x:1175,y:753,t:1528139689924};\\\", \\\"{x:1173,y:754,t:1528139689995};\\\", \\\"{x:1172,y:755,t:1528139690011};\\\", \\\"{x:1172,y:756,t:1528139690035};\\\", \\\"{x:1172,y:757,t:1528139690075};\\\", \\\"{x:1173,y:759,t:1528139690252};\\\", \\\"{x:1174,y:759,t:1528139690291};\\\", \\\"{x:1175,y:759,t:1528139690316};\\\", \\\"{x:1176,y:760,t:1528139690347};\\\", \\\"{x:1177,y:761,t:1528139690859};\\\", \\\"{x:1179,y:762,t:1528139690867};\\\", \\\"{x:1180,y:763,t:1528139690878};\\\", \\\"{x:1181,y:763,t:1528139690915};\\\", \\\"{x:1182,y:764,t:1528139691043};\\\", \\\"{x:1183,y:765,t:1528139691067};\\\", \\\"{x:1183,y:766,t:1528139691078};\\\", \\\"{x:1183,y:768,t:1528139691122};\\\", \\\"{x:1183,y:769,t:1528139691155};\\\", \\\"{x:1183,y:770,t:1528139691178};\\\", \\\"{x:1183,y:771,t:1528139691579};\\\", \\\"{x:1193,y:759,t:1528139691595};\\\", \\\"{x:1211,y:726,t:1528139691612};\\\", \\\"{x:1237,y:692,t:1528139691628};\\\", \\\"{x:1264,y:661,t:1528139691645};\\\", \\\"{x:1282,y:637,t:1528139691662};\\\", \\\"{x:1291,y:621,t:1528139691679};\\\", \\\"{x:1295,y:609,t:1528139691696};\\\", \\\"{x:1295,y:604,t:1528139691712};\\\", \\\"{x:1295,y:601,t:1528139691729};\\\", \\\"{x:1295,y:599,t:1528139691745};\\\", \\\"{x:1295,y:598,t:1528139691762};\\\", \\\"{x:1294,y:595,t:1528139691779};\\\", \\\"{x:1294,y:591,t:1528139691795};\\\", \\\"{x:1293,y:588,t:1528139691813};\\\", \\\"{x:1290,y:584,t:1528139691829};\\\", \\\"{x:1289,y:584,t:1528139691845};\\\", \\\"{x:1288,y:583,t:1528139691862};\\\", \\\"{x:1287,y:583,t:1528139691879};\\\", \\\"{x:1284,y:581,t:1528139691895};\\\", \\\"{x:1283,y:580,t:1528139691912};\\\", \\\"{x:1282,y:578,t:1528139691930};\\\", \\\"{x:1281,y:574,t:1528139691945};\\\", \\\"{x:1280,y:571,t:1528139691962};\\\", \\\"{x:1278,y:568,t:1528139691979};\\\", \\\"{x:1278,y:567,t:1528139691995};\\\", \\\"{x:1278,y:565,t:1528139692012};\\\", \\\"{x:1278,y:562,t:1528139692029};\\\", \\\"{x:1278,y:561,t:1528139692045};\\\", \\\"{x:1278,y:559,t:1528139692062};\\\", \\\"{x:1278,y:558,t:1528139692132};\\\", \\\"{x:1277,y:557,t:1528139692260};\\\", \\\"{x:1283,y:556,t:1528139699404};\\\", \\\"{x:1294,y:550,t:1528139699419};\\\", \\\"{x:1330,y:541,t:1528139699435};\\\", \\\"{x:1350,y:538,t:1528139699453};\\\", \\\"{x:1364,y:536,t:1528139699468};\\\", \\\"{x:1374,y:535,t:1528139699486};\\\", \\\"{x:1379,y:534,t:1528139699503};\\\", \\\"{x:1382,y:533,t:1528139699519};\\\", \\\"{x:1384,y:533,t:1528139699555};\\\", \\\"{x:1385,y:533,t:1528139699588};\\\", \\\"{x:1387,y:533,t:1528139699603};\\\", \\\"{x:1388,y:533,t:1528139699618};\\\", \\\"{x:1391,y:533,t:1528139699635};\\\", \\\"{x:1394,y:533,t:1528139699652};\\\", \\\"{x:1397,y:533,t:1528139699669};\\\", \\\"{x:1402,y:533,t:1528139699686};\\\", \\\"{x:1405,y:535,t:1528139699703};\\\", \\\"{x:1412,y:540,t:1528139699718};\\\", \\\"{x:1417,y:544,t:1528139699736};\\\", \\\"{x:1429,y:552,t:1528139699753};\\\", \\\"{x:1435,y:557,t:1528139699769};\\\", \\\"{x:1440,y:562,t:1528139699786};\\\", \\\"{x:1443,y:569,t:1528139699802};\\\", \\\"{x:1447,y:576,t:1528139699819};\\\", \\\"{x:1448,y:576,t:1528139699835};\\\", \\\"{x:1448,y:577,t:1528139699947};\\\", \\\"{x:1446,y:577,t:1528139699955};\\\", \\\"{x:1440,y:575,t:1528139699969};\\\", \\\"{x:1430,y:573,t:1528139699985};\\\", \\\"{x:1422,y:569,t:1528139700002};\\\", \\\"{x:1410,y:566,t:1528139700019};\\\", \\\"{x:1407,y:565,t:1528139700037};\\\", \\\"{x:1405,y:565,t:1528139700053};\\\", \\\"{x:1406,y:565,t:1528139700195};\\\", \\\"{x:1407,y:566,t:1528139700211};\\\", \\\"{x:1407,y:567,t:1528139700227};\\\", \\\"{x:1407,y:568,t:1528139700237};\\\", \\\"{x:1407,y:569,t:1528139700259};\\\", \\\"{x:1407,y:571,t:1528139700275};\\\", \\\"{x:1407,y:572,t:1528139700286};\\\", \\\"{x:1407,y:576,t:1528139700302};\\\", \\\"{x:1407,y:580,t:1528139700319};\\\", \\\"{x:1407,y:587,t:1528139700336};\\\", \\\"{x:1404,y:600,t:1528139700353};\\\", \\\"{x:1398,y:612,t:1528139700370};\\\", \\\"{x:1389,y:636,t:1528139700386};\\\", \\\"{x:1381,y:654,t:1528139700401};\\\", \\\"{x:1369,y:683,t:1528139700418};\\\", \\\"{x:1349,y:737,t:1528139700436};\\\", \\\"{x:1336,y:803,t:1528139700451};\\\", \\\"{x:1327,y:867,t:1528139700468};\\\", \\\"{x:1320,y:912,t:1528139700485};\\\", \\\"{x:1317,y:941,t:1528139700502};\\\", \\\"{x:1317,y:963,t:1528139700519};\\\", \\\"{x:1315,y:988,t:1528139700536};\\\", \\\"{x:1310,y:1017,t:1528139700552};\\\", \\\"{x:1298,y:1051,t:1528139700568};\\\", \\\"{x:1273,y:1103,t:1528139700586};\\\", \\\"{x:1259,y:1123,t:1528139700602};\\\", \\\"{x:1250,y:1138,t:1528139700619};\\\", \\\"{x:1241,y:1149,t:1528139700636};\\\", \\\"{x:1234,y:1153,t:1528139700652};\\\", \\\"{x:1232,y:1153,t:1528139700669};\\\", \\\"{x:1229,y:1153,t:1528139700715};\\\", \\\"{x:1227,y:1153,t:1528139700722};\\\", \\\"{x:1225,y:1153,t:1528139700736};\\\", \\\"{x:1221,y:1136,t:1528139700753};\\\", \\\"{x:1220,y:1116,t:1528139700769};\\\", \\\"{x:1220,y:1099,t:1528139700786};\\\", \\\"{x:1226,y:1074,t:1528139700802};\\\", \\\"{x:1230,y:1061,t:1528139700819};\\\", \\\"{x:1234,y:1051,t:1528139700836};\\\", \\\"{x:1235,y:1048,t:1528139700853};\\\", \\\"{x:1236,y:1047,t:1528139700870};\\\", \\\"{x:1237,y:1045,t:1528139700886};\\\", \\\"{x:1239,y:1042,t:1528139700903};\\\", \\\"{x:1239,y:1040,t:1528139700930};\\\", \\\"{x:1239,y:1039,t:1528139700939};\\\", \\\"{x:1239,y:1038,t:1528139700954};\\\", \\\"{x:1241,y:1036,t:1528139700969};\\\", \\\"{x:1241,y:1034,t:1528139700986};\\\", \\\"{x:1243,y:1031,t:1528139701003};\\\", \\\"{x:1246,y:1027,t:1528139701019};\\\", \\\"{x:1250,y:1022,t:1528139701036};\\\", \\\"{x:1253,y:1019,t:1528139701053};\\\", \\\"{x:1255,y:1017,t:1528139701075};\\\", \\\"{x:1257,y:1016,t:1528139701091};\\\", \\\"{x:1258,y:1016,t:1528139701115};\\\", \\\"{x:1259,y:1016,t:1528139701123};\\\", \\\"{x:1261,y:1014,t:1528139701136};\\\", \\\"{x:1262,y:1013,t:1528139701153};\\\", \\\"{x:1267,y:1010,t:1528139701171};\\\", \\\"{x:1269,y:1010,t:1528139701186};\\\", \\\"{x:1269,y:1009,t:1528139701203};\\\", \\\"{x:1271,y:1009,t:1528139701222};\\\", \\\"{x:1272,y:1008,t:1528139701236};\\\", \\\"{x:1272,y:1007,t:1528139701435};\\\", \\\"{x:1273,y:1007,t:1528139701450};\\\", \\\"{x:1273,y:1005,t:1528139701492};\\\", \\\"{x:1274,y:1004,t:1528139701523};\\\", \\\"{x:1275,y:1004,t:1528139701548};\\\", \\\"{x:1275,y:1003,t:1528139701563};\\\", \\\"{x:1275,y:1002,t:1528139701571};\\\", \\\"{x:1276,y:1001,t:1528139701586};\\\", \\\"{x:1277,y:1000,t:1528139701604};\\\", \\\"{x:1278,y:1000,t:1528139701620};\\\", \\\"{x:1278,y:999,t:1528139701638};\\\", \\\"{x:1278,y:998,t:1528139701658};\\\", \\\"{x:1278,y:996,t:1528139701723};\\\", \\\"{x:1276,y:995,t:1528139701737};\\\", \\\"{x:1275,y:994,t:1528139701753};\\\", \\\"{x:1270,y:992,t:1528139701771};\\\", \\\"{x:1269,y:992,t:1528139701787};\\\", \\\"{x:1268,y:992,t:1528139701835};\\\", \\\"{x:1267,y:992,t:1528139701867};\\\", \\\"{x:1266,y:992,t:1528139701875};\\\", \\\"{x:1265,y:992,t:1528139701887};\\\", \\\"{x:1260,y:992,t:1528139701903};\\\", \\\"{x:1259,y:992,t:1528139701920};\\\", \\\"{x:1255,y:992,t:1528139701937};\\\", \\\"{x:1249,y:992,t:1528139701954};\\\", \\\"{x:1244,y:991,t:1528139701969};\\\", \\\"{x:1240,y:990,t:1528139701987};\\\", \\\"{x:1237,y:989,t:1528139702004};\\\", \\\"{x:1233,y:988,t:1528139702020};\\\", \\\"{x:1229,y:986,t:1528139702037};\\\", \\\"{x:1226,y:986,t:1528139702055};\\\", \\\"{x:1225,y:986,t:1528139702107};\\\", \\\"{x:1224,y:986,t:1528139702120};\\\", \\\"{x:1223,y:985,t:1528139702137};\\\", \\\"{x:1223,y:984,t:1528139702179};\\\", \\\"{x:1222,y:982,t:1528139702187};\\\", \\\"{x:1222,y:981,t:1528139702205};\\\", \\\"{x:1222,y:980,t:1528139702221};\\\", \\\"{x:1222,y:979,t:1528139702238};\\\", \\\"{x:1222,y:978,t:1528139702254};\\\", \\\"{x:1223,y:978,t:1528139702859};\\\", \\\"{x:1226,y:980,t:1528139702871};\\\", \\\"{x:1227,y:982,t:1528139702891};\\\", \\\"{x:1229,y:982,t:1528139702904};\\\", \\\"{x:1232,y:983,t:1528139702922};\\\", \\\"{x:1236,y:983,t:1528139702939};\\\", \\\"{x:1240,y:983,t:1528139702955};\\\", \\\"{x:1244,y:983,t:1528139702972};\\\", \\\"{x:1250,y:983,t:1528139702988};\\\", \\\"{x:1253,y:983,t:1528139703005};\\\", \\\"{x:1254,y:983,t:1528139703022};\\\", \\\"{x:1257,y:983,t:1528139703038};\\\", \\\"{x:1258,y:983,t:1528139703055};\\\", \\\"{x:1262,y:983,t:1528139703072};\\\", \\\"{x:1264,y:983,t:1528139703088};\\\", \\\"{x:1266,y:981,t:1528139703104};\\\", \\\"{x:1269,y:979,t:1528139703121};\\\", \\\"{x:1273,y:977,t:1528139703139};\\\", \\\"{x:1276,y:975,t:1528139703154};\\\", \\\"{x:1277,y:975,t:1528139703171};\\\", \\\"{x:1278,y:974,t:1528139703267};\\\", \\\"{x:1278,y:973,t:1528139703283};\\\", \\\"{x:1281,y:973,t:1528139703467};\\\", \\\"{x:1282,y:972,t:1528139703491};\\\", \\\"{x:1283,y:972,t:1528139703835};\\\", \\\"{x:1284,y:972,t:1528139703843};\\\", \\\"{x:1285,y:972,t:1528139703859};\\\", \\\"{x:1288,y:974,t:1528139703874};\\\", \\\"{x:1291,y:976,t:1528139703889};\\\", \\\"{x:1296,y:978,t:1528139703905};\\\", \\\"{x:1302,y:981,t:1528139703922};\\\", \\\"{x:1310,y:984,t:1528139703939};\\\", \\\"{x:1317,y:988,t:1528139703955};\\\", \\\"{x:1324,y:990,t:1528139703972};\\\", \\\"{x:1328,y:993,t:1528139703989};\\\", \\\"{x:1331,y:993,t:1528139704005};\\\", \\\"{x:1332,y:993,t:1528139704022};\\\", \\\"{x:1334,y:994,t:1528139704040};\\\", \\\"{x:1335,y:994,t:1528139704058};\\\", \\\"{x:1336,y:994,t:1528139704090};\\\", \\\"{x:1338,y:994,t:1528139704106};\\\", \\\"{x:1344,y:994,t:1528139704123};\\\", \\\"{x:1348,y:994,t:1528139704138};\\\", \\\"{x:1350,y:994,t:1528139704155};\\\", \\\"{x:1351,y:994,t:1528139704186};\\\", \\\"{x:1352,y:994,t:1528139704227};\\\", \\\"{x:1353,y:994,t:1528139704243};\\\", \\\"{x:1355,y:993,t:1528139704256};\\\", \\\"{x:1355,y:992,t:1528139704273};\\\", \\\"{x:1358,y:992,t:1528139704290};\\\", \\\"{x:1361,y:990,t:1528139704305};\\\", \\\"{x:1362,y:989,t:1528139704322};\\\", \\\"{x:1362,y:987,t:1528139704371};\\\", \\\"{x:1362,y:986,t:1528139704395};\\\", \\\"{x:1362,y:984,t:1528139704451};\\\", \\\"{x:1362,y:983,t:1528139704483};\\\", \\\"{x:1362,y:981,t:1528139704515};\\\", \\\"{x:1362,y:980,t:1528139704539};\\\", \\\"{x:1362,y:979,t:1528139704563};\\\", \\\"{x:1363,y:979,t:1528139705131};\\\", \\\"{x:1367,y:979,t:1528139705140};\\\", \\\"{x:1376,y:979,t:1528139705157};\\\", \\\"{x:1384,y:979,t:1528139705173};\\\", \\\"{x:1391,y:979,t:1528139705190};\\\", \\\"{x:1397,y:979,t:1528139705207};\\\", \\\"{x:1401,y:978,t:1528139705224};\\\", \\\"{x:1404,y:974,t:1528139705241};\\\", \\\"{x:1411,y:952,t:1528139705257};\\\", \\\"{x:1423,y:879,t:1528139705273};\\\", \\\"{x:1427,y:717,t:1528139705291};\\\", \\\"{x:1431,y:575,t:1528139705306};\\\", \\\"{x:1429,y:472,t:1528139705323};\\\", \\\"{x:1408,y:395,t:1528139705341};\\\", \\\"{x:1393,y:359,t:1528139705357};\\\", \\\"{x:1383,y:344,t:1528139705373};\\\", \\\"{x:1381,y:342,t:1528139705390};\\\", \\\"{x:1381,y:343,t:1528139705435};\\\", \\\"{x:1382,y:343,t:1528139705443};\\\", \\\"{x:1383,y:344,t:1528139705456};\\\", \\\"{x:1385,y:345,t:1528139705473};\\\", \\\"{x:1385,y:347,t:1528139705491};\\\", \\\"{x:1385,y:353,t:1528139705506};\\\", \\\"{x:1385,y:362,t:1528139705523};\\\", \\\"{x:1385,y:373,t:1528139705541};\\\", \\\"{x:1388,y:385,t:1528139705557};\\\", \\\"{x:1393,y:396,t:1528139705573};\\\", \\\"{x:1399,y:405,t:1528139705591};\\\", \\\"{x:1404,y:415,t:1528139705608};\\\", \\\"{x:1407,y:420,t:1528139705624};\\\", \\\"{x:1407,y:422,t:1528139705640};\\\", \\\"{x:1407,y:423,t:1528139705658};\\\", \\\"{x:1407,y:425,t:1528139705674};\\\", \\\"{x:1407,y:428,t:1528139705691};\\\", \\\"{x:1407,y:429,t:1528139705708};\\\", \\\"{x:1407,y:430,t:1528139705724};\\\", \\\"{x:1408,y:430,t:1528139705771};\\\", \\\"{x:1408,y:431,t:1528139705780};\\\", \\\"{x:1409,y:431,t:1528139705795};\\\", \\\"{x:1410,y:431,t:1528139705851};\\\", \\\"{x:1412,y:433,t:1528139706467};\\\", \\\"{x:1414,y:440,t:1528139706476};\\\", \\\"{x:1417,y:450,t:1528139706491};\\\", \\\"{x:1422,y:464,t:1528139706507};\\\", \\\"{x:1429,y:477,t:1528139706525};\\\", \\\"{x:1435,y:499,t:1528139706541};\\\", \\\"{x:1446,y:528,t:1528139706558};\\\", \\\"{x:1459,y:554,t:1528139706575};\\\", \\\"{x:1473,y:592,t:1528139706592};\\\", \\\"{x:1493,y:634,t:1528139706607};\\\", \\\"{x:1522,y:683,t:1528139706624};\\\", \\\"{x:1565,y:749,t:1528139706642};\\\", \\\"{x:1600,y:810,t:1528139706658};\\\", \\\"{x:1648,y:877,t:1528139706675};\\\", \\\"{x:1669,y:906,t:1528139706692};\\\", \\\"{x:1680,y:924,t:1528139706708};\\\", \\\"{x:1686,y:943,t:1528139706725};\\\", \\\"{x:1690,y:966,t:1528139706742};\\\", \\\"{x:1690,y:990,t:1528139706757};\\\", \\\"{x:1690,y:1016,t:1528139706775};\\\", \\\"{x:1690,y:1043,t:1528139706791};\\\", \\\"{x:1687,y:1073,t:1528139706808};\\\", \\\"{x:1681,y:1101,t:1528139706825};\\\", \\\"{x:1679,y:1122,t:1528139706841};\\\", \\\"{x:1676,y:1130,t:1528139706859};\\\", \\\"{x:1675,y:1130,t:1528139706939};\\\", \\\"{x:1673,y:1126,t:1528139706946};\\\", \\\"{x:1672,y:1120,t:1528139706958};\\\", \\\"{x:1667,y:1106,t:1528139706975};\\\", \\\"{x:1662,y:1089,t:1528139706992};\\\", \\\"{x:1660,y:1077,t:1528139707009};\\\", \\\"{x:1659,y:1069,t:1528139707025};\\\", \\\"{x:1658,y:1060,t:1528139707042};\\\", \\\"{x:1655,y:1052,t:1528139707059};\\\", \\\"{x:1655,y:1049,t:1528139707075};\\\", \\\"{x:1651,y:1042,t:1528139707092};\\\", \\\"{x:1650,y:1040,t:1528139707108};\\\", \\\"{x:1648,y:1035,t:1528139707125};\\\", \\\"{x:1645,y:1028,t:1528139707142};\\\", \\\"{x:1641,y:1023,t:1528139707158};\\\", \\\"{x:1634,y:1016,t:1528139707176};\\\", \\\"{x:1618,y:1009,t:1528139707192};\\\", \\\"{x:1595,y:1003,t:1528139707209};\\\", \\\"{x:1560,y:992,t:1528139707226};\\\", \\\"{x:1468,y:965,t:1528139707242};\\\", \\\"{x:1278,y:921,t:1528139707259};\\\", \\\"{x:1172,y:899,t:1528139707275};\\\", \\\"{x:1108,y:881,t:1528139707292};\\\", \\\"{x:1086,y:875,t:1528139707309};\\\", \\\"{x:1069,y:869,t:1528139707326};\\\", \\\"{x:1060,y:867,t:1528139707342};\\\", \\\"{x:1059,y:867,t:1528139707358};\\\", \\\"{x:1059,y:869,t:1528139707395};\\\", \\\"{x:1057,y:873,t:1528139707409};\\\", \\\"{x:1052,y:885,t:1528139707426};\\\", \\\"{x:1045,y:900,t:1528139707442};\\\", \\\"{x:1039,y:925,t:1528139707458};\\\", \\\"{x:1038,y:943,t:1528139707475};\\\", \\\"{x:1039,y:964,t:1528139707491};\\\", \\\"{x:1049,y:979,t:1528139707508};\\\", \\\"{x:1059,y:988,t:1528139707526};\\\", \\\"{x:1072,y:993,t:1528139707542};\\\", \\\"{x:1085,y:996,t:1528139707558};\\\", \\\"{x:1098,y:998,t:1528139707576};\\\", \\\"{x:1107,y:998,t:1528139707593};\\\", \\\"{x:1109,y:998,t:1528139707609};\\\", \\\"{x:1114,y:997,t:1528139707625};\\\", \\\"{x:1120,y:991,t:1528139707643};\\\", \\\"{x:1126,y:987,t:1528139707659};\\\", \\\"{x:1130,y:984,t:1528139707675};\\\", \\\"{x:1136,y:980,t:1528139707692};\\\", \\\"{x:1141,y:976,t:1528139707708};\\\", \\\"{x:1143,y:975,t:1528139707725};\\\", \\\"{x:1147,y:973,t:1528139707742};\\\", \\\"{x:1153,y:972,t:1528139707758};\\\", \\\"{x:1165,y:971,t:1528139707775};\\\", \\\"{x:1177,y:971,t:1528139707793};\\\", \\\"{x:1190,y:971,t:1528139707808};\\\", \\\"{x:1199,y:971,t:1528139707825};\\\", \\\"{x:1203,y:971,t:1528139707843};\\\", \\\"{x:1205,y:971,t:1528139707858};\\\", \\\"{x:1206,y:971,t:1528139707876};\\\", \\\"{x:1207,y:971,t:1528139707955};\\\", \\\"{x:1208,y:971,t:1528139707963};\\\", \\\"{x:1210,y:971,t:1528139707979};\\\", \\\"{x:1211,y:971,t:1528139707993};\\\", \\\"{x:1213,y:971,t:1528139708010};\\\", \\\"{x:1214,y:971,t:1528139708035};\\\", \\\"{x:1214,y:972,t:1528139708363};\\\", \\\"{x:1213,y:972,t:1528139708376};\\\", \\\"{x:1212,y:973,t:1528139708394};\\\", \\\"{x:1211,y:973,t:1528139708427};\\\", \\\"{x:1211,y:974,t:1528139708459};\\\", \\\"{x:1212,y:974,t:1528139708643};\\\", \\\"{x:1215,y:974,t:1528139708659};\\\", \\\"{x:1220,y:971,t:1528139708677};\\\", \\\"{x:1223,y:971,t:1528139708693};\\\", \\\"{x:1225,y:970,t:1528139708709};\\\", \\\"{x:1227,y:968,t:1528139708728};\\\", \\\"{x:1226,y:968,t:1528139708875};\\\", \\\"{x:1225,y:968,t:1528139708883};\\\", \\\"{x:1223,y:968,t:1528139708894};\\\", \\\"{x:1220,y:968,t:1528139708910};\\\", \\\"{x:1219,y:968,t:1528139708927};\\\", \\\"{x:1219,y:967,t:1528139709179};\\\", \\\"{x:1219,y:966,t:1528139709195};\\\", \\\"{x:1219,y:964,t:1528139709467};\\\", \\\"{x:1219,y:963,t:1528139709490};\\\", \\\"{x:1219,y:962,t:1528139709499};\\\", \\\"{x:1219,y:961,t:1528139709523};\\\", \\\"{x:1219,y:959,t:1528139709531};\\\", \\\"{x:1216,y:957,t:1528139709547};\\\", \\\"{x:1216,y:956,t:1528139709561};\\\", \\\"{x:1216,y:955,t:1528139709577};\\\", \\\"{x:1214,y:955,t:1528139709947};\\\", \\\"{x:1212,y:955,t:1528139709961};\\\", \\\"{x:1209,y:955,t:1528139709978};\\\", \\\"{x:1202,y:956,t:1528139709994};\\\", \\\"{x:1197,y:958,t:1528139710011};\\\", \\\"{x:1197,y:959,t:1528139710027};\\\", \\\"{x:1196,y:959,t:1528139710196};\\\", \\\"{x:1195,y:959,t:1528139710210};\\\", \\\"{x:1194,y:958,t:1528139710228};\\\", \\\"{x:1192,y:958,t:1528139710245};\\\", \\\"{x:1191,y:956,t:1528139710261};\\\", \\\"{x:1189,y:955,t:1528139710283};\\\", \\\"{x:1185,y:953,t:1528139710295};\\\", \\\"{x:1178,y:948,t:1528139710311};\\\", \\\"{x:1174,y:947,t:1528139710328};\\\", \\\"{x:1169,y:945,t:1528139710345};\\\", \\\"{x:1165,y:943,t:1528139710361};\\\", \\\"{x:1162,y:942,t:1528139710378};\\\", \\\"{x:1161,y:942,t:1528139710395};\\\", \\\"{x:1160,y:942,t:1528139710412};\\\", \\\"{x:1159,y:942,t:1528139710428};\\\", \\\"{x:1158,y:942,t:1528139710445};\\\", \\\"{x:1157,y:942,t:1528139710462};\\\", \\\"{x:1155,y:942,t:1528139710478};\\\", \\\"{x:1154,y:943,t:1528139710495};\\\", \\\"{x:1153,y:947,t:1528139710512};\\\", \\\"{x:1152,y:949,t:1528139710528};\\\", \\\"{x:1152,y:951,t:1528139710545};\\\", \\\"{x:1152,y:953,t:1528139710562};\\\", \\\"{x:1152,y:954,t:1528139710578};\\\", \\\"{x:1152,y:955,t:1528139710907};\\\", \\\"{x:1153,y:955,t:1528139710923};\\\", \\\"{x:1154,y:953,t:1528139710930};\\\", \\\"{x:1156,y:950,t:1528139710945};\\\", \\\"{x:1161,y:941,t:1528139710962};\\\", \\\"{x:1174,y:914,t:1528139710978};\\\", \\\"{x:1189,y:891,t:1528139710995};\\\", \\\"{x:1213,y:855,t:1528139711012};\\\", \\\"{x:1247,y:800,t:1528139711029};\\\", \\\"{x:1289,y:724,t:1528139711045};\\\", \\\"{x:1312,y:683,t:1528139711062};\\\", \\\"{x:1321,y:662,t:1528139711079};\\\", \\\"{x:1325,y:642,t:1528139711095};\\\", \\\"{x:1325,y:635,t:1528139711112};\\\", \\\"{x:1325,y:634,t:1528139711129};\\\", \\\"{x:1325,y:633,t:1528139711179};\\\", \\\"{x:1319,y:633,t:1528139711195};\\\", \\\"{x:1318,y:631,t:1528139711213};\\\", \\\"{x:1317,y:630,t:1528139711229};\\\", \\\"{x:1315,y:629,t:1528139711246};\\\", \\\"{x:1313,y:628,t:1528139711262};\\\", \\\"{x:1312,y:625,t:1528139711279};\\\", \\\"{x:1310,y:620,t:1528139711295};\\\", \\\"{x:1310,y:610,t:1528139711312};\\\", \\\"{x:1316,y:593,t:1528139711329};\\\", \\\"{x:1334,y:566,t:1528139711346};\\\", \\\"{x:1365,y:526,t:1528139711362};\\\", \\\"{x:1416,y:473,t:1528139711378};\\\", \\\"{x:1447,y:443,t:1528139711395};\\\", \\\"{x:1470,y:416,t:1528139711411};\\\", \\\"{x:1482,y:401,t:1528139711428};\\\", \\\"{x:1483,y:400,t:1528139711445};\\\", \\\"{x:1477,y:407,t:1528139711619};\\\", \\\"{x:1469,y:414,t:1528139711629};\\\", \\\"{x:1456,y:431,t:1528139711645};\\\", \\\"{x:1447,y:442,t:1528139711662};\\\", \\\"{x:1440,y:452,t:1528139711679};\\\", \\\"{x:1434,y:459,t:1528139711695};\\\", \\\"{x:1426,y:470,t:1528139711713};\\\", \\\"{x:1417,y:484,t:1528139711728};\\\", \\\"{x:1406,y:498,t:1528139711746};\\\", \\\"{x:1390,y:521,t:1528139711761};\\\", \\\"{x:1378,y:539,t:1528139711779};\\\", \\\"{x:1367,y:554,t:1528139711795};\\\", \\\"{x:1355,y:572,t:1528139711813};\\\", \\\"{x:1340,y:591,t:1528139711829};\\\", \\\"{x:1325,y:610,t:1528139711845};\\\", \\\"{x:1312,y:630,t:1528139711863};\\\", \\\"{x:1297,y:647,t:1528139711879};\\\", \\\"{x:1286,y:662,t:1528139711895};\\\", \\\"{x:1276,y:677,t:1528139711913};\\\", \\\"{x:1267,y:691,t:1528139711928};\\\", \\\"{x:1258,y:704,t:1528139711946};\\\", \\\"{x:1254,y:718,t:1528139711962};\\\", \\\"{x:1252,y:723,t:1528139711980};\\\", \\\"{x:1251,y:727,t:1528139711996};\\\", \\\"{x:1251,y:730,t:1528139712013};\\\", \\\"{x:1249,y:733,t:1528139712029};\\\", \\\"{x:1248,y:737,t:1528139712046};\\\", \\\"{x:1246,y:745,t:1528139712063};\\\", \\\"{x:1244,y:751,t:1528139712080};\\\", \\\"{x:1243,y:758,t:1528139712096};\\\", \\\"{x:1240,y:765,t:1528139712113};\\\", \\\"{x:1238,y:771,t:1528139712129};\\\", \\\"{x:1237,y:776,t:1528139712146};\\\", \\\"{x:1235,y:786,t:1528139712163};\\\", \\\"{x:1232,y:794,t:1528139712180};\\\", \\\"{x:1230,y:801,t:1528139712196};\\\", \\\"{x:1228,y:808,t:1528139712213};\\\", \\\"{x:1226,y:813,t:1528139712230};\\\", \\\"{x:1225,y:815,t:1528139712245};\\\", \\\"{x:1224,y:817,t:1528139712263};\\\", \\\"{x:1222,y:821,t:1528139712279};\\\", \\\"{x:1220,y:826,t:1528139712296};\\\", \\\"{x:1217,y:832,t:1528139712312};\\\", \\\"{x:1214,y:836,t:1528139712330};\\\", \\\"{x:1213,y:842,t:1528139712346};\\\", \\\"{x:1209,y:849,t:1528139712362};\\\", \\\"{x:1207,y:854,t:1528139712380};\\\", \\\"{x:1205,y:857,t:1528139712396};\\\", \\\"{x:1203,y:860,t:1528139712413};\\\", \\\"{x:1199,y:866,t:1528139712429};\\\", \\\"{x:1195,y:872,t:1528139712446};\\\", \\\"{x:1190,y:882,t:1528139712463};\\\", \\\"{x:1186,y:890,t:1528139712480};\\\", \\\"{x:1179,y:902,t:1528139712497};\\\", \\\"{x:1169,y:917,t:1528139712513};\\\", \\\"{x:1159,y:932,t:1528139712530};\\\", \\\"{x:1146,y:952,t:1528139712547};\\\", \\\"{x:1138,y:963,t:1528139712562};\\\", \\\"{x:1128,y:975,t:1528139712580};\\\", \\\"{x:1122,y:984,t:1528139712597};\\\", \\\"{x:1116,y:992,t:1528139712612};\\\", \\\"{x:1110,y:1004,t:1528139712629};\\\", \\\"{x:1107,y:1008,t:1528139712646};\\\", \\\"{x:1105,y:1011,t:1528139712662};\\\", \\\"{x:1105,y:1012,t:1528139712680};\\\", \\\"{x:1105,y:1013,t:1528139712698};\\\", \\\"{x:1106,y:1013,t:1528139712867};\\\", \\\"{x:1113,y:1013,t:1528139712879};\\\", \\\"{x:1133,y:1008,t:1528139712896};\\\", \\\"{x:1158,y:1003,t:1528139712913};\\\", \\\"{x:1173,y:998,t:1528139712929};\\\", \\\"{x:1188,y:993,t:1528139712946};\\\", \\\"{x:1190,y:993,t:1528139712963};\\\", \\\"{x:1191,y:993,t:1528139712980};\\\", \\\"{x:1191,y:992,t:1528139713018};\\\", \\\"{x:1192,y:992,t:1528139713029};\\\", \\\"{x:1195,y:987,t:1528139713046};\\\", \\\"{x:1198,y:985,t:1528139713064};\\\", \\\"{x:1202,y:983,t:1528139713079};\\\", \\\"{x:1203,y:981,t:1528139713096};\\\", \\\"{x:1204,y:980,t:1528139713113};\\\", \\\"{x:1205,y:978,t:1528139713130};\\\", \\\"{x:1207,y:976,t:1528139713146};\\\", \\\"{x:1208,y:974,t:1528139713163};\\\", \\\"{x:1211,y:970,t:1528139713179};\\\", \\\"{x:1213,y:968,t:1528139713197};\\\", \\\"{x:1214,y:966,t:1528139713214};\\\", \\\"{x:1214,y:964,t:1528139713229};\\\", \\\"{x:1215,y:963,t:1528139713291};\\\", \\\"{x:1215,y:964,t:1528139713499};\\\", \\\"{x:1215,y:966,t:1528139713514};\\\", \\\"{x:1216,y:969,t:1528139713531};\\\", \\\"{x:1216,y:970,t:1528139713547};\\\", \\\"{x:1217,y:971,t:1528139713564};\\\", \\\"{x:1217,y:972,t:1528139713581};\\\", \\\"{x:1218,y:973,t:1528139713597};\\\", \\\"{x:1219,y:973,t:1528139713614};\\\", \\\"{x:1220,y:974,t:1528139713631};\\\", \\\"{x:1221,y:975,t:1528139713647};\\\", \\\"{x:1224,y:977,t:1528139713664};\\\", \\\"{x:1228,y:978,t:1528139713681};\\\", \\\"{x:1237,y:985,t:1528139713698};\\\", \\\"{x:1242,y:988,t:1528139713714};\\\", \\\"{x:1252,y:996,t:1528139713731};\\\", \\\"{x:1257,y:1000,t:1528139713748};\\\", \\\"{x:1259,y:1002,t:1528139713764};\\\", \\\"{x:1261,y:1002,t:1528139713851};\\\", \\\"{x:1263,y:1002,t:1528139713864};\\\", \\\"{x:1265,y:1002,t:1528139713881};\\\", \\\"{x:1270,y:1002,t:1528139713898};\\\", \\\"{x:1274,y:1002,t:1528139713914};\\\", \\\"{x:1286,y:1002,t:1528139713930};\\\", \\\"{x:1294,y:1001,t:1528139713948};\\\", \\\"{x:1301,y:1000,t:1528139713964};\\\", \\\"{x:1305,y:998,t:1528139713981};\\\", \\\"{x:1309,y:996,t:1528139713997};\\\", \\\"{x:1311,y:994,t:1528139714013};\\\", \\\"{x:1314,y:992,t:1528139714031};\\\", \\\"{x:1315,y:991,t:1528139714047};\\\", \\\"{x:1315,y:988,t:1528139714065};\\\", \\\"{x:1315,y:987,t:1528139714080};\\\", \\\"{x:1316,y:985,t:1528139714098};\\\", \\\"{x:1316,y:981,t:1528139714114};\\\", \\\"{x:1316,y:978,t:1528139714130};\\\", \\\"{x:1316,y:974,t:1528139714147};\\\", \\\"{x:1316,y:973,t:1528139714164};\\\", \\\"{x:1315,y:970,t:1528139714181};\\\", \\\"{x:1314,y:969,t:1528139714202};\\\", \\\"{x:1313,y:968,t:1528139714214};\\\", \\\"{x:1311,y:966,t:1528139714231};\\\", \\\"{x:1304,y:966,t:1528139714248};\\\", \\\"{x:1303,y:966,t:1528139714275};\\\", \\\"{x:1302,y:966,t:1528139714291};\\\", \\\"{x:1301,y:966,t:1528139714314};\\\", \\\"{x:1300,y:966,t:1528139714395};\\\", \\\"{x:1299,y:966,t:1528139714467};\\\", \\\"{x:1297,y:967,t:1528139714491};\\\", \\\"{x:1295,y:968,t:1528139714506};\\\", \\\"{x:1294,y:969,t:1528139714523};\\\", \\\"{x:1293,y:972,t:1528139714531};\\\", \\\"{x:1293,y:973,t:1528139714548};\\\", \\\"{x:1293,y:974,t:1528139714565};\\\", \\\"{x:1293,y:975,t:1528139714582};\\\", \\\"{x:1292,y:975,t:1528139714598};\\\", \\\"{x:1292,y:976,t:1528139714615};\\\", \\\"{x:1292,y:977,t:1528139714651};\\\", \\\"{x:1292,y:978,t:1528139714690};\\\", \\\"{x:1292,y:979,t:1528139714698};\\\", \\\"{x:1293,y:979,t:1528139714714};\\\", \\\"{x:1293,y:980,t:1528139714732};\\\", \\\"{x:1295,y:980,t:1528139714748};\\\", \\\"{x:1298,y:981,t:1528139714765};\\\", \\\"{x:1305,y:981,t:1528139714782};\\\", \\\"{x:1312,y:983,t:1528139714798};\\\", \\\"{x:1318,y:984,t:1528139714816};\\\", \\\"{x:1323,y:984,t:1528139714832};\\\", \\\"{x:1326,y:984,t:1528139714849};\\\", \\\"{x:1328,y:985,t:1528139714865};\\\", \\\"{x:1329,y:985,t:1528139714882};\\\", \\\"{x:1330,y:985,t:1528139714915};\\\", \\\"{x:1331,y:985,t:1528139714932};\\\", \\\"{x:1332,y:985,t:1528139714960};\\\", \\\"{x:1333,y:985,t:1528139714981};\\\", \\\"{x:1335,y:984,t:1528139715005};\\\", \\\"{x:1336,y:982,t:1528139715021};\\\", \\\"{x:1337,y:980,t:1528139715037};\\\", \\\"{x:1338,y:979,t:1528139715053};\\\", \\\"{x:1339,y:978,t:1528139715061};\\\", \\\"{x:1339,y:977,t:1528139715075};\\\", \\\"{x:1339,y:975,t:1528139715092};\\\", \\\"{x:1339,y:974,t:1528139715109};\\\", \\\"{x:1340,y:973,t:1528139715294};\\\", \\\"{x:1341,y:973,t:1528139715317};\\\", \\\"{x:1342,y:973,t:1528139715533};\\\", \\\"{x:1344,y:973,t:1528139715557};\\\", \\\"{x:1345,y:973,t:1528139715573};\\\", \\\"{x:1346,y:974,t:1528139715581};\\\", \\\"{x:1347,y:975,t:1528139715593};\\\", \\\"{x:1348,y:976,t:1528139715610};\\\", \\\"{x:1351,y:978,t:1528139715627};\\\", \\\"{x:1355,y:980,t:1528139715642};\\\", \\\"{x:1358,y:982,t:1528139715659};\\\", \\\"{x:1364,y:986,t:1528139715677};\\\", \\\"{x:1375,y:990,t:1528139715693};\\\", \\\"{x:1382,y:994,t:1528139715710};\\\", \\\"{x:1388,y:996,t:1528139715727};\\\", \\\"{x:1391,y:998,t:1528139715743};\\\", \\\"{x:1394,y:999,t:1528139715759};\\\", \\\"{x:1397,y:1000,t:1528139715776};\\\", \\\"{x:1403,y:1002,t:1528139715793};\\\", \\\"{x:1408,y:1002,t:1528139715809};\\\", \\\"{x:1413,y:1005,t:1528139715826};\\\", \\\"{x:1414,y:1005,t:1528139715844};\\\", \\\"{x:1415,y:1005,t:1528139715860};\\\", \\\"{x:1416,y:1005,t:1528139715877};\\\", \\\"{x:1417,y:1005,t:1528139715909};\\\", \\\"{x:1418,y:1005,t:1528139715957};\\\", \\\"{x:1420,y:1005,t:1528139715990};\\\", \\\"{x:1420,y:1004,t:1528139716005};\\\", \\\"{x:1421,y:1004,t:1528139716029};\\\", \\\"{x:1422,y:1003,t:1528139716044};\\\", \\\"{x:1422,y:1002,t:1528139716061};\\\", \\\"{x:1422,y:1001,t:1528139716076};\\\", \\\"{x:1422,y:1000,t:1528139716094};\\\", \\\"{x:1423,y:998,t:1528139716110};\\\", \\\"{x:1423,y:997,t:1528139716158};\\\", \\\"{x:1423,y:996,t:1528139716165};\\\", \\\"{x:1423,y:995,t:1528139716177};\\\", \\\"{x:1423,y:994,t:1528139716194};\\\", \\\"{x:1423,y:993,t:1528139716210};\\\", \\\"{x:1424,y:992,t:1528139716227};\\\", \\\"{x:1424,y:990,t:1528139716243};\\\", \\\"{x:1425,y:988,t:1528139716260};\\\", \\\"{x:1425,y:987,t:1528139716276};\\\", \\\"{x:1425,y:986,t:1528139716293};\\\", \\\"{x:1426,y:986,t:1528139716333};\\\", \\\"{x:1428,y:986,t:1528139717006};\\\", \\\"{x:1429,y:986,t:1528139717021};\\\", \\\"{x:1430,y:986,t:1528139717045};\\\", \\\"{x:1431,y:986,t:1528139717061};\\\", \\\"{x:1433,y:987,t:1528139717077};\\\", \\\"{x:1436,y:987,t:1528139717095};\\\", \\\"{x:1443,y:989,t:1528139717110};\\\", \\\"{x:1452,y:989,t:1528139717128};\\\", \\\"{x:1462,y:989,t:1528139717144};\\\", \\\"{x:1469,y:989,t:1528139717160};\\\", \\\"{x:1472,y:989,t:1528139717178};\\\", \\\"{x:1473,y:989,t:1528139717194};\\\", \\\"{x:1474,y:989,t:1528139717270};\\\", \\\"{x:1475,y:989,t:1528139717277};\\\", \\\"{x:1477,y:988,t:1528139717294};\\\", \\\"{x:1478,y:988,t:1528139717311};\\\", \\\"{x:1480,y:988,t:1528139717328};\\\", \\\"{x:1481,y:987,t:1528139717344};\\\", \\\"{x:1482,y:986,t:1528139717361};\\\", \\\"{x:1483,y:985,t:1528139717377};\\\", \\\"{x:1484,y:985,t:1528139717394};\\\", \\\"{x:1485,y:984,t:1528139717412};\\\", \\\"{x:1486,y:983,t:1528139717557};\\\", \\\"{x:1487,y:983,t:1528139717781};\\\", \\\"{x:1488,y:983,t:1528139718006};\\\", \\\"{x:1489,y:983,t:1528139718045};\\\", \\\"{x:1491,y:983,t:1528139718061};\\\", \\\"{x:1493,y:983,t:1528139718079};\\\", \\\"{x:1495,y:983,t:1528139718094};\\\", \\\"{x:1497,y:984,t:1528139718111};\\\", \\\"{x:1498,y:985,t:1528139718129};\\\", \\\"{x:1503,y:986,t:1528139718146};\\\", \\\"{x:1506,y:988,t:1528139718162};\\\", \\\"{x:1511,y:988,t:1528139718178};\\\", \\\"{x:1514,y:990,t:1528139718195};\\\", \\\"{x:1516,y:991,t:1528139718212};\\\", \\\"{x:1517,y:991,t:1528139718229};\\\", \\\"{x:1518,y:991,t:1528139718253};\\\", \\\"{x:1519,y:991,t:1528139718261};\\\", \\\"{x:1520,y:991,t:1528139718279};\\\", \\\"{x:1522,y:991,t:1528139718295};\\\", \\\"{x:1523,y:991,t:1528139718312};\\\", \\\"{x:1525,y:991,t:1528139718329};\\\", \\\"{x:1526,y:991,t:1528139718345};\\\", \\\"{x:1527,y:991,t:1528139718362};\\\", \\\"{x:1528,y:991,t:1528139718379};\\\", \\\"{x:1530,y:991,t:1528139718397};\\\", \\\"{x:1531,y:990,t:1528139718429};\\\", \\\"{x:1533,y:989,t:1528139718453};\\\", \\\"{x:1534,y:989,t:1528139718477};\\\", \\\"{x:1534,y:988,t:1528139718485};\\\", \\\"{x:1535,y:987,t:1528139718517};\\\", \\\"{x:1536,y:987,t:1528139718533};\\\", \\\"{x:1536,y:986,t:1528139718546};\\\", \\\"{x:1537,y:984,t:1528139718562};\\\", \\\"{x:1539,y:983,t:1528139718578};\\\", \\\"{x:1540,y:983,t:1528139718595};\\\", \\\"{x:1540,y:982,t:1528139718620};\\\", \\\"{x:1540,y:981,t:1528139718628};\\\", \\\"{x:1541,y:980,t:1528139718645};\\\", \\\"{x:1541,y:979,t:1528139718662};\\\", \\\"{x:1542,y:978,t:1528139719013};\\\", \\\"{x:1544,y:975,t:1528139719029};\\\", \\\"{x:1544,y:974,t:1528139719046};\\\", \\\"{x:1545,y:972,t:1528139719063};\\\", \\\"{x:1546,y:970,t:1528139719080};\\\", \\\"{x:1546,y:969,t:1528139719096};\\\", \\\"{x:1547,y:968,t:1528139719117};\\\", \\\"{x:1547,y:967,t:1528139719132};\\\", \\\"{x:1547,y:966,t:1528139719181};\\\", \\\"{x:1546,y:966,t:1528139719757};\\\", \\\"{x:1545,y:966,t:1528139719765};\\\", \\\"{x:1543,y:966,t:1528139719780};\\\", \\\"{x:1536,y:966,t:1528139719796};\\\", \\\"{x:1531,y:966,t:1528139719813};\\\", \\\"{x:1525,y:966,t:1528139719830};\\\", \\\"{x:1520,y:966,t:1528139719847};\\\", \\\"{x:1516,y:966,t:1528139719863};\\\", \\\"{x:1510,y:966,t:1528139719880};\\\", \\\"{x:1505,y:966,t:1528139719896};\\\", \\\"{x:1499,y:966,t:1528139719913};\\\", \\\"{x:1494,y:966,t:1528139719930};\\\", \\\"{x:1490,y:966,t:1528139719947};\\\", \\\"{x:1486,y:966,t:1528139719963};\\\", \\\"{x:1481,y:966,t:1528139719979};\\\", \\\"{x:1472,y:966,t:1528139719997};\\\", \\\"{x:1464,y:966,t:1528139720013};\\\", \\\"{x:1450,y:967,t:1528139720030};\\\", \\\"{x:1431,y:967,t:1528139720047};\\\", \\\"{x:1417,y:967,t:1528139720063};\\\", \\\"{x:1403,y:967,t:1528139720080};\\\", \\\"{x:1392,y:967,t:1528139720097};\\\", \\\"{x:1381,y:968,t:1528139720114};\\\", \\\"{x:1375,y:968,t:1528139720130};\\\", \\\"{x:1371,y:969,t:1528139720146};\\\", \\\"{x:1370,y:969,t:1528139720163};\\\", \\\"{x:1369,y:969,t:1528139720181};\\\", \\\"{x:1369,y:970,t:1528139720301};\\\", \\\"{x:1365,y:971,t:1528139720405};\\\", \\\"{x:1362,y:973,t:1528139720413};\\\", \\\"{x:1357,y:975,t:1528139720431};\\\", \\\"{x:1354,y:976,t:1528139720447};\\\", \\\"{x:1352,y:977,t:1528139720464};\\\", \\\"{x:1351,y:978,t:1528139720484};\\\", \\\"{x:1354,y:976,t:1528139720797};\\\", \\\"{x:1358,y:972,t:1528139720814};\\\", \\\"{x:1361,y:970,t:1528139720831};\\\", \\\"{x:1362,y:969,t:1528139720893};\\\", \\\"{x:1362,y:968,t:1528139720909};\\\", \\\"{x:1362,y:966,t:1528139720917};\\\", \\\"{x:1362,y:963,t:1528139720931};\\\", \\\"{x:1363,y:957,t:1528139720948};\\\", \\\"{x:1363,y:943,t:1528139720965};\\\", \\\"{x:1363,y:933,t:1528139720981};\\\", \\\"{x:1363,y:917,t:1528139720998};\\\", \\\"{x:1363,y:904,t:1528139721015};\\\", \\\"{x:1363,y:898,t:1528139721031};\\\", \\\"{x:1363,y:894,t:1528139721047};\\\", \\\"{x:1363,y:892,t:1528139721064};\\\", \\\"{x:1365,y:889,t:1528139721082};\\\", \\\"{x:1369,y:883,t:1528139721098};\\\", \\\"{x:1369,y:880,t:1528139721115};\\\", \\\"{x:1371,y:877,t:1528139721132};\\\", \\\"{x:1371,y:873,t:1528139721148};\\\", \\\"{x:1372,y:869,t:1528139721165};\\\", \\\"{x:1373,y:866,t:1528139721181};\\\", \\\"{x:1374,y:863,t:1528139721198};\\\", \\\"{x:1375,y:857,t:1528139721214};\\\", \\\"{x:1378,y:852,t:1528139721231};\\\", \\\"{x:1378,y:849,t:1528139721248};\\\", \\\"{x:1378,y:844,t:1528139721265};\\\", \\\"{x:1378,y:841,t:1528139721282};\\\", \\\"{x:1381,y:833,t:1528139721298};\\\", \\\"{x:1382,y:827,t:1528139721315};\\\", \\\"{x:1382,y:825,t:1528139721331};\\\", \\\"{x:1382,y:824,t:1528139721347};\\\", \\\"{x:1382,y:823,t:1528139721365};\\\", \\\"{x:1382,y:822,t:1528139721389};\\\", \\\"{x:1382,y:821,t:1528139721421};\\\", \\\"{x:1382,y:817,t:1528139721758};\\\", \\\"{x:1377,y:807,t:1528139721765};\\\", \\\"{x:1361,y:785,t:1528139721782};\\\", \\\"{x:1344,y:763,t:1528139721799};\\\", \\\"{x:1325,y:739,t:1528139721816};\\\", \\\"{x:1305,y:716,t:1528139721831};\\\", \\\"{x:1290,y:700,t:1528139721848};\\\", \\\"{x:1281,y:685,t:1528139721865};\\\", \\\"{x:1278,y:681,t:1528139721883};\\\", \\\"{x:1276,y:679,t:1528139721899};\\\", \\\"{x:1274,y:674,t:1528139721914};\\\", \\\"{x:1272,y:668,t:1528139721931};\\\", \\\"{x:1272,y:667,t:1528139721949};\\\", \\\"{x:1272,y:666,t:1528139721965};\\\", \\\"{x:1272,y:665,t:1528139721997};\\\", \\\"{x:1272,y:664,t:1528139722021};\\\", \\\"{x:1272,y:663,t:1528139722094};\\\", \\\"{x:1265,y:668,t:1528139722125};\\\", \\\"{x:1252,y:684,t:1528139722133};\\\", \\\"{x:1226,y:712,t:1528139722149};\\\", \\\"{x:1198,y:749,t:1528139722165};\\\", \\\"{x:1179,y:782,t:1528139722182};\\\", \\\"{x:1164,y:813,t:1528139722199};\\\", \\\"{x:1148,y:846,t:1528139722215};\\\", \\\"{x:1135,y:875,t:1528139722231};\\\", \\\"{x:1125,y:907,t:1528139722249};\\\", \\\"{x:1120,y:931,t:1528139722265};\\\", \\\"{x:1117,y:951,t:1528139722283};\\\", \\\"{x:1117,y:966,t:1528139722299};\\\", \\\"{x:1118,y:975,t:1528139722315};\\\", \\\"{x:1121,y:984,t:1528139722331};\\\", \\\"{x:1122,y:990,t:1528139722349};\\\", \\\"{x:1122,y:993,t:1528139722365};\\\", \\\"{x:1122,y:997,t:1528139722382};\\\", \\\"{x:1122,y:1001,t:1528139722398};\\\", \\\"{x:1121,y:1006,t:1528139722416};\\\", \\\"{x:1120,y:1009,t:1528139722431};\\\", \\\"{x:1120,y:1013,t:1528139722448};\\\", \\\"{x:1120,y:1015,t:1528139722466};\\\", \\\"{x:1120,y:1018,t:1528139722483};\\\", \\\"{x:1120,y:1020,t:1528139722499};\\\", \\\"{x:1120,y:1021,t:1528139722516};\\\", \\\"{x:1122,y:1021,t:1528139722566};\\\", \\\"{x:1128,y:1016,t:1528139722583};\\\", \\\"{x:1133,y:1010,t:1528139722599};\\\", \\\"{x:1138,y:1005,t:1528139722616};\\\", \\\"{x:1139,y:1003,t:1528139722633};\\\", \\\"{x:1141,y:1001,t:1528139722649};\\\", \\\"{x:1141,y:1000,t:1528139722666};\\\", \\\"{x:1141,y:998,t:1528139722683};\\\", \\\"{x:1141,y:995,t:1528139722698};\\\", \\\"{x:1142,y:993,t:1528139722715};\\\", \\\"{x:1142,y:988,t:1528139722732};\\\", \\\"{x:1144,y:985,t:1528139722748};\\\", \\\"{x:1144,y:984,t:1528139722765};\\\", \\\"{x:1144,y:982,t:1528139722782};\\\", \\\"{x:1144,y:981,t:1528139722798};\\\", \\\"{x:1144,y:979,t:1528139722815};\\\", \\\"{x:1145,y:979,t:1528139722836};\\\", \\\"{x:1145,y:978,t:1528139722917};\\\", \\\"{x:1145,y:977,t:1528139723525};\\\", \\\"{x:1147,y:978,t:1528139723533};\\\", \\\"{x:1150,y:979,t:1528139723550};\\\", \\\"{x:1156,y:980,t:1528139723566};\\\", \\\"{x:1166,y:980,t:1528139723582};\\\", \\\"{x:1170,y:980,t:1528139723600};\\\", \\\"{x:1175,y:980,t:1528139723617};\\\", \\\"{x:1179,y:980,t:1528139723633};\\\", \\\"{x:1182,y:980,t:1528139723650};\\\", \\\"{x:1184,y:980,t:1528139723667};\\\", \\\"{x:1187,y:979,t:1528139723683};\\\", \\\"{x:1190,y:978,t:1528139723699};\\\", \\\"{x:1196,y:974,t:1528139723716};\\\", \\\"{x:1202,y:973,t:1528139723732};\\\", \\\"{x:1204,y:971,t:1528139723749};\\\", \\\"{x:1205,y:969,t:1528139723766};\\\", \\\"{x:1208,y:967,t:1528139723783};\\\", \\\"{x:1210,y:966,t:1528139723799};\\\", \\\"{x:1210,y:965,t:1528139723845};\\\", \\\"{x:1211,y:964,t:1528139723884};\\\", \\\"{x:1212,y:964,t:1528139723901};\\\", \\\"{x:1213,y:963,t:1528139723917};\\\", \\\"{x:1214,y:962,t:1528139724276};\\\", \\\"{x:1215,y:962,t:1528139724285};\\\", \\\"{x:1216,y:962,t:1528139724300};\\\", \\\"{x:1220,y:963,t:1528139724316};\\\", \\\"{x:1228,y:966,t:1528139724333};\\\", \\\"{x:1238,y:970,t:1528139724350};\\\", \\\"{x:1251,y:975,t:1528139724366};\\\", \\\"{x:1261,y:976,t:1528139724383};\\\", \\\"{x:1269,y:977,t:1528139724401};\\\", \\\"{x:1273,y:977,t:1528139724416};\\\", \\\"{x:1275,y:979,t:1528139724434};\\\", \\\"{x:1276,y:979,t:1528139724450};\\\", \\\"{x:1277,y:979,t:1528139724485};\\\", \\\"{x:1278,y:979,t:1528139724509};\\\", \\\"{x:1279,y:979,t:1528139724517};\\\", \\\"{x:1283,y:978,t:1528139724534};\\\", \\\"{x:1285,y:978,t:1528139724551};\\\", \\\"{x:1287,y:976,t:1528139724567};\\\", \\\"{x:1292,y:973,t:1528139724583};\\\", \\\"{x:1295,y:971,t:1528139724600};\\\", \\\"{x:1297,y:969,t:1528139724616};\\\", \\\"{x:1295,y:969,t:1528139724757};\\\", \\\"{x:1294,y:968,t:1528139724768};\\\", \\\"{x:1293,y:968,t:1528139725134};\\\", \\\"{x:1294,y:968,t:1528139725149};\\\", \\\"{x:1294,y:969,t:1528139725157};\\\", \\\"{x:1295,y:970,t:1528139725168};\\\", \\\"{x:1296,y:970,t:1528139725184};\\\", \\\"{x:1298,y:970,t:1528139725200};\\\", \\\"{x:1299,y:970,t:1528139725221};\\\", \\\"{x:1300,y:970,t:1528139725234};\\\", \\\"{x:1300,y:971,t:1528139725250};\\\", \\\"{x:1302,y:971,t:1528139725268};\\\", \\\"{x:1306,y:971,t:1528139725285};\\\", \\\"{x:1309,y:971,t:1528139725301};\\\", \\\"{x:1312,y:971,t:1528139725317};\\\", \\\"{x:1316,y:971,t:1528139725335};\\\", \\\"{x:1320,y:972,t:1528139725351};\\\", \\\"{x:1324,y:973,t:1528139725367};\\\", \\\"{x:1327,y:974,t:1528139725385};\\\", \\\"{x:1331,y:975,t:1528139725401};\\\", \\\"{x:1332,y:975,t:1528139725418};\\\", \\\"{x:1334,y:975,t:1528139725435};\\\", \\\"{x:1336,y:976,t:1528139725450};\\\", \\\"{x:1338,y:976,t:1528139725468};\\\", \\\"{x:1341,y:976,t:1528139725485};\\\", \\\"{x:1342,y:976,t:1528139725517};\\\", \\\"{x:1344,y:976,t:1528139725573};\\\", \\\"{x:1345,y:975,t:1528139725589};\\\", \\\"{x:1346,y:975,t:1528139725601};\\\", \\\"{x:1348,y:974,t:1528139725618};\\\", \\\"{x:1348,y:973,t:1528139725635};\\\", \\\"{x:1348,y:972,t:1528139725677};\\\", \\\"{x:1350,y:972,t:1528139726445};\\\", \\\"{x:1353,y:973,t:1528139726452};\\\", \\\"{x:1355,y:976,t:1528139726469};\\\", \\\"{x:1357,y:977,t:1528139726486};\\\", \\\"{x:1362,y:980,t:1528139726502};\\\", \\\"{x:1366,y:982,t:1528139726519};\\\", \\\"{x:1369,y:985,t:1528139726536};\\\", \\\"{x:1372,y:987,t:1528139726552};\\\", \\\"{x:1375,y:988,t:1528139726569};\\\", \\\"{x:1378,y:988,t:1528139726586};\\\", \\\"{x:1383,y:988,t:1528139726602};\\\", \\\"{x:1391,y:988,t:1528139726619};\\\", \\\"{x:1397,y:988,t:1528139726636};\\\", \\\"{x:1400,y:988,t:1528139726653};\\\", \\\"{x:1401,y:988,t:1528139726669};\\\", \\\"{x:1403,y:988,t:1528139726733};\\\", \\\"{x:1406,y:988,t:1528139726749};\\\", \\\"{x:1408,y:988,t:1528139726757};\\\", \\\"{x:1411,y:986,t:1528139726768};\\\", \\\"{x:1417,y:984,t:1528139726787};\\\", \\\"{x:1422,y:982,t:1528139726802};\\\", \\\"{x:1427,y:981,t:1528139726819};\\\", \\\"{x:1429,y:981,t:1528139726835};\\\", \\\"{x:1430,y:980,t:1528139726853};\\\", \\\"{x:1431,y:980,t:1528139727412};\\\", \\\"{x:1432,y:980,t:1528139727435};\\\", \\\"{x:1436,y:981,t:1528139727452};\\\", \\\"{x:1445,y:983,t:1528139727469};\\\", \\\"{x:1455,y:985,t:1528139727486};\\\", \\\"{x:1465,y:988,t:1528139727502};\\\", \\\"{x:1478,y:989,t:1528139727519};\\\", \\\"{x:1483,y:990,t:1528139727537};\\\", \\\"{x:1490,y:990,t:1528139727552};\\\", \\\"{x:1491,y:990,t:1528139727569};\\\", \\\"{x:1492,y:990,t:1528139727661};\\\", \\\"{x:1493,y:988,t:1528139727677};\\\", \\\"{x:1493,y:987,t:1528139727692};\\\", \\\"{x:1493,y:985,t:1528139727703};\\\", \\\"{x:1492,y:982,t:1528139727720};\\\", \\\"{x:1489,y:976,t:1528139727736};\\\", \\\"{x:1488,y:972,t:1528139727752};\\\", \\\"{x:1483,y:963,t:1528139727771};\\\", \\\"{x:1478,y:950,t:1528139727787};\\\", \\\"{x:1473,y:940,t:1528139727802};\\\", \\\"{x:1471,y:937,t:1528139727820};\\\", \\\"{x:1468,y:932,t:1528139727837};\\\", \\\"{x:1467,y:930,t:1528139727853};\\\", \\\"{x:1464,y:924,t:1528139727870};\\\", \\\"{x:1461,y:919,t:1528139727887};\\\", \\\"{x:1455,y:913,t:1528139727904};\\\", \\\"{x:1450,y:908,t:1528139727920};\\\", \\\"{x:1444,y:902,t:1528139727937};\\\", \\\"{x:1438,y:892,t:1528139727954};\\\", \\\"{x:1428,y:876,t:1528139727970};\\\", \\\"{x:1415,y:855,t:1528139727987};\\\", \\\"{x:1397,y:828,t:1528139728004};\\\", \\\"{x:1383,y:807,t:1528139728020};\\\", \\\"{x:1355,y:775,t:1528139728036};\\\", \\\"{x:1340,y:756,t:1528139728053};\\\", \\\"{x:1325,y:740,t:1528139728070};\\\", \\\"{x:1312,y:725,t:1528139728087};\\\", \\\"{x:1302,y:713,t:1528139728103};\\\", \\\"{x:1296,y:704,t:1528139728120};\\\", \\\"{x:1292,y:699,t:1528139728137};\\\", \\\"{x:1284,y:685,t:1528139728153};\\\", \\\"{x:1277,y:676,t:1528139728170};\\\", \\\"{x:1273,y:672,t:1528139728186};\\\", \\\"{x:1269,y:666,t:1528139728204};\\\", \\\"{x:1265,y:656,t:1528139728220};\\\", \\\"{x:1258,y:645,t:1528139728236};\\\", \\\"{x:1255,y:641,t:1528139728254};\\\", \\\"{x:1251,y:636,t:1528139728270};\\\", \\\"{x:1247,y:631,t:1528139728286};\\\", \\\"{x:1245,y:629,t:1528139728304};\\\", \\\"{x:1245,y:628,t:1528139728321};\\\", \\\"{x:1243,y:625,t:1528139728337};\\\", \\\"{x:1240,y:623,t:1528139728354};\\\", \\\"{x:1239,y:622,t:1528139728370};\\\", \\\"{x:1237,y:621,t:1528139728387};\\\", \\\"{x:1235,y:621,t:1528139728404};\\\", \\\"{x:1217,y:621,t:1528139728421};\\\", \\\"{x:1173,y:626,t:1528139728436};\\\", \\\"{x:1104,y:635,t:1528139728454};\\\", \\\"{x:1039,y:645,t:1528139728471};\\\", \\\"{x:972,y:654,t:1528139728487};\\\", \\\"{x:883,y:671,t:1528139728504};\\\", \\\"{x:794,y:682,t:1528139728520};\\\", \\\"{x:708,y:691,t:1528139728537};\\\", \\\"{x:623,y:699,t:1528139728553};\\\", \\\"{x:544,y:704,t:1528139728571};\\\", \\\"{x:491,y:704,t:1528139728587};\\\", \\\"{x:462,y:704,t:1528139728604};\\\", \\\"{x:447,y:702,t:1528139728620};\\\", \\\"{x:437,y:700,t:1528139728636};\\\", \\\"{x:433,y:700,t:1528139728654};\\\", \\\"{x:432,y:700,t:1528139728671};\\\", \\\"{x:431,y:700,t:1528139728687};\\\", \\\"{x:427,y:700,t:1528139728704};\\\", \\\"{x:415,y:696,t:1528139728721};\\\", \\\"{x:391,y:689,t:1528139728737};\\\", \\\"{x:368,y:680,t:1528139728753};\\\", \\\"{x:350,y:671,t:1528139728770};\\\", \\\"{x:328,y:661,t:1528139728788};\\\", \\\"{x:311,y:650,t:1528139728803};\\\", \\\"{x:297,y:637,t:1528139728821};\\\", \\\"{x:295,y:631,t:1528139728837};\\\", \\\"{x:288,y:617,t:1528139728852};\\\", \\\"{x:288,y:610,t:1528139728868};\\\", \\\"{x:288,y:602,t:1528139728886};\\\", \\\"{x:290,y:591,t:1528139728903};\\\", \\\"{x:298,y:579,t:1528139728919};\\\", \\\"{x:302,y:571,t:1528139728935};\\\", \\\"{x:306,y:567,t:1528139728952};\\\", \\\"{x:313,y:561,t:1528139728970};\\\", \\\"{x:321,y:556,t:1528139728986};\\\", \\\"{x:334,y:549,t:1528139729003};\\\", \\\"{x:350,y:544,t:1528139729020};\\\", \\\"{x:365,y:541,t:1528139729036};\\\", \\\"{x:387,y:536,t:1528139729052};\\\", \\\"{x:400,y:533,t:1528139729070};\\\", \\\"{x:409,y:532,t:1528139729085};\\\", \\\"{x:414,y:531,t:1528139729102};\\\", \\\"{x:418,y:531,t:1528139729120};\\\", \\\"{x:421,y:530,t:1528139729136};\\\", \\\"{x:431,y:529,t:1528139729153};\\\", \\\"{x:454,y:527,t:1528139729170};\\\", \\\"{x:489,y:524,t:1528139729186};\\\", \\\"{x:529,y:521,t:1528139729202};\\\", \\\"{x:577,y:514,t:1528139729220};\\\", \\\"{x:636,y:514,t:1528139729235};\\\", \\\"{x:739,y:514,t:1528139729253};\\\", \\\"{x:797,y:521,t:1528139729270};\\\", \\\"{x:840,y:529,t:1528139729286};\\\", \\\"{x:853,y:532,t:1528139729302};\\\", \\\"{x:854,y:533,t:1528139729319};\\\", \\\"{x:851,y:535,t:1528139729336};\\\", \\\"{x:838,y:536,t:1528139729353};\\\", \\\"{x:818,y:536,t:1528139729370};\\\", \\\"{x:791,y:536,t:1528139729386};\\\", \\\"{x:751,y:536,t:1528139729402};\\\", \\\"{x:712,y:532,t:1528139729421};\\\", \\\"{x:681,y:527,t:1528139729436};\\\", \\\"{x:679,y:526,t:1528139729452};\\\", \\\"{x:670,y:526,t:1528139729638};\\\", \\\"{x:637,y:527,t:1528139729653};\\\", \\\"{x:600,y:533,t:1528139729671};\\\", \\\"{x:584,y:533,t:1528139729687};\\\", \\\"{x:576,y:533,t:1528139729703};\\\", \\\"{x:575,y:533,t:1528139729757};\\\", \\\"{x:575,y:531,t:1528139729772};\\\", \\\"{x:578,y:531,t:1528139729786};\\\", \\\"{x:582,y:527,t:1528139729804};\\\", \\\"{x:586,y:525,t:1528139729819};\\\", \\\"{x:591,y:523,t:1528139729837};\\\", \\\"{x:594,y:521,t:1528139729854};\\\", \\\"{x:596,y:520,t:1528139729870};\\\", \\\"{x:597,y:519,t:1528139729973};\\\", \\\"{x:598,y:518,t:1528139729986};\\\", \\\"{x:599,y:517,t:1528139730030};\\\", \\\"{x:600,y:517,t:1528139730037};\\\", \\\"{x:602,y:515,t:1528139730054};\\\", \\\"{x:603,y:514,t:1528139730069};\\\", \\\"{x:606,y:511,t:1528139730087};\\\", \\\"{x:608,y:509,t:1528139730103};\\\", \\\"{x:609,y:507,t:1528139730120};\\\", \\\"{x:610,y:507,t:1528139730140};\\\", \\\"{x:610,y:513,t:1528139730508};\\\", \\\"{x:610,y:519,t:1528139730521};\\\", \\\"{x:610,y:529,t:1528139730537};\\\", \\\"{x:610,y:547,t:1528139730554};\\\", \\\"{x:610,y:568,t:1528139730571};\\\", \\\"{x:610,y:593,t:1528139730587};\\\", \\\"{x:610,y:620,t:1528139730605};\\\", \\\"{x:610,y:678,t:1528139730621};\\\", \\\"{x:610,y:729,t:1528139730638};\\\", \\\"{x:610,y:768,t:1528139730654};\\\", \\\"{x:610,y:800,t:1528139730671};\\\", \\\"{x:613,y:817,t:1528139730687};\\\", \\\"{x:615,y:821,t:1528139730703};\\\", \\\"{x:616,y:822,t:1528139730720};\\\", \\\"{x:614,y:820,t:1528139730821};\\\", \\\"{x:606,y:815,t:1528139730837};\\\", \\\"{x:595,y:808,t:1528139730853};\\\", \\\"{x:582,y:799,t:1528139730870};\\\", \\\"{x:569,y:788,t:1528139730887};\\\", \\\"{x:562,y:782,t:1528139730903};\\\", \\\"{x:560,y:776,t:1528139730919};\\\", \\\"{x:557,y:773,t:1528139730937};\\\", \\\"{x:556,y:769,t:1528139730952};\\\", \\\"{x:552,y:764,t:1528139730970};\\\", \\\"{x:550,y:760,t:1528139730986};\\\", \\\"{x:550,y:759,t:1528139731003};\\\", \\\"{x:549,y:758,t:1528139731133};\\\", \\\"{x:548,y:757,t:1528139731149};\\\", \\\"{x:547,y:757,t:1528139731157};\\\", \\\"{x:547,y:756,t:1528139731169};\\\", \\\"{x:543,y:755,t:1528139731185};\\\", \\\"{x:539,y:753,t:1528139731203};\\\", \\\"{x:533,y:750,t:1528139731219};\\\", \\\"{x:527,y:746,t:1528139731238};\\\", \\\"{x:523,y:744,t:1528139731255};\\\" ] }, { \\\"rt\\\": 49137, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 397691, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 4, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -F -F -11 AM-12 PM-12 PM-01 PM-02 PM-Z -Z -O -03 PM-02 PM-03 PM-03 PM-04 PM-I -01 PM-02 PM-01 PM-02 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:742,t:1528139734037};\\\", \\\"{x:632,y:734,t:1528139734053};\\\", \\\"{x:935,y:720,t:1528139734069};\\\", \\\"{x:1152,y:702,t:1528139734089};\\\", \\\"{x:1362,y:672,t:1528139734107};\\\", \\\"{x:1517,y:650,t:1528139734124};\\\", \\\"{x:1665,y:630,t:1528139734140};\\\", \\\"{x:1728,y:623,t:1528139734156};\\\", \\\"{x:1779,y:623,t:1528139734174};\\\", \\\"{x:1816,y:634,t:1528139734190};\\\", \\\"{x:1842,y:650,t:1528139734207};\\\", \\\"{x:1855,y:663,t:1528139734223};\\\", \\\"{x:1855,y:669,t:1528139734240};\\\", \\\"{x:1853,y:674,t:1528139734257};\\\", \\\"{x:1848,y:675,t:1528139734274};\\\", \\\"{x:1840,y:678,t:1528139734290};\\\", \\\"{x:1825,y:682,t:1528139734307};\\\", \\\"{x:1800,y:686,t:1528139734324};\\\", \\\"{x:1732,y:688,t:1528139734340};\\\", \\\"{x:1665,y:688,t:1528139734357};\\\", \\\"{x:1590,y:688,t:1528139734374};\\\", \\\"{x:1529,y:688,t:1528139734391};\\\", \\\"{x:1479,y:688,t:1528139734407};\\\", \\\"{x:1445,y:688,t:1528139734424};\\\", \\\"{x:1424,y:689,t:1528139734441};\\\", \\\"{x:1412,y:690,t:1528139734457};\\\", \\\"{x:1410,y:690,t:1528139734474};\\\", \\\"{x:1409,y:690,t:1528139734605};\\\", \\\"{x:1410,y:684,t:1528139734613};\\\", \\\"{x:1415,y:675,t:1528139734624};\\\", \\\"{x:1428,y:662,t:1528139734641};\\\", \\\"{x:1439,y:647,t:1528139734657};\\\", \\\"{x:1445,y:628,t:1528139734675};\\\", \\\"{x:1451,y:612,t:1528139734692};\\\", \\\"{x:1451,y:607,t:1528139734707};\\\", \\\"{x:1451,y:604,t:1528139734724};\\\", \\\"{x:1451,y:602,t:1528139734741};\\\", \\\"{x:1449,y:600,t:1528139734758};\\\", \\\"{x:1439,y:595,t:1528139734774};\\\", \\\"{x:1415,y:593,t:1528139734791};\\\", \\\"{x:1383,y:593,t:1528139734808};\\\", \\\"{x:1360,y:593,t:1528139734824};\\\", \\\"{x:1341,y:593,t:1528139734841};\\\", \\\"{x:1331,y:595,t:1528139734858};\\\", \\\"{x:1327,y:596,t:1528139734874};\\\", \\\"{x:1325,y:596,t:1528139734891};\\\", \\\"{x:1331,y:596,t:1528139734974};\\\", \\\"{x:1348,y:596,t:1528139734991};\\\", \\\"{x:1363,y:596,t:1528139735009};\\\", \\\"{x:1372,y:595,t:1528139735024};\\\", \\\"{x:1376,y:594,t:1528139735041};\\\", \\\"{x:1382,y:594,t:1528139735058};\\\", \\\"{x:1386,y:594,t:1528139735074};\\\", \\\"{x:1387,y:594,t:1528139735092};\\\", \\\"{x:1389,y:594,t:1528139735109};\\\", \\\"{x:1385,y:594,t:1528139740901};\\\", \\\"{x:1354,y:598,t:1528139740913};\\\", \\\"{x:1226,y:663,t:1528139740929};\\\", \\\"{x:1177,y:690,t:1528139740947};\\\", \\\"{x:1160,y:707,t:1528139740963};\\\", \\\"{x:1147,y:723,t:1528139740980};\\\", \\\"{x:1126,y:743,t:1528139740996};\\\", \\\"{x:1113,y:754,t:1528139741013};\\\", \\\"{x:1094,y:769,t:1528139741040};\\\", \\\"{x:1089,y:774,t:1528139741046};\\\", \\\"{x:1081,y:795,t:1528139741063};\\\", \\\"{x:1076,y:824,t:1528139741079};\\\", \\\"{x:1075,y:852,t:1528139741096};\\\", \\\"{x:1075,y:869,t:1528139741112};\\\", \\\"{x:1082,y:887,t:1528139741129};\\\", \\\"{x:1086,y:902,t:1528139741146};\\\", \\\"{x:1093,y:914,t:1528139741163};\\\", \\\"{x:1097,y:921,t:1528139741178};\\\", \\\"{x:1102,y:924,t:1528139741196};\\\", \\\"{x:1104,y:925,t:1528139741213};\\\", \\\"{x:1110,y:925,t:1528139741229};\\\", \\\"{x:1117,y:925,t:1528139741246};\\\", \\\"{x:1127,y:923,t:1528139741263};\\\", \\\"{x:1134,y:919,t:1528139741280};\\\", \\\"{x:1140,y:914,t:1528139741296};\\\", \\\"{x:1151,y:906,t:1528139741313};\\\", \\\"{x:1166,y:896,t:1528139741330};\\\", \\\"{x:1182,y:887,t:1528139741346};\\\", \\\"{x:1197,y:881,t:1528139741363};\\\", \\\"{x:1204,y:877,t:1528139741380};\\\", \\\"{x:1203,y:877,t:1528139741588};\\\", \\\"{x:1201,y:877,t:1528139741596};\\\", \\\"{x:1198,y:879,t:1528139741613};\\\", \\\"{x:1194,y:882,t:1528139741630};\\\", \\\"{x:1188,y:892,t:1528139741660};\\\", \\\"{x:1187,y:894,t:1528139741667};\\\", \\\"{x:1186,y:894,t:1528139741680};\\\", \\\"{x:1185,y:897,t:1528139741697};\\\", \\\"{x:1184,y:901,t:1528139741713};\\\", \\\"{x:1184,y:904,t:1528139741730};\\\", \\\"{x:1183,y:909,t:1528139741747};\\\", \\\"{x:1180,y:913,t:1528139741763};\\\", \\\"{x:1180,y:918,t:1528139741780};\\\", \\\"{x:1179,y:919,t:1528139741797};\\\", \\\"{x:1179,y:921,t:1528139741813};\\\", \\\"{x:1179,y:922,t:1528139741830};\\\", \\\"{x:1179,y:923,t:1528139741847};\\\", \\\"{x:1178,y:925,t:1528139741863};\\\", \\\"{x:1177,y:926,t:1528139741880};\\\", \\\"{x:1177,y:928,t:1528139741901};\\\", \\\"{x:1176,y:929,t:1528139741924};\\\", \\\"{x:1176,y:931,t:1528139741948};\\\", \\\"{x:1175,y:932,t:1528139741963};\\\", \\\"{x:1173,y:934,t:1528139741979};\\\", \\\"{x:1173,y:935,t:1528139741997};\\\", \\\"{x:1172,y:936,t:1528139742013};\\\", \\\"{x:1170,y:938,t:1528139742030};\\\", \\\"{x:1168,y:939,t:1528139742052};\\\", \\\"{x:1168,y:940,t:1528139742064};\\\", \\\"{x:1167,y:942,t:1528139742080};\\\", \\\"{x:1164,y:945,t:1528139742098};\\\", \\\"{x:1164,y:946,t:1528139742113};\\\", \\\"{x:1163,y:948,t:1528139742131};\\\", \\\"{x:1161,y:949,t:1528139742147};\\\", \\\"{x:1159,y:951,t:1528139742164};\\\", \\\"{x:1158,y:952,t:1528139742188};\\\", \\\"{x:1156,y:952,t:1528139742229};\\\", \\\"{x:1155,y:954,t:1528139742253};\\\", \\\"{x:1154,y:954,t:1528139742285};\\\", \\\"{x:1152,y:955,t:1528139742301};\\\", \\\"{x:1152,y:953,t:1528139744669};\\\", \\\"{x:1152,y:951,t:1528139744683};\\\", \\\"{x:1154,y:947,t:1528139744700};\\\", \\\"{x:1157,y:945,t:1528139744717};\\\", \\\"{x:1158,y:942,t:1528139744733};\\\", \\\"{x:1159,y:941,t:1528139744749};\\\", \\\"{x:1160,y:940,t:1528139744767};\\\", \\\"{x:1161,y:938,t:1528139744783};\\\", \\\"{x:1162,y:937,t:1528139744799};\\\", \\\"{x:1163,y:936,t:1528139744820};\\\", \\\"{x:1164,y:935,t:1528139744844};\\\", \\\"{x:1165,y:934,t:1528139744852};\\\", \\\"{x:1166,y:933,t:1528139744893};\\\", \\\"{x:1166,y:932,t:1528139744909};\\\", \\\"{x:1167,y:931,t:1528139744917};\\\", \\\"{x:1168,y:930,t:1528139744973};\\\", \\\"{x:1169,y:929,t:1528139745061};\\\", \\\"{x:1170,y:928,t:1528139745100};\\\", \\\"{x:1171,y:927,t:1528139745117};\\\", \\\"{x:1172,y:926,t:1528139745156};\\\", \\\"{x:1173,y:925,t:1528139745173};\\\", \\\"{x:1174,y:924,t:1528139745189};\\\", \\\"{x:1175,y:923,t:1528139745221};\\\", \\\"{x:1176,y:922,t:1528139745237};\\\", \\\"{x:1177,y:922,t:1528139745317};\\\", \\\"{x:1179,y:922,t:1528139745357};\\\", \\\"{x:1180,y:922,t:1528139745373};\\\", \\\"{x:1182,y:922,t:1528139745384};\\\", \\\"{x:1183,y:922,t:1528139745413};\\\", \\\"{x:1184,y:921,t:1528139745437};\\\", \\\"{x:1185,y:921,t:1528139745453};\\\", \\\"{x:1186,y:921,t:1528139745501};\\\", \\\"{x:1188,y:921,t:1528139745573};\\\", \\\"{x:1189,y:921,t:1528139745597};\\\", \\\"{x:1192,y:921,t:1528139745612};\\\", \\\"{x:1193,y:921,t:1528139745629};\\\", \\\"{x:1195,y:921,t:1528139745637};\\\", \\\"{x:1196,y:922,t:1528139745651};\\\", \\\"{x:1199,y:924,t:1528139745667};\\\", \\\"{x:1202,y:927,t:1528139745684};\\\", \\\"{x:1206,y:930,t:1528139745700};\\\", \\\"{x:1208,y:931,t:1528139745716};\\\", \\\"{x:1212,y:933,t:1528139745733};\\\", \\\"{x:1213,y:935,t:1528139745751};\\\", \\\"{x:1215,y:936,t:1528139745768};\\\", \\\"{x:1216,y:937,t:1528139745784};\\\", \\\"{x:1217,y:937,t:1528139745800};\\\", \\\"{x:1218,y:938,t:1528139745821};\\\", \\\"{x:1219,y:939,t:1528139745837};\\\", \\\"{x:1220,y:940,t:1528139745851};\\\", \\\"{x:1221,y:940,t:1528139745917};\\\", \\\"{x:1222,y:940,t:1528139745934};\\\", \\\"{x:1227,y:936,t:1528139745951};\\\", \\\"{x:1235,y:924,t:1528139745968};\\\", \\\"{x:1241,y:913,t:1528139745984};\\\", \\\"{x:1249,y:893,t:1528139746001};\\\", \\\"{x:1258,y:875,t:1528139746018};\\\", \\\"{x:1263,y:859,t:1528139746034};\\\", \\\"{x:1269,y:846,t:1528139746051};\\\", \\\"{x:1271,y:842,t:1528139746068};\\\", \\\"{x:1271,y:841,t:1528139746084};\\\", \\\"{x:1272,y:841,t:1528139746253};\\\", \\\"{x:1278,y:834,t:1528139746268};\\\", \\\"{x:1293,y:810,t:1528139746285};\\\", \\\"{x:1302,y:792,t:1528139746301};\\\", \\\"{x:1309,y:779,t:1528139746317};\\\", \\\"{x:1318,y:765,t:1528139746335};\\\", \\\"{x:1320,y:762,t:1528139746351};\\\", \\\"{x:1321,y:760,t:1528139746368};\\\", \\\"{x:1321,y:758,t:1528139746421};\\\", \\\"{x:1322,y:756,t:1528139746435};\\\", \\\"{x:1323,y:749,t:1528139746450};\\\", \\\"{x:1323,y:742,t:1528139746468};\\\", \\\"{x:1326,y:729,t:1528139746485};\\\", \\\"{x:1327,y:724,t:1528139746501};\\\", \\\"{x:1331,y:716,t:1528139746518};\\\", \\\"{x:1332,y:713,t:1528139746535};\\\", \\\"{x:1333,y:708,t:1528139746551};\\\", \\\"{x:1335,y:702,t:1528139746567};\\\", \\\"{x:1339,y:693,t:1528139746584};\\\", \\\"{x:1341,y:685,t:1528139746601};\\\", \\\"{x:1343,y:679,t:1528139746617};\\\", \\\"{x:1344,y:675,t:1528139746634};\\\", \\\"{x:1346,y:671,t:1528139746651};\\\", \\\"{x:1346,y:674,t:1528139747021};\\\", \\\"{x:1345,y:676,t:1528139747035};\\\", \\\"{x:1344,y:682,t:1528139747052};\\\", \\\"{x:1342,y:690,t:1528139747069};\\\", \\\"{x:1341,y:696,t:1528139747085};\\\", \\\"{x:1341,y:704,t:1528139747102};\\\", \\\"{x:1338,y:717,t:1528139747119};\\\", \\\"{x:1337,y:727,t:1528139747134};\\\", \\\"{x:1336,y:740,t:1528139747151};\\\", \\\"{x:1332,y:755,t:1528139747169};\\\", \\\"{x:1327,y:775,t:1528139747185};\\\", \\\"{x:1322,y:796,t:1528139747202};\\\", \\\"{x:1317,y:818,t:1528139747219};\\\", \\\"{x:1314,y:840,t:1528139747234};\\\", \\\"{x:1310,y:861,t:1528139747252};\\\", \\\"{x:1305,y:887,t:1528139747268};\\\", \\\"{x:1300,y:902,t:1528139747284};\\\", \\\"{x:1293,y:919,t:1528139747302};\\\", \\\"{x:1285,y:931,t:1528139747319};\\\", \\\"{x:1278,y:941,t:1528139747335};\\\", \\\"{x:1273,y:951,t:1528139747351};\\\", \\\"{x:1265,y:959,t:1528139747369};\\\", \\\"{x:1260,y:964,t:1528139747384};\\\", \\\"{x:1251,y:970,t:1528139747401};\\\", \\\"{x:1241,y:977,t:1528139747419};\\\", \\\"{x:1229,y:985,t:1528139747435};\\\", \\\"{x:1218,y:989,t:1528139747451};\\\", \\\"{x:1207,y:992,t:1528139747468};\\\", \\\"{x:1196,y:993,t:1528139747486};\\\", \\\"{x:1185,y:993,t:1528139747502};\\\", \\\"{x:1182,y:993,t:1528139747519};\\\", \\\"{x:1192,y:993,t:1528139747637};\\\", \\\"{x:1203,y:993,t:1528139747652};\\\", \\\"{x:1225,y:993,t:1528139747668};\\\", \\\"{x:1228,y:994,t:1528139747685};\\\", \\\"{x:1230,y:995,t:1528139747702};\\\", \\\"{x:1232,y:996,t:1528139747719};\\\", \\\"{x:1233,y:996,t:1528139747756};\\\", \\\"{x:1235,y:996,t:1528139747773};\\\", \\\"{x:1236,y:994,t:1528139747786};\\\", \\\"{x:1237,y:991,t:1528139747802};\\\", \\\"{x:1240,y:986,t:1528139747818};\\\", \\\"{x:1243,y:979,t:1528139747836};\\\", \\\"{x:1245,y:976,t:1528139747852};\\\", \\\"{x:1247,y:973,t:1528139747869};\\\", \\\"{x:1247,y:971,t:1528139747885};\\\", \\\"{x:1247,y:969,t:1528139747903};\\\", \\\"{x:1248,y:964,t:1528139747919};\\\", \\\"{x:1249,y:961,t:1528139747936};\\\", \\\"{x:1249,y:959,t:1528139747952};\\\", \\\"{x:1249,y:958,t:1528139747968};\\\", \\\"{x:1250,y:957,t:1528139747985};\\\", \\\"{x:1251,y:957,t:1528139748002};\\\", \\\"{x:1251,y:956,t:1528139748035};\\\", \\\"{x:1251,y:955,t:1528139748084};\\\", \\\"{x:1252,y:953,t:1528139748285};\\\", \\\"{x:1257,y:953,t:1528139748303};\\\", \\\"{x:1259,y:953,t:1528139748320};\\\", \\\"{x:1261,y:953,t:1528139748336};\\\", \\\"{x:1264,y:953,t:1528139748353};\\\", \\\"{x:1266,y:953,t:1528139748370};\\\", \\\"{x:1268,y:954,t:1528139748445};\\\", \\\"{x:1271,y:955,t:1528139748453};\\\", \\\"{x:1275,y:958,t:1528139748470};\\\", \\\"{x:1282,y:963,t:1528139748486};\\\", \\\"{x:1285,y:965,t:1528139748503};\\\", \\\"{x:1286,y:965,t:1528139748519};\\\", \\\"{x:1286,y:966,t:1528139748536};\\\", \\\"{x:1287,y:967,t:1528139748565};\\\", \\\"{x:1288,y:968,t:1528139748605};\\\", \\\"{x:1289,y:968,t:1528139748619};\\\", \\\"{x:1294,y:972,t:1528139748636};\\\", \\\"{x:1297,y:975,t:1528139748653};\\\", \\\"{x:1300,y:978,t:1528139748670};\\\", \\\"{x:1300,y:979,t:1528139748692};\\\", \\\"{x:1301,y:980,t:1528139748703};\\\", \\\"{x:1302,y:981,t:1528139748813};\\\", \\\"{x:1303,y:981,t:1528139748821};\\\", \\\"{x:1304,y:982,t:1528139748837};\\\", \\\"{x:1304,y:983,t:1528139748853};\\\", \\\"{x:1305,y:983,t:1528139748870};\\\", \\\"{x:1307,y:983,t:1528139748893};\\\", \\\"{x:1308,y:983,t:1528139748903};\\\", \\\"{x:1311,y:983,t:1528139748920};\\\", \\\"{x:1316,y:983,t:1528139748937};\\\", \\\"{x:1320,y:983,t:1528139748952};\\\", \\\"{x:1323,y:983,t:1528139748970};\\\", \\\"{x:1326,y:983,t:1528139748986};\\\", \\\"{x:1331,y:983,t:1528139749003};\\\", \\\"{x:1335,y:983,t:1528139749020};\\\", \\\"{x:1337,y:983,t:1528139749036};\\\", \\\"{x:1338,y:983,t:1528139749053};\\\", \\\"{x:1340,y:982,t:1528139749069};\\\", \\\"{x:1341,y:982,t:1528139749087};\\\", \\\"{x:1343,y:981,t:1528139749104};\\\", \\\"{x:1344,y:981,t:1528139749119};\\\", \\\"{x:1346,y:979,t:1528139749137};\\\", \\\"{x:1348,y:977,t:1528139749154};\\\", \\\"{x:1351,y:975,t:1528139749170};\\\", \\\"{x:1352,y:974,t:1528139749187};\\\", \\\"{x:1354,y:971,t:1528139749203};\\\", \\\"{x:1355,y:970,t:1528139749220};\\\", \\\"{x:1357,y:968,t:1528139749237};\\\", \\\"{x:1357,y:967,t:1528139749253};\\\", \\\"{x:1359,y:967,t:1528139749629};\\\", \\\"{x:1360,y:967,t:1528139749645};\\\", \\\"{x:1361,y:967,t:1528139749654};\\\", \\\"{x:1366,y:970,t:1528139749671};\\\", \\\"{x:1368,y:971,t:1528139749687};\\\", \\\"{x:1371,y:973,t:1528139749704};\\\", \\\"{x:1376,y:974,t:1528139749721};\\\", \\\"{x:1382,y:975,t:1528139749736};\\\", \\\"{x:1390,y:976,t:1528139749753};\\\", \\\"{x:1394,y:977,t:1528139749771};\\\", \\\"{x:1400,y:977,t:1528139749787};\\\", \\\"{x:1404,y:977,t:1528139749803};\\\", \\\"{x:1407,y:977,t:1528139749820};\\\", \\\"{x:1410,y:977,t:1528139749838};\\\", \\\"{x:1411,y:977,t:1528139749854};\\\", \\\"{x:1415,y:974,t:1528139749871};\\\", \\\"{x:1417,y:972,t:1528139749888};\\\", \\\"{x:1418,y:971,t:1528139749903};\\\", \\\"{x:1419,y:968,t:1528139749921};\\\", \\\"{x:1420,y:967,t:1528139749938};\\\", \\\"{x:1421,y:965,t:1528139749953};\\\", \\\"{x:1422,y:962,t:1528139749971};\\\", \\\"{x:1424,y:959,t:1528139749988};\\\", \\\"{x:1424,y:957,t:1528139750004};\\\", \\\"{x:1424,y:955,t:1528139750021};\\\", \\\"{x:1425,y:955,t:1528139750460};\\\", \\\"{x:1425,y:956,t:1528139750471};\\\", \\\"{x:1425,y:957,t:1528139750487};\\\", \\\"{x:1427,y:960,t:1528139750505};\\\", \\\"{x:1428,y:961,t:1528139750521};\\\", \\\"{x:1430,y:965,t:1528139750538};\\\", \\\"{x:1433,y:967,t:1528139750555};\\\", \\\"{x:1437,y:971,t:1528139750570};\\\", \\\"{x:1441,y:972,t:1528139750587};\\\", \\\"{x:1445,y:975,t:1528139750603};\\\", \\\"{x:1448,y:976,t:1528139750621};\\\", \\\"{x:1450,y:976,t:1528139750637};\\\", \\\"{x:1452,y:976,t:1528139750654};\\\", \\\"{x:1453,y:976,t:1528139750675};\\\", \\\"{x:1454,y:976,t:1528139750691};\\\", \\\"{x:1455,y:976,t:1528139750704};\\\", \\\"{x:1458,y:976,t:1528139750722};\\\", \\\"{x:1459,y:976,t:1528139750737};\\\", \\\"{x:1462,y:976,t:1528139750755};\\\", \\\"{x:1465,y:976,t:1528139750772};\\\", \\\"{x:1467,y:976,t:1528139750787};\\\", \\\"{x:1471,y:974,t:1528139750804};\\\", \\\"{x:1473,y:973,t:1528139750821};\\\", \\\"{x:1475,y:971,t:1528139750837};\\\", \\\"{x:1476,y:969,t:1528139750855};\\\", \\\"{x:1477,y:968,t:1528139750872};\\\", \\\"{x:1478,y:968,t:1528139750888};\\\", \\\"{x:1479,y:967,t:1528139750905};\\\", \\\"{x:1481,y:965,t:1528139750921};\\\", \\\"{x:1483,y:964,t:1528139750938};\\\", \\\"{x:1484,y:963,t:1528139750955};\\\", \\\"{x:1485,y:962,t:1528139750973};\\\", \\\"{x:1486,y:961,t:1528139750988};\\\", \\\"{x:1486,y:960,t:1528139751109};\\\", \\\"{x:1484,y:960,t:1528139751122};\\\", \\\"{x:1469,y:960,t:1528139751139};\\\", \\\"{x:1447,y:961,t:1528139751154};\\\", \\\"{x:1408,y:961,t:1528139751172};\\\", \\\"{x:1261,y:928,t:1528139751188};\\\", \\\"{x:1120,y:889,t:1528139751204};\\\", \\\"{x:976,y:845,t:1528139751222};\\\", \\\"{x:835,y:806,t:1528139751239};\\\", \\\"{x:691,y:763,t:1528139751254};\\\", \\\"{x:541,y:716,t:1528139751271};\\\", \\\"{x:397,y:666,t:1528139751291};\\\", \\\"{x:286,y:633,t:1528139751304};\\\", \\\"{x:216,y:612,t:1528139751322};\\\", \\\"{x:189,y:597,t:1528139751355};\\\", \\\"{x:189,y:595,t:1528139751371};\\\", \\\"{x:189,y:592,t:1528139751387};\\\", \\\"{x:194,y:587,t:1528139751404};\\\", \\\"{x:202,y:582,t:1528139751420};\\\", \\\"{x:213,y:576,t:1528139751437};\\\", \\\"{x:225,y:565,t:1528139751454};\\\", \\\"{x:239,y:555,t:1528139751472};\\\", \\\"{x:257,y:546,t:1528139751487};\\\", \\\"{x:271,y:540,t:1528139751504};\\\", \\\"{x:286,y:534,t:1528139751522};\\\", \\\"{x:294,y:530,t:1528139751537};\\\", \\\"{x:302,y:526,t:1528139751554};\\\", \\\"{x:307,y:525,t:1528139751572};\\\", \\\"{x:311,y:522,t:1528139751588};\\\", \\\"{x:330,y:518,t:1528139751604};\\\", \\\"{x:345,y:516,t:1528139751622};\\\", \\\"{x:362,y:515,t:1528139751637};\\\", \\\"{x:382,y:515,t:1528139751655};\\\", \\\"{x:405,y:515,t:1528139751671};\\\", \\\"{x:434,y:515,t:1528139751687};\\\", \\\"{x:470,y:515,t:1528139751704};\\\", \\\"{x:511,y:512,t:1528139751723};\\\", \\\"{x:551,y:511,t:1528139751738};\\\", \\\"{x:587,y:506,t:1528139751755};\\\", \\\"{x:626,y:502,t:1528139751772};\\\", \\\"{x:664,y:499,t:1528139751787};\\\", \\\"{x:709,y:499,t:1528139751804};\\\", \\\"{x:741,y:499,t:1528139751822};\\\", \\\"{x:773,y:499,t:1528139751838};\\\", \\\"{x:799,y:499,t:1528139751854};\\\", \\\"{x:826,y:499,t:1528139751871};\\\", \\\"{x:843,y:499,t:1528139751889};\\\", \\\"{x:856,y:499,t:1528139751905};\\\", \\\"{x:866,y:499,t:1528139751921};\\\", \\\"{x:872,y:499,t:1528139751938};\\\", \\\"{x:875,y:499,t:1528139751954};\\\", \\\"{x:878,y:499,t:1528139751971};\\\", \\\"{x:879,y:499,t:1528139751987};\\\", \\\"{x:879,y:500,t:1528139752269};\\\", \\\"{x:879,y:501,t:1528139752285};\\\", \\\"{x:879,y:502,t:1528139752300};\\\", \\\"{x:879,y:504,t:1528139752324};\\\", \\\"{x:879,y:505,t:1528139752341};\\\", \\\"{x:879,y:507,t:1528139752356};\\\", \\\"{x:879,y:509,t:1528139752372};\\\", \\\"{x:879,y:512,t:1528139752388};\\\", \\\"{x:879,y:514,t:1528139752406};\\\", \\\"{x:879,y:515,t:1528139752422};\\\", \\\"{x:878,y:518,t:1528139752750};\\\", \\\"{x:876,y:522,t:1528139752756};\\\", \\\"{x:874,y:527,t:1528139752772};\\\", \\\"{x:872,y:531,t:1528139752789};\\\", \\\"{x:871,y:533,t:1528139752805};\\\", \\\"{x:870,y:534,t:1528139752822};\\\", \\\"{x:869,y:534,t:1528139752838};\\\", \\\"{x:868,y:536,t:1528139752855};\\\", \\\"{x:867,y:537,t:1528139752872};\\\", \\\"{x:866,y:537,t:1528139752888};\\\", \\\"{x:864,y:538,t:1528139752905};\\\", \\\"{x:863,y:539,t:1528139752922};\\\", \\\"{x:862,y:539,t:1528139752938};\\\", \\\"{x:860,y:539,t:1528139752972};\\\", \\\"{x:857,y:538,t:1528139752989};\\\", \\\"{x:853,y:532,t:1528139753005};\\\", \\\"{x:850,y:530,t:1528139753022};\\\", \\\"{x:848,y:527,t:1528139753040};\\\", \\\"{x:846,y:525,t:1528139753055};\\\", \\\"{x:845,y:524,t:1528139753073};\\\", \\\"{x:844,y:522,t:1528139753088};\\\", \\\"{x:844,y:520,t:1528139753105};\\\", \\\"{x:843,y:519,t:1528139753122};\\\", \\\"{x:841,y:517,t:1528139753140};\\\", \\\"{x:841,y:516,t:1528139753156};\\\", \\\"{x:841,y:515,t:1528139753179};\\\", \\\"{x:840,y:515,t:1528139753189};\\\", \\\"{x:839,y:513,t:1528139753206};\\\", \\\"{x:839,y:512,t:1528139753325};\\\", \\\"{x:839,y:510,t:1528139753340};\\\", \\\"{x:839,y:509,t:1528139753364};\\\", \\\"{x:846,y:513,t:1528139754172};\\\", \\\"{x:851,y:515,t:1528139754181};\\\", \\\"{x:857,y:518,t:1528139754190};\\\", \\\"{x:872,y:524,t:1528139754206};\\\", \\\"{x:894,y:533,t:1528139754224};\\\", \\\"{x:920,y:545,t:1528139754239};\\\", \\\"{x:974,y:566,t:1528139754257};\\\", \\\"{x:1054,y:601,t:1528139754274};\\\", \\\"{x:1155,y:635,t:1528139754289};\\\", \\\"{x:1256,y:673,t:1528139754307};\\\", \\\"{x:1393,y:720,t:1528139754324};\\\", \\\"{x:1473,y:741,t:1528139754340};\\\", \\\"{x:1527,y:759,t:1528139754357};\\\", \\\"{x:1555,y:767,t:1528139754374};\\\", \\\"{x:1572,y:773,t:1528139754391};\\\", \\\"{x:1578,y:775,t:1528139754406};\\\", \\\"{x:1575,y:775,t:1528139754525};\\\", \\\"{x:1560,y:771,t:1528139754543};\\\", \\\"{x:1538,y:768,t:1528139754557};\\\", \\\"{x:1520,y:766,t:1528139754574};\\\", \\\"{x:1501,y:761,t:1528139754591};\\\", \\\"{x:1482,y:756,t:1528139754607};\\\", \\\"{x:1470,y:751,t:1528139754624};\\\", \\\"{x:1459,y:745,t:1528139754641};\\\", \\\"{x:1447,y:738,t:1528139754657};\\\", \\\"{x:1440,y:733,t:1528139754674};\\\", \\\"{x:1436,y:731,t:1528139754691};\\\", \\\"{x:1435,y:730,t:1528139754708};\\\", \\\"{x:1434,y:728,t:1528139754724};\\\", \\\"{x:1432,y:725,t:1528139754742};\\\", \\\"{x:1431,y:721,t:1528139754758};\\\", \\\"{x:1429,y:716,t:1528139754774};\\\", \\\"{x:1429,y:712,t:1528139754791};\\\", \\\"{x:1427,y:706,t:1528139754808};\\\", \\\"{x:1426,y:701,t:1528139754824};\\\", \\\"{x:1423,y:692,t:1528139754842};\\\", \\\"{x:1422,y:688,t:1528139754858};\\\", \\\"{x:1421,y:683,t:1528139754874};\\\", \\\"{x:1420,y:681,t:1528139754891};\\\", \\\"{x:1420,y:677,t:1528139754908};\\\", \\\"{x:1420,y:672,t:1528139754924};\\\", \\\"{x:1420,y:668,t:1528139754941};\\\", \\\"{x:1420,y:666,t:1528139754958};\\\", \\\"{x:1420,y:664,t:1528139754974};\\\", \\\"{x:1420,y:662,t:1528139754991};\\\", \\\"{x:1420,y:657,t:1528139755008};\\\", \\\"{x:1420,y:656,t:1528139755024};\\\", \\\"{x:1420,y:654,t:1528139755041};\\\", \\\"{x:1420,y:652,t:1528139755059};\\\", \\\"{x:1420,y:649,t:1528139755074};\\\", \\\"{x:1420,y:647,t:1528139755091};\\\", \\\"{x:1420,y:644,t:1528139755108};\\\", \\\"{x:1420,y:642,t:1528139755124};\\\", \\\"{x:1421,y:639,t:1528139755140};\\\", \\\"{x:1421,y:636,t:1528139755157};\\\", \\\"{x:1421,y:633,t:1528139755174};\\\", \\\"{x:1421,y:627,t:1528139755190};\\\", \\\"{x:1421,y:621,t:1528139755208};\\\", \\\"{x:1421,y:620,t:1528139755224};\\\", \\\"{x:1421,y:618,t:1528139755240};\\\", \\\"{x:1421,y:616,t:1528139755258};\\\", \\\"{x:1421,y:615,t:1528139755274};\\\", \\\"{x:1421,y:613,t:1528139755292};\\\", \\\"{x:1421,y:612,t:1528139755308};\\\", \\\"{x:1421,y:610,t:1528139755324};\\\", \\\"{x:1421,y:606,t:1528139755341};\\\", \\\"{x:1421,y:603,t:1528139755357};\\\", \\\"{x:1421,y:599,t:1528139755374};\\\", \\\"{x:1421,y:597,t:1528139755391};\\\", \\\"{x:1421,y:595,t:1528139755407};\\\", \\\"{x:1421,y:592,t:1528139755425};\\\", \\\"{x:1422,y:590,t:1528139755442};\\\", \\\"{x:1423,y:589,t:1528139755458};\\\", \\\"{x:1423,y:588,t:1528139755474};\\\", \\\"{x:1424,y:587,t:1528139755491};\\\", \\\"{x:1424,y:586,t:1528139755507};\\\", \\\"{x:1426,y:584,t:1528139755524};\\\", \\\"{x:1426,y:583,t:1528139755725};\\\", \\\"{x:1426,y:581,t:1528139755742};\\\", \\\"{x:1426,y:578,t:1528139755758};\\\", \\\"{x:1426,y:577,t:1528139755775};\\\", \\\"{x:1425,y:575,t:1528139755792};\\\", \\\"{x:1424,y:574,t:1528139755810};\\\", \\\"{x:1424,y:573,t:1528139755825};\\\", \\\"{x:1424,y:572,t:1528139755842};\\\", \\\"{x:1423,y:571,t:1528139755859};\\\", \\\"{x:1422,y:571,t:1528139756165};\\\", \\\"{x:1420,y:573,t:1528139756175};\\\", \\\"{x:1415,y:579,t:1528139756192};\\\", \\\"{x:1412,y:583,t:1528139756209};\\\", \\\"{x:1409,y:588,t:1528139756226};\\\", \\\"{x:1404,y:595,t:1528139756242};\\\", \\\"{x:1400,y:600,t:1528139756258};\\\", \\\"{x:1391,y:617,t:1528139756275};\\\", \\\"{x:1384,y:632,t:1528139756291};\\\", \\\"{x:1378,y:644,t:1528139756309};\\\", \\\"{x:1370,y:656,t:1528139756325};\\\", \\\"{x:1364,y:666,t:1528139756342};\\\", \\\"{x:1359,y:675,t:1528139756358};\\\", \\\"{x:1356,y:683,t:1528139756375};\\\", \\\"{x:1352,y:691,t:1528139756391};\\\", \\\"{x:1348,y:704,t:1528139756409};\\\", \\\"{x:1345,y:717,t:1528139756426};\\\", \\\"{x:1340,y:734,t:1528139756441};\\\", \\\"{x:1335,y:750,t:1528139756459};\\\", \\\"{x:1329,y:773,t:1528139756476};\\\", \\\"{x:1326,y:779,t:1528139756491};\\\", \\\"{x:1325,y:782,t:1528139756509};\\\", \\\"{x:1325,y:783,t:1528139756526};\\\", \\\"{x:1325,y:784,t:1528139756572};\\\", \\\"{x:1325,y:785,t:1528139756588};\\\", \\\"{x:1325,y:786,t:1528139756596};\\\", \\\"{x:1323,y:787,t:1528139756609};\\\", \\\"{x:1322,y:789,t:1528139756628};\\\", \\\"{x:1321,y:791,t:1528139756644};\\\", \\\"{x:1321,y:792,t:1528139756659};\\\", \\\"{x:1319,y:794,t:1528139756676};\\\", \\\"{x:1319,y:795,t:1528139756693};\\\", \\\"{x:1318,y:798,t:1528139756709};\\\", \\\"{x:1317,y:800,t:1528139756725};\\\", \\\"{x:1316,y:801,t:1528139756743};\\\", \\\"{x:1316,y:802,t:1528139756759};\\\", \\\"{x:1315,y:804,t:1528139756776};\\\", \\\"{x:1315,y:805,t:1528139756796};\\\", \\\"{x:1314,y:805,t:1528139756809};\\\", \\\"{x:1318,y:795,t:1528139757725};\\\", \\\"{x:1334,y:777,t:1528139757732};\\\", \\\"{x:1343,y:768,t:1528139757743};\\\", \\\"{x:1374,y:743,t:1528139757760};\\\", \\\"{x:1407,y:716,t:1528139757777};\\\", \\\"{x:1449,y:684,t:1528139757794};\\\", \\\"{x:1487,y:655,t:1528139757810};\\\", \\\"{x:1521,y:631,t:1528139757827};\\\", \\\"{x:1561,y:596,t:1528139757844};\\\", \\\"{x:1576,y:581,t:1528139757860};\\\", \\\"{x:1586,y:567,t:1528139757877};\\\", \\\"{x:1593,y:555,t:1528139757894};\\\", \\\"{x:1595,y:551,t:1528139757910};\\\", \\\"{x:1596,y:549,t:1528139757927};\\\", \\\"{x:1597,y:547,t:1528139757945};\\\", \\\"{x:1597,y:548,t:1528139758837};\\\", \\\"{x:1597,y:562,t:1528139758844};\\\", \\\"{x:1593,y:593,t:1528139758860};\\\", \\\"{x:1593,y:618,t:1528139758878};\\\", \\\"{x:1593,y:642,t:1528139758895};\\\", \\\"{x:1594,y:656,t:1528139758911};\\\", \\\"{x:1601,y:669,t:1528139758928};\\\", \\\"{x:1611,y:680,t:1528139758944};\\\", \\\"{x:1616,y:685,t:1528139758960};\\\", \\\"{x:1616,y:686,t:1528139758978};\\\", \\\"{x:1616,y:687,t:1528139759292};\\\", \\\"{x:1618,y:694,t:1528139759302};\\\", \\\"{x:1621,y:700,t:1528139759313};\\\", \\\"{x:1626,y:712,t:1528139759328};\\\", \\\"{x:1631,y:723,t:1528139759345};\\\", \\\"{x:1635,y:733,t:1528139759362};\\\", \\\"{x:1638,y:738,t:1528139759378};\\\", \\\"{x:1638,y:739,t:1528139759395};\\\", \\\"{x:1638,y:741,t:1528139759412};\\\", \\\"{x:1637,y:742,t:1528139759493};\\\", \\\"{x:1637,y:743,t:1528139759500};\\\", \\\"{x:1636,y:743,t:1528139759513};\\\", \\\"{x:1633,y:745,t:1528139759528};\\\", \\\"{x:1631,y:748,t:1528139759545};\\\", \\\"{x:1624,y:750,t:1528139759562};\\\", \\\"{x:1608,y:755,t:1528139759577};\\\", \\\"{x:1589,y:758,t:1528139759594};\\\", \\\"{x:1557,y:765,t:1528139759611};\\\", \\\"{x:1538,y:765,t:1528139759628};\\\", \\\"{x:1524,y:766,t:1528139759644};\\\", \\\"{x:1514,y:767,t:1528139759661};\\\", \\\"{x:1509,y:767,t:1528139759679};\\\", \\\"{x:1506,y:767,t:1528139759695};\\\", \\\"{x:1506,y:768,t:1528139759901};\\\", \\\"{x:1506,y:769,t:1528139759912};\\\", \\\"{x:1506,y:771,t:1528139759930};\\\", \\\"{x:1506,y:772,t:1528139759945};\\\", \\\"{x:1506,y:773,t:1528139759962};\\\", \\\"{x:1506,y:775,t:1528139759979};\\\", \\\"{x:1506,y:776,t:1528139759995};\\\", \\\"{x:1506,y:778,t:1528139760012};\\\", \\\"{x:1506,y:779,t:1528139760029};\\\", \\\"{x:1506,y:780,t:1528139760045};\\\", \\\"{x:1506,y:781,t:1528139760063};\\\", \\\"{x:1506,y:782,t:1528139760079};\\\", \\\"{x:1506,y:783,t:1528139760100};\\\", \\\"{x:1506,y:784,t:1528139760112};\\\", \\\"{x:1504,y:792,t:1528139760129};\\\", \\\"{x:1500,y:801,t:1528139760146};\\\", \\\"{x:1500,y:804,t:1528139760162};\\\", \\\"{x:1498,y:806,t:1528139760179};\\\", \\\"{x:1498,y:807,t:1528139760221};\\\", \\\"{x:1497,y:809,t:1528139760236};\\\", \\\"{x:1497,y:811,t:1528139760246};\\\", \\\"{x:1497,y:814,t:1528139760263};\\\", \\\"{x:1495,y:817,t:1528139760279};\\\", \\\"{x:1494,y:820,t:1528139760297};\\\", \\\"{x:1493,y:823,t:1528139760313};\\\", \\\"{x:1492,y:828,t:1528139760329};\\\", \\\"{x:1491,y:830,t:1528139760346};\\\", \\\"{x:1491,y:831,t:1528139760365};\\\", \\\"{x:1491,y:832,t:1528139760380};\\\", \\\"{x:1490,y:835,t:1528139760397};\\\", \\\"{x:1489,y:835,t:1528139760428};\\\", \\\"{x:1489,y:836,t:1528139760469};\\\", \\\"{x:1489,y:837,t:1528139760492};\\\", \\\"{x:1488,y:838,t:1528139760500};\\\", \\\"{x:1487,y:838,t:1528139760644};\\\", \\\"{x:1486,y:838,t:1528139760659};\\\", \\\"{x:1485,y:838,t:1528139760667};\\\", \\\"{x:1483,y:839,t:1528139760682};\\\", \\\"{x:1482,y:840,t:1528139760696};\\\", \\\"{x:1481,y:841,t:1528139760712};\\\", \\\"{x:1480,y:842,t:1528139760729};\\\", \\\"{x:1479,y:845,t:1528139760745};\\\", \\\"{x:1478,y:846,t:1528139760763};\\\", \\\"{x:1477,y:847,t:1528139760778};\\\", \\\"{x:1475,y:851,t:1528139760795};\\\", \\\"{x:1472,y:858,t:1528139760813};\\\", \\\"{x:1466,y:870,t:1528139760829};\\\", \\\"{x:1460,y:883,t:1528139760846};\\\", \\\"{x:1450,y:898,t:1528139760863};\\\", \\\"{x:1448,y:904,t:1528139760880};\\\", \\\"{x:1445,y:907,t:1528139760896};\\\", \\\"{x:1443,y:910,t:1528139760913};\\\", \\\"{x:1442,y:914,t:1528139760929};\\\", \\\"{x:1441,y:915,t:1528139760946};\\\", \\\"{x:1441,y:916,t:1528139760964};\\\", \\\"{x:1438,y:919,t:1528139760980};\\\", \\\"{x:1438,y:922,t:1528139760996};\\\", \\\"{x:1436,y:925,t:1528139761013};\\\", \\\"{x:1435,y:927,t:1528139761030};\\\", \\\"{x:1434,y:928,t:1528139761046};\\\", \\\"{x:1431,y:933,t:1528139761063};\\\", \\\"{x:1428,y:939,t:1528139761080};\\\", \\\"{x:1424,y:943,t:1528139761096};\\\", \\\"{x:1420,y:947,t:1528139761114};\\\", \\\"{x:1415,y:950,t:1528139761130};\\\", \\\"{x:1412,y:953,t:1528139761146};\\\", \\\"{x:1410,y:955,t:1528139761163};\\\", \\\"{x:1409,y:956,t:1528139761180};\\\", \\\"{x:1408,y:957,t:1528139761197};\\\", \\\"{x:1408,y:955,t:1528139761388};\\\", \\\"{x:1413,y:949,t:1528139761396};\\\", \\\"{x:1432,y:935,t:1528139761413};\\\", \\\"{x:1445,y:926,t:1528139761430};\\\", \\\"{x:1457,y:918,t:1528139761447};\\\", \\\"{x:1465,y:911,t:1528139761463};\\\", \\\"{x:1473,y:905,t:1528139761480};\\\", \\\"{x:1477,y:902,t:1528139761497};\\\", \\\"{x:1482,y:899,t:1528139761513};\\\", \\\"{x:1487,y:895,t:1528139761530};\\\", \\\"{x:1493,y:892,t:1528139761547};\\\", \\\"{x:1497,y:887,t:1528139761564};\\\", \\\"{x:1501,y:880,t:1528139761580};\\\", \\\"{x:1505,y:872,t:1528139761598};\\\", \\\"{x:1509,y:864,t:1528139761613};\\\", \\\"{x:1510,y:859,t:1528139761631};\\\", \\\"{x:1512,y:851,t:1528139761647};\\\", \\\"{x:1512,y:844,t:1528139761665};\\\", \\\"{x:1512,y:839,t:1528139761680};\\\", \\\"{x:1512,y:833,t:1528139761697};\\\", \\\"{x:1511,y:832,t:1528139761714};\\\", \\\"{x:1510,y:831,t:1528139761730};\\\", \\\"{x:1509,y:831,t:1528139761772};\\\", \\\"{x:1508,y:831,t:1528139761852};\\\", \\\"{x:1507,y:831,t:1528139761865};\\\", \\\"{x:1506,y:831,t:1528139761880};\\\", \\\"{x:1505,y:831,t:1528139761957};\\\", \\\"{x:1504,y:831,t:1528139761997};\\\", \\\"{x:1503,y:832,t:1528139762014};\\\", \\\"{x:1503,y:833,t:1528139762036};\\\", \\\"{x:1502,y:834,t:1528139762052};\\\", \\\"{x:1502,y:835,t:1528139762092};\\\", \\\"{x:1501,y:836,t:1528139762317};\\\", \\\"{x:1501,y:837,t:1528139762365};\\\", \\\"{x:1501,y:838,t:1528139762388};\\\", \\\"{x:1500,y:838,t:1528139762469};\\\", \\\"{x:1500,y:839,t:1528139762481};\\\", \\\"{x:1500,y:842,t:1528139762498};\\\", \\\"{x:1500,y:847,t:1528139762514};\\\", \\\"{x:1500,y:849,t:1528139762531};\\\", \\\"{x:1500,y:852,t:1528139762548};\\\", \\\"{x:1500,y:853,t:1528139762564};\\\", \\\"{x:1500,y:854,t:1528139762581};\\\", \\\"{x:1500,y:856,t:1528139762598};\\\", \\\"{x:1500,y:858,t:1528139762614};\\\", \\\"{x:1500,y:863,t:1528139762631};\\\", \\\"{x:1500,y:867,t:1528139762649};\\\", \\\"{x:1501,y:870,t:1528139762664};\\\", \\\"{x:1503,y:872,t:1528139762682};\\\", \\\"{x:1505,y:874,t:1528139762698};\\\", \\\"{x:1507,y:877,t:1528139762714};\\\", \\\"{x:1507,y:880,t:1528139762731};\\\", \\\"{x:1512,y:887,t:1528139762748};\\\", \\\"{x:1514,y:890,t:1528139762766};\\\", \\\"{x:1516,y:894,t:1528139762781};\\\", \\\"{x:1519,y:899,t:1528139762799};\\\", \\\"{x:1520,y:902,t:1528139762815};\\\", \\\"{x:1522,y:907,t:1528139762831};\\\", \\\"{x:1523,y:911,t:1528139762848};\\\", \\\"{x:1524,y:918,t:1528139762865};\\\", \\\"{x:1526,y:927,t:1528139762882};\\\", \\\"{x:1528,y:935,t:1528139762898};\\\", \\\"{x:1529,y:944,t:1528139762916};\\\", \\\"{x:1531,y:950,t:1528139762931};\\\", \\\"{x:1533,y:956,t:1528139762948};\\\", \\\"{x:1535,y:961,t:1528139762964};\\\", \\\"{x:1536,y:964,t:1528139762982};\\\", \\\"{x:1536,y:966,t:1528139762998};\\\", \\\"{x:1538,y:969,t:1528139763015};\\\", \\\"{x:1538,y:970,t:1528139763031};\\\", \\\"{x:1538,y:971,t:1528139763445};\\\", \\\"{x:1538,y:970,t:1528139763484};\\\", \\\"{x:1538,y:967,t:1528139763499};\\\", \\\"{x:1537,y:963,t:1528139763515};\\\", \\\"{x:1535,y:960,t:1528139763533};\\\", \\\"{x:1534,y:958,t:1528139763548};\\\", \\\"{x:1531,y:956,t:1528139763565};\\\", \\\"{x:1523,y:953,t:1528139763583};\\\", \\\"{x:1516,y:950,t:1528139763600};\\\", \\\"{x:1509,y:948,t:1528139763615};\\\", \\\"{x:1500,y:948,t:1528139763632};\\\", \\\"{x:1489,y:948,t:1528139763649};\\\", \\\"{x:1483,y:949,t:1528139763666};\\\", \\\"{x:1473,y:956,t:1528139763683};\\\", \\\"{x:1467,y:961,t:1528139763700};\\\", \\\"{x:1462,y:965,t:1528139763715};\\\", \\\"{x:1460,y:969,t:1528139763732};\\\", \\\"{x:1460,y:970,t:1528139763748};\\\", \\\"{x:1460,y:968,t:1528139763853};\\\", \\\"{x:1460,y:964,t:1528139763865};\\\", \\\"{x:1462,y:958,t:1528139763883};\\\", \\\"{x:1464,y:950,t:1528139763899};\\\", \\\"{x:1464,y:938,t:1528139763916};\\\", \\\"{x:1464,y:934,t:1528139763933};\\\", \\\"{x:1464,y:928,t:1528139763949};\\\", \\\"{x:1463,y:923,t:1528139763967};\\\", \\\"{x:1462,y:920,t:1528139763983};\\\", \\\"{x:1460,y:919,t:1528139764092};\\\", \\\"{x:1459,y:919,t:1528139764100};\\\", \\\"{x:1457,y:919,t:1528139764124};\\\", \\\"{x:1455,y:919,t:1528139764141};\\\", \\\"{x:1454,y:921,t:1528139764150};\\\", \\\"{x:1454,y:924,t:1528139764167};\\\", \\\"{x:1453,y:926,t:1528139764182};\\\", \\\"{x:1453,y:928,t:1528139764198};\\\", \\\"{x:1453,y:931,t:1528139764216};\\\", \\\"{x:1453,y:934,t:1528139764232};\\\", \\\"{x:1454,y:937,t:1528139764249};\\\", \\\"{x:1455,y:939,t:1528139764265};\\\", \\\"{x:1456,y:941,t:1528139764283};\\\", \\\"{x:1457,y:942,t:1528139764299};\\\", \\\"{x:1460,y:946,t:1528139764316};\\\", \\\"{x:1460,y:947,t:1528139764333};\\\", \\\"{x:1460,y:949,t:1528139764356};\\\", \\\"{x:1462,y:950,t:1528139764371};\\\", \\\"{x:1462,y:952,t:1528139764383};\\\", \\\"{x:1462,y:955,t:1528139764399};\\\", \\\"{x:1463,y:962,t:1528139764416};\\\", \\\"{x:1463,y:968,t:1528139764433};\\\", \\\"{x:1464,y:971,t:1528139764449};\\\", \\\"{x:1464,y:973,t:1528139764466};\\\", \\\"{x:1465,y:973,t:1528139764483};\\\", \\\"{x:1466,y:973,t:1528139764588};\\\", \\\"{x:1468,y:973,t:1528139764599};\\\", \\\"{x:1473,y:972,t:1528139764616};\\\", \\\"{x:1481,y:970,t:1528139764634};\\\", \\\"{x:1489,y:967,t:1528139764650};\\\", \\\"{x:1494,y:963,t:1528139764666};\\\", \\\"{x:1497,y:963,t:1528139764683};\\\", \\\"{x:1498,y:962,t:1528139764701};\\\", \\\"{x:1498,y:963,t:1528139764973};\\\", \\\"{x:1501,y:965,t:1528139764984};\\\", \\\"{x:1503,y:969,t:1528139765000};\\\", \\\"{x:1506,y:972,t:1528139765016};\\\", \\\"{x:1508,y:974,t:1528139765033};\\\", \\\"{x:1510,y:975,t:1528139765049};\\\", \\\"{x:1511,y:975,t:1528139765092};\\\", \\\"{x:1514,y:975,t:1528139765100};\\\", \\\"{x:1520,y:975,t:1528139765117};\\\", \\\"{x:1531,y:975,t:1528139765133};\\\", \\\"{x:1542,y:975,t:1528139765150};\\\", \\\"{x:1550,y:973,t:1528139765167};\\\", \\\"{x:1553,y:972,t:1528139765183};\\\", \\\"{x:1555,y:969,t:1528139765200};\\\", \\\"{x:1556,y:967,t:1528139765217};\\\", \\\"{x:1556,y:966,t:1528139765233};\\\", \\\"{x:1557,y:963,t:1528139765250};\\\", \\\"{x:1557,y:961,t:1528139765268};\\\", \\\"{x:1557,y:960,t:1528139765283};\\\", \\\"{x:1557,y:959,t:1528139765300};\\\", \\\"{x:1557,y:958,t:1528139765357};\\\", \\\"{x:1555,y:958,t:1528139765380};\\\", \\\"{x:1554,y:958,t:1528139765405};\\\", \\\"{x:1553,y:958,t:1528139765418};\\\", \\\"{x:1552,y:959,t:1528139765435};\\\", \\\"{x:1551,y:960,t:1528139765450};\\\", \\\"{x:1551,y:962,t:1528139765467};\\\", \\\"{x:1551,y:965,t:1528139765484};\\\", \\\"{x:1551,y:968,t:1528139765500};\\\", \\\"{x:1551,y:969,t:1528139765517};\\\", \\\"{x:1551,y:971,t:1528139765535};\\\", \\\"{x:1551,y:972,t:1528139765550};\\\", \\\"{x:1551,y:973,t:1528139765567};\\\", \\\"{x:1551,y:974,t:1528139765584};\\\", \\\"{x:1553,y:975,t:1528139765600};\\\", \\\"{x:1554,y:976,t:1528139765620};\\\", \\\"{x:1556,y:977,t:1528139765636};\\\", \\\"{x:1558,y:978,t:1528139765652};\\\", \\\"{x:1560,y:978,t:1528139765668};\\\", \\\"{x:1567,y:978,t:1528139765684};\\\", \\\"{x:1573,y:978,t:1528139765702};\\\", \\\"{x:1579,y:978,t:1528139765717};\\\", \\\"{x:1584,y:978,t:1528139765734};\\\", \\\"{x:1592,y:978,t:1528139765751};\\\", \\\"{x:1596,y:977,t:1528139765768};\\\", \\\"{x:1601,y:975,t:1528139765784};\\\", \\\"{x:1606,y:973,t:1528139765801};\\\", \\\"{x:1607,y:972,t:1528139765817};\\\", \\\"{x:1608,y:971,t:1528139765834};\\\", \\\"{x:1610,y:970,t:1528139765851};\\\", \\\"{x:1610,y:969,t:1528139765867};\\\", \\\"{x:1611,y:967,t:1528139765884};\\\", \\\"{x:1612,y:966,t:1528139765902};\\\", \\\"{x:1612,y:964,t:1528139765917};\\\", \\\"{x:1613,y:963,t:1528139765935};\\\", \\\"{x:1614,y:962,t:1528139765965};\\\", \\\"{x:1614,y:961,t:1528139766029};\\\", \\\"{x:1614,y:960,t:1528139766085};\\\", \\\"{x:1615,y:959,t:1528139766109};\\\", \\\"{x:1616,y:958,t:1528139766252};\\\", \\\"{x:1616,y:957,t:1528139766725};\\\", \\\"{x:1617,y:956,t:1528139766741};\\\", \\\"{x:1618,y:956,t:1528139766860};\\\", \\\"{x:1619,y:955,t:1528139767108};\\\", \\\"{x:1618,y:955,t:1528139767372};\\\", \\\"{x:1617,y:955,t:1528139767404};\\\", \\\"{x:1616,y:955,t:1528139767420};\\\", \\\"{x:1613,y:955,t:1528139767435};\\\", \\\"{x:1608,y:955,t:1528139767452};\\\", \\\"{x:1602,y:955,t:1528139767470};\\\", \\\"{x:1598,y:955,t:1528139767486};\\\", \\\"{x:1593,y:955,t:1528139767502};\\\", \\\"{x:1589,y:955,t:1528139767520};\\\", \\\"{x:1584,y:955,t:1528139767535};\\\", \\\"{x:1582,y:955,t:1528139767552};\\\", \\\"{x:1579,y:955,t:1528139767569};\\\", \\\"{x:1576,y:955,t:1528139767585};\\\", \\\"{x:1572,y:952,t:1528139767601};\\\", \\\"{x:1569,y:951,t:1528139767619};\\\", \\\"{x:1561,y:948,t:1528139767635};\\\", \\\"{x:1559,y:946,t:1528139767652};\\\", \\\"{x:1557,y:943,t:1528139767669};\\\", \\\"{x:1552,y:937,t:1528139767686};\\\", \\\"{x:1550,y:931,t:1528139767702};\\\", \\\"{x:1547,y:925,t:1528139767719};\\\", \\\"{x:1543,y:917,t:1528139767736};\\\", \\\"{x:1541,y:913,t:1528139767752};\\\", \\\"{x:1539,y:907,t:1528139767769};\\\", \\\"{x:1538,y:902,t:1528139767786};\\\", \\\"{x:1537,y:896,t:1528139767802};\\\", \\\"{x:1537,y:891,t:1528139767820};\\\", \\\"{x:1533,y:880,t:1528139767835};\\\", \\\"{x:1532,y:874,t:1528139767852};\\\", \\\"{x:1531,y:866,t:1528139767869};\\\", \\\"{x:1526,y:851,t:1528139767887};\\\", \\\"{x:1523,y:841,t:1528139767902};\\\", \\\"{x:1522,y:837,t:1528139767919};\\\", \\\"{x:1522,y:833,t:1528139767936};\\\", \\\"{x:1520,y:828,t:1528139767953};\\\", \\\"{x:1520,y:824,t:1528139767970};\\\", \\\"{x:1519,y:818,t:1528139767986};\\\", \\\"{x:1518,y:814,t:1528139768003};\\\", \\\"{x:1518,y:810,t:1528139768019};\\\", \\\"{x:1518,y:806,t:1528139768035};\\\", \\\"{x:1518,y:803,t:1528139768053};\\\", \\\"{x:1518,y:800,t:1528139768069};\\\", \\\"{x:1518,y:797,t:1528139768087};\\\", \\\"{x:1518,y:795,t:1528139768103};\\\", \\\"{x:1518,y:794,t:1528139768119};\\\", \\\"{x:1518,y:791,t:1528139768136};\\\", \\\"{x:1518,y:790,t:1528139768153};\\\", \\\"{x:1518,y:788,t:1528139768169};\\\", \\\"{x:1519,y:787,t:1528139768186};\\\", \\\"{x:1519,y:784,t:1528139768203};\\\", \\\"{x:1520,y:781,t:1528139768220};\\\", \\\"{x:1520,y:777,t:1528139768236};\\\", \\\"{x:1520,y:775,t:1528139768253};\\\", \\\"{x:1520,y:774,t:1528139768269};\\\", \\\"{x:1520,y:773,t:1528139768293};\\\", \\\"{x:1520,y:772,t:1528139768308};\\\", \\\"{x:1521,y:771,t:1528139768341};\\\", \\\"{x:1521,y:770,t:1528139768893};\\\", \\\"{x:1521,y:769,t:1528139768908};\\\", \\\"{x:1520,y:769,t:1528139768924};\\\", \\\"{x:1519,y:769,t:1528139768948};\\\", \\\"{x:1518,y:769,t:1528139768989};\\\", \\\"{x:1517,y:769,t:1528139769004};\\\", \\\"{x:1516,y:769,t:1528139769021};\\\", \\\"{x:1515,y:769,t:1528139769037};\\\", \\\"{x:1513,y:770,t:1528139769053};\\\", \\\"{x:1512,y:771,t:1528139769070};\\\", \\\"{x:1511,y:772,t:1528139769107};\\\", \\\"{x:1511,y:773,t:1528139769131};\\\", \\\"{x:1510,y:773,t:1528139769155};\\\", \\\"{x:1509,y:773,t:1528139769285};\\\", \\\"{x:1508,y:773,t:1528139769292};\\\", \\\"{x:1507,y:773,t:1528139769305};\\\", \\\"{x:1503,y:773,t:1528139769320};\\\", \\\"{x:1495,y:773,t:1528139769338};\\\", \\\"{x:1480,y:773,t:1528139769355};\\\", \\\"{x:1455,y:773,t:1528139769371};\\\", \\\"{x:1427,y:772,t:1528139769387};\\\", \\\"{x:1363,y:764,t:1528139769404};\\\", \\\"{x:1299,y:755,t:1528139769420};\\\", \\\"{x:1215,y:742,t:1528139769438};\\\", \\\"{x:1123,y:729,t:1528139769454};\\\", \\\"{x:1035,y:717,t:1528139769470};\\\", \\\"{x:931,y:700,t:1528139769488};\\\", \\\"{x:851,y:679,t:1528139769504};\\\", \\\"{x:793,y:662,t:1528139769521};\\\", \\\"{x:746,y:650,t:1528139769537};\\\", \\\"{x:722,y:643,t:1528139769554};\\\", \\\"{x:708,y:640,t:1528139769571};\\\", \\\"{x:698,y:639,t:1528139769587};\\\", \\\"{x:686,y:638,t:1528139769604};\\\", \\\"{x:680,y:637,t:1528139769621};\\\", \\\"{x:673,y:636,t:1528139769637};\\\", \\\"{x:669,y:635,t:1528139769655};\\\", \\\"{x:661,y:633,t:1528139769671};\\\", \\\"{x:653,y:630,t:1528139769689};\\\", \\\"{x:647,y:626,t:1528139769705};\\\", \\\"{x:638,y:621,t:1528139769721};\\\", \\\"{x:625,y:615,t:1528139769734};\\\", \\\"{x:611,y:604,t:1528139769750};\\\", \\\"{x:597,y:592,t:1528139769769};\\\", \\\"{x:586,y:583,t:1528139769784};\\\", \\\"{x:566,y:570,t:1528139769801};\\\", \\\"{x:550,y:559,t:1528139769819};\\\", \\\"{x:535,y:549,t:1528139769836};\\\", \\\"{x:532,y:547,t:1528139769852};\\\", \\\"{x:531,y:547,t:1528139769869};\\\", \\\"{x:534,y:545,t:1528139770044};\\\", \\\"{x:557,y:541,t:1528139770053};\\\", \\\"{x:643,y:534,t:1528139770071};\\\", \\\"{x:742,y:534,t:1528139770088};\\\", \\\"{x:795,y:534,t:1528139770102};\\\", \\\"{x:823,y:534,t:1528139770120};\\\", \\\"{x:829,y:534,t:1528139770137};\\\", \\\"{x:830,y:534,t:1528139770152};\\\", \\\"{x:831,y:533,t:1528139770267};\\\", \\\"{x:829,y:532,t:1528139770275};\\\", \\\"{x:825,y:531,t:1528139770286};\\\", \\\"{x:823,y:530,t:1528139770304};\\\", \\\"{x:822,y:530,t:1528139770348};\\\", \\\"{x:822,y:528,t:1528139770356};\\\", \\\"{x:825,y:523,t:1528139770371};\\\", \\\"{x:832,y:516,t:1528139770388};\\\", \\\"{x:835,y:513,t:1528139770403};\\\", \\\"{x:838,y:510,t:1528139770420};\\\", \\\"{x:838,y:508,t:1528139770437};\\\", \\\"{x:838,y:505,t:1528139770564};\\\", \\\"{x:838,y:504,t:1528139770580};\\\", \\\"{x:837,y:504,t:1528139771141};\\\", \\\"{x:832,y:504,t:1528139771154};\\\", \\\"{x:826,y:504,t:1528139771170};\\\", \\\"{x:823,y:504,t:1528139771188};\\\", \\\"{x:820,y:504,t:1528139771204};\\\", \\\"{x:816,y:504,t:1528139771220};\\\", \\\"{x:806,y:505,t:1528139771237};\\\", \\\"{x:787,y:508,t:1528139771254};\\\", \\\"{x:753,y:522,t:1528139771270};\\\", \\\"{x:707,y:532,t:1528139771288};\\\", \\\"{x:652,y:535,t:1528139771304};\\\", \\\"{x:600,y:529,t:1528139771320};\\\", \\\"{x:533,y:499,t:1528139771337};\\\", \\\"{x:497,y:490,t:1528139771354};\\\", \\\"{x:428,y:464,t:1528139771371};\\\", \\\"{x:417,y:459,t:1528139771387};\\\", \\\"{x:389,y:447,t:1528139771404};\\\", \\\"{x:379,y:443,t:1528139771420};\\\", \\\"{x:377,y:442,t:1528139771437};\\\", \\\"{x:376,y:442,t:1528139771467};\\\", \\\"{x:375,y:442,t:1528139771475};\\\", \\\"{x:373,y:442,t:1528139771487};\\\", \\\"{x:369,y:444,t:1528139771504};\\\", \\\"{x:364,y:448,t:1528139771520};\\\", \\\"{x:359,y:451,t:1528139771537};\\\", \\\"{x:349,y:457,t:1528139771554};\\\", \\\"{x:335,y:466,t:1528139771570};\\\", \\\"{x:324,y:473,t:1528139771587};\\\", \\\"{x:304,y:485,t:1528139771603};\\\", \\\"{x:287,y:497,t:1528139771621};\\\", \\\"{x:265,y:512,t:1528139771638};\\\", \\\"{x:233,y:531,t:1528139771654};\\\", \\\"{x:207,y:545,t:1528139771670};\\\", \\\"{x:183,y:554,t:1528139771687};\\\", \\\"{x:162,y:562,t:1528139771705};\\\", \\\"{x:142,y:572,t:1528139771722};\\\", \\\"{x:129,y:577,t:1528139771738};\\\", \\\"{x:122,y:581,t:1528139771754};\\\", \\\"{x:117,y:583,t:1528139771771};\\\", \\\"{x:115,y:585,t:1528139771787};\\\", \\\"{x:118,y:585,t:1528139771941};\\\", \\\"{x:129,y:584,t:1528139771956};\\\", \\\"{x:162,y:577,t:1528139771973};\\\", \\\"{x:183,y:575,t:1528139771989};\\\", \\\"{x:205,y:571,t:1528139772004};\\\", \\\"{x:229,y:567,t:1528139772021};\\\", \\\"{x:255,y:565,t:1528139772038};\\\", \\\"{x:278,y:560,t:1528139772054};\\\", \\\"{x:307,y:559,t:1528139772071};\\\", \\\"{x:340,y:554,t:1528139772088};\\\", \\\"{x:378,y:551,t:1528139772104};\\\", \\\"{x:409,y:548,t:1528139772121};\\\", \\\"{x:435,y:543,t:1528139772139};\\\", \\\"{x:453,y:540,t:1528139772155};\\\", \\\"{x:466,y:538,t:1528139772171};\\\", \\\"{x:474,y:537,t:1528139772187};\\\", \\\"{x:482,y:537,t:1528139772205};\\\", \\\"{x:494,y:537,t:1528139772221};\\\", \\\"{x:506,y:537,t:1528139772239};\\\", \\\"{x:514,y:536,t:1528139772255};\\\", \\\"{x:531,y:535,t:1528139772271};\\\", \\\"{x:553,y:535,t:1528139772288};\\\", \\\"{x:578,y:535,t:1528139772305};\\\", \\\"{x:603,y:541,t:1528139772322};\\\", \\\"{x:632,y:549,t:1528139772339};\\\", \\\"{x:672,y:561,t:1528139772356};\\\", \\\"{x:689,y:568,t:1528139772371};\\\", \\\"{x:734,y:580,t:1528139772388};\\\", \\\"{x:758,y:587,t:1528139772405};\\\", \\\"{x:772,y:591,t:1528139772421};\\\", \\\"{x:776,y:592,t:1528139772438};\\\", \\\"{x:777,y:593,t:1528139772459};\\\", \\\"{x:777,y:595,t:1528139772477};\\\", \\\"{x:774,y:595,t:1528139772488};\\\", \\\"{x:767,y:594,t:1528139772505};\\\", \\\"{x:756,y:590,t:1528139772522};\\\", \\\"{x:746,y:589,t:1528139772539};\\\", \\\"{x:733,y:589,t:1528139772556};\\\", \\\"{x:729,y:589,t:1528139772571};\\\", \\\"{x:727,y:589,t:1528139772588};\\\", \\\"{x:726,y:590,t:1528139772605};\\\", \\\"{x:724,y:590,t:1528139772623};\\\", \\\"{x:718,y:591,t:1528139772639};\\\", \\\"{x:711,y:591,t:1528139772655};\\\", \\\"{x:704,y:591,t:1528139772671};\\\", \\\"{x:694,y:591,t:1528139772688};\\\", \\\"{x:681,y:591,t:1528139772706};\\\", \\\"{x:664,y:591,t:1528139772722};\\\", \\\"{x:659,y:591,t:1528139772737};\\\", \\\"{x:657,y:591,t:1528139772755};\\\", \\\"{x:656,y:591,t:1528139772771};\\\", \\\"{x:654,y:590,t:1528139772843};\\\", \\\"{x:652,y:590,t:1528139772859};\\\", \\\"{x:651,y:590,t:1528139772875};\\\", \\\"{x:650,y:589,t:1528139772888};\\\", \\\"{x:646,y:587,t:1528139772905};\\\", \\\"{x:642,y:585,t:1528139772922};\\\", \\\"{x:635,y:581,t:1528139772938};\\\", \\\"{x:629,y:577,t:1528139772956};\\\", \\\"{x:626,y:575,t:1528139772972};\\\", \\\"{x:624,y:575,t:1528139772988};\\\", \\\"{x:624,y:574,t:1528139773006};\\\", \\\"{x:626,y:574,t:1528139773572};\\\", \\\"{x:647,y:574,t:1528139773589};\\\", \\\"{x:677,y:574,t:1528139773606};\\\", \\\"{x:730,y:574,t:1528139773623};\\\", \\\"{x:791,y:574,t:1528139773639};\\\", \\\"{x:852,y:574,t:1528139773657};\\\", \\\"{x:914,y:566,t:1528139773672};\\\", \\\"{x:940,y:560,t:1528139773690};\\\", \\\"{x:943,y:557,t:1528139773706};\\\", \\\"{x:945,y:557,t:1528139773731};\\\", \\\"{x:947,y:557,t:1528139773820};\\\", \\\"{x:947,y:558,t:1528139773836};\\\", \\\"{x:947,y:559,t:1528139773844};\\\", \\\"{x:947,y:560,t:1528139773856};\\\", \\\"{x:943,y:563,t:1528139773874};\\\", \\\"{x:937,y:568,t:1528139773889};\\\", \\\"{x:926,y:572,t:1528139773906};\\\", \\\"{x:910,y:578,t:1528139773922};\\\", \\\"{x:900,y:580,t:1528139773939};\\\", \\\"{x:891,y:583,t:1528139773956};\\\", \\\"{x:888,y:584,t:1528139773971};\\\", \\\"{x:886,y:584,t:1528139774004};\\\", \\\"{x:885,y:584,t:1528139774020};\\\", \\\"{x:883,y:584,t:1528139774036};\\\", \\\"{x:881,y:584,t:1528139774044};\\\", \\\"{x:879,y:584,t:1528139774055};\\\", \\\"{x:877,y:582,t:1528139774071};\\\", \\\"{x:876,y:582,t:1528139774089};\\\", \\\"{x:875,y:581,t:1528139774105};\\\", \\\"{x:873,y:581,t:1528139774121};\\\", \\\"{x:870,y:581,t:1528139774139};\\\", \\\"{x:866,y:581,t:1528139774156};\\\", \\\"{x:862,y:581,t:1528139774171};\\\", \\\"{x:859,y:581,t:1528139774190};\\\", \\\"{x:858,y:581,t:1528139774206};\\\", \\\"{x:857,y:581,t:1528139774224};\\\", \\\"{x:856,y:581,t:1528139774251};\\\", \\\"{x:855,y:580,t:1528139774268};\\\", \\\"{x:854,y:579,t:1528139774284};\\\", \\\"{x:855,y:579,t:1528139774708};\\\", \\\"{x:861,y:581,t:1528139774723};\\\", \\\"{x:903,y:606,t:1528139774743};\\\", \\\"{x:950,y:633,t:1528139774757};\\\", \\\"{x:1017,y:666,t:1528139774774};\\\", \\\"{x:1093,y:709,t:1528139774791};\\\", \\\"{x:1179,y:765,t:1528139774807};\\\", \\\"{x:1270,y:826,t:1528139774823};\\\", \\\"{x:1359,y:885,t:1528139774840};\\\", \\\"{x:1446,y:934,t:1528139774857};\\\", \\\"{x:1520,y:980,t:1528139774873};\\\", \\\"{x:1562,y:1004,t:1528139774890};\\\", \\\"{x:1598,y:1027,t:1528139774908};\\\", \\\"{x:1608,y:1032,t:1528139774923};\\\", \\\"{x:1610,y:1033,t:1528139774940};\\\", \\\"{x:1607,y:1033,t:1528139775165};\\\", \\\"{x:1605,y:1031,t:1528139775173};\\\", \\\"{x:1603,y:1030,t:1528139775183};\\\", \\\"{x:1597,y:1028,t:1528139775199};\\\", \\\"{x:1586,y:1027,t:1528139775216};\\\", \\\"{x:1581,y:1026,t:1528139775233};\\\", \\\"{x:1575,y:1025,t:1528139775249};\\\", \\\"{x:1568,y:1023,t:1528139775266};\\\", \\\"{x:1561,y:1022,t:1528139775283};\\\", \\\"{x:1556,y:1021,t:1528139775299};\\\", \\\"{x:1551,y:1020,t:1528139775316};\\\", \\\"{x:1549,y:1020,t:1528139775333};\\\", \\\"{x:1548,y:1020,t:1528139775349};\\\", \\\"{x:1545,y:1019,t:1528139775366};\\\", \\\"{x:1541,y:1019,t:1528139775383};\\\", \\\"{x:1538,y:1019,t:1528139775399};\\\", \\\"{x:1532,y:1019,t:1528139775417};\\\", \\\"{x:1525,y:1016,t:1528139775434};\\\", \\\"{x:1515,y:1015,t:1528139775449};\\\", \\\"{x:1501,y:1014,t:1528139775467};\\\", \\\"{x:1492,y:1014,t:1528139775484};\\\", \\\"{x:1488,y:1014,t:1528139775499};\\\", \\\"{x:1480,y:1014,t:1528139775517};\\\", \\\"{x:1478,y:1014,t:1528139775533};\\\", \\\"{x:1477,y:1014,t:1528139775556};\\\", \\\"{x:1476,y:1014,t:1528139775573};\\\", \\\"{x:1475,y:1014,t:1528139775584};\\\", \\\"{x:1471,y:1011,t:1528139775604};\\\", \\\"{x:1463,y:1007,t:1528139775616};\\\", \\\"{x:1444,y:994,t:1528139775633};\\\", \\\"{x:1425,y:976,t:1528139775651};\\\", \\\"{x:1408,y:962,t:1528139775667};\\\", \\\"{x:1402,y:957,t:1528139775683};\\\", \\\"{x:1401,y:956,t:1528139775701};\\\", \\\"{x:1400,y:955,t:1528139775717};\\\", \\\"{x:1400,y:954,t:1528139775861};\\\", \\\"{x:1400,y:953,t:1528139775869};\\\", \\\"{x:1400,y:951,t:1528139775884};\\\", \\\"{x:1404,y:949,t:1528139775901};\\\", \\\"{x:1409,y:947,t:1528139775917};\\\", \\\"{x:1419,y:946,t:1528139775934};\\\", \\\"{x:1428,y:944,t:1528139775951};\\\", \\\"{x:1436,y:942,t:1528139775967};\\\", \\\"{x:1449,y:941,t:1528139775984};\\\", \\\"{x:1455,y:939,t:1528139776001};\\\", \\\"{x:1458,y:939,t:1528139776016};\\\", \\\"{x:1459,y:941,t:1528139776157};\\\", \\\"{x:1459,y:943,t:1528139776166};\\\", \\\"{x:1455,y:950,t:1528139776183};\\\", \\\"{x:1452,y:954,t:1528139776201};\\\", \\\"{x:1451,y:955,t:1528139776217};\\\", \\\"{x:1451,y:957,t:1528139776237};\\\", \\\"{x:1450,y:957,t:1528139776325};\\\", \\\"{x:1449,y:957,t:1528139776341};\\\", \\\"{x:1447,y:957,t:1528139776350};\\\", \\\"{x:1445,y:956,t:1528139776368};\\\", \\\"{x:1443,y:956,t:1528139776384};\\\", \\\"{x:1442,y:955,t:1528139776400};\\\", \\\"{x:1441,y:954,t:1528139776533};\\\", \\\"{x:1441,y:949,t:1528139776573};\\\", \\\"{x:1444,y:944,t:1528139776585};\\\", \\\"{x:1447,y:938,t:1528139776600};\\\", \\\"{x:1451,y:931,t:1528139776618};\\\", \\\"{x:1457,y:920,t:1528139776634};\\\", \\\"{x:1463,y:912,t:1528139776650};\\\", \\\"{x:1465,y:906,t:1528139776667};\\\", \\\"{x:1466,y:900,t:1528139776684};\\\", \\\"{x:1467,y:896,t:1528139776701};\\\", \\\"{x:1468,y:891,t:1528139776718};\\\", \\\"{x:1468,y:885,t:1528139776734};\\\", \\\"{x:1468,y:880,t:1528139776750};\\\", \\\"{x:1468,y:874,t:1528139776767};\\\", \\\"{x:1468,y:870,t:1528139776785};\\\", \\\"{x:1468,y:869,t:1528139776800};\\\", \\\"{x:1468,y:866,t:1528139776817};\\\", \\\"{x:1468,y:863,t:1528139776835};\\\", \\\"{x:1468,y:862,t:1528139776851};\\\", \\\"{x:1468,y:861,t:1528139776877};\\\", \\\"{x:1468,y:869,t:1528139776981};\\\", \\\"{x:1468,y:874,t:1528139776989};\\\", \\\"{x:1468,y:879,t:1528139777002};\\\", \\\"{x:1464,y:888,t:1528139777017};\\\", \\\"{x:1463,y:901,t:1528139777034};\\\", \\\"{x:1463,y:912,t:1528139777051};\\\", \\\"{x:1465,y:922,t:1528139777068};\\\", \\\"{x:1467,y:927,t:1528139777085};\\\", \\\"{x:1467,y:931,t:1528139777101};\\\", \\\"{x:1467,y:936,t:1528139777118};\\\", \\\"{x:1467,y:938,t:1528139777135};\\\", \\\"{x:1467,y:941,t:1528139777152};\\\", \\\"{x:1467,y:942,t:1528139777173};\\\", \\\"{x:1467,y:944,t:1528139777197};\\\", \\\"{x:1467,y:945,t:1528139777205};\\\", \\\"{x:1467,y:946,t:1528139777218};\\\", \\\"{x:1467,y:947,t:1528139777234};\\\", \\\"{x:1467,y:950,t:1528139777252};\\\", \\\"{x:1467,y:951,t:1528139777268};\\\", \\\"{x:1467,y:953,t:1528139777285};\\\", \\\"{x:1469,y:954,t:1528139777405};\\\", \\\"{x:1473,y:956,t:1528139777418};\\\", \\\"{x:1485,y:961,t:1528139777435};\\\", \\\"{x:1491,y:963,t:1528139777452};\\\", \\\"{x:1500,y:963,t:1528139777469};\\\", \\\"{x:1506,y:964,t:1528139777485};\\\", \\\"{x:1514,y:964,t:1528139777501};\\\", \\\"{x:1521,y:964,t:1528139777519};\\\", \\\"{x:1528,y:962,t:1528139777535};\\\", \\\"{x:1532,y:957,t:1528139777551};\\\", \\\"{x:1537,y:951,t:1528139777569};\\\", \\\"{x:1541,y:946,t:1528139777585};\\\", \\\"{x:1545,y:943,t:1528139777601};\\\", \\\"{x:1546,y:943,t:1528139777764};\\\", \\\"{x:1547,y:943,t:1528139777796};\\\", \\\"{x:1548,y:943,t:1528139777852};\\\", \\\"{x:1548,y:944,t:1528139777876};\\\", \\\"{x:1548,y:945,t:1528139777885};\\\", \\\"{x:1548,y:947,t:1528139777908};\\\", \\\"{x:1547,y:947,t:1528139777918};\\\", \\\"{x:1543,y:950,t:1528139777935};\\\", \\\"{x:1535,y:952,t:1528139777951};\\\", \\\"{x:1531,y:955,t:1528139777968};\\\", \\\"{x:1527,y:958,t:1528139777986};\\\", \\\"{x:1524,y:962,t:1528139778001};\\\", \\\"{x:1523,y:962,t:1528139778018};\\\", \\\"{x:1520,y:964,t:1528139778036};\\\", \\\"{x:1519,y:964,t:1528139778052};\\\", \\\"{x:1514,y:968,t:1528139778068};\\\", \\\"{x:1512,y:969,t:1528139778086};\\\", \\\"{x:1510,y:971,t:1528139778101};\\\", \\\"{x:1508,y:972,t:1528139778119};\\\", \\\"{x:1504,y:974,t:1528139778136};\\\", \\\"{x:1499,y:975,t:1528139778152};\\\", \\\"{x:1491,y:976,t:1528139778169};\\\", \\\"{x:1482,y:976,t:1528139778186};\\\", \\\"{x:1471,y:976,t:1528139778201};\\\", \\\"{x:1456,y:976,t:1528139778219};\\\", \\\"{x:1446,y:978,t:1528139778236};\\\", \\\"{x:1441,y:978,t:1528139778252};\\\", \\\"{x:1431,y:977,t:1528139778269};\\\", \\\"{x:1427,y:975,t:1528139778285};\\\", \\\"{x:1426,y:974,t:1528139778303};\\\", \\\"{x:1431,y:975,t:1528139778357};\\\", \\\"{x:1432,y:976,t:1528139778368};\\\", \\\"{x:1437,y:979,t:1528139778386};\\\", \\\"{x:1441,y:981,t:1528139778403};\\\", \\\"{x:1442,y:983,t:1528139778418};\\\", \\\"{x:1443,y:984,t:1528139778436};\\\", \\\"{x:1445,y:984,t:1528139778453};\\\", \\\"{x:1458,y:981,t:1528139778468};\\\", \\\"{x:1470,y:976,t:1528139778486};\\\", \\\"{x:1480,y:970,t:1528139778502};\\\", \\\"{x:1487,y:966,t:1528139778519};\\\", \\\"{x:1494,y:962,t:1528139778536};\\\", \\\"{x:1495,y:962,t:1528139778552};\\\", \\\"{x:1497,y:961,t:1528139778569};\\\", \\\"{x:1496,y:961,t:1528139778973};\\\", \\\"{x:1495,y:961,t:1528139778997};\\\", \\\"{x:1494,y:962,t:1528139779013};\\\", \\\"{x:1493,y:963,t:1528139779029};\\\", \\\"{x:1493,y:965,t:1528139779206};\\\", \\\"{x:1493,y:966,t:1528139779221};\\\", \\\"{x:1494,y:968,t:1528139779237};\\\", \\\"{x:1495,y:970,t:1528139779253};\\\", \\\"{x:1498,y:972,t:1528139779269};\\\", \\\"{x:1502,y:974,t:1528139779287};\\\", \\\"{x:1506,y:976,t:1528139779303};\\\", \\\"{x:1512,y:980,t:1528139779319};\\\", \\\"{x:1517,y:980,t:1528139779336};\\\", \\\"{x:1520,y:980,t:1528139779352};\\\", \\\"{x:1523,y:980,t:1528139779370};\\\", \\\"{x:1525,y:980,t:1528139779386};\\\", \\\"{x:1527,y:980,t:1528139779403};\\\", \\\"{x:1528,y:980,t:1528139779420};\\\", \\\"{x:1531,y:979,t:1528139779437};\\\", \\\"{x:1534,y:978,t:1528139779452};\\\", \\\"{x:1535,y:976,t:1528139779470};\\\", \\\"{x:1537,y:976,t:1528139779486};\\\", \\\"{x:1537,y:975,t:1528139779503};\\\", \\\"{x:1538,y:975,t:1528139779533};\\\", \\\"{x:1540,y:974,t:1528139779556};\\\", \\\"{x:1541,y:974,t:1528139779569};\\\", \\\"{x:1541,y:973,t:1528139779588};\\\", \\\"{x:1542,y:972,t:1528139779916};\\\", \\\"{x:1543,y:972,t:1528139779933};\\\", \\\"{x:1544,y:972,t:1528139779965};\\\", \\\"{x:1546,y:972,t:1528139779973};\\\", \\\"{x:1548,y:973,t:1528139779986};\\\", \\\"{x:1551,y:975,t:1528139780003};\\\", \\\"{x:1554,y:976,t:1528139780021};\\\", \\\"{x:1555,y:976,t:1528139780052};\\\", \\\"{x:1556,y:976,t:1528139780077};\\\", \\\"{x:1558,y:977,t:1528139780092};\\\", \\\"{x:1559,y:977,t:1528139780117};\\\", \\\"{x:1561,y:977,t:1528139780124};\\\", \\\"{x:1563,y:977,t:1528139780141};\\\", \\\"{x:1566,y:977,t:1528139780153};\\\", \\\"{x:1570,y:976,t:1528139780171};\\\", \\\"{x:1580,y:971,t:1528139780186};\\\", \\\"{x:1592,y:963,t:1528139780204};\\\", \\\"{x:1606,y:949,t:1528139780221};\\\", \\\"{x:1611,y:942,t:1528139780236};\\\", \\\"{x:1616,y:936,t:1528139780253};\\\", \\\"{x:1619,y:935,t:1528139780270};\\\", \\\"{x:1621,y:934,t:1528139780287};\\\", \\\"{x:1622,y:934,t:1528139780304};\\\", \\\"{x:1618,y:934,t:1528139780413};\\\", \\\"{x:1612,y:933,t:1528139780421};\\\", \\\"{x:1595,y:931,t:1528139780437};\\\", \\\"{x:1566,y:925,t:1528139780453};\\\", \\\"{x:1516,y:919,t:1528139780470};\\\", \\\"{x:1459,y:916,t:1528139780488};\\\", \\\"{x:1398,y:907,t:1528139780503};\\\", \\\"{x:1341,y:898,t:1528139780520};\\\", \\\"{x:1271,y:885,t:1528139780538};\\\", \\\"{x:1187,y:872,t:1528139780554};\\\", \\\"{x:1096,y:845,t:1528139780571};\\\", \\\"{x:996,y:815,t:1528139780588};\\\", \\\"{x:877,y:779,t:1528139780604};\\\", \\\"{x:677,y:714,t:1528139780620};\\\", \\\"{x:549,y:674,t:1528139780638};\\\", \\\"{x:440,y:637,t:1528139780654};\\\", \\\"{x:355,y:604,t:1528139780675};\\\", \\\"{x:308,y:582,t:1528139780688};\\\", \\\"{x:281,y:571,t:1528139780703};\\\", \\\"{x:277,y:569,t:1528139780720};\\\", \\\"{x:284,y:571,t:1528139780779};\\\", \\\"{x:291,y:574,t:1528139780788};\\\", \\\"{x:294,y:576,t:1528139780804};\\\", \\\"{x:302,y:587,t:1528139780820};\\\", \\\"{x:315,y:605,t:1528139780838};\\\", \\\"{x:325,y:621,t:1528139780854};\\\", \\\"{x:331,y:628,t:1528139780870};\\\", \\\"{x:334,y:631,t:1528139780887};\\\", \\\"{x:335,y:634,t:1528139780905};\\\", \\\"{x:338,y:638,t:1528139780922};\\\", \\\"{x:340,y:642,t:1528139780937};\\\", \\\"{x:341,y:643,t:1528139780954};\\\", \\\"{x:341,y:645,t:1528139780970};\\\", \\\"{x:344,y:650,t:1528139780987};\\\", \\\"{x:346,y:656,t:1528139781004};\\\", \\\"{x:349,y:661,t:1528139781021};\\\", \\\"{x:350,y:663,t:1528139781037};\\\", \\\"{x:352,y:665,t:1528139781054};\\\", \\\"{x:354,y:667,t:1528139781071};\\\", \\\"{x:356,y:669,t:1528139781087};\\\", \\\"{x:358,y:670,t:1528139781105};\\\", \\\"{x:361,y:671,t:1528139781121};\\\", \\\"{x:364,y:673,t:1528139781137};\\\", \\\"{x:365,y:674,t:1528139781154};\\\", \\\"{x:372,y:677,t:1528139781171};\\\", \\\"{x:376,y:680,t:1528139781187};\\\", \\\"{x:382,y:684,t:1528139781204};\\\", \\\"{x:384,y:685,t:1528139781221};\\\", \\\"{x:387,y:688,t:1528139781237};\\\", \\\"{x:388,y:688,t:1528139781333};\\\", \\\"{x:390,y:688,t:1528139781350};\\\", \\\"{x:391,y:689,t:1528139781356};\\\", \\\"{x:394,y:689,t:1528139781371};\\\", \\\"{x:408,y:695,t:1528139781388};\\\", \\\"{x:420,y:699,t:1528139781404};\\\", \\\"{x:433,y:705,t:1528139781422};\\\", \\\"{x:448,y:712,t:1528139781438};\\\", \\\"{x:459,y:717,t:1528139781455};\\\", \\\"{x:468,y:720,t:1528139781473};\\\", \\\"{x:473,y:724,t:1528139781488};\\\", \\\"{x:475,y:725,t:1528139781505};\\\", \\\"{x:478,y:726,t:1528139781521};\\\", \\\"{x:479,y:726,t:1528139781537};\\\", \\\"{x:480,y:728,t:1528139781556};\\\", \\\"{x:481,y:728,t:1528139781572};\\\", \\\"{x:483,y:730,t:1528139781587};\\\", \\\"{x:486,y:734,t:1528139781604};\\\", \\\"{x:488,y:735,t:1528139781621};\\\", \\\"{x:489,y:736,t:1528139781637};\\\", \\\"{x:490,y:737,t:1528139781700};\\\", \\\"{x:491,y:737,t:1528139782717};\\\", \\\"{x:493,y:737,t:1528139782732};\\\", \\\"{x:494,y:737,t:1528139782740};\\\", \\\"{x:495,y:737,t:1528139782804};\\\", \\\"{x:496,y:735,t:1528139782828};\\\", \\\"{x:498,y:734,t:1528139782971};\\\" ] }, { \\\"rt\\\": 37886, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 436820, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -10 AM-11 AM-12 PM-12 PM-01 PM-M -M -M -11 AM-12 PM-12 PM-01 PM-01 PM-02 PM-03 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:733,t:1528139783095};\\\", \\\"{x:500,y:733,t:1528139783124};\\\", \\\"{x:501,y:731,t:1528139783139};\\\", \\\"{x:506,y:721,t:1528139783155};\\\", \\\"{x:509,y:718,t:1528139783172};\\\", \\\"{x:513,y:715,t:1528139783189};\\\", \\\"{x:516,y:712,t:1528139783205};\\\", \\\"{x:522,y:708,t:1528139783222};\\\", \\\"{x:528,y:704,t:1528139783239};\\\", \\\"{x:544,y:695,t:1528139783266};\\\", \\\"{x:551,y:691,t:1528139783272};\\\", \\\"{x:564,y:684,t:1528139783289};\\\", \\\"{x:574,y:678,t:1528139783306};\\\", \\\"{x:578,y:677,t:1528139783322};\\\", \\\"{x:586,y:673,t:1528139783339};\\\", \\\"{x:599,y:668,t:1528139783356};\\\", \\\"{x:614,y:661,t:1528139783372};\\\", \\\"{x:628,y:654,t:1528139783390};\\\", \\\"{x:647,y:646,t:1528139783406};\\\", \\\"{x:671,y:632,t:1528139783422};\\\", \\\"{x:705,y:616,t:1528139783439};\\\", \\\"{x:753,y:594,t:1528139783456};\\\", \\\"{x:799,y:577,t:1528139783472};\\\", \\\"{x:1219,y:451,t:1528139783605};\\\", \\\"{x:1280,y:435,t:1528139783623};\\\", \\\"{x:1339,y:427,t:1528139783640};\\\", \\\"{x:1374,y:422,t:1528139783657};\\\", \\\"{x:1394,y:419,t:1528139783673};\\\", \\\"{x:1421,y:415,t:1528139783689};\\\", \\\"{x:1461,y:410,t:1528139783706};\\\", \\\"{x:1503,y:402,t:1528139783723};\\\", \\\"{x:1578,y:394,t:1528139783739};\\\", \\\"{x:1746,y:369,t:1528139783756};\\\", \\\"{x:1885,y:363,t:1528139783773};\\\", \\\"{x:1919,y:363,t:1528139783789};\\\", \\\"{x:1919,y:357,t:1528139783860};\\\", \\\"{x:1919,y:356,t:1528139783874};\\\", \\\"{x:1919,y:354,t:1528139783890};\\\", \\\"{x:1915,y:352,t:1528139784060};\\\", \\\"{x:1883,y:341,t:1528139784074};\\\", \\\"{x:1767,y:308,t:1528139784091};\\\", \\\"{x:1647,y:272,t:1528139784107};\\\", \\\"{x:1594,y:255,t:1528139784124};\\\", \\\"{x:1569,y:248,t:1528139784140};\\\", \\\"{x:1557,y:246,t:1528139784157};\\\", \\\"{x:1546,y:243,t:1528139784173};\\\", \\\"{x:1536,y:242,t:1528139784191};\\\", \\\"{x:1520,y:242,t:1528139784206};\\\", \\\"{x:1494,y:242,t:1528139784224};\\\", \\\"{x:1458,y:247,t:1528139784240};\\\", \\\"{x:1404,y:258,t:1528139784256};\\\", \\\"{x:1345,y:275,t:1528139784274};\\\", \\\"{x:1306,y:294,t:1528139784290};\\\", \\\"{x:1276,y:312,t:1528139784306};\\\", \\\"{x:1250,y:331,t:1528139784323};\\\", \\\"{x:1216,y:369,t:1528139784340};\\\", \\\"{x:1206,y:387,t:1528139784357};\\\", \\\"{x:1204,y:394,t:1528139784374};\\\", \\\"{x:1204,y:395,t:1528139785076};\\\", \\\"{x:1205,y:396,t:1528139785090};\\\", \\\"{x:1212,y:396,t:1528139785107};\\\", \\\"{x:1219,y:396,t:1528139785124};\\\", \\\"{x:1222,y:395,t:1528139785140};\\\", \\\"{x:1223,y:395,t:1528139785157};\\\", \\\"{x:1225,y:395,t:1528139785174};\\\", \\\"{x:1226,y:396,t:1528139785190};\\\", \\\"{x:1226,y:403,t:1528139785207};\\\", \\\"{x:1224,y:410,t:1528139785224};\\\", \\\"{x:1218,y:418,t:1528139785241};\\\", \\\"{x:1214,y:420,t:1528139785257};\\\", \\\"{x:1209,y:423,t:1528139785341};\\\", \\\"{x:1197,y:430,t:1528139785358};\\\", \\\"{x:1186,y:436,t:1528139785375};\\\", \\\"{x:1185,y:436,t:1528139785392};\\\", \\\"{x:1185,y:437,t:1528139785408};\\\", \\\"{x:1184,y:436,t:1528139785485};\\\", \\\"{x:1183,y:436,t:1528139785492};\\\", \\\"{x:1181,y:434,t:1528139785507};\\\", \\\"{x:1166,y:420,t:1528139785524};\\\", \\\"{x:1161,y:416,t:1528139785542};\\\", \\\"{x:1154,y:408,t:1528139785558};\\\", \\\"{x:1150,y:401,t:1528139785575};\\\", \\\"{x:1147,y:398,t:1528139785591};\\\", \\\"{x:1143,y:392,t:1528139785609};\\\", \\\"{x:1135,y:384,t:1528139785624};\\\", \\\"{x:1125,y:375,t:1528139785641};\\\", \\\"{x:1110,y:365,t:1528139785659};\\\", \\\"{x:1097,y:359,t:1528139785674};\\\", \\\"{x:1089,y:355,t:1528139785691};\\\", \\\"{x:1079,y:351,t:1528139785708};\\\", \\\"{x:1068,y:350,t:1528139785725};\\\", \\\"{x:1056,y:350,t:1528139785742};\\\", \\\"{x:1044,y:347,t:1528139785758};\\\", \\\"{x:1032,y:347,t:1528139785774};\\\", \\\"{x:1021,y:347,t:1528139785792};\\\", \\\"{x:1008,y:347,t:1528139785809};\\\", \\\"{x:1000,y:346,t:1528139785825};\\\", \\\"{x:994,y:345,t:1528139785842};\\\", \\\"{x:989,y:344,t:1528139785859};\\\", \\\"{x:985,y:343,t:1528139785875};\\\", \\\"{x:983,y:343,t:1528139785892};\\\", \\\"{x:982,y:342,t:1528139785909};\\\", \\\"{x:982,y:341,t:1528139786069};\\\", \\\"{x:979,y:337,t:1528139786076};\\\", \\\"{x:976,y:331,t:1528139786091};\\\", \\\"{x:972,y:323,t:1528139786109};\\\", \\\"{x:972,y:322,t:1528139786126};\\\", \\\"{x:973,y:321,t:1528139786245};\\\", \\\"{x:985,y:316,t:1528139786260};\\\", \\\"{x:1022,y:307,t:1528139786275};\\\", \\\"{x:1085,y:292,t:1528139786291};\\\", \\\"{x:1199,y:273,t:1528139786309};\\\", \\\"{x:1286,y:266,t:1528139786326};\\\", \\\"{x:1389,y:266,t:1528139786342};\\\", \\\"{x:1504,y:273,t:1528139786359};\\\", \\\"{x:1640,y:299,t:1528139786376};\\\", \\\"{x:1787,y:338,t:1528139786391};\\\", \\\"{x:1919,y:396,t:1528139786409};\\\", \\\"{x:1919,y:477,t:1528139786425};\\\", \\\"{x:1919,y:552,t:1528139786442};\\\", \\\"{x:1919,y:633,t:1528139786459};\\\", \\\"{x:1919,y:705,t:1528139786475};\\\", \\\"{x:1919,y:767,t:1528139786492};\\\", \\\"{x:1919,y:820,t:1528139786508};\\\", \\\"{x:1919,y:821,t:1528139786526};\\\", \\\"{x:1919,y:823,t:1528139786542};\\\", \\\"{x:1919,y:835,t:1528139786558};\\\", \\\"{x:1919,y:843,t:1528139786575};\\\", \\\"{x:1913,y:849,t:1528139786592};\\\", \\\"{x:1897,y:854,t:1528139786609};\\\", \\\"{x:1876,y:855,t:1528139786626};\\\", \\\"{x:1840,y:831,t:1528139786642};\\\", \\\"{x:1786,y:789,t:1528139786659};\\\", \\\"{x:1707,y:728,t:1528139786676};\\\", \\\"{x:1539,y:622,t:1528139786693};\\\", \\\"{x:1404,y:567,t:1528139786709};\\\", \\\"{x:1261,y:508,t:1528139786726};\\\", \\\"{x:1115,y:444,t:1528139786742};\\\", \\\"{x:930,y:360,t:1528139786758};\\\", \\\"{x:706,y:246,t:1528139786776};\\\", \\\"{x:480,y:141,t:1528139786792};\\\", \\\"{x:246,y:41,t:1528139786809};\\\", \\\"{x:0,y:0,t:1528139786826};\\\", \\\"{x:2,y:0,t:1528139789541};\\\", \\\"{x:22,y:0,t:1528139789549};\\\", \\\"{x:72,y:0,t:1528139789561};\\\", \\\"{x:210,y:16,t:1528139789578};\\\", \\\"{x:365,y:40,t:1528139789596};\\\", \\\"{x:545,y:67,t:1528139789610};\\\", \\\"{x:683,y:101,t:1528139789628};\\\", \\\"{x:902,y:169,t:1528139789644};\\\", \\\"{x:1084,y:224,t:1528139789663};\\\", \\\"{x:1265,y:292,t:1528139789678};\\\", \\\"{x:1445,y:349,t:1528139789695};\\\", \\\"{x:1605,y:394,t:1528139789712};\\\", \\\"{x:1749,y:438,t:1528139789728};\\\", \\\"{x:1859,y:479,t:1528139789745};\\\", \\\"{x:1919,y:519,t:1528139789762};\\\", \\\"{x:1919,y:566,t:1528139789778};\\\", \\\"{x:1919,y:605,t:1528139789794};\\\", \\\"{x:1919,y:644,t:1528139789810};\\\", \\\"{x:1919,y:670,t:1528139789827};\\\", \\\"{x:1919,y:736,t:1528139789843};\\\", \\\"{x:1919,y:794,t:1528139789861};\\\", \\\"{x:1919,y:835,t:1528139789877};\\\", \\\"{x:1919,y:879,t:1528139789894};\\\", \\\"{x:1919,y:901,t:1528139789911};\\\", \\\"{x:1919,y:914,t:1528139789927};\\\", \\\"{x:1919,y:920,t:1528139789945};\\\", \\\"{x:1919,y:927,t:1528139789960};\\\", \\\"{x:1919,y:930,t:1528139789977};\\\", \\\"{x:1919,y:940,t:1528139789995};\\\", \\\"{x:1919,y:956,t:1528139790011};\\\", \\\"{x:1913,y:980,t:1528139790028};\\\", \\\"{x:1898,y:1005,t:1528139790045};\\\", \\\"{x:1885,y:1020,t:1528139790061};\\\", \\\"{x:1871,y:1032,t:1528139790078};\\\", \\\"{x:1860,y:1039,t:1528139790095};\\\", \\\"{x:1849,y:1047,t:1528139790112};\\\", \\\"{x:1841,y:1051,t:1528139790129};\\\", \\\"{x:1834,y:1055,t:1528139790146};\\\", \\\"{x:1828,y:1057,t:1528139790162};\\\", \\\"{x:1825,y:1059,t:1528139790179};\\\", \\\"{x:1820,y:1061,t:1528139790195};\\\", \\\"{x:1813,y:1064,t:1528139790212};\\\", \\\"{x:1808,y:1068,t:1528139790229};\\\", \\\"{x:1802,y:1068,t:1528139790245};\\\", \\\"{x:1796,y:1070,t:1528139790262};\\\", \\\"{x:1787,y:1073,t:1528139790279};\\\", \\\"{x:1780,y:1074,t:1528139790295};\\\", \\\"{x:1770,y:1075,t:1528139790312};\\\", \\\"{x:1757,y:1075,t:1528139790328};\\\", \\\"{x:1739,y:1075,t:1528139790345};\\\", \\\"{x:1725,y:1075,t:1528139790362};\\\", \\\"{x:1705,y:1075,t:1528139790379};\\\", \\\"{x:1683,y:1075,t:1528139790395};\\\", \\\"{x:1660,y:1075,t:1528139790412};\\\", \\\"{x:1621,y:1075,t:1528139790428};\\\", \\\"{x:1592,y:1074,t:1528139790445};\\\", \\\"{x:1564,y:1069,t:1528139790462};\\\", \\\"{x:1540,y:1066,t:1528139790479};\\\", \\\"{x:1517,y:1058,t:1528139790495};\\\", \\\"{x:1497,y:1053,t:1528139790512};\\\", \\\"{x:1488,y:1052,t:1528139790529};\\\", \\\"{x:1483,y:1051,t:1528139790546};\\\", \\\"{x:1478,y:1051,t:1528139790562};\\\", \\\"{x:1476,y:1050,t:1528139790578};\\\", \\\"{x:1474,y:1050,t:1528139790643};\\\", \\\"{x:1473,y:1049,t:1528139790652};\\\", \\\"{x:1471,y:1048,t:1528139790667};\\\", \\\"{x:1471,y:1047,t:1528139790678};\\\", \\\"{x:1469,y:1046,t:1528139790695};\\\", \\\"{x:1467,y:1044,t:1528139790711};\\\", \\\"{x:1462,y:1039,t:1528139790728};\\\", \\\"{x:1456,y:1033,t:1528139790746};\\\", \\\"{x:1449,y:1025,t:1528139790761};\\\", \\\"{x:1443,y:1019,t:1528139790779};\\\", \\\"{x:1437,y:1014,t:1528139790795};\\\", \\\"{x:1432,y:1009,t:1528139790812};\\\", \\\"{x:1430,y:1007,t:1528139790829};\\\", \\\"{x:1426,y:1004,t:1528139790846};\\\", \\\"{x:1425,y:1002,t:1528139790862};\\\", \\\"{x:1424,y:1002,t:1528139791053};\\\", \\\"{x:1423,y:1001,t:1528139791068};\\\", \\\"{x:1420,y:1001,t:1528139791079};\\\", \\\"{x:1414,y:997,t:1528139791096};\\\", \\\"{x:1405,y:993,t:1528139791113};\\\", \\\"{x:1395,y:990,t:1528139791129};\\\", \\\"{x:1385,y:984,t:1528139791146};\\\", \\\"{x:1371,y:978,t:1528139791163};\\\", \\\"{x:1360,y:971,t:1528139791179};\\\", \\\"{x:1348,y:962,t:1528139791196};\\\", \\\"{x:1343,y:958,t:1528139791213};\\\", \\\"{x:1342,y:957,t:1528139791229};\\\", \\\"{x:1340,y:953,t:1528139791246};\\\", \\\"{x:1339,y:948,t:1528139791263};\\\", \\\"{x:1335,y:934,t:1528139791279};\\\", \\\"{x:1333,y:923,t:1528139791296};\\\", \\\"{x:1330,y:914,t:1528139791313};\\\", \\\"{x:1329,y:907,t:1528139791329};\\\", \\\"{x:1326,y:893,t:1528139791346};\\\", \\\"{x:1321,y:877,t:1528139791363};\\\", \\\"{x:1318,y:866,t:1528139791379};\\\", \\\"{x:1316,y:859,t:1528139791395};\\\", \\\"{x:1314,y:844,t:1528139791413};\\\", \\\"{x:1312,y:838,t:1528139791430};\\\", \\\"{x:1312,y:836,t:1528139791446};\\\", \\\"{x:1312,y:833,t:1528139791463};\\\", \\\"{x:1312,y:829,t:1528139791480};\\\", \\\"{x:1312,y:822,t:1528139791496};\\\", \\\"{x:1313,y:814,t:1528139791513};\\\", \\\"{x:1317,y:803,t:1528139791530};\\\", \\\"{x:1321,y:788,t:1528139791546};\\\", \\\"{x:1327,y:769,t:1528139791563};\\\", \\\"{x:1334,y:744,t:1528139791581};\\\", \\\"{x:1337,y:734,t:1528139791596};\\\", \\\"{x:1355,y:694,t:1528139791613};\\\", \\\"{x:1362,y:677,t:1528139791630};\\\", \\\"{x:1368,y:666,t:1528139791646};\\\", \\\"{x:1373,y:657,t:1528139791663};\\\", \\\"{x:1380,y:644,t:1528139791680};\\\", \\\"{x:1385,y:638,t:1528139791696};\\\", \\\"{x:1389,y:632,t:1528139791714};\\\", \\\"{x:1393,y:627,t:1528139791730};\\\", \\\"{x:1397,y:620,t:1528139791746};\\\", \\\"{x:1401,y:616,t:1528139791764};\\\", \\\"{x:1406,y:610,t:1528139791780};\\\", \\\"{x:1410,y:606,t:1528139791797};\\\", \\\"{x:1413,y:602,t:1528139791814};\\\", \\\"{x:1415,y:599,t:1528139791830};\\\", \\\"{x:1417,y:597,t:1528139791847};\\\", \\\"{x:1418,y:595,t:1528139791863};\\\", \\\"{x:1419,y:594,t:1528139791880};\\\", \\\"{x:1420,y:594,t:1528139791897};\\\", \\\"{x:1421,y:592,t:1528139791914};\\\", \\\"{x:1422,y:591,t:1528139791930};\\\", \\\"{x:1423,y:590,t:1528139791965};\\\", \\\"{x:1423,y:589,t:1528139792269};\\\", \\\"{x:1423,y:586,t:1528139792280};\\\", \\\"{x:1424,y:577,t:1528139792297};\\\", \\\"{x:1425,y:567,t:1528139792314};\\\", \\\"{x:1427,y:553,t:1528139792330};\\\", \\\"{x:1431,y:542,t:1528139792347};\\\", \\\"{x:1436,y:525,t:1528139792365};\\\", \\\"{x:1440,y:514,t:1528139792380};\\\", \\\"{x:1441,y:508,t:1528139792396};\\\", \\\"{x:1441,y:503,t:1528139792415};\\\", \\\"{x:1441,y:494,t:1528139792430};\\\", \\\"{x:1441,y:486,t:1528139792447};\\\", \\\"{x:1441,y:480,t:1528139792465};\\\", \\\"{x:1441,y:476,t:1528139792480};\\\", \\\"{x:1441,y:474,t:1528139792497};\\\", \\\"{x:1441,y:471,t:1528139792514};\\\", \\\"{x:1441,y:468,t:1528139792531};\\\", \\\"{x:1441,y:461,t:1528139792548};\\\", \\\"{x:1441,y:453,t:1528139792564};\\\", \\\"{x:1441,y:449,t:1528139792581};\\\", \\\"{x:1441,y:448,t:1528139792597};\\\", \\\"{x:1441,y:446,t:1528139792615};\\\", \\\"{x:1441,y:444,t:1528139792630};\\\", \\\"{x:1441,y:443,t:1528139792647};\\\", \\\"{x:1441,y:441,t:1528139792664};\\\", \\\"{x:1440,y:438,t:1528139792681};\\\", \\\"{x:1440,y:436,t:1528139792697};\\\", \\\"{x:1439,y:434,t:1528139792714};\\\", \\\"{x:1439,y:433,t:1528139792732};\\\", \\\"{x:1438,y:432,t:1528139792756};\\\", \\\"{x:1444,y:432,t:1528139793228};\\\", \\\"{x:1451,y:432,t:1528139793237};\\\", \\\"{x:1465,y:433,t:1528139793249};\\\", \\\"{x:1491,y:437,t:1528139793264};\\\", \\\"{x:1524,y:443,t:1528139793281};\\\", \\\"{x:1555,y:449,t:1528139793298};\\\", \\\"{x:1600,y:463,t:1528139793314};\\\", \\\"{x:1640,y:476,t:1528139793331};\\\", \\\"{x:1688,y:488,t:1528139793348};\\\", \\\"{x:1701,y:491,t:1528139793364};\\\", \\\"{x:1707,y:494,t:1528139793381};\\\", \\\"{x:1708,y:495,t:1528139793429};\\\", \\\"{x:1709,y:495,t:1528139793444};\\\", \\\"{x:1709,y:496,t:1528139793501};\\\", \\\"{x:1710,y:497,t:1528139793514};\\\", \\\"{x:1711,y:501,t:1528139793531};\\\", \\\"{x:1713,y:513,t:1528139793549};\\\", \\\"{x:1715,y:519,t:1528139793564};\\\", \\\"{x:1717,y:525,t:1528139793581};\\\", \\\"{x:1719,y:534,t:1528139793598};\\\", \\\"{x:1722,y:541,t:1528139793616};\\\", \\\"{x:1722,y:549,t:1528139793632};\\\", \\\"{x:1723,y:560,t:1528139793649};\\\", \\\"{x:1724,y:574,t:1528139793665};\\\", \\\"{x:1724,y:584,t:1528139793682};\\\", \\\"{x:1727,y:597,t:1528139793699};\\\", \\\"{x:1727,y:608,t:1528139793715};\\\", \\\"{x:1728,y:624,t:1528139793732};\\\", \\\"{x:1728,y:642,t:1528139793749};\\\", \\\"{x:1729,y:652,t:1528139793765};\\\", \\\"{x:1729,y:664,t:1528139793781};\\\", \\\"{x:1731,y:679,t:1528139793798};\\\", \\\"{x:1731,y:694,t:1528139793814};\\\", \\\"{x:1731,y:703,t:1528139793830};\\\", \\\"{x:1731,y:714,t:1528139793848};\\\", \\\"{x:1733,y:729,t:1528139793865};\\\", \\\"{x:1735,y:745,t:1528139793881};\\\", \\\"{x:1736,y:751,t:1528139793898};\\\", \\\"{x:1737,y:757,t:1528139793915};\\\", \\\"{x:1737,y:769,t:1528139793932};\\\", \\\"{x:1737,y:778,t:1528139793948};\\\", \\\"{x:1737,y:781,t:1528139793965};\\\", \\\"{x:1737,y:785,t:1528139793982};\\\", \\\"{x:1737,y:789,t:1528139793998};\\\", \\\"{x:1737,y:792,t:1528139794015};\\\", \\\"{x:1737,y:796,t:1528139794032};\\\", \\\"{x:1736,y:800,t:1528139794048};\\\", \\\"{x:1734,y:804,t:1528139794064};\\\", \\\"{x:1727,y:811,t:1528139794082};\\\", \\\"{x:1722,y:816,t:1528139794098};\\\", \\\"{x:1715,y:822,t:1528139794115};\\\", \\\"{x:1702,y:830,t:1528139794132};\\\", \\\"{x:1696,y:833,t:1528139794148};\\\", \\\"{x:1686,y:835,t:1528139794165};\\\", \\\"{x:1676,y:839,t:1528139794182};\\\", \\\"{x:1660,y:840,t:1528139794199};\\\", \\\"{x:1642,y:841,t:1528139794215};\\\", \\\"{x:1612,y:843,t:1528139794232};\\\", \\\"{x:1578,y:843,t:1528139794248};\\\", \\\"{x:1531,y:843,t:1528139794265};\\\", \\\"{x:1480,y:843,t:1528139794282};\\\", \\\"{x:1426,y:841,t:1528139794298};\\\", \\\"{x:1368,y:841,t:1528139794315};\\\", \\\"{x:1267,y:841,t:1528139794332};\\\", \\\"{x:1220,y:835,t:1528139794348};\\\", \\\"{x:1189,y:830,t:1528139794365};\\\", \\\"{x:1175,y:829,t:1528139794382};\\\", \\\"{x:1173,y:829,t:1528139794398};\\\", \\\"{x:1172,y:829,t:1528139794493};\\\", \\\"{x:1172,y:827,t:1528139794524};\\\", \\\"{x:1172,y:823,t:1528139794532};\\\", \\\"{x:1178,y:812,t:1528139794548};\\\", \\\"{x:1181,y:808,t:1528139794565};\\\", \\\"{x:1186,y:803,t:1528139794582};\\\", \\\"{x:1194,y:799,t:1528139794599};\\\", \\\"{x:1206,y:795,t:1528139794615};\\\", \\\"{x:1218,y:791,t:1528139794632};\\\", \\\"{x:1226,y:789,t:1528139794649};\\\", \\\"{x:1231,y:786,t:1528139794665};\\\", \\\"{x:1233,y:786,t:1528139794683};\\\", \\\"{x:1239,y:785,t:1528139794699};\\\", \\\"{x:1245,y:782,t:1528139794715};\\\", \\\"{x:1253,y:782,t:1528139794732};\\\", \\\"{x:1259,y:781,t:1528139794748};\\\", \\\"{x:1268,y:780,t:1528139794765};\\\", \\\"{x:1281,y:778,t:1528139794782};\\\", \\\"{x:1290,y:777,t:1528139794800};\\\", \\\"{x:1299,y:776,t:1528139794815};\\\", \\\"{x:1307,y:775,t:1528139794831};\\\", \\\"{x:1317,y:775,t:1528139794848};\\\", \\\"{x:1325,y:775,t:1528139794865};\\\", \\\"{x:1333,y:775,t:1528139794882};\\\", \\\"{x:1336,y:775,t:1528139794898};\\\", \\\"{x:1337,y:775,t:1528139794916};\\\", \\\"{x:1338,y:775,t:1528139794932};\\\", \\\"{x:1339,y:774,t:1528139795149};\\\", \\\"{x:1340,y:773,t:1528139795205};\\\", \\\"{x:1341,y:772,t:1528139795229};\\\", \\\"{x:1342,y:772,t:1528139795237};\\\", \\\"{x:1343,y:770,t:1528139795253};\\\", \\\"{x:1344,y:770,t:1528139795266};\\\", \\\"{x:1345,y:769,t:1528139795282};\\\", \\\"{x:1347,y:767,t:1528139795302};\\\", \\\"{x:1347,y:766,t:1528139795315};\\\", \\\"{x:1348,y:766,t:1528139795332};\\\", \\\"{x:1350,y:764,t:1528139795348};\\\", \\\"{x:1352,y:763,t:1528139795365};\\\", \\\"{x:1352,y:762,t:1528139795383};\\\", \\\"{x:1353,y:761,t:1528139795398};\\\", \\\"{x:1352,y:761,t:1528139803293};\\\", \\\"{x:1347,y:764,t:1528139805381};\\\", \\\"{x:1337,y:770,t:1528139805392};\\\", \\\"{x:1326,y:782,t:1528139805408};\\\", \\\"{x:1317,y:792,t:1528139805424};\\\", \\\"{x:1310,y:800,t:1528139805441};\\\", \\\"{x:1304,y:806,t:1528139805458};\\\", \\\"{x:1302,y:809,t:1528139805475};\\\", \\\"{x:1299,y:815,t:1528139805491};\\\", \\\"{x:1295,y:824,t:1528139805508};\\\", \\\"{x:1289,y:842,t:1528139805524};\\\", \\\"{x:1285,y:855,t:1528139805541};\\\", \\\"{x:1280,y:868,t:1528139805558};\\\", \\\"{x:1278,y:878,t:1528139805575};\\\", \\\"{x:1275,y:885,t:1528139805590};\\\", \\\"{x:1274,y:890,t:1528139805607};\\\", \\\"{x:1271,y:899,t:1528139805625};\\\", \\\"{x:1268,y:906,t:1528139805640};\\\", \\\"{x:1264,y:914,t:1528139805658};\\\", \\\"{x:1261,y:918,t:1528139805675};\\\", \\\"{x:1258,y:923,t:1528139805691};\\\", \\\"{x:1255,y:929,t:1528139805708};\\\", \\\"{x:1252,y:933,t:1528139805724};\\\", \\\"{x:1249,y:934,t:1528139805741};\\\", \\\"{x:1245,y:936,t:1528139805758};\\\", \\\"{x:1239,y:940,t:1528139805774};\\\", \\\"{x:1234,y:942,t:1528139805792};\\\", \\\"{x:1228,y:949,t:1528139805808};\\\", \\\"{x:1223,y:953,t:1528139805824};\\\", \\\"{x:1217,y:956,t:1528139805842};\\\", \\\"{x:1212,y:958,t:1528139805858};\\\", \\\"{x:1210,y:960,t:1528139805875};\\\", \\\"{x:1209,y:960,t:1528139805891};\\\", \\\"{x:1209,y:961,t:1528139805908};\\\", \\\"{x:1208,y:962,t:1528139806357};\\\", \\\"{x:1208,y:963,t:1528139806364};\\\", \\\"{x:1208,y:964,t:1528139806374};\\\", \\\"{x:1208,y:966,t:1528139806392};\\\", \\\"{x:1208,y:967,t:1528139806409};\\\", \\\"{x:1208,y:969,t:1528139806425};\\\", \\\"{x:1208,y:972,t:1528139806442};\\\", \\\"{x:1209,y:975,t:1528139806459};\\\", \\\"{x:1209,y:979,t:1528139806475};\\\", \\\"{x:1211,y:982,t:1528139806492};\\\", \\\"{x:1215,y:987,t:1528139806509};\\\", \\\"{x:1220,y:992,t:1528139806524};\\\", \\\"{x:1223,y:995,t:1528139806541};\\\", \\\"{x:1224,y:997,t:1528139806564};\\\", \\\"{x:1225,y:998,t:1528139806588};\\\", \\\"{x:1226,y:998,t:1528139806621};\\\", \\\"{x:1227,y:998,t:1528139806660};\\\", \\\"{x:1228,y:998,t:1528139806676};\\\", \\\"{x:1229,y:998,t:1528139806692};\\\", \\\"{x:1232,y:998,t:1528139806708};\\\", \\\"{x:1236,y:998,t:1528139806726};\\\", \\\"{x:1240,y:998,t:1528139806742};\\\", \\\"{x:1246,y:998,t:1528139806758};\\\", \\\"{x:1250,y:998,t:1528139806776};\\\", \\\"{x:1255,y:998,t:1528139806792};\\\", \\\"{x:1261,y:998,t:1528139806809};\\\", \\\"{x:1265,y:997,t:1528139806826};\\\", \\\"{x:1270,y:995,t:1528139806842};\\\", \\\"{x:1274,y:992,t:1528139806858};\\\", \\\"{x:1279,y:989,t:1528139806875};\\\", \\\"{x:1284,y:985,t:1528139806891};\\\", \\\"{x:1289,y:983,t:1528139806909};\\\", \\\"{x:1290,y:980,t:1528139806926};\\\", \\\"{x:1293,y:976,t:1528139806942};\\\", \\\"{x:1294,y:972,t:1528139806959};\\\", \\\"{x:1296,y:968,t:1528139806976};\\\", \\\"{x:1297,y:965,t:1528139806992};\\\", \\\"{x:1298,y:964,t:1528139807009};\\\", \\\"{x:1298,y:962,t:1528139807026};\\\", \\\"{x:1299,y:961,t:1528139807052};\\\", \\\"{x:1299,y:963,t:1528139807292};\\\", \\\"{x:1299,y:965,t:1528139807308};\\\", \\\"{x:1300,y:967,t:1528139807325};\\\", \\\"{x:1300,y:968,t:1528139807342};\\\", \\\"{x:1302,y:972,t:1528139807358};\\\", \\\"{x:1303,y:974,t:1528139807375};\\\", \\\"{x:1304,y:975,t:1528139807392};\\\", \\\"{x:1305,y:976,t:1528139807408};\\\", \\\"{x:1307,y:977,t:1528139807425};\\\", \\\"{x:1307,y:978,t:1528139807443};\\\", \\\"{x:1308,y:979,t:1528139807458};\\\", \\\"{x:1309,y:979,t:1528139807508};\\\", \\\"{x:1311,y:980,t:1528139807532};\\\", \\\"{x:1312,y:980,t:1528139807548};\\\", \\\"{x:1313,y:980,t:1528139807559};\\\", \\\"{x:1316,y:980,t:1528139807575};\\\", \\\"{x:1319,y:980,t:1528139807592};\\\", \\\"{x:1322,y:979,t:1528139807610};\\\", \\\"{x:1325,y:979,t:1528139807626};\\\", \\\"{x:1327,y:977,t:1528139807642};\\\", \\\"{x:1329,y:977,t:1528139807660};\\\", \\\"{x:1331,y:976,t:1528139807676};\\\", \\\"{x:1333,y:974,t:1528139807692};\\\", \\\"{x:1335,y:974,t:1528139807710};\\\", \\\"{x:1336,y:972,t:1528139807725};\\\", \\\"{x:1338,y:972,t:1528139807742};\\\", \\\"{x:1339,y:971,t:1528139807760};\\\", \\\"{x:1341,y:970,t:1528139807775};\\\", \\\"{x:1345,y:968,t:1528139807792};\\\", \\\"{x:1347,y:966,t:1528139807809};\\\", \\\"{x:1349,y:966,t:1528139807825};\\\", \\\"{x:1349,y:964,t:1528139807843};\\\", \\\"{x:1351,y:964,t:1528139807859};\\\", \\\"{x:1351,y:963,t:1528139807875};\\\", \\\"{x:1352,y:962,t:1528139807924};\\\", \\\"{x:1353,y:962,t:1528139808637};\\\", \\\"{x:1355,y:964,t:1528139808644};\\\", \\\"{x:1356,y:966,t:1528139808660};\\\", \\\"{x:1360,y:971,t:1528139808677};\\\", \\\"{x:1363,y:974,t:1528139808694};\\\", \\\"{x:1365,y:976,t:1528139808710};\\\", \\\"{x:1366,y:977,t:1528139808764};\\\", \\\"{x:1367,y:978,t:1528139808837};\\\", \\\"{x:1368,y:978,t:1528139808893};\\\", \\\"{x:1369,y:978,t:1528139808925};\\\", \\\"{x:1369,y:979,t:1528139808932};\\\", \\\"{x:1371,y:979,t:1528139808944};\\\", \\\"{x:1375,y:979,t:1528139808961};\\\", \\\"{x:1379,y:981,t:1528139808977};\\\", \\\"{x:1383,y:981,t:1528139808993};\\\", \\\"{x:1386,y:981,t:1528139809010};\\\", \\\"{x:1389,y:981,t:1528139809027};\\\", \\\"{x:1392,y:981,t:1528139809044};\\\", \\\"{x:1395,y:981,t:1528139809060};\\\", \\\"{x:1397,y:980,t:1528139809076};\\\", \\\"{x:1400,y:979,t:1528139809094};\\\", \\\"{x:1402,y:978,t:1528139809111};\\\", \\\"{x:1403,y:977,t:1528139809127};\\\", \\\"{x:1405,y:977,t:1528139809173};\\\", \\\"{x:1407,y:975,t:1528139809188};\\\", \\\"{x:1408,y:974,t:1528139809221};\\\", \\\"{x:1409,y:974,t:1528139809325};\\\", \\\"{x:1411,y:973,t:1528139809396};\\\", \\\"{x:1411,y:972,t:1528139809484};\\\", \\\"{x:1411,y:971,t:1528139809508};\\\", \\\"{x:1412,y:969,t:1528139809516};\\\", \\\"{x:1412,y:968,t:1528139809533};\\\", \\\"{x:1412,y:967,t:1528139809549};\\\", \\\"{x:1412,y:965,t:1528139809561};\\\", \\\"{x:1412,y:964,t:1528139809581};\\\", \\\"{x:1412,y:963,t:1528139809628};\\\", \\\"{x:1412,y:962,t:1528139809644};\\\", \\\"{x:1410,y:961,t:1528139809661};\\\", \\\"{x:1410,y:959,t:1528139809678};\\\", \\\"{x:1408,y:956,t:1528139809694};\\\", \\\"{x:1406,y:952,t:1528139809712};\\\", \\\"{x:1404,y:950,t:1528139809728};\\\", \\\"{x:1401,y:943,t:1528139809745};\\\", \\\"{x:1397,y:935,t:1528139809761};\\\", \\\"{x:1391,y:915,t:1528139809778};\\\", \\\"{x:1385,y:897,t:1528139809796};\\\", \\\"{x:1382,y:888,t:1528139809812};\\\", \\\"{x:1377,y:875,t:1528139809829};\\\", \\\"{x:1373,y:870,t:1528139809845};\\\", \\\"{x:1373,y:869,t:1528139809861};\\\", \\\"{x:1373,y:867,t:1528139809901};\\\", \\\"{x:1372,y:867,t:1528139809911};\\\", \\\"{x:1371,y:865,t:1528139809927};\\\", \\\"{x:1370,y:863,t:1528139809944};\\\", \\\"{x:1368,y:858,t:1528139809960};\\\", \\\"{x:1366,y:853,t:1528139809977};\\\", \\\"{x:1363,y:846,t:1528139809994};\\\", \\\"{x:1362,y:844,t:1528139810010};\\\", \\\"{x:1361,y:842,t:1528139810027};\\\", \\\"{x:1361,y:840,t:1528139810052};\\\", \\\"{x:1360,y:840,t:1528139811308};\\\", \\\"{x:1364,y:837,t:1528139811316};\\\", \\\"{x:1370,y:832,t:1528139811329};\\\", \\\"{x:1382,y:826,t:1528139811346};\\\", \\\"{x:1398,y:821,t:1528139811362};\\\", \\\"{x:1408,y:817,t:1528139811379};\\\", \\\"{x:1421,y:813,t:1528139811397};\\\", \\\"{x:1426,y:810,t:1528139811412};\\\", \\\"{x:1428,y:809,t:1528139811429};\\\", \\\"{x:1430,y:809,t:1528139811446};\\\", \\\"{x:1432,y:808,t:1528139811468};\\\", \\\"{x:1433,y:808,t:1528139811485};\\\", \\\"{x:1433,y:807,t:1528139811496};\\\", \\\"{x:1435,y:807,t:1528139811513};\\\", \\\"{x:1436,y:806,t:1528139811529};\\\", \\\"{x:1439,y:804,t:1528139811546};\\\", \\\"{x:1444,y:801,t:1528139811563};\\\", \\\"{x:1447,y:799,t:1528139811579};\\\", \\\"{x:1452,y:797,t:1528139811596};\\\", \\\"{x:1454,y:795,t:1528139811612};\\\", \\\"{x:1458,y:795,t:1528139811629};\\\", \\\"{x:1458,y:794,t:1528139811646};\\\", \\\"{x:1459,y:794,t:1528139811663};\\\", \\\"{x:1460,y:793,t:1528139811679};\\\", \\\"{x:1458,y:793,t:1528139811892};\\\", \\\"{x:1454,y:796,t:1528139811900};\\\", \\\"{x:1451,y:797,t:1528139811912};\\\", \\\"{x:1445,y:800,t:1528139811929};\\\", \\\"{x:1441,y:802,t:1528139811947};\\\", \\\"{x:1440,y:803,t:1528139811963};\\\", \\\"{x:1438,y:803,t:1528139811980};\\\", \\\"{x:1438,y:804,t:1528139811996};\\\", \\\"{x:1436,y:806,t:1528139812013};\\\", \\\"{x:1435,y:807,t:1528139812044};\\\", \\\"{x:1435,y:808,t:1528139812085};\\\", \\\"{x:1435,y:809,t:1528139812096};\\\", \\\"{x:1434,y:810,t:1528139812165};\\\", \\\"{x:1433,y:810,t:1528139812180};\\\", \\\"{x:1431,y:812,t:1528139812196};\\\", \\\"{x:1430,y:814,t:1528139812213};\\\", \\\"{x:1428,y:815,t:1528139812230};\\\", \\\"{x:1426,y:817,t:1528139812246};\\\", \\\"{x:1423,y:819,t:1528139812263};\\\", \\\"{x:1422,y:820,t:1528139812280};\\\", \\\"{x:1421,y:820,t:1528139812297};\\\", \\\"{x:1421,y:821,t:1528139812313};\\\", \\\"{x:1420,y:822,t:1528139812330};\\\", \\\"{x:1419,y:823,t:1528139812346};\\\", \\\"{x:1418,y:824,t:1528139812363};\\\", \\\"{x:1415,y:826,t:1528139812380};\\\", \\\"{x:1415,y:827,t:1528139812396};\\\", \\\"{x:1414,y:827,t:1528139812413};\\\", \\\"{x:1413,y:829,t:1528139812430};\\\", \\\"{x:1412,y:829,t:1528139812447};\\\", \\\"{x:1411,y:830,t:1528139812464};\\\", \\\"{x:1410,y:830,t:1528139812480};\\\", \\\"{x:1409,y:831,t:1528139812498};\\\", \\\"{x:1408,y:832,t:1528139812516};\\\", \\\"{x:1407,y:832,t:1528139812532};\\\", \\\"{x:1406,y:833,t:1528139812549};\\\", \\\"{x:1405,y:833,t:1528139812563};\\\", \\\"{x:1403,y:835,t:1528139812580};\\\", \\\"{x:1402,y:836,t:1528139812597};\\\", \\\"{x:1402,y:837,t:1528139812613};\\\", \\\"{x:1401,y:838,t:1528139812630};\\\", \\\"{x:1401,y:839,t:1528139812647};\\\", \\\"{x:1400,y:840,t:1528139812663};\\\", \\\"{x:1399,y:841,t:1528139812680};\\\", \\\"{x:1399,y:842,t:1528139812708};\\\", \\\"{x:1398,y:843,t:1528139812716};\\\", \\\"{x:1398,y:844,t:1528139812731};\\\", \\\"{x:1397,y:844,t:1528139812747};\\\", \\\"{x:1396,y:845,t:1528139812763};\\\", \\\"{x:1396,y:846,t:1528139812787};\\\", \\\"{x:1395,y:847,t:1528139812827};\\\", \\\"{x:1395,y:848,t:1528139812836};\\\", \\\"{x:1395,y:849,t:1528139812851};\\\", \\\"{x:1395,y:850,t:1528139812864};\\\", \\\"{x:1394,y:852,t:1528139812880};\\\", \\\"{x:1393,y:853,t:1528139812896};\\\", \\\"{x:1391,y:857,t:1528139812913};\\\", \\\"{x:1390,y:859,t:1528139812929};\\\", \\\"{x:1388,y:863,t:1528139812946};\\\", \\\"{x:1386,y:866,t:1528139812964};\\\", \\\"{x:1382,y:871,t:1528139812980};\\\", \\\"{x:1379,y:876,t:1528139812996};\\\", \\\"{x:1377,y:879,t:1528139813014};\\\", \\\"{x:1376,y:881,t:1528139813030};\\\", \\\"{x:1373,y:883,t:1528139813046};\\\", \\\"{x:1367,y:887,t:1528139813063};\\\", \\\"{x:1359,y:893,t:1528139813080};\\\", \\\"{x:1354,y:898,t:1528139813096};\\\", \\\"{x:1345,y:908,t:1528139813114};\\\", \\\"{x:1334,y:922,t:1528139813129};\\\", \\\"{x:1321,y:930,t:1528139813147};\\\", \\\"{x:1307,y:940,t:1528139813163};\\\", \\\"{x:1303,y:942,t:1528139813180};\\\", \\\"{x:1300,y:945,t:1528139813197};\\\", \\\"{x:1299,y:946,t:1528139813214};\\\", \\\"{x:1298,y:948,t:1528139813230};\\\", \\\"{x:1298,y:950,t:1528139813247};\\\", \\\"{x:1295,y:954,t:1528139813264};\\\", \\\"{x:1294,y:955,t:1528139813281};\\\", \\\"{x:1293,y:961,t:1528139813297};\\\", \\\"{x:1292,y:962,t:1528139813314};\\\", \\\"{x:1292,y:965,t:1528139813331};\\\", \\\"{x:1292,y:968,t:1528139813347};\\\", \\\"{x:1292,y:973,t:1528139813364};\\\", \\\"{x:1292,y:976,t:1528139813380};\\\", \\\"{x:1292,y:980,t:1528139813397};\\\", \\\"{x:1292,y:982,t:1528139813414};\\\", \\\"{x:1292,y:983,t:1528139813436};\\\", \\\"{x:1292,y:984,t:1528139813477};\\\", \\\"{x:1292,y:985,t:1528139813485};\\\", \\\"{x:1292,y:986,t:1528139813500};\\\", \\\"{x:1292,y:987,t:1528139813514};\\\", \\\"{x:1293,y:988,t:1528139813531};\\\", \\\"{x:1295,y:989,t:1528139813547};\\\", \\\"{x:1304,y:993,t:1528139813564};\\\", \\\"{x:1309,y:995,t:1528139813581};\\\", \\\"{x:1315,y:997,t:1528139813597};\\\", \\\"{x:1323,y:1000,t:1528139813614};\\\", \\\"{x:1332,y:1002,t:1528139813631};\\\", \\\"{x:1338,y:1002,t:1528139813647};\\\", \\\"{x:1342,y:1002,t:1528139813664};\\\", \\\"{x:1347,y:1002,t:1528139813681};\\\", \\\"{x:1349,y:1002,t:1528139813698};\\\", \\\"{x:1354,y:1000,t:1528139813714};\\\", \\\"{x:1358,y:998,t:1528139813731};\\\", \\\"{x:1363,y:995,t:1528139813748};\\\", \\\"{x:1366,y:992,t:1528139813764};\\\", \\\"{x:1368,y:989,t:1528139813781};\\\", \\\"{x:1370,y:986,t:1528139813798};\\\", \\\"{x:1371,y:983,t:1528139813815};\\\", \\\"{x:1371,y:982,t:1528139813831};\\\", \\\"{x:1371,y:980,t:1528139813860};\\\", \\\"{x:1371,y:979,t:1528139813876};\\\", \\\"{x:1371,y:978,t:1528139813884};\\\", \\\"{x:1370,y:976,t:1528139813898};\\\", \\\"{x:1369,y:975,t:1528139813914};\\\", \\\"{x:1365,y:972,t:1528139813931};\\\", \\\"{x:1363,y:970,t:1528139813948};\\\", \\\"{x:1362,y:970,t:1528139813964};\\\", \\\"{x:1362,y:969,t:1528139814004};\\\", \\\"{x:1362,y:968,t:1528139814061};\\\", \\\"{x:1363,y:967,t:1528139814076};\\\", \\\"{x:1364,y:967,t:1528139814100};\\\", \\\"{x:1365,y:970,t:1528139814172};\\\", \\\"{x:1368,y:973,t:1528139814180};\\\", \\\"{x:1370,y:975,t:1528139814198};\\\", \\\"{x:1372,y:977,t:1528139814214};\\\", \\\"{x:1375,y:981,t:1528139814230};\\\", \\\"{x:1377,y:981,t:1528139814247};\\\", \\\"{x:1380,y:982,t:1528139814264};\\\", \\\"{x:1383,y:982,t:1528139814280};\\\", \\\"{x:1387,y:982,t:1528139814298};\\\", \\\"{x:1391,y:982,t:1528139814315};\\\", \\\"{x:1397,y:982,t:1528139814331};\\\", \\\"{x:1403,y:982,t:1528139814347};\\\", \\\"{x:1408,y:982,t:1528139814365};\\\", \\\"{x:1410,y:982,t:1528139814381};\\\", \\\"{x:1413,y:981,t:1528139814397};\\\", \\\"{x:1418,y:978,t:1528139814415};\\\", \\\"{x:1421,y:975,t:1528139814431};\\\", \\\"{x:1424,y:972,t:1528139814448};\\\", \\\"{x:1426,y:970,t:1528139814465};\\\", \\\"{x:1427,y:969,t:1528139814481};\\\", \\\"{x:1429,y:967,t:1528139814498};\\\", \\\"{x:1431,y:965,t:1528139814514};\\\", \\\"{x:1432,y:964,t:1528139814532};\\\", \\\"{x:1432,y:963,t:1528139814692};\\\", \\\"{x:1431,y:963,t:1528139814732};\\\", \\\"{x:1430,y:964,t:1528139814772};\\\", \\\"{x:1429,y:964,t:1528139814796};\\\", \\\"{x:1429,y:965,t:1528139814861};\\\", \\\"{x:1430,y:967,t:1528139814876};\\\", \\\"{x:1431,y:968,t:1528139814884};\\\", \\\"{x:1435,y:970,t:1528139814898};\\\", \\\"{x:1437,y:972,t:1528139814916};\\\", \\\"{x:1444,y:977,t:1528139814931};\\\", \\\"{x:1448,y:980,t:1528139814947};\\\", \\\"{x:1454,y:983,t:1528139814965};\\\", \\\"{x:1457,y:985,t:1528139814982};\\\", \\\"{x:1460,y:986,t:1528139814998};\\\", \\\"{x:1461,y:986,t:1528139815019};\\\", \\\"{x:1463,y:987,t:1528139815031};\\\", \\\"{x:1466,y:988,t:1528139815048};\\\", \\\"{x:1469,y:989,t:1528139815064};\\\", \\\"{x:1471,y:989,t:1528139815081};\\\", \\\"{x:1474,y:989,t:1528139815098};\\\", \\\"{x:1477,y:989,t:1528139815115};\\\", \\\"{x:1481,y:989,t:1528139815131};\\\", \\\"{x:1484,y:989,t:1528139815149};\\\", \\\"{x:1486,y:988,t:1528139815164};\\\", \\\"{x:1489,y:985,t:1528139815182};\\\", \\\"{x:1491,y:983,t:1528139815199};\\\", \\\"{x:1494,y:980,t:1528139815215};\\\", \\\"{x:1497,y:977,t:1528139815231};\\\", \\\"{x:1498,y:976,t:1528139815248};\\\", \\\"{x:1500,y:974,t:1528139815264};\\\", \\\"{x:1502,y:969,t:1528139815282};\\\", \\\"{x:1502,y:968,t:1528139815298};\\\", \\\"{x:1503,y:966,t:1528139815314};\\\", \\\"{x:1504,y:967,t:1528139815596};\\\", \\\"{x:1505,y:968,t:1528139815604};\\\", \\\"{x:1506,y:971,t:1528139815616};\\\", \\\"{x:1510,y:975,t:1528139815632};\\\", \\\"{x:1514,y:976,t:1528139815649};\\\", \\\"{x:1516,y:977,t:1528139815665};\\\", \\\"{x:1520,y:978,t:1528139815682};\\\", \\\"{x:1522,y:978,t:1528139815699};\\\", \\\"{x:1525,y:979,t:1528139815716};\\\", \\\"{x:1526,y:979,t:1528139815748};\\\", \\\"{x:1527,y:979,t:1528139815766};\\\", \\\"{x:1528,y:979,t:1528139815783};\\\", \\\"{x:1529,y:979,t:1528139815799};\\\", \\\"{x:1532,y:979,t:1528139815816};\\\", \\\"{x:1533,y:979,t:1528139815833};\\\", \\\"{x:1535,y:979,t:1528139815849};\\\", \\\"{x:1538,y:979,t:1528139815866};\\\", \\\"{x:1538,y:978,t:1528139815883};\\\", \\\"{x:1541,y:976,t:1528139815899};\\\", \\\"{x:1544,y:973,t:1528139815916};\\\", \\\"{x:1546,y:972,t:1528139815932};\\\", \\\"{x:1548,y:968,t:1528139815950};\\\", \\\"{x:1549,y:966,t:1528139815966};\\\", \\\"{x:1550,y:965,t:1528139815983};\\\", \\\"{x:1551,y:964,t:1528139816000};\\\", \\\"{x:1552,y:963,t:1528139816016};\\\", \\\"{x:1553,y:962,t:1528139816036};\\\", \\\"{x:1554,y:962,t:1528139816100};\\\", \\\"{x:1555,y:964,t:1528139816516};\\\", \\\"{x:1559,y:970,t:1528139816533};\\\", \\\"{x:1561,y:972,t:1528139816550};\\\", \\\"{x:1563,y:974,t:1528139816566};\\\", \\\"{x:1567,y:977,t:1528139816583};\\\", \\\"{x:1571,y:979,t:1528139816600};\\\", \\\"{x:1573,y:981,t:1528139816616};\\\", \\\"{x:1576,y:982,t:1528139816633};\\\", \\\"{x:1578,y:982,t:1528139816765};\\\", \\\"{x:1579,y:982,t:1528139816788};\\\", \\\"{x:1581,y:982,t:1528139816804};\\\", \\\"{x:1582,y:982,t:1528139816820};\\\", \\\"{x:1584,y:982,t:1528139816833};\\\", \\\"{x:1586,y:982,t:1528139816850};\\\", \\\"{x:1587,y:982,t:1528139816868};\\\", \\\"{x:1588,y:982,t:1528139816884};\\\", \\\"{x:1589,y:982,t:1528139816900};\\\", \\\"{x:1591,y:982,t:1528139816917};\\\", \\\"{x:1591,y:981,t:1528139816932};\\\", \\\"{x:1592,y:981,t:1528139816955};\\\", \\\"{x:1593,y:981,t:1528139816966};\\\", \\\"{x:1596,y:979,t:1528139816983};\\\", \\\"{x:1600,y:976,t:1528139817000};\\\", \\\"{x:1602,y:975,t:1528139817016};\\\", \\\"{x:1603,y:974,t:1528139817033};\\\", \\\"{x:1604,y:974,t:1528139817049};\\\", \\\"{x:1605,y:973,t:1528139817066};\\\", \\\"{x:1606,y:972,t:1528139817100};\\\", \\\"{x:1607,y:971,t:1528139817116};\\\", \\\"{x:1608,y:971,t:1528139817133};\\\", \\\"{x:1609,y:970,t:1528139817156};\\\", \\\"{x:1609,y:968,t:1528139818389};\\\", \\\"{x:1606,y:967,t:1528139818402};\\\", \\\"{x:1583,y:967,t:1528139818418};\\\", \\\"{x:1557,y:967,t:1528139818434};\\\", \\\"{x:1512,y:967,t:1528139818452};\\\", \\\"{x:1410,y:962,t:1528139818468};\\\", \\\"{x:1303,y:938,t:1528139818485};\\\", \\\"{x:1162,y:896,t:1528139818502};\\\", \\\"{x:1038,y:861,t:1528139818518};\\\", \\\"{x:926,y:826,t:1528139818536};\\\", \\\"{x:827,y:800,t:1528139818551};\\\", \\\"{x:730,y:772,t:1528139818568};\\\", \\\"{x:671,y:753,t:1528139818585};\\\", \\\"{x:632,y:736,t:1528139818601};\\\", \\\"{x:606,y:724,t:1528139818618};\\\", \\\"{x:585,y:715,t:1528139818635};\\\", \\\"{x:566,y:705,t:1528139818651};\\\", \\\"{x:533,y:689,t:1528139818668};\\\", \\\"{x:512,y:678,t:1528139818686};\\\", \\\"{x:488,y:662,t:1528139818702};\\\", \\\"{x:454,y:636,t:1528139818718};\\\", \\\"{x:440,y:622,t:1528139818734};\\\", \\\"{x:426,y:598,t:1528139818766};\\\", \\\"{x:426,y:593,t:1528139818783};\\\", \\\"{x:426,y:591,t:1528139818801};\\\", \\\"{x:431,y:587,t:1528139818818};\\\", \\\"{x:447,y:581,t:1528139818834};\\\", \\\"{x:495,y:569,t:1528139818851};\\\", \\\"{x:531,y:565,t:1528139818869};\\\", \\\"{x:559,y:560,t:1528139818885};\\\", \\\"{x:590,y:555,t:1528139818902};\\\", \\\"{x:622,y:555,t:1528139818918};\\\", \\\"{x:646,y:555,t:1528139818935};\\\", \\\"{x:663,y:555,t:1528139818951};\\\", \\\"{x:671,y:555,t:1528139818968};\\\", \\\"{x:668,y:555,t:1528139819068};\\\", \\\"{x:614,y:560,t:1528139819087};\\\", \\\"{x:492,y:575,t:1528139819102};\\\", \\\"{x:365,y:575,t:1528139819119};\\\", \\\"{x:243,y:575,t:1528139819135};\\\", \\\"{x:149,y:575,t:1528139819152};\\\", \\\"{x:125,y:575,t:1528139819169};\\\", \\\"{x:114,y:575,t:1528139819186};\\\", \\\"{x:109,y:574,t:1528139819201};\\\", \\\"{x:108,y:574,t:1528139819218};\\\", \\\"{x:109,y:574,t:1528139819299};\\\", \\\"{x:110,y:574,t:1528139819308};\\\", \\\"{x:112,y:575,t:1528139819319};\\\", \\\"{x:117,y:582,t:1528139819335};\\\", \\\"{x:127,y:590,t:1528139819353};\\\", \\\"{x:138,y:599,t:1528139819370};\\\", \\\"{x:156,y:606,t:1528139819387};\\\", \\\"{x:178,y:610,t:1528139819403};\\\", \\\"{x:202,y:615,t:1528139819419};\\\", \\\"{x:223,y:616,t:1528139819436};\\\", \\\"{x:229,y:616,t:1528139819452};\\\", \\\"{x:230,y:616,t:1528139819469};\\\", \\\"{x:227,y:616,t:1528139819588};\\\", \\\"{x:225,y:615,t:1528139819603};\\\", \\\"{x:215,y:615,t:1528139819620};\\\", \\\"{x:209,y:615,t:1528139819637};\\\", \\\"{x:204,y:614,t:1528139819653};\\\", \\\"{x:199,y:612,t:1528139819670};\\\", \\\"{x:197,y:611,t:1528139819687};\\\", \\\"{x:195,y:608,t:1528139819704};\\\", \\\"{x:193,y:606,t:1528139819720};\\\", \\\"{x:192,y:605,t:1528139819737};\\\", \\\"{x:192,y:603,t:1528139819754};\\\", \\\"{x:192,y:602,t:1528139819770};\\\", \\\"{x:192,y:601,t:1528139819787};\\\", \\\"{x:189,y:597,t:1528139819805};\\\", \\\"{x:187,y:594,t:1528139819820};\\\", \\\"{x:186,y:593,t:1528139819836};\\\", \\\"{x:183,y:592,t:1528139819852};\\\", \\\"{x:181,y:591,t:1528139819875};\\\", \\\"{x:179,y:591,t:1528139819886};\\\", \\\"{x:176,y:590,t:1528139819902};\\\", \\\"{x:174,y:590,t:1528139819920};\\\", \\\"{x:169,y:588,t:1528139819936};\\\", \\\"{x:165,y:587,t:1528139819953};\\\", \\\"{x:162,y:587,t:1528139819969};\\\", \\\"{x:160,y:586,t:1528139819985};\\\", \\\"{x:159,y:586,t:1528139820003};\\\", \\\"{x:158,y:586,t:1528139820019};\\\", \\\"{x:163,y:589,t:1528139820395};\\\", \\\"{x:188,y:598,t:1528139820403};\\\", \\\"{x:230,y:619,t:1528139820420};\\\", \\\"{x:287,y:650,t:1528139820437};\\\", \\\"{x:348,y:676,t:1528139820453};\\\", \\\"{x:391,y:700,t:1528139820470};\\\", \\\"{x:418,y:715,t:1528139820487};\\\", \\\"{x:437,y:723,t:1528139820503};\\\", \\\"{x:450,y:728,t:1528139820520};\\\", \\\"{x:454,y:729,t:1528139820537};\\\", \\\"{x:455,y:731,t:1528139820668};\\\" ] }, { \\\"rt\\\": 85002, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 523054, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J -B -B -B -B -O -B -I -I -B -B -B -B -12 PM-12 PM-M -M -01 PM-12 PM-J -E -E -F -03 PM-03 PM-03 PM-03 PM-M -J -B -B -I -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:454,y:731,t:1528139822507};\\\", \\\"{x:451,y:731,t:1528139822521};\\\", \\\"{x:443,y:728,t:1528139822537};\\\", \\\"{x:429,y:722,t:1528139822555};\\\", \\\"{x:416,y:716,t:1528139822571};\\\", \\\"{x:404,y:711,t:1528139822587};\\\", \\\"{x:387,y:705,t:1528139822605};\\\", \\\"{x:368,y:697,t:1528139822622};\\\", \\\"{x:347,y:691,t:1528139822638};\\\", \\\"{x:324,y:685,t:1528139822655};\\\", \\\"{x:295,y:675,t:1528139822672};\\\", \\\"{x:271,y:666,t:1528139822689};\\\", \\\"{x:249,y:659,t:1528139822705};\\\", \\\"{x:0,y:488,t:1528139822805};\\\", \\\"{x:0,y:461,t:1528139822821};\\\", \\\"{x:0,y:406,t:1528139822844};\\\", \\\"{x:0,y:389,t:1528139822855};\\\", \\\"{x:0,y:353,t:1528139822871};\\\", \\\"{x:0,y:322,t:1528139822889};\\\", \\\"{x:0,y:283,t:1528139822904};\\\", \\\"{x:0,y:231,t:1528139822921};\\\", \\\"{x:0,y:180,t:1528139822939};\\\", \\\"{x:0,y:134,t:1528139822955};\\\", \\\"{x:0,y:80,t:1528139822971};\\\", \\\"{x:0,y:51,t:1528139822988};\\\", \\\"{x:0,y:24,t:1528139823004};\\\", \\\"{x:0,y:0,t:1528139823022};\\\", \\\"{x:6,y:0,t:1528139824772};\\\", \\\"{x:33,y:0,t:1528139824790};\\\", \\\"{x:63,y:0,t:1528139824807};\\\", \\\"{x:108,y:5,t:1528139824823};\\\", \\\"{x:174,y:20,t:1528139824840};\\\", \\\"{x:239,y:32,t:1528139824857};\\\", \\\"{x:314,y:56,t:1528139824873};\\\", \\\"{x:389,y:76,t:1528139824890};\\\", \\\"{x:489,y:104,t:1528139824907};\\\", \\\"{x:535,y:115,t:1528139824924};\\\", \\\"{x:582,y:125,t:1528139824940};\\\", \\\"{x:611,y:131,t:1528139824957};\\\", \\\"{x:636,y:134,t:1528139824974};\\\", \\\"{x:654,y:136,t:1528139824991};\\\", \\\"{x:675,y:140,t:1528139825007};\\\", \\\"{x:695,y:143,t:1528139825024};\\\", \\\"{x:708,y:145,t:1528139825040};\\\", \\\"{x:720,y:147,t:1528139825057};\\\", \\\"{x:734,y:152,t:1528139825073};\\\", \\\"{x:759,y:164,t:1528139825089};\\\", \\\"{x:821,y:193,t:1528139825107};\\\", \\\"{x:867,y:219,t:1528139825123};\\\", \\\"{x:927,y:256,t:1528139825140};\\\", \\\"{x:1003,y:310,t:1528139825157};\\\", \\\"{x:1081,y:367,t:1528139825174};\\\", \\\"{x:1146,y:415,t:1528139825190};\\\", \\\"{x:1206,y:462,t:1528139825207};\\\", \\\"{x:1260,y:506,t:1528139825224};\\\", \\\"{x:1322,y:552,t:1528139825240};\\\", \\\"{x:1379,y:596,t:1528139825257};\\\", \\\"{x:1423,y:636,t:1528139825274};\\\", \\\"{x:1457,y:666,t:1528139825290};\\\", \\\"{x:1476,y:691,t:1528139825307};\\\", \\\"{x:1486,y:706,t:1528139825324};\\\", \\\"{x:1486,y:708,t:1528139825340};\\\", \\\"{x:1486,y:711,t:1528139825357};\\\", \\\"{x:1486,y:715,t:1528139825374};\\\", \\\"{x:1486,y:725,t:1528139825390};\\\", \\\"{x:1486,y:736,t:1528139825407};\\\", \\\"{x:1485,y:743,t:1528139825425};\\\", \\\"{x:1485,y:749,t:1528139825441};\\\", \\\"{x:1485,y:752,t:1528139825457};\\\", \\\"{x:1484,y:756,t:1528139825475};\\\", \\\"{x:1481,y:761,t:1528139825491};\\\", \\\"{x:1481,y:762,t:1528139825508};\\\", \\\"{x:1481,y:763,t:1528139825524};\\\", \\\"{x:1480,y:764,t:1528139825542};\\\", \\\"{x:1479,y:765,t:1528139825557};\\\", \\\"{x:1478,y:766,t:1528139825574};\\\", \\\"{x:1477,y:767,t:1528139825591};\\\", \\\"{x:1475,y:767,t:1528139825607};\\\", \\\"{x:1473,y:767,t:1528139825625};\\\", \\\"{x:1472,y:767,t:1528139825641};\\\", \\\"{x:1471,y:767,t:1528139825708};\\\", \\\"{x:1470,y:767,t:1528139825724};\\\", \\\"{x:1468,y:767,t:1528139825742};\\\", \\\"{x:1467,y:767,t:1528139825758};\\\", \\\"{x:1466,y:767,t:1528139825780};\\\", \\\"{x:1463,y:767,t:1528139825796};\\\", \\\"{x:1462,y:766,t:1528139825809};\\\", \\\"{x:1458,y:763,t:1528139825824};\\\", \\\"{x:1453,y:761,t:1528139825842};\\\", \\\"{x:1446,y:759,t:1528139825859};\\\", \\\"{x:1430,y:755,t:1528139825875};\\\", \\\"{x:1395,y:748,t:1528139825892};\\\", \\\"{x:1363,y:744,t:1528139825908};\\\", \\\"{x:1318,y:738,t:1528139825924};\\\", \\\"{x:1282,y:733,t:1528139825942};\\\", \\\"{x:1257,y:728,t:1528139825959};\\\", \\\"{x:1240,y:726,t:1528139825974};\\\", \\\"{x:1232,y:725,t:1528139825991};\\\", \\\"{x:1225,y:724,t:1528139826008};\\\", \\\"{x:1220,y:723,t:1528139826024};\\\", \\\"{x:1218,y:723,t:1528139826043};\\\", \\\"{x:1217,y:723,t:1528139826108};\\\", \\\"{x:1218,y:723,t:1528139826412};\\\", \\\"{x:1221,y:724,t:1528139826426};\\\", \\\"{x:1224,y:725,t:1528139826442};\\\", \\\"{x:1228,y:725,t:1528139826459};\\\", \\\"{x:1233,y:726,t:1528139826476};\\\", \\\"{x:1234,y:726,t:1528139826492};\\\", \\\"{x:1235,y:727,t:1528139826508};\\\", \\\"{x:1236,y:727,t:1528139826526};\\\", \\\"{x:1239,y:728,t:1528139826542};\\\", \\\"{x:1243,y:731,t:1528139826558};\\\", \\\"{x:1252,y:736,t:1528139826575};\\\", \\\"{x:1266,y:750,t:1528139826591};\\\", \\\"{x:1284,y:774,t:1528139826608};\\\", \\\"{x:1310,y:809,t:1528139826626};\\\", \\\"{x:1336,y:844,t:1528139826643};\\\", \\\"{x:1383,y:906,t:1528139826658};\\\", \\\"{x:1459,y:1000,t:1528139826676};\\\", \\\"{x:1505,y:1048,t:1528139826692};\\\", \\\"{x:1531,y:1073,t:1528139826708};\\\", \\\"{x:1545,y:1084,t:1528139826726};\\\", \\\"{x:1549,y:1088,t:1528139826743};\\\", \\\"{x:1546,y:1086,t:1528139826828};\\\", \\\"{x:1536,y:1082,t:1528139826843};\\\", \\\"{x:1516,y:1072,t:1528139826858};\\\", \\\"{x:1496,y:1065,t:1528139826875};\\\", \\\"{x:1456,y:1053,t:1528139826892};\\\", \\\"{x:1416,y:1042,t:1528139826908};\\\", \\\"{x:1387,y:1034,t:1528139826925};\\\", \\\"{x:1366,y:1028,t:1528139826942};\\\", \\\"{x:1353,y:1022,t:1528139826959};\\\", \\\"{x:1340,y:1018,t:1528139826975};\\\", \\\"{x:1333,y:1014,t:1528139826992};\\\", \\\"{x:1329,y:1012,t:1528139827009};\\\", \\\"{x:1328,y:1010,t:1528139827026};\\\", \\\"{x:1327,y:1010,t:1528139827084};\\\", \\\"{x:1327,y:1009,t:1528139827092};\\\", \\\"{x:1324,y:1004,t:1528139827110};\\\", \\\"{x:1323,y:1000,t:1528139827126};\\\", \\\"{x:1319,y:991,t:1528139827143};\\\", \\\"{x:1315,y:985,t:1528139827160};\\\", \\\"{x:1314,y:983,t:1528139827175};\\\", \\\"{x:1309,y:974,t:1528139827193};\\\", \\\"{x:1301,y:960,t:1528139827210};\\\", \\\"{x:1300,y:959,t:1528139827226};\\\", \\\"{x:1300,y:958,t:1528139827242};\\\", \\\"{x:1300,y:956,t:1528139827260};\\\", \\\"{x:1300,y:955,t:1528139827275};\\\", \\\"{x:1300,y:954,t:1528139827292};\\\", \\\"{x:1300,y:953,t:1528139827316};\\\", \\\"{x:1300,y:951,t:1528139827332};\\\", \\\"{x:1301,y:950,t:1528139827348};\\\", \\\"{x:1301,y:949,t:1528139827380};\\\", \\\"{x:1302,y:949,t:1528139827404};\\\", \\\"{x:1303,y:949,t:1528139827412};\\\", \\\"{x:1304,y:949,t:1528139827425};\\\", \\\"{x:1305,y:949,t:1528139827451};\\\", \\\"{x:1304,y:945,t:1528139827780};\\\", \\\"{x:1292,y:931,t:1528139827792};\\\", \\\"{x:1275,y:901,t:1528139827809};\\\", \\\"{x:1270,y:888,t:1528139827826};\\\", \\\"{x:1266,y:882,t:1528139827842};\\\", \\\"{x:1259,y:874,t:1528139827859};\\\", \\\"{x:1254,y:871,t:1528139827876};\\\", \\\"{x:1248,y:866,t:1528139827892};\\\", \\\"{x:1245,y:863,t:1528139827909};\\\", \\\"{x:1240,y:861,t:1528139827926};\\\", \\\"{x:1238,y:859,t:1528139827943};\\\", \\\"{x:1235,y:856,t:1528139827959};\\\", \\\"{x:1235,y:855,t:1528139827976};\\\", \\\"{x:1234,y:852,t:1528139827993};\\\", \\\"{x:1232,y:851,t:1528139828009};\\\", \\\"{x:1228,y:847,t:1528139828026};\\\", \\\"{x:1222,y:842,t:1528139828043};\\\", \\\"{x:1219,y:840,t:1528139828059};\\\", \\\"{x:1218,y:839,t:1528139828076};\\\", \\\"{x:1217,y:838,t:1528139828165};\\\", \\\"{x:1217,y:837,t:1528139829245};\\\", \\\"{x:1216,y:836,t:1528139829300};\\\", \\\"{x:1216,y:835,t:1528139829383};\\\", \\\"{x:1215,y:835,t:1528139830245};\\\", \\\"{x:1213,y:835,t:1528139830868};\\\", \\\"{x:1212,y:835,t:1528139830879};\\\", \\\"{x:1208,y:834,t:1528139830897};\\\", \\\"{x:1206,y:833,t:1528139830911};\\\", \\\"{x:1205,y:833,t:1528139830928};\\\", \\\"{x:1204,y:833,t:1528139830946};\\\", \\\"{x:1203,y:833,t:1528139830962};\\\", \\\"{x:1203,y:832,t:1528139830979};\\\", \\\"{x:1202,y:832,t:1528139831780};\\\", \\\"{x:1201,y:831,t:1528139831860};\\\", \\\"{x:1200,y:831,t:1528139832963};\\\", \\\"{x:1197,y:831,t:1528139832980};\\\", \\\"{x:1196,y:831,t:1528139832997};\\\", \\\"{x:1195,y:831,t:1528139833014};\\\", \\\"{x:1194,y:831,t:1528139833031};\\\", \\\"{x:1193,y:831,t:1528139833047};\\\", \\\"{x:1192,y:831,t:1528139833220};\\\", \\\"{x:1190,y:831,t:1528139833484};\\\", \\\"{x:1189,y:831,t:1528139833500};\\\", \\\"{x:1188,y:831,t:1528139833651};\\\", \\\"{x:1187,y:831,t:1528139833828};\\\", \\\"{x:1186,y:831,t:1528139833836};\\\", \\\"{x:1184,y:831,t:1528139833848};\\\", \\\"{x:1183,y:831,t:1528139833868};\\\", \\\"{x:1182,y:831,t:1528139833884};\\\", \\\"{x:1181,y:830,t:1528139833898};\\\", \\\"{x:1180,y:829,t:1528139834012};\\\", \\\"{x:1176,y:821,t:1528139834020};\\\", \\\"{x:1174,y:814,t:1528139834031};\\\", \\\"{x:1169,y:806,t:1528139834048};\\\", \\\"{x:1166,y:800,t:1528139834065};\\\", \\\"{x:1161,y:788,t:1528139834081};\\\", \\\"{x:1156,y:776,t:1528139834098};\\\", \\\"{x:1152,y:767,t:1528139834115};\\\", \\\"{x:1147,y:756,t:1528139834132};\\\", \\\"{x:1146,y:752,t:1528139834148};\\\", \\\"{x:1144,y:749,t:1528139834165};\\\", \\\"{x:1144,y:748,t:1528139834182};\\\", \\\"{x:1145,y:749,t:1528139834772};\\\", \\\"{x:1145,y:750,t:1528139834782};\\\", \\\"{x:1148,y:754,t:1528139834799};\\\", \\\"{x:1149,y:756,t:1528139834815};\\\", \\\"{x:1152,y:759,t:1528139834832};\\\", \\\"{x:1155,y:763,t:1528139834849};\\\", \\\"{x:1159,y:767,t:1528139834866};\\\", \\\"{x:1164,y:773,t:1528139834882};\\\", \\\"{x:1166,y:776,t:1528139834899};\\\", \\\"{x:1170,y:781,t:1528139834915};\\\", \\\"{x:1177,y:790,t:1528139834932};\\\", \\\"{x:1179,y:792,t:1528139834949};\\\", \\\"{x:1181,y:795,t:1528139834965};\\\", \\\"{x:1183,y:797,t:1528139834982};\\\", \\\"{x:1185,y:799,t:1528139834999};\\\", \\\"{x:1186,y:801,t:1528139835017};\\\", \\\"{x:1189,y:804,t:1528139835032};\\\", \\\"{x:1192,y:807,t:1528139835053};\\\", \\\"{x:1192,y:808,t:1528139835069};\\\", \\\"{x:1193,y:809,t:1528139835086};\\\", \\\"{x:1195,y:812,t:1528139835102};\\\", \\\"{x:1199,y:818,t:1528139835119};\\\", \\\"{x:1203,y:822,t:1528139835135};\\\", \\\"{x:1207,y:826,t:1528139835153};\\\", \\\"{x:1207,y:827,t:1528139835169};\\\", \\\"{x:1209,y:829,t:1528139835186};\\\", \\\"{x:1211,y:829,t:1528139835202};\\\", \\\"{x:1213,y:830,t:1528139835220};\\\", \\\"{x:1214,y:823,t:1528139835793};\\\", \\\"{x:1218,y:808,t:1528139835803};\\\", \\\"{x:1232,y:773,t:1528139835820};\\\", \\\"{x:1253,y:718,t:1528139835836};\\\", \\\"{x:1290,y:620,t:1528139835854};\\\", \\\"{x:1312,y:539,t:1528139835869};\\\", \\\"{x:1318,y:504,t:1528139835887};\\\", \\\"{x:1318,y:467,t:1528139835904};\\\", \\\"{x:1316,y:450,t:1528139835919};\\\", \\\"{x:1315,y:448,t:1528139835936};\\\", \\\"{x:1313,y:448,t:1528139836040};\\\", \\\"{x:1312,y:451,t:1528139836053};\\\", \\\"{x:1311,y:453,t:1528139836070};\\\", \\\"{x:1309,y:457,t:1528139836087};\\\", \\\"{x:1309,y:462,t:1528139836103};\\\", \\\"{x:1309,y:466,t:1528139836119};\\\", \\\"{x:1309,y:468,t:1528139836137};\\\", \\\"{x:1309,y:472,t:1528139836154};\\\", \\\"{x:1309,y:474,t:1528139836169};\\\", \\\"{x:1309,y:475,t:1528139836187};\\\", \\\"{x:1309,y:479,t:1528139836204};\\\", \\\"{x:1309,y:482,t:1528139836220};\\\", \\\"{x:1309,y:486,t:1528139836236};\\\", \\\"{x:1311,y:492,t:1528139836254};\\\", \\\"{x:1312,y:496,t:1528139836271};\\\", \\\"{x:1313,y:499,t:1528139836287};\\\", \\\"{x:1315,y:504,t:1528139836304};\\\", \\\"{x:1317,y:508,t:1528139836320};\\\", \\\"{x:1317,y:511,t:1528139836337};\\\", \\\"{x:1317,y:517,t:1528139836353};\\\", \\\"{x:1318,y:522,t:1528139836371};\\\", \\\"{x:1320,y:526,t:1528139836387};\\\", \\\"{x:1320,y:528,t:1528139836403};\\\", \\\"{x:1321,y:530,t:1528139836421};\\\", \\\"{x:1321,y:532,t:1528139836437};\\\", \\\"{x:1322,y:534,t:1528139836453};\\\", \\\"{x:1322,y:536,t:1528139836471};\\\", \\\"{x:1323,y:541,t:1528139836487};\\\", \\\"{x:1324,y:546,t:1528139836504};\\\", \\\"{x:1325,y:553,t:1528139836521};\\\", \\\"{x:1325,y:557,t:1528139836536};\\\", \\\"{x:1327,y:561,t:1528139836554};\\\", \\\"{x:1327,y:564,t:1528139836570};\\\", \\\"{x:1328,y:565,t:1528139836587};\\\", \\\"{x:1328,y:566,t:1528139836604};\\\", \\\"{x:1328,y:567,t:1528139836621};\\\", \\\"{x:1328,y:570,t:1528139836636};\\\", \\\"{x:1328,y:571,t:1528139836654};\\\", \\\"{x:1328,y:574,t:1528139836671};\\\", \\\"{x:1328,y:576,t:1528139836687};\\\", \\\"{x:1329,y:579,t:1528139836703};\\\", \\\"{x:1329,y:581,t:1528139836728};\\\", \\\"{x:1330,y:582,t:1528139836737};\\\", \\\"{x:1330,y:585,t:1528139836754};\\\", \\\"{x:1331,y:589,t:1528139836771};\\\", \\\"{x:1332,y:594,t:1528139836788};\\\", \\\"{x:1332,y:598,t:1528139836804};\\\", \\\"{x:1333,y:602,t:1528139836820};\\\", \\\"{x:1334,y:605,t:1528139836837};\\\", \\\"{x:1335,y:606,t:1528139836853};\\\", \\\"{x:1335,y:608,t:1528139836870};\\\", \\\"{x:1335,y:612,t:1528139836887};\\\", \\\"{x:1335,y:614,t:1528139836904};\\\", \\\"{x:1335,y:618,t:1528139836920};\\\", \\\"{x:1336,y:621,t:1528139836937};\\\", \\\"{x:1338,y:625,t:1528139836953};\\\", \\\"{x:1338,y:630,t:1528139836970};\\\", \\\"{x:1338,y:634,t:1528139836987};\\\", \\\"{x:1339,y:637,t:1528139837003};\\\", \\\"{x:1340,y:639,t:1528139837021};\\\", \\\"{x:1340,y:641,t:1528139837037};\\\", \\\"{x:1341,y:643,t:1528139837053};\\\", \\\"{x:1341,y:646,t:1528139837070};\\\", \\\"{x:1342,y:648,t:1528139837087};\\\", \\\"{x:1342,y:649,t:1528139837103};\\\", \\\"{x:1342,y:651,t:1528139837120};\\\", \\\"{x:1342,y:652,t:1528139837137};\\\", \\\"{x:1342,y:653,t:1528139837154};\\\", \\\"{x:1342,y:655,t:1528139837170};\\\", \\\"{x:1342,y:657,t:1528139837187};\\\", \\\"{x:1344,y:660,t:1528139837205};\\\", \\\"{x:1344,y:662,t:1528139837221};\\\", \\\"{x:1345,y:664,t:1528139837238};\\\", \\\"{x:1346,y:666,t:1528139837255};\\\", \\\"{x:1346,y:668,t:1528139837271};\\\", \\\"{x:1349,y:674,t:1528139837288};\\\", \\\"{x:1350,y:678,t:1528139837304};\\\", \\\"{x:1352,y:683,t:1528139837320};\\\", \\\"{x:1354,y:687,t:1528139837338};\\\", \\\"{x:1357,y:691,t:1528139837355};\\\", \\\"{x:1357,y:694,t:1528139837370};\\\", \\\"{x:1358,y:697,t:1528139837388};\\\", \\\"{x:1359,y:697,t:1528139837405};\\\", \\\"{x:1360,y:699,t:1528139837421};\\\", \\\"{x:1360,y:700,t:1528139837438};\\\", \\\"{x:1360,y:701,t:1528139837455};\\\", \\\"{x:1361,y:704,t:1528139837471};\\\", \\\"{x:1363,y:707,t:1528139837487};\\\", \\\"{x:1364,y:709,t:1528139837505};\\\", \\\"{x:1365,y:712,t:1528139837520};\\\", \\\"{x:1366,y:714,t:1528139837538};\\\", \\\"{x:1367,y:716,t:1528139837554};\\\", \\\"{x:1369,y:718,t:1528139837571};\\\", \\\"{x:1370,y:722,t:1528139837588};\\\", \\\"{x:1371,y:724,t:1528139837605};\\\", \\\"{x:1371,y:725,t:1528139837622};\\\", \\\"{x:1372,y:726,t:1528139837638};\\\", \\\"{x:1373,y:728,t:1528139837655};\\\", \\\"{x:1374,y:731,t:1528139837670};\\\", \\\"{x:1375,y:732,t:1528139837687};\\\", \\\"{x:1377,y:735,t:1528139837704};\\\", \\\"{x:1377,y:737,t:1528139837721};\\\", \\\"{x:1379,y:739,t:1528139837737};\\\", \\\"{x:1380,y:739,t:1528139837783};\\\", \\\"{x:1380,y:740,t:1528139837791};\\\", \\\"{x:1380,y:741,t:1528139837804};\\\", \\\"{x:1381,y:742,t:1528139837823};\\\", \\\"{x:1382,y:743,t:1528139837895};\\\", \\\"{x:1383,y:743,t:1528139837934};\\\", \\\"{x:1383,y:744,t:1528139837968};\\\", \\\"{x:1383,y:745,t:1528139837975};\\\", \\\"{x:1384,y:747,t:1528139837991};\\\", \\\"{x:1385,y:748,t:1528139838015};\\\", \\\"{x:1385,y:749,t:1528139838032};\\\", \\\"{x:1386,y:750,t:1528139838040};\\\", \\\"{x:1386,y:751,t:1528139838056};\\\", \\\"{x:1387,y:754,t:1528139838071};\\\", \\\"{x:1389,y:758,t:1528139838087};\\\", \\\"{x:1391,y:764,t:1528139838105};\\\", \\\"{x:1394,y:768,t:1528139838122};\\\", \\\"{x:1396,y:774,t:1528139838139};\\\", \\\"{x:1398,y:779,t:1528139838154};\\\", \\\"{x:1400,y:784,t:1528139838171};\\\", \\\"{x:1402,y:786,t:1528139838188};\\\", \\\"{x:1402,y:787,t:1528139838205};\\\", \\\"{x:1402,y:788,t:1528139838222};\\\", \\\"{x:1402,y:789,t:1528139838352};\\\", \\\"{x:1402,y:790,t:1528139838359};\\\", \\\"{x:1402,y:791,t:1528139838375};\\\", \\\"{x:1401,y:792,t:1528139838389};\\\", \\\"{x:1400,y:794,t:1528139838405};\\\", \\\"{x:1399,y:795,t:1528139838422};\\\", \\\"{x:1398,y:797,t:1528139838439};\\\", \\\"{x:1396,y:800,t:1528139838455};\\\", \\\"{x:1395,y:802,t:1528139838472};\\\", \\\"{x:1393,y:803,t:1528139838489};\\\", \\\"{x:1391,y:805,t:1528139838506};\\\", \\\"{x:1390,y:806,t:1528139838522};\\\", \\\"{x:1385,y:810,t:1528139838539};\\\", \\\"{x:1382,y:813,t:1528139838556};\\\", \\\"{x:1376,y:818,t:1528139838572};\\\", \\\"{x:1368,y:823,t:1528139838589};\\\", \\\"{x:1358,y:830,t:1528139838606};\\\", \\\"{x:1351,y:836,t:1528139838622};\\\", \\\"{x:1340,y:847,t:1528139838639};\\\", \\\"{x:1318,y:868,t:1528139838656};\\\", \\\"{x:1302,y:879,t:1528139838672};\\\", \\\"{x:1288,y:886,t:1528139838689};\\\", \\\"{x:1272,y:896,t:1528139838706};\\\", \\\"{x:1257,y:903,t:1528139838722};\\\", \\\"{x:1246,y:910,t:1528139838739};\\\", \\\"{x:1240,y:914,t:1528139838755};\\\", \\\"{x:1238,y:915,t:1528139838772};\\\", \\\"{x:1236,y:916,t:1528139838789};\\\", \\\"{x:1234,y:918,t:1528139838806};\\\", \\\"{x:1230,y:922,t:1528139838822};\\\", \\\"{x:1227,y:925,t:1528139838839};\\\", \\\"{x:1223,y:929,t:1528139838855};\\\", \\\"{x:1222,y:930,t:1528139838872};\\\", \\\"{x:1221,y:932,t:1528139838889};\\\", \\\"{x:1219,y:934,t:1528139838905};\\\", \\\"{x:1217,y:939,t:1528139838923};\\\", \\\"{x:1215,y:942,t:1528139838939};\\\", \\\"{x:1212,y:945,t:1528139838956};\\\", \\\"{x:1209,y:947,t:1528139838972};\\\", \\\"{x:1206,y:951,t:1528139838988};\\\", \\\"{x:1203,y:955,t:1528139839006};\\\", \\\"{x:1200,y:959,t:1528139839023};\\\", \\\"{x:1199,y:961,t:1528139839039};\\\", \\\"{x:1198,y:962,t:1528139839056};\\\", \\\"{x:1198,y:963,t:1528139839079};\\\", \\\"{x:1197,y:963,t:1528139839095};\\\", \\\"{x:1197,y:964,t:1528139839391};\\\", \\\"{x:1198,y:964,t:1528139839406};\\\", \\\"{x:1201,y:964,t:1528139839423};\\\", \\\"{x:1205,y:962,t:1528139839440};\\\", \\\"{x:1208,y:961,t:1528139839455};\\\", \\\"{x:1211,y:960,t:1528139839473};\\\", \\\"{x:1214,y:959,t:1528139839490};\\\", \\\"{x:1217,y:957,t:1528139839506};\\\", \\\"{x:1220,y:957,t:1528139839523};\\\", \\\"{x:1225,y:957,t:1528139839540};\\\", \\\"{x:1228,y:957,t:1528139839556};\\\", \\\"{x:1232,y:957,t:1528139839573};\\\", \\\"{x:1235,y:957,t:1528139839590};\\\", \\\"{x:1239,y:957,t:1528139839606};\\\", \\\"{x:1242,y:957,t:1528139839623};\\\", \\\"{x:1246,y:956,t:1528139839640};\\\", \\\"{x:1248,y:955,t:1528139839655};\\\", \\\"{x:1250,y:955,t:1528139839673};\\\", \\\"{x:1252,y:955,t:1528139839690};\\\", \\\"{x:1253,y:954,t:1528139839706};\\\", \\\"{x:1255,y:954,t:1528139839722};\\\", \\\"{x:1256,y:954,t:1528139839740};\\\", \\\"{x:1257,y:954,t:1528139839759};\\\", \\\"{x:1258,y:953,t:1528139839776};\\\", \\\"{x:1259,y:953,t:1528139839800};\\\", \\\"{x:1260,y:953,t:1528139839807};\\\", \\\"{x:1262,y:952,t:1528139839823};\\\", \\\"{x:1263,y:951,t:1528139839839};\\\", \\\"{x:1265,y:950,t:1528139839857};\\\", \\\"{x:1269,y:949,t:1528139839873};\\\", \\\"{x:1274,y:945,t:1528139839890};\\\", \\\"{x:1278,y:942,t:1528139839907};\\\", \\\"{x:1283,y:938,t:1528139839923};\\\", \\\"{x:1288,y:935,t:1528139839940};\\\", \\\"{x:1293,y:932,t:1528139839957};\\\", \\\"{x:1298,y:928,t:1528139839973};\\\", \\\"{x:1301,y:926,t:1528139839990};\\\", \\\"{x:1303,y:925,t:1528139840007};\\\", \\\"{x:1306,y:922,t:1528139840023};\\\", \\\"{x:1309,y:918,t:1528139840040};\\\", \\\"{x:1311,y:915,t:1528139840057};\\\", \\\"{x:1314,y:912,t:1528139840073};\\\", \\\"{x:1316,y:910,t:1528139840090};\\\", \\\"{x:1317,y:909,t:1528139840107};\\\", \\\"{x:1320,y:908,t:1528139840123};\\\", \\\"{x:1321,y:907,t:1528139840141};\\\", \\\"{x:1324,y:904,t:1528139840157};\\\", \\\"{x:1327,y:902,t:1528139840173};\\\", \\\"{x:1330,y:898,t:1528139840190};\\\", \\\"{x:1333,y:896,t:1528139840207};\\\", \\\"{x:1337,y:892,t:1528139840224};\\\", \\\"{x:1339,y:890,t:1528139840240};\\\", \\\"{x:1341,y:889,t:1528139840257};\\\", \\\"{x:1343,y:885,t:1528139840274};\\\", \\\"{x:1346,y:882,t:1528139840290};\\\", \\\"{x:1348,y:880,t:1528139840306};\\\", \\\"{x:1348,y:878,t:1528139840324};\\\", \\\"{x:1349,y:877,t:1528139840340};\\\", \\\"{x:1350,y:875,t:1528139840357};\\\", \\\"{x:1351,y:873,t:1528139840374};\\\", \\\"{x:1351,y:870,t:1528139840390};\\\", \\\"{x:1353,y:867,t:1528139840407};\\\", \\\"{x:1354,y:862,t:1528139840424};\\\", \\\"{x:1355,y:860,t:1528139840440};\\\", \\\"{x:1355,y:858,t:1528139840457};\\\", \\\"{x:1355,y:857,t:1528139840474};\\\", \\\"{x:1357,y:854,t:1528139840490};\\\", \\\"{x:1357,y:852,t:1528139840507};\\\", \\\"{x:1358,y:849,t:1528139840524};\\\", \\\"{x:1359,y:843,t:1528139840540};\\\", \\\"{x:1361,y:836,t:1528139840557};\\\", \\\"{x:1361,y:833,t:1528139840574};\\\", \\\"{x:1361,y:830,t:1528139840590};\\\", \\\"{x:1363,y:824,t:1528139840607};\\\", \\\"{x:1364,y:820,t:1528139840623};\\\", \\\"{x:1365,y:815,t:1528139840641};\\\", \\\"{x:1366,y:808,t:1528139840656};\\\", \\\"{x:1367,y:804,t:1528139840674};\\\", \\\"{x:1368,y:799,t:1528139840690};\\\", \\\"{x:1368,y:797,t:1528139840707};\\\", \\\"{x:1369,y:790,t:1528139840723};\\\", \\\"{x:1370,y:789,t:1528139840741};\\\", \\\"{x:1370,y:785,t:1528139840758};\\\", \\\"{x:1370,y:782,t:1528139840774};\\\", \\\"{x:1370,y:778,t:1528139840791};\\\", \\\"{x:1370,y:772,t:1528139840807};\\\", \\\"{x:1370,y:765,t:1528139840824};\\\", \\\"{x:1370,y:763,t:1528139840841};\\\", \\\"{x:1370,y:760,t:1528139840857};\\\", \\\"{x:1370,y:754,t:1528139840874};\\\", \\\"{x:1370,y:749,t:1528139840891};\\\", \\\"{x:1370,y:745,t:1528139840907};\\\", \\\"{x:1370,y:737,t:1528139840924};\\\", \\\"{x:1370,y:727,t:1528139840941};\\\", \\\"{x:1370,y:722,t:1528139840957};\\\", \\\"{x:1369,y:718,t:1528139840974};\\\", \\\"{x:1367,y:712,t:1528139840991};\\\", \\\"{x:1366,y:710,t:1528139841007};\\\", \\\"{x:1365,y:706,t:1528139841024};\\\", \\\"{x:1365,y:705,t:1528139841041};\\\", \\\"{x:1365,y:704,t:1528139841057};\\\", \\\"{x:1364,y:706,t:1528139841472};\\\", \\\"{x:1361,y:714,t:1528139841480};\\\", \\\"{x:1359,y:722,t:1528139841491};\\\", \\\"{x:1354,y:735,t:1528139841508};\\\", \\\"{x:1353,y:741,t:1528139841524};\\\", \\\"{x:1351,y:745,t:1528139841541};\\\", \\\"{x:1349,y:749,t:1528139841558};\\\", \\\"{x:1348,y:750,t:1528139841574};\\\", \\\"{x:1346,y:752,t:1528139841591};\\\", \\\"{x:1342,y:753,t:1528139841608};\\\", \\\"{x:1337,y:753,t:1528139841625};\\\", \\\"{x:1329,y:755,t:1528139841641};\\\", \\\"{x:1324,y:756,t:1528139841658};\\\", \\\"{x:1321,y:757,t:1528139841675};\\\", \\\"{x:1320,y:757,t:1528139841744};\\\", \\\"{x:1322,y:759,t:1528139842175};\\\", \\\"{x:1325,y:759,t:1528139842199};\\\", \\\"{x:1328,y:760,t:1528139842207};\\\", \\\"{x:1334,y:761,t:1528139842224};\\\", \\\"{x:1341,y:764,t:1528139842241};\\\", \\\"{x:1347,y:765,t:1528139842258};\\\", \\\"{x:1352,y:765,t:1528139842275};\\\", \\\"{x:1357,y:768,t:1528139842292};\\\", \\\"{x:1360,y:768,t:1528139842308};\\\", \\\"{x:1363,y:769,t:1528139842324};\\\", \\\"{x:1364,y:769,t:1528139842342};\\\", \\\"{x:1365,y:769,t:1528139842357};\\\", \\\"{x:1365,y:770,t:1528139842767};\\\", \\\"{x:1364,y:772,t:1528139842776};\\\", \\\"{x:1358,y:781,t:1528139842792};\\\", \\\"{x:1357,y:782,t:1528139842809};\\\", \\\"{x:1356,y:784,t:1528139842824};\\\", \\\"{x:1355,y:785,t:1528139842841};\\\", \\\"{x:1354,y:786,t:1528139842858};\\\", \\\"{x:1353,y:788,t:1528139842876};\\\", \\\"{x:1350,y:791,t:1528139842891};\\\", \\\"{x:1347,y:798,t:1528139842908};\\\", \\\"{x:1344,y:801,t:1528139842925};\\\", \\\"{x:1342,y:806,t:1528139842942};\\\", \\\"{x:1341,y:807,t:1528139842959};\\\", \\\"{x:1338,y:812,t:1528139842974};\\\", \\\"{x:1335,y:816,t:1528139842992};\\\", \\\"{x:1332,y:823,t:1528139843009};\\\", \\\"{x:1327,y:831,t:1528139843025};\\\", \\\"{x:1323,y:839,t:1528139843042};\\\", \\\"{x:1317,y:848,t:1528139843058};\\\", \\\"{x:1313,y:853,t:1528139843076};\\\", \\\"{x:1311,y:857,t:1528139843091};\\\", \\\"{x:1309,y:859,t:1528139843109};\\\", \\\"{x:1307,y:862,t:1528139843126};\\\", \\\"{x:1306,y:864,t:1528139843142};\\\", \\\"{x:1303,y:869,t:1528139843159};\\\", \\\"{x:1302,y:873,t:1528139843175};\\\", \\\"{x:1300,y:875,t:1528139843192};\\\", \\\"{x:1298,y:877,t:1528139843209};\\\", \\\"{x:1296,y:879,t:1528139843226};\\\", \\\"{x:1295,y:881,t:1528139843242};\\\", \\\"{x:1293,y:883,t:1528139843259};\\\", \\\"{x:1293,y:884,t:1528139843275};\\\", \\\"{x:1292,y:886,t:1528139843293};\\\", \\\"{x:1292,y:887,t:1528139843308};\\\", \\\"{x:1291,y:888,t:1528139843326};\\\", \\\"{x:1290,y:888,t:1528139843343};\\\", \\\"{x:1290,y:890,t:1528139843367};\\\", \\\"{x:1289,y:890,t:1528139843391};\\\", \\\"{x:1289,y:891,t:1528139843407};\\\", \\\"{x:1288,y:891,t:1528139843415};\\\", \\\"{x:1287,y:892,t:1528139843431};\\\", \\\"{x:1287,y:893,t:1528139843443};\\\", \\\"{x:1286,y:893,t:1528139843472};\\\", \\\"{x:1285,y:894,t:1528139843487};\\\", \\\"{x:1285,y:893,t:1528139843920};\\\", \\\"{x:1285,y:892,t:1528139843927};\\\", \\\"{x:1286,y:890,t:1528139843944};\\\", \\\"{x:1288,y:888,t:1528139843959};\\\", \\\"{x:1289,y:886,t:1528139843976};\\\", \\\"{x:1289,y:885,t:1528139843994};\\\", \\\"{x:1291,y:883,t:1528139844010};\\\", \\\"{x:1291,y:882,t:1528139844026};\\\", \\\"{x:1292,y:881,t:1528139844047};\\\", \\\"{x:1292,y:880,t:1528139844060};\\\", \\\"{x:1293,y:879,t:1528139844087};\\\", \\\"{x:1293,y:878,t:1528139844103};\\\", \\\"{x:1294,y:877,t:1528139844111};\\\", \\\"{x:1294,y:876,t:1528139844144};\\\", \\\"{x:1295,y:875,t:1528139844175};\\\", \\\"{x:1295,y:874,t:1528139844192};\\\", \\\"{x:1295,y:873,t:1528139844223};\\\", \\\"{x:1296,y:873,t:1528139844230};\\\", \\\"{x:1296,y:871,t:1528139844247};\\\", \\\"{x:1296,y:870,t:1528139844260};\\\", \\\"{x:1298,y:866,t:1528139844276};\\\", \\\"{x:1301,y:863,t:1528139844293};\\\", \\\"{x:1305,y:857,t:1528139844309};\\\", \\\"{x:1313,y:847,t:1528139844327};\\\", \\\"{x:1317,y:843,t:1528139844342};\\\", \\\"{x:1319,y:840,t:1528139844360};\\\", \\\"{x:1322,y:839,t:1528139844376};\\\", \\\"{x:1323,y:838,t:1528139844393};\\\", \\\"{x:1324,y:837,t:1528139844409};\\\", \\\"{x:1325,y:836,t:1528139844427};\\\", \\\"{x:1326,y:835,t:1528139844443};\\\", \\\"{x:1326,y:834,t:1528139844460};\\\", \\\"{x:1327,y:832,t:1528139844476};\\\", \\\"{x:1328,y:831,t:1528139844512};\\\", \\\"{x:1329,y:830,t:1528139844544};\\\", \\\"{x:1330,y:829,t:1528139844560};\\\", \\\"{x:1331,y:828,t:1528139844577};\\\", \\\"{x:1331,y:827,t:1528139844599};\\\", \\\"{x:1332,y:826,t:1528139844672};\\\", \\\"{x:1333,y:826,t:1528139844703};\\\", \\\"{x:1335,y:825,t:1528139844711};\\\", \\\"{x:1339,y:824,t:1528139844727};\\\", \\\"{x:1344,y:823,t:1528139844743};\\\", \\\"{x:1348,y:820,t:1528139844760};\\\", \\\"{x:1352,y:818,t:1528139844777};\\\", \\\"{x:1357,y:816,t:1528139844793};\\\", \\\"{x:1359,y:814,t:1528139844810};\\\", \\\"{x:1360,y:814,t:1528139844832};\\\", \\\"{x:1361,y:813,t:1528139844844};\\\", \\\"{x:1362,y:812,t:1528139844860};\\\", \\\"{x:1363,y:812,t:1528139844877};\\\", \\\"{x:1363,y:810,t:1528139844894};\\\", \\\"{x:1363,y:808,t:1528139844910};\\\", \\\"{x:1363,y:807,t:1528139844936};\\\", \\\"{x:1363,y:806,t:1528139844951};\\\", \\\"{x:1363,y:805,t:1528139844968};\\\", \\\"{x:1363,y:804,t:1528139844983};\\\", \\\"{x:1363,y:803,t:1528139844999};\\\", \\\"{x:1361,y:800,t:1528139845015};\\\", \\\"{x:1359,y:797,t:1528139845027};\\\", \\\"{x:1352,y:790,t:1528139845044};\\\", \\\"{x:1342,y:784,t:1528139845061};\\\", \\\"{x:1333,y:780,t:1528139845077};\\\", \\\"{x:1333,y:779,t:1528139845183};\\\", \\\"{x:1335,y:775,t:1528139845280};\\\", \\\"{x:1339,y:770,t:1528139845294};\\\", \\\"{x:1346,y:762,t:1528139845311};\\\", \\\"{x:1352,y:758,t:1528139845328};\\\", \\\"{x:1357,y:755,t:1528139845344};\\\", \\\"{x:1359,y:753,t:1528139845361};\\\", \\\"{x:1360,y:753,t:1528139845377};\\\", \\\"{x:1360,y:752,t:1528139845394};\\\", \\\"{x:1360,y:754,t:1528139845664};\\\", \\\"{x:1358,y:756,t:1528139845678};\\\", \\\"{x:1358,y:759,t:1528139845694};\\\", \\\"{x:1355,y:760,t:1528139845751};\\\", \\\"{x:1354,y:761,t:1528139845911};\\\", \\\"{x:1351,y:762,t:1528139845928};\\\", \\\"{x:1350,y:763,t:1528139845944};\\\", \\\"{x:1349,y:763,t:1528139845960};\\\", \\\"{x:1348,y:763,t:1528139845976};\\\", \\\"{x:1348,y:763,t:1528139845991};\\\", \\\"{x:1346,y:763,t:1528139846807};\\\", \\\"{x:1334,y:761,t:1528139846815};\\\", \\\"{x:1320,y:751,t:1528139846828};\\\", \\\"{x:1291,y:736,t:1528139846845};\\\", \\\"{x:1218,y:704,t:1528139846862};\\\", \\\"{x:1151,y:685,t:1528139846878};\\\", \\\"{x:1073,y:662,t:1528139846895};\\\", \\\"{x:998,y:640,t:1528139846912};\\\", \\\"{x:917,y:616,t:1528139846929};\\\", \\\"{x:829,y:593,t:1528139846946};\\\", \\\"{x:748,y:569,t:1528139846962};\\\", \\\"{x:681,y:549,t:1528139846979};\\\", \\\"{x:626,y:535,t:1528139846995};\\\", \\\"{x:593,y:526,t:1528139847013};\\\", \\\"{x:569,y:521,t:1528139847028};\\\", \\\"{x:556,y:519,t:1528139847045};\\\", \\\"{x:540,y:516,t:1528139847063};\\\", \\\"{x:535,y:515,t:1528139847079};\\\", \\\"{x:531,y:515,t:1528139847095};\\\", \\\"{x:528,y:513,t:1528139847112};\\\", \\\"{x:524,y:513,t:1528139847129};\\\", \\\"{x:520,y:513,t:1528139847146};\\\", \\\"{x:517,y:511,t:1528139847162};\\\", \\\"{x:517,y:510,t:1528139847359};\\\", \\\"{x:520,y:508,t:1528139847367};\\\", \\\"{x:526,y:504,t:1528139847380};\\\", \\\"{x:539,y:496,t:1528139847396};\\\", \\\"{x:555,y:484,t:1528139847414};\\\", \\\"{x:570,y:475,t:1528139847430};\\\", \\\"{x:581,y:470,t:1528139847445};\\\", \\\"{x:597,y:466,t:1528139847462};\\\", \\\"{x:610,y:462,t:1528139847479};\\\", \\\"{x:624,y:457,t:1528139847495};\\\", \\\"{x:636,y:453,t:1528139847513};\\\", \\\"{x:649,y:451,t:1528139847530};\\\", \\\"{x:659,y:449,t:1528139847545};\\\", \\\"{x:674,y:449,t:1528139847562};\\\", \\\"{x:693,y:449,t:1528139847580};\\\", \\\"{x:709,y:449,t:1528139847595};\\\", \\\"{x:724,y:449,t:1528139847612};\\\", \\\"{x:739,y:449,t:1528139847630};\\\", \\\"{x:750,y:449,t:1528139847645};\\\", \\\"{x:769,y:449,t:1528139847663};\\\", \\\"{x:779,y:449,t:1528139847679};\\\", \\\"{x:786,y:449,t:1528139847695};\\\", \\\"{x:793,y:449,t:1528139847712};\\\", \\\"{x:797,y:450,t:1528139847730};\\\", \\\"{x:801,y:452,t:1528139847746};\\\", \\\"{x:806,y:455,t:1528139847762};\\\", \\\"{x:814,y:460,t:1528139847780};\\\", \\\"{x:824,y:466,t:1528139847797};\\\", \\\"{x:834,y:475,t:1528139847812};\\\", \\\"{x:843,y:482,t:1528139847830};\\\", \\\"{x:866,y:498,t:1528139847848};\\\", \\\"{x:901,y:521,t:1528139847863};\\\", \\\"{x:956,y:554,t:1528139847879};\\\", \\\"{x:998,y:575,t:1528139847897};\\\", \\\"{x:1017,y:584,t:1528139847913};\\\", \\\"{x:1037,y:591,t:1528139847930};\\\", \\\"{x:1064,y:602,t:1528139847947};\\\", \\\"{x:1083,y:609,t:1528139847963};\\\", \\\"{x:1101,y:614,t:1528139847980};\\\", \\\"{x:1118,y:621,t:1528139847997};\\\", \\\"{x:1136,y:629,t:1528139848013};\\\", \\\"{x:1156,y:637,t:1528139848030};\\\", \\\"{x:1191,y:652,t:1528139848047};\\\", \\\"{x:1216,y:664,t:1528139848062};\\\", \\\"{x:1238,y:672,t:1528139848080};\\\", \\\"{x:1260,y:682,t:1528139848097};\\\", \\\"{x:1280,y:691,t:1528139848113};\\\", \\\"{x:1305,y:699,t:1528139848130};\\\", \\\"{x:1328,y:704,t:1528139848147};\\\", \\\"{x:1363,y:716,t:1528139848162};\\\", \\\"{x:1402,y:726,t:1528139848180};\\\", \\\"{x:1434,y:736,t:1528139848197};\\\", \\\"{x:1458,y:744,t:1528139848214};\\\", \\\"{x:1479,y:753,t:1528139848230};\\\", \\\"{x:1514,y:763,t:1528139848247};\\\", \\\"{x:1534,y:770,t:1528139848264};\\\", \\\"{x:1549,y:775,t:1528139848279};\\\", \\\"{x:1555,y:778,t:1528139848297};\\\", \\\"{x:1557,y:779,t:1528139848315};\\\", \\\"{x:1558,y:780,t:1528139848407};\\\", \\\"{x:1555,y:780,t:1528139848496};\\\", \\\"{x:1547,y:782,t:1528139848503};\\\", \\\"{x:1540,y:783,t:1528139848514};\\\", \\\"{x:1524,y:784,t:1528139848530};\\\", \\\"{x:1506,y:784,t:1528139848547};\\\", \\\"{x:1487,y:784,t:1528139848564};\\\", \\\"{x:1470,y:784,t:1528139848580};\\\", \\\"{x:1457,y:784,t:1528139848597};\\\", \\\"{x:1446,y:784,t:1528139848614};\\\", \\\"{x:1439,y:783,t:1528139848631};\\\", \\\"{x:1436,y:782,t:1528139848647};\\\", \\\"{x:1435,y:782,t:1528139848670};\\\", \\\"{x:1433,y:782,t:1528139848694};\\\", \\\"{x:1431,y:782,t:1528139848702};\\\", \\\"{x:1429,y:782,t:1528139848713};\\\", \\\"{x:1425,y:780,t:1528139848730};\\\", \\\"{x:1418,y:779,t:1528139848746};\\\", \\\"{x:1411,y:778,t:1528139848763};\\\", \\\"{x:1399,y:776,t:1528139848781};\\\", \\\"{x:1384,y:770,t:1528139848796};\\\", \\\"{x:1372,y:767,t:1528139848813};\\\", \\\"{x:1355,y:763,t:1528139848831};\\\", \\\"{x:1350,y:763,t:1528139848847};\\\", \\\"{x:1347,y:763,t:1528139848864};\\\", \\\"{x:1346,y:763,t:1528139848880};\\\", \\\"{x:1345,y:763,t:1528139848897};\\\", \\\"{x:1344,y:763,t:1528139848919};\\\", \\\"{x:1343,y:763,t:1528139848983};\\\", \\\"{x:1342,y:763,t:1528139849152};\\\", \\\"{x:1337,y:763,t:1528139849165};\\\", \\\"{x:1328,y:763,t:1528139849181};\\\", \\\"{x:1311,y:768,t:1528139849198};\\\", \\\"{x:1296,y:776,t:1528139849214};\\\", \\\"{x:1272,y:792,t:1528139849232};\\\", \\\"{x:1255,y:805,t:1528139849248};\\\", \\\"{x:1238,y:821,t:1528139849264};\\\", \\\"{x:1222,y:835,t:1528139849281};\\\", \\\"{x:1214,y:847,t:1528139849298};\\\", \\\"{x:1206,y:863,t:1528139849314};\\\", \\\"{x:1203,y:871,t:1528139849331};\\\", \\\"{x:1198,y:887,t:1528139849348};\\\", \\\"{x:1192,y:907,t:1528139849364};\\\", \\\"{x:1188,y:920,t:1528139849382};\\\", \\\"{x:1183,y:931,t:1528139849398};\\\", \\\"{x:1177,y:945,t:1528139849414};\\\", \\\"{x:1175,y:964,t:1528139849431};\\\", \\\"{x:1173,y:972,t:1528139849448};\\\", \\\"{x:1172,y:978,t:1528139849464};\\\", \\\"{x:1172,y:985,t:1528139849481};\\\", \\\"{x:1171,y:990,t:1528139849498};\\\", \\\"{x:1171,y:995,t:1528139849514};\\\", \\\"{x:1171,y:999,t:1528139849531};\\\", \\\"{x:1171,y:1000,t:1528139849548};\\\", \\\"{x:1171,y:1002,t:1528139849565};\\\", \\\"{x:1171,y:1003,t:1528139849583};\\\", \\\"{x:1172,y:999,t:1528139849735};\\\", \\\"{x:1175,y:995,t:1528139849748};\\\", \\\"{x:1183,y:986,t:1528139849765};\\\", \\\"{x:1193,y:972,t:1528139849782};\\\", \\\"{x:1203,y:960,t:1528139849799};\\\", \\\"{x:1214,y:945,t:1528139849815};\\\", \\\"{x:1221,y:936,t:1528139849831};\\\", \\\"{x:1226,y:928,t:1528139849848};\\\", \\\"{x:1232,y:919,t:1528139849865};\\\", \\\"{x:1240,y:897,t:1528139849881};\\\", \\\"{x:1245,y:888,t:1528139849898};\\\", \\\"{x:1249,y:877,t:1528139849915};\\\", \\\"{x:1257,y:860,t:1528139849931};\\\", \\\"{x:1263,y:847,t:1528139849948};\\\", \\\"{x:1268,y:832,t:1528139849965};\\\", \\\"{x:1270,y:823,t:1528139849981};\\\", \\\"{x:1272,y:819,t:1528139849998};\\\", \\\"{x:1272,y:813,t:1528139850015};\\\", \\\"{x:1272,y:809,t:1528139850031};\\\", \\\"{x:1272,y:804,t:1528139850047};\\\", \\\"{x:1272,y:799,t:1528139850064};\\\", \\\"{x:1265,y:790,t:1528139850081};\\\", \\\"{x:1252,y:780,t:1528139850098};\\\", \\\"{x:1244,y:775,t:1528139850115};\\\", \\\"{x:1239,y:772,t:1528139850131};\\\", \\\"{x:1234,y:769,t:1528139850147};\\\", \\\"{x:1225,y:768,t:1528139850164};\\\", \\\"{x:1218,y:767,t:1528139850182};\\\", \\\"{x:1213,y:767,t:1528139850197};\\\", \\\"{x:1212,y:767,t:1528139850215};\\\", \\\"{x:1211,y:767,t:1528139850303};\\\", \\\"{x:1210,y:767,t:1528139850335};\\\", \\\"{x:1208,y:767,t:1528139850349};\\\", \\\"{x:1203,y:767,t:1528139850366};\\\", \\\"{x:1198,y:767,t:1528139850382};\\\", \\\"{x:1186,y:763,t:1528139850399};\\\", \\\"{x:1170,y:759,t:1528139850416};\\\", \\\"{x:1161,y:758,t:1528139850432};\\\", \\\"{x:1156,y:758,t:1528139850448};\\\", \\\"{x:1155,y:758,t:1528139850479};\\\", \\\"{x:1156,y:758,t:1528139850823};\\\", \\\"{x:1157,y:758,t:1528139850832};\\\", \\\"{x:1158,y:759,t:1528139850849};\\\", \\\"{x:1160,y:759,t:1528139850865};\\\", \\\"{x:1161,y:759,t:1528139850895};\\\", \\\"{x:1162,y:759,t:1528139850951};\\\", \\\"{x:1163,y:759,t:1528139850975};\\\", \\\"{x:1164,y:759,t:1528139850991};\\\", \\\"{x:1166,y:759,t:1528139851007};\\\", \\\"{x:1167,y:759,t:1528139851016};\\\", \\\"{x:1171,y:759,t:1528139851032};\\\", \\\"{x:1176,y:759,t:1528139851049};\\\", \\\"{x:1182,y:759,t:1528139851066};\\\", \\\"{x:1187,y:759,t:1528139851083};\\\", \\\"{x:1194,y:759,t:1528139851100};\\\", \\\"{x:1201,y:760,t:1528139851116};\\\", \\\"{x:1214,y:760,t:1528139851133};\\\", \\\"{x:1227,y:760,t:1528139851149};\\\", \\\"{x:1231,y:760,t:1528139851166};\\\", \\\"{x:1235,y:760,t:1528139851183};\\\", \\\"{x:1239,y:760,t:1528139851199};\\\", \\\"{x:1241,y:760,t:1528139851216};\\\", \\\"{x:1243,y:760,t:1528139851232};\\\", \\\"{x:1244,y:760,t:1528139851249};\\\", \\\"{x:1246,y:760,t:1528139851266};\\\", \\\"{x:1247,y:760,t:1528139851281};\\\", \\\"{x:1250,y:760,t:1528139851299};\\\", \\\"{x:1254,y:760,t:1528139851316};\\\", \\\"{x:1262,y:760,t:1528139851332};\\\", \\\"{x:1277,y:759,t:1528139851348};\\\", \\\"{x:1291,y:759,t:1528139851365};\\\", \\\"{x:1301,y:759,t:1528139851381};\\\", \\\"{x:1332,y:759,t:1528139851398};\\\", \\\"{x:1349,y:759,t:1528139851416};\\\", \\\"{x:1359,y:759,t:1528139851433};\\\", \\\"{x:1367,y:759,t:1528139851449};\\\", \\\"{x:1374,y:759,t:1528139851466};\\\", \\\"{x:1378,y:759,t:1528139851481};\\\", \\\"{x:1381,y:759,t:1528139851499};\\\", \\\"{x:1382,y:759,t:1528139851515};\\\", \\\"{x:1384,y:759,t:1528139851533};\\\", \\\"{x:1391,y:759,t:1528139851549};\\\", \\\"{x:1395,y:759,t:1528139851566};\\\", \\\"{x:1401,y:759,t:1528139851583};\\\", \\\"{x:1402,y:759,t:1528139851599};\\\", \\\"{x:1403,y:759,t:1528139851616};\\\", \\\"{x:1404,y:759,t:1528139851633};\\\", \\\"{x:1405,y:759,t:1528139851656};\\\", \\\"{x:1406,y:759,t:1528139851666};\\\", \\\"{x:1407,y:759,t:1528139851683};\\\", \\\"{x:1408,y:759,t:1528139851720};\\\", \\\"{x:1406,y:759,t:1528139851903};\\\", \\\"{x:1405,y:759,t:1528139851916};\\\", \\\"{x:1402,y:759,t:1528139851933};\\\", \\\"{x:1399,y:759,t:1528139851949};\\\", \\\"{x:1396,y:759,t:1528139851966};\\\", \\\"{x:1391,y:759,t:1528139851983};\\\", \\\"{x:1389,y:759,t:1528139852000};\\\", \\\"{x:1385,y:759,t:1528139852017};\\\", \\\"{x:1382,y:759,t:1528139852033};\\\", \\\"{x:1378,y:759,t:1528139852050};\\\", \\\"{x:1377,y:759,t:1528139852067};\\\", \\\"{x:1376,y:759,t:1528139852083};\\\", \\\"{x:1375,y:759,t:1528139852190};\\\", \\\"{x:1373,y:759,t:1528139852206};\\\", \\\"{x:1372,y:759,t:1528139852222};\\\", \\\"{x:1371,y:760,t:1528139852233};\\\", \\\"{x:1368,y:761,t:1528139852249};\\\", \\\"{x:1365,y:761,t:1528139852266};\\\", \\\"{x:1362,y:762,t:1528139852283};\\\", \\\"{x:1359,y:762,t:1528139852300};\\\", \\\"{x:1357,y:762,t:1528139852316};\\\", \\\"{x:1355,y:762,t:1528139852333};\\\", \\\"{x:1354,y:762,t:1528139852350};\\\", \\\"{x:1353,y:763,t:1528139852375};\\\", \\\"{x:1352,y:763,t:1528139852415};\\\", \\\"{x:1351,y:763,t:1528139852439};\\\", \\\"{x:1349,y:763,t:1528139852455};\\\", \\\"{x:1348,y:764,t:1528139852471};\\\", \\\"{x:1347,y:764,t:1528139852495};\\\", \\\"{x:1346,y:764,t:1528139852552};\\\", \\\"{x:1345,y:764,t:1528139852567};\\\", \\\"{x:1344,y:764,t:1528139852591};\\\", \\\"{x:1343,y:764,t:1528139852600};\\\", \\\"{x:1342,y:764,t:1528139852617};\\\", \\\"{x:1341,y:768,t:1528139853152};\\\", \\\"{x:1338,y:777,t:1528139853167};\\\", \\\"{x:1337,y:786,t:1528139853184};\\\", \\\"{x:1337,y:791,t:1528139853201};\\\", \\\"{x:1337,y:798,t:1528139853217};\\\", \\\"{x:1337,y:802,t:1528139853234};\\\", \\\"{x:1336,y:805,t:1528139853251};\\\", \\\"{x:1336,y:809,t:1528139853268};\\\", \\\"{x:1334,y:813,t:1528139853284};\\\", \\\"{x:1334,y:816,t:1528139853300};\\\", \\\"{x:1334,y:819,t:1528139853318};\\\", \\\"{x:1333,y:824,t:1528139853334};\\\", \\\"{x:1333,y:826,t:1528139853350};\\\", \\\"{x:1333,y:832,t:1528139853367};\\\", \\\"{x:1333,y:835,t:1528139853384};\\\", \\\"{x:1333,y:839,t:1528139853400};\\\", \\\"{x:1333,y:841,t:1528139853418};\\\", \\\"{x:1333,y:844,t:1528139853433};\\\", \\\"{x:1333,y:849,t:1528139853450};\\\", \\\"{x:1333,y:854,t:1528139853468};\\\", \\\"{x:1333,y:858,t:1528139853483};\\\", \\\"{x:1333,y:862,t:1528139853501};\\\", \\\"{x:1333,y:868,t:1528139853518};\\\", \\\"{x:1333,y:876,t:1528139853533};\\\", \\\"{x:1333,y:886,t:1528139853550};\\\", \\\"{x:1333,y:892,t:1528139853568};\\\", \\\"{x:1333,y:899,t:1528139853584};\\\", \\\"{x:1333,y:901,t:1528139853601};\\\", \\\"{x:1333,y:903,t:1528139853617};\\\", \\\"{x:1334,y:905,t:1528139853635};\\\", \\\"{x:1334,y:906,t:1528139853651};\\\", \\\"{x:1334,y:907,t:1528139853668};\\\", \\\"{x:1334,y:908,t:1528139853685};\\\", \\\"{x:1335,y:908,t:1528139853701};\\\", \\\"{x:1335,y:909,t:1528139853718};\\\", \\\"{x:1335,y:909,t:1528139853873};\\\", \\\"{x:1335,y:908,t:1528139854039};\\\", \\\"{x:1335,y:890,t:1528139854051};\\\", \\\"{x:1331,y:862,t:1528139854069};\\\", \\\"{x:1330,y:843,t:1528139854086};\\\", \\\"{x:1328,y:831,t:1528139854102};\\\", \\\"{x:1328,y:828,t:1528139854118};\\\", \\\"{x:1328,y:827,t:1528139854696};\\\", \\\"{x:1328,y:817,t:1528139854703};\\\", \\\"{x:1337,y:776,t:1528139854720};\\\", \\\"{x:1343,y:760,t:1528139854737};\\\", \\\"{x:1350,y:748,t:1528139854754};\\\", \\\"{x:1352,y:743,t:1528139854771};\\\", \\\"{x:1355,y:738,t:1528139854786};\\\", \\\"{x:1358,y:734,t:1528139854803};\\\", \\\"{x:1360,y:729,t:1528139854821};\\\", \\\"{x:1362,y:726,t:1528139854836};\\\", \\\"{x:1363,y:723,t:1528139854854};\\\", \\\"{x:1366,y:720,t:1528139854870};\\\", \\\"{x:1367,y:717,t:1528139854887};\\\", \\\"{x:1368,y:716,t:1528139854903};\\\", \\\"{x:1368,y:715,t:1528139854952};\\\", \\\"{x:1368,y:714,t:1528139854959};\\\", \\\"{x:1369,y:714,t:1528139854975};\\\", \\\"{x:1369,y:713,t:1528139854991};\\\", \\\"{x:1369,y:712,t:1528139855003};\\\", \\\"{x:1371,y:710,t:1528139855020};\\\", \\\"{x:1373,y:707,t:1528139855038};\\\", \\\"{x:1375,y:704,t:1528139855055};\\\", \\\"{x:1376,y:703,t:1528139855071};\\\", \\\"{x:1378,y:702,t:1528139855103};\\\", \\\"{x:1378,y:701,t:1528139855135};\\\", \\\"{x:1378,y:700,t:1528139855183};\\\", \\\"{x:1379,y:700,t:1528139855959};\\\", \\\"{x:1379,y:701,t:1528139855975};\\\", \\\"{x:1379,y:703,t:1528139855990};\\\", \\\"{x:1378,y:704,t:1528139856007};\\\", \\\"{x:1377,y:707,t:1528139856023};\\\", \\\"{x:1376,y:708,t:1528139856039};\\\", \\\"{x:1376,y:709,t:1528139856071};\\\", \\\"{x:1375,y:710,t:1528139856079};\\\", \\\"{x:1375,y:711,t:1528139856095};\\\", \\\"{x:1375,y:712,t:1528139856111};\\\", \\\"{x:1374,y:713,t:1528139856123};\\\", \\\"{x:1374,y:714,t:1528139856141};\\\", \\\"{x:1373,y:715,t:1528139856156};\\\", \\\"{x:1372,y:716,t:1528139856199};\\\", \\\"{x:1372,y:717,t:1528139856215};\\\", \\\"{x:1371,y:718,t:1528139856223};\\\", \\\"{x:1371,y:719,t:1528139856255};\\\", \\\"{x:1371,y:720,t:1528139856296};\\\", \\\"{x:1370,y:721,t:1528139856327};\\\", \\\"{x:1369,y:722,t:1528139856431};\\\", \\\"{x:1368,y:723,t:1528139858368};\\\", \\\"{x:1367,y:727,t:1528139858380};\\\", \\\"{x:1364,y:733,t:1528139858396};\\\", \\\"{x:1362,y:741,t:1528139858412};\\\", \\\"{x:1361,y:745,t:1528139858430};\\\", \\\"{x:1360,y:751,t:1528139858445};\\\", \\\"{x:1359,y:754,t:1528139858462};\\\", \\\"{x:1357,y:759,t:1528139858479};\\\", \\\"{x:1355,y:765,t:1528139858496};\\\", \\\"{x:1353,y:772,t:1528139858512};\\\", \\\"{x:1351,y:779,t:1528139858529};\\\", \\\"{x:1350,y:781,t:1528139858547};\\\", \\\"{x:1350,y:783,t:1528139858562};\\\", \\\"{x:1349,y:785,t:1528139858580};\\\", \\\"{x:1348,y:788,t:1528139858596};\\\", \\\"{x:1347,y:792,t:1528139858612};\\\", \\\"{x:1347,y:799,t:1528139858630};\\\", \\\"{x:1346,y:804,t:1528139858647};\\\", \\\"{x:1345,y:811,t:1528139858663};\\\", \\\"{x:1344,y:812,t:1528139858679};\\\", \\\"{x:1344,y:816,t:1528139858697};\\\", \\\"{x:1344,y:821,t:1528139858713};\\\", \\\"{x:1342,y:825,t:1528139858729};\\\", \\\"{x:1341,y:831,t:1528139858747};\\\", \\\"{x:1341,y:837,t:1528139858763};\\\", \\\"{x:1341,y:841,t:1528139858780};\\\", \\\"{x:1340,y:844,t:1528139858797};\\\", \\\"{x:1340,y:849,t:1528139858814};\\\", \\\"{x:1338,y:853,t:1528139858831};\\\", \\\"{x:1338,y:859,t:1528139858846};\\\", \\\"{x:1337,y:866,t:1528139858864};\\\", \\\"{x:1336,y:870,t:1528139858880};\\\", \\\"{x:1336,y:874,t:1528139858898};\\\", \\\"{x:1335,y:877,t:1528139858914};\\\", \\\"{x:1335,y:880,t:1528139858931};\\\", \\\"{x:1335,y:881,t:1528139858948};\\\", \\\"{x:1334,y:884,t:1528139858964};\\\", \\\"{x:1334,y:887,t:1528139858980};\\\", \\\"{x:1334,y:888,t:1528139858997};\\\", \\\"{x:1333,y:891,t:1528139859015};\\\", \\\"{x:1333,y:894,t:1528139859031};\\\", \\\"{x:1333,y:898,t:1528139859047};\\\", \\\"{x:1331,y:900,t:1528139859065};\\\", \\\"{x:1331,y:903,t:1528139859080};\\\", \\\"{x:1331,y:907,t:1528139859097};\\\", \\\"{x:1330,y:910,t:1528139859115};\\\", \\\"{x:1330,y:914,t:1528139859130};\\\", \\\"{x:1330,y:917,t:1528139859148};\\\", \\\"{x:1330,y:919,t:1528139859165};\\\", \\\"{x:1330,y:923,t:1528139859182};\\\", \\\"{x:1329,y:929,t:1528139859198};\\\", \\\"{x:1328,y:933,t:1528139859215};\\\", \\\"{x:1327,y:939,t:1528139859231};\\\", \\\"{x:1327,y:941,t:1528139859247};\\\", \\\"{x:1327,y:943,t:1528139859264};\\\", \\\"{x:1326,y:945,t:1528139859282};\\\", \\\"{x:1326,y:949,t:1528139859299};\\\", \\\"{x:1325,y:953,t:1528139859315};\\\", \\\"{x:1324,y:955,t:1528139859331};\\\", \\\"{x:1324,y:958,t:1528139859348};\\\", \\\"{x:1324,y:961,t:1528139859365};\\\", \\\"{x:1324,y:965,t:1528139859382};\\\", \\\"{x:1324,y:967,t:1528139859398};\\\", \\\"{x:1324,y:970,t:1528139859415};\\\", \\\"{x:1324,y:971,t:1528139859439};\\\", \\\"{x:1324,y:972,t:1528139859751};\\\", \\\"{x:1326,y:972,t:1528139859775};\\\", \\\"{x:1328,y:972,t:1528139859784};\\\", \\\"{x:1330,y:971,t:1528139859799};\\\", \\\"{x:1332,y:970,t:1528139859817};\\\", \\\"{x:1333,y:970,t:1528139859838};\\\", \\\"{x:1333,y:969,t:1528139859855};\\\", \\\"{x:1334,y:969,t:1528139859903};\\\", \\\"{x:1335,y:969,t:1528139859983};\\\", \\\"{x:1336,y:969,t:1528139860000};\\\", \\\"{x:1338,y:967,t:1528139860081};\\\", \\\"{x:1338,y:962,t:1528139861944};\\\", \\\"{x:1336,y:959,t:1528139861955};\\\", \\\"{x:1336,y:957,t:1528139861972};\\\", \\\"{x:1335,y:951,t:1528139861988};\\\", \\\"{x:1332,y:943,t:1528139862004};\\\", \\\"{x:1330,y:938,t:1528139862023};\\\", \\\"{x:1329,y:936,t:1528139862039};\\\", \\\"{x:1329,y:935,t:1528139862054};\\\", \\\"{x:1327,y:931,t:1528139862071};\\\", \\\"{x:1325,y:928,t:1528139862088};\\\", \\\"{x:1324,y:924,t:1528139862105};\\\", \\\"{x:1323,y:923,t:1528139862121};\\\", \\\"{x:1322,y:922,t:1528139862138};\\\", \\\"{x:1323,y:924,t:1528139862238};\\\", \\\"{x:1329,y:927,t:1528139862255};\\\", \\\"{x:1335,y:931,t:1528139862272};\\\", \\\"{x:1346,y:936,t:1528139862288};\\\", \\\"{x:1357,y:942,t:1528139862305};\\\", \\\"{x:1362,y:945,t:1528139862322};\\\", \\\"{x:1365,y:948,t:1528139862338};\\\", \\\"{x:1367,y:949,t:1528139862355};\\\", \\\"{x:1368,y:950,t:1528139862372};\\\", \\\"{x:1368,y:951,t:1528139862663};\\\", \\\"{x:1366,y:951,t:1528139862775};\\\", \\\"{x:1364,y:951,t:1528139862791};\\\", \\\"{x:1360,y:951,t:1528139862807};\\\", \\\"{x:1357,y:949,t:1528139862823};\\\", \\\"{x:1353,y:946,t:1528139862841};\\\", \\\"{x:1349,y:943,t:1528139862856};\\\", \\\"{x:1346,y:941,t:1528139862874};\\\", \\\"{x:1343,y:940,t:1528139862890};\\\", \\\"{x:1341,y:939,t:1528139862907};\\\", \\\"{x:1340,y:938,t:1528139862927};\\\", \\\"{x:1339,y:937,t:1528139862959};\\\", \\\"{x:1338,y:936,t:1528139862975};\\\", \\\"{x:1337,y:935,t:1528139862991};\\\", \\\"{x:1334,y:932,t:1528139863008};\\\", \\\"{x:1332,y:929,t:1528139863024};\\\", \\\"{x:1327,y:924,t:1528139863041};\\\", \\\"{x:1324,y:920,t:1528139863057};\\\", \\\"{x:1322,y:917,t:1528139863075};\\\", \\\"{x:1321,y:913,t:1528139863091};\\\", \\\"{x:1318,y:911,t:1528139863108};\\\", \\\"{x:1315,y:906,t:1528139863125};\\\", \\\"{x:1313,y:901,t:1528139863141};\\\", \\\"{x:1309,y:896,t:1528139863158};\\\", \\\"{x:1300,y:886,t:1528139863176};\\\", \\\"{x:1296,y:881,t:1528139863191};\\\", \\\"{x:1287,y:872,t:1528139863208};\\\", \\\"{x:1283,y:868,t:1528139863225};\\\", \\\"{x:1281,y:867,t:1528139863241};\\\", \\\"{x:1281,y:865,t:1528139863257};\\\", \\\"{x:1279,y:861,t:1528139863274};\\\", \\\"{x:1277,y:853,t:1528139863291};\\\", \\\"{x:1272,y:838,t:1528139863308};\\\", \\\"{x:1271,y:824,t:1528139863324};\\\", \\\"{x:1267,y:811,t:1528139863341};\\\", \\\"{x:1265,y:801,t:1528139863358};\\\", \\\"{x:1263,y:798,t:1528139863374};\\\", \\\"{x:1263,y:796,t:1528139863391};\\\", \\\"{x:1262,y:793,t:1528139863408};\\\", \\\"{x:1261,y:790,t:1528139863424};\\\", \\\"{x:1260,y:788,t:1528139863441};\\\", \\\"{x:1260,y:784,t:1528139863458};\\\", \\\"{x:1259,y:781,t:1528139863475};\\\", \\\"{x:1259,y:777,t:1528139863491};\\\", \\\"{x:1256,y:774,t:1528139863508};\\\", \\\"{x:1255,y:770,t:1528139863525};\\\", \\\"{x:1252,y:764,t:1528139863541};\\\", \\\"{x:1248,y:759,t:1528139863558};\\\", \\\"{x:1247,y:756,t:1528139863575};\\\", \\\"{x:1243,y:751,t:1528139863592};\\\", \\\"{x:1241,y:749,t:1528139863608};\\\", \\\"{x:1239,y:746,t:1528139863625};\\\", \\\"{x:1235,y:742,t:1528139863642};\\\", \\\"{x:1229,y:735,t:1528139863658};\\\", \\\"{x:1229,y:734,t:1528139863675};\\\", \\\"{x:1229,y:733,t:1528139863692};\\\", \\\"{x:1227,y:731,t:1528139863710};\\\", \\\"{x:1225,y:728,t:1528139863725};\\\", \\\"{x:1224,y:724,t:1528139863742};\\\", \\\"{x:1222,y:723,t:1528139863759};\\\", \\\"{x:1222,y:721,t:1528139863775};\\\", \\\"{x:1221,y:720,t:1528139863792};\\\", \\\"{x:1220,y:717,t:1528139863810};\\\", \\\"{x:1218,y:714,t:1528139863826};\\\", \\\"{x:1217,y:714,t:1528139863843};\\\", \\\"{x:1217,y:713,t:1528139863859};\\\", \\\"{x:1216,y:711,t:1528139863879};\\\", \\\"{x:1216,y:710,t:1528139864079};\\\", \\\"{x:1215,y:708,t:1528139864094};\\\", \\\"{x:1215,y:707,t:1528139864110};\\\", \\\"{x:1214,y:706,t:1528139864151};\\\", \\\"{x:1214,y:712,t:1528139865206};\\\", \\\"{x:1214,y:723,t:1528139865214};\\\", \\\"{x:1218,y:732,t:1528139865229};\\\", \\\"{x:1230,y:754,t:1528139865246};\\\", \\\"{x:1239,y:767,t:1528139865263};\\\", \\\"{x:1248,y:782,t:1528139865280};\\\", \\\"{x:1255,y:793,t:1528139865297};\\\", \\\"{x:1264,y:808,t:1528139865313};\\\", \\\"{x:1271,y:822,t:1528139865329};\\\", \\\"{x:1276,y:835,t:1528139865347};\\\", \\\"{x:1285,y:854,t:1528139865363};\\\", \\\"{x:1293,y:873,t:1528139865380};\\\", \\\"{x:1300,y:891,t:1528139865396};\\\", \\\"{x:1308,y:908,t:1528139865414};\\\", \\\"{x:1314,y:923,t:1528139865430};\\\", \\\"{x:1324,y:945,t:1528139865446};\\\", \\\"{x:1329,y:958,t:1528139865464};\\\", \\\"{x:1333,y:966,t:1528139865481};\\\", \\\"{x:1337,y:972,t:1528139865497};\\\", \\\"{x:1337,y:973,t:1528139865514};\\\", \\\"{x:1337,y:974,t:1528139865531};\\\", \\\"{x:1337,y:972,t:1528139865728};\\\", \\\"{x:1337,y:965,t:1528139865735};\\\", \\\"{x:1338,y:956,t:1528139865748};\\\", \\\"{x:1342,y:947,t:1528139865765};\\\", \\\"{x:1346,y:939,t:1528139865781};\\\", \\\"{x:1351,y:927,t:1528139865798};\\\", \\\"{x:1358,y:909,t:1528139865815};\\\", \\\"{x:1361,y:903,t:1528139865831};\\\", \\\"{x:1361,y:901,t:1528139865848};\\\", \\\"{x:1363,y:897,t:1528139865865};\\\", \\\"{x:1365,y:893,t:1528139865882};\\\", \\\"{x:1367,y:890,t:1528139865898};\\\", \\\"{x:1368,y:889,t:1528139865915};\\\", \\\"{x:1369,y:886,t:1528139865931};\\\", \\\"{x:1371,y:883,t:1528139865947};\\\", \\\"{x:1373,y:881,t:1528139865965};\\\", \\\"{x:1374,y:880,t:1528139865982};\\\", \\\"{x:1375,y:878,t:1528139865999};\\\", \\\"{x:1377,y:876,t:1528139866014};\\\", \\\"{x:1378,y:876,t:1528139866032};\\\", \\\"{x:1378,y:875,t:1528139866049};\\\", \\\"{x:1379,y:875,t:1528139866240};\\\", \\\"{x:1379,y:876,t:1528139866816};\\\", \\\"{x:1379,y:877,t:1528139866823};\\\", \\\"{x:1379,y:879,t:1528139866834};\\\", \\\"{x:1379,y:880,t:1528139866854};\\\", \\\"{x:1379,y:881,t:1528139866866};\\\", \\\"{x:1379,y:882,t:1528139866894};\\\", \\\"{x:1379,y:883,t:1528139866926};\\\", \\\"{x:1379,y:884,t:1528139866942};\\\", \\\"{x:1379,y:885,t:1528139866958};\\\", \\\"{x:1379,y:886,t:1528139867007};\\\", \\\"{x:1379,y:887,t:1528139867022};\\\", \\\"{x:1379,y:888,t:1528139867046};\\\", \\\"{x:1379,y:889,t:1528139867087};\\\", \\\"{x:1379,y:890,t:1528139867101};\\\", \\\"{x:1379,y:891,t:1528139867118};\\\", \\\"{x:1378,y:893,t:1528139867136};\\\", \\\"{x:1377,y:893,t:1528139867150};\\\", \\\"{x:1377,y:894,t:1528139867168};\\\", \\\"{x:1376,y:895,t:1528139867185};\\\", \\\"{x:1376,y:898,t:1528139867202};\\\", \\\"{x:1374,y:899,t:1528139867218};\\\", \\\"{x:1374,y:900,t:1528139867235};\\\", \\\"{x:1372,y:901,t:1528139867252};\\\", \\\"{x:1371,y:902,t:1528139867268};\\\", \\\"{x:1369,y:903,t:1528139867284};\\\", \\\"{x:1368,y:904,t:1528139867318};\\\", \\\"{x:1367,y:904,t:1528139867487};\\\", \\\"{x:1366,y:903,t:1528139867502};\\\", \\\"{x:1364,y:895,t:1528139867520};\\\", \\\"{x:1363,y:891,t:1528139867535};\\\", \\\"{x:1363,y:889,t:1528139867552};\\\", \\\"{x:1363,y:888,t:1528139867569};\\\", \\\"{x:1363,y:886,t:1528139867586};\\\", \\\"{x:1362,y:885,t:1528139867603};\\\", \\\"{x:1362,y:882,t:1528139867619};\\\", \\\"{x:1361,y:878,t:1528139867635};\\\", \\\"{x:1361,y:876,t:1528139867652};\\\", \\\"{x:1360,y:872,t:1528139867668};\\\", \\\"{x:1360,y:868,t:1528139867685};\\\", \\\"{x:1359,y:866,t:1528139867702};\\\", \\\"{x:1359,y:865,t:1528139867719};\\\", \\\"{x:1359,y:861,t:1528139867736};\\\", \\\"{x:1359,y:860,t:1528139867752};\\\", \\\"{x:1359,y:859,t:1528139867770};\\\", \\\"{x:1358,y:858,t:1528139867786};\\\", \\\"{x:1358,y:857,t:1528139867802};\\\", \\\"{x:1358,y:856,t:1528139867822};\\\", \\\"{x:1358,y:855,t:1528139867837};\\\", \\\"{x:1358,y:854,t:1528139867853};\\\", \\\"{x:1358,y:853,t:1528139867870};\\\", \\\"{x:1358,y:851,t:1528139867886};\\\", \\\"{x:1357,y:850,t:1528139867902};\\\", \\\"{x:1357,y:848,t:1528139867920};\\\", \\\"{x:1357,y:847,t:1528139867951};\\\", \\\"{x:1357,y:846,t:1528139867959};\\\", \\\"{x:1357,y:845,t:1528139867974};\\\", \\\"{x:1357,y:844,t:1528139868007};\\\", \\\"{x:1357,y:843,t:1528139868030};\\\", \\\"{x:1357,y:842,t:1528139868039};\\\", \\\"{x:1356,y:840,t:1528139868054};\\\", \\\"{x:1355,y:839,t:1528139868070};\\\", \\\"{x:1354,y:835,t:1528139868087};\\\", \\\"{x:1354,y:834,t:1528139868104};\\\", \\\"{x:1353,y:832,t:1528139868121};\\\", \\\"{x:1353,y:831,t:1528139868137};\\\", \\\"{x:1352,y:829,t:1528139868154};\\\", \\\"{x:1352,y:828,t:1528139868279};\\\", \\\"{x:1351,y:826,t:1528139868295};\\\", \\\"{x:1351,y:825,t:1528139868311};\\\", \\\"{x:1351,y:823,t:1528139868335};\\\", \\\"{x:1351,y:822,t:1528139868359};\\\", \\\"{x:1351,y:820,t:1528139868375};\\\", \\\"{x:1351,y:819,t:1528139868399};\\\", \\\"{x:1351,y:818,t:1528139868407};\\\", \\\"{x:1351,y:817,t:1528139868423};\\\", \\\"{x:1351,y:816,t:1528139868472};\\\", \\\"{x:1351,y:814,t:1528139868495};\\\", \\\"{x:1351,y:813,t:1528139868519};\\\", \\\"{x:1351,y:811,t:1528139868543};\\\", \\\"{x:1351,y:810,t:1528139868555};\\\", \\\"{x:1349,y:805,t:1528139868572};\\\", \\\"{x:1349,y:804,t:1528139868587};\\\", \\\"{x:1349,y:803,t:1528139868656};\\\", \\\"{x:1349,y:802,t:1528139868672};\\\", \\\"{x:1349,y:801,t:1528139868689};\\\", \\\"{x:1349,y:800,t:1528139868719};\\\", \\\"{x:1349,y:799,t:1528139868735};\\\", \\\"{x:1349,y:798,t:1528139868750};\\\", \\\"{x:1349,y:797,t:1528139868767};\\\", \\\"{x:1349,y:796,t:1528139868775};\\\", \\\"{x:1349,y:795,t:1528139868791};\\\", \\\"{x:1352,y:793,t:1528139868806};\\\", \\\"{x:1353,y:791,t:1528139868823};\\\", \\\"{x:1355,y:789,t:1528139868839};\\\", \\\"{x:1359,y:785,t:1528139868856};\\\", \\\"{x:1366,y:781,t:1528139868872};\\\", \\\"{x:1372,y:777,t:1528139868889};\\\", \\\"{x:1381,y:770,t:1528139868906};\\\", \\\"{x:1390,y:768,t:1528139868923};\\\", \\\"{x:1400,y:765,t:1528139868939};\\\", \\\"{x:1412,y:761,t:1528139868956};\\\", \\\"{x:1425,y:758,t:1528139868973};\\\", \\\"{x:1445,y:754,t:1528139868989};\\\", \\\"{x:1468,y:750,t:1528139869006};\\\", \\\"{x:1511,y:741,t:1528139869023};\\\", \\\"{x:1537,y:736,t:1528139869039};\\\", \\\"{x:1567,y:731,t:1528139869056};\\\", \\\"{x:1596,y:727,t:1528139869073};\\\", \\\"{x:1615,y:725,t:1528139869090};\\\", \\\"{x:1633,y:722,t:1528139869106};\\\", \\\"{x:1655,y:716,t:1528139869123};\\\", \\\"{x:1682,y:708,t:1528139869140};\\\", \\\"{x:1712,y:702,t:1528139869156};\\\", \\\"{x:1738,y:695,t:1528139869173};\\\", \\\"{x:1766,y:687,t:1528139869190};\\\", \\\"{x:1830,y:668,t:1528139869207};\\\", \\\"{x:1870,y:656,t:1528139869223};\\\", \\\"{x:1912,y:651,t:1528139869240};\\\", \\\"{x:1919,y:643,t:1528139869257};\\\", \\\"{x:1919,y:629,t:1528139869280};\\\", \\\"{x:1919,y:621,t:1528139869297};\\\", \\\"{x:1919,y:617,t:1528139869315};\\\", \\\"{x:1919,y:611,t:1528139869330};\\\", \\\"{x:1919,y:608,t:1528139869347};\\\", \\\"{x:1919,y:605,t:1528139869364};\\\", \\\"{x:1919,y:604,t:1528139869381};\\\", \\\"{x:1919,y:603,t:1528139869398};\\\", \\\"{x:1919,y:601,t:1528139869414};\\\", \\\"{x:1919,y:597,t:1528139869430};\\\", \\\"{x:1919,y:596,t:1528139869447};\\\", \\\"{x:1919,y:591,t:1528139869465};\\\", \\\"{x:1919,y:586,t:1528139869480};\\\", \\\"{x:1910,y:580,t:1528139869498};\\\", \\\"{x:1891,y:572,t:1528139869515};\\\", \\\"{x:1871,y:563,t:1528139869532};\\\", \\\"{x:1838,y:547,t:1528139869548};\\\", \\\"{x:1788,y:526,t:1528139869565};\\\", \\\"{x:1705,y:501,t:1528139869580};\\\", \\\"{x:1597,y:471,t:1528139869597};\\\", \\\"{x:1357,y:402,t:1528139869615};\\\", \\\"{x:1175,y:354,t:1528139869631};\\\", \\\"{x:963,y:303,t:1528139869648};\\\", \\\"{x:747,y:261,t:1528139869664};\\\", \\\"{x:566,y:227,t:1528139869682};\\\", \\\"{x:408,y:201,t:1528139869698};\\\", \\\"{x:322,y:188,t:1528139869715};\\\", \\\"{x:266,y:180,t:1528139869732};\\\", \\\"{x:221,y:174,t:1528139869748};\\\", \\\"{x:184,y:169,t:1528139869764};\\\", \\\"{x:156,y:166,t:1528139869782};\\\", \\\"{x:132,y:165,t:1528139869797};\\\", \\\"{x:91,y:165,t:1528139869815};\\\", \\\"{x:69,y:165,t:1528139869832};\\\", \\\"{x:61,y:165,t:1528139869847};\\\", \\\"{x:59,y:167,t:1528139869864};\\\", \\\"{x:58,y:170,t:1528139869882};\\\", \\\"{x:56,y:179,t:1528139869897};\\\", \\\"{x:56,y:188,t:1528139869914};\\\", \\\"{x:56,y:196,t:1528139869932};\\\", \\\"{x:56,y:206,t:1528139869948};\\\", \\\"{x:60,y:225,t:1528139869965};\\\", \\\"{x:73,y:253,t:1528139869982};\\\", \\\"{x:96,y:285,t:1528139869997};\\\", \\\"{x:130,y:321,t:1528139870015};\\\", \\\"{x:165,y:352,t:1528139870032};\\\", \\\"{x:205,y:383,t:1528139870048};\\\", \\\"{x:275,y:432,t:1528139870065};\\\", \\\"{x:318,y:457,t:1528139870082};\\\", \\\"{x:351,y:476,t:1528139870098};\\\", \\\"{x:377,y:489,t:1528139870116};\\\", \\\"{x:397,y:499,t:1528139870131};\\\", \\\"{x:416,y:506,t:1528139870148};\\\", \\\"{x:423,y:509,t:1528139870164};\\\", \\\"{x:425,y:509,t:1528139870181};\\\", \\\"{x:426,y:509,t:1528139870198};\\\", \\\"{x:431,y:508,t:1528139871095};\\\", \\\"{x:443,y:505,t:1528139871103};\\\", \\\"{x:457,y:499,t:1528139871116};\\\", \\\"{x:500,y:491,t:1528139871134};\\\", \\\"{x:538,y:487,t:1528139871148};\\\", \\\"{x:551,y:486,t:1528139871163};\\\", \\\"{x:552,y:486,t:1528139871179};\\\", \\\"{x:555,y:486,t:1528139871206};\\\", \\\"{x:562,y:486,t:1528139871215};\\\", \\\"{x:586,y:486,t:1528139871232};\\\", \\\"{x:615,y:486,t:1528139871249};\\\", \\\"{x:640,y:486,t:1528139871265};\\\", \\\"{x:645,y:486,t:1528139871283};\\\", \\\"{x:644,y:486,t:1528139871406};\\\", \\\"{x:635,y:483,t:1528139871416};\\\", \\\"{x:611,y:476,t:1528139871433};\\\", \\\"{x:587,y:473,t:1528139871449};\\\", \\\"{x:560,y:470,t:1528139871466};\\\", \\\"{x:525,y:464,t:1528139871482};\\\", \\\"{x:500,y:463,t:1528139871499};\\\", \\\"{x:475,y:463,t:1528139871516};\\\", \\\"{x:443,y:463,t:1528139871533};\\\", \\\"{x:420,y:463,t:1528139871549};\\\", \\\"{x:397,y:461,t:1528139871566};\\\", \\\"{x:381,y:459,t:1528139871583};\\\", \\\"{x:383,y:459,t:1528139871687};\\\", \\\"{x:388,y:459,t:1528139871700};\\\", \\\"{x:402,y:460,t:1528139871716};\\\", \\\"{x:427,y:460,t:1528139871733};\\\", \\\"{x:451,y:460,t:1528139871749};\\\", \\\"{x:477,y:462,t:1528139871766};\\\", \\\"{x:536,y:469,t:1528139871782};\\\", \\\"{x:584,y:477,t:1528139871800};\\\", \\\"{x:651,y:485,t:1528139871816};\\\", \\\"{x:718,y:496,t:1528139871834};\\\", \\\"{x:760,y:502,t:1528139871850};\\\", \\\"{x:778,y:505,t:1528139871867};\\\", \\\"{x:783,y:505,t:1528139871882};\\\", \\\"{x:784,y:505,t:1528139871899};\\\", \\\"{x:783,y:507,t:1528139872127};\\\", \\\"{x:778,y:509,t:1528139872134};\\\", \\\"{x:773,y:511,t:1528139872150};\\\", \\\"{x:772,y:511,t:1528139872166};\\\", \\\"{x:771,y:511,t:1528139872183};\\\", \\\"{x:770,y:511,t:1528139872201};\\\", \\\"{x:766,y:511,t:1528139872217};\\\", \\\"{x:761,y:511,t:1528139872233};\\\", \\\"{x:751,y:511,t:1528139872250};\\\", \\\"{x:731,y:511,t:1528139872267};\\\", \\\"{x:709,y:511,t:1528139872284};\\\", \\\"{x:690,y:511,t:1528139872300};\\\", \\\"{x:673,y:511,t:1528139872316};\\\", \\\"{x:654,y:511,t:1528139872332};\\\", \\\"{x:639,y:511,t:1528139872350};\\\", \\\"{x:618,y:511,t:1528139872367};\\\", \\\"{x:602,y:511,t:1528139872382};\\\", \\\"{x:595,y:511,t:1528139872400};\\\", \\\"{x:591,y:511,t:1528139872416};\\\", \\\"{x:589,y:511,t:1528139872438};\\\", \\\"{x:589,y:513,t:1528139872735};\\\", \\\"{x:601,y:520,t:1528139872751};\\\", \\\"{x:659,y:566,t:1528139872768};\\\", \\\"{x:685,y:579,t:1528139872784};\\\", \\\"{x:705,y:587,t:1528139872800};\\\", \\\"{x:724,y:587,t:1528139872818};\\\", \\\"{x:760,y:587,t:1528139872834};\\\", \\\"{x:848,y:582,t:1528139872850};\\\", \\\"{x:969,y:568,t:1528139872867};\\\", \\\"{x:1108,y:561,t:1528139872884};\\\", \\\"{x:1255,y:561,t:1528139872901};\\\", \\\"{x:1385,y:561,t:1528139872917};\\\", \\\"{x:1493,y:561,t:1528139872933};\\\", \\\"{x:1592,y:565,t:1528139872950};\\\", \\\"{x:1634,y:569,t:1528139872967};\\\", \\\"{x:1648,y:572,t:1528139872984};\\\", \\\"{x:1650,y:573,t:1528139873000};\\\", \\\"{x:1651,y:575,t:1528139873030};\\\", \\\"{x:1651,y:586,t:1528139873038};\\\", \\\"{x:1645,y:616,t:1528139873051};\\\", \\\"{x:1609,y:732,t:1528139873066};\\\", \\\"{x:1569,y:857,t:1528139873083};\\\", \\\"{x:1537,y:932,t:1528139873100};\\\", \\\"{x:1526,y:954,t:1528139873117};\\\", \\\"{x:1522,y:965,t:1528139873134};\\\", \\\"{x:1518,y:974,t:1528139873151};\\\", \\\"{x:1514,y:979,t:1528139873167};\\\", \\\"{x:1511,y:984,t:1528139873184};\\\", \\\"{x:1508,y:986,t:1528139873201};\\\", \\\"{x:1507,y:987,t:1528139873218};\\\", \\\"{x:1504,y:987,t:1528139873234};\\\", \\\"{x:1500,y:987,t:1528139873251};\\\", \\\"{x:1494,y:987,t:1528139873267};\\\", \\\"{x:1480,y:986,t:1528139873284};\\\", \\\"{x:1459,y:984,t:1528139873301};\\\", \\\"{x:1435,y:982,t:1528139873317};\\\", \\\"{x:1409,y:982,t:1528139873334};\\\", \\\"{x:1366,y:984,t:1528139873350};\\\", \\\"{x:1327,y:989,t:1528139873367};\\\", \\\"{x:1282,y:995,t:1528139873384};\\\", \\\"{x:1229,y:1003,t:1528139873401};\\\", \\\"{x:1159,y:1014,t:1528139873417};\\\", \\\"{x:1084,y:1022,t:1528139873434};\\\", \\\"{x:1017,y:1033,t:1528139873451};\\\", \\\"{x:951,y:1048,t:1528139873467};\\\", \\\"{x:898,y:1066,t:1528139873483};\\\", \\\"{x:861,y:1083,t:1528139873501};\\\", \\\"{x:850,y:1092,t:1528139873517};\\\", \\\"{x:848,y:1094,t:1528139873534};\\\", \\\"{x:848,y:1095,t:1528139873591};\\\", \\\"{x:852,y:1095,t:1528139873601};\\\", \\\"{x:871,y:1088,t:1528139873617};\\\", \\\"{x:891,y:1075,t:1528139873634};\\\", \\\"{x:922,y:1047,t:1528139873651};\\\", \\\"{x:969,y:990,t:1528139873666};\\\", \\\"{x:1035,y:905,t:1528139873684};\\\", \\\"{x:1110,y:822,t:1528139873701};\\\", \\\"{x:1175,y:748,t:1528139873717};\\\", \\\"{x:1223,y:690,t:1528139873734};\\\", \\\"{x:1259,y:658,t:1528139873751};\\\", \\\"{x:1269,y:651,t:1528139873767};\\\", \\\"{x:1269,y:650,t:1528139873785};\\\", \\\"{x:1270,y:650,t:1528139873839};\\\", \\\"{x:1272,y:650,t:1528139873851};\\\", \\\"{x:1290,y:668,t:1528139873867};\\\", \\\"{x:1305,y:696,t:1528139873885};\\\", \\\"{x:1308,y:730,t:1528139873902};\\\", \\\"{x:1308,y:770,t:1528139873917};\\\", \\\"{x:1306,y:804,t:1528139873934};\\\", \\\"{x:1296,y:837,t:1528139873950};\\\", \\\"{x:1291,y:849,t:1528139873967};\\\", \\\"{x:1284,y:864,t:1528139873984};\\\", \\\"{x:1275,y:878,t:1528139874001};\\\", \\\"{x:1267,y:888,t:1528139874017};\\\", \\\"{x:1261,y:894,t:1528139874034};\\\", \\\"{x:1254,y:897,t:1528139874051};\\\", \\\"{x:1252,y:898,t:1528139874067};\\\", \\\"{x:1250,y:899,t:1528139874084};\\\", \\\"{x:1248,y:899,t:1528139874101};\\\", \\\"{x:1245,y:899,t:1528139874135};\\\", \\\"{x:1241,y:899,t:1528139874151};\\\", \\\"{x:1235,y:888,t:1528139874167};\\\", \\\"{x:1231,y:876,t:1528139874184};\\\", \\\"{x:1230,y:870,t:1528139874202};\\\", \\\"{x:1229,y:862,t:1528139874217};\\\", \\\"{x:1228,y:853,t:1528139874234};\\\", \\\"{x:1227,y:849,t:1528139874252};\\\", \\\"{x:1227,y:848,t:1528139874267};\\\", \\\"{x:1226,y:846,t:1528139874439};\\\", \\\"{x:1224,y:844,t:1528139874451};\\\", \\\"{x:1223,y:841,t:1528139874468};\\\", \\\"{x:1222,y:837,t:1528139874484};\\\", \\\"{x:1221,y:832,t:1528139874501};\\\", \\\"{x:1220,y:829,t:1528139874518};\\\", \\\"{x:1220,y:828,t:1528139874534};\\\", \\\"{x:1219,y:827,t:1528139874887};\\\", \\\"{x:1215,y:827,t:1528139875023};\\\", \\\"{x:1212,y:827,t:1528139875034};\\\", \\\"{x:1205,y:828,t:1528139875052};\\\", \\\"{x:1200,y:828,t:1528139875067};\\\", \\\"{x:1196,y:830,t:1528139875084};\\\", \\\"{x:1190,y:831,t:1528139875102};\\\", \\\"{x:1184,y:831,t:1528139875117};\\\", \\\"{x:1176,y:831,t:1528139875134};\\\", \\\"{x:1157,y:833,t:1528139875151};\\\", \\\"{x:1147,y:835,t:1528139875167};\\\", \\\"{x:1139,y:836,t:1528139875184};\\\", \\\"{x:1135,y:836,t:1528139875201};\\\", \\\"{x:1132,y:838,t:1528139875217};\\\", \\\"{x:1130,y:838,t:1528139875235};\\\", \\\"{x:1129,y:839,t:1528139875251};\\\", \\\"{x:1126,y:840,t:1528139875267};\\\", \\\"{x:1124,y:841,t:1528139875284};\\\", \\\"{x:1120,y:844,t:1528139875302};\\\", \\\"{x:1111,y:852,t:1528139875317};\\\", \\\"{x:1107,y:857,t:1528139875334};\\\", \\\"{x:1102,y:861,t:1528139875351};\\\", \\\"{x:1100,y:863,t:1528139875367};\\\", \\\"{x:1099,y:864,t:1528139875511};\\\", \\\"{x:1099,y:865,t:1528139875519};\\\", \\\"{x:1098,y:867,t:1528139875534};\\\", \\\"{x:1096,y:869,t:1528139875551};\\\", \\\"{x:1093,y:872,t:1528139875567};\\\", \\\"{x:1092,y:874,t:1528139875584};\\\", \\\"{x:1090,y:877,t:1528139875601};\\\", \\\"{x:1089,y:880,t:1528139875617};\\\", \\\"{x:1088,y:881,t:1528139875634};\\\", \\\"{x:1088,y:876,t:1528139875775};\\\", \\\"{x:1089,y:869,t:1528139875784};\\\", \\\"{x:1096,y:852,t:1528139875801};\\\", \\\"{x:1104,y:832,t:1528139875817};\\\", \\\"{x:1118,y:801,t:1528139875834};\\\", \\\"{x:1126,y:776,t:1528139875851};\\\", \\\"{x:1138,y:749,t:1528139875867};\\\", \\\"{x:1148,y:725,t:1528139875884};\\\", \\\"{x:1162,y:697,t:1528139875902};\\\", \\\"{x:1188,y:656,t:1528139875918};\\\", \\\"{x:1203,y:632,t:1528139875934};\\\", \\\"{x:1213,y:617,t:1528139875951};\\\", \\\"{x:1219,y:611,t:1528139875967};\\\", \\\"{x:1226,y:605,t:1528139875984};\\\", \\\"{x:1230,y:602,t:1528139876001};\\\", \\\"{x:1233,y:599,t:1528139876017};\\\", \\\"{x:1237,y:596,t:1528139876035};\\\", \\\"{x:1240,y:592,t:1528139876051};\\\", \\\"{x:1240,y:591,t:1528139876111};\\\", \\\"{x:1242,y:590,t:1528139876118};\\\", \\\"{x:1244,y:588,t:1528139876134};\\\", \\\"{x:1247,y:584,t:1528139876151};\\\", \\\"{x:1248,y:583,t:1528139876167};\\\", \\\"{x:1251,y:580,t:1528139876185};\\\", \\\"{x:1255,y:576,t:1528139876201};\\\", \\\"{x:1256,y:574,t:1528139876217};\\\", \\\"{x:1258,y:572,t:1528139876234};\\\", \\\"{x:1258,y:571,t:1528139876255};\\\", \\\"{x:1259,y:569,t:1528139876271};\\\", \\\"{x:1260,y:569,t:1528139876287};\\\", \\\"{x:1261,y:568,t:1528139876301};\\\", \\\"{x:1263,y:566,t:1528139876317};\\\", \\\"{x:1264,y:565,t:1528139876334};\\\", \\\"{x:1266,y:563,t:1528139876351};\\\", \\\"{x:1268,y:562,t:1528139876368};\\\", \\\"{x:1269,y:562,t:1528139876384};\\\", \\\"{x:1269,y:561,t:1528139876401};\\\", \\\"{x:1269,y:560,t:1528139876423};\\\", \\\"{x:1270,y:560,t:1528139877959};\\\", \\\"{x:1272,y:560,t:1528139877974};\\\", \\\"{x:1273,y:560,t:1528139877985};\\\", \\\"{x:1274,y:560,t:1528139878007};\\\", \\\"{x:1274,y:561,t:1528139878431};\\\", \\\"{x:1273,y:563,t:1528139878439};\\\", \\\"{x:1272,y:564,t:1528139878452};\\\", \\\"{x:1272,y:565,t:1528139878471};\\\", \\\"{x:1273,y:564,t:1528139879335};\\\", \\\"{x:1273,y:563,t:1528139879351};\\\", \\\"{x:1274,y:561,t:1528139879368};\\\", \\\"{x:1274,y:560,t:1528139879384};\\\", \\\"{x:1275,y:560,t:1528139879402};\\\", \\\"{x:1276,y:560,t:1528139879751};\\\", \\\"{x:1276,y:559,t:1528139879785};\\\", \\\"{x:1278,y:561,t:1528139881535};\\\", \\\"{x:1278,y:562,t:1528139881552};\\\", \\\"{x:1279,y:564,t:1528139881568};\\\", \\\"{x:1280,y:565,t:1528139881614};\\\", \\\"{x:1280,y:566,t:1528139881654};\\\", \\\"{x:1280,y:567,t:1528139881670};\\\", \\\"{x:1280,y:568,t:1528139881686};\\\", \\\"{x:1280,y:569,t:1528139881703};\\\", \\\"{x:1281,y:571,t:1528139881719};\\\", \\\"{x:1282,y:572,t:1528139881759};\\\", \\\"{x:1282,y:573,t:1528139881815};\\\", \\\"{x:1282,y:574,t:1528139881839};\\\", \\\"{x:1282,y:575,t:1528139881852};\\\", \\\"{x:1283,y:576,t:1528139881868};\\\", \\\"{x:1283,y:577,t:1528139881928};\\\", \\\"{x:1283,y:578,t:1528139882007};\\\", \\\"{x:1283,y:579,t:1528139882046};\\\", \\\"{x:1284,y:580,t:1528139882142};\\\", \\\"{x:1284,y:581,t:1528139882230};\\\", \\\"{x:1284,y:582,t:1528139882271};\\\", \\\"{x:1284,y:583,t:1528139882359};\\\", \\\"{x:1284,y:584,t:1528139882375};\\\", \\\"{x:1284,y:585,t:1528139882415};\\\", \\\"{x:1285,y:585,t:1528139882422};\\\", \\\"{x:1285,y:586,t:1528139882479};\\\", \\\"{x:1285,y:587,t:1528139882527};\\\", \\\"{x:1286,y:587,t:1528139882534};\\\", \\\"{x:1286,y:588,t:1528139882567};\\\", \\\"{x:1286,y:589,t:1528139882574};\\\", \\\"{x:1286,y:590,t:1528139882591};\\\", \\\"{x:1286,y:591,t:1528139882607};\\\", \\\"{x:1287,y:593,t:1528139882619};\\\", \\\"{x:1288,y:595,t:1528139882634};\\\", \\\"{x:1289,y:598,t:1528139882651};\\\", \\\"{x:1290,y:601,t:1528139882669};\\\", \\\"{x:1291,y:603,t:1528139882684};\\\", \\\"{x:1292,y:604,t:1528139882701};\\\", \\\"{x:1294,y:608,t:1528139882718};\\\", \\\"{x:1295,y:609,t:1528139882735};\\\", \\\"{x:1295,y:610,t:1528139882752};\\\", \\\"{x:1295,y:611,t:1528139882769};\\\", \\\"{x:1295,y:612,t:1528139882785};\\\", \\\"{x:1296,y:613,t:1528139882801};\\\", \\\"{x:1297,y:614,t:1528139882823};\\\", \\\"{x:1297,y:615,t:1528139882835};\\\", \\\"{x:1298,y:616,t:1528139882851};\\\", \\\"{x:1299,y:618,t:1528139882869};\\\", \\\"{x:1300,y:620,t:1528139882884};\\\", \\\"{x:1302,y:622,t:1528139882902};\\\", \\\"{x:1305,y:627,t:1528139882918};\\\", \\\"{x:1307,y:631,t:1528139882935};\\\", \\\"{x:1309,y:635,t:1528139882951};\\\", \\\"{x:1311,y:638,t:1528139882968};\\\", \\\"{x:1313,y:642,t:1528139882984};\\\", \\\"{x:1317,y:646,t:1528139883001};\\\", \\\"{x:1321,y:653,t:1528139883019};\\\", \\\"{x:1325,y:662,t:1528139883034};\\\", \\\"{x:1328,y:667,t:1528139883051};\\\", \\\"{x:1333,y:672,t:1528139883068};\\\", \\\"{x:1334,y:677,t:1528139883084};\\\", \\\"{x:1337,y:681,t:1528139883101};\\\", \\\"{x:1340,y:685,t:1528139883118};\\\", \\\"{x:1341,y:687,t:1528139883135};\\\", \\\"{x:1341,y:689,t:1528139883151};\\\", \\\"{x:1342,y:690,t:1528139883169};\\\", \\\"{x:1344,y:693,t:1528139883185};\\\", \\\"{x:1345,y:696,t:1528139883201};\\\", \\\"{x:1347,y:700,t:1528139883218};\\\", \\\"{x:1348,y:702,t:1528139883235};\\\", \\\"{x:1348,y:703,t:1528139883253};\\\", \\\"{x:1350,y:705,t:1528139883269};\\\", \\\"{x:1351,y:706,t:1528139883284};\\\", \\\"{x:1351,y:708,t:1528139883302};\\\", \\\"{x:1353,y:710,t:1528139883318};\\\", \\\"{x:1354,y:712,t:1528139883334};\\\", \\\"{x:1354,y:714,t:1528139883351};\\\", \\\"{x:1356,y:718,t:1528139883369};\\\", \\\"{x:1357,y:720,t:1528139883385};\\\", \\\"{x:1358,y:725,t:1528139883401};\\\", \\\"{x:1361,y:730,t:1528139883418};\\\", \\\"{x:1363,y:734,t:1528139883434};\\\", \\\"{x:1364,y:738,t:1528139883451};\\\", \\\"{x:1365,y:739,t:1528139883468};\\\", \\\"{x:1366,y:741,t:1528139883484};\\\", \\\"{x:1368,y:743,t:1528139883501};\\\", \\\"{x:1369,y:746,t:1528139883519};\\\", \\\"{x:1371,y:749,t:1528139883535};\\\", \\\"{x:1373,y:754,t:1528139883552};\\\", \\\"{x:1375,y:758,t:1528139883568};\\\", \\\"{x:1377,y:765,t:1528139883584};\\\", \\\"{x:1380,y:770,t:1528139883601};\\\", \\\"{x:1383,y:776,t:1528139883618};\\\", \\\"{x:1385,y:781,t:1528139883633};\\\", \\\"{x:1389,y:787,t:1528139883651};\\\", \\\"{x:1392,y:793,t:1528139883667};\\\", \\\"{x:1396,y:802,t:1528139883684};\\\", \\\"{x:1402,y:811,t:1528139883700};\\\", \\\"{x:1412,y:826,t:1528139883718};\\\", \\\"{x:1415,y:830,t:1528139883734};\\\", \\\"{x:1419,y:837,t:1528139883751};\\\", \\\"{x:1421,y:841,t:1528139883768};\\\", \\\"{x:1423,y:843,t:1528139883784};\\\", \\\"{x:1424,y:848,t:1528139883801};\\\", \\\"{x:1426,y:850,t:1528139883818};\\\", \\\"{x:1427,y:854,t:1528139883834};\\\", \\\"{x:1429,y:856,t:1528139883852};\\\", \\\"{x:1433,y:862,t:1528139883868};\\\", \\\"{x:1433,y:864,t:1528139883884};\\\", \\\"{x:1436,y:869,t:1528139883901};\\\", \\\"{x:1445,y:882,t:1528139883918};\\\", \\\"{x:1451,y:888,t:1528139883934};\\\", \\\"{x:1455,y:893,t:1528139883951};\\\", \\\"{x:1457,y:895,t:1528139883968};\\\", \\\"{x:1460,y:898,t:1528139883984};\\\", \\\"{x:1462,y:901,t:1528139884001};\\\", \\\"{x:1463,y:903,t:1528139884018};\\\", \\\"{x:1465,y:906,t:1528139884034};\\\", \\\"{x:1467,y:908,t:1528139884051};\\\", \\\"{x:1468,y:909,t:1528139884068};\\\", \\\"{x:1471,y:913,t:1528139884084};\\\", \\\"{x:1474,y:916,t:1528139884101};\\\", \\\"{x:1477,y:922,t:1528139884118};\\\", \\\"{x:1479,y:925,t:1528139884134};\\\", \\\"{x:1482,y:928,t:1528139884152};\\\", \\\"{x:1484,y:930,t:1528139884168};\\\", \\\"{x:1486,y:932,t:1528139884184};\\\", \\\"{x:1486,y:933,t:1528139884201};\\\", \\\"{x:1487,y:935,t:1528139884218};\\\", \\\"{x:1489,y:937,t:1528139884234};\\\", \\\"{x:1490,y:939,t:1528139884251};\\\", \\\"{x:1491,y:941,t:1528139884268};\\\", \\\"{x:1494,y:946,t:1528139884284};\\\", \\\"{x:1500,y:953,t:1528139884302};\\\", \\\"{x:1513,y:965,t:1528139884318};\\\", \\\"{x:1523,y:972,t:1528139884335};\\\", \\\"{x:1532,y:980,t:1528139884352};\\\", \\\"{x:1541,y:985,t:1528139884369};\\\", \\\"{x:1546,y:989,t:1528139884384};\\\", \\\"{x:1550,y:991,t:1528139884402};\\\", \\\"{x:1547,y:990,t:1528139886079};\\\", \\\"{x:1545,y:989,t:1528139886094};\\\", \\\"{x:1544,y:988,t:1528139886110};\\\", \\\"{x:1543,y:987,t:1528139886126};\\\", \\\"{x:1542,y:987,t:1528139886143};\\\", \\\"{x:1540,y:987,t:1528139886152};\\\", \\\"{x:1539,y:985,t:1528139886471};\\\", \\\"{x:1538,y:985,t:1528139886485};\\\", \\\"{x:1537,y:984,t:1528139886502};\\\", \\\"{x:1534,y:983,t:1528139886519};\\\", \\\"{x:1530,y:981,t:1528139886535};\\\", \\\"{x:1523,y:977,t:1528139886552};\\\", \\\"{x:1512,y:967,t:1528139886569};\\\", \\\"{x:1495,y:957,t:1528139886585};\\\", \\\"{x:1474,y:942,t:1528139886602};\\\", \\\"{x:1445,y:926,t:1528139886619};\\\", \\\"{x:1403,y:899,t:1528139886636};\\\", \\\"{x:1337,y:859,t:1528139886651};\\\", \\\"{x:1264,y:818,t:1528139886668};\\\", \\\"{x:1178,y:777,t:1528139886685};\\\", \\\"{x:1080,y:730,t:1528139886702};\\\", \\\"{x:969,y:681,t:1528139886719};\\\", \\\"{x:938,y:667,t:1528139886734};\\\", \\\"{x:914,y:657,t:1528139886752};\\\", \\\"{x:898,y:651,t:1528139886769};\\\", \\\"{x:893,y:648,t:1528139886785};\\\", \\\"{x:892,y:647,t:1528139886822};\\\", \\\"{x:889,y:647,t:1528139886871};\\\", \\\"{x:888,y:645,t:1528139886887};\\\", \\\"{x:886,y:644,t:1528139886902};\\\", \\\"{x:880,y:644,t:1528139886918};\\\", \\\"{x:873,y:641,t:1528139886934};\\\", \\\"{x:867,y:640,t:1528139886951};\\\", \\\"{x:859,y:637,t:1528139886968};\\\", \\\"{x:854,y:635,t:1528139886984};\\\", \\\"{x:850,y:635,t:1528139887002};\\\", \\\"{x:849,y:635,t:1528139887021};\\\", \\\"{x:848,y:635,t:1528139887035};\\\", \\\"{x:847,y:634,t:1528139887051};\\\", \\\"{x:848,y:634,t:1528139887326};\\\", \\\"{x:853,y:634,t:1528139887334};\\\", \\\"{x:866,y:638,t:1528139887352};\\\", \\\"{x:883,y:643,t:1528139887369};\\\", \\\"{x:903,y:648,t:1528139887385};\\\", \\\"{x:921,y:649,t:1528139887402};\\\", \\\"{x:944,y:653,t:1528139887418};\\\", \\\"{x:968,y:660,t:1528139887436};\\\", \\\"{x:989,y:666,t:1528139887451};\\\", \\\"{x:1008,y:668,t:1528139887469};\\\", \\\"{x:1026,y:672,t:1528139887486};\\\", \\\"{x:1047,y:678,t:1528139887502};\\\", \\\"{x:1079,y:684,t:1528139887519};\\\", \\\"{x:1103,y:693,t:1528139887535};\\\", \\\"{x:1130,y:700,t:1528139887552};\\\", \\\"{x:1154,y:707,t:1528139887568};\\\", \\\"{x:1186,y:719,t:1528139887585};\\\", \\\"{x:1219,y:733,t:1528139887601};\\\", \\\"{x:1257,y:755,t:1528139887619};\\\", \\\"{x:1318,y:797,t:1528139887636};\\\", \\\"{x:1386,y:845,t:1528139887651};\\\", \\\"{x:1445,y:891,t:1528139887668};\\\", \\\"{x:1481,y:922,t:1528139887686};\\\", \\\"{x:1516,y:948,t:1528139887701};\\\", \\\"{x:1548,y:973,t:1528139887719};\\\", \\\"{x:1562,y:984,t:1528139887735};\\\", \\\"{x:1568,y:990,t:1528139887752};\\\", \\\"{x:1570,y:992,t:1528139887769};\\\", \\\"{x:1569,y:992,t:1528139888359};\\\", \\\"{x:1568,y:992,t:1528139888375};\\\", \\\"{x:1567,y:992,t:1528139888390};\\\", \\\"{x:1565,y:992,t:1528139888402};\\\", \\\"{x:1564,y:991,t:1528139888418};\\\", \\\"{x:1562,y:991,t:1528139888447};\\\", \\\"{x:1561,y:990,t:1528139888463};\\\", \\\"{x:1560,y:990,t:1528139888479};\\\", \\\"{x:1559,y:990,t:1528139888486};\\\", \\\"{x:1559,y:989,t:1528139888501};\\\", \\\"{x:1555,y:988,t:1528139888519};\\\", \\\"{x:1553,y:988,t:1528139888535};\\\", \\\"{x:1553,y:987,t:1528139888552};\\\", \\\"{x:1550,y:987,t:1528139888568};\\\", \\\"{x:1549,y:987,t:1528139888584};\\\", \\\"{x:1547,y:987,t:1528139888622};\\\", \\\"{x:1545,y:986,t:1528139888678};\\\", \\\"{x:1544,y:986,t:1528139888703};\\\", \\\"{x:1543,y:985,t:1528139888719};\\\", \\\"{x:1540,y:984,t:1528139888736};\\\", \\\"{x:1539,y:984,t:1528139888895};\\\", \\\"{x:1537,y:983,t:1528139888903};\\\", \\\"{x:1531,y:980,t:1528139888918};\\\", \\\"{x:1528,y:977,t:1528139888935};\\\", \\\"{x:1522,y:976,t:1528139888953};\\\", \\\"{x:1516,y:972,t:1528139888969};\\\", \\\"{x:1506,y:968,t:1528139888986};\\\", \\\"{x:1494,y:964,t:1528139889002};\\\", \\\"{x:1484,y:959,t:1528139889020};\\\", \\\"{x:1472,y:953,t:1528139889035};\\\", \\\"{x:1459,y:947,t:1528139889051};\\\", \\\"{x:1448,y:942,t:1528139889068};\\\", \\\"{x:1446,y:941,t:1528139889085};\\\", \\\"{x:1444,y:940,t:1528139889101};\\\", \\\"{x:1440,y:936,t:1528139889118};\\\", \\\"{x:1435,y:933,t:1528139889135};\\\", \\\"{x:1418,y:920,t:1528139889151};\\\", \\\"{x:1379,y:895,t:1528139889168};\\\", \\\"{x:1335,y:866,t:1528139889185};\\\", \\\"{x:1305,y:854,t:1528139889201};\\\", \\\"{x:1282,y:843,t:1528139889219};\\\", \\\"{x:1260,y:834,t:1528139889235};\\\", \\\"{x:1234,y:824,t:1528139889251};\\\", \\\"{x:1214,y:815,t:1528139889268};\\\", \\\"{x:1208,y:812,t:1528139889285};\\\", \\\"{x:1207,y:812,t:1528139889301};\\\", \\\"{x:1206,y:812,t:1528139889440};\\\", \\\"{x:1204,y:811,t:1528139889503};\\\", \\\"{x:1199,y:806,t:1528139889519};\\\", \\\"{x:1196,y:801,t:1528139889535};\\\", \\\"{x:1196,y:799,t:1528139889551};\\\", \\\"{x:1196,y:797,t:1528139889568};\\\", \\\"{x:1196,y:795,t:1528139889585};\\\", \\\"{x:1196,y:792,t:1528139889602};\\\", \\\"{x:1195,y:790,t:1528139889620};\\\", \\\"{x:1195,y:789,t:1528139889636};\\\", \\\"{x:1195,y:787,t:1528139889652};\\\", \\\"{x:1196,y:784,t:1528139889668};\\\", \\\"{x:1197,y:783,t:1528139889686};\\\", \\\"{x:1197,y:782,t:1528139889702};\\\", \\\"{x:1200,y:781,t:1528139889718};\\\", \\\"{x:1203,y:780,t:1528139889736};\\\", \\\"{x:1207,y:777,t:1528139889751};\\\", \\\"{x:1211,y:775,t:1528139889769};\\\", \\\"{x:1214,y:774,t:1528139889786};\\\", \\\"{x:1218,y:773,t:1528139889802};\\\", \\\"{x:1222,y:772,t:1528139889818};\\\", \\\"{x:1224,y:772,t:1528139889835};\\\", \\\"{x:1228,y:772,t:1528139889852};\\\", \\\"{x:1232,y:771,t:1528139889868};\\\", \\\"{x:1237,y:771,t:1528139889886};\\\", \\\"{x:1241,y:769,t:1528139889902};\\\", \\\"{x:1244,y:769,t:1528139889918};\\\", \\\"{x:1248,y:769,t:1528139889935};\\\", \\\"{x:1252,y:769,t:1528139889952};\\\", \\\"{x:1255,y:769,t:1528139889969};\\\", \\\"{x:1258,y:768,t:1528139889985};\\\", \\\"{x:1263,y:767,t:1528139890001};\\\", \\\"{x:1270,y:765,t:1528139890021};\\\", \\\"{x:1276,y:765,t:1528139890036};\\\", \\\"{x:1285,y:764,t:1528139890052};\\\", \\\"{x:1294,y:764,t:1528139890069};\\\", \\\"{x:1305,y:764,t:1528139890086};\\\", \\\"{x:1315,y:763,t:1528139890102};\\\", \\\"{x:1329,y:762,t:1528139890119};\\\", \\\"{x:1339,y:761,t:1528139890136};\\\", \\\"{x:1348,y:759,t:1528139890152};\\\", \\\"{x:1351,y:759,t:1528139890168};\\\", \\\"{x:1353,y:759,t:1528139890186};\\\", \\\"{x:1355,y:758,t:1528139890202};\\\", \\\"{x:1355,y:757,t:1528139890220};\\\", \\\"{x:1356,y:757,t:1528139890246};\\\", \\\"{x:1354,y:760,t:1528139892407};\\\", \\\"{x:1353,y:762,t:1528139892420};\\\", \\\"{x:1351,y:765,t:1528139892435};\\\", \\\"{x:1350,y:766,t:1528139892452};\\\", \\\"{x:1348,y:767,t:1528139892469};\\\", \\\"{x:1348,y:768,t:1528139892486};\\\", \\\"{x:1347,y:767,t:1528139892686};\\\", \\\"{x:1347,y:765,t:1528139892702};\\\", \\\"{x:1346,y:764,t:1528139892726};\\\", \\\"{x:1345,y:764,t:1528139892736};\\\", \\\"{x:1344,y:764,t:1528139893087};\\\", \\\"{x:1340,y:765,t:1528139893103};\\\", \\\"{x:1328,y:777,t:1528139893118};\\\", \\\"{x:1322,y:785,t:1528139893135};\\\", \\\"{x:1318,y:789,t:1528139893152};\\\", \\\"{x:1315,y:792,t:1528139893169};\\\", \\\"{x:1310,y:796,t:1528139893186};\\\", \\\"{x:1308,y:800,t:1528139893202};\\\", \\\"{x:1303,y:804,t:1528139893221};\\\", \\\"{x:1300,y:808,t:1528139893236};\\\", \\\"{x:1298,y:811,t:1528139893252};\\\", \\\"{x:1297,y:813,t:1528139893270};\\\", \\\"{x:1295,y:814,t:1528139893286};\\\", \\\"{x:1294,y:815,t:1528139893302};\\\", \\\"{x:1292,y:816,t:1528139893318};\\\", \\\"{x:1292,y:816,t:1528139893366};\\\", \\\"{x:1291,y:816,t:1528139893575};\\\", \\\"{x:1290,y:816,t:1528139893585};\\\", \\\"{x:1289,y:816,t:1528139893600};\\\", \\\"{x:1288,y:816,t:1528139893617};\\\", \\\"{x:1286,y:815,t:1528139893635};\\\", \\\"{x:1285,y:814,t:1528139893662};\\\", \\\"{x:1284,y:813,t:1528139893735};\\\", \\\"{x:1283,y:813,t:1528139894199};\\\", \\\"{x:1277,y:809,t:1528139894206};\\\", \\\"{x:1271,y:805,t:1528139894218};\\\", \\\"{x:1252,y:794,t:1528139894235};\\\", \\\"{x:1227,y:782,t:1528139894252};\\\", \\\"{x:1188,y:765,t:1528139894268};\\\", \\\"{x:1150,y:751,t:1528139894284};\\\", \\\"{x:1122,y:738,t:1528139894302};\\\", \\\"{x:1084,y:722,t:1528139894319};\\\", \\\"{x:1072,y:717,t:1528139894335};\\\", \\\"{x:1066,y:715,t:1528139894352};\\\", \\\"{x:1065,y:715,t:1528139894455};\\\", \\\"{x:1069,y:715,t:1528139897370};\\\", \\\"{x:1081,y:715,t:1528139897378};\\\", \\\"{x:1092,y:717,t:1528139897391};\\\", \\\"{x:1115,y:719,t:1528139897407};\\\", \\\"{x:1140,y:724,t:1528139897424};\\\", \\\"{x:1176,y:728,t:1528139897441};\\\", \\\"{x:1191,y:731,t:1528139897458};\\\", \\\"{x:1238,y:738,t:1528139897474};\\\", \\\"{x:1261,y:742,t:1528139897491};\\\", \\\"{x:1285,y:748,t:1528139897507};\\\", \\\"{x:1305,y:754,t:1528139897524};\\\", \\\"{x:1315,y:757,t:1528139897542};\\\", \\\"{x:1324,y:758,t:1528139897557};\\\", \\\"{x:1332,y:761,t:1528139897575};\\\", \\\"{x:1342,y:766,t:1528139897592};\\\", \\\"{x:1354,y:771,t:1528139897607};\\\", \\\"{x:1364,y:773,t:1528139897624};\\\", \\\"{x:1375,y:777,t:1528139897641};\\\", \\\"{x:1376,y:777,t:1528139897657};\\\", \\\"{x:1377,y:778,t:1528139897674};\\\", \\\"{x:1374,y:778,t:1528139897842};\\\", \\\"{x:1367,y:778,t:1528139897858};\\\", \\\"{x:1357,y:778,t:1528139897873};\\\", \\\"{x:1342,y:778,t:1528139897891};\\\", \\\"{x:1326,y:778,t:1528139897908};\\\", \\\"{x:1316,y:778,t:1528139897924};\\\", \\\"{x:1311,y:778,t:1528139897940};\\\", \\\"{x:1306,y:778,t:1528139897957};\\\", \\\"{x:1300,y:778,t:1528139897973};\\\", \\\"{x:1293,y:778,t:1528139897991};\\\", \\\"{x:1284,y:778,t:1528139898007};\\\", \\\"{x:1278,y:776,t:1528139898023};\\\", \\\"{x:1271,y:776,t:1528139898040};\\\", \\\"{x:1265,y:775,t:1528139898057};\\\", \\\"{x:1258,y:774,t:1528139898073};\\\", \\\"{x:1251,y:773,t:1528139898091};\\\", \\\"{x:1245,y:773,t:1528139898108};\\\", \\\"{x:1241,y:772,t:1528139898123};\\\", \\\"{x:1240,y:772,t:1528139898141};\\\", \\\"{x:1238,y:772,t:1528139898161};\\\", \\\"{x:1236,y:772,t:1528139898174};\\\", \\\"{x:1234,y:771,t:1528139898191};\\\", \\\"{x:1226,y:771,t:1528139898209};\\\", \\\"{x:1216,y:768,t:1528139898224};\\\", \\\"{x:1212,y:768,t:1528139898241};\\\", \\\"{x:1204,y:768,t:1528139898258};\\\", \\\"{x:1202,y:768,t:1528139898274};\\\", \\\"{x:1201,y:768,t:1528139898291};\\\", \\\"{x:1199,y:768,t:1528139898308};\\\", \\\"{x:1198,y:768,t:1528139898330};\\\", \\\"{x:1197,y:768,t:1528139898341};\\\", \\\"{x:1196,y:768,t:1528139898358};\\\", \\\"{x:1193,y:767,t:1528139898375};\\\", \\\"{x:1191,y:767,t:1528139898391};\\\", \\\"{x:1187,y:766,t:1528139898408};\\\", \\\"{x:1184,y:766,t:1528139898426};\\\", \\\"{x:1182,y:766,t:1528139898441};\\\", \\\"{x:1181,y:765,t:1528139898458};\\\", \\\"{x:1180,y:765,t:1528139898474};\\\", \\\"{x:1179,y:765,t:1528139898491};\\\", \\\"{x:1176,y:765,t:1528139898507};\\\", \\\"{x:1174,y:765,t:1528139898525};\\\", \\\"{x:1172,y:765,t:1528139898541};\\\", \\\"{x:1170,y:765,t:1528139898558};\\\", \\\"{x:1167,y:765,t:1528139898574};\\\", \\\"{x:1166,y:765,t:1528139898591};\\\", \\\"{x:1164,y:765,t:1528139898608};\\\", \\\"{x:1164,y:764,t:1528139898624};\\\", \\\"{x:1163,y:764,t:1528139898714};\\\", \\\"{x:1163,y:760,t:1528139898730};\\\", \\\"{x:1165,y:748,t:1528139898742};\\\", \\\"{x:1173,y:724,t:1528139898758};\\\", \\\"{x:1183,y:707,t:1528139898776};\\\", \\\"{x:1190,y:690,t:1528139898792};\\\", \\\"{x:1198,y:672,t:1528139898808};\\\", \\\"{x:1206,y:647,t:1528139898825};\\\", \\\"{x:1211,y:637,t:1528139898841};\\\", \\\"{x:1216,y:626,t:1528139898859};\\\", \\\"{x:1225,y:612,t:1528139898875};\\\", \\\"{x:1230,y:603,t:1528139898892};\\\", \\\"{x:1235,y:592,t:1528139898908};\\\", \\\"{x:1237,y:584,t:1528139898925};\\\", \\\"{x:1242,y:573,t:1528139898942};\\\", \\\"{x:1248,y:560,t:1528139898958};\\\", \\\"{x:1253,y:549,t:1528139898975};\\\", \\\"{x:1257,y:540,t:1528139898992};\\\", \\\"{x:1260,y:534,t:1528139899008};\\\", \\\"{x:1263,y:529,t:1528139899025};\\\", \\\"{x:1267,y:524,t:1528139899042};\\\", \\\"{x:1270,y:522,t:1528139899058};\\\", \\\"{x:1273,y:520,t:1528139899074};\\\", \\\"{x:1276,y:518,t:1528139899092};\\\", \\\"{x:1277,y:517,t:1528139899113};\\\", \\\"{x:1278,y:516,t:1528139899124};\\\", \\\"{x:1281,y:514,t:1528139899141};\\\", \\\"{x:1283,y:513,t:1528139899158};\\\", \\\"{x:1284,y:513,t:1528139899175};\\\", \\\"{x:1285,y:517,t:1528139899401};\\\", \\\"{x:1286,y:521,t:1528139899409};\\\", \\\"{x:1287,y:529,t:1528139899425};\\\", \\\"{x:1290,y:541,t:1528139899442};\\\", \\\"{x:1293,y:548,t:1528139899459};\\\", \\\"{x:1294,y:552,t:1528139899475};\\\", \\\"{x:1295,y:556,t:1528139899492};\\\", \\\"{x:1296,y:557,t:1528139899509};\\\", \\\"{x:1296,y:559,t:1528139899525};\\\", \\\"{x:1296,y:560,t:1528139899542};\\\", \\\"{x:1297,y:563,t:1528139899560};\\\", \\\"{x:1298,y:567,t:1528139899576};\\\", \\\"{x:1300,y:572,t:1528139899592};\\\", \\\"{x:1302,y:578,t:1528139899609};\\\", \\\"{x:1304,y:582,t:1528139899625};\\\", \\\"{x:1307,y:591,t:1528139899642};\\\", \\\"{x:1309,y:599,t:1528139899660};\\\", \\\"{x:1314,y:608,t:1528139899676};\\\", \\\"{x:1317,y:616,t:1528139899692};\\\", \\\"{x:1321,y:624,t:1528139899709};\\\", \\\"{x:1325,y:633,t:1528139899726};\\\", \\\"{x:1330,y:647,t:1528139899742};\\\", \\\"{x:1335,y:659,t:1528139899759};\\\", \\\"{x:1338,y:671,t:1528139899777};\\\", \\\"{x:1342,y:687,t:1528139899792};\\\", \\\"{x:1351,y:708,t:1528139899809};\\\", \\\"{x:1355,y:717,t:1528139899825};\\\", \\\"{x:1360,y:725,t:1528139899842};\\\", \\\"{x:1362,y:729,t:1528139899859};\\\", \\\"{x:1364,y:732,t:1528139899876};\\\", \\\"{x:1368,y:740,t:1528139899892};\\\", \\\"{x:1372,y:744,t:1528139899909};\\\", \\\"{x:1375,y:749,t:1528139899927};\\\", \\\"{x:1377,y:751,t:1528139899942};\\\", \\\"{x:1379,y:753,t:1528139899959};\\\", \\\"{x:1382,y:757,t:1528139899976};\\\", \\\"{x:1385,y:761,t:1528139899992};\\\", \\\"{x:1390,y:768,t:1528139900009};\\\", \\\"{x:1395,y:773,t:1528139900026};\\\", \\\"{x:1399,y:777,t:1528139900043};\\\", \\\"{x:1401,y:780,t:1528139900059};\\\", \\\"{x:1402,y:783,t:1528139900076};\\\", \\\"{x:1405,y:788,t:1528139900093};\\\", \\\"{x:1409,y:791,t:1528139900109};\\\", \\\"{x:1411,y:795,t:1528139900126};\\\", \\\"{x:1414,y:799,t:1528139900143};\\\", \\\"{x:1417,y:803,t:1528139900159};\\\", \\\"{x:1420,y:808,t:1528139900176};\\\", \\\"{x:1426,y:821,t:1528139900193};\\\", \\\"{x:1430,y:826,t:1528139900209};\\\", \\\"{x:1435,y:833,t:1528139900226};\\\", \\\"{x:1439,y:840,t:1528139900243};\\\", \\\"{x:1443,y:850,t:1528139900259};\\\", \\\"{x:1450,y:863,t:1528139900276};\\\", \\\"{x:1455,y:875,t:1528139900293};\\\", \\\"{x:1459,y:883,t:1528139900310};\\\", \\\"{x:1462,y:892,t:1528139900326};\\\", \\\"{x:1465,y:899,t:1528139900343};\\\", \\\"{x:1467,y:906,t:1528139900360};\\\", \\\"{x:1468,y:909,t:1528139900376};\\\", \\\"{x:1471,y:915,t:1528139900394};\\\", \\\"{x:1475,y:921,t:1528139900409};\\\", \\\"{x:1480,y:929,t:1528139900426};\\\", \\\"{x:1484,y:936,t:1528139900444};\\\", \\\"{x:1488,y:941,t:1528139900459};\\\", \\\"{x:1489,y:945,t:1528139900477};\\\", \\\"{x:1491,y:950,t:1528139900493};\\\", \\\"{x:1494,y:955,t:1528139900510};\\\", \\\"{x:1496,y:957,t:1528139900526};\\\", \\\"{x:1497,y:961,t:1528139900544};\\\", \\\"{x:1498,y:962,t:1528139900559};\\\", \\\"{x:1501,y:966,t:1528139900577};\\\", \\\"{x:1503,y:970,t:1528139900594};\\\", \\\"{x:1503,y:973,t:1528139900609};\\\", \\\"{x:1503,y:974,t:1528139900649};\\\", \\\"{x:1503,y:971,t:1528139901674};\\\", \\\"{x:1500,y:965,t:1528139901681};\\\", \\\"{x:1496,y:957,t:1528139901695};\\\", \\\"{x:1489,y:944,t:1528139901711};\\\", \\\"{x:1478,y:926,t:1528139901727};\\\", \\\"{x:1461,y:904,t:1528139901744};\\\", \\\"{x:1447,y:886,t:1528139901761};\\\", \\\"{x:1440,y:878,t:1528139901778};\\\", \\\"{x:1438,y:875,t:1528139901795};\\\", \\\"{x:1434,y:866,t:1528139901811};\\\", \\\"{x:1426,y:853,t:1528139901828};\\\", \\\"{x:1419,y:835,t:1528139901845};\\\", \\\"{x:1408,y:809,t:1528139901861};\\\", \\\"{x:1378,y:757,t:1528139901877};\\\", \\\"{x:1347,y:714,t:1528139901895};\\\", \\\"{x:1336,y:702,t:1528139901911};\\\", \\\"{x:1331,y:696,t:1528139901927};\\\", \\\"{x:1321,y:683,t:1528139901944};\\\", \\\"{x:1303,y:657,t:1528139901962};\\\", \\\"{x:1294,y:639,t:1528139901977};\\\", \\\"{x:1273,y:609,t:1528139901994};\\\", \\\"{x:1244,y:569,t:1528139902012};\\\", \\\"{x:1223,y:536,t:1528139902027};\\\", \\\"{x:1210,y:513,t:1528139902044};\\\", \\\"{x:1195,y:492,t:1528139902060};\\\", \\\"{x:1187,y:482,t:1528139902076};\\\", \\\"{x:1186,y:481,t:1528139902094};\\\", \\\"{x:1185,y:481,t:1528139902113};\\\", \\\"{x:1185,y:483,t:1528139902337};\\\", \\\"{x:1190,y:496,t:1528139902346};\\\", \\\"{x:1208,y:525,t:1528139902362};\\\", \\\"{x:1225,y:550,t:1528139902378};\\\", \\\"{x:1243,y:575,t:1528139902394};\\\", \\\"{x:1270,y:604,t:1528139902411};\\\", \\\"{x:1292,y:624,t:1528139902428};\\\", \\\"{x:1311,y:640,t:1528139902444};\\\", \\\"{x:1327,y:661,t:1528139902461};\\\", \\\"{x:1342,y:691,t:1528139902478};\\\", \\\"{x:1362,y:748,t:1528139902494};\\\", \\\"{x:1376,y:798,t:1528139902511};\\\", \\\"{x:1387,y:832,t:1528139902528};\\\", \\\"{x:1400,y:861,t:1528139902544};\\\", \\\"{x:1427,y:905,t:1528139902561};\\\", \\\"{x:1438,y:924,t:1528139902578};\\\", \\\"{x:1445,y:941,t:1528139902594};\\\", \\\"{x:1452,y:957,t:1528139902611};\\\", \\\"{x:1458,y:973,t:1528139902628};\\\", \\\"{x:1462,y:985,t:1528139902644};\\\", \\\"{x:1464,y:991,t:1528139902661};\\\", \\\"{x:1467,y:996,t:1528139902678};\\\", \\\"{x:1467,y:997,t:1528139902695};\\\", \\\"{x:1467,y:998,t:1528139902794};\\\", \\\"{x:1467,y:996,t:1528139902970};\\\", \\\"{x:1467,y:992,t:1528139902978};\\\", \\\"{x:1467,y:988,t:1528139902995};\\\", \\\"{x:1467,y:987,t:1528139903011};\\\", \\\"{x:1467,y:985,t:1528139903028};\\\", \\\"{x:1467,y:983,t:1528139903046};\\\", \\\"{x:1467,y:978,t:1528139903061};\\\", \\\"{x:1467,y:972,t:1528139903078};\\\", \\\"{x:1467,y:969,t:1528139903095};\\\", \\\"{x:1465,y:962,t:1528139903112};\\\", \\\"{x:1464,y:955,t:1528139903129};\\\", \\\"{x:1464,y:949,t:1528139903145};\\\", \\\"{x:1462,y:942,t:1528139903162};\\\", \\\"{x:1460,y:934,t:1528139903178};\\\", \\\"{x:1456,y:922,t:1528139903195};\\\", \\\"{x:1451,y:910,t:1528139903212};\\\", \\\"{x:1445,y:896,t:1528139903228};\\\", \\\"{x:1441,y:889,t:1528139903246};\\\", \\\"{x:1437,y:879,t:1528139903262};\\\", \\\"{x:1432,y:871,t:1528139903279};\\\", \\\"{x:1429,y:865,t:1528139903295};\\\", \\\"{x:1426,y:859,t:1528139903312};\\\", \\\"{x:1424,y:853,t:1528139903329};\\\", \\\"{x:1420,y:843,t:1528139903345};\\\", \\\"{x:1415,y:831,t:1528139903362};\\\", \\\"{x:1411,y:823,t:1528139903378};\\\", \\\"{x:1410,y:821,t:1528139903395};\\\", \\\"{x:1409,y:818,t:1528139903417};\\\", \\\"{x:1409,y:817,t:1528139903434};\\\", \\\"{x:1409,y:816,t:1528139903445};\\\", \\\"{x:1406,y:812,t:1528139903463};\\\", \\\"{x:1404,y:809,t:1528139903478};\\\", \\\"{x:1402,y:806,t:1528139903495};\\\", \\\"{x:1401,y:803,t:1528139903512};\\\", \\\"{x:1398,y:799,t:1528139903528};\\\", \\\"{x:1395,y:793,t:1528139903545};\\\", \\\"{x:1392,y:790,t:1528139903563};\\\", \\\"{x:1391,y:789,t:1528139903578};\\\", \\\"{x:1390,y:788,t:1528139903595};\\\", \\\"{x:1390,y:786,t:1528139903874};\\\", \\\"{x:1389,y:786,t:1528139903881};\\\", \\\"{x:1389,y:785,t:1528139903913};\\\", \\\"{x:1389,y:783,t:1528139903946};\\\", \\\"{x:1388,y:783,t:1528139903962};\\\", \\\"{x:1387,y:782,t:1528139904314};\\\", \\\"{x:1383,y:782,t:1528139904329};\\\", \\\"{x:1379,y:781,t:1528139904347};\\\", \\\"{x:1369,y:779,t:1528139904363};\\\", \\\"{x:1358,y:779,t:1528139904380};\\\", \\\"{x:1341,y:779,t:1528139904397};\\\", \\\"{x:1326,y:779,t:1528139904413};\\\", \\\"{x:1314,y:779,t:1528139904429};\\\", \\\"{x:1303,y:779,t:1528139904446};\\\", \\\"{x:1294,y:779,t:1528139904463};\\\", \\\"{x:1287,y:779,t:1528139904480};\\\", \\\"{x:1283,y:779,t:1528139904496};\\\", \\\"{x:1273,y:779,t:1528139904513};\\\", \\\"{x:1262,y:779,t:1528139904529};\\\", \\\"{x:1247,y:779,t:1528139904546};\\\", \\\"{x:1227,y:779,t:1528139904563};\\\", \\\"{x:1202,y:779,t:1528139904580};\\\", \\\"{x:1182,y:779,t:1528139904596};\\\", \\\"{x:1155,y:779,t:1528139904613};\\\", \\\"{x:1121,y:779,t:1528139904630};\\\", \\\"{x:1077,y:775,t:1528139904646};\\\", \\\"{x:1020,y:765,t:1528139904663};\\\", \\\"{x:942,y:750,t:1528139904679};\\\", \\\"{x:864,y:730,t:1528139904696};\\\", \\\"{x:756,y:697,t:1528139904713};\\\", \\\"{x:692,y:669,t:1528139904729};\\\", \\\"{x:626,y:644,t:1528139904747};\\\", \\\"{x:577,y:625,t:1528139904765};\\\", \\\"{x:542,y:612,t:1528139904779};\\\", \\\"{x:521,y:602,t:1528139904796};\\\", \\\"{x:504,y:592,t:1528139904813};\\\", \\\"{x:498,y:588,t:1528139904830};\\\", \\\"{x:493,y:585,t:1528139904846};\\\", \\\"{x:493,y:584,t:1528139904880};\\\", \\\"{x:493,y:583,t:1528139904921};\\\", \\\"{x:493,y:580,t:1528139904930};\\\", \\\"{x:493,y:576,t:1528139904946};\\\", \\\"{x:493,y:574,t:1528139904962};\\\", \\\"{x:493,y:573,t:1528139904980};\\\", \\\"{x:493,y:572,t:1528139905001};\\\", \\\"{x:493,y:571,t:1528139905013};\\\", \\\"{x:493,y:570,t:1528139905030};\\\", \\\"{x:496,y:570,t:1528139905047};\\\", \\\"{x:504,y:569,t:1528139905063};\\\", \\\"{x:518,y:569,t:1528139905079};\\\", \\\"{x:543,y:567,t:1528139905097};\\\", \\\"{x:545,y:567,t:1528139905113};\\\", \\\"{x:545,y:566,t:1528139905130};\\\", \\\"{x:544,y:566,t:1528139905305};\\\", \\\"{x:533,y:566,t:1528139905313};\\\", \\\"{x:520,y:566,t:1528139905330};\\\", \\\"{x:517,y:566,t:1528139905347};\\\", \\\"{x:516,y:566,t:1528139905363};\\\", \\\"{x:515,y:566,t:1528139905380};\\\", \\\"{x:512,y:566,t:1528139905397};\\\", \\\"{x:511,y:566,t:1528139905413};\\\", \\\"{x:509,y:566,t:1528139905431};\\\", \\\"{x:505,y:566,t:1528139905447};\\\", \\\"{x:498,y:566,t:1528139905465};\\\", \\\"{x:492,y:565,t:1528139905480};\\\", \\\"{x:476,y:554,t:1528139905497};\\\", \\\"{x:455,y:539,t:1528139905513};\\\", \\\"{x:427,y:521,t:1528139905530};\\\", \\\"{x:408,y:509,t:1528139905548};\\\", \\\"{x:390,y:498,t:1528139905564};\\\", \\\"{x:378,y:493,t:1528139905580};\\\", \\\"{x:367,y:487,t:1528139905597};\\\", \\\"{x:364,y:487,t:1528139905613};\\\", \\\"{x:363,y:487,t:1528139905681};\\\", \\\"{x:360,y:487,t:1528139905696};\\\", \\\"{x:354,y:494,t:1528139905714};\\\", \\\"{x:345,y:503,t:1528139905730};\\\", \\\"{x:338,y:508,t:1528139905746};\\\", \\\"{x:330,y:514,t:1528139905764};\\\", \\\"{x:324,y:519,t:1528139905781};\\\", \\\"{x:316,y:526,t:1528139905797};\\\", \\\"{x:304,y:537,t:1528139905814};\\\", \\\"{x:290,y:546,t:1528139905831};\\\", \\\"{x:276,y:556,t:1528139905847};\\\", \\\"{x:258,y:563,t:1528139905865};\\\", \\\"{x:243,y:568,t:1528139905879};\\\", \\\"{x:226,y:571,t:1528139905897};\\\", \\\"{x:220,y:571,t:1528139905914};\\\", \\\"{x:216,y:571,t:1528139905930};\\\", \\\"{x:211,y:568,t:1528139905947};\\\", \\\"{x:206,y:559,t:1528139905964};\\\", \\\"{x:196,y:544,t:1528139905981};\\\", \\\"{x:187,y:533,t:1528139905997};\\\", \\\"{x:183,y:528,t:1528139906014};\\\", \\\"{x:182,y:526,t:1528139906031};\\\", \\\"{x:178,y:520,t:1528139906048};\\\", \\\"{x:174,y:511,t:1528139906065};\\\", \\\"{x:173,y:507,t:1528139906081};\\\", \\\"{x:173,y:506,t:1528139906105};\\\", \\\"{x:173,y:509,t:1528139906512};\\\", \\\"{x:212,y:552,t:1528139906521};\\\", \\\"{x:277,y:617,t:1528139906532};\\\", \\\"{x:407,y:729,t:1528139906549};\\\", \\\"{x:499,y:801,t:1528139906564};\\\", \\\"{x:550,y:834,t:1528139906581};\\\", \\\"{x:589,y:853,t:1528139906598};\\\", \\\"{x:608,y:861,t:1528139906614};\\\", \\\"{x:614,y:862,t:1528139906631};\\\", \\\"{x:615,y:862,t:1528139906648};\\\", \\\"{x:616,y:860,t:1528139906664};\\\", \\\"{x:616,y:854,t:1528139906681};\\\", \\\"{x:614,y:841,t:1528139906698};\\\", \\\"{x:601,y:818,t:1528139906715};\\\", \\\"{x:589,y:801,t:1528139906731};\\\", \\\"{x:580,y:788,t:1528139906748};\\\", \\\"{x:577,y:784,t:1528139906766};\\\", \\\"{x:574,y:777,t:1528139906781};\\\", \\\"{x:565,y:766,t:1528139906798};\\\", \\\"{x:558,y:757,t:1528139906815};\\\", \\\"{x:557,y:755,t:1528139906831};\\\", \\\"{x:556,y:755,t:1528139906849};\\\", \\\"{x:555,y:754,t:1528139906955};\\\", \\\"{x:553,y:753,t:1528139906965};\\\", \\\"{x:545,y:750,t:1528139906981};\\\", \\\"{x:536,y:746,t:1528139906998};\\\", \\\"{x:533,y:745,t:1528139907015};\\\", \\\"{x:528,y:743,t:1528139907031};\\\", \\\"{x:527,y:742,t:1528139907048};\\\" ] }, { \\\"rt\\\": 17859, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 542528, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X -03 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:735,t:1528139909745};\\\", \\\"{x:575,y:720,t:1528139909755};\\\", \\\"{x:627,y:708,t:1528139909766};\\\", \\\"{x:732,y:696,t:1528139909784};\\\", \\\"{x:885,y:696,t:1528139909800};\\\", \\\"{x:987,y:696,t:1528139909817};\\\", \\\"{x:1095,y:696,t:1528139909834};\\\", \\\"{x:1218,y:690,t:1528139909851};\\\", \\\"{x:1343,y:688,t:1528139909867};\\\", \\\"{x:1464,y:678,t:1528139909884};\\\", \\\"{x:1563,y:666,t:1528139909902};\\\", \\\"{x:1622,y:658,t:1528139909917};\\\", \\\"{x:1650,y:654,t:1528139909934};\\\", \\\"{x:1668,y:653,t:1528139909951};\\\", \\\"{x:1671,y:653,t:1528139909967};\\\", \\\"{x:1674,y:653,t:1528139909984};\\\", \\\"{x:1688,y:646,t:1528139910001};\\\", \\\"{x:1701,y:640,t:1528139910018};\\\", \\\"{x:1728,y:628,t:1528139910034};\\\", \\\"{x:1771,y:611,t:1528139910051};\\\", \\\"{x:1827,y:597,t:1528139910069};\\\", \\\"{x:1887,y:581,t:1528139910084};\\\", \\\"{x:1919,y:573,t:1528139910101};\\\", \\\"{x:1919,y:568,t:1528139910118};\\\", \\\"{x:1919,y:565,t:1528139910170};\\\", \\\"{x:1919,y:562,t:1528139910184};\\\", \\\"{x:1919,y:544,t:1528139910201};\\\", \\\"{x:1919,y:529,t:1528139910217};\\\", \\\"{x:1919,y:509,t:1528139910234};\\\", \\\"{x:1919,y:483,t:1528139910251};\\\", \\\"{x:1919,y:475,t:1528139910267};\\\", \\\"{x:1919,y:473,t:1528139910288};\\\", \\\"{x:1919,y:470,t:1528139910301};\\\", \\\"{x:1919,y:466,t:1528139910317};\\\", \\\"{x:1919,y:463,t:1528139910335};\\\", \\\"{x:1919,y:459,t:1528139910352};\\\", \\\"{x:1919,y:456,t:1528139910368};\\\", \\\"{x:1919,y:455,t:1528139910384};\\\", \\\"{x:1919,y:453,t:1528139910402};\\\", \\\"{x:1918,y:453,t:1528139910849};\\\", \\\"{x:1910,y:453,t:1528139910857};\\\", \\\"{x:1903,y:456,t:1528139910869};\\\", \\\"{x:1881,y:461,t:1528139910885};\\\", \\\"{x:1851,y:469,t:1528139910901};\\\", \\\"{x:1807,y:478,t:1528139910918};\\\", \\\"{x:1755,y:493,t:1528139910935};\\\", \\\"{x:1707,y:508,t:1528139910951};\\\", \\\"{x:1675,y:517,t:1528139910969};\\\", \\\"{x:1635,y:532,t:1528139910986};\\\", \\\"{x:1616,y:541,t:1528139911002};\\\", \\\"{x:1600,y:552,t:1528139911019};\\\", \\\"{x:1585,y:562,t:1528139911035};\\\", \\\"{x:1572,y:575,t:1528139911052};\\\", \\\"{x:1564,y:582,t:1528139911068};\\\", \\\"{x:1559,y:588,t:1528139911086};\\\", \\\"{x:1556,y:592,t:1528139911103};\\\", \\\"{x:1554,y:594,t:1528139911119};\\\", \\\"{x:1551,y:596,t:1528139911136};\\\", \\\"{x:1545,y:599,t:1528139911153};\\\", \\\"{x:1542,y:601,t:1528139911169};\\\", \\\"{x:1538,y:602,t:1528139911185};\\\", \\\"{x:1536,y:603,t:1528139911202};\\\", \\\"{x:1535,y:603,t:1528139911233};\\\", \\\"{x:1530,y:600,t:1528139915986};\\\", \\\"{x:1519,y:581,t:1528139915994};\\\", \\\"{x:1505,y:562,t:1528139916007};\\\", \\\"{x:1492,y:545,t:1528139916023};\\\", \\\"{x:1476,y:523,t:1528139916040};\\\", \\\"{x:1457,y:495,t:1528139916057};\\\", \\\"{x:1448,y:483,t:1528139916073};\\\", \\\"{x:1443,y:476,t:1528139916090};\\\", \\\"{x:1439,y:470,t:1528139916107};\\\", \\\"{x:1434,y:459,t:1528139916124};\\\", \\\"{x:1429,y:443,t:1528139916140};\\\", \\\"{x:1424,y:426,t:1528139916157};\\\", \\\"{x:1419,y:412,t:1528139916174};\\\", \\\"{x:1415,y:396,t:1528139916189};\\\", \\\"{x:1410,y:377,t:1528139916207};\\\", \\\"{x:1406,y:347,t:1528139916224};\\\", \\\"{x:1403,y:318,t:1528139916240};\\\", \\\"{x:1403,y:285,t:1528139916257};\\\", \\\"{x:1404,y:260,t:1528139916273};\\\", \\\"{x:1406,y:249,t:1528139916289};\\\", \\\"{x:1410,y:239,t:1528139916306};\\\", \\\"{x:1412,y:231,t:1528139916323};\\\", \\\"{x:1413,y:229,t:1528139916339};\\\", \\\"{x:1413,y:227,t:1528139916356};\\\", \\\"{x:1413,y:226,t:1528139916373};\\\", \\\"{x:1413,y:225,t:1528139916389};\\\", \\\"{x:1413,y:224,t:1528139916417};\\\", \\\"{x:1413,y:223,t:1528139916473};\\\", \\\"{x:1413,y:222,t:1528139916552};\\\", \\\"{x:1412,y:222,t:1528139916609};\\\", \\\"{x:1410,y:222,t:1528139916623};\\\", \\\"{x:1409,y:222,t:1528139916865};\\\", \\\"{x:1408,y:222,t:1528139916953};\\\", \\\"{x:1405,y:222,t:1528139916977};\\\", \\\"{x:1394,y:223,t:1528139916991};\\\", \\\"{x:1357,y:230,t:1528139917008};\\\", \\\"{x:1337,y:234,t:1528139917025};\\\", \\\"{x:1331,y:238,t:1528139917041};\\\", \\\"{x:1331,y:239,t:1528139917058};\\\", \\\"{x:1330,y:239,t:1528139917178};\\\", \\\"{x:1330,y:233,t:1528139917191};\\\", \\\"{x:1326,y:220,t:1528139917208};\\\", \\\"{x:1307,y:200,t:1528139917225};\\\", \\\"{x:1288,y:187,t:1528139917241};\\\", \\\"{x:1268,y:176,t:1528139917257};\\\", \\\"{x:1250,y:165,t:1528139917275};\\\", \\\"{x:1244,y:161,t:1528139917291};\\\", \\\"{x:1242,y:158,t:1528139917308};\\\", \\\"{x:1241,y:156,t:1528139917325};\\\", \\\"{x:1240,y:155,t:1528139917341};\\\", \\\"{x:1239,y:154,t:1528139917358};\\\", \\\"{x:1238,y:154,t:1528139917385};\\\", \\\"{x:1236,y:154,t:1528139917449};\\\", \\\"{x:1234,y:154,t:1528139917466};\\\", \\\"{x:1234,y:167,t:1528139917475};\\\", \\\"{x:1238,y:199,t:1528139917491};\\\", \\\"{x:1247,y:212,t:1528139917508};\\\", \\\"{x:1252,y:216,t:1528139917525};\\\", \\\"{x:1253,y:217,t:1528139917569};\\\", \\\"{x:1254,y:218,t:1528139917577};\\\", \\\"{x:1258,y:224,t:1528139917592};\\\", \\\"{x:1267,y:232,t:1528139917608};\\\", \\\"{x:1268,y:232,t:1528139917625};\\\", \\\"{x:1263,y:236,t:1528139917976};\\\", \\\"{x:1257,y:238,t:1528139917991};\\\", \\\"{x:1252,y:241,t:1528139918009};\\\", \\\"{x:1248,y:243,t:1528139918024};\\\", \\\"{x:1239,y:251,t:1528139918042};\\\", \\\"{x:1229,y:259,t:1528139918059};\\\", \\\"{x:1215,y:267,t:1528139918074};\\\", \\\"{x:1196,y:280,t:1528139918091};\\\", \\\"{x:1177,y:292,t:1528139918108};\\\", \\\"{x:1143,y:311,t:1528139918124};\\\", \\\"{x:1099,y:336,t:1528139918141};\\\", \\\"{x:1044,y:369,t:1528139918159};\\\", \\\"{x:983,y:414,t:1528139918175};\\\", \\\"{x:932,y:461,t:1528139918192};\\\", \\\"{x:829,y:588,t:1528139918210};\\\", \\\"{x:768,y:682,t:1528139918225};\\\", \\\"{x:712,y:789,t:1528139918241};\\\", \\\"{x:674,y:905,t:1528139918257};\\\", \\\"{x:656,y:1022,t:1528139918274};\\\", \\\"{x:656,y:1122,t:1528139918290};\\\", \\\"{x:681,y:1199,t:1528139918308};\\\", \\\"{x:744,y:1199,t:1528139918324};\\\", \\\"{x:827,y:1199,t:1528139918340};\\\", \\\"{x:940,y:1199,t:1528139918357};\\\", \\\"{x:1070,y:1199,t:1528139918374};\\\", \\\"{x:1203,y:1199,t:1528139918391};\\\", \\\"{x:1322,y:1199,t:1528139918407};\\\", \\\"{x:1439,y:1199,t:1528139918424};\\\", \\\"{x:1462,y:1191,t:1528139918441};\\\", \\\"{x:1468,y:1184,t:1528139918457};\\\", \\\"{x:1476,y:1170,t:1528139918474};\\\", \\\"{x:1488,y:1139,t:1528139918491};\\\", \\\"{x:1506,y:1098,t:1528139918507};\\\", \\\"{x:1528,y:1051,t:1528139918525};\\\", \\\"{x:1549,y:1010,t:1528139918541};\\\", \\\"{x:1569,y:966,t:1528139918557};\\\", \\\"{x:1588,y:927,t:1528139918574};\\\", \\\"{x:1610,y:886,t:1528139918592};\\\", \\\"{x:1625,y:857,t:1528139918607};\\\", \\\"{x:1645,y:815,t:1528139918625};\\\", \\\"{x:1651,y:797,t:1528139918641};\\\", \\\"{x:1656,y:784,t:1528139918658};\\\", \\\"{x:1658,y:780,t:1528139918675};\\\", \\\"{x:1660,y:776,t:1528139918692};\\\", \\\"{x:1661,y:774,t:1528139918707};\\\", \\\"{x:1661,y:772,t:1528139918873};\\\", \\\"{x:1660,y:772,t:1528139918882};\\\", \\\"{x:1656,y:772,t:1528139918892};\\\", \\\"{x:1646,y:772,t:1528139918909};\\\", \\\"{x:1636,y:772,t:1528139918925};\\\", \\\"{x:1626,y:772,t:1528139918942};\\\", \\\"{x:1619,y:772,t:1528139918959};\\\", \\\"{x:1612,y:772,t:1528139918974};\\\", \\\"{x:1608,y:770,t:1528139918991};\\\", \\\"{x:1603,y:770,t:1528139919009};\\\", \\\"{x:1600,y:770,t:1528139919025};\\\", \\\"{x:1599,y:770,t:1528139919049};\\\", \\\"{x:1598,y:770,t:1528139919059};\\\", \\\"{x:1597,y:771,t:1528139919081};\\\", \\\"{x:1595,y:771,t:1528139919105};\\\", \\\"{x:1593,y:773,t:1528139919114};\\\", \\\"{x:1592,y:773,t:1528139919125};\\\", \\\"{x:1588,y:775,t:1528139919142};\\\", \\\"{x:1581,y:778,t:1528139919159};\\\", \\\"{x:1573,y:782,t:1528139919175};\\\", \\\"{x:1567,y:783,t:1528139919192};\\\", \\\"{x:1559,y:787,t:1528139919209};\\\", \\\"{x:1556,y:789,t:1528139919225};\\\", \\\"{x:1554,y:790,t:1528139919242};\\\", \\\"{x:1551,y:791,t:1528139919259};\\\", \\\"{x:1548,y:793,t:1528139919275};\\\", \\\"{x:1545,y:794,t:1528139919291};\\\", \\\"{x:1541,y:796,t:1528139919308};\\\", \\\"{x:1534,y:798,t:1528139919325};\\\", \\\"{x:1527,y:802,t:1528139919341};\\\", \\\"{x:1519,y:804,t:1528139919358};\\\", \\\"{x:1506,y:807,t:1528139919375};\\\", \\\"{x:1480,y:811,t:1528139919391};\\\", \\\"{x:1453,y:813,t:1528139919409};\\\", \\\"{x:1439,y:813,t:1528139919426};\\\", \\\"{x:1429,y:813,t:1528139919441};\\\", \\\"{x:1426,y:813,t:1528139919459};\\\", \\\"{x:1425,y:813,t:1528139919476};\\\", \\\"{x:1424,y:813,t:1528139919497};\\\", \\\"{x:1423,y:813,t:1528139919553};\\\", \\\"{x:1422,y:809,t:1528139919562};\\\", \\\"{x:1419,y:802,t:1528139919576};\\\", \\\"{x:1413,y:786,t:1528139919591};\\\", \\\"{x:1410,y:770,t:1528139919609};\\\", \\\"{x:1407,y:758,t:1528139919626};\\\", \\\"{x:1403,y:747,t:1528139919643};\\\", \\\"{x:1400,y:738,t:1528139919659};\\\", \\\"{x:1398,y:731,t:1528139919676};\\\", \\\"{x:1397,y:725,t:1528139919692};\\\", \\\"{x:1396,y:718,t:1528139919709};\\\", \\\"{x:1396,y:710,t:1528139919726};\\\", \\\"{x:1396,y:706,t:1528139919743};\\\", \\\"{x:1395,y:697,t:1528139919759};\\\", \\\"{x:1394,y:691,t:1528139919775};\\\", \\\"{x:1393,y:687,t:1528139919793};\\\", \\\"{x:1392,y:684,t:1528139919809};\\\", \\\"{x:1391,y:681,t:1528139919826};\\\", \\\"{x:1391,y:680,t:1528139919843};\\\", \\\"{x:1391,y:678,t:1528139919859};\\\", \\\"{x:1391,y:677,t:1528139919970};\\\", \\\"{x:1392,y:675,t:1528139919986};\\\", \\\"{x:1394,y:673,t:1528139919993};\\\", \\\"{x:1406,y:668,t:1528139920009};\\\", \\\"{x:1422,y:660,t:1528139920026};\\\", \\\"{x:1450,y:654,t:1528139920043};\\\", \\\"{x:1482,y:648,t:1528139920059};\\\", \\\"{x:1520,y:645,t:1528139920076};\\\", \\\"{x:1547,y:639,t:1528139920093};\\\", \\\"{x:1576,y:638,t:1528139920111};\\\", \\\"{x:1600,y:638,t:1528139920126};\\\", \\\"{x:1627,y:638,t:1528139920144};\\\", \\\"{x:1649,y:638,t:1528139920160};\\\", \\\"{x:1664,y:638,t:1528139920176};\\\", \\\"{x:1678,y:638,t:1528139920192};\\\", \\\"{x:1681,y:638,t:1528139920209};\\\", \\\"{x:1682,y:638,t:1528139920336};\\\", \\\"{x:1681,y:640,t:1528139920344};\\\", \\\"{x:1676,y:642,t:1528139920359};\\\", \\\"{x:1671,y:644,t:1528139920375};\\\", \\\"{x:1669,y:645,t:1528139920393};\\\", \\\"{x:1666,y:645,t:1528139920409};\\\", \\\"{x:1663,y:648,t:1528139920425};\\\", \\\"{x:1660,y:648,t:1528139920443};\\\", \\\"{x:1659,y:649,t:1528139920460};\\\", \\\"{x:1657,y:650,t:1528139920476};\\\", \\\"{x:1655,y:651,t:1528139920493};\\\", \\\"{x:1653,y:651,t:1528139920509};\\\", \\\"{x:1649,y:654,t:1528139920526};\\\", \\\"{x:1647,y:654,t:1528139920543};\\\", \\\"{x:1642,y:656,t:1528139920560};\\\", \\\"{x:1637,y:659,t:1528139920577};\\\", \\\"{x:1634,y:662,t:1528139920593};\\\", \\\"{x:1630,y:663,t:1528139920610};\\\", \\\"{x:1622,y:668,t:1528139920627};\\\", \\\"{x:1613,y:671,t:1528139920643};\\\", \\\"{x:1601,y:674,t:1528139920660};\\\", \\\"{x:1590,y:676,t:1528139920677};\\\", \\\"{x:1573,y:677,t:1528139920692};\\\", \\\"{x:1548,y:681,t:1528139920710};\\\", \\\"{x:1517,y:682,t:1528139920727};\\\", \\\"{x:1485,y:682,t:1528139920743};\\\", \\\"{x:1452,y:682,t:1528139920760};\\\", \\\"{x:1390,y:682,t:1528139920777};\\\", \\\"{x:1351,y:682,t:1528139920793};\\\", \\\"{x:1311,y:682,t:1528139920810};\\\", \\\"{x:1283,y:682,t:1528139920827};\\\", \\\"{x:1264,y:681,t:1528139920842};\\\", \\\"{x:1254,y:680,t:1528139920860};\\\", \\\"{x:1253,y:679,t:1528139920954};\\\", \\\"{x:1255,y:681,t:1528139921026};\\\", \\\"{x:1267,y:686,t:1528139921044};\\\", \\\"{x:1278,y:691,t:1528139921061};\\\", \\\"{x:1286,y:695,t:1528139921077};\\\", \\\"{x:1293,y:699,t:1528139921094};\\\", \\\"{x:1299,y:704,t:1528139921110};\\\", \\\"{x:1302,y:706,t:1528139921127};\\\", \\\"{x:1303,y:707,t:1528139921144};\\\", \\\"{x:1304,y:707,t:1528139921257};\\\", \\\"{x:1306,y:707,t:1528139921272};\\\", \\\"{x:1307,y:707,t:1528139921297};\\\", \\\"{x:1308,y:707,t:1528139921311};\\\", \\\"{x:1310,y:707,t:1528139921327};\\\", \\\"{x:1311,y:706,t:1528139921344};\\\", \\\"{x:1315,y:702,t:1528139921360};\\\", \\\"{x:1316,y:701,t:1528139921376};\\\", \\\"{x:1317,y:700,t:1528139921394};\\\", \\\"{x:1317,y:698,t:1528139921410};\\\", \\\"{x:1318,y:698,t:1528139921433};\\\", \\\"{x:1320,y:698,t:1528139921714};\\\", \\\"{x:1321,y:698,t:1528139921727};\\\", \\\"{x:1325,y:698,t:1528139921744};\\\", \\\"{x:1328,y:698,t:1528139921761};\\\", \\\"{x:1338,y:701,t:1528139921777};\\\", \\\"{x:1351,y:707,t:1528139921794};\\\", \\\"{x:1368,y:714,t:1528139921811};\\\", \\\"{x:1385,y:721,t:1528139921828};\\\", \\\"{x:1404,y:730,t:1528139921844};\\\", \\\"{x:1422,y:739,t:1528139921861};\\\", \\\"{x:1434,y:744,t:1528139921878};\\\", \\\"{x:1443,y:750,t:1528139921894};\\\", \\\"{x:1448,y:754,t:1528139921911};\\\", \\\"{x:1448,y:755,t:1528139921928};\\\", \\\"{x:1449,y:756,t:1528139921944};\\\", \\\"{x:1450,y:756,t:1528139921969};\\\", \\\"{x:1450,y:758,t:1528139921977};\\\", \\\"{x:1451,y:759,t:1528139921995};\\\", \\\"{x:1451,y:761,t:1528139922012};\\\", \\\"{x:1452,y:765,t:1528139922028};\\\", \\\"{x:1454,y:770,t:1528139922044};\\\", \\\"{x:1456,y:775,t:1528139922061};\\\", \\\"{x:1460,y:784,t:1528139922078};\\\", \\\"{x:1463,y:790,t:1528139922094};\\\", \\\"{x:1466,y:798,t:1528139922112};\\\", \\\"{x:1468,y:804,t:1528139922128};\\\", \\\"{x:1471,y:816,t:1528139922146};\\\", \\\"{x:1471,y:822,t:1528139922161};\\\", \\\"{x:1473,y:828,t:1528139922178};\\\", \\\"{x:1476,y:837,t:1528139922195};\\\", \\\"{x:1480,y:852,t:1528139922211};\\\", \\\"{x:1484,y:861,t:1528139922228};\\\", \\\"{x:1486,y:864,t:1528139922245};\\\", \\\"{x:1488,y:868,t:1528139922262};\\\", \\\"{x:1491,y:875,t:1528139922278};\\\", \\\"{x:1493,y:886,t:1528139922295};\\\", \\\"{x:1495,y:897,t:1528139922311};\\\", \\\"{x:1498,y:906,t:1528139922328};\\\", \\\"{x:1501,y:915,t:1528139922345};\\\", \\\"{x:1504,y:921,t:1528139922361};\\\", \\\"{x:1508,y:930,t:1528139922378};\\\", \\\"{x:1512,y:941,t:1528139922396};\\\", \\\"{x:1518,y:957,t:1528139922411};\\\", \\\"{x:1524,y:970,t:1528139922428};\\\", \\\"{x:1529,y:982,t:1528139922446};\\\", \\\"{x:1536,y:994,t:1528139922462};\\\", \\\"{x:1538,y:1001,t:1528139922478};\\\", \\\"{x:1543,y:1006,t:1528139922495};\\\", \\\"{x:1545,y:1009,t:1528139922511};\\\", \\\"{x:1546,y:1012,t:1528139922528};\\\", \\\"{x:1548,y:1014,t:1528139922545};\\\", \\\"{x:1527,y:1009,t:1528139923226};\\\", \\\"{x:1466,y:992,t:1528139923233};\\\", \\\"{x:1408,y:978,t:1528139923245};\\\", \\\"{x:1302,y:936,t:1528139923265};\\\", \\\"{x:1162,y:884,t:1528139923279};\\\", \\\"{x:978,y:813,t:1528139923295};\\\", \\\"{x:736,y:720,t:1528139923312};\\\", \\\"{x:370,y:573,t:1528139923330};\\\", \\\"{x:137,y:488,t:1528139923347};\\\", \\\"{x:0,y:397,t:1528139923362};\\\", \\\"{x:0,y:234,t:1528139923395};\\\", \\\"{x:0,y:163,t:1528139923412};\\\", \\\"{x:0,y:102,t:1528139923429};\\\", \\\"{x:0,y:61,t:1528139923445};\\\", \\\"{x:0,y:34,t:1528139923462};\\\", \\\"{x:0,y:22,t:1528139923478};\\\", \\\"{x:0,y:18,t:1528139923495};\\\", \\\"{x:0,y:16,t:1528139923511};\\\", \\\"{x:17,y:0,t:1528139923528};\\\", \\\"{x:59,y:0,t:1528139923546};\\\", \\\"{x:114,y:0,t:1528139923562};\\\", \\\"{x:193,y:11,t:1528139923579};\\\", \\\"{x:273,y:32,t:1528139923596};\\\", \\\"{x:335,y:54,t:1528139923612};\\\", \\\"{x:391,y:80,t:1528139923629};\\\", \\\"{x:430,y:97,t:1528139923645};\\\", \\\"{x:457,y:113,t:1528139923662};\\\", \\\"{x:473,y:123,t:1528139923678};\\\", \\\"{x:482,y:127,t:1528139923695};\\\", \\\"{x:489,y:131,t:1528139923711};\\\", \\\"{x:496,y:135,t:1528139923729};\\\", \\\"{x:507,y:142,t:1528139923746};\\\", \\\"{x:521,y:154,t:1528139923762};\\\", \\\"{x:535,y:168,t:1528139923779};\\\", \\\"{x:543,y:179,t:1528139923795};\\\", \\\"{x:552,y:191,t:1528139923812};\\\", \\\"{x:557,y:209,t:1528139923828};\\\", \\\"{x:562,y:238,t:1528139923846};\\\", \\\"{x:568,y:272,t:1528139923863};\\\", \\\"{x:581,y:315,t:1528139923879};\\\", \\\"{x:590,y:341,t:1528139923896};\\\", \\\"{x:605,y:373,t:1528139923912};\\\", \\\"{x:613,y:392,t:1528139923929};\\\", \\\"{x:621,y:411,t:1528139923946};\\\", \\\"{x:628,y:426,t:1528139923963};\\\", \\\"{x:631,y:434,t:1528139923979};\\\", \\\"{x:632,y:437,t:1528139923996};\\\", \\\"{x:634,y:445,t:1528139924013};\\\", \\\"{x:637,y:454,t:1528139924029};\\\", \\\"{x:640,y:464,t:1528139924046};\\\", \\\"{x:641,y:472,t:1528139924063};\\\", \\\"{x:641,y:478,t:1528139924079};\\\", \\\"{x:641,y:484,t:1528139924096};\\\", \\\"{x:641,y:491,t:1528139924115};\\\", \\\"{x:641,y:492,t:1528139924128};\\\", \\\"{x:641,y:493,t:1528139924146};\\\", \\\"{x:636,y:497,t:1528139924163};\\\", \\\"{x:630,y:502,t:1528139924179};\\\", \\\"{x:626,y:508,t:1528139924195};\\\", \\\"{x:624,y:513,t:1528139924213};\\\", \\\"{x:623,y:514,t:1528139924228};\\\", \\\"{x:622,y:515,t:1528139924425};\\\", \\\"{x:621,y:515,t:1528139924433};\\\", \\\"{x:616,y:515,t:1528139924897};\\\", \\\"{x:596,y:506,t:1528139924913};\\\", \\\"{x:585,y:499,t:1528139924930};\\\", \\\"{x:581,y:497,t:1528139924947};\\\", \\\"{x:576,y:494,t:1528139924962};\\\", \\\"{x:573,y:492,t:1528139924980};\\\", \\\"{x:574,y:492,t:1528139925025};\\\", \\\"{x:575,y:492,t:1528139925033};\\\", \\\"{x:577,y:492,t:1528139925047};\\\", \\\"{x:581,y:494,t:1528139925063};\\\", \\\"{x:583,y:495,t:1528139925080};\\\", \\\"{x:589,y:497,t:1528139925097};\\\", \\\"{x:594,y:500,t:1528139925113};\\\", \\\"{x:602,y:504,t:1528139925131};\\\", \\\"{x:608,y:509,t:1528139925147};\\\", \\\"{x:613,y:512,t:1528139925163};\\\", \\\"{x:612,y:512,t:1528139925393};\\\", \\\"{x:608,y:512,t:1528139925401};\\\", \\\"{x:608,y:511,t:1528139925433};\\\", \\\"{x:607,y:511,t:1528139925448};\\\", \\\"{x:606,y:511,t:1528139925464};\\\", \\\"{x:607,y:512,t:1528139925929};\\\", \\\"{x:607,y:528,t:1528139925938};\\\", \\\"{x:607,y:539,t:1528139925946};\\\", \\\"{x:611,y:563,t:1528139925965};\\\", \\\"{x:611,y:586,t:1528139925980};\\\", \\\"{x:611,y:606,t:1528139925997};\\\", \\\"{x:611,y:620,t:1528139926014};\\\", \\\"{x:610,y:631,t:1528139926030};\\\", \\\"{x:610,y:637,t:1528139926047};\\\", \\\"{x:609,y:638,t:1528139926063};\\\", \\\"{x:607,y:641,t:1528139926080};\\\", \\\"{x:606,y:644,t:1528139926096};\\\", \\\"{x:601,y:651,t:1528139926113};\\\", \\\"{x:594,y:662,t:1528139926130};\\\", \\\"{x:588,y:670,t:1528139926147};\\\", \\\"{x:585,y:673,t:1528139926164};\\\", \\\"{x:581,y:675,t:1528139926180};\\\", \\\"{x:577,y:676,t:1528139926196};\\\", \\\"{x:567,y:678,t:1528139926214};\\\", \\\"{x:557,y:685,t:1528139926231};\\\", \\\"{x:543,y:697,t:1528139926248};\\\", \\\"{x:531,y:709,t:1528139926264};\\\", \\\"{x:509,y:726,t:1528139926281};\\\", \\\"{x:500,y:732,t:1528139926298};\\\", \\\"{x:495,y:736,t:1528139926313};\\\", \\\"{x:493,y:738,t:1528139926331};\\\", \\\"{x:491,y:740,t:1528139926347};\\\", \\\"{x:489,y:741,t:1528139926364};\\\", \\\"{x:488,y:743,t:1528139926381};\\\", \\\"{x:487,y:744,t:1528139926400};\\\" ] }, { \\\"rt\\\": 10973, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 554728, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:743,t:1528139928665};\\\", \\\"{x:504,y:732,t:1528139928689};\\\", \\\"{x:508,y:730,t:1528139928698};\\\", \\\"{x:522,y:722,t:1528139928715};\\\", \\\"{x:537,y:711,t:1528139928732};\\\", \\\"{x:550,y:702,t:1528139928747};\\\", \\\"{x:562,y:694,t:1528139928766};\\\", \\\"{x:575,y:686,t:1528139928783};\\\", \\\"{x:596,y:682,t:1528139928799};\\\", \\\"{x:618,y:679,t:1528139928816};\\\", \\\"{x:666,y:675,t:1528139928832};\\\", \\\"{x:690,y:672,t:1528139928849};\\\", \\\"{x:719,y:668,t:1528139928865};\\\", \\\"{x:748,y:666,t:1528139928883};\\\", \\\"{x:788,y:662,t:1528139928900};\\\", \\\"{x:839,y:654,t:1528139928916};\\\", \\\"{x:891,y:640,t:1528139928933};\\\", \\\"{x:951,y:628,t:1528139928950};\\\", \\\"{x:1004,y:620,t:1528139928967};\\\", \\\"{x:1056,y:607,t:1528139928983};\\\", \\\"{x:1103,y:597,t:1528139929000};\\\", \\\"{x:1181,y:573,t:1528139929016};\\\", \\\"{x:1230,y:563,t:1528139929033};\\\", \\\"{x:1269,y:557,t:1528139929051};\\\", \\\"{x:1304,y:550,t:1528139929067};\\\", \\\"{x:1328,y:546,t:1528139929083};\\\", \\\"{x:1346,y:545,t:1528139929100};\\\", \\\"{x:1361,y:545,t:1528139929117};\\\", \\\"{x:1368,y:545,t:1528139929133};\\\", \\\"{x:1371,y:545,t:1528139929150};\\\", \\\"{x:1373,y:545,t:1528139929167};\\\", \\\"{x:1374,y:545,t:1528139929184};\\\", \\\"{x:1375,y:545,t:1528139929401};\\\", \\\"{x:1378,y:564,t:1528139929417};\\\", \\\"{x:1382,y:594,t:1528139929433};\\\", \\\"{x:1382,y:635,t:1528139929451};\\\", \\\"{x:1382,y:708,t:1528139929467};\\\", \\\"{x:1382,y:788,t:1528139929484};\\\", \\\"{x:1376,y:854,t:1528139929500};\\\", \\\"{x:1367,y:921,t:1528139929517};\\\", \\\"{x:1366,y:972,t:1528139929534};\\\", \\\"{x:1365,y:996,t:1528139929551};\\\", \\\"{x:1365,y:1009,t:1528139929567};\\\", \\\"{x:1365,y:1019,t:1528139929584};\\\", \\\"{x:1365,y:1022,t:1528139929600};\\\", \\\"{x:1365,y:1027,t:1528139929617};\\\", \\\"{x:1365,y:1033,t:1528139929634};\\\", \\\"{x:1365,y:1037,t:1528139929650};\\\", \\\"{x:1365,y:1039,t:1528139929667};\\\", \\\"{x:1365,y:1033,t:1528139929809};\\\", \\\"{x:1365,y:1027,t:1528139929818};\\\", \\\"{x:1365,y:1020,t:1528139929835};\\\", \\\"{x:1365,y:1016,t:1528139929851};\\\", \\\"{x:1365,y:1012,t:1528139929867};\\\", \\\"{x:1365,y:1011,t:1528139929937};\\\", \\\"{x:1365,y:1010,t:1528139929951};\\\", \\\"{x:1364,y:1005,t:1528139929967};\\\", \\\"{x:1363,y:1002,t:1528139929984};\\\", \\\"{x:1359,y:997,t:1528139930001};\\\", \\\"{x:1358,y:996,t:1528139930017};\\\", \\\"{x:1357,y:994,t:1528139930034};\\\", \\\"{x:1355,y:992,t:1528139930051};\\\", \\\"{x:1353,y:990,t:1528139930068};\\\", \\\"{x:1349,y:985,t:1528139930084};\\\", \\\"{x:1345,y:982,t:1528139930102};\\\", \\\"{x:1344,y:981,t:1528139930118};\\\", \\\"{x:1343,y:981,t:1528139930202};\\\", \\\"{x:1343,y:980,t:1528139930241};\\\", \\\"{x:1342,y:979,t:1528139931201};\\\", \\\"{x:1342,y:977,t:1528139931281};\\\", \\\"{x:1343,y:975,t:1528139931289};\\\", \\\"{x:1345,y:974,t:1528139931303};\\\", \\\"{x:1348,y:972,t:1528139931319};\\\", \\\"{x:1349,y:970,t:1528139931336};\\\", \\\"{x:1351,y:968,t:1528139931353};\\\", \\\"{x:1353,y:966,t:1528139931368};\\\", \\\"{x:1355,y:965,t:1528139931386};\\\", \\\"{x:1356,y:965,t:1528139931417};\\\", \\\"{x:1354,y:965,t:1528139931714};\\\", \\\"{x:1351,y:965,t:1528139931721};\\\", \\\"{x:1350,y:965,t:1528139931737};\\\", \\\"{x:1348,y:964,t:1528139931753};\\\", \\\"{x:1348,y:963,t:1528139931793};\\\", \\\"{x:1347,y:963,t:1528139931809};\\\", \\\"{x:1347,y:961,t:1528139931865};\\\", \\\"{x:1348,y:960,t:1528139931881};\\\", \\\"{x:1349,y:960,t:1528139931897};\\\", \\\"{x:1349,y:959,t:1528139931913};\\\", \\\"{x:1349,y:958,t:1528139931929};\\\", \\\"{x:1351,y:956,t:1528139931937};\\\", \\\"{x:1352,y:955,t:1528139931953};\\\", \\\"{x:1353,y:953,t:1528139931969};\\\", \\\"{x:1354,y:951,t:1528139931986};\\\", \\\"{x:1355,y:951,t:1528139932002};\\\", \\\"{x:1356,y:950,t:1528139932019};\\\", \\\"{x:1356,y:949,t:1528139932169};\\\", \\\"{x:1357,y:948,t:1528139932186};\\\", \\\"{x:1357,y:946,t:1528139932204};\\\", \\\"{x:1357,y:944,t:1528139932219};\\\", \\\"{x:1357,y:942,t:1528139932237};\\\", \\\"{x:1358,y:941,t:1528139932253};\\\", \\\"{x:1358,y:939,t:1528139932270};\\\", \\\"{x:1359,y:937,t:1528139932287};\\\", \\\"{x:1360,y:934,t:1528139932304};\\\", \\\"{x:1361,y:931,t:1528139932319};\\\", \\\"{x:1362,y:927,t:1528139932337};\\\", \\\"{x:1364,y:924,t:1528139932353};\\\", \\\"{x:1365,y:922,t:1528139932369};\\\", \\\"{x:1366,y:920,t:1528139932386};\\\", \\\"{x:1368,y:918,t:1528139932404};\\\", \\\"{x:1368,y:915,t:1528139932420};\\\", \\\"{x:1372,y:909,t:1528139932436};\\\", \\\"{x:1380,y:899,t:1528139932456};\\\", \\\"{x:1381,y:898,t:1528139932470};\\\", \\\"{x:1382,y:896,t:1528139932485};\\\", \\\"{x:1385,y:894,t:1528139932502};\\\", \\\"{x:1388,y:891,t:1528139932520};\\\", \\\"{x:1389,y:889,t:1528139932536};\\\", \\\"{x:1391,y:888,t:1528139932553};\\\", \\\"{x:1393,y:885,t:1528139932570};\\\", \\\"{x:1393,y:884,t:1528139932586};\\\", \\\"{x:1394,y:883,t:1528139932603};\\\", \\\"{x:1396,y:879,t:1528139932620};\\\", \\\"{x:1398,y:876,t:1528139932636};\\\", \\\"{x:1401,y:872,t:1528139932653};\\\", \\\"{x:1404,y:867,t:1528139932670};\\\", \\\"{x:1406,y:863,t:1528139932686};\\\", \\\"{x:1408,y:861,t:1528139932703};\\\", \\\"{x:1412,y:855,t:1528139932720};\\\", \\\"{x:1414,y:853,t:1528139932736};\\\", \\\"{x:1416,y:851,t:1528139932752};\\\", \\\"{x:1416,y:849,t:1528139932770};\\\", \\\"{x:1418,y:847,t:1528139932786};\\\", \\\"{x:1419,y:843,t:1528139932803};\\\", \\\"{x:1420,y:842,t:1528139932820};\\\", \\\"{x:1420,y:841,t:1528139932838};\\\", \\\"{x:1421,y:839,t:1528139932853};\\\", \\\"{x:1422,y:838,t:1528139932870};\\\", \\\"{x:1423,y:836,t:1528139932887};\\\", \\\"{x:1424,y:834,t:1528139932903};\\\", \\\"{x:1426,y:831,t:1528139932920};\\\", \\\"{x:1427,y:828,t:1528139932937};\\\", \\\"{x:1429,y:825,t:1528139932953};\\\", \\\"{x:1433,y:819,t:1528139932970};\\\", \\\"{x:1438,y:810,t:1528139932987};\\\", \\\"{x:1440,y:804,t:1528139933003};\\\", \\\"{x:1443,y:798,t:1528139933020};\\\", \\\"{x:1449,y:787,t:1528139933037};\\\", \\\"{x:1454,y:779,t:1528139933053};\\\", \\\"{x:1459,y:772,t:1528139933070};\\\", \\\"{x:1461,y:768,t:1528139933087};\\\", \\\"{x:1468,y:760,t:1528139933104};\\\", \\\"{x:1476,y:747,t:1528139933120};\\\", \\\"{x:1483,y:733,t:1528139933137};\\\", \\\"{x:1493,y:717,t:1528139933154};\\\", \\\"{x:1504,y:703,t:1528139933170};\\\", \\\"{x:1515,y:692,t:1528139933187};\\\", \\\"{x:1523,y:681,t:1528139933205};\\\", \\\"{x:1529,y:673,t:1528139933220};\\\", \\\"{x:1536,y:662,t:1528139933238};\\\", \\\"{x:1544,y:647,t:1528139933255};\\\", \\\"{x:1548,y:634,t:1528139933271};\\\", \\\"{x:1554,y:614,t:1528139933288};\\\", \\\"{x:1562,y:587,t:1528139933304};\\\", \\\"{x:1570,y:571,t:1528139933321};\\\", \\\"{x:1575,y:559,t:1528139933337};\\\", \\\"{x:1577,y:552,t:1528139933355};\\\", \\\"{x:1580,y:547,t:1528139933370};\\\", \\\"{x:1582,y:540,t:1528139933387};\\\", \\\"{x:1585,y:532,t:1528139933404};\\\", \\\"{x:1587,y:528,t:1528139933421};\\\", \\\"{x:1590,y:520,t:1528139933438};\\\", \\\"{x:1593,y:513,t:1528139933454};\\\", \\\"{x:1598,y:503,t:1528139933471};\\\", \\\"{x:1603,y:492,t:1528139933488};\\\", \\\"{x:1611,y:474,t:1528139933505};\\\", \\\"{x:1613,y:467,t:1528139933521};\\\", \\\"{x:1616,y:461,t:1528139933537};\\\", \\\"{x:1617,y:459,t:1528139933554};\\\", \\\"{x:1618,y:456,t:1528139933570};\\\", \\\"{x:1619,y:456,t:1528139933593};\\\", \\\"{x:1611,y:457,t:1528139934193};\\\", \\\"{x:1582,y:475,t:1528139934205};\\\", \\\"{x:1536,y:499,t:1528139934222};\\\", \\\"{x:1482,y:520,t:1528139934239};\\\", \\\"{x:1392,y:554,t:1528139934254};\\\", \\\"{x:1277,y:591,t:1528139934272};\\\", \\\"{x:1042,y:637,t:1528139934288};\\\", \\\"{x:823,y:642,t:1528139934305};\\\", \\\"{x:559,y:642,t:1528139934321};\\\", \\\"{x:346,y:642,t:1528139934340};\\\", \\\"{x:226,y:645,t:1528139934356};\\\", \\\"{x:215,y:646,t:1528139934387};\\\", \\\"{x:217,y:646,t:1528139934585};\\\", \\\"{x:237,y:640,t:1528139934592};\\\", \\\"{x:254,y:637,t:1528139934605};\\\", \\\"{x:268,y:631,t:1528139934621};\\\", \\\"{x:273,y:629,t:1528139934638};\\\", \\\"{x:278,y:626,t:1528139934654};\\\", \\\"{x:283,y:624,t:1528139934671};\\\", \\\"{x:288,y:622,t:1528139934688};\\\", \\\"{x:289,y:622,t:1528139934712};\\\", \\\"{x:290,y:621,t:1528139934721};\\\", \\\"{x:295,y:619,t:1528139934737};\\\", \\\"{x:301,y:617,t:1528139934753};\\\", \\\"{x:304,y:616,t:1528139934771};\\\", \\\"{x:306,y:614,t:1528139934788};\\\", \\\"{x:312,y:610,t:1528139934804};\\\", \\\"{x:315,y:606,t:1528139934821};\\\", \\\"{x:320,y:602,t:1528139934838};\\\", \\\"{x:323,y:599,t:1528139934855};\\\", \\\"{x:324,y:596,t:1528139934871};\\\", \\\"{x:325,y:595,t:1528139934888};\\\", \\\"{x:327,y:593,t:1528139934905};\\\", \\\"{x:327,y:592,t:1528139934992};\\\", \\\"{x:330,y:589,t:1528139935008};\\\", \\\"{x:331,y:589,t:1528139935021};\\\", \\\"{x:334,y:587,t:1528139935038};\\\", \\\"{x:338,y:585,t:1528139935055};\\\", \\\"{x:343,y:582,t:1528139935071};\\\", \\\"{x:350,y:578,t:1528139935088};\\\", \\\"{x:354,y:574,t:1528139935104};\\\", \\\"{x:358,y:572,t:1528139935121};\\\", \\\"{x:361,y:569,t:1528139935138};\\\", \\\"{x:366,y:565,t:1528139935154};\\\", \\\"{x:372,y:561,t:1528139935171};\\\", \\\"{x:376,y:557,t:1528139935188};\\\", \\\"{x:381,y:554,t:1528139935206};\\\", \\\"{x:383,y:553,t:1528139935220};\\\", \\\"{x:383,y:552,t:1528139935238};\\\", \\\"{x:384,y:551,t:1528139935256};\\\", \\\"{x:384,y:549,t:1528139935270};\\\", \\\"{x:386,y:547,t:1528139935288};\\\", \\\"{x:386,y:546,t:1528139935305};\\\", \\\"{x:386,y:545,t:1528139935352};\\\", \\\"{x:386,y:544,t:1528139936097};\\\", \\\"{x:383,y:544,t:1528139936105};\\\", \\\"{x:352,y:554,t:1528139936123};\\\", \\\"{x:318,y:563,t:1528139936139};\\\", \\\"{x:290,y:571,t:1528139936155};\\\", \\\"{x:267,y:577,t:1528139936172};\\\", \\\"{x:247,y:579,t:1528139936188};\\\", \\\"{x:230,y:580,t:1528139936205};\\\", \\\"{x:222,y:580,t:1528139936222};\\\", \\\"{x:215,y:580,t:1528139936239};\\\", \\\"{x:214,y:580,t:1528139936254};\\\", \\\"{x:215,y:580,t:1528139936497};\\\", \\\"{x:271,y:541,t:1528139936538};\\\", \\\"{x:283,y:533,t:1528139936556};\\\", \\\"{x:294,y:528,t:1528139936572};\\\", \\\"{x:308,y:523,t:1528139936589};\\\", \\\"{x:317,y:521,t:1528139936606};\\\", \\\"{x:326,y:520,t:1528139936622};\\\", \\\"{x:332,y:520,t:1528139936639};\\\", \\\"{x:342,y:519,t:1528139936656};\\\", \\\"{x:347,y:519,t:1528139936672};\\\", \\\"{x:349,y:519,t:1528139936689};\\\", \\\"{x:350,y:519,t:1528139936728};\\\", \\\"{x:350,y:517,t:1528139936802};\\\", \\\"{x:349,y:517,t:1528139936823};\\\", \\\"{x:345,y:515,t:1528139936839};\\\", \\\"{x:323,y:514,t:1528139936856};\\\", \\\"{x:292,y:522,t:1528139936874};\\\", \\\"{x:283,y:523,t:1528139936889};\\\", \\\"{x:278,y:527,t:1528139936906};\\\", \\\"{x:276,y:527,t:1528139936923};\\\", \\\"{x:276,y:528,t:1528139936939};\\\", \\\"{x:276,y:529,t:1528139936960};\\\", \\\"{x:276,y:530,t:1528139936973};\\\", \\\"{x:280,y:533,t:1528139936989};\\\", \\\"{x:288,y:539,t:1528139937007};\\\", \\\"{x:300,y:546,t:1528139937024};\\\", \\\"{x:320,y:557,t:1528139937040};\\\", \\\"{x:360,y:572,t:1528139937057};\\\", \\\"{x:381,y:578,t:1528139937073};\\\", \\\"{x:392,y:581,t:1528139937089};\\\", \\\"{x:387,y:582,t:1528139937171};\\\", \\\"{x:385,y:583,t:1528139937175};\\\", \\\"{x:385,y:584,t:1528139937215};\\\", \\\"{x:385,y:587,t:1528139937224};\\\", \\\"{x:385,y:594,t:1528139937240};\\\", \\\"{x:392,y:605,t:1528139937256};\\\", \\\"{x:397,y:610,t:1528139937273};\\\", \\\"{x:401,y:613,t:1528139937290};\\\", \\\"{x:403,y:614,t:1528139937306};\\\", \\\"{x:404,y:615,t:1528139937323};\\\", \\\"{x:404,y:616,t:1528139937408};\\\", \\\"{x:404,y:617,t:1528139937423};\\\", \\\"{x:404,y:620,t:1528139937441};\\\", \\\"{x:404,y:621,t:1528139937457};\\\", \\\"{x:404,y:622,t:1528139937480};\\\", \\\"{x:404,y:623,t:1528139937625};\\\", \\\"{x:401,y:623,t:1528139937641};\\\", \\\"{x:400,y:622,t:1528139937657};\\\", \\\"{x:399,y:622,t:1528139937674};\\\", \\\"{x:397,y:622,t:1528139937690};\\\", \\\"{x:396,y:621,t:1528139937769};\\\", \\\"{x:397,y:622,t:1528139938080};\\\", \\\"{x:402,y:633,t:1528139938091};\\\", \\\"{x:409,y:656,t:1528139938108};\\\", \\\"{x:421,y:680,t:1528139938125};\\\", \\\"{x:448,y:714,t:1528139938140};\\\", \\\"{x:474,y:744,t:1528139938158};\\\", \\\"{x:509,y:772,t:1528139938175};\\\", \\\"{x:527,y:784,t:1528139938190};\\\", \\\"{x:531,y:786,t:1528139938207};\\\", \\\"{x:530,y:785,t:1528139938281};\\\", \\\"{x:529,y:781,t:1528139938290};\\\", \\\"{x:527,y:777,t:1528139938308};\\\", \\\"{x:526,y:776,t:1528139938352};\\\", \\\"{x:525,y:774,t:1528139938360};\\\", \\\"{x:524,y:773,t:1528139938374};\\\", \\\"{x:523,y:769,t:1528139938390};\\\", \\\"{x:522,y:768,t:1528139938409};\\\", \\\"{x:521,y:764,t:1528139938513};\\\", \\\"{x:521,y:760,t:1528139938525};\\\", \\\"{x:520,y:755,t:1528139938541};\\\", \\\"{x:519,y:749,t:1528139938558};\\\", \\\"{x:518,y:746,t:1528139938575};\\\", \\\"{x:518,y:744,t:1528139938591};\\\", \\\"{x:516,y:742,t:1528139938607};\\\", \\\"{x:514,y:741,t:1528139939481};\\\", \\\"{x:506,y:741,t:1528139939492};\\\", \\\"{x:469,y:733,t:1528139939509};\\\", \\\"{x:419,y:721,t:1528139939525};\\\", \\\"{x:363,y:711,t:1528139939542};\\\", \\\"{x:305,y:698,t:1528139939558};\\\", \\\"{x:258,y:690,t:1528139939576};\\\", \\\"{x:210,y:683,t:1528139939591};\\\", \\\"{x:153,y:672,t:1528139939608};\\\", \\\"{x:130,y:668,t:1528139939626};\\\", \\\"{x:115,y:663,t:1528139939643};\\\", \\\"{x:107,y:662,t:1528139939659};\\\", \\\"{x:105,y:661,t:1528139939676};\\\", \\\"{x:104,y:660,t:1528139939692};\\\", \\\"{x:103,y:660,t:1528139939737};\\\", \\\"{x:102,y:660,t:1528139939745};\\\", \\\"{x:100,y:660,t:1528139939758};\\\", \\\"{x:95,y:660,t:1528139939775};\\\", \\\"{x:84,y:659,t:1528139939792};\\\", \\\"{x:76,y:658,t:1528139939808};\\\", \\\"{x:71,y:656,t:1528139939826};\\\", \\\"{x:64,y:656,t:1528139939842};\\\", \\\"{x:56,y:655,t:1528139939859};\\\", \\\"{x:45,y:654,t:1528139939875};\\\", \\\"{x:32,y:651,t:1528139939893};\\\", \\\"{x:0,y:645,t:1528139939948};\\\", \\\"{x:0,y:644,t:1528139939959};\\\", \\\"{x:0,y:640,t:1528139939974};\\\", \\\"{x:0,y:633,t:1528139939991};\\\", \\\"{x:0,y:629,t:1528139940009};\\\", \\\"{x:0,y:624,t:1528139940024};\\\" ] }, { \\\"rt\\\": 9028, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 565016, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-10 AM-B -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:0,y:584,t:1528139940150};\\\", \\\"{x:0,y:582,t:1528139940159};\\\", \\\"{x:0,y:577,t:1528139940175};\\\", \\\"{x:0,y:572,t:1528139940192};\\\", \\\"{x:0,y:570,t:1528139940207};\\\", \\\"{x:0,y:569,t:1528139940488};\\\", \\\"{x:7,y:569,t:1528139941793};\\\", \\\"{x:33,y:569,t:1528139941811};\\\", \\\"{x:85,y:573,t:1528139941828};\\\", \\\"{x:168,y:584,t:1528139941843};\\\", \\\"{x:276,y:600,t:1528139941860};\\\", \\\"{x:393,y:616,t:1528139941878};\\\", \\\"{x:515,y:635,t:1528139941894};\\\", \\\"{x:658,y:668,t:1528139941910};\\\", \\\"{x:803,y:700,t:1528139941928};\\\", \\\"{x:949,y:733,t:1528139941943};\\\", \\\"{x:1166,y:765,t:1528139941960};\\\", \\\"{x:1305,y:786,t:1528139941977};\\\", \\\"{x:1422,y:805,t:1528139941994};\\\", \\\"{x:1521,y:817,t:1528139942010};\\\", \\\"{x:1602,y:828,t:1528139942028};\\\", \\\"{x:1649,y:835,t:1528139942044};\\\", \\\"{x:1685,y:841,t:1528139942060};\\\", \\\"{x:1695,y:845,t:1528139942077};\\\", \\\"{x:1698,y:845,t:1528139942095};\\\", \\\"{x:1697,y:845,t:1528139942217};\\\", \\\"{x:1694,y:845,t:1528139942228};\\\", \\\"{x:1687,y:845,t:1528139942244};\\\", \\\"{x:1680,y:845,t:1528139942261};\\\", \\\"{x:1670,y:845,t:1528139942278};\\\", \\\"{x:1656,y:845,t:1528139942294};\\\", \\\"{x:1640,y:845,t:1528139942311};\\\", \\\"{x:1598,y:847,t:1528139942328};\\\", \\\"{x:1571,y:847,t:1528139942345};\\\", \\\"{x:1542,y:847,t:1528139942361};\\\", \\\"{x:1517,y:847,t:1528139942379};\\\", \\\"{x:1500,y:847,t:1528139942395};\\\", \\\"{x:1490,y:847,t:1528139942412};\\\", \\\"{x:1483,y:847,t:1528139942429};\\\", \\\"{x:1478,y:847,t:1528139942445};\\\", \\\"{x:1475,y:847,t:1528139942461};\\\", \\\"{x:1469,y:847,t:1528139942478};\\\", \\\"{x:1460,y:847,t:1528139942496};\\\", \\\"{x:1453,y:846,t:1528139942512};\\\", \\\"{x:1442,y:846,t:1528139942529};\\\", \\\"{x:1427,y:845,t:1528139942546};\\\", \\\"{x:1408,y:842,t:1528139942564};\\\", \\\"{x:1386,y:839,t:1528139942579};\\\", \\\"{x:1371,y:837,t:1528139942595};\\\", \\\"{x:1365,y:835,t:1528139942613};\\\", \\\"{x:1362,y:835,t:1528139942628};\\\", \\\"{x:1361,y:835,t:1528139942646};\\\", \\\"{x:1359,y:834,t:1528139942663};\\\", \\\"{x:1358,y:834,t:1528139942680};\\\", \\\"{x:1357,y:833,t:1528139942696};\\\", \\\"{x:1351,y:830,t:1528139942713};\\\", \\\"{x:1338,y:825,t:1528139942730};\\\", \\\"{x:1313,y:813,t:1528139942746};\\\", \\\"{x:1282,y:802,t:1528139942762};\\\", \\\"{x:1258,y:792,t:1528139942779};\\\", \\\"{x:1242,y:787,t:1528139942796};\\\", \\\"{x:1230,y:782,t:1528139942813};\\\", \\\"{x:1222,y:778,t:1528139942829};\\\", \\\"{x:1220,y:777,t:1528139942846};\\\", \\\"{x:1219,y:777,t:1528139942863};\\\", \\\"{x:1220,y:776,t:1528139942984};\\\", \\\"{x:1228,y:773,t:1528139942996};\\\", \\\"{x:1248,y:765,t:1528139943014};\\\", \\\"{x:1270,y:761,t:1528139943029};\\\", \\\"{x:1290,y:753,t:1528139943046};\\\", \\\"{x:1308,y:745,t:1528139943064};\\\", \\\"{x:1321,y:738,t:1528139943079};\\\", \\\"{x:1328,y:731,t:1528139943096};\\\", \\\"{x:1332,y:728,t:1528139943114};\\\", \\\"{x:1333,y:728,t:1528139943130};\\\", \\\"{x:1333,y:727,t:1528139943257};\\\", \\\"{x:1334,y:726,t:1528139943265};\\\", \\\"{x:1338,y:719,t:1528139943281};\\\", \\\"{x:1344,y:705,t:1528139943298};\\\", \\\"{x:1353,y:686,t:1528139943313};\\\", \\\"{x:1362,y:665,t:1528139943331};\\\", \\\"{x:1374,y:647,t:1528139943347};\\\", \\\"{x:1383,y:636,t:1528139943364};\\\", \\\"{x:1388,y:629,t:1528139943381};\\\", \\\"{x:1391,y:627,t:1528139943398};\\\", \\\"{x:1391,y:626,t:1528139943415};\\\", \\\"{x:1391,y:623,t:1528139943431};\\\", \\\"{x:1393,y:621,t:1528139943448};\\\", \\\"{x:1394,y:619,t:1528139943465};\\\", \\\"{x:1397,y:613,t:1528139943481};\\\", \\\"{x:1399,y:608,t:1528139943497};\\\", \\\"{x:1402,y:605,t:1528139943515};\\\", \\\"{x:1404,y:603,t:1528139943531};\\\", \\\"{x:1404,y:601,t:1528139943548};\\\", \\\"{x:1406,y:597,t:1528139943565};\\\", \\\"{x:1406,y:596,t:1528139943582};\\\", \\\"{x:1409,y:592,t:1528139943597};\\\", \\\"{x:1409,y:590,t:1528139943614};\\\", \\\"{x:1411,y:586,t:1528139943632};\\\", \\\"{x:1412,y:583,t:1528139943648};\\\", \\\"{x:1414,y:580,t:1528139943665};\\\", \\\"{x:1415,y:579,t:1528139943682};\\\", \\\"{x:1415,y:576,t:1528139943699};\\\", \\\"{x:1416,y:574,t:1528139943715};\\\", \\\"{x:1418,y:572,t:1528139943732};\\\", \\\"{x:1419,y:570,t:1528139943750};\\\", \\\"{x:1419,y:568,t:1528139943765};\\\", \\\"{x:1421,y:567,t:1528139943782};\\\", \\\"{x:1421,y:566,t:1528139943809};\\\", \\\"{x:1421,y:565,t:1528139943817};\\\", \\\"{x:1421,y:564,t:1528139943832};\\\", \\\"{x:1422,y:562,t:1528139943849};\\\", \\\"{x:1422,y:561,t:1528139943866};\\\", \\\"{x:1424,y:558,t:1528139943882};\\\", \\\"{x:1425,y:557,t:1528139943905};\\\", \\\"{x:1425,y:556,t:1528139943969};\\\", \\\"{x:1425,y:555,t:1528139943985};\\\", \\\"{x:1426,y:555,t:1528139944001};\\\", \\\"{x:1426,y:554,t:1528139944016};\\\", \\\"{x:1427,y:553,t:1528139944040};\\\", \\\"{x:1427,y:555,t:1528139944601};\\\", \\\"{x:1420,y:566,t:1528139944618};\\\", \\\"{x:1412,y:578,t:1528139944634};\\\", \\\"{x:1405,y:590,t:1528139944651};\\\", \\\"{x:1397,y:601,t:1528139944668};\\\", \\\"{x:1390,y:612,t:1528139944684};\\\", \\\"{x:1386,y:620,t:1528139944701};\\\", \\\"{x:1383,y:628,t:1528139944719};\\\", \\\"{x:1381,y:633,t:1528139944734};\\\", \\\"{x:1379,y:638,t:1528139944751};\\\", \\\"{x:1377,y:644,t:1528139944768};\\\", \\\"{x:1372,y:658,t:1528139944784};\\\", \\\"{x:1366,y:671,t:1528139944801};\\\", \\\"{x:1359,y:684,t:1528139944818};\\\", \\\"{x:1354,y:696,t:1528139944835};\\\", \\\"{x:1354,y:702,t:1528139944851};\\\", \\\"{x:1353,y:706,t:1528139944868};\\\", \\\"{x:1353,y:708,t:1528139944885};\\\", \\\"{x:1353,y:709,t:1528139944902};\\\", \\\"{x:1352,y:710,t:1528139944917};\\\", \\\"{x:1351,y:711,t:1528139944935};\\\", \\\"{x:1350,y:715,t:1528139944952};\\\", \\\"{x:1348,y:720,t:1528139944968};\\\", \\\"{x:1346,y:726,t:1528139944984};\\\", \\\"{x:1342,y:733,t:1528139945002};\\\", \\\"{x:1339,y:742,t:1528139945018};\\\", \\\"{x:1334,y:752,t:1528139945035};\\\", \\\"{x:1328,y:763,t:1528139945052};\\\", \\\"{x:1320,y:776,t:1528139945069};\\\", \\\"{x:1311,y:794,t:1528139945084};\\\", \\\"{x:1300,y:815,t:1528139945102};\\\", \\\"{x:1286,y:839,t:1528139945119};\\\", \\\"{x:1275,y:861,t:1528139945135};\\\", \\\"{x:1266,y:875,t:1528139945152};\\\", \\\"{x:1253,y:897,t:1528139945168};\\\", \\\"{x:1246,y:905,t:1528139945186};\\\", \\\"{x:1241,y:914,t:1528139945202};\\\", \\\"{x:1233,y:928,t:1528139945219};\\\", \\\"{x:1227,y:940,t:1528139945236};\\\", \\\"{x:1219,y:956,t:1528139945252};\\\", \\\"{x:1212,y:971,t:1528139945269};\\\", \\\"{x:1204,y:987,t:1528139945287};\\\", \\\"{x:1196,y:998,t:1528139945302};\\\", \\\"{x:1191,y:1009,t:1528139945318};\\\", \\\"{x:1186,y:1018,t:1528139945336};\\\", \\\"{x:1182,y:1031,t:1528139945353};\\\", \\\"{x:1180,y:1034,t:1528139945369};\\\", \\\"{x:1180,y:1035,t:1528139945386};\\\", \\\"{x:1180,y:1033,t:1528139945601};\\\", \\\"{x:1180,y:1029,t:1528139945609};\\\", \\\"{x:1183,y:1026,t:1528139945620};\\\", \\\"{x:1184,y:1018,t:1528139945637};\\\", \\\"{x:1188,y:1012,t:1528139945653};\\\", \\\"{x:1188,y:1010,t:1528139945669};\\\", \\\"{x:1190,y:1008,t:1528139945687};\\\", \\\"{x:1190,y:1006,t:1528139945703};\\\", \\\"{x:1191,y:1004,t:1528139945720};\\\", \\\"{x:1193,y:1000,t:1528139945736};\\\", \\\"{x:1194,y:996,t:1528139945754};\\\", \\\"{x:1196,y:992,t:1528139945770};\\\", \\\"{x:1200,y:987,t:1528139945787};\\\", \\\"{x:1204,y:981,t:1528139945804};\\\", \\\"{x:1209,y:975,t:1528139945820};\\\", \\\"{x:1216,y:963,t:1528139945837};\\\", \\\"{x:1225,y:950,t:1528139945854};\\\", \\\"{x:1236,y:936,t:1528139945871};\\\", \\\"{x:1248,y:921,t:1528139945887};\\\", \\\"{x:1258,y:908,t:1528139945904};\\\", \\\"{x:1274,y:885,t:1528139945920};\\\", \\\"{x:1285,y:870,t:1528139945937};\\\", \\\"{x:1294,y:858,t:1528139945954};\\\", \\\"{x:1304,y:843,t:1528139945971};\\\", \\\"{x:1309,y:835,t:1528139945987};\\\", \\\"{x:1313,y:828,t:1528139946004};\\\", \\\"{x:1317,y:815,t:1528139946021};\\\", \\\"{x:1321,y:799,t:1528139946038};\\\", \\\"{x:1328,y:785,t:1528139946054};\\\", \\\"{x:1335,y:770,t:1528139946071};\\\", \\\"{x:1340,y:759,t:1528139946088};\\\", \\\"{x:1343,y:750,t:1528139946105};\\\", \\\"{x:1350,y:735,t:1528139946121};\\\", \\\"{x:1355,y:721,t:1528139946138};\\\", \\\"{x:1361,y:707,t:1528139946156};\\\", \\\"{x:1367,y:688,t:1528139946171};\\\", \\\"{x:1371,y:674,t:1528139946188};\\\", \\\"{x:1375,y:661,t:1528139946205};\\\", \\\"{x:1380,y:644,t:1528139946221};\\\", \\\"{x:1386,y:627,t:1528139946239};\\\", \\\"{x:1391,y:610,t:1528139946255};\\\", \\\"{x:1396,y:595,t:1528139946272};\\\", \\\"{x:1402,y:582,t:1528139946288};\\\", \\\"{x:1408,y:567,t:1528139946305};\\\", \\\"{x:1413,y:557,t:1528139946322};\\\", \\\"{x:1414,y:554,t:1528139946338};\\\", \\\"{x:1415,y:551,t:1528139946355};\\\", \\\"{x:1415,y:550,t:1528139946371};\\\", \\\"{x:1411,y:549,t:1528139946496};\\\", \\\"{x:1402,y:549,t:1528139946505};\\\", \\\"{x:1382,y:556,t:1528139946522};\\\", \\\"{x:1360,y:556,t:1528139946539};\\\", \\\"{x:1333,y:560,t:1528139946556};\\\", \\\"{x:1298,y:568,t:1528139946572};\\\", \\\"{x:1242,y:585,t:1528139946589};\\\", \\\"{x:1173,y:593,t:1528139946606};\\\", \\\"{x:1092,y:602,t:1528139946622};\\\", \\\"{x:1009,y:614,t:1528139946639};\\\", \\\"{x:975,y:615,t:1528139946656};\\\", \\\"{x:948,y:615,t:1528139946674};\\\", \\\"{x:945,y:615,t:1528139946688};\\\", \\\"{x:943,y:615,t:1528139946706};\\\", \\\"{x:941,y:615,t:1528139946727};\\\", \\\"{x:939,y:615,t:1528139946736};\\\", \\\"{x:937,y:617,t:1528139946747};\\\", \\\"{x:934,y:618,t:1528139946764};\\\", \\\"{x:931,y:620,t:1528139946781};\\\", \\\"{x:926,y:621,t:1528139946798};\\\", \\\"{x:913,y:623,t:1528139946814};\\\", \\\"{x:898,y:623,t:1528139946830};\\\", \\\"{x:887,y:623,t:1528139946847};\\\", \\\"{x:883,y:618,t:1528139946864};\\\", \\\"{x:883,y:604,t:1528139946880};\\\", \\\"{x:883,y:595,t:1528139946898};\\\", \\\"{x:883,y:589,t:1528139946915};\\\", \\\"{x:883,y:582,t:1528139946930};\\\", \\\"{x:883,y:578,t:1528139946946};\\\", \\\"{x:882,y:575,t:1528139946964};\\\", \\\"{x:880,y:572,t:1528139946981};\\\", \\\"{x:880,y:571,t:1528139946996};\\\", \\\"{x:879,y:569,t:1528139947013};\\\", \\\"{x:877,y:565,t:1528139947031};\\\", \\\"{x:873,y:558,t:1528139947047};\\\", \\\"{x:868,y:551,t:1528139947064};\\\", \\\"{x:860,y:544,t:1528139947081};\\\", \\\"{x:854,y:537,t:1528139947097};\\\", \\\"{x:849,y:528,t:1528139947115};\\\", \\\"{x:849,y:519,t:1528139947132};\\\", \\\"{x:847,y:510,t:1528139947148};\\\", \\\"{x:845,y:503,t:1528139947165};\\\", \\\"{x:844,y:499,t:1528139947182};\\\", \\\"{x:843,y:498,t:1528139947198};\\\", \\\"{x:842,y:498,t:1528139947265};\\\", \\\"{x:842,y:499,t:1528139947600};\\\", \\\"{x:841,y:502,t:1528139947614};\\\", \\\"{x:839,y:508,t:1528139947631};\\\", \\\"{x:838,y:511,t:1528139947648};\\\", \\\"{x:837,y:513,t:1528139947665};\\\", \\\"{x:837,y:514,t:1528139947682};\\\", \\\"{x:837,y:516,t:1528139947785};\\\", \\\"{x:838,y:516,t:1528139947799};\\\", \\\"{x:839,y:518,t:1528139947816};\\\", \\\"{x:841,y:523,t:1528139947832};\\\", \\\"{x:843,y:527,t:1528139947850};\\\", \\\"{x:846,y:530,t:1528139947866};\\\", \\\"{x:846,y:532,t:1528139948553};\\\", \\\"{x:830,y:548,t:1528139948566};\\\", \\\"{x:778,y:602,t:1528139948585};\\\", \\\"{x:724,y:656,t:1528139948600};\\\", \\\"{x:686,y:699,t:1528139948616};\\\", \\\"{x:676,y:710,t:1528139948631};\\\", \\\"{x:666,y:720,t:1528139948649};\\\", \\\"{x:658,y:724,t:1528139948665};\\\", \\\"{x:654,y:727,t:1528139948682};\\\", \\\"{x:651,y:728,t:1528139948699};\\\", \\\"{x:649,y:728,t:1528139948715};\\\", \\\"{x:646,y:730,t:1528139948732};\\\", \\\"{x:641,y:731,t:1528139948749};\\\", \\\"{x:634,y:735,t:1528139948765};\\\", \\\"{x:627,y:737,t:1528139948782};\\\", \\\"{x:615,y:740,t:1528139948799};\\\", \\\"{x:600,y:740,t:1528139948816};\\\", \\\"{x:568,y:740,t:1528139948832};\\\", \\\"{x:543,y:740,t:1528139948849};\\\", \\\"{x:520,y:740,t:1528139948866};\\\", \\\"{x:505,y:740,t:1528139948881};\\\", \\\"{x:495,y:740,t:1528139948898};\\\", \\\"{x:491,y:741,t:1528139948915};\\\", \\\"{x:490,y:741,t:1528139948932};\\\" ] }, { \\\"rt\\\": 21594, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 587842, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -N -N -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:732,t:1528139952810};\\\", \\\"{x:483,y:714,t:1528139952818};\\\", \\\"{x:466,y:677,t:1528139952831};\\\", \\\"{x:461,y:664,t:1528139952849};\\\", \\\"{x:455,y:651,t:1528139952869};\\\", \\\"{x:444,y:633,t:1528139952886};\\\", \\\"{x:433,y:617,t:1528139952903};\\\", \\\"{x:429,y:611,t:1528139952920};\\\", \\\"{x:425,y:605,t:1528139952936};\\\", \\\"{x:420,y:597,t:1528139952953};\\\", \\\"{x:419,y:591,t:1528139952970};\\\", \\\"{x:417,y:587,t:1528139952986};\\\", \\\"{x:417,y:583,t:1528139953003};\\\", \\\"{x:416,y:577,t:1528139953020};\\\", \\\"{x:415,y:570,t:1528139953036};\\\", \\\"{x:413,y:563,t:1528139953053};\\\", \\\"{x:413,y:558,t:1528139953070};\\\", \\\"{x:413,y:552,t:1528139953086};\\\", \\\"{x:416,y:542,t:1528139953103};\\\", \\\"{x:423,y:530,t:1528139953120};\\\", \\\"{x:429,y:523,t:1528139953136};\\\", \\\"{x:439,y:513,t:1528139953153};\\\", \\\"{x:452,y:503,t:1528139953170};\\\", \\\"{x:467,y:494,t:1528139953186};\\\", \\\"{x:484,y:483,t:1528139953203};\\\", \\\"{x:499,y:473,t:1528139953220};\\\", \\\"{x:517,y:465,t:1528139953237};\\\", \\\"{x:540,y:456,t:1528139953253};\\\", \\\"{x:562,y:450,t:1528139953270};\\\", \\\"{x:582,y:443,t:1528139953287};\\\", \\\"{x:598,y:439,t:1528139953303};\\\", \\\"{x:618,y:434,t:1528139953319};\\\", \\\"{x:623,y:433,t:1528139953337};\\\", \\\"{x:627,y:433,t:1528139953354};\\\", \\\"{x:633,y:431,t:1528139953370};\\\", \\\"{x:634,y:431,t:1528139953387};\\\", \\\"{x:635,y:431,t:1528139953404};\\\", \\\"{x:636,y:431,t:1528139953477};\\\", \\\"{x:645,y:431,t:1528139953961};\\\", \\\"{x:667,y:433,t:1528139953972};\\\", \\\"{x:739,y:444,t:1528139953989};\\\", \\\"{x:831,y:457,t:1528139954005};\\\", \\\"{x:904,y:472,t:1528139954022};\\\", \\\"{x:974,y:493,t:1528139954039};\\\", \\\"{x:1055,y:516,t:1528139954056};\\\", \\\"{x:1185,y:552,t:1528139954072};\\\", \\\"{x:1259,y:581,t:1528139954090};\\\", \\\"{x:1333,y:615,t:1528139954106};\\\", \\\"{x:1405,y:646,t:1528139954123};\\\", \\\"{x:1485,y:681,t:1528139954140};\\\", \\\"{x:1557,y:710,t:1528139954156};\\\", \\\"{x:1626,y:741,t:1528139954173};\\\", \\\"{x:1694,y:782,t:1528139954189};\\\", \\\"{x:1760,y:822,t:1528139954206};\\\", \\\"{x:1813,y:858,t:1528139954222};\\\", \\\"{x:1864,y:895,t:1528139954240};\\\", \\\"{x:1919,y:947,t:1528139954256};\\\", \\\"{x:1919,y:984,t:1528139954273};\\\", \\\"{x:1919,y:1004,t:1528139954287};\\\", \\\"{x:1919,y:1080,t:1528139954304};\\\", \\\"{x:1919,y:1112,t:1528139954321};\\\", \\\"{x:1919,y:1132,t:1528139954337};\\\", \\\"{x:1919,y:1145,t:1528139954354};\\\", \\\"{x:1919,y:1147,t:1528139954371};\\\", \\\"{x:1919,y:1148,t:1528139954387};\\\", \\\"{x:1919,y:1150,t:1528139954404};\\\", \\\"{x:1916,y:1153,t:1528139954421};\\\", \\\"{x:1909,y:1157,t:1528139954438};\\\", \\\"{x:1900,y:1159,t:1528139954454};\\\", \\\"{x:1887,y:1161,t:1528139954470};\\\", \\\"{x:1872,y:1161,t:1528139954487};\\\", \\\"{x:1845,y:1161,t:1528139954504};\\\", \\\"{x:1829,y:1156,t:1528139954521};\\\", \\\"{x:1809,y:1150,t:1528139954536};\\\", \\\"{x:1786,y:1142,t:1528139954554};\\\", \\\"{x:1755,y:1132,t:1528139954570};\\\", \\\"{x:1724,y:1123,t:1528139954587};\\\", \\\"{x:1700,y:1116,t:1528139954603};\\\", \\\"{x:1678,y:1109,t:1528139954621};\\\", \\\"{x:1654,y:1102,t:1528139954638};\\\", \\\"{x:1636,y:1098,t:1528139954654};\\\", \\\"{x:1626,y:1093,t:1528139954671};\\\", \\\"{x:1619,y:1091,t:1528139954688};\\\", \\\"{x:1613,y:1088,t:1528139954704};\\\", \\\"{x:1611,y:1088,t:1528139954721};\\\", \\\"{x:1611,y:1087,t:1528139954738};\\\", \\\"{x:1610,y:1087,t:1528139954754};\\\", \\\"{x:1610,y:1086,t:1528139954776};\\\", \\\"{x:1610,y:1083,t:1528139954788};\\\", \\\"{x:1610,y:1075,t:1528139954804};\\\", \\\"{x:1609,y:1062,t:1528139954822};\\\", \\\"{x:1604,y:1045,t:1528139954839};\\\", \\\"{x:1595,y:1027,t:1528139954854};\\\", \\\"{x:1589,y:1012,t:1528139954872};\\\", \\\"{x:1582,y:995,t:1528139954888};\\\", \\\"{x:1578,y:987,t:1528139954904};\\\", \\\"{x:1577,y:981,t:1528139954921};\\\", \\\"{x:1576,y:977,t:1528139954938};\\\", \\\"{x:1575,y:975,t:1528139954954};\\\", \\\"{x:1575,y:972,t:1528139954971};\\\", \\\"{x:1575,y:969,t:1528139954988};\\\", \\\"{x:1575,y:967,t:1528139955004};\\\", \\\"{x:1575,y:966,t:1528139955021};\\\", \\\"{x:1575,y:964,t:1528139955038};\\\", \\\"{x:1575,y:963,t:1528139955054};\\\", \\\"{x:1576,y:962,t:1528139955071};\\\", \\\"{x:1582,y:959,t:1528139955089};\\\", \\\"{x:1585,y:956,t:1528139955104};\\\", \\\"{x:1588,y:952,t:1528139955122};\\\", \\\"{x:1590,y:951,t:1528139955138};\\\", \\\"{x:1594,y:948,t:1528139955155};\\\", \\\"{x:1597,y:945,t:1528139955171};\\\", \\\"{x:1601,y:938,t:1528139955188};\\\", \\\"{x:1607,y:923,t:1528139955206};\\\", \\\"{x:1613,y:911,t:1528139955221};\\\", \\\"{x:1618,y:896,t:1528139955243};\\\", \\\"{x:1625,y:884,t:1528139955260};\\\", \\\"{x:1635,y:869,t:1528139955275};\\\", \\\"{x:1649,y:849,t:1528139955293};\\\", \\\"{x:1654,y:841,t:1528139955309};\\\", \\\"{x:1661,y:833,t:1528139955325};\\\", \\\"{x:1667,y:826,t:1528139955342};\\\", \\\"{x:1673,y:819,t:1528139955359};\\\", \\\"{x:1676,y:816,t:1528139955376};\\\", \\\"{x:1677,y:813,t:1528139955392};\\\", \\\"{x:1678,y:812,t:1528139955409};\\\", \\\"{x:1678,y:811,t:1528139955444};\\\", \\\"{x:1678,y:810,t:1528139955460};\\\", \\\"{x:1678,y:806,t:1528139955475};\\\", \\\"{x:1678,y:796,t:1528139955492};\\\", \\\"{x:1678,y:787,t:1528139955508};\\\", \\\"{x:1678,y:783,t:1528139955526};\\\", \\\"{x:1678,y:780,t:1528139955542};\\\", \\\"{x:1678,y:778,t:1528139955560};\\\", \\\"{x:1677,y:775,t:1528139955575};\\\", \\\"{x:1677,y:773,t:1528139955592};\\\", \\\"{x:1675,y:771,t:1528139955609};\\\", \\\"{x:1675,y:769,t:1528139955626};\\\", \\\"{x:1675,y:768,t:1528139955693};\\\", \\\"{x:1675,y:767,t:1528139955709};\\\", \\\"{x:1674,y:766,t:1528139955725};\\\", \\\"{x:1674,y:765,t:1528139955757};\\\", \\\"{x:1673,y:764,t:1528139955773};\\\", \\\"{x:1672,y:762,t:1528139955789};\\\", \\\"{x:1671,y:760,t:1528139955796};\\\", \\\"{x:1671,y:759,t:1528139955812};\\\", \\\"{x:1670,y:757,t:1528139955827};\\\", \\\"{x:1669,y:754,t:1528139955842};\\\", \\\"{x:1668,y:753,t:1528139955859};\\\", \\\"{x:1667,y:751,t:1528139955876};\\\", \\\"{x:1667,y:750,t:1528139955892};\\\", \\\"{x:1667,y:749,t:1528139955910};\\\", \\\"{x:1665,y:748,t:1528139955927};\\\", \\\"{x:1665,y:746,t:1528139955942};\\\", \\\"{x:1664,y:746,t:1528139955972};\\\", \\\"{x:1664,y:744,t:1528139955981};\\\", \\\"{x:1662,y:743,t:1528139955996};\\\", \\\"{x:1661,y:741,t:1528139956010};\\\", \\\"{x:1658,y:737,t:1528139956027};\\\", \\\"{x:1654,y:733,t:1528139956043};\\\", \\\"{x:1651,y:731,t:1528139956060};\\\", \\\"{x:1648,y:728,t:1528139956077};\\\", \\\"{x:1645,y:725,t:1528139956092};\\\", \\\"{x:1640,y:722,t:1528139956109};\\\", \\\"{x:1634,y:718,t:1528139956127};\\\", \\\"{x:1632,y:717,t:1528139956142};\\\", \\\"{x:1631,y:716,t:1528139956160};\\\", \\\"{x:1631,y:715,t:1528139956180};\\\", \\\"{x:1630,y:715,t:1528139956193};\\\", \\\"{x:1629,y:714,t:1528139956210};\\\", \\\"{x:1626,y:713,t:1528139956226};\\\", \\\"{x:1623,y:711,t:1528139956242};\\\", \\\"{x:1622,y:711,t:1528139956260};\\\", \\\"{x:1618,y:709,t:1528139956277};\\\", \\\"{x:1617,y:709,t:1528139956292};\\\", \\\"{x:1616,y:709,t:1528139956309};\\\", \\\"{x:1616,y:708,t:1528139956327};\\\", \\\"{x:1615,y:709,t:1528139957052};\\\", \\\"{x:1615,y:712,t:1528139957060};\\\", \\\"{x:1617,y:717,t:1528139957076};\\\", \\\"{x:1618,y:719,t:1528139957093};\\\", \\\"{x:1620,y:722,t:1528139957111};\\\", \\\"{x:1621,y:723,t:1528139957127};\\\", \\\"{x:1621,y:724,t:1528139957143};\\\", \\\"{x:1622,y:726,t:1528139957161};\\\", \\\"{x:1622,y:727,t:1528139957176};\\\", \\\"{x:1623,y:728,t:1528139957194};\\\", \\\"{x:1624,y:730,t:1528139957210};\\\", \\\"{x:1624,y:731,t:1528139957227};\\\", \\\"{x:1625,y:733,t:1528139957244};\\\", \\\"{x:1627,y:735,t:1528139957260};\\\", \\\"{x:1630,y:739,t:1528139957277};\\\", \\\"{x:1631,y:742,t:1528139957293};\\\", \\\"{x:1636,y:747,t:1528139957310};\\\", \\\"{x:1640,y:752,t:1528139957327};\\\", \\\"{x:1644,y:757,t:1528139957343};\\\", \\\"{x:1649,y:763,t:1528139957361};\\\", \\\"{x:1658,y:772,t:1528139957377};\\\", \\\"{x:1664,y:778,t:1528139957393};\\\", \\\"{x:1668,y:783,t:1528139957410};\\\", \\\"{x:1676,y:791,t:1528139957427};\\\", \\\"{x:1685,y:803,t:1528139957443};\\\", \\\"{x:1701,y:818,t:1528139957461};\\\", \\\"{x:1708,y:825,t:1528139957477};\\\", \\\"{x:1717,y:834,t:1528139957493};\\\", \\\"{x:1726,y:844,t:1528139957511};\\\", \\\"{x:1736,y:854,t:1528139957528};\\\", \\\"{x:1742,y:860,t:1528139957543};\\\", \\\"{x:1748,y:866,t:1528139957561};\\\", \\\"{x:1754,y:871,t:1528139957578};\\\", \\\"{x:1759,y:875,t:1528139957593};\\\", \\\"{x:1762,y:879,t:1528139957610};\\\", \\\"{x:1765,y:883,t:1528139957627};\\\", \\\"{x:1766,y:885,t:1528139957644};\\\", \\\"{x:1769,y:889,t:1528139957660};\\\", \\\"{x:1770,y:891,t:1528139957678};\\\", \\\"{x:1772,y:893,t:1528139957693};\\\", \\\"{x:1773,y:896,t:1528139957711};\\\", \\\"{x:1775,y:900,t:1528139957728};\\\", \\\"{x:1778,y:904,t:1528139957744};\\\", \\\"{x:1782,y:908,t:1528139957761};\\\", \\\"{x:1787,y:915,t:1528139957778};\\\", \\\"{x:1793,y:922,t:1528139957794};\\\", \\\"{x:1800,y:931,t:1528139957810};\\\", \\\"{x:1806,y:938,t:1528139957826};\\\", \\\"{x:1812,y:947,t:1528139957842};\\\", \\\"{x:1819,y:957,t:1528139957859};\\\", \\\"{x:1824,y:964,t:1528139957877};\\\", \\\"{x:1826,y:967,t:1528139957893};\\\", \\\"{x:1826,y:968,t:1528139957910};\\\", \\\"{x:1826,y:967,t:1528139958324};\\\", \\\"{x:1825,y:965,t:1528139958332};\\\", \\\"{x:1824,y:964,t:1528139958344};\\\", \\\"{x:1822,y:964,t:1528139958361};\\\", \\\"{x:1817,y:961,t:1528139958377};\\\", \\\"{x:1815,y:959,t:1528139958394};\\\", \\\"{x:1812,y:957,t:1528139958410};\\\", \\\"{x:1811,y:957,t:1528139958428};\\\", \\\"{x:1810,y:956,t:1528139958444};\\\", \\\"{x:1808,y:955,t:1528139958652};\\\", \\\"{x:1806,y:952,t:1528139958660};\\\", \\\"{x:1796,y:943,t:1528139958678};\\\", \\\"{x:1783,y:935,t:1528139958695};\\\", \\\"{x:1772,y:928,t:1528139958712};\\\", \\\"{x:1760,y:918,t:1528139958728};\\\", \\\"{x:1746,y:907,t:1528139958744};\\\", \\\"{x:1732,y:895,t:1528139958762};\\\", \\\"{x:1720,y:885,t:1528139958778};\\\", \\\"{x:1712,y:877,t:1528139958795};\\\", \\\"{x:1706,y:869,t:1528139958811};\\\", \\\"{x:1702,y:865,t:1528139958827};\\\", \\\"{x:1699,y:859,t:1528139958844};\\\", \\\"{x:1694,y:850,t:1528139958861};\\\", \\\"{x:1690,y:839,t:1528139958877};\\\", \\\"{x:1686,y:831,t:1528139958896};\\\", \\\"{x:1685,y:828,t:1528139958911};\\\", \\\"{x:1683,y:825,t:1528139958926};\\\", \\\"{x:1682,y:822,t:1528139958944};\\\", \\\"{x:1679,y:818,t:1528139958961};\\\", \\\"{x:1676,y:814,t:1528139958977};\\\", \\\"{x:1672,y:807,t:1528139958994};\\\", \\\"{x:1670,y:803,t:1528139959011};\\\", \\\"{x:1664,y:794,t:1528139959027};\\\", \\\"{x:1655,y:784,t:1528139959044};\\\", \\\"{x:1651,y:780,t:1528139959061};\\\", \\\"{x:1647,y:777,t:1528139959077};\\\", \\\"{x:1645,y:774,t:1528139959094};\\\", \\\"{x:1644,y:773,t:1528139959111};\\\", \\\"{x:1642,y:771,t:1528139959127};\\\", \\\"{x:1641,y:769,t:1528139959144};\\\", \\\"{x:1640,y:768,t:1528139959161};\\\", \\\"{x:1639,y:767,t:1528139959177};\\\", \\\"{x:1637,y:766,t:1528139959194};\\\", \\\"{x:1636,y:765,t:1528139959212};\\\", \\\"{x:1634,y:764,t:1528139959228};\\\", \\\"{x:1633,y:762,t:1528139959244};\\\", \\\"{x:1632,y:758,t:1528139959261};\\\", \\\"{x:1630,y:757,t:1528139959279};\\\", \\\"{x:1628,y:754,t:1528139959295};\\\", \\\"{x:1626,y:751,t:1528139959311};\\\", \\\"{x:1624,y:750,t:1528139959329};\\\", \\\"{x:1623,y:749,t:1528139959345};\\\", \\\"{x:1621,y:747,t:1528139959361};\\\", \\\"{x:1619,y:745,t:1528139959378};\\\", \\\"{x:1617,y:743,t:1528139959395};\\\", \\\"{x:1616,y:741,t:1528139959411};\\\", \\\"{x:1612,y:737,t:1528139959428};\\\", \\\"{x:1608,y:735,t:1528139959445};\\\", \\\"{x:1606,y:734,t:1528139959462};\\\", \\\"{x:1601,y:731,t:1528139959479};\\\", \\\"{x:1596,y:730,t:1528139959494};\\\", \\\"{x:1594,y:729,t:1528139959511};\\\", \\\"{x:1593,y:728,t:1528139959528};\\\", \\\"{x:1593,y:727,t:1528139959544};\\\", \\\"{x:1592,y:726,t:1528139959684};\\\", \\\"{x:1592,y:725,t:1528139959740};\\\", \\\"{x:1592,y:724,t:1528139959757};\\\", \\\"{x:1592,y:723,t:1528139959780};\\\", \\\"{x:1592,y:722,t:1528139959795};\\\", \\\"{x:1591,y:721,t:1528139959812};\\\", \\\"{x:1590,y:720,t:1528139959829};\\\", \\\"{x:1590,y:719,t:1528139959846};\\\", \\\"{x:1590,y:718,t:1528139960549};\\\", \\\"{x:1590,y:717,t:1528139960562};\\\", \\\"{x:1592,y:716,t:1528139960580};\\\", \\\"{x:1593,y:715,t:1528139960597};\\\", \\\"{x:1594,y:714,t:1528139960613};\\\", \\\"{x:1596,y:714,t:1528139960629};\\\", \\\"{x:1596,y:713,t:1528139960693};\\\", \\\"{x:1597,y:712,t:1528139960708};\\\", \\\"{x:1598,y:712,t:1528139960805};\\\", \\\"{x:1599,y:712,t:1528139960837};\\\", \\\"{x:1600,y:711,t:1528139960860};\\\", \\\"{x:1601,y:711,t:1528139960869};\\\", \\\"{x:1602,y:710,t:1528139960884};\\\", \\\"{x:1603,y:710,t:1528139960900};\\\", \\\"{x:1604,y:709,t:1528139960913};\\\", \\\"{x:1605,y:709,t:1528139960930};\\\", \\\"{x:1607,y:708,t:1528139960946};\\\", \\\"{x:1608,y:708,t:1528139960962};\\\", \\\"{x:1610,y:707,t:1528139960980};\\\", \\\"{x:1611,y:706,t:1528139960996};\\\", \\\"{x:1614,y:705,t:1528139961013};\\\", \\\"{x:1615,y:705,t:1528139961293};\\\", \\\"{x:1617,y:705,t:1528139961308};\\\", \\\"{x:1619,y:705,t:1528139961332};\\\", \\\"{x:1619,y:706,t:1528139961347};\\\", \\\"{x:1620,y:706,t:1528139961364};\\\", \\\"{x:1620,y:707,t:1528139963356};\\\", \\\"{x:1620,y:708,t:1528139963372};\\\", \\\"{x:1618,y:711,t:1528139963381};\\\", \\\"{x:1611,y:718,t:1528139963398};\\\", \\\"{x:1606,y:722,t:1528139963414};\\\", \\\"{x:1601,y:728,t:1528139963431};\\\", \\\"{x:1599,y:730,t:1528139963448};\\\", \\\"{x:1598,y:730,t:1528139963464};\\\", \\\"{x:1598,y:731,t:1528139963517};\\\", \\\"{x:1597,y:735,t:1528139963530};\\\", \\\"{x:1596,y:738,t:1528139963548};\\\", \\\"{x:1592,y:746,t:1528139963564};\\\", \\\"{x:1591,y:750,t:1528139963580};\\\", \\\"{x:1589,y:754,t:1528139963597};\\\", \\\"{x:1589,y:755,t:1528139963614};\\\", \\\"{x:1587,y:759,t:1528139963630};\\\", \\\"{x:1585,y:762,t:1528139963647};\\\", \\\"{x:1583,y:769,t:1528139963664};\\\", \\\"{x:1578,y:778,t:1528139963681};\\\", \\\"{x:1571,y:789,t:1528139963698};\\\", \\\"{x:1569,y:795,t:1528139963713};\\\", \\\"{x:1567,y:799,t:1528139963731};\\\", \\\"{x:1566,y:803,t:1528139963748};\\\", \\\"{x:1564,y:807,t:1528139963764};\\\", \\\"{x:1562,y:812,t:1528139963780};\\\", \\\"{x:1559,y:820,t:1528139963797};\\\", \\\"{x:1552,y:834,t:1528139963815};\\\", \\\"{x:1546,y:849,t:1528139963831};\\\", \\\"{x:1539,y:864,t:1528139963848};\\\", \\\"{x:1532,y:876,t:1528139963864};\\\", \\\"{x:1525,y:888,t:1528139963881};\\\", \\\"{x:1521,y:894,t:1528139963898};\\\", \\\"{x:1519,y:899,t:1528139963915};\\\", \\\"{x:1516,y:905,t:1528139963931};\\\", \\\"{x:1514,y:908,t:1528139963948};\\\", \\\"{x:1510,y:914,t:1528139963964};\\\", \\\"{x:1508,y:918,t:1528139963980};\\\", \\\"{x:1506,y:921,t:1528139963998};\\\", \\\"{x:1504,y:923,t:1528139964015};\\\", \\\"{x:1503,y:925,t:1528139964031};\\\", \\\"{x:1503,y:926,t:1528139964048};\\\", \\\"{x:1501,y:927,t:1528139964065};\\\", \\\"{x:1500,y:929,t:1528139964080};\\\", \\\"{x:1499,y:931,t:1528139964098};\\\", \\\"{x:1498,y:934,t:1528139964115};\\\", \\\"{x:1496,y:936,t:1528139964131};\\\", \\\"{x:1495,y:937,t:1528139964148};\\\", \\\"{x:1494,y:939,t:1528139964164};\\\", \\\"{x:1493,y:940,t:1528139964181};\\\", \\\"{x:1492,y:942,t:1528139964198};\\\", \\\"{x:1491,y:943,t:1528139964214};\\\", \\\"{x:1490,y:944,t:1528139964231};\\\", \\\"{x:1489,y:945,t:1528139964260};\\\", \\\"{x:1488,y:947,t:1528139964292};\\\", \\\"{x:1487,y:947,t:1528139964333};\\\", \\\"{x:1487,y:948,t:1528139964381};\\\", \\\"{x:1487,y:949,t:1528139964445};\\\", \\\"{x:1487,y:950,t:1528139964469};\\\", \\\"{x:1486,y:950,t:1528139964482};\\\", \\\"{x:1486,y:951,t:1528139964498};\\\", \\\"{x:1485,y:952,t:1528139964548};\\\", \\\"{x:1485,y:953,t:1528139965253};\\\", \\\"{x:1485,y:954,t:1528139965757};\\\", \\\"{x:1485,y:956,t:1528139965765};\\\", \\\"{x:1485,y:962,t:1528139965782};\\\", \\\"{x:1485,y:966,t:1528139965798};\\\", \\\"{x:1485,y:967,t:1528139965816};\\\", \\\"{x:1486,y:956,t:1528139966484};\\\", \\\"{x:1493,y:933,t:1528139966499};\\\", \\\"{x:1502,y:900,t:1528139966516};\\\", \\\"{x:1518,y:847,t:1528139966532};\\\", \\\"{x:1524,y:825,t:1528139966549};\\\", \\\"{x:1530,y:805,t:1528139966566};\\\", \\\"{x:1538,y:790,t:1528139966583};\\\", \\\"{x:1545,y:778,t:1528139966599};\\\", \\\"{x:1550,y:767,t:1528139966615};\\\", \\\"{x:1557,y:754,t:1528139966632};\\\", \\\"{x:1566,y:737,t:1528139966650};\\\", \\\"{x:1570,y:727,t:1528139966666};\\\", \\\"{x:1577,y:719,t:1528139966683};\\\", \\\"{x:1583,y:710,t:1528139966700};\\\", \\\"{x:1590,y:703,t:1528139966715};\\\", \\\"{x:1604,y:689,t:1528139966732};\\\", \\\"{x:1616,y:679,t:1528139966750};\\\", \\\"{x:1626,y:670,t:1528139966766};\\\", \\\"{x:1635,y:663,t:1528139966783};\\\", \\\"{x:1640,y:659,t:1528139966800};\\\", \\\"{x:1642,y:657,t:1528139966816};\\\", \\\"{x:1642,y:661,t:1528139966980};\\\", \\\"{x:1639,y:671,t:1528139966989};\\\", \\\"{x:1634,y:678,t:1528139967000};\\\", \\\"{x:1623,y:699,t:1528139967016};\\\", \\\"{x:1612,y:718,t:1528139967033};\\\", \\\"{x:1602,y:735,t:1528139967050};\\\", \\\"{x:1596,y:752,t:1528139967066};\\\", \\\"{x:1589,y:769,t:1528139967083};\\\", \\\"{x:1582,y:783,t:1528139967100};\\\", \\\"{x:1576,y:797,t:1528139967116};\\\", \\\"{x:1576,y:803,t:1528139967132};\\\", \\\"{x:1571,y:813,t:1528139967150};\\\", \\\"{x:1570,y:818,t:1528139967166};\\\", \\\"{x:1568,y:824,t:1528139967183};\\\", \\\"{x:1567,y:830,t:1528139967200};\\\", \\\"{x:1564,y:837,t:1528139967218};\\\", \\\"{x:1562,y:848,t:1528139967233};\\\", \\\"{x:1553,y:864,t:1528139967250};\\\", \\\"{x:1546,y:878,t:1528139967266};\\\", \\\"{x:1535,y:896,t:1528139967284};\\\", \\\"{x:1526,y:912,t:1528139967300};\\\", \\\"{x:1516,y:932,t:1528139967317};\\\", \\\"{x:1514,y:938,t:1528139967333};\\\", \\\"{x:1511,y:944,t:1528139967349};\\\", \\\"{x:1508,y:948,t:1528139967366};\\\", \\\"{x:1506,y:952,t:1528139967382};\\\", \\\"{x:1504,y:954,t:1528139967400};\\\", \\\"{x:1503,y:958,t:1528139967416};\\\", \\\"{x:1499,y:962,t:1528139967433};\\\", \\\"{x:1496,y:966,t:1528139967449};\\\", \\\"{x:1494,y:968,t:1528139967466};\\\", \\\"{x:1492,y:970,t:1528139967482};\\\", \\\"{x:1491,y:966,t:1528139967732};\\\", \\\"{x:1491,y:961,t:1528139967749};\\\", \\\"{x:1490,y:957,t:1528139967767};\\\", \\\"{x:1489,y:954,t:1528139967783};\\\", \\\"{x:1488,y:951,t:1528139967800};\\\", \\\"{x:1488,y:949,t:1528139967816};\\\", \\\"{x:1488,y:947,t:1528139967833};\\\", \\\"{x:1487,y:944,t:1528139967849};\\\", \\\"{x:1486,y:942,t:1528139967866};\\\", \\\"{x:1485,y:937,t:1528139967884};\\\", \\\"{x:1485,y:935,t:1528139967899};\\\", \\\"{x:1483,y:932,t:1528139967917};\\\", \\\"{x:1481,y:929,t:1528139967933};\\\", \\\"{x:1479,y:924,t:1528139967949};\\\", \\\"{x:1476,y:915,t:1528139967967};\\\", \\\"{x:1469,y:901,t:1528139967984};\\\", \\\"{x:1463,y:886,t:1528139967999};\\\", \\\"{x:1457,y:873,t:1528139968016};\\\", \\\"{x:1446,y:855,t:1528139968033};\\\", \\\"{x:1433,y:836,t:1528139968050};\\\", \\\"{x:1424,y:820,t:1528139968066};\\\", \\\"{x:1414,y:802,t:1528139968083};\\\", \\\"{x:1404,y:788,t:1528139968100};\\\", \\\"{x:1392,y:769,t:1528139968116};\\\", \\\"{x:1385,y:757,t:1528139968134};\\\", \\\"{x:1376,y:739,t:1528139968149};\\\", \\\"{x:1370,y:727,t:1528139968166};\\\", \\\"{x:1362,y:714,t:1528139968184};\\\", \\\"{x:1351,y:702,t:1528139968199};\\\", \\\"{x:1342,y:691,t:1528139968216};\\\", \\\"{x:1337,y:686,t:1528139968234};\\\", \\\"{x:1332,y:680,t:1528139968249};\\\", \\\"{x:1326,y:673,t:1528139968267};\\\", \\\"{x:1323,y:670,t:1528139968284};\\\", \\\"{x:1321,y:668,t:1528139968300};\\\", \\\"{x:1321,y:666,t:1528139968317};\\\", \\\"{x:1319,y:663,t:1528139968333};\\\", \\\"{x:1316,y:660,t:1528139968350};\\\", \\\"{x:1313,y:656,t:1528139968366};\\\", \\\"{x:1311,y:652,t:1528139968384};\\\", \\\"{x:1310,y:649,t:1528139968400};\\\", \\\"{x:1307,y:645,t:1528139968417};\\\", \\\"{x:1305,y:640,t:1528139968434};\\\", \\\"{x:1300,y:632,t:1528139968450};\\\", \\\"{x:1298,y:629,t:1528139968466};\\\", \\\"{x:1294,y:621,t:1528139968484};\\\", \\\"{x:1291,y:617,t:1528139968500};\\\", \\\"{x:1289,y:614,t:1528139968516};\\\", \\\"{x:1282,y:607,t:1528139968534};\\\", \\\"{x:1277,y:602,t:1528139968551};\\\", \\\"{x:1273,y:597,t:1528139968567};\\\", \\\"{x:1268,y:591,t:1528139968584};\\\", \\\"{x:1264,y:587,t:1528139968601};\\\", \\\"{x:1263,y:585,t:1528139968616};\\\", \\\"{x:1263,y:586,t:1528139968796};\\\", \\\"{x:1270,y:599,t:1528139968804};\\\", \\\"{x:1299,y:626,t:1528139968817};\\\", \\\"{x:1357,y:677,t:1528139968834};\\\", \\\"{x:1358,y:680,t:1528139968851};\\\", \\\"{x:1292,y:664,t:1528139968867};\\\", \\\"{x:1012,y:600,t:1528139968884};\\\", \\\"{x:763,y:557,t:1528139968901};\\\", \\\"{x:569,y:525,t:1528139968919};\\\", \\\"{x:453,y:492,t:1528139968935};\\\", \\\"{x:378,y:470,t:1528139968951};\\\", \\\"{x:249,y:430,t:1528139968987};\\\", \\\"{x:245,y:429,t:1528139969003};\\\", \\\"{x:248,y:427,t:1528139969059};\\\", \\\"{x:256,y:426,t:1528139969070};\\\", \\\"{x:266,y:426,t:1528139969086};\\\", \\\"{x:274,y:425,t:1528139969103};\\\", \\\"{x:292,y:419,t:1528139969120};\\\", \\\"{x:327,y:414,t:1528139969136};\\\", \\\"{x:361,y:409,t:1528139969154};\\\", \\\"{x:383,y:408,t:1528139969171};\\\", \\\"{x:410,y:408,t:1528139969186};\\\", \\\"{x:460,y:412,t:1528139969204};\\\", \\\"{x:491,y:416,t:1528139969220};\\\", \\\"{x:513,y:417,t:1528139969237};\\\", \\\"{x:526,y:417,t:1528139969253};\\\", \\\"{x:537,y:418,t:1528139969270};\\\", \\\"{x:564,y:422,t:1528139969287};\\\", \\\"{x:590,y:425,t:1528139969303};\\\", \\\"{x:615,y:427,t:1528139969320};\\\", \\\"{x:634,y:428,t:1528139969337};\\\", \\\"{x:649,y:428,t:1528139969353};\\\", \\\"{x:662,y:428,t:1528139969371};\\\", \\\"{x:674,y:429,t:1528139969387};\\\", \\\"{x:686,y:432,t:1528139969403};\\\", \\\"{x:697,y:434,t:1528139969420};\\\", \\\"{x:701,y:437,t:1528139969438};\\\", \\\"{x:708,y:442,t:1528139969454};\\\", \\\"{x:719,y:450,t:1528139969470};\\\", \\\"{x:731,y:456,t:1528139969488};\\\", \\\"{x:741,y:459,t:1528139969504};\\\", \\\"{x:749,y:462,t:1528139969520};\\\", \\\"{x:758,y:467,t:1528139969538};\\\", \\\"{x:780,y:477,t:1528139969554};\\\", \\\"{x:802,y:487,t:1528139969572};\\\", \\\"{x:826,y:497,t:1528139969587};\\\", \\\"{x:834,y:500,t:1528139969602};\\\", \\\"{x:845,y:505,t:1528139969618};\\\", \\\"{x:854,y:509,t:1528139969635};\\\", \\\"{x:852,y:511,t:1528139969948};\\\", \\\"{x:850,y:511,t:1528139969956};\\\", \\\"{x:848,y:511,t:1528139969967};\\\", \\\"{x:845,y:511,t:1528139969984};\\\", \\\"{x:844,y:511,t:1528139970077};\\\", \\\"{x:843,y:511,t:1528139970108};\\\", \\\"{x:841,y:511,t:1528139970132};\\\", \\\"{x:841,y:510,t:1528139970140};\\\", \\\"{x:840,y:510,t:1528139970163};\\\", \\\"{x:839,y:509,t:1528139970371};\\\", \\\"{x:829,y:509,t:1528139970460};\\\", \\\"{x:812,y:509,t:1528139970471};\\\", \\\"{x:786,y:510,t:1528139970487};\\\", \\\"{x:750,y:510,t:1528139970504};\\\", \\\"{x:700,y:510,t:1528139970522};\\\", \\\"{x:667,y:509,t:1528139970538};\\\", \\\"{x:645,y:502,t:1528139970554};\\\", \\\"{x:632,y:498,t:1528139970572};\\\", \\\"{x:629,y:497,t:1528139970588};\\\", \\\"{x:628,y:497,t:1528139970956};\\\", \\\"{x:623,y:506,t:1528139971420};\\\", \\\"{x:616,y:517,t:1528139971429};\\\", \\\"{x:606,y:531,t:1528139971441};\\\", \\\"{x:588,y:557,t:1528139971456};\\\", \\\"{x:576,y:578,t:1528139971472};\\\", \\\"{x:571,y:599,t:1528139971489};\\\", \\\"{x:568,y:615,t:1528139971505};\\\", \\\"{x:567,y:623,t:1528139971521};\\\", \\\"{x:567,y:633,t:1528139971539};\\\", \\\"{x:567,y:655,t:1528139971555};\\\", \\\"{x:567,y:666,t:1528139971572};\\\", \\\"{x:567,y:677,t:1528139971588};\\\", \\\"{x:567,y:686,t:1528139971606};\\\", \\\"{x:566,y:697,t:1528139971623};\\\", \\\"{x:562,y:710,t:1528139971639};\\\", \\\"{x:557,y:722,t:1528139971656};\\\", \\\"{x:555,y:732,t:1528139971672};\\\", \\\"{x:555,y:736,t:1528139971688};\\\", \\\"{x:555,y:737,t:1528139971723};\\\", \\\"{x:555,y:738,t:1528139971740};\\\", \\\"{x:555,y:739,t:1528139971763};\\\" ] }, { \\\"rt\\\": 10718, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 599867, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:740,t:1528139973683};\\\", \\\"{x:550,y:740,t:1528139973702};\\\", \\\"{x:549,y:740,t:1528139973707};\\\", \\\"{x:548,y:741,t:1528139973731};\\\", \\\"{x:548,y:742,t:1528139973740};\\\", \\\"{x:546,y:742,t:1528139973757};\\\", \\\"{x:544,y:743,t:1528139973773};\\\", \\\"{x:543,y:744,t:1528139973791};\\\", \\\"{x:540,y:744,t:1528139973848};\\\", \\\"{x:540,y:737,t:1528139974205};\\\", \\\"{x:540,y:729,t:1528139974212};\\\", \\\"{x:540,y:718,t:1528139974226};\\\", \\\"{x:543,y:700,t:1528139974240};\\\", \\\"{x:544,y:682,t:1528139974257};\\\", \\\"{x:545,y:663,t:1528139974275};\\\", \\\"{x:545,y:641,t:1528139974290};\\\", \\\"{x:548,y:612,t:1528139974307};\\\", \\\"{x:552,y:593,t:1528139974325};\\\", \\\"{x:559,y:571,t:1528139974340};\\\", \\\"{x:564,y:557,t:1528139974357};\\\", \\\"{x:569,y:544,t:1528139974375};\\\", \\\"{x:574,y:538,t:1528139974392};\\\", \\\"{x:575,y:536,t:1528139974407};\\\", \\\"{x:576,y:535,t:1528139974424};\\\", \\\"{x:576,y:534,t:1528139974443};\\\", \\\"{x:578,y:532,t:1528139974467};\\\", \\\"{x:580,y:530,t:1528139974476};\\\", \\\"{x:587,y:520,t:1528139974492};\\\", \\\"{x:594,y:511,t:1528139974510};\\\", \\\"{x:603,y:504,t:1528139974525};\\\", \\\"{x:614,y:497,t:1528139974541};\\\", \\\"{x:622,y:494,t:1528139974558};\\\", \\\"{x:627,y:492,t:1528139974574};\\\", \\\"{x:628,y:492,t:1528139974591};\\\", \\\"{x:629,y:492,t:1528139974716};\\\", \\\"{x:632,y:492,t:1528139974725};\\\", \\\"{x:653,y:492,t:1528139974743};\\\", \\\"{x:698,y:492,t:1528139974757};\\\", \\\"{x:754,y:500,t:1528139974775};\\\", \\\"{x:834,y:509,t:1528139974791};\\\", \\\"{x:942,y:509,t:1528139974807};\\\", \\\"{x:1049,y:515,t:1528139974825};\\\", \\\"{x:1149,y:531,t:1528139974842};\\\", \\\"{x:1246,y:544,t:1528139974857};\\\", \\\"{x:1360,y:563,t:1528139974875};\\\", \\\"{x:1546,y:618,t:1528139974891};\\\", \\\"{x:1688,y:672,t:1528139974908};\\\", \\\"{x:1807,y:723,t:1528139974924};\\\", \\\"{x:1893,y:752,t:1528139974941};\\\", \\\"{x:1919,y:766,t:1528139974957};\\\", \\\"{x:1919,y:771,t:1528139974974};\\\", \\\"{x:1919,y:773,t:1528139974992};\\\", \\\"{x:1919,y:774,t:1528139975011};\\\", \\\"{x:1914,y:779,t:1528139975148};\\\", \\\"{x:1905,y:791,t:1528139975159};\\\", \\\"{x:1888,y:816,t:1528139975176};\\\", \\\"{x:1876,y:832,t:1528139975192};\\\", \\\"{x:1864,y:848,t:1528139975209};\\\", \\\"{x:1849,y:863,t:1528139975225};\\\", \\\"{x:1839,y:872,t:1528139975242};\\\", \\\"{x:1827,y:880,t:1528139975259};\\\", \\\"{x:1812,y:890,t:1528139975275};\\\", \\\"{x:1800,y:897,t:1528139975292};\\\", \\\"{x:1787,y:901,t:1528139975308};\\\", \\\"{x:1775,y:903,t:1528139975326};\\\", \\\"{x:1759,y:908,t:1528139975342};\\\", \\\"{x:1750,y:912,t:1528139975359};\\\", \\\"{x:1732,y:926,t:1528139975376};\\\", \\\"{x:1701,y:947,t:1528139975391};\\\", \\\"{x:1660,y:973,t:1528139975409};\\\", \\\"{x:1612,y:996,t:1528139975427};\\\", \\\"{x:1577,y:1009,t:1528139975442};\\\", \\\"{x:1555,y:1019,t:1528139975459};\\\", \\\"{x:1542,y:1021,t:1528139975476};\\\", \\\"{x:1539,y:1022,t:1528139975491};\\\", \\\"{x:1539,y:1017,t:1528139975757};\\\", \\\"{x:1539,y:1010,t:1528139975764};\\\", \\\"{x:1539,y:1004,t:1528139975776};\\\", \\\"{x:1538,y:992,t:1528139975793};\\\", \\\"{x:1537,y:982,t:1528139975809};\\\", \\\"{x:1537,y:976,t:1528139975827};\\\", \\\"{x:1537,y:969,t:1528139975843};\\\", \\\"{x:1537,y:964,t:1528139975860};\\\", \\\"{x:1535,y:959,t:1528139975876};\\\", \\\"{x:1535,y:957,t:1528139975893};\\\", \\\"{x:1534,y:956,t:1528139975909};\\\", \\\"{x:1534,y:954,t:1528139975927};\\\", \\\"{x:1533,y:953,t:1528139975943};\\\", \\\"{x:1532,y:953,t:1528139976100};\\\", \\\"{x:1532,y:954,t:1528139976156};\\\", \\\"{x:1532,y:955,t:1528139976164};\\\", \\\"{x:1532,y:956,t:1528139976176};\\\", \\\"{x:1532,y:957,t:1528139976194};\\\", \\\"{x:1532,y:958,t:1528139976436};\\\", \\\"{x:1532,y:959,t:1528139976444};\\\", \\\"{x:1531,y:960,t:1528139976460};\\\", \\\"{x:1530,y:962,t:1528139976475};\\\", \\\"{x:1530,y:963,t:1528139976507};\\\", \\\"{x:1530,y:965,t:1528139976813};\\\", \\\"{x:1529,y:966,t:1528139976830};\\\", \\\"{x:1528,y:966,t:1528139976842};\\\", \\\"{x:1528,y:967,t:1528139976948};\\\", \\\"{x:1527,y:967,t:1528139976960};\\\", \\\"{x:1527,y:968,t:1528139976987};\\\", \\\"{x:1527,y:969,t:1528139977003};\\\", \\\"{x:1528,y:969,t:1528139977020};\\\", \\\"{x:1529,y:969,t:1528139977036};\\\", \\\"{x:1530,y:970,t:1528139977044};\\\", \\\"{x:1532,y:971,t:1528139977059};\\\", \\\"{x:1533,y:971,t:1528139977077};\\\", \\\"{x:1533,y:972,t:1528139977093};\\\", \\\"{x:1535,y:972,t:1528139977116};\\\", \\\"{x:1536,y:972,t:1528139977140};\\\", \\\"{x:1538,y:972,t:1528139977172};\\\", \\\"{x:1538,y:973,t:1528139977180};\\\", \\\"{x:1539,y:973,t:1528139977196};\\\", \\\"{x:1539,y:974,t:1528139977210};\\\", \\\"{x:1542,y:975,t:1528139977228};\\\", \\\"{x:1543,y:975,t:1528139977244};\\\", \\\"{x:1544,y:975,t:1528139977268};\\\", \\\"{x:1545,y:975,t:1528139977277};\\\", \\\"{x:1544,y:975,t:1528139977541};\\\", \\\"{x:1544,y:974,t:1528139977564};\\\", \\\"{x:1544,y:973,t:1528139977580};\\\", \\\"{x:1544,y:972,t:1528139977596};\\\", \\\"{x:1544,y:971,t:1528139977612};\\\", \\\"{x:1544,y:970,t:1528139977636};\\\", \\\"{x:1544,y:969,t:1528139977644};\\\", \\\"{x:1544,y:968,t:1528139977677};\\\", \\\"{x:1544,y:966,t:1528139977694};\\\", \\\"{x:1544,y:965,t:1528139977711};\\\", \\\"{x:1544,y:964,t:1528139977727};\\\", \\\"{x:1544,y:962,t:1528139977745};\\\", \\\"{x:1543,y:960,t:1528139977761};\\\", \\\"{x:1542,y:959,t:1528139977780};\\\", \\\"{x:1542,y:958,t:1528139977794};\\\", \\\"{x:1541,y:957,t:1528139977811};\\\", \\\"{x:1540,y:955,t:1528139977827};\\\", \\\"{x:1540,y:952,t:1528139977844};\\\", \\\"{x:1540,y:951,t:1528139977861};\\\", \\\"{x:1540,y:950,t:1528139977877};\\\", \\\"{x:1539,y:948,t:1528139977894};\\\", \\\"{x:1538,y:947,t:1528139977912};\\\", \\\"{x:1538,y:946,t:1528139977927};\\\", \\\"{x:1537,y:944,t:1528139977944};\\\", \\\"{x:1537,y:940,t:1528139977961};\\\", \\\"{x:1532,y:936,t:1528139977977};\\\", \\\"{x:1530,y:931,t:1528139977994};\\\", \\\"{x:1529,y:928,t:1528139978012};\\\", \\\"{x:1525,y:923,t:1528139978028};\\\", \\\"{x:1523,y:919,t:1528139978044};\\\", \\\"{x:1522,y:917,t:1528139978061};\\\", \\\"{x:1520,y:915,t:1528139978078};\\\", \\\"{x:1519,y:913,t:1528139978094};\\\", \\\"{x:1519,y:912,t:1528139978111};\\\", \\\"{x:1517,y:910,t:1528139978128};\\\", \\\"{x:1517,y:908,t:1528139978144};\\\", \\\"{x:1516,y:907,t:1528139978161};\\\", \\\"{x:1515,y:905,t:1528139978178};\\\", \\\"{x:1512,y:899,t:1528139978194};\\\", \\\"{x:1508,y:893,t:1528139978212};\\\", \\\"{x:1505,y:889,t:1528139978228};\\\", \\\"{x:1502,y:885,t:1528139978244};\\\", \\\"{x:1500,y:881,t:1528139978261};\\\", \\\"{x:1497,y:877,t:1528139978278};\\\", \\\"{x:1491,y:869,t:1528139978294};\\\", \\\"{x:1485,y:860,t:1528139978311};\\\", \\\"{x:1482,y:856,t:1528139978329};\\\", \\\"{x:1479,y:852,t:1528139978345};\\\", \\\"{x:1476,y:849,t:1528139978362};\\\", \\\"{x:1474,y:845,t:1528139978379};\\\", \\\"{x:1473,y:843,t:1528139978395};\\\", \\\"{x:1472,y:840,t:1528139978412};\\\", \\\"{x:1470,y:837,t:1528139978428};\\\", \\\"{x:1469,y:836,t:1528139978445};\\\", \\\"{x:1468,y:833,t:1528139978461};\\\", \\\"{x:1467,y:832,t:1528139978478};\\\", \\\"{x:1462,y:826,t:1528139978495};\\\", \\\"{x:1460,y:820,t:1528139978511};\\\", \\\"{x:1456,y:816,t:1528139978528};\\\", \\\"{x:1452,y:813,t:1528139978545};\\\", \\\"{x:1451,y:810,t:1528139978561};\\\", \\\"{x:1448,y:807,t:1528139978578};\\\", \\\"{x:1447,y:806,t:1528139978595};\\\", \\\"{x:1445,y:804,t:1528139978611};\\\", \\\"{x:1443,y:800,t:1528139978628};\\\", \\\"{x:1441,y:795,t:1528139978645};\\\", \\\"{x:1439,y:791,t:1528139978661};\\\", \\\"{x:1436,y:788,t:1528139978678};\\\", \\\"{x:1430,y:780,t:1528139978695};\\\", \\\"{x:1425,y:772,t:1528139978712};\\\", \\\"{x:1419,y:765,t:1528139978729};\\\", \\\"{x:1409,y:752,t:1528139978746};\\\", \\\"{x:1404,y:744,t:1528139978761};\\\", \\\"{x:1396,y:733,t:1528139978778};\\\", \\\"{x:1391,y:725,t:1528139978795};\\\", \\\"{x:1390,y:723,t:1528139978811};\\\", \\\"{x:1389,y:723,t:1528139978828};\\\", \\\"{x:1389,y:722,t:1528139978940};\\\", \\\"{x:1388,y:722,t:1528139978948};\\\", \\\"{x:1388,y:720,t:1528139978988};\\\", \\\"{x:1388,y:717,t:1528139978996};\\\", \\\"{x:1388,y:712,t:1528139979012};\\\", \\\"{x:1387,y:707,t:1528139979028};\\\", \\\"{x:1386,y:701,t:1528139979045};\\\", \\\"{x:1383,y:696,t:1528139979063};\\\", \\\"{x:1380,y:692,t:1528139979079};\\\", \\\"{x:1380,y:689,t:1528139979100};\\\", \\\"{x:1380,y:688,t:1528139979132};\\\", \\\"{x:1380,y:687,t:1528139979145};\\\", \\\"{x:1379,y:686,t:1528139979162};\\\", \\\"{x:1378,y:685,t:1528139979178};\\\", \\\"{x:1376,y:685,t:1528139979941};\\\", \\\"{x:1368,y:686,t:1528139979948};\\\", \\\"{x:1358,y:689,t:1528139979962};\\\", \\\"{x:1332,y:696,t:1528139979980};\\\", \\\"{x:1249,y:720,t:1528139979996};\\\", \\\"{x:1168,y:743,t:1528139980012};\\\", \\\"{x:1080,y:766,t:1528139980029};\\\", \\\"{x:990,y:783,t:1528139980047};\\\", \\\"{x:890,y:787,t:1528139980062};\\\", \\\"{x:779,y:787,t:1528139980079};\\\", \\\"{x:660,y:787,t:1528139980096};\\\", \\\"{x:543,y:787,t:1528139980113};\\\", \\\"{x:442,y:782,t:1528139980129};\\\", \\\"{x:377,y:769,t:1528139980147};\\\", \\\"{x:314,y:757,t:1528139980163};\\\", \\\"{x:239,y:735,t:1528139980179};\\\", \\\"{x:136,y:703,t:1528139980195};\\\", \\\"{x:90,y:686,t:1528139980213};\\\", \\\"{x:67,y:678,t:1528139980229};\\\", \\\"{x:60,y:673,t:1528139980247};\\\", \\\"{x:60,y:671,t:1528139980276};\\\", \\\"{x:60,y:668,t:1528139980285};\\\", \\\"{x:63,y:663,t:1528139980295};\\\", \\\"{x:71,y:656,t:1528139980313};\\\", \\\"{x:85,y:649,t:1528139980328};\\\", \\\"{x:105,y:639,t:1528139980345};\\\", \\\"{x:122,y:629,t:1528139980364};\\\", \\\"{x:137,y:619,t:1528139980378};\\\", \\\"{x:152,y:610,t:1528139980395};\\\", \\\"{x:165,y:604,t:1528139980412};\\\", \\\"{x:177,y:599,t:1528139980429};\\\", \\\"{x:193,y:591,t:1528139980446};\\\", \\\"{x:202,y:588,t:1528139980463};\\\", \\\"{x:212,y:586,t:1528139980479};\\\", \\\"{x:225,y:585,t:1528139980496};\\\", \\\"{x:240,y:585,t:1528139980513};\\\", \\\"{x:254,y:585,t:1528139980530};\\\", \\\"{x:270,y:585,t:1528139980546};\\\", \\\"{x:298,y:585,t:1528139980563};\\\", \\\"{x:316,y:587,t:1528139980579};\\\", \\\"{x:331,y:589,t:1528139980596};\\\", \\\"{x:343,y:593,t:1528139980613};\\\", \\\"{x:356,y:594,t:1528139980629};\\\", \\\"{x:366,y:598,t:1528139980646};\\\", \\\"{x:372,y:599,t:1528139980663};\\\", \\\"{x:377,y:600,t:1528139980680};\\\", \\\"{x:383,y:601,t:1528139980696};\\\", \\\"{x:392,y:602,t:1528139980712};\\\", \\\"{x:400,y:602,t:1528139980730};\\\", \\\"{x:412,y:602,t:1528139980747};\\\", \\\"{x:422,y:602,t:1528139980763};\\\", \\\"{x:438,y:602,t:1528139980779};\\\", \\\"{x:445,y:602,t:1528139980797};\\\", \\\"{x:454,y:601,t:1528139980812};\\\", \\\"{x:460,y:598,t:1528139980830};\\\", \\\"{x:464,y:595,t:1528139980846};\\\", \\\"{x:473,y:591,t:1528139980863};\\\", \\\"{x:484,y:585,t:1528139980879};\\\", \\\"{x:502,y:576,t:1528139980899};\\\", \\\"{x:517,y:572,t:1528139980913};\\\", \\\"{x:529,y:567,t:1528139980930};\\\", \\\"{x:538,y:562,t:1528139980946};\\\", \\\"{x:545,y:560,t:1528139980963};\\\", \\\"{x:561,y:556,t:1528139980979};\\\", \\\"{x:574,y:553,t:1528139980997};\\\", \\\"{x:593,y:551,t:1528139981013};\\\", \\\"{x:612,y:548,t:1528139981030};\\\", \\\"{x:626,y:547,t:1528139981047};\\\", \\\"{x:638,y:545,t:1528139981063};\\\", \\\"{x:648,y:543,t:1528139981080};\\\", \\\"{x:659,y:542,t:1528139981096};\\\", \\\"{x:668,y:542,t:1528139981112};\\\", \\\"{x:674,y:541,t:1528139981130};\\\", \\\"{x:678,y:540,t:1528139981146};\\\", \\\"{x:686,y:540,t:1528139981163};\\\", \\\"{x:701,y:540,t:1528139981180};\\\", \\\"{x:713,y:540,t:1528139981197};\\\", \\\"{x:727,y:540,t:1528139981213};\\\", \\\"{x:738,y:540,t:1528139981230};\\\", \\\"{x:743,y:540,t:1528139981246};\\\", \\\"{x:744,y:540,t:1528139981264};\\\", \\\"{x:744,y:541,t:1528139981323};\\\", \\\"{x:744,y:542,t:1528139981340};\\\", \\\"{x:744,y:545,t:1528139981347};\\\", \\\"{x:742,y:548,t:1528139981364};\\\", \\\"{x:739,y:554,t:1528139981380};\\\", \\\"{x:735,y:561,t:1528139981398};\\\", \\\"{x:731,y:567,t:1528139981414};\\\", \\\"{x:726,y:574,t:1528139981429};\\\", \\\"{x:722,y:576,t:1528139981447};\\\", \\\"{x:717,y:578,t:1528139981464};\\\", \\\"{x:712,y:580,t:1528139981480};\\\", \\\"{x:706,y:582,t:1528139981497};\\\", \\\"{x:704,y:583,t:1528139981514};\\\", \\\"{x:699,y:585,t:1528139981530};\\\", \\\"{x:697,y:586,t:1528139981546};\\\", \\\"{x:694,y:586,t:1528139981563};\\\", \\\"{x:692,y:586,t:1528139981580};\\\", \\\"{x:688,y:587,t:1528139981596};\\\", \\\"{x:683,y:590,t:1528139981613};\\\", \\\"{x:679,y:591,t:1528139981630};\\\", \\\"{x:671,y:593,t:1528139981647};\\\", \\\"{x:660,y:594,t:1528139981664};\\\", \\\"{x:651,y:595,t:1528139981680};\\\", \\\"{x:645,y:595,t:1528139981696};\\\", \\\"{x:638,y:595,t:1528139981714};\\\", \\\"{x:631,y:595,t:1528139981731};\\\", \\\"{x:627,y:595,t:1528139981746};\\\", \\\"{x:625,y:595,t:1528139981764};\\\", \\\"{x:623,y:595,t:1528139981781};\\\", \\\"{x:623,y:594,t:1528139981797};\\\", \\\"{x:621,y:594,t:1528139981820};\\\", \\\"{x:619,y:593,t:1528139981860};\\\", \\\"{x:617,y:592,t:1528139981881};\\\", \\\"{x:616,y:591,t:1528139981897};\\\", \\\"{x:614,y:590,t:1528139981913};\\\", \\\"{x:613,y:590,t:1528139981931};\\\", \\\"{x:610,y:590,t:1528139982316};\\\", \\\"{x:597,y:608,t:1528139982332};\\\", \\\"{x:568,y:666,t:1528139982347};\\\", \\\"{x:554,y:695,t:1528139982364};\\\", \\\"{x:545,y:718,t:1528139982381};\\\", \\\"{x:539,y:730,t:1528139982398};\\\", \\\"{x:537,y:737,t:1528139982414};\\\", \\\"{x:537,y:738,t:1528139982430};\\\", \\\"{x:537,y:732,t:1528139982588};\\\", \\\"{x:537,y:715,t:1528139982599};\\\", \\\"{x:545,y:684,t:1528139982615};\\\", \\\"{x:564,y:649,t:1528139982631};\\\", \\\"{x:585,y:620,t:1528139982648};\\\", \\\"{x:600,y:602,t:1528139982664};\\\", \\\"{x:603,y:598,t:1528139982681};\\\", \\\"{x:603,y:595,t:1528139982970};\\\", \\\"{x:603,y:592,t:1528139982982};\\\", \\\"{x:603,y:590,t:1528139982998};\\\", \\\"{x:605,y:588,t:1528139983015};\\\", \\\"{x:605,y:587,t:1528139983035};\\\", \\\"{x:605,y:586,t:1528139983047};\\\", \\\"{x:605,y:585,t:1528139983065};\\\", \\\"{x:605,y:584,t:1528139983387};\\\", \\\"{x:602,y:592,t:1528139983398};\\\", \\\"{x:587,y:620,t:1528139983415};\\\", \\\"{x:574,y:648,t:1528139983432};\\\", \\\"{x:559,y:671,t:1528139983449};\\\", \\\"{x:550,y:688,t:1528139983465};\\\", \\\"{x:544,y:697,t:1528139983482};\\\", \\\"{x:543,y:700,t:1528139983499};\\\", \\\"{x:541,y:704,t:1528139983515};\\\", \\\"{x:539,y:710,t:1528139983532};\\\", \\\"{x:536,y:714,t:1528139983549};\\\", \\\"{x:536,y:716,t:1528139983565};\\\", \\\"{x:533,y:720,t:1528139983582};\\\", \\\"{x:532,y:720,t:1528139983598};\\\", \\\"{x:531,y:721,t:1528139983660};\\\", \\\"{x:529,y:725,t:1528139983716};\\\", \\\"{x:528,y:727,t:1528139983732};\\\", \\\"{x:523,y:734,t:1528139983749};\\\", \\\"{x:522,y:737,t:1528139983765};\\\", \\\"{x:521,y:737,t:1528139983783};\\\", \\\"{x:521,y:738,t:1528139983799};\\\" ] }, { \\\"rt\\\": 13169, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 614299, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:739,t:1528139986380};\\\", \\\"{x:520,y:729,t:1528139986539};\\\", \\\"{x:520,y:706,t:1528139986553};\\\", \\\"{x:520,y:688,t:1528139986568};\\\", \\\"{x:520,y:685,t:1528139986584};\\\", \\\"{x:520,y:679,t:1528139986600};\\\", \\\"{x:520,y:674,t:1528139986618};\\\", \\\"{x:520,y:673,t:1528139986634};\\\", \\\"{x:521,y:670,t:1528139986651};\\\", \\\"{x:521,y:669,t:1528139986667};\\\", \\\"{x:521,y:667,t:1528139986685};\\\", \\\"{x:522,y:665,t:1528139986701};\\\", \\\"{x:523,y:663,t:1528139986724};\\\", \\\"{x:523,y:662,t:1528139986748};\\\", \\\"{x:523,y:661,t:1528139986755};\\\", \\\"{x:523,y:659,t:1528139986771};\\\", \\\"{x:524,y:657,t:1528139986785};\\\", \\\"{x:525,y:657,t:1528139986801};\\\", \\\"{x:525,y:655,t:1528139986818};\\\", \\\"{x:526,y:651,t:1528139986836};\\\", \\\"{x:527,y:650,t:1528139986859};\\\", \\\"{x:527,y:649,t:1528139986868};\\\", \\\"{x:527,y:648,t:1528139986886};\\\", \\\"{x:528,y:646,t:1528139986901};\\\", \\\"{x:528,y:645,t:1528139986919};\\\", \\\"{x:528,y:644,t:1528139986936};\\\", \\\"{x:529,y:642,t:1528139986950};\\\", \\\"{x:530,y:639,t:1528139986968};\\\", \\\"{x:530,y:638,t:1528139986985};\\\", \\\"{x:531,y:636,t:1528139987001};\\\", \\\"{x:531,y:635,t:1528139987018};\\\", \\\"{x:532,y:633,t:1528139987035};\\\", \\\"{x:532,y:632,t:1528139987059};\\\", \\\"{x:532,y:630,t:1528139987076};\\\", \\\"{x:532,y:629,t:1528139987085};\\\", \\\"{x:533,y:629,t:1528139987101};\\\", \\\"{x:533,y:627,t:1528139987118};\\\", \\\"{x:533,y:626,t:1528139987139};\\\", \\\"{x:533,y:624,t:1528139987164};\\\", \\\"{x:533,y:623,t:1528139987180};\\\", \\\"{x:533,y:622,t:1528139987196};\\\", \\\"{x:530,y:622,t:1528139987339};\\\", \\\"{x:512,y:629,t:1528139987352};\\\", \\\"{x:454,y:662,t:1528139987370};\\\", \\\"{x:407,y:684,t:1528139987387};\\\", \\\"{x:372,y:696,t:1528139987402};\\\", \\\"{x:339,y:698,t:1528139987418};\\\", \\\"{x:294,y:698,t:1528139987435};\\\", \\\"{x:273,y:698,t:1528139987452};\\\", \\\"{x:253,y:698,t:1528139987468};\\\", \\\"{x:242,y:699,t:1528139987485};\\\", \\\"{x:233,y:702,t:1528139987502};\\\", \\\"{x:225,y:702,t:1528139987518};\\\", \\\"{x:221,y:704,t:1528139987535};\\\", \\\"{x:215,y:706,t:1528139987553};\\\", \\\"{x:205,y:708,t:1528139987568};\\\", \\\"{x:191,y:711,t:1528139987585};\\\", \\\"{x:172,y:713,t:1528139987602};\\\", \\\"{x:146,y:716,t:1528139987619};\\\", \\\"{x:128,y:716,t:1528139987635};\\\", \\\"{x:102,y:716,t:1528139987652};\\\", \\\"{x:75,y:714,t:1528139987669};\\\", \\\"{x:42,y:709,t:1528139987685};\\\", \\\"{x:15,y:705,t:1528139987702};\\\", \\\"{x:0,y:697,t:1528139987719};\\\", \\\"{x:0,y:687,t:1528139987735};\\\", \\\"{x:0,y:681,t:1528139987752};\\\", \\\"{x:0,y:671,t:1528139987769};\\\", \\\"{x:0,y:660,t:1528139987785};\\\", \\\"{x:0,y:652,t:1528139987802};\\\", \\\"{x:0,y:642,t:1528139987819};\\\", \\\"{x:0,y:637,t:1528139987835};\\\", \\\"{x:0,y:633,t:1528139987853};\\\", \\\"{x:0,y:630,t:1528139987869};\\\", \\\"{x:0,y:622,t:1528139987885};\\\", \\\"{x:0,y:619,t:1528139987902};\\\", \\\"{x:9,y:615,t:1528139988021};\\\", \\\"{x:84,y:608,t:1528139988036};\\\", \\\"{x:212,y:604,t:1528139988054};\\\", \\\"{x:375,y:604,t:1528139988069};\\\", \\\"{x:505,y:602,t:1528139988086};\\\", \\\"{x:619,y:598,t:1528139988102};\\\", \\\"{x:704,y:594,t:1528139988119};\\\", \\\"{x:754,y:593,t:1528139988137};\\\", \\\"{x:779,y:593,t:1528139988152};\\\", \\\"{x:797,y:590,t:1528139988168};\\\", \\\"{x:819,y:589,t:1528139988186};\\\", \\\"{x:849,y:589,t:1528139988202};\\\", \\\"{x:928,y:592,t:1528139988219};\\\", \\\"{x:990,y:602,t:1528139988236};\\\", \\\"{x:1023,y:605,t:1528139988252};\\\", \\\"{x:1044,y:606,t:1528139988269};\\\", \\\"{x:1053,y:606,t:1528139988286};\\\", \\\"{x:1056,y:606,t:1528139988302};\\\", \\\"{x:1057,y:606,t:1528139988339};\\\", \\\"{x:1059,y:606,t:1528139988355};\\\", \\\"{x:1064,y:606,t:1528139988370};\\\", \\\"{x:1083,y:606,t:1528139988386};\\\", \\\"{x:1106,y:600,t:1528139988402};\\\", \\\"{x:1139,y:589,t:1528139988420};\\\", \\\"{x:1164,y:583,t:1528139988436};\\\", \\\"{x:1189,y:576,t:1528139988453};\\\", \\\"{x:1219,y:568,t:1528139988470};\\\", \\\"{x:1243,y:563,t:1528139988486};\\\", \\\"{x:1264,y:560,t:1528139988503};\\\", \\\"{x:1284,y:557,t:1528139988519};\\\", \\\"{x:1311,y:554,t:1528139988537};\\\", \\\"{x:1330,y:552,t:1528139988552};\\\", \\\"{x:1349,y:548,t:1528139988570};\\\", \\\"{x:1368,y:543,t:1528139988587};\\\", \\\"{x:1376,y:542,t:1528139988602};\\\", \\\"{x:1384,y:541,t:1528139988620};\\\", \\\"{x:1387,y:541,t:1528139988636};\\\", \\\"{x:1389,y:540,t:1528139988653};\\\", \\\"{x:1390,y:540,t:1528139988669};\\\", \\\"{x:1394,y:540,t:1528139988687};\\\", \\\"{x:1414,y:538,t:1528139988702};\\\", \\\"{x:1436,y:538,t:1528139988720};\\\", \\\"{x:1458,y:537,t:1528139988736};\\\", \\\"{x:1471,y:537,t:1528139988752};\\\", \\\"{x:1480,y:536,t:1528139988770};\\\", \\\"{x:1487,y:535,t:1528139988787};\\\", \\\"{x:1507,y:534,t:1528139988804};\\\", \\\"{x:1513,y:534,t:1528139988820};\\\", \\\"{x:1526,y:534,t:1528139988837};\\\", \\\"{x:1547,y:534,t:1528139988854};\\\", \\\"{x:1564,y:534,t:1528139988870};\\\", \\\"{x:1571,y:534,t:1528139988886};\\\", \\\"{x:1572,y:534,t:1528139988904};\\\", \\\"{x:1575,y:534,t:1528139988919};\\\", \\\"{x:1577,y:534,t:1528139988936};\\\", \\\"{x:1578,y:534,t:1528139989060};\\\", \\\"{x:1578,y:535,t:1528139989091};\\\", \\\"{x:1578,y:537,t:1528139989103};\\\", \\\"{x:1578,y:540,t:1528139989119};\\\", \\\"{x:1577,y:544,t:1528139989136};\\\", \\\"{x:1575,y:545,t:1528139989153};\\\", \\\"{x:1571,y:549,t:1528139989169};\\\", \\\"{x:1569,y:551,t:1528139989186};\\\", \\\"{x:1566,y:555,t:1528139989203};\\\", \\\"{x:1566,y:558,t:1528139989219};\\\", \\\"{x:1564,y:560,t:1528139989236};\\\", \\\"{x:1563,y:562,t:1528139989253};\\\", \\\"{x:1560,y:565,t:1528139989270};\\\", \\\"{x:1559,y:568,t:1528139989286};\\\", \\\"{x:1556,y:572,t:1528139989303};\\\", \\\"{x:1553,y:577,t:1528139989319};\\\", \\\"{x:1548,y:584,t:1528139989336};\\\", \\\"{x:1544,y:590,t:1528139989353};\\\", \\\"{x:1535,y:603,t:1528139989369};\\\", \\\"{x:1528,y:611,t:1528139989386};\\\", \\\"{x:1515,y:627,t:1528139989403};\\\", \\\"{x:1507,y:638,t:1528139989419};\\\", \\\"{x:1500,y:649,t:1528139989437};\\\", \\\"{x:1493,y:664,t:1528139989453};\\\", \\\"{x:1485,y:675,t:1528139989470};\\\", \\\"{x:1477,y:687,t:1528139989486};\\\", \\\"{x:1469,y:700,t:1528139989503};\\\", \\\"{x:1462,y:716,t:1528139989519};\\\", \\\"{x:1450,y:736,t:1528139989537};\\\", \\\"{x:1437,y:757,t:1528139989554};\\\", \\\"{x:1425,y:780,t:1528139989570};\\\", \\\"{x:1413,y:807,t:1528139989587};\\\", \\\"{x:1386,y:871,t:1528139989604};\\\", \\\"{x:1373,y:901,t:1528139989619};\\\", \\\"{x:1361,y:924,t:1528139989637};\\\", \\\"{x:1351,y:940,t:1528139989654};\\\", \\\"{x:1343,y:955,t:1528139989670};\\\", \\\"{x:1339,y:966,t:1528139989686};\\\", \\\"{x:1337,y:972,t:1528139989704};\\\", \\\"{x:1337,y:977,t:1528139989720};\\\", \\\"{x:1334,y:981,t:1528139989737};\\\", \\\"{x:1334,y:987,t:1528139989755};\\\", \\\"{x:1331,y:993,t:1528139989771};\\\", \\\"{x:1330,y:997,t:1528139989786};\\\", \\\"{x:1330,y:1000,t:1528139989803};\\\", \\\"{x:1330,y:1002,t:1528139989821};\\\", \\\"{x:1330,y:1003,t:1528139989844};\\\", \\\"{x:1334,y:1003,t:1528139989940};\\\", \\\"{x:1338,y:1002,t:1528139989954};\\\", \\\"{x:1347,y:1000,t:1528139989970};\\\", \\\"{x:1359,y:996,t:1528139989987};\\\", \\\"{x:1367,y:994,t:1528139990004};\\\", \\\"{x:1370,y:993,t:1528139990019};\\\", \\\"{x:1377,y:992,t:1528139990037};\\\", \\\"{x:1380,y:992,t:1528139990053};\\\", \\\"{x:1383,y:992,t:1528139990070};\\\", \\\"{x:1384,y:992,t:1528139990087};\\\", \\\"{x:1385,y:992,t:1528139990104};\\\", \\\"{x:1386,y:992,t:1528139990196};\\\", \\\"{x:1388,y:991,t:1528139990212};\\\", \\\"{x:1388,y:990,t:1528139990221};\\\", \\\"{x:1389,y:990,t:1528139990243};\\\", \\\"{x:1390,y:990,t:1528139990253};\\\", \\\"{x:1394,y:990,t:1528139990271};\\\", \\\"{x:1397,y:990,t:1528139990286};\\\", \\\"{x:1401,y:990,t:1528139990303};\\\", \\\"{x:1404,y:990,t:1528139990320};\\\", \\\"{x:1407,y:989,t:1528139990337};\\\", \\\"{x:1411,y:988,t:1528139990353};\\\", \\\"{x:1415,y:987,t:1528139990371};\\\", \\\"{x:1420,y:985,t:1528139990387};\\\", \\\"{x:1428,y:983,t:1528139990404};\\\", \\\"{x:1434,y:982,t:1528139990420};\\\", \\\"{x:1442,y:980,t:1528139990437};\\\", \\\"{x:1451,y:977,t:1528139990454};\\\", \\\"{x:1462,y:974,t:1528139990471};\\\", \\\"{x:1470,y:973,t:1528139990486};\\\", \\\"{x:1475,y:972,t:1528139990503};\\\", \\\"{x:1480,y:970,t:1528139990521};\\\", \\\"{x:1483,y:969,t:1528139990537};\\\", \\\"{x:1487,y:968,t:1528139990555};\\\", \\\"{x:1490,y:966,t:1528139990570};\\\", \\\"{x:1491,y:966,t:1528139990586};\\\", \\\"{x:1490,y:966,t:1528139991060};\\\", \\\"{x:1488,y:966,t:1528139991076};\\\", \\\"{x:1486,y:964,t:1528139991088};\\\", \\\"{x:1486,y:962,t:1528139991103};\\\", \\\"{x:1484,y:958,t:1528139991120};\\\", \\\"{x:1484,y:955,t:1528139991137};\\\", \\\"{x:1483,y:953,t:1528139991153};\\\", \\\"{x:1482,y:951,t:1528139991170};\\\", \\\"{x:1481,y:947,t:1528139991187};\\\", \\\"{x:1481,y:944,t:1528139991203};\\\", \\\"{x:1480,y:938,t:1528139991220};\\\", \\\"{x:1479,y:933,t:1528139991238};\\\", \\\"{x:1479,y:930,t:1528139991253};\\\", \\\"{x:1479,y:923,t:1528139991271};\\\", \\\"{x:1479,y:917,t:1528139991288};\\\", \\\"{x:1482,y:906,t:1528139991303};\\\", \\\"{x:1485,y:896,t:1528139991321};\\\", \\\"{x:1488,y:885,t:1528139991338};\\\", \\\"{x:1493,y:870,t:1528139991353};\\\", \\\"{x:1498,y:859,t:1528139991370};\\\", \\\"{x:1504,y:844,t:1528139991388};\\\", \\\"{x:1507,y:839,t:1528139991403};\\\", \\\"{x:1508,y:835,t:1528139991421};\\\", \\\"{x:1509,y:830,t:1528139991438};\\\", \\\"{x:1510,y:827,t:1528139991453};\\\", \\\"{x:1510,y:826,t:1528139991740};\\\", \\\"{x:1510,y:822,t:1528139991754};\\\", \\\"{x:1510,y:815,t:1528139991771};\\\", \\\"{x:1510,y:808,t:1528139991788};\\\", \\\"{x:1510,y:805,t:1528139991804};\\\", \\\"{x:1510,y:802,t:1528139991821};\\\", \\\"{x:1510,y:799,t:1528139991838};\\\", \\\"{x:1509,y:794,t:1528139991855};\\\", \\\"{x:1509,y:790,t:1528139991871};\\\", \\\"{x:1508,y:788,t:1528139991888};\\\", \\\"{x:1508,y:785,t:1528139991905};\\\", \\\"{x:1508,y:784,t:1528139991921};\\\", \\\"{x:1508,y:783,t:1528139991938};\\\", \\\"{x:1508,y:782,t:1528139991954};\\\", \\\"{x:1508,y:781,t:1528139991972};\\\", \\\"{x:1507,y:778,t:1528139991987};\\\", \\\"{x:1507,y:775,t:1528139992005};\\\", \\\"{x:1507,y:774,t:1528139992020};\\\", \\\"{x:1507,y:772,t:1528139992038};\\\", \\\"{x:1506,y:769,t:1528139992055};\\\", \\\"{x:1505,y:767,t:1528139992071};\\\", \\\"{x:1505,y:765,t:1528139992088};\\\", \\\"{x:1505,y:762,t:1528139992105};\\\", \\\"{x:1504,y:759,t:1528139992120};\\\", \\\"{x:1504,y:756,t:1528139992137};\\\", \\\"{x:1504,y:754,t:1528139992154};\\\", \\\"{x:1503,y:750,t:1528139992171};\\\", \\\"{x:1502,y:745,t:1528139992188};\\\", \\\"{x:1501,y:744,t:1528139992205};\\\", \\\"{x:1501,y:742,t:1528139992221};\\\", \\\"{x:1500,y:740,t:1528139992238};\\\", \\\"{x:1499,y:737,t:1528139992254};\\\", \\\"{x:1499,y:735,t:1528139992271};\\\", \\\"{x:1499,y:734,t:1528139992292};\\\", \\\"{x:1499,y:732,t:1528139992316};\\\", \\\"{x:1499,y:730,t:1528139992603};\\\", \\\"{x:1499,y:725,t:1528139992610};\\\", \\\"{x:1498,y:720,t:1528139992620};\\\", \\\"{x:1496,y:707,t:1528139992637};\\\", \\\"{x:1491,y:687,t:1528139992654};\\\", \\\"{x:1488,y:663,t:1528139992670};\\\", \\\"{x:1487,y:644,t:1528139992687};\\\", \\\"{x:1485,y:623,t:1528139992705};\\\", \\\"{x:1482,y:600,t:1528139992721};\\\", \\\"{x:1480,y:575,t:1528139992737};\\\", \\\"{x:1479,y:549,t:1528139992754};\\\", \\\"{x:1479,y:506,t:1528139992771};\\\", \\\"{x:1476,y:468,t:1528139992787};\\\", \\\"{x:1472,y:430,t:1528139992804};\\\", \\\"{x:1467,y:398,t:1528139992822};\\\", \\\"{x:1463,y:375,t:1528139992838};\\\", \\\"{x:1462,y:362,t:1528139992854};\\\", \\\"{x:1459,y:351,t:1528139992871};\\\", \\\"{x:1458,y:337,t:1528139992887};\\\", \\\"{x:1457,y:330,t:1528139992904};\\\", \\\"{x:1457,y:329,t:1528139992921};\\\", \\\"{x:1456,y:326,t:1528139992937};\\\", \\\"{x:1456,y:324,t:1528139992955};\\\", \\\"{x:1455,y:320,t:1528139992971};\\\", \\\"{x:1455,y:318,t:1528139992987};\\\", \\\"{x:1455,y:316,t:1528139993004};\\\", \\\"{x:1455,y:313,t:1528139993021};\\\", \\\"{x:1455,y:309,t:1528139993037};\\\", \\\"{x:1455,y:305,t:1528139993054};\\\", \\\"{x:1455,y:300,t:1528139993072};\\\", \\\"{x:1455,y:296,t:1528139993088};\\\", \\\"{x:1455,y:291,t:1528139993105};\\\", \\\"{x:1456,y:287,t:1528139993122};\\\", \\\"{x:1457,y:285,t:1528139993138};\\\", \\\"{x:1457,y:284,t:1528139993154};\\\", \\\"{x:1458,y:283,t:1528139993171};\\\", \\\"{x:1458,y:282,t:1528139993188};\\\", \\\"{x:1460,y:285,t:1528139994052};\\\", \\\"{x:1462,y:286,t:1528139994060};\\\", \\\"{x:1462,y:287,t:1528139994071};\\\", \\\"{x:1464,y:289,t:1528139994089};\\\", \\\"{x:1466,y:291,t:1528139994105};\\\", \\\"{x:1468,y:292,t:1528139994122};\\\", \\\"{x:1469,y:293,t:1528139994139};\\\", \\\"{x:1469,y:294,t:1528139994155};\\\", \\\"{x:1469,y:296,t:1528139994188};\\\", \\\"{x:1469,y:297,t:1528139994205};\\\", \\\"{x:1470,y:299,t:1528139994221};\\\", \\\"{x:1470,y:300,t:1528139994238};\\\", \\\"{x:1470,y:303,t:1528139994254};\\\", \\\"{x:1470,y:304,t:1528139994271};\\\", \\\"{x:1470,y:310,t:1528139994288};\\\", \\\"{x:1470,y:315,t:1528139994304};\\\", \\\"{x:1470,y:323,t:1528139994321};\\\", \\\"{x:1472,y:334,t:1528139994338};\\\", \\\"{x:1473,y:346,t:1528139994354};\\\", \\\"{x:1477,y:371,t:1528139994371};\\\", \\\"{x:1481,y:390,t:1528139994389};\\\", \\\"{x:1481,y:411,t:1528139994404};\\\", \\\"{x:1481,y:438,t:1528139994421};\\\", \\\"{x:1481,y:469,t:1528139994438};\\\", \\\"{x:1481,y:505,t:1528139994454};\\\", \\\"{x:1481,y:541,t:1528139994472};\\\", \\\"{x:1481,y:573,t:1528139994489};\\\", \\\"{x:1481,y:607,t:1528139994504};\\\", \\\"{x:1481,y:628,t:1528139994521};\\\", \\\"{x:1481,y:646,t:1528139994539};\\\", \\\"{x:1481,y:664,t:1528139994554};\\\", \\\"{x:1482,y:689,t:1528139994571};\\\", \\\"{x:1482,y:704,t:1528139994589};\\\", \\\"{x:1482,y:715,t:1528139994605};\\\", \\\"{x:1483,y:722,t:1528139994622};\\\", \\\"{x:1483,y:728,t:1528139994639};\\\", \\\"{x:1483,y:731,t:1528139994655};\\\", \\\"{x:1483,y:732,t:1528139994671};\\\", \\\"{x:1483,y:734,t:1528139994688};\\\", \\\"{x:1483,y:735,t:1528139994704};\\\", \\\"{x:1483,y:739,t:1528139994722};\\\", \\\"{x:1483,y:744,t:1528139994738};\\\", \\\"{x:1483,y:749,t:1528139994754};\\\", \\\"{x:1483,y:758,t:1528139994771};\\\", \\\"{x:1483,y:769,t:1528139994788};\\\", \\\"{x:1483,y:783,t:1528139994806};\\\", \\\"{x:1483,y:793,t:1528139994821};\\\", \\\"{x:1483,y:799,t:1528139994838};\\\", \\\"{x:1483,y:805,t:1528139994855};\\\", \\\"{x:1483,y:812,t:1528139994872};\\\", \\\"{x:1483,y:817,t:1528139994889};\\\", \\\"{x:1483,y:819,t:1528139994906};\\\", \\\"{x:1483,y:821,t:1528139994921};\\\", \\\"{x:1483,y:825,t:1528139994941};\\\", \\\"{x:1483,y:831,t:1528139994955};\\\", \\\"{x:1483,y:835,t:1528139994971};\\\", \\\"{x:1483,y:839,t:1528139994990};\\\", \\\"{x:1483,y:843,t:1528139995005};\\\", \\\"{x:1482,y:849,t:1528139995021};\\\", \\\"{x:1481,y:853,t:1528139995039};\\\", \\\"{x:1481,y:855,t:1528139995056};\\\", \\\"{x:1481,y:856,t:1528139995071};\\\", \\\"{x:1481,y:860,t:1528139995089};\\\", \\\"{x:1481,y:866,t:1528139995106};\\\", \\\"{x:1481,y:869,t:1528139995122};\\\", \\\"{x:1481,y:871,t:1528139995139};\\\", \\\"{x:1481,y:874,t:1528139995156};\\\", \\\"{x:1481,y:876,t:1528139995172};\\\", \\\"{x:1481,y:879,t:1528139995189};\\\", \\\"{x:1481,y:883,t:1528139995206};\\\", \\\"{x:1481,y:890,t:1528139995222};\\\", \\\"{x:1481,y:898,t:1528139995239};\\\", \\\"{x:1481,y:905,t:1528139995256};\\\", \\\"{x:1481,y:910,t:1528139995272};\\\", \\\"{x:1480,y:914,t:1528139995289};\\\", \\\"{x:1480,y:919,t:1528139995305};\\\", \\\"{x:1480,y:923,t:1528139995321};\\\", \\\"{x:1480,y:927,t:1528139995339};\\\", \\\"{x:1480,y:931,t:1528139995356};\\\", \\\"{x:1478,y:933,t:1528139995371};\\\", \\\"{x:1478,y:934,t:1528139995389};\\\", \\\"{x:1478,y:935,t:1528139995406};\\\", \\\"{x:1477,y:936,t:1528139995421};\\\", \\\"{x:1476,y:936,t:1528139995444};\\\", \\\"{x:1474,y:936,t:1528139995456};\\\", \\\"{x:1462,y:935,t:1528139995472};\\\", \\\"{x:1444,y:928,t:1528139995488};\\\", \\\"{x:1421,y:916,t:1528139995506};\\\", \\\"{x:1372,y:886,t:1528139995521};\\\", \\\"{x:1285,y:836,t:1528139995539};\\\", \\\"{x:1122,y:753,t:1528139995555};\\\", \\\"{x:1015,y:710,t:1528139995573};\\\", \\\"{x:910,y:662,t:1528139995589};\\\", \\\"{x:846,y:634,t:1528139995608};\\\", \\\"{x:782,y:606,t:1528139995622};\\\", \\\"{x:722,y:573,t:1528139995656};\\\", \\\"{x:716,y:568,t:1528139995675};\\\", \\\"{x:715,y:568,t:1528139995691};\\\", \\\"{x:714,y:568,t:1528139995971};\\\", \\\"{x:711,y:566,t:1528139995980};\\\", \\\"{x:708,y:565,t:1528139995992};\\\", \\\"{x:698,y:565,t:1528139996009};\\\", \\\"{x:684,y:567,t:1528139996026};\\\", \\\"{x:662,y:573,t:1528139996043};\\\", \\\"{x:639,y:575,t:1528139996058};\\\", \\\"{x:607,y:578,t:1528139996077};\\\", \\\"{x:596,y:578,t:1528139996092};\\\", \\\"{x:590,y:578,t:1528139996108};\\\", \\\"{x:586,y:578,t:1528139996125};\\\", \\\"{x:584,y:579,t:1528139996188};\\\", \\\"{x:583,y:580,t:1528139996212};\\\", \\\"{x:582,y:581,t:1528139996225};\\\", \\\"{x:582,y:582,t:1528139996243};\\\", \\\"{x:582,y:585,t:1528139996259};\\\", \\\"{x:582,y:586,t:1528139996283};\\\", \\\"{x:582,y:588,t:1528139996299};\\\", \\\"{x:583,y:588,t:1528139996310};\\\", \\\"{x:586,y:589,t:1528139996326};\\\", \\\"{x:589,y:591,t:1528139996343};\\\", \\\"{x:593,y:592,t:1528139996360};\\\", \\\"{x:595,y:593,t:1528139996376};\\\", \\\"{x:597,y:595,t:1528139996392};\\\", \\\"{x:599,y:595,t:1528139996411};\\\", \\\"{x:600,y:596,t:1528139996437};\\\", \\\"{x:602,y:596,t:1528139996467};\\\", \\\"{x:599,y:599,t:1528139996876};\\\", \\\"{x:563,y:605,t:1528139996893};\\\", \\\"{x:487,y:611,t:1528139996910};\\\", \\\"{x:415,y:611,t:1528139996927};\\\", \\\"{x:344,y:597,t:1528139996943};\\\", \\\"{x:319,y:580,t:1528139996960};\\\", \\\"{x:298,y:565,t:1528139996977};\\\", \\\"{x:296,y:555,t:1528139996994};\\\", \\\"{x:294,y:553,t:1528139997009};\\\", \\\"{x:294,y:552,t:1528139997027};\\\", \\\"{x:297,y:550,t:1528139997043};\\\", \\\"{x:301,y:549,t:1528139997059};\\\", \\\"{x:308,y:549,t:1528139997076};\\\", \\\"{x:312,y:549,t:1528139997094};\\\", \\\"{x:317,y:549,t:1528139997109};\\\", \\\"{x:322,y:549,t:1528139997127};\\\", \\\"{x:328,y:550,t:1528139997144};\\\", \\\"{x:336,y:553,t:1528139997159};\\\", \\\"{x:341,y:554,t:1528139997176};\\\", \\\"{x:349,y:557,t:1528139997194};\\\", \\\"{x:352,y:558,t:1528139997209};\\\", \\\"{x:359,y:562,t:1528139997226};\\\", \\\"{x:366,y:565,t:1528139997244};\\\", \\\"{x:368,y:567,t:1528139997260};\\\", \\\"{x:370,y:570,t:1528139997278};\\\", \\\"{x:370,y:571,t:1528139997293};\\\", \\\"{x:373,y:577,t:1528139997309};\\\", \\\"{x:375,y:583,t:1528139997326};\\\", \\\"{x:378,y:589,t:1528139997344};\\\", \\\"{x:379,y:593,t:1528139997360};\\\", \\\"{x:380,y:597,t:1528139997376};\\\", \\\"{x:381,y:597,t:1528139997393};\\\", \\\"{x:381,y:598,t:1528139997811};\\\", \\\"{x:382,y:606,t:1528139997852};\\\", \\\"{x:383,y:613,t:1528139997861};\\\", \\\"{x:392,y:633,t:1528139997878};\\\", \\\"{x:406,y:659,t:1528139997894};\\\", \\\"{x:428,y:692,t:1528139997910};\\\", \\\"{x:452,y:724,t:1528139997927};\\\", \\\"{x:475,y:750,t:1528139997944};\\\", \\\"{x:489,y:762,t:1528139997960};\\\", \\\"{x:498,y:774,t:1528139997978};\\\", \\\"{x:505,y:781,t:1528139997993};\\\", \\\"{x:508,y:783,t:1528139998010};\\\", \\\"{x:508,y:782,t:1528139998155};\\\", \\\"{x:508,y:780,t:1528139998163};\\\", \\\"{x:508,y:777,t:1528139998177};\\\", \\\"{x:508,y:772,t:1528139998194};\\\", \\\"{x:508,y:770,t:1528139998210};\\\", \\\"{x:508,y:766,t:1528139998229};\\\" ] }, { \\\"rt\\\": 39198, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 654950, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Coffee break for F, B. Shift start for M,L\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10574, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Bangladesh\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 666530, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 15013, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 682556, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 5858, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 689748, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"02TJQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"02TJQ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 219, dom: 1092, initialDom: 1166",
  "javascriptErrors": []
}