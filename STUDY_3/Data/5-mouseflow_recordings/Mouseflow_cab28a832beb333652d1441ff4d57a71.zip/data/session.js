var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cab28a832beb333652d1441ff4d57a71",
  "created": "2018-05-25T11:11:12.3881294-07:00",
  "lastActivity": "2018-05-25T11:12:49.9441294-07:00",
  "pageViews": [
    {
      "id": "052512724a6dc1f9c527ab4cfe4d3a184157461f",
      "startTime": "2018-05-25T11:11:12.3881294-07:00",
      "endTime": "2018-05-25T11:12:49.9441294-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 97556,
      "engagementTime": 39704,
      "scroll": 100.0,
      "tags": [
        "click-rage",
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 97556,
  "engagementTime": 39704,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "click-rage",
    "form-interact"
  ],
  "variables": [
    "SID=K8DJ0",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7ea58fc0308fde8471bd48d0056ec0e8",
  "gdpr": false
}