var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5b4d3b04b334de2578a90a2766e72c28",
  "created": "2018-06-04T12:22:38.5557591-07:00",
  "lastActivity": "2018-06-04T12:23:05.7057591-07:00",
  "pageViews": [
    {
      "id": "0604380742ecaf4b5ce93f8e87536784864eed41",
      "startTime": "2018-06-04T12:22:38.5557591-07:00",
      "endTime": "2018-06-04T12:23:05.7057591-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 27150,
      "engagementTime": 25951,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27150,
  "engagementTime": 25951,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8e998fea52706e43c2973c385a0093e9",
  "gdpr": false
}