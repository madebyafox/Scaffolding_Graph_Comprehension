var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cdd6ebee2f52e9ffe4b9225e89a825c5",
  "created": "2018-06-04T12:17:47.2153459-07:00",
  "lastActivity": "2018-06-04T12:17:53.8453459-07:00",
  "pageViews": [
    {
      "id": "06044784a9eade7d09e63ab5f33889cdeaa48034",
      "startTime": "2018-06-04T12:17:47.2153459-07:00",
      "endTime": "2018-06-04T12:17:53.8453459-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 6630,
      "engagementTime": 6630,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6630,
  "engagementTime": 6630,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BK993",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "27c7f7fc8c7b2e3330c70c2dfcf085f2",
  "gdpr": false
}