var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "077e0e43b511240f5d61f1b4e94a5919",
  "created": "2018-05-21T09:10:34.4003711-07:00",
  "lastActivity": "2018-05-21T09:11:07.0856914-07:00",
  "pageViews": [
    {
      "id": "052134994d98c8e03fb110d26b052e72c9281057",
      "startTime": "2018-05-21T09:10:34.4003711-07:00",
      "endTime": "2018-05-21T09:11:07.0856914-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 32714,
      "engagementTime": 32714,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32714,
  "engagementTime": 32714,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G72GB",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c8b09e530b25d07346f71b223b902714",
  "gdpr": false
}