var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "645e620f10b576624abcca9588315637",
  "created": "2018-05-25T11:10:47.4687275-07:00",
  "lastActivity": "2018-05-25T11:12:03.8848493-07:00",
  "pageViews": [
    {
      "id": "05254718d2386a9580b9450e0b701c842e33a4f2",
      "startTime": "2018-05-25T11:10:47.4687275-07:00",
      "endTime": "2018-05-25T11:12:03.8848493-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 76476,
      "engagementTime": 67129,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 76476,
  "engagementTime": 67129,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2WQ0M",
    "CONDITION=114",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f1e5bd058eff9faa1a7ce99a5dc78f3b",
  "gdpr": false
}