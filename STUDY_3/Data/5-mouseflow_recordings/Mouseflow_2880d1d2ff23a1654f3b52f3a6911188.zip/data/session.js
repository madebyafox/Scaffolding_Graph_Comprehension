var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2880d1d2ff23a1654f3b52f3a6911188",
  "created": "2018-05-15T17:08:11.5570079-07:00",
  "lastActivity": "2018-05-15T17:08:21.3029809-07:00",
  "pageViews": [
    {
      "id": "05151187ee618ae8f420b4cc2d20bd061cceff78",
      "startTime": "2018-05-15T17:08:11.7849809-07:00",
      "endTime": "2018-05-15T17:08:21.3029809-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 9518,
      "engagementTime": 9486,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9518,
  "engagementTime": 9486,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QY1F7",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3044eea442d805dc4f0b2246a3a44e0d",
  "gdpr": false
}