var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b99dbde7a8de79b7af171dc46a86fc7b",
  "created": "2018-05-25T09:08:58.9739639-07:00",
  "lastActivity": "2018-05-25T09:09:25.5939639-07:00",
  "pageViews": [
    {
      "id": "052559469e1a8911ea5d64205c3a5828cab34df4",
      "startTime": "2018-05-25T09:08:58.9739639-07:00",
      "endTime": "2018-05-25T09:09:25.5939639-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 26620,
      "engagementTime": 19522,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26620,
  "engagementTime": 19522,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EJPRM",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e2cccf6c43e390d99b2db8264320ea66",
  "gdpr": false
}