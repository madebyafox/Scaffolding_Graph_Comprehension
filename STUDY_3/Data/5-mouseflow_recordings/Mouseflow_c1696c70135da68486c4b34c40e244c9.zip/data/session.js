var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c1696c70135da68486c4b34c40e244c9",
  "created": "2018-05-25T11:17:26.1697469-07:00",
  "lastActivity": "2018-05-25T11:17:59.4627469-07:00",
  "pageViews": [
    {
      "id": "05252619cafd5379969c47e97c91f040ad89681b",
      "startTime": "2018-05-25T11:17:26.1697469-07:00",
      "endTime": "2018-05-25T11:17:59.4627469-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 33293,
      "engagementTime": 27643,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33293,
  "engagementTime": 27643,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FK2HU",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3ec88daaccd6a6fad1bfeb4a8a86b88f",
  "gdpr": false
}