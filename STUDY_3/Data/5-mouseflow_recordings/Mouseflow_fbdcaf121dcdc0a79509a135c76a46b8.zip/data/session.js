var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fbdcaf121dcdc0a79509a135c76a46b8",
  "created": "2018-05-18T11:19:21.1733338-07:00",
  "lastActivity": "2018-05-18T11:19:38.482347-07:00",
  "pageViews": [
    {
      "id": "05182114703d4358cdc0c4c63a382698c9c7699b",
      "startTime": "2018-05-18T11:19:21.185347-07:00",
      "endTime": "2018-05-18T11:19:38.482347-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 17297,
      "engagementTime": 17197,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17297,
  "engagementTime": 17197,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.51",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T2OHS",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fb21756f8042320715d52e30adc6752c",
  "gdpr": false
}